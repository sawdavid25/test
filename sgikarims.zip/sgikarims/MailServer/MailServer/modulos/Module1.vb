﻿Module Module1
#Region "Estructuras"


    'NOTA en vez de udtConexion debe ser una colección o lista con al menos un elemento (local)
    '     en el caso de estar en modo depuración, el primer elemento sería Debug

    'Public Conexiones As List(Of udtCredencial)
    'Public MyCnnInfo As udtCredencial '<<< credenciales de la conexión activa
    'Public dictionary As New Dictionary(Of Integer, String)


    Public Structure udtConexion
        Dim local As udtCredencial
        Dim servidor As udtCredencial
        Dim wan1 As udtCredencial
        Dim wan2 As udtCredencial
    End Structure

    Public Structure udtCredencial
        Dim Servidor As String
        Dim Usuario As String
        Dim Clave As String
        Dim Base As String
        Dim Modo As String
        Dim Def As Integer
        'Cadena de conexión completa
        Dim ConnectionString As String
    End Structure

    Public Structure udtSesion
        Dim IdEmpresa As Integer
        Dim Empresa As String
        Dim Estacion As String
        Dim IP As String
        Dim idUsuario As Integer
        Dim Usuario As String
        Dim Firma As String
        Dim Nivel As String
        Dim BaseConta As String
        Dim DivisaLocal As Integer
        Dim DivisaLocalSimbolo As String
        Dim DivisaExtranjera As Integer
        Dim DivisaExtranjeraSimbolo As String
    End Structure



    Public Structure udtSistema
        Dim Version As String
        Dim Modo As String
    End Structure

    Public Structure udtUnidad
        Dim id As Integer
        Dim simbolo As String
        Dim nombre As String
        Dim factor As Double

    End Structure

    Public Structure udtDivisas
        Dim Local As udtUnidad
        Dim Externa As udtUnidad
    End Structure




#End Region

#Region "Variables Globales"

    ' ver arriba Conexiones y MyCnnInfo
    Public Conexion As New udtConexion

    Public Sistema As New udtSistema
    Public Sesion As New udtSesion

    Public MyCnn As New ClsConexion
    Public cFunciones As New clsFunciones

    ' ver arriba MyCnnInfo
    Public strConexion As String = ""


    Public strModo As String = ""

    Public Divisa As udtDivisas
    Public Externa As udtDivisas
    Public BaseConta As String = STR_VACIO
    Public Tasa As Double = 0.0
    Public strBusquedaLista As String = STR_VACIO

    Public Fprincipal As New Form1


#End Region
#Region "Constantes"


    Public Const MAIL_HOST As String = "192.168.4.137"
    Public Const MAIL_USER As String = "mailserver"
    Public Const MAIL_PASS As String = "//mail**02017"
    Public Const MAIL_BASE As String = "MailServer"

    Public Const NO_FILA As Integer = (-1)
    Public Const STR_VACIO As String = ""
    Public Const INT_CERO As Integer = 0
    Public Const INT_UNO As Integer = 1
    Public Const MYSQL_AÑO As String = "YEAR(NOW())"
    Public Const MYSQL_HOY As String = "NOW()"
    Public Const STR_CERO_MONEDA As String = "0.00"
    Public Const STR_ASTERISCO As String = "*"
    Public Const FMT_BULTOS As String = "0"
    Public Const FMT_CANTIDAD As String = "0.00#"
    Public Const FMT_Factor As String = "0.00##"
    Public Const FMT_GASTOS As String = "0.00"
    Public Const FMT_PORCENTAJE As String = "0.00"
    Public Const FMT_TASA As String = "0.00###"
    Public Const FMT_TOTAL As String = "0.00"
    Public Const FMT_UNITARIO As String = "0.00#####"

    Public Const FMT_MSO_ENTERO As String = "#,##0"
    Public Const FMT_MSO_TOTAL As String = "#,##0.00"
    Public Const FMT_MSO_CANTIDAD As String = "#,##0.00#"
    Public Const FMT_MSO_UNITARIO As String = "#,##0.00#####"
    Public Const FORMATO_MONEDA As String = " #,##0.00"
    Public Const FORMATO_MYSQL As String = "yyyy-MM-dd"
    Public Const STR_LOC As String = "loc"
    Public Const STR_EXT As String = "ext"
    Public Const INT_LOC As Integer = 177
    Public Const INT_EXT As Integer = 178
    Public CON As MySqlConnection
    Public Const STR_RELLENO As String = "__________"
    Public ConexioString As String = STR_VACIO
    Public Const CLAVE_ENCRIPTAMIENTO As String = "1#2aBKDU78%%"
    Public Const ARROBA As String = "@"

#End Region
End Module
