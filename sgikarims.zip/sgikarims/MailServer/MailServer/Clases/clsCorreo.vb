﻿Public Class clsCorreo

#Region "Variables"
    Const REMITENTE As String = "sgi.notifications@sierratextiles.com "
    Const CONTRA As String = "t&mx}g84nv&;"
    Const DOMINIO As String = "sierratextiles-com.mail.protection.outlook.com"
    Const PUERTO As Integer = 25

    Dim strDestinatario As String
    Dim strAsunto As String
    Dim strContenido As String
#End Region

#Region "Propiedades"
    Public WriteOnly Property Destinatario As String
        Set(value As String)
            strDestinatario = value
        End Set
    End Property
    Public WriteOnly Property Asunto As String
        Set(value As String)
            strAsunto = value
        End Set
    End Property
    Public WriteOnly Property Contenido As String
        Set(value As String)
            strContenido = value
        End Set
    End Property
#End Region

    Public Function EnviarCorreo() As Boolean
        Dim _Message As New System.Net.Mail.MailMessage()
        Dim _SMTP As New System.Net.Mail.SmtpClient
        _SMTP.Credentials = New System.Net.NetworkCredential(REMITENTE, CONTRA)
        _SMTP.Host = DOMINIO
        _SMTP.Port = PUERTO
        _SMTP.EnableSsl = False

        ' CONFIGURACION_DEL_MENSAJE() 
        _Message.[To].Add(strDestinatario) 'Cuenta de Correo al que se le quiere enviar el e-mail 
        _Message.From = New System.Net.Mail.MailAddress(REMITENTE) 'Quien lo envía 
        _Message.Subject = strAsunto  'Sujeto del e-mail 
        _Message.SubjectEncoding = System.Text.Encoding.UTF8 'Codificacion 
        _Message.Body = strContenido  'contenido del mail 
        _Message.BodyEncoding = System.Text.Encoding.UTF8
        _Message.Priority = System.Net.Mail.MailPriority.Normal
        _Message.IsBodyHtml = True
        '_Message.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure
        '  _Message.CC.Add(CeldaCC.Text)

        'ENVIO() 
        Try

            '_SMTP.UseDefaultCredentials = True
            '_SMTP.EnableSsl = True

            _SMTP.Send(_Message)
            Return True
        Catch ex As System.Net.Mail.SmtpException
            ' MessageBox.Show(ex.ToString, "Fault!", MessageBoxButtons.OK)
            Return False
        End Try
        _Message = Nothing
        _SMTP = Nothing
    End Function
End Class
