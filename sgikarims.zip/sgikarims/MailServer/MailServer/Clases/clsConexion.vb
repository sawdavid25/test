﻿Imports System.Xml
Imports System.IO
Public Class ClsConexion
    Dim constr As String
    Public Property CONECTAR() As String
        Set(ByVal VALUE As String)
            constr = VALUE
            Try
                If IsNothing(CON) = True Then
                    CON = New MySqlConnection
                End If
                If CON.State = ConnectionState.Open Then
                    CON.Close()
                End If
                CON.ConnectionString = constr
                If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
                    CON.Open()
                End If
                'CON.Open()
            Catch MyEX As MySqlException
                MsgBox(MyEX.ToString)
            Catch EX As Exception
                MsgBox(EX.ToString)
            End Try
        End Set
        Get
            Return CONstr
        End Get
    End Property

#Region "Procedimientos"
    'XML
    Private Sub VerificarXml()
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim nodo As XmlNode
        Dim strpath As String = Application.StartupPath & "\Conexion.xml"
        Dim strTemp As String = STR_VACIO
        If cFunciones.ExisteArchivo(strpath) Then
            Try
                xml_Documento.Load(strpath)
                nodos_lista = xml_Documento.SelectNodes("/conexion/name")
                For Each nodo In nodos_lista
                    'If Left(nodo.Attributes.GetNamedItem("codigo").Value, INT_UNO) = ARROBA Then
                    '    nodo.Attributes.GetNamedItem("codigo").Value = cFunciones.Encriptar(nodo.Attributes.GetNamedItem("codigo").Value, CLAVE_ENCRIPTAMIENTO)
                    'End If
                    If Left(nodo.ChildNodes.Item(0).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(0).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(0).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(INT_UNO).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(1).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(INT_UNO).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(2).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(2).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(2).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(3).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(3).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(3).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                    If Left(nodo.ChildNodes.Item(4).InnerText, INT_UNO) = ARROBA Then
                        strTemp = STR_VACIO
                        strTemp = Replace(nodo.ChildNodes.Item(4).InnerText.ToString, "@", "")
                        nodo.ChildNodes.Item(4).InnerText = cFunciones.Encriptar(strTemp, CLAVE_ENCRIPTAMIENTO)
                    End If
                Next
                xml_Documento.Save(strpath)
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            MsgBox("No se encontró el archivo de conexión", MsgBoxStyle.ApplicationModal)
            End
        End If
    End Sub

    Public Sub ObtenerCredencialesXml()
        Try
            Dim xml_Documento As New XmlDocument
            Dim nodos_lista As XmlNodeList
            Dim nodo As XmlNode
            Dim strpath As String = Application.StartupPath & "\Conexion.xml"
            'Cargamos el archivo
            VerificarXml()
            If cFunciones.ExisteArchivo(strpath) Then
                xml_Documento.Load(strpath)
                'Obtenemos la lista de los nodos "name"
                nodos_lista = xml_Documento.SelectNodes("/conexion/name")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    'Obtenemos el atributo del codigo
                    Dim mCodigo = nodo.Attributes.GetNamedItem("codigo").Value
                    'Obtenemos Elementos
                    Dim nombre = nodo.ChildNodes.Item(0).InnerText
                    Dim server = cFunciones.Desencriptar(nodo.ChildNodes.Item(1).InnerText, CLAVE_ENCRIPTAMIENTO)
                    Dim user = cFunciones.Desencriptar(nodo.ChildNodes.Item(2).InnerText, CLAVE_ENCRIPTAMIENTO)
                    Dim pass = cFunciones.Desencriptar(nodo.ChildNodes.Item(3).InnerText, CLAVE_ENCRIPTAMIENTO)
                    Dim db = cFunciones.Desencriptar(nodo.ChildNodes.Item(4).InnerText, CLAVE_ENCRIPTAMIENTO)
                    Dim def = nodo.ChildNodes.Item(5).InnerText
                    Select Case mCodigo
                        Case "1"
                            Conexion.local.Servidor = server
                            Conexion.local.Usuario = user
                            Conexion.local.Clave = pass
                            Conexion.local.Base = db
                            Conexion.local.Modo = nombre
                            Conexion.local.Def = CInt(def)
                        Case "2"
                            Conexion.servidor.Servidor = server
                            Conexion.servidor.Usuario = user
                            Conexion.servidor.Clave = pass
                            Conexion.servidor.Base = db
                            Conexion.servidor.Modo = nombre
                            Conexion.servidor.Def = CInt(def)
                        Case "3"
                            Conexion.wan1.Servidor = server
                            Conexion.wan1.Usuario = user
                            Conexion.wan1.Clave = pass
                            Conexion.wan1.Base = db
                            Conexion.wan1.Modo = nombre
                            Conexion.wan1.Def = CInt(def)
                        Case "4"
                            Conexion.wan2.Servidor = server
                            Conexion.wan2.Usuario = user
                            Conexion.wan2.Clave = pass
                            Conexion.wan2.Base = db
                            Conexion.wan2.Modo = nombre
                            Conexion.wan2.Def = CInt(def)
                    End Select
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

#End Region

#Region "Funciones"


    Public Function StringConexion(ByVal srtLocal As String) As String
        Dim strConexion As String = "server={server};uid={user};password={pass};database={db} ;Allow User Variables=True"
        If srtLocal = "1" Then
            strConexion = Replace(strConexion, "{server}", Conexion.local.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.local.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.local.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.local.Base)
        ElseIf srtLocal = "2" Then
            strConexion = Replace(strConexion, "{server}", Conexion.servidor.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.servidor.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.servidor.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.servidor.Base)
        ElseIf srtLocal = "3" Then
            strConexion = Replace(strConexion, "{server}", Conexion.wan1.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.wan1.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.wan1.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.wan1.Base)
        ElseIf srtLocal = "4" Then
            strConexion = Replace(strConexion, "{server}", Conexion.wan2.Servidor)
            strConexion = Replace(strConexion, "{user}", Conexion.wan2.Usuario)
            strConexion = Replace(strConexion, "{pass}", Conexion.wan2.Clave)
            strConexion = Replace(strConexion, "{db}", Conexion.wan2.Base)
        End If
        Return strConexion
    End Function

    Public Function ProbarConexiones() As Boolean
        Dim logResultado As Boolean = False
        Dim mensaje As String

        If IsNothing(CON) = True Then
            CON = New MySqlConnection
        End If
        If CON.State = ConnectionState.Open Then
            CON.Close()
        End If
        CON.ConnectionString = strConexion
        If CON.State = ConnectionState.Closed Or CON.State = ConnectionState.Broken Then
            If CON.ConnectionString.Length <> 0 Then
                Try
                    CON.Open()
                    logResultado = True
                Catch MYEX As MySqlException
                    mensaje = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION Error#=" & MYEX.Number & " " & MYEX.ToString
                    Return logResultado
                    Exit Function
                Catch EX As Exception
                    mensaje = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION Error=" & EX.ToString
                    Return logResultado
                    Exit Function
                End Try
            Else
                mensaje = "BiblioTABLAS - TTDCMTOS_DTL - PSELECT_CONDICION String de Conexión no definido"
                Return logResultado
                Exit Function
            End If
        Else
            logResultado = True
        End If
        Return logResultado
    End Function

    Public Function MyOpen() As MySqlConnection
        Dim logPing As Boolean = False
        Dim CON As New MySqlConnection
        Try
            CON.ConnectionString = CONECTAR
            CON.Open()
            logPing = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return CON
    End Function

    Public Function GetReader(ByVal strQuery As String) As MySqlDataReader
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Try
            CONECTAR = strConexion
            If ProbarConexiones() = True Then
                COM = New MySqlCommand(strQuery, CON)
                COM.CommandType = CommandType.Text
                REA = COM.ExecuteReader()
                REA.Read()
                Return REA
                Exit Function
            Else
                Return Nothing
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            REA = Nothing
        End Try
        Return Nothing
    End Function

    Public Function BorrarRegistro(ByVal strTabla As String, Optional ByVal strCondicion As String = "", Optional intLimite As Integer = 0) As Boolean
        BorrarRegistro = False
        Dim COM As MySqlCommand
        Dim strSQL As String = ""
        strSQL = "DELETE FROM " & strTabla
        If strCondicion.Length > 0 Then
            strSQL &= " WHERE " & strCondicion
            If intLimite > 0 Then
                strSQL &= " LIMIT " & intLimite
            End If
        End If
        Try
            If MsgBox("¿Está seguro que desea borrar este registro?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                CONECTAR = strConexion
                If ProbarConexiones() = True Then
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    BorrarRegistro = True
                    cFunciones.EscribirRegistro(strTabla, clsFunciones.AccEnum.acDelete)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function GetEscalar(ByVal strSQL As String) As String
        Return STR_VACIO
    End Function

#End Region

End Class