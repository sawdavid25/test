﻿
Imports System.Text
Imports System.IO
Imports System.Security.Cryptography

Public Class clsFunciones

#Region "Miembros"

    Public Enum AccEnum

        acAdd = 0
        acDelete = 1
        acUpdate = 2
        acPrint = 3
        acCorrect = 4
        acConfirm = 5
        acUnlock = 6
        acCargar = 7
        acSalida = 8
        acPoliza = 9
        acLiberar = 10


    End Enum

    Public Enum Monedas

        Mlocal = 0
        Mextrangero = 0

    End Enum

    Public Enum IpEquipo

        ip = 0
        equipo = 1

    End Enum

    Dim strMatrix As String

#End Region
    
#Region "Encriptar"

    Private Function Algoritmo(ByVal strClave As String) As RijndaelManaged
        Const salt As String = "pkdkdkdkd"
        Const tamaño As Integer = 256

        Dim keyBuilder As Rfc2898DeriveBytes = New Rfc2898DeriveBytes(strClave, Encoding.Unicode.GetBytes(salt))
        Dim algorithm As RijndaelManaged = New RijndaelManaged()
        algorithm.KeySize = tamaño
        algorithm.IV = keyBuilder.GetBytes(CType(algorithm.BlockSize / 8, Integer))
        algorithm.Key = keyBuilder.GetBytes(CType(algorithm.KeySize / 8, Integer))
        algorithm.Padding = PaddingMode.PKCS7
        Return algorithm
    End Function

    Public Function Encriptar(ByVal strTextoPlano As String, ByVal strClave As String) As String
        Dim encryptedPassword As String = Nothing
        Using outputStream As MemoryStream = New MemoryStream()
            Dim algorithm As RijndaelManaged = Algoritmo(strClave)
            Using cryptoStream As CryptoStream = New CryptoStream(outputStream, algorithm.CreateEncryptor(), CryptoStreamMode.Write)
                Dim inputBuffer() As Byte = Encoding.Unicode.GetBytes(strTextoPlano)
                cryptoStream.Write(inputBuffer, 0, inputBuffer.Length)
                cryptoStream.FlushFinalBlock()
                encryptedPassword = Convert.ToBase64String(outputStream.ToArray())
            End Using
        End Using
        Return encryptedPassword
    End Function

    Public Function Desencriptar(ByVal BytesEncriptados As String, ByVal strClave As String) As String
        Dim plainText As String = Nothing
        Try
            Using inputStream As MemoryStream = New MemoryStream(Convert.FromBase64String(BytesEncriptados))
                Dim algorithm As RijndaelManaged = Algoritmo(strClave)
                Using cryptoStream As CryptoStream = New CryptoStream(inputStream, algorithm.CreateDecryptor(), CryptoStreamMode.Read)
                    Dim outputBuffer(0 To CType(inputStream.Length - 1, Integer)) As Byte
                    Dim readBytes As Integer = cryptoStream.Read(outputBuffer, 0, CType(inputStream.Length, Integer))
                    plainText = Encoding.Unicode.GetString(outputBuffer, 0, readBytes)
                End Using
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return plainText
    End Function

#End Region

    Public Sub New()
        strMatrix = STR_VACIO
    End Sub


#Region "Conversiones"

    Public Function ExterioLocal(ByVal Cantidad As Double) As Double
        ExterioLocal = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim dblTCambio As Double = INT_CERO
        strSQL = "select Tasa From TCambio where Fecha= now()"
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dblTCambio = CDbl(COM.ExecuteScalar)
            ExterioLocal = Cantidad * dblTCambio
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

#End Region

#Region "Controles"

    'Private Const blanco As Color = Color.White
    Public Sub ValidarFilaGrid(ByRef ListaGrid As DataGridView, ByVal strColumna As String)
        Try
            For i As Integer = 0 To ListaGrid.Rows.Count - 1
                If CStr(ListaGrid.Rows(i).Cells(strColumna).Value) = STR_VACIO Then
                    ListaGrid.Rows(i).Cells(strColumna).Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaGrid.Rows(i).Cells(strColumna).Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaGrid.Rows(i).Cells(strColumna).Value = Format(INT_CERO, FORMATO_MONEDA)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function ValidarFecha(ByVal strFecha As String) As Boolean
        Dim logResultado As Boolean = False
        If IsDate(strFecha) Then
            logResultado = True
        End If

        Return logResultado

    End Function

    Public Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, Optional ByVal color As System.Drawing.Color = Nothing)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim arrayFila() As String
        Try
            If color = Nothing Then
                color = Drawing.Color.White
            End If
            arrayFila = strFila.Split("|".ToCharArray)


            For i = 0 To arrayFila.Length - 1



                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                Celda.Style.BackColor = color

                Fila.Cells.Add(Celda)
            Next
            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub ValidadarLongitudTextBox(ByRef txt As TextBox, ByVal intLongitud As Integer)

        txt.MaxLength = intLongitud
        If txt.Text.Length >= intLongitud Then
            MsgBox("Solo puede ingresar un máximo de " & intLongitud & " caracteres.")
        End If

    End Sub

    Public Function ValidarCampoNumerico(ByRef TxTCampo As TextBox) As Boolean

        If Not IsNumeric(TxTCampo.Text) Then
            TxTCampo.BackColor = Color.Coral
            MsgBox("Ingrese un valor numérico")
            TxTCampo.Text = "0.00"
            TxTCampo.Focus()
            ValidarCampoNumerico = False
        Else
            TxTCampo.BackColor = Color.White
            ValidarCampoNumerico = True
        End If

    End Function

    Public Function ValidarCampoTexto(ByRef TxtCampo As TextBox, Optional ByVal intLongitud As Integer = 32000) As Boolean

        TxtCampo.MaxLength = intLongitud
        If TxtCampo.Text.Length <= 0 Or TxtCampo.Text.Length >= intLongitud Then
            If TxtCampo.Text.Length >= intLongitud Then
                MsgBox("Solo puede ingresar un máximo de " & intLongitud & " caracteres.")
            End If
            TxtCampo.BackColor = Color.Coral
            ValidarCampoTexto = False
        Else
            TxtCampo.BackColor = Color.White
            ValidarCampoTexto = True
        End If

    End Function

    Public Function ValidarCombo(ByRef Combo As ComboBox) As Boolean

        If Combo.SelectedIndex = NO_FILA Then
            Combo.BackColor = Color.Coral
            Return False
        Else
            Combo.BackColor = Color.White
            Return True
        End If

    End Function

    Public Sub CargarLista(ByRef lista As DataGridView, ByVal strSQL As String, Optional ByVal ADD As Boolean = False)

        Dim COM As New MySqlCommand
        Dim DAR As MySqlDataAdapter
        Dim dataTable As New DataTable

        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then

                COM = New MySqlCommand(strSQL, CON)
                COM.CommandType = CommandType.Text
                DAR = New MySqlDataAdapter(COM)
                DAR.Fill(dataTable)

                'If ADD = False Then
                '    lista.DataSource = Nothing
                '    lista.Refresh()
                'End If

                lista.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
                lista.DataSource = dataTable
                lista.RowsDefaultCellStyle.BackColor = Color.White
                lista.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub



    Public Sub BuscarenLista(ByRef lista As DataGridView)

        Dim contador As Integer = INT_CERO
        Dim intInicio As Integer = 0

        strBusquedaLista = InputBox("ingresa algo para buscar", "buscador", strBusquedaLista)


        For i As Integer = CInt(lista.CurrentRow.Index + 1) To lista.Rows.Count - 1
            contador = contador + 1
            For j As Integer = 0 To CInt(lista.Columns.Count - 1)

                ' If (strBusqueda Like "?[" & DataGridView1.Rows(i).Cells(j).Value.ToString & "]") = True Then
                If InStr(lista.Rows(i).Cells(j).Value.ToString, strBusquedaLista, CompareMethod.Text) > 0 Then
                    lista.CurrentCell = lista(j, i)
                    Exit Sub

                End If
            Next

        Next


        For i As Integer = CInt(0) To lista.Rows.Count - 1
            contador = contador + 1
            For j As Integer = 0 To CInt(lista.Columns.Count - 1)

                ' If (strBusqueda Like "?[" & DataGridView1.Rows(i).Cells(j).Value.ToString & "]") = True Then
                If InStr(lista.Rows(i).Cells(j).Value.ToString, strBusquedaLista, CompareMethod.Text) > 0 Then
                    lista.CurrentCell = lista(j, i)
                    Exit Sub

                End If
            Next

        Next
        MsgBox("Not Found")
    End Sub

#End Region

#Region "Archivos"

    Public Function ArchivoTemporal() As String
        Dim strTemp As String
        Dim strDir As String
        strDir = System.IO.Path.GetTempPath
        strTemp = System.IO.Path.GetTempFileName
        'MsgBox(strDir & vbNewLine & strTemp)
        Return strTemp
    End Function

    Public Function AbrirArchivo(strPath) As Boolean
        AbrirArchivo = False
        If cFunciones.ExisteArchivo(strPath) = True Then
            Try
                Process.Start(strPath)
                AbrirArchivo = True
            Catch ex As Exception
                MsgBox(ex.Message, , "Error al Abrir")
            End Try
        End If
    End Function



    Public Function ExisteArchivo(ByVal strPath As String) As Boolean
        ExisteArchivo = False
        Try
            If System.IO.File.Exists(strPath) = True Then
                ExisteArchivo = True
            Else
                MsgBox("El archivo no existe")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Public Function CopiarArchivo(ByVal strArchivoOrigen As String, Optional ByVal strArchivoDefault As String = "NuevoArchivo", Optional ByVal strExtDefaul As String = ".docx", Optional ByVal strFiltro As String = "Word documents (.docx)|*.docx")
        CopiarArchivo = STR_VACIO
        Dim DialogoGuardar As New SaveFileDialog
        DialogoGuardar.FileName = strArchivoDefault
        DialogoGuardar.DefaultExt = strExtDefaul
        DialogoGuardar.Filter = strFiltro
        Dim strOrigen As String = Application.StartupPath & "\" & strArchivoOrigen
        Dim logResultado As Boolean = DialogoGuardar.ShowDialog()
        If logResultado = True Then
            If cFunciones.ExisteArchivo(strOrigen) = True Then
                Dim strDestino As String = DialogoGuardar.FileName
                Try
                    System.IO.File.Copy(strOrigen, strDestino, True)
                    CopiarArchivo = strDestino
                Catch ex As Exception
                    MsgBox(ex.Message, , "Error al copiar")
                End Try
            End If
        End If
    End Function

#End Region

#Region "Funciones"




    Public Function Mysqldatenet(ByVal fecha As MySqlDateTime) As Date
        Dim fechanet As Date

        Return fechanet
    End Function


    Public Function DivisaLocal() As Integer
        Dim Local As String = STR_VACIO
        Dim COML As MySqlCommand
        Dim CON1 As MySqlConnection
        Dim valorLocal As String = STR_VACIO

        CON1 = New MySqlConnection(strConexion)
        CON1.Open()

        Local = "SELECT Cat_Clave " & _
                "FROM Catalogos " & _
                "WHERE cat_num in (434)"

        Try
            COML = New MySqlCommand(Local, CON1)
            valorLocal = COML.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON1.Close()

        Return valorLocal

    End Function

    Public Function DivisaExtranjera() As Integer
        Dim Extrangera As String = STR_VACIO
        Dim COME As MySqlCommand
        Dim CON1 As MySqlConnection
        Dim valorExtranjero As String = STR_VACIO

        CON1 = New MySqlConnection(strConexion)
        CON1.Open()

        Extrangera = " SELECT Cat_Clave " & _
                "FROM Catalogos " & _
                "WHERE cat_num in (433)"
        Try
            COME = New MySqlCommand(Extrangera, CON1)
            valorExtranjero = COME.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON1.Close()

        Return valorExtranjero

    End Function

    Public Function QueryTasa(Optional ByVal fecha As String = STR_VACIO) As Double
        Dim strSQL As String = STR_VACIO
        Dim con1 As MySqlConnection
        Dim COMQT As MySqlCommand
        Dim Tasa As Double = 0.0

        con1 = New MySqlConnection(strConexion)
        con1.Open()

        Try
            strSQL = "SELECT IFNULL(ROUND(AVG(Tasa),5),1) Tasa FROM TCambio WHERE Fecha LIKE '{fecha}%' AND Local= '{local}' AND Exterior='{extranjero}'"
            strSQL = Replace(strSQL, "{fecha}", fecha)
            strSQL = Replace(strSQL, "{local}", DivisaLocal)
            strSQL = Replace(strSQL, "{extranjero}", DivisaExtranjera)

            COMQT = New MySqlCommand(strSQL, con1)
            Tasa = COMQT.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        con1.Close()

        Return Tasa
    End Function

    Public Function MesALetras(ByVal intMes As Integer) As String
        Select Case intMes
            Case 1 : MesALetras = "Enero"
            Case 2 : MesALetras = "Febrero"
            Case 3 : MesALetras = "Marzo"
            Case 4 : MesALetras = "Abril"
            Case 5 : MesALetras = "Mayo"
            Case 6 : MesALetras = "Junio"
            Case 7 : MesALetras = "Julio"
            Case 8 : MesALetras = "Agosto"
            Case 9 : MesALetras = "Septiembre"
            Case 10 : MesALetras = "Octubre"
            Case 11 : MesALetras = "Noviembre"
            Case 12 : MesALetras = "Diciembre"
            Case Else : MesALetras = "Mes no válido"
        End Select
    End Function

    Public Sub LimpiarParametros()
        strMatrix = STR_VACIO
    End Sub

    Public Sub AgregarParametro(ByVal strBusqueda As String, ByVal strReemplazo As String)
        strBusqueda = Replace(strBusqueda, "|", ".")
        strBusqueda = Replace(strBusqueda, ">", ".")
        strReemplazo = Replace(strReemplazo, "|", ".")
        strReemplazo = Replace(strReemplazo, ">", ".")
        strMatrix &= strBusqueda & ">" & strReemplazo & "|"
    End Sub

    Public Function MyStr(ByVal data As String) As String
        data = Replace(data, "\", "\\")
        data = Replace(data, vbNullChar, "\0")
        data = Replace(data, "'", "\'")
        data = Replace(data, """", "\""")
        data = Replace(data, vbBack, "\b")
        data = Replace(data, vbLf, "\n")
        data = Replace(data, vbCr, "\r")
        data = Replace(data, vbTab, "\t")
        data = Replace(data, Space(2), Space(1))
        Return Trim(data)
    End Function

    Public Function ObtenerIPoEquipo(ByVal IoE As IpEquipo) As String
        Dim nombrePC As String
        Dim entradasIP As Net.IPHostEntry
        nombrePC = Net.Dns.GetHostName
        entradasIP = Net.Dns.GetHostByName(nombrePC)
        Dim direccion_Ip As String = entradasIP.AddressList(0).ToString
        If IoE = IpEquipo.ip Then
            Return direccion_Ip
        ElseIf IoE = IpEquipo.equipo Then
            Return nombrePC
        Else
            MsgBox("Parametro inválido")
            Return vbNull
        End If


    End Function

    Public Function SrtingToDouble(ByVal numero As String) As Double
        Dim doble As Double = vbNull
        Return doble
    End Function

    Public Sub EscribirRegistro(ByVal Tabla As String, ByVal Accion As AccEnum, Optional Codigo As Long = vbEmpty, Optional Catalogo As Integer = vbEmpty, Optional Año As String = STR_VACIO, Optional Numero As Long = vbEmpty, Optional Notas As String = vbNullString)
        Dim COM As MySqlCommand
        Dim strAccion As String = ""
        Dim strSql As String = ""
        Select Case Accion
            Case AccEnum.acAdd
                strAccion = "AGREGAR"
            Case AccEnum.acDelete
                strAccion = "BORRAR"
            Case AccEnum.acUpdate
                strAccion = "MODIFICAR"
            Case AccEnum.acPrint
                strAccion = "IMPRIMIR"
            Case AccEnum.acCorrect
                strAccion = "CORREGIR"
            Case AccEnum.acConfirm
                strAccion = "CONFIRMAR"
            Case AccEnum.acUnlock
                strAccion = "LIBERAR"
            Case Else
                strAccion = "N/A"
        End Select
        If Año = STR_VACIO Then
            Año = INT_CERO
        End If
        strSql = "INSERT INTO Registro Values ({idregistro},{idempresa},{idusuario},'{usuario}',{fecha},'{tabla}', {codigo},{catalogo},{ano},{numero},'{accion}','{notas}')"
        strSql = Replace(strSql, "{idregistro}", 0)
        strSql = Replace(strSql, "{idempresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{idusuario}", Sesion.idUsuario)
        strSql = Replace(strSql, "{usuario}", Sesion.Usuario)
        strSql = Replace(strSql, "{fecha}", "now()")
        strSql = Replace(strSql, "{tabla}", Tabla)
        strSql = Replace(strSql, "{codigo}", Codigo)
        strSql = Replace(strSql, "{catalogo}", Catalogo)
        strSql = Replace(strSql, "{ano}", Año)
        strSql = Replace(strSql, "{numero}", Numero)
        strSql = Replace(strSql, "{accion}", strAccion)
        strSql = Replace(strSql, "{notas}", Notas)
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSql, CON)
                COM.ExecuteNonQuery()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub





    'Muestra los documentos que han descargado de este
    Public Sub MostrarDependencias(ByVal Tipo As Integer, ByVal Año As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim i As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strDato As String = STR_VACIO

        ' Origen 

        'Instrucción de selección
        strSQL = vbNullString
        strSQL &= " SELECT DISTINCT COALESCE(c.cat_desc,'') Documento, r.PDoc_Par_Ano Ano, r.PDoc_Par_Num Numero"
        strSQL &= "     FROM Dcmtos_DTL_Pro r"
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_clase = 'Documentos' AND c.cat_num = r.PDoc_Par_Cat"
        strSQL &= "     WHERE r.PDoc_Sis_Emp = {empresa} AND r.PDoc_Chi_Cat = {Tipo} AND r.PDoc_Chi_Ano = {Año} AND r.PDoc_Chi_Num = {Numero}"
        strSQL &= "  ORDER BY r.PDoc_Par_Ano, r.PDoc_Par_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Tipo}", Tipo)
        strSQL = Replace(strSQL, "{Año}", Año)
        strSQL = Replace(strSQL, "{Numero}", Numero)

        i = vbEmpty
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = i + 1 & ") "
                    strFila &= REA.GetString("Documento") & ": "
                    strFila &= REA.GetInt32("Ano") & Space(4)
                    strFila &= REA.GetInt32("Numero").ToString(FORMATO_MONEDA) & vbCrLf

                    If Not (strFila = vbNullString) Then

                        strDato = "Dato" & vbCr
                        strDato &= "======" & vbCr & vbCr & strFila
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        ' Dependientes 

        'Instrucción de selección
        strSQL = vbNullString
        strSQL &= " SELECT DISTINCT COALESCE(c.cat_desc,'') Documento, r.PDoc_Chi_Ano Ano, r.PDoc_Chi_Num Numero"
        strSQL &= "     FROM Dcmtos_DTL_Pro r"
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_clase = 'Documentos' AND c.cat_num = r.PDoc_Par_Cat"
        strSQL &= "     WHERE r.PDoc_Sis_Emp = {empresa} AND r.PDoc_Chi_Cat = {Tipo} AND r.PDoc_Chi_Ano = {Año} AND r.PDoc_Chi_Num = {Numero}"
        strSQL &= "  UNION"
        strSQL &= " Select DISTINCT COALESCE(cc.cat_desc,'') Documento, hh.HDoc_Doc_Ano  Año, hh.HDoc_Doc_Num  Numero"
        strSQL &= "     from ECtaCte ce"
        strSQL &= "         left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp = ce.ECta_Sis_Emp and hh.HDoc_Doc_Cat =ce.ECta_Doc_Cat and hh.HDoc_Doc_Ano = ce.ECta_Doc_Ano and hh.HDoc_Doc_Num =ce.ECta_Doc_Num"
        strSQL &= "    left join Catalogos cc on cc.cat_num = hh.HDoc_Doc_Cat"
        strSQL &= "  where ce.ECta_Sis_Emp = {empresa} and ce.ECta_Ref_Cat = {Tipo} and ce.ECta_Ref_Ano = {Año} and ce.ECta_Ref_Num = {Numero} and ce.ECta_Ref_Cat != ce.ECta_Doc_Cat  and hh.HDoc_Doc_Status = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Tipo}", Tipo)
        strSQL = Replace(strSQL, "{Año}", Año)
        strSQL = Replace(strSQL, "{Numero}", Numero)

        i = vbEmpty
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = i + 1 & ") "
                    strFila &= REA.GetString("Documento") & ": "
                    strFila &= REA.GetInt32("Ano") & Space(4)
                    strFila &= REA.GetInt32("Numero").ToString(FORMATO_MONEDA) & vbCrLf

                    If Not (strFila = vbNullString) Then
                        strDato = strDato & IIf(strDato = vbNullString, vbNullString, vbCr & vbCr)
                        strDato &= "Dependencias" & vbCr
                        strDato &= "============" & vbCr & vbCr & strFila

                    End If
                    If Not (strDato = vbNullString) Then
                        MsgBox(strDato, vbInformation, "Relaciones")
                    Else
                        MsgBox("No se encontro informacion de los documentos relacionados", vbInformation, "Relaciones")
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

End Class
