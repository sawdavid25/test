﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.botonProbar = New System.Windows.Forms.Button()
        Me.DirectorySearcher1 = New System.DirectoryServices.DirectorySearcher()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CeldaNumero = New System.Windows.Forms.Label()
        Me.celdaConteo = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'botonProbar
        '
        Me.botonProbar.Location = New System.Drawing.Point(15, 44)
        Me.botonProbar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonProbar.Name = "botonProbar"
        Me.botonProbar.Size = New System.Drawing.Size(473, 53)
        Me.botonProbar.TabIndex = 0
        Me.botonProbar.Text = "Enviar Correos Manualmente"
        Me.botonProbar.UseVisualStyleBackColor = True
        '
        'DirectorySearcher1
        '
        Me.DirectorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01")
        Me.DirectorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01")
        Me.DirectorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01")
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(16, 142)
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(473, 28)
        Me.ProgressBar1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 100)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Correos Restantes"
        '
        'CeldaNumero
        '
        Me.CeldaNumero.AutoSize = True
        Me.CeldaNumero.Location = New System.Drawing.Point(193, 100)
        Me.CeldaNumero.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.CeldaNumero.Name = "CeldaNumero"
        Me.CeldaNumero.Size = New System.Drawing.Size(16, 17)
        Me.CeldaNumero.TabIndex = 3
        Me.CeldaNumero.Text = "0"
        '
        'celdaConteo
        '
        Me.celdaConteo.AutoSize = True
        Me.celdaConteo.Location = New System.Drawing.Point(377, 11)
        Me.celdaConteo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaConteo.Name = "celdaConteo"
        Me.celdaConteo.Size = New System.Drawing.Size(16, 17)
        Me.celdaConteo.TabIndex = 4
        Me.celdaConteo.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(85, 11)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(225, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Tiempo restante para nuevo envio"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(535, 206)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.celdaConteo)
        Me.Controls.Add(Me.CeldaNumero)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.botonProbar)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Timer1 As Timer
    Friend WithEvents botonProbar As Button
    Friend WithEvents DirectorySearcher1 As System.DirectoryServices.DirectorySearcher
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CeldaNumero As System.Windows.Forms.Label
    Friend WithEvents celdaConteo As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
