﻿Public Class Form1
#Region "Variables"
    Dim Counter As Integer

#End Region

    Private Sub InicializaTimer()

        Counter = 0
        Timer1.Interval = 3000
        Timer1.Enabled = True

    End Sub

    Private Function SqlCorreos() As String
        Dim strsql As String = STR_VACIO
        strsql = " select * from correocmc "
        strsql &= " where Estado =0 "
        Return strsql
    End Function

    Private Function contarCOrreos() As Integer

        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Try

       
        strConexion = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
        strConexion = Replace(strConexion, "{server}", MAIL_HOST)
        strConexion = Replace(strConexion, "{user}", MAIL_USER)
        strConexion = Replace(strConexion, "{password}", MAIL_PASS)
        strConexion = Replace(strConexion, "{database}", MAIL_BASE)
        MyCnn.CONECTAR = strConexion


            strsql = " select count(*) from correocmc "
            strsql &= " where Estado =0 "

        COM = New MySqlCommand(strsql, CON)

            Return COM.ExecuteScalar()
        Catch ex As Exception
            Return 0
        End Try
    End Function

    Private Sub ActualizarEstado(ByVal idcoreeo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim CONE As MySqlConnection
        Dim COM As MySqlCommand
        Try
            CONE = New MySqlConnection
            CONE.ConnectionString = strConexion
            CONE.Open()

            strSQL = " Update correocmc set Estado = 1, fecha_envio = NOW() where idCorreo = {correo} "
            strSQL = Replace(strSQL, "{correo}", idcoreeo)

            COM = New MySqlCommand(strSQL, CONE)
            COM.ExecuteScalar()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub EnviarTodosCorreos()
        Dim strsql As String = SqlCorreos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim MAIL As New clsCorreo
        Try

            CeldaNumero.Text = contarCOrreos()
            ProgressBar1.Value = 0
            ProgressBar1.Maximum = CInt(CeldaNumero.Text)

            strConexion = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
            strConexion = Replace(strConexion, "{server}", MAIL_HOST)
            strConexion = Replace(strConexion, "{user}", MAIL_USER)
            strConexion = Replace(strConexion, "{password}", MAIL_PASS)
            strConexion = Replace(strConexion, "{database}", MAIL_BASE)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    MAIL.Asunto = REA.GetString("Asunto")
                    MAIL.Destinatario = REA.GetString("Destinatario")
                    MAIL.Contenido = REA.GetString("Contenido")
                    If MAIL.EnviarCorreo() Then
                        ActualizarEstado(REA.GetInt32("idCorreo"))

                    End If

                    Application.DoEvents()
                    CeldaNumero.Text = CInt(CeldaNumero.Text) - 1
                    ProgressBar1.Value += 1

                Loop

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim Tiempo As Integer
        Try
            Tiempo = 1500
            If Counter = Tiempo Then
                Timer1.Enabled = False
                EnviarTodosCorreos()
                Counter = 0
                Timer1.Enabled = True

            Else
                Counter = Counter + 1
            End If
            celdaConteo.Text = Tiempo - Counter
        Catch ex As Exception

        End Try


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Timer1.Enabled = True

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        Timer1.Enabled = False
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            Timer1.Enabled = True

        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonProbar_Click(sender As Object, e As EventArgs) Handles botonProbar.Click
        Try
            Timer1.Enabled = False
            EnviarTodosCorreos()
            Counter = 0
            Timer1.Enabled = True
        Catch ex As Exception
            '   MsgBox(ex.ToString)
        End Try
    End Sub


End Class
