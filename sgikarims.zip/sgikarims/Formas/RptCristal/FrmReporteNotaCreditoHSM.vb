﻿Public Class FrmReporteNotaCreditoHSM
    Private ReporteNCHSM As Object
    Public Property Reporte_A_Ver_NCHSM() As Object

        Get
            Return ReporteNCHSM
        End Get
        Set(ByVal value As Object)
            ReporteNCHSM = value
        End Set
    End Property

    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load
        Try
            If IsNothing(ReporteNCHSM) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteNCHSM
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class