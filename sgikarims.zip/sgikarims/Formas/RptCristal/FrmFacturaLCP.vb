﻿Public Class FrmFacturaLCP
    Private ReporteFacturacionLCP As Object
    Public Property Reporte_A_VerLCP() As Object
        Get
            Return ReporteFacturacionLCP
        End Get
        Set(ByVal value As Object)
            ReporteFacturacionLCP = value
        End Set
    End Property
    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs)
        Try
            If IsNothing(ReporteFacturacionLCP) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteFacturacionLCP
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class