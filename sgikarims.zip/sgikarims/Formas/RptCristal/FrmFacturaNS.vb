﻿Public Class FrmFacturaNS
    Private ReporteFacturacionNS As Object
    Public Property Reporte_A_VerNS() As Object

        Get
            Return ReporteFacturacionNS
        End Get
        Set(ByVal value As Object)
            ReporteFacturacionNS = value
        End Set
    End Property
    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs)
        Try
            If IsNothing(ReporteFacturacionNS) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteFacturacionNS
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class