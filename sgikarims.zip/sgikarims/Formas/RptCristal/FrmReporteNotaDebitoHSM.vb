﻿Public Class FrmReporteNotaDebitoHSM
    Private ReporteNDHSM As Object
    Public Property Reporte_A_Ver_NDHSM() As Object

        Get
            Return ReporteNDHSM
        End Get
        Set(ByVal value As Object)
            ReporteNDHSM = value
        End Set
    End Property

    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load
        Try
            If IsNothing(ReporteNDHSM) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteNDHSM
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class