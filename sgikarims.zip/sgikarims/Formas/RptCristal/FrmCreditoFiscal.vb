﻿Public Class FrmCreditoFiscal
    Private ReporteCreditoFiscal As Object
    Public Property Reporte_A_VerCF() As Object

        Get
            Return ReporteCreditoFiscal
        End Get
        Set(ByVal value As Object)
            ReporteCreditoFiscal = value
        End Set
    End Property
    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs)
        Try
            If IsNothing(ReporteCreditoFiscal) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteCreditoFiscal
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class