﻿Public Class frmReporteFactSV
    Private ReporteSV As Object
    Public Property Reporte_A_VerSV() As Object

        Get
            Return ReporteSV
        End Get
        Set(ByVal value As Object)
            ReporteSV = value
        End Set
    End Property

    Private Sub CrystalReportViewer2_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer2.Load

        Try
            If IsNothing(ReporteSV) = True Then Exit Sub
            CrystalReportViewer2.ReportSource = ReporteSV
            Me.CrystalReportViewer2.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub
End Class