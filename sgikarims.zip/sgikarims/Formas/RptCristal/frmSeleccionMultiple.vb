﻿Public Class frmSeleccionMultiple
    'Devuelve la cantidad de filas seleccionadas
    Public ReadOnly Property CantidadSeleccion() As Integer
    Public ReadOnly Property ColumnaSeleccion() As Integer
    Public Property Multiple As Boolean = False

    Private strBuscar As String = String.Empty

    'Crea la columna para seleccion
    Public Sub AgregarColumnaSeleccion()
        Dim sel As New DataGridViewCheckBoxColumn
        sel.Name = "lista_seleccion"
        sel.HeaderText = "Selected"
        sel.Width = 60
        sel.DefaultCellStyle.BackColor = Color.LightBlue
        sel.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        sel.DefaultCellStyle.NullValue = False
        Lista.Columns.Add(sel)

        _ColumnaSeleccion = sel.Index
    End Sub

    'Devuelve si existe una columna para seleccion multiple
    Private Sub VerificarColumnaSeleccion()
        Dim i As Integer = NO_FILA
        Try
            i = Lista.Columns.Item("lista_seleccion").Index
        Catch ex As Exception
        End Try
        If i.Equals(NO_FILA) And Multiple Then
            AgregarColumnaSeleccion()
        End If
    End Sub

    'Devuelve si hay filas seleccionadas
    Public Function HaySeleccion() As Boolean
        Dim intCol As Integer = INT_CERO
        Dim intSel As Integer = INT_CERO
        Dim logOk As Boolean = False
        Dim row As DataGridViewRow

        If Multiple Then
            intCol = Lista.Columns.Item("lista_seleccion").Index
            For Each row In Lista.Rows
                If Convert.ToBoolean(row.Cells(intCol).Value) Then
                    intSel += 1
                End If
            Next
            _CantidadSeleccion = intSel
            logOk = Not (intSel.Equals(INT_CERO))
        Else
            logOk = Lista.CurrentRow IsNot Nothing
        End If
        Return logOk
    End Function

    'Boton cancelar
    Private Sub BotonCancelar_Click(sender As Object, e As EventArgs) Handles BotonCancelar.Click
        DialogResult = DialogResult.Cancel
    End Sub

    'Boton aceptar
    Private Sub BotonAceptar_Click(sender As Object, e As EventArgs) Handles BotonAceptar.Click
        VerificarColumnaSeleccion()
        If HaySeleccion() Then
            DialogResult = DialogResult.OK
        Else
            MessageBox.Show("No items selected", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Lista.Focus()
        End If
    End Sub

    'Doble clic
    Private Sub Lista_DoubleClick(sender As Object, e As EventArgs) Handles Lista.DoubleClick
        Dim intCol As Integer = INT_CERO
        VerificarColumnaSeleccion()
        If Lista.CurrentRow IsNot Nothing Then
            If Multiple Then
                'Seleccion multiple
                intCol = Lista.Columns.Item("lista_seleccion").Index
                Lista.CurrentRow.Cells(intCol).Value = Not CBool(Lista.CurrentRow.Cells(intCol).Value)
            Else
                BotonAceptar.PerformClick()
            End If
        End If
    End Sub

    Private Sub Lista_KeyDown(sender As Object, e As KeyEventArgs) Handles Lista.KeyDown
        If e.KeyCode = Keys.F3 Then
            e.SuppressKeyPress = True
            If Lista.Rows.Count > INT_CERO Then
                'Mostrar ventana de busqueda
                BuscarTexto()
            End If
        End If
    End Sub

    Private Sub BuscarTexto()
        Dim strTemp As String = String.Empty
        Dim strDato As String = String.Empty

        Dim intDesde As Integer = INT_CERO
        Dim intFilas As Integer = (Lista.Rows.Count - 1)
        Dim intCols As Integer = (Lista.Columns.Count - 1)

        Dim logEx As Boolean = False

        strTemp = InputBox(String.Empty, "Search", strBuscar).Trim.ToUpper
        If strTemp.Equals(String.Empty) Then
            strBuscar = String.Empty
        Else
            'Si el texto es diferente buscar desde el inicio
            If strTemp.Equals(strBuscar) Then
                intDesde = (Lista.CurrentRow.Index + 1)
            End If
            strBuscar = strTemp

            'Recorrer las filas
            For i As Integer = intDesde To intFilas
                'Recorrer las columnas
                For j As Integer = INT_CERO To intCols
                    strDato = If(Lista.Rows(i).Cells(j).Value, String.Empty).ToString().ToUpper.Trim
                    If strDato.Contains(strTemp) Then
                        'Seleccionar fila encontrada
                        Lista.ClearSelection()
                        Lista.CurrentCell = Lista.Rows(i).Cells(j)
                        logEx = True
                        Exit For
                    End If
                Next
                If logEx Then Exit For
            Next

            If Not logEx Then
                MessageBox.Show("No search results for this text", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Lista.Focus()
            End If
        End If
    End Sub
End Class