﻿Public Class frmFactuarEspecial
    Private ReporteNCHilos As Object
    Public Property Reporte_A_Ver_NCHilos() As Object

        Get
            Return ReporteNCHilos
        End Get
        Set(ByVal value As Object)
            ReporteNCHilos = value
        End Set
    End Property

    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load
        Try
            If IsNothing(ReporteNCHilos) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteNCHilos
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class