﻿Public Class FrmFacturaHN
    Private ReporteFacturacionHN As Object
    Public Property Reporte_A_VerHSM() As Object

        Get
            Return ReporteFacturacionHN
        End Get
        Set(ByVal value As Object)
            ReporteFacturacionHN = value
        End Set
    End Property
    Public Property Reporte_A_VerHN() As Object

        Get
            Return ReporteFacturacionHN
        End Get
        Set(ByVal value As Object)
            ReporteFacturacionHN = value
        End Set
    End Property
    Public Property Reporte_A_VerNS() As Object

        Get
            Return ReporteFacturacionHN
        End Get
        Set(ByVal value As Object)
            ReporteFacturacionHN = value
        End Set
    End Property
    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs)
        Try
            If IsNothing(ReporteFacturacionHN) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteFacturacionHN
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class