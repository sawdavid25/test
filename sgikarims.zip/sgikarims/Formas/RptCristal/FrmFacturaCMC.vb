﻿Public Class FrmFacturaCMC
    Private ReporteFacturaCMC As Object
    Public Property Reporte_A_Ver_FacturaCMC() As Object

        Get
            Return ReporteFacturaCMC
        End Get
        Set(ByVal value As Object)
            ReporteFacturaCMC = value
        End Set
    End Property
    Private Sub FrmFacturaCMC_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            If IsNothing(ReporteFacturaCMC) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteFacturaCMC
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load

    End Sub
End Class