﻿Public Class FrmReporteNotaCreditoPY
    Private ReporteNCPY As Object
    Public Property Reporte_A_Ver_NCPY() As Object

        Get
            Return ReporteNCPY
        End Get
        Set(ByVal value As Object)
            ReporteNCPY = value
        End Set
    End Property

    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load
        Try
            If IsNothing(ReporteNCPY) = True Then Exit Sub
            CrystalReportViewer1.ReportSource = ReporteNCPY
            Me.CrystalReportViewer1.RefreshReport()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class