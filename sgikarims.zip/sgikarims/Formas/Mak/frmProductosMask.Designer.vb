﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProductosMask
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonColor = New System.Windows.Forms.Button()
        Me.celdaColor = New System.Windows.Forms.TextBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colColor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDocumento.SuspendLayout()
        Me.SuspendLayout()
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(482, 65)
        Me.Encabezado1.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 65)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(482, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Location = New System.Drawing.Point(12, 101)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(432, 70)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcion, Me.colColor, Me.ColClase})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(432, 70)
        Me.dgLista.TabIndex = 0
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.checkActivo)
        Me.PanelDocumento.Controls.Add(Me.Label3)
        Me.PanelDocumento.Controls.Add(Me.Label2)
        Me.PanelDocumento.Controls.Add(Me.Label1)
        Me.PanelDocumento.Controls.Add(Me.botonColor)
        Me.PanelDocumento.Controls.Add(Me.celdaColor)
        Me.PanelDocumento.Controls.Add(Me.celdaDescripcion)
        Me.PanelDocumento.Controls.Add(Me.celdaCodigo)
        Me.PanelDocumento.Location = New System.Drawing.Point(12, 195)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(432, 125)
        Me.PanelDocumento.TabIndex = 3
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Location = New System.Drawing.Point(334, 33)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 7
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 92)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Color"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(33, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Description"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Code"
        '
        'botonColor
        '
        Me.botonColor.Location = New System.Drawing.Point(354, 82)
        Me.botonColor.Name = "botonColor"
        Me.botonColor.Size = New System.Drawing.Size(40, 23)
        Me.botonColor.TabIndex = 3
        Me.botonColor.Text = "..."
        Me.botonColor.UseVisualStyleBackColor = True
        '
        'celdaColor
        '
        Me.celdaColor.Location = New System.Drawing.Point(106, 85)
        Me.celdaColor.Name = "celdaColor"
        Me.celdaColor.ReadOnly = True
        Me.celdaColor.Size = New System.Drawing.Size(242, 20)
        Me.celdaColor.TabIndex = 2
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(106, 59)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(242, 20)
        Me.celdaDescripcion.TabIndex = 1
        '
        'celdaCodigo
        '
        Me.celdaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCodigo.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaCodigo.Location = New System.Drawing.Point(106, 33)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(100, 21)
        Me.celdaCodigo.TabIndex = 0
        Me.celdaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "ID"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 43
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colColor
        '
        Me.colColor.HeaderText = "Color"
        Me.colColor.Name = "colColor"
        Me.colColor.ReadOnly = True
        Me.colColor.Width = 56
        '
        'ColClase
        '
        Me.ColClase.HeaderText = "Type"
        Me.ColClase.Name = "ColClase"
        Me.ColClase.ReadOnly = True
        Me.ColClase.Width = 56
        '
        'frmProductosMask
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(482, 345)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmProductosMask"
        Me.Text = "frmProductosMask"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDocumento.ResumeLayout(False)
        Me.PanelDocumento.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents botonColor As Button
    Friend WithEvents celdaColor As TextBox
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents celdaCodigo As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colColor As DataGridViewTextBoxColumn
    Friend WithEvents ColClase As DataGridViewTextBoxColumn
End Class
