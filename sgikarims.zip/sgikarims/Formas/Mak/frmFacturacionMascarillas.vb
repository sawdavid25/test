﻿Public Class frmFacturacionMascarillas

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CatFactura = 691
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaNumero.Text = NO_FILA
        celdaIdCliente.Text = NO_FILA
        celdaCliente.Clear()
        celdaDireccion.Clear()
        celdaTotalCantidad.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFecha.Value = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaMoneda.Clear()
        celdaIdMoneda.Clear()
        celdaMoneda.Text = "US$"
        celdaIdMoneda.Text = 178
        celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
        celdaRef2.Clear()
        celdaIdFabricante.Clear()
        checkActivo.Checked = True
        celdaIdFabricante.Text = NO_FILA

        dgDetalle.Rows.Clear()
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num num,h.HDoc_Doc_Fec, h.HDoc_Emp_Nom cliente, HDoc_DR1_Num referencia 
                        From Dcmtos_HDR h
                        Where h.HDoc_Sis_Emp = {emp} And h.HDoc_Doc_Cat = {cat} {fech}"

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{cat}", CatFactura)
        If checkFechas.Checked = True Then
            strSQL = strSQL.Replace("{fech}", "And h.HDoc_Doc_Fec BETWEEN '{inicial}' AND '{final}'")
            strSQL = strSQL.Replace("{inicial}", dtpInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{final}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        Else
            strSQL = strSQL.Replace("{fech}", "")
        End If

        Return strSQL
    End Function

    Private Function SQLEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num num, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Mon idMoneda, h.HDoc_Doc_TC TC, cat_clave, h.HDoc_Emp_Cod idcliente, h.HDoc_Emp_Nom cliente, h.HDoc_Emp_Dir direccion, h.HDoc_Doc_Status, h.HDoc_DR1_Cat idFab
                        FROM Dcmtos_HDR h
                        LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{cat}", CatFactura)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)
        Return strSQL
    End Function

    Private Function SQLDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL

        strSQL = " SELECT p.PDoc_Par_Cat, p.PDoc_Par_Ano,p.PDoc_Par_Num,p.PDoc_Par_Lin, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, d.DDoc_Prd_UM UM,c.cat_clave, d.DDoc_RF1_Dbl saldo, d.DDoc_Prd_NET precio,d.DDoc_Prd_QTY cantidad, d.DDoc_Prd_PUQ paquetes, d.DDoc_RF2_Cod tipoPaq, d.DDoc_Prd_Ref referencia, d.DDoc_Doc_Lin linea
                        FROM Dcmtos_DTL d
                        LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 127
                        LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas'
                        WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{cat}", CatFactura)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)

        Return strSQL
    End Function

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            BarraTitulo1.CambiarTitulo("Billing")
            ListaPrincipal()
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Invoice")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New bill")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgListaPrincipal.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("num") & "|"
                    strFila &= REA.GetDateTime("HDoc_Doc_Fec") & "|"
                    strFila &= REA.GetString("cliente") & "|"
                    strFila &= REA.GetString("referencia")

                    cFunciones.AgregarFila(dgListaPrincipal, strFila)

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CalcularTotales()
        Dim dblSumaMonto As Double = 0
        Dim dblSumaQTY As Double = 0

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            dblSumaMonto = dgDetalle.Rows(i).Cells("colTotal").Value + dblSumaMonto
            dblSumaQTY = dgDetalle.Rows(i).Cells("colCantidad").Value + dblSumaQTY
        Next

        celdaTotal.Text = dblSumaMonto.ToString(FORMATO_MONEDA)
        celdaTotalCantidad.Text = dblSumaQTY.ToString(FORMATO_MONEDA)
    End Sub

    Private Function referencias() As String
        Dim strReferencia As String = STR_VACIO
        Dim referencia As String = STR_VACIO

        Try
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(j).Visible = True Then

                    If j = 0 Then
                        referencia = dgDetalle.Rows(j).Cells("colreferencia").Value
                    Else
                        referencia = referencia & " / " & dgDetalle.Rows(j).Cells("colreferencia").Value
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return referencia
    End Function

    Private Function ValidarCampos()
        Dim boolValidar As Boolean = True
        Try
            If celdaIdCliente.Text = NO_FILA Then
                MsgBox("You must select a Client", vbCritical)
                boolValidar = False
                Exit Function
            End If
            If dgDetalle.Rows.Count = 0 Then
                MsgBox("No data in detail", vbCritical)
                boolValidar = False
                Exit Function
            End If

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colCantidad").Value = 0 Then
                    MsgBox("Please enter the quantity on the line " & i + 1, vbCritical)
                    boolValidar = False
                    Exit Function
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return boolValidar
    End Function

    Private Function GuardarHDR()
        Dim GuardarCorrecto As Boolean = True
        Dim strRef As String = STR_VACIO
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_CAT = CatFactura
        If celdaNumero.Text = NO_FILA Then
            celdaNumero.Text = cFunciones.NuevoId(CatFactura)
            hdr.HDOC_DOC_NUM = celdaNumero.Text
        Else
            hdr.HDOC_DOC_NUM = celdaNumero.Text
        End If
        hdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
        hdr.HDOC_DOC_MON = celdaIdMoneda.Text
        hdr.HDOC_DOC_TC = celdaTasa.Text
        hdr.HDOC_EMP_COD = celdaIdCliente.Text
        hdr.HDOC_EMP_NOM = celdaCliente.Text
        hdr.HDOC_EMP_DIR = celdaDireccion.Text
        hdr.HDOC_DR1_CAT = celdaIdFabricante.Text
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If Not dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                If i = 0 Then
                    strRef = dgDetalle.Rows(i).Cells("colreferencia").Value
                Else
                    strRef = strRef & " / " & dgDetalle.Rows(i).Cells("colreferencia").Value
                End If
            End If
        Next
        hdr.HDOC_DR1_NUM = strRef
        hdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, 0)

        hdr.CONEXION = strConexion
        If Me.Tag = "Nuevo" Then
            If hdr.Guardar = False Then
                GuardarCorrecto = False
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Else
            If hdr.Actualizar = False Then
                GuardarCorrecto = False
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

        Return GuardarCorrecto
    End Function

    Private Function GuardarDTL()
        Dim GuardarCorrecto As Boolean = True
        Dim dtl As New clsDcmtos_DTL

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
            dtl.DDOC_DOC_CAT = CatFactura
            dtl.DDOC_DOC_ANO = celdaAnio.Text
            dtl.DDOC_DOC_NUM = celdaNumero.Text
            If dgDetalle.Rows(i).Cells("colLinea").Value = vbNullString Then
                dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
                dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
            Else
                dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
            End If
            dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
            dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
            dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value
            dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colSaldo").Value
            dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
            dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
            dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPaquetes").Value
            dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colTipoPaquete").Value
            dtl.DDOC_PRD_REF = dgDetalle.Rows(i).Cells("colreferencia").Value

            dtl.CONEXION = strConexion

            If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                If dtl.Guardar = False Then
                    GuardarCorrecto = False
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                If dtl.Actualizar = False Then
                    GuardarCorrecto = False
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                If dtl.Borrar = False Then
                    GuardarCorrecto = False
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Next

        Return GuardarCorrecto
    End Function

    Private Function GuardarCuentaCorriente()
        Dim GuardarCorrecto As Boolean = True
        Dim ec As New Tablas.TECTACTE

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            ec.ECTA_SIS_EMP = Sesion.IdEmpresa
            ec.ECTA_DOC_CAT = CatFactura
            ec.ECTA_DOC_ANO = celdaAnio.Text
            ec.ECTA_DOC_NUM = celdaNumero.Text
            ec.ECTA_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
            ec.ECTA_TIPOEMP = 1
            ec.ECTA_CODEMP = celdaIdCliente.Text
            ec.ECTA_CRGO_LOC = (dgDetalle.Rows(i).Cells("colTotal").Value * celdaTasa.Text)
            ec.ECTA_CRGO_EXT = dgDetalle.Rows(i).Cells("colTotal").Value
            ec.ECTA_CONCEPTO = "Factura No. " & celdaNumero.Text
            ec.ECta_FecDcmt_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            ec.ECta_FecVenc_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            ec.ECTA_MONEDA = celdaIdMoneda.Text
            ec.ECTA_TC = celdaTasa.Text
            ec.ECTA_REF_CAT = CatFactura
            ec.ECTA_REF_ANO = celdaAnio.Text
            ec.ECTA_REF_NUM = celdaNumero.Text

            ec.CONEXION = strConexion

            If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                If ec.PINSERT = False Then
                    GuardarCorrecto = False
                    MsgBox(ec.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                If ec.PUPDATE = False Then
                    GuardarCorrecto = False
                    MsgBox(ec.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                If ec.PDELETE = False Then
                    GuardarCorrecto = False
                    MsgBox(ec.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Next

        Return GuardarCorrecto
    End Function

    Private Function GuardarDTL_Pro()
        Dim GuardarCorrecto As Boolean = True
        Dim pro As New clsDcmtos_DTL_Pro
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            pro.PDOC_SIS_EMP = Sesion.IdEmpresa
            pro.PDOC_PAR_CAT = dgDetalle.Rows(i).Cells("colCatalogo").Value
            pro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAno").Value
            pro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumero").Value
            pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaIngreso").Value

            pro.PDOC_CHI_CAT = CatFactura
            pro.PDOC_CHI_ANO = celdaAnio.Text
            pro.PDOC_CHI_NUM = celdaNumero.Text
            pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
            pro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value

            If checkActivo.Checked = True Then
                pro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                pro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value
            Else
                pro.PDOC_QTY_ORD = INT_CERO
                pro.PDOC_QTY_PRO = INT_CERO
            End If
            pro.CONEXION = strConexion
            If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                If pro.Guardar = False Then
                    GuardarCorrecto = False
                    MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                If pro.Actualizar = False Then
                    GuardarCorrecto = False
                    MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                If pro.Borrar = False Then
                    GuardarCorrecto = False
                    MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Next

        Return GuardarCorrecto
    End Function

    Private Sub CargarEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        Try
            strSQL = SQLEncabezado(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetInt32("HDoc_Doc_Status") = 1 Then
                        checkActivo.Checked = INT_UNO
                    Else
                        checkActivo.Checked = INT_CERO
                    End If
                    celdaAnio.Text = REA.GetInt32("anio")
                    celdaNumero.Text = REA.GetInt32("num")
                    dtpFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    celdaMoneda.Text = REA.GetString("cat_clave")
                    celdaIdCliente.Text = REA.GetInt32("idcliente")
                    celdaCliente.Text = REA.GetString("cliente")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaIdFabricante.Text = REA.GetInt32("idFab")
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strFila As String = STR_VACIO

        Try


            strSQL = SQLDetalle(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgDetalle.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("PDoc_Par_Cat") & "|" ' Catalogo ingreso
                    strFila &= REA.GetInt32("PDoc_Par_Ano") & "|" ' Año ingreso
                    strFila &= REA.GetInt32("PDoc_Par_Num") & "|" ' Numero ingreso
                    strFila &= REA.GetInt32("PDoc_Par_Lin") & "|" ' Linea ingreso
                    strFila &= REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetInt32("UM") & "|"
                    strFila &= REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetDouble("saldo") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("cantidad") & "|"
                    strFila &= (REA.GetDouble("precio") * REA.GetDouble("cantidad")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("paquetes") & "|" ' paquete
                    strFila &= REA.GetString("tipoPaq") & "|" ' tipo de paquete
                    strFila &= REA.GetString("referencia") & "|" ' referencia
                    strFila &= REA.GetInt32("linea") & "|" ' linea
                    strFila &= INT_UNO  ' extra

                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop
                CalcularTotales()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub BorrarEncabezado()
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = CatFactura
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text

            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BorrarDetalle()
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = {cat} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{cat}", CatFactura)
            strSQL = strSQL.Replace("{anio}", celdaAnio.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BorrarCuentaCorriente()
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "ECta_Sis_Emp = {emp} AND ECta_Doc_Cat = {cat} AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{cat}", CatFactura)
            strSQL = strSQL.Replace("{anio}", celdaAnio.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BorrarRelacionDescargos()
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "PDoc_Sis_Emp = {emp} AND PDoc_Chi_Cat = {cat} AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{cat}", CatFactura)
            strSQL = strSQL.Replace("{anio}", celdaAnio.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)
            Dim dtlPro As New clsDcmtos_DTL_Pro
            dtlPro.CONEXION = strConexion
            dtlPro.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

#Region "Eventos"
    Private Sub frmFacturacionMascarillas_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFinal.Value = Today  'DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        MostrarLista()
        Accesos()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            Me.Tag = "Nuevo"
            LimpiarCampos()
            botonGastos.Enabled = False
            MostrarLista(False, True)
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Customer"
            frm.Campos = " c.cli_codigo codigo, c.cli_cliente cliente, c.cli_direccion "
            frm.Tabla = " Clientes c "
            frm.FiltroText = " Enter the Customer to filter "
            frm.Filtro = " c.cli_cliente "
            frm.Ordenamiento = " c.cli_cliente "
            frm.TipoOrdenamiento = " ASC "
            frm.Condicion = " c.cli_sisemp = " & Sesion.IdEmpresa & " AND c.cli_status = 'Activo'"
            frm.Limite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strCampos As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        strCampos = " d.DDoc_Doc_Ano anio,d.DDoc_Doc_Num numero,d.DDoc_Doc_Lin linea,d.DDoc_Prd_Cod codigo,d.DDoc_Prd_Des descripcion,d.DDoc_Prd_NET precio, h.HDoc_DR1_Num referencia, (d.DDoc_Prd_QTY) - COALESCE((
                        SELECT SUM(c.PDoc_QTY_Pro)
                        FROM Dcmtos_DTL_Pro c
                        WHERE d.DDoc_Sis_Emp = c.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = c.PDoc_Par_Cat AND d.DDoc_Doc_Ano = c.PDoc_Par_Ano AND d.DDoc_Doc_Num = c.PDoc_Par_Num AND d.DDoc_Doc_Lin = c.PDoc_Par_Lin AND c.PDoc_Chi_Cat = {cat}),0) Saldo,l.cat_clave medida, d.DDoc_Prd_UM Umedida, i.inv_provcod fabricante"

        strCampos = strCampos.Replace("{cat}", CatFactura)

        strTabla = " Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN Catalogos l ON l.cat_num = d.DDoc_Prd_UM AND cat_clase = 'Medidas'"

        strCondicion = " h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 127 AND h.HDoc_Doc_Status = 1 AND  (COALESCE((
                            SELECT SUM(p.PDoc_QTY_Pro)
                            FROM Dcmtos_DTL_Pro p
                            WHERE d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num AND d.DDoc_Doc_Lin = p.PDoc_Par_Lin AND p.PDoc_Chi_Cat = {cat}),0) < d.DDoc_Prd_QTY)"

        strCondicion = strCondicion.Replace("{emp}", Sesion.IdEmpresa)
        strCondicion = strCondicion.Replace("{cat}", CatFactura)

        Try
            frm.Titulo = "Discharges"
            frm.Campos = strCampos
            frm.Tabla = strTabla
            frm.FiltroText = " Enter the Reference To filter"
            frm.Filtro = " h.HDoc_DR1_Num "
            frm.Ordenamiento = " d.DDoc_Doc_Ano, d.DDoc_Doc_Num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strFila = 127 & "|" ' Catalogo Ingreso
                strFila &= frm.ListaClientes.SelectedCells(0).Value & "|" 'Año Ingreso
                strFila &= frm.ListaClientes.SelectedCells(1).Value & "|" 'Numero Ingreso
                strFila &= frm.ListaClientes.SelectedCells(2).Value & "|" 'Linea Ingreso
                strFila &= frm.ListaClientes.SelectedCells(3).Value & "|" 'Codigo de inventario
                strFila &= frm.ListaClientes.SelectedCells(4).Value & "|" 'Descripcion del código
                strFila &= frm.ListaClientes.SelectedCells(9).Value & "|" 'Id de medida
                strFila &= frm.ListaClientes.SelectedCells(8).Value & "|" 'Unidad de medida
                strFila &= frm.ListaClientes.SelectedCells(7).Value & "|" 'Saldo
                strFila &= frm.ListaClientes.SelectedCells(5).Value & "|" 'Precio
                strFila &= INT_CERO & "|" ' Cantidad a Descargar
                strFila &= INT_CERO & "|" ' total
                strFila &= INT_UNO & "|" ' Cantidad de Paquetes
                strFila &= "" & "|" ' Tipo de Bulto
                strFila &= frm.ListaClientes.SelectedCells(6).Value & "|"
                strFila &= "" & "|"
                strFila &= INT_CERO

                If dgDetalle.Rows.Count = 0 Then
                    celdaIdFabricante.Text = frm.ListaClientes.SelectedCells(10).Value
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Else
                    If celdaIdFabricante.Text = frm.ListaClientes.SelectedCells(10).Value Then
                        cFunciones.AgregarFila(dgDetalle, strFila)
                    Else
                        MsgBox("You cannot add a different manufacturer's product", vbInformation, "Notice")
                        Exit Sub
                    End If
                End If


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        dgDetalle.SelectedCells(11).Value = dgDetalle.SelectedCells(9).Value * dgDetalle.SelectedCells(10).Value
        CalcularTotales()
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        Else
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 13
                    Dim frm As New frmSeleccionar

                    Try
                        frm.Titulo = "Package Type"
                        frm.Campos = " cat_num Number, cat_Desc Description"
                        frm.Tabla = " Catalogos"
                        frm.FiltroText = " Enter the Package Type to filter"
                        frm.Filtro = " cat_Desc "
                        frm.Condicion = "  cat_clase = 'TipoBulto'"

                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.SelectedCells(13).Value = frm.Dato
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
            End Select
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If (logInsertar = True And Me.Tag = "Nuevo") Or (logEditar = True And Me.Tag = "Mod") Then
            If ValidarCampos() = True Then
                If GuardarHDR() = True Then
                    If Me.Tag = "Nuevo" Then
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 1, CatFactura, celdaAnio.Text, celdaNumero.Text, "Agregar")
                    Else
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 1, CatFactura, celdaAnio.Text, celdaNumero.Text, "Modificacion")
                    End If

                    If GuardarDTL() = True Then

                        If GuardarCuentaCorriente() = True Then
                            GuardarDTL_Pro()
                            MsgBox("Document Saved Successfully", vbInformation, "Notice")
                            MostrarLista()
                        End If
                    End If
                End If
            End If
        Else
            MsgBox("You do not have access to modify the document.", vbInformation)
        End If
    End Sub

    Private Sub dgListaPrincipal_DoubleClick(sender As Object, e As EventArgs) Handles dgListaPrincipal.DoubleClick
        Dim anio As Integer = INT_CERO
        Dim Numero As Integer = INT_CERO

        Me.Tag = "Mod"
        anio = dgListaPrincipal.SelectedCells(0).Value
        Numero = dgListaPrincipal.SelectedCells(1).Value
        LimpiarCampos()
        BloquearBotones()
        botonGastos.Enabled = True
        MostrarLista(False)
        CargarEncabezado(anio, Numero)
        CargarDetalle(anio, Numero)
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        dgDetalle.CurrentRow.Cells("colExtra").Value = 2
        dgDetalle.CurrentRow.Visible = False
    End Sub

    Private Sub dgListaPrincipal_KeyDown(sender As Object, e As KeyEventArgs) Handles dgListaPrincipal.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgListaPrincipal)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(CatFactura, dgListaPrincipal.SelectedCells(0).Value, dgListaPrincipal.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgListaPrincipal.SelectedCells(1).Value, dgListaPrincipal.SelectedCells(0).Value, CatFactura)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are you sure to delete the document", vbInformation + vbYesNo, "Notice") = vbYes Then
                BorrarEncabezado()
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 1, CatFactura, celdaAnio.Text, celdaNumero.Text, "Eliminación")
                BorrarDetalle()
                BorrarCuentaCorriente()
                BorrarRelacionDescargos()
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permissions to perform this action", vbCritical)
        End If
    End Sub

    Private Sub botonGastos_Click(sender As Object, e As EventArgs) Handles botonGastos.Click
        Dim frm As New frmGastosLogistica
        frm.Catalogo = CatFactura
        frm.Ano = celdaAnio.Text
        frm.Numero = celdaNumero.Text
        frm.linea = INT_UNO

        frm.Ref_Ano = celdaAnio.Text
        frm.Ref_Catalogo = CatFactura
        frm.Ref_Numero = celdaNumero.Text
        frm.Ref_linea = INT_UNO

        frm.celdaReferencia.Text = "Factura No. " & celdaNumero.Text

        frm.ShowDialog(Me)
    End Sub

    Private Sub botonPagos_Click(sender As Object, e As EventArgs) Handles botonPagos.Click
        Dim frm As New frmPagosMascarillas
        frm.Catalogo = CatFactura
        frm.Ano = celdaAnio.Text
        frm.Numero = celdaNumero.Text

        frm.celdaReferencia.Text = "Factura No. " & celdaNumero.Text
        frm.ShowDialog(Me)
    End Sub

#End Region

#End Region
End Class