﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPagosMascarillas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelInfo = New System.Windows.Forms.Panel()
        Me.celdaReferencia = New System.Windows.Forms.Label()
        Me.celdaNum = New System.Windows.Forms.TextBox()
        Me.celdaAno = New System.Windows.Forms.TextBox()
        Me.celdaCat = New System.Windows.Forms.TextBox()
        Me.panelTotal = New System.Windows.Forms.Panel()
        Me.celdaSuma = New System.Windows.Forms.TextBox()
        Me.etiquetaLibras = New System.Windows.Forms.Label()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.dgPagos = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelInfo.SuspendLayout()
        Me.panelTotal.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgPagos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelInfo
        '
        Me.panelInfo.Controls.Add(Me.celdaReferencia)
        Me.panelInfo.Controls.Add(Me.celdaNum)
        Me.panelInfo.Controls.Add(Me.celdaAno)
        Me.panelInfo.Controls.Add(Me.celdaCat)
        Me.panelInfo.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelInfo.Location = New System.Drawing.Point(0, 0)
        Me.panelInfo.Margin = New System.Windows.Forms.Padding(4)
        Me.panelInfo.Name = "panelInfo"
        Me.panelInfo.Size = New System.Drawing.Size(800, 55)
        Me.panelInfo.TabIndex = 1
        '
        'celdaReferencia
        '
        Me.celdaReferencia.AutoSize = True
        Me.celdaReferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaReferencia.Location = New System.Drawing.Point(28, 18)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(57, 18)
        Me.celdaReferencia.TabIndex = 8
        Me.celdaReferencia.Text = "Label1"
        '
        'celdaNum
        '
        Me.celdaNum.Location = New System.Drawing.Point(510, 17)
        Me.celdaNum.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNum.Name = "celdaNum"
        Me.celdaNum.Size = New System.Drawing.Size(12, 22)
        Me.celdaNum.TabIndex = 2
        Me.celdaNum.Text = "100"
        Me.celdaNum.Visible = False
        '
        'celdaAno
        '
        Me.celdaAno.Location = New System.Drawing.Point(481, 15)
        Me.celdaAno.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAno.Name = "celdaAno"
        Me.celdaAno.Size = New System.Drawing.Size(12, 22)
        Me.celdaAno.TabIndex = 1
        Me.celdaAno.Text = "2019"
        Me.celdaAno.Visible = False
        '
        'celdaCat
        '
        Me.celdaCat.Location = New System.Drawing.Point(452, 15)
        Me.celdaCat.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCat.Name = "celdaCat"
        Me.celdaCat.Size = New System.Drawing.Size(12, 22)
        Me.celdaCat.TabIndex = 0
        Me.celdaCat.Text = "47"
        Me.celdaCat.Visible = False
        '
        'panelTotal
        '
        Me.panelTotal.Controls.Add(Me.celdaSuma)
        Me.panelTotal.Controls.Add(Me.etiquetaLibras)
        Me.panelTotal.Controls.Add(Me.botonCancelar)
        Me.panelTotal.Controls.Add(Me.botonAceptar)
        Me.panelTotal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotal.Location = New System.Drawing.Point(0, 388)
        Me.panelTotal.Margin = New System.Windows.Forms.Padding(4)
        Me.panelTotal.Name = "panelTotal"
        Me.panelTotal.Size = New System.Drawing.Size(800, 62)
        Me.panelTotal.TabIndex = 2
        '
        'celdaSuma
        '
        Me.celdaSuma.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSuma.Enabled = False
        Me.celdaSuma.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaSuma.Location = New System.Drawing.Point(101, 14)
        Me.celdaSuma.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaSuma.Name = "celdaSuma"
        Me.celdaSuma.Size = New System.Drawing.Size(141, 26)
        Me.celdaSuma.TabIndex = 6
        '
        'etiquetaLibras
        '
        Me.etiquetaLibras.AutoSize = True
        Me.etiquetaLibras.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaLibras.Location = New System.Drawing.Point(28, 17)
        Me.etiquetaLibras.Name = "etiquetaLibras"
        Me.etiquetaLibras.Size = New System.Drawing.Size(51, 20)
        Me.etiquetaLibras.TabIndex = 7
        Me.etiquetaLibras.Text = "Total"
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.botonCancelar.Location = New System.Drawing.Point(545, 6)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(79, 47)
        Me.botonCancelar.TabIndex = 5
        Me.botonCancelar.Text = "Cancelar"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(687, 6)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(79, 47)
        Me.botonAceptar.TabIndex = 4
        Me.botonAceptar.Text = "Aceptar"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonEliminar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(717, 55)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(4)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(83, 333)
        Me.panelBotones.TabIndex = 3
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(7, 90)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(60, 50)
        Me.botonEliminar.TabIndex = 3
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(8, 21)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(60, 53)
        Me.botonAgregar.TabIndex = 2
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'dgPagos
        '
        Me.dgPagos.AllowUserToAddRows = False
        Me.dgPagos.AllowUserToDeleteRows = False
        Me.dgPagos.AllowUserToOrderColumns = True
        Me.dgPagos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPagos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPagos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colFecha, Me.colDocumento, Me.colMonto, Me.colMarca})
        Me.dgPagos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgPagos.Location = New System.Drawing.Point(0, 55)
        Me.dgPagos.MultiSelect = False
        Me.dgPagos.Name = "dgPagos"
        Me.dgPagos.RowTemplate.Height = 24
        Me.dgPagos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPagos.Size = New System.Drawing.Size(717, 333)
        Me.dgPagos.TabIndex = 4
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        '
        'colMonto
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText
        Me.colMonto.DefaultCellStyle = DataGridViewCellStyle1
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Marca"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.Visible = False
        '
        'frmPagosMascarillas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.dgPagos)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.panelTotal)
        Me.Controls.Add(Me.panelInfo)
        Me.Name = "frmPagosMascarillas"
        Me.Text = "Payments"
        Me.panelInfo.ResumeLayout(False)
        Me.panelInfo.PerformLayout()
        Me.panelTotal.ResumeLayout(False)
        Me.panelTotal.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgPagos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents panelInfo As Panel
    Friend WithEvents celdaReferencia As Label
    Friend WithEvents celdaNum As TextBox
    Friend WithEvents celdaAno As TextBox
    Friend WithEvents celdaCat As TextBox
    Friend WithEvents panelTotal As Panel
    Friend WithEvents celdaSuma As TextBox
    Friend WithEvents etiquetaLibras As Label
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents dgPagos As DataGridView
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
End Class
