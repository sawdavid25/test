﻿Imports System.ComponentModel

Public Class frmProductosMask

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Function NuevoArticulo() As Long
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim NUEVO As Long
        Try
            strSQL = " Select max(ifnull(art_codigo,0))+1 
                        from Articulos 
                        where art_sisemp = " & Sesion.IdEmpresa

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            NUEVO = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return NUEVO
    End Function

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
            'botonBuscar.Enabled = True
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
            'botonBuscar.Enabled = False
        End If
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False, Optional cod As Integer = 0)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelDocumento.Dock = DockStyle.None
            PanelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Product Maintenance")
            'Cargar Datos
            queryListaPrincipal()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            PanelDocumento.Dock = DockStyle.Fill
            PanelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Public Sub LimpiarPanel()
        checkActivo.Checked = True
        celdaCodigo.Text = NO_FILA
        celdaDescripcion.Text = STR_VACIO
        celdaColor.Text = NO_FILA
    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT a.art_codigo Codigo, IFNULL(a.art_DCorta,'') Dcorta,  IFNULL(a.art_desc,'N/A') descripcion, IFNULL(c.cat_desc,'') Clase, a.art_status estado
                        FROM Articulos a
                        LEFT JOIN Catalogos c ON c.cat_num = a.art_clase AND c.cat_clase = 'ClaseArt'
                        WHERE art_sisemp ={empresa}  AND c.cat_clave = 'MASK'
                        ORDER BY art_codigo desc"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal(Optional cod As Integer = 0)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLlista()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Codigo") & "|" & REA.GetString("DCorta") & "|" & REA.GetString("descripcion") & "|" & REA.GetString("Clase")
                    If REA.GetInt32("estado") = 1 Then
                        cFunciones.AgregarFila(dgLista, strFila)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    End If

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SeleccionEncabezado(ByVal intCodigo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = "Select a.art_codigo Codigo,  a.art_DCorta DCorta, a.art_DLarga DLarga, a.art_clase IDClase, caa.cat_desc Clase, art_status Estado, a.art_desc color
                FROM Articulos a
                LEFT JOIN Catalogos caa ON caa.cat_num = a.art_clase AND caa.cat_clase ='ClaseArt'
                WHERE a.art_sisemp  = {empresa} AND a.art_codigo ={codigo}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", intCodigo)

        Return strSQL
    End Function

    Private Sub CargarEncabezado2(ByVal intCodigo As Integer, Optional ByVal intClase As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "Select a.art_codigo Codigo,  a.art_DCorta DCorta, a.art_DLarga DLarga, a.art_clase IDClase, caa.cat_desc Clase, art_status Estado, a.art_desc color
                FROM Articulos a
                LEFT JOIN Catalogos caa ON caa.cat_num = a.art_clase AND caa.cat_clase ='ClaseArt'
                WHERE a.art_sisemp  = {empresa} AND a.art_codigo ={codigo}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", intCodigo)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        REA.Read()
        celdaCodigo.Text = REA.GetInt32("Codigo")
        celdaDescripcion.Text = REA.GetString("DCorta")
        celdaColor.Text = REA.GetString("color")

    End Sub

    Private Sub CargarEncabezado(ByVal intCodigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        strSQL = SeleccionEncabezado(intCodigo)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                REA.Read()
                celdaCodigo.Text = REA.GetInt32("Codigo")
                celdaDescripcion.Text = REA.GetString("DCorta")
                celdaColor.Text = REA.GetString("color")
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Query para guardar Datos Encabezado
    Private Function GuardarRegistro() As Boolean
        Dim logResultado As Boolean = True
        Dim TArt As New Tablas.TARTICULOS

        Try
            TArt.CONEXION = strConexion
            TArt.ART_SISEMP = Sesion.IdEmpresa

            TArt.ART_CLASE = 526
            TArt.ART_TITULO = STR_VACIO
            TArt.ART_ACABADO = INT_CERO
            TArt.ART_SPINNING = INT_CERO
            TArt.ART_DENIER = INT_CERO
            TArt.ART_FILAMENTO = INT_CERO
            TArt.ART_EXTRAINFO = STR_VACIO
            TArt.ART_DCORTA = celdaDescripcion.Text
            TArt.ART_DLARGA = celdaDescripcion.Text
            TArt.ART_TEXTURIZADO = INT_CERO
            TArt.ART_DESC = celdaColor.Text
            TArt.ART_FRAC = STR_VACIO
            TArt.ART_DUTY = NO_FILA
            TArt.ART_REF = INT_CERO
            TArt.ART_HEATHER = INT_CERO
            TArt.ART_STATUS = IIf(checkActivo.Checked = True, 1, 0)
            TArt.ART_VENTA = INT_CERO
            TArt.ART_PRODUCCION = INT_UNO


            If Me.Tag = "Mod" Then
                TArt.ART_CODIGO = celdaCodigo.Text
                If TArt.PUPDATE = False Then
                    logResultado = False
                    MsgBox(TArt.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                celdaCodigo.Text = NuevoArticulo()
                TArt.ART_CODIGO = celdaCodigo.Text
                If TArt.PINSERT = False Then
                    logResultado = False
                    MsgBox(TArt.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Public Sub CrearUnProductoGenerico(ByVal strCodigoArticulo As String)
        Dim lngID As Integer
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Dim CON2 As MySqlConnection
        Dim REA As MySqlDataReader

        strSQL = "SELECT (IFNULL(MAX(inv_numero),0)+1) ID"
        strSQL &= "      FROM Inventarios"
        strSQL &= "              WHERE inv_sisemp={empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            lngID = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        strSQL2 = "SELECT cat_num, cat_clave, cat_desc"
        strSQL2 &= "     FROM Catalogos"
        strSQL2 &= "             WHERE {desc} = 'GENERIC'"
        If Sesion.IdEmpresa = 15 Then
            strSQL2 = Replace(strSQL2, "{desc}", "cat_dato")
        Else
            strSQL2 = Replace(strSQL2, "{desc}", "cat_sist")
        End If


        Try
            CON2 = New MySqlConnection(strConexion)
            CON2.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON2)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read

                    If MsgBox(" Do you want to create Generic Code?" & vbCr & vbCr & REA.GetString("cat_desc"), vbExclamation + vbYesNo + vbDefaultButton2, "Generic: " & REA.GetString("cat_clave")) = vbYes Then
                        '  REA.Close()

                        Dim Inv As New Tablas.TINVENTARIOS
                        Inv.CONEXION = strConexion

                        Inv.INV_SISEMP = Sesion.IdEmpresa
                        Inv.INV_NUMERO = lngID
                        Inv.inv_fecha_NET = cFunciones.HoyMySQL
                        Inv.INV_ARTCODIGO = strCodigoArticulo
                        If Sesion.IdEmpresa = 15 Then
                            Inv.INV_LUGARFAB = 1
                        Else
                            Inv.INV_LUGARFAB = REA.GetInt64("cat_num")
                        End If

                        Inv.INV_UMVENTA = 69
                        Inv.INV_UMCMPRA = 69
                        Inv.INV_UMFAC = 1
                        Inv.INV_COSTO = 0
                        Inv.INV_PRECIOMIN = 0
                        Inv.INV_PRECIOMAX = 0
                        Inv.INV_PRECIOFAC = 1
                        Inv.INV_STATUS = IIf(checkActivo.Checked = True, 1, 2)
                        Inv.INV_GENERICO = 1

                        If Me.Tag = "Mod" Then
                            If Inv.PINSERT() = False Then
                                MsgBox(Inv.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        Else
                            If Inv.PINSERT = False Then
                                MsgBox(Inv.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        End If

                        lngID = lngID + 1
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Validacion y metodos de Borrar 
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*)"
        strSQL &= "     FROM Inventarios i "
        strSQL &= "         WHERE i.inv_sisemp = {empresa} AND i.inv_artcodigo ={num}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{num}", celdaCodigo.Text)
        Return strSQL
    End Function

    Private Sub BorrarProducto(ByVal num As Integer)

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Articulos  WHERE art_sisemp = {empresa} AND art_codigo = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", num)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Eventos"

    Private Sub frmProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If GuardarRegistro() Then
                If Me.Tag = "Nuevo" Then

                    CrearUnProductoGenerico(celdaCodigo.Text)
                    'Registra la transaccion
                    cFunciones.EscribirRegistro("Productos", clsFunciones.AccEnum.acAdd, celdaCodigo.Text)
                    MsgBox("Successful", MsgBoxStyle.Information)

                Else

                    MsgBox("Successful", MsgBoxStyle.Information)
                    'Registra la transaccion
                    cFunciones.EscribirRegistro("Productos", clsFunciones.AccEnum.acUpdate, celdaCodigo.Text)

                End If
                MostrarLista(True, False, celdaCodigo.Text)
            End If




        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO

        LimpiarPanel()
        MostrarLista(False)
        Me.Tag = "Nuevo"

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If PanelDocumento.Visible = True Then
            MostrarLista(True, False, celdaCodigo.Text)
        Else
            Me.Close()
        End If
    End Sub

    Private Sub dgLista_DoubleClick1(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intCodigo As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        LimpiarPanel()
        intCodigo = dgLista.SelectedCells(0).Value
        Dim strSQL As String = STR_VACIO


        strSQL = "SELECT * "
        strSQL &= " FROM Articulos a"
        strSQL &= "      WHERE a.art_sisemp = {empresa} and a.art_codigo = {codigo}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", intCodigo)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        REA.Read()

        CargarEncabezado(intCodigo)

        MostrarLista(False)
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(INT_CERO, INT_CERO, INT_CERO, "Articulos", dgLista.SelectedCells(0).Value)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim IntNumDocs As Integer

            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()
            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarProducto(celdaCodigo.Text)
                    cFunciones.EscribirRegistro("Productos", clsFunciones.AccEnum.acDelete, celdaCodigo.Text)
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub frmProductosMask_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub botonColor_Click(sender As Object, e As EventArgs) Handles botonColor.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Color"
            frm.Campos = " cat_desc Color"
            frm.Tabla = " Catalogos  "
            frm.FiltroText = " Select a color "
            frm.Filtro = "  cat_desc   "
            frm.Condicion = " cat_clase = 'Color' "

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaColor.Text = frm.LLave

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

End Class