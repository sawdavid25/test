﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFacturacionMascarillas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgListaPrincipal = New System.Windows.Forms.DataGridView()
        Me.colLAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltors = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPaquetes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoPaquete = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colreferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTotalCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.botonGastos = New System.Windows.Forms.Button()
        Me.celdaRef2 = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaIdFabricante = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.botonPagos = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgListaPrincipal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltors.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgListaPrincipal)
        Me.panelListaPrincipal.Controls.Add(Me.panelFiltors)
        Me.panelListaPrincipal.Location = New System.Drawing.Point(272, 11)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(219, 106)
        Me.panelListaPrincipal.TabIndex = 0
        '
        'dgListaPrincipal
        '
        Me.dgListaPrincipal.AllowUserToAddRows = False
        Me.dgListaPrincipal.AllowUserToDeleteRows = False
        Me.dgListaPrincipal.AllowUserToOrderColumns = True
        Me.dgListaPrincipal.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgListaPrincipal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaPrincipal.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLAnio, Me.colLNumero, Me.colLFecha, Me.colLCliente, Me.colLReferencia})
        Me.dgListaPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaPrincipal.Location = New System.Drawing.Point(0, 55)
        Me.dgListaPrincipal.Name = "dgListaPrincipal"
        Me.dgListaPrincipal.ReadOnly = True
        Me.dgListaPrincipal.RowTemplate.Height = 24
        Me.dgListaPrincipal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaPrincipal.Size = New System.Drawing.Size(219, 51)
        Me.dgListaPrincipal.TabIndex = 1
        '
        'colLAnio
        '
        Me.colLAnio.HeaderText = "Anio"
        Me.colLAnio.Name = "colLAnio"
        Me.colLAnio.ReadOnly = True
        '
        'colLNumero
        '
        Me.colLNumero.HeaderText = "Numero"
        Me.colLNumero.Name = "colLNumero"
        Me.colLNumero.ReadOnly = True
        '
        'colLFecha
        '
        Me.colLFecha.HeaderText = "Date"
        Me.colLFecha.Name = "colLFecha"
        Me.colLFecha.ReadOnly = True
        '
        'colLCliente
        '
        Me.colLCliente.HeaderText = "Client"
        Me.colLCliente.Name = "colLCliente"
        Me.colLCliente.ReadOnly = True
        '
        'colLReferencia
        '
        Me.colLReferencia.HeaderText = "Reference"
        Me.colLReferencia.Name = "colLReferencia"
        Me.colLReferencia.ReadOnly = True
        '
        'panelFiltors
        '
        Me.panelFiltors.Controls.Add(Me.botonActualizar)
        Me.panelFiltors.Controls.Add(Me.etiquetaFechas)
        Me.panelFiltors.Controls.Add(Me.dtpFinal)
        Me.panelFiltors.Controls.Add(Me.dtpInicial)
        Me.panelFiltors.Controls.Add(Me.checkFechas)
        Me.panelFiltors.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltors.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltors.Name = "panelFiltors"
        Me.panelFiltors.Size = New System.Drawing.Size(219, 55)
        Me.panelFiltors.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(621, 13)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 26)
        Me.botonActualizar.TabIndex = 12
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(392, 20)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaFechas.TabIndex = 11
        Me.etiquetaFechas.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(474, 15)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(121, 22)
        Me.dtpFinal.TabIndex = 10
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(254, 15)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(121, 22)
        Me.dtpInicial.TabIndex = 9
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(17, 19)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(231, 21)
        Me.checkFechas.TabIndex = 8
        Me.checkFechas.Text = "Show Documents Between Date"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelTotales)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(27, 142)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1052, 415)
        Me.panelDocumento.TabIndex = 3
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.Panel2)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 189)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1052, 157)
        Me.panelDetalle.TabIndex = 3
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAno, Me.colNumero, Me.colLineaIngreso, Me.colCodigo, Me.colDescripcion, Me.colIdMedida, Me.colUMedida, Me.colSaldo, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colPaquetes, Me.colTipoPaquete, Me.colreferencia, Me.colLinea, Me.colExtra})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(989, 157)
        Me.dgDetalle.TabIndex = 1
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 93
        '
        'colAno
        '
        Me.colAno.HeaderText = "Ano"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        Me.colAno.Width = 62
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Numero"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Visible = False
        Me.colNumero.Width = 87
        '
        'colLineaIngreso
        '
        Me.colLineaIngreso.HeaderText = "LineaIngreso"
        Me.colLineaIngreso.Name = "colLineaIngreso"
        Me.colLineaIngreso.ReadOnly = True
        Me.colLineaIngreso.Visible = False
        Me.colLineaIngreso.Width = 119
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "idMedida"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.ReadOnly = True
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 94
        '
        'colUMedida
        '
        Me.colUMedida.HeaderText = "Measure"
        Me.colUMedida.Name = "colUMedida"
        Me.colUMedida.ReadOnly = True
        Me.colUMedida.Width = 92
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Width = 88
        '
        'colPrecio
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.Format = "N2"
        DataGridViewCellStyle1.NullValue = Nothing
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.colPrecio.DefaultCellStyle = DataGridViewCellStyle1
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 69
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 90
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 69
        '
        'colPaquetes
        '
        Me.colPaquetes.HeaderText = "Package"
        Me.colPaquetes.Name = "colPaquetes"
        Me.colPaquetes.Width = 92
        '
        'colTipoPaquete
        '
        Me.colTipoPaquete.HeaderText = "Package Type"
        Me.colTipoPaquete.Name = "colTipoPaquete"
        Me.colTipoPaquete.ReadOnly = True
        Me.colTipoPaquete.Width = 128
        '
        'colreferencia
        '
        Me.colreferencia.HeaderText = "Reference"
        Me.colreferencia.Name = "colreferencia"
        Me.colreferencia.ReadOnly = True
        Me.colreferencia.Width = 103
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 64
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        Me.colExtra.Width = 69
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonQuitar)
        Me.Panel2.Controls.Add(Me.botonAgregar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(989, 0)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(63, 157)
        Me.Panel2.TabIndex = 2
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotalCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotal)
        Me.panelTotales.Controls.Add(Me.etiquetaCantidad)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 346)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1052, 69)
        Me.panelTotales.TabIndex = 4
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(852, 24)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(140, 22)
        Me.celdaTotal.TabIndex = 3
        '
        'celdaTotalCantidad
        '
        Me.celdaTotalCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalCantidad.Location = New System.Drawing.Point(605, 24)
        Me.celdaTotalCantidad.Name = "celdaTotalCantidad"
        Me.celdaTotalCantidad.ReadOnly = True
        Me.celdaTotalCantidad.Size = New System.Drawing.Size(140, 22)
        Me.celdaTotalCantidad.TabIndex = 2
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotal.Location = New System.Drawing.Point(797, 27)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaTotal.TabIndex = 1
        Me.etiquetaTotal.Text = "Total"
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCantidad.Location = New System.Drawing.Point(483, 27)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(111, 17)
        Me.etiquetaCantidad.TabIndex = 0
        Me.etiquetaCantidad.Text = "Total Quantity"
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.botonPagos)
        Me.panelEncabezado.Controls.Add(Me.botonGastos)
        Me.panelEncabezado.Controls.Add(Me.celdaRef2)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.celdaIdFabricante)
        Me.panelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaIdCliente)
        Me.panelEncabezado.Controls.Add(Me.checkActivo)
        Me.panelEncabezado.Controls.Add(Me.celdaTasa)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaDireccion)
        Me.panelEncabezado.Controls.Add(Me.botonCliente)
        Me.panelEncabezado.Controls.Add(Me.celdaCliente)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDireccion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCliente)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1052, 189)
        Me.panelEncabezado.TabIndex = 0
        '
        'botonGastos
        '
        Me.botonGastos.Location = New System.Drawing.Point(707, 136)
        Me.botonGastos.Margin = New System.Windows.Forms.Padding(4)
        Me.botonGastos.Name = "botonGastos"
        Me.botonGastos.Size = New System.Drawing.Size(100, 28)
        Me.botonGastos.TabIndex = 48
        Me.botonGastos.Text = "Expenses"
        Me.botonGastos.UseVisualStyleBackColor = True
        '
        'celdaRef2
        '
        Me.celdaRef2.Location = New System.Drawing.Point(667, 165)
        Me.celdaRef2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaRef2.Name = "celdaRef2"
        Me.celdaRef2.Size = New System.Drawing.Size(37, 22)
        Me.celdaRef2.TabIndex = 47
        Me.celdaRef2.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(230, 141)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(49, 25)
        Me.botonMoneda.TabIndex = 46
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(113, 97)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(113, 22)
        Me.dtpFecha.TabIndex = 45
        '
        'celdaIdFabricante
        '
        Me.celdaIdFabricante.Location = New System.Drawing.Point(461, 94)
        Me.celdaIdFabricante.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdFabricante.Name = "celdaIdFabricante"
        Me.celdaIdFabricante.Size = New System.Drawing.Size(40, 22)
        Me.celdaIdFabricante.TabIndex = 44
        Me.celdaIdFabricante.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(285, 142)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(37, 22)
        Me.celdaIdMoneda.TabIndex = 43
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(1005, 44)
        Me.celdaIdCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(54, 22)
        Me.celdaIdCliente.TabIndex = 42
        Me.celdaIdCliente.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(254, 19)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 40
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(546, 141)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(113, 22)
        Me.celdaTasa.TabIndex = 39
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(110, 141)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(113, 22)
        Me.celdaMoneda.TabIndex = 38
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(544, 55)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(447, 61)
        Me.celdaDireccion.TabIndex = 37
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(997, 10)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(37, 30)
        Me.botonCliente.TabIndex = 34
        Me.botonCliente.Text = "..."
        Me.botonCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(544, 17)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(447, 22)
        Me.celdaCliente.TabIndex = 36
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(113, 58)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(113, 22)
        Me.celdaNumero.TabIndex = 35
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(113, 17)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(113, 22)
        Me.celdaAnio.TabIndex = 32
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(458, 141)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 31
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(22, 141)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 30
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(453, 55)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(53, 17)
        Me.etiquetaDireccion.TabIndex = 29
        Me.etiquetaDireccion.Text = "Addres"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(453, 17)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(43, 17)
        Me.etiquetaCliente.TabIndex = 28
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(22, 99)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 27
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(22, 58)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 26
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(22, 17)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 25
        Me.etiquetaAnio.Text = "Year"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 75)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1085, 35)
        Me.BarraTitulo1.TabIndex = 2
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1085, 75)
        Me.Encabezado1.TabIndex = 1
        '
        'botonPagos
        '
        Me.botonPagos.Location = New System.Drawing.Point(889, 135)
        Me.botonPagos.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPagos.Name = "botonPagos"
        Me.botonPagos.Size = New System.Drawing.Size(100, 28)
        Me.botonPagos.TabIndex = 49
        Me.botonPagos.Text = "Payments"
        Me.botonPagos.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(14, 47)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(35, 30)
        Me.botonQuitar.TabIndex = 0
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(14, 10)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(35, 30)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'frmFacturacionMascarillas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1085, 595)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmFacturacionMascarillas"
        Me.Text = "Billing of Masks"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgListaPrincipal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltors.ResumeLayout(False)
        Me.panelFiltors.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents panelFiltors As Panel
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents botonActualizar As Button
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents dgListaPrincipal As DataGridView
    Friend WithEvents colLAnio As DataGridViewTextBoxColumn
    Friend WithEvents colLNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLFecha As DataGridViewTextBoxColumn
    Friend WithEvents colLCliente As DataGridViewTextBoxColumn
    Friend WithEvents colLReferencia As DataGridViewTextBoxColumn
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents celdaRef2 As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaIdFabricante As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents Panel2 As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaTotalCantidad As TextBox
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents etiquetaCantidad As Label
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLineaIngreso As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colUMedida As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colPaquetes As DataGridViewTextBoxColumn
    Friend WithEvents colTipoPaquete As DataGridViewTextBoxColumn
    Friend WithEvents colreferencia As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents botonGastos As Button
    Friend WithEvents botonPagos As Button
End Class
