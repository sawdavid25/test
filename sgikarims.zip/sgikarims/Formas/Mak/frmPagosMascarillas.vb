﻿Public Class frmPagosMascarillas
#Region "Variable y Constantes"

    Dim intcatalogo As Integer
    Dim intano As Integer
    Dim intnumero As Integer
    Dim intlinea As Integer
#End Region

#Region "Propiedades"
    Public WriteOnly Property Catalogo As String
        Set(value As String)
            intcatalogo = value
        End Set
    End Property

    Public WriteOnly Property Ano As String
        Set(value As String)
            intano = value
        End Set
    End Property

    Public WriteOnly Property Numero As String
        Set(value As String)
            intnumero = value
        End Set
    End Property

#End Region

#Region "Procedimientos"
    Private Sub Sumar()
        Dim k As Integer = 0
        Dim suma As Double = 0

        For k = 0 To dgPagos.Rows.Count - 1
            If dgPagos.Rows(k).Cells("colMarca").Value = 2 Then
            Else
                suma = suma + dgPagos.Rows(k).Cells("colMonto").Value  ' total
            End If

        Next
        celdaSuma.Text = suma.ToString(FORMATO_MONEDA)

    End Sub

    Public Sub Guardar()
        Dim p As New Tablas.TPAGOS_MASK
        Try
            For i As Integer = 0 To dgPagos.Rows.Count - 1
                p.EMPRESA = Sesion.IdEmpresa
                p.CATALOGO = celdaCat.Text
                p.ANIO = celdaAno.Text
                p.NUMERO = celdaNum.Text
                p.Fecha_NET = CDate(dgPagos.Rows(i).Cells("colFecha").Value)
                p.DOCUMENTO = dgPagos.Rows(i).Cells("colDocumento").Value
                p.MONTO = dgPagos.Rows(i).Cells("colMonto").Value

                p.CONEXION = strConexion

                Select Case dgPagos.Rows(i).Cells("colMarca").Value
                    Case INT_CERO
                        dgPagos.Rows(i).Cells("colLinea").Value = i + 1
                        p.LINEA = dgPagos.Rows(i).Cells("colLinea").Value
                        If p.PINSERT = False Then
                            MsgBox(p.MERROR.ToString)
                        End If
                    Case INT_UNO
                        p.LINEA = dgPagos.Rows(i).Cells("colLinea").Value
                        If p.PUPDATE = False Then
                            MsgBox(p.MERROR.ToString)
                        End If
                    Case 2
                        p.LINEA = dgPagos.Rows(i).Cells("colLinea").Value
                        If p.PDELETE = False Then
                            MsgBox(p.MERROR.ToString)
                        End If
                        cFunciones.EscribirRegistro("Pagos", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, celdaCat.Text, celdaAno.Text, celdaNum.Text, "Eliminación de Pago No. " & dgPagos.Rows(i).Cells("colDocumento").Value)
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarDatos()
        Dim strSql As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSql = " SELECT p.Linea,p.Fecha,p.Documento,p.Monto
                            FROM Pagos_Mask p
                            WHERE p.Empresa = {empresa} AND p.Catalogo = {catalogo} AND p.Anio = {anio} AND p.Numero = {numero}
                            ORDER BY p.Linea ASC"
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{catalogo}", intcatalogo)
            strSql = strSql.Replace("{anio}", intano)
            strSql = strSql.Replace("{numero}", intnumero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Linea") & "|" ' Linea
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"   ' Fecha
                    strFila &= REA.GetString("Documento") & "|"    ' Numero de Documento
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"   ' Monto

                    strFila &= "1"

                    cFunciones.AgregarFila(dgPagos, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Eventos"
    Private Sub frmPagosMascarillas_Load(sender As Object, e As EventArgs) Handles Me.Load
        celdaCat.Text = intcatalogo
        celdaAno.Text = intano
        celdaNum.Text = intnumero
        CargarDatos()
        Sumar()
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Guardar()
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        dgPagos.Rows.Add()

        dgPagos.Rows(dgPagos.Rows.Count - 1).Selected = True
        dgPagos.SelectedCells(0).Value = 0
        dgPagos.SelectedCells(1).Value = cFunciones.HoyMySQL
        dgPagos.SelectedCells(2).Value = ""
        dgPagos.SelectedCells(3).Value = INT_CERO.ToString(FORMATO_MONEDA)
        dgPagos.SelectedCells(4).Value = INT_CERO
    End Sub

    Private Sub dgPagos_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgPagos.CellEndEdit
        Select Case dgPagos.CurrentCell.ColumnIndex
            Case 3
                Sumar()
        End Select

    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        dgPagos.CurrentRow.Cells("colMarca").Value = 2
        dgPagos.CurrentRow.Visible = False
        Sumar()
    End Sub

    Private Sub dgPagos_DoubleClick(sender As Object, e As EventArgs) Handles dgPagos.DoubleClick
        Dim frm As New frmDateTimePicker
        Select Case dgPagos.CurrentCell.ColumnIndex
            Case 1
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    dgPagos.CurrentRow.Cells("colFecha").Value = frm.LLave
                End If
        End Select

    End Sub
#End Region
End Class