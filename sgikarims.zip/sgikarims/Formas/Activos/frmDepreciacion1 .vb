﻿Public Class frmDepreciacion1
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
#End Region

#Region "Prodiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Funciones y Procedimientos"

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLActivos(ByVal fecha As Date) As String
        Dim strsql As String = STR_VACIO
        Try
            ' strsql = "SELECT COALESCE(CONCAT(p.per_nombre1,' ',p.per_apellido1),'(sin asignar)') Encargado, a.Codigo, a.Descripcion, ROUND(a.Precio * a.Tasa,2) Precio, d.dep_monto Depreciacion, CAST(COALESCE(SUM(d.dep_monto),'') AS CHAR) Acumulada, CAST(COALESCE(SUM(d.dep_dias),'') AS CHAR) Dias, t.Cta_Depreciacion CtaDep, t.Cta_Acumulada CtaAcu
            strsql = "SELECT l3.*,(l3.MontoDepreciar - l3.Anual) LibrosActual
		                    FROM (
			                    SELECT l2.*,l2.Monto + COALESCE((
				                    SELECT ROUND(SUM(de.dep_monto),2)
					                    FROM Depreciaciones de
						                    WHERE de.dep_empresa = {empresa} AND de.dep_codigo = l2.Codigo AND de.dep_fecha  <=  '{fecha}' ),0) Anual
							                    FROM (  
	                    SELECT l1.FechaActivo,DATEDIFF(l1.Fecha,l1.Fecha2) Fecha2,l1.TipoA,l1.Factura,CAST(l1.Fecha AS DATE ) Fecha,l1.pro_proveedor,l1.Codigo,l1.Descripcion,l1.Precio,l1.Moneda,l1.Porcentaje,l1.Tasa,l1.Tipo,l1.VidaU,l1.CostoActivo,l1.ValorRescate,
                     (l1.CostoActivo - l1.ValorRescate) MontoDepreciar, ROUND(IFNULL(IF(l1.Tipo='Years',((l1.CostoActivo - l1.ValorRescate) / (l1.VidaU * 12)), IF(l1.Tipo ='Hours',((l1.CostoActivo - l1.ValorRescate) / l1.VidaU * (l1.CantidadH)), IF(l1.Tipo ='Units',((l1.CostoActivo - l1.ValorRescate) / l1.VidaU * (l1.CantidadH)),0))),0),2) Monto
	                      FROM (
		                    SELECT a.Fecha FechaActivo,a.Fecha Fecha2,t.Descripcion TipoA,a.Factura,'{fecha}' fecha, 
		                    IFNULL(po.pro_proveedor,'')pro_proveedor, a.Codigo, a.Descripcion,IF(a.Costo_IVA=0, a.precio, a.Costo_IVA) Precio, 
			                    IF(a.Id_Moneda = {moneda} , 'LOCAL',c.cat_clave) Moneda, a.Porcentaje_IVA Porcentaje, a.Tasa,m.cat_clave Tipo,
				                    IF(m.cat_clave= 'Years',a.Pro_Anios,IF(m.cat_clave='Units',a.Pro_Unidades,IF(m.cat_clave = 'Hours',a.Pro_Horas,0))) VidaU,
					                    ROUND(IF(a.Costo_IVA=0, a.precio, a.Costo_IVA) / (1 + (a.Porcentaje_IVA / 100)) * a.Tasa,2) CostoActivo,a.Residuo ValorRescate ,
				                    IFNULL((
					                    SELECT SUM(hu.CantidadHU)
						                    FROM ActivosHU hu
							                    WHERE hu.Empresa = {empresa} AND hu.Mes = {mes} AND hu.idActivo = a.Codigo AND hu.Estado = 1),0) CantidadH 
	                    FROM Activos a
	                    LEFT JOIN Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo
	                    LEFT JOIN Personal p ON p.per_sisemp = a.Empresa AND p.per_codigo = a.Id_Usuario
	                    LEFT JOIN Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo
	                    LEFT JOIN Proveedores po ON po.pro_sisemp = a.Empresa AND po.pro_codigo = a.Id_Proveedor
	                    LEFT JOIN Catalogos c ON c.cat_num = a.Id_Moneda AND c.cat_clase = 'Monedas'
	                    LEFT JOIN Catalogos m ON m.cat_num = a.Id_Depreciacion AND m.cat_clase = 'Depreciacion'
	                    WHERE a.Empresa = {empresa} AND a.Fecha <= '{fecha}'
	                     GROUP BY a.Codigo
	                    ORDER BY a.Codigo  ) l1 )l2 )l3 WHERE l3.Fecha2 > 30"

            strsql = strsql.Replace("{empresa}", Sesion.IdEmpresa)
            strsql = strsql.Replace("{fecha}", fecha.ToString(FORMATO_MYSQL))
            strsql = strsql.Replace("{anio}", fecha.Year)
            strsql = strsql.Replace("{mes}", fecha.Month)
            strsql = strsql.Replace("{moneda}", cfun.MonedaDefault(0))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strsql
    End Function
    Private Sub Previsualizar()
        Dim strSQL As String = STR_VACIO
        Dim Fecha As Date
        Dim Mes As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim dblTotal As Double = INT_CERO
        Try
            Fecha = cFunciones.UltimodiaDelMes(dtpFecha.Value)
            Mes = Fecha.Month
            strSQL = SQLActivos(Fecha)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgDetalle.Rows.Clear()
            dblTotal = INT_CERO
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("TipoA") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("pro_proveedor") & "|"
                    If REA.GetDouble("Monto") = INT_CERO Or ((REA.GetDouble("MontoDepreciar")) - (REA.GetDouble("Anual"))) < 1 Then
                        strFila &= "NO" & "|"
                    Else
                        strFila &= "YES" & "|"
                        dblTotal = dblTotal + REA.GetDouble("Monto")
                    End If
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetInt32("Porcentaje") & "|"
                    strFila &= REA.GetDouble("Tasa") & "|"
                    strFila &= REA.GetString("Tipo") & "|"
                    strFila &= REA.GetInt32("VidaU") & "|"
                    strFila &= REA.GetDouble("CostoActivo").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("ValorRescate").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("MontoDepreciar").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Anual").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("LibrosActual").ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetDateTime("FechaActivo") & "|"
                    strFila &= INT_CERO
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
            dtpFecha.Enabled = True
            celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            dgDetalle.Columns("colValor").HeaderText = cFunciones.MesIngles(dtpFecha.Value.Month) & " - " & dtpFecha.Value.Year
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(d.dep_linea),0) + 1  Codigo  "
        strSQL &= " FROM Depreciaciones d  "
        strSQL &= " WHERE d.dep_empresa = {empresa} And d.dep_codigo = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function Ejecutar() As Boolean
        Dim LogResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim cDepreciacion As New Tablas.TDEPRECIACIONES
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                cDepreciacion.DEP_EMPRESA = Sesion.IdEmpresa
                cDepreciacion.DEP_CODIGO = dgDetalle.Rows(i).Cells("colCodigo").Value
                cDepreciacion.dep_fecha_NET = dgDetalle.Rows(i).Cells("colFecha").Value
                cDepreciacion.DEP_DIAS = INT_CERO
                cDepreciacion.DEP_MONTO = dgDetalle.Rows(i).Cells("colValor").Value
                cDepreciacion.DEP_ESTADO = INT_CERO
                Select Case dgDetalle.Rows(i).Cells("colExtra").Value
                    Case 0
                        If dgDetalle.Rows(i).Cells("colDepreciarC").Value = "YES" Then 'Guardar nueva Linea
                            cDepreciacion.DEP_LINEA = NuevaLinea(dgDetalle.Rows(i).Cells("colCodigo").Value)
                            cDepreciacion.CONEXION = strConexion
                            If cDepreciacion.PINSERT = False Then
                                LogResultado = False
                                MsgBox(cDepreciacion.MERROR.ToString)
                            Else
                                LogResultado = True
                            End If
                        End If
                    Case 1 'Actualizar Linea
                        If dgDetalle.Rows(i).Cells("colDepreciarC").Value = "YES" Then
                            cDepreciacion.DEP_LINEA = dgDetalle.Rows(i).Cells("colLinea").Value
                            cDepreciacion.CONEXION = strConexion
                            If cDepreciacion.PUPDATE = False Then
                                LogResultado = False
                                MsgBox(cDepreciacion.MERROR.ToString)
                            Else
                                LogResultado = True
                            End If
                        End If
                        'Case 2 ' Borrar Linea
                        '    cDepreciacion.DEP_LINEA = dgDepreciacion.Rows(i).Cells("colLinea").Value
                        '    cDepreciacion.CONEXION = strConexion
                        '    If cDepreciacion.PDELETE = False Then
                        '        LogResultado = False
                        '        MsgBox(cDepreciacion.MERROR.ToString)
                        '    End If
                End Select
            Next
            'strSQL = " UPDATE Depreciaciones SET dep_estado=1
            '           WHERE dep_empresa = {empresa}  AND (dep_fecha <= '{fecha}') AND (dep_estado = 0) "

            'strSQL = strSQL.Replace("{fecha}", cFunciones.UltimodiaDelMes(dtpFecha.Value).ToString(FORMATO_MYSQL))
            'strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            'MyCnn.CONECTAR = strConexion
            'COM = New MySqlCommand(strSQL, CON)
            'COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Depreciation")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                Reset()
            End If
            dgDetalle.DataSource = Nothing
        End If
    End Sub
    Private Sub CalcularFecha()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim strNombre As String = STR_VACIO
        Try
            strSQL = "SELECT CAST(IFNULL(MAX(a.dep_fecha),
	                        (SELECT DATE_SUB(IFNULL(MIN(b.dep_fecha), CURDATE()), INTERVAL 1 MONTH)
	                        FROM Depreciaciones b
	                        WHERE b.dep_empresa={empresa} AND b.dep_estado=0)) AS DATE) Fecha
                        FROM Depreciaciones a
                        WHERE a.dep_empresa={empresa}  AND a.dep_estado=1"

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dtpFecha.Value = COM.ExecuteScalar
            dtpFecha.Value = dtpFecha.Value.AddMonths(INT_UNO)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT DISTINCT  l1.Anio,l1.Mes,Case l1.Mes         
                            when 1 then CONCAT('DEPRECIATION OF JANUARY ',l1.Anio)  
                                When 2 then CONCAT('DEPRECIATION OF FEBRUARY ',l1.Anio) 
                                    When 3 then CONCAT('DEPRECIATION OF MARCH ',l1.Anio) 
                                        WHEN 4 THEN CONCAT('DEPRECIATION OF APRIL ',l1.Anio) 
                                            WHEN 5 then CONCAT('DEPRECIATION OF MAY ',l1.Anio)  
                                        WHEN 6 then CONCAT('DEPRECIATION OF JUNE ',l1.Anio)  
                                    WHEN 7 then CONCAT('DEPRECIATION OF JULY ',l1.Anio)  
                                WHEN 8 then CONCAT('DEPRECIATION OF AUGUST ',l1.Anio)  
                            WHen 9 then CONCAT('DEPRECIATION OF SEPTEMBER ',l1.Anio)  
                        when 10 then CONCAT('DEPRECIATION OF OCTOBER ',l1.Anio)  
                    when 11 then CONCAT('DEPRECIATION OF NOVEMBER ',l1.Anio)  
                WHEN 12 Then CONCAT('DEPRECIATION OF DECEMBER ',l1.Anio)  
                    END FechaDepreciacion, l1.Fecha  
                        FROM( 
                            SELECT EXTRACT(MONTH FROM d.dep_fecha) Mes ,EXTRACT(YEAR FROM d.dep_fecha) Anio, d.dep_fecha Fecha 
                                FROM  Depreciaciones d 
                                    WHERE d.dep_empresa = {empresa} AND d.dep_estado = 1  "
            If checkFecha.Checked = True Then

                strSql &= " AND (d.dep_fecha BETWEEN '{fechainicio}' AND '{fechafin}') "

                strSql = Replace(strSql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
                strSql = Replace(strSql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

            End If
            strSql &= "                            ) l1  ORDER BY l1.Fecha DESC  "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read

                    strLinea = REA.GetInt32("Anio") & "|" 'Año
                    strLinea &= REA.GetDateTime("Fecha") & "|" 'Fecha 
                    strLinea &= REA.GetString("FechaDepreciacion")  'Fecha Depreciacion
                    ' If REA.GetInt32("Estado") = INT_UNO Then
                    cFunciones.AgregarFila(dgLista, strLinea)
                    'Else
                    ' cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    '  End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLCargarDepreciacion(ByVal fecha As Date) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT l3.*,(l3.MontoDepreciar - l3.Anual) LibrosActual 
                        FROM ( 
                            SELECT l2.*,ROUND(l2.Monto + COALESCE(( 
                                SELECT ROUND(SUM(de.dep_monto),2) 
                                    FROM Depreciaciones de 
                                        WHERE de.dep_empresa = {empresa} AND de.dep_codigo = l2.Codigo AND de.dep_fecha < '{fecha}'),0),2) Anual 
                                            FROM ( 
                                                SELECT l1.FechaActivo,l1.TipoA,l1.Factura,CAST(l1.Fecha AS DATE ) Fecha ,l1.pro_proveedor,l1.Codigo,l1.Descripcion,l1.Precio,l1.Moneda,l1.Porcentaje,l1.Tasa,l1.Tipo,l1.VidaU,l1.CostoActivo,l1.ValorRescate, 
                                                    (l1.CostoActivo - l1.ValorRescate) MontoDepreciar,l1.Monto,l1.Linea 
                                                        FROM ( 
                                                            SELECT a.Fecha FechaActivo,t.Descripcion TipoA,a.Factura,'{fecha}' fecha, IFNULL(po.pro_proveedor,'')pro_proveedor, a.Codigo, a.Descripcion,IF(a.Costo_IVA = 0,a.Precio,a.Costo_IVA) Precio,  
                                                         IF(a.Id_Moneda = {moneda} , 'LOCAL',c.cat_clave) Moneda, a.Porcentaje_IVA Porcentaje, a.Tasa,IFNULL(m.cat_clave,'') Tipo, 
                                                    IF(m.cat_clave= 'Years',a.Pro_Anios,IF(m.cat_clave='Units',a.Pro_Unidades,IF(m.cat_clave = 'Hours',a.Pro_Horas,a.Pro_Anios))) VidaU, 
                                                ROUND(IF(a.Costo_IVA = 0,a.Precio,a.Costo_IVA) / (1 + (a.Porcentaje_IVA / 100)) * a.Tasa,2) CostoActivo,a.Residuo ValorRescate,d.dep_monto Monto,d.dep_linea Linea, 
                                            IFNULL(( 
                                        SELECT SUM(hu.CantidadHU) 
                                    FROM ActivosHU hu 
                                 WHERE hu.Empresa = {empresa} AND hu.Mes = {mes} AND hu.idActivo = a.Codigo AND hu.Estado = 1),0) CantidadH 
                            FROM Depreciaciones d  
                        LEFT JOIN Activos a ON a.Empresa = d.dep_empresa AND a.Codigo = d.dep_codigo  
                    LEFT JOIN Personal p ON p.per_sisemp = a.Empresa AND p.per_codigo = a.Id_Usuario 
                        LEFT JOIN Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo 
                            LEFT JOIN Proveedores po ON po.pro_sisemp = a.Empresa AND po.pro_codigo = a.Id_Proveedor 
                                LEFT JOIN Catalogos c ON c.cat_num = a.Id_Moneda AND c.cat_clase = 'Monedas' 
                                    LEFT JOIN Catalogos m ON m.cat_num = a.Id_Depreciacion AND m.cat_clase = 'Depreciacion' 
                                        WHERE d.dep_empresa = {empresa} AND d.dep_fecha = '{fecha}' AND d.dep_estado = 1 
                                            GROUP BY a.Codigo 
                                                    ORDER BY a.Codigo 
                                                        ) l1 )l2 ) l3 "
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{fecha}", fecha.ToString(FORMATO_MYSQL))
        strSQL = strSQL.Replace("{anio}", fecha.Year)
        strSQL = strSQL.Replace("{mes}", fecha.Month)
        strSQL = strSQL.Replace("{moneda}", cfun.MonedaDefault(0))
        Return strSQL
    End Function
    Public Sub CargarDepreacion(ByVal Fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim Mes As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim dblTotal As Double = INT_CERO
        Try
            strSQL = SQLCargarDepreciacion(Fecha)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgDetalle.Rows.Clear()
            dblTotal = INT_CERO
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("TipoA") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("pro_proveedor") & "|"
                    If REA.GetDouble("Monto") = INT_CERO Then
                        strFila &= "NO" & "|"
                    Else
                        strFila &= "YES" & "|"
                        dblTotal = dblTotal + REA.GetDouble("Monto")
                    End If
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetInt32("Porcentaje") & "|"
                    strFila &= REA.GetDouble("Tasa") & "|"
                    strFila &= REA.GetString("Tipo") & "|"
                    strFila &= REA.GetInt32("VidaU") & "|"
                    strFila &= REA.GetDouble("CostoActivo").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("ValorRescate").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("MontoDepreciar").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Anual").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("LibrosActual").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDateTime("FechaActivo") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
            dtpFecha.Enabled = False
            dtpFecha.Value = Fecha
            celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            dgDetalle.Columns("colValor").HeaderText = cFunciones.MesIngles(dtpFecha.Value.Month) & " - " & dtpFecha.Value.Year
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidacionDepreciacion(ByVal fecha As Date) As Boolean
        Dim logValidar As Boolean = True
        Dim strsQL As String
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim intValidar As Integer
        strsQL = " SELECT COUNT(*) 
                    FROM Depreciaciones d 
                        WHERE d.dep_empresa = {empresa} AND d.dep_fecha = '{fecha}' AND (d.dep_estado = 1 OR d.dep_estado = 0)"
        strsQL = Replace(strsQL, "{empresa}", Sesion.IdEmpresa)
        strsQL = Replace(strsQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strsQL, conec)
        intValidar = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        If intValidar > INT_CERO Then
            logValidar = False
        Else
            logValidar = True
        End If
        Return logValidar
    End Function
    Public Sub BorrarDepreciacion(ByVal fecha As Date)
        Dim strSQL As String = STR_VACIO

        strSQL = "dep_empresa = {empresa} AND dep_fecha = '{fecha}' "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))
        Dim depre As New Tablas.TDEPRECIACIONES
        depre.CONEXION = strConexion
        depre.PDELETE(strSQL)
    End Sub
    Private Function PedirAutorizacionDepreciacion(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AutorizarDepreciacion"
        Dim frm As frmAutorización
        PedirAutorizacionDepreciacion = False

        frm = New frmAutorización
        frm.Iniciar(12, STR_MARGEN, 0, "Autorizar Depreciacion")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionDepreciacion = True
                ' cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acConfirm, 0, 952, celdaAnio.Text, celdaNumero.Text, "Autorizó Saldo PO " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
    Private Function ConteoLinea() As Integer
        Dim intLinea As Integer = INT_CERO
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colDepreciarC").Value = "YES" Then
                intLinea = intLinea + 1
            End If
        Next
        Return intLinea
    End Function
    Public Sub Reset()
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
    End Sub
    Public Sub ActualizarEstado()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        strSQL = " UPDATE Depreciaciones SET dep_estado=1
                       WHERE dep_empresa = {empresa}  AND (dep_fecha <= '{fecha}') AND (dep_estado = 0) "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE Depreciaciones SET dep_estado=1
                       WHERE dep_empresa = {empresa}  AND (dep_fecha <= '{fecha}') AND (dep_estado = 0) "
        End If

        strSQL = strSQL.Replace("{fecha}", cFunciones.UltimodiaDelMes(dtpFecha.Value).ToString(FORMATO_MYSQL))
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
    End Sub
    Public Sub CalcularTotal()
        Dim dblTotal As Double = INT_CERO
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colDepreciarC").Value = "YES" Then
                dblTotal = dblTotal + dgDetalle.Rows(i).Cells("colValor").Value
            End If
        Next
        celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
    End Sub
#End Region
#Region "Eventos"
    Private Sub frmDepreciacion1_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            Accesos()
            CalcularFecha()
            MostrarLista()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub GuardarDatosDepreciacion()
        Dim conta As New clsContabilidad
        If MsgBox(ConteoLinea() & " Resgister until " & cFunciones.MesIngles(dtpFecha.Value.Month) & " " & dtpFecha.Value.Year & vbNewLine & " Do you want to continue? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            'marcar como depreciado
            If Ejecutar() = True Then
                ' CalcularFecha()
                'BotonPrevio.Focus()
                celdaTotal.Text = "0.00"
                dgDetalle.Rows.Clear()
                'hacer poliza
                If conta.GenerarPoliza(160, dtpFecha.Value.Year, dtpFecha.Value.Month, fecha:=cFunciones.UltimodiaDelMes(dtpFecha.Value)) = True Then
                    ActualizarEstado()
                End If
            End If
        End If
    End Sub
    Private Sub frmDepreciacion1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
            Reset()
            Previsualizar()
            Encabezado1.botonBorrar.Enabled = False
        Else
            MsgBox("Do you not have access to create a new Fixed asset per hour or units", vbInformation)
        End If
    End Sub
    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try

            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 4
                    'Dim opt As New frmOption
                    Try


                        If (dgDetalle.CurrentRow.Cells("colDepreciarC").Value = "NO") Then
                            dgDetalle.CurrentRow.Cells("colDepreciarC").Value = "YES"
                        Else
                            dgDetalle.CurrentRow.Cells("colDepreciarC").Value = "NO"
                        End If

                        CalcularTotal()

                        'opt.Titulo = "Option"
                        'opt.Mensaje = "Select an option"
                        'opt.Opciones = "YES" & "|" & "NO "

                        'If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        '    Select Case opt.Seleccion
                        '        Case 0
                        '            dgDetalle.CurrentRow.Cells("colDepreciarC").Value = "YES"

                        '        Case 1
                        '            dgDetalle.CurrentRow.Cells("colDepreciarC").Value = "NO"
                        '    End Select
                        '    CalcularTotal()
                        'Else
                        '    Exit Sub
                        'End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            Reset()
            CargarDepreacion(dgLista.SelectedCells(1).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExisteCierre As Integer

        If Me.Tag = "Nuevo" Then
            ' Previsualizar()
            If dgDetalle.Rows.Count > 0 Then

                'Verifica si hay cierre
                strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
                strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", Year(dtpFecha.Value.ToString(FORMATO_MYSQL)))
                strSQL = Replace(strSQL, "{fec}", dtpFecha.Value.ToString(FORMATO_MYSQL))
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                intExisteCierre = COM.ExecuteScalar
                If intExisteCierre = 0 Then
                    If ValidacionDepreciacion(dtpFecha.Value) = False Then
                        If MsgBox("you want to subscribe the depreciation data of the date I select " & "?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                            If PedirAutorizacionDepreciacion("Depreciacion") = True Then
                                BorrarDepreciacion(dtpFecha.Value)
                                GuardarDatosDepreciacion()
                                MostrarLista(True)
                            End If
                        End If
                    Else
                        GuardarDatosDepreciacion()
                        MostrarLista(True)
                    End If
                Else
                    'Si hay cierre solicita autorización para modificar
                    MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                    If cFunciones.AutorizarCambios = True Then
                        GuardarDatosDepreciacion()
                        MostrarLista(True)
                    End If
                End If
            End If
        ElseIf Me.Tag = "mod" Then
            If dgDetalle.Rows.Count > 0 Then
                'Verifica si hay cierre
                strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
                strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", Year(dtpFecha.Value.ToString(FORMATO_MYSQL)))
                strSQL = Replace(strSQL, "{fec}", dtpFecha.Value.ToString(FORMATO_MYSQL))
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                intExisteCierre = COM.ExecuteScalar
                If intExisteCierre = 0 Then
                    GuardarDatosDepreciacion()
                    MostrarLista(True)
                Else
                    'Si hay cierre solicita autorización para modificar
                    MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                    If cFunciones.AutorizarCambios = True Then
                        GuardarDatosDepreciacion()
                        MostrarLista(True)
                    End If
                End If
            End If
        Else
            MsgBox("You don't have permission to execute this process")
        End If
    End Sub
    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If Me.Tag = "Nuevo" Then
            Reset()
            Previsualizar()
        End If
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                If PedirAutorizacionDepreciacion("Depreciacion") = True Then
                    BorrarDepreciacion(dtpFecha.Value)
                    cfun.BorrarEncabezadoPoliza(dtpFecha.Value.Month, dtpFecha.Value.Year, 160)
                    cfun.BorrarDetallePoliza(dtpFecha.Value.Month, dtpFecha.Value.Year, 160)
                End If
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
                'ElseIf e.KeyCode = Keys.F6 Then
                '   cfun.MostrarDependencias(36, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
                ' ElseIf e.KeyCode = Keys.F7 Then
                '    Dim rpt As New clsReportes
                '    rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 36)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click
        Dim frm As New frmOption
        Dim NP As New clsPolizaContable
        Dim NPC As New frmNPolizasContables
        NP.intTipo = 160
        NP.intCiclo = dtpFecha.Value.Year
        NP.intNumero = dtpFecha.Value.Month
        NP.intModo = 23
        NP.MostrarPolizaContable()
    End Sub

    Private Sub dgDetalle_KeyDown(sender As Object, e As KeyEventArgs) Handles dgDetalle.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgDetalle)
                e.Handled = True
                e.SuppressKeyPress = True
                'ElseIf e.KeyCode = Keys.F6 Then
                '   cfun.MostrarDependencias(36, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
                ' ElseIf e.KeyCode = Keys.F7 Then
                '    Dim rpt As New clsReportes
                '    rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 36)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotal()
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim cRep As New clsReportes
        Dim fecha As Date
        Dim tipo As Integer = INT_CERO
        Try
            If Me.Tag = "Nuevo" Then
                tipo = 0
                fecha = cFunciones.UltimodiaDelMes(dtpFecha.Value)

                cRep.ImpreDepreciaciones(fecha, tipo)
            Else
                tipo = 1
                fecha = cFunciones.UltimodiaDelMes(dtpFecha.Value)

                cRep.ImpreDepreciaciones(fecha, tipo)
            End If
            'fecha = cFunciones.UltimodiaDelMes(dtpFecha.Value)
            'cRep.ReporteDepreciacion(fecha)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
End Class