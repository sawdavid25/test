﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDepreciacion1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDepreciacion1))
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colTipoActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDepreciarC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMontoAdquisicion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPorcentaje = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVidaUtil = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCostoActivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colValorR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMontoD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colValor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAcumuladoA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLibrosA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(208, 12)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(59, 43)
        Me.botonImprimir.TabIndex = 50
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(268, 17)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 15)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaTotal.Location = New System.Drawing.Point(242, 41)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(119, 23)
        Me.celdaTotal.TabIndex = 3
        Me.celdaTotal.Text = "0.00"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dtpFecha
        '
        Me.dtpFecha.CustomFormat = "MMMM yyyy"
        Me.dtpFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFecha.Location = New System.Drawing.Point(17, 17)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(194, 26)
        Me.dtpFecha.TabIndex = 0
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 102)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(600, 73)
        Me.panelListaPrincipal.TabIndex = 54
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colFecha2, Me.colFechaD})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 44)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(600, 29)
        Me.dgLista.TabIndex = 3
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "YEAR"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 61
        '
        'colFecha2
        '
        Me.colFecha2.HeaderText = "Date"
        Me.colFecha2.Name = "colFecha2"
        Me.colFecha2.ReadOnly = True
        Me.colFecha2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFecha2.Width = 36
        '
        'colFechaD
        '
        Me.colFechaD.HeaderText = "Depreciation Date"
        Me.colFechaD.Name = "colFechaD"
        Me.colFechaD.ReadOnly = True
        Me.colFechaD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFechaD.Width = 89
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(600, 44)
        Me.panelFecha.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(436, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(326, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(182, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(24, 198)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(516, 156)
        Me.panelDocumento.TabIndex = 55
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 88)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(516, 68)
        Me.panelDetalle.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colTipoActivo, Me.colFactura, Me.colFecha, Me.colProveedor, Me.colDepreciarC, Me.colCodigo, Me.colDescripcion, Me.colMontoAdquisicion, Me.colMoneda, Me.colPorcentaje, Me.colTasa, Me.colTipoUnidad, Me.colVidaUtil, Me.colCostoActivo, Me.colValorR, Me.colMontoD, Me.colValor, Me.colAcumuladoA, Me.colLibrosA, Me.colLinea, Me.colFecha3, Me.colExtra})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(516, 68)
        Me.dgDetalle.TabIndex = 2
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.botonPolizaC)
        Me.panelEncabezado.Controls.Add(Me.celdaTotal)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.Label1)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(516, 88)
        Me.panelEncabezado.TabIndex = 0
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(412, 42)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(29, 23)
        Me.botonPolizaC.TabIndex = 32
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(600, 30)
        Me.BarraTitulo1.TabIndex = 53
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(600, 72)
        Me.Encabezado1.TabIndex = 1
        '
        'colTipoActivo
        '
        Me.colTipoActivo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTipoActivo.HeaderText = "Fixet"
        Me.colTipoActivo.Name = "colTipoActivo"
        Me.colTipoActivo.ReadOnly = True
        Me.colTipoActivo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTipoActivo.Width = 35
        '
        'colFactura
        '
        Me.colFactura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFactura.HeaderText = "Invoice"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        Me.colFactura.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFactura.Width = 48
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFecha.Width = 44
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Provider"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        Me.colProveedor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colProveedor.Width = 67
        '
        'colDepreciarC
        '
        Me.colDepreciarC.HeaderText = "Depreciable this Closing"
        Me.colDepreciarC.Name = "colDepreciarC"
        Me.colDepreciarC.ReadOnly = True
        Me.colDepreciarC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDepreciarC.Width = 108
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCodigo.Width = 47
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDescripcion.Width = 85
        '
        'colMontoAdquisicion
        '
        Me.colMontoAdquisicion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMontoAdquisicion.HeaderText = "Cost"
        Me.colMontoAdquisicion.Name = "colMontoAdquisicion"
        Me.colMontoAdquisicion.ReadOnly = True
        Me.colMontoAdquisicion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMontoAdquisicion.Width = 34
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Coin"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMoneda.Width = 42
        '
        'colPorcentaje
        '
        Me.colPorcentaje.HeaderText = "Percentaje"
        Me.colPorcentaje.Name = "colPorcentaje"
        Me.colPorcentaje.ReadOnly = True
        Me.colPorcentaje.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPorcentaje.Width = 82
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTasa.Width = 44
        '
        'colTipoUnidad
        '
        Me.colTipoUnidad.HeaderText = "Type"
        Me.colTipoUnidad.Name = "colTipoUnidad"
        Me.colTipoUnidad.ReadOnly = True
        Me.colTipoUnidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTipoUnidad.Width = 46
        '
        'colVidaUtil
        '
        Me.colVidaUtil.HeaderText = "Useful Life"
        Me.colVidaUtil.Name = "colVidaUtil"
        Me.colVidaUtil.ReadOnly = True
        Me.colVidaUtil.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colVidaUtil.Width = 81
        '
        'colCostoActivo
        '
        Me.colCostoActivo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCostoActivo.HeaderText = "Asset Cost"
        Me.colCostoActivo.Name = "colCostoActivo"
        Me.colCostoActivo.ReadOnly = True
        Me.colCostoActivo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCostoActivo.Width = 57
        '
        'colValorR
        '
        Me.colValorR.HeaderText = "Rescue Value"
        Me.colValorR.Name = "colValorR"
        Me.colValorR.ReadOnly = True
        Me.colValorR.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colValorR.Width = 102
        '
        'colMontoD
        '
        Me.colMontoD.HeaderText = "Amount to Depreciate"
        Me.colMontoD.Name = "colMontoD"
        Me.colMontoD.ReadOnly = True
        Me.colMontoD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMontoD.Width = 136
        '
        'colValor
        '
        Me.colValor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colValor.HeaderText = " "
        Me.colValor.Name = "colValor"
        Me.colValor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colValor.Width = 16
        '
        'colAcumuladoA
        '
        Me.colAcumuladoA.HeaderText = "Accumulated Per Year"
        Me.colAcumuladoA.Name = "colAcumuladoA"
        Me.colAcumuladoA.ReadOnly = True
        Me.colAcumuladoA.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colAcumuladoA.Width = 113
        '
        'colLibrosA
        '
        Me.colLibrosA.HeaderText = "Current Books"
        Me.colLibrosA.Name = "colLibrosA"
        Me.colLibrosA.ReadOnly = True
        Me.colLibrosA.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colLibrosA.Width = 94
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        Me.colLinea.Width = 64
        '
        'colFecha3
        '
        Me.colFecha3.HeaderText = "Asset Date"
        Me.colFecha3.Name = "colFecha3"
        Me.colFecha3.ReadOnly = True
        Me.colFecha3.Width = 98
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Status"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        Me.colExtra.Width = 77
        '
        'frmDepreciacion1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 366)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmDepreciacion1"
        Me.Text = "Depretiation"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents botonImprimir As Button
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colFecha2 As DataGridViewTextBoxColumn
    Friend WithEvents colFechaD As DataGridViewTextBoxColumn
    Friend WithEvents botonPolizaC As Button
    Friend WithEvents colTipoActivo As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As DataGridViewTextBoxColumn
    Friend WithEvents colDepreciarC As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colMontoAdquisicion As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colPorcentaje As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
    Friend WithEvents colTipoUnidad As DataGridViewTextBoxColumn
    Friend WithEvents colVidaUtil As DataGridViewTextBoxColumn
    Friend WithEvents colCostoActivo As DataGridViewTextBoxColumn
    Friend WithEvents colValorR As DataGridViewTextBoxColumn
    Friend WithEvents colMontoD As DataGridViewTextBoxColumn
    Friend WithEvents colValor As DataGridViewTextBoxColumn
    Friend WithEvents colAcumuladoA As DataGridViewTextBoxColumn
    Friend WithEvents colLibrosA As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colFecha3 As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
End Class
