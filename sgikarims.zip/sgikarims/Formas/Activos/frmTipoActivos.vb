﻿Public Class frmTipoActivos
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

#End Region

#Region "Prodiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region


#Region "Procedimientos"

    Private Function QueryListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT t.Codigo ID , t.Descripcion Description  , if(t.Depreciar = 0, 'No', 'Yes') Depreciate , concat(t.Porcentaje,'%') Percentage, t.Cta_Activo Account
                          FROM Tipos_Activo t
                        WHERE t.Empresa = {emp}
                    ORDER BY t.Codigo DESC"

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)

        Return strSQL

    End Function

    Private Sub LimpiarCampos()
        celdaCodigo.Text = NO_FILA
        CeldaDescripcion.Text = STR_VACIO
        celdaCuenta.Text = STR_VACIO
        celdaCuentaID.Text = STR_VACIO
        CeldaPorcentaje.Text = 0
        celdaDepreciacion.Text = STR_VACIO
        celdaDepreciacionID.Text = STR_VACIO
        CeldaAcumulada.Text = STR_VACIO
        celdaAcumuladaID.Text = STR_VACIO
        checkActivo.Checked = True

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional ByVal logInsert As Boolean = True)
        Try

            'Muestra el listado principal
            If logMostrar = True Then
                panelListaPrincipal.Visible = True
                panelListaPrincipal.Dock = DockStyle.Fill
                panelDocumento.Visible = False
                panelDocumento.Dock = DockStyle.None
                BarraTitulo1.CambiarTitulo("Fixed Asset")
                BloquearBotones()

                ListaPrincipal()
            Else
                'Muestra el Detalle
                panelListaPrincipal.Visible = False
                panelListaPrincipal.Dock = DockStyle.None
                panelDocumento.Visible = True
                panelDocumento.Dock = DockStyle.Fill

                'Modificación
                If logInsert = False Then
                    BarraTitulo1.CambiarTitulo("Modifiy Fixed Asset")
                    Me.Tag = "Mod"
                    BloquearBotones(False)
                Else
                    'Nuevo
                    BarraTitulo1.CambiarTitulo("New Fixed Asset")
                    Me.Tag = "Nuevo"
                    BloquearBotones(False)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If

    End Sub

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarCampos()
        Dim comprobar As Boolean = True
        Try
            If celdaDepreciacion.Text = vbNullString Then
                Return comprobar = False
                Exit Function
            End If
            If celdaCuenta.Text = vbNullString Then
                Return comprobar = False
                Exit Function
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return comprobar
    End Function

    Private Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = QueryListaPrincipal()
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("ID") & "|"
                    strFila &= REA.GetString("Description") & "|"
                    strFila &= REA.GetString("Depreciate") & "|"
                    strFila &= REA.GetString("Percentage") & "|"
                    strFila &= REA.GetString("Account")

                    cFunciones.AgregarFila(dgLista, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub ActivarDepreciacion()
        If checkActivo.Checked = True Then
            CeldaPorcentaje.ReadOnly = False
            botonCuenta.Enabled = True
            botonAcumulado.Enabled = True
        Else
            celdaCuentaID.Text = STR_VACIO
            celdaCuenta.Text = STR_VACIO
            CeldaPorcentaje.Text = "0.00"
            celdaDepreciacion.Text = STR_VACIO
            celdaDepreciacionID.Text = STR_VACIO
            CeldaAcumulada.Text = STR_VACIO
            celdaAcumuladaID.Text = STR_VACIO

            CeldaPorcentaje.ReadOnly = True
            botonCuenta.Enabled = False
            botonAcumulado.Enabled = False
        End If
    End Sub

    Private Sub CargarDatos(ByVal codigo As Integer)
        Dim strSSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSSQL = " SELECT t.*  , IFNULL(c.nombre,'Cuenta Invalida') cuenta, IFNULL(d.nombre,'Cuenta Invalida') depreciacion, IFNULL(a.nombre,'Cuenta Invalida') acumulada 
                        FROM Tipos_Activo t
	                        LEFT JOIN {conta}.cuentas c ON c.empresa = t.Empresa AND  c.id_cuenta = t.Cta_Activo
	                        LEFT JOIN {conta}.cuentas d ON d.empresa = t.Empresa AND d.id_cuenta = t.Cta_Depreciacion 
	                        LEFT JOIN {conta}.cuentas a ON a.empresa = t.Empresa AND a.id_cuenta = t.Cta_Acumulada  
                        WHERE t.Empresa = {empresa} AND t.Codigo = {codigo} "

            strSSQL = strSSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSSQL = strSSQL.Replace("{codigo}", codigo)
            strSSQL = strSSQL.Replace("{conta}", cFunciones.ContaEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaCodigo.Text = REA.GetInt32("Codigo")
                    CeldaDescripcion.Text = REA.GetString("Descripcion")
                    celdaCuentaID.Text = REA.GetString("Cta_Activo")
                    celdaCuenta.Text = REA.GetString("cuenta")
                    CeldaPorcentaje.Text = REA.GetDouble("Porcentaje")
                    celdaDepreciacionID.Text = REA.GetString("Cta_Depreciacion")
                    celdaDepreciacion.Text = REA.GetString("depreciacion")
                    celdaAcumuladaID.Text = REA.GetString("Cta_Acumulada")
                    CeldaAcumulada.Text = REA.GetString("acumulada")
                    If REA.GetInt32("Depreciar") = INT_CERO Then
                        checkActivo.Checked = False
                    Else
                        checkActivo.Checked = True
                    End If
                    ActivarDepreciacion()
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logResultado As Boolean = True

        If cFunciones.ValidarCampoTexto(CeldaDescripcion) = False Then
            Return False
            Exit Function
        End If

        If cFunciones.ValidarCampoTexto(celdaCuentaID) = False Then
            Return False
            Exit Function
        End If
        If checkActivo.Checked = True Then
            If cFunciones.ValidarCampoTexto(celdaDepreciacionID) = False Then
                Return False
                Exit Function
            End If

            If cFunciones.ValidarCampoTexto(celdaAcumuladaID) = False Then
                Return False
                Exit Function
            End If


            If cFunciones.ValidarCampoNumerico(CeldaPorcentaje) = False Then
                Return False
                Exit Function
            End If
        End If

        Return logResultado
    End Function

    Private Sub Guardar()
        Dim ta As New Tablas.TTIPOS_ACTIVO

        Try

            ta.EMPRESA = Sesion.IdEmpresa
            ta.DESCRIPCION = CeldaDescripcion.Text
            ta.PORCENTAJE = IIf(CeldaPorcentaje.Text = INT_CERO, INT_CERO, CDbl(CeldaPorcentaje.Text))
            ta.CTA_DEPRECIACION = celdaCuentaID.Text
            ta.CTA_DEPRECIACION = celdaDepreciacionID.Text
            ta.CTA_ACUMULADA = celdaAcumuladaID.Text
            ta.CTA_ACTIVO = celdaCuentaID.Text
            If checkActivo.Checked = True Then
                ta.DEPRECIAR = INT_UNO
            Else
                ta.DEPRECIAR = INT_CERO
            End If
            ta.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                ta.CODIGO = INT_CERO
                If logInsertar = True Then
                    If ta.PINSERT = False Then
                        MsgBox(ta.MERROR.ToString)
                    Else
                        MsgBox("Data saved successfully", vbInformation, "Notice")
                    End If
                Else
                    MsgBox("You don't have acces to Insert ")
                End If

            Else
                ta.CODIGO = celdaCodigo.Text
                If logEditar = True Then
                    If ta.PUPDATE = False Then
                        MsgBox(ta.MERROR.ToString)
                    Else
                        MsgBox("Data updated successfully", vbInformation, "Notice")
                    End If
                Else
                    MsgBox("You don't have acces to Update ")
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Borrar()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim ta As New Tablas.TTIPOS_ACTIVO
        Try
            strSQL = " SELECT count(*) FROM Activos a
                    WHERE a.Empresa = {empresa} AND a.Id_Tipo = {codigo} "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{codigo}", celdaCodigo.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            If COM.ExecuteScalar = 0 Then
                ta.CONEXION = strConexion
                If ta.PDELETE(" Empresa= " & Sesion.IdEmpresa & " and Codigo = " & celdaCodigo.Text) = False Then
                    MsgBox(ta.MERROR.ToString)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

    Private Sub frmTipoActivos_Load(sender As Object, e As EventArgs) Handles Me.Load
        MostrarLista()
        Accesos()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim frms As New frmSeleccionar
        Try
            If logInsertar = True Then
                Me.Tag = "Nuevo"
                LimpiarCampos()
                MostrarLista(False, True)
            Else
                MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intcodigo As Integer = NO_FILA
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            BarraTitulo1.CambiarTitulo("Modify")
            intcodigo = dgLista.SelectedCells(0).Value
            Reset()
            CargarDatos(intcodigo)
            MostrarLista(False, False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCuenta_Click(sender As Object, e As EventArgs) Handles botonCuenta.Click
        Dim frm As New frmSeleccionar
        Dim Condicion As String = STR_VACIO
        Dim condicion1 As String = STR_VACIO
        Try
            If Sesion.IdEmpresa = 18 Then
                Condicion = "c.empresa = {empresa} AND c.pid > '1201' AND c.pid < '1202' "
            Else
                Condicion = "c.empresa = {empresa}  "
            End If

            Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
            condicion1 = "{conta}"
            condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
            'Datospara mostrar en pantalla
            frm.Titulo = "Account"
            frm.FiltroText = "Enter the Name Account To Filter "

            'Datos de Base para Llenar Grid
            frm.Campos = " c.id_cuenta , c.nombre  , if ((SELECT COUNT(*) FROM " & cFunciones.ContaEmpresa & ".cuentas cc WHERE cc.empresa = c.empresa AND cc.pid =c.id_cuenta )= 0 ,'Detalle', 'Padre' )Tipo  "
            frm.Tabla = condicion1 & ".cuentas c "
            frm.Condicion = Condicion
            frm.Limite =
            frm.Ordenamiento = "id_cuenta"
            frm.Filtro = " nombre"

            'Mostrar formulario
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'Captura de datos seleccionados
                If frm.Dato2 = "Padre" Then
                    MsgBox("You can't use a father accounts")
                Else
                    celdaCuentaID.Text = frm.LLave
                    celdaCuenta.Text = frm.Dato
                    CeldaDescripcion.Text = frm.Dato
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonDepreciacion_Click(sender As Object, e As EventArgs) Handles botonDepreciacion.Click
        Dim frm As New frmSeleccionar
        Dim Condicion As String = STR_VACIO
        Dim condicion1 As String = STR_VACIO
        Try
            If Sesion.IdEmpresa = 18 Then
                Condicion = "c.empresa = {empresa} AND c.pid >= '510202' AND c.pid < '6102' AND LENGTH(id_cuenta)> 8  "
            Else
                Condicion = "c.empresa = {empresa} "
            End If

            Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
            condicion1 = "{conta}"
            condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
            'Datospara mostrar en pantalla
            frm.Titulo = "Account"
            frm.FiltroText = "Enter the Name Account To Filter "

            'Datos de Base para Llenar Grid
            frm.Campos = " c.id_cuenta , c.nombre  , if ((SELECT COUNT(*) FROM " & cFunciones.ContaEmpresa & ".cuentas cc WHERE cc.empresa = c.empresa AND cc.pid =c.id_cuenta )= 0 ,'Detalle', 'Padre' )Tipo  "
            frm.Tabla = condicion1 & ".cuentas c "
            frm.Condicion = Condicion
            frm.Limite =
            frm.Ordenamiento = "id_cuenta"
            frm.Filtro = " nombre"

            'Mostrar formulario
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'Captura de datos seleccionados
                If frm.Dato2 = "Padre" Then
                    MsgBox("You can't use a father accounts")
                Else
                    celdaDepreciacionID.Text = frm.LLave
                    celdaDepreciacion.Text = frm.Dato
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAcumulado_Click(sender As Object, e As EventArgs) Handles botonAcumulado.Click
        Dim frm As New frmSeleccionar
        Dim Condicion As String = STR_VACIO
        Dim condicion1 As String = STR_VACIO
        Try

            If Sesion.IdEmpresa = 18 Then
                Condicion = "c.empresa = {empresa} AND c.pid > '1202' AND c.pid < '1203' "
            Else
                Condicion = "c.empresa = {empresa}  "
            End If

            Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)
            condicion1 = "{conta}"
            condicion1 = Replace(condicion1, "{conta}", cFunciones.ContaEmpresa)
            'Datospara mostrar en pantalla
            frm.Titulo = "Account"
            frm.FiltroText = "Enter the Name Account To Filter "

            'Datos de Base para Llenar Grid
            frm.Campos = " c.id_cuenta , c.nombre  , if ((SELECT COUNT(*) FROM " & cFunciones.ContaEmpresa & ".cuentas cc WHERE cc.empresa = c.empresa AND cc.pid =c.id_cuenta )= 0 ,'Detalle', 'Padre' )Tipo  "
            frm.Tabla = condicion1 & ".cuentas c "
            frm.Condicion = Condicion
            frm.Limite =
            frm.Ordenamiento = "id_cuenta"
            frm.Filtro = " nombre"

            'Mostrar formulario
            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'Captura de datos seleccionados
                If frm.Dato2 = "Padre" Then
                    MsgBox("You can't use a father accounts")
                Else
                    celdaAcumuladaID.Text = frm.LLave
                    CeldaAcumulada.Text = frm.Dato
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarCampos() = True Then
            Guardar()
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If MsgBox(" Do you want to delete this register? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            If LogBorrar = True Then
                Borrar()
                MostrarLista()
            Else
                MsgBox("You don't have acces to delete ")
            End If
        End If
    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class