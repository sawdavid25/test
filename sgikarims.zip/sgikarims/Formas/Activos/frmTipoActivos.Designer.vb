﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTipoActivos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDepreciar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPorcentaje = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.botonCuenta = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CeldaAcumulada = New System.Windows.Forms.Label()
        Me.botonAcumulado = New System.Windows.Forms.Button()
        Me.celdaAcumuladaID = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaDepreciacion = New System.Windows.Forms.Label()
        Me.botonDepreciacion = New System.Windows.Forms.Button()
        Me.celdaDepreciacionID = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CeldaPorcentaje = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaCuenta = New System.Windows.Forms.Label()
        Me.celdaCuentaID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CeldaDescripcion = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.ID = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Location = New System.Drawing.Point(16, 124)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(4)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(73, 50)
        Me.panelListaPrincipal.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colDescripcion, Me.colDepreciar, Me.colPorcentaje, Me.colCuenta})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(73, 50)
        Me.dgLista.TabIndex = 0
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Width = 50
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'colDepreciar
        '
        Me.colDepreciar.HeaderText = "Depreciate"
        Me.colDepreciar.Name = "colDepreciar"
        Me.colDepreciar.ReadOnly = True
        Me.colDepreciar.Width = 106
        '
        'colPorcentaje
        '
        Me.colPorcentaje.HeaderText = "Percentage"
        Me.colPorcentaje.Name = "colPorcentaje"
        Me.colPorcentaje.ReadOnly = True
        Me.colPorcentaje.Width = 110
        '
        'colCuenta
        '
        Me.colCuenta.HeaderText = "Account"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.ReadOnly = True
        Me.colCuenta.Width = 88
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.botonCuenta)
        Me.panelDocumento.Controls.Add(Me.GroupBox1)
        Me.panelDocumento.Controls.Add(Me.celdaCuenta)
        Me.panelDocumento.Controls.Add(Me.celdaCuentaID)
        Me.panelDocumento.Controls.Add(Me.Label3)
        Me.panelDocumento.Controls.Add(Me.CeldaDescripcion)
        Me.panelDocumento.Controls.Add(Me.Label2)
        Me.panelDocumento.Controls.Add(Me.celdaCodigo)
        Me.panelDocumento.Controls.Add(Me.ID)
        Me.panelDocumento.Location = New System.Drawing.Point(97, 124)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(523, 327)
        Me.panelDocumento.TabIndex = 3
        '
        'botonCuenta
        '
        Me.botonCuenta.Location = New System.Drawing.Point(384, 39)
        Me.botonCuenta.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCuenta.Name = "botonCuenta"
        Me.botonCuenta.Size = New System.Drawing.Size(45, 27)
        Me.botonCuenta.TabIndex = 4
        Me.botonCuenta.Text = ".."
        Me.botonCuenta.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CeldaAcumulada)
        Me.GroupBox1.Controls.Add(Me.botonAcumulado)
        Me.GroupBox1.Controls.Add(Me.celdaAcumuladaID)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.celdaDepreciacion)
        Me.GroupBox1.Controls.Add(Me.botonDepreciacion)
        Me.GroupBox1.Controls.Add(Me.celdaDepreciacionID)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.CeldaPorcentaje)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.checkActivo)
        Me.GroupBox1.Location = New System.Drawing.Point(27, 142)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(459, 182)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Depreciation"
        '
        'CeldaAcumulada
        '
        Me.CeldaAcumulada.AutoSize = True
        Me.CeldaAcumulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaAcumulada.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.CeldaAcumulada.Location = New System.Drawing.Point(177, 160)
        Me.CeldaAcumulada.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.CeldaAcumulada.Name = "CeldaAcumulada"
        Me.CeldaAcumulada.Size = New System.Drawing.Size(57, 17)
        Me.CeldaAcumulada.TabIndex = 14
        Me.CeldaAcumulada.Text = "Label8"
        '
        'botonAcumulado
        '
        Me.botonAcumulado.Location = New System.Drawing.Point(396, 123)
        Me.botonAcumulado.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAcumulado.Name = "botonAcumulado"
        Me.botonAcumulado.Size = New System.Drawing.Size(45, 27)
        Me.botonAcumulado.TabIndex = 8
        Me.botonAcumulado.Text = ".."
        Me.botonAcumulado.UseVisualStyleBackColor = True
        '
        'celdaAcumuladaID
        '
        Me.celdaAcumuladaID.Location = New System.Drawing.Point(177, 126)
        Me.celdaAcumuladaID.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAcumuladaID.Name = "celdaAcumuladaID"
        Me.celdaAcumuladaID.ReadOnly = True
        Me.celdaAcumuladaID.Size = New System.Drawing.Size(211, 22)
        Me.celdaAcumuladaID.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(8, 126)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(129, 17)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Acumulate Account"
        '
        'celdaDepreciacion
        '
        Me.celdaDepreciacion.AutoSize = True
        Me.celdaDepreciacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDepreciacion.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaDepreciacion.Location = New System.Drawing.Point(173, 97)
        Me.celdaDepreciacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaDepreciacion.Name = "celdaDepreciacion"
        Me.celdaDepreciacion.Size = New System.Drawing.Size(57, 17)
        Me.celdaDepreciacion.TabIndex = 10
        Me.celdaDepreciacion.Text = "Label7"
        '
        'botonDepreciacion
        '
        Me.botonDepreciacion.Location = New System.Drawing.Point(396, 66)
        Me.botonDepreciacion.Margin = New System.Windows.Forms.Padding(4)
        Me.botonDepreciacion.Name = "botonDepreciacion"
        Me.botonDepreciacion.Size = New System.Drawing.Size(45, 27)
        Me.botonDepreciacion.TabIndex = 7
        Me.botonDepreciacion.Text = ".."
        Me.botonDepreciacion.UseVisualStyleBackColor = True
        '
        'celdaDepreciacionID
        '
        Me.celdaDepreciacionID.Location = New System.Drawing.Point(177, 69)
        Me.celdaDepreciacionID.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDepreciacionID.Name = "celdaDepreciacionID"
        Me.celdaDepreciacionID.ReadOnly = True
        Me.celdaDepreciacionID.Size = New System.Drawing.Size(211, 22)
        Me.celdaDepreciacionID.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 73)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(143, 17)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Depreciation Account"
        '
        'CeldaPorcentaje
        '
        Me.CeldaPorcentaje.Location = New System.Drawing.Point(195, 27)
        Me.CeldaPorcentaje.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaPorcentaje.Name = "CeldaPorcentaje"
        Me.CeldaPorcentaje.Size = New System.Drawing.Size(117, 22)
        Me.CeldaPorcentaje.TabIndex = 6
        Me.CeldaPorcentaje.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 36)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 17)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Percentage"
        Me.Label5.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Location = New System.Drawing.Point(376, 16)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 5
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaCuenta
        '
        Me.celdaCuenta.AutoSize = True
        Me.celdaCuenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCuenta.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaCuenta.Location = New System.Drawing.Point(121, 107)
        Me.celdaCuenta.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaCuenta.Name = "celdaCuenta"
        Me.celdaCuenta.Size = New System.Drawing.Size(57, 17)
        Me.celdaCuenta.TabIndex = 6
        Me.celdaCuenta.Text = "Label4"
        '
        'celdaCuentaID
        '
        Me.celdaCuentaID.Location = New System.Drawing.Point(111, 79)
        Me.celdaCuentaID.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCuentaID.Name = "celdaCuentaID"
        Me.celdaCuentaID.ReadOnly = True
        Me.celdaCuentaID.Size = New System.Drawing.Size(263, 22)
        Me.celdaCuentaID.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 79)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Account"
        '
        'CeldaDescripcion
        '
        Me.CeldaDescripcion.Location = New System.Drawing.Point(111, 43)
        Me.CeldaDescripcion.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaDescripcion.Name = "CeldaDescripcion"
        Me.CeldaDescripcion.ReadOnly = True
        Me.CeldaDescripcion.Size = New System.Drawing.Size(263, 22)
        Me.CeldaDescripcion.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 48)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Description"
        '
        'celdaCodigo
        '
        Me.celdaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigo.Location = New System.Drawing.Point(111, 11)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(132, 22)
        Me.celdaCodigo.TabIndex = 1
        '
        'ID
        '
        Me.ID.AutoSize = True
        Me.ID.Location = New System.Drawing.Point(23, 15)
        Me.ID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.ID.Name = "ID"
        Me.ID.Size = New System.Drawing.Size(21, 17)
        Me.ID.TabIndex = 0
        Me.ID.Text = "ID"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 80)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(653, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(653, 80)
        Me.Encabezado1.TabIndex = 0
        '
        'frmTipoActivos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(653, 486)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmTipoActivos"
        Me.Text = "Fixed Assets"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents botonCuenta As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CeldaAcumulada As Label
    Friend WithEvents botonAcumulado As Button
    Friend WithEvents celdaAcumuladaID As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaDepreciacion As Label
    Friend WithEvents botonDepreciacion As Button
    Friend WithEvents celdaDepreciacionID As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents CeldaPorcentaje As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaCuenta As Label
    Friend WithEvents celdaCuentaID As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents CeldaDescripcion As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaCodigo As TextBox
    Friend WithEvents ID As Label
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colDepreciar As DataGridViewTextBoxColumn
    Friend WithEvents colPorcentaje As DataGridViewTextBoxColumn
    Friend WithEvents colCuenta As DataGridViewTextBoxColumn
End Class
