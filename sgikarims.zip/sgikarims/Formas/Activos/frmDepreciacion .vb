﻿Public Class frmDepreciacion
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False


#End Region

#Region "Prodiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Funciones y Procedimientos"

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLActivos(ByVal fecha As Date) As String
        Dim strsql As String = STR_VACIO
        Try
            strsql = "SELECT COALESCE(CONCAT(p.per_nombre1,' ',p.per_apellido1),'(sin asignar)') Encargado, a.Codigo, a.Descripcion, ROUND(a.Precio * a.Tasa,2) Precio, d.dep_monto Depreciacion, CAST(COALESCE(SUM(d.dep_monto),'') AS CHAR) Acumulada, CAST(COALESCE(SUM(d.dep_dias),'') AS CHAR) Dias, t.Cta_Depreciacion CtaDep, t.Cta_Acumulada CtaAcu
                        FROM Activos a
                        LEFT JOIN Depreciaciones d ON d.dep_empresa = a.Empresa AND d.dep_codigo = a.Codigo
                        LEFT JOIN Personal p ON p.per_sisemp = a.Empresa AND p.per_codigo = a.Id_Usuario
                        LEFT JOIN Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo
                        WHERE a.Empresa = {empresa} AND (d.dep_fecha <= '{fecha}' AND d.dep_estado = 0)
                         GROUP BY a.Codigo
                        ORDER BY p.per_nombre1, p.per_apellido1, a.Codigo"

            strsql = strsql.Replace("{empresa}", Sesion.IdEmpresa)
            strsql = strsql.Replace("{fecha}", fecha.ToString(FORMATO_MYSQL))
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strsql
    End Function

    Private Sub Previsualizar()
        Dim strSQL As String = STR_VACIO
        Dim Fecha As Date
        Dim Mes As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim dblTotal As Double = INT_CERO
        Try
            Fecha = cFunciones.UltimodiaDelMes(dtpFecha.Value)
            Mes = Fecha.Month
            strSQL = SQLActivos(Fecha)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            dblTotal = INT_CERO
            If REA.HasRows Then
                Do While REA.Read
                    strFila = STR_VACIO
                    strFila &= REA.GetString("Encargado") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Depreciacion").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Acumulada").ToString(FORMATO_MONEDA) & "|"
                    strFila &= (REA.GetDouble("Precio") - REA.GetDouble("Acumulada")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("Dias") & "|"
                    strFila &= REA.GetString("CtaDep") & "|"
                    strFila &= REA.GetString("CtaAcu")

                    cFunciones.AgregarFila(dgLista, strFila)
                    dblTotal = dblTotal + REA.GetDouble("Depreciacion")
                Loop
            End If
            celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function Ejecutar() As Boolean
        Dim LogResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " UPDATE Depreciaciones SET dep_estado=1
                       WHERE dep_empresa = {empresa}  AND (dep_fecha <= '{fecha}') AND (dep_estado = 0) "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Depreciaciones SET dep_estado=1
                       WHERE dep_empresa = {empresa}  AND (dep_fecha <= '{fecha}') AND (dep_estado = 0) "
            End If

            strSQL = strSQL.Replace("{fecha}", cFunciones.UltimodiaDelMes(dtpFecha.Value).ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            LogResultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function

    Private Sub CalcularFecha()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = "SELECT CAST(IFNULL(MAX(a.dep_fecha),
	                        (SELECT DATE_SUB(IFNULL(MIN(b.dep_fecha), CURDATE()), INTERVAL 1 MONTH)
	                        FROM Depreciaciones b
	                        WHERE b.dep_empresa={empresa} AND b.dep_estado=0)) AS DATE) Fecha
                        FROM Depreciaciones a
                        WHERE a.dep_empresa={empresa}  AND a.dep_estado=1"

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dtpFecha.Value = COM.ExecuteScalar
            dtpFecha.Value = dtpFecha.Value.AddMonths(INT_UNO)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

    Private Sub frmDepreciacion_Load(sender As Object, e As EventArgs) Handles Me.Load

        Try
            Accesos()
            CalcularFecha()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BotonPrevio_Click(sender As Object, e As EventArgs) Handles BotonPrevio.Click
        If logConsultar = True Then
            Previsualizar()
        Else
            MsgBox("You don't have permission to preview")
        End If

    End Sub

    Private Sub botonAplicar_Click(sender As Object, e As EventArgs) Handles botonAplicar.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExisteCierre As Integer

        If logInsertar = True Then
            Previsualizar()
            If dgLista.Rows.Count > 0 Then

                'Verifica si hay cierre
                strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
                strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", Year(dtpFecha.Value.ToString(FORMATO_MYSQL)))
                strSQL = Replace(strSQL, "{fec}", dtpFecha.Value.ToString(FORMATO_MYSQL))

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                intExisteCierre = COM.ExecuteScalar

                If intExisteCierre = 0 Then
                    GuardarDatosDepreciacion()
                Else
                    'Si hay cierre solicita autorización para modificar
                    MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                    If cFunciones.AutorizarCambios = True Then
                        GuardarDatosDepreciacion()
                    End If
                End If

            End If
        Else
            MsgBox("You don't have permission to execute this process")
        End If
    End Sub

    Private Sub GuardarDatosDepreciacion()
        Dim conta As New clsContabilidad
        If MsgBox(dgLista.Rows.Count & " Resgister until " & cFunciones.MesIngles(dtpFecha.Value.Month) & " " & dtpFecha.Value.Year & vbNewLine & " Do you want to continue? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            'hacer poliza
            If conta.GenerarPoliza(160, dtpFecha.Value.Year, dtpFecha.Value.Month, fecha:=cFunciones.UltimodiaDelMes(dtpFecha.Value)) = True Then
                'marcar como depreciado
                If Ejecutar() = True Then
                    CalcularFecha()
                    BotonPrevio.Focus()
                    celdaTotal.Text = "0.00"
                    dgLista.Rows.Clear()
                End If
            End If
        End If
    End Sub

    Private Sub frmDepreciacion_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim cRep As New clsReportes
        Dim fecha As Date
        Try
            fecha = cFunciones.UltimodiaDelMes(dtpFecha.Value)
            cRep.ReporteDepreciacion(fecha)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class