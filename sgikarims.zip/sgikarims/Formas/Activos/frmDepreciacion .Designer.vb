﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDepreciacion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDepreciacion))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.botonAplicar = New System.Windows.Forms.Button()
        Me.BotonPrevio = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colEncargado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDepMensual = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAcumulado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colValor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDias = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuentaDep = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuentaAcuc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonImprimir)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.celdaTotal)
        Me.Panel1.Controls.Add(Me.botonAplicar)
        Me.Panel1.Controls.Add(Me.BotonPrevio)
        Me.Panel1.Controls.Add(Me.dtpFecha)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(800, 100)
        Me.Panel1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(684, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 18)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaTotal.Location = New System.Drawing.Point(612, 49)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(157, 27)
        Me.celdaTotal.TabIndex = 3
        Me.celdaTotal.Text = "0.00"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'botonAplicar
        '
        Me.botonAplicar.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.botonAplicar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAplicar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAplicar.Location = New System.Drawing.Point(401, 19)
        Me.botonAplicar.Name = "botonAplicar"
        Me.botonAplicar.Size = New System.Drawing.Size(75, 44)
        Me.botonAplicar.TabIndex = 2
        Me.botonAplicar.Text = "Apply"
        Me.botonAplicar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAplicar.UseVisualStyleBackColor = False
        '
        'BotonPrevio
        '
        Me.BotonPrevio.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BotonPrevio.Image = Global.KARIMs_SGI.My.Resources.Resources.search
        Me.BotonPrevio.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonPrevio.Location = New System.Drawing.Point(312, 19)
        Me.BotonPrevio.Name = "BotonPrevio"
        Me.BotonPrevio.Size = New System.Drawing.Size(73, 44)
        Me.BotonPrevio.TabIndex = 1
        Me.BotonPrevio.Text = "Preview"
        Me.BotonPrevio.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonPrevio.UseVisualStyleBackColor = False
        '
        'dtpFecha
        '
        Me.dtpFecha.CustomFormat = "MMMM yyyy"
        Me.dtpFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpFecha.Location = New System.Drawing.Point(31, 29)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(258, 30)
        Me.dtpFecha.TabIndex = 0
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEncargado, Me.colCodigo, Me.colDescripcion, Me.colCosto, Me.colDepMensual, Me.colAcumulado, Me.colValor, Me.colDias, Me.colCuentaDep, Me.colCuentaAcuc})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 100)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(800, 350)
        Me.dgLista.TabIndex = 1
        '
        'colEncargado
        '
        Me.colEncargado.HeaderText = "Responsible"
        Me.colEncargado.Name = "colEncargado"
        Me.colEncargado.ReadOnly = True
        Me.colEncargado.Width = 115
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'colCosto
        '
        Me.colCosto.HeaderText = "Cost"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        Me.colCosto.Width = 65
        '
        'colDepMensual
        '
        Me.colDepMensual.HeaderText = "Monthly Dep"
        Me.colDepMensual.Name = "colDepMensual"
        Me.colDepMensual.ReadOnly = True
        Me.colDepMensual.Width = 107
        '
        'colAcumulado
        '
        Me.colAcumulado.HeaderText = "Acumulate Dep."
        Me.colAcumulado.Name = "colAcumulado"
        Me.colAcumulado.ReadOnly = True
        Me.colAcumulado.Width = 126
        '
        'colValor
        '
        Me.colValor.HeaderText = "Current Value"
        Me.colValor.Name = "colValor"
        Me.colValor.ReadOnly = True
        Me.colValor.Width = 114
        '
        'colDias
        '
        Me.colDias.HeaderText = "Days"
        Me.colDias.Name = "colDias"
        Me.colDias.ReadOnly = True
        Me.colDias.Width = 69
        '
        'colCuentaDep
        '
        Me.colCuentaDep.HeaderText = "Cuenta Dep"
        Me.colCuentaDep.Name = "colCuentaDep"
        Me.colCuentaDep.ReadOnly = True
        Me.colCuentaDep.Visible = False
        Me.colCuentaDep.Width = 103
        '
        'colCuentaAcuc
        '
        Me.colCuentaAcuc.HeaderText = "Cuena ACu"
        Me.colCuentaAcuc.Name = "colCuentaAcuc"
        Me.colCuentaAcuc.ReadOnly = True
        Me.colCuentaAcuc.Visible = False
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(483, 13)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(79, 53)
        Me.botonImprimir.TabIndex = 50
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'frmDepreciacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.dgLista)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmDepreciacion"
        Me.Text = "Depretiation"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents botonAplicar As Button
    Friend WithEvents BotonPrevio As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents colEncargado As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colDepMensual As DataGridViewTextBoxColumn
    Friend WithEvents colAcumulado As DataGridViewTextBoxColumn
    Friend WithEvents colValor As DataGridViewTextBoxColumn
    Friend WithEvents colDias As DataGridViewTextBoxColumn
    Friend WithEvents colCuentaDep As DataGridViewTextBoxColumn
    Friend WithEvents colCuentaAcuc As DataGridViewTextBoxColumn
    Friend WithEvents botonImprimir As Button
End Class
