﻿Public Class frmSincronizacion

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim YarnD As String = "YarnDivision"
    Dim intTipoReport As Integer = 0

#End Region

#Region "Prodiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property TipoReporte As Integer
        Get
            Return intTipoReport
        End Get
        Set(value As Integer)
            intTipoReport = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Function SQLRegistroOpenInvoice()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select o.registro "
        strSQL &= "    From " & YarnD & ".Open_Invoice o "
        strSQL &= "        Where o.correlativo> 0 "
        strSQL &= "            Limit 1"

        Return strSQL
    End Function

    Private Function SQLRegistroCorp(ByVal tblReg As String)
        Dim strSQL As String = STR_VACIO

        strSQL = " Select o.Registro "
        strSQL &= "    From " & YarnD & ".{tabla} o "
        strSQL &= "        Where o.Correlativo> 0 "
        strSQL &= "            Limit 1"

        strSQL = Replace(strSQL, "{tabla}", tblReg)
        Return strSQL
    End Function
    Private Function SQLBase()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT e.idEmpresa empresa, e.Descripcion base, e.codigo_empresa codigo, e.conta_empresa conta "
        strSQL &= "    From " & YarnD & ".Empresa e "

        Return strSQL

    End Function
    Private Function sqlVentasSemanalesCliente(ByVal codEmpresa As Integer, ByVal base As String, ByVal idEmpresa As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT  0 Correlativo ,IFNULL(yd.idGrupo,-1) idGrupo, l2.* "
        strSQL &= "     FROM ( "
        strSQL &= "         SELECT l1.id, l1.idCliente idCliente, l1.Cliente Cliente, SUM(l1.cantidad) cantidad, SUM(l1.total) Total, l1.Categoria Categoria, l1.paisCategoria, current_timestamp "
        strSQL &= "             FROM ( "
        strSQL &= "                 SELECT  " & idEmpresa & " id,iv.inv_artcodigo idHilo, c.cli_codigo idCliente, c.cli_cliente Cliente, e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano ciclo, e.HDoc_Doc_Fec fecha, e.HDoc_Doc_Num numero, e.HDoc_DR1_Dbl num2, "
        strSQL &= "                     d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, IFNULL(d.DDoc_RF1_Txt,'') Referencia, "
        strSQL &= "                         SUM((d.DDoc_Prd_QTY - d.DDoc_RF2_Dbl) * m.cat_sist) cantidad, IF(SUM(d.DDoc_Prd_QTY - d.DDoc_RF2_Dbl)>0,(d.DDoc_Prd_NET / m.cat_sist),0) precio, COALESCE(l.cat_clave,'') medida, ROUND(SUM((d.DDoc_Prd_QTY - d.DDoc_RF2_Dbl) * d.DDoc_Prd_NET),2) total, IFNULL(ct.cat_desc,'N/A') Categoria, "
        strSQL &= "                             IFNULL(ct.cat_num,-1) idCategoria, cat.cat_num idOrigen, cat.cat_clave Region, IFNULL(ct.cat_pid,0) paisCategoria "
        strSQL &= "                                 FROM " & base & ".Dcmtos_DTL d "
        strSQL &= "                                     INNER JOIN " & base & ".Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "                                         LEFT JOIN " & base & ".Clientes c ON c.cli_sisemp = e.HDoc_Sis_Emp AND c.cli_codigo = e.HDoc_DR1_Emp"
        strSQL &= "                                             LEFT JOIN " & base & ".Catalogos ct ON ct.cat_num = c.cli_categoria "
        strSQL &= "                                                 LEFT JOIN " & base & ".Catalogos m ON m.cat_clase='Medidas' AND m.cat_num = d.DDoc_Prd_UM "
        strSQL &= "                                                     LEFT JOIN " & base & ".Catalogos l ON l.cat_clase='Medidas' AND l.cat_sist = 1 "
        strSQL &= "                                                 LEFT JOIN " & base & ".Inventarios iv ON iv.inv_sisemp = d.DDoc_Sis_Emp AND iv.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                                             LEFT JOIN  " & base & ".Catalogos o ON o.cat_num = iv.inv_lugarfab "
        strSQL &= "                                         LEFT JOIN " & base & ".Catalogos cat ON cat.cat_num = o.cat_pid "
        strSQL &= "                                     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 395 AND (e.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') AND e.HDoc_Doc_Status = 1 AND LENGTH(e.HDoc_DR1_Num)>6 "
        strSQL &= "                                 GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
        strSQL &= "                             ORDER BY c.cli_categoria, cat.cat_num) l1 "
        strSQL &= "                         GROUP BY l1.idCliente, Categoria "
        strSQL &= "                     ORDER BY l1.idCategoria, Total DESC	)l2 "
        strSQL &= "                 LEFT JOIN YarnDivision.Grupo_Detalle yd ON yd.idEmpresa = l2.id AND yd.Codigo = l2.idCliente AND yd.idTipo = 1 "
        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{fechainicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafin}", dtpFecha.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function


    Private Function sqlOpenInvoices(ByVal logAR As Boolean, ByVal codEmpresa As Integer, ByVal base As String, ByVal idEmpresa As Integer)
        Dim strSQL As String = STR_VACIO

        'Selecciona las facturas con saldo
        strSQL = vbNullString
        strSQL = strSQL & "SELECT 0 correlativo, IFNULL(dg.idGrupo,-1) idGrupo, l1.*, current_timestamp "
        strSQL = strSQL & " FROM( "
        strSQL = strSQL & " SELECT " & idEmpresa & " id, Codigo, Nombre, Fecha, Invoice, Referencia, Descripcion, Round(Credito,2) Info, IF(LC=" & "'L/C'" & ",LC,IF(DiasYRM>0,CONCAT('NET ',CAST(DiasYRM AS CHAR)),'')) Termino, Vence, IF(Dias>0,CAST(Dias AS Char),'') Dias, Saldo, IF(Dias>0,Saldo,0) Deuda, ROUND(IF(Dias>0 AND Saldo>0, ((0.18/360) * Dias) * Saldo,0),2) Mora, ROUND(Saldo * Tasa,2) SaldoQ, Tasa, TRIM(BOTH ',' FROM CAST(Programa AS CHAR)) Programa,PF, Pagare, Entrega, Clase, Serie,Autorizacion  "
        strSQL = strSQL & " FROM"

        'IDC y Extension corresponden al cliente y plazo en factura y sobreescritos en YM
        strSQL = strSQL & " (SELECT s1.Codigo, UPPER(c.cli_cliente) Nombre, s1.Fecha, s1.Invoice, s1.Referencia, s1.Descripcion Descripcion, ROUND((s1.Total+s1.Cargos)-s1.Abonos,2) Saldo, s1.Tasa, c.cli_forma Forma, c.cli_montoCR Credito, IFNULL(Extension,c.cli_plazoCR) Plazo, s1.LC,s1.DiasYRM, DATE_ADD(s1.Fecha, INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY) Vence, DATEDIFF(@corte, DATE_ADD(s1.Fecha, INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY)) Dias, TRIM(s1.Programa) Programa, s1.PF PF, if(s1.pagare=1,'RECEIVED',if(s1.pagare= 0, 'NOT RECEIVED','-')) Pagare, s1.Entrega Entrega, s1.Clase Clase , IFNULL(s1.Serie,'N/A') Serie, IFNULL(s1.NumeroAutorizacion,'-') Autorizacion "
        strSQL = strSQL & "  FROM"
        strSQL = strSQL & "  (SELECT ef.HDoc_Sis_Emp Empresa, ef.HDoc_Doc_Cat Tipo, {idempresa} Invoice, ef.HDoc_DR1_Num Referencia, ef.HDoc_Doc_Fec Fecha, cf.ECta_Crgo_Ext Total, ef.HDoc_Doc_TC Tasa, ef.HDoc_DR1_Emp IDC, ef.HDoc_RF2_Num Extension, fel.Serie,fel.NumeroAutorizacion, "

        'Total de cargos (sin incluir factura)
        strSQL = strSQL & "      IFNULL( (SELECT SUM(a1.ECta_Crgo_Ext)"
        strSQL = strSQL & "               FROM " & base & ".ECtaCte a1 "
        strSQL = strSQL & "               WHERE a1.ECta_Sis_Emp=ef.HDoc_Sis_Emp And a1.ECta_Ref_Cat=ef.HDoc_Doc_Cat And a1.ECta_Ref_Ano=ef.HDoc_Doc_Ano And a1.ECta_Ref_Num=ef.HDoc_Doc_Num And a1.ECta_FecDcmt <= @corte And Not(a1.ECta_Doc_Cat=ef.HDoc_Doc_Cat)),0) Cargos,"

        'Total de abonos a la factura
        strSQL = strSQL & "      IFNULL( (Select SUM(a1.ECta_Abno_Ext)"
        strSQL = strSQL & "               FROM " & base & ".ECtaCte a1 "
        strSQL = strSQL & "               WHERE a1.ECta_Sis_Emp=ef.HDoc_Sis_Emp And a1.ECta_Ref_Cat=ef.HDoc_Doc_Cat And a1.ECta_Ref_Ano=ef.HDoc_Doc_Ano And a1.ECta_Ref_Num=ef.HDoc_Doc_Num And a1.ECta_FecDcmt <= @corte),0) Abonos,"

        'Solicitante (ref. Yarn Movement) / no entre compañías
        If logAR Then
            strSQL = strSQL & "      IFNULL( (Select e1.HDoc_DR1_Emp "
            strSQL = strSQL & "               FROM " & base & ".Dcmtos_DTL_Pro r1"
            strSQL = strSQL & "                  LEFT JOIN " & base & ".Dcmtos_HDR e1 On e1.HDoc_Sis_Emp=r1.PDoc_Sis_Emp And e1.HDoc_Doc_Cat=r1.PDoc_Chi_Cat And e1.HDoc_Doc_Ano=r1.PDoc_Chi_Ano And e1.HDoc_Doc_Num=r1.PDoc_Chi_Num"
            strSQL = strSQL & "               WHERE r1.PDoc_Sis_Emp = ef.HDoc_Sis_Emp And r1.PDoc_Par_Cat=ef.HDoc_Doc_Cat And r1.PDoc_Par_Ano=ef.HDoc_Doc_Ano And r1.PDoc_Par_Num=ef.HDoc_Doc_Num And r1.PDoc_Chi_Cat=@movimiento LIMIT 1),-1) Codigo, "
        Else : strSQL = strSQL & " ef.HDoc_Emp_Cod Codigo, "
        End If

        strSQL = strSQL & " IFNULL((
                                SELECT e1.HDoc_DR1_Cat
                                FROM " & base & ".Dcmtos_DTL_Pro r1
                                LEFT JOIN " & base & ".Dcmtos_HDR e1 ON e1.HDoc_Sis_Emp=r1.PDoc_Sis_Emp AND e1.HDoc_Doc_Cat=r1.PDoc_Chi_Cat AND e1.HDoc_Doc_Ano=r1.PDoc_Chi_Ano AND e1.HDoc_Doc_Num=r1.PDoc_Chi_Num
                                WHERE r1.PDoc_Sis_Emp = ef.HDoc_Sis_Emp AND r1.PDoc_Par_Cat=ef.HDoc_Doc_Cat AND r1.PDoc_Par_Ano=ef.HDoc_Doc_Ano AND r1.PDoc_Par_Num=ef.HDoc_Doc_Num AND r1.PDoc_Chi_Cat=395
                                LIMIT 1),0) DiasYRM,

                            IFNULL((
                                SELECT e1.DDoc_RF2_Txt
                                FROM " & base & ".Dcmtos_DTL_Pro r1
                                LEFT JOIN " & base & ".Dcmtos_DTL e1 ON e1.DDoc_Sis_Emp=r1.PDoc_Sis_Emp AND e1.DDoc_Doc_Cat=r1.PDoc_Chi_Cat AND e1.DDoc_Doc_Ano=r1.PDoc_Chi_Ano AND e1.DDoc_Doc_Num=r1.PDoc_Chi_Num
                                WHERE r1.PDoc_Sis_Emp = ef.HDoc_Sis_Emp AND r1.PDoc_Par_Cat=ef.HDoc_Doc_Cat AND r1.PDoc_Par_Ano=ef.HDoc_Doc_Ano AND r1.PDoc_Par_Num=ef.HDoc_Doc_Num AND r1.PDoc_Chi_Cat=395
                                LIMIT 1),'N/A') LC,"

        ' Clase de Pago agregado en YRM

        strSQL = strSQL & "      IFNULL( (Select cl.cat_desc  "
        strSQL = strSQL & "               FROM " & base & ".Dcmtos_DTL_Pro r1"
        strSQL = strSQL & "                  LEFT JOIN " & base & ".Dcmtos_HDR e1 On e1.HDoc_Sis_Emp=r1.PDoc_Sis_Emp And e1.HDoc_Doc_Cat=r1.PDoc_Chi_Cat And e1.HDoc_Doc_Ano=r1.PDoc_Chi_Ano And e1.HDoc_Doc_Num=r1.PDoc_Chi_Num"
        strSQL &= "                         left join " & base & ".Catalogos cl on cl.cat_num = e1.HDoc_DR2_Emp and cl.cat_clase = 'ClassYRM' "
        strSQL = strSQL & "               WHERE r1.PDoc_Sis_Emp = ef.HDoc_Sis_Emp And r1.PDoc_Par_Cat=ef.HDoc_Doc_Cat And r1.PDoc_Par_Ano=ef.HDoc_Doc_Ano And r1.PDoc_Par_Num=ef.HDoc_Doc_Num And r1.PDoc_Chi_Cat=@movimiento LIMIT 1),'N/A') Clase, "

        ' Factura -> Inst/despacho -> Pedido
        strSQL = strSQL & "      IFNULL((Select GROUP_CONCAT(DISTINCT DDoc_RF2_Cod SEPARATOR ',') Buyer "
        strSQL = strSQL & "              FROM " & base & ".Dcmtos_DTL_Pro ri "
        strSQL = strSQL & "                   LEFT JOIN " & base & ".Dcmtos_DTL_Pro rp ON rp.PDoc_Sis_Emp=ri.PDoc_Sis_Emp AND rp.PDoc_Chi_Cat=ri.PDoc_Par_Cat AND rp.PDoc_Chi_Ano=ri.PDoc_Par_Ano AND rp.PDoc_Chi_Num=ri.PDoc_Par_Num AND rp.PDoc_Chi_Lin=ri.PDoc_Par_Lin AND rp.PDoc_Par_Cat=@pedido"
        strSQL = strSQL & "                   LEFT JOIN " & base & ".Dcmtos_DTL dp ON dp.DDoc_Sis_Emp=rp.PDoc_Sis_Emp AND dp.DDoc_Doc_Cat=rp.PDoc_Par_Cat AND dp.DDoc_Doc_Ano=rp.PDoc_Par_Ano AND dp.DDoc_Doc_Num=rp.PDoc_Par_Num AND dp.DDoc_Doc_Lin=rp.PDoc_Par_Lin"
        strSQL = strSQL & "              WHERE ri.PDoc_Sis_Emp=ef.HDoc_Sis_Emp AND ri.PDoc_Chi_Cat=ef.HDoc_Doc_Cat AND ri.PDoc_Chi_Ano=ef.HDoc_Doc_Ano AND ri.PDoc_Chi_Num=ef.HDoc_Doc_Num),'') Programa,"

        ' 2015-01-20 Incluir PF
        strSQL = strSQL & "   ifnull((select group_concat(Distinct pf.HDoc_DR1_Num SEPARATOR ',') PO    "
        strSQL = strSQL & "         FROM " & base & ".Dcmtos_DTL_Pro pp     "
        strSQL = strSQL & "           LEFT JOIN " & base & ".Dcmtos_DTL_Pro ppp ON ppp.PDoc_Sis_Emp=pp.PDoc_Sis_Emp AND ppp.PDoc_Chi_Cat=pp.PDoc_Par_Cat AND ppp.PDoc_Chi_Ano=pp.PDoc_Par_Ano AND ppp.PDoc_Chi_Num=pp.PDoc_Par_Num AND ppp.PDoc_Chi_Lin=pp.PDoc_Par_Lin AND ppp.PDoc_Par_Cat=75       "
        strSQL = strSQL & "           LEFT JOIN " & base & ".Dcmtos_HDR pf on pf.HDoc_Sis_Emp = ppp.PDoc_Sis_Emp and pf.HDoc_Doc_Cat = ppp.PDoc_Par_Cat and pf.HDoc_Doc_Ano = ppp.PDoc_Par_Ano and pf.HDoc_Doc_Num = ppp.PDoc_Par_Num        "
        strSQL = strSQL & "         WHERE pp.PDoc_Sis_Emp=ef.HDoc_Sis_Emp AND pp.PDoc_Chi_Cat=ef.HDoc_Doc_Cat AND pp.PDoc_Chi_Ano=ef.HDoc_Doc_Ano AND pp.PDoc_Chi_Num=ef.HDoc_Doc_Num ), '-') PF,     "

        '2023-11-20 incluir la descripcion de las facturas, concatenadas si son varias líneas
        strSQL = strSQL & "    IFNULL((SELECT group_concat(art.art_DLarga SEPARATOR ' | ') Des  "
        strSQL = strSQL & "        FROM " & base & ".Dcmtos_HDR hdr "
        strSQL = strSQL & "            INNER JOIN " & base & ".Dcmtos_DTL dtl ON dtl.DDoc_Sis_Emp = hdr.HDoc_Sis_Emp AND dtl.DDoc_Doc_Cat = hdr.HDoc_Doc_Cat AND dtl.DDoc_Doc_Ano = hdr.HDoc_Doc_Ano AND dtl.DDoc_Doc_Num = hdr.HDoc_Doc_Num "
        strSQL = strSQL & "                LEFT JOIN " & base & ".Inventarios inv ON inv.inv_sisemp = dtl.DDoc_Sis_Emp AND inv.inv_numero = dtl.DDoc_Prd_Cod "
        strSQL = strSQL & "            LEFT JOIN " & base & ".Articulos art ON art.art_sisemp = inv.inv_sisemp AND art.art_codigo = inv.inv_artcodigo "
        strSQL = strSQL & "        WHERE hdr.HDoc_Sis_Emp = ef.HDoc_Sis_Emp AND hdr.HDoc_Doc_Cat = ef.HDoc_Doc_Cat  AND hdr.HDoc_Doc_Ano = ef.HDoc_Doc_Ano  AND hdr.HDoc_Doc_Num = ef.HDoc_Doc_Num), '-') Descripcion,"

        '2014-10-13 incluir si tiene pagares y en que estado se encuentran
        strSQL = strSQL & "   ifnull((select pa.HDoc_RF1_Num "
        strSQL = strSQL & "        from " & base & ".Dcmtos_DTL_Pro pro "
        strSQL = strSQL & "           left join " & base & ".Dcmtos_HDR pa on pro.PDoc_Sis_Emp = pa.HDoc_Sis_Emp and pro.PDoc_Chi_Cat = pa.HDoc_Doc_Cat and pro.PDoc_Chi_Ano = pa.HDoc_Doc_Ano and pro.PDoc_Chi_Num = pa.HDoc_Doc_Num "
        strSQL = strSQL & "        where pro.PDoc_Sis_Emp =ef.HDoc_Sis_Emp and pro.PDoc_Chi_Cat = 465 and  pa.HDoc_Doc_Status = 1 and pro.PDoc_Par_Cat = ef.HDoc_Doc_Cat and pro.PDoc_Par_Ano = ef.HDoc_Doc_Ano and pro.PDoc_Par_Num = ef.HDoc_Doc_Num limit 1),'3')  pagare, "

        'Fecha de Entrega
        strSQL = strSQL & " IFNULL(( "
        strSQL = strSQL & "    Select af.ADoc_Dta_Fec "
        strSQL = strSQL & "        From " & base & ".Dcmtos_DTL_Pro pe "
        strSQL = strSQL & "        Left JOIN " & base & ".Dcmtos_ACC af ON af.ADoc_Sis_Emp=pe.PDoc_Sis_Emp AND af.ADoc_Doc_Cat = pe.PDoc_Chi_Cat AND af.ADoc_Doc_Ano = pe.PDoc_Par_Ano AND af.ADoc_Doc_Num = pe.PDoc_Par_Num AND af.ADoc_Doc_Sub ='Doc_PolExp' AND af.ADoc_Doc_Lin = '23' "
        strSQL = strSQL & "    WHERE pe.PDoc_Sis_Emp = ef.HDoc_Sis_Emp AND pe.PDoc_Par_Cat = ef.HDoc_Doc_Cat AND pe.PDoc_Par_Ano = ef.HDoc_Doc_Ano AND pe.PDoc_Par_Num = ef.HDoc_Doc_Num AND pe.PDoc_Chi_Cat = 56 "
        strSQL = strSQL & " LIMIT 1), NULL) Entrega "

        strSQL = strSQL & "   FROM " & base & ".Dcmtos_HDR ef"
        strSQL = strSQL & "      INNER JOIN " & base & ".ECtaCte cf ON cf.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = ef.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = ef.HDoc_Doc_Ano AND cf.ECta_Doc_Num = ef.HDoc_Doc_Num"
        strSQL = strSQL & "         LEFT JOIN " & base & ".Fel fel ON fel.Empresa = ef.HDoc_Sis_Emp AND fel.Catalogo = ef.HDoc_Doc_Cat AND fel.Anio = ef.HDoc_Doc_Ano AND fel.Numero = ef.HDoc_Doc_Num"
        strSQL = strSQL & "   WHERE ef.HDoc_Sis_Emp=@empresa AND ef.HDoc_Doc_Cat=@venta AND ef.HDoc_Doc_Fec <= @corte AND ef.HDoc_Doc_Status=1) s1"
        strSQL = strSQL & "  LEFT JOIN " & base & ".Clientes c ON c.cli_sisemp=s1.Empresa AND c.cli_codigo=s1.Codigo"
        strSQL = strSQL & "  WHERE NOT(ISNULL(c.cli_codigo)) "   '110617 SdL / incluir todo sin importar si es del grupo {AND IFNULL(c.cli_idem,1)=0}
        strSQL = strSQL & "  HAVING (Saldo <> 0)) s2"
        strSQL = strSQL & " ORDER BY Nombre, Fecha, Invoice, Codigo) l1 "
        strSQL = strSQL & " LEFT JOIN YarnDivision.Grupo_Detalle dg ON dg.idEmpresa = l1.id AND dg.Codigo = l1.Codigo AND dg.idTipo = 1 "

        'Reemplazar parámetros
        strSQL = Replace(strSQL, "@empresa", codEmpresa)
        strSQL = Replace(strSQL, "@pedido", 75)
        strSQL = Replace(strSQL, "@despacho", 48)
        strSQL = Replace(strSQL, "@venta", 36)
        strSQL = Replace(strSQL, "@cargo", 397)
        strSQL = Replace(strSQL, "@movimiento", 395)
        strSQL = Replace(strSQL, "@corte", "'" & dtpFecha.Value.ToString(FORMATO_MYSQL) & "'")
        If idEmpresa > 1 Then
            '' If idEmpresa = 2 Or idEmpresa = 4 Then
            strSQL = Replace(strSQL, "{idempresa}", "ef.HDoc_DR1_Dbl")
        Else
            strSQL = Replace(strSQL, "{idempresa}", "ef.HDoc_Doc_Num")
        End If

        Return strSQL
    End Function
    Private Function sqlInventarioenTransito(ByVal codEmpresa As Integer, ByVal Base As String, ByVal idEmpresa As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT 0 Correlativo," & idEmpresa & " Empresa,h.HDoc_Doc_Fec Fecha, h47.HDoc_Doc_Fec, h.HDoc_Emp_Nom Proveedor, h.HDoc_DR1_Num Referencia, a.art_DCorta Hilo, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET Precio, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET)Total, h.HDoc_Doc_TC TC, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET *h.HDoc_Doc_TC) totalLocal, IFNULL(d.DDoc_RF1_Fec,'') ETD, IFNULL(c.ADoc_Dta_Fec,'') ETA,(CASE WHEN b.cat_desc = 'Chemical' THEN 'CHEMICAL' WHEN b.cat_desc = 'Fiber' THEN 'FIBER' ELSE 'YARN' END) Tipo,e.emp_razon Origen, CASE WHEN h38.HDoc_Ant_Com = 1 then IF(cp.cat_num = 0,CONCAT('Hilos y Algodon, S.A.'),IF(cp.cat_num = 1,CONCAT('Pride Yarn, S. de R.L.'),IF(cp.cat_num = 310,CONCAT('Amtex de El Salvador, S.A. DE C.V.'),IF(cp.cat_num = 327,CONCAT('Dominican Republic Yarn Suppliers GK, S.R.L.'),'')))) ELSE ''  END  Pais, cp.cat_num idPais, i.inv_fecha FechaCreacion, current_timestamp "
        strSQL &= " FROM " & Base & ".Dcmtos_HDR h"
        strSQL &= "  LEFT JOIN " & Base & ".Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQL &= "     LEFT JOIN " & Base & ".Dcmtos_DTL_Pro p38 ON p38.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p38.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p38.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p38.PDoc_Chi_Num = d.DDoc_Doc_Num AND p38.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "         LEFT JOIN " & Base & ".Dcmtos_HDR h38 ON h38.HDoc_Sis_Emp = p38.PDoc_Sis_Emp AND h38.HDoc_Doc_Cat = p38.PDoc_Par_Cat AND h38.HDoc_Doc_Ano = p38.PDoc_Par_Ano AND h38.HDoc_Doc_Num = p38.PDoc_Par_Num "
        strSQL &= "             LEFT JOIN " & Base & ".Proveedores pr ON pr.pro_sisemp= h38.HDoc_Sis_Emp AND pr.pro_codigo = h38.HDoc_Emp_Cod "
        strSQL &= "                 LEFT JOIN " & Base & ".Empresas e ON e.emp_no = h.HDoc_Sis_Emp"
        strSQL &= "                     LEFT JOIN " & Base & ".Catalogos cp ON cp.cat_num = pr.pro_pais AND cp.cat_clase = 'Paises'"
        strSQL &= "                         LEFT JOIN " & Base & ".Dcmtos_ACC c ON c.ADoc_Sis_Emp = d.DDoc_Sis_Emp AND c.ADoc_Doc_Cat= d.DDoc_Doc_Cat AND c.ADoc_Doc_Ano = d.DDoc_Doc_Ano AND c.ADoc_Doc_Num = d.DDoc_Doc_Num AND c.ADoc_Doc_Sub ='Doc_PFactura' AND c.ADoc_Doc_Lin = '15'"
        strSQL &= "                       LEFT JOIN " & Base & ".Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                     LEFT JOIN " & Base & ".Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                 LEFT JOIN " & Base & ".Catalogos b ON b.cat_num = a.art_clase AND b.cat_clase = 'ClaseArt' "
        strSQL &= "             LEFT JOIN " & Base & ".Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin "
        strSQL &= "         LEFT JOIN " & Base & ".Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pp.PDoc_Par_Cat = p.PDoc_Chi_Cat AND pp.PDoc_Par_Ano = p.PDoc_Chi_Ano AND pp.PDoc_Par_Num = p.PDoc_Chi_Num AND pp.PDoc_Par_Lin = p.PDoc_Chi_Lin "
        strSQL &= "          LEFT JOIN " & Base & ".Dcmtos_HDR h180 ON h180.HDoc_Sis_Emp = pp.PDoc_Sis_Emp AND h180.HDoc_Doc_Cat = pp.PDoc_Chi_Cat AND h180.HDoc_Doc_Ano = pp.PDoc_Chi_Ano AND h180.HDoc_Doc_Num = pp.PDoc_Chi_Num"
        strSQL &= "     LEFT JOIN  " & Base & ".Dcmtos_DTL_Pro ppp ON ppp.PDoc_Sis_Emp = pp.PDoc_Sis_Emp AND ppp.PDoc_Par_Cat = pp.PDoc_Chi_Cat AND ppp.PDoc_Par_Ano = pp.PDoc_Chi_Ano AND ppp.PDoc_Par_Num = pp.PDoc_Chi_Num AND ppp.PDoc_Par_Lin = pp.PDoc_Chi_Lin AND ppp.PDoc_Chi_Cat = 47 "
        strSQL &= "  LEFT JOIN " & Base & ".Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = ppp.PDoc_Sis_Emp AND h47.HDoc_Doc_Cat = ppp.PDoc_Chi_Cat AND h47.HDoc_Doc_Ano = ppp.PDoc_Chi_Ano AND h47.HDoc_Doc_Num = ppp.PDoc_Chi_Num "
        strSQL &= "WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 127 AND h.HDoc_Doc_Status = 1 AND ((ppp.PDoc_Sis_Emp IS NULL AND h180.HDoc_DR1_Dbl IS NULL)  OR (ppp.PDoc_Sis_Emp = h47.HDoc_Sis_Emp AND h47.HDoc_Doc_Fec >'{fecha}')) AND h.HDoc_Doc_Fec BETWEEN '2019-01-01' AND '{fecha}' "
        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function

    Private Function sqlBalanceCombinado(ByVal codEmpresa As Integer, ByVal Base As String, ByVal idEmpresa As Integer, ByVal strContaEmp As String, ByVal TC As Double)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT 0 Correlativo," & codEmpresa & " codEmpresa, " & idEmpresa & " Empresa, n.Cuenta0, n.Nivel0, n.Nivel1,n.Cuenta1, n.Nivel2,n.Cuenta2,n.Nivel3, n.Cuenta3, n.Nivel4, n.Cuenta4,"
        strSQL &= "     SUM((SELECT IFNULL(SUM(IF(d.operacion = 'C', IFNULL(d.importe / {tc},0), (IFNULL(d.importe / {tc},0) *-1))),0) FROM " & strContaEmp & ".polizas p "
        strSQL &= "         LEFT JOIN " & strContaEmp & ".detalle_polizas d ON d.empresa = p.empresa AND d.ejercicio = p.ejercicio AND d.poliza = p.poliza"
        strSQL &= "             LEFT JOIN " & strContaEmp & ".tipo_poliza t ON t.tipo_poliza = p.tipo"
        strSQL &= "                 WHERE p.empresa = {empresa} AND p.fecha BETWEEN '{inicio}' AND '{fin}' AND d.cuenta = n.Cuenta4 AND NOT t.tipo_poliza IN(4,5)))saldo, CURRENT_TIMESTAMP Registro "
        strSQL &= "                     FROM " & strContaEmp & ".nomenclatura_nivel n WHERE n.Cuenta0 <=3 GROUP BY n.Cuenta3 "


        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{tc}", TC)
        strSQL = Replace(strSQL, "{inicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fin}", dtpFecha.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function

    Private Function sqlPLCombinado(ByVal codEmpresa As Integer, ByVal Base As String, ByVal idEmpresa As Integer, ByVal strContaEmp As String, ByVal TC As Double)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT 0 Correlativo," & codEmpresa & " codEmpresa, " & idEmpresa & " Empresa, n.Cuenta0, n.Nivel0, n.Nivel1,n.Cuenta1, n.Nivel2,n.Cuenta2,n.Nivel3, n.Cuenta3, n.Nivel4, n.Cuenta4,"
        strSQL &= "     SUM((SELECT IFNULL(SUM(IF(d.operacion = 'C', IFNULL(d.importe / {tc},0), (IFNULL(d.importe / {tc},0) *-1))),0) FROM " & strContaEmp & ".polizas p "
        strSQL &= "         LEFT JOIN " & strContaEmp & ".detalle_polizas d ON d.empresa = p.empresa AND d.ejercicio = p.ejercicio AND d.poliza = p.poliza"
        strSQL &= "             LEFT JOIN " & strContaEmp & ".tipo_poliza t ON t.tipo_poliza = p.tipo"
        strSQL &= "                 WHERE p.empresa = {empresa} AND p.fecha BETWEEN '{inicio}' AND '{fin}' AND d.cuenta = n.Cuenta4 AND NOT t.tipo_poliza IN(4,5)))saldo, CURRENT_TIMESTAMP Registro "
        strSQL &= "                     FROM " & strContaEmp & ".nomenclatura_nivel n WHERE n.Cuenta0 >=4 GROUP BY n.Cuenta3 "


        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{tc}", TC)
        strSQL = Replace(strSQL, "{inicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fin}", dtpFecha.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function

    Private Function sqlAgingSumary(ByVal codEmpresa As Integer, ByVal base As String, ByVal idEmpresa As Integer)
        Dim strSQl As String = STR_VACIO

        strSQl = " SELECT 0 correlativo, IFNULL(dg.idGrupo,-1) idGrupo, l1.*, current_timestamp "
        strSQl &= "  FROM("
        strSQl &= "       SELECT " & idEmpresa & " id, '{corte}' Fecha , ID Codigo, Nombre Customer, ((SUM(Saldo)-(SUM(IF(Dias>=0,Saldo,0))))) Current, SUM(IF(Dias >=0 AND Dias <=15,Saldo,0)) Grupo15, "
        strSQl &= "         SUM(IF(Dias >=16 And Dias <=30,Saldo,0)) Grupo30, SUM(IF(Dias >=31 And Dias <=60,Saldo,0)) Grupo60, SUM(IF(Dias >=61 And Dias <=90,Saldo,0)) Grupo90, SUM(IF(Dias >=91,Saldo,0)) Grupo91, SUM(Saldo) Total "
        strSQl &= "             FROM ( "
        strSQl &= "                 SELECT s1.*, ROUND((s1.Total+s1.Cargos)-s1.Abonos,2) Saldo, c.cli_codigo ID,c.cli_cliente Nombre, c.cli_forma Forma, c.cli_montoCR Credito, c.cli_plazoCR Plazo, DATE_ADD(s1.Fecha,"
        strSQl &= "                     INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY) Vence, DATEDIFF('{corte}', DATE_ADD(s1.Fecha, INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY)) Dias, c.cli_usuario Usuario "
        strSQl &= "                         FROM ( "
        strSQl &= "                             SELECT ef.HDoc_Sis_Emp Empresa, ef.HDoc_Doc_Cat Tipo, ef.HDoc_Doc_Num Numero, ef.HDoc_Doc_Fec Fecha, cf.ECta_Crgo_Ext Total, ef.HDoc_DR1_Emp IDC, ef.HDoc_RF2_Num Extension, IFNULL(( "
        strSQl &= "                                 SELECT SUM(a1.ECta_Crgo_Ext) "
        strSQl &= "                                     From " & base & ".ECtaCte a1 "
        strSQl &= "                                         WHERE a1.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND a1.ECta_Ref_Cat=ef.HDoc_Doc_Cat AND a1.ECta_Ref_Ano=ef.HDoc_Doc_Ano AND a1.ECta_Ref_Num=ef.HDoc_Doc_Num AND NOT(a1.ECta_Doc_Cat=ef.HDoc_Doc_Cat) AND a1.ECta_FecDcmt<='{corte}'),0) Cargos, IFNULL(( "
        strSQl &= "                                             Select SUM(a1.ECta_Abno_Ext) "
        strSQl &= "                                                 From " & base & ".ECtaCte a1 "
        strSQl &= "                                                     WHERE a1.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND a1.ECta_Ref_Cat=ef.HDoc_Doc_Cat AND a1.ECta_Ref_Ano=ef.HDoc_Doc_Ano AND a1.ECta_Ref_Num=ef.HDoc_Doc_Num AND a1.ECta_FecDcmt<='{corte}'),0) Abonos, IFNULL(( "
        strSQl &= "                                                         Select e1.HDoc_DR1_Emp "
        strSQl &= "                                                         From " & base & ".Dcmtos_DTL_Pro r1 "
        strSQl &= "                                                        Left JOIN " & base & ".Dcmtos_HDR e1 ON e1.HDoc_Sis_Emp=r1.PDoc_Sis_Emp AND e1.HDoc_Doc_Cat=r1.PDoc_Chi_Cat AND e1.HDoc_Doc_Ano=r1.PDoc_Chi_Ano AND e1.HDoc_Doc_Num=r1.PDoc_Chi_Num "
        strSQl &= "                                                    WHERE r1.PDoc_Sis_Emp = ef.HDoc_Sis_Emp AND r1.PDoc_Par_Cat=ef.HDoc_Doc_Cat AND r1.PDoc_Par_Ano=ef.HDoc_Doc_Ano AND r1.PDoc_Par_Num=ef.HDoc_Doc_Num AND r1.PDoc_Chi_Cat=395 "
        strSQl &= "                                                LIMIT 1),-1) Codigo "
        strSQl &= "                                            From " & base & ".Dcmtos_HDR ef "
        strSQl &= "                                        INNER JOIN " & base & ".ECtaCte cf ON cf.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = ef.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = ef.HDoc_Doc_Ano AND cf.ECta_Doc_Num = ef.HDoc_Doc_Num "
        strSQl &= "                                    WHERE ef.HDoc_Sis_Emp= {empresa} AND ef.HDoc_Doc_Cat=36 AND ef.HDoc_Doc_Fec<='{corte}' AND ef.HDoc_Doc_Status=1) s1 "
        strSQl &= "                                Left JOIN " & base & ".Clientes c ON c.cli_sisemp=s1.Empresa AND c.cli_codigo=s1.Codigo "
        strSQl &= "                            WHERE NOT(ISNULL(c.cli_codigo)) "
        strSQl &= "                        HAVING (Saldo <> 0)) s2 "
        strSQl &= "                    GROUP BY s2.ID "
        strSQl &= "                ORDER BY Nombre) l1 "
        strSQl &= "             LEFT JOIN YarnDivision.Grupo_Detalle dg ON dg.idEmpresa = l1.id AND dg.Codigo = l1.Codigo AND dg.idTipo = 1 "

        strSQl = Replace(strSQl, "{empresa}", codEmpresa)
        strSQl = Replace(strSQl, "{corte}", dtpFecha.Value.ToString(FORMATO_MYSQL))

        Return strSQl
    End Function

    Private Function sqlCuentasPorPagar(ByVal codEmpresa As Integer, ByVal base As String, ByVal idEmpresa As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT 0,{codempresa},l1.*  ,
	                    (case	
		                    when l1.Dias >=0 then l1.saldo ELSE 0
	                    END) 0_,
	                    (case	
		                    when l1.Dias BETWEEN -30 AND -1 then l1.saldo ELSE 0
	                    END) 1_30,
	                    (case	
		                    when l1.Dias BETWEEN -60 AND -31 then l1.saldo ELSE 0
	                    END) 31_60,
	                    (case	
		                    when l1.Dias BETWEEN -90 AND -61 then l1.saldo ELSE 0
	                    END) 60_90,
	                    (case	
		                    when l1.Dias <-90 then l1.saldo ELSE 0
	                    END) _mas90,now()

                    FROM (
                            SELECT ef.HDoc_Emp_Cod Id, ef.HDoc_Emp_Nom Nombre, IF(lc.pro_plazoCR = 0,'', CONCAT('NET',' ',lc.pro_plazoCR)) Terminos, ef.HDoc_DR1_Num Factura,ef.HDoc_DR2_Num Referencia, ef.HDoc_Doc_Fec Fecha, ef.HDoc_DR1_Fec Vencimiento, DATEDIFF(ef.HDoc_DR1_Fec,CURDATE()) Dias, lm.cat_clave Moneda, lv.cat_clave Divisa, cf.ECta_Crgo_Loc Monto, COALESCE(SUM(cd.ECta_Sini_Ext),0) Cargos, COALESCE(SUM(cd.ECta_Abno_Ext),0) Abonos, ROUND((cf.ECta_Crgo_Ext + COALESCE(SUM(cd.ECta_Crgo_Ext),0)) - COALESCE(SUM(cd.ECta_Abno_Ext),0),2) Saldo,ef.HDoc_RF1_Txt Notas
                            FROM " & base & ".Dcmtos_HDR ef
                                INNER JOIN " & base & ".ECtaCte cf ON cf.ECta_Sis_Emp = ef.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = ef.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = ef.HDoc_Doc_Ano AND cf.ECta_Doc_Num = ef.HDoc_Doc_Num
                                LEFT JOIN " & base & ".ECtaCte cd ON cd.ECta_Sis_Emp = ef.HDoc_Sis_Emp AND cd.ECta_Ref_Cat = ef.HDoc_Doc_Cat AND cd.ECta_Ref_Ano = ef.HDoc_Doc_Ano AND cd.ECta_Ref_Num = ef.HDoc_Doc_Num AND cd.ECta_FecDcmt <= '{fechaFin}' AND NOT(cd.ECta_Doc_Cat = ef.HDoc_Doc_Cat)
                                LEFT JOIN " & base & ".Proveedores lc ON lc.pro_sisemp = ef.HDoc_Sis_Emp AND lc.pro_codigo = ef.HDoc_Emp_Cod
                                LEFT JOIN " & base & ".Catalogos ld ON ld.cat_clase='Defaults' AND ld.cat_sist = 'CUR_LOC'
                                LEFT JOIN " & base & ".Catalogos lm ON lm.cat_clase='Monedas' AND lm.cat_num = ld.cat_clave
                                LEFT JOIN " & base & ".Catalogos lv ON lv.cat_clase='Monedas' AND lv.cat_num = ef.HDoc_Doc_Mon
                            WHERE ef.HDoc_Sis_Emp = {empresa} AND ef.HDoc_Doc_Cat = 44 AND (ef.HDoc_DR2_Fec <='{fechaFin}') AND ef.HDoc_Doc_Status = 1 AND ef.HDoc_RF1_Num = 1
                            GROUP BY ef.HDoc_Doc_Ano, ef.HDoc_Doc_Num
                            HAVING saldo >  1
                     ORDER BY ef.HDoc_Emp_Cod, ef.HDoc_Doc_Fec, ef.HDoc_Doc_Num)l1 "

        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{base}", base)
        strSQL = Replace(strSQL, "{codempresa}", idEmpresa)
        strSQL = Replace(strSQL, "{fechaFin}", dtpFecha.Value.ToString(FORMATO_MYSQL))

        Return strSQL

    End Function

    Private Function sqlOrdenRequisicion(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer) ' Query de Orden de Requisicion
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT 0 Correlativo, IFNULL(gd.idTipo,2) tipo, IFNULL(gd.idGrupo,-2) idGrupo, s1.*, CURRENT_TIMESTAMP "
        strSQL &= "    FROM( "
        strSQL &= "        Select Orden.* "
        strSQL &= "            FROM "
        strSQL &= "                ( Select a.art_codigo, {idemp},h.HDoc_Doc_Cat,h.HDoc_Doc_Ano,h.HDoc_Doc_Num,h.HDoc_Doc_Fec,d.DDoc_Doc_Lin, i.inv_lugarfab, ctg.cat_pid, "
        strSQL &= "                    (If(d.DDoc_Prd_UM =69, d.DDoc_Prd_QTY, (d.DDoc_Prd_QTY *2.2046)) - If(IFNULL(t.DDoc_Prd_UM,0) = 69,(SUM(IFNULL(t.DDoc_Prd_QTY,0))),(SUM(IFNULL(t.DDoc_Prd_QTY,0)*2.2046)))) Saldo, IFNULL(v.pro_proveedor,'') Proveedor, i.inv_provcod, (IF(d.DDoc_RF1_Cod IS NULL,'', CONCAT(d.DDoc_RF1_Cod, IF(h.HDoc_DR1_Num = '','', CONCAT(' / ',h.HDoc_DR1_Num))))) PO, IFNULL(h.HDoc_RF2_Cod,'') Contrato, IFNULL(i.inv_descripcion,'') Yarn_Desc, a.art_DCorta General_Descripcion, IF(h47.HDoc_DR1_Num IS NULL, IFNULL(hc.HDoc_DR1_Num,''), h47.HDoc_DR1_Num) Referencia, IFNULL(hc.HDoc_RF2_Txt,'')LT, IFNULL(( "
        strSQL &= "                        Select cc.ADoc_Dta_Txt "
        strSQL &= "                            From {base}.Dcmtos_ACC cc "
        strSQL &= "                                WHERE cc.ADoc_Sis_Emp = hc.HDoc_Sis_Emp AND cc.ADoc_Doc_Cat = hc.HDoc_Doc_Cat AND cc.ADoc_Doc_Ano = hc.HDoc_Doc_Ano AND cc.ADoc_Doc_Num = hc.HDoc_Doc_Num AND cc.ADoc_Doc_Sub = 'Doc_PFactura' AND cc.ADoc_Doc_Lin = '07'),'') Contenedor, IFNULL(( "
        strSQL &= "                                SELECT nav.cat_desc "
        strSQL &= "                                    From {base}.Catalogos nav "
        strSQL &= "                                        WHERE nav.cat_num = t.DDoc_RF2_Dbl AND nav.cat_clase = 'Naviera' ),'') Naviera, "
        strSQL &= "                                               'PEND. TO SHIP' estado, CONCAT('PEND. TO SHIP',(if(d.DDoc_Prd_Fob = 0,'', '/SOLD'))) estado_Joby, IFNULL(d.DDoc_RF1_Fec,'') ETD, IFNULL(( "
        strSQL &= "                                                    Select cc.ADoc_Dta_Fec "
        strSQL &= "                                                        From {base}.Dcmtos_ACC cc "
        strSQL &= "                                                            WHERE cc.ADoc_Sis_Emp = hc.HDoc_Sis_Emp AND cc.ADoc_Doc_Cat = hc.HDoc_Doc_Cat AND cc.ADoc_Doc_Ano = hc.HDoc_Doc_Ano AND cc.ADoc_Doc_Num = hc.HDoc_Doc_Num AND cc.ADoc_Doc_Sub = 'Doc_PFactura' AND cc.ADoc_Doc_Lin = '15' "
        strSQL &= "                                                                ),'') ETA,  IF(d.DDoc_Prd_PNr IS NULL, 'AVAILABLE', d.DDoc_Prd_PNr) statuss, if( cat1.cat_sist = 'Art_Fibra','FIBER', IFNULL(cat.cat_desc,'')) categoria,ctg.cat_num "
        strSQL &= "                                                                    From {base}.Dcmtos_HDR h "
        strSQL &= "                                                                Left JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num and d.DDoc_RF2_Num = 0 "
        strSQL &= "                                                            Left JOIN {base}.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 127 "
        strSQL &= "                                                            LEFT JOIN {base}.Dcmtos_DTL_Pro p1 ON p1.PDoc_Sis_Emp = p.PDoc_Sis_Emp and p1.PDoc_Par_Cat = p.PDoc_Chi_Cat and p1.PDoc_Par_Ano = p.PDoc_Chi_Ano and p1.PDoc_Par_Num = p.PDoc_Chi_Num and p1.PDoc_Par_Lin = p.PDoc_Chi_Lin and p1.PDoc_Chi_Cat = 55 "
        strSQL &= "                                                            Left JOIN {base}.Dcmtos_DTL_Pro p2 ON p2.PDoc_Sis_Emp = p1.PDoc_Sis_Emp and p2.PDoc_Par_Cat = p1.PDoc_Chi_Cat and p2.PDoc_Par_Ano = p1.PDoc_Chi_Ano and p2.PDoc_Par_Num = p1.PDoc_Chi_Num and p2.PDoc_Par_Lin = p1.PDoc_Chi_Lin and p2.PDoc_Chi_Cat = 180 "
        strSQL &= "                                                            Left JOIN {base}.Dcmtos_DTL_Pro p3 ON p3.PDoc_Sis_Emp = p2.PDoc_Sis_Emp and p3.PDoc_Par_Cat = p2.PDoc_Chi_Cat and p3.PDoc_Par_Ano = p2.PDoc_Chi_Ano and p3.PDoc_Par_Num = p2.PDoc_Chi_Num and p3.PDoc_Par_Lin = p2.PDoc_Chi_Lin and p3.PDoc_Chi_Cat = 47  "
        strSQL &= "                                                            Left JOIN {base}.Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp= p3.PDoc_Sis_Emp and h47.HDoc_Doc_Cat = p3.PDoc_Chi_Cat and h47.HDoc_Doc_Ano = p3.PDoc_Chi_Ano and h47.HDoc_Doc_Num = p3.PDoc_Chi_Num "
        strSQL &= "                                                        Left JOIN {base}.Dcmtos_DTL t ON t.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND t.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND t.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND t.DDoc_Doc_Num = p.PDoc_Chi_Num AND t.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strSQL &= "                                                     Left JOIN {base}.Dcmtos_HDR hc ON hc.HDoc_Sis_Emp = t.DDoc_Sis_Emp AND hc.HDoc_Doc_Cat = t.DDoc_Doc_Cat AND hc.HDoc_Doc_Ano = t.DDoc_Doc_Ano AND hc.HDoc_Doc_Num = t.DDoc_Doc_Num "
        strSQL &= "                                                Left JOIN {base}.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                                            Left JOIN {base}.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                                        Left JOIN {base}.Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = d.DDoc_RF1_Num "
        strSQL &= "                                    Left JOIN {base}.Catalogos cat ON cat.cat_num= a.art_ref and cat.cat_clase = 'Clasificacion' "
        strSQL &= "                                 LEFT JOIN {base}.Catalogos cat1 ON cat1.cat_num = a.art_clase and cat1.cat_clase = 'ClaseArt' "
        strSQL &= "                             Left JOIN {base}.Catalogos ctg ON ctg.cat_num = i.inv_lugarfab and ctg.cat_clase = 'Paises' "
        strSQL &= "                          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 38 AND h.HDoc_Doc_Fec <= '{fecha}' AND h.HDoc_Doc_Status = 1 AND NOT h.HDoc_Ant_Com = 1 AND cat1.cat_sist NOT IN('Art_CHEM','Art_OTHER', 'Art_TELA' ) "
        strSQL &= "                      GROUP BY d.DDoc_Doc_Num, d.DDoc_Doc_Lin) Orden "
        strSQL &= "                 Where Orden.Saldo > 50 and (Orden.cat_pid = 564 OR Orden.cat_num= 3)) s1 "
        strSQL &= "             Left JOIN YarnDivision.Grupo_Detalle gd ON gd.idEmpresa = {idemp} AND gd.Codigo= s1.art_codigo AND gd.idTipo = 2 "

        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{idemp}", idempresa)
        strSQL = Replace(strSQL, "{base}", base)
        strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function

    Private Function sqlConfirmacion(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer) ' Query de Confirmacion de Embarque
        Dim strSQL As String

        strSQL = " SELECT 0 Correlativo, IFNULL(gd.idTipo,2) tipo, IFNULL(gd.idGrupo,-2) idGrupo, s1.*, CURRENT_TIMESTAMP FROM("
        strSQL &= "   SELECT a.art_codigo, {idemp}, ho.HDoc_Doc_Cat, ho.HDoc_Doc_Ano, ho.HDoc_Doc_Num, ho.HDoc_Doc_Fec fecha, dl.DDoc_Doc_Lin linea, inv.inv_lugarfab, ctg.cat_pid, CE.Saldo, IFNULL(pr.pro_proveedor,'') Proveedor, inv.inv_provcod, (IF(dl.DDoc_RF1_Cod IS NULL,'', CONCAT(dl.DDoc_RF1_Cod, IF(ho.HDoc_DR1_Num = '','',CONCAT(' / ',ho.HDoc_DR1_Num))))) PO, IFNULL(ho.HDoc_RF2_Cod,'') Contrato, IFNULL(inv.inv_descripcion,'') Yarn_Desc, a.art_DCorta General_Descripcion, CE.Referencia, CE.LT, CE.Contenedor, CE.Naviera, 'OCEAN' estado, CE.estado_Joby, "
        strSQL &= "      IFNULL(CE.etd,'') ETD, CE.ETA, CE.statuss, IFNULL(cat.cat_desc,'') categoria, ctg.cat_num "
        strSQL &= "         FROM ( "
        strSQL &= "            Select d.DDoc_RF1_Fec etd, h.HDoc_Sis_Emp empresa, d.DDoc_Doc_Cat catalogo, d.DDoc_Doc_Ano anio, d.DDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, (If(d.DDoc_Prd_UM =69, d.DDoc_Prd_QTY, (d.DDoc_Prd_QTY *2.2046)) - If(IFNULL(dtl.DDoc_Prd_UM,0) = 69,(SUM(IFNULL(dtl.DDoc_Prd_QTY,0))),(SUM(IFNULL(dtl.DDoc_Prd_QTY,0)*2.2046)))) Saldo, d.DDoc_Prd_Cod cod, IF(h47.HDoc_DR1_Num IS NULL,IFNULL(h.HDoc_DR1_Num,''),h47.HDoc_DR1_Num) Referencia, IFNULL(h.HDoc_RF2_Txt,'')LT, IFNULL(( "
        strSQL &= "                Select cc.ADoc_Dta_Txt "
        strSQL &= "                    From {base}.Dcmtos_ACC cc "
        strSQL &= "                        WHERE cc.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND cc.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND cc.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND cc.ADoc_Doc_Num = h.HDoc_Doc_Num AND cc.ADoc_Doc_Sub = 'Doc_PFactura' AND cc.ADoc_Doc_Lin = '07' "
        strSQL &= "                            ),'') Contenedor, IFNULL(( "
        strSQL &= "                                SELECT nav.cat_desc "
        strSQL &= "                                    From {base}.Catalogos nav "
        strSQL &= "                                        WHERE nav.cat_num = d.DDoc_RF2_Dbl AND nav.cat_clase = 'Naviera' ),'') Naviera, IFNULL(( "
        strSQL &= "                                             Select cc.ADoc_Dta_Fec "
        strSQL &= "                                                From {base}.Dcmtos_ACC cc "
        strSQL &= "                                                    WHERE cc.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND cc.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND cc.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND cc.ADoc_Doc_Num = h.HDoc_Doc_Num AND cc.ADoc_Doc_Sub = 'Doc_PFactura' AND cc.ADoc_Doc_Lin = '15' "
        strSQL &= "                                                        ),'') ETA, CONCAT('OCEAN',(if(IFNULL(d.DDoc_RF1_Num,0) = 0,'', '/SOLD'))) estado_Joby, IF(d.DDoc_RF2_Cod IS NULL, 'AVAILABLE', d.DDoc_RF2_Cod) statuss "
        strSQL &= "                                                            From {base}.Dcmtos_HDR h "
        '-- CONFIRMACIÓN DE EMBARQUE
        strSQL &= "                                                                Left JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                                                                    Left JOIN {base}.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 55 "
        strSQL &= "                                                                        Left JOIN {base}.Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND dp.PDoc_Par_Cat = p.PDoc_Chi_Cat AND dp.PDoc_Par_Ano = p.PDoc_Chi_Ano AND dp.PDoc_Par_Num = p.PDoc_Chi_Num AND dp.PDoc_Par_Lin = p.PDoc_Chi_Lin AND dp.PDoc_Chi_Cat = 180 "
        strSQL &= "                                                                            Left JOIN {base}.Dcmtos_DTL_Pro t ON t.PDoc_Sis_Emp = dp.PDoc_Sis_Emp AND t.PDoc_Par_Cat = dp.PDoc_Chi_Cat AND t.PDoc_Par_Ano = dp.PDoc_Chi_Ano AND t.PDoc_Par_Num = dp.PDoc_Chi_Num AND t.PDoc_Par_Lin = dp.PDoc_Chi_Lin AND t.PDoc_Chi_Cat = 47 "
        '-- INGRESO A BODEGA
        strSQL &= "                                                                        Left JOIN {base}.Dcmtos_DTL dtl ON dtl.DDoc_Sis_Emp = t.PDoc_Sis_Emp AND dtl.DDoc_Doc_Cat = t.PDoc_Chi_Cat AND dtl.DDoc_Doc_Ano = t.PDoc_Chi_Ano AND dtl.DDoc_Doc_Num= t.PDoc_Chi_Num AND dtl.DDoc_Doc_Lin = t.PDoc_Chi_Lin "
        strSQL &= "                                                                        LEFT JOIN {base}.Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = dtl.DDoc_Sis_Emp and h47.HDoc_Doc_Cat = dtl.DDoc_Doc_Cat and h47.HDoc_Doc_Ano = dtl.DDoc_Doc_Ano and h47.HDoc_Doc_Num = dtl.DDoc_Doc_Num "
        strSQL &= "                                                                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 127 AND h.HDoc_Doc_Fec <= '{fecha}' AND h.HDoc_Doc_Status = 1 "
        strSQL &= "                                                                GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano,d.DDoc_Doc_Num, d.DDoc_Doc_Lin) CE "
        '-- ORDEN DE REQUISICION
        strSQL &= "                                                            Left JOIN {base}.Dcmtos_DTL_Pro m ON m.PDoc_Sis_Emp = CE.empresa AND m.PDoc_Chi_Cat = CE.catalogo AND m.PDoc_Chi_Ano = CE.anio AND m.PDoc_Chi_Num = CE.numero AND m.PDoc_Chi_Lin = CE.linea AND m.PDoc_Par_Cat = 38 "
        strSQL &= "                                                        Left JOIN {base}.Dcmtos_HDR ho ON ho.HDoc_Sis_Emp = m.PDoc_Sis_Emp AND ho.HDoc_Doc_Cat = m.PDoc_Par_Cat AND ho.HDoc_Doc_Ano = m.PDoc_Par_Ano AND ho.HDoc_Doc_Num = m.PDoc_Par_Num AND ho.HDoc_Doc_Status = 1 AND NOT ho.HDoc_Ant_Com = 1 "
        strSQL &= "                                                    Left JOIN {base}.Dcmtos_DTL dl ON dl.DDoc_Sis_Emp = ho.HDoc_Sis_Emp AND dl.DDoc_Doc_Cat = ho.HDoc_Doc_Cat AND dl.DDoc_Doc_Ano = ho.HDoc_Doc_Ano AND dl.DDoc_Doc_Num = ho.HDoc_Doc_Num AND dl.DDoc_Doc_Lin = m.PDoc_Par_Lin "
        strSQL &= "                                                Left JOIN {base}.Proveedores pr ON pr.pro_sisemp = dl.DDoc_Sis_Emp AND pr.pro_codigo = dl.DDoc_RF1_Num "
        strSQL &= "                                            Left JOIN {base}.Inventarios inv ON inv.inv_sisemp = CE.Empresa AND inv.inv_numero = CE.cod "
        strSQL &= "                                        Left JOIN {base}.Articulos a ON a.art_sisemp = inv.inv_sisemp AND a.art_codigo = inv.inv_artcodigo "
        strSQL &= "                                    Left JOIN {base}.Catalogos cat ON cat.cat_num = a.art_ref AND cat.cat_clase = 'Clasificacion' "
        strSQL &= "                                Left JOIN {base}.Catalogos ctg ON ctg.cat_num = inv.inv_lugarfab and ctg.cat_clase = 'Paises' "
        strSQL &= "                            LEFT JOIN {base}.Catalogos cat1 ON cat1.cat_num = a.art_clase and cat1.cat_clase = 'ClaseArt' "
        strSQL &= "                       WHERE CE.Saldo > 50 AND (ctg.cat_pid = 564 OR ctg.cat_num = 3) AND cat1.cat_sist NOT IN('Art_CHEM','Art_OTHER', 'Art_TELA','Art_Fibra')) s1 "
        strSQL &= "                   LEFT JOIN YarnDivision.Grupo_Detalle gd ON gd.idEmpresa = {idemp} AND gd.Codigo= s1.art_codigo AND gd.idTipo = 2 "

        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{idemp}", idempresa)
        strSQL = Replace(strSQL, "{base}", base)
        strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function

    Private Function sqlIngresos(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer) ' Query de Ingresos a Bodega
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT 0 Correlativo, IFNULL(gd.idTipo,2) tipo, IFNULL(gd.idGrupo,-2) idGrupo, s1.*, CURRENT_TIMESTAMP "
        strSQL &= "    FROM( "
        strSQL &= "        Select * "
        strSQL &= "            FROM ( "
        strSQL &= "                Select a.art_codigo, {idemp} Empresa, IFNULL(h.HDoc_Doc_Cat,0) Catalogo, IFNULL(h.HDoc_Doc_Ano,0) Anio, IFNULL(h.HDoc_Doc_Num,0) Numero, IFNULL(h.HDoc_Doc_Fec,'0') Fecha, IFNULL(d.DDoc_Doc_Lin,0) Linea, i.inv_lugarfab, ctg.cat_pid,  IF(tl.DDoc_Prd_UM = 69, tl.DDoc_Prd_QTY, (tl.DDoc_Prd_QTY *2.2046)) - ( "
        strSQL &= "                    Select IFNULL(SUM(tll.DDoc_Prd_QTY),0) * (IF(tll.DDoc_Prd_UM = 69,1,2.2046)) Saldo "
        strSQL &= "                        From {base}.Dcmtos_DTL_Pro pro "
        strSQL &= "                            Left JOIN {base}.Dcmtos_HDR dr1 ON dr1.HDoc_Sis_Emp = pro.PDoc_Sis_Emp AND dr1.HDoc_Doc_Cat = pro.PDoc_Chi_Cat AND dr1.HDoc_Doc_Ano = pro.PDoc_Chi_Ano AND dr1.HDoc_Doc_Num = pro.PDoc_Chi_Num "
        strSQL &= "                                Left JOIN {base}.Dcmtos_DTL tll ON tll.DDoc_Sis_Emp = pro.PDoc_Sis_Emp AND tll.DDoc_Doc_Cat = pro.PDoc_Chi_Cat AND tll.DDoc_Doc_Ano = pro.PDoc_Chi_Ano AND tll.DDoc_Doc_Num = pro.PDoc_Chi_Num AND tll.DDoc_Doc_Lin = pro.PDoc_Chi_Lin "
        strSQL &= "                                    WHERE pro.PDoc_Sis_Emp = tl.DDoc_Sis_Emp AND pro.PDoc_Par_Cat = tl.DDoc_Doc_Cat AND pro.PDoc_Par_Ano = tl.DDoc_Doc_Ano AND pro.PDoc_Par_Num = tl.DDoc_Doc_Num AND pro.PDoc_Par_Lin = tl.DDoc_Doc_Lin AND pro.PDoc_Chi_Cat = 48 AND dr1.HDoc_Doc_Status = 1) Saldo, IFNULL(pr.pro_proveedor ,'') Proveedor, i.inv_provcod,  (IF(d.DDoc_RF1_Cod IS NULL,'', CONCAT(d.DDoc_RF1_Cod,IF(h.HDoc_DR1_Num = '','', CONCAT(' / ',h.HDoc_DR1_Num))) ))PO, IFNULL(h.HDoc_RF2_Cod,'') Contrato, IFNULL(i.inv_descripcion,'') Yarn_Desc, a.art_DCorta General_Descripcion, IFNULL(dr.HDoc_DR1_Num,'') Referencia, IFNULL(hr.HDoc_RF2_Txt,'')LT, IFNULL(( "
        strSQL &= "                                        Select cc.ADoc_Dta_Txt "
        strSQL &= "                                            From {base}.Dcmtos_ACC cc "
        strSQL &= "                                                WHERE cc.ADoc_Sis_Emp = hr.HDoc_Sis_Emp AND cc.ADoc_Doc_Cat = hr.HDoc_Doc_Cat AND cc.ADoc_Doc_Ano = hr.HDoc_Doc_Ano AND cc.ADoc_Doc_Num = hr.HDoc_Doc_Num AND cc.ADoc_Doc_Sub = 'Doc_PFactura' AND cc.ADoc_Doc_Lin = '07' "
        strSQL &= "                                                    ),'') Contenedor, IFNULL(( "
        strSQL &= "                                SELECT nav.cat_desc "
        strSQL &= "                                    From {base}.Catalogos nav "
        strSQL &= "                                        WHERE nav.cat_num = dl.DDoc_RF2_Dbl AND nav.cat_clase = 'Naviera' ),'') Naviera, "
        strSQL &= "                                                                    'WAREHOUSE' estado, CONCAT('WAREHOUSE',(SELECT IF(COUNT(*) = 0,'','/SOLD') FROM {base}.Reserva rc "
        strSQL &= "                                                                    WHERE rc.id_empresa=  tl.DDoc_Sis_Emp AND rc.doc_tipo = tl.DDoc_Doc_Cat AND rc.doc_ciclo = tl.DDoc_Doc_Ano AND rc.doc_num = tl.DDoc_Doc_Num AND rc.doc_lin = tl.DDoc_Doc_Lin AND rc.estado = 0)) estado_Joby, IFNULL(dl.DDoc_RF1_Fec,'') ETD, IFNULL(( "
        strSQL &= "                                                                        Select cc.ADoc_Dta_Fec "
        strSQL &= "                                                                            From {base}.Dcmtos_ACC cc "
        strSQL &= "                                                                                WHERE cc.ADoc_Sis_Emp = hr.HDoc_Sis_Emp AND cc.ADoc_Doc_Cat = hr.HDoc_Doc_Cat AND cc.ADoc_Doc_Ano = hr.HDoc_Doc_Ano AND cc.ADoc_Doc_Num = hr.HDoc_Doc_Num AND cc.ADoc_Doc_Sub = 'Doc_PFactura' AND cc.ADoc_Doc_Lin = '15' "
        strSQL &= "                                                                                    ),'') ETA, "
        strSQL &= "                                                                           IFNULL(( "
        strSQL &= "                                                                           Select GROUP_CONCAT(DISTINCT rc.nombre ORDER BY rc.nombre SEPARATOR ' | ') "
        strSQL &= "                                                                           From {base}.Reserva rc "
        strSQL &= "                                                                           WHERE rc.id_empresa = tl.DDoc_Sis_Emp AND rc.doc_tipo = tl.DDoc_Doc_Cat AND rc.doc_ciclo = tl.DDoc_Doc_Ano AND rc.doc_num = tl.DDoc_Doc_Num  AND rc.doc_lin = tl.DDoc_Doc_Lin AND rc.estado = 0 "
        strSQL &= "                                                                           Group by rc.doc_ciclo,rc.doc_num,rc.doc_lin),'AVAILABLE') statuss, IFNULL(cat.cat_desc,'') categoria, ctg.cat_num "
        strSQL &= "                                                                                        From {base}.Dcmtos_HDR dr "
        strSQL &= "                                                                                            Left JOIN {base}.Dcmtos_DTL tl ON tl.DDoc_Sis_Emp = dr.HDoc_Sis_Emp AND tl.DDoc_Doc_Cat = dr.HDoc_Doc_Cat AND tl.DDoc_Doc_Ano = dr.HDoc_Doc_Ano AND tl.DDoc_Doc_Num = dr.HDoc_Doc_Num "
        '-- De ingreso a poliza
        strSQL &= "                                                                                                Left JOIN {base}.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = tl.DDoc_Sis_Emp and p.PDoc_Chi_Cat = tl.DDoc_Doc_Cat and p.PDoc_Chi_Ano = tl.DDoc_Doc_Ano and p.PDoc_Chi_Num = tl.DDoc_Doc_Num and p.PDoc_Chi_Lin = tl.DDoc_Doc_Lin and p.PDoc_Par_Cat = 180 "
        '-- De póliza a Datos para póliza
        strSQL &= "                                                                                                    Left JOIN {base}.Dcmtos_DTL_Pro p1 ON p1.PDoc_Sis_Emp = p.PDoc_Sis_Emp and p1.PDoc_Chi_Cat = p.PDoc_Par_Cat and p1.PDoc_Chi_Ano = p.PDoc_Par_Ano and p1.PDoc_Chi_Num = p.PDoc_Par_Num and p1.PDoc_Chi_Lin = p.PDoc_Par_Lin and p1.PDoc_Par_Cat = 55 "
        '-- De Datos para póliza a Confirmacion
        strSQL &= "                                                                                                        Left JOIN {base}.Dcmtos_DTL_Pro p2 ON p2.PDoc_Sis_Emp = p1.PDoc_Sis_Emp and p2.PDoc_Chi_Cat = p1.PDoc_Par_Cat and p2.PDoc_Chi_Ano = p1.PDoc_Par_Ano and p2.PDoc_Chi_Num = p1.PDoc_Par_Num and p2.PDoc_Chi_Lin = p1.PDoc_Par_Lin and p2.PDoc_Par_Cat = 127 "
        '-- Encabezado y Detalle de Confirmación
        strSQL &= "                                                                                                    Left JOIN {base}.Dcmtos_DTL dl ON dl.DDoc_Sis_Emp = p2.PDoc_Sis_Emp and dl.DDoc_Doc_Cat = p2.PDoc_Par_Cat and dl.DDoc_Doc_Ano = p2.PDoc_Par_Ano and dl.DDoc_Doc_Num = p2.PDoc_Par_Num and dl.DDoc_Doc_Lin = p2.PDoc_Par_Lin "
        strSQL &= "                                                                                                Left JOIN {base}.Dcmtos_HDR hr ON hr.HDoc_Sis_Emp = dl.DDoc_Sis_Emp and hr.HDoc_Doc_Cat = dl.DDoc_Doc_Cat and hr.HDoc_Doc_Ano = dl.DDoc_Doc_Ano and dl.DDoc_Doc_Num = hr.HDoc_Doc_Num "
        '-- De Confirmación a Orden de Requisición
        strSQL &= "                                                                                            Left JOIN {base}.Dcmtos_DTL_Pro p3 ON p3.PDoc_Sis_Emp = p2.PDoc_Sis_Emp and p3.PDoc_Chi_Cat = p2.PDoc_Par_Cat and p3.PDoc_Chi_Ano = p2.PDoc_Par_Ano and p3.PDoc_Chi_Num = p2.PDoc_Par_Num and p3.PDoc_Chi_Lin = p2.PDoc_Par_Lin and p3.PDoc_Par_Cat = 38 "
        '-- Encabezado y Detalle de Orden de Requisicion
        strSQL &= "                                                                                        Left JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = p3.PDoc_Sis_Emp and d.DDoc_Doc_Cat = p3.PDoc_Par_Cat and d.DDoc_Doc_Ano = p3.PDoc_Par_Ano and d.DDoc_Doc_Num = p3.PDoc_Par_Num and d.DDoc_Doc_Lin = p3.PDoc_Par_Lin "
        strSQL &= "                                                                                    Left JOIN {base}.Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num AND h.HDoc_Doc_Status = 1 AND NOT h.HDoc_Ant_Com = 1 "
        strSQL &= "                                                                                Left JOIN {base}.Proveedores pr ON pr.pro_sisemp = d.DDoc_Sis_Emp AND pr.pro_codigo = d.DDoc_RF1_Num "
        strSQL &= "                                                                            Left JOIN {base}.Inventarios i ON i.inv_sisemp = tl.DDoc_Sis_Emp and i.inv_numero = tl.DDoc_Prd_Cod "
        strSQL &= "                                                                        Left JOIN {base}.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                                                                    Left JOIN {base}.Catalogos cat ON cat.cat_num = a.art_ref AND cat.cat_clase = 'Clasificacion' "
        strSQL &= "                                                                Left JOIN {base}.Catalogos ctg ON ctg.cat_num = i.inv_lugarfab and ctg.cat_clase = 'Paises' "
        strSQL &= "                                                              LEFT JOIN {base}.Catalogos cat1 ON cat1.cat_num = a.art_clase and cat1.cat_clase = 'ClaseArt' "
        strSQL &= "                                                           WHERE dr.HDoc_Sis_Emp = {empresa} AND dr.HDoc_Doc_Cat = 47 AND dr.HDoc_Doc_Fec <= '{fecha}' and (ctg.cat_pid = 564 OR ctg.cat_num = 3) AND cat1.cat_sist NOT IN('Art_CHEM','Art_OTHER', 'Art_TELA','Art_Fibra','Art_empaque') "
        strSQL &= "                                                       GROUP BY tl.DDoc_Doc_Ano, tl.DDoc_Doc_Num,tl.DDoc_Doc_Lin) s1 "
        strSQL &= "                                                   WHERE s1.Saldo > 50) s1 "
        strSQL &= "                                               Left Join YarnDivision.Grupo_Detalle gd ON gd.idEmpresa = {idemp} And gd.Codigo= s1.art_codigo And gd.idTipo = 2 "

        strSQL = Replace(strSQL, "{empresa}", codEmpresa)
        strSQL = Replace(strSQL, "{idemp}", idempresa)
        strSQL = Replace(strSQL, "{base}", base)
        strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))

        Return strSQL

    End Function

    Private Function sqlVentasCompanie(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strSQL As String = STR_VACIO

        Try

            strSQL = "SELECT 0,{codempresa},a.*, IFNULL(s.cat_clave,'') origen,c.cli_codigo idCliente, c.cli_cliente nombre, CONCAT(u.per_nombre1,' ',u.per_apellido1) usuario,now()
                FROM (
                SELECT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano ciclo, e.HDoc_Doc_Fec fecha, e.HDoc_Doc_Num numero, e.HDoc_DR1_Dbl num2, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, IFNULL(d.DDoc_RF1_Txt,'') Referencia, SUM((d.DDoc_Prd_QTY - d.DDoc_RF2_Dbl) * m.cat_sist) cantidad, IF(SUM(d.DDoc_Prd_QTY - d.DDoc_RF2_Dbl)>0,(d.DDoc_Prd_NET / m.cat_sist),0) precio, COALESCE(l.cat_clave,'') medida, ROUND(SUM((d.DDoc_Prd_QTY - d.DDoc_RF2_Dbl) * d.DDoc_Prd_NET),2) total,po.pro_proveedor mill
                FROM {base}.Dcmtos_DTL d
                INNER JOIN {base}.Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num
                LEFT JOIN {base}.Catalogos m ON m.cat_clase='Medidas' AND m.cat_num = d.DDoc_Prd_UM
                LEFT JOIN {base}.Catalogos l ON l.cat_clase='Medidas' AND l.cat_sist = 1
                LEFT JOIN {base}.Inventarios iv ON iv.inv_sisemp = d.DDoc_Sis_Emp AND iv.inv_numero = d.DDoc_Prd_Cod
                LEFT JOIN {base}.Proveedores po ON po.pro_sisemp = iv.inv_sisemp AND po.pro_codigo = iv.inv_provcod
                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 395 AND (e.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}') AND e.HDoc_Doc_Status = 1
                GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin
                ORDER BY e.HDoc_Emp_Nom, d.DDoc_Doc_Num, d.DDoc_Doc_Lin) a
                LEFT JOIN {base}.Dcmtos_DTL_Pro rf ON rf.PDoc_Sis_Emp = a.empresa AND rf.PDoc_Chi_Cat = a.tipo AND rf.PDoc_Chi_Ano = a.ciclo AND rf.PDoc_Chi_Num = a.numero AND rf.PDoc_Chi_Lin = a.linea
                LEFT JOIN {base}.Dcmtos_DTL_Pro ri ON ri.PDoc_Sis_Emp = rf.PDoc_Sis_Emp AND ri.PDoc_Chi_Cat = rf.PDoc_Par_Cat AND ri.PDoc_Chi_Ano = rf.PDoc_Par_Ano AND ri.PDoc_Chi_Num = rf.PDoc_Par_Num AND ri.PDoc_Chi_Lin = rf.PDoc_Par_Lin
                LEFT JOIN {base}.Dcmtos_DTL_Pro rp ON rp.PDoc_Sis_Emp = ri.PDoc_Sis_Emp AND rp.PDoc_Chi_Cat = ri.PDoc_Par_Cat AND rp.PDoc_Chi_Ano = ri.PDoc_Par_Ano AND rp.PDoc_Chi_Num = ri.PDoc_Par_Num AND rp.PDoc_Chi_Lin = ri.PDoc_Par_Lin AND rp.PDoc_Par_Cat = 75
                LEFT JOIN {base}.Dcmtos_HDR p ON p.HDoc_Sis_Emp = rp.PDoc_Sis_Emp AND p.HDoc_Doc_Cat = rp.PDoc_Par_Cat AND p.HDoc_Doc_Ano = rp.PDoc_Par_Ano AND p.HDoc_Doc_Num = rp.PDoc_Par_Num
                LEFT JOIN {base}.Personal u ON u.per_sisemp = a.empresa AND u.per_usuario = p.HDoc_Usuario
                LEFT JOIN {base}.Clientes c ON c.cli_sisemp = p.HDoc_Sis_Emp AND c.cli_codigo = p.HDoc_DR1_Emp
                LEFT JOIN {base}.Inventarios i ON i.inv_sisemp = a.empresa AND i.inv_numero = a.codigo
        
                LEFT JOIN {base}.Articulos  ar ON ar.art_sisemp = i.inv_sisemp AND ar.art_codigo = i.inv_artcodigo 
                LEFT JOIN {base}.Catalogos car ON car.cat_num = ar.art_clase  
                

                LEFT JOIN {base}.Catalogos s ON s.cat_clase = 'Paises' AND s.cat_num = i.inv_lugarfab
                WHERE car.cat_sist NOT IN ('Art_CHEM')
                ORDER BY idCliente "


            strSQL = Replace(strSQL, "{base}", base)
            strSQL = Replace(strSQL, "{empresa}", idempresa)
            strSQL = Replace(strSQL, "{codempresa}", codEmpresa)
            strSQL = Replace(strSQL, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", Ffin.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strSQL

    End Function

    Private Function sqlVentaGross(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Finicio As Date, ByVal Ffin As Date, ByVal Conta As String) As String
        Dim strSQl As String = STR_VACIO
        Try

            strSQl = " SELECT 0,dg.idGrupo, l1.*, ROUND((l1.precio-l1.costo),2) variacion, ROUND(IFNULL(((l1.precio-l1.costo)/l1.precio)*100,0),2) margen, now()"
            strSQl &= "  FROM ("
            strSQl &= "  SELECT {codempresa} id, h.HDoc_DR1_Emp Codigo, IFNULL(v.inv_fecha,'') fecha_Cod, 0 lb_Devueltas,h.HDoc_Doc_Cat cat, h.HDoc_Doc_Num numero, IFNULL(d.DDoc_Doc_Lin,'') DDoc_Doc_Lin, h.HDoc_DR1_Dbl numero2, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom cliente, IFNULL(a.art_DCorta,'') descripcion, IFNULL(c.cat_clave,'') origen, IFNULL(r.pro_proveedor,' ') fabricante, IFNULL(d.DDoc_RF1_Txt,'') referencia, IFNULL(IF(cc.cat_sist=0,1,cc.cat_sist),0) factor, IFNULL(cc.cat_clave,'') medida, IFNULL(d.DDoc_Prd_QTY,0) cantidad, IFNULL(d.DDoc_Prd_NET,0) precio, IF(a.art_clase = 330, IFNULL(nq.NombreIngles,''), IFNULL(n.NombreIngles,'')) NombreCosto, IF(a.art_clase = 330, IFNULL(nqv.NombreIngles,''), IFNULL(n1.NombreIngles,'')) NombreVenta, IFNULL(IFNULL(c4.cat_desc,r.pro_codigo),'') Intercompany,"
            strSQl &= "    if(r.pro_codigo IN("
            strSQl &= "   SELECT pp.cat_pid"
            strSQl &= "   FROM {base}.Catalogos pp"
            strSQl &= "   WHERE pp.cat_sisemp = {empresa} AND pp.cat_clase = 'Intercompany' AND pp.cat_desc LIKE '{intercompany}'),r.pro_nombre,'ALL') Tipo, IFNULL(("
            strSQl &= "   SELECT di.DDoc_Prd_NET"
            strSQl &= "   FROM {base}.Dcmtos_DTL_Pro p"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro f ON f.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND f.PDoc_Chi_Cat = p.PDoc_Par_Cat AND f.PDoc_Chi_Ano = p.PDoc_Par_Ano AND f.PDoc_Chi_Num = p.PDoc_Par_Num AND f.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = f.PDoc_Par_Cat AND i.PDoc_Chi_Ano = f.PDoc_Par_Ano AND i.PDoc_Chi_Num = f.PDoc_Par_Num AND i.PDoc_Chi_Lin = f.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL di ON di.DDoc_Sis_Emp = i.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = i.PDoc_Par_Cat AND di.DDoc_Doc_Ano = i.PDoc_Par_Ano AND di.DDoc_Doc_Num =i.PDoc_Par_Num AND di.DDoc_Doc_Lin = i.PDoc_Par_Lin"
            strSQl &= "   WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin),0) Costo, IFNULL(("
            strSQl &= "   SELECT hi.HDoc_Doc_Fec"
            strSQl &= "   FROM {base}.Dcmtos_DTL_Pro p"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro f ON f.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND f.PDoc_Chi_Cat = p.PDoc_Par_Cat AND f.PDoc_Chi_Ano = p.PDoc_Par_Ano AND f.PDoc_Chi_Num = p.PDoc_Par_Num AND f.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = f.PDoc_Par_Cat AND i.PDoc_Chi_Ano = f.PDoc_Par_Ano AND i.PDoc_Chi_Num = f.PDoc_Par_Num AND i.PDoc_Chi_Lin = f.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_HDR hi ON hi.HDoc_Sis_Emp = i.PDoc_Sis_Emp AND hi.HDoc_Doc_Cat = i.PDoc_Par_Cat AND hi.HDoc_Doc_Ano = i.PDoc_Par_Ano AND hi.HDoc_Doc_Num =i.PDoc_Par_Num"
            strSQl &= "   WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin),0) Fecha_Ing, IFNULL(("
            strSQl &= "   SELECT hi.HDoc_Emp_Nom"
            strSQl &= "   FROM {base}.Dcmtos_DTL_Pro p"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro f ON f.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND f.PDoc_Chi_Cat = p.PDoc_Par_Cat AND f.PDoc_Chi_Ano = p.PDoc_Par_Ano AND f.PDoc_Chi_Num = p.PDoc_Par_Num AND f.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = f.PDoc_Par_Cat AND i.PDoc_Chi_Ano = f.PDoc_Par_Ano AND i.PDoc_Chi_Num = f.PDoc_Par_Num AND i.PDoc_Chi_Lin = f.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_HDR hi ON hi.HDoc_Sis_Emp = i.PDoc_Sis_Emp AND hi.HDoc_Doc_Cat = i.PDoc_Par_Cat AND hi.HDoc_Doc_Ano = i.PDoc_Par_Ano AND hi.HDoc_Doc_Num =i.PDoc_Par_Num"
            strSQl &= "   WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin),'') Proveedor, IFNULL(c2.cat_desc,'') Clasificacion, IFNULL(("
            strSQl &= "   SELECT di.DDoc_Prd_Ref"
            strSQl &= "   FROM {base}.Dcmtos_DTL_Pro p"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro f ON f.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND f.PDoc_Chi_Cat = p.PDoc_Par_Cat AND f.PDoc_Chi_Ano = p.PDoc_Par_Ano AND f.PDoc_Chi_Num = p.PDoc_Par_Num AND f.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = f.PDoc_Par_Cat AND i.PDoc_Chi_Ano = f.PDoc_Par_Ano AND i.PDoc_Chi_Num = f.PDoc_Par_Num AND i.PDoc_Chi_Lin = f.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL di ON di.DDoc_Sis_Emp = i.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = i.PDoc_Par_Cat AND di.DDoc_Doc_Ano = i.PDoc_Par_Ano AND di.DDoc_Doc_Num =i.PDoc_Par_Num AND di.DDoc_Doc_Lin = i.PDoc_Par_Lin"
            strSQl &= "   WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin),0) MKT, IFNULL(("
            strSQl &= "   SELECT hdr38.HDoc_RF2_Cod"
            strSQl &= "   FROM {base}.Dcmtos_DTL_Pro par36"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro par48 ON par36.PDoc_Sis_Emp=par48.PDoc_Sis_Emp AND par36.PDoc_Par_Ano=par48.PDoc_Chi_Ano AND par36.PDoc_Par_Cat=par48.PDoc_Chi_Cat AND par36.PDoc_Par_Num=par48.PDoc_Chi_Num AND par36.PDoc_Par_Lin=par48.PDoc_Chi_Lin AND par48.PDoc_Par_Cat=48"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro par47 ON par48.PDoc_Sis_Emp=par47.PDoc_Sis_Emp AND par48.PDoc_Par_Ano=par47.PDoc_Chi_Ano AND par48.PDoc_Par_Cat=par47.PDoc_Chi_Cat AND par48.PDoc_Par_Num=par47.PDoc_Chi_Num AND par48.PDoc_Par_Lin=par47.PDoc_Chi_Lin AND par47.PDoc_Par_Cat=47"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro par180 ON par47.PDoc_Sis_Emp=par180.PDoc_Sis_Emp AND par47.PDoc_Par_Ano=par180.PDoc_Chi_Ano AND par47.PDoc_Par_Cat=par180.PDoc_Chi_Cat AND par47.PDoc_Par_Num=par180.PDoc_Chi_Num AND par47.PDoc_Par_Lin=par180.PDoc_Chi_Lin AND par180.PDoc_Par_Cat=180"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro par55 ON par180.PDoc_Sis_Emp=par55.PDoc_Sis_Emp AND par180.PDoc_Par_Ano=par55.PDoc_Chi_Ano AND par180.PDoc_Par_Cat=par55.PDoc_Chi_Cat AND par180.PDoc_Par_Num=par55.PDoc_Chi_Num AND par180.PDoc_Par_Lin=par55.PDoc_Chi_Lin AND par55.PDoc_Par_Cat=55"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro par127 ON par55.PDoc_Sis_Emp=par127.PDoc_Sis_Emp AND par55.PDoc_Par_Ano=par127.PDoc_Chi_Ano AND par55.PDoc_Par_Cat=par127.PDoc_Chi_Cat AND par55.PDoc_Par_Num=par127.PDoc_Chi_Num AND par55.PDoc_Par_Lin=par127.PDoc_Chi_Lin AND par127.PDoc_Par_Cat=127"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro par38 ON par127.PDoc_Sis_Emp=par38.PDoc_Sis_Emp AND par127.PDoc_Par_Ano=par38.PDoc_Chi_Ano AND par127.PDoc_Par_Cat=par38.PDoc_Chi_Cat AND par127.PDoc_Par_Num=par38.PDoc_Chi_Num AND par127.PDoc_Par_Lin=par38.PDoc_Chi_Lin AND par38.PDoc_Par_Cat=38"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_HDR hdr38 ON par38.PDoc_Sis_Emp=hdr38.HDoc_Sis_Emp AND par38.PDoc_Par_Ano=hdr38.HDoc_Doc_Ano AND par38.PDoc_Par_Cat=hdr38.HDoc_Doc_Cat AND par38.PDoc_Par_Num=hdr38.HDoc_Doc_Num"
            strSQl &= "   WHERE par36.PDoc_Sis_Emp= d.DDoc_Sis_Emp AND par36.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND par36.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND par36.PDoc_Chi_Num= d.DDoc_Doc_Num AND par36.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
            strSQl &= "   			),'') contractNumber, IFNULL(("
            strSQl &= "   SELECT hi.HDoc_Doc_TC"
            strSQl &= "   FROM {base}.Dcmtos_DTL_Pro p"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro f ON f.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND f.PDoc_Chi_Cat = p.PDoc_Par_Cat AND f.PDoc_Chi_Ano = p.PDoc_Par_Ano AND f.PDoc_Chi_Num = p.PDoc_Par_Num AND f.PDoc_Chi_Lin = p.PDoc_Par_Lin"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = f.PDoc_Par_Cat AND i.PDoc_Chi_Ano = f.PDoc_Par_Ano AND i.PDoc_Chi_Num = f.PDoc_Par_Num AND i.PDoc_Chi_Lin = f.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_HDR hi ON hi.HDoc_Sis_Emp = i.PDoc_Sis_Emp AND hi.HDoc_Doc_Cat = i.PDoc_Par_Cat AND hi.HDoc_Doc_Ano = i.PDoc_Par_Ano AND hi.HDoc_Doc_Num =i.PDoc_Par_Num"
            strSQl &= "   WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin),'') Tasa,'' Estado, IFNULL(cl.cli_nombre,'')  DCorta"
            strSQl &= "   FROM {base}.Dcmtos_HDR h"
            strSQl &= "   LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
            strSQl &= "   LEFT JOIN {base}.Clientes cl ON cl.cli_sisemp = h.HDoc_Sis_Emp AND cl.cli_codigo = h.HDoc_Emp_Cod "
            strSQl &= "   LEFT JOIN {base}.Inventarios v ON v.inv_sisemp = d.DDoc_Sis_Emp AND v.inv_numero = d.DDoc_Prd_Cod"
            strSQl &= "   LEFT JOIN {base}.Articulos a ON a.art_sisemp = v.inv_sisemp AND a.art_codigo = v.inv_artcodigo"
            strSQl &= "   LEFT JOIN {base}.Catalogos c ON c.cat_num = v.inv_lugarfab"
            strSQl &= "   LEFT JOIN {base}.Proveedores r ON r.pro_sisemp = v.inv_sisemp AND r.pro_codigo = v.inv_provcod"
            strSQl &= "   LEFT JOIN {base}.Catalogos cc ON cc.cat_num = d.DDoc_Prd_UM"
            strSQl &= "   LEFT JOIN {base}.Catalogos c2 ON c2.cat_clase = 'ClaseArt' AND c2.cat_num = a.art_clase"
            strSQl &= "   LEFT JOIN {base}.Catalogos gs ON gs.cat_num = v.inv_lugarfab AND gs.cat_clase = 'Paises'"
            strSQl &= "   LEFT JOIN {conta}.inventario_codigos os ON os.clase = gs.cat_sisemp"
            strSQl &= "   LEFT JOIN {conta}.inventario_codigos ic ON ic.clase = a.art_clase"
            strSQl &= "   LEFT JOIN {conta}.cuentas cq ON cq.id_cuenta = ic.costo"
            strSQl &= "   LEFT JOIN {conta}.nomenclatura nq ON nq.idCuenta = cq.id_nomenclatura"
            strSQl &= "   LEFT JOIN {conta}.cuentas cqv ON cqv.id_cuenta = ic.venta"
            strSQl &= "   LEFT JOIN {conta}.nomenclatura nqv ON nqv.idCuenta = cqv.id_nomenclatura"
            strSQl &= "   LEFT JOIN {conta}.cuentas c1 ON c1.id_cuenta = os.costo"
            strSQl &= "   LEFT JOIN {conta}.nomenclatura n ON n.idCuenta = c1.id_nomenclatura"
            strSQl &= "   LEFT JOIN {conta}.cuentas c3 ON c3.id_cuenta = os.venta"
            strSQl &= "   LEFT JOIN {conta}.nomenclatura n1 ON n1.idCuenta = c3.id_nomenclatura"
            strSQl &= "   LEFT JOIN {base}.Catalogos c4 ON c4.cat_clase = 'ClassYRM' AND c4.cat_num = h.HDoc_DR2_Emp"
            strSQl &= "   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 395 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' AND h.HDoc_Doc_Status = 1 "
            strSQl &= "            UNION"
            strSQl &= "            SELECT {codempresa} id, h.HDoc_DR1_Emp Codigo, IFNULL(v.inv_fecha,'') fecha_Cod, (d.DDoc_Prd_Cif * -1) lb_Devueltas,h.HDoc_Doc_Cat cat, IFNULL(hf.HDoc_Doc_Num,0) numero, IFNULL(d.DDoc_Doc_Lin,'') DDoc_Doc_Lin, IFNULL(hf.HDoc_DR1_Dbl,0) numero2, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom cliente, IFNULL(CONCAT('NOTA DE CRÉDITO NO.',' / ', {num},' / ', d.DDoc_Prd_Des,' / FACTURA:',' ', hf.HDoc_Doc_Num),0) descripcion, '' origen, IFNULL(r.pro_proveedor,' ') fabricante, IFNULL(hf.HDoc_DR1_Num,0) referencia,'' Factor,''medida, d.DDoc_Prd_QTY cantidad, IFNULL(d.DDoc_Prd_NET,0) precio,IF(a.art_clase = 330, IFNULL(nq.NombreIngles,''), IFNULL(n.NombreIngles,'')) NombreCosto, IF(a.art_clase = 330, IFNULL(nqv.NombreIngles,''), IFNULL(n1.NombreIngles,'')) NombreVenta, IFNULL(IFNULL(c4.cat_desc,r.pro_codigo),'') intercompany,"
            strSQl &= "             if(r.pro_codigo IN("
            strSQl &= "            SELECT pp.cat_pid"
            strSQl &= "            FROM {base}.Catalogos pp"
            strSQl &= "            WHERE pp.cat_sisemp = {empresa} AND pp.cat_clase = 'Intercompany' AND pp.cat_desc LIKE '{intercompany}'),r.pro_nombre,'ALL') Tipo,"
            strSQl &= "             1 costo,'','', IFNULL(c2.cat_desc,'') Clasificacion,'','',0,'' Estado, IFNULL(cl.cli_nombre,'') DCorta"
            strSQl &= "            FROM {base}.Dcmtos_HDR h"
            strSQl &= "            LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
            strSQl &= "            LEFT JOIN {base}.ECtaCte e ON e.ECta_Sis_Emp = d.DDoc_Sis_Emp AND e.ECta_Doc_Cat = d.DDoc_Doc_Cat AND e.ECta_Doc_Ano = d.DDoc_Doc_Ano AND e.ECta_Doc_Num = d.DDoc_Doc_Num AND IF(d.DDoc_Prd_Cod = 0 OR d.DDoc_Prd_Cod IS NULL,e.ECta_Doc_Lin = 1,e.ECta_Doc_Lin = d.DDoc_Prd_Cod)"
            strSQl &= "            LEFT JOIN {base}.Dcmtos_HDR hf ON hf.HDoc_Sis_Emp = e.ECta_Sis_Emp AND hf.HDoc_Doc_Cat = e.ECta_Ref_Cat AND hf.HDoc_Doc_Ano = e.ECta_Ref_Ano AND hf.HDoc_Doc_Num = e.ECta_Ref_Num"
            strSQl &= "            LEFT JOIN {base}.Dcmtos_DTL df ON df.DDoc_Sis_Emp = hf.HDoc_Sis_Emp AND df.DDoc_Doc_Cat = hf.HDoc_Doc_Cat AND df.DDoc_Doc_Ano = hf.HDoc_Doc_Ano AND df.DDoc_Doc_Num = hf.HDoc_Doc_Num AND df.DDoc_Doc_Lin = e.ECta_Doc_Lin"
            strSQl &= "            LEFT JOIN {base}.Dcmtos_DTL_Pro dpy ON dpy.PDoc_Sis_Emp = df.DDoc_Sis_Emp AND dpy.PDoc_Par_Cat = df.DDoc_Doc_Cat AND dpy.PDoc_Par_Ano = df.DDoc_Doc_Ano AND dpy.PDoc_Par_Num = df.DDoc_Doc_Num AND dpy.PDoc_Chi_Cat = 395"
            strSQl &= "            LEFT JOIN {base}.Dcmtos_HDR hy ON hy.HDoc_Sis_Emp = dpy.PDoc_Sis_Emp AND hy.HDoc_Doc_Cat = dpy.PDoc_Chi_Cat AND hy.HDoc_Doc_Ano = dpy.PDoc_Chi_Ano AND hy.HDoc_Doc_Num = dpy.PDoc_Chi_Num"
            strSQl &= "            LEFT JOIN {base}.Clientes cl ON cl.cli_sisemp = h.HDoc_Sis_Emp AND cl.cli_codigo = h.HDoc_Emp_Cod"
            strSQl &= "            LEFT JOIN {base}.Inventarios v ON v.inv_sisemp = d.DDoc_Sis_Emp AND v.inv_numero = df.DDoc_Prd_Cod"
            strSQl &= "            LEFT JOIN {base}.Articulos a ON a.art_sisemp = v.inv_sisemp AND a.art_codigo = v.inv_artcodigo"
            strSQl &= "            LEFT JOIN {base}.Proveedores r ON r.pro_sisemp = v.inv_sisemp AND r.pro_codigo = v.inv_provcod"
            strSQl &= "            LEFT JOIN {base}.Catalogos c2 ON c2.cat_clase = 'ClaseArt' AND c2.cat_num = a.art_clase"
            strSQl &= "            LEFT JOIN {base}.Catalogos gs ON gs.cat_num = v.inv_lugarfab AND gs.cat_clase = 'Paises'"
            strSQl &= "            LEFT JOIN {conta}.inventario_codigos os ON os.clase = gs.cat_sisemp"
            strSQl &= "            LEFT JOIN {conta}.inventario_codigos ic ON ic.clase = a.art_codigo"
            strSQl &= "            LEFT JOIN {conta}.cuentas cq ON cq.id_cuenta = ic.costo"
            strSQl &= "            LEFT JOIN {conta}.nomenclatura nq ON nq.idCuenta = cq.id_nomenclatura"
            strSQl &= "            LEFT JOIN {conta}.cuentas cqv ON cqv.id_cuenta = ic.venta"
            strSQl &= "            LEFT JOIN {conta}.nomenclatura nqv ON nqv.idCuenta = cqv.id_nomenclatura"
            strSQl &= "            LEFT JOIN {conta}.cuentas c1 ON c1.id_cuenta = os.costo"
            strSQl &= "            LEFT JOIN {conta}.nomenclatura n ON n.idCuenta = c1.id_nomenclatura"
            strSQl &= "            LEFT JOIN {conta}.cuentas c3 ON c3.id_cuenta = os.venta"
            strSQl &= "            LEFT JOIN {conta}.nomenclatura n1 ON n1.idCuenta = c3.id_nomenclatura"
            strSQl &= "            LEFT JOIN {base}.Catalogos c4 ON c4.cat_clase = 'ClassYRM' AND c4.cat_num = hy.HDoc_DR2_Emp"
            strSQl &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 31 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' AND h.HDoc_Doc_Status = 1 AND h.HDoc_DR1_Cat > 0"
            strSQl &= " UNION "
            strSQl &= " SELECT {codempresa} id, e.HDoc_DR1_Emp Codigo, IFNULL(i.inv_fecha,'') fecha_Cod, 0,e.HDoc_Doc_Cat Cat, e.HDoc_Doc_Num numero, IFNULL(d.DDoc_Doc_Lin,'') DDoc_Doc_Lin,e.HDoc_Doc_Num numero2,e.HDoc_Doc_Fec Fecha, UPPER(lc.pro_proveedor) Nombre, CONCAT('Return Yarn ',a.art_DCorta,' ',cp.cat_clave) Producto,o.cat_clave origen, IFNULL(f.pro_proveedor,'') Fabricante,e.HDoc_DR2_NUM Referencia,cm.cat_sist Factor,cm.cat_clave Medida,d.DDoc_Prd_QTY Peso,i.inv_costo Precio,IF(a.art_clase = 330, IFNULL(nq.NombreIngles,''), IFNULL(n.NombreIngles,'')) NombreCosto, IF(a.art_clase = 330, IFNULL(nqv.NombreIngles,''), IFNULL(n1.NombreIngles,'')) NombreVenta, IFNULL(f.pro_codigo,'') Intercompany,"
            strSQl &= "  if(f.pro_codigo IN("
            strSQl &= " SELECT pp.cat_pid"
            strSQl &= " FROM {base}.Catalogos pp"
            strSQl &= " WHERE pp.cat_sisemp = {empresa} AND pp.cat_clase = 'Intercompany' AND pp.cat_desc LIKE '{intercompany}'),f.pro_nombre,'ALL') Tipo,"
            strSQl &= "  i.inv_costo Costo,e.HDoc_Doc_Fec Fecha_ing, e.HDoc_Emp_Nom Proveedor, IFNULL(c2.cat_desc,'') Clasificacion,'','',0,"
            strSQl &= "  IFNULL((SELECT ca.cat_desc"
            strSQl &= "  FROM {base}.Dcmtos_HDR h"
            strSQl &= "  LEFT JOIN {base}.Dcmtos_DTL dtl ON dtl.DDoc_Sis_Emp = h.HDoc_Sis_Emp  AND dtl.DDoc_Doc_Cat = h.HDoc_Doc_Cat  AND dtl.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQl &= "  LEFT JOIN {base}.Dcmtos_DTL_Pro pro ON pro.PDoc_Sis_Emp = dtl.DDoc_Sis_Emp  AND pro.PDoc_Par_Cat = dtl.DDoc_Doc_Cat  AND pro.PDoc_Par_Ano = dtl.DDoc_Doc_Ano  AND pro.PDoc_Par_Num = dtl.DDoc_Doc_Num AND  pro.PDoc_Par_Lin = dtl.DDoc_Doc_Lin"
            strSQl &= "  LEFT JOIN {base}.Catalogos ca ON ca.cat_num = dtl.DDoc_RF2_Num AND ca.cat_clase = 'StatusIngBdg'"
            strSQl &= "  WHERE h.HDoc_Sis_Emp  = d.DDoc_Sis_Emp  AND h.HDoc_Doc_Cat  = d.DDoc_Doc_Cat   AND h.HDoc_Doc_Ano  = d.DDoc_Doc_Ano   AND h.HDoc_DR1_Cat = 1 AND h.HDoc_Doc_Num = d.DDoc_Doc_Num LIMIT 1),'') Estado, IFNULL('','') DCorta"
            strSQl &= " FROM {base}.Dcmtos_HDR e"
            strSQl &= " LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=e.HDoc_Doc_Ano AND d.DDoc_Doc_Num=e.HDoc_Doc_Num"
            strSQl &= " LEFT JOIN {base}.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
            strSQl &= " LEFT JOIN {base}.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQl &= " LEFT JOIN {base}.Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM"
            strSQl &= " LEFT JOIN {base}.Catalogos cp ON cp.cat_clase = 'Paises' AND cp.cat_num = i.inv_lugarfab"
            strSQl &= " LEFT JOIN {base}.Catalogos o ON o.cat_num = i.inv_lugarfab"
            strSQl &= " LEFT JOIN {base}.Proveedores lc ON lc.pro_sisemp = e.HDoc_Sis_Emp AND lc.pro_codigo = e.HDoc_Emp_Cod"
            strSQl &= " LEFT JOIN {base}.Proveedores f ON f.pro_sisemp = i.inv_sisemp AND f.pro_codigo = i.inv_provcod"
            strSQl &= " LEFT JOIN {base}.Dcmtos_ACC c ON c.ADoc_Sis_Emp = d.DDoc_Sis_Emp AND c.ADoc_Doc_Cat = d.DDoc_Doc_Cat AND c.ADoc_Doc_Ano = d.DDoc_Doc_Ano AND c.ADoc_Doc_Num = d.DDoc_Doc_Num AND c.ADoc_Doc_Sub = 'Doc_DIngreso' AND c.ADoc_Doc_Lin = '04'"
            strSQl &= " LEFT JOIN {base}.Dcmtos_DTL_Pro r1 ON r1.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r1.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND r1.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND r1.PDoc_Chi_Num=d.DDoc_Doc_Num AND r1.PDoc_Chi_Lin=d.DDoc_Doc_Lin"
            strSQl &= " LEFT JOIN {base}.Dcmtos_DTL_Pro r2 ON r2.PDoc_Sis_Emp=r1.PDoc_Sis_Emp AND r2.PDoc_Chi_Cat=r1.PDoc_Par_Cat AND r2.PDoc_Chi_Ano=r1.PDoc_Par_Ano AND r2.PDoc_Chi_Num=r1.PDoc_Par_Num AND r1.PDoc_Chi_Lin=d.DDoc_Doc_Lin"
            strSQl &= " LEFT JOIN {base}.Catalogos gs ON gs.cat_num = i.inv_lugarfab AND gs.cat_clase = 'Paises'"
            strSQl &= " LEFT JOIN {conta}.inventario_codigos os ON os.clase = gs.cat_sisemp"
            strSQl &= " LEFT JOIN {conta}.inventario_codigos ic ON ic.clase = a.art_clase"
            strSQl &= " LEFT JOIN {conta}.cuentas cq ON cq.id_cuenta = ic.costo"
            strSQl &= " LEFT JOIN {conta}.nomenclatura nq ON nq.idCuenta = cq.id_nomenclatura"
            strSQl &= " LEFT JOIN {conta}.cuentas cqv ON cqv.id_cuenta = ic.venta"
            strSQl &= " LEFT JOIN {conta}.nomenclatura nqv ON nqv.idCuenta = cqv.id_nomenclatura"
            strSQl &= " LEFT JOIN {conta}.cuentas c1 ON c1.id_cuenta = os.costo"
            strSQl &= " LEFT JOIN {conta}.nomenclatura n ON n.idCuenta = c1.id_nomenclatura"
            strSQl &= " LEFT JOIN {conta}.cuentas c3 ON c3.id_cuenta = os.venta"
            strSQl &= " LEFT JOIN {conta}.nomenclatura n1 ON n1.idCuenta = c3.id_nomenclatura"
            strSQl &= " LEFT JOIN {base}.Catalogos c2 ON c2.cat_clase = 'ClaseArt' AND c2.cat_num = a.art_clase"
            strSQl &= " WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat=47 AND e.HDoc_DR1_Cat=1 AND e.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}'"
            strSQl &= " GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
            strSQl &= "  /* Nota de crédito Proveedor */ "
            strSQl &= "          UNION"
            strSQl &= "          SELECT {codempresa} id, h.HDoc_DR1_Emp Codigo, IFNULL(i.inv_fecha,'') fecha_Cod, 0,h.HDoc_Doc_Cat cat, IFNULL(CONCAT(h.HDoc_RF2_Cod,' ',h.HDoc_RF1_Txt),h.HDoc_Doc_Num) AS Nota, IFNULL(d.DDoc_Doc_Lin,'') DDoc_Doc_Lin, IFNULL(CONCAT(h.HDoc_RF2_Cod,' ',h.HDoc_RF1_Txt),h.HDoc_Doc_Num) NumE, h.HDoc_Doc_Fec Fecha, IF(h.HDoc_Doc_Status=1, p.pro_proveedor, '- A N U L A D O -') AS Empresa, CONCAT('NOTA DE CRÉDITO PROVEEDOR -',h.HDoc_RF1_Cod,' - ',h.HDoc_DR1_Num) Descripcion,'' Origen, IFNULL(f.pro_proveedor,'') Fabricante,IF(h.HDoc_Doc_Status=1, h.HDoc_DR1_Num, '') AS Factura,h.HDoc_Doc_TC Factor,'' Medida,1 Cantidad, ROUND(IFNULL(d.DDoc_Prd_NET,0),2) AS Precio,'' NombreCosto,'' NombreVenta, "
            strSQl &= "           '0' Intercompany,"
            strSQl &= "           if(f.pro_codigo IN("
            strSQl &= "          SELECT pp.cat_pid"
            strSQl &= "          FROM {base}.Catalogos pp"
            strSQl &= "          WHERE pp.cat_sisemp = {empresa} AND pp.cat_clase = 'Intercompany' AND pp.cat_desc LIKE 'ALL'),f.pro_nombre,'ALL') Tipo, ROUND(IFNULL(d.DDoc_Prd_NET,0),2) Costo,'' Fecha_Ing,  '' Proveedor, IFNULL(c2.cat_desc,'') Clasificacion,'','',0,'',IFNULL('','') DCorta"
            strSQl &= "          FROM {base}.Dcmtos_HDR h"
            strSQl &= "          LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
            strSQl &= "          LEFT JOIN {base}.ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num"
            strSQl &= "          LEFT JOIN {base}.Dcmtos_HDR h44 ON h44.HDoc_Sis_Emp = e.ECta_Sis_Emp AND h44.HDoc_Doc_Cat = e.ECta_Ref_Cat AND h44.HDoc_Doc_Ano = e.ECta_Ref_Ano AND h44.HDoc_Doc_Num = e.ECta_Ref_Num"
            strSQl &= "          LEFT JOIN {base}.Dcmtos_DTL d44 ON d44.DDoc_Sis_Emp = h44.HDoc_Sis_Emp AND d44.DDoc_Doc_Cat = h44.HDoc_Doc_Cat AND d44.DDoc_Doc_Ano = h44.HDoc_Doc_Ano AND d44.DDoc_Doc_Num = h44.HDoc_Doc_Num"
            strSQl &= "          LEFT JOIN {base}.Dcmtos_DTL_Pro pr ON pr.PDoc_Sis_Emp = d44.DDoc_Sis_Emp AND pr.PDoc_Chi_Cat = d44.DDoc_Doc_Cat AND pr.PDoc_Chi_Ano = d44.DDoc_Doc_Ano AND pr.PDoc_Chi_Num = d44.DDoc_Doc_Num AND pr.PDoc_Chi_Lin = d44.DDoc_Doc_Lin"
            strSQl &= "          LEFT JOIN {base}.Dcmtos_HDR h180 ON h180.HDoc_Sis_Emp = pr.PDoc_Sis_Emp AND h180.HDoc_Doc_Cat = pr.PDoc_Par_Cat AND h180.HDoc_Doc_Ano = pr.PDoc_Par_Ano AND h180.HDoc_Doc_Num = pr.PDoc_Par_Num"
            strSQl &= "          LEFT JOIN {base}.Dcmtos_DTL d180 ON d180.DDoc_Sis_Emp = h180.HDoc_Sis_Emp AND d180.DDoc_Doc_Cat = h180.HDoc_Doc_Cat AND d180.DDoc_Doc_Ano = h180.HDoc_Doc_Ano AND d180.DDoc_Doc_Num = h180.HDoc_Doc_Num"
            strSQl &= "          LEFT JOIN {base}.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d180.DDoc_Prd_Cod"
            strSQl &= "          LEFT JOIN {base}.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQl &= "          LEFT JOIN {base}.Catalogos c2 ON c2.cat_clase = 'ClaseArt' AND c2.cat_num = a.art_clase"
            strSQl &= "          LEFT JOIN {base}.Proveedores f ON f.pro_sisemp = i.inv_sisemp AND f.pro_codigo = i.inv_provcod"
            strSQl &= "          LEFT JOIN {base}.Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_Emp_Cod"
            strSQl &= "          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 39 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' AND h.HDoc_Doc_Status = 1 AND h.HDoc_Doc_Mon = 178 AND p.pro_fabricante = 'Si'"
            strSQl &= "          GROUP BY d.DDoc_Sis_Emp,d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num,d.DDoc_Doc_Lin"
            strSQl &= "  UNION "
            strSQl &= "  SELECT {codempresa} id, h.HDoc_DR1_Emp Codigo, IFNULL(v.inv_fecha,'') fecha_Cod, 0, h.HDoc_Doc_Cat cat, hf.HDoc_Doc_Num numero, IFNULL(d.DDoc_Doc_Lin,'') DDoc_Doc_Lin, hf.HDoc_DR1_Dbl numero2, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom cliente, CONCAT('NOTA DE DÉBITO NO.',' / ', h.HDoc_Doc_Num,' / ', d.DDoc_Prd_Des,' / FACTURA:',' ', hf.HDoc_Doc_Num) descripcion, '' origen, IFNULL(r.pro_proveedor,' ') fabricante,hf.HDoc_DR1_Num referencia,'' Factor,''medida, d.DDoc_Prd_QTY cantidad, IFNULL(d.DDoc_Prd_NET,0) precio, IF(a.art_clase = 330, IFNULL(nq.NombreIngles,''), IFNULL(n.NombreIngles,'')) NombreCosto, IF(a.art_clase = 330, IFNULL(nqv.NombreIngles,''), IFNULL(n1.NombreIngles,'')) NombreVenta, IFNULL(IFNULL(c4.cat_desc,r.pro_codigo),'') intercompany,"
            strSQl &= "   if(r.pro_codigo IN("
            strSQl &= "  SELECT pp.cat_pid"
            strSQl &= "  FROM {base}.Catalogos pp"
            strSQl &= "  WHERE pp.cat_sisemp = {empresa} AND pp.cat_clase = 'Intercompany' AND pp.cat_desc LIKE '{intercompany}'),r.pro_nombre,'ALL') Tipo,"
            strSQl &= "   1 costo,'','', IFNULL(c2.cat_desc,'') Clasificacion,'','',0,'',IFNULL('','') DCorta"
            strSQl &= "  FROM {base}.Dcmtos_HDR h"
            strSQl &= "  LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
            strSQl &= "  LEFT JOIN {base}.ECtaCte e ON e.ECta_Sis_Emp = d.DDoc_Sis_Emp AND e.ECta_Doc_Cat = d.DDoc_Doc_Cat AND e.ECta_Doc_Ano = d.DDoc_Doc_Ano AND e.ECta_Doc_Num = d.DDoc_Doc_Num AND IF(d.DDoc_Doc_Lin = 0,'',e.ECta_Doc_Lin = d.DDoc_Doc_Lin)"
            strSQl &= "  LEFT JOIN {base}.Dcmtos_HDR hf ON hf.HDoc_Sis_Emp = e.ECta_Sis_Emp AND hf.HDoc_Doc_Cat = e.ECta_Ref_Cat AND hf.HDoc_Doc_Ano = e.ECta_Ref_Ano AND hf.HDoc_Doc_Num = e.ECta_Ref_Num"
            strSQl &= "  LEFT JOIN {base}.Dcmtos_DTL df ON df.DDoc_Sis_Emp = hf.HDoc_Sis_Emp AND df.DDoc_Doc_Cat = hf.HDoc_Doc_Cat AND df.DDoc_Doc_Ano = hf.HDoc_Doc_Ano AND df.DDoc_Doc_Num = hf.HDoc_Doc_Num AND df.DDoc_Doc_Lin = e.ECta_Doc_Lin"
            strSQl &= "  LEFT JOIN {base}.Dcmtos_DTL_Pro dpy ON dpy.PDoc_Sis_Emp = df.DDoc_Sis_Emp AND dpy.PDoc_Par_Cat = df.DDoc_Doc_Cat AND dpy.PDoc_Par_Ano = df.DDoc_Doc_Ano AND dpy.PDoc_Par_Num = df.DDoc_Doc_Num AND dpy.PDoc_Chi_Cat = 395"
            strSQl &= "  LEFT JOIN {base}.Dcmtos_HDR hy ON hy.HDoc_Sis_Emp = dpy.PDoc_Sis_Emp AND hy.HDoc_Doc_Cat = dpy.PDoc_Chi_Cat AND hy.HDoc_Doc_Ano = dpy.PDoc_Chi_Ano AND hy.HDoc_Doc_Num = dpy.PDoc_Chi_Num"
            strSQl &= "  LEFT JOIN {base}.Inventarios v ON v.inv_sisemp = d.DDoc_Sis_Emp AND v.inv_numero = df.DDoc_Prd_Cod"
            strSQl &= "  LEFT JOIN {base}.Articulos a ON a.art_sisemp = v.inv_sisemp AND a.art_codigo = v.inv_artcodigo"
            strSQl &= "  LEFT JOIN {base}.Proveedores r ON r.pro_sisemp = v.inv_sisemp AND r.pro_codigo = v.inv_provcod"
            strSQl &= "  LEFT JOIN {base}.Catalogos c2 ON c2.cat_clase = 'ClaseArt' AND c2.cat_num = a.art_clase"
            strSQl &= "  LEFT JOIN {base}.Catalogos gs ON gs.cat_num = v.inv_lugarfab AND gs.cat_clase = 'Paises'"
            strSQl &= "  LEFT JOIN {conta}.inventario_codigos os ON os.clase = gs.cat_sisemp"
            strSQl &= "  LEFT JOIN {conta}.inventario_codigos ic ON ic.clase = a.art_codigo"
            strSQl &= "  LEFT JOIN {conta}.cuentas cq ON cq.id_cuenta = ic.costo"
            strSQl &= "  LEFT JOIN {conta}.nomenclatura nq ON nq.idCuenta = cq.id_nomenclatura"
            strSQl &= "  LEFT JOIN {conta}.cuentas cqv ON cqv.id_cuenta = ic.venta"
            strSQl &= "  LEFT JOIN {conta}.nomenclatura nqv ON nqv.idCuenta = cqv.id_nomenclatura"
            strSQl &= "  LEFT JOIN {conta}.cuentas c1 ON c1.id_cuenta = os.costo"
            strSQl &= "  LEFT JOIN {conta}.nomenclatura n ON n.idCuenta = c1.id_nomenclatura"
            strSQl &= "  LEFT JOIN {conta}.cuentas c3 ON c3.id_cuenta = os.venta"
            strSQl &= "  LEFT JOIN {conta}.nomenclatura n1 ON n1.idCuenta = c3.id_nomenclatura"
            strSQl &= "  LEFT JOIN {base}.Catalogos c4 ON c4.cat_clase = 'ClassYRM' AND c4.cat_num = hy.HDoc_DR2_Emp"
            strSQl &= "  WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 32 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' AND h.HDoc_Doc_Status = 1"
            strSQl &= "  GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num)l1 "
            'strSQl &= "   {filtro} "
            strSQl &= "  LEFT JOIN YarnDivision.Grupo_Detalle dg ON dg.idEmpresa = l1.id AND dg.Codigo = l1.Codigo AND dg.idTipo = 1"
            strSQl &= "  ORDER BY l1.cat DESC, l1.fecha,l1.numero "

            strSQl = Replace(strSQl, "{base}", base)
            strSQl = Replace(strSQl, "{empresa}", idempresa)
            strSQl = Replace(strSQl, "{codempresa}", codEmpresa)
            strSQl = Replace(strSQl, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQl = Replace(strSQl, "{fin}", Ffin.ToString(FORMATO_MYSQL))
            strSQl = Replace(strSQl, "{conta}", Conta)
            Select Case Sesion.IdEmpresa
                Case 12
                    strSQl = Replace(strSQl, "{num}", "h.HDoc_Doc_Num") ' h. Nota de Crédito
                    strSQl = Replace(strSQl, "{num2}", "hf.HDoc_Doc_Num") ' hf. Factua
                    'strSQl = Replace(strSQl, "{filtro}", "WHERE l1.Tipo LIKE '%ALL%' AND l1.Intercompany NOT LIKE '%Intercompany%' AND l1.Intercompany NOT IN (SELECT ci.cat_pid FROM Catalogos ci WHERE ci.cat_clase = 'Intercompany' AND ci.cat_sisemp = {empresa}  )")
                    'strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                Case 18, 15, 19, 20, 21
                    strSQl = Replace(strSQl, "{num}", "h.HDoc_DR1_Dbl")
                    strSQl = Replace(strSQl, "{num2}", "hf.HDoc_DR1_Dbl")
                    'strSQl = Replace(strSQl, "{filtro}", "WHERE l1.Tipo LIKE '%ALL%' AND l1.Intercompany NOT LIKE '%Intercompany%' AND l1.Intercompany NOT IN (SELECT ci.cat_pid FROM Catalogos ci WHERE ci.cat_clase = 'Intercompany' AND ci.cat_sisemp = {empresa}  )")
                    'strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)

                Case 11
                    strSQl = Replace(strSQl, "{num}", "h.HDoc_DR1_Dbl")
                    strSQl = Replace(strSQl, "{num2}", "hf.HDoc_DR1_Dbl")
                    'strSQl = Replace(strSQl, "{filtro}", "WHERE l1.Tipo LIKE '%ALL%' AND l1.Intercompany NOT LIKE '%Intercompany%' AND l1.Intercompany NOT IN (SELECT ci.cat_pid FROM Catalogos ci WHERE ci.cat_clase = 'Intercompany' AND ci.cat_sisemp = {empresa}  )")
                    'strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                Case 14
                    strSQl = Replace(strSQl, "{num}", "h.HDoc_DR1_Dbl")
                    strSQl = Replace(strSQl, "{num2}", "hf.HDoc_DR1_Dbl")
                    'strSQl = Replace(strSQl, "{filtro}", "WHERE l1.Tipo LIKE '%ALL%' AND l1.Intercompany NOT LIKE '%Intercompany%' AND l1.Intercompany NOT IN (SELECT ci.cat_pid FROM Catalogos ci WHERE ci.cat_clase = 'Intercompany' AND ci.cat_sisemp = {empresa}  )")
                    'strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)

                Case 16
                    strSQl = Replace(strSQl, "{num}", "h.HDoc_DR1_Dbl")
                    strSQl = Replace(strSQl, "{num2}", "hf.HDoc_DR1_Dbl")
                    'strSQl = Replace(strSQl, "{filtro}", "WHERE l1.Tipo LIKE '%ALL%' AND l1.Intercompany NOT LIKE '%Intercompany%' AND l1.Clasificacion
                    'Not LIKE '%Chemical%'  AND l1.Intercompany NOT LIKE '%Intercompany%'
                    'And l1.Intercompany Not IN (SELECT ci.cat_pid FROM Catalogos ci WHERE ci.cat_clase = 'Intercompany' AND ci.cat_sisemp = {empresa}  )")
                    'strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)

            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQl
    End Function


    Private Function sqlCheckReport(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT 0,{codempresa},0, l1.idCliente idCliente, l1.Empresa Cliente, (SUM(l1.Monto) + SUM(l1.Gastos)) total_ , now()"
            strSql &= " FROM ( "
            strSql &= "         SELECT m.BMov_Cta IDB, "
            strSql &= "                 CONCAT('DEPOSITED IN ', UPPER(IFNULL(( "
            strSql &= "                 SELECT cat_desc "
            strSql &= "                 FROM  {base}.Catalogos"
            strSql &= "                 WHERE cat_clase='Bancos' AND cat_num=b.BCta_Cod_Ban),'')),' (',b.BCta_Num_Cue,')') Banco, "
            strSql &= "                 m.BMov_Doc_Cat DTipo, m.BMov_Doc_Ano DAño, m.BMov_Doc_Num DNumero, d.DDoc_Doc_Lin Linea, m.BMov_Fec Fecha, e.HDoc_RF1_Cod Concepto, TRIM(CONCAT(IF(ISNULL(ey.HDoc_Doc_Cat), UPPER(ct.cat_desc),''),' ',d.DDoc_RF1_Txt)) Referencia, e.HDoc_Doc_Mon Moneda, IFNULL(v.cat_ext,'X') Simbolo, d.DDoc_RF1_Dbl Monto, (e.HDoc_RF1_Dbl+e.HDoc_DR1_Dbl) Total, (((d.DDoc_RF1_Dbl / (e.HDoc_RF1_Dbl+e.HDoc_DR1_Dbl)) * e.HDoc_DR1_Dbl)* - 1) Gastos, ef.HDoc_Doc_Cat FTipo, ef.HDoc_Doc_Ano FAño, ef.HDoc_Doc_Num FNumero, cl.cli_codigo IDC, cl.cli_cliente Cliente, IFNULL(ey.HDoc_Doc_Cat,-1) YTipo, IFNULL(ey.HDoc_Doc_Ano,-1) YAño, IFNULL(ey.HDoc_Doc_Num,-1) YNumero, IFNULL(ey.HDoc_DR1_Dbl,-1) YNumero2, IFNULL(ey.HDoc_DR1_Emp,-1) IDE, IFNULL(cx.cli_cliente,cl.cli_cliente) Empresa, cl.cli_codigo  idCliente, cl.cli_sisemp sisEmpresa, "
            strSql &= "                  IFNULL(( SELECT GROUP_CONCAT(DISTINCT CAST(h.DDoc_RF1_Cod AS CHAR) SEPARATOR ', ') "
            strSql &= "                           FROM {base}.Dcmtos_DTL h "
            strSql &= "                           WHERE h.DDoc_Sis_Emp=e.HDoc_Sis_Emp AND h.DDoc_Doc_Cat=e.HDoc_Doc_Cat AND h.DDoc_Doc_Ano=e.HDoc_Doc_Ano AND h.DDoc_Doc_Num=e.HDoc_Doc_Num AND h.DDoc_RF2_Cod='CHEQUE'),'') Cheques,    "
            strSql &= "                 CAST(CONCAT(m.BMov_Cta,m.BMov_Doc_Cat,m.BMov_Doc_Ano,m.BMov_Doc_Num) AS CHAR) Firma "
            strSql &= "         FROM {base}.MvtosBcos m  "
            strSql &= "             LEFT JOIN {base}.CtasBcos b ON b.BCta_Sis_Emp=m.BMov_Sis_Emp AND b.BCta_Num=m.BMov_Cta "
            strSql &= "             LEFT JOIN {base}.Dcmtos_HDR e ON e.HDoc_Sis_Emp=m.BMov_Sis_Emp AND e.HDoc_Doc_Cat=m.BMov_Doc_Cat AND e.HDoc_Doc_Ano=m.BMov_Doc_Ano AND e.HDoc_Doc_Num=m.BMov_Doc_Num  "
            strSql &= "             LEFT JOIN {base}.Catalogos v ON v.cat_clase='Monedas' AND v.cat_num=e.HDoc_Doc_Mon "
            strSql &= "             LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp=e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=e.HDoc_Doc_Ano AND d.DDoc_Doc_Num=e.HDoc_Doc_Num "
            strSql &= "             LEFT JOIN {base}.Dcmtos_HDR ef ON ef.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND ef.HDoc_Doc_Cat=d.DDoc_RF1_Num AND ef.HDoc_Doc_Ano=d.DDoc_RF2_Num AND ef.HDoc_Doc_Num=d.DDoc_RF3_Num "
            strSql &= "             LEFT JOIN {base}.Clientes cl ON cl.cli_sisemp=ef.HDoc_Sis_Emp AND cl.cli_codigo=ef.HDoc_Emp_Cod "
            strSql &= "             LEFT JOIN {base}.Dcmtos_DTL_Pro ry ON ry.PDoc_Sis_Emp=ef.HDoc_Sis_Emp AND ry.PDoc_Par_Cat=ef.HDoc_Doc_Cat AND ry.PDoc_Par_Ano=ef.HDoc_Doc_Ano AND ry.PDoc_Par_Num=ef.HDoc_Doc_Num AND ry.PDoc_Chi_Cat=395  "
            strSql &= "             LEFT JOIN {base}.Dcmtos_HDR ey ON ey.HDoc_Sis_Emp=ry.PDoc_Sis_Emp AND ey.HDoc_Doc_Cat=ry.PDoc_Chi_Cat AND ey.HDoc_Doc_Ano=ry.PDoc_Chi_Ano AND ey.HDoc_Doc_Num=ry.PDoc_Chi_Num "
            strSql &= "             LEFT JOIN {base}.Clientes cx ON cx.cli_sisemp=ey.HDoc_Sis_Emp AND cx.cli_codigo=ey.HDoc_DR1_Emp "
            strSql &= "             LEFT JOIN {base}.Catalogos ct ON ct.cat_clase='Documentos' AND ct.cat_num=ef.HDoc_Doc_Cat "
            strSql &= "         WHERE m.BMov_Sis_Emp={empresa} AND m.BMov_Doc_Cat=54 AND m.BMov_Fec BETWEEN '{inicio}' AND '{fin}' AND d.DDoc_RF2_Cod='VENTA' "
            strSql &= "         GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
            strSql &= "        ORDER BY IDB, DTipo, DAño, DNumero, Linea) l1 "
            strSql &= " GROUP BY l1.Empresa "

            strSql = Replace(strSql, "{base}", base)
            strSql = Replace(strSql, "{empresa}", idempresa)
            strSql = Replace(strSql, "{codempresa}", codEmpresa)
            strSql = Replace(strSql, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", Ffin.ToString(FORMATO_MYSQL))


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function sqlVendorsPO(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT 0,{codempresa}, l2.*,  IF(l2.Cancelado = 0,(l2.Cantidad- l2.T_Transito-l2.T_Descargo - l2.Manual),0) Saldo, now()
                        FROM (
                            SELECT l1.*, SUM(IF(l1.Transito = 'Transito', l1.Descargo,0)) T_Transito, SUM(IF(l1.Transito != 'Transito', IFNULL(l1.Descargo,0),0)) T_Descargo
                            FROM (
                                SELECT d.DDoc_Sis_Emp Empresa, d.DDoc_Doc_Cat Cat, d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Num, d.DDoc_Doc_Lin Lin, d.DDoc_RF2_Num Cancelado,h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Cod Codigo, h.HDoc_Emp_Nom Proveedor, d.DDoc_Prd_Des Hilo,  d.DDoc_RF2_Dbl FOB,d.DDoc_RF3_Dbl CIF, d.DDoc_Prd_QTY Cantidad, IFNULL(p.PDoc_QTY_Pro,0) Descargo, IFNULL((
                                    SELECT IFNULL(po.PDoc_Chi_Num, 'Transito')
                                    FROM {base}.Dcmtos_DTL_Pro pp
                                        LEFT JOIN {base}.Dcmtos_DTL_Pro pd ON pd.PDoc_Sis_Emp = pp.PDoc_Sis_Emp AND pd.PDoc_Par_Cat = pp.PDoc_Chi_Cat AND pd.PDoc_Par_Ano = pp.PDoc_Chi_Ano AND pd.PDoc_Par_Num = pp.PDoc_Chi_Num AND pd.PDoc_Par_Lin = pp.PDoc_Chi_Lin
                                       LEFT JOIN  {base}.Dcmtos_DTL_Pro po ON po.PDoc_Sis_Emp =pd.PDoc_Sis_Emp AND po.PDoc_Par_Cat = pd.PDoc_Chi_Cat AND po.PDoc_Par_Ano = pd.PDoc_Chi_Ano AND po.PDoc_Par_Num = pd.PDoc_Chi_Num AND po.PDoc_Par_Lin = pd.PDoc_Chi_Lin AND po.PDoc_Chi_Cat = 47
                                    WHERE pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pp.PDoc_Par_Cat = p.PDoc_Chi_Cat AND pp.PDoc_Par_Ano = p.PDoc_Chi_Ano AND pp.PDoc_Par_Num = p.PDoc_Chi_Num AND pp.PDoc_Par_Lin = p.PDoc_Chi_Lin
                                    LIMIT 1),'N/A') Transito,

                                IFNULL((SELECT SUM(t.IDoc_Itm_QTY) FROM  {base}.Dcmtos_DTL_Itm t
                                        WHERE t.IDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.IDoc_Doc_Cat = d.DDoc_Doc_Cat AND t.IDoc_Doc_Ano = d.DDoc_Doc_Ano AND t.IDoc_Doc_Num = d.DDoc_Doc_Num AND t.IDoc_Doc_Lin = d.DDoc_Doc_Lin),0) Manual, ip.pro_proveedor Fabricante
                                        FROM {base}.Dcmtos_HDR h
                                           LEFT JOIN  {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                                           LEFT JOIN {base}.Proveedores ip ON ip.pro_sisemp = d.DDoc_Sis_Emp AND ip.pro_codigo = d.DDoc_RF1_Num 
                                           LEFT JOIN {base}.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin
                                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 38 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' AND h.HDoc_Doc_Status = 1 
                            )l1
                        GROUP BY l1.Empresa, l1.Cat,l1.Ano,l1.Num,l1.Lin)l2
                         -- HAVING Saldo> 20
                        ORDER BY l2.Proveedor, l2.Hilo, l2.Ano,l2.Num"

            strSql = Replace(strSql, "{base}", base)
            strSql = Replace(strSql, "{empresa}", idempresa)
            strSql = Replace(strSql, "{codempresa}", codEmpresa)
            strSql = Replace(strSql, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSql = Replace(strSql, "{fin}", Ffin.ToString(FORMATO_MYSQL))


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SqlInventarioCorte(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Fcorte As Date) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT  0,{codempresa},'{corte}', SUM(l1.Saldo) montolbs, 0, l1.Region Region, l1.Clase Tipo, now()  FROM (
                            SELECT i.inv_fecha AS fecha_Ingreso,d.DDoc_Sis_Emp AS empresa,d.DDoc_Doc_Cat AS catalogo,d.DDoc_Doc_Ano AS ano,d.DDoc_Doc_Num AS numero,d.DDoc_Doc_Lin AS linea,a.art_codigo AS articulo,a.art_DCorta AS descripcion, IF((d.DDoc_Prd_UM = 70),(d.DDoc_Prd_QTY * 2.2046),d.DDoc_Prd_QTY) AS entrada, 
                            SUM(IFNULL(IF((d.DDoc_Prd_UM = 70),(di.DDoc_Prd_QTY * 2.2046),di.DDoc_Prd_QTY),0)) AS descargos, IF((d.DDoc_Prd_UM = 70),((d.DDoc_Prd_QTY - SUM(IFNULL(di.DDoc_Prd_QTY,0))) * 2.2046),(d.DDoc_Prd_QTY - SUM(IFNULL(di.DDoc_Prd_QTY,0)))) AS Saldo,h.HDoc_DR1_Num AS referencia,c.cat_desc AS Origen, MAX(hi.HDoc_Doc_Fec) AS Ultimo_despacho, 
                            IF(cls.cat_sist= 'Art_Fibra','FIBER', IF(cc.cat_desc = 'Asia', 'ASIA', IF(cc.cat_desc= 'Nafta','NAFTA',IF(cc.cat_desc ='Mexico','NAFTA','CAFTA')))) AS Region, ps.pro_proveedor AS Fabricante, IFNULL(a.art_DCorta,'N/A') AS Grupo, IF(cls.cat_sist= 'Art_TELA' , 'FABRIC', IF(cls.cat_sist= 'Art_Fibra','FIBER','YARN' ) ) Clase
                            FROM (((((((((((({base}.Dcmtos_HDR h
                                LEFT JOIN {base}.Dcmtos_DTL d ON(((d.DDoc_Sis_Emp = h.HDoc_Sis_Emp) AND (d.DDoc_Doc_Cat = h.HDoc_Doc_Cat) AND (d.DDoc_Doc_Ano = h.HDoc_Doc_Ano) AND (d.DDoc_Doc_Num = h.HDoc_Doc_Num))))
                                LEFT JOIN {base}.Inventarios i ON(((i.inv_sisemp = d.DDoc_Sis_Emp) AND (i.inv_numero = d.DDoc_Prd_Cod))))
                                LEFT JOIN {base}.Proveedores ps ON(((ps.pro_sisemp = i.inv_sisemp) AND (ps.pro_codigo = i.inv_provcod))))
                                LEFT JOIN {base}.Catalogos c ON((c.cat_num = i.inv_lugarfab)))
                                LEFT JOIN {base}.Catalogos cc ON((cc.cat_num = c.cat_sisemp)))
                                LEFT JOIN {base}.Articulos a ON(((a.art_sisemp = i.inv_sisemp) AND (a.art_codigo = i.inv_artcodigo))))
                                LEFT JOIN {base}.Catalogos cls ON cls.cat_num = a.art_clase  AND cls.cat_clase = 'ClaseArt'
                                LEFT JOIN {base}.Dcmtos_DTL_Pro p ON(((p.PDoc_Sis_Emp = d.DDoc_Sis_Emp) AND (p.PDoc_Par_Cat = d.DDoc_Doc_Cat) AND (p.PDoc_Par_Ano = d.DDoc_Doc_Ano) AND (p.PDoc_Par_Num = d.DDoc_Doc_Num) AND (p.PDoc_Par_Lin = d.DDoc_Doc_Lin))AND p.PDoc_Chi_Cat = 48   ))
                                LEFT JOIN {base}.Dcmtos_HDR hi ON(((hi.HDoc_Sis_Emp = p.PDoc_Sis_Emp) AND (hi.HDoc_Doc_Cat = p.PDoc_Chi_Cat) AND (hi.HDoc_Doc_Ano = p.PDoc_Chi_Ano) AND (hi.HDoc_Doc_Num = p.PDoc_Chi_Num) AND (hi.HDoc_Doc_Status = 1 AND hi.HDoc_Doc_Fec <= '{corte}'))))
                                LEFT JOIN {base}.Dcmtos_DTL di ON(((di.DDoc_Sis_Emp = hi.HDoc_Sis_Emp) AND (di.DDoc_Doc_Cat = hi.HDoc_Doc_Cat) AND (di.DDoc_Doc_Ano = hi.HDoc_Doc_Ano) AND (di.DDoc_Doc_Num = hi.HDoc_Doc_Num) AND (di.DDoc_Doc_Lin = p.PDoc_Chi_Lin))))                             
                            )))WHERE ((h.HDoc_Sis_Emp = {empresa}) AND (h.HDoc_Doc_Cat = 47)) AND h.HDoc_Doc_Fec <= '{corte}' AND cls.cat_sist not IN ('Art_CHEM', 'Art_OTHER', 'Art_empaque')
                            GROUP BY d.DDoc_Sis_Emp,d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num,d.DDoc_Doc_Lin
                            HAVING (Saldo >= 1)) l1
                        GROUP BY Region, Tipo"
            strSQL = Replace(strSQL, "{base}", base)
            strSQL = Replace(strSQL, "{empresa}", idempresa)
            strSQL = Replace(strSQL, "{codempresa}", codEmpresa)
            strSQL = Replace(strSQL, "{corte}", Fcorte.ToString(FORMATO_MYSQL))
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function SqlUsaInventory(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT   0,{codempresa}, s1.Codigo, s1.Clase, s1.Tipo, s1.Descripcion, s1.IDF, s1.Fabricante, s1.GID, IFNULL(s1.Grupo,s1.Fabricante) Grupo,  if (((SUM(s1.Ordenado) - (SUM(s1.Embarcado)+ SUM(s1.Apartado))) )<0, 0, ((SUM(s1.Ordenado) - (SUM(s1.Embarcado)+ SUM(s1.Apartado))) )) SaldoPO,  SUM(s1.Reserva) Reserva, (SUM(s1.Inventario) - SUM(s1.Despacho)) SaldoInventario,  now() 
                        FROM (
                        SELECT Codigo, Clase, Tipo, Descripcion, IDF, GID, Grupo, Fabricante, SUM(Ordenado) Ordenado, SUM(Embarcado) Embarcado, SUM(Apartado) Apartado, SUM(Inventario) Inventario, SUM(Despacho) Despacho, SUM(Reserva) Reserva
                        FROM (
                        SELECT a.art_codigo Codigo, cc.cat_clave Clase, IFNULL(ca.cat_clave,'') Tipo, a.art_DCorta Descripcion, IFNULL(p.pro_codigo,-1) IDF, IFNULL(cg.cat_ext,'') GID, cg.cat_desc Grupo, UPPER(IFNULL(IFNULL(p.pro_nombre,p.pro_proveedor),'(DESCONOCIDO)')) Fabricante, 0 Ordenado, 0 Embarcado, 0 Apartado, ROUND(d.DDoc_Prd_QTY * ROUND(cm.cat_sist,5),2) Inventario, ROUND((
                        SELECT IFNULL(SUM(PDoc_QTY_Pro),0)
                        FROM {base}.Dcmtos_DTL_Pro r
                        WHERE r.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r.PDoc_Par_Cat=d.DDoc_Doc_Cat AND r.PDoc_Par_Ano=d.DDoc_Doc_Ano AND r.PDoc_Par_Num=d.DDoc_Doc_Num AND r.PDoc_Par_Lin=d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat=48) * ROUND(cm.cat_sist,5),2) Despacho, ROUND((
                        SELECT IFNULL(SUM(s.cantidad),0)
                        FROM {base}.Reserva s
                        WHERE s.id_empresa=d.DDoc_Sis_Emp AND s.doc_tipo=d.DDoc_Doc_Cat AND s.doc_ciclo=d.DDoc_Doc_Ano AND s.doc_num=d.DDoc_Doc_NUM AND s.doc_lin=d.DDoc_Doc_Lin AND NOT(s.estado=2)),02) Reserva
                        FROM {base}.Dcmtos_DTL d
                        LEFT JOIN {base}.Catalogos cm ON cm.cat_clase='Medidas' AND cm.cat_num=d.DDoc_Prd_UM
                        LEFT JOIN {base}.Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod
                        LEFT JOIN {base}.Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo
                        LEFT JOIN {base}.Proveedores p ON p.pro_sisemp=i.inv_sisemp AND p.pro_codigo=i.inv_provcod
                        LEFT JOIN {base}.Catalogos cp ON cp.cat_clase='Paises' AND cp.cat_num=i.inv_lugarfab 
                        LEFT JOIN {base}.Catalogos cc ON cc.cat_clase='ClaseArt' AND cc.cat_num=a.art_clase
                        LEFT JOIN {base}.Catalogos ca ON ca.cat_clase='Spinning' AND ca.cat_num=a.art_spinning
                        LEFT JOIN {base}.Catalogos cg ON cg.cat_clase='Rpt_Inventory' AND cg.cat_clave=p.pro_codigo AND (cg.cat_sist=ca.cat_clave OR (cg.cat_sist='' AND (INSTR(cg.cat_dato, IFNULL(ca.cat_clave,''))=0 OR IFNULL(ca.cat_clave,'')=''))) AND cg.cat_sisemp=d.DDoc_Sis_Emp
                        WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=47 AND cm.cat_clave IN ('LBS','KGS') AND cp.cat_clave IN ('USA','HN','GT','SV','NI','CR') AND cc.cat_sist NOT IN('Art_CHEM','Art_Fibra','Art_TELA', 'Art_OTHER','Art_empaque', 'Art_ramplas' )
                        HAVING ABS(Inventario-Despacho) > 0.9) g1
                        GROUP BY Codigo, IDF 

                        UNION

                        SELECT Codigo, Clase, Tipo, Descripcion, IDF, GID, Grupo, Fabricante, SUM(Ordenado) Ordenado, SUM(Embarcado) Embarcado, SUM(IF(Apartado<=(Ordenado-Embarcado),Apartado, IF((Ordenado-Embarcado)<0,0,(Ordenado-Embarcado)))) Apartado, 0 Inventario, 0 Despacho, 0 Reserva
                        FROM (
                        SELECT a.art_codigo Codigo, cc.cat_clave Clase, IFNULL(ca.cat_clave,'') Tipo, a.art_DCorta Descripcion, IFNULL(p.pro_codigo,-1) IDF, IFNULL(cg.cat_ext,'') GID, cg.cat_desc Grupo, UPPER(IFNULL(IFNULL(p.pro_nombre,p.pro_proveedor),'(DESCONOCIDO)')) Fabricante, (ROUND(d.DDoc_Prd_QTY * ROUND(cm.cat_sist,5),2)) Ordenado, (ROUND((
                        SELECT IFNULL(SUM(PDoc_QTY_Pro),0)
                        FROM {base}.Dcmtos_DTL_Pro r
                        WHERE r.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r.PDoc_Par_Cat=d.DDoc_Doc_Cat AND r.PDoc_Par_Ano=d.DDoc_Doc_Ano AND r.PDoc_Par_Num=d.DDoc_Doc_Num AND r.PDoc_Par_Lin=d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat=127) * ROUND(cm.cat_sist,5),2) + ROUND((
                        SELECT IFNULL(SUM(m.IDoc_Itm_QTY),0)
                        FROM {base}.Dcmtos_DTL_Itm m
                        WHERE m
                        .IDoc_Sis_Emp=d.DDoc_Sis_Emp AND m.IDoc_Doc_Cat=d.DDoc_Doc_Cat AND m.IDoc_Doc_Ano=d.DDoc_Doc_Ano AND m.IDoc_Doc_Num=d.DDoc_Doc_Num AND m.IDoc_Doc_Lin=d.DDoc_Doc_Lin) * ROUND(cm.cat_sist,5),2)) Embarcado, (ROUND((
                        SELECT IFNULL(SUM(s.cantidad),0)
                        FROM {base}.Reserva s
                        WHERE s.id_empresa=d.DDoc_Sis_Emp AND s.doc_tipo=d.DDoc_Doc_Cat AND s.doc_ciclo=d.DDoc_Doc_Ano AND s.doc_num=d.DDoc_Doc_NUM AND s.doc_lin=d.DDoc_Doc_Lin AND NOT(s.estado=2)) * ROUND(cm.cat_sist,5),02)) Apartado
                        FROM {base}.Dcmtos_DTL d
                        LEFT JOIN {base}.Dcmtos_HDR er ON er.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND er.HDoc_Doc_Cat=d.DDoc_Doc_Cat AND er.HDoc_Doc_Ano=d.DDoc_Doc_Ano AND er.HDoc_Doc_Num=d.DDoc_Doc_Num
                        LEFT JOIN {base}.Catalogos cm ON cm.cat_clase='Medidas' AND cm.cat_num=d.DDoc_Prd_UM
                        LEFT JOIN {base}.Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod
                        LEFT JOIN {base}.Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo
                        LEFT JOIN {base}.Proveedores p ON p.pro_sisemp=i.inv_sisemp AND p.pro_codigo=d.DDoc_RF1_Num
                        LEFT JOIN {base}.Catalogos cp ON cp.cat_clase='Paises' AND cp.cat_num=i.inv_lugarfab
                        LEFT JOIN {base}.Catalogos cc ON cc.cat_clase='ClaseArt' AND cc.cat_num=a.art_clase
                        LEFT JOIN {base}.Catalogos ca ON ca.cat_clase='Spinning' AND ca.cat_num=a.art_spinning
                        LEFT JOIN {base}.Catalogos cg ON cg.cat_clase='Rpt_Inventory' AND cg.cat_clave=p.pro_codigo AND (cg.cat_sist=ca.cat_clave OR (cg.cat_sist='' AND (INSTR(cg.cat_dato, IFNULL(ca.cat_clave,''))=0 OR IFNULL(
                        ca.cat_clave,'')=''))) AND cg.cat_sisemp=d.DDoc_Sis_Emp
                        WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=38 AND er.HDoc_Doc_Status=1 AND d.DDoc_RF2_Num=0 AND cm.cat_clave IN ('LBS','KGS') AND cp.cat_clave IN ('USA','HN','GT','SV','NI','CR')) s2
                        GROUP BY Codigo, IDF

                        ) s1
                        GROUP BY Codigo, IDF
                        HAVING ABS(SaldoPO) > 0.9 OR ABS(SaldoInventario) > 0.9
                        ORDER BY GID DESC, Fabricante, Clase, Descripcion  "

            strSql = Replace(strSql, "{base}", base)
            strSql = Replace(strSql, "{empresa}", idempresa)
            strSql = Replace(strSql, "{codempresa}", codEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function SqlInventario(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer) As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT   0,{codempresa},  e.HDoc_Doc_Fec Fecha, IF(IFNULL(d.DDoc_RF2_Num,0)=0,'GOOD', IF(d.DDoc_RF2_NUM=1,'CLEARENCE','BAD')) EstadoH, a.art_codigo Producto, d.DDoc_Prd_Cod Codigo, CONCAT(a.art_DCorta,'') Descripcion, cp.cat_desc  Origen, i.inv_prodlote Lote, i.inv_prodsem Semana, i.inv_costo Costo, COALESCE(e.HDoc_DR1_Num,'') Factura, IFNULL(d.DDoc_RF2_Cod,'') Bodega, IFNULL(IFNULL(p.pro_nombre,p.pro_proveedor),'N/A') Proveedor, 
                            ROUND((d.DDoc_Prd_QTY - IFNULL((
                            SELECT SUM(p.PDoc_QTY_Pro)
                            FROM {base}.Dcmtos_DTL_Pro p
                            INNER JOIN {base}.Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND h.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND h.HDoc_Doc_Num = p.PDoc_Chi_Num
                            WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 48),0)) * IF(ROUND(cm.cat_sist,4)=0,1, ROUND(cm.cat_sist,4)),2) Saldo, now()  
                            FROM {base}.Dcmtos_DTL d
                            INNER JOIN {base}.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            INNER JOIN {base}.Articulos a ON a.art_sisemp = d.DDoc_Sis_Emp AND a.art_codigo = i.inv_artcodigo
                            INNER JOIN {base}.Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num
                            LEFT JOIN {base}.Proveedores p ON p.pro_sisemp = d.DDoc_Sis_Emp AND p.pro_codigo = i.inv_provcod
                            LEFT JOIN {base}.Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM
                            LEFT JOIN {base}.Catalogos cp ON cp.cat_clase = 'Paises' AND cp.cat_num = i.inv_lugarfab
                            LEFT JOIN {base}.Catalogos cn ON cn.cat_clase = 'Countries' AND cn.cat_num = cp.cat_pid
                            LEFT JOIN {base}.Catalogos cc ON cc.cat_num = a.art_clase
                            LEFT JOIN {base}.Catalogos ca ON ca.cat_num = a.art_acabado
                            LEFT JOIN {base}.Catalogos cs ON cs.cat_num = a.art_spinning
                            WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND NOT(cc.cat_sist IN ('Art_CHEM','Art_OTHER','Art_TELA'))
                            GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin
                            HAVING ABS(Saldo) > 9
                            ORDER BY  a.art_DCorta, p.pro_proveedor, i.inv_prodano, i.inv_prodsem "

            strSql = Replace(strSql, "{base}", base)
            strSql = Replace(strSql, "{empresa}", idempresa)
            strSql = Replace(strSql, "{codempresa}", codEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Private Function sqlPurchase(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strSQl As String = STR_VACIO
        Try
            strSQl = " SELECT 0, {codempresa},  h.HDoc_Emp_Cod Codigo, IF(v.pro_plazoCR = 0,'', CONCAT('NET',' ',v.pro_plazoCR)) Terminos,h.HDoc_Emp_Nom Nombre, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num NumeroConf, h.HDoc_Doc_Fec Fecha, 
                            IFNULL((SELECT CAST(ac.ADoc_Dta_Fec AS CHAR) FROM Dcmtos_HDR hd
                            LEFT JOIN Dcmtos_ACC ac ON ac.ADoc_Sis_Emp = hd.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = hd.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = hd.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = hd.HDoc_Doc_Num AND ac.ADoc_Doc_Lin = 04
                            WHERE hd.HDoc_Sis_Emp = h.HDoc_Sis_Emp  AND hd.HDoc_Doc_Cat = h.HDoc_Doc_Cat AND hd.HDoc_Doc_Ano = h.HDoc_Doc_Ano  AND hd.HDoc_Doc_Num = h.HDoc_Doc_Num),'0000-00-00') Fechaemision,
                            h.HDoc_DR1_Num Factura,c1.cat_clave Region, a.art_DCorta Descripcion, IFNULL((
                            SELECT hi.HDoc_DR1_Num
                            FROM {base}.Dcmtos_DTL_Pro p
                            LEFT JOIN {base}.Dcmtos_DTL_Pro p1 ON p1.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p1.PDoc_Par_Cat = p.PDoc_Chi_Cat AND p1.PDoc_Par_Ano = p.PDoc_Chi_Ano AND p1.PDoc_Par_Num = p.PDoc_Chi_Num AND p1.PDoc_Par_Lin = p.PDoc_Chi_Lin
                            LEFT JOIN {base}.Dcmtos_DTL_Pro p3 ON p3.PDoc_Sis_Emp = p1.PDoc_Sis_Emp AND p3.PDoc_Par_Cat = p1.PDoc_Chi_Cat AND p3.PDoc_Par_Ano = p1.PDoc_Chi_Ano AND p3.PDoc_Par_Num = p1.PDoc_Chi_Num AND p3.PDoc_Par_Lin = p1.PDoc_Chi_Lin AND p3.PDoc_Chi_Cat = 47
                            LEFT JOIN {base}.Dcmtos_DTL di ON di.DDoc_Sis_Emp = p3.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = p3.PDoc_Chi_Cat AND di.DDoc_Doc_Ano = p3.PDoc_Chi_Ano AND di.DDoc_Doc_Num = p3.PDoc_Chi_Num AND di.DDoc_Doc_Lin = p3.PDoc_Chi_Lin
                            LEFT JOIN {base}.Dcmtos_HDR hi ON hi.HDoc_Sis_Emp = di.DDoc_Sis_Emp AND hi.HDoc_Doc_Cat = di.DDoc_Doc_Cat AND hi.HDoc_Doc_Ano = di.DDoc_Doc_Ano AND hi.HDoc_Doc_Num = di.DDoc_Doc_Num
                                WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin LIMIT 1),h.HDoc_DR1_Num) Referencia, (d.DDoc_Prd_QTY * c.cat_sist) Cantidad, IFNULL((d.DDoc_Prd_NET / c.cat_sist),0) Precio, IFNULL(((d.DDoc_Prd_QTY * c.cat_sist)* (d.DDoc_Prd_NET / c.cat_sist)),0) Total, IFNULL((
                            SELECT hi.HDoc_RF2_Txt
                            FROM {base}.Dcmtos_DTL_Pro p
                            LEFT JOIN {base}.Dcmtos_DTL_Pro p1 ON p1.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p1.PDoc_Par_Cat = p.PDoc_Chi_Cat AND p1.PDoc_Par_Ano = p.PDoc_Chi_Ano AND p1.PDoc_Par_Num = p.PDoc_Chi_Num AND p1.PDoc_Par_Lin = p.PDoc_Chi_Lin
                            LEFT JOIN {base}.Dcmtos_DTL_Pro p3 ON p3.PDoc_Sis_Emp = p1.PDoc_Sis_Emp AND p3.PDoc_Par_Cat = p1.PDoc_Chi_Cat AND p3.PDoc_Par_Ano = p1.PDoc_Chi_Ano AND p3.PDoc_Par_Num = p1.PDoc_Chi_Num AND p3.PDoc_Par_Lin = p1.PDoc_Chi_Lin AND p3.PDoc_Chi_Cat = 47
                            LEFT JOIN {base}.Dcmtos_DTL di ON di.DDoc_Sis_Emp = p3.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = p3.PDoc_Chi_Cat AND di.DDoc_Doc_Ano = p3.PDoc_Chi_Ano AND di.DDoc_Doc_Num = p3.PDoc_Chi_Num AND di.DDoc_Doc_Lin = p3.PDoc_Chi_Lin
                            LEFT JOIN {base}.Dcmtos_HDR hi ON hi.HDoc_Sis_Emp = di.DDoc_Sis_Emp AND hi.HDoc_Doc_Cat = di.DDoc_Doc_Cat AND hi.HDoc_Doc_Ano = di.DDoc_Doc_Ano AND hi.HDoc_Doc_Num = di.DDoc_Doc_Num
                                WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin LIMIT 1),IFNULL((
                            SELECT hi.HDoc_DR1_Num
                                FROM {base}.Dcmtos_DTL_Pro p
                                LEFT JOIN {base}.Dcmtos_DTL_Pro p1 ON p1.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p1.PDoc_Par_Cat = p.PDoc_Chi_Cat AND p1.PDoc_Par_Ano = p.PDoc_Chi_Ano AND p1.PDoc_Par_Num = p.PDoc_Chi_Num AND p1.PDoc_Par_Lin = p.PDoc_Chi_Lin
                                LEFT JOIN {base}.Dcmtos_DTL_Pro p3 ON p3.PDoc_Sis_Emp = p1.PDoc_Sis_Emp AND p3.PDoc_Par_Cat = p1.PDoc_Chi_Cat AND p3.PDoc_Par_Ano = p1.PDoc_Chi_Ano AND p3.PDoc_Par_Num = p1.PDoc_Chi_Num AND p3.PDoc_Par_Lin = p1.PDoc_Chi_Lin AND p3.PDoc_Chi_Cat = 47
                                LEFT JOIN {base}.Dcmtos_DTL di ON di.DDoc_Sis_Emp = p3.PDoc_Sis_Emp AND di.DDoc_Doc_Cat = p3.PDoc_Chi_Cat AND di.DDoc_Doc_Ano = p3.PDoc_Chi_Ano AND di.DDoc_Doc_Num = p3.PDoc_Chi_Num AND di.DDoc_Doc_Lin = p3.PDoc_Chi_Lin
                                LEFT JOIN {base}.Dcmtos_HDR hi ON hi.HDoc_Sis_Emp = di.DDoc_Sis_Emp AND hi.HDoc_Doc_Cat = di.DDoc_Doc_Cat AND hi.HDoc_Doc_Ano = di.DDoc_Doc_Ano AND hi.HDoc_Doc_Num = di.DDoc_Doc_Num
                                    WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin LIMIT 1),h.HDoc_RF2_Txt)) Numero, NOW()
                        FROM {base}.Dcmtos_HDR h
                            LEFT JOIN {base}.Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN {base}.Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                            LEFT JOIN {base}.Proveedores v ON v.pro_sisemp = h.HDoc_Sis_Emp AND v.pro_codigo = h.HDoc_Emp_Cod
                            LEFT JOIN {base}.Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                            LEFT JOIN {base}.Catalogos cc ON cc.cat_num = i.inv_lugarfab AND cc.cat_clase = 'paises'
                            LEFT JOIN {base}.Catalogos c1 ON c1.cat_num =cc.cat_pid AND c1.cat_clase = 'Countries'
                            LEFT JOIN {base}.Catalogos c ON c.cat_clase='Medidas' AND c.cat_num = d.DDoc_Prd_UM 
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 127  AND h.HDoc_DR1_Cat = 0 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}'
                                ORDER BY h.HDoc_Emp_Nom "

            strSQl = Replace(strSQl, "{base}", base)
            strSQl = Replace(strSQl, "{empresa}", idempresa)
            strSQl = Replace(strSQl, "{codempresa}", codEmpresa)
            strSQl = Replace(strSQl, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQl = Replace(strSQl, "{fin}", Ffin.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQl
    End Function

    Private Function sqlPresupuesto(ByVal codEmpresa As Integer, ByVal base As String, ByVal idempresa As Integer, ByVal Finicio As Date, ByVal Ffin As Date, ByVal strConta As String)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT 0, {codempresa},IFNULL(dg.idGrupo,-5)idGrupo, l1.valorcampo, l1.cuenta, l1.padre, SUM(l1.PreEne) PreEne, SUM(l1.EjeEne) EjeEne, SUM(l1.PreFeb) PreFeb, SUM(l1.EjeFeb) EjeFeb, SUM(l1.PreMar) PreMar, SUM(l1.EjeMar) EjeMar, SUM(l1.PreAbr) PreAbr, SUM(l1.EjeAbr) EjeAbr, SUM(l1.PreMay) PreMay, SUM(l1.EjeMay) EjeMay, SUM(l1.PreJun) PreJun, SUM(l1.EjeJun) EjeJun, SUM(l1.PreJul) PreJul, SUM(l1.EjeJul) EjeJul, SUM(l1.PreAgo) PreAgo, SUM(l1.EjeAgo) EjeAgo, SUM(l1.PreSep) PreSep, SUM(l1.EjeSep) EjeSep, SUM(l1.PreOct) PreOct, SUM(l1.EjeOct) EjeOct, SUM(l1.PreNov) PreNov, SUM(l1.EjeNov) EjeNov, SUM(l1.PreDic) PreDic, SUM(l1.EjeDic) EjeDic, NOW() reg
                            FROM (
                            SELECT {codempresa} id, r.valorcampo, IFNULL(c.nombre_ext, r.valorcampo) cuenta, r.linea, c.padre, SUM(IF(p.mes = 1, IFNULL(IFNULL(p.importe,0),0),0)) PreEne, 0 EjeEne, SUM(IF(p.mes = 2, IFNULL(IFNULL(p.importe,0),0),0)) PreFeb, 0 EjeFeb, SUM(IF(p.mes = 3, IFNULL(IFNULL(p.importe,0),0),0)) PreMar, 0 EjeMar, SUM(IF(p.mes = 4, IFNULL(IFNULL(p.importe,0),0),0)) PreAbr, 0 EjeAbr, SUM(IF(p.mes = 5, IFNULL(IFNULL(p.importe,0),0),0)) PreMay, 0 EjeMay, SUM(IF(p.mes = 6, IFNULL(IFNULL(p.importe,0),0),0)) PreJun, 0 EjeJun, SUM(IF(p.mes = 7, IFNULL(IFNULL(p.importe,0),0),0)) PreJul, 0 EjeJul, SUM(IF(p.mes = 8, IFNULL(IFNULL(p.importe,0),0),0)) PreAgo, 0 EjeAgo, SUM(IF(p.mes = 9, IFNULL(IFNULL(p.importe,0),0),0)) PreSep, 0 EjeSep, SUM(IF(p.mes = 10, IFNULL(IFNULL(p.importe,0),0),0)) PreOct,0 EjeOct, SUM(IF(p.mes = 11, IFNULL(IFNULL(p.importe,0),0),0)) PreNov,0 EjeNov, SUM(IF(p.mes = 12, IFNULL(IFNULL(p.importe,0),0),0)) PreDic,0 EjeDic
                            FROM {conta}.rpt_strc r
                            LEFT JOIN {conta}.cuentas_presupuesto c ON c.empresa = r.empresa AND c.id_cuenta = r.valorcampo
                            LEFT JOIN {conta}.pro_presupuesto p ON p.empresa = r.empresa AND p.cuenta = r.valorcampo AND p.ano = YEAR('{inicio}') AND p.mes BETWEEN MONTH('{inicio}') AND MONTH('{fin}')
                            WHERE r.empresa = {empresa} AND r.reporte = 8 AND r.tipocampo =1
                            GROUP BY r.valorcampo UNION
                            SELECT {codempresa} id, r.valorcampo, IFNULL(c.nombre_ext, r.valorcampo) cuenta, r.linea, c.padre, 
                            0 PreEne, ROUND(SUM(IF(MONTH(d.fecha) = 1, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeEne, 
                            0 PreFeb, ROUND(SUM(IF(MONTH(d.fecha) = 2, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeFeb, 
                            0 PreMar, ROUND(SUM(IF(MONTH(d.fecha) = 3, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeMar, 
                            0 PreAbr, ROUND(SUM(IF(MONTH(d.fecha) = 4, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeAbr,
                            0 PreMay, ROUND(SUM(IF(MONTH(d.fecha) = 5, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeMay, 
                            0 PreJun, ROUND(SUM(IF(MONTH(d.fecha) = 6, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeJun, 
                            0 PreJul, ROUND(SUM(IF(MONTH(d.fecha) = 7, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeJul, 
                            0 PreAgo, ROUND(SUM(IF(MONTH(d.fecha) = 8, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeAgo, 
                            0 PreSep, ROUND(SUM(IF(MONTH(d.fecha) = 9, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeSep, 
                            0 PreOct, ROUND(SUM(IF(MONTH(d.fecha) = 10, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeOct, 
                            0 PreNov, ROUND(SUM(IF(MONTH(d.fecha) = 11, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeNov, 
                            0 PreDic, ROUND(SUM(IF(MONTH(d.fecha) = 12, IFNULL(IFNULL(d.importe_ext,0),0),0)),2) EjeDic
                            FROM {conta}.rpt_strc r
                            LEFT JOIN {conta}.cuentas_presupuesto c ON c.empresa = r.empresa AND c.id_cuenta = r.valorcampo
                            LEFT JOIN {conta}.detalle_presupuesto d ON d.empresa = r.empresa AND d.cuenta = r.valorcampo AND d.fecha BETWEEN ('{inicio}') AND ('{fin}')
                            WHERE r.empresa = {empresa} AND r.reporte = 8 AND r.tipocampo =1 AND IFNULL((
                            SELECT IFNULL(h.HDoc_Doc_Status,0)
                            FROM {base}.Dcmtos_HDR h
                            WHERE h.HDoc_Sis_Emp = d.empresa AND h.HDoc_Doc_Cat = d.categoria AND h.HDoc_Doc_Ano = d.ano AND h.HDOc_Doc_Num = d.numero),0) <3
                            GROUP BY r.valorcampo 
                            ) l1
                            LEFT JOIN {yd}.Grupo_Detalle dg ON dg.idEmpresa = l1.id AND dg.cta_Contable = l1.valorcampo
                            GROUP BY l1.cuenta
                            ORDER BY l1.linea "

            strSQL = Replace(strSQL, "{base}", base)
            strSQL = Replace(strSQL, "{empresa}", idempresa)
            strSQL = Replace(strSQL, "{codempresa}", codEmpresa)
            strSQL = Replace(strSQL, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", Ffin.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{yd}", YarnD)
            strSQL = Replace(strSQL, "{conta}", strConta)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Sub botonSincronizar_Click(sender As Object, e As EventArgs) Handles botonSincronizar.Click
        Dim strSQL1 As String = STR_VACIO
        Dim CheckReport As String = STR_VACIO
        Dim strVentas As String = STR_VACIO
        Dim InventarioTransito As String = STR_VACIO
        Dim BalanceCombinado As String = STR_VACIO
        Dim PLCombinado As String = STR_VACIO
        Dim VentasxCliente As String = STR_VACIO
        Dim OpenInvoice As String = STR_VACIO
        Dim Inventario As String = STR_VACIO
        Dim Purchase As String = STR_VACIO
        Dim AgingSummary As String = STR_VACIO
        Dim CuentasXPagar As String = STR_VACIO
        Dim Planning As String = STR_VACIO
        Dim strGross As String = STR_VACIO
        Dim strOrdenesProveedores As String = STR_VACIO
        Dim strUsaInventory As String = STR_VACIO
        Dim strInvenarioCorte As String = STR_VACIO
        Dim strPresupuesto As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim idEmpresa As Integer = 0
        Dim Base As String = STR_VACIO
        Dim codEmpresa As Integer = 0
        Dim strContaEmp As String = STR_VACIO
        'Dim OI As New Tablas.TOPEN_INVOICE
        'Dim ASU As New Tablas.TAGINGSUMMARY
        Dim conecDelete As MySqlConnection
        Dim Delete As MySqlCommand
        Dim sqlDelete As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim intmoneda As Integer = INT_CERO
        Dim dblTC_ As Double = INT_CERO

        Dim sqlInsert As String = STR_VACIO
        Try
            lblStatus.Text = " Synchronizing, please wait ... "
            lblStatus.ForeColor = Color.Red
            system.Windows.Forms.Application.DoEvents()
            strSQL1 = SQLBase()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL1, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                If intTipoReport = 1 Then
                    sqlDelete = " Delete From " & YarnD & ".Open_Invoice"
                ElseIf intTipoReport = 2 Then

                ElseIf intTipoReport = 3 Then
                    sqlDelete = " Delete From " & YarnD & ".AgingSummary"
                ElseIf intTipoReport = 4 Then
                    sqlDelete = "Delete From " & YarnD & ".cxp"
                ElseIf intTipoReport = 5 Or intTipoReport = 20 Then
                    sqlDelete = "Delete From " & YarnD & ".Planning"
                ElseIf intTipoReport = 6 Then
                    sqlDelete = "Delete from " & YarnD & ".CheckReport"
                ElseIf intTipoReport = 7 Then
                    sqlDelete = "Delete from " & YarnD & ".ventas"
                ElseIf intTipoReport = 8 Then
                    sqlDelete = "Delete from " & YarnD & ".Gross"
                ElseIf intTipoReport = 9 Then
                    sqlDelete = "Delete from " & YarnD & ".VendorsPO"
                ElseIf intTipoReport = 10 Then
                    sqlDelete = " Delete from " & YarnD & ".Inventario_Corte where fecha =  '" & dtpFecha.Value.ToString(FORMATO_MYSQL) & "'"  ' 
                ElseIf intTipoReport = 11 Then
                    sqlDelete = " Delete from " & YarnD & ".Usa_Inventory "
                ElseIf intTipoReport = 12 Then
                    sqlDelete = "Delete From " & YarnD & ".Planning"
                    conecDelete = New MySqlConnection(strConexion)
                    conecDelete.Open()
                    Delete = New MySqlCommand(sqlDelete, conecDelete)
                    Try
                        Using conecDelete
                            Delete.ExecuteNonQuery()
                            Delete.Dispose()
                            Delete = Nothing
                            conecDelete.Close()
                            conecDelete.Dispose()
                            conecDelete = Nothing
                        End Using
                    Catch ex As Exception

                    End Try
                    sqlDelete = STR_VACIO
                    sqlDelete = "Delete From " & YarnD & ".Inventario_Historico where Fecha = '" & dtpFecha.Value.ToString(FORMATO_MYSQL) & "'"
                ElseIf intTipoReport = 13 Then
                    sqlDelete = " Delete from " & YarnD & ".Inventario "
                ElseIf intTipoReport = 14 Then
                    sqlDelete = " Delete from " & YarnD & ".Purchase "
                ElseIf intTipoReport = 15 Then
                    sqlDelete = " Delete From " & YarnD & ".Budget "
                ElseIf intTipoReport = 16 Then
                    sqlDelete = " Delete From " & YarnD & ".AR_Detail"
                ElseIf intTipoReport = 17 Then
                    sqlDelete = " Delete From " & YarnD & ".Ventasx_Cliente"
                ElseIf intTipoReport = 18 Then
                    sqlDelete = " Delete From " & YarnD & ".AR_Detail"
                ElseIf intTipoReport = 19 Then
                    sqlDelete = " Delete From " & YarnD & ".Inventario_Transito"
                ElseIf intTipoReport = 21 Then
                    sqlDelete = " Delete From " & YarnD & ".Combined_Balance"
                ElseIf intTipoReport = 22 Then
                    sqlDelete = " Delete From " & YarnD & ".CombinedLP"
                End If


                conecDelete = New MySqlConnection(strConexion)
                conecDelete.Open()
                Delete = New MySqlCommand(sqlDelete, conecDelete)
                Try
                    Using conecDelete
                        Delete.ExecuteNonQuery()
                        Delete.Dispose()
                        Delete = Nothing
                        conecDelete.Close()
                        conecDelete.Dispose()
                        conecDelete = Nothing
                    End Using
                Catch ex As Exception

                End Try

                Do While REA.Read
                    idEmpresa = REA.GetInt32("empresa") ' id de la empresa guardada en YarnDivision
                    Base = REA.GetString("base") 'Nombre de base de datos a consultar, ej.. Hilos, AmtexSV
                    codEmpresa = REA.GetInt32("codigo") ' codigo de la base de datos a utilizar ej.. Hilos = 12
                    strContaEmp = REA.GetString("conta")
                    sqlInsert = STR_VACIO

                    Select Case intTipoReport
                        Case 1
                            OpenInvoice = sqlOpenInvoices(True, codEmpresa, Base, idEmpresa)
                            sqlInsert = " Insert Into " & YarnD & ".Open_Invoice (" & OpenInvoice & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 2

                        Case 3
                            AgingSummary = sqlAgingSumary(codEmpresa, Base, idEmpresa)
                            sqlInsert = " Insert Into " & YarnD & ".AgingSummary (" & AgingSummary & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 4
                            CuentasXPagar = sqlCuentasPorPagar(codEmpresa, Base, idEmpresa)
                            sqlInsert = " Insert Into " & YarnD & ".cxp (" & CuentasXPagar & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 5, 20
                            Planning = sqlOrdenRequisicion(codEmpresa, Base, idEmpresa) ' Captura Query
                            sqlInsert = "Insert Into " & YarnD & ".Planning (" & Planning & ")" ' Crea el sql Insert
                            EjecutarConsulta(sqlInsert) ' Ejecuta el insert

                            ' Vacia variable
                            Planning = STR_VACIO
                            sqlInsert = STR_VACIO

                            Planning = sqlConfirmacion(codEmpresa, Base, idEmpresa)
                            sqlInsert = "Insert Into " & YarnD & ".Planning (" & Planning & ")"
                            EjecutarConsulta(sqlInsert)

                            ' Vacia Variables
                            Planning = STR_VACIO
                            sqlInsert = STR_VACIO

                            Planning = sqlIngresos(codEmpresa, Base, idEmpresa)
                            sqlInsert = "Insert Into " & YarnD & ".Planning (" & Planning & ")"
                            EjecutarConsulta(sqlInsert)
                            'Vacia Variable
                            Planning = STR_VACIO
                        Case 6
                            CheckReport = sqlCheckReport(idEmpresa, Base, codEmpresa, dtpFechaInicial.Value, dtpFecha.Value)
                            sqlInsert = " Insert into " & YarnD & ".CheckReport (" & CheckReport & ")"
                            EjecutarConsulta(sqlInsert)
                            CheckReport = STR_VACIO

                        Case 7
                            strVentas = sqlVentasCompanie(idEmpresa, Base, codEmpresa, dtpFechaInicial.Value, dtpFecha.Value)
                            sqlInsert = " Insert into " & YarnD & ".ventas (" & strVentas & ")"
                            EjecutarConsulta(sqlInsert)
                            strVentas = STR_VACIO
                        Case 8
                            strGross = sqlVentaGross(idEmpresa, Base, codEmpresa, dtpFechaInicial.Value, dtpFecha.Value, strContaEmp)
                            sqlInsert = " Insert into " & YarnD & ".Gross (" & strGross & ")"
                            EjecutarConsulta(sqlInsert)
                            strGross = STR_VACIO
                        Case 9
                            strOrdenesProveedores = sqlVendorsPO(idEmpresa, Base, codEmpresa, dtpFechaInicial.Value, dtpFecha.Value)
                            sqlInsert = " Insert into " & YarnD & ".VendorsPO (" & strOrdenesProveedores & ")"
                            EjecutarConsulta(sqlInsert)
                            strOrdenesProveedores = STR_VACIO
                        Case 10

                            strInvenarioCorte = SqlInventarioCorte(idEmpresa, Base, codEmpresa, dtpFecha.Value)
                            sqlInsert = " Insert into " & YarnD & ".Inventario_Corte (" & strInvenarioCorte & ")"
                            EjecutarConsulta(sqlInsert)
                            strInvenarioCorte = STR_VACIO
                        Case 11
                            strUsaInventory = SqlUsaInventory(idEmpresa, Base, codEmpresa)
                            sqlInsert = " Insert into " & YarnD & ".Usa_Inventory (" & strUsaInventory & ")"
                            EjecutarConsulta(sqlInsert)
                            strUsaInventory = STR_VACIO
                        Case 12
                            '**********Sincroniza Corporativos de Planning ***************
                            '*************************************************************
                            Planning = sqlOrdenRequisicion(codEmpresa, Base, idEmpresa) ' Captura Query
                            sqlInsert = "Insert Into " & YarnD & ".Planning (" & Planning & ")" ' Crea el sql Insert
                            EjecutarConsulta(sqlInsert) ' Ejecuta el insert

                            ' Vacia variable
                            Planning = STR_VACIO
                            sqlInsert = STR_VACIO

                            Planning = sqlConfirmacion(codEmpresa, Base, idEmpresa)
                            sqlInsert = "Insert Into " & YarnD & ".Planning (" & Planning & ")"
                            EjecutarConsulta(sqlInsert)

                            ' Vacia Variables
                            Planning = STR_VACIO
                            sqlInsert = STR_VACIO

                            Planning = sqlIngresos(codEmpresa, Base, idEmpresa)
                            sqlInsert = "Insert Into " & YarnD & ".Planning (" & Planning & ")"
                            EjecutarConsulta(sqlInsert)
                            'Vacia Variable
                            Planning = STR_VACIO

                            '//Inserta en la tabla de inventario Corte
                            strSQL = " SELECT 0 Correlativo, p.PEmpresa empresa, '{fecha}' fecha, SUM(p.PLibras) Inventario, ( "
                            strSQL &= " Select IFNULL(SUM(p1.PLibras),0) sold "
                            strSQL &= " From {yarn}.Planning p1"
                            strSQL &= " WHERE p1.PStatus_Joby LIKE '%SOLD' AND p1.PEmpresa = p.PEmpresa) sold, ( "
                            strSQL &= " Select IFNULL(SUM(p1.PLibras), 0) Transito"
                            strSQL &= " From {yarn}.Planning p1 "
                            strSQL &= " Where p1.PStatus_Joby = 'OCEAN' AND p1.PEmpresa = p.PEmpresa) Transito, ( "
                            strSQL &= " Select IFNULL(SUM(p1.PLibras), 0) Pendiente "
                            strSQL &= " From {yarn}.Planning p1 "
                            strSQL &= " Where p1.PStatus_Joby Like '%SHIP' AND p1.PEmpresa = p.PEmpresa) Pendiente, NOW() "
                            strSQL &= "    From {yarn}.Planning p "
                            strSQL &= "        Where p.PStatus_Joby = 'WAREHOUSE' AND p.PEmpresa = {emp} "

                            strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))
                            strSQL = Replace(strSQL, "{emp}", idEmpresa)
                            strSQL = Replace(strSQL, "{yarn}", YarnD)

                            sqlInsert = "Insert Into " & YarnD & ".Inventario_Historico (" & strSQL & ")"
                            EjecutarConsulta(sqlInsert)
                            strSQL = STR_VACIO
                        Case 13
                            Inventario = SqlInventario(idEmpresa, Base, codEmpresa)
                            sqlInsert = " Insert Into " & YarnD & ".Inventario (" & Inventario & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 14
                            Purchase = sqlPurchase(idEmpresa, Base, codEmpresa, dtpFechaInicial.Value, dtpFecha.Value)
                            sqlInsert = " Insert Into " & YarnD & ".Purchase (" & Purchase & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 15 ' Presupuesto Corporativo
                            strPresupuesto = sqlPresupuesto(idEmpresa, Base, codEmpresa, dtpFechaInicial.Value, dtpFecha.Value, strContaEmp)
                            sqlInsert = " Insert Into " & YarnD & ".Budget (" & strPresupuesto & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 16
                            OpenInvoice = sqlOpenInvoices(True, codEmpresa, Base, idEmpresa)
                            sqlInsert = " Insert Into " & YarnD & ".AR_Detail (" & OpenInvoice & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 17
                            VentasxCliente = sqlVentasSemanalesCliente(codEmpresa, Base, idEmpresa)
                            sqlInsert = " Insert Into " & YarnD & " .Ventasx_Cliente (" & VentasxCliente & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 18
                            OpenInvoice = sqlOpenInvoices(True, codEmpresa, Base, idEmpresa)
                            sqlInsert = " Insert Into " & YarnD & ".AR_Detail (" & OpenInvoice & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 19
                            InventarioTransito = sqlInventarioenTransito(codEmpresa, Base, idEmpresa)
                            sqlInsert = " INSERT INTO " & YarnD & ".Inventario_Transito (" & InventarioTransito & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 21
                            If intMoneda = 0 Then
                                Dim bd As String
                                If idEmpresa = 1 Then
                                    bd = "Hilos"
                                    dblTC_ = cFunciones.TasaSegunFechaC(dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                ElseIf idEmpresa = 2 Then
                                    bd = "AmtexPM"
                                    dblTC_ = cFunciones.TasaSegunFechaC(dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                ElseIf idEmpresa = 3 Then
                                    bd = "PrideYarn"
                                    dblTC_ = cFunciones.TasaSegunFechaC(dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                ElseIf idEmpresa = 4 Then
                                    bd = "Dominican"
                                    dblTC_ = cFunciones.TasaSegunFechaC(dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                End If
                                'SQLTC_Corte(frm.FechaFin)
                            Else
                                dblTC_ = INT_UNO
                            End If
                            BalanceCombinado = sqlBalanceCombinado(codEmpresa, Base, idEmpresa, strContaEmp, dblTC_)
                            sqlInsert = " INSERT INTO " & YarnD & ".Combined_Balance (" & BalanceCombinado & ")"
                            EjecutarConsulta(sqlInsert)
                        Case 22
                            If intmoneda = 0 Then
                                Dim bd As String
                                If idEmpresa = 1 Then
                                    bd = "Hilos"
                                    dblTC_ = cFunciones.SqlPromedioTCCorp(dtpFechaInicial.Value.ToString(FORMATO_MYSQL), dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                ElseIf idEmpresa = 2 Then
                                    bd = "AmtexPM"
                                    dblTC_ = cFunciones.SqlPromedioTCCorp(dtpFechaInicial.Value.ToString(FORMATO_MYSQL), dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                ElseIf idEmpresa = 3 Then
                                    bd = "PrideYarn"
                                    dblTC_ = cFunciones.SqlPromedioTCCorp(dtpFechaInicial.Value.ToString(FORMATO_MYSQL), dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                ElseIf idEmpresa = 4 Then
                                    bd = "Dominican"
                                    dblTC_ = cFunciones.SqlPromedioTCCorp(dtpFechaInicial.Value.ToString(FORMATO_MYSQL), dtpFecha.Value.ToString(FORMATO_MYSQL), bd)
                                End If
                                'SQLTC_Corte(frm.FechaFin)
                            Else
                                dblTC_ = INT_UNO
                            End If
                            PLCombinado = sqlPLCombinado(codEmpresa, Base, idEmpresa, strContaEmp, dblTC_)
                            sqlInsert = " INSERT INTO " & YarnD & ".CombinedLP (" & PLCombinado & ")"
                            EjecutarConsulta(sqlInsert)
                    End Select

                    If idEmpresa = 1 Then
                        checkHilos.Checked = True
                    ElseIf idEmpresa = 2 Then
                        checkAmtex.Checked = True
                    ElseIf idEmpresa = 3 Then
                        checkPride.Checked = True
                    ElseIf idEmpresa = 4 Then
                        checkDominican.Checked = True
                    End If

                    ProgressBar1.Maximum = 4
                    ProgressBar1.Minimum = 0
                    ProgressBar1.Step = 1

                    ProgressBar1.PerformStep()
                Loop
            End If
            lblStatus.Text = " Complete "
            lblStatus.ForeColor = Color.Green
            system.Windows.Forms.Application.DoEvents()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EjecutarConsulta(ByVal sqlInsert As String)
        Dim conecInsert As MySqlConnection
        Dim Insert As MySqlCommand

        conecInsert = New MySqlConnection(strConexion)
        conecInsert.Open()
        Insert = New MySqlCommand(sqlInsert, conecInsert)

        Using conecInsert
            Insert.ExecuteNonQuery()
            Insert.Dispose()
            Insert = Nothing
            conecInsert.Close()
            conecInsert.Dispose()
            conecInsert = Nothing
        End Using
    End Sub

    Private Sub CargarRegistro()
        Dim CargarReg As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim tblReg As String = STR_VACIO
        Try

            If intTipoReport = 1 Then
                strSQL = SQLRegistroOpenInvoice()
            Else
                If intTipoReport = 2 Then

                ElseIf intTipoReport = 3 Then
                    tblReg = "AgingSummary"
                ElseIf intTipoReport = 4 Then
                    tblReg = "cxp"
                ElseIf intTipoReport = 5 Then
                    tblReg = "Planning"
                ElseIf intTipoReport = 6 Then
                    tblReg = "CheckReport"
                ElseIf intTipoReport = 7 Then
                    tblReg = "ventas"
                ElseIf intTipoReport = 8 Then
                    tblReg = "Gross"
                ElseIf intTipoReport = 9 Then
                    tblReg = "VendorsPO"
                ElseIf intTipoReport = 10 Then
                    tblReg = "Inventario_Corte"
                ElseIf intTipoReport = 11 Then
                    tblReg = "Usa_Inventory"
                ElseIf intTipoReport = 12 Then
                    tblReg = "Inventario_Historico"
                ElseIf intTipoReport = 13 Then
                    tblReg = "Inventario"
                ElseIf intTipoReport = 14 Then
                    tblReg = "Purchase"
                ElseIf intTipoReport = 15 Then
                    tblReg = "Budget"
                ElseIf intTipoReport = 16 Then
                    tblReg = "AR_Detail"
                ElseIf intTipoReport = 17 Then
                    tblReg = "Ventasx_Cliente"
                ElseIf intTipoReport = 18 Then
                    tblReg = "AR_Detail"
                ElseIf intTipoReport = 19 Then
                    tblReg = "Inventario_Transito"
                ElseIf intTipoReport = 20 Then
                    tblReg = "Planning"
                ElseIf intTipoReport = 21 Then
                    tblReg = "Combined_Balance"
                ElseIf intTipoReport = 22 Then
                    tblReg = "CombinedLP"
                End If

                strSQL = SQLRegistroCorp(tblReg)

            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            CargarReg = COM.ExecuteScalar

            If Not CargarReg = vbNullString Then
                etiquetaRegistro.Text = "Last Synchronization " & CargarReg
            Else
                etiquetaRegistro.Text = "No synchronized data"
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "Eventos"
    Private Sub frmSincronizacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        checkHilos.Checked = False
        checkAmtex.Checked = False
        checkPride.Checked = False
        checkDominican.Checked = False
        BarraTitulo1.CambiarTitulo("Synchronize Companies")
        CargarRegistro()

        Select Case intTipoReport
            Case 6, 7, 8, 14, 15, 17, 21, 22
                dtpFechaInicial.Visible = True
                dtpFecha.Visible = True
            Case 9
                dtpFechaInicial.Visible = True
                dtpFecha.Visible = True
            Case 11
                dtpFecha.Visible = False
                dtpFechaInicial.Visible = False
            Case Else
                dtpFechaInicial.Visible = False
                dtpFecha.Visible = True
        End Select

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Dim rpt As New clsReportesCorporativos
        Dim Op As New frmOption
        Dim OpFiltro As New frmOption
        Me.DialogResult = DialogResult.OK

        Select Case intTipoReport
            Case 1
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select your report "
                Op.Opciones = "Open Invoice|Projection"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    Select Case Op.Seleccion
                        Case INT_CERO
                            rpt.OpenInvoiceCorp()
                        Case INT_UNO
                            rpt.Projection()
                    End Select
                End If
            Case 2

            Case 3
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select a Company "
                Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    OpFiltro.Titulo = "Corporative Reports"
                    OpFiltro.Mensaje = "Select a Filter"
                    OpFiltro.Opciones = "All|Intercompany|Yarn + Fabric|Chemical|Spinning Mills"
                    If OpFiltro.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case Op.Seleccion
                            Case INT_CERO
                                rpt.ReporteAR_AgingCorp(0, OpFiltro.Seleccion, dtpFecha.Value)
                            Case INT_UNO
                                rpt.ReporteAR_AgingCorp(1, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 2
                                rpt.ReporteAR_AgingCorp(3, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 3
                                rpt.ReporteAR_AgingCorp(2, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 4
                                rpt.ReporteAR_AgingCorp(4, OpFiltro.Seleccion, dtpFecha.Value)
                        End Select
                    End If

                End If
            Case 4
                Dim frm As New frmOption
                Dim fop As New frmOption
                frm.Titulo = "Report Option"
                frm.Mensaje = "Select"
                frm.Opciones = "Summary | Detail"
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    Select Case frm.Seleccion
                        Case 0
                            'rpt.CxprepcorporativoSummary(dtpFecha.Value)
                            Op.Titulo = "Select a Company"
                            Op.Mensaje = "Select a Company"
                            Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                            If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                                fop.Titulo = "Select type"
                                fop.Mensaje = "Select type"
                                fop.Opciones = "All|Intercompany|Yarn|Chemical|Production Plant"

                                If fop.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                                    Select Case Op.Seleccion
                                        Case INT_CERO
                                            rpt.CxprepcorporativoSummary(dtpFecha.Value, 0, fop.Seleccion)
                                        Case INT_UNO
                                            rpt.CxprepcorporativoSummary(dtpFecha.Value, 1, fop.Seleccion)
                                        Case 2
                                            rpt.CxprepcorporativoSummary(dtpFecha.Value, 3, fop.Seleccion)
                                        Case 3
                                            rpt.CxprepcorporativoSummary(dtpFecha.Value, 2, fop.Seleccion)
                                        Case 4
                                            rpt.CxprepcorporativoSummary(dtpFecha.Value, 4, fop.Seleccion)
                                    End Select
                                End If

                            End If
                        Case 1
                            Op.Titulo = "Select a Company"
                            Op.Mensaje = "Select a Company"
                            Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                            If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                                fop.Titulo = "Select type"
                                fop.Mensaje = "Select type"
                                fop.Opciones = "All|Intercompany|Yarn|Chemical|Production Plant"

                                If fop.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                                    Select Case Op.Seleccion
                                        Case INT_CERO
                                            rpt.Cxprepcorporativo(dtpFecha.Value, 0, fop.Seleccion)
                                        Case INT_UNO
                                            rpt.Cxprepcorporativo(dtpFecha.Value, 1, fop.Seleccion)
                                        Case 2
                                            rpt.Cxprepcorporativo(dtpFecha.Value, 3, fop.Seleccion)
                                        Case 3
                                            rpt.Cxprepcorporativo(dtpFecha.Value, 2, fop.Seleccion)
                                        Case 4
                                            rpt.Cxprepcorporativo(dtpFecha.Value, 4, fop.Seleccion)
                                    End Select
                                End If

                            End If
                    End Select
                End If

            Case 5

                Op.Titulo = "Reports"
                Op.Mensaje = "select the Report to Generate"
                Op.Opciones = "Chart" & "|" & "Available" & "|" & "Available Revised" & "|" & "Inventory Sumary" & "|" & "Inventory by Category"
                Dim opf As New frmOption
                opf.Titulo = "Reports"
                opf.Mensaje = "select the Report to Generate"
                opf.Opciones = "Yarn" & "|" & "Fiber"
                'Dim opOrigen As New frmOption
                'opOrigen.Titulo = "Reports"
                'opOrigen.Mensaje = "select the Report to Generate"
                'opOrigen.Opciones = "ASIA" & "|" & "NAFTA"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then ' Que reporte imprimir
                    If opf.ShowDialog = System.Windows.Forms.DialogResult.OK Then 'tipo de datos --> Hilo o fibra
                        'If opOrigen.ShowDialog = System.Windows.Forms.DialogResult.OK Then ' Origen del producto (ASIA o NAFTA)
                        Select Case Op.Seleccion
                                Case 0
                                    rpt.ChartCorp(opf.Seleccion)', opOrigen.Seleccion)
                                Case 1
                                    rpt.AvailableCorp(opf.Seleccion)', opOrigen.Seleccion)
                                Case 2
                                    rpt.AvailableRevisedCorp(opf.Seleccion)', opOrigen.Seleccion)
                                Case 3
                                    rpt.InventoryInWarehouse(opf.Seleccion)', opOrigen.Seleccion)
                                Case 4
                                    rpt.InventarioPorCategoria(opf.Seleccion) ', opOrigen.Seleccion)
                            End Select
                            'End If
                        End If
                Else
                    Exit Sub
                End If
            Case 6
                rpt.CheckReport(dtpFechaInicial.Value, dtpFecha.Value)
            Case 7
                Dim frm As New frmOption
                frm.Titulo = "Opcion de Reporte"
                frm.Opciones = "Summary | Detail"
                frm.ShowDialog(Me)

                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    Select Case frm.Seleccion
                        Case 0
                            rpt.ResumenByAcount(dtpFechaInicial.Value, dtpFecha.Value)
                        Case 1

                            rpt.SalesByAccount(dtpFechaInicial.Value, dtpFecha.Value)
                    End Select
                End If
            Case 8
                'Dim frm As New frmOption
                'frm.Titulo = "Opcion de Reporte"
                'frm.Opciones = "Summary | Detail"
                'frm.ShowDialog(Me)

                'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'Select Case frm.Seleccion
                'Case 1
                rpt.GrossMarginCorp(dtpFechaInicial.Value, dtpFecha.Value)

                'Case 0
                'rpt.GrossMarginCorpSummary(dtpFechaInicial.Value, dtpFecha.Value)

                    'End Select
                'End If
            Case 9
                rpt.VendorsPOCorp(dtpFechaInicial.Value, dtpFecha.Value)
            Case 10
                MsgBox("Done")
            Case 11
                rpt.UsaInventoryCorp()
            Case 12
                rpt.InventoryHistorical()
            Case 13
                Dim frmF As New frmFiltroInventarioCorp
                frmF.ShowDialog(Me)
                If frmF.DialogResult = DialogResult.OK Then
                    rpt.InventoryCorp(frmF.Estado, frmF.Hilo, frmF.CantidadInicio, frmF.CantidadFin)
                End If
            Case 14
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select a Company "
                Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    Select Case Op.Seleccion
                        Case INT_CERO
                            rpt.PurchasByVendorCorp(dtpFechaInicial.Value, dtpFecha.Value, 0)
                        Case INT_UNO
                            rpt.PurchasByVendorCorp(dtpFechaInicial.Value, dtpFecha.Value, 1)
                        Case 2
                            rpt.PurchasByVendorCorp(dtpFechaInicial.Value, dtpFecha.Value, 3)
                        Case 3
                            rpt.PurchasByVendorCorp(dtpFechaInicial.Value, dtpFecha.Value, 2)
                        Case 4
                            rpt.PurchasByVendorCorp(dtpFechaInicial.Value, dtpFecha.Value, 4)
                    End Select
                End If

            Case 15
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select your report "
                Op.Opciones = "Budgeted|Spent|All"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    Select Case Op.Seleccion
                        Case INT_CERO
                            rpt.ReportePresupuestoAnual(dtpFechaInicial.Value, dtpFecha.Value, INT_CERO)
                        Case INT_UNO
                            rpt.ReportePresupuestoAnual(dtpFechaInicial.Value, dtpFecha.Value, INT_UNO)
                        Case 2
                            rpt.ReportePresupuestoIntegrado(dtpFechaInicial.Value, dtpFecha.Value)
                    End Select
                End If
            Case 16 'AR Detail
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select a Company "
                Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    OpFiltro.Titulo = "Corporative Reports"
                    OpFiltro.Mensaje = "Select a Filter"
                    OpFiltro.Opciones = "All|Intercompany|Yarn + Fabric|Chemical|Spinning Mills"
                    If OpFiltro.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case Op.Seleccion
                            Case INT_CERO
                                rpt.AR_DetailCorp(0, OpFiltro.Seleccion, dtpFecha.Value)
                            Case INT_UNO
                                rpt.AR_DetailCorp(1, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 2
                                rpt.AR_DetailCorp(3, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 3
                                rpt.AR_DetailCorp(2, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 4
                                rpt.AR_DetailCorp(4, OpFiltro.Seleccion, dtpFecha.Value)
                        End Select
                    End If

                End If
            Case 17 'Ventas X Cliente 
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select a Company "
                Op.Opciones = "Hilos|PrideYarn|Amtex|Dominican"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    Select Case Op.Seleccion
                        Case INT_CERO
                            rpt.VentasXClienteCorp(1, 12)
                        Case 1
                            rpt.VentasXClienteCorp(3, 11)
                        Case 2
                            rpt.VentasXClienteCorp(2, 16)
                        Case 3
                            rpt.VentasXClienteCorp(4, 14)
                    End Select
                End If

            Case 18 'AR Detail Creit Limt
                Op.Titulo = "Corporative Reports"
                Op.Mensaje = "Select a Company "
                Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    OpFiltro.Titulo = "Corporative Reports"
                    OpFiltro.Mensaje = "Select a Filter"
                    OpFiltro.Opciones = "All|Intercompany|Yarn + Fabric|Chemical|Spinning Mills"
                    If OpFiltro.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case Op.Seleccion
                            Case INT_CERO
                                rpt.AR_DetailCorpCreditLimit(0, OpFiltro.Seleccion, dtpFecha.Value)
                            Case INT_UNO
                                rpt.AR_DetailCorpCreditLimit(1, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 2
                                rpt.AR_DetailCorpCreditLimit(3, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 3
                                rpt.AR_DetailCorpCreditLimit(2, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 4
                                rpt.AR_DetailCorpCreditLimit(4, OpFiltro.Seleccion, dtpFecha.Value)
                        End Select
                    End If
                End If
            Case 19 'Inventario en Transito 
                Op.Titulo = "Inventory in transit"
                Op.Mensaje = "Select a Company "
                Op.Opciones = "All|Hilos|PrideYarn|Amtex|Dominican"
                If Op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    OpFiltro.Titulo = "Corporative Reports"
                    OpFiltro.Mensaje = "Select a Filter"
                    OpFiltro.Opciones = "YARN|CHEMICAL|FIBER|All"
                    If OpFiltro.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case Op.Seleccion
                            Case INT_CERO
                                rpt.InventarioenTransito(0, OpFiltro.Seleccion, dtpFecha.Value)
                            Case INT_UNO
                                rpt.InventarioenTransito(1, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 2
                                rpt.InventarioenTransito(3, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 3
                                rpt.InventarioenTransito(2, OpFiltro.Seleccion, dtpFecha.Value)
                            Case 4
                                rpt.InventarioenTransito(4, OpFiltro.Seleccion, dtpFecha.Value)
                        End Select
                    End If
                End If
            Case 20
                rpt.InventoryAsiaReport(dtpFecha.Value)
            Case 21 'Balance Combinado 
                rpt.BalanceReport(dtpFechaInicial.Value, dtpFecha.Value)
            Case 22 'Balance Combinado 
                rpt.PLReport(dtpFechaInicial.Value, dtpFecha.Value)
        End Select

        Me.Close()
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub BarraTitulo1_Load(sender As Object, e As EventArgs) Handles BarraTitulo1.Load

    End Sub

#End Region

End Class