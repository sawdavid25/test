﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGrupos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgListaPrincipal = New System.Windows.Forms.DataGridView()
        Me.colNumeroGrupo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNameGrupo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoGrupo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dglistadoDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidEmpresaEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEditar = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.CheckFavorito = New System.Windows.Forms.CheckBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgListaPrincipal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dglistadoDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEditar.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgListaPrincipal)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 110)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(978, 89)
        Me.panelListaPrincipal.TabIndex = 2
        '
        'dgListaPrincipal
        '
        Me.dgListaPrincipal.AllowUserToAddRows = False
        Me.dgListaPrincipal.AllowUserToDeleteRows = False
        Me.dgListaPrincipal.AllowUserToOrderColumns = True
        Me.dgListaPrincipal.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgListaPrincipal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaPrincipal.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumeroGrupo, Me.colNameGrupo, Me.colTipoGrupo, Me.colClasificacion, Me.colClase})
        Me.dgListaPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaPrincipal.Location = New System.Drawing.Point(0, 0)
        Me.dgListaPrincipal.Name = "dgListaPrincipal"
        Me.dgListaPrincipal.ReadOnly = True
        Me.dgListaPrincipal.RowTemplate.Height = 24
        Me.dgListaPrincipal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaPrincipal.Size = New System.Drawing.Size(978, 89)
        Me.dgListaPrincipal.TabIndex = 0
        '
        'colNumeroGrupo
        '
        Me.colNumeroGrupo.HeaderText = "Code Group "
        Me.colNumeroGrupo.Name = "colNumeroGrupo"
        Me.colNumeroGrupo.ReadOnly = True
        '
        'colNameGrupo
        '
        Me.colNameGrupo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNameGrupo.HeaderText = "Name"
        Me.colNameGrupo.Name = "colNameGrupo"
        Me.colNameGrupo.ReadOnly = True
        Me.colNameGrupo.Width = 74
        '
        'colTipoGrupo
        '
        Me.colTipoGrupo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTipoGrupo.HeaderText = "kind"
        Me.colTipoGrupo.Name = "colTipoGrupo"
        Me.colTipoGrupo.ReadOnly = True
        Me.colTipoGrupo.Visible = False
        '
        'colClasificacion
        '
        Me.colClasificacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClasificacion.HeaderText = "Classification"
        Me.colClasificacion.Name = "colClasificacion"
        Me.colClasificacion.ReadOnly = True
        Me.colClasificacion.Visible = False
        '
        'colClase
        '
        Me.colClase.HeaderText = "Group Class"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dglistadoDetalle)
        Me.panelDetalle.Controls.Add(Me.panelEditar)
        Me.panelDetalle.Controls.Add(Me.panelEncabezado)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 199)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(978, 363)
        Me.panelDetalle.TabIndex = 3
        '
        'dglistadoDetalle
        '
        Me.dglistadoDetalle.AllowUserToAddRows = False
        Me.dglistadoDetalle.AllowUserToDeleteRows = False
        Me.dglistadoDetalle.AllowUserToOrderColumns = True
        Me.dglistadoDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dglistadoDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dglistadoDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colCliente, Me.colLinea, Me.colEmpresa, Me.colidEmpresaEmpresa, Me.colExtra})
        Me.dglistadoDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dglistadoDetalle.Location = New System.Drawing.Point(0, 90)
        Me.dglistadoDetalle.Name = "dglistadoDetalle"
        Me.dglistadoDetalle.ReadOnly = True
        Me.dglistadoDetalle.RowTemplate.Height = 24
        Me.dglistadoDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dglistadoDetalle.Size = New System.Drawing.Size(909, 273)
        Me.dglistadoDetalle.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Description"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 108
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'colEmpresa
        '
        Me.colEmpresa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEmpresa.HeaderText = "Company"
        Me.colEmpresa.Name = "colEmpresa"
        Me.colEmpresa.ReadOnly = True
        Me.colEmpresa.Width = 96
        '
        'colidEmpresaEmpresa
        '
        Me.colidEmpresaEmpresa.HeaderText = "Company code"
        Me.colidEmpresaEmpresa.Name = "colidEmpresaEmpresa"
        Me.colidEmpresaEmpresa.ReadOnly = True
        Me.colidEmpresaEmpresa.Visible = False
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'panelEditar
        '
        Me.panelEditar.Controls.Add(Me.botonQuitar)
        Me.panelEditar.Controls.Add(Me.botonAgregar)
        Me.panelEditar.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelEditar.Location = New System.Drawing.Point(909, 90)
        Me.panelEditar.Name = "panelEditar"
        Me.panelEditar.Size = New System.Drawing.Size(69, 273)
        Me.panelEditar.TabIndex = 2
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(10, 93)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(50, 35)
        Me.botonQuitar.TabIndex = 3
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(10, 29)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(50, 37)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.CheckFavorito)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNombre)
        Me.panelEncabezado.Controls.Add(Me.celdaNombre)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(978, 90)
        Me.panelEncabezado.TabIndex = 0
        '
        'CheckFavorito
        '
        Me.CheckFavorito.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckFavorito.AutoSize = True
        Me.CheckFavorito.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckFavorito.Location = New System.Drawing.Point(841, 53)
        Me.CheckFavorito.Name = "CheckFavorito"
        Me.CheckFavorito.Size = New System.Drawing.Size(68, 22)
        Me.CheckFavorito.TabIndex = 4
        Me.CheckFavorito.Text = "Mark"
        Me.CheckFavorito.UseVisualStyleBackColor = True
        '
        'celdaNumero
        '
        Me.celdaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumero.Location = New System.Drawing.Point(531, 51)
        Me.celdaNumero.Multiline = True
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(68, 33)
        Me.celdaNumero.TabIndex = 3
        Me.celdaNumero.Text = "-1"
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(528, 26)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(102, 17)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Group Number"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(20, 26)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(89, 17)
        Me.etiquetaNombre.TabIndex = 1
        Me.etiquetaNombre.Text = "Group Name"
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(23, 51)
        Me.celdaNombre.Multiline = True
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(442, 33)
        Me.celdaNombre.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 76)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(978, 34)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(978, 76)
        Me.Encabezado1.TabIndex = 0
        '
        'frmGrupos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(978, 562)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmGrupos"
        Me.Text = "frmGrupos"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgListaPrincipal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dglistadoDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEditar.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgListaPrincipal As DataGridView
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents dglistadoDetalle As DataGridView
    Friend WithEvents panelEditar As Panel
    Friend WithEvents etiquetaNombre As Label
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents colNumeroGrupo As DataGridViewTextBoxColumn
    Friend WithEvents colNameGrupo As DataGridViewTextBoxColumn
    Friend WithEvents colTipoGrupo As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacion As DataGridViewTextBoxColumn
    Friend WithEvents colClase As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colEmpresa As DataGridViewTextBoxColumn
    Friend WithEvents colidEmpresaEmpresa As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents CheckFavorito As System.Windows.Forms.CheckBox
End Class
