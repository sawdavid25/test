﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSincronizacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.checkHilos = New System.Windows.Forms.CheckBox()
        Me.checkAmtex = New System.Windows.Forms.CheckBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.checkDominican = New System.Windows.Forms.CheckBox()
        Me.botonSincronizar = New System.Windows.Forms.Button()
        Me.checkPride = New System.Windows.Forms.CheckBox()
        Me.etiquetaRegistro = New System.Windows.Forms.Label()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechaCorte = New System.Windows.Forms.Label()
        Me.gbEncabezado = New System.Windows.Forms.GroupBox()
        Me.gbReporte = New System.Windows.Forms.GroupBox()
        Me.gbFiltros = New System.Windows.Forms.GroupBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.panelEncabezado.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.panelFiltro.SuspendLayout()
        Me.gbEncabezado.SuspendLayout()
        Me.gbReporte.SuspendLayout()
        Me.gbFiltros.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelEncabezado
        '
        Me.panelEncabezado.BackColor = System.Drawing.SystemColors.Control
        Me.panelEncabezado.Controls.Add(Me.lblStatus)
        Me.panelEncabezado.Controls.Add(Me.checkHilos)
        Me.panelEncabezado.Controls.Add(Me.checkAmtex)
        Me.panelEncabezado.Controls.Add(Me.ProgressBar1)
        Me.panelEncabezado.Controls.Add(Me.checkDominican)
        Me.panelEncabezado.Controls.Add(Me.botonSincronizar)
        Me.panelEncabezado.Controls.Add(Me.checkPride)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelEncabezado.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        Me.panelEncabezado.Location = New System.Drawing.Point(3, 19)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(597, 145)
        Me.panelEncabezado.TabIndex = 1
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(144, 34)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(60, 25)
        Me.lblStatus.TabIndex = 6
        Me.lblStatus.Text = " ......."
        '
        'checkHilos
        '
        Me.checkHilos.AutoSize = True
        Me.checkHilos.Enabled = False
        Me.checkHilos.Location = New System.Drawing.Point(13, 14)
        Me.checkHilos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkHilos.Name = "checkHilos"
        Me.checkHilos.Size = New System.Drawing.Size(61, 21)
        Me.checkHilos.TabIndex = 2
        Me.checkHilos.Text = "Hilos"
        Me.checkHilos.UseVisualStyleBackColor = True
        '
        'checkAmtex
        '
        Me.checkAmtex.AutoSize = True
        Me.checkAmtex.Enabled = False
        Me.checkAmtex.Location = New System.Drawing.Point(13, 41)
        Me.checkAmtex.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkAmtex.Name = "checkAmtex"
        Me.checkAmtex.Size = New System.Drawing.Size(68, 21)
        Me.checkAmtex.TabIndex = 3
        Me.checkAmtex.Text = "Amtex"
        Me.checkAmtex.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ProgressBar1.Location = New System.Drawing.Point(149, 84)
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(439, 36)
        Me.ProgressBar1.TabIndex = 2
        '
        'checkDominican
        '
        Me.checkDominican.AutoSize = True
        Me.checkDominican.CheckAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.checkDominican.Enabled = False
        Me.checkDominican.Location = New System.Drawing.Point(13, 95)
        Me.checkDominican.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkDominican.Name = "checkDominican"
        Me.checkDominican.Size = New System.Drawing.Size(96, 21)
        Me.checkDominican.TabIndex = 5
        Me.checkDominican.Text = "Dominican"
        Me.checkDominican.UseVisualStyleBackColor = True
        '
        'botonSincronizar
        '
        Me.botonSincronizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSincronizar.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.botonSincronizar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonSincronizar.Location = New System.Drawing.Point(484, 2)
        Me.botonSincronizar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonSincronizar.Name = "botonSincronizar"
        Me.botonSincronizar.Size = New System.Drawing.Size(104, 48)
        Me.botonSincronizar.TabIndex = 9
        Me.botonSincronizar.Text = "To synchronize"
        Me.botonSincronizar.UseVisualStyleBackColor = False
        '
        'checkPride
        '
        Me.checkPride.AutoSize = True
        Me.checkPride.Enabled = False
        Me.checkPride.Location = New System.Drawing.Point(13, 68)
        Me.checkPride.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkPride.Name = "checkPride"
        Me.checkPride.Size = New System.Drawing.Size(97, 21)
        Me.checkPride.TabIndex = 4
        Me.checkPride.Text = "Pride Yarn"
        Me.checkPride.UseVisualStyleBackColor = True
        '
        'etiquetaRegistro
        '
        Me.etiquetaRegistro.AutoSize = True
        Me.etiquetaRegistro.ForeColor = System.Drawing.Color.Maroon
        Me.etiquetaRegistro.Location = New System.Drawing.Point(81, 95)
        Me.etiquetaRegistro.Name = "etiquetaRegistro"
        Me.etiquetaRegistro.Size = New System.Drawing.Size(57, 18)
        Me.etiquetaRegistro.TabIndex = 6
        Me.etiquetaRegistro.Text = "Label1"
        '
        'panelBotones
        '
        Me.panelBotones.BackColor = System.Drawing.SystemColors.Control
        Me.panelBotones.Controls.Add(Me.botonCancelar)
        Me.panelBotones.Controls.Add(Me.botonAceptar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelBotones.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        Me.panelBotones.Location = New System.Drawing.Point(3, 19)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(597, 89)
        Me.panelBotones.TabIndex = 2
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonCancelar.Location = New System.Drawing.Point(320, 10)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(101, 66)
        Me.botonCancelar.TabIndex = 1
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(460, 10)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(101, 66)
        Me.botonAceptar.TabIndex = 10
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Controls.Add(Me.dtpFecha)
        Me.panelFiltro.Controls.Add(Me.etiquetaFechaCorte)
        Me.panelFiltro.Controls.Add(Me.etiquetaRegistro)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelFiltro.Location = New System.Drawing.Point(3, 19)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(597, 151)
        Me.panelFiltro.TabIndex = 3
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(9, 46)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(132, 22)
        Me.dtpFechaInicial.TabIndex = 7
        '
        'dtpFecha
        '
        Me.dtpFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(171, 46)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(132, 22)
        Me.dtpFecha.TabIndex = 8
        '
        'etiquetaFechaCorte
        '
        Me.etiquetaFechaCorte.AutoSize = True
        Me.etiquetaFechaCorte.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        Me.etiquetaFechaCorte.Location = New System.Drawing.Point(9, 12)
        Me.etiquetaFechaCorte.Name = "etiquetaFechaCorte"
        Me.etiquetaFechaCorte.Size = New System.Drawing.Size(84, 17)
        Me.etiquetaFechaCorte.TabIndex = 0
        Me.etiquetaFechaCorte.Text = "Cut-off Date"
        '
        'gbEncabezado
        '
        Me.gbEncabezado.Controls.Add(Me.panelEncabezado)
        Me.gbEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbEncabezado.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbEncabezado.Location = New System.Drawing.Point(0, 37)
        Me.gbEncabezado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbEncabezado.Name = "gbEncabezado"
        Me.gbEncabezado.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbEncabezado.Size = New System.Drawing.Size(603, 166)
        Me.gbEncabezado.TabIndex = 4
        Me.gbEncabezado.TabStop = False
        Me.gbEncabezado.Text = "Synchronization"
        '
        'gbReporte
        '
        Me.gbReporte.Controls.Add(Me.panelBotones)
        Me.gbReporte.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.gbReporte.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbReporte.Location = New System.Drawing.Point(0, 375)
        Me.gbReporte.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbReporte.Name = "gbReporte"
        Me.gbReporte.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbReporte.Size = New System.Drawing.Size(603, 110)
        Me.gbReporte.TabIndex = 5
        Me.gbReporte.TabStop = False
        Me.gbReporte.Text = "Generate Report"
        '
        'gbFiltros
        '
        Me.gbFiltros.Controls.Add(Me.panelFiltro)
        Me.gbFiltros.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbFiltros.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbFiltros.Location = New System.Drawing.Point(0, 203)
        Me.gbFiltros.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbFiltros.Name = "gbFiltros"
        Me.gbFiltros.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbFiltros.Size = New System.Drawing.Size(603, 172)
        Me.gbFiltros.TabIndex = 6
        Me.gbFiltros.TabStop = False
        Me.gbFiltros.Text = "Filters"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.SystemColors.Info
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(603, 37)
        Me.BarraTitulo1.TabIndex = 0
        '
        'frmSincronizacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(603, 485)
        Me.Controls.Add(Me.gbFiltros)
        Me.Controls.Add(Me.gbReporte)
        Me.Controls.Add(Me.gbEncabezado)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmSincronizacion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Synchronization "
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.gbEncabezado.ResumeLayout(False)
        Me.gbReporte.ResumeLayout(False)
        Me.gbFiltros.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents checkDominican As System.Windows.Forms.CheckBox
    Friend WithEvents checkPride As System.Windows.Forms.CheckBox
    Friend WithEvents checkAmtex As System.Windows.Forms.CheckBox
    Friend WithEvents checkHilos As System.Windows.Forms.CheckBox
    Friend WithEvents botonSincronizar As Button
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents etiquetaRegistro As Label
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFechaCorte As Label
    Friend WithEvents gbEncabezado As GroupBox
    Friend WithEvents gbReporte As GroupBox
    Friend WithEvents gbFiltros As GroupBox
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents lblStatus As Label
End Class
