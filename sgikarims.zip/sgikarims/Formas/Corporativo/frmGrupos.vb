﻿Public Class frmGrupos

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim YarnD As String = "YarnDivision"
    Dim intTipo As Integer = NO_FILA 'el tipo de Grupo... 1-Clientes | 2-Hilos

#End Region

#Region "Prodiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Function QueryListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select g.idGrupo id, g.nombre_Grupo Nombre, g.idTipo tipo, g.idClasificacion Clasificacion, p.ClaseGrp Clase "
        strSQL &= "    From " & YarnD & ".Grupo g"
        strSQL &= "      LEFT JOIN " & YarnD & ".Permiso p ON p.Usuario = '{usuaio}'  AND p.idTipoGrp = g.idTipo "
        strSQL &= "        where g.idGrupo >=1 AND p.`Status` =  1 "
        strSQL &= "             Order by p.ClaseGrp, g.idGrupo"

        strSQL = Replace(strSQL, "{usuaio}", Sesion.Usuario)

        Return strSQL

    End Function

    Private Sub LimpiarCampos()
        celdaNombre.Clear()
        celdaNumero.Text = NO_FILA
        CheckFavorito.Checked = False
        dglistadoDetalle.Rows.Clear()

    End Sub

    Private Function QueryDetalle(ByVal grupo As Integer, ByVal tipo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT g.idGrupo id, g.nombre_Grupo nombre, IF(d.Codigo = 0, d.cta_Contable, d.Codigo) codigo, d.nombre_cliente cliente, d.Linea linea, d.idEmpresa, e.nombre_empresa company, g.idClasificacion Favorito "
        strSQL &= "    From " & YarnD & ".Grupo g "
        strSQL &= "        Left JOIN " & YarnD & ".Grupo_Detalle d ON d.idGrupo = g.idGrupo AND d.idTipo = g.idTipo "
        strSQL &= "            Left JOIN " & YarnD & ".Empresa e ON e.idEmpresa = d.idEmpresa "
        strSQL &= "                WHERE g.idGrupo = {grupo} AND g.idTipo = {tipo} "

        strSQL = Replace(strSQL, "{grupo}", grupo)
        strSQL = Replace(strSQL, "{tipo}", tipo)

        Return strSQL
    End Function

    Public Function BorrarEncabezadoGrupo() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM " & YarnD & ".Grupo  WHERE idGrupo = {grupo}  AND idTipo = {tipo} "
            strSQL = Replace(strSQL, "{grupo}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{tipo}", intTipo)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Public Function BorrarDetalleGrupo() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM " & YarnD & ".Grupo_Detalle  WHERE idGrupo = {grupo}  AND idTipo = {tipo} "
            strSQL = Replace(strSQL, "{grupo}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{tipo}", intTipo)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional ByVal logInsert As Boolean = True)
        Try

            'Muestra el listado principal
            If logMostrar = True Then
                panelListaPrincipal.Visible = True
                panelListaPrincipal.Dock = DockStyle.Fill
                panelDetalle.Visible = False
                panelDetalle.Dock = DockStyle.None
                BarraTitulo1.CambiarTitulo("Groups")
                BloquearBotones()

                ListaPrincipal()
            Else
                'Muestra el Detalle
                panelListaPrincipal.Visible = False
                panelListaPrincipal.Dock = DockStyle.None
                panelDetalle.Visible = True
                panelDetalle.Dock = DockStyle.Fill

                'Modificación
                If logInsert = False Then
                    BarraTitulo1.CambiarTitulo("Modifi Register")
                    Me.Tag = "Mod"
                    BloquearBotones(False)
                Else
                    'Nuevo
                    BarraTitulo1.CambiarTitulo("New Group")
                    Me.Tag = "Nuevo"
                    BloquearBotones(False)

                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If

    End Sub

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarCampos()
        Dim comprobar As Boolean = True
        Try
            If celdaNombre.Text = vbNullString Then
                Return comprobar = False
                Exit Function
            End If
            If dglistadoDetalle.Rows.Count > 0 Then
            Else
                Return comprobar = False
                Exit Function
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return comprobar
    End Function

    Private Sub GuardarGrupo()
        Dim grp As New Tablas.TGRUPO

        Try
            grp.CONEXION = strConexion

            grp.IDGRUPO = celdaNumero.Text
            grp.IDTIPO = intTipo
            grp.IDCLASIFICACION = IIf(CheckFavorito.Checked = False, 0, 1)
            grp.NOMBRE_GRUPO = celdaNombre.Text
            grp.USUARIO = Sesion.Usuario

            If Me.Tag = "Nuevo" Then
                If grp.PINSERT(YarnD) = False Then
                    MsgBox(grp.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            Else
                If grp.PUPDATE(YarnD) = False Then
                    MsgBox(grp.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub GuardarDetalleGrp()
        Dim Det As New Tablas.TGRUPO_DETALLE
        Dim i As Integer = 0

        Try
            Det.CONEXION = strConexion

            For i = 0 To dglistadoDetalle.Rows.Count - 1


                Det.IDGRUPO = celdaNumero.Text
                Det.IDTIPO = intTipo

                If dglistadoDetalle.Rows(i).Cells("colLinea").Value = 0 Then '0 es Nuevo, 1 Modificación
                    dglistadoDetalle.Rows(i).Cells("colLinea").Value = NuevaLineaGrupo()
                    Det.LINEA = dglistadoDetalle.Rows(i).Cells("colLinea").Value
                Else
                    Det.LINEA = dglistadoDetalle.Rows(i).Cells("colLinea").Value
                End If
                Det.IDEMPRESA = dglistadoDetalle.Rows(i).Cells("colidEmpresaEmpresa").Value
                If intTipo = 4 Or intTipo = 5 Then
                    Det.CODIGO = 0
                    Det.CTA_CONTABLE = dglistadoDetalle.Rows(i).Cells("colCodigo").Value
                Else
                    Det.CODIGO = dglistadoDetalle.Rows(i).Cells("colCodigo").Value
                End If

                Det.NOMBRE_CLIENTE = dglistadoDetalle.Rows(i).Cells("colCliente").Value

                If dglistadoDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If Det.PINSERT(YarnD) = False Then
                        MsgBox(Det.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dglistadoDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If Det.PUPDATE(YarnD) = False Then
                        MsgBox(Det.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dglistadoDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If Det.PDELETE("", YarnD) = False Then
                        MsgBox(Det.MERROR.ToString & "Line not deleted", MsgBoxStyle.Critical)
                    End If
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function NuevaLineaGrupo()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " SELECT IFNULL(MAX(gd.Linea +1),1) Linea  "
        strSQL &= "    FROM " & YarnD & ".Grupo_Detalle gd "
        strSQL &= "         WHERE gd.idGrupo = {grupo} AND gd.idTipo = {id} "

        strSQL = Replace(strSQL, "{grupo}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{id}", intTipo)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        End Using
    End Function

    Private Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = QueryListaPrincipal()
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgListaPrincipal.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("id") & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("Clasificacion") & "|"
                    strFila &= REA.GetString("Clase")

                    cfun.AgregarFila(dgListaPrincipal, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarDatosGrupo(ByVal intGrupo As Integer, ByVal intTipo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = QueryDetalle(intGrupo, intTipo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dglistadoDetalle.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    celdaNombre.Text = REA.GetString("nombre")
                    celdaNumero.Text = REA.GetInt32("id")
                    If REA.GetInt32("Favorito") = 1 Then
                        CheckFavorito.Checked = True
                    Else
                        CheckFavorito.Checked = False
                    End If

                    strFila = REA.GetString("codigo") & "|"
                    strFila &= REA.GetString("cliente") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetString("company") & "|"
                    strFila &= REA.GetInt32("idEmpresa") & "|"
                    strFila &= INT_UNO

                    cfun.AgregarFila(dglistadoDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub CargarInformacion()
        Dim strSQL As String = STR_VACIO
        Dim Opciones As New frmOption
        Dim frmS As New frmSeleccionar
        Dim idEmp As Integer = 0
        Dim nomEmp As String = STR_VACIO
        Dim nomConta As String = STR_VACIO
        Dim strfila As String = STR_VACIO
        Dim i As Integer = 0

        'strSQL = " Select e.idEmpresa codigo, e.nombre_empresa nombre, e.codigo_empresa idempresa "
        'strSQL &= "    From YarnDivision.Empresa e "
        Try
            Opciones.Titulo = "Option"
            Opciones.Mensaje = "Select an Option"
            Opciones.Opciones = "Hilos" & "|" & "Amtex" & "|" & "Pride Yarn" & "|" & "Dominican"

            If Opciones.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case Opciones.Seleccion
                    Case 0
                        idEmp = 1 'Numero de empresa guardada en la tabla empresa de la BDD YarnDivision
                        nomEmp = "Hilos" 'nombre de la BDD a utilizar para jalar clientes
                        nomConta = "contahilos"
                    Case 1
                        idEmp = 2
                        nomEmp = "AmtexPM"
                        nomConta = "contapm"
                    Case 2
                        idEmp = 3
                        nomEmp = "PrideYarn"
                        nomConta = "contapy"
                    Case 3
                        idEmp = 4
                        nomEmp = "Dominican"
                        nomConta = "contadominican"
                End Select


                If intTipo = 1 Then
                    frmS.Titulo = "Customers"
                    frmS.Campos = "c.cli_codigo codigo, c.cli_cliente cliente, c.cli_sisemp  Empresa "
                    frmS.Tabla = YarnD & ".Empresa e Left Join " & nomEmp & ".Clientes c ON c.cli_sisemp = e.codigo_empresa "
                    frmS.FiltroText = "Enter the customer to filter"
                    frmS.Filtro = " c.cli_cliente "
                    frmS.Limite = 15
                    frmS.Ordenamiento = " c.cli_cliente "
                    frmS.TipoOrdenamiento = "Asc"
                    frmS.Condicion = "e.idEmpresa =" & idEmp

                    frmS.ShowDialog(Me)

                    If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        If dglistadoDetalle.Rows.Count > 0 Then
                            For i = 0 To dglistadoDetalle.Rows.Count - 1
                                If frmS.ListaClientes.CurrentRow.Cells(0).Value = dglistadoDetalle.Rows(i).Cells("colCodigo").Value And idEmp = dglistadoDetalle.Rows(i).Cells("colidEmpresaEmpresa").Value Then
                                    MsgBox("The Client already has been selected, please select other one", vbInformation, "Notice")
                                    Exit Sub
                                End If
                            Next
                        End If
                        strfila = frmS.LLave & "|"
                        strfila &= frmS.Dato & "|"
                        strfila &= 0 & "|"
                        strfila &= nomEmp & "|"
                        'strfila &= frmS.Dato2 & "|"
                        strfila &= idEmp & "|"
                        strfila &= 0

                        cfun.AgregarFila(dglistadoDetalle, strfila)
                    End If

                ElseIf intTipo = 2 Then
                    frmS.Titulo = "Products"
                    frmS.Campos = "a.art_codigo codigo, a.art_DCorta Descripcion, a.art_sisemp empresa "
                    frmS.Tabla = YarnD & ".Empresa e Left Join " & nomEmp & ".Articulos a ON a.art_sisemp = e.codigo_empresa "
                    frmS.FiltroText = "Enter the Product to filter"
                    frmS.Filtro = " a.art_DCorta "
                    frmS.Limite = 50
                    frmS.Ordenamiento = " a.art_DCorta "
                    frmS.TipoOrdenamiento = "Asc"
                    frmS.Condicion = "e.idEmpresa =" & idEmp
                    frmS.Multiple = True

                    frmS.ShowDialog(Me)

                    If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        For j As Integer = 0 To frmS.DataGrid.Rows.Count - 1
                            If frmS.ListaClientes.Rows(j).Cells("colCheck").Value = True Then
                                If dglistadoDetalle.Rows.Count > 0 Then
                                    For i = 0 To dglistadoDetalle.Rows.Count - 1
                                        If frmS.ListaClientes.CurrentRow.Cells(1).Value = dglistadoDetalle.Rows(i).Cells("colCodigo").Value And idEmp = dglistadoDetalle.Rows(i).Cells("colidEmpresaEmpresa").Value Then
                                            MsgBox("The Client already has been selected, please select other one", vbInformation, "Notice")
                                            Exit Sub
                                        End If
                                    Next
                                End If
                                strfila = frmS.ListaClientes.Rows(j).Cells(1).Value & "|"
                                strfila &= frmS.ListaClientes.Rows(j).Cells(2).Value & "|"
                                strfila &= 0 & "|"
                                strfila &= nomEmp & "|"
                                'strfila &= frmS.Dato2 & "|"
                                strfila &= idEmp & "|"
                                strfila &= 0

                                cfun.AgregarFila(dglistadoDetalle, strfila)
                            End If
                        Next
                    End If

                ElseIf intTipo = 3 Then
                    frmS.Titulo = "Suppliers"
                    frmS.Campos = "p.pro_codigo code, p.pro_proveedor supplier, p.pro_sisemp  Empresa "
                    frmS.Tabla = YarnD & ".Empresa e Left Join " & nomEmp & ".Proveedores p ON p.pro_sisemp = e.codigo_empresa "
                    frmS.FiltroText = "Enter the supplier to filter"
                    frmS.Filtro = " p.pro_proveedor "
                    frmS.Limite = 15
                    frmS.Ordenamiento = " p.pro_proveedor "
                    frmS.TipoOrdenamiento = "Asc"
                    frmS.Condicion = "e.idEmpresa =" & idEmp

                    frmS.ShowDialog(Me)

                    If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        If dglistadoDetalle.Rows.Count > 0 Then
                            For i = 0 To dglistadoDetalle.Rows.Count - 1
                                If frmS.ListaClientes.CurrentRow.Cells(0).Value = dglistadoDetalle.Rows(i).Cells("colCodigo").Value And idEmp = dglistadoDetalle.Rows(i).Cells("colidEmpresaEmpresa").Value Then
                                    MsgBox("The Supplier already has been selected, please select other one", vbInformation, "Notice")
                                    Exit Sub
                                End If
                            Next
                        End If
                        strfila = frmS.LLave & "|"
                        strfila &= frmS.Dato & "|"
                        strfila &= 0 & "|"
                        strfila &= nomEmp & "|"
                        'strfila &= frmS.Dato2 & "|"
                        strfila &= idEmp & "|"
                        strfila &= 0

                        cfun.AgregarFila(dglistadoDetalle, strfila)
                    End If
                ElseIf intTipo = 4 Then
                    frmS.Titulo = "Accounting Accounts"
                    frmS.Campos = " c.id_cuenta cuenta, c.nombre nombre, c.empresa empresa "
                    frmS.Tabla = YarnD & ".Empresa e Left Join " & nomConta & ".cuentas c ON c.empresa = e.codigo_empresa "
                    frmS.FiltroText = "enter the account to filter"
                    frmS.Filtro = " c.nombre "
                    frmS.Limite = 15
                    frmS.Ordenamiento = " c.id_cuenta "
                    frmS.TipoOrdenamiento = "Asc"
                    frmS.Condicion = "e.idEmpresa =" & idEmp

                    frmS.ShowDialog(Me)
                    If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        If dglistadoDetalle.Rows.Count > 0 Then
                            For i = 0 To dglistadoDetalle.Rows.Count - 1
                                If frmS.ListaClientes.CurrentRow.Cells(0).Value = dglistadoDetalle.Rows(i).Cells("colCodigo").Value And idEmp = dglistadoDetalle.Rows(i).Cells("colidEmpresaEmpresa").Value Then
                                    MsgBox("The Accounting Accounts already has been selected, please select other one", vbInformation, "Notice")
                                    Exit Sub
                                End If
                            Next
                        End If
                        strfila = frmS.LLave & "|"
                        strfila &= frmS.Dato & "|"
                        strfila &= 0 & "|"
                        strfila &= nomEmp & "|"
                        'strfila &= frmS.Dato2 & "|"
                        strfila &= idEmp & "|"
                        strfila &= 0

                        cfun.AgregarFila(dglistadoDetalle, strfila)
                    End If
                ElseIf intTipo = 5 Then
                    frmS.Titulo = "Budget Accounts"
                    frmS.Campos = " p.id_cuenta cuenta, p.nombre_ext nombre, p.empresa empresa "
                    frmS.Tabla = YarnD & ".Empresa e Left Join " & nomConta & ".cuentas_presupuesto p ON p.empresa = e.codigo_empresa "
                    frmS.FiltroText = "enter the account to filter"
                    frmS.Filtro = " p.nombre_ext "
                    frmS.Limite = 15
                    frmS.Ordenamiento = " p.id_cuenta "
                    frmS.TipoOrdenamiento = "Asc"
                    frmS.Condicion = "e.idEmpresa = " & idEmp & " AND p.tipo = 3 "

                    frmS.ShowDialog(Me)

                    If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        If dglistadoDetalle.Rows.Count > 0 Then
                            For i = 0 To dglistadoDetalle.Rows.Count - 1
                                If frmS.ListaClientes.CurrentRow.Cells(0).Value = dglistadoDetalle.Rows(i).Cells("colCodigo").Value And idEmp = dglistadoDetalle.Rows(i).Cells("colidEmpresaEmpresa").Value Then
                                    MsgBox("The Accounting Accounts already has been selected, please select other one", vbInformation, "Notice")
                                    Exit Sub
                                End If
                            Next
                        End If
                        strfila = frmS.LLave & "|"
                        strfila &= frmS.Dato & "|"
                        strfila &= 0 & "|"
                        strfila &= nomEmp & "|"
                        'strfila &= frmS.Dato2 & "|"
                        strfila &= idEmp & "|"
                        strfila &= 0

                        cfun.AgregarFila(dglistadoDetalle, strfila)
                    End If
                End If
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region

#Region "Eventos"
    Private Sub frmGrupos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarLista()
        Accesos()
    End Sub

    Private Sub dgListaPrincipal_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgListaPrincipal.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim frms As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intCantidad As Integer = 0

        Try
            If logInsertar = True Then
                Me.Tag = "Nuevo"
                strsql = " SELECT COUNT(*) FROM " & YarnD & ".Permiso p WHERE p.Usuario = '{usuario}' AND p.`Status` = 1"
                strsql = Replace(strsql, "{usuario}", Sesion.Usuario)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql, CON)
                intCantidad = COM.ExecuteScalar

                If intCantidad > 1 Then
                    strCondicion = " p.Usuario = '{usuario}' and p.`Status` = 1"
                    strCondicion = Replace(strCondicion, "{usuario}", Sesion.Usuario)

                    frms.Titulo = "Types of Group"
                    frms.Campos = "p.idTipoGrp idTipo, p.ClaseGrp Clase"
                    frms.Tabla = YarnD & ".Permiso p "
                    frms.FiltroText = "Write the type of Group"
                    frms.Limite = 10
                    frms.Filtro = "p.ClaseGrp"
                    frms.Ordenamiento = "p.idTipoGrp"
                    frms.TipoOrdenamiento = ""
                    frms.Condicion = strCondicion

                    frms.ShowDialog(Me)
                    If frms.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        intTipo = frms.LLave
                    Else
                        Exit Sub
                    End If
                Else
                    strsql = STR_VACIO
                    strsql = " SELECT p.idTipoGrp idTipo FROM " & YarnD & ".Permiso p WHERE p.Usuario = '{usuario}' AND p.`Status` = 1"
                    strsql = Replace(strsql, "{usuario}", Sesion.Usuario)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strsql, CON)
                    intTipo = COM.ExecuteScalar

                End If

                LimpiarCampos()
                MostrarLista(False, True)
            Else
                MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        CargarInformacion()
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        dglistadoDetalle.CurrentRow.Cells("colExtra").Value = 2
        dglistadoDetalle.CurrentRow.Visible = False
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim numeroGrupo As Integer = 0
        Try


            If Me.Tag = "Nuevo" Then
                strSQL = " Select ifnull(MAX(idGrupo +1),1) num From " & YarnD & ".Grupo g WHERE g.idTipo = " & intTipo
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                numeroGrupo = COM.ExecuteScalar
                celdaNumero.Text = numeroGrupo
            End If

            If celdaNumero.Text > 0 Then
                If logInsertar = True And Me.Tag = "Nuevo" Then
                    If ComprobarCampos() = True Then
                        GuardarGrupo()
                        GuardarDetalleGrp()

                        If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        Else
                            Me.Tag = "Mod"
                        End If
                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If

                ElseIf logEditar = True And Me.Tag = "Mod" Then ' Verifica si tiene permiso de editar
                    If ComprobarCampos() = True Then
                        GuardarGrupo()
                        GuardarDetalleGrp()

                        If MsgBox("Information Updated Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        Else
                            Me.Tag = "Mod"
                        End If

                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If
                Else
                    MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
                    Exit Sub
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgListaPrincipal_DoubleClick(sender As Object, e As EventArgs) Handles dgListaPrincipal.DoubleClick
        Dim intGrupo As Integer = INT_CERO

        Try
            intGrupo = dgListaPrincipal.SelectedCells(0).Value
            intTipo = dgListaPrincipal.SelectedCells(2).Value
            LimpiarCampos()
            CargarDatosGrupo(intGrupo, intTipo)
            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

    Private Sub dglistadoDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dglistadoDetalle.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarEncabezadoGrupo()
                BorrarDetalleGrupo()
                MsgBox("Data deleted correctly", MsgBoxStyle.Information)
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", MsgBoxStyle.Information)
            Exit Sub
        End If

    End Sub

    Private Sub dgListaPrincipal_KeyDown(sender As Object, e As KeyEventArgs) Handles dgListaPrincipal.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgListaPrincipal)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class