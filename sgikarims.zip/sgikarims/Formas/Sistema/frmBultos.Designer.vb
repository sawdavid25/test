﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBultos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBultos))
        Me.panelBultos = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgbultos = New System.Windows.Forms.DataGridView()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelDecision = New System.Windows.Forms.Panel()
        Me.txtPendientesLbs = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtSumaSelect = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dgBultosinstruccion = New System.Windows.Forms.DataGridView()
        Me.celdaLibras = New System.Windows.Forms.TextBox()
        Me.etiquetaLibras = New System.Windows.Forms.Label()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.txtFilaSeleccionar = New System.Windows.Forms.TextBox()
        Me.btnSeleccionar = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.seleccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultoNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BoxNumberVista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.productoCod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoria = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPeso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoChi = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBultos.SuspendLayout()
        CType(Me.dgbultos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelDecision.SuspendLayout()
        CType(Me.dgBultosinstruccion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelBultos
        '
        Me.panelBultos.Controls.Add(Me.Label1)
        Me.panelBultos.Controls.Add(Me.dgbultos)
        Me.panelBultos.Controls.Add(Me.panelBotones)
        Me.panelBultos.Controls.Add(Me.panelDecision)
        Me.panelBultos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelBultos.Location = New System.Drawing.Point(0, 53)
        Me.panelBultos.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBultos.Name = "panelBultos"
        Me.panelBultos.Size = New System.Drawing.Size(921, 436)
        Me.panelBultos.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.LightGray
        Me.Label1.Location = New System.Drawing.Point(272, -2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(547, 130)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = resources.GetString("Label1.Text")
        '
        'dgbultos
        '
        Me.dgbultos.AllowUserToAddRows = False
        Me.dgbultos.AllowUserToDeleteRows = False
        Me.dgbultos.AllowUserToOrderColumns = True
        Me.dgbultos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgbultos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgbultos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.seleccion, Me.colCatalogo, Me.colAnio, Me.colNumero, Me.colLinea, Me.colBultoNo, Me.BoxNumberVista, Me.productoCod, Me.colMarca, Me.colCategoria, Me.colPeso, Me.colCatalogoChi, Me.colExtra})
        Me.dgbultos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgbultos.Location = New System.Drawing.Point(0, 0)
        Me.dgbultos.Margin = New System.Windows.Forms.Padding(2)
        Me.dgbultos.MultiSelect = False
        Me.dgbultos.Name = "dgbultos"
        Me.dgbultos.RowTemplate.Height = 24
        Me.dgbultos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgbultos.Size = New System.Drawing.Size(845, 356)
        Me.dgbultos.TabIndex = 1
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonEliminar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(845, 0)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(76, 356)
        Me.panelBotones.TabIndex = 0
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(16, 105)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(45, 41)
        Me.botonEliminar.TabIndex = 1
        Me.botonEliminar.UseVisualStyleBackColor = True
        Me.botonEliminar.Visible = False
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(16, 28)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(45, 43)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        Me.botonAgregar.Visible = False
        '
        'panelDecision
        '
        Me.panelDecision.Controls.Add(Me.txtPendientesLbs)
        Me.panelDecision.Controls.Add(Me.Label4)
        Me.panelDecision.Controls.Add(Me.txtSumaSelect)
        Me.panelDecision.Controls.Add(Me.Label3)
        Me.panelDecision.Controls.Add(Me.dgBultosinstruccion)
        Me.panelDecision.Controls.Add(Me.celdaLibras)
        Me.panelDecision.Controls.Add(Me.etiquetaLibras)
        Me.panelDecision.Controls.Add(Me.botonCancelar)
        Me.panelDecision.Controls.Add(Me.botonAceptar)
        Me.panelDecision.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelDecision.Location = New System.Drawing.Point(0, 356)
        Me.panelDecision.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDecision.Name = "panelDecision"
        Me.panelDecision.Size = New System.Drawing.Size(921, 80)
        Me.panelDecision.TabIndex = 2
        '
        'txtPendientesLbs
        '
        Me.txtPendientesLbs.BackColor = System.Drawing.SystemColors.Info
        Me.txtPendientesLbs.Enabled = False
        Me.txtPendientesLbs.Location = New System.Drawing.Point(627, 20)
        Me.txtPendientesLbs.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPendientesLbs.Name = "txtPendientesLbs"
        Me.txtPendientesLbs.Size = New System.Drawing.Size(104, 20)
        Me.txtPendientesLbs.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(561, 25)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Pediente:"
        '
        'txtSumaSelect
        '
        Me.txtSumaSelect.BackColor = System.Drawing.SystemColors.Info
        Me.txtSumaSelect.Enabled = False
        Me.txtSumaSelect.Location = New System.Drawing.Point(432, 20)
        Me.txtSumaSelect.Margin = New System.Windows.Forms.Padding(2)
        Me.txtSumaSelect.Name = "txtSumaSelect"
        Me.txtSumaSelect.Size = New System.Drawing.Size(104, 20)
        Me.txtSumaSelect.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(351, 24)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Seleccion Lbs:"
        '
        'dgBultosinstruccion
        '
        Me.dgBultosinstruccion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgBultosinstruccion.Location = New System.Drawing.Point(9, 11)
        Me.dgBultosinstruccion.Margin = New System.Windows.Forms.Padding(2)
        Me.dgBultosinstruccion.Name = "dgBultosinstruccion"
        Me.dgBultosinstruccion.RowTemplate.Height = 24
        Me.dgBultosinstruccion.Size = New System.Drawing.Size(131, 54)
        Me.dgBultosinstruccion.TabIndex = 4
        '
        'celdaLibras
        '
        Me.celdaLibras.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLibras.Enabled = False
        Me.celdaLibras.Location = New System.Drawing.Point(218, 19)
        Me.celdaLibras.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaLibras.Name = "celdaLibras"
        Me.celdaLibras.Size = New System.Drawing.Size(121, 20)
        Me.celdaLibras.TabIndex = 2
        '
        'etiquetaLibras
        '
        Me.etiquetaLibras.AutoSize = True
        Me.etiquetaLibras.Location = New System.Drawing.Point(153, 23)
        Me.etiquetaLibras.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaLibras.Name = "etiquetaLibras"
        Me.etiquetaLibras.Size = New System.Drawing.Size(54, 13)
        Me.etiquetaLibras.TabIndex = 3
        Me.etiquetaLibras.Text = "Total Lbs:"
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.botonCancelar.Location = New System.Drawing.Point(744, 12)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 57)
        Me.botonCancelar.TabIndex = 1
        Me.botonCancelar.Text = "Cancelar"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(835, 12)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 57)
        Me.botonAceptar.TabIndex = 0
        Me.botonAceptar.Text = "Aceptar"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'txtFilaSeleccionar
        '
        Me.txtFilaSeleccionar.Location = New System.Drawing.Point(608, 28)
        Me.txtFilaSeleccionar.Multiline = True
        Me.txtFilaSeleccionar.Name = "txtFilaSeleccionar"
        Me.txtFilaSeleccionar.Size = New System.Drawing.Size(139, 20)
        Me.txtFilaSeleccionar.TabIndex = 2
        '
        'btnSeleccionar
        '
        Me.btnSeleccionar.Location = New System.Drawing.Point(775, 25)
        Me.btnSeleccionar.Name = "btnSeleccionar"
        Me.btnSeleccionar.Size = New System.Drawing.Size(75, 23)
        Me.btnSeleccionar.TabIndex = 3
        Me.btnSeleccionar.Text = "Seleccionar"
        Me.btnSeleccionar.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(605, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(130, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "* Seleccion Personalizada"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(921, 53)
        Me.BarraTitulo1.TabIndex = 0
        '
        'seleccion
        '
        Me.seleccion.HeaderText = ""
        Me.seleccion.Name = "seleccion"
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Entry Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        '
        'colBultoNo
        '
        Me.colBultoNo.HeaderText = "BoxNumId"
        Me.colBultoNo.Name = "colBultoNo"
        Me.colBultoNo.ReadOnly = True
        Me.colBultoNo.Visible = False
        '
        'BoxNumberVista
        '
        Me.BoxNumberVista.HeaderText = "Box Number"
        Me.BoxNumberVista.Name = "BoxNumberVista"
        '
        'productoCod
        '
        Me.productoCod.HeaderText = "ProductCode"
        Me.productoCod.Name = "productoCod"
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Product"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        '
        'colCategoria
        '
        Me.colCategoria.HeaderText = "UnitOfMeasure"
        Me.colCategoria.Name = "colCategoria"
        Me.colCategoria.ReadOnly = True
        '
        'colPeso
        '
        Me.colPeso.HeaderText = "Weight"
        Me.colPeso.Name = "colPeso"
        Me.colPeso.ReadOnly = True
        '
        'colCatalogoChi
        '
        Me.colCatalogoChi.HeaderText = "CatChi"
        Me.colCatalogoChi.Name = "colCatalogoChi"
        Me.colCatalogoChi.ReadOnly = True
        Me.colCatalogoChi.Visible = False
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'frmBultos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(921, 489)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnSeleccionar)
        Me.Controls.Add(Me.txtFilaSeleccionar)
        Me.Controls.Add(Me.panelBultos)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmBultos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmBultos"
        Me.panelBultos.ResumeLayout(False)
        Me.panelBultos.PerformLayout()
        CType(Me.dgbultos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelDecision.ResumeLayout(False)
        Me.panelDecision.PerformLayout()
        CType(Me.dgBultosinstruccion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelBultos As Panel
    Friend WithEvents dgbultos As DataGridView
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelDecision As Panel
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents celdaLibras As TextBox
    Friend WithEvents etiquetaLibras As Label
    Friend WithEvents dgBultosinstruccion As System.Windows.Forms.DataGridView
    Friend WithEvents txtFilaSeleccionar As TextBox
    Friend WithEvents btnSeleccionar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSumaSelect As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPendientesLbs As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents seleccion As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colBultoNo As DataGridViewTextBoxColumn
    Friend WithEvents BoxNumberVista As DataGridViewTextBoxColumn
    Friend WithEvents productoCod As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colCategoria As DataGridViewTextBoxColumn
    Friend WithEvents colPeso As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoChi As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
End Class
