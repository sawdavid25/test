﻿Imports System.ComponentModel

Public Class frmBultos


#Region "Miembros"
    Dim strKey As String = STR_VACIO

    Dim parCat As Integer = 0
    Dim parAnio As Integer = 0
    Dim parNum As Integer = 0
    Dim parLinea As Integer = 0
    Dim NumBulto As Integer = 0

    Dim chiCat As Integer = 0
    Dim chiAnio As Integer = 0
    Dim LbsADescargar As Double = 0
    Dim chiNum As Integer = 0
    Dim chiLinea As Integer = 0

    Dim MarcaB As String
    Dim CategoriaB As String
    Dim pesoB As Double
    Dim extraL As Integer

    Dim cfun As New clsFunciones

    ' Variable para almacenar la suma
    Dim sumaLibras As Double = 0

    ' Variable para almacenar la suma
    Dim VisualizarInfo As Boolean = False

#End Region
#Region "Propiedades"

    Public Property DataGridIn As DataGridView
        Set(value As DataGridView)
            dgBultosinstruccion = value
        End Set
        Get
            Return dgBultosinstruccion
        End Get
    End Property
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property CatalogoP As Integer
        Get
            Return parCat
        End Get
        Set(value As Integer)
            parCat = value
        End Set
    End Property

    Public Property VisualizarInfoUp As Integer
        Get
            Return VisualizarInfo
        End Get
        Set(value As Integer)
            VisualizarInfo = value
        End Set
    End Property

    Public Property AnioP As Integer
        Get
            Return parAnio
        End Get
        Set(value As Integer)
            parAnio = value
        End Set
    End Property
    Public Property NumeroP As Integer
        Get
            Return parNum
        End Get
        Set(value As Integer)
            parNum = value
        End Set
    End Property

    Public Property LineaP As Integer
        Get
            Return parLinea
        End Get
        Set(value As Integer)
            parLinea = value
        End Set
    End Property

    Public Property BultoNo As Integer
        Get
            Return NumBulto
        End Get
        Set(value As Integer)
            NumBulto = value
        End Set
    End Property

    Public Property CatalogoChi As Integer
        Get
            Return chiCat
        End Get
        Set(value As Integer)
            chiCat = value
        End Set
    End Property

    Public Property AnioChi As Integer
        Get
            Return chiAnio
        End Get
        Set(value As Integer)
            chiAnio = value
        End Set
    End Property

    Public Property Libras As Double
        Get
            Return LbsADescargar
        End Get
        Set(value As Double)
            LbsADescargar = value
        End Set
    End Property

    Public Property NumeroChi As Integer
        Get
            Return chiNum
        End Get
        Set(value As Integer)
            chiNum = value
        End Set
    End Property

    Public Property LineaChi As Integer
        Get
            Return chiLinea
        End Get
        Set(value As Integer)
            chiLinea = value
        End Set
    End Property

    Public Property Marca As String
        Get
            Return MarcaB
        End Get
        Set(value As String)
            MarcaB = value
        End Set
    End Property

    Public Property Categoria As String
        Get
            Return CategoriaB
        End Get
        Set(value As String)
            CategoriaB = value
        End Set
    End Property

    Public Property Peso As Double
        Get
            Return pesoB
        End Get
        Set(value As Double)
            pesoB = value
        End Set
    End Property

    Public Property Extra As Integer
        Get
            Return extraL
        End Get
        Set(value As Integer)
            extraL = value
        End Set
    End Property

#End Region

#Region "Eventos"


    Public Sub SeleccionDeDatos()
        'For i = 0 To dgbultos.Rows.Count - 1
        '    parCat = dgbultos.Rows(i).Cells("colCatalogo").Value
        '    parAnio = dgbultos.Rows(i).Cells("colAnio").Value
        '    parNum = dgbultos.Rows(i).Cells("colNumero").Value
        '    parLinea = dgbultos.Rows(i).Cells("colLinea").Value
        '    BultoNo = dgbultos.Rows(i).Cells("colBultoNo").Value

        'Next
    End Sub
    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        If celdaLibras.Text <> LbsADescargar Then
            If MsgBox("The total pounds of packages does not match the pounds to be unloaded" & vbLf & vbLf & "Do you want to update the pounds to download?", vbInformation + vbYesNo, "Warning") = vbYes Then
                Me.DialogResult = System.Windows.Forms.DialogResult.OK
            End If
        ElseIf celdaLibras.Text = LbsADescargar Then
            Me.DialogResult = System.Windows.Forms.DialogResult.OK

        End If

        'SeleccionDeDatos()

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frmS As New FrmSeleccionarBulto
        Dim strFila As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        Dim LogVer As Boolean
        Dim i As Integer = 0
        Dim j As Integer = 0

        frmS.Numero = parNum
        frmS.Linea = parLinea
        frmS.Anio = parAnio
        frmS.DataGridIn = dgBultosinstruccion

        frmS.ShowDialog(Me)

        Try
            If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then
                For i = 0 To frmS.DataGrid.Rows.Count - 1
                    If frmS.dgLista.Rows(i).Cells("colCheck").Value = True Then
                        LogVer = True
                        If dgbultos.Rows.Count > 0 Then
                            For j = 0 To dgbultos.Rows.Count - 1
                                If dgbultos.Rows(j).Cells("colCatalogo").Value = frmS.dgLista.Rows(i).Cells(7).Value And dgbultos.Rows(j).Cells("colAnio").Value = frmS.dgLista.Rows(i).Cells(8).Value And dgbultos.Rows(j).Cells("colNumero").Value = frmS.dgLista.Rows(i).Cells(1).Value And dgbultos.Rows(j).Cells("colLinea").Value = frmS.dgLista.Rows(i).Cells(2).Value And dgbultos.Rows(j).Cells("colBultoNo").Value = frmS.dgLista.Rows(i).Cells(3).Value Then
                                    MsgBox("The package " & frmS.dgLista.Rows(i).Cells(1).Value & " has already been selected, select another", vbInformation, "Notice")
                                    LogVer = False
                                End If
                            Next
                        End If

                        If LogVer = True Then
                            strFila = frmS.dgLista.Rows(i).Cells(7).Value & "|" ' catalogo
                            strFila &= frmS.dgLista.Rows(i).Cells(8).Value & "|" ' Año
                            strFila &= frmS.dgLista.Rows(i).Cells(1).Value & "|" ' numero
                            strFila &= frmS.dgLista.Rows(i).Cells(2).Value & "|" ' linea
                            strFila &= frmS.dgLista.Rows(i).Cells(3).Value & "|" ' Numero de bulto
                            strFila &= frmS.dgLista.Rows(i).Cells(4).Value & "|" ' marca
                            strFila &= frmS.dgLista.Rows(i).Cells(5).Value & "|" ' categoria
                            strFila &= frmS.dgLista.Rows(i).Cells(6).Value & "|" ' peso
                            strFila &= chiLinea & "|"
                            strFila &= 0

                            cFunciones.AgregarFila(dgbultos, strFila)

                        End If
                    End If
                Next

                SumarLibras()

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub SumarLibras()
        Dim k As Integer = 0
        Dim sumaLbs As Double = 0

        For k = 0 To dgbultos.Rows.Count - 1
            If dgbultos.Rows(k).Cells("colExtra").Value = 2 Then
            Else
                sumaLbs = sumaLbs + dgbultos.Rows(k).Cells("colPeso").Value  ' peso
            End If

        Next
        celdaLibras.Text = sumaLbs

    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        dgbultos.CurrentRow.Cells("colExtra").Value = 2
        dgbultos.CurrentRow.Visible = False
        SumarLibras()

    End Sub

    Private Sub frmBultos_Load(sender As Object, e As EventArgs) Handles Me.Load
        Label1.Visible = False ' Muestra el Label cuando el cursor está sobre el TextBox
        celdaLibras.Text = LbsADescargar

        CargarBultos() ' Cargar los datos cuando se carga el formulario
        CalcularSuma()


    End Sub

    Private Sub CargarBultos()

        ' Declarar variables necesarias
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Dim strSql As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Dim LogVer As Boolean = True

        ' Reemplazar parámetros en la consulta SQL
        strSql = "SELECT " &
         "0 Seleccionado, " &
         "h.HDoc_Doc_Ano anioIngreso, " &
         "h.HDoc_Doc_Num numeroIngreso, " &
         "d.DDoc_Doc_Cat catalogo, " &
         "d.DDoc_Prd_Cod productoCod, " &
         "d.DDoc_Prd_Des productoDesc, " &
         "d.DDoc_RF1_Dbl cantTotal, " &
         "c.cat_Clave medida, " &
         "b.BDoc_Doc_Num col_numIngreso, " &
         "b.BDoc_Doc_Lin col_LinIngreso, " &
         "b.BDoc_Box_Lin  col_NumCaja, " &
         "b.BDOC_BOX_HSM col_NumCajaVista, " &
         "IF(b.BDoc_Box_LB = b.BDoc_Box_LBExt, (b.BDoc_Box_LB - b.BDoc_Box_Ord), b.BDoc_Box_LB) col_PesoCaja " &
         "FROM Dcmtos_DTL d " &
         "INNER JOIN Catalogos c ON d.DDoc_Prd_UM = c.cat_num " &
         "INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp " &
         "AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat " &
         "AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano " &
         "AND h.HDoc_Doc_Num = d.DDoc_Doc_Num " &
         "INNER JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp " &
         "AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat " &
         "AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano " &
         "AND b.BDoc_Doc_Num = d.DDoc_Doc_Num " &
         "AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin " &
         "LEFT JOIN Dcmtos_DTL_Box_Pro p ON p.BPDoc_Sis_Emp = b.BDoc_Sis_Emp " &
         "AND p.BPDoc_Par_Cat = b.BDoc_Doc_Cat " &
         "AND p.BPDoc_Par_Ano = b.BDoc_Doc_Ano " &
         "AND p.BPDoc_Par_Num = b.BDoc_Doc_Num " &
         "AND p.BPDoc_Par_Lin =  b.BDoc_Doc_Lin " &
         "AND p.BPDoc_Box_Lin =  b.BDoc_Box_Lin " &
         "WHERE d.DDoc_Sis_Emp = {empresa} " &
         "AND d.DDoc_Doc_Cat = {categoria} " &
         "AND d.DDoc_Doc_Ano = {anio} " &
         "AND d.DDoc_Doc_Num = {numero} " &
         "AND d.DDoc_Doc_Lin = {lineaIng} " &
         "AND p.BPDoc_Box_Lin IS NULL "


        ' Aquí se reemplazan los parámetros en la consulta
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)       ' El valor del parámetro empresa (ej. 15)
        strSql = Replace(strSql, "{categoria}", parCat)      ' El valor del parámetro categoria (ej. 47)
        strSql = Replace(strSql, "{anio}", parAnio)         ' El valor del parámetro anio (ej. 2025)
        strSql = Replace(strSql, "{numero}", parNum)      ' El valor del parámetro numero (ej. 17139)
        strSql = Replace(strSql, "{lineaIng}", LineaP)      ' El valor del parámetro linea ingreso (ej. 1)
        'CatalogoP
        'frmB.AnioP
        ''frmB.NumeroP
        ''frmB.LineaP
        'parCat
        'parAnio
        'parNum
        'parLinea
        'NumBulto

        Try
            ' Ejecutar la consulta SQL
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader

            dgbultos.Columns(0).Width = 30

            Dim validaCargaCajas As Boolean = True

            'Si dgbultos tiene datos y esta editando
            If dgbultos.Rows.Count > 0 And VisualizarInfo = True Then
                validaCargaCajas = False

                dgbultos.Columns(0).ReadOnly = True ' Deshabilita la edición en la columna de checkbox
                btnSeleccionar.Enabled = False      ' Desactiva el botón de filtro
                txtFilaSeleccionar.Enabled = False  ' Deshabilita edit filtro
                botonCancelar.Enabled = False
                botonAceptar.Enabled = False
                RemoveHandler Label2.Click, AddressOf Label2_Click ' Desactivar el evento Click del Label

            End If




            If REA.HasRows And validaCargaCajas Then
                ' If REA.HasRows And Not (VisualizarInfo) Then

                Do While REA.Read

                    LogVer = True
                    If dgbultos.Rows.Count > 0 Then
                        For j = 0 To dgbultos.Rows.Count - 1
                            If dgbultos.Rows(j).Cells("colCatalogo").Value = REA.GetString("catalogo") And dgbultos.Rows(j).Cells("colAnio").Value = REA.GetString("anioIngreso") And dgbultos.Rows(j).Cells("colNumero").Value = REA.GetInt32("numeroIngreso") And dgbultos.Rows(j).Cells("colLinea").Value = REA.GetInt32("col_LinIngreso") And dgbultos.Rows(j).Cells("colBultoNo").Value = REA.GetString("col_NumCaja") Then
                                'MsgBox("The package " & frmS.dgLista.Rows(i).Cells(1).Value & " has already been selected, select another", vbInformation, "Notice")
                                LogVer = False
                            End If
                        Next
                    End If

                    If LogVer = True Then
                        ' Crear una nueva fila
                        Dim Fila As New DataGridViewRow()

                        'Se deja Desctivado el checkbox, por es la primera vez en selecionar, 
                        'La validacion de los selecionados, es filtrada arriba, logVer
                        Dim Check As New DataGridViewCheckBoxCell()
                        Check.Value = False

                        Fila.Cells.Add(Check)  ' Agregar el CheckBox a la fila (índice 0)
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("catalogo")})           ' catalogo
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("anioIngreso")})        ' Año
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetInt32("numeroIngreso")})       ' numero
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetInt32("col_LinIngreso")})      ' Línea Ingreso Caja
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("col_NumCaja")})        ' Número Caja
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("col_NumCajaVista")})        ' Número Caja
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("productoCod")})                                  ' Mark idproducto desc
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("productoDesc")})                                  ' Mark producto desc
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetString("medida")})             ' categoria
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = REA.GetDouble("col_PesoCaja")})       ' Peso Caja
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = chiLinea})                            ' Línea adicional (si es necesario)
                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = 1})

                        ' Agregar la fila al DataGridView
                        dgbultos.Rows.Add(Fila)

                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox("Error al cargar los datos: " & ex.Message)
        End Try

    End Sub

    Private Sub frmBultos_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        ' Cerrar la conexión a la base de datos si está abierta
        If CON IsNot Nothing AndAlso CON.State = ConnectionState.Open Then
            CON.Close()
        End If

        ' Limpiar el DataGridView
        ' dgbultos.Rows.Clear()

    End Sub

    Private Sub btnSeleccionar_Click(sender As Object, e As EventArgs) Handles btnSeleccionar.Click
        ' Limpiar la selección anterior
        limpiarSeleccion()

        ' Obtener el texto ingresado en el TextBox
        Dim input As String = txtFilaSeleccionar.Text.Trim()

        ' Verificar si el input no está vacío
        If Not String.IsNullOrEmpty(input) Then
            ' Dividir el texto en partes (por comas o rangos)
            Dim partes As String() = input.Split(","c)

            For Each parte In partes
                If parte.Contains("-") Then
                    ' Rango de registros (ejemplo: 55-59)
                    Dim rangos As String() = parte.Split("-"c)
                    If rangos.Length = 2 Then
                        Dim inicio As Integer
                        Dim fin As Integer

                        ' Intentar convertir los rangos a enteros
                        If Integer.TryParse(rangos(0).Trim(), inicio) AndAlso Integer.TryParse(rangos(1).Trim(), fin) Then
                            ' Verificar que el rango es válido
                            If inicio <= fin Then
                                ' Recorrer las filas del DataGridView
                                For Each row As DataGridViewRow In dgbultos.Rows
                                    ' Obtener el valor de la columna 'colBultoNo' en cada fila
                                    Dim bultoNo As Integer = Convert.ToInt32(row.Cells("BoxNumberVista").Value)

                                    ' Verificar si el valor de 'colBultoNo' está dentro del rango
                                    If bultoNo >= inicio AndAlso bultoNo <= fin Then
                                        ' Marcar la fila
                                        row.Cells(0).Value = True  ' Columna de CheckBox (index 0)
                                        row.Selected = True  ' Seleccionar la fila
                                    End If
                                Next
                            End If
                        End If
                    End If
                Else
                    ' Número de registro individual (ejemplo: 56, 57, 58)
                    Dim numeroBulto As Integer
                    If Integer.TryParse(parte.Trim(), numeroBulto) Then
                        ' Recorrer las filas del DataGridView
                        For Each row As DataGridViewRow In dgbultos.Rows
                            ' Obtener el valor de la columna 'colBultoNo' en cada fila
                            Dim bultoNo As Integer = Convert.ToInt32(row.Cells("BoxNumberVista").Value)

                            ' Verificar si el valor de 'colBultoNo' coincide con el número de bulto
                            If bultoNo = numeroBulto Then
                                ' Marcar la fila
                                row.Cells(0).Value = True  ' Columna de CheckBox (index 0)
                                row.Selected = True  ' Seleccionar la fila
                            End If
                        Next
                    End If
                End If
            Next
        End If

        ' Calcular la suma (si es necesario)
        CalcularSuma()
    End Sub


    Private Sub limpiarSeleccion()

        ' Limpiar la selección de las filas
        dgbultos.ClearSelection()
        ' Limpiar las casillas de verificación (suponiendo que la columna de casillas de verificación es la primera, índice 0)
        For Each row As DataGridViewRow In dgbultos.Rows
            row.Cells(0).Value = False  ' Establecer el valor de la columna CheckBox en False
        Next
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        ' Alterna la visibilidad del Label al hacer clic en el TextBox
        Label1.Visible = Not Label1.Visible
    End Sub

    ' Evento que se dispara cuando el estado del CheckBox cambia
    Private Sub dgbultos_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles dgbultos.CurrentCellDirtyStateChanged
        ' Verificamos si la celda actual es un CheckBox
        If dgbultos.CurrentCell.ColumnIndex = 0 Then
            dgbultos.CommitEdit(DataGridViewDataErrorContexts.Commit)
            CalcularSuma()
        End If
    End Sub

    Private Sub CalcularSuma()
        sumaLibras = 0
        For Each row As DataGridViewRow In dgbultos.Rows
            ' Verificamos si el CheckBox está marcado
            If Convert.ToBoolean(row.Cells(0).Value) = True Then
                ' Si está marcado, sumamos el valor de la columna 'colPeso'
                If Not IsDBNull(row.Cells("colPeso").Value) Then
                    sumaLibras += Convert.ToDouble(row.Cells("colPeso").Value)
                End If

                ' Si el CheckBox está marcado, actualizamos la columna colExtra1 con el valor 1
                row.Cells("colExtra").Value = 0
            Else
                row.Cells("colExtra").Value = 2
            End If
        Next

        txtSumaSelect.Text = sumaLibras.ToString()
        LbsADescargar = sumaLibras 'Variable para verificar descargo, muestra notificacion
        txtPendientesLbs.Text = (Convert.ToDouble(celdaLibras.Text) - Convert.ToDouble(txtSumaSelect.Text)).ToString()

    End Sub




#End Region
End Class