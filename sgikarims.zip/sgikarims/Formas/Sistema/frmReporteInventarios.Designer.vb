﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporteInventarios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReporteInventarios))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dgPaises = New System.Windows.Forms.DataGridView()
        Me.col_num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonCentroAmerica = New System.Windows.Forms.Button()
        Me.botonAsia = New System.Windows.Forms.Button()
        Me.celdaIdSpinning = New System.Windows.Forms.TextBox()
        Me.celdaIdAcabado = New System.Windows.Forms.TextBox()
        Me.celdaIdPaisOrigen = New System.Windows.Forms.TextBox()
        Me.celdaIdCLase = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaTituloHilo = New System.Windows.Forms.TextBox()
        Me.botonPaisOrigen = New System.Windows.Forms.Button()
        Me.celdaPaisOrigen = New System.Windows.Forms.TextBox()
        Me.etiquetaPaisOrigen = New System.Windows.Forms.Label()
        Me.botonSpinning = New System.Windows.Forms.Button()
        Me.CeldaSpinning = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.botonAcabado = New System.Windows.Forms.Button()
        Me.CeldaAcabado = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonClase = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaClase = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.celdaIdProveedor = New System.Windows.Forms.TextBox()
        Me.celdaIdBodega = New System.Windows.Forms.TextBox()
        Me.celdaIdFabricante = New System.Windows.Forms.TextBox()
        Me.rbInventario = New System.Windows.Forms.RadioButton()
        Me.rbOtrosProductos = New System.Windows.Forms.RadioButton()
        Me.rbSoloHilo = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.checkBodega = New System.Windows.Forms.CheckBox()
        Me.checkDeclaracion = New System.Windows.Forms.CheckBox()
        Me.checkPartidaArancelaria = New System.Windows.Forms.CheckBox()
        Me.checkHeathers = New System.Windows.Forms.CheckBox()
        Me.botonBodega = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaBodega = New System.Windows.Forms.TextBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.botonFabricante = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaFabricante = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.dtpInventarioFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.checkFiltrarFecha = New System.Windows.Forms.CheckBox()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.checkMuestra = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgPaises, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dgPaises)
        Me.GroupBox1.Controls.Add(Me.botonCentroAmerica)
        Me.GroupBox1.Controls.Add(Me.botonAsia)
        Me.GroupBox1.Controls.Add(Me.celdaIdSpinning)
        Me.GroupBox1.Controls.Add(Me.celdaIdAcabado)
        Me.GroupBox1.Controls.Add(Me.celdaIdPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaIdCLase)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.celdaTituloHilo)
        Me.GroupBox1.Controls.Add(Me.botonPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.etiquetaPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.botonSpinning)
        Me.GroupBox1.Controls.Add(Me.CeldaSpinning)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.botonAcabado)
        Me.GroupBox1.Controls.Add(Me.CeldaAcabado)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.botonClase)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.celdaClase)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 31)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(420, 510)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Thread Data"
        '
        'dgPaises
        '
        Me.dgPaises.AllowUserToAddRows = False
        Me.dgPaises.AllowUserToDeleteRows = False
        Me.dgPaises.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPaises.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPaises.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_num, Me.col_nombre})
        Me.dgPaises.Location = New System.Drawing.Point(45, 229)
        Me.dgPaises.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgPaises.Name = "dgPaises"
        Me.dgPaises.ReadOnly = True
        Me.dgPaises.Size = New System.Drawing.Size(320, 122)
        Me.dgPaises.TabIndex = 18
        '
        'col_num
        '
        Me.col_num.HeaderText = "Number"
        Me.col_num.Name = "col_num"
        Me.col_num.ReadOnly = True
        Me.col_num.Visible = False
        '
        'col_nombre
        '
        Me.col_nombre.HeaderText = "Country"
        Me.col_nombre.Name = "col_nombre"
        Me.col_nombre.ReadOnly = True
        '
        'botonCentroAmerica
        '
        Me.botonCentroAmerica.Image = CType(resources.GetObject("botonCentroAmerica.Image"), System.Drawing.Image)
        Me.botonCentroAmerica.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCentroAmerica.Location = New System.Drawing.Point(119, 358)
        Me.botonCentroAmerica.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCentroAmerica.Name = "botonCentroAmerica"
        Me.botonCentroAmerica.Size = New System.Drawing.Size(117, 62)
        Me.botonCentroAmerica.TabIndex = 17
        Me.botonCentroAmerica.Text = "                 Centro  America   "
        Me.botonCentroAmerica.UseVisualStyleBackColor = True
        '
        'botonAsia
        '
        Me.botonAsia.Image = CType(resources.GetObject("botonAsia.Image"), System.Drawing.Image)
        Me.botonAsia.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAsia.Location = New System.Drawing.Point(257, 358)
        Me.botonAsia.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAsia.Name = "botonAsia"
        Me.botonAsia.Size = New System.Drawing.Size(95, 62)
        Me.botonAsia.TabIndex = 16
        Me.botonAsia.Text = "                  Asia"
        Me.botonAsia.UseVisualStyleBackColor = True
        '
        'celdaIdSpinning
        '
        Me.celdaIdSpinning.Location = New System.Drawing.Point(99, 117)
        Me.celdaIdSpinning.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdSpinning.Name = "celdaIdSpinning"
        Me.celdaIdSpinning.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdSpinning.TabIndex = 15
        Me.celdaIdSpinning.Text = "0"
        Me.celdaIdSpinning.Visible = False
        '
        'celdaIdAcabado
        '
        Me.celdaIdAcabado.Location = New System.Drawing.Point(119, 68)
        Me.celdaIdAcabado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdAcabado.Name = "celdaIdAcabado"
        Me.celdaIdAcabado.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdAcabado.TabIndex = 14
        Me.celdaIdAcabado.Text = "0"
        Me.celdaIdAcabado.Visible = False
        '
        'celdaIdPaisOrigen
        '
        Me.celdaIdPaisOrigen.Location = New System.Drawing.Point(119, 165)
        Me.celdaIdPaisOrigen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdPaisOrigen.Name = "celdaIdPaisOrigen"
        Me.celdaIdPaisOrigen.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdPaisOrigen.TabIndex = 13
        Me.celdaIdPaisOrigen.Text = "0"
        Me.celdaIdPaisOrigen.Visible = False
        '
        'celdaIdCLase
        '
        Me.celdaIdCLase.Location = New System.Drawing.Point(116, 23)
        Me.celdaIdCLase.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdCLase.Name = "celdaIdCLase"
        Me.celdaIdCLase.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdCLase.TabIndex = 12
        Me.celdaIdCLase.Text = "0"
        Me.celdaIdCLase.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(61, 431)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(101, 17)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Thread of Title"
        '
        'celdaTituloHilo
        '
        Me.celdaTituloHilo.Location = New System.Drawing.Point(45, 450)
        Me.celdaTituloHilo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTituloHilo.Name = "celdaTituloHilo"
        Me.celdaTituloHilo.Size = New System.Drawing.Size(324, 22)
        Me.celdaTituloHilo.TabIndex = 11
        '
        'botonPaisOrigen
        '
        Me.botonPaisOrigen.Location = New System.Drawing.Point(332, 193)
        Me.botonPaisOrigen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonPaisOrigen.Name = "botonPaisOrigen"
        Me.botonPaisOrigen.Size = New System.Drawing.Size(39, 28)
        Me.botonPaisOrigen.TabIndex = 7
        Me.botonPaisOrigen.Text = "+"
        Me.botonPaisOrigen.UseVisualStyleBackColor = True
        '
        'celdaPaisOrigen
        '
        Me.celdaPaisOrigen.Location = New System.Drawing.Point(116, 197)
        Me.celdaPaisOrigen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaPaisOrigen.Name = "celdaPaisOrigen"
        Me.celdaPaisOrigen.Size = New System.Drawing.Size(207, 22)
        Me.celdaPaisOrigen.TabIndex = 6
        '
        'etiquetaPaisOrigen
        '
        Me.etiquetaPaisOrigen.AutoSize = True
        Me.etiquetaPaisOrigen.Location = New System.Drawing.Point(3, 201)
        Me.etiquetaPaisOrigen.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPaisOrigen.Name = "etiquetaPaisOrigen"
        Me.etiquetaPaisOrigen.Size = New System.Drawing.Size(107, 17)
        Me.etiquetaPaisOrigen.TabIndex = 1
        Me.etiquetaPaisOrigen.Text = "Coutry of Origin"
        '
        'botonSpinning
        '
        Me.botonSpinning.Location = New System.Drawing.Point(332, 138)
        Me.botonSpinning.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonSpinning.Name = "botonSpinning"
        Me.botonSpinning.Size = New System.Drawing.Size(39, 28)
        Me.botonSpinning.TabIndex = 5
        Me.botonSpinning.Text = "..."
        Me.botonSpinning.UseVisualStyleBackColor = True
        '
        'CeldaSpinning
        '
        Me.CeldaSpinning.Location = New System.Drawing.Point(116, 142)
        Me.CeldaSpinning.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaSpinning.Name = "CeldaSpinning"
        Me.CeldaSpinning.Size = New System.Drawing.Size(207, 22)
        Me.CeldaSpinning.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(41, 145)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 17)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Spinning"
        '
        'botonAcabado
        '
        Me.botonAcabado.Location = New System.Drawing.Point(332, 89)
        Me.botonAcabado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAcabado.Name = "botonAcabado"
        Me.botonAcabado.Size = New System.Drawing.Size(39, 28)
        Me.botonAcabado.TabIndex = 3
        Me.botonAcabado.Text = "..."
        Me.botonAcabado.UseVisualStyleBackColor = True
        '
        'CeldaAcabado
        '
        Me.CeldaAcabado.Location = New System.Drawing.Point(116, 92)
        Me.CeldaAcabado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaAcabado.Name = "CeldaAcabado"
        Me.CeldaAcabado.Size = New System.Drawing.Size(207, 22)
        Me.CeldaAcabado.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(41, 96)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Finish"
        '
        'botonClase
        '
        Me.botonClase.Location = New System.Drawing.Point(332, 43)
        Me.botonClase.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonClase.Name = "botonClase"
        Me.botonClase.Size = New System.Drawing.Size(39, 28)
        Me.botonClase.TabIndex = 1
        Me.botonClase.Text = "..."
        Me.botonClase.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 47)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Class"
        '
        'celdaClase
        '
        Me.celdaClase.Location = New System.Drawing.Point(116, 46)
        Me.celdaClase.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaClase.Name = "celdaClase"
        Me.celdaClase.Size = New System.Drawing.Size(207, 22)
        Me.celdaClase.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.checkMuestra)
        Me.GroupBox2.Controls.Add(Me.celdaIdProveedor)
        Me.GroupBox2.Controls.Add(Me.celdaIdBodega)
        Me.GroupBox2.Controls.Add(Me.celdaIdFabricante)
        Me.GroupBox2.Controls.Add(Me.rbInventario)
        Me.GroupBox2.Controls.Add(Me.rbOtrosProductos)
        Me.GroupBox2.Controls.Add(Me.rbSoloHilo)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.checkBodega)
        Me.GroupBox2.Controls.Add(Me.checkDeclaracion)
        Me.GroupBox2.Controls.Add(Me.checkPartidaArancelaria)
        Me.GroupBox2.Controls.Add(Me.checkHeathers)
        Me.GroupBox2.Controls.Add(Me.botonBodega)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.celdaBodega)
        Me.GroupBox2.Controls.Add(Me.botonProveedor)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.celdaProveedor)
        Me.GroupBox2.Controls.Add(Me.botonFabricante)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.celdaFabricante)
        Me.GroupBox2.Location = New System.Drawing.Point(444, 31)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(419, 401)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Additonal Options"
        '
        'celdaIdProveedor
        '
        Me.celdaIdProveedor.Location = New System.Drawing.Point(176, 74)
        Me.celdaIdProveedor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdProveedor.Name = "celdaIdProveedor"
        Me.celdaIdProveedor.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdProveedor.TabIndex = 21
        Me.celdaIdProveedor.Text = "0"
        Me.celdaIdProveedor.Visible = False
        '
        'celdaIdBodega
        '
        Me.celdaIdBodega.Location = New System.Drawing.Point(189, 124)
        Me.celdaIdBodega.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdBodega.Name = "celdaIdBodega"
        Me.celdaIdBodega.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdBodega.TabIndex = 20
        Me.celdaIdBodega.Visible = False
        '
        'celdaIdFabricante
        '
        Me.celdaIdFabricante.Location = New System.Drawing.Point(176, 14)
        Me.celdaIdFabricante.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdFabricante.Name = "celdaIdFabricante"
        Me.celdaIdFabricante.Size = New System.Drawing.Size(43, 22)
        Me.celdaIdFabricante.TabIndex = 16
        Me.celdaIdFabricante.Text = "0"
        Me.celdaIdFabricante.Visible = False
        '
        'rbInventario
        '
        Me.rbInventario.AutoSize = True
        Me.rbInventario.Location = New System.Drawing.Point(263, 373)
        Me.rbInventario.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbInventario.Name = "rbInventario"
        Me.rbInventario.Size = New System.Drawing.Size(106, 21)
        Me.rbInventario.TabIndex = 19
        Me.rbInventario.TabStop = True
        Me.rbInventario.Text = "All Inventory"
        Me.rbInventario.UseVisualStyleBackColor = True
        '
        'rbOtrosProductos
        '
        Me.rbOtrosProductos.AutoSize = True
        Me.rbOtrosProductos.Location = New System.Drawing.Point(131, 373)
        Me.rbOtrosProductos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbOtrosProductos.Name = "rbOtrosProductos"
        Me.rbOtrosProductos.Size = New System.Drawing.Size(118, 21)
        Me.rbOtrosProductos.TabIndex = 18
        Me.rbOtrosProductos.TabStop = True
        Me.rbOtrosProductos.Text = "Other Product"
        Me.rbOtrosProductos.UseVisualStyleBackColor = True
        '
        'rbSoloHilo
        '
        Me.rbSoloHilo.AutoSize = True
        Me.rbSoloHilo.Checked = True
        Me.rbSoloHilo.Location = New System.Drawing.Point(12, 373)
        Me.rbSoloHilo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbSoloHilo.Name = "rbSoloHilo"
        Me.rbSoloHilo.Size = New System.Drawing.Size(108, 21)
        Me.rbSoloHilo.TabIndex = 17
        Me.rbSoloHilo.TabStop = True
        Me.rbSoloHilo.Text = "Only Thread"
        Me.rbSoloHilo.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(26, 352)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(352, 17)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "___________________________________________"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(25, 199)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(352, 17)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "___________________________________________"
        '
        'checkBodega
        '
        Me.checkBodega.AutoSize = True
        Me.checkBodega.Location = New System.Drawing.Point(29, 310)
        Me.checkBodega.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkBodega.Name = "checkBodega"
        Me.checkBodega.Size = New System.Drawing.Size(104, 21)
        Me.checkBodega.TabIndex = 14
        Me.checkBodega.Text = "Show Cellar"
        Me.checkBodega.UseVisualStyleBackColor = True
        '
        'checkDeclaracion
        '
        Me.checkDeclaracion.AutoSize = True
        Me.checkDeclaracion.ForeColor = System.Drawing.Color.Blue
        Me.checkDeclaracion.Location = New System.Drawing.Point(29, 282)
        Me.checkDeclaracion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkDeclaracion.Name = "checkDeclaracion"
        Me.checkDeclaracion.Size = New System.Drawing.Size(194, 21)
        Me.checkDeclaracion.TabIndex = 13
        Me.checkDeclaracion.Text = "Show Declaration Number"
        Me.checkDeclaracion.UseVisualStyleBackColor = True
        '
        'checkPartidaArancelaria
        '
        Me.checkPartidaArancelaria.AutoSize = True
        Me.checkPartidaArancelaria.Location = New System.Drawing.Point(29, 254)
        Me.checkPartidaArancelaria.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkPartidaArancelaria.Name = "checkPartidaArancelaria"
        Me.checkPartidaArancelaria.Size = New System.Drawing.Size(173, 21)
        Me.checkPartidaArancelaria.TabIndex = 12
        Me.checkPartidaArancelaria.Text = "Show Departure Tariff "
        Me.checkPartidaArancelaria.UseVisualStyleBackColor = True
        '
        'checkHeathers
        '
        Me.checkHeathers.AutoSize = True
        Me.checkHeathers.Location = New System.Drawing.Point(29, 225)
        Me.checkHeathers.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkHeathers.Name = "checkHeathers"
        Me.checkHeathers.Size = New System.Drawing.Size(159, 21)
        Me.checkHeathers.TabIndex = 11
        Me.checkHeathers.Text = "Show Sun  Heathers"
        Me.checkHeathers.UseVisualStyleBackColor = True
        '
        'botonBodega
        '
        Me.botonBodega.Location = New System.Drawing.Point(344, 146)
        Me.botonBodega.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonBodega.Name = "botonBodega"
        Me.botonBodega.Size = New System.Drawing.Size(39, 28)
        Me.botonBodega.TabIndex = 8
        Me.botonBodega.Text = "..."
        Me.botonBodega.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(25, 153)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 17)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Cellar"
        '
        'celdaBodega
        '
        Me.celdaBodega.Location = New System.Drawing.Point(109, 149)
        Me.celdaBodega.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaBodega.Name = "celdaBodega"
        Me.celdaBodega.Size = New System.Drawing.Size(225, 22)
        Me.celdaBodega.TabIndex = 10
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(344, 97)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(39, 28)
        Me.botonProveedor.TabIndex = 5
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(25, 103)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Provider"
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(109, 100)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(225, 22)
        Me.celdaProveedor.TabIndex = 7
        '
        'botonFabricante
        '
        Me.botonFabricante.Location = New System.Drawing.Point(344, 39)
        Me.botonFabricante.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonFabricante.Name = "botonFabricante"
        Me.botonFabricante.Size = New System.Drawing.Size(39, 28)
        Me.botonFabricante.TabIndex = 2
        Me.botonFabricante.Text = "..."
        Me.botonFabricante.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 46)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 17)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Maker"
        '
        'celdaFabricante
        '
        Me.celdaFabricante.Location = New System.Drawing.Point(109, 42)
        Me.celdaFabricante.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaFabricante.Name = "celdaFabricante"
        Me.celdaFabricante.Size = New System.Drawing.Size(225, 22)
        Me.celdaFabricante.TabIndex = 4
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.dtpInventarioFecha)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.checkFiltrarFecha)
        Me.GroupBox3.Location = New System.Drawing.Point(444, 439)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(419, 101)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        '
        'dtpInventarioFecha
        '
        Me.dtpInventarioFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInventarioFecha.Location = New System.Drawing.Point(283, 55)
        Me.dtpInventarioFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpInventarioFecha.Name = "dtpInventarioFecha"
        Me.dtpInventarioFecha.Size = New System.Drawing.Size(127, 22)
        Me.dtpInventarioFecha.TabIndex = 2
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(147, 63)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(124, 17)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Show Inventory to "
        '
        'checkFiltrarFecha
        '
        Me.checkFiltrarFecha.AutoSize = True
        Me.checkFiltrarFecha.Location = New System.Drawing.Point(24, 4)
        Me.checkFiltrarFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkFiltrarFecha.Name = "checkFiltrarFecha"
        Me.checkFiltrarFecha.Size = New System.Drawing.Size(117, 21)
        Me.checkFiltrarFecha.TabIndex = 0
        Me.checkFiltrarFecha.Text = "Filter By date "
        Me.checkFiltrarFecha.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(471, 581)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(100, 28)
        Me.botonAceptar.TabIndex = 3
        Me.botonAceptar.Text = "Continue"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(648, 581)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(100, 28)
        Me.botonCancelar.TabIndex = 4
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'checkMuestra
        '
        Me.checkMuestra.AutoSize = True
        Me.checkMuestra.Location = New System.Drawing.Point(29, 339)
        Me.checkMuestra.Margin = New System.Windows.Forms.Padding(4)
        Me.checkMuestra.Name = "checkMuestra"
        Me.checkMuestra.Size = New System.Drawing.Size(77, 21)
        Me.checkMuestra.TabIndex = 22
        Me.checkMuestra.Text = "Sample"
        Me.checkMuestra.UseVisualStyleBackColor = True
        '
        'frmReporteInventarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(899, 688)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmReporteInventarios"
        Me.Text = "frmReporteInventarios"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgPaises, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaPaisOrigen As TextBox
    Friend WithEvents etiquetaPaisOrigen As Label
    Friend WithEvents botonSpinning As Button
    Friend WithEvents CeldaSpinning As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents botonAcabado As Button
    Friend WithEvents CeldaAcabado As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents botonClase As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaClase As TextBox
    Friend WithEvents botonPaisOrigen As Button
    Friend WithEvents Label5 As Label
    Friend WithEvents celdaTituloHilo As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rbInventario As RadioButton
    Friend WithEvents rbOtrosProductos As RadioButton
    Friend WithEvents rbSoloHilo As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents checkBodega As System.Windows.Forms.CheckBox
    Friend WithEvents checkDeclaracion As System.Windows.Forms.CheckBox
    Friend WithEvents checkPartidaArancelaria As System.Windows.Forms.CheckBox
    Friend WithEvents checkHeathers As System.Windows.Forms.CheckBox
    Friend WithEvents botonBodega As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaBodega As TextBox
    Friend WithEvents botonProveedor As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents botonFabricante As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents celdaFabricante As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents dtpInventarioFecha As DateTimePicker
    Friend WithEvents Label11 As Label
    Friend WithEvents checkFiltrarFecha As System.Windows.Forms.CheckBox
    Friend WithEvents celdaIdSpinning As TextBox
    Friend WithEvents celdaIdAcabado As TextBox
    Friend WithEvents celdaIdPaisOrigen As TextBox
    Friend WithEvents celdaIdCLase As TextBox
    Friend WithEvents celdaIdProveedor As TextBox
    Friend WithEvents celdaIdBodega As TextBox
    Friend WithEvents celdaIdFabricante As TextBox
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAsia As Button
    Friend WithEvents dgPaises As DataGridView
    Friend WithEvents botonCentroAmerica As Button
    Friend WithEvents col_num As DataGridViewTextBoxColumn
    Friend WithEvents col_nombre As DataGridViewTextBoxColumn
    Friend WithEvents checkMuestra As System.Windows.Forms.CheckBox
End Class
