﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporteDetalleFactura
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonFabricante = New System.Windows.Forms.Button()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFechaFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFiltrarClase = New System.Windows.Forms.CheckBox()
        Me.checkMostrarCostos = New System.Windows.Forms.CheckBox()
        Me.checkPrecioPedido = New System.Windows.Forms.CheckBox()
        Me.botonContinuar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.checkTodaClase = New System.Windows.Forms.CheckBox()
        Me.CheckBoxProveedor = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonFabricante)
        Me.GroupBox1.Controls.Add(Me.celdaIdCliente)
        Me.GroupBox1.Controls.Add(Me.celdaCliente)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 22)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(324, 65)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Name"
        '
        'botonFabricante
        '
        Me.botonFabricante.Location = New System.Drawing.Point(278, 30)
        Me.botonFabricante.Name = "botonFabricante"
        Me.botonFabricante.Size = New System.Drawing.Size(30, 19)
        Me.botonFabricante.TabIndex = 2
        Me.botonFabricante.Text = "..."
        Me.botonFabricante.UseVisualStyleBackColor = True
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(74, 4)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(28, 20)
        Me.celdaIdCliente.TabIndex = 1
        Me.celdaIdCliente.Text = "-1"
        Me.celdaIdCliente.Visible = False
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(6, 30)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(256, 20)
        Me.celdaCliente.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.dtpFechaFin)
        Me.GroupBox2.Controls.Add(Me.dtpFechaInicio)
        Me.GroupBox2.Location = New System.Drawing.Point(18, 110)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(318, 66)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(166, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Until"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "From"
        '
        'dtpFechaFin
        '
        Me.dtpFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFin.Location = New System.Drawing.Point(207, 33)
        Me.dtpFechaFin.Name = "dtpFechaFin"
        Me.dtpFechaFin.Size = New System.Drawing.Size(95, 20)
        Me.dtpFechaFin.TabIndex = 1
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(56, 34)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(95, 20)
        Me.dtpFechaInicio.TabIndex = 0
        '
        'checkFiltrarClase
        '
        Me.checkFiltrarClase.AutoSize = True
        Me.checkFiltrarClase.Location = New System.Drawing.Point(18, 191)
        Me.checkFiltrarClase.Name = "checkFiltrarClase"
        Me.checkFiltrarClase.Size = New System.Drawing.Size(133, 17)
        Me.checkFiltrarClase.TabIndex = 2
        Me.checkFiltrarClase.Text = "Filter by class /product"
        Me.checkFiltrarClase.UseVisualStyleBackColor = True
        '
        'checkMostrarCostos
        '
        Me.checkMostrarCostos.AutoSize = True
        Me.checkMostrarCostos.Location = New System.Drawing.Point(18, 214)
        Me.checkMostrarCostos.Name = "checkMostrarCostos"
        Me.checkMostrarCostos.Size = New System.Drawing.Size(97, 17)
        Me.checkMostrarCostos.TabIndex = 3
        Me.checkMostrarCostos.Text = "Show By Costs"
        Me.checkMostrarCostos.UseVisualStyleBackColor = True
        '
        'checkPrecioPedido
        '
        Me.checkPrecioPedido.AutoSize = True
        Me.checkPrecioPedido.Location = New System.Drawing.Point(18, 237)
        Me.checkPrecioPedido.Name = "checkPrecioPedido"
        Me.checkPrecioPedido.Size = New System.Drawing.Size(82, 17)
        Me.checkPrecioPedido.TabIndex = 4
        Me.checkPrecioPedido.Text = "Order Price "
        Me.checkPrecioPedido.UseVisualStyleBackColor = True
        '
        'botonContinuar
        '
        Me.botonContinuar.Location = New System.Drawing.Point(187, 231)
        Me.botonContinuar.Name = "botonContinuar"
        Me.botonContinuar.Size = New System.Drawing.Size(75, 23)
        Me.botonContinuar.TabIndex = 5
        Me.botonContinuar.Text = "Continue "
        Me.botonContinuar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(276, 231)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.botonCancelar.TabIndex = 6
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'checkTodaClase
        '
        Me.checkTodaClase.AutoSize = True
        Me.checkTodaClase.Location = New System.Drawing.Point(18, 260)
        Me.checkTodaClase.Name = "checkTodaClase"
        Me.checkTodaClase.Size = New System.Drawing.Size(136, 17)
        Me.checkTodaClase.TabIndex = 7
        Me.checkTodaClase.Text = "Select de Whole Class "
        Me.checkTodaClase.UseVisualStyleBackColor = True
        '
        'CheckBoxProveedor
        '
        Me.CheckBoxProveedor.AutoSize = True
        Me.CheckBoxProveedor.Location = New System.Drawing.Point(18, 283)
        Me.CheckBoxProveedor.Name = "CheckBoxProveedor"
        Me.CheckBoxProveedor.Size = New System.Drawing.Size(103, 17)
        Me.CheckBoxProveedor.TabIndex = 8
        Me.CheckBoxProveedor.Text = "Filter by provider"
        Me.CheckBoxProveedor.UseVisualStyleBackColor = True
        '
        'frmReporteDetalleFactura
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(389, 334)
        Me.Controls.Add(Me.CheckBoxProveedor)
        Me.Controls.Add(Me.checkTodaClase)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonContinuar)
        Me.Controls.Add(Me.checkPrecioPedido)
        Me.Controls.Add(Me.checkMostrarCostos)
        Me.Controls.Add(Me.checkFiltrarClase)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmReporteDetalleFactura"
        Me.Text = "frmReporteDetalleFactura"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpFechaFin As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents checkFiltrarClase As System.Windows.Forms.CheckBox
    Friend WithEvents checkMostrarCostos As System.Windows.Forms.CheckBox
    Friend WithEvents checkPrecioPedido As System.Windows.Forms.CheckBox
    Friend WithEvents botonContinuar As Button
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonFabricante As Button
    Friend WithEvents checkTodaClase As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaInicio As DateTimePicker
    Friend WithEvents CheckBoxProveedor As System.Windows.Forms.CheckBox
End Class
