﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGastosLogistica
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaCat_ref = New System.Windows.Forms.TextBox()
        Me.celdaAno_ref = New System.Windows.Forms.TextBox()
        Me.celdaNum_ref = New System.Windows.Forms.TextBox()
        Me.celdaLin_ref = New System.Windows.Forms.TextBox()
        Me.celdaLin = New System.Windows.Forms.TextBox()
        Me.celdaNum = New System.Windows.Forms.TextBox()
        Me.celdaAno = New System.Windows.Forms.TextBox()
        Me.celdaCat = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.celdaSuma = New System.Windows.Forms.TextBox()
        Me.etiquetaLibras = New System.Windows.Forms.Label()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.dgGastos = New System.Windows.Forms.DataGridView()
        Me.cat_i = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ano_i = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.num_i = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lin_i = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idGasto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Gasto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cat_x = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ano_x = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.num_x = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lin_x = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaReferencia = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.dgGastos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaReferencia)
        Me.Panel1.Controls.Add(Me.celdaCat_ref)
        Me.Panel1.Controls.Add(Me.celdaAno_ref)
        Me.Panel1.Controls.Add(Me.celdaNum_ref)
        Me.Panel1.Controls.Add(Me.celdaLin_ref)
        Me.Panel1.Controls.Add(Me.celdaLin)
        Me.Panel1.Controls.Add(Me.celdaNum)
        Me.Panel1.Controls.Add(Me.celdaAno)
        Me.Panel1.Controls.Add(Me.celdaCat)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(519, 45)
        Me.Panel1.TabIndex = 0
        '
        'celdaCat_ref
        '
        Me.celdaCat_ref.Location = New System.Drawing.Point(355, 12)
        Me.celdaCat_ref.Name = "celdaCat_ref"
        Me.celdaCat_ref.Size = New System.Drawing.Size(10, 20)
        Me.celdaCat_ref.TabIndex = 7
        Me.celdaCat_ref.Text = "56"
        Me.celdaCat_ref.Visible = False
        '
        'celdaAno_ref
        '
        Me.celdaAno_ref.Location = New System.Drawing.Point(402, 12)
        Me.celdaAno_ref.Name = "celdaAno_ref"
        Me.celdaAno_ref.Size = New System.Drawing.Size(10, 20)
        Me.celdaAno_ref.TabIndex = 6
        Me.celdaAno_ref.Text = "2019"
        Me.celdaAno_ref.Visible = False
        '
        'celdaNum_ref
        '
        Me.celdaNum_ref.Location = New System.Drawing.Point(449, 12)
        Me.celdaNum_ref.Name = "celdaNum_ref"
        Me.celdaNum_ref.Size = New System.Drawing.Size(10, 20)
        Me.celdaNum_ref.TabIndex = 5
        Me.celdaNum_ref.Text = "100"
        Me.celdaNum_ref.Visible = False
        '
        'celdaLin_ref
        '
        Me.celdaLin_ref.Location = New System.Drawing.Point(496, 12)
        Me.celdaLin_ref.Name = "celdaLin_ref"
        Me.celdaLin_ref.Size = New System.Drawing.Size(10, 20)
        Me.celdaLin_ref.TabIndex = 4
        Me.celdaLin_ref.Text = "2"
        Me.celdaLin_ref.Visible = False
        '
        'celdaLin
        '
        Me.celdaLin.Location = New System.Drawing.Point(480, 12)
        Me.celdaLin.Name = "celdaLin"
        Me.celdaLin.Size = New System.Drawing.Size(10, 20)
        Me.celdaLin.TabIndex = 3
        Me.celdaLin.Text = "1"
        Me.celdaLin.Visible = False
        '
        'celdaNum
        '
        Me.celdaNum.Location = New System.Drawing.Point(433, 12)
        Me.celdaNum.Name = "celdaNum"
        Me.celdaNum.Size = New System.Drawing.Size(10, 20)
        Me.celdaNum.TabIndex = 2
        Me.celdaNum.Text = "100"
        Me.celdaNum.Visible = False
        '
        'celdaAno
        '
        Me.celdaAno.Location = New System.Drawing.Point(386, 12)
        Me.celdaAno.Name = "celdaAno"
        Me.celdaAno.Size = New System.Drawing.Size(10, 20)
        Me.celdaAno.TabIndex = 1
        Me.celdaAno.Text = "2019"
        Me.celdaAno.Visible = False
        '
        'celdaCat
        '
        Me.celdaCat.Location = New System.Drawing.Point(339, 12)
        Me.celdaCat.Name = "celdaCat"
        Me.celdaCat.Size = New System.Drawing.Size(10, 20)
        Me.celdaCat.TabIndex = 0
        Me.celdaCat.Text = "47"
        Me.celdaCat.Visible = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.celdaSuma)
        Me.Panel2.Controls.Add(Me.etiquetaLibras)
        Me.Panel2.Controls.Add(Me.botonCancelar)
        Me.Panel2.Controls.Add(Me.botonAceptar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 289)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(519, 50)
        Me.Panel2.TabIndex = 1
        '
        'celdaSuma
        '
        Me.celdaSuma.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSuma.Enabled = False
        Me.celdaSuma.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaSuma.Location = New System.Drawing.Point(76, 11)
        Me.celdaSuma.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSuma.Name = "celdaSuma"
        Me.celdaSuma.Size = New System.Drawing.Size(107, 22)
        Me.celdaSuma.TabIndex = 6
        '
        'etiquetaLibras
        '
        Me.etiquetaLibras.AutoSize = True
        Me.etiquetaLibras.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaLibras.Location = New System.Drawing.Point(21, 14)
        Me.etiquetaLibras.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaLibras.Name = "etiquetaLibras"
        Me.etiquetaLibras.Size = New System.Drawing.Size(44, 16)
        Me.etiquetaLibras.TabIndex = 7
        Me.etiquetaLibras.Text = "Total"
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.botonCancelar.Location = New System.Drawing.Point(328, 5)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(59, 38)
        Me.botonCancelar.TabIndex = 5
        Me.botonCancelar.Text = "Cancelar"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(434, 5)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(59, 38)
        Me.botonAceptar.TabIndex = 4
        Me.botonAceptar.Text = "Aceptar"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.botonEliminar)
        Me.Panel3.Controls.Add(Me.botonAgregar)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(457, 45)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(62, 244)
        Me.Panel3.TabIndex = 2
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(5, 73)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(45, 41)
        Me.botonEliminar.TabIndex = 3
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(6, 17)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(45, 43)
        Me.botonAgregar.TabIndex = 2
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'dgGastos
        '
        Me.dgGastos.AllowUserToAddRows = False
        Me.dgGastos.AllowUserToDeleteRows = False
        Me.dgGastos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgGastos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgGastos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgGastos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgGastos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cat_i, Me.ano_i, Me.num_i, Me.lin_i, Me.idGasto, Me.Gasto, Me.Monto, Me.cat_x, Me.ano_x, Me.num_x, Me.lin_x, Me.colMarca})
        Me.dgGastos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgGastos.Location = New System.Drawing.Point(0, 45)
        Me.dgGastos.MultiSelect = False
        Me.dgGastos.Name = "dgGastos"
        Me.dgGastos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgGastos.Size = New System.Drawing.Size(457, 244)
        Me.dgGastos.TabIndex = 3
        '
        'cat_i
        '
        Me.cat_i.HeaderText = "cat_i"
        Me.cat_i.Name = "cat_i"
        Me.cat_i.Visible = False
        Me.cat_i.Width = 55
        '
        'ano_i
        '
        Me.ano_i.HeaderText = "ano_i"
        Me.ano_i.Name = "ano_i"
        Me.ano_i.Visible = False
        Me.ano_i.Width = 58
        '
        'num_i
        '
        Me.num_i.HeaderText = "num_i"
        Me.num_i.Name = "num_i"
        Me.num_i.Visible = False
        Me.num_i.Width = 60
        '
        'lin_i
        '
        Me.lin_i.HeaderText = "lin_i"
        Me.lin_i.Name = "lin_i"
        Me.lin_i.Visible = False
        Me.lin_i.Width = 50
        '
        'idGasto
        '
        Me.idGasto.HeaderText = "ID"
        Me.idGasto.Name = "idGasto"
        Me.idGasto.Width = 43
        '
        'Gasto
        '
        Me.Gasto.HeaderText = "Gasto"
        Me.Gasto.Name = "Gasto"
        Me.Gasto.Width = 60
        '
        'Monto
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Blue
        DataGridViewCellStyle1.Format = "N2"
        DataGridViewCellStyle1.NullValue = "0"
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        Me.Monto.DefaultCellStyle = DataGridViewCellStyle1
        Me.Monto.HeaderText = "Monto"
        Me.Monto.Name = "Monto"
        Me.Monto.Width = 62
        '
        'cat_x
        '
        Me.cat_x.HeaderText = "cat_x"
        Me.cat_x.Name = "cat_x"
        Me.cat_x.Visible = False
        Me.cat_x.Width = 58
        '
        'ano_x
        '
        Me.ano_x.HeaderText = "ano_x"
        Me.ano_x.Name = "ano_x"
        Me.ano_x.Visible = False
        Me.ano_x.Width = 61
        '
        'num_x
        '
        Me.num_x.HeaderText = "num_x"
        Me.num_x.Name = "num_x"
        Me.num_x.Visible = False
        Me.num_x.Width = 63
        '
        'lin_x
        '
        Me.lin_x.HeaderText = "lin_x"
        Me.lin_x.Name = "lin_x"
        Me.lin_x.Visible = False
        Me.lin_x.Width = 53
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Marca"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.Visible = False
        Me.colMarca.Width = 62
        '
        'celdaReferencia
        '
        Me.celdaReferencia.AutoSize = True
        Me.celdaReferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaReferencia.Location = New System.Drawing.Point(21, 15)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(51, 15)
        Me.celdaReferencia.TabIndex = 8
        Me.celdaReferencia.Text = "Label1"
        '
        'frmGastosLogistica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(519, 339)
        Me.Controls.Add(Me.dgGastos)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmGastosLogistica"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Import and Export Expenses"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        CType(Me.dgGastos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents dgGastos As DataGridView
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents celdaSuma As TextBox
    Friend WithEvents etiquetaLibras As Label
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents celdaCat_ref As TextBox
    Friend WithEvents celdaAno_ref As TextBox
    Friend WithEvents celdaNum_ref As TextBox
    Friend WithEvents celdaLin_ref As TextBox
    Friend WithEvents celdaLin As TextBox
    Friend WithEvents celdaNum As TextBox
    Friend WithEvents celdaAno As TextBox
    Friend WithEvents celdaCat As TextBox
    Friend WithEvents cat_i As DataGridViewTextBoxColumn
    Friend WithEvents ano_i As DataGridViewTextBoxColumn
    Friend WithEvents num_i As DataGridViewTextBoxColumn
    Friend WithEvents lin_i As DataGridViewTextBoxColumn
    Friend WithEvents idGasto As DataGridViewTextBoxColumn
    Friend WithEvents Gasto As DataGridViewTextBoxColumn
    Friend WithEvents Monto As DataGridViewTextBoxColumn
    Friend WithEvents cat_x As DataGridViewTextBoxColumn
    Friend WithEvents ano_x As DataGridViewTextBoxColumn
    Friend WithEvents num_x As DataGridViewTextBoxColumn
    Friend WithEvents lin_x As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents celdaReferencia As Label
End Class
