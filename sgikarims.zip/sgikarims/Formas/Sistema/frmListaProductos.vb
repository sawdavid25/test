﻿Public Class frmListaProductos

#Region "Miembros"

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 127
    Dim cfun As New clsFunciones

    Dim strLLave As String = STR_VACIO
    Dim strDato As String = STR_VACIO
    Dim strDato2 As String = STR_VACIO
    Dim strDato3 As String = STR_VACIO
    Dim strDato4 As String = STR_VACIO

    Dim strCampos As String = STR_VACIO
    Dim strTabla As String = STR_VACIO
    Dim strFiltro As String = STR_VACIO
    Dim intLimite As Integer = NO_FILA
    Dim strCondicion As String = STR_VACIO
    Dim strOrdenamiento As String = STR_VACIO
    Dim strFiltroText As String = STR_VACIO
    Dim strTitulo As String = STR_VACIO
    Dim ROrdenamiento As String = "DESC"
    Dim strAgrupar As String = STR_VACIO

    Private strCriterio As String
    Private strBusqueda As String
    Private logCargado As Boolean
    Private logCancelar As Boolean


    Public Generico As Boolean
    Public Especifico As Boolean

#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property LLave As String
        Get
            Return strLLave
        End Get
        Set(value As String)
            strLLave = value
        End Set
    End Property

    Public Property Dato2 As String
        Get
            Return strDato2
        End Get
        Set(value As String)
            strDato2 = value
        End Set
    End Property

    Public Property Dato As String
        Get
            Return strDato
        End Get
        Set(value As String)
            strDato = value
        End Set
    End Property

    Public Property Dato3 As String
        Get
            Return strDato3
        End Get
        Set(value As String)
            strDato3 = value
        End Set
    End Property

    Public Property Dato4 As String
        Get
            Return strDato4
        End Get
        Set(value As String)
            strDato4 = value
        End Set
    End Property

    Public Property Campos As String
        Get
            Return strCampos
        End Get
        Set(value As String)
            strCampos = value
        End Set
    End Property

    Public Property Tabla As String
        Get
            Return strTabla
        End Get
        Set(value As String)
            strTabla = value
        End Set
    End Property

    Public Property Titulo As String
        Get
            Return strTitulo
        End Get
        Set(value As String)
            strTitulo = value
        End Set
    End Property

    Public Property Limite As Integer
        Get
            Return intLimite
        End Get
        Set(value As Integer)
            intLimite = value
        End Set
    End Property

    Public Property Condicion As String
        Get
            Return strCondicion
        End Get
        Set(value As String)
            strCondicion = value
        End Set
    End Property

    Public Property Ordenamiento As String
        Get
            Return strOrdenamiento
        End Get
        Set(value As String)
            strOrdenamiento = value
        End Set
    End Property

    Public WriteOnly Property TipoOrdenamiento As String
        Set(value As String)
            ROrdenamiento = value
        End Set
    End Property

#End Region

#Region "Funciones y Procedimientos Locales"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Buscar()




    End Sub

    Private Function SQLlistaCompras() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT inv_sisemp, inv_numero, inv_fecha, inv_artcodigo,inv_provcod, inv_lugarfab, art_sisemp, inv_partnum, inv_prodlote, inv_prodano, inv_prodsem, inv_costo, inv_generico,inv_status  , art_codigo, art_DCorta, inv_UMcmpra, ifnull(pro.pro_sisemp,0), ifnull(pro.pro_codigo,0), ifnull(pro.pro_proveedor,'') proveedor, m.cat_clave, art_DCorta, IFNULL(p.cat_clave,'')Origen"
        strsql &= " FROM  Inventarios "
        strsql &= "       INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo "
        strsql &= "       LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMcmpra "
        strsql &= "       LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab "
        strsql &= "       LEFT JOIN Proveedores pro ON pro_sisemp = inv_sisemp AND pro_codigo = inv_provcod"
        strsql &= "   WHERE inv_sisemp = {empresa} AND " & strCriterio
        strsql &= " inv_status = 'activo'"


        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)


        Return strsql

    End Function

    Private Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        'Dim CON As MySqlConnection
        'CON = New MySqlConnection(strConexion)
        'CON.Open()
        Dim strFila As String = STR_VACIO

        strSQL = SQLlistaCompras()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read

                    strFila = REA.GetInt32("inv_numero") & "|"
                    strFila &= REA.GetInt32("art_codigo") & "|"
                    strFila &= REA.GetString("art_DCorta") & "|"
                    strFila &= REA.GetDouble("inv_costo") & "|"
                    strFila &= REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("proveedor") & "|"
                    strFila &= REA.GetString("origen") & "|"
                    strFila &= REA.GetString("inv_partnum") & "|"
                    strFila &= REA.GetString("art_DCorta") & "|"
                    strFila &= REA.GetString("inv_prodlote") & "|"
                    strFila &= REA.GetInt32("inv_prodano") & "|"
                    strFila &= REA.GetInt32("inv_prodsem") & "|"
                    strFila &= REA.GetInt32("inv_UMcmpra") & "|"
                    strFila &= REA.GetInt32("inv_generico")


                    If REA.GetInt32("inv_generico") = 0 Then
                        cfun.AgregarFila(dgLista, strFila, Color.Lavender)
                    Else
                        cfun.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString, strFila)
        End Try

        'CON.Close()
    End Sub


    Private Sub Seleccionar()
        If dgLista.SelectedRows.Count = 0 Then Exit Sub
        Try
            strLLave = dgLista.SelectedCells(0).Value
            strDato = dgLista.SelectedCells(1).Value
            strDato2 = dgLista.SelectedCells(2).Value
            strDato3 = dgLista.SelectedCells(3).Value
            strDato4 = dgLista.SelectedCells(4).Value
        Catch ex As Exception

        End Try
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

#End Region

    Private Sub frmListaProductos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmListaProductos_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        CargarLista()
    End Sub

    Private Sub Form_Activate()

        strCriterio = vbNull

        logCargado = False

        If Generico Then
            checkGenericos.Checked = True
            checkEspecificos.Checked = False
        ElseIf Especifico Then
            checkGenericos.Checked = False
            checkEspecificos.Checked = True
        Else
            checkGenericos.Checked = True
            checkEspecificos.Checked = True
        End If

        ConfigurarFiltro()

        logCargado = True

        CargarLista()

    End Sub

    Private Sub MostrarInfo()



    End Sub

    Private Sub ConfigurarFiltro()

        If checkGenericos.Checked = False And checkEspecificos.Checked = True Then
            'Específico
            strCriterio = " inv_generico = 1 AND "
        ElseIf checkGenericos.Checked = True And checkEspecificos.Checked = False Then
            'Genérico
            strCriterio = " inv_generico = 0 AND "
        End If
    End Sub

    Private Sub For_Activate()

        strCriterio = vbNull

        logCargado = False

        If Generico Then
            checkGenericos.Checked = True
            checkEspecificos.Checked = False
        ElseIf Especifico Then
            checkGenericos.Checked = False
            checkEspecificos.Checked = True
        Else
            checkGenericos.Checked = True
            checkEspecificos.Checked = True
        End If

        ConfigurarFiltro()

        logCargado = True

    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()
    End Sub


    Private Sub dgLista_SelectionChanged(sender As Object, e As EventArgs)

        celdaFabricante.Text = dgLista.CurrentRow.Cells("colFabricante").Value
        celdaLugarFabri.Text = dgLista.CurrentRow.Cells("colLugarFabri").Value
        celdaNumParte.Text = dgLista.CurrentRow.Cells("colNoParte").Value
        celdaDescripcion.Text = dgLista.CurrentRow.Cells("colDescrip").Value
        celdaNumLote.Text = dgLista.CurrentRow.Cells("colNoLote").Value
        celdaAño.Text = dgLista.CurrentRow.Cells("colAño").Value
        celdaSemana.Text = dgLista.CurrentRow.Cells("colSemana").Value

    End Sub

    Private Sub checkEspecificos_CheckedChanged(sender As Object, e As EventArgs) Handles checkEspecificos.CheckedChanged

        Dim strFila As String = STR_VACIO
        ' If Not logCargado Then Exit Sub

        strCriterio = vbNull
        ConfigurarFiltro()
        CargarLista()
        MostrarInfo()


    End Sub


    Private Sub checkGenericos_CheckedChanged(sender As Object, e As EventArgs) Handles checkGenericos.CheckedChanged

        Dim strFila As String = STR_VACIO
        '  If Not logCargado Then Exit Sub

        strCriterio = vbNull
        ConfigurarFiltro()
        CargarLista()
        MostrarInfo()

    End Sub

    Private Sub celdaEspera_TextChanged(sender As Object, e As EventArgs) Handles celdaEspera.TextChanged

        MostrarInfo()

    End Sub

    Private Sub botonBusca_Click(sender As Object, e As EventArgs) Handles botonBusca.Click

        Buscar()
    End Sub

End Class