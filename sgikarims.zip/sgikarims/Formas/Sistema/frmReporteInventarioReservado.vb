﻿Public Class frmReporteInventarioReservado
#Region "Variables"
    Dim IntInventarioOpciones As Integer
#End Region

#Region "Procedimientos"

    Public ReadOnly Property OpcioneInventario As Integer
        Get
            Return IntInventarioOpciones
        End Get
    End Property
#End Region



    Private Sub frmReporteInventarioReservado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Try
            If rbInventarioReservado.Checked = True Then
                IntInventarioOpciones = 1
            ElseIf rbOrdenadoComprometido.Checked = True Then
                IntInventarioOpciones = 0
            End If



            Me.DialogResult = DialogResult.OK

        Catch ex As Exception
            MsgBox(e.ToString)
        End Try
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub
End Class