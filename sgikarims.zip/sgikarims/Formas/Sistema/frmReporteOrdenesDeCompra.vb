﻿Public Class frmReporteOrdenesDeCompra
#Region "Variables"
    Dim IntFabricante As Integer
    Dim IntProducto As Integer
    Dim IntPaisOrigen As Integer
    Dim IntrOpciones As Integer
    Dim LogResumen As Boolean
    Dim LogHeathers As Boolean
    Dim dtFechaInicial As Date
    Dim dtFechaFinal As Date
    Dim IntOrdenamiento As Integer



#End Region

#Region "Propiedades"

    Public ReadOnly Property Cod_Fabricante As Integer
        Get
            Return IntFabricante
        End Get
    End Property
    Public ReadOnly Property Cod_Producto As Integer
        Get
            Return IntProducto
        End Get
    End Property
    Public ReadOnly Property Cod_PaisOrigen As Integer
        Get
            Return IntPaisOrigen
        End Get
    End Property
    Public ReadOnly Property Seleccion_Opciones As Integer
        Get
            Return IntrOpciones
        End Get
    End Property
    Public ReadOnly Property Pos_Resumen As Boolean
        Get
            Return LogResumen
        End Get
    End Property
    Public ReadOnly Property Pos_Heathers As Boolean
        Get
            Return LogHeathers
        End Get
    End Property
    Public ReadOnly Property Seleccion_Fecha_Inicial As Date
        Get
            Return dtFechaInicial
        End Get
    End Property
    Public ReadOnly Property Seleccion_Fecha_Final As Date
        Get
            Return dtFechaFinal
        End Get
    End Property
    Public ReadOnly Property Pos_Ordenamiento
        Get
            Return IntOrdenamiento
        End Get
    End Property


#End Region

    Private Sub botonFabricante_Click(sender As Object, e As EventArgs) Handles botonFabricante.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " pro_codigo ID , pro_proveedor Proveedor "
        frm.Tabla = " Proveedores "
        frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & " and  pro_fabricante = 'Si' "
        frm.Filtro = " pro_proveedor "
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Proveedores "
        frm.FiltroText = " Ingrese el nombre del proveedor para filtar "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIDProveedor.Text = frm.LLave
            celdaFabricante.Text = frm.Dato
        End If

    End Sub

    Private Sub botonPaisOrigen_Click(sender As Object, e As EventArgs) Handles botonPaisOrigen.Click
        Dim frm As New frmSeleccionar

        ' Propiedades de consulta 
        frm.Campos = " cat_num ID , cat_desc Descripcion "
        frm.Tabla = " Catalogos "
        frm.Condicion = " cat_clase = 'paises' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogos "
        frm.FiltroText = " Ingrese el nombre del pais para filtrar"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIDPaisOrigen.Text = frm.LLave
            celdaPaisOrigen.Text = frm.Dato

        End If

    End Sub

    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click
        Dim frm As New frmSeleccionar

        'Propiedades de consulta
        frm.Campos = " art_codigo ID, art_DCorta DescripcionCorta "
        frm.Tabla = " Articulos "
        frm.Condicion = " art_sisemp= " & Sesion.IdEmpresa & ""
        frm.Filtro = " art_DCorta "
        frm.Limite = " 20 "

        'Propiedades de Formulario
        frm.Titulo = " Articulo "
        frm.FiltroText = " Ingrese el Nombre del Articulo para filtrar "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIDProducto.Text = frm.LLave
            celdaProducto.Text = frm.Dato
        End If



    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

        Try


            IntFabricante = CInt(celdaIDProveedor.Text)
            IntProducto = CInt(celdaIDProducto.Text)

            IntPaisOrigen = CInt(celdaIDPaisOrigen.Text)

            If rbConSaldo.Checked = True Then

                IntrOpciones = 0
            ElseIf rbSinSaldo.Checked = True Then
                IntrOpciones = 1
            Else
                IntrOpciones = 2

        End If


        If checkResumen.Checked = True Then

                LogResumen = True
            Else
                LogResumen = False

            End If
            If checkHeathers.Checked = True Then

                LogHeathers = 1
            Else
                LogHeathers = 0

        End If
        dtFechaInicial = dtpFechaInicial.Value
        dtFechaFinal = dtpFechaFinal.Value


            If rbProveedor.Checked = True Then
                IntOrdenamiento = 0
            ElseIf rbFabricante.Checked = True Then
                IntOrdenamiento = 1
            Else
                IntOrdenamiento = 2

            End If
            Me.DialogResult = DialogResult.OK

        Catch ex As Exception
            MsgBox(e.ToString)
        End Try

    End Sub

    Private Sub dtpFechaInicial_ValueChanged(sender As Object, e As EventArgs) Handles dtpFechaInicial.ValueChanged

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()

    End Sub

    Private Sub frmReporteOrdenesDeCompra_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFechaFinal.Value = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        dtpFechaInicial.Value = DateSerial(Year(dtpFechaFinal.Value), 1, 1)
    End Sub
End Class