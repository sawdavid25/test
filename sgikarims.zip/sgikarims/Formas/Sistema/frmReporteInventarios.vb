﻿Public Class frmReporteInventarios
#Region "Variables"
    Dim strPaisTemporal As String
    Dim IntClase As Integer
    Dim intAcabado As Integer
    Dim IntSpinning As Integer
    Dim strPaises As String
    Dim strPais As String
    Dim strTituloHilos As String
    Dim IntFabricante As Integer
    Dim IntProveedor As Integer
    Dim strBodega As String
    Dim LogHeathers As Boolean
    Dim LogPartida As Boolean
    Dim LogDeclaracion As Boolean
    Dim LogBodega As Boolean
    Dim LogMuestra As Boolean
    Dim IntNoHilo As Integer
    Dim LogFecha As Boolean
    Dim dtFechaInventario As Date
    Dim IntNotas As Integer
#End Region
    Public ReadOnly Property COD_CLASE As Integer
        Get
            Return IntClase
        End Get
    End Property
    Public ReadOnly Property COD_Acabado As Integer
        Get
            Return intAcabado
        End Get
    End Property
    Public ReadOnly Property COD_Spinning As Integer
        Get
            Return IntSpinning
        End Get
    End Property


    Public ReadOnly Property InformacionTitulo As String
        Get
            Return strTituloHilos
        End Get
    End Property

    Public ReadOnly Property Cod_Fabricante As Integer
        Get
            Return IntFabricante
        End Get
    End Property
    Public ReadOnly Property Cod_Proveedor As Integer
        Get
            Return IntProveedor
        End Get
    End Property
    Public ReadOnly Property Paises As String
        Get
            Return strPaises
        End Get
    End Property
    Public ReadOnly Property Pais As String
        Get
            Return strPais
        End Get
    End Property
    Public ReadOnly Property Cod_Bodega As String
        Get
            Return strBodega
        End Get
    End Property
    Public ReadOnly Property Seleccion_Heathers As Boolean
        Get
            Return LogHeathers
        End Get
    End Property
    Public ReadOnly Property Seleccion_Partida As Boolean
        Get
            Return LogPartida
        End Get
    End Property
    Public ReadOnly Property Seleccion_Declaracion As Boolean
        Get
            Return LogDeclaracion
        End Get
    End Property
    Public ReadOnly Property Seleccion_Bodega As Boolean
        Get
            Return LogBodega
        End Get
    End Property
    Public ReadOnly Property Seleccion_Muestra As Boolean
        Get
            Return LogMuestra
        End Get
    End Property
    Public ReadOnly Property Seleccion_Opciones As Integer
        Get
            Return IntNoHilo
        End Get
    End Property
    Public ReadOnly Property Seleccion_Fecha As Boolean
        Get
            Return LogFecha
        End Get
    End Property
    Public ReadOnly Property Seleccion_FechaInventario As Date
        Get
            Return dtFechaInventario
        End Get
    End Property
    Public ReadOnly Property OpcionNotas As Integer
        Get
            Return IntNotas
        End Get
    End Property

    Private Sub botonFabricante_Click(sender As Object, e As EventArgs) Handles botonFabricante.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " pro_codigo ID , pro_proveedor Provider "
        frm.Tabla = " Proveedores "
        frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & " and  pro_fabricante = 'Si' "
        frm.Filtro = " pro_proveedor "
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Proveedores "
        frm.FiltroText = " Enter provider name to filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdFabricante.Text = frm.LLave
            celdaFabricante.Text = frm.Dato
        End If
    End Sub
    Private Sub botonPaisOrigen_Click(sender As Object, e As EventArgs) Handles botonPaisOrigen.Click
        Dim frm As New frmSeleccionar
        Dim CF As New clsFunciones


        ' Propiedades de consulta 
        frm.Campos = " cat_num ID , cat_desc Description "
        frm.Tabla = " Catalogos "
        frm.Condicion = " cat_clase = 'paises' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the country to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then

            If Not ExistePais(frm.LLave) Then
                CF.AgregarFila(dgPaises, frm.LLave & "|" & frm.Dato)
            End If



        End If
    End Sub
    Private Sub botonClase_Click(sender As Object, e As EventArgs) Handles botonClase.Click
        Dim frm As New frmSeleccionar

        ' Propiedades de consulta 
        frm.Campos = " c.cat_num IDC ,c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase='ClaseArt' ORDER BY c.cat_desc "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the Catalog to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdCLase.Text = frm.LLave
            celdaClase.Text = frm.Dato
        End If
    End Sub
    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " p.pro_codigo Code , p.pro_proveedor Provider "
        frm.Tabla = " Proveedores p  "
        frm.Condicion = " p.pro_sisemp = " & Sesion.IdEmpresa & ""
        frm.Ordenamiento = " Provider"
        frm.Filtro = " p.pro_proveedor"
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Suppliers "
        frm.FiltroText = " Enter provider name to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdProveedor.Text = frm.LLave
            celdaProveedor.Text = frm.Dato
        End If

    End Sub
    Private Sub botonAcabado_Click(sender As Object, e As EventArgs) Handles botonAcabado.Click

        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_num Code , c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase = 'Acabado'"
        frm.Ordenamiento = " c.cat_clase"
        frm.Filtro = " c.cat_desc "
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Finish "
        frm.FiltroText = " Enter Finish Name to Filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdAcabado.Text = frm.LLave
            CeldaAcabado.Text = frm.Dato
        End If

    End Sub
    Private Sub botonBodega_Click(sender As Object, e As EventArgs) Handles botonBodega.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_clave Cellar "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase='Bodegas' "
        frm.Filtro = " c.cat_clave"
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Suppliers "
        frm.FiltroText = " Enter provider name to filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaBodega.Text = frm.LLave
        End If


    End Sub
    Private Sub botonSpinning_Click(sender As Object, e As EventArgs) Handles botonSpinning.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_num Number , c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase ='Spinning' ORDER By cat_clave "
        frm.Filtro = " c.cat_clave "
        frm.Limite = " 10 "
        ' propiedades de formulario
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the Spinning name to filter "
        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdSpinning.Text = frm.LLave
            CeldaSpinning.Text = frm.Dato
        End If
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Dim frm As New frmOption

        Try






            IntClase = CInt(celdaIdCLase.Text)
            intAcabado = CInt(celdaIdAcabado.Text)
            IntSpinning = CInt(celdaIdSpinning.Text)


            strPaises = STR_VACIO
            strPais = STR_VACIO

            For i = 0 To dgPaises.RowCount - 1
                If i < dgPaises.RowCount - 1 Then
                    strPaises &= dgPaises.Rows(i).Cells("col_num").Value & ","
                    strPais &= dgPaises.Rows(i).Cells("col_nombre").Value & ","
                ElseIf i = dgPaises.RowCount - 1 Then
                    strPaises = strPaises & dgPaises.Rows(i).Cells("col_num").Value
                    strPais &= dgPaises.Rows(i).Cells("col_nombre").Value
                End If

            Next




            strTituloHilos = celdaTituloHilo.Text
            IntFabricante = CInt(celdaIdFabricante.Text)
            IntProveedor = CInt(celdaIdProveedor.Text)
            strBodega = celdaBodega.Text

            If checkHeathers.Checked = True Then
                LogHeathers = True
            Else
                LogHeathers = False
            End If

            If checkPartidaArancelaria.Checked = True Then
                LogPartida = True
            Else
                LogPartida = False
            End If

            If checkDeclaracion.Checked = True Then
                LogDeclaracion = True
            Else
                LogDeclaracion = False
            End If

            If checkBodega.Checked = True Then
                LogBodega = True
            Else
                LogBodega = False
            End If
            If checkMuestra.Checked = True Then
                LogMuestra = True
            Else
                LogMuestra = False
            End If


            If rbSoloHilo.Checked = True Then
                IntNoHilo = 1
            ElseIf rbOtrosProductos.Checked = True Then
                IntNoHilo = 2
            Else
                IntNoHilo  = 0
            End If

            If checkFiltrarFecha.Checked = True Then
                dtFechaInventario = dtpInventarioFecha.Value
            End If



            frm.Opciones = "Include entry doc notes |" & " No Notes "
            frm.Titulo = " DOCUMENTS NOTES "
            frm.ShowDialog(Me)
            Me.DialogResult = DialogResult.OK
            Select Case frm.Seleccion
                Case 0  ' Notas de Ingreso 
                    IntNotas = 1
                Case 1 ' Sin Notas 
                    IntNotas = 2
            End Select


        Catch ex As Exception
            MsgBox(e.ToString)
        End Try
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Function ExistePais(ByVal codigo As Integer) As Boolean
        Dim logResultado As Boolean = False
        For i As Integer = 0 To dgPaises.Rows.Count - 1
            If codigo = dgPaises.Rows(i).Cells("col_num").Value Then
                logResultado = True
                Exit For
            End If
        Next
        Return logResultado
    End Function
    Private Sub botonAsia_Click(sender As Object, e As EventArgs) Handles botonAsia.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Dim CF As New clsFunciones

        Try
            strSQL = " SELECT c.cat_num Numero , c.cat_desc Descripcion FROM Catalogos c WHERE cat_clase='Paises' AND cat_pid=(SELECT cat_num FROM Catalogos WHERE cat_clase='Countries' AND cat_clave='ASIA')  ORDER BY cat_desc "

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                Do While REA.Read
                    If Not ExistePais(REA.GetInt32("Numero")) Then
                        CF.AgregarFila(dgPaises, REA.GetInt32("Numero") & "|" & REA.GetString("Descripcion"))
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonCentroAmerica_Click(sender As Object, e As EventArgs) Handles botonCentroAmerica.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CF As New clsFunciones

        Try
            strSQL = " SELECT c.cat_num Numero , c.cat_desc Descripcion FROM Catalogos c WHERE cat_clase='Paises' AND cat_pid=(SELECT cat_num FROM Catalogos WHERE cat_clase='Countries' AND cat_clave='CA')  ORDER BY cat_desc "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If Not ExistePais(REA.GetInt32("Numero")) Then
                        CF.AgregarFila(dgPaises, REA.GetInt32("Numero") & "|" & REA.GetString("Descripcion"))
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub checkDeclaracion_CheckedChanged(sender As Object, e As EventArgs) Handles checkDeclaracion.CheckedChanged
        If checkDeclaracion.Checked = True Then
            checkPartidaArancelaria.Checked = False

        End If
    End Sub

    Private Sub checkPartidaArancelaria_CheckedChanged(sender As Object, e As EventArgs) Handles checkPartidaArancelaria.CheckedChanged
        If checkPartidaArancelaria.Checked = True Then
            checkDeclaracion.Checked = False
        End If
    End Sub
End Class