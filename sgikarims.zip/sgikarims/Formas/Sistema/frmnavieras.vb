﻿Public Class frmnavieras
#Region "variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const INSERTAR = 1
    Const ACTUALIZAR = 2
    Const BORRAR = 3
    Const CONSULTAR = 4
    Dim dicRequisitos As New Dictionary(Of Integer, Integer)
    Dim dicAccesos As New Dictionary(Of Integer, Integer)
    Dim cfun As New clsFunciones
#End Region
#Region "propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "funciones"

    Private Sub frmnavieras_Load(sender As Object, e As EventArgs) Handles Me.Load
        reset()
        Accesos()
        MostrarLista()
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            paneldocumento.Dock = DockStyle.None
            paneldocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Navieras")
            BarraTitulo2.CambiarTitulo("Navieras")
            'Cargar Datos

            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones(True)
            Me.Tag = "Nuevo"
        Else
            BloquearBotones(False)
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            paneldocumento.Dock = DockStyle.Fill
            paneldocumento.Visible = True
            If logInsert = False Then
                Me.Tag = "Mod"

                BloquearBotones(False, True)
            Else
                Me.Tag = "Nuevo"

                BarraTitulo1.CambiarTitulo(" New Record")
                BloquearBotones(False)


                reset()
            End If
            dgListaNavieras.DataSource = Nothing
        End If
    End Sub

    Private Function SQLENCABEZADO(ByVal codigo As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT cat_num, cat_clase, cat_desc "
        strSQL &= "     FROM Catalogos Where cat_clase = 'Naviera' And cat_num = {codigo} Order By cat_num Asc "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", codigo)
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLENCABEZADO(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaid.Text = REA.GetInt32("cat_num")
                    celdanombre.Text = REA.GetString("cat_desc")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function sqlcargarnaviera(ByVal Codigo As Integer) As String
        Dim strSQL As String
        strSQL = " SELECT cat_num, cat_clase, cat_desc "
        strSQL &= "     FROM Catalogos "
        strSQL &= "       Where cat_clase = 'Naviera' Order By cat_num Asc  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function

    Private Function sqlNaviera() As String
        Dim strSQL As String
        strSQL = " SELECT cat_num, cat_clase, cat_desc "
        strSQL &= "     FROM Catalogos "
        strSQL &= "       Where cat_clase = 'Naviera' Order By cat_num Asc  "
        Return strSQL
    End Function
    Private Sub CargarLista()
        Dim str_sql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            str_sql = sqlNaviera()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(str_sql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgListaNavieras.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("cat_num") & "|"
                    strFila &= REA.GetString("cat_desc")
                    cFunciones.AgregarFila(dgListaNavieras, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True, Optional logBorrar As Boolean = False)
        If logBloquear = True Then
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonBorrar.Enabled = False
        Else
            Encabezado1.botonGuardar.Enabled = True
            Encabezado1.botonBorrar.Enabled = True

        End If
    End Sub

    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logResultado As Boolean = True
        Try
            If celdanombre.Text = STR_VACIO Then
                logResultado = False
                MsgBox("Enter the data")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function ComprobarNaviera() As Integer
        Dim intResultado As Integer = NO_FILA
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSql = " Select Count(*)  From Catalogos  Where  cat_desc = '{cat_desc}'   "
            strSql = Replace(strSql, "{cat_desc}", celdanombre.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intResultado
    End Function

    Private Function NuevaNaviera() As Integer
        Dim intResultado As Integer = NO_FILA
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSql = " Select Max(cat_num)+1 From Catalogos   "
            ' strSql = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intResultado
    End Function

    Private Function guardarnaviera() As Boolean
        Dim logresultado As Boolean
        Dim programa As New Tablas.TCATALOGOS

        Try
            programa.CONEXION = strConexion
            programa.CAT_DESC = celdanombre.Text
            programa.CAT_CLASE = "Naviera"

            If Me.Tag = "Nuevo" Then
                If ComprobarNaviera() = INT_UNO Then
                    logresultado = False
                    MsgBox("The Shipping Line Already Exist")
                    reset()
                    Exit Function
                End If
                celdaid.Text = NuevaNaviera()
                programa.CAT_NUM = celdaid.Text
                If logInsertar = True Then
                    If programa.PINSERT = False Then
                        MsgBox(programa.MERROR.ToString & "Could not save this document")
                        logresultado = False
                    Else
                        logresultado = True
                        cFunciones.EscribirRegistro("Navieras", clsFunciones.AccEnum.acAdd, celdaid.Text, 0, cFunciones.AñoMySQL, celdaid.Text, celdanombre.Text)
                    End If
                Else
                    MsgBox("You Don´t Have Permissions")
                End If

            ElseIf Me.Tag = "mod" Then
                If ComprobarNaviera() = INT_UNO Then
                    logresultado = False
                    MsgBox("The shipping line Already Exist")
                    Exit Function
                End If
                If logEditar = True Then
                    programa.CAT_NUM = celdaid.Text
                    cFunciones.EscribirRegistro("Navieras", clsFunciones.AccEnum.acUpdate, celdaid.Text, 0, cFunciones.AñoMySQL, celdaid.Text, celdanombre.Text)
                    If programa.PUPDATE = False Then
                        MsgBox(programa.MERROR.ToString)
                        logresultado = False
                    Else
                        logresultado = True
                    End If
                Else
                    MsgBox("You Don´t Have Permissions")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logresultado
    End Function

    Public Sub LimpiarDatos()
        celdaid.Text = INT_CERO
        celdanombre.Text = STR_VACIO
    End Sub

    Public Sub reset()
        celdaid.Text = INT_CERO
        celdanombre.Text = ""
    End Sub


#End Region

#Region "Eventos"

    Private Sub frmnavierasLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        MostrarLista()
        Me.Tag = "Nuevo"
    End Sub

    Private Sub dgListaNavieras_DoubleClick(sender As Object, e As EventArgs) Handles dgListaNavieras.DoubleClick

        Try
            If dgListaNavieras.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modify")

            CargarEncabezado(dgListaNavieras.SelectedCells(0).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarDatos() = True Then

            If guardarnaviera() = True Then

                MostrarLista(True)
            End If
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If paneldocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        reset()
        MostrarLista(False, True)
        Encabezado1.botonBorrar.Enabled = False

    End Sub

    'Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar

    'If MsgBox("Esta seguro que desea eliminar", vbQuestion + vbYesNo, "Verificacion") = vbYes Then
    'If () = True Then
    '           MostrarLista(True)
    'End If
    'Else
    'End If

    'End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgListaNavieras.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgListaNavieras)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(0, 0, dgListaNavieras.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgListaNavieras.SelectedCells(0).Value, 0, 0, "ProgramasSC", dgListaNavieras.SelectedCells(0).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmnavieras_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub



#End Region
End Class
