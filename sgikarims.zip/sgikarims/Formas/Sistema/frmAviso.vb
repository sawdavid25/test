﻿Public Class frmAviso


#Region "Miembros"
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

    Dim strTexto As String = STR_VACIO

#End Region

#Region "Propiedades"
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

    Public Property Texto As String
        Get
            Return strTexto
        End Get
        Set(value As String)
            strTexto = value
        End Set
    End Property
#End Region


#Region "Eventos"

    Private Sub frmAviso_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmAviso_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim Texto As String = STR_VACIO

        Texto = strTexto

        celdaAviso.Text = strTexto
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()
    End Sub

#End Region




End Class