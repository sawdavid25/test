﻿Public Class frmImportaciones

#Region "Miembros"

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer
    Dim clic As Boolean = False
    Dim intmodo As String
    Dim ContarFilas As Integer
    Dim msj As String
    Dim strDato1 As String = STR_VACIO
    Dim strDato2 As String = STR_VACIO
    Dim strDato3 As String = STR_VACIO
    Dim strDato4 As String = STR_VACIO
    Dim strDato5 As String = STR_VACIO
    Dim strDato6 As String = STR_VACIO
    Dim strDato7 As String = STR_VACIO
    Dim strDato8 As String = STR_VACIO
    Dim strDato9 As String = STR_VACIO

#End Region


#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
    Public Property Dato1 As String
        Get
            Return strDato1
        End Get
        Set(value As String)
            strDato1 = value
        End Set
    End Property

    Public Property Dato2 As String
        Get
            Return strDato2
        End Get
        Set(value As String)
            strDato2 = value
        End Set
    End Property

    Public Property Dato3 As String
        Get
            Return strDato3
        End Get
        Set(value As String)
            strDato3 = value
        End Set
    End Property

    Public Property Dato4 As String
        Get
            Return strDato4
        End Get
        Set(value As String)
            strDato4 = value
        End Set
    End Property

    Public Property Dato5 As String
        Get
            Return strDato5
        End Get
        Set(value As String)
            strDato5 = value
        End Set
    End Property

    Public Property Dato6 As String
        Get
            Return strDato6
        End Get
        Set(value As String)
            strDato6 = value
        End Set
    End Property

    Public Property Dato7 As String
        Get
            Return strDato7
        End Get
        Set(value As String)
            strDato7 = value
        End Set
    End Property

    Public Property Dato8 As String
        Get
            Return strDato8
        End Get
        Set(value As String)
            strDato8 = value
        End Set
    End Property

    Public Property Dato9 As String
        Get
            Return strDato9
        End Get
        Set(value As String)
            strDato9 = value
        End Set
    End Property

#End Region


#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonBorrar.Enabled = False

        End If

    End Sub

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub Seleccionar()
        If dgImportaciones.SelectedRows.Count = 0 Then Exit Sub
        Try


            Dato1 = dgImportaciones.SelectedCells(0).Value
            Dato2 = dgImportaciones.SelectedCells(1).Value
            Dato3 = dgImportaciones.SelectedCells(2).Value
            Dato4 = dgImportaciones.SelectedCells(3).Value
            Dato5 = dgImportaciones.SelectedCells(4).Value
            Dato6 = dgImportaciones.SelectedCells(5).Value
            Dato7 = dgImportaciones.SelectedCells(6).Value
            Dato8 = dgImportaciones.SelectedCells(7).Value
            Dato9 = dgImportaciones.SelectedCells(8).Value

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Me.DialogResult = System.Windows.Forms.DialogResult.OK

    End Sub


#End Region



#Region "Eventos"
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        Me.Close()

    End Sub

    Private Sub botonSeleccionar_Click(sender As Object, e As EventArgs) Handles botonSeleccionar.Click
        Seleccionar()
        Me.dgImportaciones.Rows.Remove(dgImportaciones.CurrentRow)

    End Sub



#End Region

End Class