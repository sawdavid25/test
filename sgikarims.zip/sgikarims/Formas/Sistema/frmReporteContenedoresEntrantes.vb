﻿Public Class frmReporteContenedoresEntrantes
#Region "Variables"
    Dim dtFechaInicial As Date
    Dim dtFechaFinal As Date
    Dim logSinFechaArribo As Boolean
    Dim LogFiltrarCuenta As Boolean
    Dim LogReferencia As Boolean
    Dim LogCCosto As Boolean
    Dim LogRubro As Boolean
    Dim strCuenta As String
    Dim strNombre As String
    Dim LogAceptado As Boolean
    Dim LogMoneda As Boolean
#End Region
#Region "Propiedades"

    Public ReadOnly Property CCosto As Boolean
        Get
            Return LogCCosto
        End Get
    End Property
    Public ReadOnly Property Referencia As Boolean
        Get
            Return LogReferencia
        End Get
    End Property
    Public ReadOnly Property SeleccionFechaInicial As Date
        Get
            Return dtFechaInicial
        End Get
    End Property
    Public ReadOnly Property SeleccionFechaFinal As Date
        Get
            Return dtFechaFinal
        End Get
    End Property
    Public ReadOnly Property SinFechaArribo As Boolean
        Get
            Return logSinFechaArribo
        End Get
    End Property
    Public ReadOnly Property FiltroCuenta As Boolean
        Get
            Return LogFiltrarCuenta
        End Get
    End Property
    Public Property Cuenta As String
        Get
            Return strCuenta
        End Get
        Set(value As String)
            strCuenta = value
        End Set
    End Property
    Public Property Nombre As String
        Get
            Return strNombre
        End Get
        Set(value As String)
            strNombre = value
        End Set
    End Property
    Public ReadOnly Property Aceptar As Boolean
        Get
            Return LogAceptado
        End Get
    End Property
    Public ReadOnly Property Rubro As Boolean
        Get
            Return LogRubro
        End Get
    End Property
    Public ReadOnly Property Moneda As Boolean
        Get
            Return LogMoneda
        End Get
    End Property
#End Region
    Public Sub Cambiocuenta()
        checkSinFechaArribo.Text = "Summary"
        checkFiltrarCuenta.Checked = True
    End Sub

    Public Sub CambioFecha()
        Label4.Text = "Select any desired quarter date for the report"
        dtpFechaFinal.Enabled = False
        etiquetaFechaFinal.Enabled = False
        checkSinFechaArribo.Enabled = False
    End Sub
    Public Sub OcultarControles()
        checkSinFechaArribo.Visible = False
        checkFiltrarCuenta.Visible = False
    End Sub
   

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Dim frm As New frmSeleccionar
        Try

            dtFechaInicial = dtpFechaInicial.Value
            dtFechaFinal = dtpFechaFinal.Value
            LogAceptado = Aceptar
            '      If LogAceptado = True Then
            If dtFechaFinal < dtFechaInicial Then
                    MsgBox("The end date must be greater than or equal to the starting date", MsgBoxStyle.Exclamation, "Date Range")
                    Exit Sub

                End If
            '     End If

            If checkSinFechaArribo.Checked = True Then
                logSinFechaArribo = True
            Else
                logSinFechaArribo = False
            End If
            If checkCC.Checked = True Then
                LogCCosto = True
            Else
                LogCCosto = False
            End If
            If checkReferencia.Checked = True Then
                LogReferencia = True
            Else
                LogReferencia = False
            End If

            If checkRubroCuenta.Checked = True Then
                LogRubro = True
            Else
                LogRubro = False
            End If

            If checkMonedaTasa.Checked = True Then
                LogMoneda = True
            Else
                LogMoneda = False
            End If

            If checkFiltrarCuenta.Checked = True Then
                frm.Campos = " c.id_cuenta Id, c.nombre Nombre"
                frm.Tabla = " " & cFunciones.ContaEmpresa & ".cuentas c "
                frm.Condicion = " c.Empresa = " & Sesion.IdEmpresa & " "
                frm.Ordenamiento = "c.id_cuenta"
                frm.TipoOrdenamiento = " ASC"
                frm.Filtro = "c.nombre"
                frm.Limite = "20"
                'Propiedades del Formulario 
                frm.Titulo = "Acounting Accounts"
                frm.FiltroText = " Enter Item Name to filter"
                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    strCuenta = frm.LLave
                    strNombre = frm.Dato
                End If
                LogFiltrarCuenta = True
            Else
                LogFiltrarCuenta = False
            End If
            Me.DialogResult = DialogResult.OK
        Catch ex As Exception
            MsgBox(e.ToString)
        End Try





    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Sub frmReporteContenedoresEntrantes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFechaInicial.Value = Today.AddMonths(NO_FILA)
        dtpFechaFinal.Value = Today

        'If Sesion.idGiro = 1 Then
        '    checkRubroCuenta.Visible = True
        'Else
        '    checkRubroCuenta.Visible = False
        'End If

    End Sub

    Private Sub checkSinFechaArribo_CheckedChanged(sender As Object, e As EventArgs) Handles checkSinFechaArribo.CheckedChanged
        If checkSinFechaArribo.Checked = True Then
            'checkRubroCuenta.Enabled = False
            checkMonedaTasa.Enabled = False
        Else
            checkRubroCuenta.Enabled = True
            checkMonedaTasa.Enabled = True
        End If
    End Sub

    Private Sub checkRubroCuenta_CheckedChanged(sender As Object, e As EventArgs) Handles checkRubroCuenta.CheckedChanged
        If checkRubroCuenta.Checked = True Then
            'checkSinFechaArribo.Enabled = False
        Else
            checkSinFechaArribo.Enabled = True
        End If
    End Sub

    Private Sub checkMonedaTasa_CheckedChanged(sender As Object, e As EventArgs) Handles checkMonedaTasa.CheckedChanged
        If checkMonedaTasa.Checked = True Then
            checkSinFechaArribo.Enabled = False
        Else
            checkSinFechaArribo.Enabled = True
        End If
    End Sub

End Class