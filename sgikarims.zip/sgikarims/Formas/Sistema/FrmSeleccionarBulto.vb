﻿
Public Class FrmSeleccionarBulto
#Region "Variables"
    Dim intLinea As Integer = NO_FILA
    Dim intNumero As Integer = NO_FILA
    Dim intAno As Integer = NO_FILA
#End Region

#Region "Propiedades"
    Public Property DataGrid As DataGridView
        Set(value As DataGridView)
            dgLista = value
        End Set
        Get
            Return dgLista
        End Get
    End Property

    Public Property DataGridIn As DataGridView
        Set(value As DataGridView)
            dgBultosYaDescargados = value
        End Set
        Get
            Return dgBultosYaDescargados
        End Get
    End Property

    Public Property Numero As String
        Get
            Return intNumero
        End Get
        Set(value As String)
            intNumero = value
        End Set
    End Property

    Public Property Anio As String
        Get
            Return intAno
        End Get
        Set(value As String)
            intAno = value
        End Set
    End Property

    Public Property Linea As String
        Get
            Return intLinea
        End Get
        Set(value As String)
            intLinea = value
        End Set
    End Property
#End Region

#Region "Funciones y Procedimientos "
    Private Function sqlCategoria(ByVal intCategoria As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT cmd.DCat_CodigoProd Codigo , cmd.DCat_NombreProd Descripcion  "
        strSQL &= "        FROM CategoriaMercadeo_DTL cmd "
        strSQL &= "             WHERE cmd.DCat_Empresa = {empresa} AND cmd.DCat_IdCategoria = {categoria}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{categoria}", intCategoria)
        Return strSQL
    End Function
    Public Sub CargarCategoria(ByVal Categoria As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim check As New DataGridViewCheckBoxCell
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = sqlCategoria(Categoria)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        dgLista.Rows.Clear()
        If REA.HasRows Then
            Do While REA.Read
                Fila = New DataGridViewRow
                check = New DataGridViewCheckBoxCell
                check.Value = False
                check.ReadOnly = False
                Fila.Cells.Add(check)

                Celda = New DataGridViewTextBoxCell
                Celda.Value = REA.GetInt32("Codigo")
                Fila.Cells.Add(Celda)

                Celda = New DataGridViewTextBoxCell
                Celda.Value = REA.GetString("Descripcion")
                Fila.Cells.Add(Celda)
                dgLista.Rows.Add(Fila)
            Loop
        End If

    End Sub
    Private Function SQLBultos() As String
        Dim strSQl As String = STR_VACIO

        strSQl = " SELECT l1.Numero Numero, l1.Linea Linea, l1.Bulto Bulto, l1.Marca Marca, l1.Categoria Categoria, l1.peso peso, l1.catalogo catalogo, l1.anio anio, l1.ChiCat ChiCat, l1.LinBulto lineaBulto  "
        strSQl &= "  FROM ( "
        strSQl &= "         SELECT d.BDoc_Doc_Num Numero, d.BDoc_Doc_Lin Linea, d.BDoc_Box_Lin Bulto, d.BDoc_Box_Cod Marca, d.BDoc_Box_Ctg Categoria, d.BDoc_Box_LB peso, d.BDoc_Doc_Cat catalogo, d.BDoc_Doc_Ano anio, IFNULL(p.BPDoc_Chi_Cat, '') ChiCat, IFNULL(p.BPDoc_Chi_Ano, '') ChiAno, IFNULL(p.BPDoc_Chi_Num, '') ChiNum, IFNULL(p.BPDoc_Chi_Lin,'') ChiLin, d.BDoc_Box_Ord LinBulto "
        strSQl &= "             FROM Dcmtos_DTL_Box d "
        strSQl &= "             LEFT JOIN Dcmtos_DTL_Box_Pro p ON p.BPDoc_Sis_Emp = d.BDoc_Sis_Emp AND p.BPDoc_Par_Cat = d.BDoc_Doc_Cat AND p.BPDoc_Par_Ano = d.BDoc_Doc_Ano AND p.BPDoc_Par_Num = d.BDoc_Doc_Num AND p.BPDoc_Par_Lin = d.BDoc_Doc_Lin AND p.BPDoc_Box_Lin = d.BDoc_Box_lin "
        strSQl &= "         WHERE d.BDoc_Sis_Emp = {empresa} AND d.BDoc_Doc_Cat = 47 AND d.BDoc_Doc_Ano = {ano} AND d.BDoc_Doc_Num = {numero} and d.BDoc_Doc_Lin = {linea} AND p.BPDoc_Par_Num IS NULL "
        strSQl &= "         ORDER BY d.BDoc_Doc_Num, d.BDoc_Doc_Lin, d.BDoc_Box_Lin)l1 "

        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{ano}", intAno)
        strSQl = Replace(strSQl, "{numero}", intNumero)
        strSQl = Replace(strSQl, "{linea}", intLinea)


        Return strSQl
    End Function

    Private Sub CargarLista()
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim check As New DataGridViewCheckBoxCell
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSql As String = STR_VACIO

        Try

            strSql = SQLBultos()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read


                    Fila = New DataGridViewRow
                    check = New DataGridViewCheckBoxCell
                    check.Value = False
                    check.ReadOnly = False
                    Fila.Cells.Add(check)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("Numero")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("Linea")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("Bulto")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("Marca")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("Categoria")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("peso")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("catalogo")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString("anio")
                    Fila.Cells.Add(Celda)

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetDouble("lineaBulto")
                    Fila.Cells.Add(Celda)


                    dgLista.Rows.Add(Fila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SeleccionarTodo()
        celdaPeso.Text = 0
        For i As Integer = 0 To dgLista.Rows.Count - 1
            dgLista.Rows(i).Cells("colCheck").Value = True
            ' celdaPeso.Text = ((CDbl(celdaPeso.Text) + CDbl(dgLista.Rows(i).Cells("colPeso").Value))).ToString(FORMATO_MONEDA)
        Next
    End Sub

    Private Sub NoSeleccionar()
        For i As Integer = 0 To dgLista.Rows.Count - 1
            dgLista.Rows(i).Cells("colCheck").Value = False

        Next
        celdaPeso.Text = 0
    End Sub

#End Region

#Region "Eventos"
    Private Sub FrmSeleccionarBulto_Load(sender As Object, e As EventArgs) Handles Me.Load
        'CargarLista()
        CargarCategoria(intNumero)
    End Sub

    Private Sub botonCanccelar_Click(sender As Object, e As EventArgs) Handles botonCanccelar.Click
        DataGrid = dgLista
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        If dgLista.CurrentRow.Cells("colCheck").Value = True Then
            dgLista.CurrentRow.Cells("colCheck").Value = False
            ' celdaPeso.Text = ((CDbl(celdaPeso.Text) - CDbl(dgLista.CurrentRow.Cells("colPeso").Value))).ToString(FORMATO_MONEDA)
        Else
            dgLista.CurrentRow.Cells("colCheck").Value = True
            'celdaPeso.Text = ((CDbl(celdaPeso.Text) + CDbl(dgLista.CurrentRow.Cells("colPeso").Value))).ToString(FORMATO_MONEDA)
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.Space Then
                If dgLista.CurrentRow.Cells("colCheck").Value = True Then
                    dgLista.CurrentRow.Cells("colCheck").Value = False
                    '   celdaPeso.Text = ((CDbl(celdaPeso.Text) - CDbl(dgLista.CurrentRow.Cells("colPeso").Value))).ToString(FORMATO_MONEDA)
                Else
                    dgLista.CurrentRow.Cells("colCheck").Value = True
                    '  celdaPeso.Text = ((CDbl(celdaPeso.Text) + CDbl(dgLista.CurrentRow.Cells("colPeso").Value))).ToString(FORMATO_MONEDA)
                End If
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub
#End Region

    Private Sub checkTodo_CheckedChanged(sender As Object, e As EventArgs) Handles checkTodo.CheckedChanged
        If checkTodo.Checked = True Then
            SeleccionarTodo()
        Else
            NoSeleccionar()
        End If
    End Sub

    Private Sub botonCategoria_Click(sender As Object, e As EventArgs) Handles botonCategoria.Click
        Dim frm As New frmSeleccionar
        frm.Titulo = "Select "
        frm.FiltroText = " Filter by Category "
        frm.Filtro = " cm.Cat_NombreCategoria "

        frm.Campos = " cm.Cat_IdCategoria Codigo , cm.Cat_NombreCategoria Categoria  "
        frm.Tabla = " CategoriaMercadeo_HDR cm "
        frm.Condicion = " cm.Cat_Empresa = " & Sesion.IdEmpresa & " "
        frm.Limite = 20
        frm.ShowDialog(Me)
        If frm.DialogResult = DialogResult.OK Then
            celdaidCategoria.Text = frm.LLave
            celdaCategoria.Text = frm.Dato
        End If
        CargarCategoria(celdaidCategoria.Text)
    End Sub
End Class