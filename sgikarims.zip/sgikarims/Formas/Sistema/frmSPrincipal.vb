﻿
Public Class frmSPrincipal

    Dim cPrincipal As New clsPrincipal

#Region "Funciones y Procedimientos Locales"

    Private Sub CargarMenu()
        Dim strSQL As String = STR_VACIO
        Dim nde As TreeNode
        Dim REA As MySqlDataReader
        Dim intGrupo As Integer = NO_FILA
        Dim logEstado As Boolean = False
        Dim COM As MySqlCommand
        Opciones.Nodes.Clear()
        strSQL = cPrincipal.SQLProgramas
        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader()
                If REA.HasRows = False Then
                    Exit Sub
                End If
                Do While REA.Read
                    If intGrupo <> REA.GetInt32("Grupo") Then
                        intGrupo = REA.GetInt32("Grupo")
                        nde = Opciones.Nodes.Add(REA.GetString("Titulo"))
                    End If
                    nde.Nodes.Add(REA.GetString("Objeto"), REA.GetString("Descripcion"))
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

    Private Sub frmSPrincipal_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Dim cSesion As New clsSesion
        cSesion.EscribirSesion(False)
        End
    End Sub

    Private Sub FrmSPrincipal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim NombreControl As String = "Panel"
        Dim PanelControl As String = "frmPanelControl"
        CargarMenu()

        Me.Text = "SGI/" & Sesion.Empresa
        textoUsuario.Text = Sesion.Usuario & "@" & strModo
        textoVersion.Text = Sistema.Version
        textoEmpresa.Text = Sesion.Empresa
        celdaEmpresa.Text = Sesion.Empresa
        celdaNombre.Text = Sesion.Usuario
        CuadroLogo.Image = ImageList1.Images(Sesion.IdEmpresa.ToString)
        CuadroLogo.SizeMode = PictureBoxSizeMode.StretchImage
        cPrincipal.ComprobarTasaGt()
        If cPrincipal.MostrarFormulario(PanelControl, Me) = True Then
            BarraDeTareas1.AgregarFormulario(PanelControl, NombreControl)
        End If
    End Sub

    Private Sub Opciones_DoubleClick(sender As Object, e As EventArgs) Handles Opciones.DoubleClick
        Dim nde As TreeNode
        Dim strForm As String = STR_VACIO
        'If Opciones.SelectedNode Then Exit Sub
        Try
            If Sesion.FechaSesion = Today Then
                nde = Opciones.SelectedNode
                strForm = nde.Name.ToString
                If cPrincipal.MostrarFormulario(strForm, Me) = True Then
                    BarraDeTareas1.AgregarFormulario(strForm, nde.Text)
                End If
            Else
                MsgBox(" Your session has expired. Please log in again.")
                End
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BarraDeTareas1_SelecionarPestaña(sender As Object, click As Boolean) Handles BarraDeTareas1.SelecionarPestaña
        Dim strForm As String = STR_VACIO
        strForm = BarraDeTareas1.TabControl1.TabPages(BarraDeTareas1.TabControl1.SelectedIndex).Name
        cPrincipal.MostrarFormulario(strForm, Me, True)
    End Sub

    Private Sub Opciones_KeyDown(sender As Object, e As KeyEventArgs) Handles Opciones.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then

                Dim nde As TreeNode
                Dim strForm As String = STR_VACIO
                'If Opciones.SelectedNode Then Exit Sub
                Try
                    If Sesion.FechaSesion = Today Then
                        nde = Opciones.SelectedNode
                        strForm = nde.Name.ToString
                        If cPrincipal.MostrarFormulario(strForm, Me) = True Then
                            BarraDeTareas1.AgregarFormulario(strForm, nde.Text)
                        End If
                    Else
                        MsgBox(" Your session has expired. Please log in again.")
                        End
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub celdaEmpresa_Click(sender As Object, e As EventArgs) Handles celdaEmpresa.Click
        Me.CargarMenu()
    End Sub
End Class
