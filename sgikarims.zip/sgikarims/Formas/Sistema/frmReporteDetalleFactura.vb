﻿Public Class frmReporteDetalleFactura
    Private WithEvents Check_Box As System.Windows.Forms.CheckBox
#Region "Variables"
    Dim IntCliente As Integer
    Dim dtFechaInicio As Date
    Dim dtFechaFin As Date
    Dim LogProducto As Boolean
    Dim LogCostos As Boolean
    Dim LogPedido As Boolean
    Dim LogRango As Boolean
    Dim IntSeleccion As Integer

    Dim strClase As String
    Dim strDescripcion As String
    Dim strCodigo As Integer
    Dim strIDC As Integer



#End Region

#Region "Propiedades"
    Public ReadOnly Property Cod_Cliente As Integer
        Get
            Return IntCliente
        End Get
    End Property
    Public ReadOnly Property Rango As Boolean
        Get
            Return LogRango
        End Get
    End Property
    Public ReadOnly Property SeleccionFechaInicio As Date
        Get
            Return dtFechaInicio
        End Get
    End Property
    Public ReadOnly Property SeleccionFechaFin As Date
        Get
            Return dtFechaFin
        End Get
    End Property
    Public ReadOnly Property Pos_FiltroProducto As Boolean
        Get
            Return LogProducto
        End Get
    End Property
    Public ReadOnly Property Pos_Costos As Boolean
        Get
            Return LogCostos
        End Get
    End Property
    Public ReadOnly Property Pos_Pedido As Boolean
        Get
            Return LogPedido
        End Get
    End Property
    Public Property Clase_ As String
        Get
            Return strClase
        End Get
        Set(value As String)
            strClase = value
        End Set
    End Property
    Public Property Codigo As Integer
        Get
            Return strCodigo
        End Get
        Set(value As Integer)
            strCodigo = value
        End Set
    End Property
    Public Property Descripcion As String
        Get
            Return strDescripcion
        End Get
        Set(value As String)
            strDescripcion = value
        End Set
    End Property
    Public Property IDC As Integer
        Get
            Return strIDC
        End Get
        Set(value As Integer)
            strIDC = value
        End Set
    End Property
    Public ReadOnly Property Seleccion_Clase1 As String
        Get
            Return strClase
        End Get
    End Property


    Public ReadOnly Property Seleccion_IDC As Integer
        Get
            Return strIDC
        End Get
    End Property
    Public ReadOnly Property seleccion_Descripcion As String
        Get
            Return strDescripcion
        End Get
    End Property
    Public ReadOnly Property Seleccion_Codigo As Integer
        Get
            Return strCodigo
        End Get
    End Property



#End Region

    Private Sub botonFabricante_Click(sender As Object, e As EventArgs) Handles botonFabricante.Click
        Dim frm As New frmSeleccionar
        'Propiedades de Consulta
        frm.Campos = "cli_codigo Code, cli_cliente Client"
        frm.Tabla = " Clientes"
        frm.Condicion = " cli_sisemp= " & Sesion.IdEmpresa & ""
        frm.Filtro = "cli_cliente"
        frm.Limite = "20"
        'Propiedades del Formulario 
        frm.Titulo = "Customers"
        frm.FiltroText = " Enter the Customer Name to filter"
        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
        End If

    End Sub

    Private Sub botonContinuar_Click(sender As Object, e As EventArgs) Handles botonContinuar.Click
        Dim frm As New frmSeleccionar
        Dim DetalleFact As New clsReportes
        Try

            IntCliente = (celdaIdCliente.Text)


            dtFechaInicio = dtpFechaInicio.Value
            dtFechaFin = dtpFechaFin.Value




            If checkFiltrarClase.Checked = True Then
                'LogProducto = True
                'Propiedades de Consulta
                frm.Campos = "c.cat_num IDC, c.cat_desc Class, a.art_DCorta Description, a.art_codigo Code"
                frm.Tabla = " Articulos a INNER JOIN Catalogos c ON c.cat_clase='ClaseArt' AND c.cat_num= a.art_clase"
                frm.Condicion = " a.art_sisemp= " & Sesion.IdEmpresa & ""
                frm.Agrupar = " Class , Description , Code"
                frm.Filtro = "a.art_DCorta"
                frm.Limite = "20"
                'Propiedades del Formulario 
                frm.Titulo = "Article"
                frm.FiltroText = " Enter Item Name to filter"
                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    LogProducto = True
                    strIDC = frm.LLave
                    strClase = frm.Dato
                    strDescripcion = frm.Dato2
                    strCodigo = frm.Dato3
                Else
                    LogProducto = False
                End If
            ElseIf checkTodaClase.Checked = True Then
                'Propiedades de consulta '
                frm.Campos = "c.cat_num IDC, c.cat_clave Class, c.cat_desc Description "
                frm.Tabla = "Catalogos c"
                frm.Condicion = "c.cat_clase='ClaseArt' ORDER BY c.cat_desc"
                frm.Limite = "20"
                'Propiedades del Formulario'
                frm.Titulo = " Filter All Class"
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    LogProducto = True
                    strIDC = frm.LLave
                    strDescripcion = frm.Dato
                    strClase = frm.Dato2
                Else
                    LogProducto = False
                End If
            ElseIf checkBoxProveedor.Checked = True Then
                'Propiedades de consulta '
                frm.Campos = "p.pro_codigo codigo, p.pro_proveedor Proveedor "
                frm.Tabla = "Proveedores p"
                frm.Condicion = "p.pro_fabricante = 'Si'"
                frm.Filtro = "p.pro_proveedor"
                frm.Limite = "20"
                'Propiedades del Formulario'
                frm.Titulo = " Filter All Class"
                frm.FiltroText = " Enter Item Name to filter"
                frm.Agrupar = "Proveedor, codigo"
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    LogProducto = True
                    strIDC = frm.LLave
                    strDescripcion = frm.Dato
                Else
                    LogProducto = False
                End If
            End If




            'If checkFiltrarClase.Checked = True Then
            '    LogProducto = True
            '    frm.Campos = " c.cat_num IDC, c.cat_clave Clase, c.cat_desc Descripcion "
            '    frm.Tabla = " Catalogos c "
            '    frm.Condicion = " c.cat_clase='ClaseArt' ORDER BY c.cat_desc"
            '    frm.Limite = " 20 "
            '    'Propiedades del Formulario 
            '    frm.Titulo = "Catalogos"
            '    frm.FiltroText = "Ingrese el Nombre de Catalogo para filtrar"
            '    frm.ShowDialog(Me)
            '    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '        strIDC = frm.LLave
            '        strClase = frm.Dato
            '        strDescripcion = frm.Dato2
            '        strCodigo = frm.Dato3
            '    End If
            '    LogProducto = False
            'End If


            If checkMostrarCostos.Checked Then
                LogCostos = True
            Else
                LogCostos = False
            End If

            If checkPrecioPedido.Checked Then
                LogPedido = True
            Else
                LogPedido = False
            End If

            Me.DialogResult = DialogResult.OK



        Catch ex As Exception
            MsgBox(e.ToString)
        End Try
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class