﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFiltroInventarioCorp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.PanelBotom = New System.Windows.Forms.Panel()
        Me.grupoEstado = New System.Windows.Forms.GroupBox()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.botonEstado = New System.Windows.Forms.Button()
        Me.checkEstado = New System.Windows.Forms.CheckBox()
        Me.grupoHilo = New System.Windows.Forms.GroupBox()
        Me.celdaHilo = New System.Windows.Forms.TextBox()
        Me.botonHilo = New System.Windows.Forms.Button()
        Me.checkYarn = New System.Windows.Forms.CheckBox()
        Me.grupoCantidad = New System.Windows.Forms.GroupBox()
        Me.celdaSaldoFinal = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaSaldoInicial = New System.Windows.Forms.TextBox()
        Me.checkSaldo = New System.Windows.Forms.CheckBox()
        Me.PanelBotom.SuspendLayout()
        Me.grupoEstado.SuspendLayout()
        Me.grupoHilo.SuspendLayout()
        Me.grupoCantidad.SuspendLayout()
        Me.SuspendLayout()
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonCancelar.Location = New System.Drawing.Point(167, 21)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(102, 67)
        Me.botonCancelar.TabIndex = 3
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(306, 21)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(102, 67)
        Me.botonAceptar.TabIndex = 2
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'PanelBotom
        '
        Me.PanelBotom.Controls.Add(Me.botonAceptar)
        Me.PanelBotom.Controls.Add(Me.botonCancelar)
        Me.PanelBotom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBotom.Location = New System.Drawing.Point(0, 272)
        Me.PanelBotom.Name = "PanelBotom"
        Me.PanelBotom.Size = New System.Drawing.Size(430, 100)
        Me.PanelBotom.TabIndex = 4
        '
        'grupoEstado
        '
        Me.grupoEstado.Controls.Add(Me.celdaEstado)
        Me.grupoEstado.Controls.Add(Me.botonEstado)
        Me.grupoEstado.Controls.Add(Me.checkEstado)
        Me.grupoEstado.Dock = System.Windows.Forms.DockStyle.Top
        Me.grupoEstado.Location = New System.Drawing.Point(0, 0)
        Me.grupoEstado.Name = "grupoEstado"
        Me.grupoEstado.Size = New System.Drawing.Size(430, 78)
        Me.grupoEstado.TabIndex = 5
        Me.grupoEstado.TabStop = False
        Me.grupoEstado.Text = "Status"
        '
        'celdaEstado
        '
        Me.celdaEstado.Location = New System.Drawing.Point(129, 26)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.ReadOnly = True
        Me.celdaEstado.Size = New System.Drawing.Size(184, 22)
        Me.celdaEstado.TabIndex = 2
        Me.celdaEstado.Text = "ALL"
        '
        'botonEstado
        '
        Me.botonEstado.Enabled = False
        Me.botonEstado.Location = New System.Drawing.Point(333, 25)
        Me.botonEstado.Name = "botonEstado"
        Me.botonEstado.Size = New System.Drawing.Size(38, 23)
        Me.botonEstado.TabIndex = 1
        Me.botonEstado.Text = "..."
        Me.botonEstado.UseVisualStyleBackColor = True
        '
        'checkEstado
        '
        Me.checkEstado.AutoSize = True
        Me.checkEstado.Location = New System.Drawing.Point(12, 21)
        Me.checkEstado.Name = "checkEstado"
        Me.checkEstado.Size = New System.Drawing.Size(66, 21)
        Me.checkEstado.TabIndex = 0
        Me.checkEstado.Text = "Satus"
        Me.checkEstado.UseVisualStyleBackColor = True
        '
        'grupoHilo
        '
        Me.grupoHilo.Controls.Add(Me.celdaHilo)
        Me.grupoHilo.Controls.Add(Me.botonHilo)
        Me.grupoHilo.Controls.Add(Me.checkYarn)
        Me.grupoHilo.Dock = System.Windows.Forms.DockStyle.Top
        Me.grupoHilo.Location = New System.Drawing.Point(0, 78)
        Me.grupoHilo.Name = "grupoHilo"
        Me.grupoHilo.Size = New System.Drawing.Size(430, 71)
        Me.grupoHilo.TabIndex = 7
        Me.grupoHilo.TabStop = False
        Me.grupoHilo.Text = "Yarn Count"
        '
        'celdaHilo
        '
        Me.celdaHilo.Location = New System.Drawing.Point(129, 30)
        Me.celdaHilo.Name = "celdaHilo"
        Me.celdaHilo.ReadOnly = True
        Me.celdaHilo.Size = New System.Drawing.Size(184, 22)
        Me.celdaHilo.TabIndex = 4
        Me.celdaHilo.Text = "ALL"
        '
        'botonHilo
        '
        Me.botonHilo.Enabled = False
        Me.botonHilo.Location = New System.Drawing.Point(333, 29)
        Me.botonHilo.Name = "botonHilo"
        Me.botonHilo.Size = New System.Drawing.Size(38, 23)
        Me.botonHilo.TabIndex = 3
        Me.botonHilo.Text = "..."
        Me.botonHilo.UseVisualStyleBackColor = True
        '
        'checkYarn
        '
        Me.checkYarn.AutoSize = True
        Me.checkYarn.Location = New System.Drawing.Point(12, 21)
        Me.checkYarn.Name = "checkYarn"
        Me.checkYarn.Size = New System.Drawing.Size(99, 21)
        Me.checkYarn.TabIndex = 0
        Me.checkYarn.Text = "Yarn count"
        Me.checkYarn.UseVisualStyleBackColor = True
        '
        'grupoCantidad
        '
        Me.grupoCantidad.Controls.Add(Me.celdaSaldoFinal)
        Me.grupoCantidad.Controls.Add(Me.Label2)
        Me.grupoCantidad.Controls.Add(Me.Label1)
        Me.grupoCantidad.Controls.Add(Me.celdaSaldoInicial)
        Me.grupoCantidad.Controls.Add(Me.checkSaldo)
        Me.grupoCantidad.Dock = System.Windows.Forms.DockStyle.Top
        Me.grupoCantidad.Location = New System.Drawing.Point(0, 149)
        Me.grupoCantidad.Name = "grupoCantidad"
        Me.grupoCantidad.Size = New System.Drawing.Size(430, 100)
        Me.grupoCantidad.TabIndex = 8
        Me.grupoCantidad.TabStop = False
        Me.grupoCantidad.Text = "Balance"
        '
        'celdaSaldoFinal
        '
        Me.celdaSaldoFinal.Location = New System.Drawing.Point(273, 42)
        Me.celdaSaldoFinal.Name = "celdaSaldoFinal"
        Me.celdaSaldoFinal.ReadOnly = True
        Me.celdaSaldoFinal.Size = New System.Drawing.Size(100, 22)
        Me.celdaSaldoFinal.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(61, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Between"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(235, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "and"
        '
        'celdaSaldoInicial
        '
        Me.celdaSaldoInicial.Location = New System.Drawing.Point(129, 42)
        Me.celdaSaldoInicial.Name = "celdaSaldoInicial"
        Me.celdaSaldoInicial.ReadOnly = True
        Me.celdaSaldoInicial.Size = New System.Drawing.Size(100, 22)
        Me.celdaSaldoInicial.TabIndex = 1
        Me.celdaSaldoInicial.Text = "1"
        '
        'checkSaldo
        '
        Me.checkSaldo.AutoSize = True
        Me.checkSaldo.Location = New System.Drawing.Point(12, 21)
        Me.checkSaldo.Name = "checkSaldo"
        Me.checkSaldo.Size = New System.Drawing.Size(81, 21)
        Me.checkSaldo.TabIndex = 0
        Me.checkSaldo.Text = "Balance"
        Me.checkSaldo.UseVisualStyleBackColor = True
        '
        'frmFiltroInventarioCorp
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(430, 372)
        Me.Controls.Add(Me.grupoCantidad)
        Me.Controls.Add(Me.grupoHilo)
        Me.Controls.Add(Me.grupoEstado)
        Me.Controls.Add(Me.PanelBotom)
        Me.Name = "frmFiltroInventarioCorp"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Filter Out"
        Me.PanelBotom.ResumeLayout(False)
        Me.grupoEstado.ResumeLayout(False)
        Me.grupoEstado.PerformLayout()
        Me.grupoHilo.ResumeLayout(False)
        Me.grupoHilo.PerformLayout()
        Me.grupoCantidad.ResumeLayout(False)
        Me.grupoCantidad.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents PanelBotom As Panel
    Friend WithEvents grupoEstado As GroupBox
    Friend WithEvents celdaEstado As TextBox
    Friend WithEvents botonEstado As Button
    Friend WithEvents checkEstado As System.Windows.Forms.CheckBox
    Friend WithEvents grupoHilo As GroupBox
    Friend WithEvents celdaHilo As TextBox
    Friend WithEvents botonHilo As Button
    Friend WithEvents checkYarn As System.Windows.Forms.CheckBox
    Friend WithEvents grupoCantidad As GroupBox
    Friend WithEvents celdaSaldoFinal As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaSaldoInicial As TextBox
    Friend WithEvents checkSaldo As System.Windows.Forms.CheckBox
End Class
