﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSeleccionar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonCrear = New System.Windows.Forms.Button()
        Me.etiquetaFiltro = New System.Windows.Forms.Label()
        Me.celdaFiltro = New System.Windows.Forms.TextBox()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.botonSeleccionar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.ListaClientes = New System.Windows.Forms.DataGridView()
        Me.Progress = New System.Windows.Forms.ProgressBar()
        Me.Panel1.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ListaClientes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonCrear)
        Me.Panel1.Controls.Add(Me.etiquetaFiltro)
        Me.Panel1.Controls.Add(Me.celdaFiltro)
        Me.Panel1.Controls.Add(Me.botonBuscar)
        Me.Panel1.Controls.Add(Me.botonSeleccionar)
        Me.Panel1.Controls.Add(Me.botonCancelar)
        Me.Panel1.Controls.Add(Me.CuadroLogo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(834, 113)
        Me.Panel1.TabIndex = 0
        '
        'botonCrear
        '
        Me.botonCrear.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonCrear.Location = New System.Drawing.Point(168, 12)
        Me.botonCrear.Name = "botonCrear"
        Me.botonCrear.Size = New System.Drawing.Size(75, 45)
        Me.botonCrear.TabIndex = 6
        Me.botonCrear.Text = "C&reate"
        Me.botonCrear.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCrear.UseVisualStyleBackColor = True
        '
        'etiquetaFiltro
        '
        Me.etiquetaFiltro.AutoSize = True
        Me.etiquetaFiltro.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaFiltro.Location = New System.Drawing.Point(21, 62)
        Me.etiquetaFiltro.Name = "etiquetaFiltro"
        Me.etiquetaFiltro.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaFiltro.TabIndex = 5
        Me.etiquetaFiltro.Text = "Label1"
        '
        'celdaFiltro
        '
        Me.celdaFiltro.Location = New System.Drawing.Point(12, 78)
        Me.celdaFiltro.Name = "celdaFiltro"
        Me.celdaFiltro.Size = New System.Drawing.Size(437, 20)
        Me.celdaFiltro.TabIndex = 1
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.zoom
        Me.botonBuscar.Location = New System.Drawing.Point(12, 11)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(72, 45)
        Me.botonBuscar.TabIndex = 2
        Me.botonBuscar.Text = "&Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'botonSeleccionar
        '
        Me.botonSeleccionar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonSeleccionar.Location = New System.Drawing.Point(90, 12)
        Me.botonSeleccionar.Name = "botonSeleccionar"
        Me.botonSeleccionar.Size = New System.Drawing.Size(72, 45)
        Me.botonSeleccionar.TabIndex = 3
        Me.botonSeleccionar.Text = "&Select"
        Me.botonSeleccionar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonSeleccionar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(377, 11)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(72, 45)
        Me.botonCancelar.TabIndex = 4
        Me.botonCancelar.Text = "&Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroLogo.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CuadroLogo.Image = Global.KARIMs_SGI.My.Resources.Resources.logokarims
        Me.CuadroLogo.Location = New System.Drawing.Point(723, 12)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(99, 78)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CuadroLogo.TabIndex = 2
        Me.CuadroLogo.TabStop = False
        '
        'ListaClientes
        '
        Me.ListaClientes.AllowUserToAddRows = False
        Me.ListaClientes.AllowUserToDeleteRows = False
        Me.ListaClientes.AllowUserToOrderColumns = True
        Me.ListaClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ListaClientes.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaClientes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ListaClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaClientes.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListaClientes.Location = New System.Drawing.Point(0, 113)
        Me.ListaClientes.MultiSelect = False
        Me.ListaClientes.Name = "ListaClientes"
        Me.ListaClientes.ReadOnly = True
        Me.ListaClientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaClientes.Size = New System.Drawing.Size(834, 231)
        Me.ListaClientes.TabIndex = 1
        '
        'Progress
        '
        Me.Progress.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Progress.Location = New System.Drawing.Point(0, 344)
        Me.Progress.Name = "Progress"
        Me.Progress.Size = New System.Drawing.Size(834, 6)
        Me.Progress.TabIndex = 2
        '
        'frmSeleccionar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(834, 350)
        Me.ControlBox = False
        Me.Controls.Add(Me.ListaClientes)
        Me.Controls.Add(Me.Progress)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmSeleccionar"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ListaClientes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ListaClientes As System.Windows.Forms.DataGridView
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents celdaFiltro As System.Windows.Forms.TextBox
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents botonSeleccionar As System.Windows.Forms.Button
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents etiquetaFiltro As System.Windows.Forms.Label
    Friend WithEvents botonCrear As System.Windows.Forms.Button
    Friend WithEvents Progress As ProgressBar
End Class
