﻿Public Class frmAutorización

#Region "Miembros"

    Private intID As Integer
    Private intModulo As Integer
    Private intItem As Integer
    Private intNivel As Integer

    Private logAceptar As Boolean

    Dim strKey As String = STR_VACIO
    Private strClase As String
    Private strUsuario As String
    Private strClave As String

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property Nivel As Integer
        Get
            Return intNivel
        End Get
        Set(value As Integer)
            intNivel = value
        End Set
    End Property

    Public Property Aceptado As Boolean
        Get
            Return logAceptar
        End Get
        Set(value As Boolean)
            logAceptar = value
        End Set
    End Property

    Public Property ID As Integer
        Get
            Return intID
        End Get
        Set(value As Integer)
            intID = value
        End Set
    End Property

    Public Property Usuario As String
        Get
            Return strUsuario
        End Get
        Set(value As String)
            strUsuario = value
        End Set
    End Property

    Public Property Clave As String
        Get
            Return strClave
        End Get
        Set(value As String)
            strClave = value
        End Set
    End Property

    Public Property Clase As String
        Get
            Return strClase
        End Get
        Set(value As String)
            strClase = value
        End Set
    End Property

#End Region

    Public Sub Iniciar(ByVal Modulo As Integer, ByVal Clase As String, Optional Item As Integer = vbEmpty, Optional Titulo As String = "Datos de autorización")

        intModulo = Modulo
        intItem = Item
        strClase = Clase

        botonContinuar.Enabled = True


    End Sub

    Private Sub botonContinuar_Click(sender As Object, e As EventArgs) Handles botonContinuar.Click
        Dim strSQL As String
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader

        If celdaUsuario.Text = vbNullString Then
            MsgBox("No se ha ingresado el usuario", vbExclamation, "Aviso")
        ElseIf celdaContraseña.Text = vbNullString Then
            MsgBox("No se ha ingresado la contraseña", vbExclamation, "Aviso")
        Else
            strSQL = "SELECT per_codigo"
            strSQL &= "  FROM Personal"
            strSQL &= "     WHERE per_sisemp={empresa} AND per_usuario='{usuario}'"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{usuario}", celdaUsuario.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intID = COM.ExecuteScalar

            If intID = vbEmpty Then
                MsgBox("Usuario no válido", vbExclamation, "Aviso")
            Else
                strSQL = "SELECT per_usuario"
                strSQL &= "  FROM Personal"
                strSQL &= "     WHERE per_sisemp={empresa} AND per_codigo='{ID}' AND per_clave=MD5('{Pass}') "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{ID}", intID)
                strSQL = Replace(strSQL, "{Pass}", celdaContraseña.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                strSQL = COM.ExecuteScalar

                If strSQL = vbNullString Then
                    MsgBox("Contraseña no válida", vbExclamation, "Aviso")
                Else
                    strSQL = "SELECT pms_codigo Clase, pms_nivel Nivel"
                    strSQL &= "  FROM Permisos"
                    strSQL &= "      WHERE pms_empresa={empresa} AND pms_modulo='{Modulo}' AND pms_usuario='{Usuario}' AND {criterio} LIMIT 1"
                    If intItem = vbEmpty Then
                        strSQL = Replace(strSQL, "{criterio}", "pms_codigo=" & "'" & strClase & "'")
                    Else
                        strSQL = Replace(strSQL, "{criterio}", "pms_id=" & intItem)
                    End If
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{Modulo}", intModulo)
                    strSQL = Replace(strSQL, "{Usuario}", celdaUsuario.Text)

                    MyCnn.CONECTAR = strConexion


                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.Read Then
                        intNivel = REA.GetInt32("Nivel")
                        If Not (intItem = vbEmpty) Then
                            strClase = REA.GetString("Clase")
                        End If
                        strUsuario = celdaUsuario.Text
                        strClave = celdaContraseña.Text

                        logAceptar = True
                        Me.DialogResult = System.Windows.Forms.DialogResult.OK
                    Else
                        MsgBox("Usuario no autorizado para realizar esta acción", vbExclamation, "Aviso")
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        logAceptar = False
        Me.Close()
    End Sub

    Private Sub celdaUsuario_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaUsuario.KeyDown
        If e.KeyCode = Keys.Enter Then
            celdaContraseña.Focus()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub celdaContraseña_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaContraseña.KeyDown
        If e.KeyCode = Keys.Enter Then
            botonContinuar.Focus()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

End Class