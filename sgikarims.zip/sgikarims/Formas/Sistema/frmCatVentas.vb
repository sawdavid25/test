﻿Public Class frmCatVentas

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim sCat As String
    Dim sSel As String
    Dim sWhr As String
    Dim sOrd As String

    Public Fabricas As Boolean
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region


    Private Sub SelectCAT(Catalogo As String)

        Select Case Catalogo
            Case "Ventas"
                sSel = " SELECT cli_codigo, cli_cliente, cli_status FROM Clientes "
                sWhr = " WHERE cli_sisemp = {empresa} AND cli_cliente "
                sOrd = " ORDER BY cli_codigo "

                sWhr = Replace(sWhr, "{empresa}", Sesion.IdEmpresa)

            Case "Compras"
                sSel = " SELECT pro_codigo, pro_proveedor, pro_status FROM Proveedores "
                sWhr = " WHERE pro_sisemp = {empresa} IIf(Fabricas, AND pro_fabricante='Si', vbNullString) &  AND pro_proveedor "
                sOrd = " ORDER BY pro_codigo "

                sWhr = Replace(sWhr, "{empresa}", Sesion.IdEmpresa)

            Case "Empresas"
                sSel = vbNullString
                sSel = sSel & "            (SELECT                                      "
                sSel = sSel & "                concat('C', Right(concat('00000',        "
                sSel = sSel & "                CAST(cli_codigo AS CHAR)),5)) as Codigo, "
                sSel = sSel & "                cli_cliente as Nombre,                   "
                sSel = sSel & "                cli_status As Estado,                    "
                sSel = sSel & "                cli_sisemp as Sisemp                     "
                sSel = sSel & "            FROM Clientes                                "
                sSel = sSel & "            WHERE cli_sisemp = {empresa})             "
                sSel = sSel & "            UNION                                        "
                sSel = sSel & "            (SELECT                                      "
                sSel = sSel & "                concat('P', Right(concat('00000',        "
                sSel = sSel & "                CAST(pro_codigo AS CHAR)),5)),           "
                sSel = sSel & "                pro_proveedor,                           "
                sSel = sSel & "                pro_status,                              "
                sSel = sSel & "                pro_sisemp                               "
                sSel = sSel & "            FROM Proveedores                             "
                sSel = sSel & "            WHERE pro_sisemp = {empresa})             "
                sOrd = " ORDER BY Nombre"
                sWhr = " "


                sWhr = Replace(sWhr, "{empresa}", Sesion.IdEmpresa)

            Case "Bancos"

            Case "Inventarios"

            Case "Planilla"

            Case Else
              
        End Select
    End Sub

    Private Sub CeldaTexto1_TextChanged(sender As Object, e As EventArgs) Handles CeldaTexto1.TextChanged

        Dim strTemp As String

        If sCat = "Empresas" Then
            sSel = vbNullString
            sSel = sSel & "            (SELECT                                      "
            sSel = sSel & "                concat('C', Right(concat('00000',        "
            sSel = sSel & "                CAST(cli_codigo AS CHAR)),5)) as Codigo, "
            sSel = sSel & "                cli_cliente as Nombre,                   "
            sSel = sSel & "                cli_status As Estado,                    "
            sSel = sSel & "                cli_sisemp as Sisemp                     "
            sSel = sSel & "            FROM Clientes                                "
            sSel = sSel & "            WHERE cli_sisemp = {empresa}            "
            sSel = sSel & "            AND cli_cliente LIKE '%" & CeldaTexto1.Text & "%')      "
            sSel = sSel & "            UNION                                        "
            sSel = sSel & "            (SELECT                                      "
            sSel = sSel & "                concat('P', Right(concat('00000',        "
            sSel = sSel & "                CAST(pro_codigo AS CHAR)),5)),           "
            sSel = sSel & "                pro_proveedor,                           "
            sSel = sSel & "                pro_status,                              "
            sSel = sSel & "                pro_sisemp                               "
            sSel = sSel & "            FROM Proveedores                             "
            sSel = sSel & "            WHERE pro_sisemp = {empresa}             "
            sSel = sSel & "            AND pro_proveedor LIKE '%" & CeldaTexto1.Text & "%')    "
            strTemp = sSel & sWhr & sOrd
        Else
            strTemp = sSel & sWhr & " LIKE '%" & CeldaTexto1.Text & "%' " & sOrd
        End If

        sSel = Replace(sSel, "{empresa}", Sesion.IdEmpresa)

    End Sub

    Private Sub frmCatVentas_Load(sender As Object, e As EventArgs) Handles MyBase.Load



    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click

        Me.Close()

    End Sub

End Class