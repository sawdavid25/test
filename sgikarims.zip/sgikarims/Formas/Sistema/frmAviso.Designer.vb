﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAviso
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelAviso = New System.Windows.Forms.Panel()
        Me.celdaAviso = New System.Windows.Forms.TextBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.PanelAviso.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelAviso
        '
        Me.PanelAviso.Controls.Add(Me.celdaAviso)
        Me.PanelAviso.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelAviso.Location = New System.Drawing.Point(0, 0)
        Me.PanelAviso.Name = "PanelAviso"
        Me.PanelAviso.Size = New System.Drawing.Size(660, 426)
        Me.PanelAviso.TabIndex = 0
        '
        'celdaAviso
        '
        Me.celdaAviso.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAviso.Dock = System.Windows.Forms.DockStyle.Fill
        Me.celdaAviso.Location = New System.Drawing.Point(0, 0)
        Me.celdaAviso.Multiline = True
        Me.celdaAviso.Name = "celdaAviso"
        Me.celdaAviso.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.celdaAviso.Size = New System.Drawing.Size(660, 426)
        Me.celdaAviso.TabIndex = 0
        '
        'botonCerrar
        '
        Me.botonCerrar.CausesValidation = False
        Me.botonCerrar.Location = New System.Drawing.Point(528, 444)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(120, 36)
        Me.botonCerrar.TabIndex = 1
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'frmAviso
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(660, 503)
        Me.Controls.Add(Me.botonCerrar)
        Me.Controls.Add(Me.PanelAviso)
        Me.Name = "frmAviso"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmAviso"
        Me.PanelAviso.ResumeLayout(False)
        Me.PanelAviso.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelAviso As System.Windows.Forms.Panel
    Friend WithEvents celdaAviso As System.Windows.Forms.TextBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
End Class
