﻿Public Class frmReservas


#Region "Variables de Instancia"

    Dim intCatalogo As Integer = vbEmpty
    Dim intNumero As Integer = vbEmpty
    Dim intAño As Integer = vbEmpty
    Dim intLinea As Integer = vbEmpty
    Dim intFila As Integer = vbEmpty
    Dim intEmpresa As Integer = vbEmpty
    Dim intCantidad As Integer = vbEmpty
    Dim intReservado As Integer = vbEmpty
    Dim InfoProd As String = STR_VACIO
    Dim Med As String = STR_VACIO
    Dim Despa As Double
    Dim Articulo As Double

    Private dblDespachado As Double
    Private dblSaldo As Double
    Private dblReserva As Double
    Private dblDisponible As Double

    Private logModificado As Boolean

#End Region

#Region "Propiedades"

    Public Property Modificado As Boolean
        Get
            Return logModificado
        End Get
        Set(value As Boolean)
            logModificado = value
        End Set
    End Property

    Public Property Catalogo As String
        Get
            Return intCatalogo
        End Get
        Set(value As String)
            intCatalogo = value
        End Set
    End Property

    Public Property Numero As String
        Get
            Return intNumero
        End Get
        Set(value As String)
            intNumero = value
        End Set
    End Property

    Public Property Empresa As Integer
        Get
            Return intEmpresa
        End Get
        Set(value As Integer)
            intEmpresa = value
        End Set
    End Property

    Public Property Anio As String
        Get
            Return intAño
        End Get
        Set(value As String)
            intAño = value
        End Set
    End Property

    Public Property Linea As Integer
        Get
            Return intLinea
        End Get
        Set(value As Integer)
            intLinea = value
        End Set
    End Property

    Public Property Fila As Integer
        Get
            Return intFila
        End Get
        Set(value As Integer)
            intFila = value
        End Set
    End Property

    Public Property Medida As String
        Get
            Return Med
        End Get
        Set(value As String)
            Med = value
        End Set
    End Property

    Public Property InfoProducto As String
        Get
            Return InfoProd
        End Get
        Set(value As String)
            InfoProd = value
        End Set
    End Property


    Public Property Despacho As Double
        Get
            Return Despa
        End Get
        Set(value As Double)
            Despa = value
        End Set
    End Property

    Public Property DesArticulo As String
        Get
            Return Despa
        End Get
        Set(value As String)
            Despa = value
        End Set
    End Property


    Public Property Cantidad As Double
        Get
            Return intCantidad
        End Get
        Set(value As Double)
            intCantidad = value
        End Set
    End Property

    Public Property Reservado As Double
        Get
            Return intReservado
        End Get
        Set(value As Double)
            intReservado = value
        End Set
    End Property


#End Region

#Region "Procedimientos"

    Private Sub LimpiarPanel()

        celdaProducto.Text = STR_VACIO
        celdaNombreCliente.Text = STR_VACIO
        celdaCodigo.Text = NO_FILA
        celdaCantReservada.Text = NO_FILA
        celdaEstado.Text = NO_FILA
        celdaObservaciones.Text = STR_VACIO
        celdaSaldo.Text = NO_FILA
        celdaReservado.Text = NO_FILA
        celdaDisponible.Text = NO_FILA

    End Sub

    'Carga el listado
    Private Function CargarLista()
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT nombre, cantidad, nota, linea, id_entidad, estado, referencia"
        strSQL &= "      FROM Reserva"
        strSQL &= "              WHERE id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={año} AND doc_num={numero} AND doc_lin={linea}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{linea}", intLinea)

        Return strSQL
    End Function

    Private Sub queryCargarLista()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        'Dim strFila As String = STR_VACIO
        Dim e As Integer = vbEmpty

        strSQL = CargarLista()
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgDetalleReserva.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    Dim strFila As String = STR_VACIO
                    strFila &= REA.GetString("nombre") & "|"
                    strFila &= REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("nota") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("id_entidad") & "|"
                    strFila &= REA.GetInt32("estado")
                    celdaReferencia.Text = REA.GetString("referencia")
                    e = REA.GetInt32("estado")

                    AgregarFila(dgDetalleReserva, strFila, e)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal estado As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If estado = 2 Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Red
                    End If
                ElseIf estado = INT_UNO Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Yellow
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Rutina de inicio
    Private Sub Iniciar(ByVal Fila As Integer, ByVal Año As Integer, ByVal Numero As Long, ByVal Linea As Integer, ByVal Medida As String, ByVal Descripcion As String, ByVal Despacho As Double)
        Dim intDescargo As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        intDescargo = 48
        dblDespachado = Despacho

        strSQL = " SELECT d.DDoc_Prd_QTY - IFNULL(("
        strSQL &= "      SELECT SUM(r.PDoc_QTY_Pro)"
        strSQL &= "              FROM Dcmtos_DTL_Pro r"
        strSQL &= "          WHERE r.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r.PDoc_Par_Cat=d.DDoc_Doc_Cat AND r.PDoc_Par_Ano=d.DDoc_Doc_Ano AND r.PDoc_Par_Num=d.DDoc_Doc_Num AND r.PDoc_Par_Lin=d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat={descargo}),0) Saldo"
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=47 AND d.DDoc_Doc_Ano={año} AND d.DDoc_Doc_Num={numero} AND d.DDoc_Doc_Lin={linea}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", Año)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{linea}", Linea)
        strSQL = Replace(strSQL, "{descargo}", intDescargo)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        dblSaldo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        celdaProducto.Text = Descripcion
        etiquetaMedida.Text = Medida
        celdaSaldo.Text = (dblSaldo - dblDespachado).ToString(FORMATO_MONEDA)

        queryCargarLista()
        MostrarDisponible()

    End Sub

    'Guardar los datos
    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim chdr As New clsDcmtos_HDR
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim i As Integer = vbEmpty
        Dim RSV As New Tablas.TRESERVA
        Try

                   RSV.CONEXION = strConexion

            RSV.ID_EMPRESA = intEmpresa
            RSV.DOC_TIPO = 47
            RSV.DOC_CICLO = intAño
            RSV.DOC_NUM = intNumero
            RSV.DOC_LIN = intLinea

            RSV.marca_NET = Now()
            RSV.ESTADO = vbEmpty
            RSV.USUARIO = Sesion.Usuario

            If Me.Tag = "Nuevo" Then
                strSQL = "SELECT (IFNULL(MAX(linea),0)+1) Linea "
                strSQL &= "      FROM Reserva"
                strSQL &= "              WHERE id_empresa= {empresa} AND doc_tipo=47 AND doc_ciclo={anio} AND doc_num={numero} AND doc_lin={linea}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", intAño)
                strSQL = Replace(strSQL, "{numero}", intNumero)
                strSQL = Replace(strSQL, "{linea}", intLinea)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                i = COM.ExecuteScalar
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()

                RSV.LINEA = i
                RSV.REFERENCIA = "***** AGREGADO *****" & vbCr & "Fecha: " & Now() & vbCr & "Usuario: " & Sesion.Usuario & vbCr & "Cliente: " & celdaNombreCliente.Text & vbCr & "Cantidad: " & celdaCantReservada.Text & Medida
            Else
                i = dgDetalleReserva.CurrentRow.Cells(3).Value
                RSV.LINEA = i
                RSV.REFERENCIA = celdaReferencia.Text & vbCr & "***** MODIFICADO *****" & vbCr & "Fecha: " & Now() & vbCr & "Usuario: " & Sesion.Usuario & vbCr & "Cliente: " & celdaNombreCliente.Text & vbCr & "Cantidad: " & celdaCantReservada.Text & Medida
            End If

            RSV.ID_ENTIDAD = celdaCodigo.Text
            RSV.NOMBRE = celdaNombreCliente.Text
            RSV.CANTIDAD = celdaCantReservada.Text
            RSV.NOTA = celdaObservaciones.Text


            If Me.Tag = "Mod" Then
                If RSV.PUPDATE = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If RSV.PINSERT = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Comprueba los datos antes de guardar
    Private Function Comprobar() As Boolean
        Dim logResultado As Boolean = True
       
        If celdaNombreCliente.Text = vbNullString Or celdaCodigo.Text = vbNullString Then
            MsgBox("No ha seleccionado el Cliente", vbExclamation, "Aviso")

            logResultado = False

        Else
            If Me.Tag = "Nuevo" Then
                If celdaCantReservada.Text < vbEmpty Then
                    MsgBox("El Monto de la Reserva debe ser mayor que cero", vbExclamation, "Aviso")
                    logResultado = False
                ElseIf (CDbl(celdaCantReservada.Text) > dblDisponible) Then
                    MsgBox("El Monto de la Reserva es mayor que la cantidad disponible", vbExclamation, "Aviso")
                    logResultado = False
                Else
                    logResultado = True

                End If
            ElseIf Me.Tag = "Mod" Then
                If CDbl(celdaCantReservada.Text > (dblDisponible + celdaReservado.Text)) Then
                    MsgBox("El Monto de la Reserva es mayor que la cantidad disponible", vbExclamation, "Aviso")
                    logResultado = False
                Else
                    logResultado = True
                End If
            End If
        End If
        Return logResultado
    End Function

#End Region

#Region "Eventos"
    Private Sub frmSubDocumentos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Iniciar(intFila, intAño, intNumero, intLinea, Med, InfoProd, Despa)

    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel

    End Sub

    Private Sub botonProveedores_Click(sender As Object, e As EventArgs) Handles botonProveedores.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp={empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " cli_codigo ID, UPPER(TRIM(cli_cliente)) Descripcion"
            frm.Tabla = " Clientes"
            frm.FiltroText = " Enter the Client to filter"
            frm.Filtro = "  cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " cli_cliente "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaNombreCliente.Text = frm.Dato
                celdaCodigo.Text = frm.LLave
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Actualiza la cantidad disponible
    Private Sub MostrarDisponible()
        Dim dblSuma As Double
        Dim i As Integer = vbEmpty

        For i = 0 To dgDetalleReserva.Rows.Count - 1
            If Not (dgDetalleReserva.Rows(i).Cells("colEstado").Value = 2) Then
                dblSuma = dblSuma + dgDetalleReserva.Rows(i).Cells("colCantidad").Value
            End If
        Next
        dblReserva = dblSuma
        dblDisponible = (dblSaldo - (dblDespachado + dblReserva))

        celdaReservado.Text = dblReserva.ToString(FORMATO_MONEDA)
        celdaDisponible.Text = dblDisponible.ToString(FORMATO_MONEDA)
    End Sub

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        Me.Tag = "Nuevo"
        If dblDisponible > vbEmpty Then
            LimpiarPanel()
            botonProveedores.Enabled = True
        Else
            MsgBox("No hay Saldo Disponible para reservar", vbInformation, "Aviso")
        End If

        celdaEstado.Text = "NUEVO"
        celdaEstado.BackColor = Color.Blue

        celdaSaldo.Text = intCantidad.ToString(FORMATO_MONEDA)
        celdaDisponible.Text = intReservado.ToString(FORMATO_MONEDA)

    End Sub

    Private Sub botonModificar_Click(sender As Object, e As EventArgs) Handles botonModificar.Click
        Me.Tag = "Mod"
        Dim i As Integer = vbEmpty
        Dim estado As Integer = vbEmpty


        celdaCodigo.Text = dgDetalleReserva.CurrentRow.Cells(4).Value
        celdaNombreCliente.Text = dgDetalleReserva.CurrentRow.Cells(0).Value
        botonProveedores.Enabled = True


        celdaCantReservada.Text = dgDetalleReserva.CurrentRow.Cells(1).Value
        celdaObservaciones.Text = dgDetalleReserva.CurrentRow.Cells(2).Value
        estado = dgDetalleReserva.CurrentRow.Cells(5).Value
        Select Case estado
            Case vbEmpty
                celdaEstado.Text = "RESERVADO"
                celdaEstado.BackColor = Color.Blue
            Case INT_UNO
                celdaEstado.Text = "PENDIENTE"
            Case 2
                celdaEstado.Text = "INACTIVO"
                celdaEstado.BackColor = Color.Red

                botonProveedores.Enabled = False
                celdaCantReservada.Enabled = False
                celdaObservaciones.Enabled = False
                botonAsignar.Enabled = False
        End Select
    End Sub

    Private Sub botonDesactivar_Click(sender As Object, e As EventArgs) Handles botonDesactivar.Click
        Me.Tag = "Mod"
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand

        'For i = 0 To dgDetalleReserva.Rows.Count - 1

        'If dgDetalleReserva.Rows(i).Cells("colSeleccionar").Value = "SI" Then

        'If Not (i = NO_FILA) Then
        'Si no está inactivo
        If Not (dgDetalleReserva.CurrentRow.Cells(5).Value) = 2 Then
            If MsgBox(("Desactivar la linea de reserva seleccionada?") & vbCr & vbCr & dgDetalleReserva.CurrentRow.Cells(1).Value & "/" & dgDetalleReserva.CurrentRow.Cells(0).Value, vbQuestion + vbYesNo, "Desactivar Reserva") = vbYes Then

                strSQL = "UPDATE Reserva"
                strSQL &= "      SET estado={estado}, referencia= {referencia}"
                strSQL &= "   WHERE id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={año} AND doc_num={numero} AND doc_lin={linea} AND linea={lineaD}"
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= ";UPDATE PDM.Reserva"
                    strSQL &= "      SET estado={estado}, referencia= {referencia}"
                    strSQL &= "   WHERE id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={año} AND doc_num={numero} AND doc_lin={linea} AND linea={lineaD}"
                End If
                strSQL = Replace(strSQL, "{estado}", 2)
                strSQL = Replace(strSQL, "{referencia}", "CONCAT(referencia,'\r\n***** DESACTIVADO *****\r\nFecha: ',CAST(NOW() AS CHAR),'\r\nUsuario: " & Sesion.Usuario & "')")
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{año}", intAño)
                strSQL = Replace(strSQL, "{numero}", intNumero)
                strSQL = Replace(strSQL, "{linea}", intLinea)
                strSQL = Replace(strSQL, "{lineaD}", dgDetalleReserva.CurrentRow.Cells(3).Value)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()

                logModificado = True

                dgDetalleReserva.CurrentRow.Cells(5).Value = 2
                'dgDetalleReserva.Rows(i).Cells("colEstado")

                MostrarDisponible()
            End If
        End If
        'End If

        'End If
        'Next
    End Sub
    'Private Sub dgDetalleReserva_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalleReserva.DoubleClick

    '    If dgDetalleReserva.SelectedCells(0).Value.ToString.Length < 2 Then
    '        dgDetalleReserva.SelectedCells(0).Value = "SI"
    '    Else
    '        dgDetalleReserva.SelectedCells(0).Value = ""
    '    End If

    '    frmMensaje.Close()

    'End Sub
    Private Sub botonAsignar_Click(sender As Object, e As EventArgs) Handles botonAsignar.Click
        If Comprobar() Then
            If Guardar() Then
                logModificado = True

                CargarLista()
                queryCargarLista()
                MostrarDisponible()
            End If
        End If
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        LimpiarPanel()
    End Sub

    Private Sub botonEventos_Click(sender As Object, e As EventArgs) Handles botonEventos.Click
        Dim strSQL As String
        Dim strDato As String
        Dim i As Integer = vbEmpty
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        'For i = 0 To dgDetalleReserva.Rows.Count - 1
        If dgDetalleReserva.Rows.Count > 0 Then
            i = dgDetalleReserva.CurrentRow.Cells(3).Value
            strSQL = "SELECT referencia"
            strSQL &= "      FROM Reserva"
            strSQL &= "           WHERE id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={anio} AND doc_num={numero} AND doc_lin={linea} AND linea={linea2}"
            strSQL &= "       LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{linea}", intLinea)
            strSQL = Replace(strSQL, "{linea2}", i)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            strDato = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            If (strDato = vbNullString) Then
                MsgBox("La Linea seleccionada no tiene historial", vbInformation, "Aviso")
            Else
                MsgBox(strDato, vbInformation, "Historial")
            End If

        End If
        'Next
    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        Me.Tag = "Mod"
        Dim j As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO

        If dgDetalleReserva.Rows.Count > 0 Then
            j = dgDetalleReserva.CurrentRow.Cells(5).Value
            'Si está activo pregunta si se desactiva (no eliminar)
            If Not (j = 2) Then
                If MsgBox("Desacrtivar la linea de reserva en lugar de eliminarla?", vbQuestion + vbYesNo, "Eliminar") = vbYes Then
                    Exit Sub
                End If
            End If


            'Confirma la eliminacion
            If MsgBox("Se eliminara definitivamente la linea de reserva " & vbCr & vbCr & dgDetalleReserva.CurrentRow.Cells(1).Value & "/" & dgDetalleReserva.CurrentRow.Cells(0).Value, vbQuestion + vbYesNo, "Eliminar") = vbYes Then
                strSQL = "id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={anio} AND doc_num={numero} AND doc_lin={linea} AND linea={linea2}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{numero}", intNumero)
                strSQL = Replace(strSQL, "{anio}", intAño)
                strSQL = Replace(strSQL, "{linea}", intLinea)
                strSQL = Replace(strSQL, "{linea2}", dgDetalleReserva.CurrentRow.Cells(3).Value)

                Dim reserva As New Tablas.TRESERVA
                reserva.CONEXION = strConexion
                reserva.PDELETE(strSQL)

                logModificado = True
                LimpiarPanel()
                queryCargarLista()
                MostrarDisponible()
            End If
        End If
    End Sub

#End Region


End Class