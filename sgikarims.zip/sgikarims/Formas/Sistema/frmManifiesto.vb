﻿Public Class frmManifiesto

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

#End Region


#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Carga datos del Listado
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO
        Dim empresa As String

        If Sesion.Empresa = "Hilos y Algodon" And Sesion.IdEmpresa = 12 Then
            strsql = " SELECT HDoc_Doc_Cat TYPE, HDoc_Doc_Ano YEAR, HDoc_Doc_Fec DATE, IF(HDoc_DR2_Num ='{serie}', HDoc_Doc_Num, HDoc_Doc_Num) Number, HDoc_Doc_Num Num2, HDoc_DR2_Num Series, HDoc_Emp_Nom CLIENT, HDoc_DR1_Num Reference,HDoc_RF1_Dbl Flete"
        Else
            strsql = " SELECT HDoc_Doc_Cat TYPE, HDoc_Doc_Ano YEAR, HDoc_Doc_Fec DATE, IF(LENGTH(HDoc_DR2_Num)>2, HDoc_DR1_Dbl, HDoc_Doc_Num) Number, HDoc_Doc_Num Num2, HDoc_DR2_Num Series, HDoc_Emp_Nom CLIENT, HDoc_DR1_Num Reference,HDoc_RF1_Dbl Flete"
        End If

        strsql &= "  FROM Dcmtos_HDR"
        strsql &= "    WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}'"

        If checkFecha.Checked = True Then

            strsql &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "ORDER BY HDoc_Doc_Fec DESC, HDoc_Doc_Num DESC "
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{serie}", SQLSerie)

        empresa = Sesion.Empresa

        Return strsql
    End Function

    Private Function SQLSerie()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSerie As String = STR_VACIO


        strSQL = "SELECT c.cat_sist serie"
        strSQL &= "     FROM Catalogos c"
        strSQL &= "          WHERE c.cat_clase = 'serie'and c.cat_clave = 'Doc_CFactura' and c.cat_sisemp = {empresa} and c.cat_pid = 0"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                strSerie = REA.GetString("serie")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strSerie
    End Function

    'Procedimiento para Cargar dgLista 
    Public Sub queryLista()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLlista()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = " |" & REA.GetInt32("Year") & "|" & REA.GetDateTime("Date") & "|" & REA.GetInt32("Number") & "|" & REA.GetInt32("Num2") & "|" &
                     REA.GetString("Series") & "|" & REA.GetString("Client") & "|" & REA.GetString("Reference") & "|" & REA.GetDouble("Flete")

                    cFunciones.AgregarFila(dgLista, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub



#End Region

#Region "Eventos"

    Private Sub frmManifiesto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()

        dtpInicio.Value = Today.AddMonths(NO_FILA)
        dtpFinal.Value = Today
        queryLista()
        ' checkFechaOptional.Checked = False
        If checkFechaOptional.Checked = False Then
            dtpFechaOptional.Enabled = False
        Else
            dtpFechaOptional.Enabled = True
        End If

    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()

    End Sub

    Private Sub Update_Click(sender As Object, e As EventArgs) Handles botonCListado.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            queryLista()
        End If

    End Sub
    Private Sub botonHojaRuta_Click(sender As Object, e As EventArgs) Handles botonHojaRuta.Click
        Me.Hide()
        Dim strLista As String = STR_VACIO
        Dim i As Integer
        Dim WC As New clsReportes
        Dim Contador As Integer = INT_CERO
        Dim logCancelar As Boolean
        Dim intNumero As Integer
        Dim fecha As Date

        For i = 0 To dgLista.Rows.Count - 1
            If dgLista.Rows(i).Cells(0).Value = "SI" Then
                Contador = Contador + 1

                strLista &= IIf(strLista = vbNullString, " ", "|")
                'If celdaNo.Text = vbNullString Then
                strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & dgLista.Rows(i).Cells("colNum2").Value
                'Else
                '    strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & dgLista.Rows(i).Cells("colNumero").Value & "-" & Val(celdaNo.Text)
                'End If
            End If

            'Factura Seleccionada

        Next

        If Contador = 0 Then
            MsgBox("You must select at least one bill", vbExclamation, "Notice")
            logCancelar = True
        Else
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                permiteWord = True
            End If
            If celdaNo.Text = vbNullString And checkFechaOptional.Checked = False Then
                WC.ReportWaybillConsolidation(strLista)
            ElseIf checkFechaOptional.Checked = True And celdaNo.Text = vbNullString Then
                fecha = dtpFechaOptional.Value
                fecha = fecha.ToString(FORMATO_MYSQL)
                WC.ReportWaybillConsolidation(strLista, 0, fecha)
            ElseIf Not (celdaNo.Text = vbNullString) And checkFechaOptional.Checked = True Then
                fecha = dtpFechaOptional.Value
                fecha = fecha.ToString(FORMATO_MYSQL)
                WC.ReportWaybillConsolidation(strLista, celdaNo.Text, fecha)
            Else
                WC.ReportWaybillConsolidation(strLista, celdaNo.Text)
            End If
        End If
        Me.Close()
    End Sub

    Private Sub botonListaEmpaque_Click(sender As Object, e As EventArgs) Handles botonListaEmpaque.Click
        'Me.Hide()
        Dim strLista As String = STR_VACIO
        Dim i As Integer
        Dim PL As New clsReportes
        Dim Contador As Integer = INT_CERO
        Dim logCancelar As Boolean
        Dim fecha As Date

        For i = 0 To dgLista.Rows.Count - 1
            If dgLista.Rows(i).Cells(0).Value = "SI" Then
                Contador = Contador + 1

                strLista &= IIf(strLista = vbNullString, " ", "|")
                'If celdaNo.Text = vbNullString Then
                strLista &= dgLista.Rows(i).Cells("ColAño").Value & "-" & dgLista.Rows(i).Cells("colNum2").Value
                'Else
                '    strLista &= dgLista.Rows(i).Cells("ColAño").Value & "-" & Val(celdaNo.Text)
                'End If
            End If

            'Factura Seleccionada
        Next

        If Contador = 0 Then
            MsgBox("You must select at least one bill", vbExclamation, "Notice")
            logCancelar = True
        Else
            If celdaNo.Text = vbNullString And checkFechaOptional.Checked = False Then
                PL.ReportPackingListConsolidation(strLista)
            ElseIf checkFechaOptional.Checked = True And celdaNo.Text = vbNullString Then
                fecha = dtpFechaOptional.Value
                fecha = fecha.ToString(FORMATO_MYSQL)
                PL.ReportPackingListConsolidation(strLista, 0, fecha)
            ElseIf Not (celdaNo.Text = vbNullString) And checkFechaOptional.Checked = True Then
                fecha = dtpFechaOptional.Value
                fecha = fecha.ToString(FORMATO_MYSQL)
                PL.ReportPackingListConsolidation(strLista, celdaNo.Text, fecha)
            Else
                PL.ReportPackingListConsolidation(strLista, celdaNo.Text)
            End If

        End If
        Me.Close()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick


        If dgLista.SelectedCells(0).Value.ToString.Length < 2 Then
            dgLista.SelectedCells(0).Value = "SI"
        Else
            dgLista.SelectedCells(0).Value = ""
        End If

        frmMensaje.Close()



    End Sub

    Private Sub botonManifiesto_Click(sender As Object, e As EventArgs) Handles botonManifiesto.Click
        'Me.Hide()
        Dim strLista As String = STR_VACIO
        Dim i As Integer
        Dim WC As New clsReportes
        Dim Contador As Integer = INT_CERO
        Dim logCancelar As Boolean
        Dim fecha As Date

        For i = 0 To dgLista.Rows.Count - 1
            If dgLista.Rows(i).Cells(0).Value = "SI" Then
                Contador = Contador + 1

                strLista &= IIf(strLista = vbNullString, " ", "|")
                'If celdaNo.Text = vbNullString Then
                strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & dgLista.Rows(i).Cells("colNum2").Value
                'Else
                '    strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & Val(celdaNo.Text)
                'End If
            End If

            'Factura Seleccionada
        Next

        If Contador = 0 Then
            MsgBox("You must select at least one bill ", vbExclamation, "Notice")
            logCancelar = True
        Else
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                permiteWord = True
            End If
            If celdaNo.Text = vbNullString And checkFechaOptional.Checked = False Then
                WC.ReportManifestConsolidation(strLista)
            ElseIf checkFechaOptional.Checked = True And celdaNo.Text = vbNullString Then
                fecha = dtpFechaOptional.Value
                fecha = fecha.ToString(FORMATO_MYSQL)
                WC.ReportManifestConsolidation(strLista, 0, fecha)
            ElseIf Not (celdaNo.Text = vbNullString) And checkFechaOptional.Checked = True Then
                fecha = dtpFechaOptional.Value
                fecha = fecha.ToString(FORMATO_MYSQL)
                WC.ReportManifestConsolidation(strLista, celdaNo.Text, fecha)
            Else
                WC.ReportManifestConsolidation(strLista, celdaNo.Text)
            End If

        End If
        permiteWord = False
        Me.Close()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub checkFechaOptional_CheckedChanged(sender As Object, e As EventArgs) Handles checkFechaOptional.CheckedChanged

        If checkFechaOptional.Checked = True Then
            dtpFechaOptional.Enabled = True
        Else
            dtpFechaOptional.Enabled = False
        End If

    End Sub

#End Region

    Private Sub dgLista_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgLista.CellContentClick

    End Sub

    Private Sub BotonDocumentoSalida_Click(sender As Object, e As EventArgs) Handles BotonDocumentoSalida.Click
        Dim strLista As String = STR_VACIO
        Dim i As Integer
        Dim WC As New clsReportes
        Dim Contador As Integer = INT_CERO
        Dim logCancelar As Boolean
        Dim fecha As Date

        For i = 0 To dgLista.Rows.Count - 1
            If dgLista.Rows(i).Cells(0).Value = "SI" Then
                Contador = Contador + 1

                strLista &= IIf(strLista = vbNullString, " ", "|")
                'If celdaNo.Text = vbNullString Then
                strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & dgLista.Rows(i).Cells("colNum2").Value
                'Else
                '    strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & Val(celdaNo.Text)
                'End If
            End If
            'Factura Seleccionada
        Next
        If celdaNo.Text = vbNullString And checkFechaOptional.Checked = False Then
            WC.ReporteInspeccionSalidas(strLista)
        End If
        Me.Close()
    End Sub

    Private Sub BotonCaratula_Click(sender As Object, e As EventArgs) Handles BotonCaratula.Click
        Dim strLista As String = STR_VACIO
        Dim i As Integer
        Dim WC As New clsReportes
        Dim Contador As Integer = INT_CERO
        Dim logCancelar As Boolean
        Dim fecha As Date

        For i = 0 To dgLista.Rows.Count - 1
            If dgLista.Rows(i).Cells(0).Value = "SI" Then
                Contador = Contador + 1

                strLista &= IIf(strLista = vbNullString, " ", "|")
                'If celdaNo.Text = vbNullString Then
                strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & dgLista.Rows(i).Cells("colNum2").Value
                'Else
                '    strLista &= dgLista.Rows(i).Cells("colAño").Value & "-" & Val(celdaNo.Text)
                'End If
            End If
            'Factura Seleccionada
        Next
        If checkFechaOptional.Checked = True Then
            WC.DocumentacionCaratula(strLista, dtpFechaOptional.Value)
        End If
        Me.Close()
    End Sub
End Class