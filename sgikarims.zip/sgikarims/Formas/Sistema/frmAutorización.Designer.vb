﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAutorización
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelAcción = New System.Windows.Forms.Panel()
        Me.etiquetaInfo = New System.Windows.Forms.Label()
        Me.etiquetaTitulo = New System.Windows.Forms.Label()
        Me.panelAutorización = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonContinuar = New System.Windows.Forms.Button()
        Me.celdaContraseña = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.etiquetaContraseña = New System.Windows.Forms.Label()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.panelAcción.SuspendLayout()
        Me.panelAutorización.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelAcción
        '
        Me.panelAcción.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.panelAcción.Controls.Add(Me.etiquetaInfo)
        Me.panelAcción.Controls.Add(Me.etiquetaTitulo)
        Me.panelAcción.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelAcción.Location = New System.Drawing.Point(0, 0)
        Me.panelAcción.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelAcción.Name = "panelAcción"
        Me.panelAcción.Size = New System.Drawing.Size(368, 81)
        Me.panelAcción.TabIndex = 0
        '
        'etiquetaInfo
        '
        Me.etiquetaInfo.AutoSize = True
        Me.etiquetaInfo.Location = New System.Drawing.Point(30, 43)
        Me.etiquetaInfo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaInfo.Name = "etiquetaInfo"
        Me.etiquetaInfo.Size = New System.Drawing.Size(16, 13)
        Me.etiquetaInfo.TabIndex = 1
        Me.etiquetaInfo.Text = "..."
        '
        'etiquetaTitulo
        '
        Me.etiquetaTitulo.AutoSize = True
        Me.etiquetaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTitulo.Location = New System.Drawing.Point(29, 15)
        Me.etiquetaTitulo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTitulo.Name = "etiquetaTitulo"
        Me.etiquetaTitulo.Size = New System.Drawing.Size(127, 17)
        Me.etiquetaTitulo.TabIndex = 0
        Me.etiquetaTitulo.Text = "Authorize Action"
        '
        'panelAutorización
        '
        Me.panelAutorización.Controls.Add(Me.botonCancelar)
        Me.panelAutorización.Controls.Add(Me.botonContinuar)
        Me.panelAutorización.Controls.Add(Me.celdaContraseña)
        Me.panelAutorización.Controls.Add(Me.celdaUsuario)
        Me.panelAutorización.Controls.Add(Me.etiquetaContraseña)
        Me.panelAutorización.Controls.Add(Me.etiquetaUsuario)
        Me.panelAutorización.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelAutorización.Location = New System.Drawing.Point(0, 81)
        Me.panelAutorización.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelAutorización.Name = "panelAutorización"
        Me.panelAutorización.Size = New System.Drawing.Size(368, 196)
        Me.panelAutorización.TabIndex = 1
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel5
        Me.botonCancelar.Location = New System.Drawing.Point(280, 113)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(64, 49)
        Me.botonCancelar.TabIndex = 5
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonContinuar
        '
        Me.botonContinuar.Image = Global.KARIMs_SGI.My.Resources.Resources.next_set_2
        Me.botonContinuar.Location = New System.Drawing.Point(280, 51)
        Me.botonContinuar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonContinuar.Name = "botonContinuar"
        Me.botonContinuar.Size = New System.Drawing.Size(64, 49)
        Me.botonContinuar.TabIndex = 4
        Me.botonContinuar.Text = "Continue"
        Me.botonContinuar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonContinuar.UseVisualStyleBackColor = True
        '
        'celdaContraseña
        '
        Me.celdaContraseña.Location = New System.Drawing.Point(32, 127)
        Me.celdaContraseña.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaContraseña.Name = "celdaContraseña"
        Me.celdaContraseña.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.celdaContraseña.Size = New System.Drawing.Size(180, 20)
        Me.celdaContraseña.TabIndex = 3
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(32, 62)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(180, 20)
        Me.celdaUsuario.TabIndex = 2
        '
        'etiquetaContraseña
        '
        Me.etiquetaContraseña.AutoSize = True
        Me.etiquetaContraseña.Location = New System.Drawing.Point(30, 103)
        Me.etiquetaContraseña.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaContraseña.Name = "etiquetaContraseña"
        Me.etiquetaContraseña.Size = New System.Drawing.Size(53, 13)
        Me.etiquetaContraseña.TabIndex = 1
        Me.etiquetaContraseña.Text = "Password"
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(30, 37)
        Me.etiquetaUsuario.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaUsuario.TabIndex = 0
        Me.etiquetaUsuario.Text = "User"
        '
        'frmAutorización
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(368, 277)
        Me.Controls.Add(Me.panelAutorización)
        Me.Controls.Add(Me.panelAcción)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmAutorización"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Authorization"
        Me.panelAcción.ResumeLayout(False)
        Me.panelAcción.PerformLayout()
        Me.panelAutorización.ResumeLayout(False)
        Me.panelAutorización.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelAcción As System.Windows.Forms.Panel
    Friend WithEvents etiquetaInfo As System.Windows.Forms.Label
    Friend WithEvents etiquetaTitulo As System.Windows.Forms.Label
    Friend WithEvents panelAutorización As System.Windows.Forms.Panel
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonContinuar As System.Windows.Forms.Button
    Friend WithEvents celdaContraseña As System.Windows.Forms.TextBox
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaContraseña As System.Windows.Forms.Label
    Friend WithEvents etiquetaUsuario As System.Windows.Forms.Label
End Class
