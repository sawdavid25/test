﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmXDescargo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.panelInfoAdicional = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelInformacion = New System.Windows.Forms.Panel()
        Me.etiquetaInfoProducto = New System.Windows.Forms.Label()
        Me.etiquetaInformacion = New System.Windows.Forms.Label()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPais = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSemana = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDatos.SuspendLayout()
        Me.panelInfoAdicional.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelInformacion.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.botonCancelar)
        Me.panelDatos.Controls.Add(Me.botonAceptar)
        Me.panelDatos.Controls.Add(Me.panelInfoAdicional)
        Me.panelDatos.Controls.Add(Me.panelDetalle)
        Me.panelDatos.Controls.Add(Me.panelInformacion)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(733, 457)
        Me.panelDatos.TabIndex = 0
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(626, 400)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 45)
        Me.botonCancelar.TabIndex = 4
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.next_set_2
        Me.botonAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAceptar.Location = New System.Drawing.Point(534, 400)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 45)
        Me.botonAceptar.TabIndex = 3
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'panelInfoAdicional
        '
        Me.panelInfoAdicional.BackColor = System.Drawing.SystemColors.Info
        Me.panelInfoAdicional.Controls.Add(Me.Label2)
        Me.panelInfoAdicional.Controls.Add(Me.Label1)
        Me.panelInfoAdicional.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelInfoAdicional.Location = New System.Drawing.Point(0, 258)
        Me.panelInfoAdicional.Name = "panelInfoAdicional"
        Me.panelInfoAdicional.Size = New System.Drawing.Size(733, 126)
        Me.panelInfoAdicional.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Info()"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(129, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Informacion Adicional"
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDetalle.Location = New System.Drawing.Point(0, 129)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(733, 129)
        Me.panelDetalle.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colFecha, Me.colNumero, Me.colReferencia, Me.colLinea, Me.colCodigo, Me.colDescripcion, Me.colPrecio, Me.colSaldo, Me.colMedida, Me.colDescargo, Me.colUnidad, Me.colPais, Me.colFabricante, Me.colLote, Me.colSemana, Me.colClase})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.Size = New System.Drawing.Size(733, 129)
        Me.dgDetalle.TabIndex = 0
        '
        'panelInformacion
        '
        Me.panelInformacion.BackColor = System.Drawing.SystemColors.Info
        Me.panelInformacion.Controls.Add(Me.etiquetaInfoProducto)
        Me.panelInformacion.Controls.Add(Me.etiquetaInformacion)
        Me.panelInformacion.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelInformacion.Location = New System.Drawing.Point(0, 0)
        Me.panelInformacion.Name = "panelInformacion"
        Me.panelInformacion.Size = New System.Drawing.Size(733, 129)
        Me.panelInformacion.TabIndex = 0
        '
        'etiquetaInfoProducto
        '
        Me.etiquetaInfoProducto.AutoSize = True
        Me.etiquetaInfoProducto.Location = New System.Drawing.Point(12, 42)
        Me.etiquetaInfoProducto.Name = "etiquetaInfoProducto"
        Me.etiquetaInfoProducto.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaInfoProducto.TabIndex = 1
        Me.etiquetaInfoProducto.Text = "Info()"
        '
        'etiquetaInformacion
        '
        Me.etiquetaInformacion.AutoSize = True
        Me.etiquetaInformacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaInformacion.Location = New System.Drawing.Point(12, 19)
        Me.etiquetaInformacion.Name = "etiquetaInformacion"
        Me.etiquetaInformacion.Size = New System.Drawing.Size(73, 13)
        Me.etiquetaInformacion.TabIndex = 0
        Me.etiquetaInformacion.Text = "Informacion"
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        '
        'colDescargo
        '
        Me.colDescargo.HeaderText = "Discharge"
        Me.colDescargo.Name = "colDescargo"
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unit"
        Me.colUnidad.Name = "colUnidad"
        '
        'colPais
        '
        Me.colPais.HeaderText = "Country"
        Me.colPais.Name = "colPais"
        '
        'colFabricante
        '
        Me.colFabricante.HeaderText = "Manufacturer"
        Me.colFabricante.Name = "colFabricante"
        '
        'colLote
        '
        Me.colLote.HeaderText = "Lot"
        Me.colLote.Name = "colLote"
        '
        'colSemana
        '
        Me.colSemana.HeaderText = "Week"
        Me.colSemana.Name = "colSemana"
        '
        'colClase
        '
        Me.colClase.HeaderText = "Class"
        Me.colClase.Name = "colClase"
        '
        'frmXDescargo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(733, 457)
        Me.Controls.Add(Me.panelDatos)
        Me.Name = "frmXDescargo"
        Me.Text = "frmXDescargo"
        Me.panelDatos.ResumeLayout(False)
        Me.panelInfoAdicional.ResumeLayout(False)
        Me.panelInfoAdicional.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelInformacion.ResumeLayout(False)
        Me.panelInformacion.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelDatos As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelInformacion As System.Windows.Forms.Panel
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents panelInfoAdicional As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents etiquetaInfoProducto As System.Windows.Forms.Label
    Friend WithEvents etiquetaInformacion As System.Windows.Forms.Label
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPais As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFabricante As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLote As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSemana As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colClase As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
