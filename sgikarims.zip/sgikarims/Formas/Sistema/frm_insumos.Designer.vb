﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_insumos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgListaInsumos = New System.Windows.Forms.DataGridView()
        Me.cat_num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cat_desc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.paneldocumento = New System.Windows.Forms.Panel()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.celdanombre = New System.Windows.Forms.TextBox()
        Me.celdaid = New System.Windows.Forms.TextBox()
        Me.lblname = New System.Windows.Forms.Label()
        Me.lblid = New System.Windows.Forms.Label()
        Me.BarraTitulo2 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgListaInsumos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.paneldocumento.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelLista.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelLista.Controls.Add(Me.dgListaInsumos)
        Me.PanelLista.Location = New System.Drawing.Point(592, 204)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(433, 294)
        Me.PanelLista.TabIndex = 7
        '
        'dgListaInsumos
        '
        Me.dgListaInsumos.AllowUserToAddRows = False
        Me.dgListaInsumos.AllowUserToDeleteRows = False
        Me.dgListaInsumos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgListaInsumos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgListaInsumos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgListaInsumos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaInsumos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cat_num, Me.cat_desc})
        Me.dgListaInsumos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaInsumos.GridColor = System.Drawing.SystemColors.Control
        Me.dgListaInsumos.Location = New System.Drawing.Point(0, 0)
        Me.dgListaInsumos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgListaInsumos.Name = "dgListaInsumos"
        Me.dgListaInsumos.ReadOnly = True
        Me.dgListaInsumos.RowHeadersWidth = 51
        Me.dgListaInsumos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaInsumos.Size = New System.Drawing.Size(433, 294)
        Me.dgListaInsumos.TabIndex = 0
        '
        'cat_num
        '
        Me.cat_num.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.cat_num.HeaderText = "ID"
        Me.cat_num.MinimumWidth = 6
        Me.cat_num.Name = "cat_num"
        Me.cat_num.ReadOnly = True
        Me.cat_num.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.cat_num.Width = 50
        '
        'cat_desc
        '
        Me.cat_desc.HeaderText = "Name"
        Me.cat_desc.MinimumWidth = 6
        Me.cat_desc.Name = "cat_desc"
        Me.cat_desc.ReadOnly = True
        Me.cat_desc.Width = 74
        '
        'paneldocumento
        '
        Me.paneldocumento.Controls.Add(Me.BarraTitulo1)
        Me.paneldocumento.Controls.Add(Me.celdanombre)
        Me.paneldocumento.Controls.Add(Me.celdaid)
        Me.paneldocumento.Controls.Add(Me.lblname)
        Me.paneldocumento.Controls.Add(Me.lblid)
        Me.paneldocumento.Location = New System.Drawing.Point(63, 204)
        Me.paneldocumento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.paneldocumento.Name = "paneldocumento"
        Me.paneldocumento.Size = New System.Drawing.Size(432, 265)
        Me.paneldocumento.TabIndex = 6
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Location = New System.Drawing.Point(4, 5)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(423, 37)
        Me.BarraTitulo1.TabIndex = 4
        '
        'celdanombre
        '
        Me.celdanombre.Location = New System.Drawing.Point(128, 151)
        Me.celdanombre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdanombre.Name = "celdanombre"
        Me.celdanombre.Size = New System.Drawing.Size(215, 22)
        Me.celdanombre.TabIndex = 3
        '
        'celdaid
        '
        Me.celdaid.Location = New System.Drawing.Point(128, 103)
        Me.celdaid.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaid.Name = "celdaid"
        Me.celdaid.ReadOnly = True
        Me.celdaid.Size = New System.Drawing.Size(132, 22)
        Me.celdaid.TabIndex = 2
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Location = New System.Drawing.Point(28, 155)
        Me.lblname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(45, 17)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Name"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Location = New System.Drawing.Point(28, 107)
        Me.lblid.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(21, 17)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "ID"
        '
        'BarraTitulo2
        '
        Me.BarraTitulo2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BarraTitulo2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo2.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo2.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo2.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo2.Name = "BarraTitulo2"
        Me.BarraTitulo2.Size = New System.Drawing.Size(1067, 37)
        Me.BarraTitulo2.TabIndex = 8
        '
        'Encabezado1
        '
        Me.Encabezado1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1067, 89)
        Me.Encabezado1.TabIndex = 5
        '
        'frm_insumos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 554)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.paneldocumento)
        Me.Controls.Add(Me.BarraTitulo2)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frm_insumos"
        Me.Text = "frm_insumos"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgListaInsumos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.paneldocumento.ResumeLayout(False)
        Me.paneldocumento.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgListaInsumos As DataGridView
    Friend WithEvents paneldocumento As Panel
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents celdanombre As TextBox
    Friend WithEvents celdaid As TextBox
    Friend WithEvents lblname As Label
    Friend WithEvents lblid As Label
    Friend WithEvents BarraTitulo2 As BarraTitulo
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents cat_num As DataGridViewTextBoxColumn
    Friend WithEvents cat_desc As DataGridViewTextBoxColumn
End Class
