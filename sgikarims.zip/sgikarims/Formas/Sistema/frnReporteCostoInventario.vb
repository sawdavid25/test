﻿Public Class frnReporteCostoInventario

#Region "Variables"
    Dim intProducto As Integer
    Dim intPaisOrigen As Integer
    Dim strBodega As String
    Dim LogFecha As Boolean
    Dim dtFechaInventario As Date
    Dim LogColumnas As Boolean
    Dim strOrdenar As String
    Dim intNotas As Integer
    Dim LogBodega As Boolean
    Dim strTitulo As String
    Dim logEx As Boolean
    Dim i As Integer
    Dim LogAceptado As Boolean
#End Region
#Region "Propiedades"
    Public ReadOnly Property Producto As Integer
        Get
            Return intProducto
        End Get
    End Property
    Public ReadOnly Property PaisOrigen As Integer
        Get
            Return intPaisOrigen
        End Get
    End Property
    Public ReadOnly Property Bodega As String
        Get
            Return strBodega
        End Get
    End Property
    Public ReadOnly Property MostrarBodega As Boolean
        Get
            Return LogBodega
        End Get
    End Property
    Public ReadOnly Property enBlanco As Boolean
        Get
            Return logEx
        End Get
    End Property

    Public ReadOnly Property FiltroFecha As Boolean
        Get
            Return LogFecha
        End Get
    End Property
    Public ReadOnly Property SeleccionFechaInventario As Date
        Get
            Return dtFechaInventario
        End Get
    End Property
    Public ReadOnly Property Columnas As Boolean
        Get
            Return LogColumnas
        End Get
    End Property
    Public ReadOnly Property OrdenarPor As String
        Get
            Return strOrdenar
        End Get
    End Property
    Public ReadOnly Property OpcionNotas As Integer
        Get
            Return intNotas
        End Get
    End Property


    Public Property Aceptado As Boolean
        Get
            Return LogAceptado
        End Get
        Set(value As Boolean)
            LogAceptado = value
        End Set
    End Property

#End Region
    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " art_codigo ID, art_DCorta Description "
        frm.Tabla = " Articulos "
        frm.Condicion = " art_sisemp=" & Sesion.IdEmpresa & " ORDER BY art_DCorta "
        frm.Filtro = " art_DCorta"
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Articulos "
        frm.FiltroText = " Enter the product name to filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdProducto.Text = frm.LLave
            celdaProducto.Text = frm.Dato
        End If
    End Sub
    Private Sub BotonPaisOrigen_Click(sender As Object, e As EventArgs) Handles BotonPaisOrigen.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " cat_num ID, cat_desc Description "
        frm.Tabla = " Catalogos "
        frm.Condicion = " cat_clase='Paises' "
        frm.Filtro = " cat_desc"
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Catalogos "
        frm.FiltroText = " Enter source country name to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdPaisOrigen.Text = frm.LLave
            celdaPaisOrigen.Text = frm.Dato
        End If
    End Sub
    Private Sub botonBodega_Click(sender As Object, e As EventArgs) Handles botonBodega.Click
        Dim frm As New frmSeleccionar
        Dim arrayColumnas As New List(Of String)
        Dim contador As Integer = INT_CERO


        'propiedades de consulta


        frm.Campos = "DISTINCT DDoc_RF2_Cod Winery"
        frm.Tabla = " Dcmtos_DTL "
        frm.Condicion = " DDoc_Sis_Emp=" & Sesion.IdEmpresa & " AND DDoc_Doc_Cat=47 ORDER BY DDoc_RF2_Cod "
        frm.Filtro = " DDoc_RF2_Cod "
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Bodega "
        frm.FiltroText = " Enter the winery name to filter "



        If checkMostrarBodega.Checked Then
            ' propiedades de consulta
            frm.Campos = "DISTINCT TRIM(LEFT(DDoc_RF2_Cod,1)) Winery"
            frm.Tabla = "Dcmtos_DTL"
            frm.Condicion = "DDoc_Sis_Emp=" & Sesion.IdEmpresa & " AND DDoc_Doc_Cat=47 AND DDoc_RF2_Cod!='' ORDER BY DDoc_RF2_Cod"
            frm.Filtro = "DDoc_RF2_Cod"
            frm.Limite = "20"
            ' propiedades de formulario 
            frm.Titulo = "Dcmtos_DTL"
            frm.FiltroText = " Enter the winery name to filter"
            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then
                i = frm.ListaClientes.CurrentRow.Index + 1
                celdaBodega.Text = frm.LLave
                'celdaBodega.Text = frm.Dato
            End If
        End If
        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            i = frm.ListaClientes.CurrentRow.Index + 1
            celdaBodega.Text = frm.LLave

        End If



    End Sub

    Private Sub BotonOrdernar_Click(sender As Object, e As EventArgs) Handles BotonOrdernar.Click
        Dim frm As New frmOption

        frm.Opciones = "Referencia |" & "Fecha |" & "Bodega |" & "Producto"
        frm.ShowDialog(Me)
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Select Case frm.Seleccion
                Case 0
                    CeldaOrdernar.Text = "Referencia"
                Case 1
                    CeldaOrdernar.Text = "Fecha"
                Case 2
                    CeldaOrdernar.Text = "Bodega"
                Case 3
                    CeldaOrdernar.Text = "Producto"
            End Select
        Else
            Exit Sub

        End If





    End Sub

    Private Sub BotonAceptar_Click(sender As Object, e As EventArgs) Handles BotonAceptar.Click
        Dim frm As New frmOption
        Dim frmTemp As New clsReportes

        Try
            intProducto = CInt(celdaIdProducto.Text)
            intPaisOrigen = CInt(celdaIdPaisOrigen.Text)
            strBodega = celdaBodega.Text
            LogFecha = checkFiltrarFecha.Checked

            If checkMostrarBodega.Checked = True Then
                LogBodega = True
            Else
                LogBodega = False
            End If


            If LogFecha = True Then
                dtFechaInventario = dtpFechaInventario.Value
            End If

            If checkColumnasInventario.Checked = True Then
                LogColumnas = True
            Else
                LogColumnas = False
            End If
            If Not CeldaOrdernar.Text = vbNullString Then
                strOrdenar = CeldaOrdernar.Text
            End If
            If Not CeldaOrdenar1.Text = vbNullString Then
                strOrdenar = strOrdenar & IIf(strOrdenar = vbNullString, vbNullString, ", ") & CeldaOrdenar1.Text
            End If

            If i > vbEmpty Then
                logEx = (Trim(strBodega) = vbNullString)

            End If
            If LogAceptado = True Then

                Me.Hide()
                Me.DialogResult = DialogResult.OK

                frm.Opciones = "Include Comments and Notes" & "|" & "No Comments"
                frm.Titulo = " Comments and Notes "


                'frm.Opciones = "Include Comments and Notes" & "No Comments"


                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    Me.DialogResult = DialogResult.OK

                    Select Case frm.Seleccion
                        Case 0  ' Comentarios
                            intNotas = 1
                        Case 1 ' Sin Notas 
                            intNotas = 2
                    End Select
                Else
                    Me.DialogResult = DialogResult.Cancel
                End If

            Else
                    Me.DialogResult = DialogResult.OK
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BotonCancelar_Click(sender As Object, e As EventArgs) Handles BotonCancelar.Click
        Me.Close()

    End Sub

    Private Sub BotonOrdenar1_Click(sender As Object, e As EventArgs) Handles BotonOrdenar1.Click
        Dim frm As New frmOption

        frm.Opciones = "Referencia |" & "Fecha |" & "Bodega |" & "Producto"
        frm.ShowDialog(Me)
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Select Case frm.Seleccion
                Case 0
                    CeldaOrdenar1.Text = "Referencia"
                Case 1
                    CeldaOrdenar1.Text = "Fecha"
                Case 2
                    CeldaOrdenar1.Text = "Bodega"
                Case 3
                    CeldaOrdenar1.Text = "Producto"
            End Select
        Else
            Exit Sub

        End If


    End Sub
    Public Sub Resumen()
        celdaBodega.Enabled = False
        checkColumnasInventario.Enabled = False
        checkFiltrarFecha.Enabled = False
        BotonOrdenar1.Enabled = False
        BotonOrdernar.Enabled = False
        dtpFechaInventario.Enabled = False
        CeldaOrdenar1.Enabled = False
        CeldaOrdernar.Enabled = False

    End Sub
End Class