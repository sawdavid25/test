﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDiagramaGannt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.ForeColor = System.Drawing.SystemColors.Highlight
        Me.etiquetaNombre.Location = New System.Drawing.Point(100, 26)
        Me.etiquetaNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(195, 17)
        Me.etiquetaNombre.TabIndex = 7
        Me.etiquetaNombre.Text = "Select the desired date range"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(52, 43)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(384, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "_______________________________________________"
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(318, 151)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(100, 41)
        Me.botonCancelar.TabIndex = 11
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(64, 74)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(45, 17)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "DATE"
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Location = New System.Drawing.Point(67, 104)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(273, 22)
        Me.dtpFechaInicial.TabIndex = 8
        Me.dtpFechaInicial.Value = New Date(2017, 6, 1, 0, 0, 0, 0)
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonGuardar.Location = New System.Drawing.Point(210, 151)
        Me.botonGuardar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(100, 41)
        Me.botonGuardar.TabIndex = 10
        Me.botonGuardar.Text = "Continue"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'frmDiagramaGannt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(451, 209)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonGuardar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.dtpFechaInicial)
        Me.Controls.Add(Me.etiquetaNombre)
        Me.Controls.Add(Me.Label3)
        Me.Name = "frmDiagramaGannt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmDiagramaGannt"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents etiquetaNombre As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonGuardar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpFechaInicial As DateTimePicker
End Class
