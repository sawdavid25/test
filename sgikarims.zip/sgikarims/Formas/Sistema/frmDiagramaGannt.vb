﻿Public Class frmDiagramaGannt
#Region "Variables"
    Dim dtFecha As Date
    Dim intOpcion As Integer = NO_FILA
#End Region
#Region "Propiedades"
    Public ReadOnly Property FechaCorte As Date
        Get
            Return dtFecha
        End Get
    End Property
    Public Property Numero As Integer
        Get
            Return intOpcion
        End Get
        Set(value As Integer)
            intOpcion = value
        End Set
    End Property
#End Region
#Region "Funciones"

    Public Sub CambioNombre()

        If intOpcion = 0 Then
            etiquetaNombre.Text = " Select any day of the week that you need to visualize. "
        ElseIf intOpcion = 1 Then
            etiquetaNombre.Text = " Select any day of the month you need to visualize. "
        ElseIf intOpcion = 2 Then
            etiquetaNombre.Text = " Select any day of the year that you need to visualize. "
        End If


    End Sub

#End Region


    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        Try

            Dim frm As New frmOption

            dtFecha = dtpFechaInicial.Value
            Me.DialogResult = DialogResult.OK
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub frmDiagramaGannt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFechaInicial.Value = Today
        CambioNombre()
    End Sub
End Class