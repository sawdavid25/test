﻿Public Class frmSPermisos
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim varNuevo As Boolean = True

    Dim cfun As New clsFunciones
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Function cargardgv()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        ' Limpiar los DataGridViews
        dgvPermisosDisponibles.Rows.Clear()
        dgvPermisosAsignados.Rows.Clear()

        Dim usuario As String = celdaUsuario.Text

        If celdaIdUsuario.Text <> "" Then
            ' Cargar permisos asignados
            Dim queryAsignados As String = "SELECT p.pro_codigo, p.pro_descripcion , a.seg_insertar, a.seg_editar, a.seg_borrar, a.seg_buscar " &
                                   "FROM Accesos a INNER JOIN Programas p ON a.seg_programa = p.pro_codigo {usuario};"
            queryAsignados = Replace(queryAsignados, "{usuario}", "WHERE a.seg_usuario = '" & celdaUsuario.Text & "'")

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(queryAsignados, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("pro_codigo") & "|"
                    strFila &= REA.GetString("pro_descripcion") & "|"
                    strFila &= REA.GetString("seg_insertar") & "|"
                    strFila &= REA.GetString("seg_editar") & "|"
                    strFila &= REA.GetString("seg_borrar") & "|"
                    strFila &= REA.GetString("seg_buscar")

                    cFunciones.AgregarFila(dgvPermisosAsignados, strFila)
                Loop
            End If

        End If

        strFila = STR_VACIO
        ' Cargar permisos disponibles
        Dim queryDisponibles As String = "SELECT pro_codigo, pro_descripcion FROM Programas WHERE pro_codigo NOT IN (SELECT seg_programa FROM Accesos WHERE seg_usuario = '" & celdaUsuario.Text & "');"

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(queryDisponibles, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                strFila = REA.GetString("pro_codigo") & "|"
                strFila &= REA.GetString("pro_descripcion")

                cFunciones.AgregarFila(dgvPermisosDisponibles, strFila)
                ' dgvPermisosDisponibles.Rows.Add(REA.GetString("pro_codigo").ToString, REA.GetString("pro_descripcion").ToString)
            Loop
        End If
    End Function
    Private Function usuarioDatos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        ' Limpiar los DataGridViews
        dgvPermisosDisponibles.Rows.Clear()
        dgvPermisosAsignados.Rows.Clear()

        Dim usuario As String = celdaUsuario.Text

        ' Cargar permisos asignados
        Dim queryAsignados As String = "SELECT per_codigo codigo, per_usuario usuario, per_nombre1 primerNombre, per_nombre2 segundoNombre, per_apellido1 primerApellido, per_apellido2 segundoApellido, per_correo correo, ifnull(per_fecha,'2030-12-31') fecha, pue_descripcion " &
                                   ", ifnull(pue_codigo,-1) idpuesto, ifnull(pue_descripcion,'N/A') puesto FROM Personal LEFT JOIN Puestos ON per_sisemp=pue_sisemp AND per_puesto=pue_codigo WHERE per_sisemp=" & Sesion.IdEmpresa & " AND per_codigo = '" & celdaIdUsuario.Text & "';"
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(queryAsignados, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaIdUsuario.Text = REA.GetString("codigo")
                celdaUsuario.Text = REA.GetString("usuario")
                celdaContraseña.Text = STR_ASTERISCO
                celdaPrimerNombre.Text = REA.GetString("primerNombre")
                celdaSegundoNombre.Text = REA.GetString("segundoNombre")
                celdaPrimerApellido.Text = REA.GetString("primerApellido")
                celdaSegundoApellido.Text = REA.GetString("segundoApellido")
                celdaCorreo.Text = REA.GetString("correo")
                dtpFecha.Value = REA.GetDateTime("fecha")
                celdaIdPuesto.Text = REA.GetInt32("idpuesto")
                celdaPuesto.Text = REA.GetString("puesto")
            Loop
        End If
    End Function
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos
        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0
        Try
            If varNuevo Then
                If celdaUsuario.Text.Length < 3 Then
                    MsgBox("Ingrese usuario", vbCritical)
                    Comprobar = False
                    botonUsuario.Focus()
                    Exit Function
                End If
            Else
                If celdaIdUsuario.Text = STR_VACIO Then
                    MsgBox("Seleccione usuario", vbCritical)
                    Comprobar = False
                    celdaUsuario.Focus()
                    Exit Function
                End If

            End If

            If celdaPrimerNombre.Text = STR_VACIO Then
                MsgBox("Seleccione al menos un nombre", vbCritical)
                Comprobar = False
                celdaPrimerNombre.Focus()
                Exit Function
            End If
            If celdaPrimerApellido.Text = STR_VACIO Then
                MsgBox("ingrese al menos un apellido", vbCritical)
                Comprobar = False
                celdaPrimerApellido.Focus()
                Exit Function
            End If
            If celdaContraseña.Text <> STR_ASTERISCO And celdaContraseña.Text.Length = 0 Then
                MsgBox("Ingrese una contraseña", vbCritical)
                Comprobar = False
                celdaContraseña.Focus()
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
            Comprobar = False
        End Try
        Return Comprobar
    End Function
    Private Sub botonUsuario_Click(sender As Object, e As EventArgs) Handles botonUsuario.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Usuario"
            frm.Campos = " per_codigo codigo, per_usuario usuario, concat(per_nombre1,' ', per_apellido1) nombre"
            frm.Tabla = " Personal"
            frm.FiltroText = " Ingrese usuario"
            frm.Filtro = " per_usuario "
            frm.Condicion = "per_sisemp=" & Sesion.IdEmpresa
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdUsuario.Text = frm.LLave
                celdaUsuario.Text = frm.Dato
                celdaPrimerNombre.Text = frm.Dato2
            End If
            If logConsultar Then
                usuarioDatos()
                cargardgv()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonUsuarioOriginal_Click(sender As Object, e As EventArgs) Handles botonUsuarioOriginal.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Usuario"
            frm.Campos = " per_codigo codigo, per_usuario usuario, concat(per_nombre1,' ', per_apellido1) nombre"
            frm.Tabla = " Personal"
            frm.FiltroText = " Ingrese usuario"
            frm.Filtro = " per_usuario "
            frm.Condicion = " per_usuario <> '" & celdaUsuario.Text & "' AND per_sisemp=" & Sesion.IdEmpresa
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdausuarioIDOriginal.Text = frm.LLave
                celdaUsuarioOriginal.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgvPermisosDisponibles_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPermisosDisponibles.CellDoubleClick
        If e.RowIndex >= 0 Then
            ' Obtener la fila seleccionada
            Dim selectedRow As DataGridViewRow = dgvPermisosDisponibles.Rows(e.RowIndex)

            ' Agregar la fila a "Permisos Asignados"
            dgvPermisosAsignados.Rows.Add(selectedRow.Cells("pro_codigo").Value, selectedRow.Cells("pro_descripcion").Value, "", "", "", "")

            ' Eliminar la fila de "Permisos Disponibles"
            dgvPermisosDisponibles.Rows.RemoveAt(e.RowIndex)
        End If
    End Sub
    Private Sub dgvPermisosAsignados_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPermisosAsignados.CellClick
        If e.RowIndex >= 0 AndAlso (e.ColumnIndex >= 2 AndAlso e.ColumnIndex <= 5) Then
            ' Cambiar el valor de la celda a "SI" si es "NO", o viceversa
            Dim cellValue As String = dgvPermisosAsignados.Rows(e.RowIndex).Cells(e.ColumnIndex).Value.ToString()

            If cellValue = "" Then
                dgvPermisosAsignados.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "SI"
            Else
                dgvPermisosAsignados.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = ""
            End If
        End If
    End Sub
    Private Sub dgvPermisosAsignados_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvPermisosAsignados.CellDoubleClick
        If e.RowIndex >= 0 Then
            ' Obtener la fila seleccionada
            Dim selectedRow As DataGridViewRow = dgvPermisosAsignados.Rows(e.RowIndex)

            ' Agregar la fila a "Permisos Disponibles"
            dgvPermisosDisponibles.Rows.Add(selectedRow.Cells("a_pro_codigo").Value, selectedRow.Cells("a_pro_descripcion").Value)

            ' Eliminar la fila de "Permisos Asignados"
            dgvPermisosAsignados.Rows.RemoveAt(e.RowIndex)
        End If
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            If ComprobarCampos() = True Then
                Guardar()
                cFunciones.EscribirRegistro("Personal", clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 687, "", 0, "Modificacion de accesos")
                MsgBox("Information Saved Successfully", vbInformation, "Notice")
            Else
                MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        '' GUARDAR ACCESOS
        If LogBorrar Then
            For Each row As DataGridViewRow In dgvPermisosDisponibles.Rows
                Dim codigoPrograma As Integer = Convert.ToInt32(row.Cells("pro_codigo").Value)
                Dim query As String = "DELETE FROM Accesos WHERE seg_sisemp= " & Sesion.IdEmpresa & " AND seg_programa = " & codigoPrograma & " AND seg_usuario = '" & celdaUsuario.Text & "'"

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(query, CON)
                REA = COM.ExecuteReader
                CON.Close()
                REA.Close()
                COM.Connection.Close()
            Next
        End If

        If logEditar Or logInsertar Then
            For Each row As DataGridViewRow In dgvPermisosAsignados.Rows
                Dim codigoPrograma As Integer = Convert.ToInt32(row.Cells("a_pro_codigo").Value)
                Dim inserta As String = row.Cells("seg_insertar").Value.ToString()
                Dim edita As String = row.Cells("seg_editar").Value.ToString()
                Dim borra As String = row.Cells("seg_borrar").Value.ToString()
                Dim consulta As String = row.Cells("seg_buscar").Value.ToString()

                ' Conectar a la base de datos y verificar si el registro existe
                Dim query As String = "SELECT COUNT(*) existe FROM Accesos WHERE seg_sisemp=" & Sesion.IdEmpresa & " AND seg_programa = " & codigoPrograma & " AND seg_usuario = '" & celdaUsuario.Text & "'"
                Dim recordExists As Integer = 0

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(query, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        recordExists = REA.GetInt32("existe")
                    Loop
                End If
                CON.Close()
                REA.Close()
                COM.Connection.Close()


                ' Insertar o actualizar según corresponda
                If recordExists > 0 Then
                    query = "UPDATE Accesos SET seg_insertar = '" & inserta & "', seg_editar = '" & edita & "', seg_borrar = '" & borra & "', seg_buscar = '" & consulta & "' WHERE seg_sisemp=" & Sesion.IdEmpresa & " AND seg_programa = " & codigoPrograma & " AND seg_usuario = '" & celdaUsuario.Text & "'"
                Else
                    query = "INSERT INTO Accesos (seg_sisemp, seg_usuario, seg_programa, seg_insertar, seg_editar, seg_borrar, seg_buscar) VALUES (" & Sesion.IdEmpresa & ", '" & celdaUsuario.Text & "', " & codigoPrograma & ", '" & inserta & "', '" & edita & "', '" & borra & "', '" & consulta & "')"
                End If

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(query, CON)
                REA = COM.ExecuteReader
                CON.Close()
                REA.Close()
                COM.Connection.Close()
            Next
        End If

    End Sub
    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = True
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            ' Conectar a la base de datos y verificar si el registro existe
            Dim query As String = "SELECT COUNT(*) existe FROM Personal WHERE per_sisemp=" & Sesion.IdEmpresa & " AND per_usuario = '" & celdaUsuario.Text & "';"
            Dim recordExists As Integer = 0

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(query, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    recordExists = REA.GetInt32("existe")
                Loop
            End If
            CON.Close()
            REA.Close()
            COM.Connection.Close()

            ' Insertar o actualizar según corresponda
            If recordExists > 0 Then
                query = "UPDATE Personal SET {clave}per_nombre1='" & celdaPrimerNombre.Text & "', per_nombre2='" & celdaSegundoNombre.Text & "' , per_apellido1='" & celdaPrimerApellido.Text & "', per_apellido2='" & celdaSegundoApellido.Text & "', per_correo='" & celdaCorreo.Text & "', per_fecha='" & dtpFecha.Value.ToString(FORMATO_MYSQL) & "', per_estado=" & If(checkActivar.Checked, 1, 0) & " WHERE per_sisemp= " & Sesion.IdEmpresa & " AND per_codigo=" & celdaIdUsuario.Text
                If celdaContraseña.Text = STR_ASTERISCO Then
                    query = Replace(query, "{clave}", STR_VACIO)
                Else
                    query = Replace(query, "{clave}", " per_clave=md5('" & celdaContraseña.Text & "'), ")
                End If
            Else
                If chkCopiarAccesos.Checked Then
                    query = " INSERT INTO Accesos
                                SELECT seg_sisemp, '" & celdaUsuario.Text & "', seg_programa, seg_insertar, seg_editar, seg_borrar, seg_buscar
                                FROM Accesos WHERE seg_usuario LIKE '" & celdaUsuarioOriginal.Text & "' AND seg_sisemp=" & Sesion.IdEmpresa & " AND seg_programa IN (SELECT seg_programa FROM Accesos 
                                WHERE seg_usuario IN ('" & celdaUsuario.Text & "','" & celdaUsuarioOriginal.Text & "')  AND seg_sisemp=" & Sesion.IdEmpresa & "
                                GROUP BY seg_programa
                                HAVING COUNT(seg_usuario)<2 
                                ORDER BY seg_programa);"
                Else
                    query = "INSERT INTO Personal(per_sisemp,per_codigo, per_usuario , per_clave , per_nombre1 , per_nombre2 , per_apellido1 , per_apellido2 , per_correo , per_fecha, per_estado) VALUES (" & Sesion.IdEmpresa & ", " & nuevoCodigo() & ", '" & celdaUsuario.Text & "', MD5('" & celdaContraseña.Text & "'), '" & celdaPrimerNombre.Text & "', '" & celdaSegundoNombre.Text & "', '" & celdaPrimerApellido.Text & "', '" & celdaSegundoApellido.Text & "', '" & celdaCorreo.Text & "', '" & dtpFecha.Value.ToString(FORMATO_MYSQL) & "',1); "
                End If

            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(query, CON)
            REA = COM.ExecuteReader
            CON.Close()
            REA.Close()
            COM.Connection.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function nuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim numero As Integer

        strSQL = " Select IFNULL(MAX(p.per_codigo),0)+1 NUMERO  "
        strSQL &= " FROM Personal p"
        strSQL &= " WHERE p.per_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        numero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return numero
    End Function
#End Region

#Region "Eventos"
    Private Sub frmPedidoProduccionHilo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        dgvPermisosAsignados.Rows.Clear()
        dgvPermisosDisponibles.Rows.Clear()
    End Sub
    Private Sub frmPedidoProduccionHilo_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        Me.Close()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo

        If logInsertar Or logEditar Then
            dgvPermisosAsignados.Rows.Clear()
            dgvPermisosDisponibles.Rows.Clear()
            celdaIdUsuario.Text = STR_VACIO
            celdaUsuario.Text = STR_VACIO
            celdaPrimerNombre.Text = STR_VACIO
            celdaSegundoNombre.Text = STR_VACIO
            celdaPrimerApellido.Text = STR_VACIO
            celdaSegundoApellido.Text = STR_VACIO
            celdaCorreo.Text = STR_VACIO
            celdaIdPuesto.Text = STR_VACIO
            celdaPuesto.Text = STR_VACIO
            dtpFecha.Value = Now() ' .ToString("dd-mm-yyyy") ' MYSQL_HOY.ToString()
            celdaContraseña.Text = STR_VACIO
            cargardgv()
        End If
    End Sub

    Private Sub btnPuesto_Click(sender As Object, e As EventArgs) Handles btnPuesto.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Puesto"
            frm.Campos = " pue_codigo codigo, pue_descripcion descripcion"
            frm.Tabla = " Puestos"
            frm.FiltroText = " Ingrese puesto"
            frm.Filtro = " pue_descripcion "
            frm.Condicion = "pue_sisemp=" & Sesion.IdEmpresa
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdPuesto.Text = frm.LLave
                celdaPuesto.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgvPermisosDisponibles.KeyDown, dgvPermisosAsignados.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                Dim dgv As DataGridView = CType(sender, DataGridView)
                cfun.BuscarenLista(dgv)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub chkCopiarAccesos_CheckedChanged(sender As Object, e As EventArgs) Handles chkCopiarAccesos.CheckedChanged
        If chkCopiarAccesos.Checked Then
            If PermisoCopiar() Then
                Panel1.Visible = False
                panelUsuarioOriginal.Visible = True
            Else
                Panel1.Visible = True
                panelUsuarioOriginal.Visible = False
                chkCopiarAccesos.Checked = False
            End If
        Else
            Panel1.Visible = True
            panelUsuarioOriginal.Visible = False
            chkCopiarAccesos.Checked = False
        End If

    End Sub
    Private Function PermisoCopiar() As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "copiar"
        Dim frm As New frmAutorización
        frm.Iniciar(687, STR_MARGEN, 0, "copiar")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                Return True
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                Return False
            End If
        End If
        Return False
    End Function
#End Region


End Class