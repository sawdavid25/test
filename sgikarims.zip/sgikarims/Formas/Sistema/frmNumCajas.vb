﻿Public Class frmNumCajas

#Region "Miembros"

    Dim intFila As Integer
    Dim strKey As String = STR_VACIO

    Private strBoxes As String

    Public intnumero As Integer
    Public intano As Integer

#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return intnumero
        End Get
        Set(value As Integer)
            intnumero = value
        End Set
    End Property

    Public Property Año As Integer
        Get
            Return intano
        End Get
        Set(value As Integer)
            intano = value
        End Set
    End Property

#End Region
    'Query que carga Listado de Cajas
    Private Function SQLlista(ByVal intano As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT BDoc_Box_Lin, BDoc_Box_Cod, BDoc_Box_QTY, BDoc_Box_LB, BDoc_Sis_Emp, BDoc_Doc_Cat, BDoc_Doc_Ano, BDoc_Doc_Num, BDoc_Doc_Lin"
        strsql &= " FROM Dcmtos_DTL_Box"
        strsql &= "   WHERE BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = 36 AND BDoc_Doc_Ano = {año} AND BDoc_Doc_Num = {numero} AND BDoc_Doc_Lin = {fila}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intano)
        strsql = Replace(strsql, "{numero}", intnumero)
        strsql = Replace(strsql, "{fila}", (intFila + 1))

        Return strsql

    End Function


    'Query que carga las Instrucciones de Despacho
    Public Sub CargarListaCajas(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLlista(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read

                    strBoxes &= REA.GetInt32("BDoc_Box_Lin") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Box_Cod") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Box_QTY") & "|"
                    strBoxes &= REA.GetDouble("BDoc_Box_LB") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Sis_Emp") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Doc_Cat") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Doc_Ano") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Doc_Num") & "|"
                    strBoxes &= REA.GetInt32("BDoc_Doc_Lin")

                    cFunciones.AgregarFila(dgLista, strBoxes)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub



    Private Sub frmNumCajas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            CargarListaCajas(intano, intnumero)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgLista_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgLista.CellContentClick

    End Sub
End Class