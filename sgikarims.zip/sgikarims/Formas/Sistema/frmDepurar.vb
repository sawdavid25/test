﻿Public Class frmDepurar
    Dim strkey As String = STR_VACIO

    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

    Private Sub frmDepurar_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cDepurar As New clsDepurar
        'cDepurar.CambiaraCajaChicha()
    End Sub

    Private Sub btonFacturas_Click(sender As Object, e As EventArgs) Handles btonFacturas.Click
        Dim strsql As String = STR_VACIO
        Dim cone As MySqlConnection
        Dim cone2 As MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim rea2 As MySqlDataReader
        Dim ITM As New ListViewItem
        Dim intNumero As Integer = NO_FILA
        Dim intCat As Integer = NO_FILA
        Dim intAno As Integer = NO_FILA
        Try
            cone = New MySqlConnection(strConexion)
            cone.Open()
            strsql = "select h.HDoc_Doc_Num , h.HDoc_Doc_Fec , h.HDoc_Doc_TC , sum((dt.DDoc_Prd_NET * dt.DDoc_Prd_QTY))totalD," & _
                " sum((h.HDoc_Doc_TC * dt.DDoc_Prd_NET * dt.DDoc_Prd_QTY)) totalQ, " & _
                " h.HDoc_Doc_Ano, h.HDoc_Doc_Cat" & _
                " from Dcmtos_HDR h " & _
                "   left join Dcmtos_DTL dt on dt.DDoc_Sis_Emp = h.HDoc_Sis_Emp and" & _
                "       dt.DDoc_Doc_Cat = h.HDoc_Doc_Cat and dt.DDoc_Doc_Ano = h.HDoc_Doc_Ano 	" & _
                "       and dt.DDoc_Doc_Num = h.HDoc_Doc_Num " & _
                " where h.HDoc_Sis_Emp = 3 and h.HDoc_Doc_Cat = 36  and h.HDoc_Doc_Ano = 2014 and h.HDoc_Doc_Status  = 1" & _
                " group by h.HDoc_Doc_Num"

            COM = New MySqlCommand(strsql, cone)
            REA = COM.ExecuteReader
            If REA.HasRows = False Then
                Exit Sub
            End If
            Do While REA.Read
                intNumero = REA.GetInt32("HDoc_Doc_Num")
                intAno = REA.GetInt32("HDoc_Doc_Ano")
                intCat = REA.GetInt32("HDoc_Doc_Cat")
                ITM = lvData.Items.Add(intNumero)
                ITM.SubItems.Add(REA.GetMySqlDateTime("HDoc_Doc_Fec").ToString)
                ITM.SubItems.Add(REA.GetDouble("HDoc_Doc_TC").ToString)
                ITM.SubItems.Add(REA.GetDouble("totalD").ToString)
                ITM.SubItems.Add(REA.GetDouble("totalQ").ToString)
                strsql = STR_VACIO
                strsql = " select p.poliza , p.tasa, (sum(d.importe)/2) imp  " & _
                    " from conta.polizas p" & _
                    "   left join conta.detalle_polizas d on p.empresa = d.empresa and " & _
                    "      p.ejercicio = d.ejercicio and p.poliza = d.poliza" & _
                    " where p.ref_tipo = {cat} and p.ref_ciclo = {año} and p.ref_numero = " & _
                    "   {numero} and p.empresa = 3 and p.ejercicio = 7 and p.tipo = 9" & _
                    " group by p.poliza "
                strsql = Replace(strsql, "{cat}", intCat)
                strsql = Replace(strsql, "{año}", intAno)
                strsql = Replace(strsql, "{numero}", intNumero)
                cone2 = New MySqlConnection(strConexion)
                cone2.Open()
                COM = New MySqlCommand(strsql, cone2)
                rea2 = COM.ExecuteReader
                Do While rea2.Read
                    ITM.SubItems.Add(rea2.GetInt32("poliza"))
                    ITM.SubItems.Add(rea2.GetDouble("tasa"))
                    ITM.SubItems.Add(rea2.GetDouble("imp"))
                Loop
                cone2.Close()
            Loop
            cone.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            REA = Nothing
            rea2 = Nothing
        End Try
    End Sub

End Class