﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporteOrdenesDeCompra
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.celdaFabricante = New System.Windows.Forms.TextBox()
        Me.botonFabricante = New System.Windows.Forms.Button()
        Me.rbConSaldo = New System.Windows.Forms.RadioButton()
        Me.rbSinSaldo = New System.Windows.Forms.RadioButton()
        Me.rbIncluirTodo = New System.Windows.Forms.RadioButton()
        Me.checkResumen = New System.Windows.Forms.CheckBox()
        Me.checkHeathers = New System.Windows.Forms.CheckBox()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechaInicial = New System.Windows.Forms.Label()
        Me.etiquetaFechaFinal = New System.Windows.Forms.Label()
        Me.rbProveedor = New System.Windows.Forms.RadioButton()
        Me.rbFabricante = New System.Windows.Forms.RadioButton()
        Me.rbProducto = New System.Windows.Forms.RadioButton()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.etiquetaFabricante = New System.Windows.Forms.Label()
        Me.etiquetaPaisOrigen = New System.Windows.Forms.Label()
        Me.celdaPaisOrigen = New System.Windows.Forms.TextBox()
        Me.botonPaisOrigen = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaIDPaisOrigen = New System.Windows.Forms.TextBox()
        Me.celdaIDProducto = New System.Windows.Forms.TextBox()
        Me.celdaIDProveedor = New System.Windows.Forms.TextBox()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'celdaFabricante
        '
        Me.celdaFabricante.Location = New System.Drawing.Point(6, 40)
        Me.celdaFabricante.Name = "celdaFabricante"
        Me.celdaFabricante.Size = New System.Drawing.Size(415, 20)
        Me.celdaFabricante.TabIndex = 0
        '
        'botonFabricante
        '
        Me.botonFabricante.Location = New System.Drawing.Point(447, 40)
        Me.botonFabricante.Name = "botonFabricante"
        Me.botonFabricante.Size = New System.Drawing.Size(33, 20)
        Me.botonFabricante.TabIndex = 1
        Me.botonFabricante.Text = "..."
        Me.botonFabricante.UseVisualStyleBackColor = True
        '
        'rbConSaldo
        '
        Me.rbConSaldo.AutoSize = True
        Me.rbConSaldo.Checked = True
        Me.rbConSaldo.Location = New System.Drawing.Point(41, 19)
        Me.rbConSaldo.Name = "rbConSaldo"
        Me.rbConSaldo.Size = New System.Drawing.Size(89, 17)
        Me.rbConSaldo.TabIndex = 6
        Me.rbConSaldo.TabStop = True
        Me.rbConSaldo.Text = "With Balance"
        Me.rbConSaldo.UseVisualStyleBackColor = True
        '
        'rbSinSaldo
        '
        Me.rbSinSaldo.AutoSize = True
        Me.rbSinSaldo.Location = New System.Drawing.Point(41, 42)
        Me.rbSinSaldo.Name = "rbSinSaldo"
        Me.rbSinSaldo.Size = New System.Drawing.Size(134, 17)
        Me.rbSinSaldo.TabIndex = 7
        Me.rbSinSaldo.TabStop = True
        Me.rbSinSaldo.Text = "Not Balance(canceled)"
        Me.rbSinSaldo.UseVisualStyleBackColor = True
        '
        'rbIncluirTodo
        '
        Me.rbIncluirTodo.AutoSize = True
        Me.rbIncluirTodo.Location = New System.Drawing.Point(41, 65)
        Me.rbIncluirTodo.Name = "rbIncluirTodo"
        Me.rbIncluirTodo.Size = New System.Drawing.Size(74, 17)
        Me.rbIncluirTodo.TabIndex = 8
        Me.rbIncluirTodo.TabStop = True
        Me.rbIncluirTodo.Text = "Include All"
        Me.rbIncluirTodo.UseVisualStyleBackColor = True
        '
        'checkResumen
        '
        Me.checkResumen.AutoSize = True
        Me.checkResumen.Location = New System.Drawing.Point(197, 19)
        Me.checkResumen.Name = "checkResumen"
        Me.checkResumen.Size = New System.Drawing.Size(69, 17)
        Me.checkResumen.TabIndex = 9
        Me.checkResumen.Text = "Summary"
        Me.checkResumen.UseVisualStyleBackColor = True
        '
        'checkHeathers
        '
        Me.checkHeathers.AutoSize = True
        Me.checkHeathers.Location = New System.Drawing.Point(197, 43)
        Me.checkHeathers.Name = "checkHeathers"
        Me.checkHeathers.Size = New System.Drawing.Size(93, 17)
        Me.checkHeathers.TabIndex = 12
        Me.checkHeathers.Text = "Only Heathers"
        Me.checkHeathers.UseVisualStyleBackColor = True
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(106, 28)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(83, 20)
        Me.dtpFechaInicial.TabIndex = 14
        Me.dtpFechaInicial.Value = New Date(2017, 1, 1, 8, 31, 0, 0)
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(280, 29)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(91, 20)
        Me.dtpFechaFinal.TabIndex = 15
        Me.dtpFechaFinal.Value = New Date(2017, 3, 3, 8, 31, 0, 0)
        '
        'etiquetaFechaInicial
        '
        Me.etiquetaFechaInicial.AutoSize = True
        Me.etiquetaFechaInicial.Location = New System.Drawing.Point(52, 34)
        Me.etiquetaFechaInicial.Name = "etiquetaFechaInicial"
        Me.etiquetaFechaInicial.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaFechaInicial.TabIndex = 16
        Me.etiquetaFechaInicial.Text = "Initial"
        '
        'etiquetaFechaFinal
        '
        Me.etiquetaFechaFinal.AutoSize = True
        Me.etiquetaFechaFinal.Location = New System.Drawing.Point(239, 34)
        Me.etiquetaFechaFinal.Name = "etiquetaFechaFinal"
        Me.etiquetaFechaFinal.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaFechaFinal.TabIndex = 17
        Me.etiquetaFechaFinal.Text = "Final"
        '
        'rbProveedor
        '
        Me.rbProveedor.AutoSize = True
        Me.rbProveedor.Checked = True
        Me.rbProveedor.Location = New System.Drawing.Point(12, 19)
        Me.rbProveedor.Name = "rbProveedor"
        Me.rbProveedor.Size = New System.Drawing.Size(64, 17)
        Me.rbProveedor.TabIndex = 18
        Me.rbProveedor.TabStop = True
        Me.rbProveedor.Text = "Provider"
        Me.rbProveedor.UseVisualStyleBackColor = True
        '
        'rbFabricante
        '
        Me.rbFabricante.AutoSize = True
        Me.rbFabricante.Location = New System.Drawing.Point(106, 19)
        Me.rbFabricante.Name = "rbFabricante"
        Me.rbFabricante.Size = New System.Drawing.Size(52, 17)
        Me.rbFabricante.TabIndex = 19
        Me.rbFabricante.TabStop = True
        Me.rbFabricante.Text = "Make"
        Me.rbFabricante.UseVisualStyleBackColor = True
        '
        'rbProducto
        '
        Me.rbProducto.AutoSize = True
        Me.rbProducto.Location = New System.Drawing.Point(208, 19)
        Me.rbProducto.Name = "rbProducto"
        Me.rbProducto.Size = New System.Drawing.Size(62, 17)
        Me.rbProducto.TabIndex = 20
        Me.rbProducto.TabStop = True
        Me.rbProducto.Text = "Product"
        Me.rbProducto.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(187, 423)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 23)
        Me.botonAceptar.TabIndex = 21
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(292, 423)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.botonCancelar.TabIndex = 22
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'etiquetaFabricante
        '
        Me.etiquetaFabricante.AutoSize = True
        Me.etiquetaFabricante.Location = New System.Drawing.Point(9, 24)
        Me.etiquetaFabricante.Name = "etiquetaFabricante"
        Me.etiquetaFabricante.Size = New System.Drawing.Size(37, 13)
        Me.etiquetaFabricante.TabIndex = 23
        Me.etiquetaFabricante.Text = "Maker"
        '
        'etiquetaPaisOrigen
        '
        Me.etiquetaPaisOrigen.AutoSize = True
        Me.etiquetaPaisOrigen.Location = New System.Drawing.Point(9, 108)
        Me.etiquetaPaisOrigen.Name = "etiquetaPaisOrigen"
        Me.etiquetaPaisOrigen.Size = New System.Drawing.Size(87, 13)
        Me.etiquetaPaisOrigen.TabIndex = 25
        Me.etiquetaPaisOrigen.Text = "Country Of Origin"
        '
        'celdaPaisOrigen
        '
        Me.celdaPaisOrigen.Location = New System.Drawing.Point(6, 124)
        Me.celdaPaisOrigen.Name = "celdaPaisOrigen"
        Me.celdaPaisOrigen.Size = New System.Drawing.Size(415, 20)
        Me.celdaPaisOrigen.TabIndex = 26
        '
        'botonPaisOrigen
        '
        Me.botonPaisOrigen.Location = New System.Drawing.Point(447, 121)
        Me.botonPaisOrigen.Name = "botonPaisOrigen"
        Me.botonPaisOrigen.Size = New System.Drawing.Size(33, 23)
        Me.botonPaisOrigen.TabIndex = 27
        Me.botonPaisOrigen.Text = "..."
        Me.botonPaisOrigen.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaIDPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaIDProducto)
        Me.GroupBox1.Controls.Add(Me.celdaIDProveedor)
        Me.GroupBox1.Controls.Add(Me.etiquetaProducto)
        Me.GroupBox1.Controls.Add(Me.botonProducto)
        Me.GroupBox1.Controls.Add(Me.botonPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaProducto)
        Me.GroupBox1.Controls.Add(Me.etiquetaPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaFabricante)
        Me.GroupBox1.Controls.Add(Me.botonFabricante)
        Me.GroupBox1.Controls.Add(Me.etiquetaFabricante)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(491, 162)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Orders By"
        '
        'celdaIDPaisOrigen
        '
        Me.celdaIDPaisOrigen.Location = New System.Drawing.Point(118, 105)
        Me.celdaIDPaisOrigen.Name = "celdaIDPaisOrigen"
        Me.celdaIDPaisOrigen.Size = New System.Drawing.Size(29, 20)
        Me.celdaIDPaisOrigen.TabIndex = 30
        Me.celdaIDPaisOrigen.Text = "-1"
        Me.celdaIDPaisOrigen.Visible = False
        '
        'celdaIDProducto
        '
        Me.celdaIDProducto.Location = New System.Drawing.Point(118, 62)
        Me.celdaIDProducto.Name = "celdaIDProducto"
        Me.celdaIDProducto.Size = New System.Drawing.Size(29, 20)
        Me.celdaIDProducto.TabIndex = 13
        Me.celdaIDProducto.Text = "-1"
        Me.celdaIDProducto.Visible = False
        '
        'celdaIDProveedor
        '
        Me.celdaIDProveedor.Location = New System.Drawing.Point(118, 17)
        Me.celdaIDProveedor.Name = "celdaIDProveedor"
        Me.celdaIDProveedor.Size = New System.Drawing.Size(29, 20)
        Me.celdaIDProveedor.TabIndex = 29
        Me.celdaIDProveedor.Text = "-1"
        Me.celdaIDProveedor.Visible = False
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(9, 69)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaProducto.TabIndex = 28
        Me.etiquetaProducto.Text = "Product"
        '
        'botonProducto
        '
        Me.botonProducto.Location = New System.Drawing.Point(447, 85)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(33, 23)
        Me.botonProducto.TabIndex = 26
        Me.botonProducto.Text = "..."
        Me.botonProducto.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.Location = New System.Drawing.Point(6, 85)
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.Size = New System.Drawing.Size(415, 20)
        Me.celdaProducto.TabIndex = 25
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbConSaldo)
        Me.GroupBox2.Controls.Add(Me.rbSinSaldo)
        Me.GroupBox2.Controls.Add(Me.rbIncluirTodo)
        Me.GroupBox2.Controls.Add(Me.checkResumen)
        Me.GroupBox2.Controls.Add(Me.checkHeathers)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 180)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(491, 94)
        Me.GroupBox2.TabIndex = 30
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Additional options"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.dtpFechaFinal)
        Me.GroupBox3.Controls.Add(Me.dtpFechaInicial)
        Me.GroupBox3.Controls.Add(Me.etiquetaFechaInicial)
        Me.GroupBox3.Controls.Add(Me.etiquetaFechaFinal)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 280)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(491, 69)
        Me.GroupBox3.TabIndex = 31
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Date Range"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.rbProveedor)
        Me.GroupBox4.Controls.Add(Me.rbFabricante)
        Me.GroupBox4.Controls.Add(Me.rbProducto)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 355)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(491, 62)
        Me.GroupBox4.TabIndex = 32
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Select Orders By "
        '
        'frmReporteOrdenesDeCompra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(514, 461)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Name = "frmReporteOrdenesDeCompra"
        Me.Text = "frmReporteOrdenesDeCompra"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents celdaFabricante As TextBox
    Friend WithEvents botonFabricante As Button
    Friend WithEvents rbConSaldo As RadioButton
    Friend WithEvents rbSinSaldo As RadioButton
    Friend WithEvents rbIncluirTodo As RadioButton
    Friend WithEvents checkResumen As System.Windows.Forms.CheckBox
    Friend WithEvents checkHeathers As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents etiquetaFechaInicial As Label
    Friend WithEvents etiquetaFechaFinal As Label
    Friend WithEvents rbProveedor As RadioButton
    Friend WithEvents rbFabricante As RadioButton
    Friend WithEvents rbProducto As RadioButton
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonCancelar As Button
    Friend WithEvents etiquetaFabricante As Label
    Friend WithEvents etiquetaPaisOrigen As Label
    Friend WithEvents celdaPaisOrigen As TextBox
    Friend WithEvents botonPaisOrigen As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents etiquetaProducto As Label
    Friend WithEvents botonProducto As Button
    Friend WithEvents celdaProducto As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents celdaIDProveedor As TextBox
    Friend WithEvents celdaIDProducto As TextBox
    Friend WithEvents celdaIDPaisOrigen As TextBox
End Class
