﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmXPresupuesto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelPrincipal = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colTransaccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.PanelFinal = New System.Windows.Forms.Panel()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.CeldaTotal = New System.Windows.Forms.TextBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.PanelPrincipal.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.PanelFinal.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelPrincipal
        '
        Me.PanelPrincipal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelPrincipal.Controls.Add(Me.dgDetalle)
        Me.PanelPrincipal.Location = New System.Drawing.Point(0, 0)
        Me.PanelPrincipal.Name = "PanelPrincipal"
        Me.PanelPrincipal.Size = New System.Drawing.Size(422, 257)
        Me.PanelPrincipal.TabIndex = 0
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colTransaccion, Me.colCuenta, Me.colNombre, Me.colMonto, Me.colOperacion})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(422, 257)
        Me.dgDetalle.TabIndex = 0
        '
        'colTransaccion
        '
        Me.colTransaccion.HeaderText = "Transaccion"
        Me.colTransaccion.Name = "colTransaccion"
        Me.colTransaccion.Visible = False
        '
        'colCuenta
        '
        Me.colCuenta.HeaderText = "Account"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.Visible = False
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 70
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        '
        'colOperacion
        '
        Me.colOperacion.HeaderText = "Operacion"
        Me.colOperacion.Name = "colOperacion"
        Me.colOperacion.Visible = False
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Controls.Add(Me.botonQuitar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(423, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(91, 257)
        Me.panelBotones.TabIndex = 1
        '
        'botonAgregar
        '
        Me.botonAgregar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(30, 77)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(35, 31)
        Me.botonAgregar.TabIndex = 41
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(30, 146)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(35, 30)
        Me.botonQuitar.TabIndex = 40
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'PanelFinal
        '
        Me.PanelFinal.Controls.Add(Me.etiquetaTotal)
        Me.PanelFinal.Controls.Add(Me.CeldaTotal)
        Me.PanelFinal.Controls.Add(Me.botonCerrar)
        Me.PanelFinal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelFinal.Location = New System.Drawing.Point(0, 257)
        Me.PanelFinal.Name = "PanelFinal"
        Me.PanelFinal.Size = New System.Drawing.Size(514, 80)
        Me.PanelFinal.TabIndex = 1
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.BackColor = System.Drawing.SystemColors.Control
        Me.etiquetaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotal.ForeColor = System.Drawing.SystemColors.Highlight
        Me.etiquetaTotal.Location = New System.Drawing.Point(12, 37)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(57, 20)
        Me.etiquetaTotal.TabIndex = 2
        Me.etiquetaTotal.Text = "Total:"
        '
        'CeldaTotal
        '
        Me.CeldaTotal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTotal.BackColor = System.Drawing.Color.WhiteSmoke
        Me.CeldaTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.CeldaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotal.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.CeldaTotal.Location = New System.Drawing.Point(91, 37)
        Me.CeldaTotal.Multiline = True
        Me.CeldaTotal.Name = "CeldaTotal"
        Me.CeldaTotal.Size = New System.Drawing.Size(288, 26)
        Me.CeldaTotal.TabIndex = 1
        Me.CeldaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Location = New System.Drawing.Point(406, 28)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(87, 35)
        Me.botonCerrar.TabIndex = 0
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'frmXPresupuesto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(514, 337)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.PanelFinal)
        Me.Controls.Add(Me.PanelPrincipal)
        Me.Name = "frmXPresupuesto"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmXPresupuesto"
        Me.PanelPrincipal.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.PanelFinal.ResumeLayout(False)
        Me.PanelFinal.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelPrincipal As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents PanelFinal As System.Windows.Forms.Panel
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents CeldaTotal As System.Windows.Forms.TextBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents colTransaccion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCuenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOperacion As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
