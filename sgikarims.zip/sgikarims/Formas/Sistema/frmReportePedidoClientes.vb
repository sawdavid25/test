﻿Public Class frmReportePedidoClientes

#Region "Variables"
    Dim IntSeleccionClientes As Integer
    Dim IntCliente As Integer
    Dim IntProducto As Integer
    Dim IntPaisOrigen As Integer
    Dim IntOpciones As Integer
    Dim LogResumen As Boolean
    Dim LogHeathers As Boolean
    Dim LogFecha As Boolean
    Dim LogTotal As Boolean
    Dim dtFechaInicio As Date
    Dim dtFechaFin As Date
    Dim intOpcionLineas As Integer
#End Region

#Region "Propiedades"

    Public ReadOnly Property TipoDeCliente As Integer
        Get
            Return IntSeleccionClientes
        End Get
    End Property

    Public ReadOnly Property IDCliente As Integer
        Get
            Return IntCliente
        End Get
    End Property

    Public ReadOnly Property Cod_Producto As Integer
        Get
            Return IntProducto
        End Get
    End Property

    Public ReadOnly Property Cod_PaisOrigen As Integer
        Get
            Return IntPaisOrigen
        End Get
    End Property

    Public ReadOnly Property Opciones As Integer
        Get
            Return IntOpciones
        End Get
    End Property

    Public ReadOnly Property Pos_Resumen As Boolean
        Get
            Return LogResumen
        End Get
    End Property

    Public ReadOnly Property Pos_FechaEntrega As Boolean
        Get
            Return LogFecha
        End Get
    End Property

    Public ReadOnly Property Pos_Heathers As Boolean
        Get
            Return LogHeathers
        End Get
    End Property

    Public ReadOnly Property Pos_TotalSub As Boolean
        Get
            Return LogTotal
        End Get
    End Property

    Public ReadOnly Property SeleccionFechaInicial As Date
        Get
            Return dtFechaInicio
        End Get
    End Property

    Public ReadOnly Property SeleccionFechaFinal As Date
        Get
            Return dtFechaFin
        End Get
    End Property

    Public ReadOnly Property OpcionesLineas As Integer
        Get
            Return intOpcionLineas
        End Get
    End Property
#End Region

#Region "Eventos"

    Private Sub frmReportepedidoClientes_load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpFechaInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 3, 1)
        dtpFechaFin.Value = Today

    End Sub


    Private Sub botonClienteSolicitante_Click(sender As Object, e As EventArgs) Handles botonClienteSolicitante.Click
        Dim frm As New frmSeleccionar
        'Propiedades de Consulta
        frm.Campos = "cli_codigo Code, cli_cliente Client"
        frm.Tabla = " Clientes"
        frm.Condicion = " cli_sisemp= " & Sesion.IdEmpresa & ""
        frm.Filtro = "cli_cliente"
        frm.Limite = "20"

        'Propiedades del Formulario 
        frm.Titulo = "Customers"
        frm.FiltroText = " Enter the Customer Name to filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIDClienteSolicitante.Text = frm.LLave
            celdaClienteSolicitante.Text = frm.Dato
        End If
    End Sub

    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click
        Dim frm As New frmSeleccionar
        'Propiedades de consulta
        frm.Campos = " art_codigo ID, art_DCorta ShortDescription"
        frm.Tabla = " Articulos "
        frm.Condicion = " art_sisemp= " & Sesion.IdEmpresa & ""
        frm.Filtro = " art_DCorta "
        frm.Limite = " 20 "

        'Propiedades de Formulario
        frm.Titulo = " Articles"
        frm.FiltroText = " Enter Item Name to filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdProducto.Text = frm.LLave
            celdaProducto.Text = frm.Dato
        End If
    End Sub

    Private Sub botonPaisOrigen_Click(sender As Object, e As EventArgs) Handles botonPaisOrigen.Click
        Dim frm As New frmSeleccionar

        ' Propiedades de consulta 
        frm.Campos = " cat_num ID , cat_desc Description "
        frm.Tabla = " Catalogos "
        frm.Condicion = " cat_clase = 'paises' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the country to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaIdPaisOrigen.Text = frm.LLave
            celdaPaisOrigen.Text = frm.Dato

        End If

    End Sub

    Private Sub botonAcept_Click_1(sender As Object, e As EventArgs) Handles botonAcept.Click
        Try
            If rbCliente.Checked = True Then
                IntSeleccionClientes = 0
            ElseIf rbSolicitante.Checked = True Then
                IntSeleccionClientes = 1
            End If

            IntCliente = CInt(celdaIDClienteSolicitante.Text)
            IntProducto = CInt(celdaIdProducto.Text)

            IntPaisOrigen = CInt(celdaIdPaisOrigen.Text)

            If rbConSaldo.Checked = True Then
                IntOpciones = 0
            ElseIf rbSinSaldo.Checked = True Then
                IntOpciones = 1
            ElseIf rbIncluirTodo.Checked = True Then
                IntOpciones = 2
            End If


            If checkResumen.Checked = True Then
                LogResumen = True
            Else
                LogResumen = False
            End If

            If checkFechaEntrega.Checked = True Then
                LogFecha = True
            Else
                LogFecha = False
            End If


            If checkHeathers.Checked = True Then
                LogHeathers = True
            Else
                LogHeathers = False
            End If

            If checkTotalSub.Checked = True Then
                LogTotal = True
            Else
                LogTotal = False
            End If

            dtFechaInicio = dtpFechaInicio.Value
            dtFechaFin = dtpFechaFin.Value

            If rbActiveLines.Checked = True Then
                intOpcionLineas = 0
            ElseIf rbCanceledLines.Checked = True Then
                intOpcionLineas = 1
            ElseIf rbAllLines.Checked = True Then
                intOpcionLineas = 2
            End If

            Me.DialogResult = DialogResult.OK

        Catch ex As Exception
            MsgBox(e.ToString)
        End Try
    End Sub

    Private Sub botonCancel_Click_1(sender As Object, e As EventArgs) Handles botonCancel.Click
        Me.Close()
    End Sub

#End Region

    Private Sub checkTotalSub_CheckedChanged(sender As Object, e As EventArgs) Handles checkTotalSub.CheckedChanged

    End Sub

    Private Sub checkHeathers_CheckedChanged(sender As Object, e As EventArgs) Handles checkHeathers.CheckedChanged

    End Sub
End Class