﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEquiposVentas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.panelGrupos = New System.Windows.Forms.Panel()
        Me.dgListaGrupos = New System.Windows.Forms.DataGridView()
        Me.panelUsuarios = New System.Windows.Forms.Panel()
        Me.dgListaUsuarios = New System.Windows.Forms.DataGridView()
        Me.panelEquipos = New System.Windows.Forms.Panel()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.etiquetaCode = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.celdaNombreGroup = New System.Windows.Forms.TextBox()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGrupo = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colCodGrupo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTypeGroup = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGroupName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelPrincipal.SuspendLayout()
        Me.panelGrupos.SuspendLayout()
        CType(Me.dgListaGrupos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelUsuarios.SuspendLayout()
        CType(Me.dgListaUsuarios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEquipos.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelPrincipal
        '
        Me.panelPrincipal.Controls.Add(Me.panelGrupos)
        Me.panelPrincipal.Controls.Add(Me.panelUsuarios)
        Me.panelPrincipal.Location = New System.Drawing.Point(0, 133)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(1124, 380)
        Me.panelPrincipal.TabIndex = 2
        '
        'panelGrupos
        '
        Me.panelGrupos.Controls.Add(Me.dgListaGrupos)
        Me.panelGrupos.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelGrupos.Location = New System.Drawing.Point(551, 0)
        Me.panelGrupos.Name = "panelGrupos"
        Me.panelGrupos.Size = New System.Drawing.Size(573, 380)
        Me.panelGrupos.TabIndex = 1
        '
        'dgListaGrupos
        '
        Me.dgListaGrupos.AllowUserToAddRows = False
        Me.dgListaGrupos.AllowUserToDeleteRows = False
        Me.dgListaGrupos.AllowUserToOrderColumns = True
        Me.dgListaGrupos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgListaGrupos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgListaGrupos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaGrupos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCode, Me.colTypeGroup, Me.colGroupName, Me.colDescripcion})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgListaGrupos.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgListaGrupos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaGrupos.Location = New System.Drawing.Point(0, 0)
        Me.dgListaGrupos.Name = "dgListaGrupos"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgListaGrupos.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgListaGrupos.RowTemplate.Height = 24
        Me.dgListaGrupos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaGrupos.Size = New System.Drawing.Size(573, 380)
        Me.dgListaGrupos.TabIndex = 0
        '
        'panelUsuarios
        '
        Me.panelUsuarios.Controls.Add(Me.dgListaUsuarios)
        Me.panelUsuarios.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelUsuarios.Location = New System.Drawing.Point(0, 0)
        Me.panelUsuarios.Name = "panelUsuarios"
        Me.panelUsuarios.Size = New System.Drawing.Size(1124, 380)
        Me.panelUsuarios.TabIndex = 0
        '
        'dgListaUsuarios
        '
        Me.dgListaUsuarios.AllowUserToAddRows = False
        Me.dgListaUsuarios.AllowUserToDeleteRows = False
        Me.dgListaUsuarios.AllowUserToOrderColumns = True
        Me.dgListaUsuarios.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgListaUsuarios.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgListaUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaUsuarios.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colUsuario, Me.colNombre, Me.colGrupo, Me.colCodGrupo, Me.colCodPuesto, Me.colPuesto})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgListaUsuarios.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgListaUsuarios.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaUsuarios.Location = New System.Drawing.Point(0, 0)
        Me.dgListaUsuarios.Name = "dgListaUsuarios"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgListaUsuarios.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgListaUsuarios.RowTemplate.Height = 24
        Me.dgListaUsuarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaUsuarios.Size = New System.Drawing.Size(1124, 380)
        Me.dgListaUsuarios.TabIndex = 0
        '
        'panelEquipos
        '
        Me.panelEquipos.Controls.Add(Me.celdaUsuario)
        Me.panelEquipos.Controls.Add(Me.celdaEmpresa)
        Me.panelEquipos.Controls.Add(Me.celdaTipo)
        Me.panelEquipos.Controls.Add(Me.etiquetaDescripcion)
        Me.panelEquipos.Controls.Add(Me.etiquetaNombre)
        Me.panelEquipos.Controls.Add(Me.etiquetaCode)
        Me.panelEquipos.Controls.Add(Me.celdaDescripcion)
        Me.panelEquipos.Controls.Add(Me.celdaNombreGroup)
        Me.panelEquipos.Controls.Add(Me.celdaCodigo)
        Me.panelEquipos.Location = New System.Drawing.Point(12, 541)
        Me.panelEquipos.Name = "panelEquipos"
        Me.panelEquipos.Size = New System.Drawing.Size(816, 300)
        Me.panelEquipos.TabIndex = 3
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(634, 144)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(58, 22)
        Me.celdaUsuario.TabIndex = 8
        Me.celdaUsuario.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(634, 116)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(58, 22)
        Me.celdaEmpresa.TabIndex = 7
        Me.celdaEmpresa.Visible = False
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(634, 88)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.Size = New System.Drawing.Size(58, 22)
        Me.celdaTipo.TabIndex = 6
        Me.celdaTipo.Visible = False
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(9, 197)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 5
        Me.etiquetaDescripcion.Text = "Description"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(9, 137)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(89, 17)
        Me.etiquetaNombre.TabIndex = 4
        Me.etiquetaNombre.Text = "Group Name"
        '
        'etiquetaCode
        '
        Me.etiquetaCode.AutoSize = True
        Me.etiquetaCode.Location = New System.Drawing.Point(9, 88)
        Me.etiquetaCode.Name = "etiquetaCode"
        Me.etiquetaCode.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaCode.TabIndex = 3
        Me.etiquetaCode.Text = "Code"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(148, 192)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(287, 78)
        Me.celdaDescripcion.TabIndex = 2
        '
        'celdaNombreGroup
        '
        Me.celdaNombreGroup.Location = New System.Drawing.Point(148, 137)
        Me.celdaNombreGroup.Name = "celdaNombreGroup"
        Me.celdaNombreGroup.Size = New System.Drawing.Size(287, 22)
        Me.celdaNombreGroup.TabIndex = 1
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCodigo.ForeColor = System.Drawing.Color.RoyalBlue
        Me.celdaCodigo.Location = New System.Drawing.Point(148, 83)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(135, 22)
        Me.celdaCodigo.TabIndex = 0
        Me.celdaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1162, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1162, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colUsuario
        '
        Me.colUsuario.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        Me.colUsuario.Width = 67
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 74
        '
        'colGrupo
        '
        Me.colGrupo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGrupo.HeaderText = "Group"
        Me.colGrupo.Name = "colGrupo"
        Me.colGrupo.ReadOnly = True
        Me.colGrupo.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colGrupo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colGrupo.Width = 77
        '
        'colCodGrupo
        '
        Me.colCodGrupo.HeaderText = "CodGrupo"
        Me.colCodGrupo.Name = "colCodGrupo"
        Me.colCodGrupo.ReadOnly = True
        Me.colCodGrupo.Visible = False
        '
        'colCodPuesto
        '
        Me.colCodPuesto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodPuesto.HeaderText = "CodPuesto"
        Me.colCodPuesto.Name = "colCodPuesto"
        Me.colCodPuesto.ReadOnly = True
        Me.colCodPuesto.Visible = False
        Me.colCodPuesto.Width = 106
        '
        'colPuesto
        '
        Me.colPuesto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colPuesto.HeaderText = "Puesto"
        Me.colPuesto.Name = "colPuesto"
        Me.colPuesto.ReadOnly = True
        '
        'colCode
        '
        Me.colCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCode.HeaderText = "CodeGroup"
        Me.colCode.Name = "colCode"
        Me.colCode.Visible = False
        Me.colCode.Width = 110
        '
        'colTypeGroup
        '
        Me.colTypeGroup.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTypeGroup.HeaderText = "Type Group"
        Me.colTypeGroup.Name = "colTypeGroup"
        Me.colTypeGroup.Visible = False
        Me.colTypeGroup.Width = 113
        '
        'colGroupName
        '
        Me.colGroupName.HeaderText = "GroupName"
        Me.colGroupName.Name = "colGroupName"
        Me.colGroupName.ReadOnly = True
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcion.HeaderText = "Description Group"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        '
        'frmEquiposVentas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1162, 936)
        Me.Controls.Add(Me.panelEquipos)
        Me.Controls.Add(Me.panelPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmEquiposVentas"
        Me.Text = "frmEquiposVentas"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelPrincipal.ResumeLayout(False)
        Me.panelGrupos.ResumeLayout(False)
        CType(Me.dgListaGrupos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelUsuarios.ResumeLayout(False)
        CType(Me.dgListaUsuarios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEquipos.ResumeLayout(False)
        Me.panelEquipos.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelPrincipal As System.Windows.Forms.Panel
    Friend WithEvents panelGrupos As System.Windows.Forms.Panel
    Friend WithEvents panelUsuarios As System.Windows.Forms.Panel
    Friend WithEvents dgListaUsuarios As System.Windows.Forms.DataGridView
    Friend WithEvents dgListaGrupos As System.Windows.Forms.DataGridView
    Friend WithEvents panelEquipos As System.Windows.Forms.Panel
    Friend WithEvents etiquetaDescripcion As System.Windows.Forms.Label
    Friend WithEvents etiquetaNombre As System.Windows.Forms.Label
    Friend WithEvents etiquetaCode As System.Windows.Forms.Label
    Friend WithEvents celdaDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents celdaNombreGroup As System.Windows.Forms.TextBox
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents celdaTipo As System.Windows.Forms.TextBox
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colGrupo As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colCodGrupo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCodPuesto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPuesto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTypeGroup As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colGroupName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
