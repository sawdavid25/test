﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmContraseña
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaConfirmarContraseña = New System.Windows.Forms.TextBox()
        Me.etiquetaConfirmarContraseña = New System.Windows.Forms.Label()
        Me.celdaContraseña = New System.Windows.Forms.TextBox()
        Me.etiquetaContraseña = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaConfirmarContraseña)
        Me.Panel1.Controls.Add(Me.etiquetaConfirmarContraseña)
        Me.Panel1.Controls.Add(Me.celdaContraseña)
        Me.Panel1.Controls.Add(Me.etiquetaContraseña)
        Me.Panel1.Controls.Add(Me.etiquetaNombre)
        Me.Panel1.Location = New System.Drawing.Point(29, 137)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(725, 172)
        Me.Panel1.TabIndex = 2
        '
        'celdaConfirmarContraseña
        '
        Me.celdaConfirmarContraseña.Location = New System.Drawing.Point(265, 126)
        Me.celdaConfirmarContraseña.Name = "celdaConfirmarContraseña"
        Me.celdaConfirmarContraseña.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.celdaConfirmarContraseña.Size = New System.Drawing.Size(396, 22)
        Me.celdaConfirmarContraseña.TabIndex = 4
        '
        'etiquetaConfirmarContraseña
        '
        Me.etiquetaConfirmarContraseña.AutoSize = True
        Me.etiquetaConfirmarContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaConfirmarContraseña.Location = New System.Drawing.Point(47, 129)
        Me.etiquetaConfirmarContraseña.Name = "etiquetaConfirmarContraseña"
        Me.etiquetaConfirmarContraseña.Size = New System.Drawing.Size(154, 18)
        Me.etiquetaConfirmarContraseña.TabIndex = 3
        Me.etiquetaConfirmarContraseña.Text = "Confirm the password"
        '
        'celdaContraseña
        '
        Me.celdaContraseña.Location = New System.Drawing.Point(265, 87)
        Me.celdaContraseña.Name = "celdaContraseña"
        Me.celdaContraseña.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.celdaContraseña.Size = New System.Drawing.Size(396, 22)
        Me.celdaContraseña.TabIndex = 2
        '
        'etiquetaContraseña
        '
        Me.etiquetaContraseña.AutoSize = True
        Me.etiquetaContraseña.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaContraseña.Location = New System.Drawing.Point(47, 90)
        Me.etiquetaContraseña.Name = "etiquetaContraseña"
        Me.etiquetaContraseña.Size = New System.Drawing.Size(178, 18)
        Me.etiquetaContraseña.TabIndex = 1
        Me.etiquetaContraseña.Text = "Enter your new Password"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaNombre.Location = New System.Drawing.Point(294, 39)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(71, 25)
        Me.etiquetaNombre.TabIndex = 0
        Me.etiquetaNombre.Text = "Label1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(149, 328)
        Me.Label1.MaximumSize = New System.Drawing.Size(470, 250)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(468, 60)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Password must be at least 8 characters, must contain letters, numbers (0-9) and a" &
    "t least one special character (@,#,/,*,%,&,!,(,),?,)."
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(800, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(800, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmContraseña
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmContraseña"
        Me.Text = "Password"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents Panel1 As Panel
    Friend WithEvents celdaConfirmarContraseña As TextBox
    Friend WithEvents etiquetaConfirmarContraseña As Label
    Friend WithEvents celdaContraseña As TextBox
    Friend WithEvents etiquetaContraseña As Label
    Friend WithEvents etiquetaNombre As Label
    Friend WithEvents Label1 As Label
End Class
