﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporteContenedoresEntrantes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechaInicio = New System.Windows.Forms.Label()
        Me.etiquetaFechaFinal = New System.Windows.Forms.Label()
        Me.checkSinFechaArribo = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.checkFiltrarCuenta = New System.Windows.Forms.CheckBox()
        Me.checkReferencia = New System.Windows.Forms.CheckBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.checkCC = New System.Windows.Forms.CheckBox()
        Me.checkRubroCuenta = New System.Windows.Forms.CheckBox()
        Me.checkMonedaTasa = New System.Windows.Forms.CheckBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(26, 77)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(200, 20)
        Me.dtpFechaInicial.TabIndex = 0
        Me.dtpFechaInicial.Value = New Date(2017, 6, 1, 0, 0, 0, 0)
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(26, 133)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(200, 20)
        Me.dtpFechaFinal.TabIndex = 1
        Me.dtpFechaFinal.Value = New Date(2017, 6, 30, 0, 0, 0, 0)
        '
        'etiquetaFechaInicio
        '
        Me.etiquetaFechaInicio.AutoSize = True
        Me.etiquetaFechaInicio.Location = New System.Drawing.Point(33, 61)
        Me.etiquetaFechaInicio.Name = "etiquetaFechaInicio"
        Me.etiquetaFechaInicio.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaFechaInicio.TabIndex = 2
        Me.etiquetaFechaInicio.Text = "Initial Date"
        '
        'etiquetaFechaFinal
        '
        Me.etiquetaFechaFinal.AutoSize = True
        Me.etiquetaFechaFinal.ForeColor = System.Drawing.SystemColors.ControlText
        Me.etiquetaFechaFinal.Location = New System.Drawing.Point(33, 117)
        Me.etiquetaFechaFinal.Name = "etiquetaFechaFinal"
        Me.etiquetaFechaFinal.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaFechaFinal.TabIndex = 3
        Me.etiquetaFechaFinal.Text = "Final Date"
        '
        'checkSinFechaArribo
        '
        Me.checkSinFechaArribo.AutoSize = True
        Me.checkSinFechaArribo.Location = New System.Drawing.Point(26, 158)
        Me.checkSinFechaArribo.Name = "checkSinFechaArribo"
        Me.checkSinFechaArribo.Size = New System.Drawing.Size(115, 17)
        Me.checkSinFechaArribo.TabIndex = 4
        Me.checkSinFechaArribo.Text = "No Date Of Arrival "
        Me.checkSinFechaArribo.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(277, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "_____________________________________________"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.Highlight
        Me.Label4.Location = New System.Drawing.Point(51, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(146, 26)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Select the desired date range"
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAceptar.Location = New System.Drawing.Point(124, 3)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(52, 30)
        Me.botonAceptar.TabIndex = 7
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(183, 3)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(60, 30)
        Me.botonCancelar.TabIndex = 8
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'checkFiltrarCuenta
        '
        Me.checkFiltrarCuenta.AutoSize = True
        Me.checkFiltrarCuenta.Location = New System.Drawing.Point(26, 181)
        Me.checkFiltrarCuenta.Name = "checkFiltrarCuenta"
        Me.checkFiltrarCuenta.Size = New System.Drawing.Size(91, 17)
        Me.checkFiltrarCuenta.TabIndex = 9
        Me.checkFiltrarCuenta.Text = "Filter Account"
        Me.checkFiltrarCuenta.UseVisualStyleBackColor = True
        '
        'checkReferencia
        '
        Me.checkReferencia.AutoSize = True
        Me.checkReferencia.Location = New System.Drawing.Point(26, 205)
        Me.checkReferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.checkReferencia.Name = "checkReferencia"
        Me.checkReferencia.Size = New System.Drawing.Size(106, 17)
        Me.checkReferencia.TabIndex = 10
        Me.checkReferencia.Text = "Show Reference"
        Me.checkReferencia.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonAceptar)
        Me.Panel1.Controls.Add(Me.botonCancelar)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 298)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(252, 43)
        Me.Panel1.TabIndex = 11
        '
        'checkCC
        '
        Me.checkCC.AutoSize = True
        Me.checkCC.Location = New System.Drawing.Point(26, 227)
        Me.checkCC.Margin = New System.Windows.Forms.Padding(2)
        Me.checkCC.Name = "checkCC"
        Me.checkCC.Size = New System.Drawing.Size(109, 17)
        Me.checkCC.TabIndex = 12
        Me.checkCC.Text = "Show cost center"
        Me.checkCC.UseVisualStyleBackColor = True
        Me.checkCC.Visible = False
        '
        'checkRubroCuenta
        '
        Me.checkRubroCuenta.AutoSize = True
        Me.checkRubroCuenta.Location = New System.Drawing.Point(26, 249)
        Me.checkRubroCuenta.Name = "checkRubroCuenta"
        Me.checkRubroCuenta.Size = New System.Drawing.Size(100, 17)
        Me.checkRubroCuenta.TabIndex = 13
        Me.checkRubroCuenta.Text = "Rubro y Cuenta"
        Me.checkRubroCuenta.UseVisualStyleBackColor = True
        Me.checkRubroCuenta.Visible = False
        '
        'checkMonedaTasa
        '
        Me.checkMonedaTasa.AutoSize = True
        Me.checkMonedaTasa.Location = New System.Drawing.Point(26, 272)
        Me.checkMonedaTasa.Name = "checkMonedaTasa"
        Me.checkMonedaTasa.Size = New System.Drawing.Size(153, 17)
        Me.checkMonedaTasa.TabIndex = 14
        Me.checkMonedaTasa.Text = "Tasa de Cambio y Moneda"
        Me.checkMonedaTasa.UseVisualStyleBackColor = True
        Me.checkMonedaTasa.Visible = False
        '
        'frmReporteContenedoresEntrantes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ClientSize = New System.Drawing.Size(252, 341)
        Me.Controls.Add(Me.checkMonedaTasa)
        Me.Controls.Add(Me.checkRubroCuenta)
        Me.Controls.Add(Me.checkCC)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.checkReferencia)
        Me.Controls.Add(Me.checkFiltrarCuenta)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.checkSinFechaArribo)
        Me.Controls.Add(Me.etiquetaFechaFinal)
        Me.Controls.Add(Me.etiquetaFechaInicio)
        Me.Controls.Add(Me.dtpFechaFinal)
        Me.Controls.Add(Me.dtpFechaInicial)
        Me.Name = "frmReporteContenedoresEntrantes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GK"
        Me.Panel1.ResumeLayout(false)
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub

    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents etiquetaFechaInicio As Label
    Friend WithEvents etiquetaFechaFinal As Label
    Friend WithEvents checkSinFechaArribo As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonCancelar As Button
    Friend WithEvents checkFiltrarCuenta As System.Windows.Forms.CheckBox
    Friend WithEvents checkReferencia As System.Windows.Forms.CheckBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents checkCC As System.Windows.Forms.CheckBox
    Friend WithEvents checkRubroCuenta As System.Windows.Forms.CheckBox
    Friend WithEvents checkMonedaTasa As System.Windows.Forms.CheckBox
End Class
