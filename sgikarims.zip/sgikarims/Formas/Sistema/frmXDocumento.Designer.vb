﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmXDocumento
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDocumento = New System.Windows.Forms.DataGridView()
        Me.colCorrelativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelTotales = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.celdaQuetzales = New System.Windows.Forms.TextBox()
        Me.etiquetaQuetzal = New System.Windows.Forms.Label()
        Me.celdaDolar = New System.Windows.Forms.TextBox()
        Me.etiquetaDolar = New System.Windows.Forms.Label()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDocumento, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTotales.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDocumento)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 0)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(652, 192)
        Me.PanelDetalle.TabIndex = 0
        '
        'dgDocumento
        '
        Me.dgDocumento.AllowUserToAddRows = False
        Me.dgDocumento.AllowUserToDeleteRows = False
        Me.dgDocumento.AllowUserToOrderColumns = True
        Me.dgDocumento.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDocumento.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDocumento.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumento.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCorrelativo, Me.colFecha, Me.colTipo, Me.colNumero, Me.colNombre, Me.colConcepto, Me.colMoneda, Me.colTasa, Me.colMonto, Me.colExt, Me.colLoc})
        Me.dgDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumento.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumento.Name = "dgDocumento"
        Me.dgDocumento.ReadOnly = True
        Me.dgDocumento.RowTemplate.Height = 24
        Me.dgDocumento.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumento.Size = New System.Drawing.Size(652, 192)
        Me.dgDocumento.TabIndex = 0
        '
        'colCorrelativo
        '
        Me.colCorrelativo.HeaderText = "N°"
        Me.colCorrelativo.Name = "colCorrelativo"
        Me.colCorrelativo.ReadOnly = True
        Me.colCorrelativo.Width = 53
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Width = 69
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 87
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 74
        '
        'colConcepto
        '
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.Name = "colConcepto"
        Me.colConcepto.ReadOnly = True
        Me.colConcepto.Width = 89
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Currency"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.Width = 94
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.Width = 67
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        Me.colMonto.Width = 85
        '
        'colExt
        '
        Me.colExt.HeaderText = "Payment $"
        Me.colExt.Name = "colExt"
        Me.colExt.ReadOnly = True
        Me.colExt.Width = 104
        '
        'colLoc
        '
        Me.colLoc.HeaderText = "Payment Local"
        Me.colLoc.Name = "colLoc"
        Me.colLoc.ReadOnly = True
        Me.colLoc.Width = 130
        '
        'PanelTotales
        '
        Me.PanelTotales.Controls.Add(Me.botonCancelar)
        Me.PanelTotales.Controls.Add(Me.celdaQuetzales)
        Me.PanelTotales.Controls.Add(Me.etiquetaQuetzal)
        Me.PanelTotales.Controls.Add(Me.celdaDolar)
        Me.PanelTotales.Controls.Add(Me.etiquetaDolar)
        Me.PanelTotales.Controls.Add(Me.etiquetaTotal)
        Me.PanelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelTotales.Location = New System.Drawing.Point(0, 192)
        Me.PanelTotales.Name = "PanelTotales"
        Me.PanelTotales.Size = New System.Drawing.Size(652, 70)
        Me.PanelTotales.TabIndex = 1
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(541, 17)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 42)
        Me.botonCancelar.TabIndex = 19
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'celdaQuetzales
        '
        Me.celdaQuetzales.Location = New System.Drawing.Point(344, 24)
        Me.celdaQuetzales.Name = "celdaQuetzales"
        Me.celdaQuetzales.ReadOnly = True
        Me.celdaQuetzales.Size = New System.Drawing.Size(156, 22)
        Me.celdaQuetzales.TabIndex = 4
        '
        'etiquetaQuetzal
        '
        Me.etiquetaQuetzal.AutoSize = True
        Me.etiquetaQuetzal.Location = New System.Drawing.Point(305, 27)
        Me.etiquetaQuetzal.Name = "etiquetaQuetzal"
        Me.etiquetaQuetzal.Size = New System.Drawing.Size(23, 17)
        Me.etiquetaQuetzal.TabIndex = 3
        Me.etiquetaQuetzal.Text = "Q."
        '
        'celdaDolar
        '
        Me.celdaDolar.Location = New System.Drawing.Point(126, 24)
        Me.celdaDolar.Name = "celdaDolar"
        Me.celdaDolar.ReadOnly = True
        Me.celdaDolar.Size = New System.Drawing.Size(156, 22)
        Me.celdaDolar.TabIndex = 2
        '
        'etiquetaDolar
        '
        Me.etiquetaDolar.AutoSize = True
        Me.etiquetaDolar.Location = New System.Drawing.Point(93, 24)
        Me.etiquetaDolar.Name = "etiquetaDolar"
        Me.etiquetaDolar.Size = New System.Drawing.Size(16, 17)
        Me.etiquetaDolar.TabIndex = 1
        Me.etiquetaDolar.Text = "$"
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(12, 24)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTotal.TabIndex = 0
        Me.etiquetaTotal.Text = "Total"
        '
        'frmXDocumento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(652, 262)
        Me.Controls.Add(Me.PanelDetalle)
        Me.Controls.Add(Me.PanelTotales)
        Me.Name = "frmXDocumento"
        Me.Text = "frmXDocumento"
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDocumento, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTotales.ResumeLayout(False)
        Me.PanelTotales.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDocumento As DataGridView
    Friend WithEvents PanelTotales As Panel
    Friend WithEvents celdaQuetzales As TextBox
    Friend WithEvents etiquetaQuetzal As Label
    Friend WithEvents celdaDolar As TextBox
    Friend WithEvents etiquetaDolar As Label
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents botonCancelar As Button
    Friend WithEvents colCorrelativo As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colExt As DataGridViewTextBoxColumn
    Friend WithEvents colLoc As DataGridViewTextBoxColumn
End Class
