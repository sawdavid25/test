﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSubDocumentos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvSubDocumentosfrm = New System.Windows.Forms.DataGridView()
        Me.Descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Datos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Contenido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.EtiquetaDocumento = New System.Windows.Forms.Label()
        Me.celdaDocumento = New System.Windows.Forms.TextBox()
        Me.celdaGuardar = New System.Windows.Forms.TextBox()
        Me.botonDatosPoliza = New System.Windows.Forms.Button()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.btnImprimir = New System.Windows.Forms.Button()
        Me.btnGuardar = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        CType(Me.dgvSubDocumentosfrm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvSubDocumentosfrm
        '
        Me.dgvSubDocumentosfrm.AllowUserToAddRows = False
        Me.dgvSubDocumentosfrm.AllowUserToDeleteRows = False
        Me.dgvSubDocumentosfrm.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvSubDocumentosfrm.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.dgvSubDocumentosfrm.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvSubDocumentosfrm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSubDocumentosfrm.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Descripcion, Me.Datos, Me.Linea, Me.Contenido})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSubDocumentosfrm.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgvSubDocumentosfrm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvSubDocumentosfrm.GridColor = System.Drawing.SystemColors.Control
        Me.dgvSubDocumentosfrm.Location = New System.Drawing.Point(0, 33)
        Me.dgvSubDocumentosfrm.Name = "dgvSubDocumentosfrm"
        Me.dgvSubDocumentosfrm.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvSubDocumentosfrm.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgvSubDocumentosfrm.Size = New System.Drawing.Size(701, 361)
        Me.dgvSubDocumentosfrm.TabIndex = 0
        '
        'Descripcion
        '
        Me.Descripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Descripcion.DefaultCellStyle = DataGridViewCellStyle2
        Me.Descripcion.HeaderText = "Description"
        Me.Descripcion.MinimumWidth = 10
        Me.Descripcion.Name = "Descripcion"
        Me.Descripcion.ReadOnly = True
        Me.Descripcion.Width = 85
        '
        'Datos
        '
        Me.Datos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Datos.DefaultCellStyle = DataGridViewCellStyle3
        Me.Datos.HeaderText = "Data"
        Me.Datos.MinimumWidth = 10
        Me.Datos.Name = "Datos"
        Me.Datos.ReadOnly = True
        Me.Datos.Width = 55
        '
        'Linea
        '
        Me.Linea.HeaderText = "Line"
        Me.Linea.MinimumWidth = 10
        Me.Linea.Name = "Linea"
        Me.Linea.ReadOnly = True
        Me.Linea.Visible = False
        '
        'Contenido
        '
        Me.Contenido.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Contenido.DefaultCellStyle = DataGridViewCellStyle4
        Me.Contenido.HeaderText = "Content"
        Me.Contenido.MinimumWidth = 10
        Me.Contenido.Name = "Contenido"
        Me.Contenido.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'TextBox1
        '
        Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TextBox1.Location = New System.Drawing.Point(0, 0)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(701, 33)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = "**Los Datos Cargados de Manera Automatica, no estaran disponibles para impresion " &
    "hasta que se haya guardado el documento"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaDocumento
        '
        Me.EtiquetaDocumento.AutoSize = True
        Me.EtiquetaDocumento.Location = New System.Drawing.Point(227, 56)
        Me.EtiquetaDocumento.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.EtiquetaDocumento.Name = "EtiquetaDocumento"
        Me.EtiquetaDocumento.Size = New System.Drawing.Size(62, 13)
        Me.EtiquetaDocumento.TabIndex = 6
        Me.EtiquetaDocumento.Text = "Documento"
        Me.EtiquetaDocumento.Visible = False
        '
        'celdaDocumento
        '
        Me.celdaDocumento.Location = New System.Drawing.Point(302, 49)
        Me.celdaDocumento.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDocumento.Name = "celdaDocumento"
        Me.celdaDocumento.Size = New System.Drawing.Size(76, 20)
        Me.celdaDocumento.TabIndex = 7
        Me.celdaDocumento.Visible = False
        '
        'celdaGuardar
        '
        Me.celdaGuardar.Location = New System.Drawing.Point(337, 30)
        Me.celdaGuardar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaGuardar.Name = "celdaGuardar"
        Me.celdaGuardar.Size = New System.Drawing.Size(76, 20)
        Me.celdaGuardar.TabIndex = 8
        Me.celdaGuardar.Visible = False
        '
        'botonDatosPoliza
        '
        Me.botonDatosPoliza.Image = Global.KARIMs_SGI.My.Resources.Resources.paste
        Me.botonDatosPoliza.Location = New System.Drawing.Point(12, 30)
        Me.botonDatosPoliza.Name = "botonDatosPoliza"
        Me.botonDatosPoliza.Size = New System.Drawing.Size(83, 50)
        Me.botonDatosPoliza.TabIndex = 5
        Me.botonDatosPoliza.Text = "Policy Data"
        Me.botonDatosPoliza.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonDatosPoliza.UseVisualStyleBackColor = True
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(634, 16)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(56, 50)
        Me.botonCerrar.TabIndex = 4
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'btnImprimir
        '
        Me.btnImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print1
        Me.btnImprimir.Location = New System.Drawing.Point(506, 16)
        Me.btnImprimir.Name = "btnImprimir"
        Me.btnImprimir.Size = New System.Drawing.Size(54, 50)
        Me.btnImprimir.TabIndex = 2
        Me.btnImprimir.Text = "Print"
        Me.btnImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnImprimir.UseVisualStyleBackColor = True
        '
        'btnGuardar
        '
        Me.btnGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.btnGuardar.Location = New System.Drawing.Point(446, 16)
        Me.btnGuardar.Name = "btnGuardar"
        Me.btnGuardar.Size = New System.Drawing.Size(54, 50)
        Me.btnGuardar.TabIndex = 1
        Me.btnGuardar.Text = "Aceptar"
        Me.btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnGuardar.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonCerrar)
        Me.Panel1.Controls.Add(Me.botonDatosPoliza)
        Me.Panel1.Controls.Add(Me.celdaGuardar)
        Me.Panel1.Controls.Add(Me.btnGuardar)
        Me.Panel1.Controls.Add(Me.celdaDocumento)
        Me.Panel1.Controls.Add(Me.EtiquetaDocumento)
        Me.Panel1.Controls.Add(Me.btnImprimir)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 394)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(701, 86)
        Me.Panel1.TabIndex = 9
        '
        'frmSubDocumentos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ClientSize = New System.Drawing.Size(701, 480)
        Me.Controls.Add(Me.dgvSubDocumentosfrm)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmSubDocumentos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "im "
        CType(Me.dgvSubDocumentosfrm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvSubDocumentosfrm As System.Windows.Forms.DataGridView
    Friend WithEvents btnGuardar As System.Windows.Forms.Button
    Friend WithEvents btnImprimir As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonDatosPoliza As System.Windows.Forms.Button
    Friend WithEvents EtiquetaDocumento As System.Windows.Forms.Label
    Friend WithEvents celdaDocumento As System.Windows.Forms.TextBox
    Friend WithEvents celdaGuardar As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Descripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Datos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Linea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Contenido As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
