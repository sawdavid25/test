﻿Public Class frmContraseña
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Limpiarcontraseña()
        celdaConfirmarContraseña.Text = STR_VACIO
        celdaContraseña.Text = STR_VACIO
        etiquetaNombre.Text = Sesion.Usuario
        BarraTitulo1.CambiarTitulo("Password")
        Encabezado1.botonBorrar.Enabled = False
        Encabezado1.botonNuevo.Enabled = False
    End Sub
    Private Function ComprobarContraseña() As Boolean
        Dim logVerificar As Boolean = True
        If celdaContraseña.Text = celdaConfirmarContraseña.Text Then
            logVerificar = True
        Else
            MsgBox("Passwords do not match, please try again", MsgBoxStyle.Information)
            Limpiarcontraseña()
            logVerificar = False
        End If
        Return logVerificar
    End Function
    Private Function ComprobarDigitos() As Boolean
        Dim logVerificar As Boolean
        Dim strNumeros As String = "1,2,3,4,5,6,7,8,9,0"
        Dim arrayNumeros() As String

        arrayNumeros = strNumeros.Split(",")

        If celdaContraseña.Text.Length >= 8 Then
            For i As Integer = INT_CERO To arrayNumeros.Length - 1
                If InStr(celdaContraseña.Text, arrayNumeros(i)) > INT_CERO Then
                    Return True
                    Exit Function
                End If
            Next
        Else
            MsgBox("Password must be at least 8 characters", MsgBoxStyle.Information)
            Limpiarcontraseña()
        End If

        If logVerificar = False Then
            MsgBox("Please enter digits" & strNumeros & "", MsgBoxStyle.Information)
            Limpiarcontraseña()
        End If
        Return logVerificar
    End Function
    Private Function ComprobarCaracteresEspeciales() As Boolean
        Dim logVerificar As Boolean = False
        Dim strCaracteres As String = "@,#,/,*,%,&,!,(,),\,?,¿"
        Dim ArrayCaracter() As String

        ArrayCaracter = strCaracteres.Split(",")
        If celdaContraseña.Text.Length >= 8 Then

            For i As Integer = INT_CERO To ArrayCaracter.Length - 1
                If InStr(celdaContraseña.Text, ArrayCaracter(i)) > INT_CERO Then
                    Return True
                    Exit Function
                End If
            Next
        Else
            MsgBox("Password must be at least 8 characters", MsgBoxStyle.Information)
            Limpiarcontraseña()
        End If

        If logVerificar = False Then
            MsgBox("Please enter special characters " & strCaracteres & "", MsgBoxStyle.Information)
            Limpiarcontraseña()
        End If

        Return logVerificar
    End Function
    Public Function VerificarContraseña() As Boolean
        Dim logVerificar As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim intCodigo As Integer

        strSQL = "SELECT COUNT(*) "
        strSQL &= "     FROM HistorialC hc "
        strSQL &= "         WHERE  hc.id_Empresa = {empresa} and hc.id_Usuario = {usuario} AND hc.Contrasena= md5('{contrasena}') "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.idUsuario)
        strSQL = Replace(strSQL, "{contrasena}", celdaContraseña.Text)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intCodigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        If intCodigo >= INT_UNO Then
            MsgBox("This password has already been used before, Please enter a different one ", MsgBoxStyle.Information)
            logVerificar = False
            Limpiarcontraseña()
        End If
        Return logVerificar
    End Function
    Private Function Guardar(ByVal Codigo As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = "  UPDATE  Personal p set p.per_clave = MD5('{contrasena}') , p.per_fecha = now()     "
        strSQL &= "     WHERE p.per_codigo = {codigo} AND p.per_sisemp = {empresa} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{contrasena}", celdaContraseña.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        If GuardarContraseña() = True Then
            logGuardar = True
        Else
            logGuardar = False
        End If

        Return logGuardar
    End Function
    Private Function GuardarContraseña() As Boolean
        Dim logGuardar As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = "  INSERT INTO HistorialC Values ({empresa},{usuario},MD5('{contrasena}')) "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.idUsuario)
        strSQL = Replace(strSQL, "{contrasena}", celdaContraseña.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        Return logGuardar
    End Function
#End Region
#Region "Eventos"
    Private Sub frmContraseña_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        Limpiarcontraseña()
    End Sub

    Private Sub frmContraseña_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If logEditar = True Then
                If ComprobarContraseña() = True Then
                    If ComprobarDigitos() = True Then
                        If ComprobarCaracteresEspeciales() = True Then
                            If VerificarContraseña() = True Then
                                If Guardar(Sesion.idUsuario) Then
                                    End
                                End If
                            End If
                        End If
                    End If
                End If
            Else
                MsgBox("You don't have permission to update ")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        Me.Close()
        End
    End Sub
#End Region
End Class