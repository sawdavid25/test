﻿Public Class frmFFechas

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim intCurDoc As Integer
    Dim strReferencia As String
    Dim cfun As New clsFunciones

    Private logRango As Boolean
    Private logAceptado As Boolean
    Private logExcluye As Boolean
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


    Public Property Acepatdo As Boolean
        Get
            Return logAceptado
        End Get
        Set(value As Boolean)
            logAceptado = value
        End Set
    End Property

    Public Property Rango As Boolean
        Get
            Return logRango
        End Get
        Set(value As Boolean)
            logRango = value
        End Set
    End Property
#End Region


#Region "Procedimientos"


    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

        If logRango Then
            If MsgBox("La fecha final debe ser mayor o igual que la fecha inicial", MsgBoxStyle.Exclamation, "Rango de fecha") Then
            Else
                logAceptado = True
                Me.Hide()
            End If
        Else
            logAceptado = True
            Me.Hide()
        End If
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Sub frmFFechas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpInicial.Value = Today.AddMonths(NO_FILA)
        If logRango Then
            dtpFinal.Value = Today
        Else
            etiquetaInicio.Text = "Fecha"
            dtpInicial.Value = Today

            etiquetaFinal.Visible = False
            dtpFinal.Visible = False

            check1.Location = New System.Drawing.Point(47, 158)
            check2.Location = New System.Drawing.Point(47, 180)
        End If

    End Sub

#End Region


End Class