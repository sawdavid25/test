﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPackingHSM
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPackingHSM))
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.gbLibras = New System.Windows.Forms.GroupBox()
        Me.botonTaraAprox = New System.Windows.Forms.Button()
        Me.etiquetaLbsPaquetes = New System.Windows.Forms.Label()
        Me.celdaTaraAprox = New System.Windows.Forms.TextBox()
        Me.celdaReferenciaLbs = New System.Windows.Forms.TextBox()
        Me.celdaLbsPaquetes = New System.Windows.Forms.TextBox()
        Me.etiquetaReferenciaLbs = New System.Windows.Forms.Label()
        Me.etiquetaLbsTara = New System.Windows.Forms.Label()
        Me.celdaLbsTara = New System.Windows.Forms.TextBox()
        Me.celdaLbsBrutas = New System.Windows.Forms.TextBox()
        Me.etiquetaLbsNetas = New System.Windows.Forms.Label()
        Me.etiquetaLbsBrutas = New System.Windows.Forms.Label()
        Me.celdaLbsNetas = New System.Windows.Forms.TextBox()
        Me.gbKilos = New System.Windows.Forms.GroupBox()
        Me.etiquetapaquetes = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.celdaPaquetes = New System.Windows.Forms.TextBox()
        Me.etiquetaReferencia = New System.Windows.Forms.Label()
        Me.etiquetaTara = New System.Windows.Forms.Label()
        Me.celdaTara = New System.Windows.Forms.TextBox()
        Me.celdaKilosBrutos = New System.Windows.Forms.TextBox()
        Me.etiquetaKilosNetos = New System.Windows.Forms.Label()
        Me.etiquetaKilosBrutos = New System.Windows.Forms.Label()
        Me.celdaKilosN = New System.Windows.Forms.TextBox()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaLinea = New System.Windows.Forms.TextBox()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.celdaSumaBultos = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaTotalK = New System.Windows.Forms.TextBox()
        Me.celdaTotalLbs = New System.Windows.Forms.TextBox()
        Me.etiquetaTotalK = New System.Windows.Forms.Label()
        Me.etiquetaTotalLbs = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.colBultos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTara = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTaraLbs = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKilosNetos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKilosBrutos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLibrasBrutas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtraPack = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaPack = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Gin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_GinBac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Crp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDatos.SuspendLayout()
        Me.gbLibras.SuspendLayout()
        Me.gbKilos.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.gbLibras)
        Me.panelDatos.Controls.Add(Me.gbKilos)
        Me.panelDatos.Controls.Add(Me.botonAgregar)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 37)
        Me.panelDatos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1117, 226)
        Me.panelDatos.TabIndex = 2
        '
        'gbLibras
        '
        Me.gbLibras.Controls.Add(Me.botonTaraAprox)
        Me.gbLibras.Controls.Add(Me.etiquetaLbsPaquetes)
        Me.gbLibras.Controls.Add(Me.celdaTaraAprox)
        Me.gbLibras.Controls.Add(Me.celdaReferenciaLbs)
        Me.gbLibras.Controls.Add(Me.celdaLbsPaquetes)
        Me.gbLibras.Controls.Add(Me.etiquetaReferenciaLbs)
        Me.gbLibras.Controls.Add(Me.etiquetaLbsTara)
        Me.gbLibras.Controls.Add(Me.celdaLbsTara)
        Me.gbLibras.Controls.Add(Me.celdaLbsBrutas)
        Me.gbLibras.Controls.Add(Me.etiquetaLbsNetas)
        Me.gbLibras.Controls.Add(Me.etiquetaLbsBrutas)
        Me.gbLibras.Controls.Add(Me.celdaLbsNetas)
        Me.gbLibras.ForeColor = System.Drawing.Color.Brown
        Me.gbLibras.Location = New System.Drawing.Point(12, 113)
        Me.gbLibras.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbLibras.Name = "gbLibras"
        Me.gbLibras.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbLibras.Size = New System.Drawing.Size(892, 100)
        Me.gbLibras.TabIndex = 15
        Me.gbLibras.TabStop = False
        Me.gbLibras.Text = "POUNDS"
        '
        'botonTaraAprox
        '
        Me.botonTaraAprox.ForeColor = System.Drawing.Color.Black
        Me.botonTaraAprox.Location = New System.Drawing.Point(845, 52)
        Me.botonTaraAprox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonTaraAprox.Name = "botonTaraAprox"
        Me.botonTaraAprox.Size = New System.Drawing.Size(41, 22)
        Me.botonTaraAprox.TabIndex = 17
        Me.botonTaraAprox.Text = "..."
        Me.botonTaraAprox.UseVisualStyleBackColor = True
        '
        'etiquetaLbsPaquetes
        '
        Me.etiquetaLbsPaquetes.AutoSize = True
        Me.etiquetaLbsPaquetes.Location = New System.Drawing.Point(27, 32)
        Me.etiquetaLbsPaquetes.Name = "etiquetaLbsPaquetes"
        Me.etiquetaLbsPaquetes.Size = New System.Drawing.Size(95, 17)
        Me.etiquetaLbsPaquetes.TabIndex = 0
        Me.etiquetaLbsPaquetes.Text = "No. packages"
        '
        'celdaTaraAprox
        '
        Me.celdaTaraAprox.Location = New System.Drawing.Point(721, 50)
        Me.celdaTaraAprox.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTaraAprox.Name = "celdaTaraAprox"
        Me.celdaTaraAprox.Size = New System.Drawing.Size(113, 22)
        Me.celdaTaraAprox.TabIndex = 16
        '
        'celdaReferenciaLbs
        '
        Me.celdaReferenciaLbs.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.celdaReferenciaLbs.Location = New System.Drawing.Point(544, 52)
        Me.celdaReferenciaLbs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaReferenciaLbs.MaxLength = 18
        Me.celdaReferenciaLbs.Name = "celdaReferenciaLbs"
        Me.celdaReferenciaLbs.Size = New System.Drawing.Size(156, 22)
        Me.celdaReferenciaLbs.TabIndex = 13
        '
        'celdaLbsPaquetes
        '
        Me.celdaLbsPaquetes.Location = New System.Drawing.Point(29, 52)
        Me.celdaLbsPaquetes.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLbsPaquetes.Name = "celdaLbsPaquetes"
        Me.celdaLbsPaquetes.Size = New System.Drawing.Size(100, 22)
        Me.celdaLbsPaquetes.TabIndex = 1
        Me.celdaLbsPaquetes.Text = "1"
        '
        'etiquetaReferenciaLbs
        '
        Me.etiquetaReferenciaLbs.AutoSize = True
        Me.etiquetaReferenciaLbs.Location = New System.Drawing.Point(541, 32)
        Me.etiquetaReferenciaLbs.Name = "etiquetaReferenciaLbs"
        Me.etiquetaReferenciaLbs.Size = New System.Drawing.Size(74, 17)
        Me.etiquetaReferenciaLbs.TabIndex = 12
        Me.etiquetaReferenciaLbs.Text = "Reference"
        '
        'etiquetaLbsTara
        '
        Me.etiquetaLbsTara.AutoSize = True
        Me.etiquetaLbsTara.Location = New System.Drawing.Point(155, 32)
        Me.etiquetaLbsTara.Name = "etiquetaLbsTara"
        Me.etiquetaLbsTara.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaLbsTara.TabIndex = 2
        Me.etiquetaLbsTara.Text = "Tare"
        '
        'celdaLbsTara
        '
        Me.celdaLbsTara.Location = New System.Drawing.Point(157, 52)
        Me.celdaLbsTara.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLbsTara.Name = "celdaLbsTara"
        Me.celdaLbsTara.Size = New System.Drawing.Size(100, 22)
        Me.celdaLbsTara.TabIndex = 3
        Me.celdaLbsTara.Text = "0"
        '
        'celdaLbsBrutas
        '
        Me.celdaLbsBrutas.Location = New System.Drawing.Point(407, 52)
        Me.celdaLbsBrutas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLbsBrutas.Name = "celdaLbsBrutas"
        Me.celdaLbsBrutas.Size = New System.Drawing.Size(100, 22)
        Me.celdaLbsBrutas.TabIndex = 7
        '
        'etiquetaLbsNetas
        '
        Me.etiquetaLbsNetas.AutoSize = True
        Me.etiquetaLbsNetas.Location = New System.Drawing.Point(280, 32)
        Me.etiquetaLbsNetas.Name = "etiquetaLbsNetas"
        Me.etiquetaLbsNetas.Size = New System.Drawing.Size(82, 17)
        Me.etiquetaLbsNetas.TabIndex = 4
        Me.etiquetaLbsNetas.Text = "Pounds Net"
        '
        'etiquetaLbsBrutas
        '
        Me.etiquetaLbsBrutas.AutoSize = True
        Me.etiquetaLbsBrutas.Location = New System.Drawing.Point(404, 32)
        Me.etiquetaLbsBrutas.Name = "etiquetaLbsBrutas"
        Me.etiquetaLbsBrutas.Size = New System.Drawing.Size(91, 17)
        Me.etiquetaLbsBrutas.TabIndex = 6
        Me.etiquetaLbsBrutas.Text = "Punds Groos"
        '
        'celdaLbsNetas
        '
        Me.celdaLbsNetas.Location = New System.Drawing.Point(283, 52)
        Me.celdaLbsNetas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLbsNetas.Name = "celdaLbsNetas"
        Me.celdaLbsNetas.Size = New System.Drawing.Size(100, 22)
        Me.celdaLbsNetas.TabIndex = 5
        Me.celdaLbsNetas.Text = "0"
        '
        'gbKilos
        '
        Me.gbKilos.Controls.Add(Me.etiquetapaquetes)
        Me.gbKilos.Controls.Add(Me.celdaReferencia)
        Me.gbKilos.Controls.Add(Me.celdaPaquetes)
        Me.gbKilos.Controls.Add(Me.etiquetaReferencia)
        Me.gbKilos.Controls.Add(Me.etiquetaTara)
        Me.gbKilos.Controls.Add(Me.celdaTara)
        Me.gbKilos.Controls.Add(Me.celdaKilosBrutos)
        Me.gbKilos.Controls.Add(Me.etiquetaKilosNetos)
        Me.gbKilos.Controls.Add(Me.etiquetaKilosBrutos)
        Me.gbKilos.Controls.Add(Me.celdaKilosN)
        Me.gbKilos.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.gbKilos.Location = New System.Drawing.Point(12, 7)
        Me.gbKilos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbKilos.Name = "gbKilos"
        Me.gbKilos.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbKilos.Size = New System.Drawing.Size(892, 100)
        Me.gbKilos.TabIndex = 14
        Me.gbKilos.TabStop = False
        Me.gbKilos.Text = "KILOS"
        '
        'etiquetapaquetes
        '
        Me.etiquetapaquetes.AutoSize = True
        Me.etiquetapaquetes.Location = New System.Drawing.Point(27, 32)
        Me.etiquetapaquetes.Name = "etiquetapaquetes"
        Me.etiquetapaquetes.Size = New System.Drawing.Size(95, 17)
        Me.etiquetapaquetes.TabIndex = 0
        Me.etiquetapaquetes.Text = "No. packages"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(544, 52)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(156, 22)
        Me.celdaReferencia.TabIndex = 13
        '
        'celdaPaquetes
        '
        Me.celdaPaquetes.Location = New System.Drawing.Point(29, 52)
        Me.celdaPaquetes.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPaquetes.Name = "celdaPaquetes"
        Me.celdaPaquetes.Size = New System.Drawing.Size(100, 22)
        Me.celdaPaquetes.TabIndex = 1
        Me.celdaPaquetes.Text = "1"
        '
        'etiquetaReferencia
        '
        Me.etiquetaReferencia.AutoSize = True
        Me.etiquetaReferencia.Location = New System.Drawing.Point(541, 32)
        Me.etiquetaReferencia.Name = "etiquetaReferencia"
        Me.etiquetaReferencia.Size = New System.Drawing.Size(74, 17)
        Me.etiquetaReferencia.TabIndex = 12
        Me.etiquetaReferencia.Text = "Reference"
        '
        'etiquetaTara
        '
        Me.etiquetaTara.AutoSize = True
        Me.etiquetaTara.Location = New System.Drawing.Point(155, 32)
        Me.etiquetaTara.Name = "etiquetaTara"
        Me.etiquetaTara.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTara.TabIndex = 2
        Me.etiquetaTara.Text = "Tare"
        '
        'celdaTara
        '
        Me.celdaTara.Location = New System.Drawing.Point(157, 52)
        Me.celdaTara.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTara.Name = "celdaTara"
        Me.celdaTara.Size = New System.Drawing.Size(100, 22)
        Me.celdaTara.TabIndex = 3
        Me.celdaTara.Text = "0"
        '
        'celdaKilosBrutos
        '
        Me.celdaKilosBrutos.Enabled = False
        Me.celdaKilosBrutos.Location = New System.Drawing.Point(407, 52)
        Me.celdaKilosBrutos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaKilosBrutos.Name = "celdaKilosBrutos"
        Me.celdaKilosBrutos.Size = New System.Drawing.Size(100, 22)
        Me.celdaKilosBrutos.TabIndex = 7
        '
        'etiquetaKilosNetos
        '
        Me.etiquetaKilosNetos.AutoSize = True
        Me.etiquetaKilosNetos.Location = New System.Drawing.Point(280, 32)
        Me.etiquetaKilosNetos.Name = "etiquetaKilosNetos"
        Me.etiquetaKilosNetos.Size = New System.Drawing.Size(51, 17)
        Me.etiquetaKilosNetos.TabIndex = 4
        Me.etiquetaKilosNetos.Text = "Kg Net"
        '
        'etiquetaKilosBrutos
        '
        Me.etiquetaKilosBrutos.AutoSize = True
        Me.etiquetaKilosBrutos.Location = New System.Drawing.Point(404, 32)
        Me.etiquetaKilosBrutos.Name = "etiquetaKilosBrutos"
        Me.etiquetaKilosBrutos.Size = New System.Drawing.Size(68, 17)
        Me.etiquetaKilosBrutos.TabIndex = 6
        Me.etiquetaKilosBrutos.Text = "Kg Groos"
        '
        'celdaKilosN
        '
        Me.celdaKilosN.Location = New System.Drawing.Point(283, 52)
        Me.celdaKilosN.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaKilosN.Name = "celdaKilosN"
        Me.celdaKilosN.Size = New System.Drawing.Size(100, 22)
        Me.celdaKilosN.TabIndex = 5
        Me.celdaKilosN.Text = "0"
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(947, 39)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(77, 68)
        Me.botonAgregar.TabIndex = 5
        Me.botonAgregar.Text = "Add"
        Me.botonAgregar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAgregar.UseVisualStyleBackColor = True
        Me.botonAgregar.Visible = False
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colBultos, Me.colTara, Me.colTaraLbs, Me.colKilosNetos, Me.colKilosBrutos, Me.colLibrasBrutas, Me.colReferencia, Me.colXtraPack, Me.colLineaDet, Me.colLineaPack, Me.colTipoBulto, Me.col_Gin, Me.col_GinBac, Me.col_Crp, Me.col_referencia})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgDetalle.Location = New System.Drawing.Point(0, 263)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(1020, 258)
        Me.dgDetalle.TabIndex = 0
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaNumero)
        Me.panelTotales.Controls.Add(Me.celdaAnio)
        Me.panelTotales.Controls.Add(Me.Label1)
        Me.panelTotales.Controls.Add(Me.celdaLinea)
        Me.panelTotales.Controls.Add(Me.botonCancelar)
        Me.panelTotales.Controls.Add(Me.botonAceptar)
        Me.panelTotales.Controls.Add(Me.celdaSumaBultos)
        Me.panelTotales.Controls.Add(Me.celdaCatalogo)
        Me.panelTotales.Controls.Add(Me.celdaTotalK)
        Me.panelTotales.Controls.Add(Me.celdaTotalLbs)
        Me.panelTotales.Controls.Add(Me.etiquetaTotalK)
        Me.panelTotales.Controls.Add(Me.etiquetaTotalLbs)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 521)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1117, 105)
        Me.panelTotales.TabIndex = 4
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(564, 71)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(45, 22)
        Me.celdaNumero.TabIndex = 13
        Me.celdaNumero.Visible = False
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(499, 71)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.Size = New System.Drawing.Size(45, 22)
        Me.celdaAnio.TabIndex = 12
        Me.celdaAnio.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(457, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Total Package"
        '
        'celdaLinea
        '
        Me.celdaLinea.Location = New System.Drawing.Point(401, 71)
        Me.celdaLinea.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLinea.Name = "celdaLinea"
        Me.celdaLinea.Size = New System.Drawing.Size(45, 22)
        Me.celdaLinea.TabIndex = 10
        Me.celdaLinea.Visible = False
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(1005, 25)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(77, 65)
        Me.botonCancelar.TabIndex = 9
        Me.botonCancelar.Text = "Close"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(923, 25)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(77, 65)
        Me.botonAceptar.TabIndex = 8
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'celdaSumaBultos
        '
        Me.celdaSumaBultos.Location = New System.Drawing.Point(460, 42)
        Me.celdaSumaBultos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaSumaBultos.Name = "celdaSumaBultos"
        Me.celdaSumaBultos.Size = New System.Drawing.Size(115, 22)
        Me.celdaSumaBultos.TabIndex = 6
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(652, 71)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(44, 22)
        Me.celdaCatalogo.TabIndex = 4
        Me.celdaCatalogo.Visible = False
        '
        'celdaTotalK
        '
        Me.celdaTotalK.Location = New System.Drawing.Point(313, 42)
        Me.celdaTotalK.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotalK.Name = "celdaTotalK"
        Me.celdaTotalK.Size = New System.Drawing.Size(115, 22)
        Me.celdaTotalK.TabIndex = 3
        '
        'celdaTotalLbs
        '
        Me.celdaTotalLbs.Location = New System.Drawing.Point(185, 42)
        Me.celdaTotalLbs.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotalLbs.Name = "celdaTotalLbs"
        Me.celdaTotalLbs.Size = New System.Drawing.Size(115, 22)
        Me.celdaTotalLbs.TabIndex = 2
        '
        'etiquetaTotalK
        '
        Me.etiquetaTotalK.AutoSize = True
        Me.etiquetaTotalK.Location = New System.Drawing.Point(309, 22)
        Me.etiquetaTotalK.Name = "etiquetaTotalK"
        Me.etiquetaTotalK.Size = New System.Drawing.Size(74, 17)
        Me.etiquetaTotalK.TabIndex = 1
        Me.etiquetaTotalK.Text = "Total Neto"
        '
        'etiquetaTotalLbs
        '
        Me.etiquetaTotalLbs.AutoSize = True
        Me.etiquetaTotalLbs.Location = New System.Drawing.Point(181, 22)
        Me.etiquetaTotalLbs.Name = "etiquetaTotalLbs"
        Me.etiquetaTotalLbs.Size = New System.Drawing.Size(82, 17)
        Me.etiquetaTotalLbs.TabIndex = 0
        Me.etiquetaTotalLbs.Text = "Total Gross"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonMenos)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(1022, 263)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(95, 258)
        Me.Panel1.TabIndex = 11
        '
        'botonMenos
        '
        Me.botonMenos.Image = CType(resources.GetObject("botonMenos.Image"), System.Drawing.Image)
        Me.botonMenos.Location = New System.Drawing.Point(25, 118)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(55, 46)
        Me.botonMenos.TabIndex = 46
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1117, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'colBultos
        '
        Me.colBultos.HeaderText = "Package"
        Me.colBultos.Name = "colBultos"
        Me.colBultos.ReadOnly = True
        Me.colBultos.Visible = False
        '
        'colTara
        '
        Me.colTara.HeaderText = "Tara"
        Me.colTara.Name = "colTara"
        Me.colTara.ReadOnly = True
        '
        'colTaraLbs
        '
        Me.colTaraLbs.HeaderText = "Lbs tare"
        Me.colTaraLbs.Name = "colTaraLbs"
        Me.colTaraLbs.ReadOnly = True
        Me.colTaraLbs.Visible = False
        '
        'colKilosNetos
        '
        Me.colKilosNetos.HeaderText = "Lb HSM"
        Me.colKilosNetos.Name = "colKilosNetos"
        Me.colKilosNetos.ReadOnly = True
        '
        'colKilosBrutos
        '
        Me.colKilosBrutos.HeaderText = "Lb Groos"
        Me.colKilosBrutos.Name = "colKilosBrutos"
        Me.colKilosBrutos.ReadOnly = True
        '
        'colLibrasBrutas
        '
        Me.colLibrasBrutas.HeaderText = "Paca"
        Me.colLibrasBrutas.Name = "colLibrasBrutas"
        Me.colLibrasBrutas.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Marca"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colXtraPack
        '
        Me.colXtraPack.HeaderText = "XtraPackingList"
        Me.colXtraPack.Name = "colXtraPack"
        Me.colXtraPack.ReadOnly = True
        Me.colXtraPack.Visible = False
        '
        'colLineaDet
        '
        Me.colLineaDet.HeaderText = "LineaDetalle"
        Me.colLineaDet.Name = "colLineaDet"
        Me.colLineaDet.ReadOnly = True
        Me.colLineaDet.Visible = False
        '
        'colLineaPack
        '
        Me.colLineaPack.HeaderText = "LineaPack"
        Me.colLineaPack.Name = "colLineaPack"
        Me.colLineaPack.ReadOnly = True
        Me.colLineaPack.Visible = False
        '
        'colTipoBulto
        '
        Me.colTipoBulto.HeaderText = "Categoria"
        Me.colTipoBulto.Name = "colTipoBulto"
        Me.colTipoBulto.ReadOnly = True
        '
        'col_Gin
        '
        Me.col_Gin.HeaderText = "Gin"
        Me.col_Gin.Name = "col_Gin"
        '
        'col_GinBac
        '
        Me.col_GinBac.HeaderText = "GinBal"
        Me.col_GinBac.Name = "col_GinBac"
        '
        'col_Crp
        '
        Me.col_Crp.HeaderText = "CRP"
        Me.col_Crp.Name = "col_Crp"
        '
        'col_referencia
        '
        Me.col_referencia.HeaderText = "Ref"
        Me.col_referencia.Name = "col_referencia"
        '
        'frmPackingHSM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1117, 626)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.dgDetalle)
        Me.Controls.Add(Me.panelTotales)
        Me.Controls.Add(Me.panelDatos)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmPackingHSM"
        Me.Text = "Packing Returns"
        Me.panelDatos.ResumeLayout(False)
        Me.gbLibras.ResumeLayout(False)
        Me.gbLibras.PerformLayout()
        Me.gbKilos.ResumeLayout(False)
        Me.gbKilos.PerformLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelDatos As Panel
    Friend WithEvents celdaKilosBrutos As TextBox
    Friend WithEvents etiquetaKilosBrutos As Label
    Friend WithEvents celdaKilosN As TextBox
    Friend WithEvents etiquetaKilosNetos As Label
    Friend WithEvents celdaTara As TextBox
    Friend WithEvents etiquetaTara As Label
    Friend WithEvents celdaPaquetes As TextBox
    Friend WithEvents etiquetapaquetes As Label
    Friend WithEvents celdaReferencia As TextBox
    Friend WithEvents etiquetaReferencia As Label
    Friend WithEvents botonAgregar As Button
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents gbLibras As GroupBox
    Friend WithEvents etiquetaLbsPaquetes As Label
    Friend WithEvents celdaReferenciaLbs As TextBox
    Friend WithEvents celdaLbsPaquetes As TextBox
    Friend WithEvents etiquetaReferenciaLbs As Label
    Friend WithEvents etiquetaLbsTara As Label
    Friend WithEvents celdaLbsTara As TextBox
    Friend WithEvents celdaLbsBrutas As TextBox
    Friend WithEvents etiquetaLbsNetas As Label
    Friend WithEvents etiquetaLbsBrutas As Label
    Friend WithEvents celdaLbsNetas As TextBox
    Friend WithEvents gbKilos As GroupBox
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaTotalK As TextBox
    Friend WithEvents celdaTotalLbs As TextBox
    Friend WithEvents etiquetaTotalK As Label
    Friend WithEvents etiquetaTotalLbs As Label
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaSumaBultos As TextBox
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents celdaLinea As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents botonMenos As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaAnio As System.Windows.Forms.TextBox
    Friend WithEvents botonTaraAprox As Button
    Friend WithEvents celdaTaraAprox As TextBox
    Friend WithEvents colBultos As DataGridViewTextBoxColumn
    Friend WithEvents colTara As DataGridViewTextBoxColumn
    Friend WithEvents colTaraLbs As DataGridViewTextBoxColumn
    Friend WithEvents colKilosNetos As DataGridViewTextBoxColumn
    Friend WithEvents colKilosBrutos As DataGridViewTextBoxColumn
    Friend WithEvents colLibrasBrutas As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colXtraPack As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDet As DataGridViewTextBoxColumn
    Friend WithEvents colLineaPack As DataGridViewTextBoxColumn
    Friend WithEvents colTipoBulto As DataGridViewTextBoxColumn
    Friend WithEvents col_Gin As DataGridViewTextBoxColumn
    Friend WithEvents col_GinBac As DataGridViewTextBoxColumn
    Friend WithEvents col_Crp As DataGridViewTextBoxColumn
    Friend WithEvents col_referencia As DataGridViewTextBoxColumn
End Class
