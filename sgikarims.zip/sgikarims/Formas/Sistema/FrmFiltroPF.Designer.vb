﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmFiltroPF
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelFiltro = New System.Windows.Forms.Panel()
        Me.checkMuestra = New System.Windows.Forms.CheckBox()
        Me.celdaIdMedida = New System.Windows.Forms.TextBox()
        Me.BotonMedida = New System.Windows.Forms.Button()
        Me.celdaMedida = New System.Windows.Forms.TextBox()
        Me.rbCadena3 = New System.Windows.Forms.RadioButton()
        Me.rbCadenaInsr = New System.Windows.Forms.RadioButton()
        Me.rbCadena1 = New System.Windows.Forms.RadioButton()
        Me.checkIncludeHeathers = New System.Windows.Forms.CheckBox()
        Me.botonRefrescar = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.botonContinente = New System.Windows.Forms.Button()
        Me.celdaidCountry = New System.Windows.Forms.TextBox()
        Me.celdaContinente = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaSpinning = New System.Windows.Forms.TextBox()
        Me.botonSpinning = New System.Windows.Forms.Button()
        Me.celdaidSpnning = New System.Windows.Forms.TextBox()
        Me.celdaDescripcionCorta = New System.Windows.Forms.TextBox()
        Me.celdaidClase = New System.Windows.Forms.TextBox()
        Me.celdaidAcabado = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaTitulo = New System.Windows.Forms.TextBox()
        Me.celdaidPais = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaCodigoProducto = New System.Windows.Forms.TextBox()
        Me.botonAcabado = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaAcabado = New System.Windows.Forms.TextBox()
        Me.celdaCodigoInventario = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonClase = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaClase = New System.Windows.Forms.TextBox()
        Me.celdaPais = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.botonPais = New System.Windows.Forms.Button()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.PanelDatagrid = New System.Windows.Forms.Panel()
        Me.dgInventario = New System.Windows.Forms.DataGridView()
        Me.colInventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidmedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelFiltro.SuspendLayout()
        Me.PanelBotones.SuspendLayout()
        Me.PanelDatagrid.SuspendLayout()
        CType(Me.dgInventario, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelFiltro
        '
        Me.PanelFiltro.Controls.Add(Me.checkMuestra)
        Me.PanelFiltro.Controls.Add(Me.celdaIdMedida)
        Me.PanelFiltro.Controls.Add(Me.BotonMedida)
        Me.PanelFiltro.Controls.Add(Me.celdaMedida)
        Me.PanelFiltro.Controls.Add(Me.rbCadena3)
        Me.PanelFiltro.Controls.Add(Me.rbCadenaInsr)
        Me.PanelFiltro.Controls.Add(Me.rbCadena1)
        Me.PanelFiltro.Controls.Add(Me.checkIncludeHeathers)
        Me.PanelFiltro.Controls.Add(Me.botonRefrescar)
        Me.PanelFiltro.Controls.Add(Me.botonBuscar)
        Me.PanelFiltro.Controls.Add(Me.botonContinente)
        Me.PanelFiltro.Controls.Add(Me.celdaidCountry)
        Me.PanelFiltro.Controls.Add(Me.celdaContinente)
        Me.PanelFiltro.Controls.Add(Me.Label9)
        Me.PanelFiltro.Controls.Add(Me.celdaSpinning)
        Me.PanelFiltro.Controls.Add(Me.botonSpinning)
        Me.PanelFiltro.Controls.Add(Me.celdaidSpnning)
        Me.PanelFiltro.Controls.Add(Me.celdaDescripcionCorta)
        Me.PanelFiltro.Controls.Add(Me.celdaidClase)
        Me.PanelFiltro.Controls.Add(Me.celdaidAcabado)
        Me.PanelFiltro.Controls.Add(Me.Label8)
        Me.PanelFiltro.Controls.Add(Me.Label4)
        Me.PanelFiltro.Controls.Add(Me.celdaTitulo)
        Me.PanelFiltro.Controls.Add(Me.celdaidPais)
        Me.PanelFiltro.Controls.Add(Me.Label3)
        Me.PanelFiltro.Controls.Add(Me.celdaCodigoProducto)
        Me.PanelFiltro.Controls.Add(Me.botonAcabado)
        Me.PanelFiltro.Controls.Add(Me.Label2)
        Me.PanelFiltro.Controls.Add(Me.celdaAcabado)
        Me.PanelFiltro.Controls.Add(Me.celdaCodigoInventario)
        Me.PanelFiltro.Controls.Add(Me.Label7)
        Me.PanelFiltro.Controls.Add(Me.Label1)
        Me.PanelFiltro.Controls.Add(Me.botonClase)
        Me.PanelFiltro.Controls.Add(Me.Label5)
        Me.PanelFiltro.Controls.Add(Me.celdaClase)
        Me.PanelFiltro.Controls.Add(Me.celdaPais)
        Me.PanelFiltro.Controls.Add(Me.Label6)
        Me.PanelFiltro.Controls.Add(Me.botonPais)
        Me.PanelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.PanelFiltro.Name = "PanelFiltro"
        Me.PanelFiltro.Size = New System.Drawing.Size(938, 205)
        Me.PanelFiltro.TabIndex = 0
        '
        'checkMuestra
        '
        Me.checkMuestra.AutoSize = True
        Me.checkMuestra.Location = New System.Drawing.Point(456, 174)
        Me.checkMuestra.Name = "checkMuestra"
        Me.checkMuestra.Size = New System.Drawing.Size(77, 21)
        Me.checkMuestra.TabIndex = 36
        Me.checkMuestra.Text = "Sample"
        Me.checkMuestra.UseVisualStyleBackColor = True
        '
        'celdaIdMedida
        '
        Me.celdaIdMedida.Location = New System.Drawing.Point(105, 167)
        Me.celdaIdMedida.Name = "celdaIdMedida"
        Me.celdaIdMedida.Size = New System.Drawing.Size(17, 22)
        Me.celdaIdMedida.TabIndex = 35
        Me.celdaIdMedida.Text = "-1"
        Me.celdaIdMedida.Visible = False
        '
        'BotonMedida
        '
        Me.BotonMedida.Location = New System.Drawing.Point(386, 167)
        Me.BotonMedida.Name = "BotonMedida"
        Me.BotonMedida.Size = New System.Drawing.Size(36, 23)
        Me.BotonMedida.TabIndex = 34
        Me.BotonMedida.Text = "..."
        Me.BotonMedida.UseVisualStyleBackColor = True
        '
        'celdaMedida
        '
        Me.celdaMedida.Location = New System.Drawing.Point(144, 166)
        Me.celdaMedida.Name = "celdaMedida"
        Me.celdaMedida.ReadOnly = True
        Me.celdaMedida.Size = New System.Drawing.Size(236, 22)
        Me.celdaMedida.TabIndex = 33
        '
        'rbCadena3
        '
        Me.rbCadena3.AutoSize = True
        Me.rbCadena3.Location = New System.Drawing.Point(733, 43)
        Me.rbCadena3.Name = "rbCadena3"
        Me.rbCadena3.Size = New System.Drawing.Size(86, 21)
        Me.rbCadena3.TabIndex = 29
        Me.rbCadena3.Text = "End With"
        Me.rbCadena3.UseVisualStyleBackColor = True
        '
        'rbCadenaInsr
        '
        Me.rbCadenaInsr.AutoSize = True
        Me.rbCadenaInsr.Checked = True
        Me.rbCadenaInsr.Location = New System.Drawing.Point(631, 43)
        Me.rbCadenaInsr.Name = "rbCadenaInsr"
        Me.rbCadenaInsr.Size = New System.Drawing.Size(77, 21)
        Me.rbCadenaInsr.TabIndex = 28
        Me.rbCadenaInsr.TabStop = True
        Me.rbCadenaInsr.Text = "Contain"
        Me.rbCadenaInsr.UseVisualStyleBackColor = True
        '
        'rbCadena1
        '
        Me.rbCadena1.AutoSize = True
        Me.rbCadena1.Location = New System.Drawing.Point(517, 43)
        Me.rbCadena1.Name = "rbCadena1"
        Me.rbCadena1.Size = New System.Drawing.Size(91, 21)
        Me.rbCadena1.TabIndex = 27
        Me.rbCadena1.Text = "Start With"
        Me.rbCadena1.UseVisualStyleBackColor = True
        '
        'checkIncludeHeathers
        '
        Me.checkIncludeHeathers.AutoSize = True
        Me.checkIncludeHeathers.Location = New System.Drawing.Point(13, 168)
        Me.checkIncludeHeathers.Name = "checkIncludeHeathers"
        Me.checkIncludeHeathers.Size = New System.Drawing.Size(92, 21)
        Me.checkIncludeHeathers.TabIndex = 22
        Me.checkIncludeHeathers.Text = " Heathers"
        Me.checkIncludeHeathers.UseVisualStyleBackColor = True
        '
        'botonRefrescar
        '
        Me.botonRefrescar.Location = New System.Drawing.Point(785, 168)
        Me.botonRefrescar.Name = "botonRefrescar"
        Me.botonRefrescar.Size = New System.Drawing.Size(74, 30)
        Me.botonRefrescar.TabIndex = 21
        Me.botonRefrescar.Text = "Reset "
        Me.botonRefrescar.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.search
        Me.botonBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.botonBuscar.Location = New System.Drawing.Point(674, 168)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(89, 31)
        Me.botonBuscar.TabIndex = 20
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'botonContinente
        '
        Me.botonContinente.Location = New System.Drawing.Point(386, 132)
        Me.botonContinente.Name = "botonContinente"
        Me.botonContinente.Size = New System.Drawing.Size(36, 23)
        Me.botonContinente.TabIndex = 19
        Me.botonContinente.Text = "..."
        Me.botonContinente.UseVisualStyleBackColor = True
        '
        'celdaidCountry
        '
        Me.celdaidCountry.Location = New System.Drawing.Point(105, 133)
        Me.celdaidCountry.Name = "celdaidCountry"
        Me.celdaidCountry.Size = New System.Drawing.Size(17, 22)
        Me.celdaidCountry.TabIndex = 18
        Me.celdaidCountry.Text = "-1"
        Me.celdaidCountry.Visible = False
        '
        'celdaContinente
        '
        Me.celdaContinente.Location = New System.Drawing.Point(143, 133)
        Me.celdaContinente.Name = "celdaContinente"
        Me.celdaContinente.ReadOnly = True
        Me.celdaContinente.Size = New System.Drawing.Size(237, 22)
        Me.celdaContinente.TabIndex = 17
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 130)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 17)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Region"
        '
        'celdaSpinning
        '
        Me.celdaSpinning.Location = New System.Drawing.Point(574, 141)
        Me.celdaSpinning.Name = "celdaSpinning"
        Me.celdaSpinning.ReadOnly = True
        Me.celdaSpinning.Size = New System.Drawing.Size(247, 22)
        Me.celdaSpinning.TabIndex = 10
        '
        'botonSpinning
        '
        Me.botonSpinning.Location = New System.Drawing.Point(827, 140)
        Me.botonSpinning.Name = "botonSpinning"
        Me.botonSpinning.Size = New System.Drawing.Size(36, 23)
        Me.botonSpinning.TabIndex = 11
        Me.botonSpinning.Text = "..."
        Me.botonSpinning.UseVisualStyleBackColor = True
        '
        'celdaidSpnning
        '
        Me.celdaidSpnning.Location = New System.Drawing.Point(541, 144)
        Me.celdaidSpnning.Name = "celdaidSpnning"
        Me.celdaidSpnning.Size = New System.Drawing.Size(17, 22)
        Me.celdaidSpnning.TabIndex = 15
        Me.celdaidSpnning.Text = "-1"
        Me.celdaidSpnning.Visible = False
        '
        'celdaDescripcionCorta
        '
        Me.celdaDescripcionCorta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDescripcionCorta.Location = New System.Drawing.Point(574, 78)
        Me.celdaDescripcionCorta.Name = "celdaDescripcionCorta"
        Me.celdaDescripcionCorta.Size = New System.Drawing.Size(279, 22)
        Me.celdaDescripcionCorta.TabIndex = 6
        '
        'celdaidClase
        '
        Me.celdaidClase.Location = New System.Drawing.Point(541, 108)
        Me.celdaidClase.Name = "celdaidClase"
        Me.celdaidClase.Size = New System.Drawing.Size(17, 22)
        Me.celdaidClase.TabIndex = 13
        Me.celdaidClase.Text = "-1"
        Me.celdaidClase.Visible = False
        '
        'celdaidAcabado
        '
        Me.celdaidAcabado.Location = New System.Drawing.Point(105, 104)
        Me.celdaidAcabado.Name = "celdaidAcabado"
        Me.celdaidAcabado.Size = New System.Drawing.Size(17, 22)
        Me.celdaidAcabado.TabIndex = 14
        Me.celdaidAcabado.Text = "-1"
        Me.celdaidAcabado.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(453, 142)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 17)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Spinning"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(437, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 17)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Short Description"
        '
        'celdaTitulo
        '
        Me.celdaTitulo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTitulo.Location = New System.Drawing.Point(143, 42)
        Me.celdaTitulo.Name = "celdaTitulo"
        Me.celdaTitulo.Size = New System.Drawing.Size(279, 22)
        Me.celdaTitulo.TabIndex = 4
        '
        'celdaidPais
        '
        Me.celdaidPais.Location = New System.Drawing.Point(105, 72)
        Me.celdaidPais.Name = "celdaidPais"
        Me.celdaidPais.Size = New System.Drawing.Size(17, 22)
        Me.celdaidPais.TabIndex = 12
        Me.celdaidPais.Text = "-1"
        Me.celdaidPais.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 17)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Title"
        '
        'celdaCodigoProducto
        '
        Me.celdaCodigoProducto.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigoProducto.Location = New System.Drawing.Point(570, 12)
        Me.celdaCodigoProducto.Name = "celdaCodigoProducto"
        Me.celdaCodigoProducto.Size = New System.Drawing.Size(279, 22)
        Me.celdaCodigoProducto.TabIndex = 3
        '
        'botonAcabado
        '
        Me.botonAcabado.Location = New System.Drawing.Point(386, 105)
        Me.botonAcabado.Name = "botonAcabado"
        Me.botonAcabado.Size = New System.Drawing.Size(36, 23)
        Me.botonAcabado.TabIndex = 8
        Me.botonAcabado.Text = "..."
        Me.botonAcabado.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(437, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Product Code"
        '
        'celdaAcabado
        '
        Me.celdaAcabado.Location = New System.Drawing.Point(144, 105)
        Me.celdaAcabado.Name = "celdaAcabado"
        Me.celdaAcabado.ReadOnly = True
        Me.celdaAcabado.Size = New System.Drawing.Size(236, 22)
        Me.celdaAcabado.TabIndex = 7
        '
        'celdaCodigoInventario
        '
        Me.celdaCodigoInventario.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigoInventario.Location = New System.Drawing.Point(143, 12)
        Me.celdaCodigoInventario.Name = "celdaCodigoInventario"
        Me.celdaCodigoInventario.Size = New System.Drawing.Size(279, 22)
        Me.celdaCodigoInventario.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 104)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Finish"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Inventory Code"
        '
        'botonClase
        '
        Me.botonClase.Location = New System.Drawing.Point(827, 107)
        Me.botonClase.Name = "botonClase"
        Me.botonClase.Size = New System.Drawing.Size(36, 23)
        Me.botonClase.TabIndex = 5
        Me.botonClase.Text = "..."
        Me.botonClase.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(10, 75)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 17)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Country"
        '
        'celdaClase
        '
        Me.celdaClase.Location = New System.Drawing.Point(574, 109)
        Me.celdaClase.Name = "celdaClase"
        Me.celdaClase.ReadOnly = True
        Me.celdaClase.Size = New System.Drawing.Size(247, 22)
        Me.celdaClase.TabIndex = 4
        '
        'celdaPais
        '
        Me.celdaPais.Location = New System.Drawing.Point(143, 75)
        Me.celdaPais.Name = "celdaPais"
        Me.celdaPais.ReadOnly = True
        Me.celdaPais.Size = New System.Drawing.Size(237, 22)
        Me.celdaPais.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(465, 109)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 17)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Class"
        '
        'botonPais
        '
        Me.botonPais.Location = New System.Drawing.Point(386, 75)
        Me.botonPais.Name = "botonPais"
        Me.botonPais.Size = New System.Drawing.Size(36, 23)
        Me.botonPais.TabIndex = 2
        Me.botonPais.Text = "..."
        Me.botonPais.UseVisualStyleBackColor = True
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.botonCancelar)
        Me.PanelBotones.Controls.Add(Me.botonAceptar)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelBotones.Location = New System.Drawing.Point(0, 474)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(938, 67)
        Me.PanelBotones.TabIndex = 1
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(851, 8)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 47)
        Me.botonCancelar.TabIndex = 20
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAceptar.Location = New System.Drawing.Point(733, 8)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(77, 47)
        Me.botonAceptar.TabIndex = 19
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'PanelDatagrid
        '
        Me.PanelDatagrid.Controls.Add(Me.dgInventario)
        Me.PanelDatagrid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDatagrid.Location = New System.Drawing.Point(0, 205)
        Me.PanelDatagrid.Name = "PanelDatagrid"
        Me.PanelDatagrid.Size = New System.Drawing.Size(938, 269)
        Me.PanelDatagrid.TabIndex = 2
        '
        'dgInventario
        '
        Me.dgInventario.AllowUserToAddRows = False
        Me.dgInventario.AllowUserToDeleteRows = False
        Me.dgInventario.AllowUserToOrderColumns = True
        Me.dgInventario.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgInventario.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgInventario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgInventario.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colInventario, Me.colDescripcion, Me.colidmedida, Me.colMedida, Me.colOrigen})
        Me.dgInventario.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgInventario.Location = New System.Drawing.Point(0, 0)
        Me.dgInventario.Name = "dgInventario"
        Me.dgInventario.ReadOnly = True
        Me.dgInventario.RowTemplate.Height = 24
        Me.dgInventario.Size = New System.Drawing.Size(938, 269)
        Me.dgInventario.TabIndex = 0
        '
        'colInventario
        '
        Me.colInventario.HeaderText = "Inventory"
        Me.colInventario.Name = "colInventario"
        Me.colInventario.ReadOnly = True
        Me.colInventario.Width = 95
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'colidmedida
        '
        Me.colidmedida.HeaderText = "NumMedida"
        Me.colidmedida.Name = "colidmedida"
        Me.colidmedida.ReadOnly = True
        Me.colidmedida.Visible = False
        Me.colidmedida.Width = 112
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 92
        '
        'colOrigen
        '
        Me.colOrigen.HeaderText = "Origen"
        Me.colOrigen.Name = "colOrigen"
        Me.colOrigen.ReadOnly = True
        Me.colOrigen.Width = 80
        '
        'FrmFiltroPF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(938, 541)
        Me.Controls.Add(Me.PanelDatagrid)
        Me.Controls.Add(Me.PanelBotones)
        Me.Controls.Add(Me.PanelFiltro)
        Me.Name = "FrmFiltroPF"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Select A Product"
        Me.PanelFiltro.ResumeLayout(False)
        Me.PanelFiltro.PerformLayout()
        Me.PanelBotones.ResumeLayout(False)
        Me.PanelDatagrid.ResumeLayout(False)
        CType(Me.dgInventario, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelFiltro As Panel
    Friend WithEvents celdaCodigoProducto As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaCodigoInventario As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaDescripcionCorta As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaTitulo As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents botonPais As Button
    Friend WithEvents celdaPais As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents botonClase As Button
    Friend WithEvents celdaClase As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents botonAcabado As Button
    Friend WithEvents celdaAcabado As TextBox
    Friend WithEvents botonSpinning As Button
    Friend WithEvents celdaSpinning As TextBox
    Friend WithEvents celdaidSpnning As TextBox
    Friend WithEvents celdaidAcabado As TextBox
    Friend WithEvents celdaidClase As TextBox
    Friend WithEvents celdaidPais As TextBox
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonContinente As Button
    Friend WithEvents celdaidCountry As TextBox
    Friend WithEvents celdaContinente As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents botonBuscar As Button
    Friend WithEvents PanelDatagrid As Panel
    Friend WithEvents dgInventario As DataGridView
    Friend WithEvents botonRefrescar As Button
    Friend WithEvents colInventario As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colidmedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As DataGridViewTextBoxColumn
    Friend WithEvents checkIncludeHeathers As System.Windows.Forms.CheckBox
    Friend WithEvents rbCadena3 As RadioButton
    Friend WithEvents rbCadenaInsr As RadioButton
    Friend WithEvents rbCadena1 As RadioButton
    Friend WithEvents celdaIdMedida As TextBox
    Friend WithEvents BotonMedida As Button
    Friend WithEvents celdaMedida As TextBox
    Friend WithEvents checkMuestra As System.Windows.Forms.CheckBox
End Class
