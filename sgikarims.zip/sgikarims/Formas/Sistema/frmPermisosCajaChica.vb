﻿Public Class frmPermisosCajaChica

    Dim strKey As String = STR_VACIO
    Public intnumeroCaja As Integer
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property NumeroCaja As Integer
        Get
            Return intnumeroCaja
        End Get
        Set(value As Integer)
            intnumeroCaja = value
        End Set
    End Property

#Region "Procedimientos"
    Private Function SQLCargarCajasPermitidas()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT c.BCta_Num Codigo, c.BCta_Nom_Cue Nombre, c.BCta_Des_Cue Descripcion, n.cat_ext Moneda "
        strSQL &= "    From CtasBcos c "
        strSQL &= "    Left JOIN Catalogos n ON n.cat_clase = 'Monedas' AND n.cat_num = c.BCta_Mon "
        strSQL &= "    Left JOIN Permisos p ON p.pms_empresa = c.BCta_Sis_Emp AND p.pms_modulo = 13 AND p.pms_id = c.BCta_Num "
        strSQL &= "        WHERE c.BCta_Sis_Emp = {empresa} AND c.BCta_Tipo IN (1,2,3) AND p.pms_usuario = '{usuario}' "
        strSQL &= "        ORDER BY c.BCta_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", celdaIdUsuario.Text)

        Return strSQL
    End Function

    Public Sub CargarCajasPermitidas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarCajasPermitidas()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgCajasChicas.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("Nombre") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Moneda")

                    cFunciones.AgregarFila(dgCajasChicas, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Eventos"
    Private Sub botonUsuario_Click(sender As Object, e As EventArgs) Handles botonUsuario.Click
        Dim frm As New frmSeleccionar
        celdaIdUsuario.Clear()
        celdaIdUsuario.Clear()
        Try
            frm.Titulo = "Select a User"
            frm.Campos = "CONCAT(p.per_nombre1, ' ', p.per_apellido1) Caja, p.per_usuario usuario "
            frm.Tabla = "Personal p "
            frm.Condicion = " p.per_sisemp = " & Sesion.IdEmpresa & " AND p.per_estado = 1"
            frm.Limite = 15
            frm.FiltroText = "Enter the User to filter"
            frm.Filtro = "p.per_nombre1 "
            frm.Ordenamiento = "p.per_nombre1"
            frm.TipoOrdenamiento = "ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaUsuario.Text = frm.LLave
                celdaIdUsuario.Text = frm.Dato
                CargarCajasPermitidas()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            frm.Titulo = "Select a Petty cash "
            frm.Campos = "c.BCta_Num Codigo, c.BCta_Nom_Cue Nombre, c.BCta_Des_Cue Descripcion "
            frm.Tabla = " CtasBcos c LEFT JOIN Permisos p ON p.pms_empresa = c.BCta_Sis_Emp AND p.pms_modulo = 13 AND p.pms_id = c.BCta_Num AND (p.pms_usuario ='" & celdaIdUsuario.Text & "')"
            frm.Condicion = "c.BCta_Sis_Emp = " & Sesion.IdEmpresa & " AND c.BCta_Tipo IN (1,2,3) AND ((p.pms_usuario IS NULL) OR NOT(p.pms_usuario ='" & celdaIdUsuario.Text & "')) AND c.BCta_Status = 1"
            'frm.Limite = 25
            frm.FiltroText = "Enter the Petty Cash to filter"
            frm.Filtro = "c.BCta_Nom_Cue "
            frm.Ordenamiento = "c.BCta_Num "
            frm.Ordenamiento = "c.BCta_Num, c.BCta_Tipo"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                ' Insertar en la tabla permisos
                strSQL = " INSERT INTO Permisos (pms_registro,pms_empresa,pms_modulo,pms_usuario,pms_id,pms_codigo,pms_nivel) "
                strSQL &= " VALUES (0,{empresa},13,'{user}',{cod},'ALL',0) "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{user}", celdaIdUsuario.Text)
                strSQL = Replace(strSQL, "{cod}", frm.LLave)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()

                CargarCajasPermitidas()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()
    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        If MsgBox("You are sure to delete this permission", vbYesNo, "Question") = vbYes Then
            strSQL = " DELETE FROM Permisos WHERE pms_empresa ={empresa} AND pms_usuario = '{user}' AND pms_modulo = 13 AND pms_id = {id}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{user}", celdaIdUsuario.Text)
            strSQL = Replace(strSQL, "{id}", dgCajasChicas.CurrentRow.Cells("colCodigo").Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            MsgBox("The permit has been removed", vbInformation, "Notice")
            CargarCajasPermitidas()
        End If
    End Sub

#End Region
End Class