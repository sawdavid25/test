﻿Public Class frmBackup

#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos y Funciones"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub reset()
        celdaID.Text = NO_FILA
        CheckActivo.Checked = True
        dtpFecha.Value = Today
        dgDetalle.Rows.Clear()
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelDocumento.Dock = DockStyle.None
            PanelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Backup Control")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            PanelDocumento.Dock = DockStyle.Fill
            PanelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                reset()
            End If
            dgLista.DataSource = Nothing
        End If
    End Sub

    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT b.Id_Bk , b.Fecha , if(b.Estado =0 ,'Canceled','Active') Estado 
                        from BK_Cobian b
                        WHERE b.Id_Empresa = {empresa}
                        ORDER BY b.Fecha desc "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function

    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strLinea = REA.GetString("Id_Bk") & "|" 'Año
                    strLinea &= REA.GetMySqlDateTime("Fecha").ToString & "|" 'Numero 
                    strLinea &= REA.GetString("Estado")  'Fecha
                    If REA.GetString("Estado") = "Active" Then
                        cFunciones.AgregarFila(dgLista, strLinea)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    End If

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlEncabezado(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT b.Id_Bk , b.Fecha ,b.Estado 
                    from BK_Cobian b
                    WHERE b.Id_Empresa = {empresa} AND b.Id_Bk = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function

    Public Sub CargarEncabezado(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlEncabezado(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaID.Text = REA.GetInt32("Id_Bk")

                    dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    If REA.GetInt32("Estado") = INT_UNO Then
                        CheckActivo.Checked = True
                    Else
                        CheckActivo.Checked = False
                    End If
                Loop
            End If
            COM = Nothing
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlDtalle(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT i.id_Inventario ,IFNULL(CONCAT(p.per_nombre1, ' ',p.per_apellido1),'') usuario, i.Codigo_Equipo , d.Id_Tarea idtarea ,c.Nombre  ,d.Comentario , if(d.Id_Estado = 1 ,'Good','Bad')Estado , d.Linea 
                     FROM BK_Cobian_DTL d
	                    LEFT JOIN Cobian c ON c.id_Empresa = d.Id_Empresa AND c.id_Inventario = d.Id_Inventario AND c.id_Linea = d.Id_Tarea 
	                    LEFT JOIN InventarioIT i ON i.id_Empresa = c.id_Empresa AND i.id_Inventario = c.id_Inventario 
	                    LEFT JOIN Personal p ON p.per_sisemp = i.id_Empresa AND p.per_codigo = i.id_Asignacion 
                    WHERE d.Id_Empresa = {empresa} AND d.Id_BK = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function

    Public Sub CargarDetalle(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        strSQL = sqlDtalle(Codigo)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dgDetalle.Rows.Clear()
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                strFila = REA.GetInt32("id_Inventario") & "|"
                strFila &= REA.GetString("usuario") & "|"
                strFila &= REA.GetString("Codigo_Equipo") & "|"
                strFila &= REA.GetInt32("idtarea") & "|"
                strFila &= REA.GetString("Nombre") & "|"
                strFila &= REA.GetString("Comentario") & "|"
                strFila &= REA.GetString("Estado") & "|"
                strFila &= REA.GetString("Linea") & "|"
                strFila &= INT_UNO
                If REA.GetString("Estado") = "Bad" Then
                    cfun.AgregarFila(dgDetalle, strFila, Color.Coral)
                Else
                    cfun.AgregarFila(dgDetalle, strFila)
                End If
            Loop
        End If
    End Sub

    Public Sub CargarDatosIniciales()
        Dim frm As New frmFiltro
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            frm.Titulo = " Seleccione un Fecha"

            frm.BanderaCorte = True
            frm.BanderaFechas = False
            frm.BanderaOpcion = False
            frm.BanderaFiltro = False

            frm.Titulo = " Seleccione una fecha "

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                dtpFecha.Value = frm.FechaCorte
                strSQL = " SELECT i.id_Inventario , IFNULL(CONCAT(p.per_nombre1, ' ',p.per_apellido1),'') usuario, i.Codigo_Equipo ,c.id_Linea idTarea , c.Nombre ,''  Comentario, 'Bad' Estado, 0 Linea 
                            FROM Cobian c
                            LEFT JOIN InventarioIT i ON i.id_Empresa = c.id_Empresa AND i.id_Inventario = c.id_Inventario 
                            LEFT JOIN Personal p ON p.per_sisemp = i.id_Empresa AND p.per_codigo = i.id_Asignacion 
                            WHERE c.id_Empresa = {empresa} AND c.Dia = {dia} AND c.Estado = 1 "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{dia}", dtpFecha.Value.DayOfWeek + 1)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                dgDetalle.Rows.Clear()
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        strFila = REA.GetInt32("id_Inventario") & "|"
                        strFila &= REA.GetString("usuario") & "|"
                        strFila &= REA.GetString("Codigo_Equipo") & "|"
                        strFila &= REA.GetInt32("idtarea") & "|"
                        strFila &= REA.GetString("Nombre") & "|"
                        strFila &= REA.GetString("Comentario") & "|"
                        strFila &= REA.GetString("Estado") & "|"
                        strFila &= REA.GetString("Linea") & "|"
                        strFila &= INT_CERO
                        If REA.GetString("Estado") = "Bad" Then
                            cfun.AgregarFila(dgDetalle, strFila, Color.Coral)
                        Else
                            cfun.AgregarFila(dgDetalle, strFila)
                        End If
                    Loop

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        Return LogVerdadero
    End Function

    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " SELECT ifnull(MAX(d.Linea ),0)+1 
                    FROM BK_Cobian_DTL d
                    WHERE d.Id_Empresa = {empresa} AND d.Id_BK = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function

    Private Function NuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " SELECT IFNULL( MAX(b.Id_Bk ) ,0)+1 FROM BK_Cobian b
                WHERE b.Id_Empresa = {empresa}   "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function

    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = True
        Dim IntId As Integer = NO_FILA
        Dim cCobian As New Tablas.TBK_COBIAN
        Try
            cCobian.CONEXION = strConexion
            cCobian.ID_EMPRESA = Sesion.IdEmpresa
            cCobian.Fecha_NET = dtpFecha.Value

            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    IntId = NuevoCodigo()
                    cCobian.ID_BK = IntId
                    If CheckActivo.Checked = True Then
                        cCobian.ESTADO = INT_UNO
                    Else
                        cCobian.ESTADO = INT_CERO
                    End If

                    If cCobian.PINSERT = False Then
                        MsgBox(cCobian.MERROR.ToString)
                        Return False
                        Exit Function
                    Else
                        celdaID.Text = IntId
                        If GuardarDetalle(IntId) Then
                            logResultado = True
                        Else
                            logResultado = False
                        End If
                        cFunciones.EscribirRegistro("Backup", clsFunciones.AccEnum.acAdd, celdaID.Text, 0, 0, celdaID.Text, Notas:=dtpFecha.Value.ToString)
                    End If
                Else
                    MsgBox("You don't have permission to save ")
                    Return False
                    Exit Function
                End If
            Else
                If logEditar = True Then
                    cCobian.ID_EMPRESA = Sesion.IdEmpresa
                    IntId = celdaID.Text
                    cCobian.Fecha_NET = dtpFecha.Value
                    cCobian.ID_BK = IntId
                    If CheckActivo.Checked = True Then
                        cCobian.ESTADO = INT_UNO
                    Else
                        cCobian.ESTADO = INT_CERO
                    End If
                    If cCobian.PUPDATE = False Then
                        MsgBox(cCobian.MERROR.ToString)
                        Return False
                        Exit Function
                    Else
                        If GuardarDetalle(IntId) Then
                            logResultado = True
                        Else
                            logResultado = False
                        End If
                        cFunciones.EscribirRegistro("Activos", clsFunciones.AccEnum.acUpdate, celdaID.Text, 0, 0, celdaID.Text, Notas:=dtpFecha.Value.ToString)
                    End If
                Else
                    MsgBox("You don't have permission to update ")
                    Return False
                    Exit Function
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDetalle(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cCobiain As New Tablas.TBK_COBIAN_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                cCobiain.ID_EMPRESA = Sesion.IdEmpresa
                cCobiain.ID_BK = numero
                cCobiain.ID_INVENTARIO = dgDetalle.Rows(i).Cells("colCodigo").Value
                cCobiain.ID_TAREA = dgDetalle.Rows(i).Cells("colIDTarea").Value
                If dgDetalle.Rows(i).Cells("colEstado").Value = "Bad" Then
                    cCobiain.ID_ESTADO = 0
                Else
                    cCobiain.ID_ESTADO = 1
                End If
                cCobiain.COMENTARIO = dgDetalle.Rows(i).Cells("colComentario").Value

                Select Case dgDetalle.Rows(i).Cells("colMarca").Value
                    Case 0 'Guardar nueva Linea
                        dgDetalle.Rows(i).Cells("colLinea").Value = NuevaLinea(numero)
                        cCobiain.LINEA = dgDetalle.Rows(i).Cells("colLinea").Value
                        cCobiain.CONEXION = strConexion
                        If cCobiain.PINSERT = False Then
                            logResultado = False
                            MsgBox(cCobiain.MERROR.ToString)
                        End If
                    Case 1 'Actualizar Linea
                        cCobiain.LINEA = dgDetalle.Rows(i).Cells("colLinea").Value
                        cCobiain.CONEXION = strConexion
                        If cCobiain.PUPDATE = False Then
                            logResultado = False
                            MsgBox(cCobiain.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        cCobiain.LINEA = dgDetalle.Rows(i).Cells("colLinea").Value
                        cCobiain.CONEXION = strConexion
                        If cCobiain.PDELETE = False Then
                            logResultado = False
                            MsgBox(cCobiain.MERROR.ToString)
                        End If
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function Borrar() As Boolean
        Dim LogResultado As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM  BK_Cobian  WHERE Id_Empresa = {empresa} AND Id_Bk = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaID.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            LogResultado = True

            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM  BK_Cobian_DTL  WHERE  Id_Empresa = {empresa} AND Id_BK = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaID.Text)
            COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                COM = Nothing
            LogResultado = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function

    Private Function ValidarDependencia() As Boolean
        Dim loresultado As Boolean = True
        Try

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return loresultado
    End Function

#End Region


    Private Sub frmBackup_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        MostrarLista()

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            MostrarLista(False, True)
            reset()
            CargarDatosIniciales()
        Else
            MsgBox("You don´t have access to insert")
        End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If ValidarDependencia() = False Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    Borrar()

                    cFunciones.EscribirRegistro("Activos", clsFunciones.AccEnum.acDelete, celdaID.Text, 0, 0, celdaID.Text, Notas:=dtpFecha.Value.ToString)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            reset()
            CargarEncabezado(dgLista.SelectedCells(0).Value)
            CargarDetalle(dgLista.SelectedCells(0).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmBackup_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(0, 0, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                ' historial

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 6
                If dgDetalle.CurrentCell.Value = "Bad" Then
                    dgDetalle.CurrentCell.Value = "Good"
                    For Each cel As DataGridViewCell In dgDetalle.CurrentRow.Cells
                        cel.Style.BackColor = Color.White
                    Next
                Else
                    dgDetalle.CurrentCell.Value = "Bad"
                    For Each cel As DataGridViewCell In dgDetalle.CurrentRow.Cells
                        cel.Style.BackColor = Color.Coral
                    Next
                End If
        End Select
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try

            If ComprobarFila() Then

                If Guardar() = True Then
                    MsgBox("save successful")
                    MostrarLista(True)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


End Class