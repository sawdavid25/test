﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRequisiciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelInfo1 = New System.Windows.Forms.Panel()
        Me.celdaInfoGeneral = New System.Windows.Forms.TextBox()
        Me.celdaInfo1 = New System.Windows.Forms.TextBox()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelInfo2 = New System.Windows.Forms.Panel()
        Me.celdaIcotern = New System.Windows.Forms.TextBox()
        Me.celdaPrecio = New System.Windows.Forms.TextBox()
        Me.celdaInfoProducto = New System.Windows.Forms.TextBox()
        Me.celdaInfo2 = New System.Windows.Forms.TextBox()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPais = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSemana = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tipoCambio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGFMO = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricForm = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTenido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelInfo1.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelInfo2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelInfo1
        '
        Me.panelInfo1.BackColor = System.Drawing.SystemColors.Control
        Me.panelInfo1.Controls.Add(Me.celdaInfoGeneral)
        Me.panelInfo1.Controls.Add(Me.celdaInfo1)
        Me.panelInfo1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelInfo1.Location = New System.Drawing.Point(0, 0)
        Me.panelInfo1.Margin = New System.Windows.Forms.Padding(4)
        Me.panelInfo1.Name = "panelInfo1"
        Me.panelInfo1.Size = New System.Drawing.Size(1018, 162)
        Me.panelInfo1.TabIndex = 0
        '
        'celdaInfoGeneral
        '
        Me.celdaInfoGeneral.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoGeneral.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfoGeneral.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaInfoGeneral.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaInfoGeneral.ForeColor = System.Drawing.Color.Black
        Me.celdaInfoGeneral.Location = New System.Drawing.Point(0, 30)
        Me.celdaInfoGeneral.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfoGeneral.Multiline = True
        Me.celdaInfoGeneral.Name = "celdaInfoGeneral"
        Me.celdaInfoGeneral.ReadOnly = True
        Me.celdaInfoGeneral.Size = New System.Drawing.Size(1018, 126)
        Me.celdaInfoGeneral.TabIndex = 1
        '
        'celdaInfo1
        '
        Me.celdaInfo1.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfo1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaInfo1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaInfo1.ForeColor = System.Drawing.Color.Blue
        Me.celdaInfo1.Location = New System.Drawing.Point(0, 0)
        Me.celdaInfo1.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfo1.Multiline = True
        Me.celdaInfo1.Name = "celdaInfo1"
        Me.celdaInfo1.ReadOnly = True
        Me.celdaInfo1.Size = New System.Drawing.Size(1018, 30)
        Me.celdaInfo1.TabIndex = 0
        Me.celdaInfo1.Text = "Producto Embarcado"
        '
        'panelLista
        '
        Me.panelLista.BackColor = System.Drawing.Color.LightSteelBlue
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLista.Location = New System.Drawing.Point(0, 0)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1018, 213)
        Me.panelLista.TabIndex = 1
        '
        'dgLista
        '
        Me.dgLista.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.Color.LightSteelBlue
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Transparent
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFecha, Me.colNumero, Me.colReferencia, Me.colLinea, Me.colAno, Me.colCodigo, Me.colDescripcion, Me.colPrecio, Me.colCantidad, Me.colMedida, Me.colDescargo, Me.colPais, Me.colFabricante, Me.colSemana, Me.colLote, Me.colClase, Me.colUnit, Me.colEstado, Me.colVendido, Me.tipoCambio, Me.colGFMO, Me.colFabricForm, Me.colLoteProd, Me.colTenido})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.GridColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1018, 213)
        Me.dgLista.TabIndex = 1
        '
        'panelInfo2
        '
        Me.panelInfo2.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.panelInfo2.BackColor = System.Drawing.SystemColors.Control
        Me.panelInfo2.Controls.Add(Me.celdaIcotern)
        Me.panelInfo2.Controls.Add(Me.celdaPrecio)
        Me.panelInfo2.Controls.Add(Me.celdaInfoProducto)
        Me.panelInfo2.Controls.Add(Me.celdaInfo2)
        Me.panelInfo2.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelInfo2.Location = New System.Drawing.Point(0, 375)
        Me.panelInfo2.Margin = New System.Windows.Forms.Padding(4)
        Me.panelInfo2.Name = "panelInfo2"
        Me.panelInfo2.Size = New System.Drawing.Size(1018, 161)
        Me.panelInfo2.TabIndex = 2
        '
        'celdaIcotern
        '
        Me.celdaIcotern.BackColor = System.Drawing.SystemColors.HotTrack
        Me.celdaIcotern.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.celdaIcotern.Location = New System.Drawing.Point(790, 8)
        Me.celdaIcotern.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIcotern.Name = "celdaIcotern"
        Me.celdaIcotern.Size = New System.Drawing.Size(89, 22)
        Me.celdaIcotern.TabIndex = 3
        '
        'celdaPrecio
        '
        Me.celdaPrecio.Location = New System.Drawing.Point(790, 37)
        Me.celdaPrecio.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPrecio.Name = "celdaPrecio"
        Me.celdaPrecio.Size = New System.Drawing.Size(89, 22)
        Me.celdaPrecio.TabIndex = 2
        '
        'celdaInfoProducto
        '
        Me.celdaInfoProducto.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoProducto.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfoProducto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.celdaInfoProducto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaInfoProducto.ForeColor = System.Drawing.Color.Black
        Me.celdaInfoProducto.Location = New System.Drawing.Point(0, 27)
        Me.celdaInfoProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfoProducto.Multiline = True
        Me.celdaInfoProducto.Name = "celdaInfoProducto"
        Me.celdaInfoProducto.ReadOnly = True
        Me.celdaInfoProducto.Size = New System.Drawing.Size(1018, 134)
        Me.celdaInfoProducto.TabIndex = 1
        '
        'celdaInfo2
        '
        Me.celdaInfo2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfo2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfo2.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaInfo2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaInfo2.ForeColor = System.Drawing.Color.Red
        Me.celdaInfo2.Location = New System.Drawing.Point(0, 0)
        Me.celdaInfo2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfo2.Multiline = True
        Me.celdaInfo2.Name = "celdaInfo2"
        Me.celdaInfo2.ReadOnly = True
        Me.celdaInfo2.Size = New System.Drawing.Size(1018, 27)
        Me.celdaInfo2.TabIndex = 0
        Me.celdaInfo2.Text = "Producto Requerido"
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_right_green
        Me.botonAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAceptar.Location = New System.Drawing.Point(790, 565)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(87, 52)
        Me.botonAceptar.TabIndex = 3
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(885, 565)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(91, 52)
        Me.botonCancelar.TabIndex = 4
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.panelInfo1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1018, 162)
        Me.Panel1.TabIndex = 5
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Panel2.Controls.Add(Me.panelLista)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 162)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1018, 213)
        Me.Panel2.TabIndex = 6
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.Control
        Me.colFecha.DefaultCellStyle = DataGridViewCellStyle2
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.Width = 67
        '
        'colNumero
        '
        Me.colNumero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        Me.colNumero.DefaultCellStyle = DataGridViewCellStyle3
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.Width = 87
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Info
        Me.colReferencia.DefaultCellStyle = DataGridViewCellStyle4
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.Width = 103
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Info
        Me.colLinea.DefaultCellStyle = DataGridViewCellStyle5
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Width = 64
        '
        'colAno
        '
        Me.colAno.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.Visible = False
        Me.colAno.Width = 67
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Info
        Me.colCodigo.DefaultCellStyle = DataGridViewCellStyle6
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Width = 70
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.Visible = False
        Me.colDescripcion.Width = 108
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Info
        Me.colPrecio.DefaultCellStyle = DataGridViewCellStyle7
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 69
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Info
        Me.colCantidad.DefaultCellStyle = DataGridViewCellStyle8
        Me.colCantidad.HeaderText = "Balance"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 88
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Info
        Me.colMedida.DefaultCellStyle = DataGridViewCellStyle9
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.Width = 92
        '
        'colDescargo
        '
        Me.colDescargo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.RoyalBlue
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.White
        Me.colDescargo.DefaultCellStyle = DataGridViewCellStyle10
        Me.colDescargo.HeaderText = "Discharge"
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.Width = 101
        '
        'colPais
        '
        Me.colPais.HeaderText = "Country"
        Me.colPais.Name = "colPais"
        Me.colPais.Visible = False
        Me.colPais.Width = 86
        '
        'colFabricante
        '
        Me.colFabricante.HeaderText = "Manufacturer"
        Me.colFabricante.Name = "colFabricante"
        Me.colFabricante.Visible = False
        Me.colFabricante.Width = 121
        '
        'colSemana
        '
        Me.colSemana.HeaderText = "Week"
        Me.colSemana.Name = "colSemana"
        Me.colSemana.Visible = False
        Me.colSemana.Width = 73
        '
        'colLote
        '
        Me.colLote.HeaderText = "Lot"
        Me.colLote.Name = "colLote"
        Me.colLote.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colLote.Visible = False
        Me.colLote.Width = 57
        '
        'colClase
        '
        Me.colClase.HeaderText = "Class"
        Me.colClase.Name = "colClase"
        Me.colClase.Visible = False
        Me.colClase.Width = 71
        '
        'colUnit
        '
        Me.colUnit.HeaderText = "Unit"
        Me.colUnit.Name = "colUnit"
        Me.colUnit.Visible = False
        Me.colUnit.Width = 62
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Width = 77
        '
        'colVendido
        '
        Me.colVendido.HeaderText = "Sold To"
        Me.colVendido.Name = "colVendido"
        Me.colVendido.ReadOnly = True
        Me.colVendido.Visible = False
        Me.colVendido.Width = 86
        '
        'tipoCambio
        '
        Me.tipoCambio.HeaderText = "Tipo de Cambio"
        Me.tipoCambio.Name = "tipoCambio"
        Me.tipoCambio.ReadOnly = True
        Me.tipoCambio.Visible = False
        Me.tipoCambio.Width = 136
        '
        'colGFMO
        '
        Me.colGFMO.HeaderText = "GF MO"
        Me.colGFMO.Name = "colGFMO"
        Me.colGFMO.ReadOnly = True
        Me.colGFMO.Visible = False
        Me.colGFMO.Width = 82
        '
        'colFabricForm
        '
        Me.colFabricForm.HeaderText = "Fabric Form"
        Me.colFabricForm.Name = "colFabricForm"
        Me.colFabricForm.Visible = False
        Me.colFabricForm.Width = 112
        '
        'colLoteProd
        '
        Me.colLoteProd.HeaderText = "Lote Produccion"
        Me.colLoteProd.Name = "colLoteProd"
        Me.colLoteProd.Visible = False
        Me.colLoteProd.Width = 140
        '
        'colTenido
        '
        Me.colTenido.HeaderText = "Teñido"
        Me.colTenido.Name = "colTenido"
        Me.colTenido.Visible = False
        Me.colTenido.Width = 81
        '
        'frmRequisiciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(1018, 623)
        Me.Controls.Add(Me.panelInfo2)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmRequisiciones"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmRequisicion"
        Me.panelInfo1.ResumeLayout(False)
        Me.panelInfo1.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelInfo2.ResumeLayout(False)
        Me.panelInfo2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelInfo1 As System.Windows.Forms.Panel
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents celdaInfo1 As System.Windows.Forms.TextBox
    Friend WithEvents panelInfo2 As System.Windows.Forms.Panel
    Friend WithEvents celdaInfo2 As System.Windows.Forms.TextBox
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents celdaInfoGeneral As System.Windows.Forms.TextBox
    Friend WithEvents celdaInfoProducto As System.Windows.Forms.TextBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents celdaPrecio As TextBox
    Friend WithEvents celdaIcotern As TextBox
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colPais As DataGridViewTextBoxColumn
    Friend WithEvents colFabricante As DataGridViewTextBoxColumn
    Friend WithEvents colSemana As DataGridViewTextBoxColumn
    Friend WithEvents colLote As DataGridViewTextBoxColumn
    Friend WithEvents colClase As DataGridViewTextBoxColumn
    Friend WithEvents colUnit As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colVendido As DataGridViewTextBoxColumn
    Friend WithEvents tipoCambio As DataGridViewTextBoxColumn
    Friend WithEvents colGFMO As DataGridViewTextBoxColumn
    Friend WithEvents colFabricForm As DataGridViewTextBoxColumn
    Friend WithEvents colLoteProd As DataGridViewTextBoxColumn
    Friend WithEvents colTenido As DataGridViewTextBoxColumn
End Class
