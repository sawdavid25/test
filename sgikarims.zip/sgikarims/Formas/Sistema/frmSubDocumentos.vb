﻿Public Class frmSubDocumentos

#Region "Variables de Instancia"

    Dim strClave As String = STR_VACIO
    Dim strTabla As String = STR_VACIO
    Dim strCampos As String = STR_VACIO
    Dim strCondicion As String = STR_VACIO
    Dim intAño As Integer = INT_CERO
    Dim strsub As String = STR_VACIO
    Dim strkg As Double
    Dim intCatalogo As Integer = 0
    Dim intNumero As String = STR_VACIO
    Dim intNumero2 As String = STR_VACIO
    Dim intSub As String = STR_VACIO
    Dim intDoc As String = STR_VACIO
    Dim intDiv As Integer
    Dim intCodCliente As Integer
    Dim intContrato As String
    Dim intContActivo As Boolean
    Dim PedProforma As String = STR_VACIO
    Dim logGuardar As Boolean
    Dim strAnulada As String = STR_VACIO
    Dim intLinea As Integer
    Dim Distri As String = STR_VACIO
    Dim strTipoDoc As String = STR_VACIO
    Dim dblTasaC As Double
    Dim PolImportacion As Boolean
    Dim datGrid As DataGridView

    'Variables para obtener subdoccumentos de facturacion para... poliza exportacion
    Dim anioFactDato As String = STR_VACIO
    Dim numFactDato As String = STR_VACIO
    Dim fechaPolizaExportDato As String = STR_VACIO

    Private Const FLD_TIPO As Byte = 1
    Private Const FLD_GRUPO As Byte = 4
    Private Const STR_CPORTE2 As String = "Doc_CCPorte2"
    Const Venta As String = "36"
#End Region

#Region "Propiedades"

    Public Property Contrato As String
        Get
            Return intContrato
        End Get
        Set(value As String)
            intContrato = value
        End Set
    End Property

    Public Property datagrid As DataGridView
        Get
            Return datGrid
        End Get
        Set(value As DataGridView)
            datGrid = value
        End Set
    End Property

    Public Property ContratoActivo As Boolean
        Get
            Return intContActivo
        End Get
        Set(value As Boolean)
            intContActivo = value
        End Set
    End Property

    Public Property PolizaImportacionActiva As Boolean
        Get
            Return PolImportacion
        End Get
        Set(value As Boolean)
            PolImportacion = value
        End Set
    End Property

    Public Property Doc As String
        Get
            Return intDoc
        End Get
        Set(value As String)
            intDoc = value
        End Set
    End Property

    Public Property Distribucion As String
        Get
            Return Distri
        End Get
        Set(value As String)
            Distri = value
        End Set
    End Property

    Public Property Line As Integer
        Get
            Return intLinea
        End Get
        Set(value As Integer)
            intLinea = value
        End Set
    End Property

    Public Property Año As Integer
        Get
            Return intAño
        End Get
        Set(value As Integer)
            intAño = value
        End Set
    End Property

    Public Property Catalogo As Integer
        Get
            Return intCatalogo
        End Get
        Set(value As Integer)
            intCatalogo = value
        End Set
    End Property

    Public Property Anuladas As String
        Get
            Return strAnulada
        End Get
        Set(value As String)
            strAnulada = value
        End Set
    End Property

    Public Property Division As Integer
        Get
            Return intDiv
        End Get
        Set(value As Integer)
            intDiv = value
        End Set
    End Property

    Public Property Numero As String
        Get
            Return intNumero
        End Get
        Set(value As String)
            intNumero = value
        End Set
    End Property
    Public Property Numero2 As String
        Get
            Return intNumero2
        End Get
        Set(value As String)
            intNumero2 = value
        End Set
    End Property
    WriteOnly Property SubDocumento As String
        Set(value As String)
            strsub = value
        End Set
    End Property

    Public Property Clave As String
        Get
            Return strClave
        End Get
        Set(value As String)
            strClave = value
        End Set
    End Property

    Public Property Tabla As String
        Get
            Return strTabla
        End Get
        Set(value As String)
            strTabla = value
        End Set
    End Property

    Public Property Campos As String
        Get
            Return strCampos
        End Get
        Set(value As String)
            strCampos = value
        End Set
    End Property

    Public Property Condicion As String
        Get
            Return strCondicion
        End Get
        Set(value As String)
            strCondicion = value
        End Set
    End Property

    Public Property KGBrutos As Double
        Get
            Return strkg
        End Get
        Set(value As Double)
            strkg = value
        End Set
    End Property

    Public Property Pedido As String
        Get
            Return PedProforma
        End Get
        Set(value As String)
            PedProforma = value
        End Set
    End Property

    Public Property TasaC As String
        Get
            Return dblTasaC
        End Get
        Set(value As String)
            dblTasaC = value
        End Set
    End Property

    'REFERENCIAS DE FACTURAS -> DESDE POLIZA DE EXPORTACION
    Public Property anioFact As String
        Get
            Return anioFactDato
        End Get
        Set(value As String)
            anioFactDato = value
        End Set
    End Property
    Public Property numFactura As String
        Get
            Return numFactDato
        End Get
        Set(value As String)
            numFactDato = value
        End Set
    End Property
    Public Property fechaPolizaExport As String
        Get
            Return fechaPolizaExportDato
        End Get
        Set(value As String)
            fechaPolizaExportDato = value
        End Set
    End Property

#End Region

#Region "Procedimiento"

    Private Function SaldoBultos() As Integer
        Dim intBultos As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim Cone As MySqlConnection
        Dim COM As MySqlCommand
        Try
            strSQL = "  select ifnull(sum(b.BDoc_Box_QTY) - ifnull(( "
            strSQL &= "   select sum(c.BDoc_Box_QTY ) from Dcmtos_DTL_Pro p "
            strSQL &= "   inner join Dcmtos_HDR h on h.HDoc_Sis_Emp = p.PDoc_Sis_Emp and h.HDoc_Doc_Cat = p.PDoc_Chi_Cat and h.HDoc_Doc_Ano = p.PDoc_Chi_Ano and h.HDoc_Doc_Num = p.PDoc_Chi_Num and h.HDoc_Doc_Status = 1 "
            strSQL &= "  left join Dcmtos_DTL_Box c on c.BDoc_Sis_Emp = p.PDoc_Sis_Emp and c.BDoc_Doc_Cat = p.PDoc_Chi_Cat and c.BDoc_Doc_Ano = p.PDoc_Chi_Ano and c.BDoc_Doc_Num = p.PDoc_Chi_Num and c.BDoc_Doc_Lin = p.PDoc_Chi_Lin  "
            strSQL &= "  where p.PDoc_Sis_Emp = b.BDoc_Sis_Emp  and p.PDoc_Par_Cat = b.BDoc_Doc_Cat  and p.PDoc_Par_Ano = b.BDoc_Doc_Ano  and p.PDoc_Par_Num = b.BDoc_Doc_Num  and p.PDoc_Chi_Cat = 48 "
            strSQL &= "   ),0),0) bultos "
            strSQL &= "  from Dcmtos_DTL_Box  b "
            strSQL &= " where b.BDoc_Sis_Emp = {empresa} and b.BDoc_Doc_Cat ={catalogo} and b.BDoc_Doc_Ano = {ano} and b.BDoc_Doc_Num = {numero} "


            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{ano}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)

            Cone = New MySqlConnection(strConexion)
            Cone.Open()
            COM = New MySqlCommand(strSQL, Cone)
            intBultos = COM.ExecuteScalar


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intBultos
    End Function

    Private Function SaldoKGS() As Double
        Dim dblKilos As Double = INT_CERO
            Dim strSQL As String = STR_VACIO
            Dim Cone As MySqlConnection
            Dim COM As MySqlCommand
            Try
            strSQL = "  SELECT ROUND(IF(d.DDoc_Prd_UM = 69, ((SUM(d.DDoc_Prd_QTY) - SUM(IFNULL(p.PDoc_QTY_Pro,0))) /2.2046), ((SUM(d.DDoc_Prd_QTY) - SUM(IFNULL(p.PDoc_QTY_Pro,0))))),2) kilos "
            strSQL &= "  from Dcmtos_DTL d "
            strSQL &= "  left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp =d.DDoc_Sis_Emp and p.PDoc_Par_Cat = d.DDoc_Doc_Cat and p.PDoc_Par_Ano = d.DDoc_Doc_Ano and p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin = d.DDoc_Doc_Lin   "
                strSQL &= "  left join Dcmtos_DTL_Box c on c.BDoc_Sis_Emp = p.PDoc_Sis_Emp and c.BDoc_Doc_Cat = p.PDoc_Chi_Cat and c.BDoc_Doc_Ano = p.PDoc_Chi_Ano and c.BDoc_Doc_Num = p.PDoc_Chi_Num and c.BDoc_Doc_Lin = p.PDoc_Chi_Lin  "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat ={catalogo} and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "


                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
                strSQL = Replace(strSQL, "{ano}", intAño)
                strSQL = Replace(strSQL, "{numero}", intNumero)

                Cone = New MySqlConnection(strConexion)
                Cone.Open()
                COM = New MySqlCommand(strSQL, Cone)
                dblKilos = COM.ExecuteScalar

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            Return dblKilos
    End Function

    Private Sub CargarSubDcmtos(Optional subDoc As Integer = 0) ' el subDoc solo lo utilzo en poliza de Importación

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim i As Integer = 0
        Dim arreglo() As String
        Dim strTemp As String
        Dim Nombre As String
        Dim strNombreT As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim REA3 As MySqlDataReader
        Dim REA4 As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim connec As MySqlConnection
        Dim ID As Integer
        Dim strNombrePais As String = STR_VACIO

        strNombrePais = cFunciones.PaisDefault

        CON = New MySqlConnection(strConexion)
        CON.Open()


        dgvSubDocumentosfrm.Rows.Clear()

        Dim strSQL As String
        strSQL = " SELECT  DISTINCT b.cat_clase, b.cat_clave, b.cat_desc, b.cat_sist, IFNULL(("
        strSQL &= "   SELECT 
            CASE 
                WHEN b.cat_sist = 'Char' THEN CAST(COALESCE(ADoc_Dta_Chr, '{null}') AS CHAR) 
                WHEN b.cat_sist = 'Text' THEN CAST(COALESCE(ADoc_Dta_Txt, '{null}') AS CHAR) 
                WHEN b.cat_sist = 'Date' THEN CAST(COALESCE(ADoc_Dta_Fec, '') AS CHAR) 
                WHEN b.cat_sist = 'Weight' THEN CAST(COALESCE(ADoc_Dta_Wht, '0') AS CHAR) 
                WHEN b.cat_sist = 'Cant' THEN CAST(COALESCE(ADoc_Dta_Num, '0') AS CHAR) 
                WHEN b.cat_sist = 'Money' THEN CAST(COALESCE(ADoc_Dta_Mny, '0') AS CHAR) 
            ELSE 'ERROR' END"
        strSQL &= "      FROM Dcmtos_ACC"
        strSQL &= "         WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor"
        strSQL &= "           FROM Catalogos a"
        strSQL &= "         INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase"
        strSQL &= "      WHERE a.cat_clase = 'SubDcmtos' AND a.cat_clave = '{SubDcmtos}' {condicion}"
        strSQL &= "  ORDER BY b.cat_clave, b.cat_clase"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{SubDcmtos}", strsub)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        If (Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 20) And intCatalogo = 36 Then
            strSQL = Replace(strSQL, "{condicion}", "AND b.cat_sisemp = " & Sesion.IdEmpresa & "")
            'ElseIf (Sesion.IdEmpresa = 19) And intCatalogo = 36 Then
            '    strSQL = Replace(strSQL, "{condicion}", "AND b.cat_sisemp = " & Sesion.IdEmpresa & "")
            '    'ElseIf (Sesion.IdEmpresa = 18) And intCatalogo = 36 Then
            '    '    strSQL = Replace(strSQL, "{condicion}", "AND b.cat_sisemp = " & Sesion.IdEmpresa & "")
        Else
            strSQL = Replace(strSQL, "{condicion}", " ")
        End If
        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            'REA.Read()

            'dgvSubDocumentosfrm.Rows.Clear()


            If REA.HasRows Then

                i = vbEmpty

                Do While REA.Read

                    Dim strFila As String = STR_VACIO

                    strTipoDoc = REA.GetString("cat_clase")
                    If REA.GetString("cat_clave") = "03" And strTipoDoc = "Doc_CPckLst2" Or
                                REA.GetString("cat_clave") = "03" And strTipoDoc = "Doc_CCPorte2" And Not REA.GetString("cat_clase") = "Doc_PolImp" And Not REA.GetString("cat_clase") = "Doc_PolExp" And Not REA.GetString("cat_clase") = "Doc_RADevolucion" Then
                        strSQL2 = DatosCliente(intAño, intNumero, intCatalogo)

                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM2 = New MySqlCommand(strSQL2, connec)
                        REA2 = COM2.ExecuteReader
                        REA2.Read()

                        strTemp = RecuperarNombre(REA2.GetInt32("IDcliente"))
                        Nombre = REA2.GetString("cliente") & strTemp & vbCr & REA2.GetString("direccion")
                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(Nombre, "|", " ")
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        'ElseIf strTipoDoc = "Doc_PFactura" And ((REA.GetString("cat_clave") = "13") Or (REA.GetString("cat_clave") = "14") Or (REA.GetString("cat_clave") = "16")) Then
                        ' strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & INT_CERO

                    ElseIf REA.GetString("cat_clave") = "14" And REA.GetString("cat_clase") = "Doc_CCPorte2" Then
                        strSQL3 = SumaKGS(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        REA3.Read()
                        'If Sesion.IdEmpresa = 11 Then
                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetDouble("Suma"), "|", " ")
                        'End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "14" And REA.GetString("cat_clase") = "Doc_CMan2" Then
                        strSQL3 = SumaKGS(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        REA3.Read()
                        ' If Sesion.IdEmpresa = 11 Then
                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetDouble("Suma"), "|", " ")
                        ' End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "01" And REA.GetString("cat_clase") = "Doc_CCPorte2" Then
                        If Sesion.IdEmpresa = 11 Then
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & intNumero2
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & intNumero
                        End If

                    ElseIf REA.GetString("cat_clave") = "06" And REA.GetString("cat_clase") = "Doc_CCPorte2" Then
                        strSQL3 = Contenedor(intAño, intNumero, intCatalogo, Sesion.IdEmpresa)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA4 = COM3.ExecuteReader
                        If REA4.HasRows Then
                            Do While REA4.Read
                                'If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA4.GetString("Contenedor"), "|", " ")
                                'End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA4.Close()
                        REA4 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "06" And REA.GetString("cat_clase") = "Doc_CMan2" Then
                        strSQL3 = Contenedor(intAño, intNumero, intCatalogo, Sesion.IdEmpresa)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA4 = COM3.ExecuteReader
                        If REA4.HasRows Then
                            Do While REA4.Read
                                ' If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA4.GetString("Contenedor"), "|", " ")
                                '    End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA4.Close()
                        REA4 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "02" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        If Sesion.IdEmpresa = 11 Then
                            strSQL3 = FechaPolizaExportacion(intAño, intNumero, intCatalogo)
                            connec = New MySqlConnection(strConexion)
                            connec.Open()
                            COM3 = New MySqlCommand(strSQL3, connec)
                            REA4 = COM3.ExecuteReader
                            If REA4.HasRows Then
                                Do While REA4.Read
                                    ' If Sesion.IdEmpresa = 11 Then
                                    strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA4.GetDateTime("Fecha").ToString(FORMATO_MYSQL), "|", " ")
                                    '    End If
                                Loop
                            Else
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                            End If
                            connec.Close()
                            connec.Dispose()
                            connec = Nothing
                            System.GC.Collect()
                            COM3 = Nothing
                            REA4.Close()
                            REA4 = Nothing
                            strSQL3 = STR_VACIO
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                    ElseIf REA.GetString("cat_clave") = "03" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        If Sesion.IdEmpresa = 11 Then

                            strSQL3 = LugarCarga(intAño, intNumero, intCatalogo)
                            connec = New MySqlConnection(strConexion)
                            connec.Open()
                            COM3 = New MySqlCommand(strSQL3, connec)
                            REA4 = COM3.ExecuteReader
                            If REA4.HasRows Then
                                Do While REA4.Read
                                    ' If Sesion.IdEmpresa = 11 Then
                                    strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA4.GetString("LugarCarga"), "|", " ")
                                    '    End If
                                Loop

                                'Else
                                '    strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                                'End If

                                connec.Close()
                                connec.Dispose()
                                connec = Nothing
                                System.GC.Collect()
                                COM3 = Nothing
                                REA4.Close()
                                REA4 = Nothing
                                strSQL3 = STR_VACIO
                            End If

                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                    ElseIf REA.GetString("cat_clave") = "05" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        strSQL3 = TasaCambioPolizaExportacion(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader

                        If REA3.HasRows Then
                            Do While REA3.Read()

                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetDouble("TasaCambio"), "|", " ")
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO

                    ElseIf REA.GetString("cat_clave") = "06" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        If Sesion.IdEmpresa = 11 Then
                            strSQL3 = DescripcionProducto(intAño, intNumero, intCatalogo)
                            connec = New MySqlConnection(strConexion)
                            connec.Open()
                            COM3 = New MySqlCommand(strSQL3, connec)
                            REA3 = COM3.ExecuteReader

                            If REA3.HasRows Then
                                Do While REA3.Read()
                                    If REA3.GetString("Hilados") = " " Then
                                    Else
                                        strNombreT = REA3.GetString("Hilados")
                                    End If
                                    If REA3.GetString("Hilados1") = " " Then
                                    Else
                                        strNombreT &= "/" & REA3.GetString("Hilados1")
                                    End If
                                    If REA3.GetString("Hilados2") = " " Then
                                    Else
                                        strNombreT &= "/" & REA3.GetString("Hilados2")
                                    End If
                                    If Sesion.IdEmpresa = 11 Then
                                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(strNombreT, "|", " ")
                                    End If
                                Loop
                            Else
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                            End If


                            connec.Close()
                            connec.Dispose()
                            connec = Nothing
                            System.GC.Collect()
                            COM3 = Nothing
                            REA3.Close()
                            REA3 = Nothing
                            strSQL3 = STR_VACIO
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                    ElseIf REA.GetString("cat_clave") = "07" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        If Sesion.IdEmpresa = 11 Then
                            strSQL3 = PesoBrutoPolizaExportacion(intAño, intNumero, intCatalogo)
                            connec = New MySqlConnection(strConexion)
                            connec.Open()
                            COM3 = New MySqlCommand(strSQL3, connec)
                            REA3 = COM3.ExecuteReader
                            REA3.Read()
                            'If Sesion.IdEmpresa = 11 Then
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetDouble("PesoBruto"), "|", " ")
                            'End If
                            connec.Close()
                            connec.Dispose()
                            connec = Nothing
                            System.GC.Collect()
                            COM3 = Nothing
                            REA3.Close()
                            REA3 = Nothing
                            strSQL3 = STR_VACIO
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If


                    ElseIf REA.GetString("cat_clave") = "08" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        strSQL3 = PesoNetoPolizaExportacion(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader

                        If REA3.HasRows Then
                            Do While REA3.Read()

                                'If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetDouble("Neto"), "|", " ")
                                '     End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "09" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        'If cFunciones.PaisDefault() <> "El Salvador" Or cFunciones.PaisDefault() <> "Republica Dominicana" Then
                        strSQL3 = FacturaFob(intAño, intNumero, intCatalogo, strNombrePais)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        If REA3.HasRows Then
                            Do While REA3.Read()
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & (REA3.GetDouble("Total").ToString(FORMATO_MONEDA))
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO

                    ElseIf REA.GetString("cat_clave") = "07" And REA.GetString("cat_clase") = "Doc_CCPorte2" Then
                        strSQL3 = PlacaCabezal(intAño, intNumero, intCatalogo, Sesion.IdEmpresa)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader

                        If REA3.HasRows Then
                            Do While REA3.Read()

                                'If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("Cabezal"), "|", " ")
                                'End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO

                    ElseIf REA.GetString("cat_clave") = "01" And REA.GetString("cat_clase") = "Doc_TransExp" Then
                        strSQL3 = NumeroDua(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        If REA3.HasRows Then
                            Do While REA3.Read()

                                If Sesion.IdEmpresa = 11 Then
                                    strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("Dua"), "|", " ")
                                End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If
                    ElseIf REA.GetString("cat_clave") = "12" And REA.GetString("cat_clase") = "Doc_PolExp" Then
                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & 0

                    ElseIf REA.GetString("cat_clave") = "14" And REA.GetString("cat_clase") = "Doc_PolExp" Then

                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")

                    ElseIf REA.GetString("cat_clave") = "15" And REA.GetString("cat_clase") = "Doc_PolExp" Then

                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")

                    ElseIf REA.GetString("cat_clave") = "07" And REA.GetString("cat_clase") = "Doc_CMan2" Then
                        strSQL3 = PlacaCabezal(intAño, intNumero, intCatalogo, Sesion.IdEmpresa)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader

                        If REA3.HasRows Then
                            Do While REA3.Read()

                                ' If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("Cabezal"), "|", " ")
                                ' End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If

                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "08" And REA.GetString("cat_clase") = "Doc_CCPorte2" Then
                        strSQL3 = NombrePiloto(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        If REA3.HasRows And Not Sesion.idGiro = 2 Then
                            Do While REA3.Read()
                                'If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("NombrePiloto"), "|", " ")
                                'End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO

                    ElseIf REA.GetString("cat_clave") = "08" And REA.GetString("cat_clase") = "Doc_CMan2" Then
                        strSQL3 = NombrePiloto(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        If REA3.HasRows Then
                            Do While REA3.Read()
                                ' If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("NombrePiloto"), "|", " ")
                                '    End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("valor")
                        End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "09" And REA.GetString("cat_clase") = "Doc_CMan2" Then
                        strSQL3 = Licencia(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        If REA3.HasRows Then
                            Do While REA3.Read()
                                ' If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("Licencia"), "|", " ")
                                'End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & ""
                        End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO
                    ElseIf REA.GetString("cat_clave") = "11" And REA.GetString("cat_clase") = "Doc_CMan2" Then
                        strSQL3 = Machamo(intAño, intNumero, intCatalogo)
                        connec = New MySqlConnection(strConexion)
                        connec.Open()
                        COM3 = New MySqlCommand(strSQL3, connec)
                        REA3 = COM3.ExecuteReader
                        If REA3.HasRows Then
                            Do While REA3.Read()
                                ' If Sesion.IdEmpresa = 11 Then
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetString("Machamo"), "|", " ")
                                ' End If
                            Loop
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & ""
                        End If
                        connec.Close()
                        connec.Dispose()
                        connec = Nothing
                        System.GC.Collect()
                        COM3 = Nothing
                        REA3.Close()
                        REA3 = Nothing
                        strSQL3 = STR_VACIO

                    ElseIf REA.GetString("cat_clave") = "04" And REA.GetString("cat_clase") = "Doc_CPckLst2" Or REA.GetString("cat_clave") = "04" And REA.GetString("cat_clase") = "Doc_CCPorte2" Then

                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & RecuperarDestinos()

                    ElseIf REA.GetString("cat_clase") = "Prvs_Guia" And REA.GetString("cat_clave") = "09" Then
                        If REA.GetString("Valor") = "" Then
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & SaldoBultos()
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("Valor")
                        End If
                    ElseIf REA.GetString("cat_clave") = "01" And REA.GetString("cat_clase") = "Doc_CFNotas" Then
                        If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                            strSQL3 = FechaAutorizacion(intAño, intNumero, intCatalogo)
                            connec = New MySqlConnection(strConexion)
                            connec.Open()
                            COM3 = New MySqlCommand(strSQL3, connec)
                            REA3 = COM3.ExecuteReader
                            If REA3.HasRows Then
                                Do While REA3.Read()
                                    ' If Sesion.IdEmpresa = 11 Then
                                    strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA3.GetDateTime("Fecha"), "|", " ")
                                    ' End If
                                Loop
                            Else
                                strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA.GetString("Valor"), "|", " ")
                            End If
                            connec.Close()
                            connec.Dispose()
                            connec = Nothing
                            System.GC.Collect()
                            COM3 = Nothing
                            REA3.Close()
                            REA3 = Nothing
                            strSQL3 = STR_VACIO
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA.GetString("Valor"), "|", " ")
                        End If
                    ElseIf REA.GetString("cat_clave") = "01" And REA.GetString("cat_clase") = "Doc_CCtfidos" Then
                        If Sesion.idGiro = 1 Then
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA.GetString("Valor"), "|", " ")
                        End If
                    ElseIf REA.GetString("cat_clave") = "24" And REA.GetString("cat_clase") = "Doc_PolImp" Then
                        If REA.GetString("Valor") = "" Then
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & "ZZ1 - ZONA FRANCA ZETA LA UNION"
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("Valor")
                        End If
                    ElseIf REA.GetString("cat_clase") = "Prvs_Guia" And REA.GetString("cat_clave") = "10" Then
                        If REA.GetString("Valor") = "" Then
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & SaldoKGS()
                        Else
                            strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & REA.GetString("Valor")
                        End If
                    Else
                        strFila = REA.GetString("cat_desc") & "|" & REA.GetString("cat_sist") & "|" & REA.GetString("cat_clave") & "|" & Replace(REA.GetString("Valor"), "|", " ")


                    End If

                    cFunciones.AgregarFila(dgvSubDocumentosfrm, strFila)

                    dgvSubDocumentosfrm.Rows(i).Cells(0).Style.BackColor = Color.AliceBlue
                    dgvSubDocumentosfrm.Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable
                    dgvSubDocumentosfrm.Columns(1).SortMode = DataGridViewColumnSortMode.NotSortable
                    dgvSubDocumentosfrm.Columns(2).SortMode = DataGridViewColumnSortMode.NotSortable

                    i = i + 0

                    celdaDocumento.Text = REA.GetString("cat_clase")
                Loop
                CON.Close()
                'BuscarACC()

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function FechaAutorizacion(ByVal intAÑo As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT a.ADoc_Dta_Fec Fecha"
        strSQL &= "     FROM Dcmtos_ACC a "
        strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = {catalogo} AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = 'Doc_CFNotas'"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        strSQL = Replace(strSQL, "{anio}", intAÑo)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        Return strSQL
    End Function
    Private Function DatosCliente(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO

        Try

            strSQL = "SELECT hdr.HDoc_Doc_Fec Fecha, IFNULL(c.cli_codigo,0) IDcliente, IFNULL(c.cli_cliente,0) cliente, IFNULL(c.cli_direccion,0) direccion, hdr.HDoc_DR1_Num Referencia"
            strSQL &= "  FROM Dcmtos_HDR hdr"
            strSQL &= "      LEFT JOIN Clientes c ON c.cli_sisemp = hdr.HDoc_Sis_Emp AND c.cli_codigo = hdr.HDoc_Emp_Cod"
            strSQL &= "          WHERE hdr.HDoc_Sis_Emp = {empresa} AND hdr.HDoc_Doc_Cat = {catalogo} AND hdr.HDoc_Doc_Ano = {año} AND hdr.HDoc_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{año}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return strSQL

    End Function
    Private Function SumaKGS(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "      SELECT ROUND(SUM(d.DDoc_RF2_Dbl),2) Suma "
            strSQL &= "         FROM Dcmtos_DTL d  "
            strSQL &= "             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function FechaPolizaExportacion(ByVal intaño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT h.HDoc_Doc_Fec Fecha "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intaño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL

    End Function
    Private Function TasaCambioPolizaExportacion(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT h.HDoc_Doc_TC TasaCambio  "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function PesoBrutoPolizaExportacion(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try

            strSQL = "SELECT IFNULL(Sum(d.DDoc_RF2_Dbl),0) PesoBruto"
            strSQL &= " FROM Dcmtos_DTL d  "
            strSQL &= "     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio}  AND d.DDoc_Doc_Num = {numero}   "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function PesoNetoPolizaExportacion(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT SUM(IF(d.DDoc_Prd_UM = 69, IFNULL(ROUND((d.DDoc_Prd_QTY / 2.2046),2),0), d.DDoc_Prd_QTY)) Neto "
            strSQL &= " FROM Dcmtos_DTL d  "
            strSQL &= "     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio}  AND d.DDoc_Doc_Num = {numero}   "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function Contenedor(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer, ByVal intEmpresa As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "   SELECT a.ADoc_Dta_Chr Contenedor"
            strSQL &= "     FROM Dcmtos_ACC a "
            strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} {subDocumento}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            If intEmpresa = 11 Then
                strSQL = Replace(strSQL, "{subDocumento}", "AND a.ADoc_Doc_Sub = 'Doc_HFDatos' AND a.ADoc_Doc_Lin = 03")
            Else
                strSQL = Replace(strSQL, "{subDocumento}", "AND a.ADoc_Doc_Sub = 'Doc_CCPorte2' AND a.ADoc_Doc_Lin = 06")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function PlacaCabezal(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer, ByVal intEmpresa As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "   SELECT a.ADoc_Dta_Chr Cabezal"
            strSQL &= "     FROM Dcmtos_ACC a "
            strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} {subDocumento} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            If intEmpresa = 11 Then
                strSQL = Replace(strSQL, "{subDocumento}", " AND a.ADoc_Doc_Sub = 'Doc_HFDatos' AND a.ADoc_Doc_Lin = 17")
            Else
                strSQL = Replace(strSQL, "{subDocumento}", "AND a.ADoc_Doc_Sub = 'Doc_CCPorte2' AND a.ADoc_Doc_Lin = 07")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function NombrePiloto(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "   SELECT a.ADoc_Dta_Chr NombrePiloto"
            strSQL &= "     FROM Dcmtos_ACC a "
            strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = 'Doc_HFDatos' AND a.ADoc_Doc_Lin = 15 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function Machamo(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "   SELECT a.ADoc_Dta_Chr Machamo"
            strSQL &= "     FROM Dcmtos_ACC a "
            strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = 'Doc_CCPorte2' AND a.ADoc_Doc_Lin = 11 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function Licencia(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "   SELECT a.ADoc_Dta_Chr Licencia"
            strSQL &= "     FROM Dcmtos_ACC a "
            strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = 'Doc_CCPorte2' AND a.ADoc_Doc_Lin = 09 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function LugarCarga(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT  a.ADoc_Dta_Txt LugarCarga "
        strSQL &= "     FROM  Dcmtos_ACC a "
        strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = 'Doc_HFDatos' AND a.ADoc_Doc_Lin = 4 "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)

        Return strSQL
    End Function
    Private Function DescripcionProducto(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "      SELECT IFNULL(final.numero,'') AS Numero, IFNULL(GROUP_CONCAT(DISTINCT(final.fecha)),'') AS fecha, IFNULL(GROUP_CONCAT(DISTINCT(final.importador)),'') AS Salida, "
        strSQL &= "         IFNULL(GROUP_CONCAT(DISTINCT(final.descarga)),'') AS Destino, IFNULL(GROUP_CONCAT(DISTINCT(final.trasporte)),'') AS transporte, IFNULL(GROUP_CONCAT(DISTINCT(final.furgon)),'') AS Motorista, "
        strSQL &= "             IFNULL(GROUP_CONCAT(DISTINCT(final.cabezal)),'') AS cabezal, IFNULL(GROUP_CONCAT(DISTINCT(final.piloto)),'') AS Furgon, IFNULL(GROUP_CONCAT(DISTINCT(final.licencia)),'') AS Bultos, "
        strSQL &= "                 IFNULL(GROUP_CONCAT(DISTINCT(final.pedido)),'') AS TotalKGS, IFNULL(GROUP_CONCAT(DISTINCT(final.marchamo)),'') AS marchamo, IFNULL(GROUP_CONCAT(DISTINCT(final.vendedor)),'') AS vendedor, "
        strSQL &= "                     IFNULL(GROUP_CONCAT(DISTINCT(final.origen)),'') AS Hilados, IFNULL(GROUP_CONCAT(DISTINCT(final.pais)),'') AS Hilados1, IFNULL(GROUP_CONCAT(DISTINCT(final.pais1)),'') AS pais1, IFNULL(GROUP_CONCAT(DISTINCT(final.pais2)),'') AS Hilados2, "
        strSQL &= "                         IFNULL(GROUP_CONCAT(DISTINCT(final.pais3)),'') AS pais3, IFNULL(GROUP_CONCAT(DISTINCT(final.pais4)),'') AS pais4, IFNULL(GROUP_CONCAT(DISTINCT(final.transportista)),'') AS transportista, IFNULL(GROUP_CONCAT(DISTINCT(final.cargador)),'') AS cargador "
        strSQL &= "                             FROM ( "
        strSQL &= "                                 SELECT DISTINCT(ccc.cat_clave), (CASE WHEN ccc.cat_clave = '01' THEN ccc.valores ELSE NULL END) AS numero, (CASE WHEN ccc.cat_clave = '02' THEN ccc.valores ELSE NULL END) AS fecha, (CASE WHEN ccc.cat_clave = '03' THEN ccc.valores ELSE NULL END) AS importador, (CASE WHEN ccc.cat_clave = '04' THEN ccc.valores ELSE NULL END) AS descarga, "
        strSQL &= "                                     (CASE WHEN ccc.cat_clave = '05' THEN ccc.valores ELSE NULL END) AS trasporte, (CASE WHEN ccc.cat_clave = '06' THEN ccc.valores ELSE NULL END) AS furgon, 	 (CASE WHEN ccc.cat_clave = '07' THEN ccc.valores ELSE NULL END) AS cabezal, "
        strSQL &= "                                         (CASE WHEN ccc.cat_clave = '08' THEN ccc.valores ELSE NULL END) AS piloto, 	(CASE WHEN ccc.cat_clave = '09' THEN ccc.valores ELSE NULL END) AS licencia, 	 (CASE WHEN ccc.cat_clave = '10' THEN ccc.valores ELSE NULL END) AS pedido, "
        strSQL &= "                                             (CASE WHEN ccc.cat_clave = '11' THEN ccc.valores ELSE NULL END) AS marchamo, (CASE WHEN ccc.cat_clave = '12' THEN ccc.valores ELSE NULL END) AS vendedor, 	(CASE WHEN ccc.cat_clave = '13' THEN ccc.valores ELSE NULL END) AS origen, "
        strSQL &= "                                                 (CASE WHEN ccc.cat_clave = '14' THEN ccc.valores ELSE NULL END) AS pais, 	(CASE WHEN ccc.cat_clave = '15' THEN ccc.valores ELSE NULL END) AS pais1, (CASE WHEN ccc.cat_clave = '16' THEN ccc.valores ELSE NULL END) AS pais2, 	(CASE WHEN ccc.cat_clave = '17' THEN ccc.valores ELSE NULL END) AS pais3, "
        strSQL &= "                                                     (CASE WHEN ccc.cat_clave = '18' THEN ccc.valores ELSE NULL END) AS pais4, (CASE WHEN ccc.cat_clave = '19' THEN ccc.valores ELSE NULL END) AS transportista, 	(CASE WHEN ccc.cat_clave = '20' THEN ccc.valores ELSE NULL END) AS cargador "
        strSQL &= "                                                         FROM ( "
        strSQL &= "                                                             SELECT xx.*, GROUP_CONCAT(DISTINCT(xx.valor) SEPARATOR '|') AS valores "
        strSQL &= "                                                                   FROM ( "
        strSQL &= "                                                                 SELECT a.cat_clave, a.cat_pid, a.cat_desc, b.ADoc_Sis_Emp, b.ADoc_Doc_Ano, b.ADoc_Doc_Cat, b.ADoc_Doc_Num, ( "
        strSQL &= "                                                              SELECT CASE WHEN a.cat_sist = 'Char' THEN CAST(COALESCE(c.ADoc_Dta_Chr, '{null}') AS CHAR) WHEN a.cat_sist = 'Text' THEN CAST(COALESCE(c.ADoc_Dta_Txt, '{null}') AS CHAR) "
        strSQL &= "                                                        WHEN a.cat_sist = 'Date' THEN CAST(COALESCE(c.ADoc_Dta_Fec, '{null}') AS CHAR) WHEN a.cat_sist = 'Weight' THEN CAST(COALESCE(c.ADoc_Dta_Wht, '{null}') AS CHAR) WHEN a.cat_sist = 'Cant' THEN CAST(COALESCE(c.ADoc_Dta_Num, '{null}') AS CHAR) "
        strSQL &= "                                                   WHEN a.cat_sist = 'Money' THEN CAST(COALESCE(c.ADoc_Dta_Mny, '{null}') AS CHAR) ELSE 'ERROR' END "
        strSQL &= "                                               FROM Dcmtos_ACC c "
        strSQL &= "                                         WHERE c.ADoc_Sis_Emp = b.ADoc_Sis_Emp AND c.ADoc_Doc_Cat = b.ADoc_Doc_Cat AND c.ADoc_Doc_Ano = b.ADoc_Doc_Ano AND c.ADoc_Doc_Num = b.ADoc_Doc_Num AND c.ADoc_Doc_Sub = b.ADoc_Doc_Sub AND c.ADoc_Doc_Lin = a.cat_clave) AS Valor "
        strSQL &= "                                    FROM Catalogos a "
        strSQL &= "                             INNER JOIN Dcmtos_ACC b ON b.ADoc_Sis_Emp = {empresa} AND b.ADoc_Doc_Ano = {anio} AND b.ADoc_Doc_Cat = 36 AND b.ADoc_Doc_Num = {num} AND b.ADoc_Doc_Sub = 'Doc_HFDatos' AND b.ADoc_Doc_Lin = a.cat_clave "
        strSQL &= "                       WHERE a.cat_clase = b.ADoc_Doc_Sub) xx "
        strSQL &= "                GROUP BY xx.cat_clave "
        strSQL &= "         ORDER BY xx.cat_pid) ccc "
        strSQL &= " GROUP BY ccc.cat_clave)final "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAño)
        strSQL = Replace(strSQL, "{num}", intNumero)

        Return strSQL
    End Function
    Private Function FacturaFob(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer, ByVal strNomPais As String)
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT (SUM((d.DDoc_Prd_NET * d.DDoc_Prd_QTY))- SUM(d.DDoc_Prd_DSQ)) Total "
        strSQL &= "     FROM Dcmtos_DTL d "
        strSQL &= "         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        If strNomPais = "El Salvador" Or strNomPais = "Republica Dominicana" Or Sesion.idGiro = 2 Then
            strSQL = Replace(strSQL, "{cat}", 56)
        Else
            strSQL = Replace(strSQL, "{cat}", 36)
        End If


        Return strSQL
    End Function
    Private Function NumeroDua(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT a.ADoc_Dta_Chr Dua "
        strSQL &= "     FROM Dcmtos_ACC a  "
        strSQL &= "         WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Ano = {anio} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = 'Doc_PolExp' AND a.ADoc_Doc_Lin = '04' "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        Return strSQL
    End Function
    'Importa los datos ya existentes
    Private Function MostrarDatosPolizaImport(ByVal campo As String, ByVal LineaSubDoc As String)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT {campo} From Dcmtos_DTL_Pro p "
        strSQL &= " Left Join Dcmtos_ACC c ON c.ADoc_Sis_Emp = p.PDoc_Sis_Emp And c.ADoc_Doc_Cat = p.PDoc_Par_Cat And c.ADoc_Doc_Ano = p.PDoc_Par_Ano And c.ADoc_Doc_Num = p.PDoc_Par_Num And c.ADoc_Doc_Sub = 'Doc_PCarrInst' AND c.ADoc_Doc_Lin = '{lin}' "
        strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} And p.PDoc_Chi_Cat = 180 And p.PDoc_Chi_Ano = {anio} And p.PDoc_Chi_Num = {num} And p.PDoc_Par_Cat = 55 And p.PDoc_Par_Lin = 1 "

        If campo = STR_VACIO Then
            strSQL = Replace(strSQL, "{campo}", "c.ADoc_Dta_Txt")
        Else
            strSQL = Replace(strSQL, "{campo}", "c.ADoc_Dta_Chr")
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAño)
        strSQL = Replace(strSQL, "{num}", intNumero)
        strSQL = Replace(strSQL, "{lin}", LineaSubDoc)
        Return strSQL
    End Function
    Private Sub ImportarDatos(ByVal dgvSubDocumentosfrm As DataGridView, ByVal Documento As String)
        Me.dgvSubDocumentosfrm.DefaultCellStyle.WrapMode = DataGridViewTriState.True
        Dim iFila As Integer
        Dim dblTemp As Double
        Dim strDato As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim arreglo() As String
        Dim Div As Integer


        Try
            strSQL = DatosCliente(intAño, intNumero, intCatalogo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            REA.Read()



            For iFila = vbEmpty To dgvSubDocumentosfrm.Rows.Count - 1
                strDato = strsub
                If (strDato = Documento) Then
                    Select Case strDato
                        Case "Doc_PFactura"
                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value
                                Case "13"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = INT_CERO
                                Case "14"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = INT_CERO
                                Case "16"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = INT_CERO
                            End Select

                        Case "Doc_CCPorte", "Doc_CPckLst", "Doc_CMan", "Doc_CCPorte2", "Doc_CPckLst2", "Doc_CMan2"
                            'Carta de porte, lista de empaque y manifiesto
                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value
                                Case "01"           'Numero
                                    'Sólo si no es manifiesto
                                    'If InStr(1, strDato, "Doc_CMan2", vbTextCompare) = vbEmpty Then
                                    If intNumero > vbNullString Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = intNumero
                                    End If
                                    'End If
                                Case "02"           'Fecha
                                    If IsDate(REA.GetDateTime("Fecha")) Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                                    End If
                                Case "03"           'Importador/consignatario
                                    'Sólo si no es manifiesto
                                    strTemp = vbNullString
                                    If InStr(1, strDato, "Doc_CMan", vbTextCompare) = vbEmpty Then
                                        strTemp = RecuperarNombre(REA.GetInt32("IDcliente"))
                                    End If
                                    'Nombre y dirección
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = REA.GetString("cliente") & strTemp & vbCr & REA.GetString("direccion")
                                Case "04"            'Lugar de descarga
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = RecuperarDestinos()
                                Case "05"
                                    If strDato = "Doc_CCPorte2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = "TERRESTRE"
                                    End If
                                    'Lista de empaque
                                    If strDato = "Doc_CPckLst2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = REA.GetString("Referencia")
                                    End If
                                Case "06"           'Pedidos (ref./lista de empaque)
                                    If strDato = "Doc_CPckLst2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = RecuperarPedidos()
                                    End If
                                Case "07"
                                    If strDato = "Doc_CCPorte2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Style.BackColor = Color.Cornsilk
                                    End If


                                Case "08" ' Nombre de Piloto
                                    Dim strSQLnpi As String = STR_VACIO
                                    Dim npilot As String = STR_VACIO

                                    Dim conec As MySqlConnection
                                    strSQLnpi &= "    

                                                SELECT IFNULL((
                                                SELECT ADoc_Dta_Chr
                                                FROM Dcmtos_ACC
                                                WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 36 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                                                FROM Catalogos a
                                                INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                                                WHERE a.cat_clase = 'SubDcmtos' AND a.cat_clave = 'Doc_HFDatos' {condi} AND b.cat_clave = {vari}
                                                ORDER BY b.cat_clave, b.cat_clase

                                                "
                                    If Sesion.IdEmpresa = 11 Then
                                        strSQLnpi = Replace(strSQLnpi, "{vari}", "15")
                                        strSQLnpi = Replace(strSQLnpi, "{condi}", "")
                                    Else
                                        strSQLnpi = Replace(strSQLnpi, "{vari}", "19")
                                        strSQLnpi = Replace(strSQLnpi, "{condi}", "AND b.cat_sisemp = {empresa}")
                                    End If

                                    strSQLnpi = Replace(strSQLnpi, "{empresa}", Sesion.IdEmpresa)
                                    strSQLnpi = Replace(strSQLnpi, "{anio}", intAño)
                                    strSQLnpi = Replace(strSQLnpi, "{numero}", intNumero)

                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQLnpi, conec)
                                    Using conec
                                        npilot = COM.ExecuteScalar()
                                        COM.Dispose()
                                        COM = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using

                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = npilot


                                Case "10"       'Pedidos
                                    If strDato = "Doc_CCPorte2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = RecuperarPedidos()
                                    End If



                                Case "11"       'Marchamo
                                    Dim strSQLmarcha As String = STR_VACIO
                                    Dim marcham As String = STR_VACIO

                                    Dim conec As MySqlConnection
                                    strSQLmarcha &= "    

                                                SELECT IFNULL((
                                                SELECT ADoc_Dta_Txt
                                                FROM Dcmtos_ACC
                                                WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 36 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                                                FROM Catalogos a
                                                INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                                                WHERE a.cat_clase = 'SubDcmtos' AND a.cat_clave = 'Doc_HFDatos' AND b.cat_sisemp = {empresa} AND b.cat_clave = 5
                                                ORDER BY b.cat_clave, b.cat_clase

                                                "
                                    strSQLmarcha = Replace(strSQLmarcha, "{empresa}", Sesion.IdEmpresa)
                                    strSQLmarcha = Replace(strSQLmarcha, "{anio}", intAño)
                                    strSQLmarcha = Replace(strSQLmarcha, "{numero}", intNumero)

                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQLmarcha, conec)
                                    Using conec
                                        marcham = COM.ExecuteScalar()
                                        COM.Dispose()
                                        COM = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using

                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = marcham




                                Case "12"            'País vendedor
                                    If strDato = "Doc_CCPorte2" Then
                                        Dim strSQL2 As String = STR_VACIO
                                        Dim pais As String = STR_VACIO
                                        Dim conec As MySqlConnection

                                        strSQL2 = "   SELECT cat_desc"
                                        strSQL2 &= "      FROM Catalogos"
                                        strSQL2 &= "          WHERE cat_clase='Paises' AND cat_sist='DEF_COUNTRY'"

                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQL2, CON)
                                        Using conec
                                            pais = COM.ExecuteScalar
                                            COM.Dispose()
                                            COM = Nothing
                                            conec.Close()
                                            conec.Dispose()
                                            conec = Nothing
                                            System.GC.Collect()
                                        End Using
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = pais
                                    End If
                                Case "13"       'País origen
                                    If strDato = "Doc_CCPorte2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = RecuperarOrigen()
                                    End If
                                Case "14"       'Peso bruto (KGS)
                                    If strDato = "Doc_CCPorte2" Then
                                        Dim strSQL3 As String = STR_VACIO
                                        Dim conec As MySqlConnection

                                        strSQL3 = "  SELECT SUM(dtl.DDoc_RF2_Dbl)"
                                        strSQL3 &= "     FROM Dcmtos_DTL dtl"
                                        strSQL3 &= "         WHERE dtl.DDoc_Sis_Emp  = {empresa} and dtl.DDoc_Doc_Cat  = {catalogo} and dtl.DDoc_Doc_Ano  = {año} and dtl.DDoc_Doc_Num  = {numero}"


                                        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
                                        strSQL3 = Replace(strSQL3, "{catalogo}", intCatalogo)
                                        strSQL3 = Replace(strSQL3, "{año}", intAño)
                                        strSQL3 = Replace(strSQL3, "{numero}", intNumero)


                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQL3, conec)
                                        Using conec
                                            dblTemp = COM.ExecuteScalar()
                                            COM.Dispose()
                                            COM = Nothing
                                            conec.Close()
                                            conec.Dispose()
                                            conec = Nothing
                                            System.GC.Collect()
                                        End Using
                                        If dblTemp > vbEmpty Then
                                            dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblTemp.ToString(FORMATO_MONEDA)
                                            'dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = strkg
                                        End If
                                    End If


                                Case "17"       'Aduna Salida 
                                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = "ZL Cofradia "
                                    End If


                                Case "20"       'Cargador / Loader
                                    If strDato = "Doc_CCPorte2" Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Sesion.Empresa
                                    End If
                            End Select
                        Case "Doc_HFDatos"
                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value
                                Case "01"       'Carga el lugar de Descrarga
                                    If Not Sesion.IdEmpresa = 18 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = RecuperarDestinos()
                                    End If
                                Case "08"           'Lugar de Carga el dato de Proveedor del Hilo
                                    Dim strSQL7 As String = STR_VACIO
                                    Dim Mill As String = STR_VACIO
                                    Dim cone As MySqlConnection

                                    strSQL7 = "SELECT DISTINCT IFNULL(p.pro_proveedor,'') Mill"
                                    strSQL7 &= "     FROM Dcmtos_HDR h"
                                    strSQL7 &= "        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                                    strSQL7 &= "             LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
                                    strSQL7 &= "         LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod "
                                    strSQL7 &= "      LEFT JOIN Catalogos c ON c.cat_num = i.inv_lugarfab"
                                    strSQL7 &= "   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {numero}"

                                    strSQL7 = Replace(strSQL7, "{empresa}", Sesion.IdEmpresa)
                                    strSQL7 = Replace(strSQL7, "{cat}", intCatalogo)
                                    strSQL7 = Replace(strSQL7, "{año}", intAño)
                                    strSQL7 = Replace(strSQL7, "{numero}", intNumero)
                                    MyCnn.CONECTAR = strConexion
                                    COM = New MySqlCommand(strSQL7, CON)
                                    REA = COM.ExecuteReader
                                    If REA.HasRows Then
                                        Do While REA.Read
                                            Mill &= REA.GetString("Mill") & " /"
                                        Loop
                                    End If
                                    COM = Nothing
                                    REA.Close()
                                    REA = Nothing
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Mill
                                Case "09"      'Carga el dato del Lugar de Fabricacion del hilo
                                    Dim strSQL8 As String = STR_VACIO
                                    Dim LugFab As String = STR_VACIO
                                    Dim cone As MySqlConnection

                                    strSQL8 = "SELECT DISTINCT IFNULL(c.cat_desc,'') lugarFab"
                                    strSQL8 &= "     FROM Dcmtos_HDR h"
                                    strSQL8 &= "        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                                    strSQL8 &= "             LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
                                    strSQL8 &= "         LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod "
                                    strSQL8 &= "      LEFT JOIN Catalogos c ON c.cat_num = i.inv_lugarfab"
                                    strSQL8 &= "   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {numero}"

                                    strSQL8 = Replace(strSQL8, "{empresa}", Sesion.IdEmpresa)
                                    strSQL8 = Replace(strSQL8, "{cat}", intCatalogo)
                                    strSQL8 = Replace(strSQL8, "{año}", intAño)
                                    strSQL8 = Replace(strSQL8, "{numero}", intNumero)
                                    MyCnn.CONECTAR = strConexion
                                    COM = New MySqlCommand(strSQL8, CON)
                                    REA = COM.ExecuteReader
                                    If REA.HasRows Then
                                        Do While REA.Read
                                            LugFab &= REA.GetString("lugarFab") & " /"
                                        Loop
                                    End If
                                    COM = Nothing
                                    REA.Close()
                                    REA = Nothing
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = LugFab

                                Case "10"     'Nota por Default solo para Honduras
                                    If Sesion.IdEmpresa = 11 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = "DO NOT MIX LOTS / NO MEZCLAR LOTES"
                                    End If

                                Case "11"               'Lot
                                    Dim strSQL4 As String = STR_VACIO
                                    Dim Lot As String = STR_VACIO

                                    Dim conec As MySqlConnection
                                    strSQL4 &= "         
                                                SELECT DISTINCT IFNULL(i.inv_prodlote,'') AS lot
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                                                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                                                GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin

                                                "
                                    strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
                                    strSQL4 = Replace(strSQL4, "{anio}", intAño)
                                    strSQL4 = Replace(strSQL4, "{numero}", intNumero)

                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQL4, conec)
                                    REA = COM.ExecuteReader
                                    If REA.HasRows Then
                                        Do While REA.Read
                                            Lot &= REA.GetString("lot") & " /"
                                        Loop
                                    End If
                                    COM = Nothing
                                    REA.Close()
                                    REA = Nothing
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Lot

                                Case "12" 'Mills Provveedor (Codigo de Inventario)
                                    If Sesion.IdEmpresa = 15 Then




                                        'Dim strSQL5 As String = STR_VACIO
                                        'Dim conec As MySqlConnection
                                        'Dim dblPrecioFOB As Double

                                        'strSQL5 = "SELECT SUM(d.DDoc_Prd_Net * d.DDoc_Prd_QTY)"
                                        'strSQL5 &= "     FROM Dcmtos_HDR h "
                                        'strSQL5 &= "             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND  d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND h.HDoc_Doc_Cat = d.DDoc_Doc_cat"
                                        'strSQL5 &= "    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}"

                                        'strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                                        'strSQL5 = Replace(strSQL5, "{anio}", intAño)
                                        'strSQL5 = Replace(strSQL5, "{numero}", intNumero)

                                        'conec = New MySqlConnection(strConexion)
                                        'conec.Open()
                                        'COM = New MySqlCommand(strSQL5, conec)
                                        'Using conec
                                        '    dblPrecioFOB = COM.ExecuteScalar()
                                        '    COM.Dispose()
                                        '    COM = Nothing
                                        '    conec.Close()
                                        '    conec.Dispose()
                                        '    conec = Nothing
                                        '    System.GC.Collect()
                                        'End Using
                                        'dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblPrecioFOB.ToString(FORMATO_MONEDA)

                                        Dim strSQLMills As String = STR_VACIO
                                        Dim Proveedor As String = STR_VACIO

                                        Dim conec As MySqlConnection
                                        strSQLMills &= "         
                                                SELECT  DISTINCT IFNULL(pro_proveedor,'') as Proveedor
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                                                LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                                                LEFT JOIN Proveedores ON pro_sisemp = inv_sisemp AND pro_codigo=inv_Provcod
                                                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                                                GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin

                                                "
                                        strSQLMills = Replace(strSQLMills, "{empresa}", Sesion.IdEmpresa)
                                        strSQLMills = Replace(strSQLMills, "{anio}", intAño)
                                        strSQLMills = Replace(strSQLMills, "{numero}", intNumero)

                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQLMills, conec)
                                        REA = COM.ExecuteReader
                                        If REA.HasRows Then
                                            Do While REA.Read
                                                Proveedor &= REA.GetString("Proveedor") & " /"
                                            Loop
                                        End If
                                        COM = Nothing
                                        REA.Close()
                                        REA = Nothing
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Proveedor
                                    End If

                                Case "13"               'Origen
                                    If Sesion.IdEmpresa = 15 Then
                                        Dim strSQLOrigen As String = STR_VACIO
                                        Dim orig As String = STR_VACIO

                                        Dim conec As MySqlConnection
                                        strSQLOrigen &= "         
                                                SELECT  DISTINCT IFNULL(C.cat_desc, '') AS Pais
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                                                LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                                                LEFT JOIN Proveedores ON pro_sisemp = inv_sisemp AND pro_codigo=inv_Provcod
                                                LEFT JOIN Catalogos C ON C.cat_clase = 'Paises' AND C.cat_num= inv_lugarfab
                                                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                                                GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin

                                                "
                                        strSQLOrigen = Replace(strSQLOrigen, "{empresa}", Sesion.IdEmpresa)
                                        strSQLOrigen = Replace(strSQLOrigen, "{anio}", intAño)
                                        strSQLOrigen = Replace(strSQLOrigen, "{numero}", intNumero)

                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQLOrigen, conec)
                                        REA = COM.ExecuteReader
                                        If REA.HasRows Then
                                            Do While REA.Read
                                                orig &= REA.GetString("Pais") & " /"
                                            Loop
                                        End If
                                        COM = Nothing
                                        REA.Close()
                                        REA = Nothing
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = orig
                                    End If
                                    '=======================================================================================================
                                    ' SE AGREGA CONDICION ESPECIFICA PARA NS, TEMAS DE CATALOGOS DE SUBDOCUMENTOS NO COINCIDEN ENTRE NS-HSM

                                Case "17" 'Lugar de Carga PARA NS CATALOGO DIFERENTES
                                    If Sesion.IdEmpresa = 20 Then
                                        Dim strSQLMills As String = STR_VACIO
                                        Dim Proveedor As String = STR_VACIO

                                        Dim conec As MySqlConnection
                                        strSQLMills &= "         
                                                SELECT  DISTINCT IFNULL(pro_proveedor,'') as Proveedor
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                                                LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                                                LEFT JOIN Proveedores ON pro_sisemp = inv_sisemp AND pro_codigo=inv_Provcod
                                                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                                                GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin

                                                "
                                        strSQLMills = Replace(strSQLMills, "{empresa}", Sesion.IdEmpresa)
                                        strSQLMills = Replace(strSQLMills, "{anio}", intAño)
                                        strSQLMills = Replace(strSQLMills, "{numero}", intNumero)

                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQLMills, conec)
                                        REA = COM.ExecuteReader
                                        If REA.HasRows Then
                                            Do While REA.Read
                                                Proveedor &= REA.GetString("Proveedor") & " /"
                                            Loop
                                        End If
                                        COM = Nothing
                                        REA.Close()
                                        REA = Nothing
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Proveedor
                                    End If

                                Case "18" 'Destino Final PARA NS CATALOGO DIFERENTES
                                    If Sesion.IdEmpresa = 20 Then
                                        Dim strSQLOrigen As String = STR_VACIO
                                        Dim orig As String = STR_VACIO

                                        Dim conec As MySqlConnection
                                        strSQLOrigen &= "         
                                                SELECT  DISTINCT C.cat_desc AS Pais
                                                FROM Dcmtos_DTL d
                                                LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                                                LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                                                LEFT JOIN Proveedores ON pro_sisemp = inv_sisemp AND pro_codigo=inv_Provcod
                                                LEFT JOIN Catalogos C ON C.cat_clase = 'Paises' AND C.cat_num= inv_lugarfab
                                                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                                                GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin

                                                "
                                        strSQLOrigen = Replace(strSQLOrigen, "{empresa}", Sesion.IdEmpresa)
                                        strSQLOrigen = Replace(strSQLOrigen, "{anio}", intAño)
                                        strSQLOrigen = Replace(strSQLOrigen, "{numero}", intNumero)

                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQLOrigen, conec)
                                        REA = COM.ExecuteReader
                                        If REA.HasRows Then
                                            Do While REA.Read
                                                orig &= REA.GetString("Pais") & " /"
                                            Loop
                                        End If
                                        COM = Nothing
                                        REA.Close()
                                        REA = Nothing
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = orig
                                    End If

                            End Select
                        Case "Doc_CNotas"
                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value
                                Case "01"               'Nota1
                                    Dim strSQL5 As String = STR_VACIO
                                    Dim Nota1 As String = STR_VACIO
                                    Dim conec As MySqlConnection


                                    strSQL5 = "   SELECT cat_desc"
                                    strSQL5 &= "     FROM Catalogos"
                                    strSQL5 &= "          WHERE cat_clase = 'Defaults' AND cat_clave = 'Nota1' AND cat_sisemp= {empresa}"

                                    strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)


                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQL5, conec)
                                    Using conec
                                        Nota1 = COM.ExecuteScalar()
                                        COM.Dispose()
                                        COM = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using

                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Nota1
                                Case "02"               'Nota1
                                    Dim strSQL6 As String = STR_VACIO
                                    Dim Nota2 As String = STR_VACIO
                                    Dim conec As MySqlConnection


                                    strSQL6 = "   SELECT cat_desc"
                                    strSQL6 &= "     FROM Catalogos"
                                    strSQL6 &= "          WHERE cat_clase = 'Defaults' AND cat_clave = 'Nota2' AND cat_sisemp= {empresa}"

                                    strSQL6 = Replace(strSQL6, "{empresa}", Sesion.IdEmpresa)


                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQL6, conec)
                                    Using conec
                                        Nota2 = COM.ExecuteScalar()
                                        COM.Dispose()
                                        COM = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using

                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Nota2
                                Case "03"
                                    Dim strSQL7 As String = STR_VACIO
                                    Dim Nota3 As String = STR_VACIO
                                    Dim conec As MySqlConnection

                                    strSQL7 = "   SELECT cat_desc"
                                    strSQL7 &= "     FROM Catalogos"
                                    strSQL7 &= "          WHERE cat_clase = 'Defaults' AND cat_clave = 'Nota3' AND cat_sisemp= {empresa}"

                                    strSQL7 = Replace(strSQL7, "{empresa}", Sesion.IdEmpresa)

                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQL7, conec)
                                    Using conec
                                        Nota3 = COM.ExecuteScalar()
                                        COM.Dispose()
                                        COM = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using

                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = Nota3
                            End Select

                        Case "Doc_PolImp"
                            Dim strSQL8 As String = STR_VACIO
                            Dim COMAND As MySqlCommand
                            Dim READ As MySqlDataReader
                            Dim conec As MySqlConnection
                            Dim frm As New frmPolizaImportacion
                            Dim strSQLPI As String = STR_VACIO
                            Dim strLin As String = STR_VACIO
                            Dim datoLin As String = STR_VACIO

                            Dim dblPesoBruto As Double = 0
                            Dim dblPesoNeto As Double = 0
                            Dim dblFob As Double = 0
                            Dim dblFlete As Double = 0
                            Dim dblSeguro As Double = 0
                            Dim dblDAI As Double = 0
                            Dim dblIVA As Double = 0
                            Dim dblOtros As Double = 0


                            For i As Integer = INT_CERO To datGrid.Rows.Count - 1
                                dblPesoBruto = dblPesoBruto + datGrid.Rows(i).Cells("colKGBrutos2").Value
                                dblPesoNeto = dblPesoNeto + datGrid.Rows(i).Cells("colKGNetos2").Value
                                dblFob = dblFob + datGrid.Rows(i).Cells("colFOB2").Value
                                dblFlete = dblFlete + datGrid.Rows(i).Cells("colFlete2").Value
                                dblSeguro = dblSeguro + datGrid.Rows(i).Cells("colSeguro2").Value
                                dblDAI = dblDAI + datGrid.Rows(i).Cells("colDAI2").Value
                                dblIVA = dblIVA + datGrid.Rows(i).Cells("colIVA2").Value
                                dblOtros = dblOtros + datagrid.Rows(i).Cells("colOtros2").Value
                            Next

                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value

                                Case "07"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblPesoBruto

                                Case "08"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblPesoNeto

                                Case "09"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblFob

                                Case "10"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblFlete

                                Case "11"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblSeguro

                                Case "12"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblOtros

                                Case "14"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblDAI

                                Case "15"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblIVA
                                Case "16" ' Conocimiento de embarque
                                    strSQLPI = MostrarDatosPolizaImport(STR_VACIO, "01")
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COMAND = New MySqlCommand(strSQLPI, conec)
                                    Using conec
                                        datoLin = COMAND.ExecuteScalar
                                        COMAND.Dispose()
                                        COMAND = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = datoLin
                                Case "17" ' Manifiesto de Carga
                                    strSQLPI = MostrarDatosPolizaImport(STR_VACIO, "02")
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COMAND = New MySqlCommand(strSQLPI, conec)
                                    Using conec
                                        datoLin = COMAND.ExecuteScalar
                                        COMAND.Dispose()
                                        COMAND = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = datoLin

                                Case "18" ' Autorización de transporte
                                    strSQLPI = MostrarDatosPolizaImport("ADoc_Dta_Chr", "12")
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COMAND = New MySqlCommand(strSQLPI, conec)
                                    Using conec
                                        datoLin = COMAND.ExecuteScalar
                                        COMAND.Dispose()
                                        COMAND = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = datoLin

                                Case "19" ' Carta de Cupo
                                    strSQLPI = MostrarDatosPolizaImport(STR_VACIO, "05")
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COMAND = New MySqlCommand(strSQLPI, conec)
                                    Using conec
                                        datoLin = COMAND.ExecuteScalar
                                        COMAND.Dispose()
                                        COMAND = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = datoLin

                                Case 21
                                    strSQLPI = STR_VACIO
                                    strSQLPI = " SELECT a.ADoc_Dta_Txt FROM Dcmtos_DTL_Pro p "
                                    strSQLPI &= " Left JOIN Dcmtos_DTL_Pro d ON d.PDoc_Sis_Emp= p.PDoc_Sis_Emp AND d.PDoc_Chi_Cat = p.PDoc_Par_Cat AND d.PDoc_Chi_Ano= p.PDoc_Par_Ano AND d.PDoc_Chi_Num= p.PDoc_Par_Num AND d.PDoc_Chi_Lin = 1 AND d.PDoc_Par_Cat = 127 "
                                    strSQLPI &= " Left JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp= d.PDoc_Sis_Emp AND a.ADoc_Doc_Cat = d.PDoc_Par_Cat AND a.ADoc_Doc_Ano = d.PDoc_Par_Ano AND a.ADoc_Doc_Num= d.PDoc_Par_Num AND a.ADoc_Doc_Sub = 'Doc_PFactura' AND a.ADoc_Doc_Lin = '08' "
                                    strSQLPI &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 180 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {num} AND p.PDoc_Par_Cat = 55 AND p.PDoc_Par_Lin = 1 "

                                    strSQLPI = Replace(strSQLPI, "{empresa}", Sesion.IdEmpresa)
                                    strSQLPI = Replace(strSQLPI, "{anio}", intAño)
                                    strSQLPI = Replace(strSQLPI, "{num}", intNumero)
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COMAND = New MySqlCommand(strSQLPI, conec)
                                    Using conec
                                        datoLin = COMAND.ExecuteScalar
                                        COMAND.Dispose()
                                        COMAND = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = datoLin
                                Case 24
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = "ZZ1 - ZONA FRANCA ZETA LA UNION"

                            End Select
                        Case "Doc_RADevolucion"
                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value
                                Case "01"           'Numero
                                    Dim strSQL5 As String = STR_VACIO
                                    'Dim COM5 As MySqlCommand
                                    Dim conec As MySqlConnection
                                    Dim intDevolucion As Integer = 0

                                    strSQL5 = "Select IFNULL(MAX(ac.ADoc_Dta_Chr + 1),1)"
                                    strSQL5 &= "      FROM Dcmtos_ACC ac"
                                    strSQL5 &= "              WHERE ac.ADoc_Sis_Emp = {empresa} And ac.ADoc_Doc_Cat = {catalogo} And ac.ADoc_Doc_Ano = {anio}"

                                    strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                                    strSQL5 = Replace(strSQL5, "{catalogo}", 490)
                                    strSQL5 = Replace(strSQL5, "{anio}", intAño)

                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM = New MySqlCommand(strSQL5, conec)
                                    Using conec
                                        intDevolucion = COM.ExecuteScalar
                                        COM.Dispose()
                                        COM = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using

                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = intDevolucion
                            End Select

                        Case "Doc_PolExp"
                            Dim strSQL8 As String = STR_VACIO
                            Dim COMAND As MySqlCommand
                            Dim READ As MySqlDataReader

                            Dim dblPesoBruto As Double = 0
                            Dim dblPesoNeto As Double = 0
                            Dim dblFob As Double = 0
                            Dim dblFlete As Double = 0
                            Dim dblSeguro As Double = 0
                            Dim dblDAI As Double = 0
                            Dim dblIVA As Double = 0

                            Dim fechaCartaPorte As String = STR_VACIO
                            Dim transportista As String = STR_VACIO
                            Dim hilados As String = STR_VACIO
                            Dim precioFOB As String = STR_VACIO

                            strSQL8 = " Select  IFNULL(EDoc_Lin_Desc,0) DescLinea,IFNULL(SUM(EDoc_Lin_Gross),0) KGBrutos, IFNULL(SUM( EDoc_Lin_Net),0) KGNetos, IFNULL(SUM( EDoc_Lin_Fob),0) FOB, IFNULL(SUM( EDoc_Lin_Freight),0) Flete, IFNULL(SUM( EDoc_Lin_Insurance),0) Seguro, IFNULL(SUM( EDoc_Lin_Cargos),0) Cargos, IFNULL(SUM(EDoc_Lin_Cif),0) CIF, IFNULL(SUM( EDoc_Lin_DAI),0) DAI, IFNULL(SUM( EDoc_Lin_IVA),0) IVA "
                            strSQL8 &= " From Dcmtos_DTL "
                            strSQL8 &= " Left JOIN Dcmtos_DEC On EDoc_Sis_Emp = DDoc_Sis_Emp And EDoc_Doc_Cat = DDoc_Doc_Cat And EDoc_Doc_Ano = DDoc_Doc_Ano And EDoc_Doc_Num = DDoc_Doc_Num And EDoc_Doc_Lin = DDoc_Doc_Lin "
                            strSQL8 &= " Left JOIN Catalogos On cat_num = DDoc_Prd_UM And cat_clase = 'Medidas' "
                            strSQL8 &= " Left JOIN Inventarios ON inv_numero = DDoc_Prd_Cod AND inv_sisemp = {empresa} "
                            strSQL8 &= " Left JOIN Dcmtos_DTL_Box ON BDoc_Sis_Emp = DDoc_Sis_Emp AND BDoc_Doc_Cat = DDoc_Doc_Cat AND BDoc_Doc_Ano = DDoc_Doc_Ano AND BDoc_Doc_Num = DDoc_Doc_Num AND BDoc_Doc_Lin = DDoc_Doc_Lin "
                            strSQL8 &= " WHERE DDoc_Doc_Cat = 56 AND DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
                            strSQL8 &= " ORDER BY DDoc_Doc_Lin "

                            strSQL8 = Replace(strSQL8, "{empresa}", Sesion.IdEmpresa)
                            strSQL8 = Replace(strSQL8, "{anio}", intAño)
                            strSQL8 = Replace(strSQL8, "{numero}", intNumero)

                            Try
                                MyCnn.CONECTAR = strConexion
                                COMAND = New MySqlCommand(strSQL8, CON)
                                READ = COMAND.ExecuteReader

                                If READ.HasRows Then
                                    Do While READ.Read
                                        dblPesoBruto = READ.GetDouble("KGBrutos")
                                        dblPesoNeto = READ.GetDouble("KGNetos")
                                        dblFob = READ.GetDouble("FOB")
                                        dblFlete = READ.GetDouble("Flete")
                                        dblSeguro = READ.GetDouble("Seguro")
                                        dblDAI = READ.GetDouble("DAI")
                                        dblIVA = READ.GetDouble("IVA")
                                    Loop
                                End If

                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try

                            '============================================  BEGIN - SubDocumentos de factura para poliza de exportacion ===============================================
                            If (Sesion.idGiro = 2) Then
                                Dim strSQLDocFact As String = STR_VACIO
                                Dim ComSubFact As MySqlCommand
                                Dim ReadSubFact As MySqlDataReader


                                '========= FACTURA - CARTA DE PORTE =============
                                strSQLDocFact = " 
                            SELECT  DISTINCT b.cat_clase, b.cat_clave, b.cat_desc, b.cat_sist, IFNULL((
                            SELECT 
                                CASE 
                                WHEN b.cat_sist = 'Char' THEN CAST(COALESCE(ADoc_Dta_Chr, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Text' THEN CAST(COALESCE(ADoc_Dta_Txt, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Date' THEN CAST(COALESCE(ADoc_Dta_Fec, '') AS CHAR) 
                                WHEN b.cat_sist = 'Weight' THEN CAST(COALESCE(ADoc_Dta_Wht, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Cant' THEN CAST(COALESCE(ADoc_Dta_Num, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Money' THEN CAST(COALESCE(ADoc_Dta_Mny, '0') AS CHAR) 
                            ELSE 'ERROR' END
                            From Dcmtos_ACC
                            WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num IN ({numero}) AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                            From Catalogos a
                            INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                            Where a.cat_clase = 'SubDcmtos' AND a.cat_clave = '{SubDcmtos}' {condicion} AND b.cat_clave IN ('02', '19')  "
                                strSQLDocFact = Replace(strSQLDocFact, "{SubDcmtos}", "Doc_CCPorte2")
                                strSQLDocFact = Replace(strSQLDocFact, "{catalogo}", 36)

                                '========= FACTURA - DATOS DE FACTURACION =============
                                strSQLDocFact &= " 
                            UNION
                            SELECT  DISTINCT b.cat_clase, b.cat_clave, b.cat_desc, b.cat_sist, IFNULL((
                            SELECT 
                                CASE 
                                WHEN b.cat_sist = 'Char' THEN CAST(COALESCE(ADoc_Dta_Chr, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Text' THEN CAST(COALESCE(ADoc_Dta_Txt, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Date' THEN CAST(COALESCE(ADoc_Dta_Fec, '') AS CHAR) 
                                WHEN b.cat_sist = 'Weight' THEN CAST(COALESCE(ADoc_Dta_Wht, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Cant' THEN CAST(COALESCE(ADoc_Dta_Num, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Money' THEN CAST(COALESCE(ADoc_Dta_Mny, '0') AS CHAR) 
                            ELSE 'ERROR' END
                            From Dcmtos_ACC
                            WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num IN ({numero}) AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                            From Catalogos a
                            INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                            Where a.cat_clase = 'SubDcmtos' AND a.cat_clave = '{SubDcmtos}' {condicion}  AND b.cat_clave IN ('16', '17')  "
                                strSQLDocFact = Replace(strSQLDocFact, "{empresa}", Sesion.IdEmpresa)
                                strSQLDocFact = Replace(strSQLDocFact, "{año}", intAño)
                                strSQLDocFact = Replace(strSQLDocFact, "{numero}", numFactura)
                                strSQLDocFact = Replace(strSQLDocFact, "{SubDcmtos}", "Doc_HFDatos")
                                strSQLDocFact = Replace(strSQLDocFact, "{catalogo}", 36)
                                If (Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 20) And intCatalogo = 56 Then
                                    strSQLDocFact = Replace(strSQLDocFact, "{condicion}", "And b.cat_sisemp = " & Sesion.IdEmpresa & "")
                                Else
                                    strSQLDocFact = Replace(strSQLDocFact, "{condicion}", " ")
                                End If



                                Try
                                    MyCnn.CONECTAR = strConexion
                                    ComSubFact = New MySqlCommand(strSQLDocFact, CON)
                                    ReadSubFact = ComSubFact.ExecuteReader

                                    If ReadSubFact.HasRows Then
                                        Do While ReadSubFact.Read
                                            If (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "02") Then
                                                fechaCartaPorte = ReadSubFact.GetString("Valor")
                                            End If
                                            If (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "19") Then
                                                transportista = ReadSubFact.GetString("Valor")
                                            End If
                                            If (ReadSubFact.GetString("cat_clase") = "Doc_HFDatos" And ReadSubFact.GetString("cat_clave") = "17") Then
                                                hilados = ReadSubFact.GetString("Valor")
                                            End If
                                            If (ReadSubFact.GetString("cat_clase") = "Doc_HFDatos" And ReadSubFact.GetString("cat_clave") = "16") Then
                                                precioFOB = ReadSubFact.GetString("Valor")
                                            End If
                                        Loop
                                    End If

                                Catch ex As Exception
                                    MsgBox(ex.ToString)
                                End Try


                            End If

                            '============================================  BEGIN - SubDocumentos de factura para poliza de exportacion ===============================================

                            Select Case dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value
                                'BEGIN - SUBDOCUMENTOS DE FACTURA
                                Case "02"
                                    If Sesion.idGiro = 2 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = fechaCartaPorte
                                    End If
                                Case "18"
                                    If Sesion.idGiro = 2 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = transportista
                                    End If
                                Case "06"
                                    If Sesion.idGiro = 2 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = hilados
                                    End If
                                Case "23"
                                    If Sesion.idGiro = 2 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = fechaPolizaExportDato
                                    End If
                                'END - SUBDOCUMENTOS DE FACTURA
                                Case "07"
                                    If Not Sesion.IdEmpresa = 11 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblPesoBruto
                                    End If
                                Case "08"
                                    If Not Sesion.IdEmpresa = 11 Then
                                        dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblPesoNeto
                                    End If
                                Case "09"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblFob

                                Case "10"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblFlete

                                Case "11"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblSeguro

                                Case "14"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblDAI

                                Case "15"
                                    dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = dblIVA

                            End Select

'============================================  BEGIN - SubDocumentos de factura para poliza de exportacion ===============================================
                        Case "Prvs_Guia"

                            If (Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20) Then
                                Dim strSQL8 As String = STR_VACIO
                                '============================================  BEGIN - SubDocumentos de factura para poliza de exportacion ===============================================
                                Dim strSQLDocFact As String = STR_VACIO
                                Dim ComSubFact As MySqlCommand
                                Dim ReadSubFact As MySqlDataReader

                                '========= FACTURA - CARTA DE PORTE PESO =============
                                strSQLDocFact = " 
                            SELECT  DISTINCT b.cat_clase, b.cat_clave, b.cat_desc, b.cat_sist, IFNULL((
                            SELECT 
                                CASE 
                                WHEN b.cat_sist = 'Char' THEN CAST(COALESCE(ADoc_Dta_Chr, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Text' THEN CAST(COALESCE(ADoc_Dta_Txt, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Date' THEN CAST(COALESCE(ADoc_Dta_Fec, '') AS CHAR) 
                                WHEN b.cat_sist = 'Weight' THEN CAST(SUM(COALESCE(ADoc_Dta_Wht, '0')) AS CHAR) 
                                WHEN b.cat_sist = 'Cant' THEN CAST(COALESCE(ADoc_Dta_Num, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Money' THEN CAST(COALESCE(ADoc_Dta_Mny, '0') AS CHAR) 
                            ELSE 'ERROR' END
                            From Dcmtos_ACC
                            WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num IN ({numero}) AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                            From Catalogos a
                            INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                            Where a.cat_clase = 'SubDcmtos' AND a.cat_clave = '{SubDcmtos}' {condicion} AND b.cat_clave IN ('14')   "
                                strSQLDocFact = Replace(strSQLDocFact, "{SubDcmtos}", "Doc_CCPorte2")
                                strSQLDocFact = Replace(strSQLDocFact, "{catalogo}", 36)
                                strSQLDocFact = Replace(strSQLDocFact, "{numero}", numFactura)
                                '========= FACTURA - CARTA DE PORTE =============
                                strSQLDocFact &= "
                            UNION
                            SELECT  DISTINCT b.cat_clase, b.cat_clave, b.cat_desc, b.cat_sist, IFNULL((
                            SELECT 
                                CASE 
                                WHEN b.cat_sist = 'Char' THEN CAST(COALESCE(ADoc_Dta_Chr, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Text' THEN CAST(COALESCE(ADoc_Dta_Txt, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Date' THEN CAST(COALESCE(ADoc_Dta_Fec, '') AS CHAR) 
                                WHEN b.cat_sist = 'Weight' THEN CAST(COALESCE(ADoc_Dta_Wht, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Cant' THEN CAST(COALESCE(ADoc_Dta_Num, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Money' THEN CAST(COALESCE(ADoc_Dta_Mny, '0') AS CHAR) 
                            ELSE 'ERROR' END
                            From Dcmtos_ACC
                            WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                            From Catalogos a
                            INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                            Where a.cat_clase = 'SubDcmtos' AND a.cat_clave = '{SubDcmtos}' {condicion} AND b.cat_clave IN ('06', '07','09', '11')   "
                                strSQLDocFact = Replace(strSQLDocFact, "{SubDcmtos}", "Doc_CCPorte2")
                                strSQLDocFact = Replace(strSQLDocFact, "{catalogo}", 36)

                                '========= FACTURA - DATOS DE FACTURACION =============
                                strSQLDocFact &= " 
                            UNION
                            SELECT  DISTINCT b.cat_clase, b.cat_clave, b.cat_desc, b.cat_sist, IFNULL((
                            SELECT 
                                CASE 
                                WHEN b.cat_sist = 'Char' THEN CAST(COALESCE(ADoc_Dta_Chr, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Text' THEN CAST(COALESCE(ADoc_Dta_Txt, '{null}') AS CHAR) 
                                WHEN b.cat_sist = 'Date' THEN CAST(COALESCE(ADoc_Dta_Fec, '') AS CHAR) 
                                WHEN b.cat_sist = 'Weight' THEN CAST(COALESCE(ADoc_Dta_Wht, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Cant' THEN CAST(COALESCE(ADoc_Dta_Num, '0') AS CHAR) 
                                WHEN b.cat_sist = 'Money' THEN CAST(COALESCE(ADoc_Dta_Mny, '0') AS CHAR) 
                            ELSE 'ERROR' END
                            From Dcmtos_ACC
                            WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = b.cat_clase AND ADoc_Doc_Lin = b.cat_clave),'') AS Valor
                            From Catalogos a
                            INNER JOIN Catalogos b ON a.cat_clave = b.cat_clase
                            Where a.cat_clase = 'SubDcmtos' AND a.cat_clave = '{SubDcmtos}' {condicion}  AND b.cat_clave IN  ('03')  "
                                strSQLDocFact = Replace(strSQLDocFact, "{empresa}", Sesion.IdEmpresa)
                                strSQLDocFact = Replace(strSQLDocFact, "{año}", intAño)

                                Dim partes() As String = numFactura.Split(","c)

                                strSQLDocFact = Replace(strSQLDocFact, "{numero}", partes(0))
                                strSQLDocFact = Replace(strSQLDocFact, "{SubDcmtos}", "Doc_HFDatos")
                                strSQLDocFact = Replace(strSQLDocFact, "{catalogo}", 36)
                                strSQLDocFact = Replace(strSQLDocFact, "{condicion}", "And b.cat_sisemp = " & Sesion.IdEmpresa & "")

                                Try
                                    MyCnn.CONECTAR = strConexion
                                    ComSubFact = New MySqlCommand(strSQLDocFact, CON)
                                    ReadSubFact = ComSubFact.ExecuteReader

                                    'Debug.WriteLine("Prvs_Guia" & "/ " & dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value & "--------" & dgvSubDocumentosfrm.Rows(iFila).Cells("Descripcion").Value)

                                    If ReadSubFact.HasRows Then
                                        Do While ReadSubFact.Read

                                            'LLAVE DATAGRID "00"  AND   LLAVE DE SUBDOCUMENTOS CARTA,DATOS "00"
                                            If (dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value = "06") And (ReadSubFact.GetString("cat_clase") = "Doc_HFDatos" And ReadSubFact.GetString("cat_clave") = "03") Then
                                                dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = ReadSubFact.GetString("Valor")
                                            End If

                                            If (dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value = "07") And (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "07") Then
                                                dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = ReadSubFact.GetString("Valor")
                                            End If

                                            If (dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value = "08") And (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "06") Then
                                                dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = ReadSubFact.GetString("Valor")
                                            End If

                                            If (dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value = "13") And (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "09") Then
                                                dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = ReadSubFact.GetString("Valor")
                                            End If

                                            If (dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value = "17") And (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "11") Then
                                                dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = ReadSubFact.GetString("Valor")
                                            End If

                                            If (dgvSubDocumentosfrm.Rows(iFila).Cells("Linea").Value = "22") And (ReadSubFact.GetString("cat_clase") = "Doc_CCPorte2" And ReadSubFact.GetString("cat_clave") = "14") Then
                                                dgvSubDocumentosfrm.Rows(iFila).Cells("Contenido").Value = ReadSubFact.GetString("Valor")
                                            End If

                                        Loop
                                    End If

                                Catch ex As Exception
                                    MsgBox(ex.ToString)
                                End Try

                            End If
                            '============================================  END - SubDocumentos de factura para poliza de exportacion ===============================================

                    End Select
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Trae los países de origen del detalle
    Private Function RecuperarOrigen() As String
        Dim strSQL As String
        Dim strPais As String
        Dim strTemp As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection


        strSQL = "  SELECT IFNULL(( SELECT DISTINCT(c.cat_desc)  from Dcmtos_DTL d"
        strSQL &= "      LEFT JOIN Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "         LEFT JOIN Catalogos c on c.cat_num =  i.inv_lugarfab "
        strSQL &= "       WHERE d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = {catalogo} and d.DDoc_Doc_Ano = {año} and d.DDoc_Doc_Num = {numero} ), '') AS cat_desc"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{año}", Año)
        strSQL = Replace(strSQL, "{numero}", Numero)


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            strPais = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        If Not (strPais = vbNullString) Then
            If InStr(1, strTemp, strPais) = vbEmpty Then
                strTemp = strPais
            End If
        End If

        Return strTemp
    End Function

    'Trae el nombre de la empresa a quien se cargará la venta (PF / por instrucciones de)
    Private Function RecuperarNombre(ByVal ID As Integer) As String
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection


        If strSQL = vbNullString Then
            strSQL = " SELECT GROUP_CONCAT(DISTINCT c.cli_cliente SEPARATOR ' / ') Dato"
            strSQL &= " FROM Dcmtos_DTL_Pro ri"
            strSQL &= "      INNER JOIN Dcmtos_DTL_Pro pp on pp.PDoc_Sis_Emp =ri.PDoc_Sis_Emp and pp.PDoc_Chi_Cat = ri.PDoc_Par_Cat and pp.PDoc_Chi_Ano = ri.PDoc_Par_Ano and pp.PDoc_Chi_Num = ri.PDoc_Par_Num and pp.PDoc_Chi_Lin = ri.PDoc_Par_Lin "
            strSQL &= "          INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=pp.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=pp.PDoc_Par_Cat AND e.HDoc_Doc_Ano=pp.PDoc_Par_Ano AND e.HDoc_Doc_Num =pp.PDoc_Par_Num"
            strSQL &= "              INNER JOIN Clientes c ON c.cli_sisemp=e.HDoc_Sis_Emp AND c.cli_codigo=e.HDoc_DR1_Emp"
            strSQL &= "          WHERE ri.PDoc_Sis_Emp={empresa} AND ri.PDoc_Par_Cat=48 AND ri.PDoc_Chi_Cat= 36 AND ((ri.PDoc_Chi_Ano= {año} AND ri.PDoc_Chi_Num = {numero})) AND NOT(c.cli_codigo= {codCliente})"
            strSQL &= "      GROUP BY e.HDoc_Emp_Cod"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", Año)
            strSQL = Replace(strSQL, "{numero}", Numero)
            strSQL = Replace(strSQL, "{codCliente}", ID)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                strTemp = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            If Not (strTemp = vbNullString) Then
                strTemp = " / " & strTemp
            End If
        End If

        Return strTemp
    End Function

    'Trae los destinos del detalle (lugares de descarga)
    Private Function RecuperarDestinos() As String
        Dim intCodigo As Integer
        Dim strDireccion As String  'Direccion guardada anteriormente
        Dim strTemp As String
        Dim strLista As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim conec2 As MySqlConnection

        ' ======================= BEGIN - DIRECCIION CLIENTE
        ' SELECIONA DIRECCION DEL CLIENTE, UTILIZA LA PRIMARY CLIENTE PARA BUSCAR DATO....

        strSQL2 = "  SELECT dtl.DDoc_RF1_Num codLugar"
        strSQL2 &= " FROM Dcmtos_DTL dtl"
        strSQL2 &= " WHERE dtl.DDoc_Sis_Emp  = {empresa} and dtl.DDoc_Doc_Cat  = {catalogo} and dtl.DDoc_Doc_Ano  = {año} and dtl.DDoc_Doc_Num  = {numero}"

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{catalogo}", Catalogo)
        strSQL2 = Replace(strSQL2, "{año}", Año)
        strSQL2 = Replace(strSQL2, "{numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL2, conec)
        Using conec
            intCodigo = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
        ' ======================= END - DIRECCIION CLIENTE

        ' ======================= BEGIN - DIRECCIION CLIENTE
        ' SELECCIONAR DIRECCION DE REGISTRO EN EL TABLA dcmtos_acc

        strSQL3 = " SELECT ADoc_Dta_Txt AS Direccion "
        strSQL3 &= " FROM Dcmtos_ACC dacc"
        strSQL3 &= " WHERE dacc.ADoc_Sis_Emp = {empresa} and dacc.ADoc_Doc_Cat = {catalogo} and dacc.ADoc_Doc_Ano = {año} and dacc.ADoc_Doc_Num = {numero} and dacc.ADoc_Doc_Lin = '04'  and ADoc_Doc_Sub = 'Doc_CCPorte2' "

        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
        strSQL3 = Replace(strSQL3, "{catalogo}", Catalogo)
        strSQL3 = Replace(strSQL3, "{año}", Año)
        strSQL3 = Replace(strSQL3, "{numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL3, conec)
        Using conec
            strDireccion = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
        ' ======================= END - DIRECCIION CLIENTE

        'Acumula los destinos
        If intCodigo > vbEmpty Then
            strTemp = intCodigo & ","
        Else
            strTemp = strTemp & "," & intCodigo
        End If

        ' SE AGREGA CONDICION PARA VALIDAR SI EXISTE UN DATO GUARDADO EN TABLA dcmtos_acc
        If Not (strTemp = vbNullString) And strDireccion = vbNullString Then
            'Prepara la Consulta

            'trLista &= strTemp & " ,"

            strSQL = "  SELECT cli_cliente Nombre, cli_direccion Direccion"
            strSQL &= "      FROM Clientes"
            strSQL &= "          WHERE cli_sisemp={empresa} AND cli_codigo= {codigo}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intCodigo)

            Try
                conec2 = New MySqlConnection(strConexion)
                conec2.Open()
                COM = New MySqlCommand(strSQL, conec2)
                REA = COM.ExecuteReader


                If REA.HasRows Then

                    Do While REA.Read
                        strLista = REA.GetString("Nombre") & " " & vbCrLf & REA.GetString("Direccion")
                    Loop
                End If
                REA.Close()
                REA = Nothing
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            'SE ENVIA DIRECCION YA GUARDADA
            strLista = strDireccion
        End If


        Return strLista
        conec2.Close()
    End Function

    'Trae los pedidos trabajados en esta factura
    Private Function RecuperarPedidos() As String
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim strLista As String = STR_VACIO
        Dim strDato As String = STR_VACIO
        Dim strDato2 As String = STR_VACIO
        'Dim COM2 As New MySqlCommand
        'Dim REA As MySqlDataReader
        'Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        strTemp = vbNullString


        strSQL = vbNullString
        strSQL &= " SELECT e.HDoc_Doc_Num Pedido, e.HDoc_DR1_Num Referencia"
        strSQL &= "    FROM Dcmtos_DTL_Pro ri"
        strSQL &= "          INNER JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp =ri.PDoc_Sis_Emp AND pp.PDoc_Chi_Cat = ri.PDoc_Par_Cat AND pp.PDoc_Chi_Ano = ri.PDoc_Par_Ano AND pp.PDoc_Chi_Num = ri.PDoc_Par_Num AND pp.PDoc_Chi_Lin = ri.PDoc_Par_Lin"
        strSQL &= "                  INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=pp.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=pp.PDoc_Par_Cat AND e.HDoc_Doc_Ano=pp.PDoc_Par_Ano AND e.HDoc_Doc_Num  =pp.PDoc_Par_Num"
        strSQL &= "    INNER JOIN Clientes c ON c.cli_sisemp=e.HDoc_Sis_Emp AND c.cli_codigo=e.HDoc_DR1_Emp"
        strSQL &= "  WHERE ri.PDoc_Sis_Emp={empresa} AND ri.PDoc_Par_Cat=48 AND ri.PDoc_Chi_Cat= 36 AND ((ri.PDoc_Chi_Ano= {año} AND ri.PDoc_Chi_Num = {numero}))"
        strSQL &= "  GROUP BY e.HDoc_Doc_Cat, e.HDoc_Doc_Ano, e.HDoc_Doc_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", Año)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Try
            'conec = New MySqlConnection
            'conec.ConnectionString = strConexion
            'conec.Open()
            'COM2 = New MySqlCommand(strSQL, conec)
            'REA = COM2.ExecuteReader

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    strDato = vbNullString
                    If Not (REA.GetInt32("Pedido") = vbNullString) Then
                        strDato = "PF" & REA.GetString("Pedido") & " : "
                    End If
                    strDato2 = REA.GetString("Referencia") & Space(2) & strLista
                    'Agrega el pedido al listado
                    strLista = strDato & strDato2
                Loop
            End If
            REA.Close()
            REA = Nothing
            COM = Nothing
            'conec.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        'Devuelve el resultado
        Return strLista

    End Function

    Private Function ValidarReclamo() As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim Valor As Integer = INT_CERO

        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            strSQL = " SELECT COUNT(*) Registros " & _
                     "  FROM Dcmtos_HDR  " & _
                     "      WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {catalogo} AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
            strSQL = Replace(strSQL, "{año}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)

            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar

            If Valor >= 1 Then
                logResultado = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return logResultado
    End Function

    Private Function llenarGrid() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT ADoc_Doc_Lin Lineas,ADoc_Dta_Mny Note,ADoc_Dta_Txt Issues,ADoc_Dta_Fec Date,ADoc_Dta_Chr GTO " & _
                 "      FROM Dcmtos_ACC " & _
                 "          WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = '{condicion}' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{condicion}", strsub)

        Return strSQL
    End Function

    Private Sub BuscarACC()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Valor As Integer = INT_CERO
        Dim CON As MySqlConnection

        strSQL = " SELECT COUNT(*) " & _
                 "  FROM Dcmtos_ACC " & _
                 "      WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)


        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar

            If Valor > 0 Then
                Dim Grid As String = STR_VACIO
                Dim COMG As MySqlCommand
                Dim ACCG As New Tablas.TDCMTOS_ACC
                Dim CONG As MySqlConnection
                Dim REAG As MySqlDataReader
                Dim Linea As String = STR_VACIO
                Dim fecha As String = STR_VACIO
                Dim i As Integer = 0

                Grid = llenarGrid()

                CONG = New MySqlConnection(strConexion)
                CONG.Open()

                COMG = New MySqlCommand(Grid, CONG)
                REAG = COMG.ExecuteReader

                Do While REAG.Read

                    Linea = REAG.GetString("Lineas")


                    Select Case Linea

                        Case "01"
                            dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = REAG.GetString("GTO")

                        Case "02"
                            fecha = REAG.GetString("Date")

                            dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = FormatDateTime(CDate(fecha), DateFormat.ShortDate)

                        Case "03"
                            dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = REAG.GetString("Issues")

                        Case "04"
                            dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = REAG.GetDouble("Note")

                    End Select
                    i = i + 1

                Loop
                CONG.Open()
            End If

        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try
        CON.Close()
    End Sub

    Private Sub BorrarGTO(ByVal Catalogo As Integer, Optional ByVal NumContrato As Integer = 0)
        Dim borrarDatos As String = STR_VACIO
        Dim COMB As MySqlCommand
        Dim CONB As MySqlConnection
        Dim acc As New Tablas.TDCMTOS_ACC




        borrarDatos = "      " & _
                      " ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = '{condicion}' "

        borrarDatos = Replace(borrarDatos, "{empresa}", Sesion.IdEmpresa)
        borrarDatos = Replace(borrarDatos, "{catalogo}", Catalogo)
        borrarDatos = Replace(borrarDatos, "{año}", intAño)
        If NumContrato > 0 Then
            borrarDatos = Replace(borrarDatos, "{numero}", NumContrato)
        Else
            borrarDatos = Replace(borrarDatos, "{numero}", intNumero)
        End If

        borrarDatos = Replace(borrarDatos, "{condicion}", strsub)
        acc.CONEXION = strConexion
        CONB = New MySqlConnection(strConexion)
        CONB.Open()

        Try
            COMB = New MySqlCommand(borrarDatos, CONB)

            acc.CONEXION = strConexion
            acc.PDELETE(borrarDatos)
            'COMB.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        CONB.Close()
    End Sub

    Public Sub GuardarCaso()
        Dim ACC As New Tablas.TDCMTOS_ACC
        Dim Valor As Integer = INT_CERO
        Dim strTipo As String = STR_VACIO
        Dim PolImport As New frmPolizaImportacion
        Dim polExport As New frmPolizaExportacion
        Dim strTasaCamb As String
        Try


            Valor = contarDatos(intCatalogo)


            If CInt(Valor >= 0) Then
                BorrarGTO(intCatalogo)

                Try
                    If ValidarReclamo() = True Then

                        For i As Integer = 0 To dgvSubDocumentosfrm.Rows.Count - 1

                            ACC = New Tablas.TDCMTOS_ACC
                            ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                            ACC.ADOC_DOC_CAT = intCatalogo
                            ACC.ADOC_DOC_ANO = intAño
                            ACC.ADOC_DOC_NUM = intNumero
                            ACC.ADOC_DOC_LIN = dgvSubDocumentosfrm.Rows(i).Cells("Linea").Value
                            ACC.ADOC_DOC_SUB = strsub
                            ACC.ADOC_DTA_DES = dgvSubDocumentosfrm.Rows(i).Cells("Descripcion").Value
                            strTipo = dgvSubDocumentosfrm.Rows(i).Cells("Datos").Value


                            Select Case strTipo

                                Case "Money"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = 0 Or dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = vbNullString Or dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = Nothing Then
                                        ACC.ADOC_DTA_MNY = 0
                                    Else
                                        ACC.ADOC_DTA_MNY = CDbl(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value)
                                    End If
                                Case "Weight"

                                    If strTipoDoc = "Doc_PolImp" Or strTipoDoc = "Doc_PolExp" Then
                                        If dgvSubDocumentosfrm.Rows(i).Cells("Descripcion").Value = "Tipo de cambio" Then

                                            If Not (dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value) = dblTasaC Then
                                                If MsgBox("The rate of change of the policy is different from that of the document" & vbCrLf & vbCrLf & "Policy: " & dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value & vbCrLf & "Document: " & dblTasaC & vbCrLf & vbCrLf & "¿You want to place the policy rate?", vbYesNo, "Exchange rate") = vbYes Then
                                                    dblTasaC = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                                    ' PolImport.TasaCambio = CDbl(dblTasaC)
                                                Else
                                                    dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = CDbl(dblTasaC)
                                                End If
                                            End If
                                        End If
                                    End If
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = 0 Or dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = vbNullString Or dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = Nothing Then
                                        ACC.ADOC_DTA_WHT = 0
                                    Else
                                        ACC.ADOC_DTA_WHT = CDbl(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value)
                                    End If
                                Case "Text"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                        ACC.ADOC_DTA_TXT = " "
                                    Else
                                        ACC.ADOC_DTA_TXT = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    End If
                                Case "Date"
                                    If cFunciones.ValidarFecha(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value) = True Then
                                        ACC.ADoc_Dta_Fec_NET = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    ElseIf dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = Nothing Then

                                    Else
                                        MsgBox("Fecha Invalida")
                                    End If
                                Case "Char"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = vbNullString Or dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = "" Then
                                        ACC.ADOC_DTA_CHR = " "
                                    Else
                                        ACC.ADOC_DTA_CHR = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    End If
                                Case "Cant"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = vbNullString Or dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = "" Then
                                        ACC.ADOC_DTA_NUM = 0
                                    Else
                                        ACC.ADOC_DTA_NUM = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    End If

                            End Select
                            ACC.CONEXION = strConexion
                            Try
                                If ACC.PINSERT = False Then
                                    MsgBox(ACC.MERROR.ToString)
                                End If
                                ACC.Dispose()
                                ACC = Nothing

                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try
                        Next
                        ' MsgBox("Documento Actualizado")
                    Else
                        MsgBox("Debe Guardar Primero el Documento y luego los Subdocumentos")
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Else

                Try
                    If ValidarReclamo() = True Then

                        For i As Integer = 0 To dgvSubDocumentosfrm.Rows.Count - 1

                            ACC = New Tablas.TDCMTOS_ACC
                            ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                            ACC.ADOC_DOC_CAT = intCatalogo
                            ACC.ADOC_DOC_ANO = intAño
                            ACC.ADOC_DOC_NUM = intNumero
                            ACC.ADOC_DOC_LIN = dgvSubDocumentosfrm.Rows(i).Cells("Linea").Value
                            ACC.ADOC_DOC_SUB = strsub
                            ACC.ADOC_DTA_DES = dgvSubDocumentosfrm.Rows(i).Cells("Descripcion").Value
                            strTipo = dgvSubDocumentosfrm.Rows(i).Cells("Datos").Value


                            Select Case strTipo

                                Case "Money"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                        ACC.ADOC_DTA_MNY = INT_CERO
                                    Else
                                        ACC.ADOC_DTA_MNY = CDbl(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value)
                                    End If

                                Case "Weight"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                        ACC.ADOC_DTA_WHT = 0
                                    Else
                                        ACC.ADOC_DTA_WHT = CDbl(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value)
                                    End If

                                Case "Text"

                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                        ACC.ADOC_DTA_TXT = " "
                                    Else
                                        ACC.ADOC_DTA_TXT = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    End If

                                Case "Date"
                                    If cFunciones.ValidarFecha(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value) = True Then
                                        ACC.ADoc_Dta_Fec_NET = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    ElseIf dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = Nothing Then
                                    Else
                                        MsgBox("Fecha Invalida")
                                    End If
                                Case "Char"
                                    If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                        ACC.ADOC_DTA_CHR = INT_CERO
                                    Else
                                        ACC.ADOC_DTA_CHR = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                    End If


                            End Select
                            ACC.CONEXION = strConexion
                            If ACC.PINSERT = False Then
                                MsgBox(ACC.MERROR.ToString)
                            End If
                            ACC.Dispose()
                            ACC = Nothing

                        Next
                        'MsgBox("Documento Guardado")

                    Else
                        MsgBox("Debe Guardar Primero el Documento y luego los Subdocumentos")
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            End If

            Try
                If Catalogo = 75 Then
                    If ContratoActivo = True Then

                        Valor = contarDatos(389)
                        If Valor > 0 Then
                            BorrarGTO(389, Contrato)
                            For i As Integer = 0 To dgvSubDocumentosfrm.Rows.Count - 1

                                ACC = New Tablas.TDCMTOS_ACC
                                ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                                ACC.ADOC_DOC_CAT = 389
                                ACC.ADOC_DOC_ANO = intAño
                                ACC.ADOC_DOC_NUM = intContrato
                                ACC.ADOC_DOC_LIN = dgvSubDocumentosfrm.Rows(i).Cells("Linea").Value
                                ACC.ADOC_DOC_SUB = strsub
                                ACC.ADOC_DTA_DES = dgvSubDocumentosfrm.Rows(i).Cells("Descripcion").Value
                                strTipo = dgvSubDocumentosfrm.Rows(i).Cells("Datos").Value

                                Select Case strTipo

                                    Case "Weight"
                                        ACC.ADOC_DTA_WHT = CDbl(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value)
                                    Case "Text"

                                        If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                            ACC.ADOC_DTA_TXT = " "
                                        Else
                                            ACC.ADOC_DTA_TXT = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                        End If

                                    Case "Date"
                                        If cFunciones.ValidarFecha(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value) = True Then
                                            ACC.ADoc_Dta_Fec_NET = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                        ElseIf dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = Nothing Then
                                        Else
                                            MsgBox("Fecha Invalida")
                                        End If

                                    Case "Char"
                                        ACC.ADOC_DTA_CHR = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value


                                End Select
                                ACC.CONEXION = strConexion
                                If ACC.PINSERT = False Then
                                    MsgBox(ACC.MERROR.ToString)
                                End If
                                ACC.Dispose()
                                ACC = Nothing
                            Next
                        Else
                            'MsgBox("You cant not store contract data because you have not checked the credit card check", MsgBoxStyle.Information)
                            'Exit Sub
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            Try
                If Catalogo = 127 Then
                    If PolImportacion = True Then

                        Valor = contarDatos(55)
                        If Valor > 0 Then
                            BorrarGTO(55, intNumero)
                            For i As Integer = 0 To dgvSubDocumentosfrm.Rows.Count - 1

                                ACC = New Tablas.TDCMTOS_ACC
                                ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                                ACC.ADOC_DOC_CAT = 55
                                ACC.ADOC_DOC_ANO = intAño
                                ACC.ADOC_DOC_NUM = intNumero
                                ACC.ADOC_DOC_LIN = dgvSubDocumentosfrm.Rows(i).Cells("Linea").Value
                                ACC.ADOC_DOC_SUB = strsub
                                ACC.ADOC_DTA_DES = dgvSubDocumentosfrm.Rows(i).Cells("Descripcion").Value
                                strTipo = dgvSubDocumentosfrm.Rows(i).Cells("Datos").Value

                                Select Case strTipo

                                    Case "Weight"
                                        If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                            ACC.ADOC_DTA_WHT = INT_CERO
                                        Else
                                            ACC.ADOC_DTA_WHT = CDbl(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value)
                                        End If

                                    Case "Text"

                                        If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                            ACC.ADOC_DTA_TXT = " "
                                        Else
                                            ACC.ADOC_DTA_TXT = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                        End If

                                    Case "Date"
                                        If cFunciones.ValidarFecha(dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value) = True Then
                                            ACC.ADoc_Dta_Fec_NET = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                        ElseIf dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = Nothing Then
                                        Else
                                            MsgBox("Fecha Invalida")
                                        End If

                                    Case "Char"
                                        If dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value = STR_VACIO Then
                                            ACC.ADOC_DTA_CHR = INT_CERO
                                        Else
                                            ACC.ADOC_DTA_CHR = dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                                        End If



                                End Select
                                ACC.CONEXION = strConexion
                                If ACC.PINSERT = False Then
                                    MsgBox(ACC.MERROR.ToString)
                                End If
                                ACC.Dispose()
                                ACC = Nothing
                            Next
                        Else
                            'MsgBox("You cant not store contract data because you have not checked the credit card check", MsgBoxStyle.Information)
                            'Exit Sub
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Public Sub GuardarFacturaPrideYarn()
        Dim ACC As New Tablas.TDCMTOS_ACC
        Dim Valor As Integer = INT_CERO
        Dim strTipo As String = STR_VACIO
        Dim PolImport As New frmPolizaImportacion
        Dim polExport As New frmPolizaExportacion
        Dim strTasaCamb As String

        Valor = contarDatos(intCatalogo)


        If CInt(Valor > 0) Then
            BorrarGTO(intCatalogo)

            Try
                If ValidarReclamo() = True Then

                    For i As Integer = 0 To dgvSubDocumentosfrm.Rows.Count - 1

                        ACC = New Tablas.TDCMTOS_ACC
                        ACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                        ACC.ADOC_DOC_CAT = intCatalogo
                        ACC.ADOC_DOC_ANO = intAño
                        ACC.ADOC_DOC_NUM = intNumero
                        ACC.ADOC_DOC_LIN = dgvSubDocumentosfrm.Rows(i).Cells("Linea").Value
                        If strsub = "Doc_CCPorte2" Then
                            ACC.ADOC_DOC_SUB = strsub
                            ACC.ADOC_DTA_DES = dgvSubDocumentosfrm.Rows(i).Cells("Descripcion").Value
                            strTipo = dgvSubDocumentosfrm.Rows(i).Cells("Datos").Value

                            Select Case strTipo



                            End Select
                        End If




                        ACC.CONEXION = strConexion
                        Try
                            If ACC.PINSERT = False Then
                                MsgBox(ACC.MERROR.ToString)
                            End If
                            ACC.Dispose()
                            ACC = Nothing

                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try
                    Next
                Else
                    MsgBox("Debe Guardar Primero el Documento y luego los Subdocumentos")
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Function CargarDeImportacion(ByVal intAño As Integer, ByVal intNumero As Integer) As String

        Dim strsql As String = STR_VACIO
        Me.dgvSubDocumentosfrm.DefaultCellStyle.WrapMode = DataGridViewTriState.True

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection

        Const STR_CPORTE2 As String = "Doc_CCPorte2"
        Const STR_LPLACA As String = "07"
        Const STR_BL As String = "Doc_PBLading"
        Const STR_CARRIER As String = "Doc_PCarrInst"
        Const STR_CONTENEDOR As String = "04"
        Const STR_PLACA As String = "04"
        Const STR_NOMBRE As String = "06"
        Const STR_LICENCIA As String = "11"

        Const Ingreso As String = "47"
        Const Despacho As String = "48"
        Const Importacion As String = "180"
        Const Datos As String = "55"
        Dim i As Integer = 0

        CON = New MySqlConnection(strConexion)
        CON.Open()

        strsql = " SELECT IFNULL(dc.ADoc_Dta_Txt,'') Contenedor, IFNULL(dp.ADoc_Dta_Txt,'') Placa, IFNULL(dn.ADoc_Dta_Txt,'') Nombre, IFNULL(dl.ADoc_Dta_Chr,'') Licencia"
        strsql &= "  FROM Dcmtos_DTL_Pro n "
        strsql &= "    LEFT JOIN Dcmtos_DTL_Pro m ON m.PDoc_Sis_Emp=n.PDoc_Sis_Emp AND m.PDoc_Chi_Cat=n.PDoc_Par_Cat AND m.PDoc_Chi_Ano=n.PDoc_Par_Ano AND m.PDoc_Chi_Num=n.PDoc_Par_Num AND m.PDoc_Chi_Lin=n.PDoc_Par_Lin AND m.PDoc_Par_Cat={importacion}"
        strsql &= "      LEFT JOIN Dcmtos_DTL_Pro s ON s.PDoc_Sis_Emp=m.PDoc_Sis_Emp AND s.PDoc_Chi_Cat=m.PDoc_Par_Cat AND s.PDoc_Chi_Ano=m.PDoc_Par_Ano AND s.PDoc_Chi_Num=m.PDoc_Par_Num AND s.PDoc_Chi_Lin=m.PDoc_Par_Lin AND s.PDoc_Par_Cat={datos}"
        strsql &= "         LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=m.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=m.PDoc_Par_Cat AND e.HDoc_Doc_Ano=m.PDoc_Par_Ano AND e.HDoc_Doc_Num=m.PDoc_Par_Num "
        strsql &= "          LEFT JOIN Dcmtos_ACC dc ON dc.ADoc_Sis_Emp=s.PDoc_Sis_Emp AND dc.ADoc_Doc_Cat=s.PDoc_Par_Cat AND dc.ADoc_Doc_Ano=s.PDoc_Par_Ano AND dc.ADoc_Doc_Num=s.PDoc_Par_Num AND dc.ADoc_Doc_Sub='{bl}' AND dc.ADoc_Doc_Lin='{contenedor}' "
        strsql &= "             LEFT JOIN Dcmtos_ACC dp ON dp.ADoc_Sis_Emp=s.PDoc_Sis_Emp AND dp.ADoc_Doc_Cat=s.PDoc_Par_Cat AND dp.ADoc_Doc_Ano=s.PDoc_Par_Ano AND dp.ADoc_Doc_Num=s.PDoc_Par_Num AND dp.ADoc_Doc_Sub='{carrier}' AND dp.ADoc_Doc_Lin='{placa}'"
        strsql &= "          LEFT JOIN Dcmtos_ACC dn ON dn.ADoc_Sis_Emp=s.PDoc_Sis_Emp AND dn.ADoc_Doc_Cat=s.PDoc_Par_Cat AND dn.ADoc_Doc_Ano=s.PDoc_Par_Ano AND dn.ADoc_Doc_Num=s.PDoc_Par_Num AND dn.ADoc_Doc_Sub='{carrier}' AND dn.ADoc_Doc_Lin='{nombre}'"
        strsql &= "         LEFT JOIN Dcmtos_ACC dl ON dl.ADoc_Sis_Emp=s.PDoc_Sis_Emp AND dl.ADoc_Doc_Cat=s.PDoc_Par_Cat AND dl.ADoc_Doc_Ano=s.PDoc_Par_Ano AND dl.ADoc_Doc_Num=s.PDoc_Par_Num AND dl.ADoc_Doc_Sub='{carrier}' AND dl.ADoc_Doc_Lin='{licencia}'"
        strsql &= "     WHERE n.PDoc_Sis_Emp={empresa} AND n.PDoc_Par_Cat={ingreso} AND n.PDoc_Chi_Cat={instruccion} AND ((n.PDoc_Chi_Ano={año} AND n.PDoc_Chi_Num={numero}))"
        strsql &= "    GROUP BY s.PDoc_Sis_Emp, s.PDoc_Par_Cat, s.PDoc_Par_Ano, s.PDoc_Par_Num"
        strsql &= "   ORDER BY e.HDoc_Doc_Fec DESC, e.HDoc_Doc_Num"
        strsql &= " LIMIT 1"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{ingreso}", Ingreso)
        strsql = Replace(strsql, "{instruccion}", Despacho)
        strsql = Replace(strsql, "{importacion}", Importacion)
        strsql = Replace(strsql, "{datos}", Datos)
        strsql = Replace(strsql, "{bl}", STR_BL)
        strsql = Replace(strsql, "{carrier}", STR_CARRIER)
        strsql = Replace(strsql, "{contenedor}", STR_CONTENEDOR)
        strsql = Replace(strsql, "{placa}", STR_PLACA)
        strsql = Replace(strsql, "{nombre}", STR_NOMBRE)
        strsql = Replace(strsql, "{licencia}", STR_LICENCIA)
        strsql = Replace(strsql, "{año}", intAño)
        strsql = Replace(strsql, "{numero}", intNumero)

        Try

            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                i = vbEmpty

                While REA.Read
                    If MsgBox("Se cargaran los siguientes datos" & vbNewLine &
                              "Contenedor: " & vbTab & REA.GetString("Contenedor") & vbNewLine &
                              "No. de Placa: " & vbTab & REA.GetString("Placa") & vbNewLine &
                              "Nombre de Piloto: " & vbTab & REA.GetString("Nombre") & vbNewLine &
                              "No. de Licencia: " & vbTab & REA.GetString("Licencia")) Then
                    End If

                    If MsgBoxResult.Ok Then

                        Dim strFila As String = STR_VACIO
                        dgvSubDocumentosfrm.Rows(6).Cells("Contenido").Value = REA.GetString("Contenedor")
                        dgvSubDocumentosfrm.Rows(6).Cells("Contenido").Style.ForeColor = Color.Blue
                        dgvSubDocumentosfrm.Rows(7).Cells("Contenido").Value = REA.GetString("Placa")
                        dgvSubDocumentosfrm.Rows(7).Cells("Contenido").Style.ForeColor = Color.Blue
                        dgvSubDocumentosfrm.Rows(8).Cells("Contenido").Value = REA.GetString("Nombre")
                        dgvSubDocumentosfrm.Rows(8).Cells("Contenido").Style.ForeColor = Color.Blue
                        dgvSubDocumentosfrm.Rows(9).Cells("Contenido").Value = REA.GetString("Licencia")
                        dgvSubDocumentosfrm.Rows(9).Cells("Contenido").Style.ForeColor = Color.Blue
                    End If

                End While
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strsql
        CON.Close()
    End Function

    Private Sub frmSubDocumentos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim fac As New frmFacturacion
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim subDoc As Integer

        strSQL = "SELECT COUNT(*)"
        strSQL &= "  FROM Dcmtos_ACC a"
        strSQL &= "          WHERE a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = {catalogo} AND a.ADoc_Doc_Ano = {año} AND a.ADoc_Doc_Num = {numero} AND a.ADoc_Doc_Sub = '{subdocumento}'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", Catalogo)
        strSQL = Replace(strSQL, "{año}", Año)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{subdocumento}", Doc)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        subDoc = COM.ExecuteScalar()

        If subDoc = 0 Or Doc = "Doc_CNotas" Then

            CargarSubDcmtos()
            ImportarDatos(dgvSubDocumentosfrm, strsub)
        Else
            CargarSubDcmtos()
            'ImportarDatos(dgvSubDocumentosfrm, strsub)
        End If

        dgvSubDocumentosfrm.Columns(2).Width = 225

        If celdaDocumento.Text = STR_CPORTE2 Then
            botonDatosPoliza.Visible = True
        Else
            botonDatosPoliza.Visible = False

        End If

    End Sub

    Public Function contarDatos(ByVal Catalogo As Integer) As Integer
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection
        Dim Scalar As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*) " &
                 "  FROM Dcmtos_ACC " &
                 "      WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {catalogo} AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            Scalar = COM.ExecuteScalar()
            CON.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


        Return Scalar

    End Function
    Private Function BuscarRegistrosDcmtos_DTL(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("FacturaComercial2")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\Dcmtos_DTLFCHN.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarRegistrosDcmtos_ACC(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("FacturaComercial")
        adaptador.Fill(Tablas, "Dcmtos_ACC")
        If Tablas.Tables("Dcmtos_ACC").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\Dcmtos_ACCFCHN.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Public Sub FacturaComercial(ByVal anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim repCR As New FacturaComercialHN

        strSQL = "      SELECT IFNULL(final.numero,'') AS Numero, IFNULL(GROUP_CONCAT(DISTINCT(final.fecha)),'') AS fecha, IFNULL(GROUP_CONCAT(DISTINCT(final.importador)),'') AS Salida, "
        strSQL &= "         IFNULL(GROUP_CONCAT(DISTINCT(final.descarga)),'') AS Destino, IFNULL(GROUP_CONCAT(DISTINCT(final.trasporte)),'') AS transporte, IFNULL(GROUP_CONCAT(DISTINCT(final.furgon)),'') AS Motorista, "
        strSQL &= "             IFNULL(GROUP_CONCAT(DISTINCT(final.cabezal)),'') AS cabezal, IFNULL(GROUP_CONCAT(DISTINCT(final.piloto)),'') AS Furgon, IFNULL(GROUP_CONCAT(DISTINCT(final.licencia)),'') AS Bultos, "
        strSQL &= "                 IFNULL(GROUP_CONCAT(DISTINCT(final.pedido)),'') AS TotalKGS, IFNULL(GROUP_CONCAT(DISTINCT(final.marchamo)),'') AS marchamo, IFNULL(GROUP_CONCAT(DISTINCT(final.vendedor)),'') AS vendedor, "
        strSQL &= "                     IFNULL(GROUP_CONCAT(DISTINCT(final.origen)),'') AS origen, IFNULL(GROUP_CONCAT(DISTINCT(final.pais)),'') AS pais1, IFNULL(GROUP_CONCAT(DISTINCT(final.pais1)),'') AS pais1, IFNULL(GROUP_CONCAT(DISTINCT(final.pais2)),'') AS pais2, "
        strSQL &= "                         IFNULL(GROUP_CONCAT(DISTINCT(final.pais3)),'') AS pais3, IFNULL(GROUP_CONCAT(DISTINCT(final.pais4)),'') AS pais4, IFNULL(GROUP_CONCAT(DISTINCT(final.transportista)),'') AS transportista, IFNULL(GROUP_CONCAT(DISTINCT(final.cargador)),'') AS cargador "
        strSQL &= "                             FROM ( "
        strSQL &= "                                 SELECT DISTINCT(ccc.cat_clave), (CASE WHEN ccc.cat_clave = '01' THEN ccc.valores ELSE NULL END) AS numero, (CASE WHEN ccc.cat_clave = '02' THEN ccc.valores ELSE NULL END) AS fecha, (CASE WHEN ccc.cat_clave = '03' THEN ccc.valores ELSE NULL END) AS importador, (CASE WHEN ccc.cat_clave = '04' THEN ccc.valores ELSE NULL END) AS descarga, "
        strSQL &= "                                     (CASE WHEN ccc.cat_clave = '05' THEN ccc.valores ELSE NULL END) AS trasporte, (CASE WHEN ccc.cat_clave = '06' THEN ccc.valores ELSE NULL END) AS furgon, 	 (CASE WHEN ccc.cat_clave = '07' THEN ccc.valores ELSE NULL END) AS cabezal, "
        strSQL &= "                                         (CASE WHEN ccc.cat_clave = '08' THEN ccc.valores ELSE NULL END) AS piloto, 	(CASE WHEN ccc.cat_clave = '09' THEN ccc.valores ELSE NULL END) AS licencia, 	 (CASE WHEN ccc.cat_clave = '10' THEN ccc.valores ELSE NULL END) AS pedido, "
        strSQL &= "                                             (CASE WHEN ccc.cat_clave = '11' THEN ccc.valores ELSE NULL END) AS marchamo, (CASE WHEN ccc.cat_clave = '12' THEN ccc.valores ELSE NULL END) AS vendedor, 	(CASE WHEN ccc.cat_clave = '13' THEN ccc.valores ELSE NULL END) AS origen, "
        strSQL &= "                                                 (CASE WHEN ccc.cat_clave = '14' THEN ccc.valores ELSE NULL END) AS pais, 	(CASE WHEN ccc.cat_clave = '15' THEN ccc.valores ELSE NULL END) AS pais1, (CASE WHEN ccc.cat_clave = '16' THEN ccc.valores ELSE NULL END) AS pais2, 	(CASE WHEN ccc.cat_clave = '17' THEN ccc.valores ELSE NULL END) AS pais3, "
        strSQL &= "                                                     (CASE WHEN ccc.cat_clave = '18' THEN ccc.valores ELSE NULL END) AS pais4, (CASE WHEN ccc.cat_clave = '19' THEN ccc.valores ELSE NULL END) AS transportista, 	(CASE WHEN ccc.cat_clave = '20' THEN ccc.valores ELSE NULL END) AS cargador "
        strSQL &= "                                                         FROM ( "
        strSQL &= "                                                             SELECT xx.*, GROUP_CONCAT(DISTINCT(xx.valor) SEPARATOR '|') AS valores "
        strSQL &= "                                                                   FROM ( "
        strSQL &= "                                                                 SELECT a.cat_clave, a.cat_pid, a.cat_desc, b.ADoc_Sis_Emp, b.ADoc_Doc_Ano, b.ADoc_Doc_Cat, b.ADoc_Doc_Num, ( "
        strSQL &= "                                                              SELECT CASE WHEN a.cat_sist = 'Char' THEN CAST(COALESCE(c.ADoc_Dta_Chr, '{null}') AS CHAR) WHEN a.cat_sist = 'Text' THEN CAST(COALESCE(c.ADoc_Dta_Txt, '{null}') AS CHAR) "
        strSQL &= "                                                        WHEN a.cat_sist = 'Date' THEN CAST(COALESCE(c.ADoc_Dta_Fec, '{null}') AS CHAR) WHEN a.cat_sist = 'Weight' THEN CAST(COALESCE(c.ADoc_Dta_Wht, '{null}') AS CHAR) WHEN a.cat_sist = 'Cant' THEN CAST(COALESCE(c.ADoc_Dta_Num, '{null}') AS CHAR) "
        strSQL &= "                                                   WHEN a.cat_sist = 'Money' THEN CAST(COALESCE(c.ADoc_Dta_Mny, '{null}') AS CHAR) ELSE 'ERROR' END "
        strSQL &= "                                               FROM Dcmtos_ACC c "
        strSQL &= "                                         WHERE c.ADoc_Sis_Emp = b.ADoc_Sis_Emp AND c.ADoc_Doc_Cat = b.ADoc_Doc_Cat AND c.ADoc_Doc_Ano = b.ADoc_Doc_Ano AND c.ADoc_Doc_Num = b.ADoc_Doc_Num AND c.ADoc_Doc_Sub = b.ADoc_Doc_Sub AND c.ADoc_Doc_Lin = a.cat_clave) AS Valor "
        strSQL &= "                                    FROM Catalogos a "
        strSQL &= "                             INNER JOIN Dcmtos_ACC b ON b.ADoc_Sis_Emp = {empresa} AND b.ADoc_Doc_Ano = {anio} AND b.ADoc_Doc_Cat = 47 AND b.ADoc_Doc_Num = {num} AND b.ADoc_Doc_Sub = 'Prvs_Guia' AND b.ADoc_Doc_Lin = a.cat_clave "
        strSQL &= "                       WHERE a.cat_clase = b.ADoc_Doc_Sub) xx "
        strSQL &= "                GROUP BY xx.cat_clave "
        strSQL &= "         ORDER BY xx.cat_pid) ccc "
        strSQL &= " GROUP BY ccc.cat_clave)final "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", Num)
        BuscarRegistrosDcmtos_ACC(strSQL)

        strSQL2 = "         SELECT l1.Descripcion, l1.Cantidad, ROUND(l1.Precio,2) AS Precio, l1.Moneda, l1.Referencia,l1.Saldo, l1.Bultos, ROUND((l1.Saldo * l1.Precio),2) AS TotalL, l1.Fabricante, l1.Lote "
        strSQL2 &= "            FROM ("
        strSQL2 &= "                 SELECT d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET Precio, ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),2) Total, c.cat_clave Moneda, h.HDoc_DR1_Num Referencia, IFNULL((d.DDoc_Prd_QTY - SUM(t.DDoc_Prd_QTY)),d.DDoc_Prd_QTY) Saldo, IFNULL((b.BDoc_Box_QTY - SUM(bt.BDoc_Box_QTY)),b.BDoc_Box_QTY) Bultos, pr.pro_proveedor Fabricante, i.inv_prodlote Lote "
        strSQL2 &= "                    FROM Dcmtos_DTL d "
        strSQL2 &= "                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL2 &= "                            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
        strSQL2 &= "                                LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND dp.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND dp.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND dp.PDoc_Chi_Num = h.HDoc_Doc_Num AND dp.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND dp.PDoc_Par_Cat = 180 "
        strSQL2 &= "                                    LEFT JOIN Dcmtos_DTL_Pro p55 ON p55.PDoc_Sis_Emp = dp.PDoc_Sis_Emp AND p55.PDoc_Chi_Cat = dp.PDoc_Par_Cat AND p55.PDoc_Chi_Ano = dp.PDoc_Par_Ano AND p55.PDoc_Chi_Num = dp.PDoc_Par_Num AND p55.PDoc_Chi_Lin = dp.PDoc_Par_Lin AND p55.PDoc_Par_Cat = 55    "
        strSQL2 &= "                                        LEFT JOIN Dcmtos_DTL_Pro p127 ON p127.PDoc_Sis_Emp = p55.PDoc_Sis_Emp AND p127.PDoc_Chi_Cat = p55.PDoc_Par_Cat AND p127.PDoc_Chi_Ano = p55.PDoc_Par_Ano AND p127.PDoc_Chi_Num = p55.PDoc_Par_Num AND p127.PDoc_Chi_Lin = p55.PDoc_Par_Lin AND p127.PDoc_Par_Cat = 127 "
        strSQL2 &= "                                            LEFT JOIN Dcmtos_DTL l127 ON l127.DDoc_Sis_Emp = p127.PDoc_Sis_Emp AND l127.DDoc_Doc_Cat = p127.PDoc_Par_Cat AND l127.DDoc_Doc_Ano = p127.PDoc_Par_Ano AND l127.DDoc_Doc_Num = p127.PDoc_Par_Num AND l127.DDoc_Doc_Lin = p127.PDoc_Par_Lin"
        strSQL2 &= "                                                LEFT JOIN Dcmtos_DTL_Pro p38 ON p38.PDoc_Sis_Emp = p127.PDoc_Sis_Emp AND p38.PDoc_Chi_Cat = p127.PDoc_Par_Cat AND p38.PDoc_Chi_Ano = p127.PDoc_Par_Ano AND p38.PDoc_Chi_Num = p127.PDoc_Par_Num AND p38.PDoc_Chi_Lin = p127.PDoc_Par_Lin AND p38.PDoc_Par_Cat = 38 "
        strSQL2 &= "                                                    LEFT JOIN Dcmtos_DTL l38 ON l38.DDoc_Sis_Emp = p38.PDoc_Sis_Emp AND l38.DDoc_Doc_Cat = p38.PDoc_Par_Cat AND l38.DDoc_Doc_Ano = p38.PDoc_Par_Ano AND l38.DDoc_Doc_Num = p38.PDoc_Par_Num AND l38.DDoc_Doc_Lin = p38.PDoc_Par_Lin "
        strSQL2 &= "                                                        LEFT JOIN Proveedores pr ON pr.pro_sisemp = l38.DDoc_Sis_Emp AND pr.pro_codigo = l38.DDoc_RF1_Num "
        strSQL2 &= "                                                            LEFT JOIN Inventarios i ON i.inv_sisemp = l127.DDoc_Sis_Emp AND i.inv_numero = l127.DDoc_Prd_Cod "
        strSQL2 &= "                                                                LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = dp.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat = dp.PDoc_Par_Cat AND hh.HDoc_Doc_Ano = dp.PDoc_Par_Ano AND hh.HDoc_Doc_Num = dp.PDoc_Par_Num" ' hh es poliza de importacion 180"
        strSQL2 &= "                                                            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 48 "

        strSQL2 &= "                                                        LEFT JOIN Dcmtos_HDR hhh ON hhh.HDoc_Sis_Emp =p.PDoc_Sis_Emp AND hhh.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND hhh.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND hhh.HDoc_Doc_Num = p.PDoc_Chi_Num  AND (hhh.HDoc_Doc_Status = 1 OR hhh.HDoc_Doc_Status IS NULL) "
        strSQL2 &= "                                                    LEFT JOIN Dcmtos_DTL t ON t.DDoc_Sis_Emp =  hhh.HDoc_Sis_Emp AND t.DDoc_Doc_Cat = hhh.HDoc_Doc_Cat AND t.DDoc_Doc_Ano = hhh.HDoc_Doc_Ano  AND t.DDoc_Doc_Num = hhh.HDoc_Doc_Num  AND t.DDoc_Doc_Lin = p.PDoc_Chi_Lin "

        'strSQL2 &= "                                                        LEFT JOIN Dcmtos_DTL t ON t.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND t.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND t.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND t.DDoc_Doc_Num = p.PDoc_Chi_Num AND t.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        'strSQL2 &= "                                                    LEFT JOIN Dcmtos_HDR hhh ON hhh.HDoc_Sis_Emp = t.DDoc_Sis_Emp AND hhh.HDoc_Doc_Cat = t.DDoc_Doc_Cat AND hhh.HDoc_Doc_Ano = t.DDoc_Doc_Ano AND hhh.HDoc_Doc_Num = t.DDoc_Doc_Num "
        strSQL2 &= "                                                LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL2 &= "                                            LEFT JOIN Dcmtos_DTL_Box bt ON bt.BDoc_Sis_Emp = t.DDoc_Sis_Emp AND bt.BDoc_Doc_Cat = t.DDoc_Doc_Cat AND bt.BDoc_Doc_Ano = t.DDoc_Doc_Ano AND bt.BDoc_Doc_Num = t.DDoc_Doc_Num AND bt.BDoc_Doc_Lin = t.DDoc_Doc_Lin "
        strSQL2 &= "                                 WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} AND (hhh.HDoc_Doc_Status = 1 OR hhh.HDoc_Doc_Status IS NULL) "
        strSQL2 &= "                      GROUP BY d.DDoc_Doc_Lin)l1 "
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", anio)
        strSQL2 = Replace(strSQL2, "{num}", Numero)

        BuscarRegistrosDcmtos_DTL(strSQL2)

        repCR.Load("C:\XML\Dcmtos_ACCFCHN.xml")
        repCR.Load("C:\XML\Dcmtos_DTLFCHN.xml")
        Dim frm3 As New FrmFacturaHSM
        frm3.Reporte_A_VerHSM = repCR
        frm3.CrystalReportViewer1.ReportSource = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\Dcmtos_ACCFCHN.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\Dcmtos_DTLFCHN.xml")

    End Sub
    Private Function ValidarCertificado(ByVal Anio As Integer, ByVal Numero As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim conec As New MySqlConnection
        strSQL = " SELECT COUNT(*) Validar"
        strSQL &= "     FROM Dcmtos_DTL d  "
        strSQL &= "         LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Pro_DCat = d.DDoc_Doc_Cat AND h.HDoc_Pro_DAno = d.DDoc_Doc_Ano AND h.HDoc_Pro_DNum  = d.DDoc_Doc_Num  "
        strSQL &= "             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND h.HDoc_Sis_Emp IS NULL  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetInt32("Validar") = INT_CERO Then
                    logResultado = True
                End If
            Loop
        End If
        conec.Close()
        conec.Dispose()
        Return logResultado
    End Function
    Private Function ValidarOrigenes(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim LogValidar As Boolean = False

        strSQL = " SELECT d.DDoc_Doc_Cat Catalogo , d.DDoc_Doc_Ano Anio , d.DDoc_Doc_Num Numero , d.DDoc_Doc_Lin Linea, c.cat_desc Pais "
        strSQL &= "     FROM Dcmtos_DTL d  "
        strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "             LEFT JOIN Articulos a  ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                 LEFT JOIN Catalogos p ON p.cat_num = i.inv_lugarfab AND p.cat_clase ='Paises' "
        strSQL &= "                     LEFT JOIN Catalogos c ON c.cat_num = p.cat_sisemp AND c.cat_clase = 'Countries' "
        strSQL &= "                         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                Select Case REA.GetString("Pais")
                    Case "Asia"
                        LogValidar = True
                    Case "Mexico"
                        LogValidar = True
                    Case Else
                        If ValidarCertificado(REA.GetInt32("Anio"), REA.GetInt32("Numero")) = True Then
                            LogValidar = True
                        Else
                            LogValidar = False
                            Exit Function
                        End If
                End Select
                'If (REA.GetString("Pais") <> "Asia") Or (REA.GetString("Pais") <> "Mexico") Then
                '    If ValidarCertificado(REA.GetInt32("Anio"), REA.GetInt32("Numero")) = True Then
                '        LogValidar = True
                '    Else
                '        LogValidar = False
                '        Exit Function
                '    End If
                'Else
                '    LogValidar = True
                'End If
            Loop
        End If
        Return LogValidar
    End Function
    Private Function ValidacionBotonCertificado(ByVal Anio As Integer, ByVal Numero As Integer) As Boolean
        Dim logVerificar As Boolean = False
        If ValidarOrigenes(CInt(Anio), CInt(Numero)) = True Then
            logVerificar = True
        Else
            logVerificar = False
            Exit Function
        End If
        Return logVerificar
    End Function
    Private Sub btnGuardar_Click(sender As Object, e As EventArgs) Handles btnGuardar.Click

        GuardarCaso()
        Me.Hide()

    End Sub

    Private Sub btnImprimir_Click(sender As Object, e As EventArgs) Handles btnImprimir.Click

        Try
            Dim strLista As String = STR_VACIO
            Dim BW As New clsReportes
            'Dim PL As New clsReportes
            Me.Hide()
            GuardarCaso()
            If celdaDocumento.Text = STR_CPORTE2 Then
                If (Sesion.IdEmpresa = 11) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 14) Then
                    If ValidacionBotonCertificado(Año, Numero) = False Then
                        MsgBox("Can't print without certificate")
                        Exit Sub
                    End If
                End If
                BW.ReportWaybill2(Año, Numero)
            ElseIf celdaDocumento.Text = "Doc_CPckLst2" Then
                BW.ReportPackingList2(Año, Numero)
            ElseIf celdaDocumento.Text = "Doc_CDatos" Then
                BW.Rpt_ProformaContrato(Numero, Año, PedProforma)
            ElseIf celdaDocumento.Text = "Doc_RADevolucion" Then
                BW.ReportRA(Año, Numero)
            ElseIf celdaDocumento.Text = "Prvs_Guia" Then
                FacturaComercial(Año, Numero)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click

        Close()

    End Sub

    Private Sub botonDatosPoliza_Click(sender As Object, e As EventArgs) Handles botonDatosPoliza.Click

        'Carta de porte
        If celdaDocumento.Text = STR_CPORTE2 Then
            botonDatosPoliza.Visible = True
            CargarDeImportacion(intAño, intNumero)
        Else
            botonDatosPoliza.Visible = False
        End If
    End Sub

    Private Sub dgvSubDocumentosfrm_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSubDocumentosfrm.CellEndEdit
        dgvSubDocumentosfrm.EndEdit()
    End Sub

    Private Sub dgvSubDocumentosfrm_DoubleClick(sender As Object, e As EventArgs) Handles dgvSubDocumentosfrm.DoubleClick
        Dim respuesta As Integer
        Try
            If celdaDocumento.Text = STR_CPORTE2 Then
                Select Case dgvSubDocumentosfrm.CurrentCell.RowIndex

                    Case 6
                        'Try

                        '    Dim opt As New frmOpcion

                        '    opt.Titulo = "Option"
                        '    opt.Mensaje = "Select an option"
                        '    opt.Opciones = "Data Selection" & "|" & "Manual Entry"

                        '    If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                        '        Select Case opt.Seleccion

                        '            Case 0
                        '                respuesta = 0
                        '            Case 1
                        '                respuesta = 1

                        '        End Select
                        '    Else
                        '        Exit Sub
                        '    End If

                        'Catch ex As Exception
                        '    MsgBox(ex.ToString)
                        'End Try

                        'If respuesta = 0 Then

                        Dim frm As New frmSeleccionar
                        Dim strTabla As String = STR_VACIO
                        Dim strCondicion As String = STR_VACIO
                        strTabla = " Dcmtos_ACC a LEFT JOIN Dcmtos_ACC b ON b.ADoc_Sis_Emp = a.ADoc_Sis_Emp AND b.ADoc_Doc_Cat = a.ADoc_Doc_Cat AND b.ADoc_Doc_Ano = a.ADoc_Doc_Ano AND b.ADoc_Doc_Num = a.ADoc_Doc_Num AND b.ADoc_Doc_Sub = a.ADoc_Doc_Sub AND b.ADoc_Doc_Lin = '05' LEFT JOIN Dcmtos_ACC c ON c.ADoc_Sis_Emp = a.ADoc_Sis_Emp AND c.ADoc_Doc_Cat = a.ADoc_Doc_Cat AND c.ADoc_Doc_Ano = a.ADoc_Doc_Ano AND c.ADoc_Doc_Num = a.ADoc_Doc_Num AND c.ADoc_Doc_Sub = a.ADoc_Doc_Sub AND c.ADoc_Doc_Lin = '08'LEFT JOIN Dcmtos_ACC d ON d.ADoc_Sis_Emp = a.ADoc_Sis_Emp AND d.ADoc_Doc_Cat = a.ADoc_Doc_Cat AND d.ADoc_Doc_Ano = a.ADoc_Doc_Ano AND d.ADoc_Doc_Num = a.ADoc_Doc_Num AND d.ADoc_Doc_Sub = a.ADoc_Doc_Sub AND d.ADoc_Doc_Lin = '09'LEFT JOIN Dcmtos_ACC e ON e.ADoc_Sis_Emp = a.ADoc_Sis_Emp AND e.ADoc_Doc_Cat = a.ADoc_Doc_Cat AND e.ADoc_Doc_Ano = a.ADoc_Doc_Ano AND e.ADoc_Doc_Num = a.ADoc_Doc_Num AND e.ADoc_Doc_Sub = a.ADoc_Doc_Sub AND e.ADoc_Doc_Lin = '19'"
                        strCondicion = "a.ADoc_Sis_Emp = {empresa} AND a.ADoc_Doc_Cat = 36 AND a.ADoc_Doc_Sub = '{subdoc}' AND a.ADoc_Doc_Lin = '07'"
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strCondicion = Replace(strCondicion, "{subdoc}", strsub)
                        Try
                            frm.Titulo = "Pilot Data"
                            frm.FiltroText = "Enter the Pilot Name to filter"
                            frm.Campos = " DISTINCT(TRIM(a.ADoc_Dta_Chr)) Placa, c.ADoc_Dta_Txt Piloto, d.ADoc_Dta_Chr Licencia, e.ADoc_Dta_Txt Transportista"
                            frm.Tabla = strTabla
                            frm.Condicion = strCondicion
                            frm.Filtro = " a.ADoc_Dta_Chr"
                            frm.TipoOrdenamiento = ""

                            frm.ShowDialog(Me)
                            If frm.DialogResult = DialogResult.OK Then

                                Dim strFila As String = STR_VACIO
                                dgvSubDocumentosfrm.Rows(6).Cells("Contenido").Value = frm.LLave
                                dgvSubDocumentosfrm.Rows(7).Cells("Contenido").Value = frm.Dato
                                dgvSubDocumentosfrm.Rows(8).Cells("Contenido").Value = frm.Dato2
                                dgvSubDocumentosfrm.Rows(18).Cells("Contenido").Value = frm.Dato3
                            End If
                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try

                        'ElseIf respuesta = 1 Then

                        '    dgvSubDocumentosfrm.Rows(6).Cells("Contenido").ReadOnly = False
                        'End If

                End Select
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub dgvSubDocumentosfrm_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSubDocumentosfrm.CellContentClick

    End Sub

#End Region


End Class