﻿Public Class frmSSesion

   Dim cSesion As New clsSesion
    Const LOCAL = "CUR_LOC"
    Const EXTERNA = "CUR_EXT"

    ' Declarar Variables
    Dim ArrayNombre(100) As String
    Dim ArrayServer(100) As String
    Dim ArrayUsuario(100) As String
    Dim ArrayPass(100) As String
    Dim ArrayDb(100) As String
    Dim ArrayPuerto(100) As String
    Dim ArrayDefault(100) As String
    Dim strNombre As String = STR_VACIO

    Dim cCon As New ClsConexion

#Region "Funciones y Procedimientos"
    Private Sub CargarDivisas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = " select cc.cat_num  cod ,cc.cat_desc des , cc.cat_clave sim  , cc.cat_sist factor "
        strSQL &= "  from Catalogos c "
        strSQL &= "     left join Catalogos cc on cc.cat_num = c.cat_clave   "
        strSQL &= "  where c.cat_clase = 'Defaults' and c.cat_sist = '{tipo}'"
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Replace(strSQL, "{tipo}", LOCAL), CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                Divisa.Local.id = REA.GetInt32("cod")
                Divisa.Local.nombre = REA.GetString("des")
                Divisa.Local.simbolo = REA.GetString("sim")
                Divisa.Local.factor = CDbl(REA.GetString("factor"))

            End If
            REA = Nothing

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Replace(strSQL, "{tipo}", EXTERNA), CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                Divisa.Externa.id = REA.GetInt32("cod")
                Divisa.Externa.nombre = REA.GetString("des")
                Divisa.Externa.simbolo = REA.GetString("sim")
                Divisa.Externa.factor = CDbl(REA.GetString("factor"))
            End If
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarDivisasReportes()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.* "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_num= IFNULL(( "
            strSQL &= "             SELECT m.cat_pid "
            strSQL &= "                 FROM Catalogos m "
            strSQL &= "                     WHERE m.cat_clase='Empresa' AND m.cat_clave='Moneda' AND m.cat_sisemp={empresa}),{moneda}) "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{moneda}", Divisa.Externa.id)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Replace(strSQL, "{tipo}", LOCAL), CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                Divisa.Reporte.id = REA.GetInt32("cat_num")
                Divisa.Reporte.simbolo = REA.GetString("cat_ext")
                Divisa.Reporte.nombre = REA.GetString("cat_desc")
            End If
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Reset()
        CeldaClave.Text = ""
        CeldaUsuario.Text = ""
        CeldaUsuario.Focus()
    End Sub

#End Region

    Private Sub frmSSesion_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim intdef As Integer
        MyCnn.ObtenerCredencialesXml(ArrayNombre, ArrayServer, ArrayUsuario, ArrayPass, ArrayDb, ArrayPuerto, ArrayDefault)

        'If cSesion.debug = True Then
        '    If MsgBox("¿Modo de depuración (Local)?", MsgBoxStyle.YesNo) = vbYes Then
        '        strConexion = MyCnn.StringConexion("1")
        '        EtiquetaConexion.Text = Conexion.local.Modo
        '        strModo = Conexion.local.Modo
        '    Else
        '        For i As Integer = 0 To ArrayNombre.Count - 1
        '            If i = 0 Then
        '                strNombre = ArrayNombre(i)
        '            Else
        '                strNombre = strNombre & "|" & ArrayNombre(i)
        '            End If
        '            'strNombre &= ArrayNombre(i) & "|"
        '        Next
        '        For j As Integer = 0 To ArrayDefault.Count - 1
        '            If ArrayDefault(j) = INT_UNO Then
        '                intdef = j
        '            End If
        '        Next
        '    End If
        'Else
        For i As Integer = 0 To ArrayNombre.Count - 1
            If i = 0 Then
                strNombre = ArrayNombre(i)
            Else
                strNombre = strNombre & "|" & ArrayNombre(i)
            End If
        Next
        For j As Integer = 0 To ArrayDefault.Count - 1
                If ArrayDefault(j) = INT_UNO Then
                    intdef = j
                End If
            Next

            'End If

            ConstruirConexion(intdef)

        If MyCnn.ProbarConexiones() = True Then
            EtiquetaConexion.ForeColor = Color.Black
            cSesion.ComprobarActualizacion()
            cSesion.ComprobarConfiguracion()
        Else
            EtiquetaConexion.ForeColor = Color.Red
        End If
        Sistema.Version = My.Application.Info.Version.ToString
        Sesion.Estacion = cFunciones.ObtenerIPoEquipo(clsFunciones.IpEquipo.equipo)
        Sesion.IP = cFunciones.ObtenerIPoEquipo(clsFunciones.IpEquipo.ip)
        EtiquetaVersion.Text = Sistema.Version

    End Sub

    Private Sub ConstruirConexion(ByVal intdef As Integer)
        strConexion = "server={server};Port={port};database={db} ;uid={user};password={pass};"

        strConexion = Replace(strConexion, "{server}", ArrayServer(intdef))
        strConexion = Replace(strConexion, "{user}", ArrayUsuario(intdef))
        strConexion = Replace(strConexion, "{pass}", ArrayPass(intdef))
        strConexion = Replace(strConexion, "{db}", ArrayDb(intdef))
        strConexion = Replace(strConexion, "{port}", ArrayPuerto(intdef))
        EtiquetaConexion.Text = ArrayNombre(intdef)
        strModo = ArrayNombre(intdef)
        cCon.ConexionFavorita(ArrayNombre(intdef))
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles BotonAceptar.Click
        Dim prueba As Boolean = False
        ' PanelNewPass.Location = New System.Drawing.Point(120, 1)
        ' PanelNewPass.Dock = DockStyle.Fill
        If CeldaUsuario.Text.Length > 0 And CeldaClave.Text.Length > 0 Then
            'If cSesion.ComprobarUsuario(Trim(cFunciones.MyStr(CeldaUsuario.Text)), Trim(CeldaClave.Text)) = True Then
            If cSesion.ComprobarUsuario((cFunciones.MyStr(CeldaUsuario.Text)), (CeldaClave.Text)) = True Then
                Empresas.Visible = True
                Panel2.Visible = False
                Empresas.Dock = DockStyle.Fill
                cSesion.CargarEmpresas(CeldaUsuario.Text, Empresas)
                Empresas.Focus()
            Else
                Reset()
            End If
        Else
            MsgBox("Ingrese usuario o contraseña")
        End If

    End Sub

    Private Sub CeldaUsuario_KeyDown(sender As Object, e As KeyEventArgs) Handles CeldaUsuario.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send(vbTab)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub CeldaClave_KeyDown(sender As Object, e As KeyEventArgs) Handles CeldaClave.KeyDown
        Try
            If e.KeyCode = Keys.Enter Or e.KeyCode = Keys.Tab Then
                BotonAceptar.PerformClick()
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function BuscarBase() As String
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim ValorBase As String = STR_VACIO

        strSQL = "select cat_sist Sistema " & _
                 "FROM Catalogos " & _
                 "where cat_clase = 'Datos' and cat_clave = 'Contabilidad' "

        CON = New MySqlConnection(strConexion)
        CON.Open()

        COM = New MySqlCommand(strSQL, CON)
        ValorBase = COM.ExecuteScalar()

        Return ValorBase
    End Function

    Private Sub Empresas_DoubleClick(sender As Object, e As EventArgs) Handles Empresas.DoubleClick
        Dim itm As New ListViewItem
        Dim FechaPass As Date
        Dim intDias As Integer = 0

        If Empresas.SelectedItems.Count = 0 Then Exit Sub
        itm = Empresas.SelectedItems(0)
        Sesion.IdEmpresa = CInt(itm.SubItems(0).Text)
        Sesion.Empresa = itm.SubItems(1).Text
        Sesion.idGiro = CInt(itm.SubItems(2).Text)
        Sesion.BaseConta = cFunciones.ContaEmpresa
        Sesion.FechaSesion = Today
        cSesion.EscribirSesion()
        BaseConta = cFunciones.ContaEmpresa
        CargarDivisas()
        CargarDivisasReportes()
        FechaPass = VerificarFechaContraseña()
        Dim td As TimeSpan = DateTime.Now.Subtract(FechaPass)
        intDias = td.Days
        If intDias >= 90 Then
            MsgBox("Para Continuar, por favor cambie contraseña", vbInformation, "Info")
            Dim frm As Object = Nothing
            frm = New frmContraseña
            frm.key = "frmContrasena"
            frm.Show()
            Me.Hide()
            Exit Sub
        End If
        cSesion.ComprobarActualizacion()
        Fprincipal.Show()
        Me.Hide()
    End Sub

    Private Sub Empresas_KeyDown(sender As Object, e As KeyEventArgs) Handles Empresas.KeyDown
        If e.KeyCode = Keys.Enter Then
            Dim FechaPass As Date
            Dim intDias As Integer = 0
            Dim itm As New ListViewItem
            If Empresas.SelectedItems.Count = 0 Then Exit Sub
            itm = Empresas.SelectedItems(0)
            Sesion.IdEmpresa = CInt(itm.SubItems(0).Text)
            Sesion.Empresa = itm.SubItems(1).Text
            Sesion.idGiro =CInt(itm.SubItems(2).Text)
            Sesion.BaseConta = cFunciones.ContaEmpresa
            Sesion.FechaSesion = Today
            cSesion.EscribirSesion()
            CargarDivisas()
            CargarDivisasReportes()
            FechaPass = VerificarFechaContraseña()
            Dim td As TimeSpan = DateTime.Now.Subtract(FechaPass)
            intDias = td.Days
            If intDias >= 90 Then
                MsgBox("Para Continuar, por favor cambie contraseña", vbInformation, "Info")
                Dim frm As Object = Nothing
                frm = New frmContraseña
                frm.key = "frmContrasena"
                frm.Show()
                Me.Hide()
                Exit Sub
            End If
            cSesion.ComprobarActualizacion()
            Fprincipal.Show()
            Me.Hide()
            e.Handled = True
            e.SuppressKeyPress = True
        End If

    End Sub

    Private Function VerificarFechaContraseña() As Date
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim fechaPass As Date
        Try

            strSQL = " SELECT IFNULL(p.per_fecha,Now()) FROM Personal p "
            strSQL &= "    WHERE p.per_usuario = '{user}' AND (p.per_clave = '{clave}' OR p.per_clave = MD5('{clave}')) "

            strSQL = Replace(strSQL, "{user}", CeldaUsuario.Text)
            strSQL = Replace(strSQL, "{clave}", CeldaClave.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            fechaPass = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return fechaPass
    End Function

    Private Sub IconoConexion_DoubleClick(sender As Object, e As EventArgs) Handles IconoConexion.DoubleClick
        Dim frm As New frmOption
        Try
            frm.Titulo = "Opciones de conexión"
            frm.Mensaje = "Seleccione una conexión"
            frm.Opciones = strNombre
            frm.Panel1.AutoScroll = True
            frm.Panel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
            frm.Panel1.MaximumSize = New System.Drawing.Size(237, 250)
            frm.Panel1.Size = New System.Drawing.Size(237, 250)

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                ConstruirConexion(frm.Seleccion)
            End If

            If MyCnn.ProbarConexiones() = True Then
                EtiquetaConexion.ForeColor = Color.Black
                cSesion.ComprobarActualizacion()
            Else
                EtiquetaConexion.ForeColor = Color.Red
                MsgBox("Imposible conectar con el servidor", MsgBoxStyle.Critical)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Empresas_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Empresas.SelectedIndexChanged
        Dim itm As New ListViewItem
        If Empresas.SelectedItems.Count = 0 Then Exit Sub
        itm = Empresas.SelectedItems(0)

        CuadroLogo.Image = ImageList1.Images(itm.SubItems(0).Text)
        CuadroLogo.SizeMode = PictureBoxSizeMode.StretchImage
    End Sub

    Private Sub IconoConexion_Click(sender As Object, e As EventArgs) Handles IconoConexion.Click

    End Sub
End Class
