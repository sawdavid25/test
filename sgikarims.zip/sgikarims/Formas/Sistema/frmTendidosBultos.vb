﻿Public Class frmTendidosBultos

#Region "Funciones y Procedimientos"

    Private Function SQLBultos() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " Select db.BDoc_Box_Hsm Correlative,db.BDoc_Box_Cod Mark, h.HDoc_DR1_Num Reference, d.DDoc_Prd_Des Description, db.BDoc_Box_LB PesoBulto, d.DDoc_Prd_NET Price, c.cat_clave Measure, d.DDoc_Doc_Num Number, d.DDoc_Doc_Ano YEAR, d.DDoc_Doc_Lin Line, db.BDoc_Box_Lin LineaBulto, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_UM Umedida, db.BDoc_Box_Ctg Categoria , concat( d.DDoc_Doc_Ano ,d.DDoc_Doc_Num, d.DDoc_Doc_Lin, db.BDoc_Box_Lin ) llave, CONCAT(d.DDoc_Doc_Ano,d.DDoc_Doc_Num, d.DDoc_Doc_Lin) llave2, db.BDoc_Box_LBExt PesoBruto, (db.BDoc_Box_LBExt - db.BDoc_Box_LB)Tara "
        strSQL &= " From Dcmtos_DTL d " &
                             " LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND db.BDoc_Doc_Num = d.DDoc_Doc_Num AND db.BDoc_Doc_Lin = d.DDoc_Doc_Lin " &
                             " LEFT JOIN Dcmtos_DTL_Box_Pro bp ON bp.BPDoc_Sis_Emp = db.BDoc_Sis_Emp AND bp.BPDoc_Par_Num = db.BDoc_Doc_Num AND bp.BPDoc_Par_Cat = db.BDoc_Doc_Cat AND bp.BPDoc_Par_Ano = db.BDoc_Doc_Ano AND bp.BPDoc_Par_Lin = db.BDoc_Doc_Lin AND bp.BPDoc_Box_Lin = db.BDoc_Box_Lin AND bp.BPDoc_Chi_Cat= 952 " &
                             " LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND cat_clase = 'Medidas' " &
                             "  LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = db.BDoc_Sis_Emp AND h.HDoc_Doc_Cat = db.BDoc_Doc_Cat AND h.HDoc_Doc_Ano = db.BDoc_Doc_Ano AND h.HDoc_Doc_Num = db.BDoc_Doc_Num " &
                             " LEFT JOIN Inventarios i ON i.inv_sisemp = h.HDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod " &
                              " LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo" &
                              " LEFT JOIN Materiales m ON m.det_sisemp = a.art_sisemp AND m.det_articulo = a.art_codigo "

        strSQL &= " Where d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Num = db.BDoc_Doc_Num AND h.HDoc_Ant_Com =0 AND bp.BPDoc_Par_Num IS NULL and db.BDoc_Box_Hsm = {correlativo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Try

            strSQL = Replace(strSQL, "{correlativo}", CInt(celdaCorrelativo.Text))
        Catch ex As Exception
            MsgBox("El correlativo es un dato numerico")
            celdaCorrelativo.Text = 0
            strSQL = Replace(strSQL, "{correlativo}", NO_FILA)
        End Try
        Return strSQL
    End Function

    Private Sub CargarPacas()
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim logExiste As Boolean = False

        Try
            dgPacas.Rows.Clear()
            strSQl = SQLBultos()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    For i As Integer = INT_CERO To dgPacasSeleccionadas.Rows.Count - 1
                        If REA.GetString("llave") = dgPacasSeleccionadas.Rows(i).Cells("colLlaveS").Value.ToString Then
                            logExiste = True
                        End If
                    Next
                    If Not logExiste Then
                        strFila &= REA.GetInt32("YEAR") & "|"
                        strFila &= REA.GetInt32("Number") & "|"
                        strFila &= REA.GetInt32("Line") & "|"
                        strFila &= REA.GetInt32("LineaBulto") & "|"
                        strFila &= REA.GetString("Correlative") & "|"
                        strFila &= REA.GetString("Mark") & "|"
                        strFila &= REA.GetString("Reference") & "|"
                        strFila &= REA.GetString("Description") & "|"
                        strFila &= REA.GetDouble("PesoBulto").ToString & "|"
                        strFila &= REA.GetDouble("Tara").ToString & "|" 'Tara 
                        strFila &= REA.GetDouble("PesoBruto").ToString & "|" ' peso bruto
                        strFila &= REA.GetDouble("Price").ToString & "|"
                        strFila &= REA.GetString("Measure") & "|"
                        strFila &= REA.GetString("Categoria") & "|"
                        strFila &= REA.GetString("llave") & "|"
                        strFila &= REA.GetString("llave2")

                        cFunciones.AgregarFila(dgPacas, strFila)

                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SeleccionarPaca()
        Dim strFila As String = STR_VACIO
        Try
            strFila &= dgPacas.CurrentRow.Cells("colAnoP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colNumeroP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colLineaP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colLineaBultoP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colCorrelativoP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colMarcaP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colReferenciaP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colDescripcionP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colPesoNetoP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colTaraP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colPesoBrutoP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colPrecioP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colMedidaP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colCategoriaP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colLlaveP").Value & "|"
            strFila &= dgPacas.CurrentRow.Cells("colLLave2P").Value
            cFunciones.AgregarFila(dgPacasSeleccionadas, strFila)

            dgPacas.CurrentRow.Visible = False
            celdaCorrelativo.Focus()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularTotales()
        Dim dblTotalNeto As Double = INT_CERO
        Dim dblTotalTara As Double = INT_CERO
        Dim dblTotalBrtuo As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Try
            For i As Integer = 0 To dgPacasSeleccionadas.Rows.Count - 1
                dblTotalNeto = dblTotalNeto + CDbl(dgPacasSeleccionadas.Rows(i).Cells("colPesoNetoS").Value)
                dblTotalBrtuo = dblTotalBrtuo + CDbl(dgPacasSeleccionadas.Rows(i).Cells("colPesoBrutoS").Value)
                dblTotalTara = dblTotalTara + CDbl(dgPacasSeleccionadas.Rows(i).Cells("colTaraS").Value)
                dblTotal = dblTotal + (CDbl(dgPacasSeleccionadas.Rows(i).Cells("colPesoNetoS").Value) * CDbl(dgPacasSeleccionadas.Rows(i).Cells("colPrecioS").Value))

            Next
            celdaPesoNeto.Text = dblTotalNeto.ToString(FORMATO_MONEDA)
            celdaPesoBruto.Text = dblTotalBrtuo.ToString(FORMATO_MONEDA)
            celdaTara.Text = dblTotalTara.ToString(FORMATO_MONEDA)
            celdaBultos.Text = dgPacasSeleccionadas.Rows.Count
            celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Eventos"

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        CargarPacas()
    End Sub

    Private Sub dgPacas_DoubleClick(sender As Object, e As EventArgs) Handles dgPacas.DoubleClick
        SeleccionarPaca()
        CalcularTotales()
    End Sub

    Private Sub dgPacasSeleccionadas_DoubleClick(sender As Object, e As EventArgs) Handles dgPacasSeleccionadas.DoubleClick
        dgPacasSeleccionadas.Rows.Remove(dgPacasSeleccionadas.CurrentRow)
        CalcularTotales()

    End Sub

    Private Sub celdaCorrelativo_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaCorrelativo.KeyDown
        If e.KeyCode = Keys.Enter Then
            CargarPacas()
            dgPacas.Focus()
            e.Handled = True
            e.SuppressKeyPress = True
        End If

    End Sub

    Private Sub dgPacas_KeyDown(sender As Object, e As KeyEventArgs) Handles dgPacas.KeyDown
        If e.KeyCode = Keys.Enter Then
            SeleccionarPaca()
            CalcularTotales()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

#End Region

End Class