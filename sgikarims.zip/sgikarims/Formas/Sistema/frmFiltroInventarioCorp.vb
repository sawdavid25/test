﻿Public Class frmFiltroInventarioCorp
    Private _estado As String = STR_VACIO
    Private _hilo As String = STR_VACIO
    Private _cantidadinicio As Double = NO_FILA
    Private _cantidadfin As Double = NO_FILA

    Public ReadOnly Property Estado As String
        Get
            Return _estado
        End Get
    End Property

    Public ReadOnly Property Hilo As String
        Get
            Return _hilo
        End Get
    End Property

    Public ReadOnly Property CantidadInicio As Double
        Get
            Return _cantidadinicio
        End Get
    End Property

    Public ReadOnly Property CantidadFin As Double
        Get
            Return _cantidadfin
        End Get
    End Property

    Private Sub checkEstado_CheckedChanged(sender As Object, e As EventArgs) Handles checkEstado.CheckedChanged
        If checkEstado.Checked = True Then
            botonEstado.Enabled = True
            celdaEstado.BackColor = Color.SkyBlue
            celdaEstado.Text = STR_VACIO
        Else
            botonEstado.Enabled = False
            celdaEstado.BackColor = Color.LightGray
            celdaEstado.Text = "ALL "
        End If
    End Sub

    Private Sub checkYarn_CheckedChanged(sender As Object, e As EventArgs) Handles checkYarn.CheckedChanged
        If checkYarn.Checked = True Then
            botonHilo.Enabled = True
            celdaHilo.BackColor = Color.SkyBlue
            celdaHilo.Text = STR_VACIO
        Else
            botonHilo.Enabled = False
            celdaHilo.BackColor = Color.LightGray
            celdaHilo.Text = "ALL"
        End If
    End Sub

    Private Sub checkSaldo_CheckedChanged(sender As Object, e As EventArgs) Handles checkSaldo.CheckedChanged
        If checkSaldo.Checked = True Then
            celdaSaldoFinal.ReadOnly = False
            celdaSaldoInicial.ReadOnly = False
            celdaSaldoInicial.BackColor = Color.SkyBlue
            celdaSaldoFinal.BackColor = Color.SkyBlue
        Else
            celdaSaldoFinal.ReadOnly = True
            celdaSaldoInicial.ReadOnly = True
            celdaSaldoInicial.BackColor = Color.LightGray
            celdaSaldoFinal.BackColor = Color.LightGray
        End If
    End Sub

    Private Sub celdaSaldoInicial_TextChanged(sender As Object, e As EventArgs) Handles celdaSaldoInicial.Validated
        If cFunciones.ValidarCampoNumerico(celdaSaldoInicial) = False Then
            celdaSaldoInicial.Text = INT_UNO
        End If
    End Sub

    Private Sub celdaSaldoFinal_TextChanged(sender As Object, e As EventArgs) Handles celdaSaldoFinal.Validated
        If cFunciones.ValidarCampoNumerico(celdaSaldoFinal) = False Then
            celdaSaldoFinal.Text = INT_UNO
        End If
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        If checkEstado.Checked = True Then
            _estado = celdaEstado.Text
        End If
        If checkYarn.Checked = True Then
            _hilo = celdaHilo.Text
        End If
        If checkSaldo.Checked = True Then
            _cantidadinicio = celdaSaldoInicial.Text
            _cantidadfin = celdaSaldoFinal.Text
        End If
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub botonEstado_Click(sender As Object, e As EventArgs) Handles botonEstado.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select any Status "
            frm.Filtro = " i.Estado "
            frm.FiltroText = " Select a Status "

            frm.Campos = " DISTINCT if(i.Estado ='GOOD', 'GOOD','BAD') Status "
            frm.Tabla = " YarnDivision.Inventario i "
            frm.Condicion = " 1=1 "
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaEstado.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonHilo_Click(sender As Object, e As EventArgs) Handles botonHilo.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Yarn Count "
            frm.Filtro = " i.Descripcion "
            frm.FiltroText = " Select a Yarn Count "

            frm.Campos = " DISTINCT i.Descripcion Yarn_Count  "
            frm.Tabla = " YarnDivision.Inventario i "
            frm.Condicion = " 1=1 "
            frm.Limite = 20
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaHilo.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class