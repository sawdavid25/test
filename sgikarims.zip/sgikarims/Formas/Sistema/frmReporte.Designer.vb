﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporte
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReporte))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonExportarWord = New System.Windows.Forms.Button()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonExportar = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonPrevia = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonExportarWord)
        Me.Panel1.Controls.Add(Me.botonCerrar)
        Me.Panel1.Controls.Add(Me.botonExportar)
        Me.Panel1.Controls.Add(Me.botonGuardar)
        Me.Panel1.Controls.Add(Me.botonPrevia)
        Me.Panel1.Controls.Add(Me.botonImprimir)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(591, 64)
        Me.Panel1.TabIndex = 0
        '
        'botonExportarWord
        '
        Me.botonExportarWord.Image = Global.KARIMs_SGI.My.Resources.Resources.word1
        Me.botonExportarWord.Location = New System.Drawing.Point(294, 12)
        Me.botonExportarWord.Name = "botonExportarWord"
        Me.botonExportarWord.Size = New System.Drawing.Size(71, 46)
        Me.botonExportarWord.TabIndex = 2
        Me.botonExportarWord.Text = "Export"
        Me.botonExportarWord.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportarWord.UseVisualStyleBackColor = True
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(522, 12)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(57, 46)
        Me.botonCerrar.TabIndex = 1
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonExportar
        '
        Me.botonExportar.Image = Global.KARIMs_SGI.My.Resources.Resources.doc_excel
        Me.botonExportar.Location = New System.Drawing.Point(223, 12)
        Me.botonExportar.Name = "botonExportar"
        Me.botonExportar.Size = New System.Drawing.Size(71, 46)
        Me.botonExportar.TabIndex = 0
        Me.botonExportar.Text = "Export"
        Me.botonExportar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportar.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.botonGuardar.Location = New System.Drawing.Point(152, 12)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(71, 46)
        Me.botonGuardar.TabIndex = 0
        Me.botonGuardar.Text = "Save"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonPrevia
        '
        Me.botonPrevia.Image = Global.KARIMs_SGI.My.Resources.Resources.zoom
        Me.botonPrevia.Location = New System.Drawing.Point(82, 12)
        Me.botonPrevia.Name = "botonPrevia"
        Me.botonPrevia.Size = New System.Drawing.Size(71, 46)
        Me.botonPrevia.TabIndex = 0
        Me.botonPrevia.Text = "Preview"
        Me.botonPrevia.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevia.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(12, 12)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(71, 46)
        Me.botonImprimir.TabIndex = 0
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 64)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(591, 242)
        Me.WebBrowser1.TabIndex = 1
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'frmReporte
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(591, 306)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmReporte"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmReporte"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents botonExportar As System.Windows.Forms.Button
    Friend WithEvents botonGuardar As System.Windows.Forms.Button
    Friend WithEvents botonPrevia As System.Windows.Forms.Button
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents botonExportarWord As Button
End Class
