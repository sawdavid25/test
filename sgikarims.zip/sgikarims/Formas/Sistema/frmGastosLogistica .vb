﻿Public Class frmGastosLogistica

#Region "Variable y Constantes"

    Dim intcatalogo As Integer
    Dim intano As Integer
    Dim intnumero As Integer
    Dim intlinea As Integer

    Dim intref_cat As Integer
    Dim intref_ano As Integer
    Dim intref_num As Integer
    Dim intref_lin As Integer
#End Region

#Region "Propiedades"

    Public WriteOnly Property Catalogo As String
        Set(value As String)
            intcatalogo = value
        End Set
    End Property

    Public WriteOnly Property Ano As String
        Set(value As String)
            intano = value
        End Set
    End Property

    Public WriteOnly Property Numero As String
        Set(value As String)
            intnumero = value
        End Set
    End Property

    Public WriteOnly Property linea As String
        Set(value As String)
            intlinea = value
        End Set
    End Property

    Public WriteOnly Property Ref_Catalogo As String
        Set(value As String)
            intref_cat = value
        End Set
    End Property

    Public WriteOnly Property Ref_Ano As String
        Set(value As String)
            intref_ano = value
        End Set
    End Property

    Public WriteOnly Property Ref_Numero As String
        Set(value As String)
            intref_num = value
        End Set
    End Property

    Public WriteOnly Property Ref_linea As String
        Set(value As String)
            intref_lin = value
        End Set
    End Property
#End Region

#Region "Funciones y Procedimientos"

    Private Sub Sumar()
        Dim k As Integer = 0
        Dim suma As Double = 0

        For k = 0 To dgGastos.Rows.Count - 1
            If dgGastos.Rows(k).Cells("colMarca").Value = 2 Then
            Else
                suma = suma + dgGastos.Rows(k).Cells("Monto").Value  ' total
            End If

        Next
        celdaSuma.Text = suma.ToString(FORMATO_MONEDA)

    End Sub

    Private Sub Guardar()
        Dim tg As New Tablas.TGASTOS_IMP
        Try

            For i As Integer = 0 To dgGastos.Rows.Count - 1
                tg.GAS_EMPRESA = Sesion.IdEmpresa

                tg.GAS_CATALOGO = dgGastos.Rows(i).Cells("cat_i").Value
                tg.GAS_ANO = dgGastos.Rows(i).Cells("ano_i").Value
                tg.GAS_NUMERO = dgGastos.Rows(i).Cells("num_i").Value
                tg.GAS_LINEA = dgGastos.Rows(i).Cells("lin_i").Value

                tg.GAS_IDAGASTO = dgGastos.Rows(i).Cells("idGasto").Value
                tg.GAS_MONTO = dgGastos.Rows(i).Cells("Monto").Value

                tg.GAS_REFCAT = dgGastos.Rows(i).Cells("cat_x").Value
                tg.GAS_REFANO = dgGastos.Rows(i).Cells("ano_x").Value
                tg.GAS_REFNUM = dgGastos.Rows(i).Cells("num_x").Value
                tg.GAS_REFLIN = dgGastos.Rows(i).Cells("lin_x").Value

                tg.CONEXION = strConexion

                Select Case dgGastos.Rows(i).Cells("colMarca").Value
                    Case INT_CERO
                        If tg.PINSERT = False Then
                            MsgBox(tg.MERROR.ToString)
                        End If
                    Case INT_UNO
                        If tg.PUPDATE = False Then
                            MsgBox(tg.MERROR.ToString)
                        End If
                    Case 2
                        If tg.PDELETE = False Then
                            MsgBox(tg.MERROR.ToString)
                        End If
                End Select

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDatos()
        Dim strSql As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSql = " SELECT g.gas_catalogo catalogo , g.gas_ano ano , g.gas_numero numero , g.gas_linea linea , g.gas_idagasto idgasto, c.cat_desc gasto, g.gas_monto monto , g.gas_refcat refcat , g.gas_refano refano, g.gas_refnum refnum , g.gas_reflin reflin
                         FROM Gastos_Imp g
	                        LEFT JOIN Catalogos c ON c.cat_num = g.gas_idagasto 
                        WHERE g.gas_empresa = {empresa} AND g.gas_catalogo = {catalogo} AND g.gas_ano = {ano} AND g.gas_numero = {numero} AND g.gas_linea = {linea} "

            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{catalogo}", intcatalogo)
            strSql = strSql.Replace("{ano}", intano)
            strSql = strSql.Replace("{numero}", intnumero)
            strSql = strSql.Replace("{linea}", intlinea)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("catalogo") & "|" ' CATALOGO
                    strFila &= REA.GetInt32("ano") & "|"   ' ANO
                    strFila &= REA.GetInt32("numero") & "|"    ' NUMERO
                    strFila &= REA.GetInt32("linea") & "|"   ' LINEA

                    strFila &= REA.GetInt32("idgasto") & "|"  ' ID GASTO
                    strFila &= REA.GetString("gasto") & "|"   ' GASTO
                    strFila &= REA.GetDouble("monto") & "|"          ' MONTO  

                    strFila &= REA.GetInt32("refcat") & "|" ' REF CAT
                    strFila &= REA.GetInt32("refano") & "|" ' REF ANO
                    strFila &= REA.GetInt32("refnum") & "|" ' REF NUM
                    strFila &= REA.GetInt32("reflin") & "|" ' REF LIN
                    strFila &= "1"

                    cFunciones.AgregarFila(dgGastos, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Try
            frm.Titulo = "Select a Expense"
            frm.FiltroText = " Filter by expense "


            frm.Campos = " c.cat_num Id, c.cat_desc Expense  "
            frm.Tabla = " Catalogos c "
            frm.Condicion = "  c.cat_clase ='GastosI' "
            frm.Filtro = "  c.cat_desc "

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                strFila = celdaCat.Text & "|"
                strFila &= celdaAno.Text & "|"
                strFila &= celdaNum.Text & "|"
                strFila &= celdaLin.Text & "|"
                strFila &= frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= "0.00|"
                strFila &= celdaCat_ref.Text & "|"
                strFila &= celdaAno_ref.Text & "|"
                strFila &= celdaNum_ref.Text & "|"
                strFila &= celdaLin_ref.Text & "|"
                strFila &= "0"

                cFunciones.AgregarFila(dgGastos, strFila)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        dgGastos.CurrentRow.Cells("colMarca").Value = 2
        dgGastos.CurrentRow.Visible = False
        Sumar()

    End Sub

    Private Sub dgGastos_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgGastos.CellEndEdit
        Dim dbltemp As Double
        Try
            dbltemp = CDbl(dgGastos.CurrentRow.Cells("Monto").Value)
        Catch ex As Exception
            dgGastos.CurrentRow.Cells("Monto").Value = 0
        End Try
        Sumar()

    End Sub

    Private Sub frmGastosLogistica_Load(sender As Object, e As EventArgs) Handles Me.Load
        celdaCat.Text = intcatalogo
        celdaAno.Text = intano
        celdaNum.Text = intnumero
        celdaLin.Text = intlinea

        celdaCat_ref.Text = intref_cat
        celdaAno_ref.Text = intref_ano
        celdaNum_ref.Text = intref_num
        celdaLin_ref.Text = intref_lin

        CargarDatos()
        Sumar()
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Guardar()
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub
End Class