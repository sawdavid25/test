﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFacturasRef_Aux_
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelInfo = New System.Windows.Forms.Panel()
        Me.etiquetaInfo = New System.Windows.Forms.Label()
        Me.panelReservacion = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgReservacion = New System.Windows.Forms.DataGridView()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.celdaReserva = New System.Windows.Forms.TextBox()
        Me.etiquetaTitulo = New System.Windows.Forms.Label()
        Me.celdaInfo = New System.Windows.Forms.TextBox()
        Me.paenlInfoFinal = New System.Windows.Forms.Panel()
        Me.PanelTotales = New System.Windows.Forms.Panel()
        Me.gbTotales = New System.Windows.Forms.GroupBox()
        Me.celdaCantidadDescar = New System.Windows.Forms.TextBox()
        Me.celdaDisponibleLBS = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.etiquetaDisponibleLbs = New System.Windows.Forms.Label()
        Me.celdaInfoFin = New System.Windows.Forms.TextBox()
        Me.etiquetaRequerimientos = New System.Windows.Forms.Label()
        Me.celdaCancel = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.celdaInfoFinal = New System.Windows.Forms.TextBox()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisponible = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReserva = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFila = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelInfo.SuspendLayout()
        Me.panelReservacion.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgReservacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.paenlInfoFinal.SuspendLayout()
        Me.PanelTotales.SuspendLayout()
        Me.gbTotales.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 0)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1116, 217)
        Me.panelLista.TabIndex = 0
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.BackgroundColor = System.Drawing.Color.LightSteelBlue
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colNumero, Me.colFecha, Me.colPoliza, Me.colReferencia, Me.colLinea, Me.colCodigo, Me.colDisponible, Me.colMedida, Me.colUnidad, Me.colDescargo, Me.colNota1, Me.colNota2, Me.colReserva, Me.colDetalle, Me.colPF, Me.colFila})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.GridColor = System.Drawing.SystemColors.Control
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1116, 217)
        Me.dgLista.TabIndex = 0
        '
        'panelInfo
        '
        Me.panelInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelInfo.BackColor = System.Drawing.SystemColors.Info
        Me.panelInfo.Controls.Add(Me.etiquetaInfo)
        Me.panelInfo.Controls.Add(Me.panelReservacion)
        Me.panelInfo.Controls.Add(Me.etiquetaTitulo)
        Me.panelInfo.Controls.Add(Me.celdaInfo)
        Me.panelInfo.Location = New System.Drawing.Point(0, 224)
        Me.panelInfo.Margin = New System.Windows.Forms.Padding(4)
        Me.panelInfo.Name = "panelInfo"
        Me.panelInfo.Size = New System.Drawing.Size(1116, 208)
        Me.panelInfo.TabIndex = 1
        '
        'etiquetaInfo
        '
        Me.etiquetaInfo.AutoSize = True
        Me.etiquetaInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaInfo.ForeColor = System.Drawing.Color.MidnightBlue
        Me.etiquetaInfo.Location = New System.Drawing.Point(16, 48)
        Me.etiquetaInfo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaInfo.Name = "etiquetaInfo"
        Me.etiquetaInfo.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaInfo.TabIndex = 3
        Me.etiquetaInfo.Text = "info()"
        '
        'panelReservacion
        '
        Me.panelReservacion.Controls.Add(Me.Panel1)
        Me.panelReservacion.Controls.Add(Me.celdaReserva)
        Me.panelReservacion.Location = New System.Drawing.Point(624, 70)
        Me.panelReservacion.Margin = New System.Windows.Forms.Padding(4)
        Me.panelReservacion.Name = "panelReservacion"
        Me.panelReservacion.Size = New System.Drawing.Size(465, 123)
        Me.panelReservacion.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dgReservacion)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 38)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(465, 85)
        Me.Panel1.TabIndex = 2
        '
        'dgReservacion
        '
        Me.dgReservacion.AllowUserToAddRows = False
        Me.dgReservacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgReservacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCantidad, Me.colCliente, Me.colNota})
        Me.dgReservacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgReservacion.Location = New System.Drawing.Point(0, 0)
        Me.dgReservacion.Margin = New System.Windows.Forms.Padding(4)
        Me.dgReservacion.Name = "dgReservacion"
        Me.dgReservacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgReservacion.Size = New System.Drawing.Size(465, 85)
        Me.dgReservacion.TabIndex = 0
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Amount"
        Me.colCantidad.Name = "colCantidad"
        '
        'colCliente
        '
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        '
        'colNota
        '
        Me.colNota.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNota.HeaderText = "Note"
        Me.colNota.Name = "colNota"
        Me.colNota.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colNota.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'celdaReserva
        '
        Me.celdaReserva.BackColor = System.Drawing.Color.Red
        Me.celdaReserva.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaReserva.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaReserva.ForeColor = System.Drawing.Color.AliceBlue
        Me.celdaReserva.Location = New System.Drawing.Point(0, 0)
        Me.celdaReserva.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaReserva.Multiline = True
        Me.celdaReserva.Name = "celdaReserva"
        Me.celdaReserva.Size = New System.Drawing.Size(465, 42)
        Me.celdaReserva.TabIndex = 1
        Me.celdaReserva.Text = "Reservation"
        '
        'etiquetaTitulo
        '
        Me.etiquetaTitulo.AutoSize = True
        Me.etiquetaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTitulo.ForeColor = System.Drawing.Color.MediumBlue
        Me.etiquetaTitulo.Location = New System.Drawing.Point(11, 21)
        Me.etiquetaTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTitulo.Name = "etiquetaTitulo"
        Me.etiquetaTitulo.Size = New System.Drawing.Size(166, 18)
        Me.etiquetaTitulo.TabIndex = 0
        Me.etiquetaTitulo.Text = "Inventory Information"
        '
        'celdaInfo
        '
        Me.celdaInfo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.celdaInfo.Location = New System.Drawing.Point(0, 0)
        Me.celdaInfo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfo.Multiline = True
        Me.celdaInfo.Name = "celdaInfo"
        Me.celdaInfo.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.celdaInfo.Size = New System.Drawing.Size(1116, 208)
        Me.celdaInfo.TabIndex = 1
        '
        'paenlInfoFinal
        '
        Me.paenlInfoFinal.Controls.Add(Me.PanelTotales)
        Me.paenlInfoFinal.Controls.Add(Me.celdaInfoFin)
        Me.paenlInfoFinal.Controls.Add(Me.etiquetaRequerimientos)
        Me.paenlInfoFinal.Controls.Add(Me.celdaCancel)
        Me.paenlInfoFinal.Controls.Add(Me.botonAceptar)
        Me.paenlInfoFinal.Controls.Add(Me.celdaInfoFinal)
        Me.paenlInfoFinal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.paenlInfoFinal.Location = New System.Drawing.Point(0, 440)
        Me.paenlInfoFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.paenlInfoFinal.Name = "paenlInfoFinal"
        Me.paenlInfoFinal.Size = New System.Drawing.Size(1116, 134)
        Me.paenlInfoFinal.TabIndex = 2
        '
        'PanelTotales
        '
        Me.PanelTotales.Controls.Add(Me.gbTotales)
        Me.PanelTotales.Location = New System.Drawing.Point(15, 7)
        Me.PanelTotales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PanelTotales.Name = "PanelTotales"
        Me.PanelTotales.Size = New System.Drawing.Size(317, 114)
        Me.PanelTotales.TabIndex = 6
        '
        'gbTotales
        '
        Me.gbTotales.Controls.Add(Me.celdaCantidadDescar)
        Me.gbTotales.Controls.Add(Me.celdaDisponibleLBS)
        Me.gbTotales.Controls.Add(Me.Label1)
        Me.gbTotales.Controls.Add(Me.etiquetaDisponibleLbs)
        Me.gbTotales.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbTotales.Location = New System.Drawing.Point(0, 0)
        Me.gbTotales.Margin = New System.Windows.Forms.Padding(4)
        Me.gbTotales.Name = "gbTotales"
        Me.gbTotales.Padding = New System.Windows.Forms.Padding(4)
        Me.gbTotales.Size = New System.Drawing.Size(317, 114)
        Me.gbTotales.TabIndex = 0
        Me.gbTotales.TabStop = False
        Me.gbTotales.Text = "Totals"
        '
        'celdaCantidadDescar
        '
        Me.celdaCantidadDescar.Location = New System.Drawing.Point(165, 66)
        Me.celdaCantidadDescar.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCantidadDescar.Name = "celdaCantidadDescar"
        Me.celdaCantidadDescar.Size = New System.Drawing.Size(131, 22)
        Me.celdaCantidadDescar.TabIndex = 3
        Me.celdaCantidadDescar.Text = "0.00"
        Me.celdaCantidadDescar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaDisponibleLBS
        '
        Me.celdaDisponibleLBS.Location = New System.Drawing.Point(165, 23)
        Me.celdaDisponibleLBS.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDisponibleLBS.Name = "celdaDisponibleLBS"
        Me.celdaDisponibleLBS.Size = New System.Drawing.Size(131, 22)
        Me.celdaDisponibleLBS.TabIndex = 1
        Me.celdaDisponibleLBS.Text = "0.00"
        Me.celdaDisponibleLBS.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 70)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(141, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Amount Downloading"
        '
        'etiquetaDisponibleLbs
        '
        Me.etiquetaDisponibleLbs.AutoSize = True
        Me.etiquetaDisponibleLbs.Location = New System.Drawing.Point(8, 38)
        Me.etiquetaDisponibleLbs.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDisponibleLbs.Name = "etiquetaDisponibleLbs"
        Me.etiquetaDisponibleLbs.Size = New System.Drawing.Size(95, 17)
        Me.etiquetaDisponibleLbs.TabIndex = 1
        Me.etiquetaDisponibleLbs.Text = "Available LBS"
        '
        'celdaInfoFin
        '
        Me.celdaInfoFin.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoFin.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfoFin.Location = New System.Drawing.Point(355, 48)
        Me.celdaInfoFin.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfoFin.Multiline = True
        Me.celdaInfoFin.Name = "celdaInfoFin"
        Me.celdaInfoFin.Size = New System.Drawing.Size(292, 55)
        Me.celdaInfoFin.TabIndex = 5
        Me.celdaInfoFin.Text = "..."
        '
        'etiquetaRequerimientos
        '
        Me.etiquetaRequerimientos.AutoSize = True
        Me.etiquetaRequerimientos.Location = New System.Drawing.Point(352, 27)
        Me.etiquetaRequerimientos.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRequerimientos.Name = "etiquetaRequerimientos"
        Me.etiquetaRequerimientos.Size = New System.Drawing.Size(178, 17)
        Me.etiquetaRequerimientos.TabIndex = 4
        Me.etiquetaRequerimientos.Text = "Requerimientos del Pedido"
        '
        'celdaCancel
        '
        Me.celdaCancel.Location = New System.Drawing.Point(779, 27)
        Me.celdaCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCancel.Name = "celdaCancel"
        Me.celdaCancel.Size = New System.Drawing.Size(100, 28)
        Me.celdaCancel.TabIndex = 2
        Me.celdaCancel.Text = "Cancel"
        Me.celdaCancel.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(655, 27)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(100, 28)
        Me.botonAceptar.TabIndex = 1
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'celdaInfoFinal
        '
        Me.celdaInfoFinal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaInfoFinal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoFinal.Location = New System.Drawing.Point(340, 7)
        Me.celdaInfoFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfoFinal.Multiline = True
        Me.celdaInfoFinal.Name = "celdaInfoFinal"
        Me.celdaInfoFinal.Size = New System.Drawing.Size(759, 111)
        Me.celdaInfoFinal.TabIndex = 3
        '
        'colAño
        '
        Me.colAño.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Width = 67
        '
        'colNumero
        '
        Me.colNumero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 87
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colPoliza
        '
        Me.colPoliza.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPoliza.HeaderText = "Policy"
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        Me.colPoliza.Width = 74
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 103
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 64
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colDisponible
        '
        Me.colDisponible.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDisponible.HeaderText = "Available"
        Me.colDisponible.Name = "colDisponible"
        Me.colDisponible.ReadOnly = True
        Me.colDisponible.Width = 94
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 92
        '
        'colUnidad
        '
        Me.colUnidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colUnidad.HeaderText = "Unit"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        Me.colUnidad.Visible = False
        Me.colUnidad.Width = 62
        '
        'colDescargo
        '
        Me.colDescargo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescargo.HeaderText = "Discharge"
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.Width = 101
        '
        'colNota1
        '
        Me.colNota1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNota1.HeaderText = "Note 1"
        Me.colNota1.Name = "colNota1"
        Me.colNota1.Visible = False
        Me.colNota1.Width = 79
        '
        'colNota2
        '
        Me.colNota2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNota2.HeaderText = "Note 2"
        Me.colNota2.Name = "colNota2"
        Me.colNota2.Visible = False
        Me.colNota2.Width = 79
        '
        'colReserva
        '
        Me.colReserva.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReserva.HeaderText = "Reservation"
        Me.colReserva.Name = "colReserva"
        Me.colReserva.ReadOnly = True
        Me.colReserva.Visible = False
        Me.colReserva.Width = 113
        '
        'colDetalle
        '
        Me.colDetalle.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDetalle.HeaderText = "Detail"
        Me.colDetalle.Name = "colDetalle"
        Me.colDetalle.ReadOnly = True
        Me.colDetalle.Visible = False
        Me.colDetalle.Width = 73
        '
        'colPF
        '
        Me.colPF.HeaderText = "PF"
        Me.colPF.Name = "colPF"
        '
        'colFila
        '
        Me.colFila.HeaderText = "Fila"
        Me.colFila.Name = "colFila"
        Me.colFila.ReadOnly = True
        Me.colFila.Visible = False
        '
        'frmFacturasRef_Aux_
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1116, 574)
        Me.Controls.Add(Me.paenlInfoFinal)
        Me.Controls.Add(Me.panelInfo)
        Me.Controls.Add(Me.panelLista)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmFacturasRef_Aux_"
        Me.Text = "frmFacturasRef_Aux_"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelInfo.ResumeLayout(False)
        Me.panelInfo.PerformLayout()
        Me.panelReservacion.ResumeLayout(False)
        Me.panelReservacion.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgReservacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.paenlInfoFinal.ResumeLayout(False)
        Me.paenlInfoFinal.PerformLayout()
        Me.PanelTotales.ResumeLayout(False)
        Me.gbTotales.ResumeLayout(False)
        Me.gbTotales.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelInfo As System.Windows.Forms.Panel
    Friend WithEvents paenlInfoFinal As System.Windows.Forms.Panel
    Friend WithEvents etiquetaRequerimientos As System.Windows.Forms.Label
    Friend WithEvents celdaCancel As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents gbTotales As System.Windows.Forms.GroupBox
    Friend WithEvents celdaCantidadDescar As System.Windows.Forms.TextBox
    Friend WithEvents celdaDisponibleLBS As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents etiquetaDisponibleLbs As System.Windows.Forms.Label
    Friend WithEvents celdaInfoFinal As System.Windows.Forms.TextBox
    Friend WithEvents celdaInfo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTitulo As System.Windows.Forms.Label
    Friend WithEvents panelReservacion As System.Windows.Forms.Panel
    Friend WithEvents dgReservacion As System.Windows.Forms.DataGridView
    Friend WithEvents etiquetaInfo As System.Windows.Forms.Label
    Friend WithEvents celdaReserva As System.Windows.Forms.TextBox
    Friend WithEvents celdaInfoFin As System.Windows.Forms.TextBox
    Friend WithEvents PanelTotales As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNota As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDisponible As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colNota1 As DataGridViewTextBoxColumn
    Friend WithEvents colNota2 As DataGridViewTextBoxColumn
    Friend WithEvents colReserva As DataGridViewTextBoxColumn
    Friend WithEvents colDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colPF As DataGridViewTextBoxColumn
    Friend WithEvents colFila As DataGridViewTextBoxColumn
End Class
