﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPermisosCajaChica
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelCerrar = New System.Windows.Forms.Panel()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaIdUsuario = New System.Windows.Forms.TextBox()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.botonUsuario = New System.Windows.Forms.Button()
        Me.panelUsuario = New System.Windows.Forms.Panel()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.dgCajasChicas = New System.Windows.Forms.DataGridView()
        Me.colCaja = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelCerrar.SuspendLayout()
        Me.panelUsuario.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgCajasChicas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelCerrar
        '
        Me.panelCerrar.Controls.Add(Me.botonCerrar)
        Me.panelCerrar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelCerrar.Location = New System.Drawing.Point(0, 464)
        Me.panelCerrar.Name = "panelCerrar"
        Me.panelCerrar.Size = New System.Drawing.Size(737, 64)
        Me.panelCerrar.TabIndex = 0
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel5
        Me.botonCerrar.Location = New System.Drawing.Point(642, 6)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(79, 53)
        Me.botonCerrar.TabIndex = 26
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(60, 36)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.ReadOnly = True
        Me.celdaUsuario.Size = New System.Drawing.Size(292, 22)
        Me.celdaUsuario.TabIndex = 1
        '
        'celdaIdUsuario
        '
        Me.celdaIdUsuario.Location = New System.Drawing.Point(423, 34)
        Me.celdaIdUsuario.Name = "celdaIdUsuario"
        Me.celdaIdUsuario.Size = New System.Drawing.Size(50, 22)
        Me.celdaIdUsuario.TabIndex = 2
        Me.celdaIdUsuario.Visible = False
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(16, 39)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaUsuario.TabIndex = 3
        Me.etiquetaUsuario.Text = "User"
        '
        'botonUsuario
        '
        Me.botonUsuario.Location = New System.Drawing.Point(371, 35)
        Me.botonUsuario.Name = "botonUsuario"
        Me.botonUsuario.Size = New System.Drawing.Size(35, 23)
        Me.botonUsuario.TabIndex = 4
        Me.botonUsuario.Text = "..."
        Me.botonUsuario.UseVisualStyleBackColor = True
        '
        'panelUsuario
        '
        Me.panelUsuario.Controls.Add(Me.celdaIdUsuario)
        Me.panelUsuario.Controls.Add(Me.botonUsuario)
        Me.panelUsuario.Controls.Add(Me.celdaUsuario)
        Me.panelUsuario.Controls.Add(Me.etiquetaUsuario)
        Me.panelUsuario.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelUsuario.Location = New System.Drawing.Point(0, 0)
        Me.panelUsuario.Name = "panelUsuario"
        Me.panelUsuario.Size = New System.Drawing.Size(737, 76)
        Me.panelUsuario.TabIndex = 5
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonEliminar)
        Me.panelBotones.Controls.Add(Me.botonMas)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(678, 76)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(59, 388)
        Me.panelBotones.TabIndex = 6
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(7, 79)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(43, 39)
        Me.botonEliminar.TabIndex = 5
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(7, 25)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(43, 39)
        Me.botonMas.TabIndex = 4
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'dgCajasChicas
        '
        Me.dgCajasChicas.AllowUserToAddRows = False
        Me.dgCajasChicas.AllowUserToDeleteRows = False
        Me.dgCajasChicas.AllowUserToOrderColumns = True
        Me.dgCajasChicas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgCajasChicas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCajasChicas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCaja, Me.colCodigo, Me.colDescripcion, Me.colMoneda})
        Me.dgCajasChicas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCajasChicas.Location = New System.Drawing.Point(0, 76)
        Me.dgCajasChicas.Name = "dgCajasChicas"
        Me.dgCajasChicas.RowTemplate.Height = 24
        Me.dgCajasChicas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCajasChicas.Size = New System.Drawing.Size(678, 388)
        Me.dgCajasChicas.TabIndex = 7
        '
        'colCaja
        '
        Me.colCaja.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCaja.HeaderText = "Petty Cash"
        Me.colCaja.Name = "colCaja"
        Me.colCaja.Width = 105
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.Width = 108
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Currency"
        Me.colMoneda.Name = "colMoneda"
        '
        'frmPermisosCajaChica
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(737, 528)
        Me.Controls.Add(Me.dgCajasChicas)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.panelUsuario)
        Me.Controls.Add(Me.panelCerrar)
        Me.Name = "frmPermisosCajaChica"
        Me.Text = "Petty Cash Permits"
        Me.panelCerrar.ResumeLayout(False)
        Me.panelUsuario.ResumeLayout(False)
        Me.panelUsuario.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgCajasChicas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents panelCerrar As Panel
    Friend WithEvents botonCerrar As Button
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaIdUsuario As TextBox
    Friend WithEvents etiquetaUsuario As Label
    Friend WithEvents botonUsuario As Button
    Friend WithEvents panelUsuario As Panel
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonMas As Button
    Friend WithEvents botonEliminar As Button
    Friend WithEvents dgCajasChicas As DataGridView
    Friend WithEvents colCaja As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
End Class
