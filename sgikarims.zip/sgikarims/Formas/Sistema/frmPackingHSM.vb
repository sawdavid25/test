﻿Public Class frmPackingHSM

#Region "Variables"

    Dim strLLave As String = STR_VACIO
    Dim strDato As String = STR_VACIO
    Dim strDato2 As String = STR_VACIO

    Dim intCat As Integer = INT_CERO
    Dim intLinea As Integer = INT_CERO
    Dim intRespuesta As Integer = INT_CERO
    Dim intNumero As Integer = INT_CERO
    Dim intAnio As Integer = INT_CERO
    Dim intMedida As Integer = INT_CERO
    Dim logAceptar As Boolean
    Dim dblTara As Double
    Dim dblLBS As Double
    Dim strRef As String = STR_VACIO

#End Region

#Region "Propiedades"
    Public Property LLave As String
        Get
            Return strLLave
        End Get
        Set(value As String)
            strLLave = value
        End Set
    End Property

    Public Property Dato As String
        Get
            Return strDato
        End Get
        Set(value As String)
            strDato = value
        End Set
    End Property


    Public Property Dato2 As String
        Get
            Return strDato2
        End Get
        Set(value As String)
            strDato2 = value
        End Set
    End Property

    Public Property Catalogo As Integer
        Get
            Return intCat
        End Get
        Set(value As Integer)
            intCat = value
        End Set
    End Property

    Public Property Linea As Integer
        Get
            Return intLinea
        End Get
        Set(value As Integer)
            intLinea = value
        End Set
    End Property

    Public Property Respuesta As Integer
        Get
            Return intRespuesta
        End Get
        Set(value As Integer)
            intRespuesta = value
        End Set
    End Property

    'Propiedad para comprobar si se han aceptado los cambios
    Public Property Aceptado As Boolean
        Get
            Return logAceptar
        End Get
        Set(value As Boolean)
            logAceptar = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return intNumero
        End Get
        Set(value As Integer)
            intNumero = value
        End Set
    End Property

    Public Property Anio As Integer
        Get
            Return intAnio
        End Get
        Set(value As Integer)
            intAnio = value
        End Set
    End Property

    Public Property Medida As Integer
        Get
            Return intMedida
        End Get
        Set(value As Integer)
            intMedida = value
        End Set
    End Property

    Public Property Tara As Double
        Get
            Return dblTara
        End Get
        Set(value As Double)
            dblTara = value
        End Set
    End Property

    Public Property LBS As Double
        Get
            Return dblLBS
        End Get
        Set(value As Double)
            dblLBS = value
        End Set
    End Property

    Public Property Referencia As String
        Get
            Return strRef
        End Get
        Set(value As String)
            strRef = value
        End Set
    End Property
#End Region

#Region "Procedimientos"



    Public Sub LimpiarCampos()
        celdaPaquetes.Text = INT_UNO
        celdaLbsPaquetes.Text = INT_UNO
        celdaTara.Text = 0
        celdaLbsTara.Text = 0
        celdaKilosN.Text = 0
        celdaLbsNetas.Text = 0
        celdaKilosBrutos.Text = 0
        celdaLbsBrutas.Text = 0
        celdaReferencia.Clear()
        celdaReferenciaLbs.Clear()

    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim SumaLbNetas As Double = 0
        Dim SumaLbsBrutas As Double = 0
        Dim sumaBultos As Double = 0

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colXtraPack").Value = 1 Or dgDetalle.Rows(i).Cells("colXtraPack").Value = 0 Then
                SumaLbNetas = dgDetalle.Rows(i).Cells("colKilosNetos").Value + SumaLbNetas
                SumaLbsBrutas = dgDetalle.Rows(i).Cells("colKilosBrutos").Value + SumaLbsBrutas
                sumaBultos = dgDetalle.Rows(i).Cells("colBultos").Value + sumaBultos
            End If
        Next

        celdaTotalK.Text = SumaLbNetas.ToString(FORMATO_MONEDA)
        celdaTotalLbs.Text = SumaLbsBrutas.ToString(FORMATO_MONEDA)
        celdaSumaBultos.Text = sumaBultos
        celdaLbsPaquetes.Text = sumaBultos
    End Sub

#End Region

#Region "Eventos"

    Private Sub frmPackingHSM_Load(sender As Object, e As EventArgs) Handles Me.Load

        If intMedida = 69 Then
            gbKilos.Visible = False
            gbLibras.Visible = True
            botonAgregar.Location = New System.Drawing.Point(700, 110)
        ElseIf intMedida = 70 Then
            gbKilos.Visible = True
            gbLibras.Visible = False
            botonAgregar.Location = New System.Drawing.Point(700, 7)
        End If

        If Sesion.IdEmpresa = 15 Then
            celdaTaraAprox.Visible = True
            botonTaraAprox.Visible = True
        Else
            celdaTaraAprox.Visible = False
            botonTaraAprox.Visible = False
        End If


        celdaCatalogo.Text = intCat
        celdaLinea.Text = intLinea
        celdaNumero.Text = intNumero
        celdaAnio.Text = intAnio
        celdaLbsTara.Text = dblTara
        celdaLbsNetas.Text = dblLBS
        celdaReferenciaLbs.Text = strRef

        CalcularTotales()
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim i As Integer
        Dim strFila As String = STR_VACIO
        If celdaTara.Text <> 0 Then
            For i = 0 To celdaPaquetes.Text - 1
                strFila = INT_UNO & "|"

                'If Medida = 69 Then
                '    strFila &= (celdaTara.Text).ToString(FORMATO_MONEDA) & "|"
                '    strFila &= celdaTara.Text & "|"
                'Else
                strFila &= celdaTara.Text & "|"
                strFila &= (celdaTara.Text * 2.2046).ToString(FORMATO_MONEDA) & "|"
                'End If

                strFila &= Val(celdaKilosN.Text) & "|"
                strFila &= Val(celdaKilosBrutos.Text) & "|"
                strFila &= (celdaKilosN.Text * 2.20462).ToString(FORMATO_MONEDA) & "|"
                strFila &= (celdaKilosBrutos.Text * 2.20462).ToString(FORMATO_MONEDA) & "|"
                strFila &= celdaReferencia.Text & "|"
                strFila &= 0 & "|"
                strFila &= intLinea & "|"
                strFila &= dgDetalle.Rows.Count + 1
                'strFila &= celdaTaraAprox.Text


                cFunciones.AgregarFila(dgDetalle, strFila)
            Next

        ElseIf celdaLbsTara.Text <> 0 Then
            For i = 0 To celdaLbsPaquetes.Text - 1
                strFila = INT_UNO & "|"

                'If Medida = 69 Then
                '    strFila &= (celdaLbsTara.Text / 2.20462).ToString(FORMATO_MONEDA) & "|"
                '    strFila &= celdaLbsTara.Text & "|"
                'Else
                strFila &= (celdaLbsTara.Text / 2.2046).ToString(FORMATO_MONEDA) & "|"
                strFila &= (celdaLbsTara.Text) & "|"
                'End If

                strFila &= Math.Round((celdaLbsNetas.Text / 2.20462), 2) & "|"
                strFila &= Math.Round((celdaLbsBrutas.Text / 2.20462), 2) & "|"
                strFila &= celdaLbsNetas.Text & "|"
                strFila &= celdaLbsBrutas.Text & "|"
                strFila &= celdaReferenciaLbs.Text & "|"
                strFila &= 0 & "|"
                strFila &= intLinea & "|"
                strFila &= dgDetalle.Rows.Count + 1 & "|"
                strFila &= celdaTaraAprox.Text

                cFunciones.AgregarFila(dgDetalle, strFila)
            Next

        Else

        End If
        CalcularTotales()
        LimpiarCampos()

    End Sub

    Private Sub celdaKilosBrutos_TextChanged(sender As Object, e As EventArgs) Handles celdaKilosBrutos.TextChanged
        'celdaKilosBrutos.Text = CDbl(celdaTara.Text) + CDbl(celdaKilosN.Text)
    End Sub

    Public Sub SumarCantidadesKG()
        Dim primerCant As Double
        Dim segundaCant As Double
        If celdaTara.TextLength > 0 And celdaKilosN.TextLength Then
            primerCant = celdaTara.Text
            segundaCant = celdaKilosN.Text
            celdaKilosBrutos.Text = (primerCant) + (segundaCant)
        End If

    End Sub

    Public Sub SumarCantidadesLBS()
        Dim primerCant As Double
        Dim segundaCant As Double
        If celdaLbsTara.TextLength > 0 And celdaLbsNetas.TextLength > 0 Then
            primerCant = celdaLbsTara.Text
            segundaCant = celdaLbsNetas.Text
            celdaLbsBrutas.Text = (primerCant) + (segundaCant)
        End If

    End Sub

    Public Sub RestarCantidadesLBS()
        Dim primerCant As Double
        Dim segundaCant As Double
        If celdaLbsTara.TextLength > 0 And celdaLbsBrutas.TextLength > 0 Then
            primerCant = celdaLbsBrutas.Text
            segundaCant = celdaLbsTara.Text
            celdaLbsNetas.Text = (primerCant) - (segundaCant)
        End If

    End Sub

    Private Sub celdaTara_TextChanged(sender As Object, e As EventArgs) Handles celdaTara.TextChanged
        SumarCantidadesKG()
    End Sub

    Private Sub celdaKilosN_TextChanged(sender As Object, e As EventArgs) Handles celdaKilosN.TextChanged
        SumarCantidadesKG()
    End Sub

    Private Sub celdaLbsTara_TextChanged(sender As Object, e As EventArgs) Handles celdaLbsTara.TextChanged
        SumarCantidadesLBS()
    End Sub

    Private Sub celdaLbsNetas_TextChanged(sender As Object, e As EventArgs) Handles celdaLbsNetas.TextChanged
        SumarCantidadesLBS()
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

        strLLave = celdaTotalLbs.Text
        strDato = celdaTotalK.Text
        strDato2 = celdaSumaBultos.Text

        logAceptar = True
        Aceptado = True

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Sub LlenarGridOculto()
        Dim i As Integer = INT_CERO

        For i = 0 To dgDetalle.Rows.Count - 1


        Next
    End Sub

    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click
        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer
            Dim intLinea As Integer = vbEmpty

            If dgDetalle.SelectedRows Is Nothing Then Exit Sub

            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                'For i As Integer = 0 To Count - 1
                If MsgBox("You sure you want to delete the row of the PackingList ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                    dgDetalle.SelectedCells(7).Value = 2
                    dgDetalle.CurrentRow.Visible = False
                    'Me.dgDetalle.Rows.Remove(dgDetalle.SelectedRows(0))

                    Count = Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                End If
                'Next
            Else
                Exit Sub
            End If

            CalcularTotales()
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                intLinea = intLinea + i
            Next
            celdaLinea.Text = intLinea

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonTaraAprox_Click(sender As Object, e As EventArgs) Handles botonTaraAprox.Click
        Dim selec As New frmSeleccionar
        selec.Titulo = "Tara"
        selec.Campos = " cat_desc despcripcion,cat_dato tara "
        selec.Tabla = " Catalogos "
        selec.Filtro = " cat_desc "
        selec.Ordenamiento = " cat_desc "
        selec.Condicion = " cat_clase = 'TipoBulto' "

        selec.ShowDialog(Me)

        If selec.DialogResult = System.Windows.Forms.DialogResult.OK Then
            celdaTaraAprox.Text = selec.LLave
            celdaLbsTara.Text = selec.Dato
        End If
    End Sub

    Private Sub celdaLbsBrutas_TextChanged(sender As Object, e As EventArgs) Handles celdaLbsBrutas.TextChanged
        RestarCantidadesLBS()
    End Sub

#End Region


End Class