﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBackup
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonAbajo = New System.Windows.Forms.Button()
        Me.botonUp = New System.Windows.Forms.Button()
        Me.PanelPiePagina = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CheckActivo = New System.Windows.Forms.CheckBox()
        Me.celdaID = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDTarea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTarea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Location = New System.Drawing.Point(31, 143)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(123, 71)
        Me.panelLista.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colFecha, Me.colStatus})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(123, 71)
        Me.dgLista.TabIndex = 0
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Width = 50
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Width = 77
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.PanelDetalle)
        Me.PanelDocumento.Controls.Add(Me.PanelPiePagina)
        Me.PanelDocumento.Controls.Add(Me.GroupBox1)
        Me.PanelDocumento.Location = New System.Drawing.Point(199, 114)
        Me.PanelDocumento.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(655, 206)
        Me.PanelDocumento.TabIndex = 4
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Controls.Add(Me.Panel1)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 85)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(655, 83)
        Me.PanelDetalle.TabIndex = 3
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colUsuario, Me.colNombre, Me.colIDTarea, Me.colTarea, Me.colComentario, Me.colEstado, Me.colLinea, Me.colMarca})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(600, 83)
        Me.dgDetalle.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonAbajo)
        Me.Panel1.Controls.Add(Me.botonUp)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(600, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(55, 83)
        Me.Panel1.TabIndex = 13
        '
        'botonAbajo
        '
        Me.botonAbajo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAbajo.Enabled = False
        Me.botonAbajo.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonAbajo.Location = New System.Drawing.Point(8, 48)
        Me.botonAbajo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAbajo.Name = "botonAbajo"
        Me.botonAbajo.Size = New System.Drawing.Size(43, 31)
        Me.botonAbajo.TabIndex = 32
        Me.botonAbajo.UseVisualStyleBackColor = True
        '
        'botonUp
        '
        Me.botonUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonUp.Enabled = False
        Me.botonUp.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonUp.Location = New System.Drawing.Point(8, 16)
        Me.botonUp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonUp.Name = "botonUp"
        Me.botonUp.Size = New System.Drawing.Size(43, 28)
        Me.botonUp.TabIndex = 31
        Me.botonUp.UseVisualStyleBackColor = True
        '
        'PanelPiePagina
        '
        Me.PanelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelPiePagina.Location = New System.Drawing.Point(0, 168)
        Me.PanelPiePagina.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PanelPiePagina.Name = "PanelPiePagina"
        Me.PanelPiePagina.Size = New System.Drawing.Size(655, 38)
        Me.PanelPiePagina.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.CheckActivo)
        Me.GroupBox1.Controls.Add(Me.celdaID)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(655, 85)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(41, 55)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 17)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Date"
        '
        'CheckActivo
        '
        Me.CheckActivo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckActivo.AutoSize = True
        Me.CheckActivo.Checked = True
        Me.CheckActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckActivo.Location = New System.Drawing.Point(320, 21)
        Me.CheckActivo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CheckActivo.Name = "CheckActivo"
        Me.CheckActivo.Size = New System.Drawing.Size(68, 21)
        Me.CheckActivo.TabIndex = 11
        Me.CheckActivo.Text = "Active"
        Me.CheckActivo.UseVisualStyleBackColor = True
        '
        'celdaID
        '
        Me.celdaID.Location = New System.Drawing.Point(140, 18)
        Me.celdaID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaID.Name = "celdaID"
        Me.celdaID.ReadOnly = True
        Me.celdaID.Size = New System.Drawing.Size(109, 22)
        Me.celdaID.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(41, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(21, 17)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "ID"
        '
        'dtpFecha
        '
        Me.dtpFecha.Enabled = False
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(140, 48)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(109, 22)
        Me.dtpFecha.TabIndex = 8
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(879, 272)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(879, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.Width = 67
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Computer"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 98
        '
        'colIDTarea
        '
        Me.colIDTarea.HeaderText = "IDTarea"
        Me.colIDTarea.Name = "colIDTarea"
        Me.colIDTarea.Width = 88
        '
        'colTarea
        '
        Me.colTarea.HeaderText = "Task"
        Me.colTarea.Name = "colTarea"
        Me.colTarea.Width = 68
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Comment"
        Me.colComentario.Name = "colComentario"
        Me.colComentario.Width = 96
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.Width = 77
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 64
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Marca"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.Visible = False
        Me.colMarca.Width = 76
        '
        'frmBackup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(879, 361)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmBackup"
        Me.Text = "Backup"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonAbajo As Button
    Friend WithEvents botonUp As Button
    Friend WithEvents PanelPiePagina As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CheckActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaID As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colIDTarea As DataGridViewTextBoxColumn
    Friend WithEvents colTarea As DataGridViewTextBoxColumn
    Friend WithEvents colComentario As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
End Class
