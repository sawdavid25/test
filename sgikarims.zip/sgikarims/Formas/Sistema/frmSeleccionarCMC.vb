﻿Imports System.ComponentModel
Imports System.Threading

Public Class frmSeleccionarCMC

#Region "Variables"

    Dim strLLave As String = STR_VACIO
    Dim strDato As String = STR_VACIO
    Dim strDato2 As String = STR_VACIO
    Dim strDato3 As String = STR_VACIO
    Dim strDato4 As String = STR_VACIO

    Dim strCampos As String = STR_VACIO
    Dim strTabla As String = STR_VACIO
    Dim strFiltro As String = STR_VACIO
    Dim intLimite As Integer = NO_FILA
    Dim strCondicion As String = STR_VACIO
    Dim strCondicion2 As String = STR_VACIO
    Dim strOrdenamiento As String = STR_VACIO
    Dim strFiltroText As String = STR_VACIO
    Dim strTitulo As String = STR_VACIO
    Dim ROrdenamiento As String = "DESC"
    Dim strAgrupar As String = STR_VACIO
    Dim logCrear As Boolean = False
    Dim strParametroCrear As String
    Dim logMultiple As Boolean = True

    Dim Celda As New DataGridViewTextBoxCell
    Dim Fila As New DataGridViewRow
    Dim check As New DataGridViewCheckBoxCell
    Dim arrayCampos() As String
    Dim arrayColumnas As New List(Of String)
    Dim arrayTemporal() As String
    Dim COM As MySqlCommand
    Dim REA As MySqlDataReader
    Dim intcontador As Integer = INT_CERO
    Dim thread1 As Thread
    Dim strSQL2 As String
    Dim dt As New System.Data.DataTable
    Dim DAA As MySqlDataAdapter
    Dim frmFacturaIVA As New frmFacturaIva

    Dim cfun As New clsFunciones

    Public Delegate Sub delegate1(ByVal value As Object)
#End Region

#Region "Propiedades"

    Public Property DataGrid As DataGridView
        Set(value As DataGridView)
            ListaClientes = value
        End Set
        Get
            Return ListaClientes
        End Get
    End Property

    Public Property FiltroText As String
        Get
            Return strFiltroText
        End Get
        Set(value As String)
            strFiltroText = value
        End Set
    End Property

    Public WriteOnly Property TipoOrdenamiento As String
        Set(value As String)
            ROrdenamiento = value
        End Set
    End Property

#End Region

#Region "Funciones"
    Private Sub Seleccionar()
        If ListaClientes.SelectedRows.Count = 0 Then Exit Sub
        Dim strlinea As String = ""
        Try

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub ListaClientes_KeyDown(sender As Object, e As KeyEventArgs) Handles ListaClientes.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Seleccionar()
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(ListaClientes)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaFiltro_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaFiltro.KeyDown
        Try
            If e.KeyCode = Keys.Enter Or e.KeyCode = Keys.Tab Then
                LoadData(celdaFiltro.Text)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Configura el DataGridView
        ListaClientes.Columns.Add(New DataGridViewCheckBoxColumn() With {.Name = "Select", .HeaderText = "Select"})
        'ListaClientes.Columns.Add("Select", "Select")
        ListaClientes.Columns.Add("Invoice", "Invoice")
        ListaClientes.Columns.Add("Date", "Date")
        ListaClientes.Columns.Add("Reference", "Reference")
        ListaClientes.Columns.Add("Weight", "Weight")
        ListaClientes.Columns.Add("USER", "USER")
        ListaClientes.Columns.Add("YEAR", "YEAR")
        ListaClientes.Columns.Add("Flete", "Flete")
        ListaClientes.Columns.Add("Gasto", "Gasto")
        ListaClientes.Columns.Add("Comentario", "Comentario")


        LoadData()
    End Sub

    Private Sub LoadData(Optional refNumber As String = "")
        Dim strLinea As String = STR_VACIO
        cfun.sesionHilos()

        ' Configura las cadenas de conexión
        Dim connectionStringBaseOF As String = "server=" & CMC_Hilos_Host & ";Port=" & CMC_Hilos_PORT & ";database=" & CMC_Hilos_BASE & ";uid=" & CMC_Hilos_USER & ";password=" & CMC_Hilos_PASS & ";"
        Dim connectionStringBase As String = strConexion

        ' Variables para los parámetros
        Dim empresa As Integer = Sesion.IdEmpresa

        Dim empresaRel As Integer = 12
        Dim filtroFactura As String = ""
        If refNumber = "" Then
        Else
            filtroFactura = " AND h.HDoc_Doc_Num= " & refNumber
        End If
        ' Consulta en baseOF hilos
        Dim queryBaseOF As String = " SELECT
	                    h.HDoc_Doc_Num Invoice,
	                    h.HDoc_Doc_Fec DATE,
	                    h.HDoc_DR1_Num Reference,
	                    SUM(d.DDoc_Prd_QTY) Weight,
	                    h.HDoc_Usuario USER,
	                    h.HDoc_Doc_Ano YEAR,
	                    IFNULL(h48.HDoc_RF1_Num,-1) Flete,
	                    IFNULL(h48.HDoc_Rf2_Num,-1) Gasto,
	                    IFNULL(h.HDoc_RF2_txt, ' ') Comentario,
                        CONCAT(h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num) llave
                    From " & CMC_Hilos_BASE & ".Dcmtos_HDR h
                    Left JOIN " & CMC_Hilos_BASE & ".Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN " & CMC_Hilos_BASE & ".Dcmtos_DTL_Pro p48 ON p48.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p48.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p48.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p48.PDoc_Chi_Num = h.HDoc_Doc_Num AND p48.PDoc_Par_Cat = 48
                    LEFT JOIN " & CMC_Hilos_BASE & ".Dcmtos_HDR h48 ON h48.HDoc_Sis_Emp = p48.PDoc_Sis_Emp AND h48.HDoc_Doc_Cat = p48.PDoc_Par_Cat AND h48.HDoc_Doc_Ano = p48.PDoc_Par_Ano  AND h48.HDoc_Doc_Num = p48.PDoc_Par_Num
                    Left JOIN " & CMC_Hilos_BASE & ".Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp And p.PDoc_Par_Cat = d.DDoc_Doc_Cat And p.PDoc_Par_Ano = d.DDoc_Doc_Ano And p.PDoc_Par_Num = d.DDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = " & empresaRel & " AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Pro_DCat =0 AND h.HDoc_Doc_Status = 1 " & FiltroText & filtroFactura & " 
                     GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num
                    ORDER BY h.HDoc_Doc_Fec, h.HDoc_Doc_Num DESC
                    LIMIT 20"

        ' Consulta en base
        Dim queryBase As String = "SELECT 
                             dp.PDoc_Chi_Cat,
                             dp.PDoc_Chi_Ano, 
                             dp.PDoc_Chi_Num,
                             dp.PDoc_Par_Cat HDoc_Doc_Cat, 
                             dp.PDoc_Par_Ano HDoc_Doc_Ano, 
                             dp.PDoc_Par_Num HDoc_Doc_Num,
                             CONCAT(dp.PDoc_Chi_Cat, dp.PDoc_Chi_Ano, dp.PDoc_Chi_Num) llave
                            FROM  Dcmtos_DTL_Pro dp 
                            WHERE dp.PDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND  dp.PDoc_Par_Cat = 36 AND dp.PDoc_Chi_Cat = 303  ;"

        Using connectionBaseOF As New MySqlConnection(connectionStringBaseOF)
            Using connectionBase As New MySqlConnection(connectionStringBase)
                Try
                    ' Abre las conexiones
                    connectionBaseOF.Open()
                    connectionBase.Open()

                    ' Ejecuta la consulta en baseOF
                    Dim commandBaseOF As New MySqlCommand(queryBaseOF, connectionBaseOF)
                    Dim dataTableBaseOF As New System.Data.DataTable()
                    Using readerBaseOF As MySqlDataReader = commandBaseOF.ExecuteReader()
                        dataTableBaseOF.Load(readerBaseOF)
                    End Using

                    ' Ejecuta la consulta en base
                    Dim commandBase As New MySqlCommand(queryBase, connectionBase)
                    Dim dataTableBase As New System.Data.DataTable()
                    Using readerBase As MySqlDataReader = commandBase.ExecuteReader()
                        dataTableBase.Load(readerBase)
                    End Using

                    ' Combina los resultados
                    Dim combinedResults As New List(Of Object)()

                    ' Primero, crea un HashSet para las llaves de rowBase
                    Dim baseKeys As New HashSet(Of String)
                    For Each rowBase As DataRow In dataTableBase.Rows
                        baseKeys.Add(rowBase("llave").ToString())
                    Next

                    ' Segundo, agrega los elementos coincidentes
                    For Each rowBaseOF As DataRow In dataTableBaseOF.Rows
                        Dim foundMatch As Boolean = False
                        For Each rowBase As DataRow In dataTableBase.Rows
                            If rowBaseOF("llave") = rowBase("llave") Then
                                combinedResults.Add(New With {
                                .Invoice = rowBaseOF("Invoice"),
                                .Date = rowBaseOF("Date"),
                                .Reference = rowBaseOF("Reference"),
                                .Weight = rowBaseOF("Weight"),
                                .USER = rowBaseOF("USER"),
                                .Year = rowBaseOF("YEAR"),
                                .Flete = rowBaseOF("Flete"),
                                .Gasto = rowBaseOF("Gasto"),
                                .Comentario = rowBaseOF("Comentario")
                                })
                                foundMatch = True
                            End If
                        Next

                        ' Si no se encontró ninguna coincidencia, agrega los elementos únicos de rowBaseOF
                        If Not foundMatch Then
                            combinedResults.Add(New With {
                            .Invoice = rowBaseOF("Invoice"),
                            .Date = rowBaseOF("Date"),
                            .Reference = rowBaseOF("Reference"),
                            .Weight = rowBaseOF("Weight"),
                            .USER = rowBaseOF("USER"),
                            .Year = rowBaseOF("YEAR"),
                            .Flete = rowBaseOF("Flete"),
                            .Gasto = rowBaseOF("Gasto"),
                            .Comentario = rowBaseOF("Comentario")
                            })
                        End If
                    Next

                    ' Muestra los resultados combinados en el DataGridView
                    ListaClientes.Rows.Clear()

                    For Each result In combinedResults
                        check = New DataGridViewCheckBoxCell
                        check.Value = False
                        check.ReadOnly = False

                        ListaClientes.Rows.Add(check.Value, result.Invoice, result.DATE, result.Reference, result.Weight, result.User, result.YEAR, result.Flete, result.Gasto, result.Comentario)
                    Next
                Catch ex As MySqlException
                    ' Manejo de errores
                    MessageBox.Show("Error: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    Private Sub botonSeleccionar_Click(sender As Object, e As EventArgs) Handles botonSeleccionar.Click
        ' Recorrer las filas del DataGridView para procesar los ítems seleccionados.
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub ListaClientes_DoubleClick(sender As Object, e As EventArgs) Handles ListaClientes.DoubleClick
        If ListaClientes.CurrentRow.Cells("Select").Value = True Then
            ListaClientes.CurrentRow.Cells("Select").Value = False
        Else
            ListaClientes.CurrentRow.Cells("Select").Value = True
            End If

    End Sub
    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Exit Sub
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        LoadData(celdaFiltro.Text)
    End Sub
End Class