﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmInventario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmInventario))
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonExportar = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonPrevia = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.botonPais = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaPais = New System.Windows.Forms.TextBox()
        Me.celdaClase = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.botonClase = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaAcabado = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonAcabado = New System.Windows.Forms.Button()
        Me.celdaCodigoProducto = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaidPais = New System.Windows.Forms.TextBox()
        Me.celdaTitulo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaidAcabado = New System.Windows.Forms.TextBox()
        Me.celdaidClase = New System.Windows.Forms.TextBox()
        Me.celdaDescripcionCorta = New System.Windows.Forms.TextBox()
        Me.celdaidSpnning = New System.Windows.Forms.TextBox()
        Me.botonSpinning = New System.Windows.Forms.Button()
        Me.celdaSpinning = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaContinente = New System.Windows.Forms.TextBox()
        Me.celdaidCountry = New System.Windows.Forms.TextBox()
        Me.botonContinente = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.checkIncludeHeathers = New System.Windows.Forms.CheckBox()
        Me.rbCadena1 = New System.Windows.Forms.RadioButton()
        Me.rbCadenaInsr = New System.Windows.Forms.RadioButton()
        Me.rbCadena3 = New System.Windows.Forms.RadioButton()
        Me.PanelFiltro = New System.Windows.Forms.Panel()
        Me.checkMuestra = New System.Windows.Forms.CheckBox()
        Me.botonRefrescar = New System.Windows.Forms.Button()
        Me.celdaCodigoInventario = New System.Windows.Forms.TextBox()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.botonEstado = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.celdaidEstado = New System.Windows.Forms.TextBox()
        Me.PanelEncabezado.SuspendLayout()
        Me.PanelFiltro.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.botonCerrar)
        Me.PanelEncabezado.Controls.Add(Me.botonExportar)
        Me.PanelEncabezado.Controls.Add(Me.botonGuardar)
        Me.PanelEncabezado.Controls.Add(Me.botonPrevia)
        Me.PanelEncabezado.Controls.Add(Me.botonImprimir)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(890, 79)
        Me.PanelEncabezado.TabIndex = 1
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = CType(resources.GetObject("botonCerrar.Image"), System.Drawing.Image)
        Me.botonCerrar.Location = New System.Drawing.Point(798, 15)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(76, 57)
        Me.botonCerrar.TabIndex = 1
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonExportar
        '
        Me.botonExportar.Image = CType(resources.GetObject("botonExportar.Image"), System.Drawing.Image)
        Me.botonExportar.Location = New System.Drawing.Point(297, 15)
        Me.botonExportar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonExportar.Name = "botonExportar"
        Me.botonExportar.Size = New System.Drawing.Size(95, 57)
        Me.botonExportar.TabIndex = 0
        Me.botonExportar.Text = "Export"
        Me.botonExportar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportar.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = CType(resources.GetObject("botonGuardar.Image"), System.Drawing.Image)
        Me.botonGuardar.Location = New System.Drawing.Point(203, 15)
        Me.botonGuardar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(95, 57)
        Me.botonGuardar.TabIndex = 0
        Me.botonGuardar.Text = "Save"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonPrevia
        '
        Me.botonPrevia.Image = CType(resources.GetObject("botonPrevia.Image"), System.Drawing.Image)
        Me.botonPrevia.Location = New System.Drawing.Point(109, 15)
        Me.botonPrevia.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPrevia.Name = "botonPrevia"
        Me.botonPrevia.Size = New System.Drawing.Size(95, 57)
        Me.botonPrevia.TabIndex = 0
        Me.botonPrevia.Text = "Preview"
        Me.botonPrevia.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevia.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(16, 15)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(95, 57)
        Me.botonImprimir.TabIndex = 0
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 286)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(890, 253)
        Me.WebBrowser1.TabIndex = 3
        '
        'botonPais
        '
        Me.botonPais.Location = New System.Drawing.Point(386, 74)
        Me.botonPais.Name = "botonPais"
        Me.botonPais.Size = New System.Drawing.Size(36, 23)
        Me.botonPais.TabIndex = 36
        Me.botonPais.Text = "..."
        Me.botonPais.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(478, 110)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(42, 17)
        Me.Label6.TabIndex = 39
        Me.Label6.Text = "Class"
        '
        'celdaPais
        '
        Me.celdaPais.Location = New System.Drawing.Point(143, 74)
        Me.celdaPais.Name = "celdaPais"
        Me.celdaPais.ReadOnly = True
        Me.celdaPais.Size = New System.Drawing.Size(237, 22)
        Me.celdaPais.TabIndex = 33
        '
        'celdaClase
        '
        Me.celdaClase.Location = New System.Drawing.Point(573, 110)
        Me.celdaClase.Name = "celdaClase"
        Me.celdaClase.ReadOnly = True
        Me.celdaClase.Size = New System.Drawing.Size(247, 22)
        Me.celdaClase.TabIndex = 40
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 76)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 17)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "Country"
        '
        'botonClase
        '
        Me.botonClase.Location = New System.Drawing.Point(826, 109)
        Me.botonClase.Name = "botonClase"
        Me.botonClase.Size = New System.Drawing.Size(36, 23)
        Me.botonClase.TabIndex = 42
        Me.botonClase.Text = "..."
        Me.botonClase.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 17)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "Inventory Code"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(24, 105)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 17)
        Me.Label7.TabIndex = 45
        Me.Label7.Text = "Finish"
        '
        'celdaAcabado
        '
        Me.celdaAcabado.Location = New System.Drawing.Point(144, 107)
        Me.celdaAcabado.Name = "celdaAcabado"
        Me.celdaAcabado.ReadOnly = True
        Me.celdaAcabado.Size = New System.Drawing.Size(236, 22)
        Me.celdaAcabado.TabIndex = 46
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(450, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 17)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Product Code"
        '
        'botonAcabado
        '
        Me.botonAcabado.Location = New System.Drawing.Point(386, 106)
        Me.botonAcabado.Name = "botonAcabado"
        Me.botonAcabado.Size = New System.Drawing.Size(36, 23)
        Me.botonAcabado.TabIndex = 47
        Me.botonAcabado.Text = "..."
        Me.botonAcabado.UseVisualStyleBackColor = True
        '
        'celdaCodigoProducto
        '
        Me.celdaCodigoProducto.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigoProducto.Location = New System.Drawing.Point(555, 16)
        Me.celdaCodigoProducto.Name = "celdaCodigoProducto"
        Me.celdaCodigoProducto.Size = New System.Drawing.Size(279, 22)
        Me.celdaCodigoProducto.TabIndex = 38
        Me.celdaCodigoProducto.Text = "-1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 17)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Title"
        '
        'celdaidPais
        '
        Me.celdaidPais.Location = New System.Drawing.Point(118, 73)
        Me.celdaidPais.Name = "celdaidPais"
        Me.celdaidPais.Size = New System.Drawing.Size(17, 22)
        Me.celdaidPais.TabIndex = 51
        Me.celdaidPais.Text = "-1"
        Me.celdaidPais.Visible = False
        '
        'celdaTitulo
        '
        Me.celdaTitulo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTitulo.Location = New System.Drawing.Point(143, 43)
        Me.celdaTitulo.Name = "celdaTitulo"
        Me.celdaTitulo.Size = New System.Drawing.Size(279, 22)
        Me.celdaTitulo.TabIndex = 41
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(450, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(117, 17)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "Short Description"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(466, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(63, 17)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "Spinning"
        '
        'celdaidAcabado
        '
        Me.celdaidAcabado.Location = New System.Drawing.Point(118, 105)
        Me.celdaidAcabado.Name = "celdaidAcabado"
        Me.celdaidAcabado.Size = New System.Drawing.Size(17, 22)
        Me.celdaidAcabado.TabIndex = 53
        Me.celdaidAcabado.Text = "-1"
        Me.celdaidAcabado.Visible = False
        '
        'celdaidClase
        '
        Me.celdaidClase.Location = New System.Drawing.Point(541, 110)
        Me.celdaidClase.Name = "celdaidClase"
        Me.celdaidClase.Size = New System.Drawing.Size(17, 22)
        Me.celdaidClase.TabIndex = 52
        Me.celdaidClase.Text = "-1"
        Me.celdaidClase.Visible = False
        '
        'celdaDescripcionCorta
        '
        Me.celdaDescripcionCorta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDescripcionCorta.Location = New System.Drawing.Point(573, 76)
        Me.celdaDescripcionCorta.Name = "celdaDescripcionCorta"
        Me.celdaDescripcionCorta.Size = New System.Drawing.Size(279, 22)
        Me.celdaDescripcionCorta.TabIndex = 44
        '
        'celdaidSpnning
        '
        Me.celdaidSpnning.Location = New System.Drawing.Point(541, 143)
        Me.celdaidSpnning.Name = "celdaidSpnning"
        Me.celdaidSpnning.Size = New System.Drawing.Size(17, 22)
        Me.celdaidSpnning.TabIndex = 54
        Me.celdaidSpnning.Text = "-1"
        Me.celdaidSpnning.Visible = False
        '
        'botonSpinning
        '
        Me.botonSpinning.Location = New System.Drawing.Point(826, 141)
        Me.botonSpinning.Name = "botonSpinning"
        Me.botonSpinning.Size = New System.Drawing.Size(36, 23)
        Me.botonSpinning.TabIndex = 50
        Me.botonSpinning.Text = "..."
        Me.botonSpinning.UseVisualStyleBackColor = True
        '
        'celdaSpinning
        '
        Me.celdaSpinning.Location = New System.Drawing.Point(573, 141)
        Me.celdaSpinning.Name = "celdaSpinning"
        Me.celdaSpinning.ReadOnly = True
        Me.celdaSpinning.Size = New System.Drawing.Size(247, 22)
        Me.celdaSpinning.TabIndex = 49
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 131)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 17)
        Me.Label9.TabIndex = 55
        Me.Label9.Text = "Region"
        '
        'celdaContinente
        '
        Me.celdaContinente.Location = New System.Drawing.Point(144, 133)
        Me.celdaContinente.Name = "celdaContinente"
        Me.celdaContinente.ReadOnly = True
        Me.celdaContinente.Size = New System.Drawing.Size(237, 22)
        Me.celdaContinente.TabIndex = 56
        '
        'celdaidCountry
        '
        Me.celdaidCountry.Location = New System.Drawing.Point(118, 134)
        Me.celdaidCountry.Name = "celdaidCountry"
        Me.celdaidCountry.Size = New System.Drawing.Size(17, 22)
        Me.celdaidCountry.TabIndex = 57
        Me.celdaidCountry.Text = "-1"
        Me.celdaidCountry.Visible = False
        '
        'botonContinente
        '
        Me.botonContinente.Location = New System.Drawing.Point(387, 133)
        Me.botonContinente.Name = "botonContinente"
        Me.botonContinente.Size = New System.Drawing.Size(36, 23)
        Me.botonContinente.TabIndex = 58
        Me.botonContinente.Text = "..."
        Me.botonContinente.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = CType(resources.GetObject("botonBuscar.Image"), System.Drawing.Image)
        Me.botonBuscar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.botonBuscar.Location = New System.Drawing.Point(670, 169)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(89, 31)
        Me.botonBuscar.TabIndex = 59
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'checkIncludeHeathers
        '
        Me.checkIncludeHeathers.AutoSize = True
        Me.checkIncludeHeathers.Location = New System.Drawing.Point(19, 183)
        Me.checkIncludeHeathers.Name = "checkIncludeHeathers"
        Me.checkIncludeHeathers.Size = New System.Drawing.Size(92, 21)
        Me.checkIncludeHeathers.TabIndex = 60
        Me.checkIncludeHeathers.Text = " Heathers"
        Me.checkIncludeHeathers.UseVisualStyleBackColor = True
        '
        'rbCadena1
        '
        Me.rbCadena1.AutoSize = True
        Me.rbCadena1.Location = New System.Drawing.Point(492, 44)
        Me.rbCadena1.Name = "rbCadena1"
        Me.rbCadena1.Size = New System.Drawing.Size(91, 21)
        Me.rbCadena1.TabIndex = 61
        Me.rbCadena1.Text = "Start With"
        Me.rbCadena1.UseVisualStyleBackColor = True
        '
        'rbCadenaInsr
        '
        Me.rbCadenaInsr.AutoSize = True
        Me.rbCadenaInsr.Checked = True
        Me.rbCadenaInsr.Location = New System.Drawing.Point(606, 44)
        Me.rbCadenaInsr.Name = "rbCadenaInsr"
        Me.rbCadenaInsr.Size = New System.Drawing.Size(81, 21)
        Me.rbCadenaInsr.TabIndex = 62
        Me.rbCadenaInsr.TabStop = True
        Me.rbCadenaInsr.Text = "Containt"
        Me.rbCadenaInsr.UseVisualStyleBackColor = True
        '
        'rbCadena3
        '
        Me.rbCadena3.AutoSize = True
        Me.rbCadena3.Location = New System.Drawing.Point(708, 44)
        Me.rbCadena3.Name = "rbCadena3"
        Me.rbCadena3.Size = New System.Drawing.Size(86, 21)
        Me.rbCadena3.TabIndex = 63
        Me.rbCadena3.Text = "End With"
        Me.rbCadena3.UseVisualStyleBackColor = True
        '
        'PanelFiltro
        '
        Me.PanelFiltro.Controls.Add(Me.celdaidEstado)
        Me.PanelFiltro.Controls.Add(Me.Label10)
        Me.PanelFiltro.Controls.Add(Me.botonEstado)
        Me.PanelFiltro.Controls.Add(Me.celdaEstado)
        Me.PanelFiltro.Controls.Add(Me.checkMuestra)
        Me.PanelFiltro.Controls.Add(Me.botonRefrescar)
        Me.PanelFiltro.Controls.Add(Me.rbCadena3)
        Me.PanelFiltro.Controls.Add(Me.rbCadenaInsr)
        Me.PanelFiltro.Controls.Add(Me.rbCadena1)
        Me.PanelFiltro.Controls.Add(Me.checkIncludeHeathers)
        Me.PanelFiltro.Controls.Add(Me.botonBuscar)
        Me.PanelFiltro.Controls.Add(Me.botonContinente)
        Me.PanelFiltro.Controls.Add(Me.celdaidCountry)
        Me.PanelFiltro.Controls.Add(Me.celdaContinente)
        Me.PanelFiltro.Controls.Add(Me.Label9)
        Me.PanelFiltro.Controls.Add(Me.celdaSpinning)
        Me.PanelFiltro.Controls.Add(Me.botonSpinning)
        Me.PanelFiltro.Controls.Add(Me.celdaidSpnning)
        Me.PanelFiltro.Controls.Add(Me.celdaDescripcionCorta)
        Me.PanelFiltro.Controls.Add(Me.celdaidClase)
        Me.PanelFiltro.Controls.Add(Me.celdaidAcabado)
        Me.PanelFiltro.Controls.Add(Me.Label8)
        Me.PanelFiltro.Controls.Add(Me.Label4)
        Me.PanelFiltro.Controls.Add(Me.celdaTitulo)
        Me.PanelFiltro.Controls.Add(Me.celdaidPais)
        Me.PanelFiltro.Controls.Add(Me.Label3)
        Me.PanelFiltro.Controls.Add(Me.celdaCodigoProducto)
        Me.PanelFiltro.Controls.Add(Me.botonAcabado)
        Me.PanelFiltro.Controls.Add(Me.Label2)
        Me.PanelFiltro.Controls.Add(Me.celdaAcabado)
        Me.PanelFiltro.Controls.Add(Me.celdaCodigoInventario)
        Me.PanelFiltro.Controls.Add(Me.Label7)
        Me.PanelFiltro.Controls.Add(Me.Label1)
        Me.PanelFiltro.Controls.Add(Me.botonClase)
        Me.PanelFiltro.Controls.Add(Me.Label5)
        Me.PanelFiltro.Controls.Add(Me.celdaClase)
        Me.PanelFiltro.Controls.Add(Me.celdaPais)
        Me.PanelFiltro.Controls.Add(Me.Label6)
        Me.PanelFiltro.Controls.Add(Me.botonPais)
        Me.PanelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelFiltro.Location = New System.Drawing.Point(0, 79)
        Me.PanelFiltro.Name = "PanelFiltro"
        Me.PanelFiltro.Size = New System.Drawing.Size(890, 207)
        Me.PanelFiltro.TabIndex = 2
        '
        'checkMuestra
        '
        Me.checkMuestra.AutoSize = True
        Me.checkMuestra.Location = New System.Drawing.Point(118, 183)
        Me.checkMuestra.Name = "checkMuestra"
        Me.checkMuestra.Size = New System.Drawing.Size(77, 21)
        Me.checkMuestra.TabIndex = 65
        Me.checkMuestra.Text = "Sample"
        Me.checkMuestra.UseVisualStyleBackColor = True
        '
        'botonRefrescar
        '
        Me.botonRefrescar.Location = New System.Drawing.Point(765, 169)
        Me.botonRefrescar.Name = "botonRefrescar"
        Me.botonRefrescar.Size = New System.Drawing.Size(74, 30)
        Me.botonRefrescar.TabIndex = 64
        Me.botonRefrescar.Text = "Reset "
        Me.botonRefrescar.UseVisualStyleBackColor = True
        '
        'celdaCodigoInventario
        '
        Me.celdaCodigoInventario.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigoInventario.Location = New System.Drawing.Point(143, 15)
        Me.celdaCodigoInventario.Name = "celdaCodigoInventario"
        Me.celdaCodigoInventario.ReadOnly = True
        Me.celdaCodigoInventario.Size = New System.Drawing.Size(279, 22)
        Me.celdaCodigoInventario.TabIndex = 34
        Me.celdaCodigoInventario.Text = "-1"
        '
        'Splitter1
        '
        Me.Splitter1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Splitter1.Location = New System.Drawing.Point(0, 286)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(890, 13)
        Me.Splitter1.TabIndex = 4
        Me.Splitter1.TabStop = False
        '
        'celdaEstado
        '
        Me.celdaEstado.Location = New System.Drawing.Point(144, 161)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.ReadOnly = True
        Me.celdaEstado.Size = New System.Drawing.Size(237, 22)
        Me.celdaEstado.TabIndex = 66
        '
        'botonEstado
        '
        Me.botonEstado.Location = New System.Drawing.Point(387, 160)
        Me.botonEstado.Name = "botonEstado"
        Me.botonEstado.Size = New System.Drawing.Size(36, 23)
        Me.botonEstado.TabIndex = 67
        Me.botonEstado.Text = "..."
        Me.botonEstado.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 160)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(48, 17)
        Me.Label10.TabIndex = 68
        Me.Label10.Text = "Status"
        '
        'celdaidEstado
        '
        Me.celdaidEstado.Location = New System.Drawing.Point(117, 161)
        Me.celdaidEstado.Name = "celdaidEstado"
        Me.celdaidEstado.Size = New System.Drawing.Size(17, 22)
        Me.celdaidEstado.TabIndex = 69
        Me.celdaidEstado.Text = "-1"
        Me.celdaidEstado.Visible = False
        '
        'FrmInventario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(890, 539)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.PanelFiltro)
        Me.Controls.Add(Me.PanelEncabezado)
        Me.Name = "FrmInventario"
        Me.Text = "FrmInventario"
        Me.PanelEncabezado.ResumeLayout(False)
        Me.PanelFiltro.ResumeLayout(False)
        Me.PanelFiltro.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelEncabezado As Panel
    Friend WithEvents botonCerrar As Button
    Friend WithEvents botonExportar As Button
    Friend WithEvents botonGuardar As Button
    Friend WithEvents botonPrevia As Button
    Friend WithEvents botonImprimir As Button
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents botonPais As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents celdaPais As TextBox
    Friend WithEvents celdaClase As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents botonClase As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents celdaAcabado As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents botonAcabado As Button
    Friend WithEvents celdaCodigoProducto As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaidPais As TextBox
    Friend WithEvents celdaTitulo As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaidAcabado As TextBox
    Friend WithEvents celdaidClase As TextBox
    Friend WithEvents celdaDescripcionCorta As TextBox
    Friend WithEvents celdaidSpnning As TextBox
    Friend WithEvents botonSpinning As Button
    Friend WithEvents celdaSpinning As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaContinente As TextBox
    Friend WithEvents celdaidCountry As TextBox
    Friend WithEvents botonContinente As Button
    Friend WithEvents botonBuscar As Button
    Friend WithEvents checkIncludeHeathers As System.Windows.Forms.CheckBox
    Friend WithEvents rbCadena1 As RadioButton
    Friend WithEvents rbCadenaInsr As RadioButton
    Friend WithEvents rbCadena3 As RadioButton
    Friend WithEvents PanelFiltro As Panel
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents botonRefrescar As Button
    Friend WithEvents celdaCodigoInventario As TextBox
    Friend WithEvents checkMuestra As System.Windows.Forms.CheckBox
    Friend WithEvents celdaidEstado As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents botonEstado As Button
    Friend WithEvents celdaEstado As TextBox
End Class
