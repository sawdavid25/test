﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmReporteIngresoPorFabricante
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaIdNombre = New System.Windows.Forms.TextBox()
        Me.botonNombre = New System.Windows.Forms.Button()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonContinuar = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.panelCheck = New System.Windows.Forms.Panel()
        Me.check2 = New System.Windows.Forms.CheckBox()
        Me.checkDocumentos = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.panelCheck.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaIdNombre)
        Me.GroupBox1.Controls.Add(Me.botonNombre)
        Me.GroupBox1.Controls.Add(Me.celdaNombre)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 30)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(431, 84)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Name"
        '
        'celdaIdNombre
        '
        Me.celdaIdNombre.Enabled = False
        Me.celdaIdNombre.Location = New System.Drawing.Point(195, 6)
        Me.celdaIdNombre.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIdNombre.Name = "celdaIdNombre"
        Me.celdaIdNombre.Size = New System.Drawing.Size(36, 22)
        Me.celdaIdNombre.TabIndex = 4
        Me.celdaIdNombre.Text = "-1"
        Me.celdaIdNombre.Visible = False
        '
        'botonNombre
        '
        Me.botonNombre.Location = New System.Drawing.Point(376, 32)
        Me.botonNombre.Margin = New System.Windows.Forms.Padding(4)
        Me.botonNombre.Name = "botonNombre"
        Me.botonNombre.Size = New System.Drawing.Size(47, 28)
        Me.botonNombre.TabIndex = 1
        Me.botonNombre.Text = "..."
        Me.botonNombre.UseVisualStyleBackColor = True
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(20, 36)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.ReadOnly = True
        Me.celdaNombre.Size = New System.Drawing.Size(341, 22)
        Me.celdaNombre.TabIndex = 0
        Me.celdaNombre.Text = "TODO"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.dtpFechaFinal)
        Me.GroupBox2.Controls.Add(Me.dtpFechaInicio)
        Me.GroupBox2.Location = New System.Drawing.Point(16, 121)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(389, 75)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(195, 37)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Until"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(8, 37)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Since"
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(249, 36)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(112, 22)
        Me.dtpFechaFinal.TabIndex = 1
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(71, 36)
        Me.dtpFechaInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpFechaInicio.TabIndex = 0
        '
        'botonContinuar
        '
        Me.botonContinuar.Location = New System.Drawing.Point(99, 286)
        Me.botonContinuar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonContinuar.Name = "botonContinuar"
        Me.botonContinuar.Size = New System.Drawing.Size(100, 28)
        Me.botonContinuar.TabIndex = 2
        Me.botonContinuar.Text = "Continue"
        Me.botonContinuar.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(214, 286)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(100, 28)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Cancel"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'panelCheck
        '
        Me.panelCheck.Controls.Add(Me.check2)
        Me.panelCheck.Controls.Add(Me.checkDocumentos)
        Me.panelCheck.Location = New System.Drawing.Point(16, 201)
        Me.panelCheck.Name = "panelCheck"
        Me.panelCheck.Size = New System.Drawing.Size(389, 85)
        Me.panelCheck.TabIndex = 4
        Me.panelCheck.Visible = False
        '
        'check2
        '
        Me.check2.AutoSize = True
        Me.check2.Location = New System.Drawing.Point(11, 33)
        Me.check2.Name = "check2"
        Me.check2.Size = New System.Drawing.Size(100, 21)
        Me.check2.TabIndex = 1
        Me.check2.Text = "CheckBox1"
        Me.check2.UseVisualStyleBackColor = True
        Me.check2.Visible = False
        '
        'checkDocumentos
        '
        Me.checkDocumentos.AutoSize = True
        Me.checkDocumentos.Checked = True
        Me.checkDocumentos.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkDocumentos.Location = New System.Drawing.Point(11, 3)
        Me.checkDocumentos.Name = "checkDocumentos"
        Me.checkDocumentos.Size = New System.Drawing.Size(100, 21)
        Me.checkDocumentos.TabIndex = 0
        Me.checkDocumentos.Text = "CheckBox1"
        Me.checkDocumentos.UseVisualStyleBackColor = True
        Me.checkDocumentos.Visible = False
        '
        'frmReporteIngresoPorFabricante
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(483, 323)
        Me.Controls.Add(Me.panelCheck)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.botonContinuar)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmReporteIngresoPorFabricante"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Filter"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.panelCheck.ResumeLayout(False)
        Me.panelCheck.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents botonNombre As Button
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicio As DateTimePicker
    Friend WithEvents botonContinuar As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents celdaIdNombre As TextBox
    Friend WithEvents panelCheck As Panel
    Friend WithEvents checkDocumentos As System.Windows.Forms.CheckBox
    Friend WithEvents check2 As System.Windows.Forms.CheckBox
End Class
