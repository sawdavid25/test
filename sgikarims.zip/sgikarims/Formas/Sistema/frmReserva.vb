﻿Public Class frmReserva

#Region "Variables"

    Private Const IDX_DISPONIBLE As Byte = 2
    Private Const IDX_CANTIDAD As Byte = 3
    Private Const IDX_NOTA As Byte = 4

    Private dblSaldo As Double
    Private dblReserva As Double
    Private dblDisponible As Double
    Private dblDespachado As Double

    Private logModificado As Boolean
    Private logApartado As Boolean

    Private intEmpresa As Integer
    Private intCatalogo As Integer
    Private intAno As Integer
    Private intNumero As Integer
    Private intLinea As Integer
    Private intCodMedida As Integer
    Private strInfo As String
    Private strReferencia As String

#End Region

#Region "Propiedades"

    Public Property Apartado As Boolean
        Get
            Return logApartado
        End Get
        Set(value As Boolean)
            logApartado = value
        End Set
    End Property

    Public Property Modificado()
        Get
            Return logModificado
        End Get
        Set(value)
            logModificado = value
        End Set
    End Property

    Public Property codMedida As Integer
        Get
            Return intCodMedida
        End Get
        Set(value As Integer)
            intCodMedida = value
        End Set
    End Property

    ReadOnly Property Cantidad
        Get
            Return Val(IDX_DISPONIBLE)
        End Get
    End Property

    Public Property Empresa As Integer
        Get
            Return intEmpresa
        End Get
        Set(value As Integer)
            intEmpresa = value
        End Set
    End Property

    Public Property Catalogo As Integer
        Get
            Return intCatalogo
        End Get
        Set(value As Integer)
            intCatalogo = value
        End Set
    End Property

    Public Property Año As Integer
        Get
            Return intAno
        End Get
        Set(value As Integer)
            intAno = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return intNumero
        End Get
        Set(value As Integer)
            intNumero = value
        End Set
    End Property

    Public Property Linea As Integer
        Get
            Return intLinea
        End Get
        Set(value As Integer)
            intLinea = value
        End Set
    End Property

    Public Property Info As String
        Get
            Return strInfo
        End Get
        Set(value As String)
            strInfo = value
        End Set
    End Property

    Public Property Referencia As String
        Get
            Return strReferencia
        End Get
        Set(value As String)
            strReferencia = value
        End Set
    End Property

#End Region

#Region "Funciones"

#End Region

#Region "Procedimientos"

    Private Sub CargarCampos()

        lblreferencia.Text = strReferencia
        txtDescripcion.Text = Info

    End Sub

    Private Sub Inciar()

        'Dim intDescargo As Integer
        Dim strSQL As String

        strSQL = " "

    End Sub

#End Region

#Region "Eventos de Visual Basic"

    Private Sub btnCerrar_Click(sender As Object, e As EventArgs) Handles btnCerrar.Click
        Me.Close()
    End Sub

    Private Sub btnCustomer_Click(sender As Object, e As EventArgs) Handles btnCustomer.Click
        Dim frm As New frmSeleccionar

        frm.Tabla = "Clientes"
        frm.Condicion = "cli_sisemp=" & Sesion.IdEmpresa
        frm.Campos = "cli_codigo,cli_cliente,cli_direccion,cli_moneda"
        frm.Filtro = "cli_cliente"
        frm.Titulo = "Cliente"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            CeldaCodCodigo.Text = frm.LLave
            CeldaCustomer.Text = frm.Dato
        End If
    End Sub

    Private Sub frmReserva_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargarCampos()
    End Sub

#End Region
  
End Class

