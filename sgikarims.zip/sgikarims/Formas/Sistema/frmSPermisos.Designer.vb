﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSPermisos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgvPermisosAsignados = New System.Windows.Forms.DataGridView()
        Me.a_pro_codigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.a_pro_descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.seg_insertar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.seg_editar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.seg_borrar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.seg_buscar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgvPermisosDisponibles = New System.Windows.Forms.DataGridView()
        Me.pro_codigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pro_descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.panelUsuarioOriginal = New System.Windows.Forms.Panel()
        Me.lbl_usuarioOriginal = New System.Windows.Forms.Label()
        Me.celdausuarioIDOriginal = New System.Windows.Forms.TextBox()
        Me.celdaUsuarioOriginal = New System.Windows.Forms.TextBox()
        Me.botonUsuarioOriginal = New System.Windows.Forms.Button()
        Me.chkCopiarAccesos = New System.Windows.Forms.CheckBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.btnPuesto = New System.Windows.Forms.Button()
        Me.celdaIdPuesto = New System.Windows.Forms.TextBox()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.etiquetaContraseña = New System.Windows.Forms.Label()
        Me.celdaContraseña = New System.Windows.Forms.TextBox()
        Me.etiquetaPuesto = New System.Windows.Forms.Label()
        Me.celdaPuesto = New System.Windows.Forms.TextBox()
        Me.etiquetaCorreo = New System.Windows.Forms.Label()
        Me.celdaCorreo = New System.Windows.Forms.TextBox()
        Me.etiquetaSegundoApellido = New System.Windows.Forms.Label()
        Me.celdaSegundoApellido = New System.Windows.Forms.TextBox()
        Me.etiquetaSegundoNombre = New System.Windows.Forms.Label()
        Me.celdaSegundoNombre = New System.Windows.Forms.TextBox()
        Me.etiquetaPrimerApellido = New System.Windows.Forms.Label()
        Me.celdaPrimerApellido = New System.Windows.Forms.TextBox()
        Me.etiquetaPrimerNombre = New System.Windows.Forms.Label()
        Me.celdaPrimerNombre = New System.Windows.Forms.TextBox()
        Me.celdaIdUsuario = New System.Windows.Forms.TextBox()
        Me.botonUsuario = New System.Windows.Forms.Button()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Panel1.SuspendLayout()
        CType(Me.dgvPermisosAsignados, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvPermisosDisponibles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelUsuarioOriginal.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dgvPermisosAsignados)
        Me.Panel1.Controls.Add(Me.dgvPermisosDisponibles)
        Me.Panel1.Location = New System.Drawing.Point(0, 191)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1008, 336)
        Me.Panel1.TabIndex = 16
        '
        'dgvPermisosAsignados
        '
        Me.dgvPermisosAsignados.AllowUserToAddRows = False
        Me.dgvPermisosAsignados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvPermisosAsignados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPermisosAsignados.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.a_pro_codigo, Me.a_pro_descripcion, Me.seg_insertar, Me.seg_editar, Me.seg_borrar, Me.seg_buscar})
        Me.dgvPermisosAsignados.Dock = System.Windows.Forms.DockStyle.Right
        Me.dgvPermisosAsignados.Location = New System.Drawing.Point(345, 0)
        Me.dgvPermisosAsignados.Name = "dgvPermisosAsignados"
        Me.dgvPermisosAsignados.Size = New System.Drawing.Size(663, 336)
        Me.dgvPermisosAsignados.TabIndex = 1
        '
        'a_pro_codigo
        '
        Me.a_pro_codigo.HeaderText = "Codigo"
        Me.a_pro_codigo.Name = "a_pro_codigo"
        Me.a_pro_codigo.ReadOnly = True
        '
        'a_pro_descripcion
        '
        Me.a_pro_descripcion.HeaderText = "Programa"
        Me.a_pro_descripcion.Name = "a_pro_descripcion"
        Me.a_pro_descripcion.ReadOnly = True
        '
        'seg_insertar
        '
        Me.seg_insertar.HeaderText = "insertar"
        Me.seg_insertar.Name = "seg_insertar"
        Me.seg_insertar.ReadOnly = True
        '
        'seg_editar
        '
        Me.seg_editar.HeaderText = "editar"
        Me.seg_editar.Name = "seg_editar"
        '
        'seg_borrar
        '
        Me.seg_borrar.HeaderText = "borrar"
        Me.seg_borrar.Name = "seg_borrar"
        '
        'seg_buscar
        '
        Me.seg_buscar.HeaderText = "buscar"
        Me.seg_buscar.Name = "seg_buscar"
        '
        'dgvPermisosDisponibles
        '
        Me.dgvPermisosDisponibles.AllowUserToAddRows = False
        Me.dgvPermisosDisponibles.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvPermisosDisponibles.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells
        Me.dgvPermisosDisponibles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPermisosDisponibles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.pro_codigo, Me.pro_descripcion})
        Me.dgvPermisosDisponibles.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgvPermisosDisponibles.Location = New System.Drawing.Point(0, 0)
        Me.dgvPermisosDisponibles.Name = "dgvPermisosDisponibles"
        Me.dgvPermisosDisponibles.Size = New System.Drawing.Size(319, 336)
        Me.dgvPermisosDisponibles.TabIndex = 0
        '
        'pro_codigo
        '
        Me.pro_codigo.HeaderText = "Codigo"
        Me.pro_codigo.Name = "pro_codigo"
        Me.pro_codigo.ReadOnly = True
        '
        'pro_descripcion
        '
        Me.pro_descripcion.HeaderText = "Programa"
        Me.pro_descripcion.Name = "pro_descripcion"
        Me.pro_descripcion.ReadOnly = True
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.panelUsuarioOriginal)
        Me.Panel2.Controls.Add(Me.chkCopiarAccesos)
        Me.Panel2.Controls.Add(Me.dtpFecha)
        Me.Panel2.Controls.Add(Me.etiquetaFecha)
        Me.Panel2.Controls.Add(Me.btnPuesto)
        Me.Panel2.Controls.Add(Me.celdaIdPuesto)
        Me.Panel2.Controls.Add(Me.checkActivar)
        Me.Panel2.Controls.Add(Me.etiquetaContraseña)
        Me.Panel2.Controls.Add(Me.celdaContraseña)
        Me.Panel2.Controls.Add(Me.etiquetaPuesto)
        Me.Panel2.Controls.Add(Me.celdaPuesto)
        Me.Panel2.Controls.Add(Me.etiquetaCorreo)
        Me.Panel2.Controls.Add(Me.celdaCorreo)
        Me.Panel2.Controls.Add(Me.etiquetaSegundoApellido)
        Me.Panel2.Controls.Add(Me.celdaSegundoApellido)
        Me.Panel2.Controls.Add(Me.etiquetaSegundoNombre)
        Me.Panel2.Controls.Add(Me.celdaSegundoNombre)
        Me.Panel2.Controls.Add(Me.etiquetaPrimerApellido)
        Me.Panel2.Controls.Add(Me.celdaPrimerApellido)
        Me.Panel2.Controls.Add(Me.etiquetaPrimerNombre)
        Me.Panel2.Controls.Add(Me.celdaPrimerNombre)
        Me.Panel2.Controls.Add(Me.celdaIdUsuario)
        Me.Panel2.Controls.Add(Me.botonUsuario)
        Me.Panel2.Controls.Add(Me.celdaUsuario)
        Me.Panel2.Controls.Add(Me.etiquetaUsuario)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 72)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1352, 113)
        Me.Panel2.TabIndex = 1
        '
        'panelUsuarioOriginal
        '
        Me.panelUsuarioOriginal.Controls.Add(Me.lbl_usuarioOriginal)
        Me.panelUsuarioOriginal.Controls.Add(Me.celdausuarioIDOriginal)
        Me.panelUsuarioOriginal.Controls.Add(Me.celdaUsuarioOriginal)
        Me.panelUsuarioOriginal.Controls.Add(Me.botonUsuarioOriginal)
        Me.panelUsuarioOriginal.Location = New System.Drawing.Point(968, 40)
        Me.panelUsuarioOriginal.Name = "panelUsuarioOriginal"
        Me.panelUsuarioOriginal.Size = New System.Drawing.Size(300, 46)
        Me.panelUsuarioOriginal.TabIndex = 43
        Me.panelUsuarioOriginal.Visible = False
        '
        'lbl_usuarioOriginal
        '
        Me.lbl_usuarioOriginal.AutoSize = True
        Me.lbl_usuarioOriginal.Location = New System.Drawing.Point(6, 9)
        Me.lbl_usuarioOriginal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbl_usuarioOriginal.Name = "lbl_usuarioOriginal"
        Me.lbl_usuarioOriginal.Size = New System.Drawing.Size(94, 13)
        Me.lbl_usuarioOriginal.TabIndex = 39
        Me.lbl_usuarioOriginal.Text = "Usuario Original:(*)"
        '
        'celdausuarioIDOriginal
        '
        Me.celdausuarioIDOriginal.Location = New System.Drawing.Point(104, 7)
        Me.celdausuarioIDOriginal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdausuarioIDOriginal.Name = "celdausuarioIDOriginal"
        Me.celdausuarioIDOriginal.ReadOnly = True
        Me.celdausuarioIDOriginal.Size = New System.Drawing.Size(34, 20)
        Me.celdausuarioIDOriginal.TabIndex = 40
        '
        'celdaUsuarioOriginal
        '
        Me.celdaUsuarioOriginal.Location = New System.Drawing.Point(142, 7)
        Me.celdaUsuarioOriginal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaUsuarioOriginal.Name = "celdaUsuarioOriginal"
        Me.celdaUsuarioOriginal.Size = New System.Drawing.Size(132, 20)
        Me.celdaUsuarioOriginal.TabIndex = 41
        '
        'botonUsuarioOriginal
        '
        Me.botonUsuarioOriginal.Location = New System.Drawing.Point(275, 7)
        Me.botonUsuarioOriginal.Margin = New System.Windows.Forms.Padding(2)
        Me.botonUsuarioOriginal.Name = "botonUsuarioOriginal"
        Me.botonUsuarioOriginal.Size = New System.Drawing.Size(25, 19)
        Me.botonUsuarioOriginal.TabIndex = 42
        Me.botonUsuarioOriginal.Text = "..."
        Me.botonUsuarioOriginal.UseVisualStyleBackColor = True
        '
        'chkCopiarAccesos
        '
        Me.chkCopiarAccesos.AutoSize = True
        Me.chkCopiarAccesos.Location = New System.Drawing.Point(969, 22)
        Me.chkCopiarAccesos.Name = "chkCopiarAccesos"
        Me.chkCopiarAccesos.Size = New System.Drawing.Size(107, 17)
        Me.chkCopiarAccesos.TabIndex = 38
        Me.chkCopiarAccesos.Text = "Agregar Accesos"
        Me.chkCopiarAccesos.UseVisualStyleBackColor = True
        Me.chkCopiarAccesos.Visible = False
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(426, 18)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(94, 20)
        Me.dtpFecha.TabIndex = 21
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(342, 24)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(50, 13)
        Me.etiquetaFecha.TabIndex = 37
        Me.etiquetaFecha.Text = "Fecha:(*)"
        '
        'btnPuesto
        '
        Me.btnPuesto.Location = New System.Drawing.Point(909, 46)
        Me.btnPuesto.Margin = New System.Windows.Forms.Padding(2)
        Me.btnPuesto.Name = "btnPuesto"
        Me.btnPuesto.Size = New System.Drawing.Size(25, 19)
        Me.btnPuesto.TabIndex = 17
        Me.btnPuesto.Text = "..."
        Me.btnPuesto.UseVisualStyleBackColor = True
        '
        'celdaIdPuesto
        '
        Me.celdaIdPuesto.Location = New System.Drawing.Point(694, 45)
        Me.celdaIdPuesto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdPuesto.Name = "celdaIdPuesto"
        Me.celdaIdPuesto.ReadOnly = True
        Me.celdaIdPuesto.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdPuesto.TabIndex = 15
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(540, 21)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(59, 17)
        Me.checkActivar.TabIndex = 20
        Me.checkActivar.Text = "Estado"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'etiquetaContraseña
        '
        Me.etiquetaContraseña.AutoSize = True
        Me.etiquetaContraseña.Location = New System.Drawing.Point(638, 73)
        Me.etiquetaContraseña.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaContraseña.Name = "etiquetaContraseña"
        Me.etiquetaContraseña.Size = New System.Drawing.Size(74, 13)
        Me.etiquetaContraseña.TabIndex = 18
        Me.etiquetaContraseña.Text = "Contraseña:(*)"
        '
        'celdaContraseña
        '
        Me.celdaContraseña.Location = New System.Drawing.Point(732, 70)
        Me.celdaContraseña.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaContraseña.Name = "celdaContraseña"
        Me.celdaContraseña.Size = New System.Drawing.Size(202, 20)
        Me.celdaContraseña.TabIndex = 19
        '
        'etiquetaPuesto
        '
        Me.etiquetaPuesto.AutoSize = True
        Me.etiquetaPuesto.Location = New System.Drawing.Point(638, 48)
        Me.etiquetaPuesto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaPuesto.Name = "etiquetaPuesto"
        Me.etiquetaPuesto.Size = New System.Drawing.Size(53, 13)
        Me.etiquetaPuesto.TabIndex = 14
        Me.etiquetaPuesto.Text = "Puesto:(*)"
        '
        'celdaPuesto
        '
        Me.celdaPuesto.Location = New System.Drawing.Point(732, 45)
        Me.celdaPuesto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPuesto.Name = "celdaPuesto"
        Me.celdaPuesto.ReadOnly = True
        Me.celdaPuesto.Size = New System.Drawing.Size(173, 20)
        Me.celdaPuesto.TabIndex = 16
        '
        'etiquetaCorreo
        '
        Me.etiquetaCorreo.AutoSize = True
        Me.etiquetaCorreo.Location = New System.Drawing.Point(638, 24)
        Me.etiquetaCorreo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCorreo.Name = "etiquetaCorreo"
        Me.etiquetaCorreo.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCorreo.TabIndex = 12
        Me.etiquetaCorreo.Text = "Correo:(*)"
        '
        'celdaCorreo
        '
        Me.celdaCorreo.Location = New System.Drawing.Point(732, 21)
        Me.celdaCorreo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCorreo.Name = "celdaCorreo"
        Me.celdaCorreo.Size = New System.Drawing.Size(202, 20)
        Me.celdaCorreo.TabIndex = 13
        '
        'etiquetaSegundoApellido
        '
        Me.etiquetaSegundoApellido.AutoSize = True
        Me.etiquetaSegundoApellido.Location = New System.Drawing.Point(332, 73)
        Me.etiquetaSegundoApellido.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSegundoApellido.Name = "etiquetaSegundoApellido"
        Me.etiquetaSegundoApellido.Size = New System.Drawing.Size(90, 13)
        Me.etiquetaSegundoApellido.TabIndex = 10
        Me.etiquetaSegundoApellido.Text = "Segundo Apellido"
        '
        'celdaSegundoApellido
        '
        Me.celdaSegundoApellido.Location = New System.Drawing.Point(426, 70)
        Me.celdaSegundoApellido.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSegundoApellido.Name = "celdaSegundoApellido"
        Me.celdaSegundoApellido.Size = New System.Drawing.Size(173, 20)
        Me.celdaSegundoApellido.TabIndex = 11
        '
        'etiquetaSegundoNombre
        '
        Me.etiquetaSegundoNombre.AutoSize = True
        Me.etiquetaSegundoNombre.Location = New System.Drawing.Point(332, 48)
        Me.etiquetaSegundoNombre.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSegundoNombre.Name = "etiquetaSegundoNombre"
        Me.etiquetaSegundoNombre.Size = New System.Drawing.Size(90, 13)
        Me.etiquetaSegundoNombre.TabIndex = 6
        Me.etiquetaSegundoNombre.Text = "Segundo Nombre"
        '
        'celdaSegundoNombre
        '
        Me.celdaSegundoNombre.Location = New System.Drawing.Point(426, 45)
        Me.celdaSegundoNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSegundoNombre.Name = "celdaSegundoNombre"
        Me.celdaSegundoNombre.Size = New System.Drawing.Size(173, 20)
        Me.celdaSegundoNombre.TabIndex = 7
        '
        'etiquetaPrimerApellido
        '
        Me.etiquetaPrimerApellido.AutoSize = True
        Me.etiquetaPrimerApellido.Location = New System.Drawing.Point(28, 73)
        Me.etiquetaPrimerApellido.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaPrimerApellido.Name = "etiquetaPrimerApellido"
        Me.etiquetaPrimerApellido.Size = New System.Drawing.Size(89, 13)
        Me.etiquetaPrimerApellido.TabIndex = 8
        Me.etiquetaPrimerApellido.Text = "Primer Apellido:(*)"
        '
        'celdaPrimerApellido
        '
        Me.celdaPrimerApellido.Location = New System.Drawing.Point(121, 70)
        Me.celdaPrimerApellido.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPrimerApellido.Name = "celdaPrimerApellido"
        Me.celdaPrimerApellido.Size = New System.Drawing.Size(198, 20)
        Me.celdaPrimerApellido.TabIndex = 9
        '
        'etiquetaPrimerNombre
        '
        Me.etiquetaPrimerNombre.AutoSize = True
        Me.etiquetaPrimerNombre.Location = New System.Drawing.Point(28, 48)
        Me.etiquetaPrimerNombre.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaPrimerNombre.Name = "etiquetaPrimerNombre"
        Me.etiquetaPrimerNombre.Size = New System.Drawing.Size(89, 13)
        Me.etiquetaPrimerNombre.TabIndex = 4
        Me.etiquetaPrimerNombre.Text = "Primer Nombre:(*)"
        '
        'celdaPrimerNombre
        '
        Me.celdaPrimerNombre.Location = New System.Drawing.Point(121, 45)
        Me.celdaPrimerNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPrimerNombre.Name = "celdaPrimerNombre"
        Me.celdaPrimerNombre.Size = New System.Drawing.Size(198, 20)
        Me.celdaPrimerNombre.TabIndex = 5
        '
        'celdaIdUsuario
        '
        Me.celdaIdUsuario.Location = New System.Drawing.Point(83, 21)
        Me.celdaIdUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdUsuario.Name = "celdaIdUsuario"
        Me.celdaIdUsuario.ReadOnly = True
        Me.celdaIdUsuario.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdUsuario.TabIndex = 1
        '
        'botonUsuario
        '
        Me.botonUsuario.Location = New System.Drawing.Point(294, 22)
        Me.botonUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.botonUsuario.Name = "botonUsuario"
        Me.botonUsuario.Size = New System.Drawing.Size(25, 19)
        Me.botonUsuario.TabIndex = 3
        Me.botonUsuario.Text = "..."
        Me.botonUsuario.UseVisualStyleBackColor = True
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(121, 21)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(170, 20)
        Me.celdaUsuario.TabIndex = 2
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(28, 24)
        Me.etiquetaUsuario.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(56, 13)
        Me.etiquetaUsuario.TabIndex = 0
        Me.etiquetaUsuario.Text = "Usuario:(*)"
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1352, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmSPermisos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1352, 604)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Encabezado1)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmSPermisos"
        Me.Text = "frmSPermisos"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgvPermisosAsignados, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvPermisosDisponibles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.panelUsuarioOriginal.ResumeLayout(False)
        Me.panelUsuarioOriginal.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgvPermisosAsignados As DataGridView
    Friend WithEvents dgvPermisosDisponibles As DataGridView
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents a_pro_codigo As DataGridViewTextBoxColumn
    Friend WithEvents a_pro_descripcion As DataGridViewTextBoxColumn
    Friend WithEvents seg_insertar As DataGridViewTextBoxColumn
    Friend WithEvents seg_editar As DataGridViewTextBoxColumn
    Friend WithEvents seg_borrar As DataGridViewTextBoxColumn
    Friend WithEvents seg_buscar As DataGridViewTextBoxColumn
    Friend WithEvents pro_codigo As DataGridViewTextBoxColumn
    Friend WithEvents pro_descripcion As DataGridViewTextBoxColumn
    Friend WithEvents Panel2 As Panel
    Friend WithEvents celdaIdUsuario As TextBox
    Friend WithEvents botonUsuario As Button
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents etiquetaUsuario As Label
    Friend WithEvents etiquetaSegundoApellido As Label
    Friend WithEvents celdaSegundoApellido As TextBox
    Friend WithEvents etiquetaSegundoNombre As Label
    Friend WithEvents celdaSegundoNombre As TextBox
    Friend WithEvents etiquetaPrimerApellido As Label
    Friend WithEvents celdaPrimerApellido As TextBox
    Friend WithEvents etiquetaPrimerNombre As Label
    Friend WithEvents celdaPrimerNombre As TextBox
    Friend WithEvents etiquetaContraseña As Label
    Friend WithEvents celdaContraseña As TextBox
    Friend WithEvents etiquetaPuesto As Label
    Friend WithEvents celdaPuesto As TextBox
    Friend WithEvents etiquetaCorreo As Label
    Friend WithEvents celdaCorreo As TextBox
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents btnPuesto As Button
    Friend WithEvents celdaIdPuesto As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents panelUsuarioOriginal As Panel
    Friend WithEvents lbl_usuarioOriginal As Label
    Friend WithEvents celdausuarioIDOriginal As TextBox
    Friend WithEvents celdaUsuarioOriginal As TextBox
    Friend WithEvents botonUsuarioOriginal As Button
    Friend WithEvents chkCopiarAccesos As System.Windows.Forms.CheckBox
End Class
