﻿Public Class frmXDocumento
#Region "Variables"
    Dim strFechaInicio As Date
    ' Dim strFechaFin As Date
    Dim dtFechaFin As Date
    Dim strCuenta As String
#End Region
#Region "Propiedades"
    Public WriteOnly Property FechaInicio As Date
        Set(value As Date)
            strFechaInicio = value
        End Set
    End Property
    Public WriteOnly Property FechaFinal As Date
        Set(value As Date)
            dtFechaFin = value
        End Set
    End Property
    'Public Property FechaFin As Date
    '    Get
    '        Return strFechaFin
    '    End Get
    '    Set(value As Date)
    '        strFechaFin = value
    '    End Set
    'End Property

    Public WriteOnly Property Cuenta As String
        Set(value As String)
            strCuenta = value
        End Set
    End Property

#End Region
#Region "Funciones"
    Public Sub reset()
        celdaDolar.Text = STR_VACIO
        celdaQuetzales.Text = STR_VACIO
    End Sub
    Private Function SQLDatosCuenta() As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Doc_Fec Fecha, c.cat_desc Tipo, h.HDoc_DR1_Num Numero, h.HDoc_Emp_Nom Nombre, h.HDoc_RF1_Cod Concepto, "
        strSQL &= "     m.cat_clave Moneda, d.tasa Tasa, h.HDoc_RF1_Dbl Monto, ROUND(d.importe_ext,2) Ext, ROUND(d.importe_loc,2) Loc "
        strSQL &= "         FROM {conta}.detalle_presupuesto d "
        strSQL &= "             LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.empresa AND h.HDoc_Doc_Cat = d.categoria AND h.HDoc_Doc_Ano = d.ano AND h.HDoc_Doc_Num = d.numero "
        strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Cat "
        strSQL &= "                     LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon "
        strSQL &= "                         WHERE d.empresa = {empresa} AND d.cuenta = '{cuenta}' AND d.fecha BETWEEN '{fechainicio}' AND '{fechafin}' AND h.HDoc_Doc_Status <3 "
        strSQL &= "                             	ORDER BY d.fecha "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{cuenta}", strCuenta)
        strSQL = Replace(strSQL, "{fechainicio}", strFechaInicio.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafin}", dtFechaFin.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarDetalle()
        Dim strSQL As String = STR_VACIO
        Dim dblTotal(5) As Double
        Dim strFila As String = STR_VACIO
        Dim i As Integer = INT_CERO
        'Conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLDatosCuenta()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDocumento.Rows.Clear()
                Do While REA.Read
                    i = i + 1
                    strFila = i & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Tipo") & "|"
                    strFila &= REA.GetString("Numero") & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetString("Concepto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("Tasa") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetDouble("Ext") & "|"
                    strFila &= REA.GetDouble("Loc")
                    dblTotal(0) = dblTotal(0) + REA.GetDouble("Ext")
                    dblTotal(1) = dblTotal(1) + REA.GetDouble("Loc")
                    cFunciones.AgregarFila(dgDocumento, strFila)
                Loop
            End If
            REA.Close()
            COM = Nothing
            etiquetaQuetzal.Text = cFunciones.SimboloMoneda(cFunciones.DivisaLocal)
            celdaDolar.Text = dblTotal(0).ToString(FORMATO_MONEDA)
            celdaQuetzales.Text = dblTotal(1).ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
#Region "Evento"
    Private Sub frmXDocumento_Load(sender As Object, e As EventArgs) Handles Me.Load
        reset()
        CargarDetalle()
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub
#End Region

End Class