﻿Imports System.ComponentModel

Public Class frmReporte
    Dim strTemp As String
    Dim strKey As String

    Public Property key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
    Public WriteOnly Property ArchivoTemporal As String
        Set(value As String)
            strTemp = value
        End Set
    End Property
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Try
            WebBrowser1.ShowPrintDialog()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonPrevia_Click(sender As Object, e As EventArgs) Handles botonPrevia.Click
        Try
            WebBrowser1.ShowPrintPreviewDialog()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        WebBrowser1.ShowSaveAsDialog()
    End Sub

    Private Sub frmReporte_Load(sender As Object, e As EventArgs) Handles Me.Load
        WebBrowser1.Navigate(strTemp)
        botonExportarWord.Visible = permiteWord
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        permiteWord = False
        Me.Close()
    End Sub

    Private Sub botonExportar_Click(sender As Object, e As EventArgs) Handles botonExportar.Click

        exportar()

        'Dim obj As Object

        'Try
        '    obj = CreateObject("Excel.Application")
        '    obj.Workbooks.Open(strTemp)
        '    obj.visible = True

        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'End Try

    End Sub
    Public Function exportar(Optional opcion As Integer = 0)
        If opcion = 0 Then
            Dim obj As Object
            Try
                obj = CreateObject("Excel.Application")
                obj.Workbooks.Open(strTemp)
                obj.visible = True

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            Try
                Dim rutaHtml As String = strTemp
                Dim rutaDocx As String = strTemp & ".docx"
                cFunciones.ExportarHTMLaWord(rutaHtml, rutaDocx)

            Catch ex As Exception
                MsgBox("Error: " & ex.Message)
            End Try
        End If
    End Function
    Private Sub frmReporte_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Back Then
            Me.Close()
        End If
    End Sub

    Private Sub botonExportarWord_Click(sender As Object, e As EventArgs) Handles botonExportarWord.Click
        exportar(1)
    End Sub

    Private Sub frmReporte_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        permiteWord = False
    End Sub
End Class