﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDepurar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.btonFacturas = New System.Windows.Forms.Button()
        Me.lvData = New System.Windows.Forms.ListView()
        Me.numero = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.fehca = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TotalD = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Tasa = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TotalQ = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Poliza = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.taza = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.importe = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(42, 23)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 61)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "enviar a Caja Chica"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btonFacturas
        '
        Me.btonFacturas.Location = New System.Drawing.Point(595, 70)
        Me.btonFacturas.Name = "btonFacturas"
        Me.btonFacturas.Size = New System.Drawing.Size(75, 23)
        Me.btonFacturas.TabIndex = 1
        Me.btonFacturas.Text = "Comprobar"
        Me.btonFacturas.UseVisualStyleBackColor = True
        '
        'lvData
        '
        Me.lvData.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.numero, Me.fehca, Me.TotalD, Me.Tasa, Me.TotalQ, Me.Poliza, Me.taza, Me.importe})
        Me.lvData.GridLines = True
        Me.lvData.Location = New System.Drawing.Point(31, 99)
        Me.lvData.MultiSelect = False
        Me.lvData.Name = "lvData"
        Me.lvData.Size = New System.Drawing.Size(648, 150)
        Me.lvData.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.lvData.TabIndex = 2
        Me.lvData.UseCompatibleStateImageBehavior = False
        Me.lvData.View = System.Windows.Forms.View.Details
        '
        'numero
        '
        Me.numero.Text = "Numero"
        '
        'fehca
        '
        Me.fehca.Text = "Fecha"
        '
        'TotalD
        '
        Me.TotalD.Text = "Total$"
        '
        'Tasa
        '
        Me.Tasa.Text = "TasaDoc"
        '
        'TotalQ
        '
        Me.TotalQ.Text = "TotalQDoc"
        Me.TotalQ.Width = 92
        '
        'Poliza
        '
        Me.Poliza.Text = "Poliza"
        '
        'taza
        '
        Me.taza.Text = "Taza"
        '
        'importe
        '
        Me.importe.Text = "Importe"
        '
        'frmDepurar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(706, 261)
        Me.Controls.Add(Me.lvData)
        Me.Controls.Add(Me.btonFacturas)
        Me.Controls.Add(Me.Button1)
        Me.Name = "frmDepurar"
        Me.Text = "frmDepurar"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btonFacturas As System.Windows.Forms.Button
    Friend WithEvents lvData As System.Windows.Forms.ListView
    Friend WithEvents numero As System.Windows.Forms.ColumnHeader
    Friend WithEvents fehca As System.Windows.Forms.ColumnHeader
    Friend WithEvents TotalD As System.Windows.Forms.ColumnHeader
    Friend WithEvents Tasa As System.Windows.Forms.ColumnHeader
    Friend WithEvents TotalQ As System.Windows.Forms.ColumnHeader
    Friend WithEvents Poliza As System.Windows.Forms.ColumnHeader
    Friend WithEvents taza As System.Windows.Forms.ColumnHeader
    Friend WithEvents importe As System.Windows.Forms.ColumnHeader
End Class
