﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManifiesto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelLista2 = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colSeleccion = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFlete = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonCListado = New System.Windows.Forms.Button()
        Me.etiquetaY = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.celdaEncabezado = New System.Windows.Forms.TextBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.BotonCaratula = New System.Windows.Forms.Button()
        Me.BotonDocumentoSalida = New System.Windows.Forms.Button()
        Me.dtpFechaOptional = New System.Windows.Forms.DateTimePicker()
        Me.checkFechaOptional = New System.Windows.Forms.CheckBox()
        Me.celdaFechaOptional = New System.Windows.Forms.TextBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonNotificacion = New System.Windows.Forms.Button()
        Me.botonManifiesto = New System.Windows.Forms.Button()
        Me.botonListaEmpaque = New System.Windows.Forms.Button()
        Me.botonHojaRuta = New System.Windows.Forms.Button()
        Me.celdaNo = New System.Windows.Forms.TextBox()
        Me.etiquetaNoOpcional = New System.Windows.Forms.Label()
        Me.celdaNoOpcional = New System.Windows.Forms.TextBox()
        Me.etiquetaInfoDobleClik = New System.Windows.Forms.Label()
        Me.celdaInfoDoubleClick = New System.Windows.Forms.TextBox()
        Me.panelLista.SuspendLayout()
        Me.panelLista2.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelLista.Controls.Add(Me.panelLista2)
        Me.panelLista.Controls.Add(Me.botonCListado)
        Me.panelLista.Controls.Add(Me.etiquetaY)
        Me.panelLista.Controls.Add(Me.dtpFinal)
        Me.panelLista.Controls.Add(Me.dtpInicio)
        Me.panelLista.Controls.Add(Me.checkFecha)
        Me.panelLista.Controls.Add(Me.celdaEncabezado)
        Me.panelLista.Location = New System.Drawing.Point(1, 12)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(582, 250)
        Me.panelLista.TabIndex = 0
        '
        'panelLista2
        '
        Me.panelLista2.Controls.Add(Me.dgLista)
        Me.panelLista2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLista2.Location = New System.Drawing.Point(0, 47)
        Me.panelLista2.Margin = New System.Windows.Forms.Padding(2)
        Me.panelLista2.Name = "panelLista2"
        Me.panelLista2.Size = New System.Drawing.Size(582, 203)
        Me.panelLista2.TabIndex = 7
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colSeleccion, Me.colAño, Me.colFecha, Me.colNumero, Me.colNum2, Me.colSerie, Me.colCliente, Me.colReferencia, Me.colFlete})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(582, 203)
        Me.dgLista.TabIndex = 6
        '
        'colSeleccion
        '
        Me.colSeleccion.HeaderText = ""
        Me.colSeleccion.Name = "colSeleccion"
        Me.colSeleccion.ReadOnly = True
        Me.colSeleccion.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colSeleccion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Num"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colNum2
        '
        Me.colNum2.HeaderText = "Number"
        Me.colNum2.Name = "colNum2"
        Me.colNum2.Visible = False
        '
        'colSerie
        '
        Me.colSerie.HeaderText = "Series"
        Me.colSerie.Name = "colSerie"
        Me.colSerie.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colFlete
        '
        Me.colFlete.HeaderText = "Flete"
        Me.colFlete.Name = "colFlete"
        Me.colFlete.ReadOnly = True
        Me.colFlete.Visible = False
        '
        'botonCListado
        '
        Me.botonCListado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCListado.Location = New System.Drawing.Point(442, 14)
        Me.botonCListado.Name = "botonCListado"
        Me.botonCListado.Size = New System.Drawing.Size(94, 23)
        Me.botonCListado.TabIndex = 5
        Me.botonCListado.Text = "Update"
        Me.botonCListado.UseVisualStyleBackColor = True
        '
        'etiquetaY
        '
        Me.etiquetaY.AutoSize = True
        Me.etiquetaY.Location = New System.Drawing.Point(286, 18)
        Me.etiquetaY.Name = "etiquetaY"
        Me.etiquetaY.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaY.TabIndex = 4
        Me.etiquetaY.Text = "and the"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(331, 17)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(96, 20)
        Me.dtpFinal.TabIndex = 3
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(184, 17)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(96, 20)
        Me.dtpInicio.TabIndex = 2
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(11, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(167, 17)
        Me.checkFecha.TabIndex = 1
        Me.checkFecha.Text = "Show Invoice Dated between"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'celdaEncabezado
        '
        Me.celdaEncabezado.BackColor = System.Drawing.SystemColors.Info
        Me.celdaEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.celdaEncabezado.Multiline = True
        Me.celdaEncabezado.Name = "celdaEncabezado"
        Me.celdaEncabezado.ReadOnly = True
        Me.celdaEncabezado.Size = New System.Drawing.Size(582, 47)
        Me.celdaEncabezado.TabIndex = 0
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.BotonCaratula)
        Me.panelBotones.Controls.Add(Me.BotonDocumentoSalida)
        Me.panelBotones.Controls.Add(Me.dtpFechaOptional)
        Me.panelBotones.Controls.Add(Me.checkFechaOptional)
        Me.panelBotones.Controls.Add(Me.celdaFechaOptional)
        Me.panelBotones.Controls.Add(Me.botonCerrar)
        Me.panelBotones.Controls.Add(Me.botonNotificacion)
        Me.panelBotones.Controls.Add(Me.botonManifiesto)
        Me.panelBotones.Controls.Add(Me.botonListaEmpaque)
        Me.panelBotones.Controls.Add(Me.botonHojaRuta)
        Me.panelBotones.Controls.Add(Me.celdaNo)
        Me.panelBotones.Controls.Add(Me.etiquetaNoOpcional)
        Me.panelBotones.Controls.Add(Me.celdaNoOpcional)
        Me.panelBotones.Controls.Add(Me.etiquetaInfoDobleClik)
        Me.panelBotones.Controls.Add(Me.celdaInfoDoubleClick)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelBotones.Location = New System.Drawing.Point(0, 268)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(584, 167)
        Me.panelBotones.TabIndex = 1
        '
        'BotonCaratula
        '
        Me.BotonCaratula.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.BotonCaratula.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonCaratula.Location = New System.Drawing.Point(3, 66)
        Me.BotonCaratula.Name = "BotonCaratula"
        Me.BotonCaratula.Size = New System.Drawing.Size(75, 43)
        Me.BotonCaratula.TabIndex = 16
        Me.BotonCaratula.Text = "Cover Letter"
        Me.BotonCaratula.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonCaratula.UseVisualStyleBackColor = True
        '
        'BotonDocumentoSalida
        '
        Me.BotonDocumentoSalida.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.BotonDocumentoSalida.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonDocumentoSalida.Location = New System.Drawing.Point(246, 115)
        Me.BotonDocumentoSalida.Name = "BotonDocumentoSalida"
        Me.BotonDocumentoSalida.Size = New System.Drawing.Size(75, 40)
        Me.BotonDocumentoSalida.TabIndex = 15
        Me.BotonDocumentoSalida.Text = " Inspection " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Document"
        Me.BotonDocumentoSalida.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonDocumentoSalida.UseVisualStyleBackColor = True
        '
        'dtpFechaOptional
        '
        Me.dtpFechaOptional.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaOptional.Location = New System.Drawing.Point(424, 83)
        Me.dtpFechaOptional.Name = "dtpFechaOptional"
        Me.dtpFechaOptional.Size = New System.Drawing.Size(96, 20)
        Me.dtpFechaOptional.TabIndex = 13
        '
        'checkFechaOptional
        '
        Me.checkFechaOptional.AutoSize = True
        Me.checkFechaOptional.Location = New System.Drawing.Point(377, 60)
        Me.checkFechaOptional.Name = "checkFechaOptional"
        Me.checkFechaOptional.Size = New System.Drawing.Size(95, 17)
        Me.checkFechaOptional.TabIndex = 12
        Me.checkFechaOptional.Text = "FechaOptional"
        Me.checkFechaOptional.UseVisualStyleBackColor = True
        '
        'celdaFechaOptional
        '
        Me.celdaFechaOptional.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFechaOptional.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFechaOptional.Location = New System.Drawing.Point(371, 58)
        Me.celdaFechaOptional.Multiline = True
        Me.celdaFechaOptional.Name = "celdaFechaOptional"
        Me.celdaFechaOptional.ReadOnly = True
        Me.celdaFechaOptional.Size = New System.Drawing.Size(201, 51)
        Me.celdaFechaOptional.TabIndex = 10
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.botonCerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCerrar.Location = New System.Drawing.Point(481, 115)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(94, 40)
        Me.botonCerrar.TabIndex = 9
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonNotificacion
        '
        Me.botonNotificacion.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonNotificacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonNotificacion.Location = New System.Drawing.Point(400, 115)
        Me.botonNotificacion.Name = "botonNotificacion"
        Me.botonNotificacion.Size = New System.Drawing.Size(75, 40)
        Me.botonNotificacion.TabIndex = 8
        Me.botonNotificacion.Text = "Notification"
        Me.botonNotificacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNotificacion.UseVisualStyleBackColor = True
        '
        'botonManifiesto
        '
        Me.botonManifiesto.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonManifiesto.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonManifiesto.Location = New System.Drawing.Point(165, 115)
        Me.botonManifiesto.Name = "botonManifiesto"
        Me.botonManifiesto.Size = New System.Drawing.Size(75, 40)
        Me.botonManifiesto.TabIndex = 7
        Me.botonManifiesto.Text = "Manifest"
        Me.botonManifiesto.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonManifiesto.UseVisualStyleBackColor = True
        '
        'botonListaEmpaque
        '
        Me.botonListaEmpaque.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonListaEmpaque.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonListaEmpaque.Location = New System.Drawing.Point(84, 115)
        Me.botonListaEmpaque.Name = "botonListaEmpaque"
        Me.botonListaEmpaque.Size = New System.Drawing.Size(75, 40)
        Me.botonListaEmpaque.TabIndex = 6
        Me.botonListaEmpaque.Text = "Packing List"
        Me.botonListaEmpaque.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonListaEmpaque.UseVisualStyleBackColor = True
        '
        'botonHojaRuta
        '
        Me.botonHojaRuta.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonHojaRuta.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonHojaRuta.Location = New System.Drawing.Point(3, 115)
        Me.botonHojaRuta.Name = "botonHojaRuta"
        Me.botonHojaRuta.Size = New System.Drawing.Size(75, 40)
        Me.botonHojaRuta.TabIndex = 5
        Me.botonHojaRuta.Text = "Waybill"
        Me.botonHojaRuta.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonHojaRuta.UseVisualStyleBackColor = True
        '
        'celdaNo
        '
        Me.celdaNo.Location = New System.Drawing.Point(443, 23)
        Me.celdaNo.Name = "celdaNo"
        Me.celdaNo.Size = New System.Drawing.Size(91, 20)
        Me.celdaNo.TabIndex = 4
        '
        'etiquetaNoOpcional
        '
        Me.etiquetaNoOpcional.Location = New System.Drawing.Point(374, 16)
        Me.etiquetaNoOpcional.Name = "etiquetaNoOpcional"
        Me.etiquetaNoOpcional.Size = New System.Drawing.Size(54, 27)
        Me.etiquetaNoOpcional.TabIndex = 3
        Me.etiquetaNoOpcional.Text = "Number (Optional)"
        Me.etiquetaNoOpcional.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'celdaNoOpcional
        '
        Me.celdaNoOpcional.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNoOpcional.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNoOpcional.Location = New System.Drawing.Point(371, 13)
        Me.celdaNoOpcional.Multiline = True
        Me.celdaNoOpcional.Name = "celdaNoOpcional"
        Me.celdaNoOpcional.ReadOnly = True
        Me.celdaNoOpcional.Size = New System.Drawing.Size(201, 39)
        Me.celdaNoOpcional.TabIndex = 2
        '
        'etiquetaInfoDobleClik
        '
        Me.etiquetaInfoDobleClik.AutoSize = True
        Me.etiquetaInfoDobleClik.Location = New System.Drawing.Point(27, 26)
        Me.etiquetaInfoDobleClik.Name = "etiquetaInfoDobleClik"
        Me.etiquetaInfoDobleClik.Size = New System.Drawing.Size(244, 13)
        Me.etiquetaInfoDobleClik.TabIndex = 1
        Me.etiquetaInfoDobleClik.Text = "** Double-click the Mark column to include the bill."
        '
        'celdaInfoDoubleClick
        '
        Me.celdaInfoDoubleClick.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoDoubleClick.Location = New System.Drawing.Point(12, 13)
        Me.celdaInfoDoubleClick.Multiline = True
        Me.celdaInfoDoubleClick.Name = "celdaInfoDoubleClick"
        Me.celdaInfoDoubleClick.ReadOnly = True
        Me.celdaInfoDoubleClick.Size = New System.Drawing.Size(269, 47)
        Me.celdaInfoDoubleClick.TabIndex = 0
        '
        'frmManifiesto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 435)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.panelLista)
        Me.Name = "frmManifiesto"
        Me.Text = "frmManifiesto"
        Me.panelLista.ResumeLayout(False)
        Me.panelLista.PerformLayout()
        Me.panelLista2.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelBotones.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonCListado As System.Windows.Forms.Button
    Friend WithEvents etiquetaY As System.Windows.Forms.Label
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents celdaEncabezado As System.Windows.Forms.TextBox
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents botonListaEmpaque As System.Windows.Forms.Button
    Friend WithEvents botonHojaRuta As System.Windows.Forms.Button
    Friend WithEvents celdaNo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNoOpcional As System.Windows.Forms.Label
    Friend WithEvents celdaNoOpcional As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaInfoDobleClik As System.Windows.Forms.Label
    Friend WithEvents celdaInfoDoubleClick As System.Windows.Forms.TextBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonNotificacion As System.Windows.Forms.Button
    Friend WithEvents botonManifiesto As System.Windows.Forms.Button
    Friend WithEvents panelLista2 As System.Windows.Forms.Panel
    Friend WithEvents dtpFechaOptional As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFechaOptional As System.Windows.Forms.CheckBox
    Friend WithEvents celdaFechaOptional As System.Windows.Forms.TextBox
    Friend WithEvents colSeleccion As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colAño As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSerie As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFlete As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BotonDocumentoSalida As Button
    Friend WithEvents BotonCaratula As Button
End Class
