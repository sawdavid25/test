﻿Public Class frmXDescargo

#Region "Miembros"

    Private dblCantidad As Double

    Private logAceptado As Boolean
    Private logUnico As Boolean
    Private logProducto As Boolean
    Private logLibre As Boolean
    Private logOrden As Boolean

    Private intFila As Integer
    Private strCodigo As String = STR_VACIO

#End Region

#Region "Propiedades"



#End Region

#Region "Funciones y Procedimientos Locales"

    Private Function ComprobarDatos() As Boolean
        'Comprueba los datos agregados/modificados
        Dim i As Integer
        Dim intLineas As Integer
        Dim dblTemp As Double
        Dim strSid As String
        Dim strActual As String
        Dim strProducto As String
        Dim strTemp As String
        Dim logErr As Boolean
        Dim logRelacion As Boolean
        Dim logCodigo As Boolean
        Dim strMsj As String

        intLineas = vbEmpty
        strProducto = strCodigo

    End Function

#End Region

#Region "Eventos"

    Private Sub frmConfirmacion_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

    End Sub

    Private Function InforDeProducto(Optional ByVal Fila As Integer = NO_FILA)
        Dim intCol As Integer
        Dim strDato As String = STR_VACIO
        Dim strTemp As String = STR_VACIO

        'Si existen datos
        If dgDetalle.Rows.Count > vbEmpty Then
            'Si no se especifico la fila
            If Fila = NO_FILA Then
                Fila = dgDetalle.Rows.Count
            End If

            intCol = 8
            strTemp = vbNullString

            strDato = dgDetalle.Rows(Fila).Cells("colPais").Value
            strDato = strDato & dgDetalle.Rows(Fila).Cells("colFabricante").Value & "/" & vbNullString

            strTemp = "Hilo:" & intCol & dgDetalle.Rows(Fila).Cells("colDescripcion").Value
            strTemp = "Origen:" & intCol & strDato

            If Not logOrden Then
                strTemp = "Lote:" & intCol & dgDetalle.Rows(Fila).Cells("colLote").Value
                strTemp = "Semana:" & intCol & dgDetalle.Rows(Fila).Cells("colSemana").Value
            End If
        Else
            strTemp = vbNullString
        End If
        InforDeProducto = strTemp
    End Function
#End Region


End Class