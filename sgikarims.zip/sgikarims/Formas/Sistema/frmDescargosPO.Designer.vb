﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDescargosPO
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.panelDescargos = New System.Windows.Forms.Panel()
        Me.dgDescargos = New System.Windows.Forms.DataGridView()
        Me.panelFilas = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.colLineaDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColFechaDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFilaDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones.SuspendLayout()
        Me.panelDescargos.SuspendLayout()
        CType(Me.dgDescargos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFilas.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonCancelar)
        Me.panelBotones.Controls.Add(Me.botonAceptar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelBotones.Location = New System.Drawing.Point(0, 299)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(706, 72)
        Me.panelBotones.TabIndex = 0
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Location = New System.Drawing.Point(588, 22)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(99, 31)
        Me.botonCancelar.TabIndex = 1
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Location = New System.Drawing.Point(454, 22)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(99, 31)
        Me.botonAceptar.TabIndex = 0
        Me.botonAceptar.Text = "To accept"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'panelDescargos
        '
        Me.panelDescargos.Controls.Add(Me.dgDescargos)
        Me.panelDescargos.Controls.Add(Me.panelFilas)
        Me.panelDescargos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDescargos.Location = New System.Drawing.Point(0, 0)
        Me.panelDescargos.Name = "panelDescargos"
        Me.panelDescargos.Size = New System.Drawing.Size(706, 299)
        Me.panelDescargos.TabIndex = 1
        '
        'dgDescargos
        '
        Me.dgDescargos.AllowUserToAddRows = False
        Me.dgDescargos.AllowUserToDeleteRows = False
        Me.dgDescargos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDescargos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDescargos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLineaDescargo, Me.colAnioDescargo, Me.colNumeroDescargo, Me.ColFechaDescargo, Me.colFilaDescargo, Me.colCantidadDescargo, Me.colReferenciaDescargo, Me.colExtraDescargo})
        Me.dgDescargos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDescargos.Location = New System.Drawing.Point(0, 0)
        Me.dgDescargos.Name = "dgDescargos"
        Me.dgDescargos.RowTemplate.Height = 24
        Me.dgDescargos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDescargos.Size = New System.Drawing.Size(641, 299)
        Me.dgDescargos.TabIndex = 0
        '
        'panelFilas
        '
        Me.panelFilas.Controls.Add(Me.Button1)
        Me.panelFilas.Controls.Add(Me.botonAgregar)
        Me.panelFilas.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelFilas.Location = New System.Drawing.Point(641, 0)
        Me.panelFilas.Name = "panelFilas"
        Me.panelFilas.Size = New System.Drawing.Size(65, 299)
        Me.panelFilas.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button1.Location = New System.Drawing.Point(17, 93)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(35, 30)
        Me.Button1.TabIndex = 4
        Me.Button1.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(17, 24)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(35, 30)
        Me.botonAgregar.TabIndex = 3
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'colLineaDescargo
        '
        Me.colLineaDescargo.HeaderText = "Line"
        Me.colLineaDescargo.Name = "colLineaDescargo"
        Me.colLineaDescargo.ReadOnly = True
        Me.colLineaDescargo.Visible = False
        '
        'colAnioDescargo
        '
        Me.colAnioDescargo.HeaderText = "Year"
        Me.colAnioDescargo.Name = "colAnioDescargo"
        Me.colAnioDescargo.ReadOnly = True
        Me.colAnioDescargo.Visible = False
        '
        'colNumeroDescargo
        '
        Me.colNumeroDescargo.HeaderText = "Number"
        Me.colNumeroDescargo.Name = "colNumeroDescargo"
        Me.colNumeroDescargo.ReadOnly = True
        Me.colNumeroDescargo.Visible = False
        '
        'ColFechaDescargo
        '
        Me.ColFechaDescargo.HeaderText = "Date"
        Me.ColFechaDescargo.Name = "ColFechaDescargo"
        Me.ColFechaDescargo.ReadOnly = True
        '
        'colFilaDescargo
        '
        Me.colFilaDescargo.HeaderText = "Row"
        Me.colFilaDescargo.Name = "colFilaDescargo"
        Me.colFilaDescargo.ReadOnly = True
        Me.colFilaDescargo.Visible = False
        '
        'colCantidadDescargo
        '
        Me.colCantidadDescargo.HeaderText = "Quantity"
        Me.colCantidadDescargo.Name = "colCantidadDescargo"
        '
        'colReferenciaDescargo
        '
        Me.colReferenciaDescargo.HeaderText = "Reference"
        Me.colReferenciaDescargo.Name = "colReferenciaDescargo"
        '
        'colExtraDescargo
        '
        Me.colExtraDescargo.HeaderText = "Extra"
        Me.colExtraDescargo.Name = "colExtraDescargo"
        Me.colExtraDescargo.ReadOnly = True
        Me.colExtraDescargo.Visible = False
        '
        'frmDescargosPO
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(706, 371)
        Me.Controls.Add(Me.panelDescargos)
        Me.Controls.Add(Me.panelBotones)
        Me.Name = "frmDescargosPO"
        Me.Text = "Downloaded Quantities"
        Me.panelBotones.ResumeLayout(False)
        Me.panelDescargos.ResumeLayout(False)
        CType(Me.dgDescargos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFilas.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents panelDescargos As Panel
    Friend WithEvents dgDescargos As DataGridView
    Friend WithEvents panelFilas As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents colLineaDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colAnioDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroDescargo As DataGridViewTextBoxColumn
    Friend WithEvents ColFechaDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colFilaDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colExtraDescargo As DataGridViewTextBoxColumn
End Class
