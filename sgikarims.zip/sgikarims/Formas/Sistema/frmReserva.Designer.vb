﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReserva
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnldgvReserva = New System.Windows.Forms.Panel()
        Me.dgvReserva = New System.Windows.Forms.DataGridView()
        Me.pnlControles = New System.Windows.Forms.Panel()
        Me.pnlReserva = New System.Windows.Forms.Panel()
        Me.txtDescripcion = New System.Windows.Forms.TextBox()
        Me.pbReserva = New System.Windows.Forms.PictureBox()
        Me.gpReserva = New System.Windows.Forms.GroupBox()
        Me.lblreferencia = New System.Windows.Forms.TextBox()
        Me.btnCerrar = New System.Windows.Forms.Button()
        Me.CeldaDisponible = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CeldaReserv = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CeldaSaldo = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnCancelar = New System.Windows.Forms.Button()
        Me.btnAsignar = New System.Windows.Forms.Button()
        Me.CeldaEvento = New System.Windows.Forms.Button()
        Me.CeldaEstado = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CeldaDescription = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CeldaReserva = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnCustomer = New System.Windows.Forms.Button()
        Me.CeldaCodCodigo = New System.Windows.Forms.TextBox()
        Me.CodCustomer = New System.Windows.Forms.Label()
        Me.CeldaCustomer = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnDesactivar = New System.Windows.Forms.Button()
        Me.btnModificar = New System.Windows.Forms.Button()
        Me.btnNueva = New System.Windows.Forms.Button()
        Me.pnldgvReserva.SuspendLayout()
        CType(Me.dgvReserva, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlReserva.SuspendLayout()
        CType(Me.pbReserva, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gpReserva.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnldgvReserva
        '
        Me.pnldgvReserva.Controls.Add(Me.dgvReserva)
        Me.pnldgvReserva.Controls.Add(Me.pnlControles)
        Me.pnldgvReserva.Location = New System.Drawing.Point(0, 3)
        Me.pnldgvReserva.Name = "pnldgvReserva"
        Me.pnldgvReserva.Size = New System.Drawing.Size(577, 208)
        Me.pnldgvReserva.TabIndex = 0
        '
        'dgvReserva
        '
        Me.dgvReserva.AllowUserToAddRows = False
        Me.dgvReserva.AllowUserToDeleteRows = False
        Me.dgvReserva.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvReserva.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvReserva.Location = New System.Drawing.Point(0, 0)
        Me.dgvReserva.Name = "dgvReserva"
        Me.dgvReserva.Size = New System.Drawing.Size(577, 208)
        Me.dgvReserva.TabIndex = 2
        '
        'pnlControles
        '
        Me.pnlControles.Location = New System.Drawing.Point(0, 220)
        Me.pnlControles.Name = "pnlControles"
        Me.pnlControles.Size = New System.Drawing.Size(577, 232)
        Me.pnlControles.TabIndex = 1
        '
        'pnlReserva
        '
        Me.pnlReserva.Controls.Add(Me.txtDescripcion)
        Me.pnlReserva.Controls.Add(Me.pbReserva)
        Me.pnlReserva.Controls.Add(Me.gpReserva)
        Me.pnlReserva.Controls.Add(Me.btnEliminar)
        Me.pnlReserva.Controls.Add(Me.btnDesactivar)
        Me.pnlReserva.Controls.Add(Me.btnModificar)
        Me.pnlReserva.Controls.Add(Me.btnNueva)
        Me.pnlReserva.Controls.Add(Me.pnldgvReserva)
        Me.pnlReserva.Location = New System.Drawing.Point(12, 12)
        Me.pnlReserva.Name = "pnlReserva"
        Me.pnlReserva.Size = New System.Drawing.Size(577, 521)
        Me.pnlReserva.TabIndex = 0
        '
        'txtDescripcion
        '
        Me.txtDescripcion.BackColor = System.Drawing.SystemColors.Info
        Me.txtDescripcion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescripcion.Location = New System.Drawing.Point(3, 226)
        Me.txtDescripcion.Multiline = True
        Me.txtDescripcion.Name = "txtDescripcion"
        Me.txtDescripcion.Size = New System.Drawing.Size(292, 39)
        Me.txtDescripcion.TabIndex = 7
        '
        'pbReserva
        '
        Me.pbReserva.BackColor = System.Drawing.SystemColors.Info
        Me.pbReserva.Location = New System.Drawing.Point(4, 226)
        Me.pbReserva.Name = "pbReserva"
        Me.pbReserva.Size = New System.Drawing.Size(291, 39)
        Me.pbReserva.TabIndex = 6
        Me.pbReserva.TabStop = False
        '
        'gpReserva
        '
        Me.gpReserva.Controls.Add(Me.lblreferencia)
        Me.gpReserva.Controls.Add(Me.btnCerrar)
        Me.gpReserva.Controls.Add(Me.CeldaDisponible)
        Me.gpReserva.Controls.Add(Me.Label7)
        Me.gpReserva.Controls.Add(Me.CeldaReserv)
        Me.gpReserva.Controls.Add(Me.Label6)
        Me.gpReserva.Controls.Add(Me.CeldaSaldo)
        Me.gpReserva.Controls.Add(Me.Label5)
        Me.gpReserva.Controls.Add(Me.btnCancelar)
        Me.gpReserva.Controls.Add(Me.btnAsignar)
        Me.gpReserva.Controls.Add(Me.CeldaEvento)
        Me.gpReserva.Controls.Add(Me.CeldaEstado)
        Me.gpReserva.Controls.Add(Me.Label4)
        Me.gpReserva.Controls.Add(Me.CeldaDescription)
        Me.gpReserva.Controls.Add(Me.Label3)
        Me.gpReserva.Controls.Add(Me.CeldaReserva)
        Me.gpReserva.Controls.Add(Me.Label2)
        Me.gpReserva.Controls.Add(Me.btnCustomer)
        Me.gpReserva.Controls.Add(Me.CeldaCodCodigo)
        Me.gpReserva.Controls.Add(Me.CodCustomer)
        Me.gpReserva.Controls.Add(Me.CeldaCustomer)
        Me.gpReserva.Controls.Add(Me.Label1)
        Me.gpReserva.Location = New System.Drawing.Point(14, 271)
        Me.gpReserva.Name = "gpReserva"
        Me.gpReserva.Size = New System.Drawing.Size(553, 236)
        Me.gpReserva.TabIndex = 5
        Me.gpReserva.TabStop = False
        Me.gpReserva.Text = "Reserva"
        '
        'lblreferencia
        '
        Me.lblreferencia.Location = New System.Drawing.Point(123, 202)
        Me.lblreferencia.Name = "lblreferencia"
        Me.lblreferencia.ReadOnly = True
        Me.lblreferencia.Size = New System.Drawing.Size(49, 20)
        Me.lblreferencia.TabIndex = 21
        '
        'btnCerrar
        '
        'Me.btnCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel1
        Me.btnCerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCerrar.Location = New System.Drawing.Point(480, 186)
        Me.btnCerrar.Name = "btnCerrar"
        Me.btnCerrar.Size = New System.Drawing.Size(66, 37)
        Me.btnCerrar.TabIndex = 20
        Me.btnCerrar.Text = "Close"
        Me.btnCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCerrar.UseVisualStyleBackColor = True
        '
        'CeldaDisponible
        '
        Me.CeldaDisponible.Location = New System.Drawing.Point(296, 202)
        Me.CeldaDisponible.Name = "CeldaDisponible"
        Me.CeldaDisponible.Size = New System.Drawing.Size(110, 20)
        Me.CeldaDisponible.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(293, 187)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Avaliable"
        '
        'CeldaReserv
        '
        Me.CeldaReserv.Location = New System.Drawing.Point(178, 202)
        Me.CeldaReserv.Name = "CeldaReserv"
        Me.CeldaReserv.Size = New System.Drawing.Size(109, 20)
        Me.CeldaReserv.TabIndex = 17
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(175, 186)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Reservation"
        '
        'CeldaSaldo
        '
        Me.CeldaSaldo.Location = New System.Drawing.Point(17, 203)
        Me.CeldaSaldo.Name = "CeldaSaldo"
        Me.CeldaSaldo.Size = New System.Drawing.Size(100, 20)
        Me.CeldaSaldo.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(14, 187)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Balance"
        '
        'btnCancelar
        '
        ' Me.btnCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnCancelar.Location = New System.Drawing.Point(481, 132)
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.Size = New System.Drawing.Size(66, 35)
        Me.btnCancelar.TabIndex = 13
        Me.btnCancelar.Text = "Cancel"
        Me.btnCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'btnAsignar
        '
        'Me.btnAsignar.Image = Global.KARIMs_SGI.My.Resources.Resources.next_set_2
        Me.btnAsignar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnAsignar.Location = New System.Drawing.Point(405, 132)
        Me.btnAsignar.Name = "btnAsignar"
        Me.btnAsignar.Size = New System.Drawing.Size(75, 34)
        Me.btnAsignar.TabIndex = 12
        Me.btnAsignar.Text = "Assign"
        Me.btnAsignar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnAsignar.UseVisualStyleBackColor = True
        '
        'CeldaEvento
        '
        ' Me.CeldaEvento.Image = Global.KARIMs_SGI.My.Resources.Resources.help3
        Me.CeldaEvento.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.CeldaEvento.Location = New System.Drawing.Point(405, 88)
        Me.CeldaEvento.Name = "CeldaEvento"
        Me.CeldaEvento.Size = New System.Drawing.Size(75, 38)
        Me.CeldaEvento.TabIndex = 11
        Me.CeldaEvento.Text = "Event"
        Me.CeldaEvento.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.CeldaEvento.UseVisualStyleBackColor = True
        '
        'CeldaEstado
        '
        Me.CeldaEstado.Location = New System.Drawing.Point(17, 146)
        Me.CeldaEstado.Name = "CeldaEstado"
        Me.CeldaEstado.ReadOnly = True
        Me.CeldaEstado.Size = New System.Drawing.Size(100, 20)
        Me.CeldaEstado.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Status"
        '
        'CeldaDescription
        '
        Me.CeldaDescription.Location = New System.Drawing.Point(136, 88)
        Me.CeldaDescription.Multiline = True
        Me.CeldaDescription.Name = "CeldaDescription"
        Me.CeldaDescription.Size = New System.Drawing.Size(263, 79)
        Me.CeldaDescription.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(133, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Description"
        '
        'CeldaReserva
        '
        Me.CeldaReserva.Location = New System.Drawing.Point(14, 89)
        Me.CeldaReserva.Name = "CeldaReserva"
        Me.CeldaReserva.Size = New System.Drawing.Size(100, 20)
        Me.CeldaReserva.TabIndex = 6
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 73)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Reserver Amount"
        '
        'btnCustomer
        '
        Me.btnCustomer.Location = New System.Drawing.Point(495, 41)
        Me.btnCustomer.Name = "btnCustomer"
        Me.btnCustomer.Size = New System.Drawing.Size(27, 23)
        Me.btnCustomer.TabIndex = 4
        Me.btnCustomer.Text = "..."
        Me.btnCustomer.UseVisualStyleBackColor = True
        '
        'CeldaCodCodigo
        '
        Me.CeldaCodCodigo.Location = New System.Drawing.Point(407, 44)
        Me.CeldaCodCodigo.Name = "CeldaCodCodigo"
        Me.CeldaCodCodigo.ReadOnly = True
        Me.CeldaCodCodigo.Size = New System.Drawing.Size(73, 20)
        Me.CeldaCodCodigo.TabIndex = 3
        '
        'CodCustomer
        '
        Me.CodCustomer.AutoSize = True
        Me.CodCustomer.Location = New System.Drawing.Point(404, 28)
        Me.CodCustomer.Name = "CodCustomer"
        Me.CodCustomer.Size = New System.Drawing.Size(32, 13)
        Me.CodCustomer.TabIndex = 2
        Me.CodCustomer.Text = "Code"
        '
        'CeldaCustomer
        '
        Me.CeldaCustomer.Location = New System.Drawing.Point(14, 45)
        Me.CeldaCustomer.Name = "CeldaCustomer"
        Me.CeldaCustomer.Size = New System.Drawing.Size(385, 20)
        Me.CeldaCustomer.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer"
        '
        'btnEliminar
        '
        Me.btnEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnEliminar.Location = New System.Drawing.Point(514, 223)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(53, 42)
        Me.btnEliminar.TabIndex = 4
        Me.btnEliminar.Text = "Delete"
        Me.btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'btnDesactivar
        '
        ' Me.btnDesactivar.Image = Global.KARIMs_SGI.My.Resources.Resources.flag_red
        Me.btnDesactivar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnDesactivar.Location = New System.Drawing.Point(426, 223)
        Me.btnDesactivar.Name = "btnDesactivar"
        Me.btnDesactivar.Size = New System.Drawing.Size(82, 42)
        Me.btnDesactivar.TabIndex = 3
        Me.btnDesactivar.Text = "Deactivated"
        Me.btnDesactivar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnDesactivar.UseVisualStyleBackColor = True
        '
        'btnModificar
        '
        Me.btnModificar.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.btnModificar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnModificar.Location = New System.Drawing.Point(360, 223)
        Me.btnModificar.Name = "btnModificar"
        Me.btnModificar.Size = New System.Drawing.Size(60, 42)
        Me.btnModificar.TabIndex = 2
        Me.btnModificar.Text = "Save"
        Me.btnModificar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnModificar.UseVisualStyleBackColor = True
        '
        'btnNueva
        '
        Me.btnNueva.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.btnNueva.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnNueva.Location = New System.Drawing.Point(301, 223)
        Me.btnNueva.Name = "btnNueva"
        Me.btnNueva.Size = New System.Drawing.Size(53, 42)
        Me.btnNueva.TabIndex = 1
        Me.btnNueva.Text = "New"
        Me.btnNueva.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnNueva.UseVisualStyleBackColor = True
        '
        'frmReserva
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(600, 545)
        Me.Controls.Add(Me.pnlReserva)
        Me.Name = "frmReserva"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inventory Reservation"
        Me.pnldgvReserva.ResumeLayout(False)
        CType(Me.dgvReserva, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlReserva.ResumeLayout(False)
        Me.pnlReserva.PerformLayout()
        CType(Me.pbReserva, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gpReserva.ResumeLayout(False)
        Me.gpReserva.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnldgvReserva As System.Windows.Forms.Panel
    Friend WithEvents dgvReserva As System.Windows.Forms.DataGridView
    Friend WithEvents pnlControles As System.Windows.Forms.Panel
    Friend WithEvents pnlReserva As System.Windows.Forms.Panel
    Friend WithEvents btnEliminar As System.Windows.Forms.Button
    Friend WithEvents btnDesactivar As System.Windows.Forms.Button
    Friend WithEvents btnModificar As System.Windows.Forms.Button
    Friend WithEvents btnNueva As System.Windows.Forms.Button
    Friend WithEvents gpReserva As System.Windows.Forms.GroupBox
    Friend WithEvents CeldaCustomer As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCustomer As System.Windows.Forms.Button
    Friend WithEvents CeldaCodCodigo As System.Windows.Forms.TextBox
    Friend WithEvents CodCustomer As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents CeldaReserva As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CeldaDescription As System.Windows.Forms.TextBox
    Friend WithEvents CeldaEstado As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents btnAsignar As System.Windows.Forms.Button
    Friend WithEvents CeldaEvento As System.Windows.Forms.Button
    Friend WithEvents CeldaReserv As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents CeldaSaldo As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents CeldaDisponible As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnCerrar As System.Windows.Forms.Button
    Friend WithEvents lblreferencia As System.Windows.Forms.TextBox
    Friend WithEvents pbReserva As System.Windows.Forms.PictureBox
    Friend WithEvents txtDescripcion As System.Windows.Forms.TextBox
End Class
