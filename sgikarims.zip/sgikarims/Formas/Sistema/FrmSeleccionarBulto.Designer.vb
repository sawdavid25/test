﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSeleccionarBulto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaidCategoria = New System.Windows.Forms.TextBox()
        Me.celdaCategoria = New System.Windows.Forms.TextBox()
        Me.botonCategoria = New System.Windows.Forms.Button()
        Me.checkTodo = New System.Windows.Forms.CheckBox()
        Me.celdaPeso = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgBultosYaDescargados = New System.Windows.Forms.DataGridView()
        Me.botonCanccelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCheck = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgBultosYaDescargados, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaidCategoria)
        Me.Panel1.Controls.Add(Me.celdaCategoria)
        Me.Panel1.Controls.Add(Me.botonCategoria)
        Me.Panel1.Controls.Add(Me.checkTodo)
        Me.Panel1.Controls.Add(Me.celdaPeso)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(559, 43)
        Me.Panel1.TabIndex = 0
        '
        'celdaidCategoria
        '
        Me.celdaidCategoria.Location = New System.Drawing.Point(131, 9)
        Me.celdaidCategoria.Name = "celdaidCategoria"
        Me.celdaidCategoria.Size = New System.Drawing.Size(15, 22)
        Me.celdaidCategoria.TabIndex = 4
        Me.celdaidCategoria.Visible = False
        '
        'celdaCategoria
        '
        Me.celdaCategoria.Location = New System.Drawing.Point(154, 13)
        Me.celdaCategoria.Name = "celdaCategoria"
        Me.celdaCategoria.ReadOnly = True
        Me.celdaCategoria.Size = New System.Drawing.Size(181, 22)
        Me.celdaCategoria.TabIndex = 3
        Me.celdaCategoria.Visible = False
        '
        'botonCategoria
        '
        Me.botonCategoria.Location = New System.Drawing.Point(341, 12)
        Me.botonCategoria.Name = "botonCategoria"
        Me.botonCategoria.Size = New System.Drawing.Size(37, 23)
        Me.botonCategoria.TabIndex = 2
        Me.botonCategoria.Text = "..."
        Me.botonCategoria.UseVisualStyleBackColor = True
        Me.botonCategoria.Visible = False
        '
        'checkTodo
        '
        Me.checkTodo.AutoSize = True
        Me.checkTodo.Location = New System.Drawing.Point(37, 10)
        Me.checkTodo.Name = "checkTodo"
        Me.checkTodo.Size = New System.Drawing.Size(88, 21)
        Me.checkTodo.TabIndex = 1
        Me.checkTodo.Text = "Select All"
        Me.checkTodo.UseVisualStyleBackColor = True
        '
        'celdaPeso
        '
        Me.celdaPeso.BackColor = System.Drawing.SystemColors.Info
        Me.celdaPeso.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaPeso.Location = New System.Drawing.Point(395, 9)
        Me.celdaPeso.Name = "celdaPeso"
        Me.celdaPeso.ReadOnly = True
        Me.celdaPeso.Size = New System.Drawing.Size(152, 27)
        Me.celdaPeso.TabIndex = 0
        Me.celdaPeso.Text = "0"
        Me.celdaPeso.Visible = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.dgBultosYaDescargados)
        Me.Panel2.Controls.Add(Me.botonCanccelar)
        Me.Panel2.Controls.Add(Me.botonAceptar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 405)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(559, 54)
        Me.Panel2.TabIndex = 1
        '
        'dgBultosYaDescargados
        '
        Me.dgBultosYaDescargados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgBultosYaDescargados.Location = New System.Drawing.Point(68, 6)
        Me.dgBultosYaDescargados.Name = "dgBultosYaDescargados"
        Me.dgBultosYaDescargados.RowTemplate.Height = 24
        Me.dgBultosYaDescargados.Size = New System.Drawing.Size(240, 36)
        Me.dgBultosYaDescargados.TabIndex = 2
        '
        'botonCanccelar
        '
        Me.botonCanccelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCanccelar.Location = New System.Drawing.Point(450, 12)
        Me.botonCanccelar.Name = "botonCanccelar"
        Me.botonCanccelar.Size = New System.Drawing.Size(83, 36)
        Me.botonCanccelar.TabIndex = 1
        Me.botonCanccelar.Text = "Aceptar"
        Me.botonCanccelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Location = New System.Drawing.Point(332, 12)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(80, 36)
        Me.botonAceptar.TabIndex = 0
        Me.botonAceptar.Text = "Cancelar"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCheck, Me.colNumero, Me.colDescripcion})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 43)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(559, 362)
        Me.dgLista.TabIndex = 2
        '
        'colCheck
        '
        Me.colCheck.HeaderText = ""
        Me.colCheck.Name = "colCheck"
        Me.colCheck.ReadOnly = True
        Me.colCheck.Width = 5
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "ID"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colNumero.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colNumero.Width = 27
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'FrmSeleccionarBulto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(559, 459)
        Me.Controls.Add(Me.dgLista)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "FrmSeleccionarBulto"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmSeleccionarBulto"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgBultosYaDescargados, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonCanccelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents dgBultosYaDescargados As System.Windows.Forms.DataGridView
    Friend WithEvents celdaPeso As System.Windows.Forms.TextBox
    Friend WithEvents checkTodo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaCategoria As TextBox
    Friend WithEvents botonCategoria As Button
    Friend WithEvents celdaidCategoria As TextBox
    Friend WithEvents colCheck As DataGridViewCheckBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
End Class
