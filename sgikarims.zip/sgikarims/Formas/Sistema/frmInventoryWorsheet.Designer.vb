﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInventoryWorsheet
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.gbOpcionesAdicionales = New System.Windows.Forms.GroupBox()
        Me.botonSeleccion2 = New System.Windows.Forms.Button()
        Me.celdaSeleccion2 = New System.Windows.Forms.TextBox()
        Me.botonSeleccion = New System.Windows.Forms.Button()
        Me.celdaSeleccion = New System.Windows.Forms.TextBox()
        Me.etiquetaOrdenar = New System.Windows.Forms.Label()
        Me.checkIncluirColumnas = New System.Windows.Forms.CheckBox()
        Me.gbFechas = New System.Windows.Forms.GroupBox()
        Me.checkRangeDate = New System.Windows.Forms.CheckBox()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFinal = New System.Windows.Forms.Label()
        Me.etiquetaInicial = New System.Windows.Forms.Label()
        Me.gbSeleccion = New System.Windows.Forms.GroupBox()
        Me.celdaIDPais = New System.Windows.Forms.TextBox()
        Me.celdaIDProducto = New System.Windows.Forms.TextBox()
        Me.checkBodega = New System.Windows.Forms.CheckBox()
        Me.botonBodega = New System.Windows.Forms.Button()
        Me.celdaBodega = New System.Windows.Forms.TextBox()
        Me.etiquetaBodega = New System.Windows.Forms.Label()
        Me.botonPaisOrigen = New System.Windows.Forms.Button()
        Me.celdaPaisOrigen = New System.Windows.Forms.TextBox()
        Me.etiquetPais = New System.Windows.Forms.Label()
        Me.botonProductos = New System.Windows.Forms.Button()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.panelPrincipal.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.gbOpcionesAdicionales.SuspendLayout()
        Me.gbFechas.SuspendLayout()
        Me.gbSeleccion.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelPrincipal
        '
        Me.panelPrincipal.Controls.Add(Me.panelBotones)
        Me.panelPrincipal.Controls.Add(Me.gbOpcionesAdicionales)
        Me.panelPrincipal.Controls.Add(Me.gbFechas)
        Me.panelPrincipal.Controls.Add(Me.gbSeleccion)
        Me.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelPrincipal.Location = New System.Drawing.Point(0, 0)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(434, 621)
        Me.panelPrincipal.TabIndex = 0
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonCancelar)
        Me.panelBotones.Controls.Add(Me.botonAceptar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelBotones.Location = New System.Drawing.Point(0, 535)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(434, 86)
        Me.panelBotones.TabIndex = 3
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(325, 33)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.botonCancelar.TabIndex = 1
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(230, 33)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 23)
        Me.botonAceptar.TabIndex = 0
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'gbOpcionesAdicionales
        '
        Me.gbOpcionesAdicionales.Controls.Add(Me.botonSeleccion2)
        Me.gbOpcionesAdicionales.Controls.Add(Me.celdaSeleccion2)
        Me.gbOpcionesAdicionales.Controls.Add(Me.botonSeleccion)
        Me.gbOpcionesAdicionales.Controls.Add(Me.celdaSeleccion)
        Me.gbOpcionesAdicionales.Controls.Add(Me.etiquetaOrdenar)
        Me.gbOpcionesAdicionales.Controls.Add(Me.checkIncluirColumnas)
        Me.gbOpcionesAdicionales.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbOpcionesAdicionales.Location = New System.Drawing.Point(0, 408)
        Me.gbOpcionesAdicionales.Name = "gbOpcionesAdicionales"
        Me.gbOpcionesAdicionales.Size = New System.Drawing.Size(434, 149)
        Me.gbOpcionesAdicionales.TabIndex = 2
        Me.gbOpcionesAdicionales.TabStop = False
        Me.gbOpcionesAdicionales.Text = "Additional Options"
        '
        'botonSeleccion2
        '
        Me.botonSeleccion2.Location = New System.Drawing.Point(348, 74)
        Me.botonSeleccion2.Name = "botonSeleccion2"
        Me.botonSeleccion2.Size = New System.Drawing.Size(41, 23)
        Me.botonSeleccion2.TabIndex = 15
        Me.botonSeleccion2.Text = "..."
        Me.botonSeleccion2.UseVisualStyleBackColor = True
        '
        'celdaSeleccion2
        '
        Me.celdaSeleccion2.Location = New System.Drawing.Point(230, 74)
        Me.celdaSeleccion2.Multiline = True
        Me.celdaSeleccion2.Name = "celdaSeleccion2"
        Me.celdaSeleccion2.Size = New System.Drawing.Size(112, 25)
        Me.celdaSeleccion2.TabIndex = 14
        '
        'botonSeleccion
        '
        Me.botonSeleccion.Location = New System.Drawing.Point(181, 74)
        Me.botonSeleccion.Name = "botonSeleccion"
        Me.botonSeleccion.Size = New System.Drawing.Size(41, 23)
        Me.botonSeleccion.TabIndex = 13
        Me.botonSeleccion.Text = "..."
        Me.botonSeleccion.UseVisualStyleBackColor = True
        '
        'celdaSeleccion
        '
        Me.celdaSeleccion.Location = New System.Drawing.Point(63, 74)
        Me.celdaSeleccion.Multiline = True
        Me.celdaSeleccion.Name = "celdaSeleccion"
        Me.celdaSeleccion.Size = New System.Drawing.Size(112, 25)
        Me.celdaSeleccion.TabIndex = 12
        '
        'etiquetaOrdenar
        '
        Me.etiquetaOrdenar.AutoSize = True
        Me.etiquetaOrdenar.Location = New System.Drawing.Point(12, 77)
        Me.etiquetaOrdenar.Name = "etiquetaOrdenar"
        Me.etiquetaOrdenar.Size = New System.Drawing.Size(54, 13)
        Me.etiquetaOrdenar.TabIndex = 11
        Me.etiquetaOrdenar.Text = "Order By: "
        '
        'checkIncluirColumnas
        '
        Me.checkIncluirColumnas.AutoSize = True
        Me.checkIncluirColumnas.Location = New System.Drawing.Point(15, 32)
        Me.checkIncluirColumnas.Name = "checkIncluirColumnas"
        Me.checkIncluirColumnas.Size = New System.Drawing.Size(202, 17)
        Me.checkIncluirColumnas.TabIndex = 10
        Me.checkIncluirColumnas.Text = "Include Columns for Inventory Taking"
        Me.checkIncluirColumnas.UseVisualStyleBackColor = True
        '
        'gbFechas
        '
        Me.gbFechas.Controls.Add(Me.checkRangeDate)
        Me.gbFechas.Controls.Add(Me.dtpFinal)
        Me.gbFechas.Controls.Add(Me.dtpInicial)
        Me.gbFechas.Controls.Add(Me.etiquetaFinal)
        Me.gbFechas.Controls.Add(Me.etiquetaInicial)
        Me.gbFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbFechas.Location = New System.Drawing.Point(0, 284)
        Me.gbFechas.Name = "gbFechas"
        Me.gbFechas.Size = New System.Drawing.Size(434, 124)
        Me.gbFechas.TabIndex = 1
        Me.gbFechas.TabStop = False
        Me.gbFechas.Text = "Filter By Date Range"
        '
        'checkRangeDate
        '
        Me.checkRangeDate.AutoSize = True
        Me.checkRangeDate.Location = New System.Drawing.Point(15, 41)
        Me.checkRangeDate.Name = "checkRangeDate"
        Me.checkRangeDate.Size = New System.Drawing.Size(124, 17)
        Me.checkRangeDate.TabIndex = 11
        Me.checkRangeDate.Text = "Filter By Date Range"
        Me.checkRangeDate.UseVisualStyleBackColor = True
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(260, 78)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(138, 20)
        Me.dtpFinal.TabIndex = 10
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(47, 78)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(138, 20)
        Me.dtpInicial.TabIndex = 9
        '
        'etiquetaFinal
        '
        Me.etiquetaFinal.AutoSize = True
        Me.etiquetaFinal.Location = New System.Drawing.Point(225, 84)
        Me.etiquetaFinal.Name = "etiquetaFinal"
        Me.etiquetaFinal.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaFinal.TabIndex = 8
        Me.etiquetaFinal.Text = "Final"
        '
        'etiquetaInicial
        '
        Me.etiquetaInicial.AutoSize = True
        Me.etiquetaInicial.Location = New System.Drawing.Point(10, 84)
        Me.etiquetaInicial.Name = "etiquetaInicial"
        Me.etiquetaInicial.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaInicial.TabIndex = 7
        Me.etiquetaInicial.Text = "Initial"
        '
        'gbSeleccion
        '
        Me.gbSeleccion.Controls.Add(Me.celdaIDPais)
        Me.gbSeleccion.Controls.Add(Me.celdaIDProducto)
        Me.gbSeleccion.Controls.Add(Me.checkBodega)
        Me.gbSeleccion.Controls.Add(Me.botonBodega)
        Me.gbSeleccion.Controls.Add(Me.celdaBodega)
        Me.gbSeleccion.Controls.Add(Me.etiquetaBodega)
        Me.gbSeleccion.Controls.Add(Me.botonPaisOrigen)
        Me.gbSeleccion.Controls.Add(Me.celdaPaisOrigen)
        Me.gbSeleccion.Controls.Add(Me.etiquetPais)
        Me.gbSeleccion.Controls.Add(Me.botonProductos)
        Me.gbSeleccion.Controls.Add(Me.celdaProducto)
        Me.gbSeleccion.Controls.Add(Me.etiquetaProducto)
        Me.gbSeleccion.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbSeleccion.Location = New System.Drawing.Point(0, 0)
        Me.gbSeleccion.Name = "gbSeleccion"
        Me.gbSeleccion.Size = New System.Drawing.Size(434, 284)
        Me.gbSeleccion.TabIndex = 0
        Me.gbSeleccion.TabStop = False
        Me.gbSeleccion.Text = "Selection Criteria"
        '
        'celdaIDPais
        '
        Me.celdaIDPais.Location = New System.Drawing.Point(387, 98)
        Me.celdaIDPais.Name = "celdaIDPais"
        Me.celdaIDPais.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDPais.TabIndex = 26
        Me.celdaIDPais.Text = "-1"
        Me.celdaIDPais.Visible = False
        '
        'celdaIDProducto
        '
        Me.celdaIDProducto.Location = New System.Drawing.Point(387, 33)
        Me.celdaIDProducto.Name = "celdaIDProducto"
        Me.celdaIDProducto.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDProducto.TabIndex = 25
        Me.celdaIDProducto.Text = "-1"
        Me.celdaIDProducto.Visible = False
        '
        'checkBodega
        '
        Me.checkBodega.AutoSize = True
        Me.checkBodega.Location = New System.Drawing.Point(76, 240)
        Me.checkBodega.Name = "checkBodega"
        Me.checkBodega.Size = New System.Drawing.Size(139, 17)
        Me.checkBodega.TabIndex = 9
        Me.checkBodega.Text = "Show all the warehouse"
        Me.checkBodega.UseVisualStyleBackColor = True
        '
        'botonBodega
        '
        Me.botonBodega.Location = New System.Drawing.Point(387, 183)
        Me.botonBodega.Name = "botonBodega"
        Me.botonBodega.Size = New System.Drawing.Size(41, 23)
        Me.botonBodega.TabIndex = 8
        Me.botonBodega.Text = "..."
        Me.botonBodega.UseVisualStyleBackColor = True
        '
        'celdaBodega
        '
        Me.celdaBodega.Location = New System.Drawing.Point(76, 183)
        Me.celdaBodega.Multiline = True
        Me.celdaBodega.Name = "celdaBodega"
        Me.celdaBodega.Size = New System.Drawing.Size(303, 27)
        Me.celdaBodega.TabIndex = 7
        '
        'etiquetaBodega
        '
        Me.etiquetaBodega.AutoSize = True
        Me.etiquetaBodega.Location = New System.Drawing.Point(12, 186)
        Me.etiquetaBodega.Name = "etiquetaBodega"
        Me.etiquetaBodega.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaBodega.TabIndex = 6
        Me.etiquetaBodega.Text = "Warehouse"
        '
        'botonPaisOrigen
        '
        Me.botonPaisOrigen.Location = New System.Drawing.Point(387, 117)
        Me.botonPaisOrigen.Name = "botonPaisOrigen"
        Me.botonPaisOrigen.Size = New System.Drawing.Size(41, 23)
        Me.botonPaisOrigen.TabIndex = 5
        Me.botonPaisOrigen.Text = "..."
        Me.botonPaisOrigen.UseVisualStyleBackColor = True
        '
        'celdaPaisOrigen
        '
        Me.celdaPaisOrigen.Location = New System.Drawing.Point(24, 117)
        Me.celdaPaisOrigen.Multiline = True
        Me.celdaPaisOrigen.Name = "celdaPaisOrigen"
        Me.celdaPaisOrigen.Size = New System.Drawing.Size(355, 27)
        Me.celdaPaisOrigen.TabIndex = 4
        Me.celdaPaisOrigen.Text = "(Todo....)"
        '
        'etiquetPais
        '
        Me.etiquetPais.AutoSize = True
        Me.etiquetPais.Location = New System.Drawing.Point(12, 101)
        Me.etiquetPais.Name = "etiquetPais"
        Me.etiquetPais.Size = New System.Drawing.Size(87, 13)
        Me.etiquetPais.TabIndex = 3
        Me.etiquetPais.Text = "Country Of Origin"
        '
        'botonProductos
        '
        Me.botonProductos.Location = New System.Drawing.Point(387, 52)
        Me.botonProductos.Name = "botonProductos"
        Me.botonProductos.Size = New System.Drawing.Size(41, 23)
        Me.botonProductos.TabIndex = 2
        Me.botonProductos.Text = "..."
        Me.botonProductos.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.Location = New System.Drawing.Point(24, 52)
        Me.celdaProducto.Multiline = True
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.Size = New System.Drawing.Size(355, 27)
        Me.celdaProducto.TabIndex = 1
        Me.celdaProducto.Text = "(Todo....)"
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(12, 36)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaProducto.TabIndex = 0
        Me.etiquetaProducto.Text = "Product"
        '
        'frmInventoryWorsheet
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(434, 621)
        Me.Controls.Add(Me.panelPrincipal)
        Me.Name = "frmInventoryWorsheet"
        Me.Text = "frmInventoryWorsheet"
        Me.panelPrincipal.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        Me.gbOpcionesAdicionales.ResumeLayout(False)
        Me.gbOpcionesAdicionales.PerformLayout()
        Me.gbFechas.ResumeLayout(False)
        Me.gbFechas.PerformLayout()
        Me.gbSeleccion.ResumeLayout(False)
        Me.gbSeleccion.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelPrincipal As System.Windows.Forms.Panel
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents gbOpcionesAdicionales As System.Windows.Forms.GroupBox
    Friend WithEvents gbFechas As System.Windows.Forms.GroupBox
    Friend WithEvents gbSeleccion As System.Windows.Forms.GroupBox
    Friend WithEvents botonPaisOrigen As System.Windows.Forms.Button
    Friend WithEvents celdaPaisOrigen As System.Windows.Forms.TextBox
    Friend WithEvents etiquetPais As System.Windows.Forms.Label
    Friend WithEvents botonProductos As System.Windows.Forms.Button
    Friend WithEvents celdaProducto As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProducto As System.Windows.Forms.Label
    Friend WithEvents checkBodega As System.Windows.Forms.CheckBox
    Friend WithEvents botonBodega As System.Windows.Forms.Button
    Friend WithEvents celdaBodega As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaBodega As System.Windows.Forms.Label
    Friend WithEvents botonSeleccion2 As System.Windows.Forms.Button
    Friend WithEvents celdaSeleccion2 As System.Windows.Forms.TextBox
    Friend WithEvents botonSeleccion As System.Windows.Forms.Button
    Friend WithEvents celdaSeleccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaOrdenar As System.Windows.Forms.Label
    Friend WithEvents checkIncluirColumnas As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicial As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFinal As System.Windows.Forms.Label
    Friend WithEvents etiquetaInicial As System.Windows.Forms.Label
    Friend WithEvents celdaIDProducto As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDPais As System.Windows.Forms.TextBox
    Friend WithEvents checkRangeDate As System.Windows.Forms.CheckBox
End Class
