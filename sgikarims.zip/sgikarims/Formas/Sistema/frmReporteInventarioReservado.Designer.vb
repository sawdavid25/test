﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporteInventarioReservado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rbInventarioReservado = New System.Windows.Forms.RadioButton()
        Me.rbOrdenadoComprometido = New System.Windows.Forms.RadioButton()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'rbInventarioReservado
        '
        Me.rbInventarioReservado.AutoSize = True
        Me.rbInventarioReservado.Location = New System.Drawing.Point(86, 47)
        Me.rbInventarioReservado.Name = "rbInventarioReservado"
        Me.rbInventarioReservado.Size = New System.Drawing.Size(130, 17)
        Me.rbInventarioReservado.TabIndex = 0
        Me.rbInventarioReservado.TabStop = True
        Me.rbInventarioReservado.Text = "1) Reserved Inventory"
        Me.rbInventarioReservado.UseVisualStyleBackColor = True
        '
        'rbOrdenadoComprometido
        '
        Me.rbOrdenadoComprometido.AutoSize = True
        Me.rbOrdenadoComprometido.Location = New System.Drawing.Point(86, 80)
        Me.rbOrdenadoComprometido.Name = "rbOrdenadoComprometido"
        Me.rbOrdenadoComprometido.Size = New System.Drawing.Size(144, 17)
        Me.rbOrdenadoComprometido.TabIndex = 1
        Me.rbOrdenadoComprometido.TabStop = True
        Me.rbOrdenadoComprometido.Text = "2) Organized / Organized"
        Me.rbOrdenadoComprometido.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(114, 119)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 23)
        Me.botonAceptar.TabIndex = 2
        Me.botonAceptar.Text = "Continue"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(204, 119)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.botonCancelar.TabIndex = 3
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'frmReporteInventarioReservado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 179)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Controls.Add(Me.rbOrdenadoComprometido)
        Me.Controls.Add(Me.rbInventarioReservado)
        Me.Name = "frmReporteInventarioReservado"
        Me.Text = "frmReporteInventarioReservado"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rbInventarioReservado As RadioButton
    Friend WithEvents rbOrdenadoComprometido As RadioButton
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonCancelar As Button
End Class
