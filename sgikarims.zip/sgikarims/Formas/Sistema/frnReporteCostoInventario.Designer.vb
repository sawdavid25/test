﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frnReporteCostoInventario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.checkMostrarBodega = New System.Windows.Forms.CheckBox()
        Me.celdaIdBodega = New System.Windows.Forms.TextBox()
        Me.celdaIdPaisOrigen = New System.Windows.Forms.TextBox()
        Me.celdaIdProducto = New System.Windows.Forms.TextBox()
        Me.botonBodega = New System.Windows.Forms.Button()
        Me.celdaBodega = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BotonPaisOrigen = New System.Windows.Forms.Button()
        Me.celdaPaisOrigen = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.checkFiltrarFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaInventario = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.BotonOrdenar1 = New System.Windows.Forms.Button()
        Me.CeldaOrdenar1 = New System.Windows.Forms.TextBox()
        Me.BotonOrdernar = New System.Windows.Forms.Button()
        Me.CeldaOrdernar = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checkColumnasInventario = New System.Windows.Forms.CheckBox()
        Me.BotonAceptar = New System.Windows.Forms.Button()
        Me.BotonCancelar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.checkMostrarBodega)
        Me.GroupBox1.Controls.Add(Me.celdaIdBodega)
        Me.GroupBox1.Controls.Add(Me.celdaIdPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaIdProducto)
        Me.GroupBox1.Controls.Add(Me.botonBodega)
        Me.GroupBox1.Controls.Add(Me.celdaBodega)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.BotonPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.celdaPaisOrigen)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.botonProducto)
        Me.GroupBox1.Controls.Add(Me.celdaProducto)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(353, 219)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = " Criterion Of select"
        '
        'checkMostrarBodega
        '
        Me.checkMostrarBodega.AutoSize = True
        Me.checkMostrarBodega.Enabled = False
        Me.checkMostrarBodega.Location = New System.Drawing.Point(67, 196)
        Me.checkMostrarBodega.Name = "checkMostrarBodega"
        Me.checkMostrarBodega.Size = New System.Drawing.Size(99, 17)
        Me.checkMostrarBodega.TabIndex = 13
        Me.checkMostrarBodega.Text = "Show all winery"
        Me.checkMostrarBodega.UseVisualStyleBackColor = True
        '
        'celdaIdBodega
        '
        Me.celdaIdBodega.Location = New System.Drawing.Point(93, 129)
        Me.celdaIdBodega.Name = "celdaIdBodega"
        Me.celdaIdBodega.Size = New System.Drawing.Size(35, 20)
        Me.celdaIdBodega.TabIndex = 12
        Me.celdaIdBodega.Visible = False
        '
        'celdaIdPaisOrigen
        '
        Me.celdaIdPaisOrigen.Location = New System.Drawing.Point(113, 85)
        Me.celdaIdPaisOrigen.Name = "celdaIdPaisOrigen"
        Me.celdaIdPaisOrigen.Size = New System.Drawing.Size(35, 20)
        Me.celdaIdPaisOrigen.TabIndex = 10
        Me.celdaIdPaisOrigen.Text = "-1"
        Me.celdaIdPaisOrigen.Visible = False
        '
        'celdaIdProducto
        '
        Me.celdaIdProducto.Location = New System.Drawing.Point(90, 29)
        Me.celdaIdProducto.Name = "celdaIdProducto"
        Me.celdaIdProducto.Size = New System.Drawing.Size(35, 20)
        Me.celdaIdProducto.TabIndex = 9
        Me.celdaIdProducto.Text = "-1"
        Me.celdaIdProducto.Visible = False
        '
        'botonBodega
        '
        Me.botonBodega.Location = New System.Drawing.Point(260, 155)
        Me.botonBodega.Name = "botonBodega"
        Me.botonBodega.Size = New System.Drawing.Size(40, 23)
        Me.botonBodega.TabIndex = 8
        Me.botonBodega.Text = "..."
        Me.botonBodega.UseVisualStyleBackColor = True
        '
        'celdaBodega
        '
        Me.celdaBodega.Location = New System.Drawing.Point(85, 155)
        Me.celdaBodega.Name = "celdaBodega"
        Me.celdaBodega.Size = New System.Drawing.Size(169, 20)
        Me.celdaBodega.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 155)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Warehouse"
        '
        'BotonPaisOrigen
        '
        Me.BotonPaisOrigen.Location = New System.Drawing.Point(260, 109)
        Me.BotonPaisOrigen.Name = "BotonPaisOrigen"
        Me.BotonPaisOrigen.Size = New System.Drawing.Size(40, 23)
        Me.BotonPaisOrigen.TabIndex = 5
        Me.BotonPaisOrigen.Text = "..."
        Me.BotonPaisOrigen.UseVisualStyleBackColor = True
        '
        'celdaPaisOrigen
        '
        Me.celdaPaisOrigen.Enabled = False
        Me.celdaPaisOrigen.Location = New System.Drawing.Point(20, 111)
        Me.celdaPaisOrigen.Name = "celdaPaisOrigen"
        Me.celdaPaisOrigen.Size = New System.Drawing.Size(234, 20)
        Me.celdaPaisOrigen.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Country of origin"
        '
        'botonProducto
        '
        Me.botonProducto.Location = New System.Drawing.Point(260, 52)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(40, 23)
        Me.botonProducto.TabIndex = 2
        Me.botonProducto.Text = "..."
        Me.botonProducto.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.Enabled = False
        Me.celdaProducto.Location = New System.Drawing.Point(20, 54)
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.Size = New System.Drawing.Size(234, 20)
        Me.celdaProducto.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Product"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.checkFiltrarFecha)
        Me.GroupBox2.Controls.Add(Me.dtpFechaInventario)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 248)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(353, 94)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'checkFiltrarFecha
        '
        Me.checkFiltrarFecha.AutoSize = True
        Me.checkFiltrarFecha.Location = New System.Drawing.Point(38, 0)
        Me.checkFiltrarFecha.Name = "checkFiltrarFecha"
        Me.checkFiltrarFecha.Size = New System.Drawing.Size(90, 17)
        Me.checkFiltrarFecha.TabIndex = 2
        Me.checkFiltrarFecha.Text = "Filter By date "
        Me.checkFiltrarFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaInventario
        '
        Me.dtpFechaInventario.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInventario.Location = New System.Drawing.Point(150, 47)
        Me.dtpFechaInventario.Name = "dtpFechaInventario"
        Me.dtpFechaInventario.Size = New System.Drawing.Size(119, 20)
        Me.dtpFechaInventario.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Show Inventory Up"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.BotonOrdenar1)
        Me.GroupBox3.Controls.Add(Me.CeldaOrdenar1)
        Me.GroupBox3.Controls.Add(Me.BotonOrdernar)
        Me.GroupBox3.Controls.Add(Me.CeldaOrdernar)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.checkColumnasInventario)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 348)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(353, 100)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Additional options"
        '
        'BotonOrdenar1
        '
        Me.BotonOrdenar1.Location = New System.Drawing.Point(275, 57)
        Me.BotonOrdenar1.Name = "BotonOrdenar1"
        Me.BotonOrdenar1.Size = New System.Drawing.Size(25, 23)
        Me.BotonOrdenar1.TabIndex = 5
        Me.BotonOrdenar1.Text = "..."
        Me.BotonOrdenar1.UseVisualStyleBackColor = True
        '
        'CeldaOrdenar1
        '
        Me.CeldaOrdenar1.Location = New System.Drawing.Point(201, 59)
        Me.CeldaOrdenar1.Name = "CeldaOrdenar1"
        Me.CeldaOrdenar1.Size = New System.Drawing.Size(68, 20)
        Me.CeldaOrdenar1.TabIndex = 4
        '
        'BotonOrdernar
        '
        Me.BotonOrdernar.Location = New System.Drawing.Point(165, 59)
        Me.BotonOrdernar.Name = "BotonOrdernar"
        Me.BotonOrdernar.Size = New System.Drawing.Size(30, 23)
        Me.BotonOrdernar.TabIndex = 3
        Me.BotonOrdernar.Text = "..."
        Me.BotonOrdernar.UseVisualStyleBackColor = True
        '
        'CeldaOrdernar
        '
        Me.CeldaOrdernar.Location = New System.Drawing.Point(90, 60)
        Me.CeldaOrdernar.Name = "CeldaOrdernar"
        Me.CeldaOrdernar.Size = New System.Drawing.Size(69, 20)
        Me.CeldaOrdernar.TabIndex = 2
        Me.CeldaOrdernar.Text = "Referencia"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 64)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 13)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "Ordered for"
        '
        'checkColumnasInventario
        '
        Me.checkColumnasInventario.AutoSize = True
        Me.checkColumnasInventario.Location = New System.Drawing.Point(20, 34)
        Me.checkColumnasInventario.Name = "checkColumnasInventario"
        Me.checkColumnasInventario.Size = New System.Drawing.Size(202, 17)
        Me.checkColumnasInventario.TabIndex = 0
        Me.checkColumnasInventario.Text = "Include Columns for Inventory Taking"
        Me.checkColumnasInventario.UseVisualStyleBackColor = True
        '
        'BotonAceptar
        '
        Me.BotonAceptar.Location = New System.Drawing.Point(150, 479)
        Me.BotonAceptar.Name = "BotonAceptar"
        Me.BotonAceptar.Size = New System.Drawing.Size(75, 23)
        Me.BotonAceptar.TabIndex = 3
        Me.BotonAceptar.Text = "Accept"
        Me.BotonAceptar.UseVisualStyleBackColor = True
        '
        'BotonCancelar
        '
        Me.BotonCancelar.Location = New System.Drawing.Point(237, 479)
        Me.BotonCancelar.Name = "BotonCancelar"
        Me.BotonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.BotonCancelar.TabIndex = 4
        Me.BotonCancelar.Text = "Cancel"
        Me.BotonCancelar.UseVisualStyleBackColor = True
        '
        'frnReporteCostoInventario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(418, 519)
        Me.Controls.Add(Me.BotonCancelar)
        Me.Controls.Add(Me.BotonAceptar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frnReporteCostoInventario"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "FiltersReports"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents botonBodega As Button
    Friend WithEvents celdaBodega As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents BotonPaisOrigen As Button
    Friend WithEvents celdaPaisOrigen As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents botonProducto As Button
    Friend WithEvents celdaProducto As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents checkFiltrarFecha As System.Windows.Forms.CheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents BotonOrdenar1 As Button
    Friend WithEvents CeldaOrdenar1 As TextBox
    Friend WithEvents BotonOrdernar As Button
    Friend WithEvents CeldaOrdernar As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents checkColumnasInventario As System.Windows.Forms.CheckBox
    Friend WithEvents BotonAceptar As Button
    Friend WithEvents BotonCancelar As Button
    Friend WithEvents celdaIdBodega As TextBox
    Friend WithEvents celdaIdPaisOrigen As TextBox
    Friend WithEvents celdaIdProducto As TextBox
    Friend WithEvents checkMostrarBodega As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaInventario As DateTimePicker
End Class
