﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReservas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelReserva = New System.Windows.Forms.Panel()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.etiquetaMedida = New System.Windows.Forms.Label()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.celdaDisponible = New System.Windows.Forms.TextBox()
        Me.etiquetaDisponible = New System.Windows.Forms.Label()
        Me.celdaReservado = New System.Windows.Forms.TextBox()
        Me.etiquetaReservado = New System.Windows.Forms.Label()
        Me.celdaSaldo = New System.Windows.Forms.TextBox()
        Me.etiquetaSaldo = New System.Windows.Forms.Label()
        Me.panelDatosReserva = New System.Windows.Forms.Panel()
        Me.gboxDatosReserva = New System.Windows.Forms.GroupBox()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.etiquetaEstado = New System.Windows.Forms.Label()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAsignar = New System.Windows.Forms.Button()
        Me.botonEventos = New System.Windows.Forms.Button()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.etiquetaObservaciones = New System.Windows.Forms.Label()
        Me.celdaCantReservada = New System.Windows.Forms.TextBox()
        Me.etiquetaCantReservada = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.etiquetaCodigo = New System.Windows.Forms.Label()
        Me.etiquetaNombreCliente = New System.Windows.Forms.Label()
        Me.botonProveedores = New System.Windows.Forms.Button()
        Me.celdaNombreCliente = New System.Windows.Forms.TextBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonDesactivar = New System.Windows.Forms.Button()
        Me.botonModificar = New System.Windows.Forms.Button()
        Me.botonNuevo = New System.Windows.Forms.Button()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.panelDetallle = New System.Windows.Forms.Panel()
        Me.dgDetalleReserva = New System.Windows.Forms.DataGridView()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelReserva.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.panelDatosReserva.SuspendLayout()
        Me.gboxDatosReserva.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.panelDetallle.SuspendLayout()
        CType(Me.dgDetalleReserva, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelReserva
        '
        Me.panelReserva.Controls.Add(Me.panelTotales)
        Me.panelReserva.Controls.Add(Me.panelDatosReserva)
        Me.panelReserva.Controls.Add(Me.panelBotones)
        Me.panelReserva.Controls.Add(Me.panelDetallle)
        Me.panelReserva.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelReserva.Location = New System.Drawing.Point(0, 0)
        Me.panelReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelReserva.Name = "panelReserva"
        Me.panelReserva.Size = New System.Drawing.Size(877, 688)
        Me.panelReserva.TabIndex = 0
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.etiquetaMedida)
        Me.panelTotales.Controls.Add(Me.botonCerrar)
        Me.panelTotales.Controls.Add(Me.celdaDisponible)
        Me.panelTotales.Controls.Add(Me.etiquetaDisponible)
        Me.panelTotales.Controls.Add(Me.celdaReservado)
        Me.panelTotales.Controls.Add(Me.etiquetaReservado)
        Me.panelTotales.Controls.Add(Me.celdaSaldo)
        Me.panelTotales.Controls.Add(Me.etiquetaSaldo)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 596)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(877, 92)
        Me.panelTotales.TabIndex = 3
        '
        'etiquetaMedida
        '
        Me.etiquetaMedida.AutoSize = True
        Me.etiquetaMedida.Location = New System.Drawing.Point(197, 60)
        Me.etiquetaMedida.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMedida.Name = "etiquetaMedida"
        Me.etiquetaMedida.Size = New System.Drawing.Size(54, 17)
        Me.etiquetaMedida.TabIndex = 25
        Me.etiquetaMedida.Text = "Medida"
        '
        'botonCerrar
        '
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel4
        Me.botonCerrar.Location = New System.Drawing.Point(761, 30)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(100, 52)
        Me.botonCerrar.TabIndex = 24
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'celdaDisponible
        '
        Me.celdaDisponible.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDisponible.ForeColor = System.Drawing.Color.Blue
        Me.celdaDisponible.Location = New System.Drawing.Point(496, 57)
        Me.celdaDisponible.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDisponible.Multiline = True
        Me.celdaDisponible.Name = "celdaDisponible"
        Me.celdaDisponible.Size = New System.Drawing.Size(155, 25)
        Me.celdaDisponible.TabIndex = 23
        '
        'etiquetaDisponible
        '
        Me.etiquetaDisponible.AutoSize = True
        Me.etiquetaDisponible.Location = New System.Drawing.Point(492, 34)
        Me.etiquetaDisponible.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDisponible.Name = "etiquetaDisponible"
        Me.etiquetaDisponible.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaDisponible.TabIndex = 22
        Me.etiquetaDisponible.Text = "Available"
        '
        'celdaReservado
        '
        Me.celdaReservado.BackColor = System.Drawing.SystemColors.Info
        Me.celdaReservado.ForeColor = System.Drawing.Color.Red
        Me.celdaReservado.Location = New System.Drawing.Point(309, 57)
        Me.celdaReservado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaReservado.Multiline = True
        Me.celdaReservado.Name = "celdaReservado"
        Me.celdaReservado.Size = New System.Drawing.Size(157, 25)
        Me.celdaReservado.TabIndex = 21
        '
        'etiquetaReservado
        '
        Me.etiquetaReservado.AutoSize = True
        Me.etiquetaReservado.Location = New System.Drawing.Point(305, 34)
        Me.etiquetaReservado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaReservado.Name = "etiquetaReservado"
        Me.etiquetaReservado.Size = New System.Drawing.Size(69, 17)
        Me.etiquetaReservado.TabIndex = 20
        Me.etiquetaReservado.Text = "Reserved"
        '
        'celdaSaldo
        '
        Me.celdaSaldo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSaldo.Location = New System.Drawing.Point(31, 57)
        Me.celdaSaldo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaSaldo.Multiline = True
        Me.celdaSaldo.Name = "celdaSaldo"
        Me.celdaSaldo.Size = New System.Drawing.Size(144, 25)
        Me.celdaSaldo.TabIndex = 19
        '
        'etiquetaSaldo
        '
        Me.etiquetaSaldo.AutoSize = True
        Me.etiquetaSaldo.Location = New System.Drawing.Point(27, 34)
        Me.etiquetaSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSaldo.Name = "etiquetaSaldo"
        Me.etiquetaSaldo.Size = New System.Drawing.Size(59, 17)
        Me.etiquetaSaldo.TabIndex = 18
        Me.etiquetaSaldo.Text = "Balance"
        '
        'panelDatosReserva
        '
        Me.panelDatosReserva.Controls.Add(Me.gboxDatosReserva)
        Me.panelDatosReserva.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatosReserva.Location = New System.Drawing.Point(0, 310)
        Me.panelDatosReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDatosReserva.Name = "panelDatosReserva"
        Me.panelDatosReserva.Size = New System.Drawing.Size(877, 286)
        Me.panelDatosReserva.TabIndex = 2
        '
        'gboxDatosReserva
        '
        Me.gboxDatosReserva.Controls.Add(Me.celdaReferencia)
        Me.gboxDatosReserva.Controls.Add(Me.celdaEstado)
        Me.gboxDatosReserva.Controls.Add(Me.etiquetaEstado)
        Me.gboxDatosReserva.Controls.Add(Me.botonCancelar)
        Me.gboxDatosReserva.Controls.Add(Me.botonAsignar)
        Me.gboxDatosReserva.Controls.Add(Me.botonEventos)
        Me.gboxDatosReserva.Controls.Add(Me.celdaObservaciones)
        Me.gboxDatosReserva.Controls.Add(Me.etiquetaObservaciones)
        Me.gboxDatosReserva.Controls.Add(Me.celdaCantReservada)
        Me.gboxDatosReserva.Controls.Add(Me.etiquetaCantReservada)
        Me.gboxDatosReserva.Controls.Add(Me.celdaCodigo)
        Me.gboxDatosReserva.Controls.Add(Me.etiquetaCodigo)
        Me.gboxDatosReserva.Controls.Add(Me.etiquetaNombreCliente)
        Me.gboxDatosReserva.Controls.Add(Me.botonProveedores)
        Me.gboxDatosReserva.Controls.Add(Me.celdaNombreCliente)
        Me.gboxDatosReserva.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gboxDatosReserva.Location = New System.Drawing.Point(0, 0)
        Me.gboxDatosReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gboxDatosReserva.Name = "gboxDatosReserva"
        Me.gboxDatosReserva.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gboxDatosReserva.Size = New System.Drawing.Size(877, 286)
        Me.gboxDatosReserva.TabIndex = 0
        Me.gboxDatosReserva.TabStop = False
        Me.gboxDatosReserva.Text = "Datos Reserva"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(621, 100)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaReferencia.Multiline = True
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(148, 25)
        Me.celdaReferencia.TabIndex = 18
        Me.celdaReferencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaEstado
        '
        Me.celdaEstado.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.celdaEstado.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaEstado.Location = New System.Drawing.Point(31, 244)
        Me.celdaEstado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaEstado.Multiline = True
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.Size = New System.Drawing.Size(117, 25)
        Me.celdaEstado.TabIndex = 17
        Me.celdaEstado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaEstado
        '
        Me.etiquetaEstado.AutoSize = True
        Me.etiquetaEstado.Location = New System.Drawing.Point(27, 222)
        Me.etiquetaEstado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaEstado.Name = "etiquetaEstado"
        Me.etiquetaEstado.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaEstado.TabIndex = 16
        Me.etiquetaEstado.Text = "State"
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.botonCancelar.Location = New System.Drawing.Point(764, 208)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(100, 52)
        Me.botonCancelar.TabIndex = 15
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAsignar
        '
        Me.botonAsignar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_right_green
        Me.botonAsignar.Location = New System.Drawing.Point(640, 208)
        Me.botonAsignar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAsignar.Name = "botonAsignar"
        Me.botonAsignar.Size = New System.Drawing.Size(100, 52)
        Me.botonAsignar.TabIndex = 14
        Me.botonAsignar.Text = "Assign"
        Me.botonAsignar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAsignar.UseVisualStyleBackColor = True
        '
        'botonEventos
        '
        Me.botonEventos.Image = Global.KARIMs_SGI.My.Resources.Resources.zoom
        Me.botonEventos.Location = New System.Drawing.Point(640, 133)
        Me.botonEventos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonEventos.Name = "botonEventos"
        Me.botonEventos.Size = New System.Drawing.Size(100, 52)
        Me.botonEventos.TabIndex = 13
        Me.botonEventos.Text = "Events"
        Me.botonEventos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonEventos.UseVisualStyleBackColor = True
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Location = New System.Drawing.Point(161, 133)
        Me.celdaObservaciones.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(451, 144)
        Me.celdaObservaciones.TabIndex = 12
        '
        'etiquetaObservaciones
        '
        Me.etiquetaObservaciones.AutoSize = True
        Me.etiquetaObservaciones.Location = New System.Drawing.Point(157, 111)
        Me.etiquetaObservaciones.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaObservaciones.Name = "etiquetaObservaciones"
        Me.etiquetaObservaciones.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaObservaciones.TabIndex = 11
        Me.etiquetaObservaciones.Text = "Observations"
        '
        'celdaCantReservada
        '
        Me.celdaCantReservada.Location = New System.Drawing.Point(31, 133)
        Me.celdaCantReservada.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCantReservada.Multiline = True
        Me.celdaCantReservada.Name = "celdaCantReservada"
        Me.celdaCantReservada.Size = New System.Drawing.Size(117, 25)
        Me.celdaCantReservada.TabIndex = 10
        Me.celdaCantReservada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaCantReservada
        '
        Me.etiquetaCantReservada.AutoSize = True
        Me.etiquetaCantReservada.Location = New System.Drawing.Point(27, 111)
        Me.etiquetaCantReservada.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCantReservada.Name = "etiquetaCantReservada"
        Me.etiquetaCantReservada.Size = New System.Drawing.Size(121, 17)
        Me.etiquetaCantReservada.TabIndex = 9
        Me.etiquetaCantReservada.Text = "Reserved Amount"
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Location = New System.Drawing.Point(621, 57)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCodigo.Multiline = True
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.Size = New System.Drawing.Size(148, 25)
        Me.celdaCodigo.TabIndex = 8
        Me.celdaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaCodigo
        '
        Me.etiquetaCodigo.AutoSize = True
        Me.etiquetaCodigo.Location = New System.Drawing.Point(617, 34)
        Me.etiquetaCodigo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCodigo.Name = "etiquetaCodigo"
        Me.etiquetaCodigo.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaCodigo.TabIndex = 7
        Me.etiquetaCodigo.Text = "Code"
        '
        'etiquetaNombreCliente
        '
        Me.etiquetaNombreCliente.AutoSize = True
        Me.etiquetaNombreCliente.Location = New System.Drawing.Point(27, 34)
        Me.etiquetaNombreCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNombreCliente.Name = "etiquetaNombreCliente"
        Me.etiquetaNombreCliente.Size = New System.Drawing.Size(109, 17)
        Me.etiquetaNombreCliente.TabIndex = 6
        Me.etiquetaNombreCliente.Text = "Customer Name"
        '
        'botonProveedores
        '
        Me.botonProveedores.Location = New System.Drawing.Point(496, 54)
        Me.botonProveedores.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonProveedores.Name = "botonProveedores"
        Me.botonProveedores.Size = New System.Drawing.Size(51, 27)
        Me.botonProveedores.TabIndex = 5
        Me.botonProveedores.Text = "..."
        Me.botonProveedores.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonProveedores.UseVisualStyleBackColor = True
        '
        'celdaNombreCliente
        '
        Me.celdaNombreCliente.Location = New System.Drawing.Point(31, 54)
        Me.celdaNombreCliente.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNombreCliente.Multiline = True
        Me.celdaNombreCliente.Name = "celdaNombreCliente"
        Me.celdaNombreCliente.ReadOnly = True
        Me.celdaNombreCliente.Size = New System.Drawing.Size(456, 25)
        Me.celdaNombreCliente.TabIndex = 0
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonEliminar)
        Me.panelBotones.Controls.Add(Me.botonDesactivar)
        Me.panelBotones.Controls.Add(Me.botonModificar)
        Me.panelBotones.Controls.Add(Me.botonNuevo)
        Me.panelBotones.Controls.Add(Me.celdaProducto)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelBotones.Location = New System.Drawing.Point(0, 187)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(877, 123)
        Me.panelBotones.TabIndex = 1
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(761, 31)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(100, 52)
        Me.botonEliminar.TabIndex = 4
        Me.botonEliminar.Text = "Delete"
        Me.botonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonDesactivar
        '
        Me.botonDesactivar.Image = Global.KARIMs_SGI.My.Resources.Resources.flag_red
        Me.botonDesactivar.Location = New System.Drawing.Point(653, 31)
        Me.botonDesactivar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonDesactivar.Name = "botonDesactivar"
        Me.botonDesactivar.Size = New System.Drawing.Size(100, 52)
        Me.botonDesactivar.TabIndex = 3
        Me.botonDesactivar.Text = "Desactive"
        Me.botonDesactivar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonDesactivar.UseVisualStyleBackColor = True
        '
        'botonModificar
        '
        Me.botonModificar.Image = Global.KARIMs_SGI.My.Resources.Resources.edit_21
        Me.botonModificar.Location = New System.Drawing.Point(545, 31)
        Me.botonModificar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonModificar.Name = "botonModificar"
        Me.botonModificar.Size = New System.Drawing.Size(100, 52)
        Me.botonModificar.TabIndex = 2
        Me.botonModificar.Text = "Modify"
        Me.botonModificar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonModificar.UseVisualStyleBackColor = True
        '
        'botonNuevo
        '
        Me.botonNuevo.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonNuevo.Location = New System.Drawing.Point(437, 31)
        Me.botonNuevo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonNuevo.Name = "botonNuevo"
        Me.botonNuevo.Size = New System.Drawing.Size(100, 52)
        Me.botonNuevo.TabIndex = 1
        Me.botonNuevo.Text = "New"
        Me.botonNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevo.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.BackColor = System.Drawing.SystemColors.Info
        Me.celdaProducto.Location = New System.Drawing.Point(31, 31)
        Me.celdaProducto.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaProducto.Multiline = True
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.Size = New System.Drawing.Size(383, 51)
        Me.celdaProducto.TabIndex = 0
        '
        'panelDetallle
        '
        Me.panelDetallle.Controls.Add(Me.dgDetalleReserva)
        Me.panelDetallle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDetallle.Location = New System.Drawing.Point(0, 0)
        Me.panelDetallle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDetallle.Name = "panelDetallle"
        Me.panelDetallle.Size = New System.Drawing.Size(877, 187)
        Me.panelDetallle.TabIndex = 0
        '
        'dgDetalleReserva
        '
        Me.dgDetalleReserva.AllowUserToAddRows = False
        Me.dgDetalleReserva.AllowUserToDeleteRows = False
        Me.dgDetalleReserva.AllowUserToOrderColumns = True
        Me.dgDetalleReserva.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.dgDetalleReserva.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalleReserva.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNombre, Me.colCantidad, Me.colNota, Me.colLinea, Me.colID, Me.colEstado})
        Me.dgDetalleReserva.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalleReserva.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalleReserva.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDetalleReserva.Name = "dgDetalleReserva"
        Me.dgDetalleReserva.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalleReserva.Size = New System.Drawing.Size(877, 187)
        Me.dgDetalleReserva.TabIndex = 0
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.Width = 74
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Amount"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 85
        '
        'colNota
        '
        Me.colNota.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNota.HeaderText = "Note"
        Me.colNota.Name = "colNota"
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        '
        'colID
        '
        Me.colID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.Visible = False
        '
        'colEstado
        '
        Me.colEstado.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.Visible = False
        '
        'frmReservas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(877, 688)
        Me.Controls.Add(Me.panelReserva)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmReservas"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmReservas"
        Me.panelReserva.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelDatosReserva.ResumeLayout(False)
        Me.gboxDatosReserva.ResumeLayout(False)
        Me.gboxDatosReserva.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        Me.panelBotones.PerformLayout()
        Me.panelDetallle.ResumeLayout(False)
        CType(Me.dgDetalleReserva, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelReserva As System.Windows.Forms.Panel
    Friend WithEvents panelTotales As System.Windows.Forms.Panel
    Friend WithEvents panelDatosReserva As System.Windows.Forms.Panel
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents panelDetallle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalleReserva As System.Windows.Forms.DataGridView
    Friend WithEvents celdaProducto As System.Windows.Forms.TextBox
    Friend WithEvents botonNuevo As System.Windows.Forms.Button
    Friend WithEvents gboxDatosReserva As System.Windows.Forms.GroupBox
    Friend WithEvents botonEliminar As System.Windows.Forms.Button
    Friend WithEvents botonDesactivar As System.Windows.Forms.Button
    Friend WithEvents botonModificar As System.Windows.Forms.Button
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents celdaDisponible As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDisponible As System.Windows.Forms.Label
    Friend WithEvents celdaReservado As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaReservado As System.Windows.Forms.Label
    Friend WithEvents celdaSaldo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSaldo As System.Windows.Forms.Label
    Friend WithEvents celdaEstado As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEstado As System.Windows.Forms.Label
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAsignar As System.Windows.Forms.Button
    Friend WithEvents botonEventos As System.Windows.Forms.Button
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaObservaciones As System.Windows.Forms.Label
    Friend WithEvents celdaCantReservada As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCantReservada As System.Windows.Forms.Label
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCodigo As System.Windows.Forms.Label
    Friend WithEvents etiquetaNombreCliente As System.Windows.Forms.Label
    Friend WithEvents botonProveedores As System.Windows.Forms.Button
    Friend WithEvents celdaNombreCliente As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMedida As System.Windows.Forms.Label
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNota As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEstado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
End Class
