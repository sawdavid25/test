﻿Public Class FrmInventario
#Region "Variables"
    Dim strTemp As String
    Dim strKey As String
#End Region
#Region "Propiedades"
    Public Property key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public WriteOnly Property ArchivoTemporal As String
        Set(value As String)
            strTemp = value
        End Set
    End Property
    Public WriteOnly Property Cadena As String
        Set(value As String)
            strTemp = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Public Function ComprabarDatos() As Boolean
        Dim logVerdadero = True
        If celdaCodigoInventario.Text <> STR_VACIO Then
            If cFunciones.ValidarCampoNumerico(celdaCodigoInventario) Then
            Else
                logVerdadero = False
            End If
        End If

        If celdaCodigoProducto.Text <> STR_VACIO Then
            If cFunciones.ValidarCampoNumerico(celdaCodigoProducto) Then
            Else
                logVerdadero = False
            End If
        End If
        Return logVerdadero
    End Function
    Private Function SQLInventarioPF(Optional CodigoInventario As Integer = NO_FILA, Optional CodigoProducto As Integer = NO_FILA, Optional strTitulo As String = STR_VACIO, Optional intPais As Integer = NO_FILA, Optional strDescripcionCorta As String = STR_VACIO, Optional intAcabado As Integer = NO_FILA, Optional intClase As Integer = NO_FILA, Optional intRegion As Integer = NO_FILA, Optional intSpinning As Integer = NO_FILA, Optional checkHeathers As Boolean = False, Optional rbCadenaInsr As Boolean = False, Optional rbCadena1 As Boolean = False, Optional rbCadena3 As Boolean = False, Optional checkMuestra As Boolean = False) As String
        Dim strSQL As String
        strSQL = vbNullString
        strSQL = " SELECT " & vbCr
        strSQL &= " IFNULL(d.DDoc_RF2_NUM,0) estadoE, /*IF(IFNULL(d.DDoc_RF2_Num,0)=0,'GOOD',if(d.DDoc_RF2_NUM=1,'CLEARENCE','BAD')) EstadoH,*/ IFNULL(cat.cat_desc,' ') EstadoH,"
        strSQL &= "     i.inv_artcodigo Codigo,a.art_codigo Producto, d.DDoc_Prd_Cod Codigo, CONCAT(a.art_DCorta,'') Descripcion, cp.cat_clave Origen, i.inv_prodlote Lote, i.inv_prodsem Semana, i.inv_costo Costo,"
        strSQL &= "     COALESCE(e.HDoc_DR1_Num,'') Factura, IFNULL(d.DDoc_RF2_Cod,'') Bodega, IFNULL(IFNULL(p.pro_nombre,p.pro_proveedor),'N/A') Proveedor, COALESCE(dc.ADoc_Dta_Txt,'N/A') Contenedor,"
        strSQL &= "     IFNULL(IF(e.HDoc_DR1_Emp=0,e.HDoc_Doc_Fec,"
        strSQL &= "             (SELECT r.HDoc_Doc_Fec FROM Dcmtos_HDR r "
        strSQL &= "              WHERE r.HDoc_Sis_Emp=e.HDoc_DR1_Emp AND r.HDoc_Doc_Cat=e.HDoc_Pro_DCat AND r.HDoc_Doc_Ano=e.HDoc_Pro_DAno AND r.HDoc_Doc_Num=e.HDoc_Pro_DNum LIMIT 1)), '') ETA, "
        strSQL &= "     '' Declaracion, '' Partida, IFNULL(CONCAT('>', IFNULL(c.ADoc_Dta_Txt,''),'.\n#','.\n*',ifnull(i.inv_notas,''),'.\n*', d.DDoc_RF1_Txt ,'.'),'') Notas, IFNULL(cm.cat_clave,'') Unidad," & vbCr
        strSQL &= "     ROUND((d.DDoc_Prd_QTY - IFNULL((SELECT SUM(p.PDoc_QTY_Pro)"
        strSQL &= "                                     FROM Dcmtos_DTL_Pro p " & vbCr
        strSQL &= "                                          INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND h.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND h.HDoc_Doc_Num = p.PDoc_Chi_Num "
        strSQL &= "                                     WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 48),0)) * IF(ROUND(cm.cat_sist,4)=0,1,ROUND(cm.cat_sist,4)),2) Cantidad," & vbCr
        strSQL &= "     ((SELECT IFNULL(SUM(BDoc_Box_QTY),0) Cantidad FROM Dcmtos_DTL_Box WHERE BDoc_Sis_Emp = d.DDoc_Sis_Emp AND BDoc_Doc_Cat = d.DDoc_Doc_Cat AND BDoc_Doc_Ano = d.DDoc_Doc_Ano AND BDoc_Doc_Num = d.DDoc_Doc_Num AND BDoc_Doc_Lin = d.DDoc_Doc_Lin) - "
        strSQL &= "      (SELECT IFNULL(SUM(BDoc_Box_QTY),0) Cantidad "
        strSQL &= "       FROM Dcmtos_DTL_Pro p"
        strSQL &= "            LEFT JOIN Dcmtos_DTL_Box ON BDoc_Sis_Emp = p.PDoc_Sis_Emp AND BDoc_Doc_Cat = p.PDoc_Chi_Cat AND BDoc_Doc_Ano = p.PDoc_Chi_Ano AND BDoc_Doc_Num = p.PDoc_Chi_Num AND BDoc_Doc_Lin = p.PDoc_Chi_Lin"
        strSQL &= "            LEFT JOIN Dcmtos_HDR n ON n.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND n.HDoc_Doc_Cat=p.PDoc_Chi_Cat AND n.HDoc_Doc_Ano=p.PDoc_Chi_Ano AND n.HDoc_Doc_Num=p.PDoc_Chi_Num "
        strSQL &= "       WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat=@despacho AND IFNULL(n.HDoc_Doc_Status,-1)=1)) Cajas," & vbCr
        strSQL &= "     ROUND(i.inv_costo * (d.DDoc_Prd_QTY - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
        strSQL &= "                                                     FROM Dcmtos_DTL_Pro p"
        strSQL &= "                                                     WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin),0)),2) Monto, " & vbCr
        strSQL &= "     IFNULL((SELECT SUM(v.cantidad) Cantidad FROM Reserva v WHERE v.id_empresa=d.DDoc_Sis_Emp AND v.doc_tipo=d.DDoc_Doc_Cat AND v.doc_ciclo=d.DDoc_Doc_Ano AND v.doc_num=d.DDoc_Doc_Num AND v.doc_lin=d.DDoc_Doc_Lin AND NOT(v.estado=2)),0) Reservado, "
        strSQL &= "     IFNULL((SELECT GROUP_CONCAT(CONCAT(CAST(FORMAT(v.cantidad,2) AS CHAR),' / ',v.nombre) SEPARATOR '|') Dato FROM Reserva v WHERE v.id_empresa=d.DDoc_Sis_Emp AND v.doc_tipo=d.DDoc_Doc_Cat AND v.doc_ciclo=d.DDoc_Doc_Ano AND v.doc_num=d.DDoc_Doc_Num AND v.doc_lin=d.DDoc_Doc_Lin AND NOT(v.estado=2)),'') Cliente "
        strSQL &= " FROM Dcmtos_DTL d" & vbCr
        strSQL &= "      INNER JOIN Inventarios i    ON i.inv_sisemp    = d.DDoc_Sis_Emp  AND i.inv_numero    = d.DDoc_Prd_Cod" & vbCr
        strSQL &= "      INNER JOIN Articulos a      ON a.art_sisemp    = d.DDoc_Sis_Emp  AND a.art_codigo    = i.inv_artcodigo" & vbCr
        strSQL &= "      INNER JOIN Dcmtos_HDR e     ON e.HDoc_Sis_Emp  = d.DDoc_Sis_Emp  AND e.HDoc_Doc_Cat  = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano  = d.DDoc_Doc_Ano  AND e.HDoc_Doc_Num  = d.DDoc_Doc_Num" & vbCr
        strSQL &= "      LEFT JOIN Proveedores p     ON p.pro_sisemp    = d.DDoc_Sis_Emp  AND p.pro_codigo    = i.inv_provcod" & vbCr
        strSQL &= "      LEFT JOIN Catalogos cm      ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM" & vbCr
        strSQL &= "      LEFT JOIN Catalogos cp      ON cp.cat_clase = 'Paises' AND cp.cat_num = i.inv_lugarfab " & vbCr
        strSQL &= "      LEFT JOIN Catalogos cn ON cn.cat_clase = 'Countries' AND cn.cat_num = cp.cat_pid " & vbCr
        strSQL &= "      LEFT JOIN Catalogos cc      ON cc.cat_num      = a.art_clase" & vbCr
        strSQL &= "      LEFT JOIN Catalogos ca      ON ca.cat_num      = a.art_acabado" & vbCr
        strSQL &= "      LEFT JOIN Catalogos cs      ON cs.cat_num      = a.art_spinning" & vbCr
        strSQL &= "      LEFT JOIN Catalogos cat ON cat.cat_num = d.DDoc_RF2_Num AND cat.cat_clase = 'StatusIngBdg'" & vbCr
        strSQL &= "      LEFT JOIN Dcmtos_DTL_Pro rp ON rp.PDoc_Sis_Emp = d.DDoc_Sis_Emp  AND rp.PDoc_Chi_Cat = d.DDoc_Doc_Cat  AND rp.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND rp.PDoc_Chi_Num = d.DDoc_Doc_Num  AND rp.PDoc_Chi_Lin = d.DDoc_Doc_Lin" & vbCr
        strSQL &= "      LEFT JOIN Dcmtos_DTL_Pro rd ON rd.PDoc_Sis_Emp = rp.PDoc_Sis_Emp AND rd.PDoc_Chi_Cat = rp.PDoc_Par_Cat AND rd.PDoc_Chi_Ano = rp.PDoc_Par_Ano AND rd.PDoc_Chi_Num = rp.PDoc_Par_Num AND rd.PDoc_Chi_Lin = rp.PDoc_Par_Lin" & vbCr
        strSQL &= "      LEFT JOIN Dcmtos_DTL_Pro rc ON rc.PDoc_Sis_Emp = rd.PDoc_Sis_Emp AND rc.PDoc_Chi_Cat = rd.PDoc_Par_Cat AND rc.PDoc_Chi_Ano = rd.PDoc_Par_Ano AND rc.PDoc_Chi_Num = rd.PDoc_Par_Num AND rc.PDoc_Chi_Lin = rd.PDoc_Par_Lin" & vbCr
        strSQL &= "      LEFT JOIN Dcmtos_ACC c ON c.ADoc_Sis_Emp = d.DDoc_Sis_Emp AND c.ADoc_Doc_Cat = d.DDoc_Doc_Cat AND c.ADoc_Doc_Ano = d.DDoc_Doc_Ano AND c.ADoc_Doc_Num = d.DDoc_Doc_Num AND c.ADoc_Doc_Sub = 'Doc_DIngreso' AND c.ADoc_Doc_Lin = '04'"
        'If logPartida Then
        '    strSQL = strSQL & "   LEFT JOIN Dcmtos_DEC de ON de.EDoc_Sis_Emp=rp.PDoc_Sis_Emp AND de.EDoc_Doc_Cat=rp.PDoc_Par_Cat AND de.EDoc_Doc_Ano=rp.PDoc_Par_Ano AND de.EDoc_Doc_Num=rp.PDoc_Par_Num AND de.EDoc_Doc_Lin=rp.PDoc_Par_Lin " & vbCr
        'End If
        strSQL &= "      LEFT JOIN Dcmtos_ACC dp     ON dp.ADoc_Sis_Emp = rp.PDoc_Sis_Emp AND dp.ADoc_Doc_Cat = rp.PDoc_Par_Cat AND dp.ADoc_Doc_Ano = rp.PDoc_Par_Ano AND dp.ADoc_Doc_Num = rp.PDoc_Par_Num  AND dp.ADoc_Doc_Sub = 'Doc_PolImp'    AND dp.ADoc_Doc_Lin = '01'" & vbCr
        strSQL &= "      LEFT JOIN Dcmtos_ACC dc     ON dc.ADoc_Sis_Emp = rd.PDoc_Sis_Emp AND dc.ADoc_Doc_Cat = rd.PDoc_Par_Cat AND dc.ADoc_Doc_Ano = rd.PDoc_Par_Ano AND dc.ADoc_Doc_Num = rd.PDoc_Par_Num  AND dc.ADoc_Doc_Sub = 'Doc_PBLading'  AND dc.ADoc_Doc_Lin = '04'" & vbCr
        strSQL &= "      LEFT JOIN Dcmtos_ACC df     ON df.ADoc_Sis_Emp = rc.PDoc_Sis_Emp AND df.ADoc_Doc_Cat = rc.PDoc_Par_Cat AND df.ADoc_Doc_Ano = rc.PDoc_Par_Ano AND df.ADoc_Doc_Num = rc.PDoc_Par_Num  AND df.ADoc_Doc_Sub = 'Doc_PFactura'  AND df.ADoc_Doc_Lin = '15'" & vbCr
        strSQL &= " WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND d.DDoc_Doc_Cat = 47 AND NOT(cc.cat_sist IN ('Art_CHEM','Art_OTHER','Art_TELA')) " & vbCr



        If checkHeathers = True Then
            strSQL &= " AND art_heather = 1 "
        Else
            ' strSQL &= " AND art_heather = 0 "
        End If
        If strTitulo <> STR_VACIO Then
            strSQL &= " AND art_titulo Like '%{titulo}%'"
            strSQL = Replace(strSQL, "{titulo}", strTitulo)
        End If
        If CodigoInventario <> NO_FILA Then

            strSQL &= " AND inv_numero = {inventario}"
            strSQL = Replace(strSQL, "{inventario}", CodigoInventario)
        End If
        If CodigoProducto <> NO_FILA Then
            strSQL &= " AND inv_artcodigo = {producto} "
            strSQL = Replace(strSQL, "{producto}", CodigoProducto)
        End If
        If checkMuestra = True Then
            strSQL &= " AND inv_muestra = 1 "
        Else
            '  strSQL &= " AND inv_muestra = 0 "
        End If

        If strDescripcionCorta <> STR_VACIO Then
            If rbCadenaInsr = True Then
                strSQL &= " And InStr(art_DCorta,'{descripcion}')"
                strSQL = Replace(strSQL, "{descripcion}", strDescripcionCorta)
            End If
            If rbCadena1 = True Then
                strSQL &= " AND art_DCorta LIKE '{descripcion}%'"
                strSQL = Replace(strSQL, "{descripcion}", strDescripcionCorta)
            End If
            If rbCadena3 = True Then
                strSQL &= " AND art_DCorta LIKE '%{descripcion}' "
                strSQL = Replace(strSQL, "{descripcion}", strDescripcionCorta)
            End If

        End If
        If intClase <> NO_FILA Then
            strSQL &= " AND art_clase ={clase}"
            strSQL = Replace(strSQL, "{clase}", intClase)
        End If
        If intPais <> NO_FILA Then
            strSQL &= " AND inv_lugarfab = {pais}"
            strSQL = Replace(strSQL, "{pais}", intPais)
        End If
        If intSpinning <> NO_FILA Then
            strSQL &= " AND art_spinning = {spinning}"
            strSQL = Replace(strSQL, "{spinning}", intSpinning)
        End If
        If intAcabado <> NO_FILA Then
            strSQL &= " AND art_acabado = {acabado}"
            strSQL = Replace(strSQL, "{acabado}", intAcabado)
        End If
        If celdaidCountry.Text <> NO_FILA Then
            strSQL &= " AND cn.cat_num = {country}"
            strSQL = Replace(strSQL, "{country}", celdaidCountry.Text)
        End If
        If celdaidEstado.Text <> NO_FILA Then
            If celdaidEstado.Text = INT_CERO Then
                strSQL &= " AND ( d.DDoc_RF2_Num is null  OR d.DDoc_RF2_Num = {estadoE} )"
                strSQL = Replace(strSQL, "{estadoE}", celdaidEstado.Text)
            Else
                strSQL &= " AND d.DDoc_RF2_Num = {estadoE}"
                strSQL = Replace(strSQL, "{estadoE}", celdaidEstado.Text)
            End If
        End If




        strSQL &= " GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin" & vbCr
        strSQL &= " HAVING ABS(Cantidad) > 0.9 " & vbCr
        strSQL &= " ORDER BY cp.cat_ext, a.art_DCorta, p.pro_proveedor, i.inv_prodano, i.inv_prodsem" & vbCr



        strSQL = Replace(strSQL, "@tipo", 47)
        strSQL = Replace(strSQL, "@despacho", 48)
        Return strSQL
    End Function
    Public Sub ReporteInventarioPF(Optional CodigoInventario As Integer = NO_FILA, Optional CodigoProducto As Integer = NO_FILA, Optional StrTituloH As String = STR_VACIO, Optional intPais As Integer = NO_FILA, Optional strDescripcionCorta As String = STR_VACIO, Optional intAcabado As Integer = NO_FILA, Optional intClase As Integer = NO_FILA, Optional intRegion As Integer = NO_FILA, Optional intSpinning As Integer = NO_FILA, Optional checkHeathers As Boolean = False, Optional rbCadenaInsr As Boolean = False, Optional rbCadena1 As Boolean = False, Optional rbCadena3 As Boolean = False, Optional checkMuestra As Boolean = False)
        Const STR_TITULO As String = "Inventory Report"
        Const I_TIPO As Integer = 0
        Const I_PAIS As Integer = 1
        Const I_TODO As Integer = 2

        Const C_PESO As Integer = 0
        Const C_MONTO As Integer = 1
        Const C_RESERVA As Integer = 2
        Const C_SALDO As Integer = 3

        Dim strSQl As String = STR_VACIO
        Dim strHTML As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim f As Byte
        Dim strTitulo As String
        Dim strSubtitulo As String
        Dim strFila As String
        Dim strLinea As String
        Dim Totales(3, 4) As Double
        Dim Datos(3) As String
        Dim intLinea As Integer
        Dim strNota As String
        Dim dblSaldo As Double
        Dim Grupos(2) As String
        Dim logPartida As Boolean = False
        Dim logBodega As Boolean = False
        Dim logDec As Boolean = False
        Dim cReportes As New clsReportes
        'Conexiones'
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim conec As New MySqlConnection

        Try
            Dim frmMsj As New frmMensaje


            frmMsj.Mensaje = "Consulting Data"
            frmMsj.Show()
            system.Windows.Forms.Application.DoEvents()

            strHTML = "<style type='text/css'> " & vbCr &
          "   table {table-layout: fixed; empty-cells: show; border-collapse:collapse} " &
          "   caption {padding: 5px; text-align:left; font-family: Tahoma, Arial;font-size: 8pt} " &
          "   th {width: 1.8cm; border:none Silver 1px; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt} " &
          "   td {vertical-align: top; text-align:center; border:none Silver 1px; padding:1px 3px; font-family: Tahoma, Arial;font-size: 7pt} " &
          "   td.numero {text-align:right; mso-number-format:\#\,\#\#0\.00} " &
          "   .titulo {font-family: Tahoma, Arial;font-size: 9pt} " &
          "   .encabezado {text-align: left; border: none; width: 3.1cm} " &
          "   .pie {font-family: Tahoma, Arial;font-size: 7pt} " &
          "   .izquierda {text-align:left} " &
          "   .centro {text-align:center} " &
          "   .derecha {text-align:right} " &
          "   .info {text-align:left; border:none} " & vbCr &
          "</style>"


            strTemp = cFunciones.ArchivoTemporal()
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Output)
            Print(f, "<html>")
            Print(f, "<head>")
            Print(f, "<title>" & STR_TITULO & "</title>")
            Print(f, strHTML)
            Print(f, "</head>")
            Print(f, "<body>")
            strTitulo = vbNullString
            strSubtitulo = vbNullString
            frmMsj.Mensaje = "Showing report"
            '1) >>> Título del reporte
            Print(f, "<span class='titulo'><b>" & Sesion.Empresa & " SA " & "</b></span><br><br>")
            Print(f, "<span class='titulo'><b> INVENTORY </b></span><br/>")
            Print(f, "<span class='pie'><b>" & strSubtitulo & "</b></span><br/>") '& IIf(strSubtitulo = vbNullString, vbNullString, "<br/>"))
            Print(f, "<span class='pie'>DATE " & Format(Now() & "</span><br/>"))
            Print(f, "<br/>")


            Print(f, "<table cellspacing=0>")
            strFila = "{titulo}|{lote}|{semana}|{fabricante}|{contenedor}|{factura}|" & IIf(logBodega, "{bodega}|' ", vbNullString) & "{libras};A=N|{unidades}|{precio}|{cajas}|{monto};A=N|{reservado};A=N|{disponible};A=N|{cliente}|{fecha}|{notas}"

            '2) >>> Encabezado de columnas: style='width: 1cm'

            Print(f, "<th style='border: solid black 1px; width: 2.0cm'>Status</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.0cm'>Code</th>")
            Print(f, "<th style='border: solid black 1px; width: 7.6cm'>YARN COUNT</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.5cm'>LOT N.</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.0cm'>WEEK</th>")
            Print(f, "<th style='border: solid black 1px; width: 3.1cm'>MILL</th>")
            Print(f, "<th style='border: solid black 1px; width: 2.3cm'>CONTAINER</th>")
            Print(f, "<th style='border: solid black 1px; width: 2.0cm'>INVOICE</th>")

            Print(f, "<th style='border: solid black 1px; width: 2.0cm'>POUNDS</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.0cm'>UNIT</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.4cm'>U/PRICE</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.2cm'>BOXES</th>")
            Print(f, "<th style='border: solid black 1px; width: 2.0cm'>AMOUNT</th>")
            Print(f, "<th style='border: solid black 1px; width: 2.0cm'>RESERVED</th>")
            Print(f, "<th style='border: solid black 1px; width: 2.0cm'>AVAILABLE</th>")
            Print(f, "<th style='border: solid black 1px; width: 4.0cm'>CUSTOMER</th>")
            Print(f, "<th style='border: solid black 1px; width: 1.6cm'>DATE</th>")
            Print(f, "<th style='border: solid black 1px; width: 3.6cm'>COMMENTS</th>")
            Print(f, "</tr>")

            strSQl = SQLInventarioPF(CodigoInventario, CodigoProducto, StrTituloH, intPais, strDescripcionCorta, intAcabado, intClase, intRegion, intSpinning, checkHeathers, rbCadenaInsr, rbCadena1, rbCadena3, checkMuestra)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            Do While REA.Read
                If Not (Datos(I_PAIS) = REA.GetString("Origen")) Then
                    Datos(I_PAIS) = REA.GetString("Origen")
                    Datos(I_TIPO) = REA.GetInt32("Producto")
                    If intLinea > vbEmpty Then
                        'Subtotal
                        strLinea = strFila
                        strLinea = Replace(strLinea, "{factura}", "Subtotal")
                        strLinea = Replace(strLinea, "{libras}", Format(Totales(I_TIPO, C_PESO), FMT_MSO_CANTIDAD))
                        strLinea = Replace(strLinea, "{monto}", Format(Totales(I_TIPO, C_MONTO), FORMATO_MONEDA))
                        strLinea = Replace(strLinea, "{reservado}", Format(Totales(I_TIPO, C_RESERVA), FORMATO_MONEDA))
                        strLinea = Replace(strLinea, "{disponible}", Format(Totales(I_TIPO, C_SALDO), FORMATO_MONEDA))
                        cReportes.ImprimirSubtotal(f, strLinea)

                        Totales(I_TIPO, C_PESO) = vbEmpty
                        Totales(I_TIPO, C_MONTO) = vbEmpty
                        Totales(I_TIPO, C_RESERVA) = vbEmpty
                        Totales(I_TIPO, C_SALDO) = vbEmpty

                        'Total
                        strLinea = strFila
                        strLinea = Replace(strLinea, "{factura}", "Total " & Grupos(I_PAIS))
                        strLinea = Replace(strLinea, "{libras}", Format(Totales(I_PAIS, C_PESO), FMT_MSO_CANTIDAD))
                        strLinea = Replace(strLinea, "{monto}", Format(Totales(I_PAIS, C_MONTO), FORMATO_MONEDA))
                        strLinea = Replace(strLinea, "{reservado}", Format(Totales(I_PAIS, C_RESERVA), FORMATO_MONEDA))
                        strLinea = Replace(strLinea, "{disponible}", Format(Totales(I_PAIS, C_SALDO), FORMATO_MONEDA))
                        cReportes.ImprimirSubtotal(f, strLinea, True)

                        Totales(I_PAIS, C_PESO) = vbEmpty
                        Totales(I_PAIS, C_MONTO) = vbEmpty
                        Totales(I_PAIS, C_RESERVA) = vbEmpty
                        Totales(I_PAIS, C_SALDO) = vbEmpty

                    End If
                ElseIf Not (Datos(I_TIPO) = REA.GetInt32("Producto")) Then
                    Datos(I_TIPO) = REA.GetInt32("Producto")
                    If intLinea > vbEmpty Then
                        'Subtotal
                        strLinea = strFila
                        strLinea = Replace(strLinea, "{factura}", "Subtotal")
                        strLinea = Replace(strLinea, "{libras}", Format(Totales(I_TIPO, C_PESO), FMT_MSO_CANTIDAD))
                        strLinea = Replace(strLinea, "{monto}", Format(Totales(I_TIPO, C_MONTO), FORMATO_MONEDA))
                        cReportes.ImprimirSubtotal(f, strLinea)

                        Totales(I_TIPO, C_PESO) = vbEmpty
                        Totales(I_TIPO, C_MONTO) = vbEmpty
                        Totales(I_TIPO, C_RESERVA) = vbEmpty
                        Totales(I_TIPO, C_SALDO) = vbEmpty
                    End If
                End If
                intLinea = intLinea + 1
                '4) >>> Detalle

                strNota = Replace(IIf(logPartida, REA.GetString("Partida") & vbLf, vbNullString) & IIf(logDec, REA.GetString("Declaracion") & vbLf, vbNullString) & Replace(Replace(Replace(REA.GetString("Notas"), "*.", vbNullString), "#." & vbLf, vbNullString), ">." & vbLf, vbNullString), vbLf, "<br/>")

                Print(f, "<tr>")
                If REA.GetString("EstadoH") = "GOOD" Then
                    Print(f, "<td bgcolor = '#00FF00'>" & REA.GetString("EstadoH") & "</td>")
                ElseIf REA.GetString("EstadoH") = "CLEREANCE" Then
                    Print(f, "<td bgcolor = '#FFFF00'>" & REA.GetString("EstadoH") & "</td>")
                ElseIf REA.GetString("EstadoH") = "OLD INVENTORY" Then
                    Print(f, "<td bgcolor = '#FF0000'>" & REA.GetString("EstadoH") & "</td>")
                Else
                    Print(f, "<td></td>")
                End If
                Print(f, "<td>" & REA.GetInt32("Codigo") & "</td>")
                Print(f, "<td class='izquierda'>" & REA.GetString("Descripcion") & "</td>")
                Print(f, "<td>" & REA.GetString("Lote") & "</td>")
                Print(f, "<td>" & REA.GetInt32("semana") & "</td>")
                Print(f, "<td class='izquierda'>" & REA.GetString("Proveedor") & "</td>")
                Print(f, "<td>" & REA.GetString("Contenedor") & "</td>")
                Print(f, "<td>" & REA.GetString("Factura") & "</td>")
                'If logBodega Then
                '    Print(f, "<td>" & REA.GetString("Bodega") & "</td>")
                'End If
                Print(f, "<td class='numero'>" & Format(REA.GetDouble("Cantidad"), FMT_MSO_CANTIDAD) & "</td>")
                Print(f, "<td>" & REA.GetString("Unidad") & "</td>")
                Print(f, "<td class='numero'>" & Format(REA.GetDouble("Costo"), FMT_UNITARIO) & "</td>")
                Print(f, "<td>" & REA.GetInt32("Cajas") & "</td>")
                Print(f, "<td class='numero'>" & Format(REA.GetDouble("Monto"), FMT_MSO_TOTAL) & "</td>")
                Print(f, "<td class='numero'>" & IIf(REA.GetDouble("Reservado") = vbEmpty, vbNullString, Format(REA.GetDouble("Reservado"), FMT_MSO_TOTAL)) & "</td>")
                Print(f, "<td class='numero'>" & Format(REA.GetDouble("Cantidad") - REA.GetDouble("Reservado"), FMT_MSO_TOTAL) & "</td>")
                Print(f, "<td class='izquierda'>" & Replace(REA.GetString("Cliente"), "|", "<br/>") & "</td>")
                Print(f, "<td>" & REA.GetString("ETA") & "</td>")
                Print(f, "<td class='izquierda'>" & strNota & "</td>")
                Print(f, "</tr>")

                dblSaldo = (REA.GetDouble("Cantidad") - REA.GetDouble("Reservado"))

                Totales(I_TODO, C_PESO) = Totales(I_TODO, C_PESO) + REA.GetDouble("Cantidad")
                Totales(I_TODO, C_MONTO) = Totales(I_TODO, C_MONTO) + REA.GetDouble("Monto")
                Totales(I_TODO, C_RESERVA) = Totales(I_TODO, C_RESERVA) + REA.GetDouble("Reservado")
                Totales(I_TODO, C_SALDO) = Totales(I_TODO, C_SALDO) + dblSaldo

                Totales(I_PAIS, C_PESO) = Totales(I_PAIS, C_PESO) + REA.GetDouble("Cantidad")
                Totales(I_PAIS, C_MONTO) = Totales(I_PAIS, C_MONTO) + REA.GetDouble("Monto")
                Totales(I_PAIS, C_RESERVA) = Totales(I_PAIS, C_RESERVA) + REA.GetDouble("Reservado")
                Totales(I_PAIS, C_SALDO) = Totales(I_PAIS, C_SALDO) + dblSaldo

                Totales(I_TIPO, C_PESO) = Totales(I_TIPO, C_PESO) + REA.GetDouble("Cantidad")
                Totales(I_TIPO, C_MONTO) = Totales(I_TIPO, C_MONTO) + REA.GetDouble("Monto")
                Totales(I_TIPO, C_RESERVA) = Totales(I_TIPO, C_RESERVA) + REA.GetDouble("Reservado")
                Totales(I_TIPO, C_SALDO) = Totales(I_TIPO, C_SALDO) + dblSaldo

                Grupos(I_TIPO) = REA.GetString("Descripcion")
                Grupos(I_PAIS) = REA.GetString("Origen")
            Loop
            If intLinea > vbEmpty Then
                'Subtotal
                strLinea = strFila
                strLinea = Replace(strLinea, "{factura}", "Subtotal")
                strLinea = Replace(strLinea, "{libras}", Format(Totales(I_TIPO, C_PESO), FMT_MSO_CANTIDAD))
                strLinea = Replace(strLinea, "{monto}", Format(Totales(I_TIPO, C_MONTO), FORMATO_MONEDA))
                strLinea = Replace(strLinea, "{reservado}", Format(Totales(I_TIPO, C_RESERVA), FORMATO_MONEDA))
                strLinea = Replace(strLinea, "{disponible}", Format(Totales(I_TIPO, C_SALDO), FORMATO_MONEDA))
                cReportes.ImprimirSubtotal(f, strLinea)
                'Total
                strLinea = strFila
                strLinea = Replace(strLinea, "{factura}", "Total " & Grupos(I_PAIS))
                strLinea = Replace(strLinea, "{libras}", Format(Totales(I_PAIS, C_PESO), FMT_MSO_CANTIDAD))
                strLinea = Replace(strLinea, "{monto}", Format(Totales(I_PAIS, C_MONTO), FORMATO_MONEDA))
                strLinea = Replace(strLinea, "{reservado}", Format(Totales(I_PAIS, C_RESERVA), FORMATO_MONEDA))
                strLinea = Replace(strLinea, "{disponible}", Format(Totales(I_PAIS, C_SALDO), FORMATO_MONEDA))
                cReportes.ImprimirSubtotal(f, strLinea, True)

                'Total general
                strLinea = strFila
                strLinea = Replace(strLinea, "{factura}", "Grand Total")
                strLinea = Replace(strLinea, "{libras}", Format(Totales(I_TODO, C_PESO), FMT_MSO_CANTIDAD))
                strLinea = Replace(strLinea, "{monto}", Format(Totales(I_TODO, C_MONTO), FORMATO_MONEDA))
                strLinea = Replace(strLinea, "{reservado}", Format(Totales(I_TODO, C_RESERVA), FORMATO_MONEDA))
                strLinea = Replace(strLinea, "{disponible}", Format(Totales(I_TODO, C_SALDO), FORMATO_MONEDA))
                cReportes.ImprimirSubtotal(f, strLinea)
            End If
            frmMsj.Close()
            Print(f, "</table>")
            Print(f, "<br/>")
            Print(f, "</body>")
            Print(f, "</html>")

            FileClose(f)
            Cadena = strTemp
            frmMsj.Close()
            '  MostrarInventario(strTemp)
            WebBrowser1.Navigate(strTemp)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Private Sub ImprimirSubtotal(ByVal f As Byte, ByVal Dato As String, Optional Separador As Boolean = False)
    '    Dim i As Integer
    '    Dim varDato As Object
    '    Dim varTexto As Object
    '    Dim strTemp As String
    '    Dim strEstilo As String

    '    If Not (Dato = vbNullString) Then
    '        Print(f, "<tr>")

    '        varDato = Split(Dato, "|")
    '        For i = vbEmpty To UBound(varDato)
    '            If Not (varDato(i) = vbNullString) Then
    '                If Left(varDato(i), 1) = "{" Then
    '                    varDato(i) = vbNullString
    '                End If

    '                strEstilo = IIf(Separador, "style = 'border-bottom: dotted Silver 1px' ", "")
    '                If varDato(i) = vbNullString Then
    '                    strTemp = vbNullString
    '                Else
    '                    varTexto = Split(varDato(i), ";")
    '                    strTemp = varTexto(vbEmpty)
    '                    If UBound(varTexto) > vbEmpty Then
    '                        Select Case varTexto(1)
    '                            Case "A=L" : strEstilo = strEstilo & "class='izquierda'"
    '                            Case "A=R" : strEstilo = strEstilo & "class='derecha'"
    '                            Case "A=N" : strEstilo = strEstilo & "class='numero'"
    '                        End Select
    '                    End If
    '                End If

    '                Print(f, "<td " & strEstilo & "><b>" & strTemp & "</b></td>")
    '            End If
    '        Next

    '        Print(f, "</tr>")

    '        If Separador Then
    '            Print(f, "<tr><td colspan=" & (UBound(varDato) + 1) & ">&nbsp;</td></tr>")
    '        End If
    '    End If
    '    '        MostarReporte(strTemp)
    'End Sub
    Public Sub Reset()

        checkIncludeHeathers.Checked = False
        rbCadena3.Checked = False
        rbCadena1.Checked = False
        rbCadenaInsr.Checked = True
        celdaidAcabado.Text = NO_FILA
        celdaAcabado.Text = STR_VACIO
        celdaidClase.Text = NO_FILA
        celdaClase.Text = STR_VACIO
        celdaidCountry.Text = NO_FILA
        celdaContinente.Text = STR_VACIO
        celdaidSpnning.Text = NO_FILA
        celdaSpinning.Text = STR_VACIO
        celdaidPais.Text = NO_FILA
        celdaPais.Text = STR_VACIO
        celdaCodigoInventario.Text = NO_FILA
        celdaCodigoProducto.Text = NO_FILA
        celdaTitulo.Text = STR_VACIO
        celdaDescripcionCorta.Text = STR_VACIO
        celdaidEstado.Text = NO_FILA
        celdaEstado.Text = STR_VACIO
    End Sub
#End Region
#Region "Eventos"
    Private Sub botonPrevia_Click(sender As Object, e As EventArgs) Handles botonPrevia.Click
        Try
            WebBrowser1.ShowPrintPreviewDialog()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()
    End Sub
    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        WebBrowser1.ShowSaveAsDialog()
    End Sub


    Private Sub FrmInventario_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim idEstado As Integer = INT_CERO
        Dim Estado As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLCargarEstado()
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetString("nombre") = "GOOD" Then
                        Estado = REA.GetString("nombre")
                        idEstado = REA.GetInt32("id")

                        celdaidEstado.Text = idEstado
                        celdaEstado.Text = Estado
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        ReporteInventarioPF()
        '  WebBrowser1.Navigate(strTemp)
    End Sub
    Private Sub botonPais_Click(sender As Object, e As EventArgs) Handles botonPais.Click
        Dim frm As New frmSeleccionar
        ' Propiedades de consulta 
        frm.Campos = " cat_num ID , cat_desc Description "
        frm.Tabla = " Catalogos "
        frm.Condicion = " cat_clase = 'paises' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the country to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaPais.Text = frm.Dato
            celdaidPais.Text = frm.LLave
        End If
    End Sub
    Private Sub botonAcabado_Click(sender As Object, e As EventArgs) Handles botonAcabado.Click

        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_num Code , c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase = 'Acabado'"
        frm.Ordenamiento = " c.cat_clase"
        frm.Filtro = " c.cat_desc "
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Finish "
        frm.FiltroText = " Enter Finish Name to Filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidAcabado.Text = frm.LLave
            celdaAcabado.Text = frm.Dato
        End If
    End Sub
    Private Sub botonContinente_Click(sender As Object, e As EventArgs) Handles botonContinente.Click
        Dim frm As New frmSeleccionar
        ' Propiedades de consulta 
        frm.Campos = " distinct c.cat_num , c.cat_desc  "
        frm.Tabla = " Catalogos c  inner join Catalogos cc on cc.cat_pid  = c.cat_num "
        frm.Condicion = " c.cat_clase = 'Countries' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the country to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaContinente.Text = frm.Dato
            celdaidCountry.Text = frm.LLave
        End If
    End Sub
    Private Sub botonClase_Click(sender As Object, e As EventArgs) Handles botonClase.Click
        Dim frm As New frmSeleccionar

        ' Propiedades de consulta 
        frm.Campos = " c.cat_num IDC ,c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase='ClaseArt' ORDER BY c.cat_desc "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the Catalog to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidClase.Text = frm.LLave
            celdaClase.Text = frm.Dato
        End If
    End Sub
    Private Sub botonSpinning_Click(sender As Object, e As EventArgs) Handles botonSpinning.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_num Number , c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase ='Spinning' ORDER By cat_clave "
        frm.Filtro = " c.cat_clave "
        frm.Limite = " 10 "
        ' propiedades de formulario
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the Spinning name to filter "
        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidSpnning.Text = frm.LLave
            celdaSpinning.Text = frm.Dato
        End If
    End Sub
    Private Sub botonExportar_Click_1(sender As Object, e As EventArgs) Handles botonExportar.Click
        Dim obj As Object

        Try
            obj = CreateObject("Excel.Application")
            obj.Workbooks.Open(strTemp)
            obj.visible = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Try
            WebBrowser1.ShowPrintDialog()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Dim inventario As New clsReportes
        Try
            If ComprabarDatos() = False Then
                Exit Sub
            End If
            ReporteInventarioPF(celdaCodigoInventario.Text, celdaCodigoProducto.Text, celdaTitulo.Text, celdaidPais.Text, celdaDescripcionCorta.Text, celdaidAcabado.Text, celdaidClase.Text, celdaidCountry.Text, celdaidSpnning.Text, checkIncludeHeathers.Checked, rbCadenaInsr.Checked, rbCadena1.Checked, rbCadena3.Checked, checkMuestra.Checked)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonRefrescar_Click(sender As Object, e As EventArgs) Handles botonRefrescar.Click
        Reset()
    End Sub

    'Query que carga los estados
    Private Function SQLCargarEstado() As String

        Dim strsql As String = STR_VACIO
        strsql = " SELECT IFNULL(c.cat_num,0) id, IFNULL(c.cat_desc,'') nombre"
        strsql &= "     FROM Catalogos c"
        strsql &= "         WHERE c.cat_clase = 'StatusIngBdg'"

        Return strsql
    End Function

    Private Sub botonEstado_Click(sender As Object, e As EventArgs) Handles botonEstado.Click
        Dim Good As Integer = INT_CERO
        Dim Clereance As Integer = INT_CERO
        Dim Old As Integer = INT_CERO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLCargarEstado()
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetString("nombre") = "GOOD" Then
                        Good = REA.GetInt32("id")
                    ElseIf REA.GetString("nombre") = "CLEREANCE" Then
                        Clereance = REA.GetInt32("id")
                    ElseIf REA.GetString("nombre") = "OLD INVENTORY" Then
                        Old = REA.GetInt32("id")
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim op As New frmOption
        op.Opciones = "GOOD |" & " CLEREANCE |" & "OLD INVENTORY"
        op.Titulo = " DOCUMENTS NOTES "
        op.ShowDialog(Me)
        Me.DialogResult = DialogResult.OK
        Select Case op.Seleccion
            Case 0
                celdaidEstado.Text = Good
                celdaEstado.Text = "GOOD"
            Case 1
                celdaidEstado.Text = Clereance
                celdaEstado.Text = "CLEREANCE"
            Case 2
                celdaidEstado.Text = Old
                celdaEstado.Text = "OLD INVENTORY"
        End Select
    End Sub

#End Region
End Class