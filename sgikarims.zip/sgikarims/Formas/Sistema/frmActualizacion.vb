﻿Public Class frmActualizacion

    Dim logObligatorio As Boolean = False
    Private Sub BotonDespues_Click(sender As Object, e As EventArgs) Handles BotonDespues.Click
        Me.DialogResult = DialogResult.Cancel
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.DialogResult = DialogResult.OK
    End Sub

    Private Sub frmActualizacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim strSQL As String = STR_VACIO
        Dim strHtml As String = STR_VACIO
        Dim strVersion As String = STR_VACIO
        Dim logPrimeraLinea As Boolean = True

        Dim cSesion As New clsSesion
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim f As Byte
        Dim strTemp As String = STR_VACIO
        Try
            BarraTitulo1.CambiarTitulo("There is a new update for you. ")

            strSQL = " SELECT h.Fecha , h.VersionString , h.Obligatorio , p.pro_descripcion Programa, d.Descripcion  
                        FROM YarnDivision.Update_HDR h
                            LEFT JOIN YarnDivision.Update_DTL d ON d.IdUpdate = h.Id
                            LEFT JOIN Programas p ON p.pro_codigo = d.IdPrograma
                        WHERE  h.IdEmpresa = {empresa} AND  h.VersionInteger > {version} AND d.IdPrograma in(SELECT a.seg_programa  FROM Accesos a
																	           WHERE a.seg_sisemp ={empresa} AND a.seg_usuario = '{usuario}' AND a.seg_programa = d.IdPrograma)
                        ORDER BY h.VersionInteger desc "
            strSQL = strSQL.Replace("{version}", cSesion.Version())
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{usuario}", Sesion.Usuario)
            strTemp = cFunciones.ArchivoTemporal
            f = FreeFile()
            FileOpen(f, strTemp, OpenMode.Append)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            strHtml = " <!DOCTYPE html>
                <html>
                  <head>
                    <meta charset='utf-8'>
                    <title>SGIUpdate</title>
                    <style type='text/css'>
                     body {
                          color : darkgray;
                          background-color :whitesmoke }
                    ul.navbar {
                          background: #cce5ff;
                         margin: 5px;
                           }
                           ul {
                  list-style: none;
                  padding: 0;
                }
                li {
                  padding: 5px 10px;
                  background-color: #EEEEEE;
                  border: 1px solid #DDDDDD;
                }
                    .titulo {font-family: Tahoma, Arial;font-size: 11pt;font-weight: bold; color:black  }
                    .encabezado {font-family: Tahoma, Arial;font-size: 7pt;text-align: left;font-style: italic; border: none; width: 5.1cm}
                      </style>
                  </head>
                  <body>"

            If REA.HasRows Then
                Do While REA.Read
                    If logObligatorio = False Then
                        If REA.GetInt32("Obligatorio") = INT_UNO Then
                            logObligatorio = True
                        End If
                    End If
                    If Not strVersion = REA.GetString("VersionString") Then
                        strVersion = REA.GetString("VersionString")
                        If logPrimeraLinea = True Then
                            logPrimeraLinea = False
                            strHtml &= "    <p>
                                      <h1 class='titulo'> Version - " & REA.GetString("VersionString") & "</h1>
                                      <h3 class='encabezado'>" & REA.GetMySqlDateTime("Fecha").ToString & "</h3>
                                      <ul class='navbar'> "
                        Else
                            strHtml &= "   </ul>
                                        </p> <p>
                                      <h1 class='titulo'> Version -" & REA.GetString("VersionString") & "</h1>
                                      <h3 class='encabezado'>" & REA.GetMySqlDateTime("Fecha").ToString & "</h3>
                                      <ul class='navbar'> "
                        End If
                    End If
                    strHtml &= "  <li class='titulo'>" & REA.GetString("Programa") & "
                          <p style='color:#6F6F6E;font-family: Tahoma Arial;font-size: 8pt;text-align: left; border: none; width: 5.1cm'>" & REA.GetString("Descripcion") & " </p> </li> "
                Loop

            End If
            strHtml &= " </ul>
                                        </p> </body>
                </html> "
            Print(f, strHTML)
            FileClose(f)
            WebBrowser1.Navigate(strTemp)
            If logObligatorio = True Then
                BotonDespues.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmActualizacion_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If Not Me.DialogResult = DialogResult.OK Then
            If logObligatorio = True Then
                End
            End If
        End If

    End Sub
End Class