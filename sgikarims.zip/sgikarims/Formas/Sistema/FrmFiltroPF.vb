﻿Public Class FrmFiltroPF
#Region "Variables"
    Dim intInventario As Integer
    Dim strDescripcion As String
    Dim intMedida As Integer
    Dim strMedida As String
    Dim strOrigen As String
#End Region
#Region "Propiedades"
    Public ReadOnly Property Inventario As Integer
        Get
            Return intInventario
        End Get
    End Property
    Public ReadOnly Property Descripcion As String
        Get
            Return strDescripcion
        End Get
    End Property
    Public ReadOnly Property idMedida As Integer
        Get
            Return intMedida
        End Get
    End Property
    Public ReadOnly Property Medida As String
        Get
            Return strMedida
        End Get
    End Property
    Public ReadOnly Property Origen As String
        Get
            Return strOrigen
        End Get
    End Property
#End Region
#Region "Funciones "
    Private Function SQLDefaultMedida() As String
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As New MySqlConnection
        Dim strMedida As String

        strSQL = " SELECT  cat_clave Description  "
        strSQL &= " FROM Catalogos  "
        strSQL &= " WHERE cat_clase ='Medidas' AND cat_num = 69 "
        strSQL &= " ORDER BY cat_num ASC "

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            strMedida = COM.ExecuteScalar()
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        Return strMedida
    End Function

    Private Function strSQLInventario() As String
        Dim strSQL As String
        strSQL = " SELECT inv_numero Inventory, art_DCorta Description, m.cat_num NumMedida, m.cat_clave Measure, p.cat_desc Origen "
        strSQL &= " FROM Inventarios "
        strSQL &= " INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo "
        strSQL &= " LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa "
        strSQL &= " LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab "
        strSQL &= " LEFT JOIN Catalogos cn ON cn.cat_clase = 'Countries' AND cn.cat_num = p.cat_pid "
        strSQL &= " WHERE inv_generico = 1 AND inv_sisemp = {empresa} AND inv_status = 'Activo'  "
        If checkIncludeHeathers.Checked = True Then
            strSQL &= " AND art_heather = 1 "
        Else
            strSQL &= " AND art_heather = 0 "
        End If
        If checkMuestra.Checked = True Then
            strSQL &= " AND inv_muestra = 1"
        Else
            strSQL &= " AND inv_muestra = 0 "
        End If
        If celdaCodigoInventario.Text <> STR_VACIO Then

            strSQL &= " AND inv_numero = {inventario}"
            strSQL = Replace(strSQL, "{inventario}", celdaCodigoInventario.Text)
        End If
        If celdaCodigoProducto.Text <> STR_VACIO Then
            strSQL &= " AND inv_artcodigo = {producto} "
            strSQL = Replace(strSQL, "{producto}", celdaCodigoProducto.Text)
        End If
        If celdaTitulo.Text <> STR_VACIO Then

            strSQL &= " AND art_titulo Like '%{titulo}%'"
            strSQL = Replace(strSQL, "{titulo}", celdaTitulo.Text)
        End If
        If celdaDescripcionCorta.Text <> STR_VACIO Then
            If rbCadenaInsr.Checked = True Then
                strSQL &= " and instr(art_DCorta ,'{descripcion}')"
                strSQL = Replace(strSQL, "{descripcion}", celdaDescripcionCorta.Text)
            End If
            If rbCadena1.Checked = True Then
                strSQL &= " AND art_DCorta LIKE '{descripcion}%'"
                strSQL = Replace(strSQL, "{descripcion}", celdaDescripcionCorta.Text)
            End If
            If rbCadena3.Checked = True Then
                strSQL &= " AND art_DCorta LIKE '%{descripcion}' "
                strSQL = Replace(strSQL, "{descripcion}", celdaDescripcionCorta.Text)
            End If

        End If
            If celdaidClase.Text <> NO_FILA Then
            strSQL &= " AND art_clase ={clase}"
            strSQL = Replace(strSQL, "{clase}", celdaidClase.Text)
        End If
        If celdaidPais.Text <> NO_FILA Then
            strSQL &= " AND inv_lugarfab = {pais}"
            strSQL = Replace(strSQL, "{pais}", celdaidPais.Text)
        End If
        If celdaidAcabado.Text <> NO_FILA Then
            strSQL &= " AND art_acabado = {acabado}"
            strSQL = Replace(strSQL, "{acabado}", celdaidAcabado.Text)
        End If
        If celdaidSpnning.Text <> NO_FILA Then
            strSQL &= " AND art_spinning = {spinning}"
            strSQL = Replace(strSQL, "{spinning}", celdaidSpnning.Text)
        End If
        If celdaidCountry.Text <> NO_FILA Then
            strSQL &= " AND cn.cat_num = {country}"
            strSQL = Replace(strSQL, "{country}", celdaidCountry.Text)
        End If
        If celdaIdMedida.Text <> NO_FILA Then
            strSQL &= " AND inv_UMventa = {medida} "
            strSQL = Replace(strSQL, "{medida}", celdaIdMedida.Text)
        End If

        strSQL &= " ORDER BY inv_numero DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Return strSQL
    End Function
    Public Sub CargarInventario()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            dgInventario.Rows.Clear()
            strSQL = strSQLInventario()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("Inventory") & "|"
                    strFila &= REA.GetString("Description") & "|"
                    strFila &= REA.GetInt32("NumMedida") & "|"
                    strFila &= REA.GetString("Measure") & "|"
                    strFila &= REA.GetString("Origen")
                    cFunciones.AgregarFila(dgInventario, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Reset()

        checkIncludeHeathers.Checked = False
        rbCadena3.Checked = False
        rbCadena1.Checked = False
        rbCadenaInsr.Checked = False
        celdaidAcabado.Text = NO_FILA
        celdaAcabado.Text = STR_VACIO
        celdaidClase.Text = NO_FILA
        celdaClase.Text = STR_VACIO
        celdaidCountry.Text = NO_FILA
        celdaContinente.Text = STR_VACIO
        celdaidSpnning.Text = NO_FILA
        celdaSpinning.Text = STR_VACIO
        celdaidPais.Text = NO_FILA
        celdaPais.Text = STR_VACIO
        celdaCodigoInventario.Text = STR_VACIO
        celdaCodigoProducto.Text = STR_VACIO
        celdaTitulo.Text = STR_VACIO
        celdaDescripcionCorta.Text = STR_VACIO
        celdaIdMedida.Text = "69"
        celdaMedida.Text = SQLDefaultMedida()
    End Sub
    Private Function ComprabarDatos() As Boolean
        Dim logVerdadero = True
        If celdaCodigoInventario.Text <> STR_VACIO Then
            If cFunciones.ValidarCampoNumerico(celdaCodigoInventario) Then
            Else
                logVerdadero = False
            End If
        End If

        If celdaCodigoProducto.Text <> STR_VACIO Then
            If cFunciones.ValidarCampoNumerico(celdaCodigoProducto) Then
            Else
                logVerdadero = False
            End If
        End If

        If celdaTitulo.Text <> STR_VACIO Then
            If cFunciones.ValidarCampoTexto(celdaTitulo) Then
            Else
                logVerdadero = False
            End If
        End If

        If celdaDescripcionCorta.Text <> STR_VACIO Then
            If cFunciones.ValidarCampoTexto(celdaDescripcionCorta) Then
            Else
                logVerdadero = False
            End If
        End If
        Return logVerdadero
    End Function
#End Region
#Region "Eventos"
    Private Sub botonPais_Click(sender As Object, e As EventArgs) Handles botonPais.Click
        Dim frm As New frmSeleccionar
        ' Propiedades de consulta 
        frm.Campos = " cat_num ID , cat_desc Description "
        frm.Tabla = " Catalogos "
        frm.Condicion = " cat_clase = 'paises' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the country to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaPais.Text = frm.Dato
            celdaidPais.Text = frm.LLave
        End If
    End Sub
    Private Sub botonClase_Click(sender As Object, e As EventArgs) Handles botonClase.Click
        Dim frm As New frmSeleccionar

        ' Propiedades de consulta 
        frm.Campos = " c.cat_num IDC ,c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase='ClaseArt' ORDER BY c.cat_desc "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the Catalog to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidClase.Text = frm.LLave
            celdaClase.Text = frm.Dato
        End If
    End Sub
    Private Sub botonAcabado_Click(sender As Object, e As EventArgs) Handles botonAcabado.Click

        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_num Code , c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase = 'Acabado'"
        frm.Ordenamiento = " c.cat_clase"
        frm.Filtro = " c.cat_desc "
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Finish "
        frm.FiltroText = " Enter Finish Name to Filter "

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidAcabado.Text = frm.LLave
            celdaAcabado.Text = frm.Dato
        End If
    End Sub
    Private Sub botonSpinning_Click(sender As Object, e As EventArgs) Handles botonSpinning.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " c.cat_num Number , c.cat_desc Description "
        frm.Tabla = " Catalogos c "
        frm.Condicion = " c.cat_clase ='Spinning' ORDER By cat_clave "
        frm.Filtro = " c.cat_clave "
        frm.Limite = " 10 "
        ' propiedades de formulario
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the Spinning name to filter "
        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidSpnning.Text = frm.LLave
            celdaSpinning.Text = frm.Dato
        End If
    End Sub
    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        If dgInventario.Rows.Count = 0 Then
            MsgBox("Please select a row")
            Exit Sub
        Else
            intInventario = dgInventario.CurrentRow.Cells("colInventario").Value
            strDescripcion = dgInventario.CurrentRow.Cells("colDescripcion").Value
            intMedida = dgInventario.CurrentRow.Cells("colidmedida").Value
            strMedida = dgInventario.CurrentRow.Cells("colMedida").Value
            strOrigen = dgInventario.CurrentRow.Cells("colOrigen").Value
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
        End If


    End Sub
    Private Sub FrmFiltroPF_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        celdaMedida.Text = SQLDefaultMedida()
        celdaIdMedida.Text = 69
    End Sub
    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        If ComprabarDatos() = False Then
            Exit Sub
        End If
        CargarInventario()
    End Sub
    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub
    Private Sub botonContinente_Click(sender As Object, e As EventArgs) Handles botonContinente.Click
        Dim frm As New frmSeleccionar
        ' Propiedades de consulta 
        frm.Campos = " distinct c.cat_num , c.cat_desc  "
        frm.Tabla = " Catalogos c  inner join Catalogos cc on cc.cat_pid  = c.cat_num "
        frm.Condicion = " c.cat_clase = 'Countries' "
        frm.Filtro = " cat_desc "
        frm.Limite = " 20"
        ' Propiedades de formulario 
        frm.Titulo = " Catalogs "
        frm.FiltroText = " Enter the name of the country to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaContinente.Text = frm.Dato
            celdaidCountry.Text = frm.LLave
        End If
    End Sub
    Private Sub dgInventario_DoubleClick(sender As Object, e As EventArgs) Handles dgInventario.DoubleClick
        intInventario = dgInventario.CurrentRow.Cells("colInventario").Value
        strDescripcion = dgInventario.CurrentRow.Cells("colDescripcion").Value
        intMedida = dgInventario.CurrentRow.Cells("colidmedida").Value
        strMedida = dgInventario.CurrentRow.Cells("colMedida").Value
        strOrigen = dgInventario.CurrentRow.Cells("colOrigen").Value
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub
    Private Sub botonRefrescar_Click(sender As Object, e As EventArgs) Handles botonRefrescar.Click
        Reset()
    End Sub

    Private Sub rbCadena1_CheckedChanged(sender As Object, e As EventArgs) Handles rbCadena1.CheckedChanged
        If rbCadena1.Checked = True Then
            rbCadena3.Checked = False
            rbCadenaInsr.Checked = False
        End If
    End Sub

    Private Sub rbCadena3_CheckedChanged(sender As Object, e As EventArgs) Handles rbCadena3.CheckedChanged
        If rbCadena3.Checked = True Then
            rbCadena1.Checked = False
            rbCadenaInsr.Checked = False
        End If
    End Sub

    Private Sub rbCadenaInsr_CheckedChanged(sender As Object, e As EventArgs) Handles rbCadenaInsr.CheckedChanged
        If rbCadenaInsr.Checked = True Then
            rbCadena1.Checked = False
            rbCadena3.Checked = False
        End If
    End Sub

    Private Sub BotonMedida_Click(sender As Object, e As EventArgs) Handles BotonMedida.Click
        Dim frm As New frmSeleccionar
        Try

            frm.Titulo = "Measure"
            frm.Campos = " cat_num Number,cat_clave Description  "
            frm.Tabla = " Catalogos "
            frm.FiltroText = " Enter the name of the Measure to filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = " cat_clase ='Medidas' ORDER BY cat_num  ASC "


            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMedida.Text = frm.LLave
                celdaMedida.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region
End Class