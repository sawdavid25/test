﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPrecioUnitario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.etiquetaKGS = New System.Windows.Forms.Label()
        Me.etiquetaConvertir = New System.Windows.Forms.Label()
        Me.etiquetaLBS = New System.Windows.Forms.Label()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.celdaUnitario = New System.Windows.Forms.TextBox()
        Me.etiquetaIgual = New System.Windows.Forms.Label()
        Me.celdaFactor = New System.Windows.Forms.TextBox()
        Me.etiquetaDivCantidad = New System.Windows.Forms.Label()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.etiquetaFactor = New System.Windows.Forms.Label()
        Me.etiquetaUnitario = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.etiquetaDivTotal = New System.Windows.Forms.Label()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonCalcular = New System.Windows.Forms.Button()
        Me.panelDocumento.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel1)
        Me.panelDocumento.Controls.Add(Me.panelBotones)
        Me.panelDocumento.Controls.Add(Me.celdaUnitario)
        Me.panelDocumento.Controls.Add(Me.etiquetaIgual)
        Me.panelDocumento.Controls.Add(Me.celdaFactor)
        Me.panelDocumento.Controls.Add(Me.etiquetaDivCantidad)
        Me.panelDocumento.Controls.Add(Me.celdaCantidad)
        Me.panelDocumento.Controls.Add(Me.etiquetaDivTotal)
        Me.panelDocumento.Controls.Add(Me.etiquetaCantidad)
        Me.panelDocumento.Controls.Add(Me.etiquetaFactor)
        Me.panelDocumento.Controls.Add(Me.etiquetaUnitario)
        Me.panelDocumento.Controls.Add(Me.celdaTotal)
        Me.panelDocumento.Controls.Add(Me.etiquetaTotal)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumento.Location = New System.Drawing.Point(0, 0)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(391, 304)
        Me.panelDocumento.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Info
        Me.Panel1.Controls.Add(Me.etiquetaKGS)
        Me.Panel1.Controls.Add(Me.etiquetaConvertir)
        Me.Panel1.Controls.Add(Me.etiquetaLBS)
        Me.Panel1.Location = New System.Drawing.Point(93, 140)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(117, 29)
        Me.Panel1.TabIndex = 13
        '
        'etiquetaKGS
        '
        Me.etiquetaKGS.AutoSize = True
        Me.etiquetaKGS.Location = New System.Drawing.Point(86, 8)
        Me.etiquetaKGS.Name = "etiquetaKGS"
        Me.etiquetaKGS.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaKGS.TabIndex = 15
        Me.etiquetaKGS.Text = "KGS"
        '
        'etiquetaConvertir
        '
        Me.etiquetaConvertir.AutoSize = True
        Me.etiquetaConvertir.Location = New System.Drawing.Point(3, 8)
        Me.etiquetaConvertir.Name = "etiquetaConvertir"
        Me.etiquetaConvertir.Size = New System.Drawing.Size(47, 13)
        Me.etiquetaConvertir.TabIndex = 13
        Me.etiquetaConvertir.Text = "Convert:"
        Me.etiquetaConvertir.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'etiquetaLBS
        '
        Me.etiquetaLBS.AutoSize = True
        Me.etiquetaLBS.Location = New System.Drawing.Point(53, 8)
        Me.etiquetaLBS.Name = "etiquetaLBS"
        Me.etiquetaLBS.Size = New System.Drawing.Size(27, 13)
        Me.etiquetaLBS.TabIndex = 14
        Me.etiquetaLBS.Text = "LBS"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonAceptar)
        Me.panelBotones.Controls.Add(Me.botonCancelar)
        Me.panelBotones.Controls.Add(Me.botonCalcular)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(263, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(128, 304)
        Me.panelBotones.TabIndex = 12
        '
        'celdaUnitario
        '
        Me.celdaUnitario.Location = New System.Drawing.Point(93, 232)
        Me.celdaUnitario.Name = "celdaUnitario"
        Me.celdaUnitario.Size = New System.Drawing.Size(117, 20)
        Me.celdaUnitario.TabIndex = 11
        Me.celdaUnitario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaIgual
        '
        Me.etiquetaIgual.AutoSize = True
        Me.etiquetaIgual.Location = New System.Drawing.Point(146, 207)
        Me.etiquetaIgual.Name = "etiquetaIgual"
        Me.etiquetaIgual.Size = New System.Drawing.Size(13, 13)
        Me.etiquetaIgual.TabIndex = 10
        Me.etiquetaIgual.Text = "="
        '
        'celdaFactor
        '
        Me.celdaFactor.Location = New System.Drawing.Point(93, 175)
        Me.celdaFactor.Name = "celdaFactor"
        Me.celdaFactor.Size = New System.Drawing.Size(117, 20)
        Me.celdaFactor.TabIndex = 9
        Me.celdaFactor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaDivCantidad
        '
        Me.etiquetaDivCantidad.AutoSize = True
        Me.etiquetaDivCantidad.Location = New System.Drawing.Point(146, 124)
        Me.etiquetaDivCantidad.Name = "etiquetaDivCantidad"
        Me.etiquetaDivCantidad.Size = New System.Drawing.Size(13, 13)
        Me.etiquetaDivCantidad.TabIndex = 7
        Me.etiquetaDivCantidad.Text = "÷"
        Me.etiquetaDivCantidad.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'celdaCantidad
        '
        Me.celdaCantidad.Location = New System.Drawing.Point(93, 89)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(117, 20)
        Me.celdaCantidad.TabIndex = 6
        Me.celdaCantidad.Text = "0.00"
        Me.celdaCantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.Location = New System.Drawing.Point(41, 92)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaCantidad.TabIndex = 4
        Me.etiquetaCantidad.Text = "Quantity"
        '
        'etiquetaFactor
        '
        Me.etiquetaFactor.AutoSize = True
        Me.etiquetaFactor.Location = New System.Drawing.Point(41, 178)
        Me.etiquetaFactor.Name = "etiquetaFactor"
        Me.etiquetaFactor.Size = New System.Drawing.Size(37, 13)
        Me.etiquetaFactor.TabIndex = 3
        Me.etiquetaFactor.Text = "Factor"
        '
        'etiquetaUnitario
        '
        Me.etiquetaUnitario.AutoSize = True
        Me.etiquetaUnitario.Location = New System.Drawing.Point(41, 235)
        Me.etiquetaUnitario.Name = "etiquetaUnitario"
        Me.etiquetaUnitario.Size = New System.Drawing.Size(40, 13)
        Me.etiquetaUnitario.TabIndex = 2
        Me.etiquetaUnitario.Text = "Unitary"
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(93, 46)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(117, 20)
        Me.celdaTotal.TabIndex = 1
        Me.celdaTotal.Text = "0.00"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(38, 48)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaTotal.TabIndex = 0
        Me.etiquetaTotal.Text = "Total ($.)"
        '
        'etiquetaDivTotal
        '
        Me.etiquetaDivTotal.AutoSize = True
        Me.etiquetaDivTotal.Location = New System.Drawing.Point(146, 68)
        Me.etiquetaDivTotal.Name = "etiquetaDivTotal"
        Me.etiquetaDivTotal.Size = New System.Drawing.Size(13, 13)
        Me.etiquetaDivTotal.TabIndex = 5
        Me.etiquetaDivTotal.Text = "÷"
        Me.etiquetaDivTotal.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'botonAceptar
        '
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_right_green
        Me.botonAceptar.Location = New System.Drawing.Point(40, 153)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(56, 48)
        Me.botonAceptar.TabIndex = 2
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel4
        Me.botonCancelar.Location = New System.Drawing.Point(40, 207)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(56, 48)
        Me.botonCancelar.TabIndex = 1
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonCalcular
        '
        Me.botonCalcular.Image = Global.KARIMs_SGI.My.Resources.Resources.SUMATORIA
        Me.botonCalcular.Location = New System.Drawing.Point(37, 59)
        Me.botonCalcular.Name = "botonCalcular"
        Me.botonCalcular.Size = New System.Drawing.Size(59, 46)
        Me.botonCalcular.TabIndex = 0
        Me.botonCalcular.Text = "Calculate"
        Me.botonCalcular.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCalcular.UseVisualStyleBackColor = True
        '
        'frmPrecioUnitario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(391, 304)
        Me.Controls.Add(Me.panelDocumento)
        Me.Name = "frmPrecioUnitario"
        Me.Text = "frmPrecioUnitario"
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonCalcular As System.Windows.Forms.Button
    Friend WithEvents celdaUnitario As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaIgual As System.Windows.Forms.Label
    Friend WithEvents celdaFactor As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDivCantidad As System.Windows.Forms.Label
    Friend WithEvents celdaCantidad As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDivTotal As System.Windows.Forms.Label
    Friend WithEvents etiquetaCantidad As System.Windows.Forms.Label
    Friend WithEvents etiquetaFactor As System.Windows.Forms.Label
    Friend WithEvents etiquetaUnitario As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents etiquetaKGS As System.Windows.Forms.Label
    Friend WithEvents etiquetaLBS As System.Windows.Forms.Label
    Friend WithEvents etiquetaConvertir As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
