﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSSesion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSSesion))
        Me.EtiquetaUsuario = New System.Windows.Forms.Label()
        Me.CeldaUsuario = New System.Windows.Forms.TextBox()
        Me.EtiquetaClave = New System.Windows.Forms.Label()
        Me.CeldaClave = New System.Windows.Forms.TextBox()
        Me.EtiquetaConexion = New System.Windows.Forms.Label()
        Me.EtiquetaVersion = New System.Windows.Forms.Label()
        Me.Empresas = New System.Windows.Forms.ListView()
        Me.id = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Empresa = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.IconoConexion = New System.Windows.Forms.PictureBox()
        Me.BotonAceptar = New System.Windows.Forms.Button()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.IconoConexion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'EtiquetaUsuario
        '
        Me.EtiquetaUsuario.AutoSize = True
        Me.EtiquetaUsuario.Location = New System.Drawing.Point(35, 15)
        Me.EtiquetaUsuario.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaUsuario.Name = "EtiquetaUsuario"
        Me.EtiquetaUsuario.Size = New System.Drawing.Size(57, 17)
        Me.EtiquetaUsuario.TabIndex = 1
        Me.EtiquetaUsuario.Text = "Usuario"
        '
        'CeldaUsuario
        '
        Me.CeldaUsuario.Location = New System.Drawing.Point(39, 31)
        Me.CeldaUsuario.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaUsuario.Name = "CeldaUsuario"
        Me.CeldaUsuario.Size = New System.Drawing.Size(261, 22)
        Me.CeldaUsuario.TabIndex = 1
        '
        'EtiquetaClave
        '
        Me.EtiquetaClave.AutoSize = True
        Me.EtiquetaClave.Location = New System.Drawing.Point(37, 78)
        Me.EtiquetaClave.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaClave.Name = "EtiquetaClave"
        Me.EtiquetaClave.Size = New System.Drawing.Size(81, 17)
        Me.EtiquetaClave.TabIndex = 1
        Me.EtiquetaClave.Text = "Contraseña"
        '
        'CeldaClave
        '
        Me.CeldaClave.Location = New System.Drawing.Point(41, 96)
        Me.CeldaClave.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaClave.Name = "CeldaClave"
        Me.CeldaClave.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.CeldaClave.Size = New System.Drawing.Size(259, 22)
        Me.CeldaClave.TabIndex = 2
        '
        'EtiquetaConexion
        '
        Me.EtiquetaConexion.AutoSize = True
        Me.EtiquetaConexion.Location = New System.Drawing.Point(76, 174)
        Me.EtiquetaConexion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaConexion.Name = "EtiquetaConexion"
        Me.EtiquetaConexion.Size = New System.Drawing.Size(74, 17)
        Me.EtiquetaConexion.TabIndex = 6
        Me.EtiquetaConexion.Text = "(conexion)"
        '
        'EtiquetaVersion
        '
        Me.EtiquetaVersion.AutoSize = True
        Me.EtiquetaVersion.Location = New System.Drawing.Point(245, 174)
        Me.EtiquetaVersion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.EtiquetaVersion.Name = "EtiquetaVersion"
        Me.EtiquetaVersion.Size = New System.Drawing.Size(56, 17)
        Me.EtiquetaVersion.TabIndex = 8
        Me.EtiquetaVersion.Text = "Versión"
        '
        'Empresas
        '
        Me.Empresas.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.id, Me.Empresa})
        Me.Empresas.FullRowSelect = True
        Me.Empresas.HideSelection = False
        Me.Empresas.Location = New System.Drawing.Point(687, 266)
        Me.Empresas.Margin = New System.Windows.Forms.Padding(4)
        Me.Empresas.MultiSelect = False
        Me.Empresas.Name = "Empresas"
        Me.Empresas.Size = New System.Drawing.Size(69, 50)
        Me.Empresas.TabIndex = 10
        Me.Empresas.UseCompatibleStateImageBehavior = False
        Me.Empresas.View = System.Windows.Forms.View.Details
        Me.Empresas.Visible = False
        '
        'id
        '
        Me.id.Text = "id"
        Me.id.Width = 35
        '
        'Empresa
        '
        Me.Empresa.Text = "Empresa"
        Me.Empresa.Width = 150
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Panel1.Controls.Add(Me.CuadroLogo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(192, 246)
        Me.Panel1.TabIndex = 11
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Image = Global.KARIMs_SGI.My.Resources.Resources.Sierra_Icon_BlueLogo
        Me.CuadroLogo.Location = New System.Drawing.Point(4, 46)
        Me.CuadroLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(184, 145)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.CuadroLogo.TabIndex = 0
        Me.CuadroLogo.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.IconoConexion)
        Me.Panel2.Controls.Add(Me.EtiquetaUsuario)
        Me.Panel2.Controls.Add(Me.CeldaUsuario)
        Me.Panel2.Controls.Add(Me.EtiquetaClave)
        Me.Panel2.Controls.Add(Me.EtiquetaVersion)
        Me.Panel2.Controls.Add(Me.CeldaClave)
        Me.Panel2.Controls.Add(Me.BotonAceptar)
        Me.Panel2.Controls.Add(Me.EtiquetaConexion)
        Me.Panel2.Location = New System.Drawing.Point(204, 15)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(335, 210)
        Me.Panel2.TabIndex = 12
        '
        'IconoConexion
        '
        Me.IconoConexion.Image = CType(resources.GetObject("IconoConexion.Image"), System.Drawing.Image)
        Me.IconoConexion.Location = New System.Drawing.Point(39, 169)
        Me.IconoConexion.Margin = New System.Windows.Forms.Padding(4)
        Me.IconoConexion.Name = "IconoConexion"
        Me.IconoConexion.Size = New System.Drawing.Size(21, 20)
        Me.IconoConexion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.IconoConexion.TabIndex = 7
        Me.IconoConexion.TabStop = False
        '
        'BotonAceptar
        '
        Me.BotonAceptar.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.BotonAceptar.Image = CType(resources.GetObject("BotonAceptar.Image"), System.Drawing.Image)
        Me.BotonAceptar.Location = New System.Drawing.Point(255, 128)
        Me.BotonAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.BotonAceptar.Name = "BotonAceptar"
        Me.BotonAceptar.Size = New System.Drawing.Size(47, 37)
        Me.BotonAceptar.TabIndex = 3
        Me.BotonAceptar.UseVisualStyleBackColor = True
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "12")
        Me.ImageList1.Images.SetKeyName(1, "11")
        Me.ImageList1.Images.SetKeyName(2, "14")
        Me.ImageList1.Images.SetKeyName(3, "16")
        Me.ImageList1.Images.SetKeyName(4, "15")
        Me.ImageList1.Images.SetKeyName(5, "18")
        Me.ImageList1.Images.SetKeyName(6, "19")
        Me.ImageList1.Images.SetKeyName(7, "20")
        Me.ImageList1.Images.SetKeyName(8, "21")
        Me.ImageList1.Images.SetKeyName(9, "22")
        '
        'frmSSesion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(555, 246)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Empresas)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmSSesion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inicio de sesión"
        Me.Panel1.ResumeLayout(False)
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.IconoConexion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents EtiquetaUsuario As System.Windows.Forms.Label
    Friend WithEvents CeldaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents EtiquetaClave As System.Windows.Forms.Label
    Friend WithEvents CeldaClave As System.Windows.Forms.TextBox
    Friend WithEvents BotonAceptar As System.Windows.Forms.Button
    Friend WithEvents EtiquetaConexion As System.Windows.Forms.Label
    Friend WithEvents IconoConexion As System.Windows.Forms.PictureBox
    Friend WithEvents EtiquetaVersion As System.Windows.Forms.Label
    Friend WithEvents Empresas As System.Windows.Forms.ListView
    Friend WithEvents id As System.Windows.Forms.ColumnHeader
    Friend WithEvents Empresa As System.Windows.Forms.ColumnHeader
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList

End Class
