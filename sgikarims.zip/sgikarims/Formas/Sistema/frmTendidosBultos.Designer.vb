﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTendidosBultos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaBultos = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaPesoNeto = New System.Windows.Forms.TextBox()
        Me.celdaTara = New System.Windows.Forms.TextBox()
        Me.celdaPesoBruto = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.celdaCorrelativo = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.dgPacasSeleccionadas = New System.Windows.Forms.DataGridView()
        Me.colAnoS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLienaBultoS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativoS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoNetoS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTaraS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoBrutoS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoriaS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLlaveS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLave2S = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.dgPacas = New System.Windows.Forms.DataGridView()
        Me.colAnoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaBultoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoNetoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTaraP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoBrutoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoriaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLaveP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLave2P = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgPacasPendientes = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.dgPacasSeleccionadas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.dgPacas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgPacasPendientes, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.celdaBultos)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.celdaTotal)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.celdaPesoNeto)
        Me.Panel1.Controls.Add(Me.celdaTara)
        Me.Panel1.Controls.Add(Me.celdaPesoBruto)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.celdaCorrelativo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1101, 97)
        Me.Panel1.TabIndex = 0
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(468, 12)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 17)
        Me.Label7.TabIndex = 19
        Me.Label7.Text = "Packages"
        '
        'celdaBultos
        '
        Me.celdaBultos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaBultos.Location = New System.Drawing.Point(458, 32)
        Me.celdaBultos.Name = "celdaBultos"
        Me.celdaBultos.ReadOnly = True
        Me.celdaBultos.Size = New System.Drawing.Size(85, 22)
        Me.celdaBultos.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(557, 12)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Amount"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(543, 32)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(133, 22)
        Me.celdaTotal.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(190, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 17)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Tare"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(317, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 17)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Gross weight."
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(36, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 17)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Net weight."
        '
        'celdaPesoNeto
        '
        Me.celdaPesoNeto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPesoNeto.Location = New System.Drawing.Point(25, 32)
        Me.celdaPesoNeto.Name = "celdaPesoNeto"
        Me.celdaPesoNeto.ReadOnly = True
        Me.celdaPesoNeto.Size = New System.Drawing.Size(133, 22)
        Me.celdaPesoNeto.TabIndex = 12
        '
        'celdaTara
        '
        Me.celdaTara.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTara.Location = New System.Drawing.Point(164, 32)
        Me.celdaTara.Name = "celdaTara"
        Me.celdaTara.ReadOnly = True
        Me.celdaTara.Size = New System.Drawing.Size(133, 22)
        Me.celdaTara.TabIndex = 11
        '
        'celdaPesoBruto
        '
        Me.celdaPesoBruto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPesoBruto.Location = New System.Drawing.Point(303, 32)
        Me.celdaPesoBruto.Name = "celdaPesoBruto"
        Me.celdaPesoBruto.ReadOnly = True
        Me.celdaPesoBruto.Size = New System.Drawing.Size(133, 22)
        Me.celdaPesoBruto.TabIndex = 10
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(581, 60)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'celdaCorrelativo
        '
        Me.celdaCorrelativo.Location = New System.Drawing.Point(25, 60)
        Me.celdaCorrelativo.Name = "celdaCorrelativo"
        Me.celdaCorrelativo.Size = New System.Drawing.Size(550, 22)
        Me.celdaCorrelativo.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonCancelar)
        Me.Panel2.Controls.Add(Me.botonAceptar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 446)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1101, 58)
        Me.Panel2.TabIndex = 1
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(1014, 5)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 51)
        Me.botonCancelar.TabIndex = 11
        Me.botonCancelar.Text = "Close"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(932, 5)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 51)
        Me.botonAceptar.TabIndex = 10
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel3.Controls.Add(Me.Panel5)
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(0, 97)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1101, 349)
        Me.Panel3.TabIndex = 2
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Beige
        Me.Panel5.Controls.Add(Me.dgPacasSeleccionadas)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(721, 0)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(380, 349)
        Me.Panel5.TabIndex = 1
        '
        'dgPacasSeleccionadas
        '
        Me.dgPacasSeleccionadas.AllowUserToAddRows = False
        Me.dgPacasSeleccionadas.AllowUserToDeleteRows = False
        Me.dgPacasSeleccionadas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgPacasSeleccionadas.BackgroundColor = System.Drawing.Color.DarkSeaGreen
        Me.dgPacasSeleccionadas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPacasSeleccionadas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnoS, Me.colNumeroS, Me.colLineaS, Me.colLienaBultoS, Me.colCorrelativoS, Me.colMarcaS, Me.colReferenciaS, Me.colDescripcionS, Me.colPesoNetoS, Me.colTaraS, Me.colPesoBrutoS, Me.colPrecioS, Me.colMedida, Me.colCategoriaS, Me.colLlaveS, Me.colLLave2S})
        Me.dgPacasSeleccionadas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgPacasSeleccionadas.Location = New System.Drawing.Point(0, 0)
        Me.dgPacasSeleccionadas.MultiSelect = False
        Me.dgPacasSeleccionadas.Name = "dgPacasSeleccionadas"
        Me.dgPacasSeleccionadas.ReadOnly = True
        Me.dgPacasSeleccionadas.RowTemplate.Height = 24
        Me.dgPacasSeleccionadas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPacasSeleccionadas.Size = New System.Drawing.Size(380, 349)
        Me.dgPacasSeleccionadas.TabIndex = 0
        '
        'colAnoS
        '
        Me.colAnoS.HeaderText = "Año"
        Me.colAnoS.Name = "colAnoS"
        Me.colAnoS.ReadOnly = True
        Me.colAnoS.Visible = False
        Me.colAnoS.Width = 58
        '
        'colNumeroS
        '
        Me.colNumeroS.HeaderText = "Number"
        Me.colNumeroS.Name = "colNumeroS"
        Me.colNumeroS.ReadOnly = True
        Me.colNumeroS.Visible = False
        Me.colNumeroS.Width = 83
        '
        'colLineaS
        '
        Me.colLineaS.HeaderText = "Linea"
        Me.colLineaS.Name = "colLineaS"
        Me.colLineaS.ReadOnly = True
        Me.colLineaS.Visible = False
        Me.colLineaS.Width = 68
        '
        'colLienaBultoS
        '
        Me.colLienaBultoS.HeaderText = "Bulto"
        Me.colLienaBultoS.Name = "colLienaBultoS"
        Me.colLienaBultoS.ReadOnly = True
        Me.colLienaBultoS.Visible = False
        Me.colLienaBultoS.Width = 65
        '
        'colCorrelativoS
        '
        Me.colCorrelativoS.HeaderText = "Correlative"
        Me.colCorrelativoS.Name = "colCorrelativoS"
        Me.colCorrelativoS.ReadOnly = True
        Me.colCorrelativoS.Width = 101
        '
        'colMarcaS
        '
        Me.colMarcaS.HeaderText = "Mark"
        Me.colMarcaS.Name = "colMarcaS"
        Me.colMarcaS.ReadOnly = True
        Me.colMarcaS.Width = 64
        '
        'colReferenciaS
        '
        Me.colReferenciaS.HeaderText = "Reference"
        Me.colReferenciaS.Name = "colReferenciaS"
        Me.colReferenciaS.ReadOnly = True
        Me.colReferenciaS.Width = 99
        '
        'colDescripcionS
        '
        Me.colDescripcionS.HeaderText = "Description"
        Me.colDescripcionS.Name = "colDescripcionS"
        Me.colDescripcionS.ReadOnly = True
        Me.colDescripcionS.Width = 104
        '
        'colPesoNetoS
        '
        Me.colPesoNetoS.HeaderText = "Net Weight"
        Me.colPesoNetoS.Name = "colPesoNetoS"
        Me.colPesoNetoS.ReadOnly = True
        Me.colPesoNetoS.Width = 103
        '
        'colTaraS
        '
        Me.colTaraS.HeaderText = "Tare"
        Me.colTaraS.Name = "colTaraS"
        Me.colTaraS.ReadOnly = True
        Me.colTaraS.Width = 63
        '
        'colPesoBrutoS
        '
        Me.colPesoBrutoS.HeaderText = "Gross Weight"
        Me.colPesoBrutoS.Name = "colPesoBrutoS"
        Me.colPesoBrutoS.ReadOnly = True
        Me.colPesoBrutoS.Width = 119
        '
        'colPrecioS
        '
        Me.colPrecioS.HeaderText = "Price"
        Me.colPrecioS.Name = "colPrecioS"
        Me.colPrecioS.ReadOnly = True
        Me.colPrecioS.Width = 65
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 88
        '
        'colCategoriaS
        '
        Me.colCategoriaS.HeaderText = "Category"
        Me.colCategoriaS.Name = "colCategoriaS"
        Me.colCategoriaS.ReadOnly = True
        Me.colCategoriaS.Width = 90
        '
        'colLlaveS
        '
        Me.colLlaveS.HeaderText = "Key"
        Me.colLlaveS.Name = "colLlaveS"
        Me.colLlaveS.ReadOnly = True
        Me.colLlaveS.Visible = False
        Me.colLlaveS.Width = 57
        '
        'colLLave2S
        '
        Me.colLLave2S.HeaderText = "KeyS"
        Me.colLLave2S.Name = "colLLave2S"
        Me.colLLave2S.ReadOnly = True
        Me.colLLave2S.Visible = False
        Me.colLLave2S.Width = 66
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.Info
        Me.Panel4.Controls.Add(Me.dgPacas)
        Me.Panel4.Controls.Add(Me.dgPacasPendientes)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(721, 349)
        Me.Panel4.TabIndex = 0
        '
        'dgPacas
        '
        Me.dgPacas.AllowUserToAddRows = False
        Me.dgPacas.AllowUserToDeleteRows = False
        Me.dgPacas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgPacas.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.dgPacas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPacas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnoP, Me.colNumeroP, Me.colLineaP, Me.colLineaBultoP, Me.colCorrelativoP, Me.colMarcaP, Me.colReferenciaP, Me.colDescripcionP, Me.colPesoNetoP, Me.colTaraP, Me.colPesoBrutoP, Me.colPrecioP, Me.colMedidaP, Me.colCategoriaP, Me.colLLaveP, Me.colLLave2P})
        Me.dgPacas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgPacas.Location = New System.Drawing.Point(0, 0)
        Me.dgPacas.MultiSelect = False
        Me.dgPacas.Name = "dgPacas"
        Me.dgPacas.ReadOnly = True
        Me.dgPacas.RowTemplate.Height = 24
        Me.dgPacas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPacas.Size = New System.Drawing.Size(721, 246)
        Me.dgPacas.TabIndex = 1
        '
        'colAnoP
        '
        Me.colAnoP.HeaderText = "Año"
        Me.colAnoP.Name = "colAnoP"
        Me.colAnoP.ReadOnly = True
        Me.colAnoP.Visible = False
        Me.colAnoP.Width = 58
        '
        'colNumeroP
        '
        Me.colNumeroP.HeaderText = "Numero"
        Me.colNumeroP.Name = "colNumeroP"
        Me.colNumeroP.ReadOnly = True
        Me.colNumeroP.Visible = False
        Me.colNumeroP.Width = 83
        '
        'colLineaP
        '
        Me.colLineaP.HeaderText = "Linea"
        Me.colLineaP.Name = "colLineaP"
        Me.colLineaP.ReadOnly = True
        Me.colLineaP.Visible = False
        Me.colLineaP.Width = 68
        '
        'colLineaBultoP
        '
        Me.colLineaBultoP.HeaderText = "Bulto"
        Me.colLineaBultoP.Name = "colLineaBultoP"
        Me.colLineaBultoP.ReadOnly = True
        Me.colLineaBultoP.Visible = False
        Me.colLineaBultoP.Width = 65
        '
        'colCorrelativoP
        '
        Me.colCorrelativoP.HeaderText = "Correlativo"
        Me.colCorrelativoP.Name = "colCorrelativoP"
        Me.colCorrelativoP.ReadOnly = True
        Me.colCorrelativoP.Width = 101
        '
        'colMarcaP
        '
        Me.colMarcaP.HeaderText = "Mark"
        Me.colMarcaP.Name = "colMarcaP"
        Me.colMarcaP.ReadOnly = True
        Me.colMarcaP.Width = 64
        '
        'colReferenciaP
        '
        Me.colReferenciaP.HeaderText = "Reference"
        Me.colReferenciaP.Name = "colReferenciaP"
        Me.colReferenciaP.ReadOnly = True
        Me.colReferenciaP.Width = 99
        '
        'colDescripcionP
        '
        Me.colDescripcionP.HeaderText = "Description"
        Me.colDescripcionP.Name = "colDescripcionP"
        Me.colDescripcionP.ReadOnly = True
        Me.colDescripcionP.Width = 104
        '
        'colPesoNetoP
        '
        Me.colPesoNetoP.HeaderText = "Net Weight"
        Me.colPesoNetoP.Name = "colPesoNetoP"
        Me.colPesoNetoP.ReadOnly = True
        Me.colPesoNetoP.Width = 103
        '
        'colTaraP
        '
        Me.colTaraP.HeaderText = "Tare"
        Me.colTaraP.Name = "colTaraP"
        Me.colTaraP.ReadOnly = True
        Me.colTaraP.Width = 63
        '
        'colPesoBrutoP
        '
        Me.colPesoBrutoP.HeaderText = "Gross Weight"
        Me.colPesoBrutoP.Name = "colPesoBrutoP"
        Me.colPesoBrutoP.ReadOnly = True
        Me.colPesoBrutoP.Width = 119
        '
        'colPrecioP
        '
        Me.colPrecioP.HeaderText = "Price"
        Me.colPrecioP.Name = "colPrecioP"
        Me.colPrecioP.ReadOnly = True
        Me.colPrecioP.Width = 65
        '
        'colMedidaP
        '
        Me.colMedidaP.HeaderText = "Measure"
        Me.colMedidaP.Name = "colMedidaP"
        Me.colMedidaP.ReadOnly = True
        Me.colMedidaP.Width = 88
        '
        'colCategoriaP
        '
        Me.colCategoriaP.HeaderText = "Category"
        Me.colCategoriaP.Name = "colCategoriaP"
        Me.colCategoriaP.ReadOnly = True
        Me.colCategoriaP.Width = 90
        '
        'colLLaveP
        '
        Me.colLLaveP.HeaderText = "Key"
        Me.colLLaveP.Name = "colLLaveP"
        Me.colLLaveP.ReadOnly = True
        Me.colLLaveP.Width = 57
        '
        'colLLave2P
        '
        Me.colLLave2P.HeaderText = "Key2"
        Me.colLLave2P.Name = "colLLave2P"
        Me.colLLave2P.ReadOnly = True
        Me.colLLave2P.Visible = False
        Me.colLLave2P.Width = 65
        '
        'dgPacasPendientes
        '
        Me.dgPacasPendientes.BackgroundColor = System.Drawing.SystemColors.Info
        Me.dgPacasPendientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPacasPendientes.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.dgPacasPendientes.Location = New System.Drawing.Point(0, 246)
        Me.dgPacasPendientes.Name = "dgPacasPendientes"
        Me.dgPacasPendientes.RowTemplate.Height = 24
        Me.dgPacasPendientes.Size = New System.Drawing.Size(721, 103)
        Me.dgPacasPendientes.TabIndex = 0
        '
        'frmTendidosBultos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1101, 504)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmTendidosBultos"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Packages"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        CType(Me.dgPacasSeleccionadas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.dgPacas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgPacasPendientes, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents dgPacasSeleccionadas As System.Windows.Forms.DataGridView
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents dgPacas As System.Windows.Forms.DataGridView
    Friend WithEvents dgPacasPendientes As System.Windows.Forms.DataGridView
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents celdaCorrelativo As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents celdaBultos As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaPesoNeto As System.Windows.Forms.TextBox
    Friend WithEvents celdaTara As System.Windows.Forms.TextBox
    Friend WithEvents celdaPesoBruto As System.Windows.Forms.TextBox
    Friend WithEvents colAnoS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLienaBultoS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativoS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarcaS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPesoNetoS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTaraS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPesoBrutoS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecioS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCategoriaS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLlaveS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLave2S As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnoP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaBultoP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativoP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarcaP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPesoNetoP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTaraP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPesoBrutoP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecioP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedidaP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCategoriaP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLaveP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLave2P As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
