﻿Public Class frmPrecioUnitario

#Region "Variables"

    Dim strtabla As String = STR_VACIO
    Dim strcantidad As String = STR_VACIO
    Dim strfactor As String = STR_VACIO
    Dim strunidad As String = STR_VACIO
    Public Const DEC_UNITARIO As Byte = 7
    Private Const VAL_KGS As Double = 2.2046

    Private logAceptar As Double
    Private dblPrecio As Double

#End Region

#Region "Propiedades"

    Public WriteOnly Property tabla As String
        Set(value As String)
            strtabla = value
        End Set
    End Property

    Public Property Aceptar As Double
        Get
            Return logAceptar
        End Get
        Set(value As Double)
            logAceptar = value
        End Set
    End Property

    Public Property Precio As Boolean
        Get
            Return dblPrecio
        End Get
        Set(value As Boolean)
            dblPrecio = value
        End Set
    End Property

#End Region

#Region "Funciones y Procedimientos Locales"

    Private Sub Conversion(ByVal Index As Integer)

        If Index = vbEmpty Then
            celdaFactor.Text = VAL_KGS
        Else
            celdaFactor.Text = (1 / VAL_KGS)
        End If

    End Sub

#End Region

    Private Sub frmPrecioUnitario_Load(sender As Object, e As EventArgs) Handles Me.Load

        celdaFactor.Text = Format(1, celdaTotal.Text)

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

        logAceptar = celdaUnitario.Text
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Sub botonCalcular_Click(sender As Object, e As EventArgs) Handles botonCalcular.Click

        Dim dblTotal As Double
        Dim dblCantidad As Double
        Dim dblFactor As Double

        dblTotal = CDbl(celdaTotal.Text)
        dblCantidad = CDbl(celdaCantidad.Text)
        dblFactor = CDbl(celdaFactor.Text)

        dblPrecio = ((dblTotal / dblCantidad) / dblFactor)
        celdaUnitario.Text = Format(Math.Round(dblPrecio, DEC_UNITARIO), FMT_UNITARIO)

    End Sub

    Private Sub etiquetaLBS_Click(sender As Object, e As EventArgs) Handles etiquetaLBS.Click
        Conversion(0)
    End Sub

    Private Sub etiquetaKGS_Click(sender As Object, e As EventArgs) Handles etiquetaKGS.Click
        Conversion(1)
    End Sub

    Private Sub celdaTotal_Validated(sender As Object, e As EventArgs) Handles celdaTotal.Validated
        Dim dblDato As Double
        dblDato = CDbl(celdaTotal.Text)
        celdaTotal.Text = Format(dblDato, FMT_UNITARIO)
    End Sub

    Private Sub celdaTotal_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaTotal.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send(vbTab)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub celdaCantidad_Validated(sender As Object, e As EventArgs) Handles celdaCantidad.Validated
        Dim dblDato As Double
        dblDato = CDbl(celdaCantidad.Text)
        celdaCantidad.Text = Format(dblDato, FMT_UNITARIO)
    End Sub

    Private Sub celdaCantidad_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaCantidad.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send(vbTab)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub celdaFactor_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaFactor.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send(vbTab)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

End Class