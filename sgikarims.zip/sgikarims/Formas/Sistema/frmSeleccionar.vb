﻿Imports System.ComponentModel
Imports System.Threading

Public Class frmSeleccionar

#Region "Variables"

    Dim strLLave As String = STR_VACIO
    Dim strDato As String = STR_VACIO
    Dim strDato2 As String = STR_VACIO
    Dim strDato3 As String = STR_VACIO
    Dim strDato4 As String = STR_VACIO



    Dim strCampos As String = STR_VACIO
    Dim strTabla As String = STR_VACIO
    Dim strFiltro As String = STR_VACIO
    Dim strFiltro2 As String = STR_VACIO
    Dim intLimite As Integer = NO_FILA
    Dim strCondicion As String = STR_VACIO
    Dim strCondicion2 As String = STR_VACIO
    Dim strOrdenamiento As String = STR_VACIO
    Dim strFiltroText As String = STR_VACIO
    Dim strTitulo As String = STR_VACIO
    Dim ROrdenamiento As String = "DESC"
    Dim strAgrupar As String = STR_VACIO
    Dim logCrear As Boolean = False
    Dim strParametroCrear As String
    Dim logMultiple As Boolean = False
    Dim logMultipleNV As Boolean = False




    Dim Celda As New DataGridViewTextBoxCell
    Dim Fila As New DataGridViewRow
    Dim check As New DataGridViewCheckBoxCell
    Dim arrayCampos() As String
    Dim arrayColumnas As New List(Of String)
    Dim arrayTemporal() As String
    Dim COM As MySqlCommand
    Dim REA As MySqlDataReader
    Dim intcontador As Integer = INT_CERO
    Dim thread1 As Thread
    Dim strSQL2 As String
    Dim dt As New System.Data.DataTable
    Dim DAA As MySqlDataAdapter

    Public Delegate Sub delegate1(ByVal value As Object)

#End Region

#Region "Propiedades"

    Public WriteOnly Property Multiple As Boolean
        Set(value As Boolean)
            logMultiple = value
        End Set
    End Property
    Public WriteOnly Property MultipleNV As Boolean
        Set(value As Boolean)
            logMultipleNV = value
        End Set
    End Property

    Public Property DataGrid As DataGridView
        Set(value As DataGridView)
            ListaClientes = value
        End Set
        Get
            Return ListaClientes
        End Get
    End Property


    Public WriteOnly Property ParametroCrear As String
        Set(value As String)
            strParametroCrear = value
        End Set
    End Property

    Public WriteOnly Property LCrear As String
        Set(value As String)
            logCrear = value
        End Set
    End Property

    Public Property LLave As String
        Get
            Return strLLave
        End Get
        Set(value As String)
            strLLave = value
        End Set
    End Property

    Public WriteOnly Property Agrupar As String
        Set(value As String)
            strAgrupar = value
        End Set
    End Property

    Public Property Dato2 As String
        Get
            Return strDato2
        End Get
        Set(value As String)
            strDato2 = value
        End Set
    End Property

    Public Property Dato As String
        Get
            Return strDato
        End Get
        Set(value As String)
            strDato = value
        End Set
    End Property

    Public Property Dato3 As String
        Get
            Return strDato3
        End Get
        Set(value As String)
            strDato3 = value
        End Set
    End Property

    Public Property Dato4 As String
        Get
            Return strDato4
        End Get
        Set(value As String)
            strDato4 = value
        End Set
    End Property

    Public Property Campos As String
        Get
            Return strCampos
        End Get
        Set(value As String)
            strCampos = value
        End Set
    End Property

    Public Property Tabla As String
        Get
            Return strTabla
        End Get
        Set(value As String)
            strTabla = value
        End Set
    End Property

    Public Property Filtro As String
        Get
            Return strFiltro
        End Get
        Set(value As String)
            strFiltro = value
        End Set
    End Property
    Public Property Filtro2 As String
        Get
            Return strFiltro2
        End Get
        Set(value As String)
            strFiltro2 = value
        End Set
    End Property

    Public Property FiltroText As String
        Get
            Return strFiltroText
        End Get
        Set(value As String)
            strFiltroText = value
        End Set
    End Property

    Public Property Titulo As String
        Get
            Return strTitulo
        End Get
        Set(value As String)
            strTitulo = value
        End Set
    End Property

    Public Property Limite As Integer
        Get
            Return intLimite
        End Get
        Set(value As Integer)
            intLimite = value
        End Set
    End Property

    Public Property Condicion As String
        Get
            Return strCondicion
        End Get
        Set(value As String)
            strCondicion = value
        End Set
    End Property
    Public Property Condicion2 As String
        Get
            Return strCondicion2
        End Get
        Set(value As String)
            strCondicion2 = value
        End Set
    End Property

    Public Property Ordenamiento As String
        Get
            Return strOrdenamiento
        End Get
        Set(value As String)
            strOrdenamiento = value
        End Set
    End Property

    Public WriteOnly Property TipoOrdenamiento As String
        Set(value As String)
            ROrdenamiento = value
        End Set
    End Property

#End Region

#Region "Funciones"

    Private Sub CargarMultiples(ByVal strSQL As String)
        Dim breserved As Boolean = False
        arrayColumnas.Clear()
        ListaClientes.Columns.Clear()
        strSQL2 = strSQL
        frmMensaje.Mensaje = "Please Wait, Loading Data"
        frmMensaje.Show()
        system.Windows.Forms.Application.DoEvents()
        arrayCampos = strCampos.Split(",".ToCharArray)


        For i As Integer = 0 To arrayCampos.Length - 1
            arrayCampos(i) = Trim(arrayCampos(i))
            arrayCampos(i) = Replace(arrayCampos(i), Space(2), Space(1))
            arrayTemporal = arrayCampos(i).Split(Space(1).ToCharArray)
            arrayColumnas.Add(arrayTemporal(1))
        Next
        intcontador = INT_CERO
        For Each item As String In arrayColumnas
            intcontador = intcontador + 1
            If intcontador = 1 Then
                ListaClientes.Columns.Add("colCheck", "Check")
            End If
            ListaClientes.Columns.Add("col_" & item, item)

        Next

        For Each item As String In arrayColumnas
            If item = "idreserva" Then
                ListaClientes.Columns.Item("col_" & item).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
                ListaClientes.Columns.Item("col_" & item).Width = 0
                ListaClientes.Columns.Item("col_" & item).Visible = False
                breserved = True
            End If

        Next



        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL2, CON)

        COM.CommandTimeout = 240
        REA = COM.ExecuteReader
        intcontador = INT_CERO


        ListaClientes.Rows.Clear()
        If REA.HasRows Then

            Do While REA.Read

                intcontador = intcontador + 1

                Fila = New DataGridViewRow
                check = New DataGridViewCheckBoxCell
                check.Value = False
                check.ReadOnly = False
                Fila.Cells.Add(check)

                For Each item As String In arrayColumnas
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = REA.GetString(item)

                    Fila.Cells.Add(Celda)
                Next

                ListaClientes.Rows.Add(Fila)
            Loop


        End If

        If breserved = True Then
            With ListaClientes

                For irow = 0 To .Rows.Count - 1
                    If .Rows(irow).Cells("col_reserved").Value > 0 Then
                        .Rows(irow).Cells("col_reserved").Style.BackColor = Color.Yellow
                    End If
                Next

            End With
        End If
        frmMensaje.Dispose()
        frmMensaje.Close()
        ' Me.Activate()

    End Sub

    Private Sub CargarMultiplesNV(ByVal strSQL As String)
        Dim breserved As Boolean = False

        ListaClientes.Columns.Clear()
        ListaClientes.Rows.Clear()

        frmMensaje.Mensaje = "Please Wait, Loading Data"
        frmMensaje.Show()
        System.Windows.Forms.Application.DoEvents()

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.CommandTimeout = 240
        REA = COM.ExecuteReader()

        ' Ajustar columnas automáticamente según el contenido
        'ListaClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells
        ListaClientes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None
        ListaClientes.AllowUserToOrderColumns = False

        ' Agregar columnas dinámicas basadas en nombres reales
        For i As Integer = 0 To REA.FieldCount - 1
            Dim colName As String = REA.GetName(i)
            ListaClientes.Columns.Add("col_" & colName, colName)
            'ListaClientes.Columns.Item("col_" & colName).AutoSizeMode = DataGridViewAutoSizeColumnMode.None
            'ListaClientes.Columns.Item("col_" & colName).Width = 300
            ListaClientes.Columns.Item("col_" & colName).Width = 85

        Next

        ' Agregar filas
        While REA.Read()
            Dim Fila As New DataGridViewRow()

            For i As Integer = 0 To REA.FieldCount - 1
                Dim Celda As New DataGridViewTextBoxCell()
                Celda.Value = If(REA.IsDBNull(i), "", REA.GetValue(i).ToString())
                Fila.Cells.Add(Celda)
            Next

            ListaClientes.Rows.Add(Fila)
        End While

        REA.Close()

        frmMensaje.Dispose()
        frmMensaje.Close()
    End Sub


    Private Sub Buscar()
        Dim strSQL As String = "SELECT {campos} FROM {tabla} WHERE {condicion} "
        If celdaFiltro.Text.Length > 0 Then

            If strFiltro2.Length > 0 Then
                'FILTRO 2 FOR CODIGO 
                strSQL &= " AND ({filtro} LIKE '%" & celdaFiltro.Text & "%' OR {filtro2} LIKE '%" & celdaFiltro.Text & "%')"
            Else
                strSQL &= " AND {filtro} like '%" & celdaFiltro.Text & "%'"
            End If


        End If

        If strAgrupar.Length > 0 Then
            strSQL &= " GROUP BY  " & strAgrupar
        End If
        If Condicion2.Length > 0 Then
            strSQL &= " HAVING " & strCondicion2
        End If
        If strOrdenamiento.Length > 0 Then
            strSQL &= " ORDER BY  " & strOrdenamiento & " " & ROrdenamiento
        End If
        If intLimite > 0 Then
            strSQL &= " LIMIT " & intLimite
        End If
        strSQL = Replace(strSQL, "{campos}", strCampos)
        strSQL = Replace(strSQL, "{tabla}", strTabla)
        strSQL = Replace(strSQL, "{filtro}", strFiltro)
        strSQL = Replace(strSQL, "{filtro2}", strFiltro2)
        strSQL = Replace(strSQL, "{condicion}", strCondicion)
        If logMultiple = False And logMultipleNV = False Then
            cFunciones.CargarLista(ListaClientes, strSQL)
        Else
            If logMultipleNV Then
                'Se agrego una nuevo funcion al selecionar, por que generaba errores al separar por comas
                'para evitar errores en otros modulos se crear una nueva (NV)
                CargarMultiplesNV(strSQL)
            Else
                CargarMultiples(strSQL)
            End If
        End If

        strSQL = STR_VACIO
    End Sub

    Private Sub Seleccionar()
        If ListaClientes.SelectedRows.Count = 0 Then Exit Sub
        Try
            If logMultiple = False Then
                strLLave = ListaClientes.SelectedCells(0).Value
                strDato = ListaClientes.SelectedCells(1).Value
                strDato2 = ListaClientes.SelectedCells(2).Value
                strDato3 = ListaClientes.SelectedCells(3).Value
                strDato4 = ListaClientes.SelectedCells(4).Value
            Else
                DataGrid = ListaClientes
            End If

        Catch ex As Exception

        End Try
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

#End Region

    Private Sub frmSeleccionarCliente_Load(sender As Object, e As EventArgs) Handles Me.Load
        Control.CheckForIllegalCrossThreadCalls = False

        If logCrear = True Then
            botonCrear.Visible = True
        Else
            botonCrear.Visible = False
        End If
        Buscar()
        Me.Text &= strTitulo
        etiquetaFiltro.Text = strFiltroText
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Buscar()
    End Sub

    Private Sub ListaClientes_DoubleClick(sender As Object, e As EventArgs) Handles ListaClientes.DoubleClick
        If logMultiple = True Then
            If ListaClientes.CurrentRow.Cells("colCheck").Value = True Then
                ListaClientes.CurrentRow.Cells("colCheck").Value = False
            Else
                ListaClientes.CurrentRow.Cells("colCheck").Value = True
            End If
        Else
            Seleccionar()
        End If

    End Sub

    Private Sub botonSeleccionar_Click(sender As Object, e As EventArgs) Handles botonSeleccionar.Click
        Seleccionar()
    End Sub

    Private Sub ListaClientes_KeyDown(sender As Object, e As KeyEventArgs) Handles ListaClientes.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Seleccionar()
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(ListaClientes)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaFiltro_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaFiltro.KeyDown
        Try
            If e.KeyCode = Keys.Enter Or e.KeyCode = Keys.Tab Then
                Buscar()
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Exit Sub
    End Sub

    Private Sub botonCrear_Click(sender As Object, e As EventArgs) Handles botonCrear.Click
        Select Case strParametroCrear
            Case "Insumos"
                Dim frm As New frmInsumos
                frm.ShowDialog(Me)
            Case Else
                Exit Sub
        End Select
    End Sub

    Private Sub ListaClientes_DataBindingComplete(sender As Object, e As DataGridViewBindingCompleteEventArgs) Handles ListaClientes.DataBindingComplete
        Try
            If ListaClientes.Columns.Contains("ReferenciaCortar") Then
                With ListaClientes.Columns("ReferenciaCortar")
                    .AutoSizeMode = DataGridViewAutoSizeColumnMode.None ' Muy importante
                    .Width = 100
                    .DefaultCellStyle.WrapMode = DataGridViewTriState.False
                End With

                ListaClientes.Columns("ReferenciaCortar").HeaderText = "Referencia"

            End If
        Catch ex As Exception
            MsgBox("Error al ajustar columna: " & ex.Message)
        End Try
    End Sub


End Class