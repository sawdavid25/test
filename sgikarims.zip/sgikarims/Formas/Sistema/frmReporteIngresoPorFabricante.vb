﻿Public Class frmReporteIngresoPorFabricante
#Region "Variables"
    Dim intNombre As Integer
    Dim dtFechaInicial As Date
    Dim dtFechaFinal As Date
    Dim logTodo As Boolean
    Dim LogCheck As Boolean
    Dim intFiltro As Integer
#End Region
#Region "Procedimientos"
    Public WriteOnly Property TipoFiltro As Integer

        Set(value As Integer)
            intFiltro = value
        End Set
    End Property
    Public ReadOnly Property IntSeleccion As Integer
        Get
            Return intNombre
        End Get
    End Property
    Public ReadOnly Property FechaInicial As Date
        Get
            Return dtFechaInicial
        End Get
    End Property
    Public ReadOnly Property FechaFinal As Date
        Get
            Return dtFechaFinal
        End Get
    End Property
    Public ReadOnly Property Todo As Boolean
        Get
            Return logTodo
        End Get
    End Property
    Public ReadOnly Property Check As Boolean
        Get
            Return LogCheck
        End Get
    End Property
#End Region
#Region "Funciones"
    Private Function CargarFiltro(ByVal Opcion As Integer) As frmSeleccionar
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Try
            Select Case Opcion
                Case 1  ' Proveedores 
                    frm.Campos = " pro_codigo, pro_proveedor"
                    frm.Tabla = " Proveedores"
                    frm.Filtro = " pro_proveedor"
                    frm.Limite = " 40 "
                    frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & " "
                    frm.Ordenamiento = " pro_proveedor "
                    frm.TipoOrdenamiento = "asc"
                    ' propiedades del formulario 
                    frm.Titulo = "provider"
                    frm.FiltroText = "enter the name of the provider to filter"
                Case 2
                    strTabla = " (
                                    SELECT cli_codigo ID, cli_cliente Description,IF(cli_tipo  = 0, 'Invoice',IF(cli_tipo=1,'Destination','AR')) type
                                    FROM Clientes WHERE cli_sisemp=" & Sesion.IdEmpresa & " AND cli_status ='Activo'
                                    ORDER BY cli_cliente) a "
                    'Propiedades de la consulta 
                    frm.Campos = " a.ID, a.Description, a.type "
                    frm.Tabla = strTabla
                    frm.Condicion = " a.ID>0"
                    frm.Filtro = " a.Description"
                    frm.Limite = " 20 "
                    ' Propiedades del Formulario 
                    frm.Titulo = "Customer"
                    frm.FiltroText = "Enter the name of the client to filter"
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return frm
    End Function
#End Region
    Private Sub frmReporteIngresoPorFabricante_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim fechainicio As New DateTime '(DateTime.Now.Year, DateTime.Now.Month, 1)
        Dim fechafin As DateTime    '= fechainicio.AddMonths(1).AddDays(-1)

        fechainicio = Today.AddMonths(NO_FILA)
        fechafin = Today

        dtpFechaInicio.Value = fechainicio
        dtpFechaFinal.Value = fechafin

    End Sub

    Private Sub botonNombre_Click(sender As Object, e As EventArgs) Handles botonNombre.Click
        Dim frm As New frmSeleccionar
        'Propiedades de la consulta 
        Try

            frm = CargarFiltro(intFiltro)
            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdNombre.Text = frm.LLave
                celdaNombre.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonContinuar_Click(sender As Object, e As EventArgs) Handles botonContinuar.Click
        Try
            If celdaIdNombre.Text = vbNullString Then
                MsgBox("Please choose a provider")
                Exit Sub
            Else
                intNombre = celdaIdNombre.Text
            End If
            If checkDocumentos.Checked = True Then
                logTodo = False
            Else
                logTodo = True
            End If
            If check2.Checked = True Then
                LogCheck = True
            Else
                LogCheck = False
            End If

            dtFechaInicial = dtpFechaInicio.Value
            dtFechaFinal = dtpFechaFinal.Value


            Me.DialogResult = DialogResult.OK
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class