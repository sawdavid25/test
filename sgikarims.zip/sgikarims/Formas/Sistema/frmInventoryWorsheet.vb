﻿Public Class frmInventoryWorsheet


#Region "Miembros"
    'Variables privadas
    Private logAceptado As Boolean
    Private strBodega As String

    'Variables públicas
    Public Columnas As Boolean
    Public Rango As Boolean
    Public Inicio As Date
    Public Fin As Date

    Public Pais As Integer
    Public Producto As Long

    Public Orden As String

#End Region

#Region "Propiedades"

    Public Property Aceptado As Boolean
        Get
            Return logAceptado
        End Get
        Set(value As Boolean)
            logAceptado = value
        End Set
    End Property

    Public Property Bodega As Boolean
        Get
            Return strBodega
        End Get
        Set(value As Boolean)
            strBodega = value
        End Set
    End Property

#End Region

#Region "Procedimientos"

    Public Sub Resumen()
        checkRangeDate.Enabled = False
        checkIncluirColumnas.Enabled = False

        dtpInicial.Enabled = False
        dtpFinal.Enabled = False

        botonSeleccion.Enabled = False
        botonSeleccion2.Enabled = False
        celdaSeleccion.Enabled = False
        celdaSeleccion2.Enabled = False

        botonBodega.Enabled = False
        celdaBodega.Enabled = False
    End Sub

#End Region

#Region "Eventos"

    Private Sub frmInventoryWorcheet_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Primer y último día del año
        dtpInicial.Value = Today.AddMonths(NO_FILA)
        dtpFinal.Value = Today

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click

        If celdaIDProducto.Text = NO_FILA Then
            celdaIDProducto.Text = vbEmpty
        End If

        If celdaIDPais.Text = NO_FILA Then
            celdaIDPais.Text = NO_FILA
        End If

        Producto = celdaIDProducto.Text
        Pais = celdaIDPais.Text

        If celdaBodega.Text = " " Then
            strBodega = vbNullString
        Else
            strBodega = celdaBodega.Text
        End If

        logAceptado = True
        Me.Hide()

    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub

    Private Sub botonProductos_Click(sender As Object, e As EventArgs) Handles botonProductos.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCondicion = "art_sisemp = {empresa} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            frm.Titulo = "Products"
            frm.FiltroText = " Enter The Product To Filter"
            frm.Campos = " art_codigo ID, art_DCorta Descripcion"
            frm.Tabla = " Articulos"
            frm.Filtro = " art_DCorta "
            frm.Condicion = strCondicion
            frm.Ordenamiento = "art_DCorta"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDProducto.Text = frm.LLave
                celdaProducto.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonPaisOrigen_Click(sender As Object, e As EventArgs) Handles botonPaisOrigen.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cat_clase='Paises'"

        Try
            frm.Titulo = "Counties"
            frm.FiltroText = " Enter The Countries To Filter"
            frm.Campos = " cat_num ID, cat_desc Descripcion"
            frm.Tabla = " Catalogos"
            frm.Filtro = " art_DCorta "
            frm.Condicion = strCondicion
            frm.Ordenamiento = "cat_desc"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDPais.Text = frm.LLave
                celdaPaisOrigen.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBodega_Click(sender As Object, e As EventArgs) Handles botonBodega.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        If checkBodega.Checked = True Then

            strCondicion = "DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat={tipo} "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{tipo}", 47)
            Try
                frm.Titulo = "Countries"
                frm.FiltroText = " Enter The Countries To Filter"
                frm.Campos = " DISTINCT DDoc_RF2_Cod Bodega"
                frm.Tabla = " Dcmtos_DTL"""
                frm.Filtro = " DDoc_RF2_Cod "
                frm.Condicion = strCondicion
                frm.Ordenamiento = "DDoc_RF2_Cod"

                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    celdaBodega.Text = frm.LLave
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            strCondicion = "DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat={tipo} AND DDoc_RF2_Cod!=''"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{tipo}", 47)
            Try
                frm.Titulo = "Countries"
                frm.FiltroText = " Enter The Countries To Filter"
                frm.Campos = " DISTINCT TRIM(LEFT(DDoc_RF2_Cod,1)) Bodega"
                frm.Tabla = " Dcmtos_DTL"""
                frm.Filtro = " DDoc_RF2_Cod "
                frm.Condicion = strCondicion
                frm.Ordenamiento = "DDoc_RF2_Cod"

                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    celdaBodega.Text = frm.LLave
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

#End Region







 
End Class