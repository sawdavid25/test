﻿Public Class frmRequisiciones

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim intfabricante As Integer
    Dim intclase As Integer
    Dim logclase As Boolean
    Dim logorden As Boolean
    Dim intID As Integer
    Dim strOrigenProd As String
    Dim strNombProv As String

    Public intcodInventario As Integer
    Public intcantidad As Double
    Public intprecio As Double
    Public intlinea As Integer
    Public intmedida As String
    Public intorden As String
    Public intaño As Integer
    Public intnumero As Integer
    Public intcodigo As Integer
    Public intinsert As Boolean
    Public intfila As Integer
    Public logProducto As Boolean
    Public logLibre As Boolean
    Public logUnico As Boolean
    Public logAceptado As Boolean
    Public dtFecha As Date
    Public Desperdicio As Boolean = False
    Public Invisible As Boolean = False
    Public Proceso As Boolean = False
    Public intTipoIng As Integer
    Public intTipoWaste As Integer
    Public intTipoInvisible As Integer

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property codInventario As Integer
        Get
            Return intcodInventario
        End Get
        Set(value As Integer)
            intcodInventario = value
        End Set
    End Property

    Public Property Cantidad As Double
        Get
            Return intcantidad
        End Get
        Set(value As Double)
            intcantidad = value
        End Set
    End Property

    Public Property Precio As Double
        Get
            Return intprecio
        End Get
        Set(value As Double)
            intprecio = value
        End Set
    End Property

    Public Property Linea As Boolean
        Get
            Return intlinea
        End Get
        Set(value As Boolean)
            intlinea = value
        End Set
    End Property

    Public Property Medida As String
        Get
            Return intmedida
        End Get
        Set(value As String)
            intmedida = value
        End Set
    End Property

    Public Property Orden As String
        Get
            Return intorden
        End Get
        Set(value As String)
            intorden = value
        End Set
    End Property

    Public Property Año As Integer
        Get
            Return intaño
        End Get
        Set(value As Integer)
            intaño = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return intnumero
        End Get
        Set(value As Integer)
            intnumero = value
        End Set
    End Property

    Public Property Codigo As Long
        Get
            Return intcodigo
        End Get
        Set(value As Long)
            intcodigo = value
        End Set
    End Property

    Public Property Insert As Boolean
        Get
            Return intinsert
        End Get
        Set(value As Boolean)
            intinsert = value
        End Set
    End Property

    Public Property Fila As Integer
        Get
            Return intfila
        End Get
        Set(value As Integer)
            intfila = value
        End Set
    End Property

    Public Property Producto As Boolean
        Get
            Return logProducto
        End Get
        Set(value As Boolean)
            logProducto = value
        End Set
    End Property

    Public Property Unico As Boolean
        Get
            Return logUnico
        End Get
        Set(value As Boolean)
            logUnico = value
        End Set
    End Property


    Public Property Libre As Boolean
        Get
            Return logLibre
        End Get
        Set(value As Boolean)
            logLibre = value
        End Set
    End Property

    Public Property Aceptado As Boolean
        Get
            Return logAceptado
        End Get
        Set(value As Boolean)
            logAceptado = value
        End Set
    End Property

    Public Property OrdenDeImportacion As Boolean
        Get
            Return logorden
        End Get
        Set(value As Boolean)
            logorden = value

            If value Then
                celdaInfo1.ForeColor = Color.Blue
                celdaInfo2.ForeColor = Color.Red
                panelInfo1.Visible = True
            End If
        End Set
    End Property
    Public Property Fecha As Date
        Get
            Return dtFecha
        End Get
        Set(value As Date)
            dtFecha = value
        End Set
    End Property


    Public Property intTipoIngeso As Integer
        Get
            Return intTipoIng
        End Get
        Set(value As Integer)
            intTipoIng = value
        End Set
    End Property

    Public Property TipoWaste As Integer
        Get
            Return intTipoWaste
        End Get
        Set(value As Integer)
            intTipoWaste = value
        End Set
    End Property

    Public Property TipoInvisible As Integer
        Get
            Return intTipoInvisible
        End Get
        Set(value As Integer)
            intTipoInvisible = value
        End Set
    End Property
#End Region

    Private Sub Reset()
        dgLista.Rows.Clear()
    End Sub

    Public Sub Iniciar()
        'Rutina de Inicialización
        If Me.Tag = "nuevo" Then
            intinsert = True
            ' CargarListaRequicision()
            queryInfoProducto()
        Else
            intinsert = False
            ' CargarListaRequicision()
            queryInfoProducto()
        End If
    End Sub

    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO
        Dim intID As Integer
        Dim COM As New MySqlCommand

        intfabricante = vbNullString
        If intcodigo > vbEmpty Then

            strSQL = " SELECT inv_provcod"
            strSQL &= "   FROM Inventarios"
            strSQL &= "     WHERE inv_sisemp={empresa} AND inv_numero={codigo}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intcodigo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intID = COM.ExecuteScalar

            strSQL = " SELECT inv_artcodigo"
            strSQL &= "   FROM Inventarios"
            strSQL &= "     WHERE inv_sisemp={empresa} AND inv_numero={codigo}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intcodigo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intclase = COM.ExecuteScalar

            If Not intID > vbEmpty Then intID = NO_FILA
        End If

        If (Not intID = NO_FILA) Then
            strSQL = " SELECT pro_codigo"
            strSQL &= "   FROM Proveedores"
            strSQL &= "     WHERE pro_sisemp={empresa} AND pro_codigo={ID}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ID}", intID)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intfabricante = COM.ExecuteScalar
        End If

        strSQL = "SELECT l1.*, (l1.transito - l1.bodega) confirmado, (l1.cantidad - (l1.transito+l1.manual)) saldo, 0 semana, 0 lote"
        strSQL &= " FROM ("
        strSQL &= "    SELECT d.DDoc_Doc_Cat tipo, d.DDoc_Doc_Ano ano, d.DDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, e.HDoc_Doc_Fec fecha,IFNULL(cp.cat_clave,0) pais, lf.pro_codigo codfabricante, IFNULL(lf.pro_proveedor,0) fabricante,  e.HDoc_DR1_Num referencia, d.DDoc_RF1_Cod orden, a.art_codigo clase, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion,d.DDoc_RF3_Dbl precio, d.DDoc_Prd_QTY cantidad, d.DDoc_Prd_UM unidad, IFNULL(cm.cat_clave,'') medida,"
        strSQL &= "        IFNULL((SELECT SUM(r1.PDoc_QTY_Pro) "
        strSQL &= "            FROM Dcmtos_DTL_Pro r1"

        strSQL &= "               LEFT JOIN Dcmtos_HDR e1 ON e1.HDoc_Sis_Emp = r1.PDoc_Sis_Emp AND e1.HDoc_Doc_Cat = r1.PDoc_Chi_Cat AND e1.HDoc_Doc_Ano = r1.PDoc_Chi_Ano AND e1.HDoc_Doc_Num = r1.PDoc_Chi_Num "
        strSQL &= "                  WHERE r1.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r1.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r1.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r1.PDoc_Par_Num = d.DDoc_Doc_Num AND r1.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r1.PDoc_Chi_Cat = 127 AND e1.HDoc_Doc_Status = 1),0) transito,IFNULL((SELECT SUM(IFNULL(r4.PDoc_QTY_Pro,0))  "
        strSQL &= "                         FROM Dcmtos_DTL_Pro r1"
        strSQL &= "                              LEFT JOIN Dcmtos_DTL_Pro r2 ON r2.PDoc_Sis_Emp = r1.PDoc_Sis_Emp AND r2.PDoc_Par_Cat = r1.PDoc_Chi_Cat AND r2.PDoc_Par_Ano = r1.PDoc_Chi_Ano AND r2.PDoc_Par_Num = r1.PDoc_Chi_Num AND r2.PDoc_Par_Lin = r1.PDoc_Chi_Lin AND r2.PDoc_Chi_Cat = 55 "
        strSQL &= "                                  LEFT JOIN Dcmtos_DTL_Pro r3 ON r3.PDoc_Sis_Emp = r2.PDoc_Sis_Emp AND r3.PDoc_Par_Cat = r2.PDoc_Chi_Cat AND r3.PDoc_Par_Ano = r2.PDoc_Chi_Ano AND r3.PDoc_Par_Num = r2.PDoc_Chi_Num AND r3.PDoc_Par_Lin = r2.PDoc_Chi_Lin AND r3.PDoc_Chi_Cat = 180 "
        strSQL &= "                             LEFT JOIN Dcmtos_DTL_Pro r4 ON r4.PDoc_Sis_Emp = r3.PDoc_Sis_Emp AND r4.PDoc_Par_Cat = r3.PDoc_Chi_Cat AND r4.PDoc_Par_Ano = r3.PDoc_Chi_Ano AND r4.PDoc_Par_Num = r3.PDoc_Chi_Num AND r4.PDoc_Par_Lin = r3.PDoc_Chi_Lin AND r4.PDoc_Chi_Cat =47 "
        strSQL &= "                           WHERE r1.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r1.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r1.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r1.PDoc_Par_Num = d.DDoc_Doc_Num AND r1.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r1.PDoc_Chi_Cat = 127),0) bodega, IFNULL((SELECT SUM(m.IDoc_Itm_QTY) FROM Dcmtos_DTL_Itm m WHERE m.IDoc_Sis_Emp=d.DDoc_Sis_Emp AND m.IDoc_Doc_Cat=d.DDoc_Doc_Cat AND m.IDoc_Doc_Ano=d.DDoc_Doc_Ano AND m.IDoc_Doc_Num=d.DDoc_Doc_Num AND m.IDoc_Doc_Lin=d.DDoc_Doc_Lin AND m.IDoc_RF1_Txt='DESPACHO'),0) manual,IF(e.HDoc_Doc_Status = 1 AND d.DDoc_RF2_Num = 0,1,0) activo"
        strSQL &= "                   FROM Dcmtos_DTL d"
        strSQL &= "                  INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "             LEFT JOIN Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM "
        strSQL &= "           LEFT JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod "
        strSQL &= "          LEFT JOIN Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo "
        strSQL &= "        LEFT JOIN Catalogos cp ON cp.cat_clase='Paises' AND cp.cat_num=i.inv_lugarfab "
        strSQL &= "      LEFT JOIN Proveedores lf ON lf.pro_sisemp=d.DDoc_Sis_Emp AND lf.pro_codigo=d.DDoc_RF1_Num"
        strSQL &= "     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 38 {fabricante} AND "
        strSQL &= "  (({estado} d.DDoc_RF2_Num != 9) OR (a.art_codigo={clase} AND d.DDoc_RF1_Cod='{numero}' AND '{numero}'!=''))) l1"
        strSQL &= "  ORDER BY fecha, numero, linea "

        strSQL = Replace(strSQL, "{estado}", vbNullString)

        'Documentos Involucrados
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{clase}", intclase)
        strSQL = Replace(strSQL, "{numero}", intorden)

        If intfabricante = NO_FILA Then
            strSQL = Replace(strSQL, "{fabricante}", vbNullString)
        Else
            strSQL = Replace(strSQL, "{fabricante}", " AND (d.DDoc_RF1_Num IN (0," & intfabricante & "))")
        End If

        Return strSQL
    End Function

    Private Function DescargosDeLinea(ByVal Ciclo As Integer, ByVal Numero As Integer, ByVal Linea As Integer, Optional ByVal Excluir As Integer = NO_FILA) As Double
        'Devuelve la suma de las cantidades descargadas para una línea de orden
        Dim Cf As New frmConfirmacion
        Dim dblTemp As Double
        Dim dblDes As Double
        Dim i As Integer = 0

        dblTemp = vbEmpty
        For i = 0 To Cf.dgInfoDescargo.Rows.Count - 1
            'Numero -> Requisicion 
            If Val(Cf.dgInfoDescargo.Rows(i).Cells("colAno").Value = Ciclo) And
                Val(Cf.dgInfoDescargo.Rows(i).Cells("colNumero").Value = Numero) And
                Val(Cf.dgInfoDescargo.Rows(i).Cells("colLine").Value = Linea) Then

                dblDes = Val(Cf.dgInfoDescargo.Rows(i).Cells("colDescargar").Value = Ciclo)

                If Val(Cf.dgInfoDescargo.Rows(i).Cells("colID").Value = Excluir) Then
                    'Misma linea, lo resta para incrementar el saldo
                    dblTemp = dblTemp + dblDes

                End If
            End If
        Next

        'Devuelve el resultado
        DescargosDeLinea = dblTemp
    End Function

    'Procedimiento para Cargar dgLista 
    Public Sub CargarListaRequicision()

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim a As Integer
        Dim clas As String
        Dim orden As String
        Dim f As String
        Dim d As Double
        Dim dblSaldo As Double

        strSQL = sqlLista()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strTemp As String = STR_VACIO

                    dblSaldo = (REA.GetDouble("saldo") - DescargosDeLinea(REA.GetInt32("ano"), REA.GetInt32("numero"), REA.GetInt32("linea")))

                    If ((dblSaldo > vbEmpty) Or ((REA.GetString("Orden") = orden And REA.GetString("Clase") = clas) And Not (orden = vbNullString))) Then
                        strTemp = REA.GetDateTime("fecha") & "|"
                        strTemp &= REA.GetInt32("numero") & "|"
                        If REA.GetString("orden") = intorden Then
                            logorden = True
                            strTemp &= REA.GetString("orden") & "|"
                        Else
                            logorden = False
                            strTemp &= REA.GetString("orden") & "|"
                        End If
                        strTemp &= REA.GetInt32("linea") & "|"
                        strTemp &= REA.GetInt32("ano") & "|"

                        strTemp &= REA.GetInt32("codigo") & "|"
                        strTemp &= REA.GetString("descripcion") & "|"
                        strTemp &= REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "|"
                        strTemp &= REA.GetInt32("cantidad").ToString(FORMATO_MONEDA) & "|"
                        strTemp &= REA.GetString("medida") & "|"
                        strTemp &= "0.00" & "|"

                        strTemp &= REA.GetString("pais") & "|"
                        strTemp &= REA.GetString("fabricante") & "|"
                        strTemp &= REA.GetInt32("semana") & "|"
                        strTemp &= REA.GetString("lote") & "|"

                        If REA.GetInt32("clase") = intclase Then
                            logclase = True
                            strTemp &= REA.GetInt32("clase") & "|"
                        Else
                            logclase = False
                            strTemp &= REA.GetInt32("clase") & "|"
                        End If
                        strTemp &= REA.GetInt32("unidad")


                        a = REA.GetInt32("activo")
                        clas = logclase
                        orden = logorden
                        f = REA.GetString("fabricante")
                        d = "0.0"

                        AgregarFila(dgLista, strTemp, a, clas, orden, f, d)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Pocedimiento propio de Requisiciones para agregar listado de Descargos y colores de acuerdo al estado de cada fila
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strTemp As String, ByVal activo As Integer, ByVal logclase As Boolean, ByVal logorden As Boolean, ByVal fabricante As String, ByVal descargo As Double)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim dblCantidad As Double, dblDes As Double, dblTemp As Double
        Dim strRef As String

        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strTemp.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If activo = vbEmpty Then
                    If i = 2 Then
                        Celda.Style.BackColor = Color.Red
                        Celda.Style.ForeColor = Color.White
                    End If
                Else
                    If i = 2 Then
                        Celda.Style.BackColor = Color.SkyBlue
                        Celda.Style.ForeColor = Color.White
                    End If
                End If


                If logorden Or logclase Then
                    If logorden And logclase Then
                        If i = 3 Then
                            Celda.Style.BackColor = Color.Blue
                            Celda.Style.ForeColor = Color.White
                        End If
                    ElseIf logorden Then
                        If i = 3 Then
                            Celda.Style.BackColor = Color.Yellow
                        End If
                    Else
                        If i = 3 Then
                            Celda.Style.BackColor = Color.Orange
                        End If
                    End If
                End If

                If fabricante = vbNullString Then
                    If i = 3 Then
                        Celda.Style.BackColor = Color.LightGray
                    End If
                End If

                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procemiento para Cargar dgLista 
    Private Sub CargaPanelInfo()
        Dim strTemp As String = STR_VACIO

        Try
            If dgLista.CurrentRow Is Nothing Then
                Exit Sub

            Else
                strTemp = vbNewLine
                strTemp = Space(2) & "YARN:" & Space(2) & dgLista.CurrentRow.Cells("colDescripcion").Value & vbNewLine
                strTemp &= Space(2) & "ORIGIN:" & Space(2) & dgLista.CurrentRow.Cells("colPais").Value & "/" & Space(1) & dgLista.CurrentRow.Cells("colFabricante").Value & vbNewLine

                celdaInfoProducto.Text = strTemp
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlInfoProducto(ByVal codInventario As Integer)
        Dim strSQL As String

        strSQL = "  SELECT i.inv_numero,i.inv_artcodigo, a.art_DLarga,i.inv_provcod,p.pro_proveedor, c.cat_clave Origen "
        strSQL &= "     FROM Inventarios i"
        strSQL &= "         LEFT JOIN Articulos a ON a.art_codigo = i.inv_artcodigo"
        strSQL &= "              LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp and p.pro_codigo = i.inv_provcod"
        strSQL &= "              LEFT JOIN Catalogos c ON c.cat_num = i.inv_lugarfab and cat_clase = 'paises'"
        strSQL &= "          WHERE i.inv_sisemp = {empresa} AND i.inv_numero = {codInv}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codInv}", codInventario)

        Return strSQL
    End Function
    Public Function SqlInfoProduccion(Optional exactProduction As Boolean = False, Optional fechaCajas As String = Nothing)
        Dim strSQL As String
        strSQL = " SELECT l1.Fecha,l1.Anio, l1.Numero , l1.Descripcion , l1.Codigo , l1.Medida , ROUND((l1.Saldo),2) Saldo {esDesperdicio}, l1.PO, /*ROUND(((l1.Total / l1.Cantidad) /* + l1.MO + l1.GF +l1.Waste ),5)*/ IFNULL(Precio_Kardex,0) Precio,l1.MO,l1.GF,l1.Waste, l1.Factores_, l1.Cantidad CantidadNecesaria, l1.TipoCambio TipoCambio, l1.codMedida  "
        strSQL &= "     FROM ( "
        'strSQL &= " SELECT h.HDoc_Doc_Fec Fecha,h.HDoc_Doc_Ano Anio,h.HDoc_Doc_Num Numero,h.HDoc_DR1_Num Descripcion ,d.DDoc_Prd_Cod Codigo,ROUND(SUM(d.DDoc_Prd_Net * d.DDoc_Prd_QTY),2) Total,h.HDoc_RF2_Dbl Precio,c.cat_clave Medida,o.cat_sist Po,
        '    SUM(d.DDoc_Prd_QTY) Cantidad, COALESCE(("
        'strSQL &= " SELECT SUM(p.PDoc_QTY_Ord) "
        'strSQL &= "     FROM Dcmtos_DTL_Pro p "

        ''' se agrega el join para que las cantidades sean restadas según la fecha del ingreso.
        'strSQL &= "     JOIN Dcmtos_HDR hdr ON p.PDoc_Sis_Emp = hdr.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = hdr.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = hdr.HDoc_Doc_Ano 
        '           AND p.PDoc_Chi_Num = hdr.HDoc_Doc_Num AND p.PDoc_Chi_Cat = 47"

        'strSQL &= "     WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Par_Cat = h.HDoc_Doc_Cat AND p.PDoc_Par_Ano = h.HDoc_Doc_Ano 
        '           AND p.PDoc_Par_Num = h.HDoc_Doc_Num AND p.PDoc_Chi_Cat = 47 AND hdr.HDoc_Doc_Fec<='{fecha}'),0) Saldo,	 "




        strSQL &= "SELECT
	                 h.HDoc_Doc_Fec Fecha,h.HDoc_Doc_Ano Anio,h.HDoc_Doc_Num Numero,h.HDoc_DR1_Num Descripcion,d.DDoc_Prd_Cod Codigo, 
	                -- ROUND(SUM(d.DDoc_Prd_Net * d.DDoc_Prd_QTY),2) Total,

                    (SELECT k.Kar_Cost_Ext costo_K
                            FROM Kardex k 
                            WHERE k.Kar_Sis_Emp = h.HDoc_Sis_Emp AND k.Kar_Doc_Cat IN(952,47) AND k.Kar_PO_Cat = h.HDoc_Doc_Cat AND k.Kar_PO_Ano = h.HDoc_Doc_Ano AND k.Kar_PO_Num = h.HDoc_Doc_Num AND k.Kar_Opr_Fec <= '{fechaKardex}'
                             ORDER BY k.Kar_TransId DESC 
                            LIMIT 1) Precio_Kardex,

                    COALESCE((
                    SELECT SUM(d1.DDoc_Prd_QTY * d1.DDoc_Prd_NET)
                    FROM Dcmtos_DTL_Pro pro
                    JOIN Dcmtos_HDR hdr ON pro.PDoc_Sis_Emp=hdr.HDoc_Sis_Emp AND pro.PDoc_Par_Cat=hdr.HDoc_Doc_Cat AND pro.PDoc_Par_Ano=hdr.HDoc_Doc_Ano AND pro.PDoc_Par_Num=hdr.HDoc_Doc_Num
                    JOIN Dcmtos_HDR hdr980 ON pro.PDoc_Sis_Emp=hdr980.HDoc_Sis_Emp AND pro.PDoc_Chi_Cat=hdr980.HDoc_Doc_Cat AND pro.PDoc_Chi_Ano=hdr980.HDoc_Doc_Ano AND pro.PDoc_Chi_Num=hdr980.HDoc_Doc_Num
                    LEFT JOIN Dcmtos_DTL d1 ON d1.DDoc_Sis_Emp = pro.PDoc_Sis_Emp AND d1.DDoc_Doc_Cat = pro.PDoc_Chi_Cat AND d1.DDoc_Doc_Ano = pro.PDoc_Chi_Ano AND d1.DDoc_Doc_Num = pro.PDoc_Chi_Num AND d1.DDoc_Doc_Lin = pro.PDoc_Chi_Lin
                    WHERE pro.PDoc_Sis_Emp = {empresa} AND pro.PDoc_Par_Cat=952 AND pro.PDoc_Chi_Cat=980 AND pro.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND pro.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND pro.PDoc_Chi_Num = d.DDoc_Doc_Num AND hdr.HDoc_Doc_Fec <= '{fecha}'
                    GROUP BY pro.PDoc_Chi_Cat,pro.PDoc_Chi_Ano,pro.PDoc_Chi_Num
		),0) Total,
	                h.HDoc_RF2_Dbl Precio,c.cat_clave Medida,o.cat_sist Po, 
	                COALESCE((
		                SELECT  SUM(d1.DDoc_Prd_QTY) 
		                FROM Dcmtos_DTL_Pro pro
		                JOIN Dcmtos_HDR hdr ON pro.PDoc_Sis_Emp=hdr.HDoc_Sis_Emp AND pro.PDoc_Par_Cat=hdr.HDoc_Doc_Cat AND pro.PDoc_Par_Ano=hdr.HDoc_Doc_Ano AND pro.PDoc_Par_Num=hdr.HDoc_Doc_Num
		                JOIN Dcmtos_HDR hdr980 ON pro.PDoc_Sis_Emp=hdr980.HDoc_Sis_Emp AND pro.PDoc_Chi_Cat=hdr980.HDoc_Doc_Cat AND pro.PDoc_Chi_Ano=hdr980.HDoc_Doc_Ano AND pro.PDoc_Chi_Num=hdr980.HDoc_Doc_Num
		                LEFT JOIN Dcmtos_DTL d1 ON d1.DDoc_Sis_Emp = pro.PDoc_Sis_Emp AND d1.DDoc_Doc_Cat = pro.PDoc_Chi_Cat AND d1.DDoc_Doc_Ano = pro.PDoc_Chi_Ano AND d1.DDoc_Doc_Num = pro.PDoc_Chi_Num AND d1.DDoc_Doc_Lin = pro.PDoc_Chi_Lin
		                WHERE pro.PDoc_Sis_Emp = {empresa} AND pro.PDoc_Par_Cat=952 AND pro.PDoc_Chi_Cat=980  
							AND pro.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND pro.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND pro.PDoc_Chi_Num = d.DDoc_Doc_Num
							AND hdr.HDoc_Doc_Fec <= '{fecha}'
		                 -- GROUP BY hdr.HDoc_Doc_Cat, hdr.HDoc_Doc_Ano, pro.PDoc_Chi_Num
		                GROUP BY pro.PDoc_Chi_Cat,pro.PDoc_Chi_Ano,pro.PDoc_Chi_Num
		                ),0) + if(h.HDoc_DR1_Num = 'PO - MEZCLAS', (SELECT IFNULL(SUM(d.DDoc_Prd_QTY),0) qty
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_DR1_Cat = 6 AND h.HDoc_DR2_Cat = 1),0) Cantidad , 
	                COALESCE((
		                SELECT   SUM(pro.PDoc_QTY_Pro) 
		                FROM Dcmtos_DTL_Pro pro
		                JOIN Dcmtos_HDR hdr ON pro.PDoc_Sis_Emp=hdr.HDoc_Sis_Emp AND pro.PDoc_Par_Cat=hdr.HDoc_Doc_Cat AND pro.PDoc_Par_Ano=hdr.HDoc_Doc_Ano AND pro.PDoc_Par_Num=hdr.HDoc_Doc_Num
		                JOIN Dcmtos_HDR hdr47 ON pro.PDoc_Sis_Emp=hdr47.HDoc_Sis_Emp AND pro.PDoc_Chi_Cat=hdr47.HDoc_Doc_Cat AND pro.PDoc_Chi_Ano=hdr47.HDoc_Doc_Ano AND pro.PDoc_Chi_Num=hdr47.HDoc_Doc_Num {tipoIngreso_}
		                WHERE pro.PDoc_Sis_Emp ={empresa} AND pro.PDoc_Par_Cat=980 AND pro.PDoc_Chi_Cat =47  
							AND pro.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND pro.PDoc_Par_Ano = d.DDoc_Doc_Ano AND pro.PDoc_Par_Num = d.DDoc_Doc_Num
							AND hdr47.HDoc_Doc_Fec <= '{fecha}'
		                GROUP BY pro.PDoc_Sis_Emp, pro.PDoc_Par_Cat,pro.PDoc_Par_Ano,pro.PDoc_Par_Num
                --		 GROUP BY hdr.HDoc_Doc_Cat, hdr.HDoc_Doc_Ano, hdr.HDoc_Doc_Num
			                ),0) saldo, 
	                 "

        strSQL &= "    {varMO} MO ,"
        strSQL &= "    {varGF} GF , {varWaste} Waste, {factores} Factores_, h.HDoc_Doc_TC TipoCambio , d.DDoc_Prd_UM codMedida"
        strSQL &= "             	FROM Dcmtos_HDR h 
                           	LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                           	LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' 
                                   LEFT JOIN Catalogos o ON o.cat_clase = 'PorcentajeP' AND o.cat_sisemp = {empresa}
                           WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 980 {numPO} AND h.HDoc_Doc_Fec <= '{fecha}' AND d.DDoc_Sis_Emp IS NOT NULL  
                       GROUP BY h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num)l1 "

        If (Desperdicio And Sesion.idGiro = 2) Or (Invisible And Sesion.idGiro = 2) Then
            strSQL = Replace(strSQL, "{varGF}", "0")
            strSQL = Replace(strSQL, "{varMO}", "0")
            strSQL = Replace(strSQL, "{varWaste}", "0")
            strSQL = Replace(strSQL, "{factores}", "0")
        ElseIf (Proceso And Sesion.idGiro = 2) Then
            strSQL = Replace(strSQL, "{varGF}", "IFNULL(( 
                            Select ((g.Promedio + g.Total1 + g.Total2) * .5) Total 
                                From Gastos_Produccion g 
                                    Left Join Catalogos c ON c.cat_num = g.idMoneda And c.cat_clase = 'Monedas'
                            Left Join Catalogos gp ON gp.cat_num = g.Gasto And gp.cat_clase = 'GastoP' 
                            WHERE g.idEmpresa = {empresa} And gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= '{fecha}' 
                                                ORDER BY g.Fecha DESC 
                                            LIMIT 1), 0)")
            strSQL = Replace(strSQL, "{varMO}", "IFNULL(( 
                                 SELECT ((g.Promedio + g.Total1 + g.Total2) * .5) Total 
                                     FROM Gastos_Produccion g 
                                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' 
                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' 
                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= '{fecha}' 
                             ORDER BY g.Fecha DESC 
                         LIMIT 1), 0)")

            strSQL = Replace(strSQL, "{varWaste}", "IFNULL(( 
                                 SELECT ((g.Promedio + g.Total1 + g.Total2) * .5) Total 
                                     FROM Gastos_Produccion g 
                                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' 
                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' 
                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Waste & invisible' AND g.Fecha <= '{fecha}' 
                             ORDER BY g.Fecha DESC 
                         LIMIT 1), 0)")
            strSQL = Replace(strSQL, "{factores}", "IFNULL(( 
                            SELECT  (SUM(g.Promedio + g.Total1 + g.Total2) * .5) Total
                            FROM Gastos_Produccion g
                            LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                            WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Factor' AND gp.cat_pid = 1 AND g.Fecha =(SELECT MAX(Fecha) FROM Gastos_Produccion WHERE Fecha <= '{fecha}' )
                            ORDER BY g.Fecha DESC   
                          ), 0)")
        Else
            strSQL = Replace(strSQL, "{varGF}", "IFNULL(( 
                            Select (g.Promedio + g.Total1 + g.Total2) Total 
                                From Gastos_Produccion g 
                                    Left Join Catalogos c ON c.cat_num = g.idMoneda And c.cat_clase = 'Monedas'
                            Left Join Catalogos gp ON gp.cat_num = g.Gasto And gp.cat_clase = 'GastoP' 
                            WHERE g.idEmpresa = {empresa} And gp.cat_desc = 'Gastos de fabricación' AND g.Fecha <= '{fecha}' 
                                                ORDER BY g.Fecha DESC 
                                            LIMIT 1), 0)")
            strSQL = Replace(strSQL, "{varMO}", "IFNULL(( 
                                 SELECT (g.Promedio + g.Total1 + g.Total2) Total 
                                     FROM Gastos_Produccion g 
                                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' 
                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' 
                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Mano de Obra' AND g.Fecha <= '{fecha}' 
                             ORDER BY g.Fecha DESC 
                         LIMIT 1), 0)")

            strSQL = Replace(strSQL, "{varWaste}", "IFNULL(( 
                                 SELECT (g.Promedio + g.Total1 + g.Total2) Total 
                                     FROM Gastos_Produccion g 
                                         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' 
                                     LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' 
                                 WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Waste & invisible' AND g.Fecha <= '{fecha}' 
                             ORDER BY g.Fecha DESC 
                         LIMIT 1), 0)")
            strSQL = Replace(strSQL, "{factores}", "IFNULL(( 
                            SELECT  (SUM(g.Promedio + g.Total1 + g.Total2)) Total
                            FROM Gastos_Produccion g
                            LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                            WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Factor' AND gp.cat_pid = 1 AND g.Fecha =(SELECT MAX(Fecha) FROM Gastos_Produccion WHERE Fecha <= '{fecha}' )
                            ORDER BY g.Fecha DESC   
                          ), 0)")
        End If
        If Desperdicio Or Invisible Or Proceso Then
            strSQL &= "WHERE (l1.Cantidad-ROUND((l1.Saldo),2))>0.01 "
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Then
                strSQL = Replace(strSQL, "{esDesperdicio}", ", (l1.Cantidad * ((100)/100)) Cantidad")
            Else
                strSQL = Replace(strSQL, "{esDesperdicio}", ", (l1.Cantidad * ((100-l1.PO)/100)) Cantidad")
            End If
        Else
            strSQL &= "WHERE ((l1.Cantidad * (l1.PO/100))-ROUND((l1.Saldo),2))>0.01"
            strSQL = Replace(strSQL, "{esDesperdicio}", ", (l1.Cantidad * (l1.PO/100)) Cantidad")
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        'strSQL = Replace(strSQL, "{fecha}", dtFecha.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechaKardex}", Now().ToString(FORMATO_MYSQL))


        If exactProduction = False Then
            strSQL = Replace(strSQL, "{fecha}", dtFecha.ToString(FORMATO_MYSQL))
        Else
            strSQL = Replace(strSQL, "{fecha}", fechaCajas)
        End If

        'Muestra descargos según el tipo de ingreso ' Comentado el 12-10-22
        'If Sesion.IdEmpresa = 18 Then
        '    If Codigo = 2 Then
        '        strSQL = Replace(strSQL, "{tipoIngreso_}", " AND hdr47.HDoc_DR1_Cat  = 2 ")
        '    Else
        '        strSQL = Replace(strSQL, "{tipoIngreso_}", " AND hdr47.HDoc_DR1_Cat IN(4,5)")
        '        'strSQL = Replace(strSQL, "{tipoIngreso_}", STR_VACIO)
        '    End If
        'Else
        strSQL = Replace(strSQL, "{tipoIngreso_}", STR_VACIO)
        'End If

        'If Sesion.IdEmpresa = 15 And Codigo = 2 Then ' si es ingreso de producto terminado, hace el proceso para filtar las PO según el código de inventario
        '    If codInventario = 9 And (InStr(Orden, "Regen", CompareMethod.Text) > 0 Or InStr(Orden, "Indigo", CompareMethod.Text) > 0) Then
        '        strSQL = Replace(strSQL, "{numPO}", " AND h.HDoc_Doc_Num = 4 ")
        '    ElseIf codInventario = 9 And InStr(Orden, "Supima", CompareMethod.Text) > 0 Then
        '        strSQL = Replace(strSQL, "{numPO}", " AND h.HDoc_Doc_Num = 2 ")
        '    ElseIf codInventario = 9 Then
        '        strSQL = Replace(strSQL, "{numPO}", " AND h.HDoc_Doc_Num = 1 ")
        '    Else
        '        strSQL = Replace(strSQL, "{numPO}", " AND h.HDoc_Doc_Num = 3 ")
        '    End If
        'Else
        
        If exactProduction = False Then
            strSQL = Replace(strSQL, "{numPO}", STR_VACIO)
        End If
        Return strSQL
    End Function


    Private Function sqlSaldoIngreso()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Fec Fecha, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_DR1_Num Descripcion,d.DDoc_Prd_Cod Codigo, c.cat_clave Medida, (d.DDoc_Prd_QTY - SUM(IFNULL(p.PDoc_QTY_Pro,0))) Saldo, d.DDoc_Prd_NET Precio, IFNULL((
                    SELECT (SUM(g.Promedio + g.Total1 + g.Total2)) Total
                    FROM Gastos_Produccion g
                    LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP'
                    WHERE g.idEmpresa = {empresa} AND gp.cat_desc = 'Factor' AND gp.cat_pid = {pid} AND g.Fecha =(
                    SELECT MAX(Fecha)
                    FROM Gastos_Produccion 
                    WHERE Fecha <= '{fecha}')
                    ORDER BY g.Fecha DESC 
                    ), 0) Factores_, h.HDoc_Doc_TC tipoCambio, 0 MO, 0 GF, 0 Waste, 100 PO, h.HDoc_RF2_Txt fabric, h.HDoc_DR1_Num Lote, h.HDoc_DR2_Num Tenido
                    FROM Dcmtos_HDR  h
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin
                    LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Fec <= '{fecha}' AND h.HDoc_DR1_Cat IN({Tingreso})
                    GROUP BY h.HDoc_Doc_Ano,h.HDoc_Doc_Num, d.DDoc_Doc_Lin
                    HAVING saldo > 0 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fecha}", dtFecha.ToString(FORMATO_MYSQL))

        If intTipoIng = 14 Then
            strSQL = Replace(strSQL, "{Tingreso}", "2") ' Dyeing -- Dyeing descarga de Greige (2)
            strSQL = Replace(strSQL, "{pid}", 2)
        ElseIf intTipoIng = 15 Then
            strSQL = Replace(strSQL, "{Tingreso}", "14") ' finishing -- Finishing descarga de Dyeing
            strSQL = Replace(strSQL, "{pid}", 3)
        ElseIf intTipoIng = 16 Or intTipoWaste = 1 Or intTipoInvisible = 1 Then
            strSQL = Replace(strSQL, "{Tingreso}", "15") '  rolling -- rolling descarga de finishing
            strSQL = Replace(strSQL, "{pid}", 4)
        ElseIf intTipoIng = 17 Or intTipoWaste = 2 Or intTipoInvisible = 2 Then
            strSQL = Replace(strSQL, "{Tingreso}", "15, 16") ' finish good - finish good descarga de Finishing y/o de rolling
            strSQL = Replace(strSQL, "{pid}", 5)
        End If

        Return strSQL
    End Function

    'Procedimiento para Cargar dgLista Primer Panel
    Public Sub queryInfoProducto()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim int_InvNum As Integer = 0

        Try
            strSQL = sqlInfoProducto(intcodInventario)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader


            Do While REA.Read

                strTemp = vbNullString
                strTemp = Space(2) & intcantidad.ToString(FORMATO_MONEDA) & Space(1) & intmedida & " * " & intprecio.ToString(FORMATO_MONEDA) & vbNewLine
                strTemp &= Space(2) & REA.GetString("art_DLarga") & vbNewLine
                strTemp &= Space(2) & "ORIGIN: " & REA.GetString("Origen") & vbNewLine
                strTemp &= Space(2) & "COD:" & Space(2) & REA.GetInt32("inv_numero") & " / " & " Linea # " & intlinea & vbNewLine
                strTemp &= Space(2) & REA.GetString("pro_proveedor") & vbNewLine
                int_InvNum = REA.GetInt32("inv_numero")
                strOrigenProd = REA.GetString("Origen")
                strNombProv = REA.GetString("pro_proveedor")
            Loop

            strSQL = STR_VACIO
            COM.Dispose()
            REA.Close()

            strSQL = " SELECT i.inv_artcodigo
                        FROM Inventarios i
                        WHERE i.inv_sisemp = " & Sesion.IdEmpresa & " AND inv_numero = " & int_InvNum
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intcodigo = COM.ExecuteScalar

            celdaInfoGeneral.Text = strTemp



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub QueryInfoProcuccion()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim int_InvNum As Integer = 0
        Dim dblSaldo As Double
        Try
            If intTipoIng >= 14 Or intTipoWaste = 1 Or intTipoWaste = 2 Or intTipoInvisible = 1 Or intTipoInvisible = 2 Then ' intTipoWaste = 1 es Waste de Finishing a Rolling, intTipoWaste = 2 es waste de rolling a finish good / lo mismo con el Invisible
                strSQL = sqlSaldoIngreso()
            Else
                strSQL = SqlInfoProduccion() ' intTipoWaste = 0 debe de caer a esta opción y es waste de Knitting a Greige
            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If intTipoIng >= 14 Or (Sesion.IdEmpresa = 22 And intTipoIng = 4) Or (Sesion.IdEmpresa = 22 And intTipoIng = 5) Then
                        dblSaldo = REA.GetDouble("Saldo")
                        dgLista.Columns("colFabricForm").Visible = True
                        dgLista.Columns("colLoteProd").Visible = True
                        dgLista.Columns("colTenido").Visible = True
                    Else
                        dblSaldo = (REA.GetDouble("Cantidad") * REA.GetString("PO") / 100)
                        dgLista.Columns("colFabricForm").Visible = False
                        dgLista.Columns("colLoteProd").Visible = False
                        dgLista.Columns("colTenido").Visible = False
                    End If

                    strTemp = REA.GetDateTime("Fecha") & "|"
                    strTemp &= REA.GetInt32("Numero") & "|"

                    'Numero de Orden en vez de la referencia
                    strTemp &= REA.GetString("Descripcion") & "|"

                    strTemp &= INT_UNO & "|"
                    strTemp &= REA.GetInt32("Anio") & "|"

                    strTemp &= REA.GetInt32("Codigo") & "|"
                    strTemp &= REA.GetString("Descripcion") & "|"
                    strTemp &= REA.GetDouble("Precio") & "|"
                    'If Desperdicio Or Invisible Or Proceso Then
                    If intTipoIng >= 14 Or (Sesion.IdEmpresa = 22 And intTipoIng = 4) Or (Sesion.IdEmpresa = 22 And intTipoIng = 5) Then
                        strTemp &= REA.GetDouble("Saldo") & "|"
                    ElseIf Desperdicio Or Invisible Or Proceso Then
                        strTemp &= (REA.GetDouble("CantidadNecesaria") - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    Else
                        strTemp &= (REA.GetDouble("Cantidad") - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    End If

                    '  comentado el 12-10-22 
                    'strTemp &= dblSaldo.ToString(FORMATO_MONEDA) & "|"6
                    'If Desperdicio Or Invisible Then
                    '    strTemp &= (REA.GetDouble("Cantidad") - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    'Else

                    'If Sesion.IdEmpresa = 18 Then 
                    '    strTemp &= (REA.GetDouble("Cantidad") - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    'Else
                    'strTemp &= (REA.GetDouble("CantidadNecesaria") - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    'End If
                    'End If
                    strTemp &= REA.GetString("Medida") & "|"
                    If intcantidad > vbEmpty Then
                        If intaño = REA.GetInt32("Anio") And intnumero = REA.GetInt32("Numero") Then
                            strTemp &= intcantidad.ToString(FORMATO_MONEDA) & "|"
                        Else
                            strTemp &= INT_CERO & "|"
                        End If
                    Else
                        strTemp &= INT_CERO & "|"
                    End If
                    If intTipoIng = 14 Then
                        strTemp &= (REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    Else
                        strTemp &= (dblSaldo - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA) & "|"
                    End If

                    strTemp &= STR_VACIO & "|"
                    strTemp &= STR_VACIO & "|"
                    strTemp &= STR_VACIO & "|"
                    strTemp &= STR_VACIO & "|"
                    strTemp &= STR_VACIO & "|"
                    strTemp &= STR_VACIO & "|"
                    strTemp &= STR_VACIO & "|"
                    strTemp &= (REA.GetDouble("tipoCambio")).ToString("#,##0.00##") & "|"
                    strTemp &= (REA.GetDouble("MO") + REA.GetDouble("GF") + REA.GetDouble("Waste") + REA.GetDouble("Factores_")) & "|"
                    If Sesion.IdEmpresa = 22 And intTipoIng = 2 Or intTipoIng >= 14 Then
                        strTemp &= REA.GetString("fabric") & "|"
                        strTemp &= REA.GetString("Lote") & "|"
                        strTemp &= REA.GetString("Tenido")
                    Else
                        strTemp &= vbNullString
                    End If
                    cFunciones.AgregarFila(dgLista, strTemp)
                    '  int_InvNum = REA.GetInt32("inv_numero")
                    ' strOrigenProd = REA.GetString("Origen")  
                    ' strNombProv = REA.GetString("pro_proveedor")
                Loop
            End If
            If Codigo = 6 Then
                Me.dgLista.Columns("colPrecio").Visible = True
            Else
                Me.dgLista.Columns("colPrecio").Visible = True
            End If

            strSQL = STR_VACIO
            COM.Dispose()
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean

        Dim i As Integer
        Dim intLineas As Integer
        Dim strProducto As String = vbNullString
        Dim dblTemp As Double
        Dim strActual As String
        Dim strTemp As String
        Dim logErr As Boolean
        Dim logCodigo As Boolean
        Dim strSid As String = STR_VACIO
        Dim logRelacion As Boolean
        Dim strMns As String
        Dim intContador As Integer = 0
        Dim dblPorcentaje As Double = 0
        intLineas = vbEmpty
        'strProducto = intcodigo
        For i = 0 To dgLista.Rows.Count - 1
            'Identificador de la fila (año, número, línea)
            dblTemp = dgLista.Rows(i).Cells("colDescargo").Value
            strActual = dgLista.Rows(i).Cells("colCodigo").Value
            If Sesion.idGiro = 2 Then
                If dblTemp > vbEmpty Then
                    intContador = intContador + 1
                    dgLista.Rows(i).Cells("colPais").Value = dgLista.Rows(i).Cells("colCantidad").Value 'ValidarPorcentaje(dgLista.Rows(i).Cells("colCantidad").Value, dblPorcentaje)
                    If (dblTemp > dgLista.Rows(i).Cells("colPais").Value) And Not logLibre Then
                        'Es mayor que el saldo
                        MsgBox("The amount to be discharged is greater than the balance" & vbCr & vbCr & "Requisition: " & dgLista.Rows(i).Cells("colPais").Value & vbCr & "Discharge: " & vbCr & dblTemp & vbCr & vbCr & "Difference: " & (dgLista.Rows(i).Cells("colPais").Value - dblTemp), vbInformation, "Line #" & (i + 1))
                        'logErr = True
                    ElseIf (intContador >= 2) Then
                        MsgBox("Line" & (i + 1) & ": Can not download  are multiple documents", vbExclamation, "Notice")
                        logErr = True
                    End If
                End If
                'If dblTemp > dgLista.Rows(i).Cells("colPais").Value Then
                '    MsgBox("can not be discharged more than " & dblPorcentaje & "%" & vbCr & vbCr & "Requisition:  " & dgLista.Rows(i).Cells("colPais").Value & vbCr & "Discharge: " & vbCr & dblTemp & vbCr & vbCr, vbInformation, "Line #" & (i + 1))
                '    logErr = True
                'End If
            Else
                If dblTemp > vbEmpty Then
                    If Not dgLista.Rows(i).Cells("colPais").Value = strOrigenProd Then
                        MsgBox("Verify the Origin")
                        logErr = True
                        Exit Function
                    End If
                    If Not dgLista.Rows(i).Cells("colClase").Value = intcodigo Then
                        MsgBox("Check the Description")
                        logErr = True
                        Exit Function
                    End If
                    If Not dgLista.Rows(i).Cells("colFabricante").Value = strNombProv Then
                        MsgBox("Verify Manufacturer")
                        logErr = True
                        Exit Function
                    End If

                    strTemp = dgLista.Rows(i).Cells("colAno").Value & dgLista.Rows(i).Cells("colNumero").Value & dgLista.Rows(i).Cells("colLinea").Value
                    If logorden And intcantidad > vbEmpty Then
                        'Verifica que sean las mismas cantidades
                        If Not (dblTemp = intcantidad) Then
                            If MsgBox("The quantity shipped differs from the quantity " & vbCr & vbCr & "Requisition:" & vbTab & dgLista.Rows(i).Cells("colCantidad").Value & vbCr & "Discharge: " & vbTab & dblTemp & vbCr & vbCr & "Difference: " & vbTab & dgLista.Rows(i).Cells("colCantidad").Value - dblTemp & vbCr & vbCr & "¿Replace shipping confirmation amount?", vbQuestion + vbYesNo, "Confirm") = vbNo Then
                                logErr = True
                            End If
                        End If
                    End If
                    'VALIDACION DE PRECIO SEGUI ICOTERM
                    If Not logErr Then
                        If Not dgLista.Rows(i).Cells("colPrecio").Value = celdaPrecio.Text Then
                            MsgBox("Please check de Price " & vbCr & vbCr & "Requisition:" & vbTab & dgLista.Rows(i).Cells("colPrecio").Value & vbCr & "Discharge: " & vbTab & celdaPrecio.Text)
                            logErr = True

                        End If
                    End If


                    If Not logErr Then
                        If (dblTemp > dgLista.Rows(i).Cells("colCantidad").Value) And Not logLibre Then
                            'Es mayor que el saldo
                            If logorden Then
                                MsgBox("The amount to be discharged is greater than the balance" & vbCr & vbCr & "Requisition: " & dgLista.Rows(i).Cells("colCantidad").Value & vbCr & "Discharge: " & vbCr & dblTemp & vbCr & vbCr & "Difference: " & (dgLista.Rows(i).Cells("colCantidad").Value - dblTemp), vbInformation, "Line #" & (i + 1))
                            Else
                                MsgBox("Line" & (i + 1) & ": The release can not be greater than the quantity available", vbExclamation, "Notice")
                            End If

                            If Not (logorden) Then
                                logErr = True
                            End If
                        ElseIf (strSid = vbNullString) Then
                            strSid = strTemp
                        ElseIf Not (strSid = strTemp) And logUnico Then
                            MsgBox("Line " & (i + 1) & ": Can not relate a line are multiple documents", vbExclamation, "Notice")
                            logErr = True
                        ElseIf Not (strSid = strTemp) And Not (logRelacion) Then
                            strMns = IIf(logorden, "Relate a confirmation line with more than one import line?", "Link a line item to more than one line  of contract")
                            If MsgBox(strMns, vbExclamation + vbYesNo + vbDefaultButton2, "Confirmar") = vbNo Then
                                logErr = True
                            Else
                                logRelacion = True
                            End If
                        End If
                    End If

                    If Not logErr Then
                        If (dblTemp > Val(dgLista.Rows(i).Cells("colCantidad").Value)) And (intcantidad > dblTemp) Then
                            If MsgBox("You are trying to apply more than the amount available" & vbCr & vbCr & "Contract: " & vbTab & dgLista.Rows(i).Cells("colSaldo").Value & vbTab & "Joined: " & vbTab & dblTemp & vbCr & vbCr & "You want to continue anyway?", vbQuestion + vbYesNo, "Confirm") = vbNo Then
                                logErr = True
                            End If
                        End If
                    End If

                    If Not logErr Then
                        If strProducto = vbNullString Then
                            strProducto = strActual
                        ElseIf Not (strActual = strProducto) And logProducto Then
                            MsgBox("Line " & (i + 1) & ": Yo can´t download from different products", vbExclamation, "Notice")
                            logErr = True
                        ElseIf Not (strActual = strProducto) And Not (logCodigo) Then
                            If MsgBox("Is referring to threads of different type" & vbCr & vbCr & "Do you wish continue?", vbExclamation + vbYesNo + vbDefaultButton2, "Confirm") = vbNo Then
                                logErr = True
                            Else
                                logCodigo = True
                            End If
                        End If
                    End If
                End If
                ' Fin del IF
            End If
            If logErr Then
                'Se sale del ciclo
                Exit For
            End If
        Next
        'Devuelve el resultado
        ComprobarDatos = Not (logErr)
    End Function
    'Validacion Produccion
    Private Function ValidarPorcentaje(ByVal dblNumero As Double, ByRef dblPorcentaje As Double) As Double
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim dblSaldo As Double
        Dim strSQL As String

        strSQL = " SELECT c.cat_sist Porcentaje "
        strSQL &= "     FROM Catalogos c  "
        strSQL &= "         WHERE c.cat_clase = 'PorcentajeP' "
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        dblSaldo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        dblPorcentaje = dblSaldo
        dblSaldo = (dblNumero * dblSaldo) / 100
        Return dblSaldo
    End Function
#Region "Eventos"

    Private Sub frmRequisiciones_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        If (e.CloseReason = CloseReason.UserClosing) Then

            e.Cancel = True
        End If

    End Sub

    Private Sub frmFacturasRef_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim Co As New frmConfirmacion
            If (Sesion.idGiro = 2 And logUnico = True) Then

                QueryInfoProcuccion()
            ElseIf Me.Tag = "nuevo" Then
                intinsert = True
                'CargarListaRequicision()
                queryInfoProducto()
            Else
                intinsert = False
                'CargarListaRequicision()
                queryInfoProducto()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgLista_SelectionChanged(sender As Object, e As EventArgs) Handles dgLista.SelectionChanged

        If dgLista.SelectedRows.Count > 0 Then
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then

            Else
                CargaPanelInfo()
            End If
        Else
        End If
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Dim frmConfirmacion As New frmConfirmacion

        logAceptado = False
        frmConfirmacion.Aceptado = logAceptado
        Me.Close()
        Me.Hide()

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Dim dblTemp As Double
        Dim dblSuma As Double
        Dim frmConfirmacion As New frmConfirmacion

        frmConfirmacion.dgDetalle.Rows.Clear()
        Try
            If ComprobarDatos() Then
                logAceptado = True
                frmConfirmacion.Aceptado = logAceptado

                Me.Hide()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region


End Class