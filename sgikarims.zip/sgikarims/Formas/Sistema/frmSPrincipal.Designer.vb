﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSPrincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo1")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo2")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo0", New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2})
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo4")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo5")
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo3", New System.Windows.Forms.TreeNode() {TreeNode4, TreeNode5})
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo7")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo8")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Nodo6", New System.Windows.Forms.TreeNode() {TreeNode7, TreeNode8})
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSPrincipal))
        Me.Estado = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.textoUsuario = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.textoVersion = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.textoEmpresa = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Opciones = New System.Windows.Forms.TreeView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.celdaNombre = New System.Windows.Forms.Label()
        Me.celdaEmpresa = New System.Windows.Forms.Label()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.BarraDeTareas1 = New KARIMs_SGI.BarraDeTareas()
        Me.Estado.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Estado
        '
        Me.Estado.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.Estado.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.textoUsuario, Me.ToolStripStatusLabel3, Me.textoVersion, Me.ToolStripStatusLabel5, Me.textoEmpresa})
        Me.Estado.Location = New System.Drawing.Point(0, 361)
        Me.Estado.Name = "Estado"
        Me.Estado.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.Estado.Size = New System.Drawing.Size(972, 29)
        Me.Estado.TabIndex = 3
        Me.Estado.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(62, 24)
        Me.ToolStripStatusLabel1.Text = "Usuario:"
        '
        'textoUsuario
        '
        Me.textoUsuario.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.textoUsuario.Name = "textoUsuario"
        Me.textoUsuario.Size = New System.Drawing.Size(157, 24)
        Me.textoUsuario.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedInner
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(60, 24)
        Me.ToolStripStatusLabel3.Text = "Versión:"
        '
        'textoVersion
        '
        Me.textoVersion.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Right
        Me.textoVersion.Name = "textoVersion"
        Me.textoVersion.Size = New System.Drawing.Size(157, 24)
        Me.textoVersion.Text = "ToolStripStatusLabel4"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(69, 24)
        Me.ToolStripStatusLabel5.Text = "Empresa:"
        '
        'textoEmpresa
        '
        Me.textoEmpresa.Name = "textoEmpresa"
        Me.textoEmpresa.Size = New System.Drawing.Size(153, 24)
        Me.textoEmpresa.Text = "ToolStripStatusLabel2"
        '
        'Opciones
        '
        Me.Opciones.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Opciones.Location = New System.Drawing.Point(16, 183)
        Me.Opciones.Margin = New System.Windows.Forms.Padding(4)
        Me.Opciones.Name = "Opciones"
        TreeNode1.Name = "Nodo1"
        TreeNode1.Text = "Nodo1"
        TreeNode2.Name = "Nodo2"
        TreeNode2.Text = "Nodo2"
        TreeNode3.Name = "Nodo0"
        TreeNode3.Text = "Nodo0"
        TreeNode4.Name = "Nodo4"
        TreeNode4.Text = "Nodo4"
        TreeNode5.Name = "Nodo5"
        TreeNode5.Text = "Nodo5"
        TreeNode6.Name = "Nodo3"
        TreeNode6.Text = "Nodo3"
        TreeNode7.Name = "Nodo7"
        TreeNode7.Text = "Nodo7"
        TreeNode8.Name = "Nodo8"
        TreeNode8.Text = "Nodo8"
        TreeNode9.Name = "Nodo6"
        TreeNode9.Text = "Nodo6"
        Me.Opciones.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode3, TreeNode6, TreeNode9})
        Me.Opciones.Size = New System.Drawing.Size(245, 173)
        Me.Opciones.TabIndex = 0
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "2")
        Me.ImageList1.Images.SetKeyName(1, "3")
        Me.ImageList1.Images.SetKeyName(2, "8")
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Opciones)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(271, 361)
        Me.Panel1.TabIndex = 10
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.Panel2.Controls.Add(Me.celdaNombre)
        Me.Panel2.Controls.Add(Me.celdaEmpresa)
        Me.Panel2.Controls.Add(Me.CuadroLogo)
        Me.Panel2.Location = New System.Drawing.Point(4, 4)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(259, 172)
        Me.Panel2.TabIndex = 2
        '
        'celdaNombre
        '
        Me.celdaNombre.AutoSize = True
        Me.celdaNombre.Location = New System.Drawing.Point(75, 154)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(55, 17)
        Me.celdaNombre.TabIndex = 3
        Me.celdaNombre.Text = "usuario"
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.AutoSize = True
        Me.celdaEmpresa.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaEmpresa.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaEmpresa.Location = New System.Drawing.Point(71, 132)
        Me.celdaEmpresa.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(64, 24)
        Me.celdaEmpresa.TabIndex = 2
        Me.celdaEmpresa.Text = "karims"
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroLogo.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CuadroLogo.Location = New System.Drawing.Point(12, 4)
        Me.CuadroLogo.Margin = New System.Windows.Forms.Padding(4)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(229, 117)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CuadroLogo.TabIndex = 1
        Me.CuadroLogo.TabStop = False
        '
        'Splitter1
        '
        Me.Splitter1.Location = New System.Drawing.Point(271, 0)
        Me.Splitter1.Margin = New System.Windows.Forms.Padding(4)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(4, 361)
        Me.Splitter1.TabIndex = 11
        Me.Splitter1.TabStop = False
        '
        'BarraDeTareas1
        '
        Me.BarraDeTareas1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.BarraDeTareas1.Location = New System.Drawing.Point(275, 327)
        Me.BarraDeTareas1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraDeTareas1.Name = "BarraDeTareas1"
        Me.BarraDeTareas1.Size = New System.Drawing.Size(697, 34)
        Me.BarraDeTareas1.TabIndex = 13
        '
        'frmSPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(972, 390)
        Me.Controls.Add(Me.BarraDeTareas1)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Estado)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmSPrincipal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FrmSPrincipal"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Estado.ResumeLayout(False)
        Me.Estado.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Estado As System.Windows.Forms.StatusStrip
    Friend WithEvents Opciones As System.Windows.Forms.TreeView
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents textoUsuario As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents textoVersion As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents textoEmpresa As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents BarraDeTareas1 As KARIMs_SGI.BarraDeTareas
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents celdaNombre As System.Windows.Forms.Label
    Friend WithEvents celdaEmpresa As System.Windows.Forms.Label
End Class
