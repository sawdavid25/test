﻿Public Class frmXPresupuesto

#Region "Miembros"
    Dim dblMonto As Double
    Public logDatos As Boolean

#End Region

#Region "Propiedades"
    Public Property Monto As Double
        Get
            Return dblMonto
        End Get
        Set(value As Double)
            dblMonto = value
        End Set
    End Property
#End Region

#Region "Eventos"


    Private Sub EscribeCeldaTotal()
        Dim i As Integer

        Dim dblMontoTotal As Double
        Dim dblMon As Double
        Try
            dblMontoTotal = 0

            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colOperacion").Value <> 2 Then
                    dblMon = CDbl(dgDetalle.Rows(i).Cells("colMonto").Value)
                    dblMontoTotal = dblMontoTotal + dblMon
                End If
            Next

            CeldaTotal.Text = dblMontoTotal.ToString(FORMATO_MONEDA)



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Dim i As Integer

        Dim dblMontoTotal As Double
        Dim dblMon As Double
        Try
            dblMontoTotal = 0

            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colOperacion").Value <> 2 Then
                    dblMon = CDbl(dgDetalle.Rows(i).Cells("colMonto").Value)
                    dblMontoTotal = dblMontoTotal + dblMon
                End If
            Next

            CeldaTotal.Text = dblMontoTotal.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        If dblMontoTotal > dblMonto Then
            MsgBox("El presupuesto asignado es mayor que el monto del documento.", vbInformation, "Aviso")
            Exit Sub
        End If

        With dgDetalle
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If Not (Trim(dgDetalle.Rows(0).Cells("colNombre").Value) = vbNullString) And (Trim(dgDetalle.Rows(0).Cells("colMonto").Value) = vbNullString) Or Val(dgDetalle.Rows(0).Cells("colMonto").Value) = vbNullString Then
                    MsgBox("No se admite monto cero/vacio", vbInformation, "Aviso")
                    Exit Sub
                End If
            Next i
        End With
        Me.Hide()
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strcondicion As String
        strcondicion = " empresa = {empresa} AND tipo IN(1,3)"
        strcondicion = Replace(strcondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            frm.Titulo = "Budget Allocation"
            frm.FiltroText = "Enter the Budget to filter"
            frm.Campos = "id_cuenta ID, nombre_loc Nombre, CAST(tipo AS SIGNED) Tipo"
            frm.Tabla = "contaHilos.cuentas_presupuesto"
            frm.Condicion = strcondicion
            frm.Filtro = " Nombre"
            frm.Ordenamiento = " id_cuenta"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Dim strFila As String = STR_VACIO

                strFila = 0 & "|" & frm.LLave & "|" & frm.Dato & "|" & 0 & "|" & 1

                cFunciones.AgregarFila(dgDetalle, strFila)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.SelectedRows.Count = 0 Then Exit Sub
        Try
            'Dim strFila As String
            If dgDetalle.CurrentRow.Cells(4).Value = 0 Then
                dgDetalle.SelectedCells(4).Value = 2
                CeldaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
                dgDetalle.CurrentRow.Visible = False
            Else
                dgDetalle.Rows.Remove(dgDetalle.CurrentRow)
            End If


        Catch ex As Exception
            'MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub CargarDatos(Optional strSQL As String = "")
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader

        'If dgDetalle.Rows.Count - 1 = vbNullString Then
        '    Exit Sub
        'Else
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgDetalle.Rows.Clear()

            If REA.HasRows Then

                Do While REA.Read
                    Dim strDato As String = STR_VACIO
                    strDato = vbNullString
                    strDato &= REA.GetInt32("transaccion") & "|"
                    strDato &= REA.GetString("cuenta") & "|"
                    strDato &= REA.GetString("nombre") & "|"
                    strDato &= REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|"
                    strDato &= ("0")
                    cFunciones.AgregarFila(dgDetalle, strDato)

                Loop

            End If
            EscribeCeldaTotal()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        EscribeCeldaTotal()
    End Sub

#End Region

End Class