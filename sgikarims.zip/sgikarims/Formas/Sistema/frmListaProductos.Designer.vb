﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListaProductos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.celdaBuscar = New System.Windows.Forms.TextBox()
        Me.etiquetaBuscar = New System.Windows.Forms.Label()
        Me.botonBusca = New System.Windows.Forms.Button()
        Me.checkGenericos = New System.Windows.Forms.CheckBox()
        Me.checkEspecificos = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonSeleccionar = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaVentas = New System.Windows.Forms.TextBox()
        Me.etiquetaVentas = New System.Windows.Forms.Label()
        Me.celdaCompras = New System.Windows.Forms.TextBox()
        Me.etiquetaCompras = New System.Windows.Forms.Label()
        Me.celdaExistencia = New System.Windows.Forms.TextBox()
        Me.etiquetaExistencia = New System.Windows.Forms.Label()
        Me.celdaSemana = New System.Windows.Forms.TextBox()
        Me.etiquetaSemana = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.celdaNumLote = New System.Windows.Forms.TextBox()
        Me.etiquetaNumLote = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.celdaNumParte = New System.Windows.Forms.TextBox()
        Me.etiquetaNumParte = New System.Windows.Forms.Label()
        Me.celdaLugarFabri = New System.Windows.Forms.TextBox()
        Me.etiquetaLugFabricacion = New System.Windows.Forms.Label()
        Me.celdaFabricante = New System.Windows.Forms.TextBox()
        Me.etiquetaFabricante = New System.Windows.Forms.Label()
        Me.celdaEspera = New System.Windows.Forms.TextBox()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colInventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLugaryFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoParte = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNoLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSemana = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExistencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCompras = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDocumento.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'celdaBuscar
        '
        Me.celdaBuscar.Location = New System.Drawing.Point(72, 46)
        Me.celdaBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaBuscar.Multiline = True
        Me.celdaBuscar.Name = "celdaBuscar"
        Me.celdaBuscar.Size = New System.Drawing.Size(345, 34)
        Me.celdaBuscar.TabIndex = 0
        '
        'etiquetaBuscar
        '
        Me.etiquetaBuscar.AutoSize = True
        Me.etiquetaBuscar.Location = New System.Drawing.Point(9, 49)
        Me.etiquetaBuscar.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaBuscar.Name = "etiquetaBuscar"
        Me.etiquetaBuscar.Size = New System.Drawing.Size(53, 17)
        Me.etiquetaBuscar.TabIndex = 1
        Me.etiquetaBuscar.Text = "Search"
        '
        'botonBusca
        '
        Me.botonBusca.Image = Global.KARIMs_SGI.My.Resources.Resources.view_next
        Me.botonBusca.Location = New System.Drawing.Point(427, 46)
        Me.botonBusca.Margin = New System.Windows.Forms.Padding(4)
        Me.botonBusca.Name = "botonBusca"
        Me.botonBusca.Size = New System.Drawing.Size(48, 34)
        Me.botonBusca.TabIndex = 2
        Me.botonBusca.UseVisualStyleBackColor = True
        '
        'checkGenericos
        '
        Me.checkGenericos.AutoSize = True
        Me.checkGenericos.Checked = True
        Me.checkGenericos.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkGenericos.Location = New System.Drawing.Point(529, 54)
        Me.checkGenericos.Margin = New System.Windows.Forms.Padding(4)
        Me.checkGenericos.Name = "checkGenericos"
        Me.checkGenericos.Size = New System.Drawing.Size(80, 21)
        Me.checkGenericos.TabIndex = 3
        Me.checkGenericos.Text = "Generic"
        Me.checkGenericos.UseVisualStyleBackColor = True
        '
        'checkEspecificos
        '
        Me.checkEspecificos.AutoSize = True
        Me.checkEspecificos.Checked = True
        Me.checkEspecificos.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkEspecificos.Location = New System.Drawing.Point(621, 54)
        Me.checkEspecificos.Margin = New System.Windows.Forms.Padding(4)
        Me.checkEspecificos.Name = "checkEspecificos"
        Me.checkEspecificos.Size = New System.Drawing.Size(79, 21)
        Me.checkEspecificos.TabIndex = 4
        Me.checkEspecificos.Text = "Specific"
        Me.checkEspecificos.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.botonCerrar)
        Me.panelDocumento.Controls.Add(Me.botonSeleccionar)
        Me.panelDocumento.Controls.Add(Me.GroupBox1)
        Me.panelDocumento.Controls.Add(Me.celdaEspera)
        Me.panelDocumento.Controls.Add(Me.panelLista)
        Me.panelDocumento.Controls.Add(Me.celdaBuscar)
        Me.panelDocumento.Controls.Add(Me.checkEspecificos)
        Me.panelDocumento.Controls.Add(Me.etiquetaBuscar)
        Me.panelDocumento.Controls.Add(Me.checkGenericos)
        Me.panelDocumento.Controls.Add(Me.botonBusca)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumento.Location = New System.Drawing.Point(0, 0)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(985, 663)
        Me.panelDocumento.TabIndex = 5
        '
        'botonCerrar
        '
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCerrar.Location = New System.Drawing.Point(880, 599)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(81, 49)
        Me.botonCerrar.TabIndex = 9
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonSeleccionar
        '
        Me.botonSeleccionar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_right_green
        Me.botonSeleccionar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonSeleccionar.Location = New System.Drawing.Point(784, 599)
        Me.botonSeleccionar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonSeleccionar.Name = "botonSeleccionar"
        Me.botonSeleccionar.Size = New System.Drawing.Size(88, 49)
        Me.botonSeleccionar.TabIndex = 8
        Me.botonSeleccionar.Text = "To Select"
        Me.botonSeleccionar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonSeleccionar.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaVentas)
        Me.GroupBox1.Controls.Add(Me.etiquetaVentas)
        Me.GroupBox1.Controls.Add(Me.celdaCompras)
        Me.GroupBox1.Controls.Add(Me.etiquetaCompras)
        Me.GroupBox1.Controls.Add(Me.celdaExistencia)
        Me.GroupBox1.Controls.Add(Me.etiquetaExistencia)
        Me.GroupBox1.Controls.Add(Me.celdaSemana)
        Me.GroupBox1.Controls.Add(Me.etiquetaSemana)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.etiquetaAño)
        Me.GroupBox1.Controls.Add(Me.celdaNumLote)
        Me.GroupBox1.Controls.Add(Me.etiquetaNumLote)
        Me.GroupBox1.Controls.Add(Me.celdaDescripcion)
        Me.GroupBox1.Controls.Add(Me.etiquetaDescripcion)
        Me.GroupBox1.Controls.Add(Me.celdaNumParte)
        Me.GroupBox1.Controls.Add(Me.etiquetaNumParte)
        Me.GroupBox1.Controls.Add(Me.celdaLugarFabri)
        Me.GroupBox1.Controls.Add(Me.etiquetaLugFabricacion)
        Me.GroupBox1.Controls.Add(Me.celdaFabricante)
        Me.GroupBox1.Controls.Add(Me.etiquetaFabricante)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 420)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(948, 172)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Item Specifics"
        '
        'celdaVentas
        '
        Me.celdaVentas.Location = New System.Drawing.Point(745, 140)
        Me.celdaVentas.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaVentas.Name = "celdaVentas"
        Me.celdaVentas.Size = New System.Drawing.Size(193, 22)
        Me.celdaVentas.TabIndex = 21
        Me.celdaVentas.Text = "0.00"
        Me.celdaVentas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaVentas
        '
        Me.etiquetaVentas.AutoSize = True
        Me.etiquetaVentas.Location = New System.Drawing.Point(671, 149)
        Me.etiquetaVentas.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaVentas.Name = "etiquetaVentas"
        Me.etiquetaVentas.Size = New System.Drawing.Size(43, 17)
        Me.etiquetaVentas.TabIndex = 20
        Me.etiquetaVentas.Text = "Sales"
        '
        'celdaCompras
        '
        Me.celdaCompras.Location = New System.Drawing.Point(745, 113)
        Me.celdaCompras.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCompras.Name = "celdaCompras"
        Me.celdaCompras.Size = New System.Drawing.Size(193, 22)
        Me.celdaCompras.TabIndex = 19
        Me.celdaCompras.Text = "0.00"
        Me.celdaCompras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaCompras
        '
        Me.etiquetaCompras.AutoSize = True
        Me.etiquetaCompras.Location = New System.Drawing.Point(671, 122)
        Me.etiquetaCompras.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCompras.Name = "etiquetaCompras"
        Me.etiquetaCompras.Size = New System.Drawing.Size(68, 17)
        Me.etiquetaCompras.TabIndex = 18
        Me.etiquetaCompras.Text = "Shopping"
        '
        'celdaExistencia
        '
        Me.celdaExistencia.Location = New System.Drawing.Point(745, 86)
        Me.celdaExistencia.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaExistencia.Name = "celdaExistencia"
        Me.celdaExistencia.Size = New System.Drawing.Size(193, 22)
        Me.celdaExistencia.TabIndex = 17
        Me.celdaExistencia.Text = "0.00"
        Me.celdaExistencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaExistencia
        '
        Me.etiquetaExistencia.AutoSize = True
        Me.etiquetaExistencia.Location = New System.Drawing.Point(671, 90)
        Me.etiquetaExistencia.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaExistencia.Name = "etiquetaExistencia"
        Me.etiquetaExistencia.Size = New System.Drawing.Size(68, 17)
        Me.etiquetaExistencia.TabIndex = 16
        Me.etiquetaExistencia.Text = "Existence"
        '
        'celdaSemana
        '
        Me.celdaSemana.Location = New System.Drawing.Point(745, 57)
        Me.celdaSemana.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSemana.Name = "celdaSemana"
        Me.celdaSemana.Size = New System.Drawing.Size(193, 22)
        Me.celdaSemana.TabIndex = 15
        Me.celdaSemana.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSemana
        '
        Me.etiquetaSemana.AutoSize = True
        Me.etiquetaSemana.Location = New System.Drawing.Point(671, 60)
        Me.etiquetaSemana.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSemana.Name = "etiquetaSemana"
        Me.etiquetaSemana.Size = New System.Drawing.Size(44, 17)
        Me.etiquetaSemana.TabIndex = 14
        Me.etiquetaSemana.Text = "Week"
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(745, 30)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(193, 22)
        Me.celdaAño.TabIndex = 13
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(671, 33)
        Me.etiquetaAño.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAño.TabIndex = 12
        Me.etiquetaAño.Text = "Year"
        '
        'celdaNumLote
        '
        Me.celdaNumLote.Location = New System.Drawing.Point(129, 140)
        Me.celdaNumLote.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNumLote.Name = "celdaNumLote"
        Me.celdaNumLote.Size = New System.Drawing.Size(513, 22)
        Me.celdaNumLote.TabIndex = 11
        '
        'etiquetaNumLote
        '
        Me.etiquetaNumLote.AutoSize = True
        Me.etiquetaNumLote.Location = New System.Drawing.Point(8, 144)
        Me.etiquetaNumLote.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNumLote.Name = "etiquetaNumLote"
        Me.etiquetaNumLote.Size = New System.Drawing.Size(54, 17)
        Me.etiquetaNumLote.TabIndex = 10
        Me.etiquetaNumLote.Text = "Lot No."
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(129, 113)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(513, 22)
        Me.celdaDescripcion.TabIndex = 9
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(8, 117)
        Me.etiquetaDescripcion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 8
        Me.etiquetaDescripcion.Text = "Description"
        '
        'celdaNumParte
        '
        Me.celdaNumParte.Location = New System.Drawing.Point(129, 86)
        Me.celdaNumParte.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNumParte.Name = "celdaNumParte"
        Me.celdaNumParte.Size = New System.Drawing.Size(513, 22)
        Me.celdaNumParte.TabIndex = 7
        '
        'etiquetaNumParte
        '
        Me.etiquetaNumParte.AutoSize = True
        Me.etiquetaNumParte.Location = New System.Drawing.Point(8, 90)
        Me.etiquetaNumParte.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNumParte.Name = "etiquetaNumParte"
        Me.etiquetaNumParte.Size = New System.Drawing.Size(60, 17)
        Me.etiquetaNumParte.TabIndex = 6
        Me.etiquetaNumParte.Text = "Part No."
        '
        'celdaLugarFabri
        '
        Me.celdaLugarFabri.Location = New System.Drawing.Point(129, 57)
        Me.celdaLugarFabri.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLugarFabri.Name = "celdaLugarFabri"
        Me.celdaLugarFabri.Size = New System.Drawing.Size(513, 22)
        Me.celdaLugarFabri.TabIndex = 5
        '
        'etiquetaLugFabricacion
        '
        Me.etiquetaLugFabricacion.AutoSize = True
        Me.etiquetaLugFabricacion.Location = New System.Drawing.Point(8, 60)
        Me.etiquetaLugFabricacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaLugFabricacion.Name = "etiquetaLugFabricacion"
        Me.etiquetaLugFabricacion.Size = New System.Drawing.Size(117, 17)
        Me.etiquetaLugFabricacion.TabIndex = 4
        Me.etiquetaLugFabricacion.Text = "Fabrication Place"
        '
        'celdaFabricante
        '
        Me.celdaFabricante.Location = New System.Drawing.Point(129, 30)
        Me.celdaFabricante.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaFabricante.Name = "celdaFabricante"
        Me.celdaFabricante.Size = New System.Drawing.Size(513, 22)
        Me.celdaFabricante.TabIndex = 3
        '
        'etiquetaFabricante
        '
        Me.etiquetaFabricante.AutoSize = True
        Me.etiquetaFabricante.Location = New System.Drawing.Point(8, 33)
        Me.etiquetaFabricante.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFabricante.Name = "etiquetaFabricante"
        Me.etiquetaFabricante.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaFabricante.TabIndex = 2
        Me.etiquetaFabricante.Text = "Manufacturer"
        '
        'celdaEspera
        '
        Me.celdaEspera.BackColor = System.Drawing.SystemColors.Info
        Me.celdaEspera.Location = New System.Drawing.Point(16, 377)
        Me.celdaEspera.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaEspera.Multiline = True
        Me.celdaEspera.Name = "celdaEspera"
        Me.celdaEspera.ReadOnly = True
        Me.celdaEspera.Size = New System.Drawing.Size(944, 34)
        Me.celdaEspera.TabIndex = 6
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Location = New System.Drawing.Point(16, 106)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(945, 263)
        Me.panelLista.TabIndex = 5
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colInventario, Me.colProducto, Me.colDescripcion, Me.colCosto, Me.colUnidad, Me.colFabricante, Me.colLugaryFecha, Me.colNoParte, Me.colNoLote, Me.colAno, Me.colSemana, Me.colExistencia, Me.colCompras, Me.colVenta})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(945, 263)
        Me.dgLista.TabIndex = 0
        '
        'colInventario
        '
        Me.colInventario.HeaderText = "Inventory"
        Me.colInventario.Name = "colInventario"
        Me.colInventario.ReadOnly = True
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Product"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        '
        'colCosto
        '
        Me.colCosto.HeaderText = "Cost"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unit"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        '
        'colFabricante
        '
        Me.colFabricante.HeaderText = "Manufacturer"
        Me.colFabricante.Name = "colFabricante"
        Me.colFabricante.ReadOnly = True
        '
        'colLugaryFecha
        '
        Me.colLugaryFecha.HeaderText = "Date And Place"
        Me.colLugaryFecha.Name = "colLugaryFecha"
        Me.colLugaryFecha.ReadOnly = True
        '
        'colNoParte
        '
        Me.colNoParte.HeaderText = "Part Number"
        Me.colNoParte.Name = "colNoParte"
        Me.colNoParte.ReadOnly = True
        '
        'colNoLote
        '
        Me.colNoLote.HeaderText = "Lot Number"
        Me.colNoLote.Name = "colNoLote"
        Me.colNoLote.ReadOnly = True
        '
        'colAno
        '
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        '
        'colSemana
        '
        Me.colSemana.HeaderText = "Week"
        Me.colSemana.Name = "colSemana"
        Me.colSemana.ReadOnly = True
        '
        'colExistencia
        '
        Me.colExistencia.HeaderText = "Existence"
        Me.colExistencia.Name = "colExistencia"
        Me.colExistencia.ReadOnly = True
        '
        'colCompras
        '
        Me.colCompras.HeaderText = "Buy"
        Me.colCompras.Name = "colCompras"
        Me.colCompras.ReadOnly = True
        '
        'colVenta
        '
        Me.colVenta.HeaderText = "Sales"
        Me.colVenta.Name = "colVenta"
        Me.colVenta.ReadOnly = True
        '
        'frmListaProductos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(985, 663)
        Me.Controls.Add(Me.panelDocumento)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmListaProductos"
        Me.Text = "List of Products"
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents celdaBuscar As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaBuscar As System.Windows.Forms.Label
    Friend WithEvents botonBusca As System.Windows.Forms.Button
    Friend WithEvents checkGenericos As System.Windows.Forms.CheckBox
    Friend WithEvents checkEspecificos As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonSeleccionar As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaVentas As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaVentas As System.Windows.Forms.Label
    Friend WithEvents celdaCompras As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCompras As System.Windows.Forms.Label
    Friend WithEvents celdaExistencia As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaExistencia As System.Windows.Forms.Label
    Friend WithEvents celdaSemana As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSemana As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents celdaNumLote As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumLote As System.Windows.Forms.Label
    Friend WithEvents celdaDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDescripcion As System.Windows.Forms.Label
    Friend WithEvents celdaNumParte As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumParte As System.Windows.Forms.Label
    Friend WithEvents celdaLugarFabri As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaLugFabricacion As System.Windows.Forms.Label
    Friend WithEvents celdaFabricante As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaFabricante As System.Windows.Forms.Label
    Friend WithEvents celdaEspera As System.Windows.Forms.TextBox
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents colInventario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProducto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFabricante As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLugaryFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNoParte As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNoLote As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSemana As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExistencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCompras As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVenta As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
