﻿Imports System.ComponentModel
Imports System.IO
Public Class frmMigracionNomenclatura

#Region "Miembros"
    Dim strKey As String = STR_VACIO

    'Constantes
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Const CUENTA_ACTUAL = 0
    Const PID_ACTUAL = 1
    Const CUEMTA_NUEVA = 2
    Const PID_NUEVO = 3

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Funciones y Procedimientos "

    Private Sub ActualizarNomenclatura(ByVal cuenta_actual As String, ByVal pid_actual As String, ByVal cuenta_nueva As String, ByVal pid_nueva As String)
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            ' Actualizar id_cuenta 
            strSQL = " UPDATE contapm.cuentas c SET c.id_cuenta = '{cuenta_nueva}'
                        WHERE c.id_cuenta = '{cuenta_actual}' AND c.empresa = {empresa} "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            ' Actualizar pid
            strSQL = " UPDATE contapm.cuentas c SET c.pid = '{pid_nuevo}'
                        WHERE c.pid = '{pid_actual}' AND c.empresa = {empresa} "

            strSQL = strSQL.Replace("{pid_nuevo}", pid_nueva)
            strSQL = strSQL.Replace("{pid_actual}", pid_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub ActualizarTablas(ByVal cuenta_actual As String, ByVal cuenta_nueva As String)
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            ' Actualizar detalle de polizas 
            strSQL = "UPDATE contapm.detalle_polizas d SET d.cuenta ='{cuenta_nueva}' 
                        WHERE d.empresa = {empresa} AND d.cuenta ='{cuenta_actual}' "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            ' Actualizar Clientes 
            strSQL = " UPDATE Clientes  SET cli_cuenta = '{cuenta_nueva}'
                        WHERE cli_sisemp = {empresa} AND cli_cuenta = '{cuenta_actual}' "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            ' Actualizar Proveedores 
            strSQL = " UPDATE Proveedores  SET pro_cuenta = '{cuenta_nueva}'
                        WHERE pro_sisemp = {empresa} AND pro_cuenta = '{cuenta_actual}' "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            ' Actualizar parametros empresa  
            strSQL = " UPDATE contapm.parametros_empresa SET valor = '{cuenta_nueva}'
                        WHERE empresa={empresa} AND valor  = '{cuenta_actual}' "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            ' Actualizar CtasBcos  
            strSQL = " UPDATE CtasBcos SET BCta_Cuenta = '{cuenta_nueva}'
                        WHERE BCta_Sis_Emp = {empresa} AND BCta_Cuenta = '{cuenta_actual}' "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            ' Actualizar saldos  
            strSQL = " UPDATE contapm.saldos SET cuenta = '{cuenta_nueva}'
                        WHERE empresa = {empresa} AND cuenta = '{cuenta_actual}' "

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub ActualizarDetallePolizas(ByVal cuenta_actual As String, ByVal cuenta_nueva As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = ""

            strSQL = strSQL.Replace("{cuenta_nueva}", cuenta_nueva)
            strSQL = strSQL.Replace("{cuenta_actual}", cuenta_actual)
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonArchivo_Click(sender As Object, e As EventArgs) Handles botonArchivo.Click
        Dim openFile As New OpenFileDialog
        Dim directorio As String = STR_VACIO
        Dim docReader As StreamReader
        Dim strLinea As String = STR_VACIO
        Dim ArrayDatos() As String

        Try
            openFile.InitialDirectory = "c:\"
            openFile.Filter = "csv file(*.csv)|*.csv"
            openFile.FilterIndex = 2
            openFile.RestoreDirectory = True

            If openFile.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                directorio = openFile.FileName
                docReader = New StreamReader(directorio)
                Do
                    strLinea = docReader.ReadLine
                    If Not strLinea Is Nothing Then
                        ArrayDatos = Nothing
                        ArrayDatos = strLinea.Split(";".ToCharArray)
                        MsgBox(ArrayDatos(CUENTA_ACTUAL))
                        MsgBox(ArrayDatos(PID_ACTUAL))
                        MsgBox(ArrayDatos(CUEMTA_NUEVA))
                        MsgBox(ArrayDatos(PID_NUEVO))

                    End If
                Loop Until strLinea Is Nothing
                docReader.Close()
                docReader.Dispose()
                docReader = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub


#End Region

End Class