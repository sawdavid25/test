﻿Public Class frmFacturasRef_Aux_

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim intCurDoc As Integer
    Dim cfun As New clsFunciones

    Private intUnidad As Integer
    Private strOrigen As String
    Private intLbs As Integer
    Private intKgs As Integer
    Private dblFactorLbs As Double
    Private dblFactorKgs As Double
    Private dblDescargo As Double
    Private dblExistencia As Double

    Public intaño As Integer
    Public intnumero As Integer
    Public intlinea As Integer
    Public strCodigo As Integer
    Public strCodigoPF As Integer
    Public dblPedido As Double
    Public logGenerico As Double
    Public logAceptar As Double
    Private logFactura As Boolean
    Private logInfo As Boolean
    Private logCatalogo As Boolean
    Dim descargo As Double

    Private strEspecifico As String
    Private strInfo As String
    Private strInformacion As String
    Private strLista As String
    Private strReferencias As String

    Public Const DEF_KGS As String = "KGS"
    Public Const DEF_LBS As String = "LBS"

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


    Public Property Informacion As String
        Get
            Return strInformacion
        End Get
        Set(value As String)
            strInformacion = value
        End Set
    End Property
    Public Property AnioPF As Integer
        Get
            Return strCodigoPF
        End Get
        Set(value As Integer)
            strCodigoPF = value
        End Set
    End Property
    Public Property Codigo As Integer
        Get
            Return strCodigo
        End Get
        Set(value As Integer)
            strCodigo = value
        End Set
    End Property

    Public Property año As Integer
        Get
            Return intaño
        End Get
        Set(value As Integer)
            intAño = value
        End Set
    End Property

    Public Property numero As Integer
        Get
            Return intnumero
        End Get
        Set(value As Integer)
            intNumero = value
        End Set
    End Property

    Public Property linea As Integer
        Get
            Return intlinea
        End Get
        Set(value As Integer)
            intLinea = value
        End Set
    End Property

    Public Property Unidad As Integer
        Get
            Return intUnidad
        End Get
        Set(value As Integer)
            intUnidad = value
        End Set
    End Property

    'Fija el valor pedido
    Public Property Pedido As Double
        Get
            Return dblPedido
        End Get
        Set(value As Double)
            dblPedido = value
        End Set
    End Property

    'Fija el valor de genérico
    Public Property Generico As Double
        Get
            Return logGenerico
        End Get
        Set(value As Double)
            logGenerico = value
        End Set
    End Property

    'Propiedad para comprobar si se han aceptado los cambios
    Public Property Aceptado As Double
        Get
            Return logAceptar
        End Get
        Set(value As Double)
            logAceptar = value
        End Set
    End Property
    'Para actuvar Fcaturación
    Public Property Factura As Double
        Get
            Return logFactura
        End Get
        Set(value As Double)
            logFactura = value
        End Set
    End Property

    'Para conocer que catalogo es 
    Public Property Catalogo As Double
        Get
            Return logCatalogo
        End Get
        Set(value As Double)
            logCatalogo = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Public Sub Iniciar()
        logInfo = True
        If dgLista.Rows.Count > vbEmpty Then
            ' dgLista.RowCount = vbEmpty
        End If

    End Sub

    Private Function SQLlistaDetalle()

        Dim strsql As String = STR_VACIO


        strsql = "SELECT b.HDoc_Doc_Cat Tipo, b.HDoc_Doc_Ano Ano, b.HDoc_Doc_Num Numero, b.HDoc_Doc_Fec Fecha, b.HDoc_DR1_Num Referencia, COALESCE(m.cat_clave,'') Medida, COALESCE(m.cat_num,0) Unidad, a.PDoc_Par_Lin Linea, a.PDoc_Prd_Cod Codigo, a.PDoc_QTY_Ord Disponible, a.PDoc_QTY_Pro Descargo, d.DDoc_Prd_QTY Cantidad, a.PDoc_Chi_Lin ID,"
        strsql &= "  IFNULL(("
        strsql &= "     SELECT a.ADoc_Dta_Chr Poliza"
        strsql &= "       FROM Dcmtos_DTL_Pro p"
        strsql &= "          INNER JOIN Catalogos c ON c.cat_num = p.PDoc_Par_Cat AND c.cat_clase = 'Documentos'"
        strsql &= "             INNER JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp = p.PDoc_Sis_Emp AND a.ADoc_Doc_Cat = p.PDoc_Par_Cat AND a.ADoc_Doc_Ano = p.PDoc_Par_Ano AND a.ADoc_Doc_Num = p.PDoc_Par_Num"
        strsql &= "              WHERE p.PDoc_Sis_Emp =b.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = b.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = b.HDoc_Doc_Ano AND p.PDoc_Chi_Lin= d.DDoc_Doc_Lin   AND p.PDoc_Chi_Num =b.HDoc_Doc_Num AND c.cat_sist = 'Doc_ODesImp' AND a.ADoc_Doc_Lin = '01' ),'-') POLIZA"
        strsql &= "                 FROM Dcmtos_DTL_Pro a"
        strsql &= "                  INNER JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = a.PDoc_Sis_Emp AND b.HDoc_Doc_Cat = a.PDoc_Par_Cat AND b.HDoc_Doc_Ano = a.PDoc_Par_Ano AND b.HDoc_Doc_Num = a.PDoc_Par_Num"
        strsql &= "                 INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = a.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = a.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = a.PDoc_Chi_Ano AND d.DDoc_Doc_Num = a.PDoc_Chi_Num AND d.DDoc_Doc_Lin = a.PDoc_Chi_Lin"
        strsql &= "                LEFT JOIN Catalogos m ON m.cat_clase='Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strsql &= "             WHERE PDoc_Sis_Emp = {empresa} AND PDoc_Par_Cat = 47 AND PDoc_Chi_Cat = 48 AND PDoc_Chi_Ano = {año} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea}"
        strsql &= "          ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"

        'NOTAS: '48/Instrucciones' es child, y '47/Ingreso' es parent

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)
        strsql = Replace(strsql, "{linea}", intlinea)
        Return strsql
    End Function

    Private Function SQLInfoProducto()

        Dim strsql As String = STR_VACIO
        Dim strCodigo As String

        If dgLista.Rows.Count = 0 Then
            Return strsql
            Exit Function
        End If
        strCodigo = dgLista.SelectedCells(6).Value

        strsql = " SELECT COALESCE(a.art_DLarga,'') hilo, COALESCE(p.pro_proveedor,'') fabricante, i.inv_prodlote lote, i.inv_prodsem semana, i.inv_notas nota, COALESCE(c.cat_clave, '') pais, COALESCE(i.inv_prodlote,'N/A') lote"
        strsql &= "     FROM Inventarios i"
        strsql &= "         LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strsql &= "             LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod"
        strsql &= "         LEFT JOIN Catalogos c ON c.cat_clase = 'Paises' AND c.cat_num = i.inv_lugarfab"
        strsql &= " WHERE i.inv_sisemp = {empresa} AND i.inv_numero = {codigo}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{codigo}", strCodigo)

        Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLlistaDetalle()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Ano") & "|" & REA.GetInt32("Numero") & "|" & REA.GetDateTime("Fecha") & "|" & REA.GetString("POLIZA") & "|" & REA.GetString("Referencia") & "|" & REA.GetInt32("Linea") & "|" &
                     REA.GetInt32("Codigo") & "|" & REA.GetDouble("Disponible") & "|" & REA.GetString("Medida") & "|0" & "|" & REA.GetDouble("Descargo") & "|0" & "|0" & "|0" & "|0" & "|0"

                    cFunciones.AgregarFila(dgLista, strFila)


                    'dgDatos.AlternatingRowsDefaultCellStyle.BackColor = Color.AntiqueWhite

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryInfoProducto(Optional ByVal iFila As Integer = NO_FILA)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim strNota As String
        Dim strCodigo As String
        Dim dblReserva As Double
        Dim strTemp2 As String
        Dim strSQL2 As String
        Try
            'For i As Integer 0 to dgLista.Rows.Count -1
            'Si existen Datos
            'If dgLista.Rows.Count > vbEmpty Then
            '    'Si no se especifico la fila

            'End If

            ' For i As Integer = 0 To dgLista.Rows.Count - 1
            If dgLista.Rows.Count > 0 Then
                strCodigo = dgLista.SelectedCells(6).Value

                If Not strCodigo = vbNullString Then
                    'Info de inventario reservado
                    If Not (dgReservacion.Rows.Count = NO_FILA) Then
                        dblReserva = dgLista.SelectedCells(13).Value
                        If (dblReserva > vbEmpty) Then
                            panelReservacion.Visible = True
                            dgReservacion.Visible = True

                            celdaReserva.Text = "Reserva / " & dblReserva.ToString(FORMATO_MONEDA) & Space(2) & dgLista.SelectedCells(8).Value

                            strTemp2 = dgLista.CurrentRow.Cells("colDetalle").Value
                            If strTemp2 = 0 Then
                                'Cargar detalle de reserva

                                strSQL2 = " SELECT * "
                                strSQL2 &= "     FROM Reserva"
                                strSQL2 &= "         WHERE id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={año} AND doc_num={numero} AND doc_lin={linea} AND NOT(estado=2)"

                                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                                strSQL2 = Replace(strSQL2, "{año}", dgLista.SelectedCells(0).Value)
                                strSQL2 = Replace(strSQL2, "{numero}", dgLista.SelectedCells(1).Value)
                                strSQL2 = Replace(strSQL2, "{linea}", dgLista.SelectedCells(5).Value)

                                MyCnn.CONECTAR = strConexion

                                COM = New MySqlCommand(strSQL2, CON)
                                REA = COM.ExecuteReader

                                dgReservacion.Rows.Clear()
                                Do While REA.Read

                                    Dim strFila As String

                                    strFila = REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|"
                                    strFila &= REA.GetString("nombre") & "|"
                                    strFila &= ""

                                    cFunciones.AgregarFila(dgReservacion, strFila)
                                Loop

                            End If
                        Else
                            panelReservacion.Visible = False
                            dgReservacion.Visible = False
                        End If
                    End If
                End If
                'Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Try

            strSQL = SQLInfoProducto()

            If strSQL = STR_VACIO Then
                Exit Sub
            End If
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader


            Do While REA.Read
                If logCatalogo = False Then
                    strTemp = vbNullString
                    strTemp = "Hilo:" & Space(13) & REA.GetString("hilo") & vbNewLine
                    strTemp &= "Fabricante:" & Space(2) & REA.GetString("fabricante") & vbNewLine
                    strTemp &= "Nº de Lote:" & Space(2) & REA.GetString("lote") & vbNewLine
                    strTemp &= "Semana:" & Space(7) & REA.GetInt32("semana") & vbNewLine

                    strNota = vbNullString
                    strNota = "Notas" & vbNewLine & strNota & vbNewLine

                    etiquetaInfo.Text = strTemp & strNota
                Else
                    strTemp = vbNullString
                    strTemp = "Hilo:" & Space(10) & REA.GetString("hilo") & vbNewLine
                    strTemp &= "Origen:" & Space(2) & REA.GetString("pais") & vbNewLine
                    strTemp &= "Lote:" & Space(7) & REA.GetString("lote")

                    etiquetaInfo.Text = strTemp
                End If
            Loop
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Criterio de selección del prod. genérico
    Public Sub Info(ByVal Informacion As String)
        Dim intY As Integer
        strInformacion = Informacion

        If Not (strInformacion = vbNullString) Then
            celdaInfoFinal.Visible = True
            celdaInfoFin.Text = strInformacion

        End If
    End Sub



    Public Sub InicalizacionVariables()
        Dim strSQL2 As String
        Dim strSQL As String
        Dim strSQL3 As String
        Dim strSQL4 As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = SQLInfoProducto()

        MyCnn.CONECTAR = strConexion

        COM = New MySqlCommand(strSQL, CON)

        Try
            'Id de KGS y LBS
            strSQL2 = "SELECT cat_num FROM Catalogos WHERE cat_clase='Medidas' AND cat_clave='KGS'"
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL2, conec)
            intKgs = COM.ExecuteScalar
            conec.Close()

            strSQL3 = "SELECT cat_num FROM Catalogos WHERE cat_clase='Medidas' AND cat_clave='LBS'"
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL3, conec)
            intLbs = COM.ExecuteScalar
            conec.Close()

            'Factor de conversión (división)
            strSQL4 = "SELECT cat_sist FROM Catalogos WHERE cat_clase='Medidas' AND cat_clave='KGS'"
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL4, conec)
            dblFactorKgs = COM.ExecuteScalar
            conec.Close()
            dblFactorLbs = (1 / dblFactorKgs)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarMedidaPF(ByVal codigo As Integer, ByVal ciclo As Integer)
        Dim strSQL As String
        Dim strFila As String
        Dim frmLista As New frmFacturasRef_Aux_
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strMedida As String = STR_VACIO

        strSQL = "  SELECT c.cat_clave Medida "
        strSQL &= "     FROM  Dcmtos_DTL d "
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 75 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", ciclo)
        strSQL = Replace(strSQL, "{numero}", codigo)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                strMedida = REA.GetString("Medida")
            Loop
        End If
        For i As Integer = 0 To dgLista.Rows.Count - 1
            dgLista.Rows(i).Cells("colAño").Value = dgLista.Rows(i).Cells("colAño").Value
            dgLista.Rows(i).Cells("colNumero").Value = dgLista.Rows(i).Cells("colNumero").Value
            dgLista.Rows(i).Cells("colFecha").Value = dgLista.Rows(i).Cells("colFecha").Value
            dgLista.Rows(i).Cells("colPoliza").Value = dgLista.Rows(i).Cells("colPoliza").Value
            dgLista.Rows(i).Cells("colReferencia").Value = dgLista.Rows(i).Cells("colReferencia").Value
            dgLista.Rows(i).Cells("colLinea").Value = dgLista.Rows(i).Cells("colLinea").Value
            dgLista.Rows(i).Cells("colCodigo").Value = dgLista.Rows(i).Cells("colCodigo").Value
            dgLista.Rows(i).Cells("colDisponible").Value = dgLista.Rows(i).Cells("colDisponible").Value
            dgLista.Rows(i).Cells("colMedida").Value = dgLista.Rows(i).Cells("colMedida").Value
            dgLista.Rows(i).Cells("colUnidad").Value = dgLista.Rows(i).Cells("colUnidad").Value
            dgLista.Rows(i).Cells("colDescargo").Value = dgLista.Rows(i).Cells("colDescargo").Value
            dgLista.Rows(i).Cells("colNota1").Value = dgLista.Rows(i).Cells("colNota1").Value
            dgLista.Rows(i).Cells("colNota2").Value = dgLista.Rows(i).Cells("colNota1").Value
            dgLista.Rows(i).Cells("colReserva").Value = dgLista.Rows(i).Cells("colReserva").Value
            dgLista.Rows(i).Cells("colDetalle").Value = dgLista.Rows(i).Cells("colDetalle").Value
            dgLista.Rows(i).Cells("colPF").Value = strMedida
            dgLista.Rows(i).Cells("colFila").Value = dgLista.Rows(i).Cells("colFila").Value
        Next


    End Sub
#End Region

#Region "Eventos"

    Private Sub frmFacturasRef_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intKgs As Integer
        Dim intLbs As Integer
        Dim strSQL2 As String
        Dim strSQL3 As String
        Dim KGS As Double


        panelReservacion.Visible = False
        'queryListaDetalle()
        InicalizacionVariables()
        CargarMedidaPF(Codigo, strCodigoPF)
        queryInfoProducto()
        'botonAceptar.Enabled = False
        ActualizarTotales()
        Info(Informacion)
        'descargo = dgLista.SelectedCells(10).Value

        ''Id de KGS y LBS
        'strSQL = " SELECT cat_num"
        'strSQL &= "  FROM Catalogos"
        'strSQL &= "      WHERE cat_clase='Medidas' AND cat_clave= 'KGS'"

        'conec = New MySqlConnection(strConexion)
        'conec.Open()
        'COM = New MySqlCommand(strSQL, conec)
        'intKgs = COM.ExecuteScalar()
        'conec.Close()

        'strSQL2 = "  SELECT cat_num"
        'strSQL2 &= "     FROM Catalogos"
        'strSQL2 &= "         WHERE cat_clase='Medidas' AND cat_clave='LBS'"

        'conec = New MySqlConnection(strConexion)
        'conec.Open()
        'COM = New MySqlCommand(strSQL2, conec)
        'intLbs = COM.ExecuteScalar()
        'conec.Close()

        ''Factor de conversión (división)

        'strSQL3 = "  SELECT cat_sist"
        'strSQL3 &= "     FROM Catalogos"
        'strSQL3 &= "         WHERE cat_clase='Medidas' AND cat_clave='DEF_KGS'"

        'conec = New MySqlConnection(strConexion)
        'conec.Open()
        'COM = New MySqlCommand(strSQL3, conec)
        'KGS = COM.ExecuteScalar()
        'conec.Close()

        'dblFactorKgs = CDbl(KGS)
        'dblFactorLbs = (1 / dblFactorKgs)

    End Sub

    Private Sub celdaCancel_Click(sender As Object, e As EventArgs) Handles celdaCancel.Click

        Me.Close()
        Me.Hide()

    End Sub

    'Actualiza la información de totales en pantalla
    Public Sub ActualizarTotales()
        Dim dblExiste As Double
        Dim dblDescargo As Double
        Dim dblFactor As Double
        Dim dblSuma As Double
        Dim dblSum As Double
        Dim intUM As Integer

        intUM = NO_FILA
        For i As Integer = 0 To dgLista.Rows.Count - 1
            'Determina la unidad de medida (para desplegar)
            If intUM = NO_FILA Then
                'Si se ha asignado a la propiedad Unidad del formulario
                If Not (intUnidad = NO_FILA) Then
                    intUM = intUnidad
                Else
                    intUM = dgLista.Rows(i).Cells("colUnidad").Value
                End If

                If intUM = intKgs Then
                    'Kilos a Libras
                    dblFactor = dblFactorKgs
                Else
                    'Libras a Kilos
                    dblFactor = dblFactorLbs
                End If
            End If

            dblExiste = dgLista.Rows(i).Cells("colDisponible").Value
            dblDescargo = dgLista.Rows(i).Cells("colDescargo").Value

            'Si el inventario tiene distinta u/m
            If Not (intUM = dgLista.Rows(i).Cells("colUnidad").Value) Then
                dblExiste = (dblExiste / dblFactor)
                dblDescargo = (dblDescargo / dblFactor)
            End If


            dblSuma = dblSuma + dblExiste
            dblSum = dblSum + dblDescargo
        Next

        'Despliega los totales
        celdaDisponibleLBS.Text = dblSuma.ToString(FORMATO_MONEDA)
        celdaCantidadDescar.Text = dblSum.ToString(FORMATO_MONEDA)

    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Dim dblCantidad As Double
        Dim dblSuma As Double
        Dim dblFactor As Double
        Dim i As Integer
        Dim intRef As Integer
        Dim intMedida As Integer
        Dim logVarios As Boolean
        Dim logBlancos As Boolean
        Dim strCodigo As String
        Dim strTemp As String
        Dim strMedida As String = STR_VACIO

        'Inicializa las variables locales
        strEspecifico = vbNullString
        strLista = vbNullString
        strReferencias = vbNullString
        dblDescargo = vbEmpty
        dblExistencia = vbEmpty

        'Unidad del pedido
        If intUnidad = intKgs Then
            dblFactor = dblFactorKgs
        ElseIf intUnidad = intLbs Then
            dblFactor = dblFactorLbs
        Else
            dblFactor = 1
        End If

        For i = vbEmpty To dgLista.Rows.Count - 1
            strTemp = dgLista.Rows(i).Cells("colCodigo").Value
            intMedida = dgLista.Rows(i).Cells("colUnidad").Value
            strMedida = dgLista.Rows(i).Cells("colPF").Value
            dblCantidad = dgLista.Rows(i).Cells("colDescargo").Value
            If Not (intUnidad = intMedida) Then
                dblCantidad = (dblCantidad / dblFactor)
            End If

            dblDescargo = dblDescargo + dblCantidad
            'Si hay descargo verifica el código
            If dblCantidad > vbEmpty Then

                If Not (strLista = vbNullString) Then
                    strLista = strLista & Space(2) & "/" & Space(2)
                End If
                strLista = strLista & intRef & ")" & dgLista.Rows(i).Cells("colReferencia").Value & "-" & dblCantidad.ToString(FORMATO_MONEDA)

                If Not (strReferencias = vbNullString) Then
                    strReferencias = strReferencias & " , " & Space(1)
                End If

                strReferencias = strReferencias & UCase(dgLista.Rows(i).Cells("colReferencia").Value)

                If (strCodigo = vbNullString) Then
                    strCodigo = strTemp
                ElseIf Not (strCodigo = strTemp) Then
                    'Para genérico, se comprueba que no se intente descargar de varios específicos
                    logVarios = True
                    Exit For
                End If
            Else
                logBlancos = True
            End If
            'Determina el código del cuál se está descargando
            If (dblCantidad > vbEmpty) And (strEspecifico = vbNullString) Then
                strEspecifico = strTemp
            End If
        Next
        If logVarios Then
            If logFactura Then
                MsgBox("You can only change the references indicated in the  dispatch instruction", vbExclamation, "Notice")
            ElseIf Not (logGenerico) Then
                MsgBox("You can not download multiple references if the order has a specific code", vbExclamation, "Notice")
            ElseIf MsgBox("Download multiple references for the same line item" & vbCr & vbCr & "¿Confirm that you want to continue", vbQuestion + vbYesNo + vbDefaultButton2, "Confirm") = vbNo Then
                dgLista.Focus()
            Else
                logVarios = False
            End If
        End If
        If Not (logVarios) Then
            'Suma la existencia para el código específico
            For i = 0 To dgLista.Rows.Count - 1
                dblSuma = dgLista.Rows(i).Cells("colDisponible").Value
                If dgLista.Rows(i).Cells("colCodigo").Value = strEspecifico Then
                    dblExistencia = dblExistencia + dblSuma
                End If
            Next
            If logFactura Then
                'Si se intenta dejar alguna línea a cero
                If logBlancos Then
                    MsgBox("It is not allowed to leaves some line with discharge equal to zero", vbExclamation, "Notice")
                    dgLista.Focus()
                    Exit Sub
                End If
            ElseIf (dblDescargo > dblPedido) Then
                'Para Instrucciones, pide confirmación si se desea descargar más que la cantidad restante del pedido
                If MsgBox("You are downloading a larger quantity to the order." & vbCr & vbCr & "Requested Amount: " & vbTab & dblPedido.ToString(FORMATO_MONEDA) & vbTab & strMedida & vbCr & "Total to Download:" & vbTab & dblDescargo.ToString(FORMATO_MONEDA) & vbTab & strMedida & vbCr & vbCr & "¿Confirm that you want to continue?", vbQuestion + vbYesNo + vbDefaultButton2, "Confirm") = vbNo Then
                    dgLista.Focus()
                    Exit Sub
                End If
            End If
            logAceptar = True
            Me.Hide()
        End If
    End Sub

    'Private Sub dgLista_BeforeUpdate(ByVal Col As Integer, ByVal OldValue As String, ByVal NewValue As String, ByVal Cancel As Boolean)
    '    If (Col = dgLista.SelectedCells("colDescargo").Value) Then
    '        If Val(NewValue) > Val(dgLista.SelectedCells("colDisponible").Value) Then
    '            MsgBox("La cantidad a descargar no puede ser mayor que la existencia", vbExclamation, "Aviso")
    '            dgLista.Focus()
    '            Cancel = True
    '        End If
    '    End If
    'End Sub

    Private Sub dgLista_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgLista.CellEndEdit
        Dim dblSumaDescargo As Double = 0

        'descargo = dgLista.SelectedCells(10).Value
        For i As Integer = 0 To dgLista.Rows.Count - 1
            If (CDbl(dgLista.Rows(i).Cells("colDescargo").Value) > CDbl(dgLista.Rows(i).Cells("colDisponible").Value)) Then
                MsgBox("Downloading the amount can not be greater than the existence", vbExclamation, "Aviso")
                dgLista.Rows(i).Cells("colDescargo").Value = descargo
                celdaCantidadDescar.Text = dgLista.Rows(i).Cells("colDescargo").Value
            Else
                dblSumaDescargo = dblSumaDescargo + dgLista.Rows(i).Cells("colDescargo").Value
                celdaCantidadDescar.Text = dblSumaDescargo
            End If

        Next

    End Sub

    Private Sub dgLista_SelectionChanged(sender As Object, e As EventArgs) Handles dgLista.SelectionChanged
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim strNota As String

        Try

            strSQL = SQLInfoProducto()

            If strSQL = STR_VACIO Then
                Exit Sub
            End If
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader


            Do While REA.Read
                If logCatalogo = False Then
                    strTemp = vbNullString
                    strTemp = "Hilo:" & Space(13) & REA.GetString("hilo") & vbNewLine
                    strTemp &= "Fabricante:" & Space(2) & REA.GetString("fabricante") & vbNewLine
                    strTemp &= "Nº de Lote:" & Space(2) & REA.GetString("lote") & vbNewLine
                    strTemp &= "Semana:" & Space(7) & REA.GetInt32("semana") & vbNewLine

                    strNota = vbNullString
                    strNota = "Notas" & vbNewLine & strNota & vbNewLine

                    etiquetaInfo.Text = strTemp & strNota
                Else
                    strTemp = vbNullString
                    strTemp = "Hilo:" & Space(10) & REA.GetString("hilo") & vbNewLine
                    strTemp &= "Origen:" & Space(2) & REA.GetString("pais") & vbNewLine
                    strTemp &= "Lote:" & Space(7) & REA.GetString("lote")

                    etiquetaInfo.Text = strTemp
                End If
            Loop

            queryInfoProducto()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgReservacion_DoubleClick(sender As Object, e As EventArgs) Handles dgReservacion.DoubleClick
        Dim Rsv As New frmReservas
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        Try
            strSQL = " SELECT * "
            strSQL &= "     FROM Reserva"
            strSQL &= "         WHERE id_empresa={empresa} AND doc_tipo=47 AND doc_ciclo={año} AND doc_num={numero} AND doc_lin={linea} AND NOT(estado=2)"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", dgLista.SelectedCells(0).Value)
            strSQL = Replace(strSQL, "{numero}", dgLista.SelectedCells(1).Value)
            strSQL = Replace(strSQL, "{linea}", dgLista.SelectedCells(5).Value)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            'dgReservacion.Rows.Clear()
            REA.Read()
            Rsv.Empresa = Sesion.IdEmpresa
            Rsv.Catalogo = 47
            Rsv.Anio = REA.GetInt32("doc_ciclo")
            Rsv.Numero = REA.GetInt32("doc_num")
            Rsv.Linea = REA.GetInt32("doc_lin")
            Rsv.InfoProducto = REA.GetString("nombre")
            Rsv.Medida = dgLista.SelectedCells(8).Value
            Rsv.Cantidad = dgLista.SelectedCells(7).Value
            Rsv.Reservado = dgLista.SelectedCells(13).Value
            Rsv.ShowDialog(Me)

            If Rsv.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'actualice el datagrid
                'dblReserva = dgLista.Rows(iFila).Cells("colReserva").Value
                celdaReserva.Text = "Reserva / " & dgReservacion.SelectedCells(0).value


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaCantidadDescar_TextChanged(sender As Object, e As EventArgs) Handles celdaCantidadDescar.TextChanged

    End Sub

#End Region
End Class