﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmImportaciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmImportaciones))
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.checkPoliza = New System.Windows.Forms.CheckBox()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.botonSeleccionar = New System.Windows.Forms.Button()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.dgImportaciones = New System.Windows.Forms.DataGridView()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelBotones.SuspendLayout()
        Me.panelPrincipal.SuspendLayout()
        CType(Me.dgImportaciones, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.checkPoliza)
        Me.panelBotones.Controls.Add(Me.botonBuscar)
        Me.panelBotones.Controls.Add(Me.botonSeleccionar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(1048, 74)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(225, 444)
        Me.panelBotones.TabIndex = 1
        '
        'checkPoliza
        '
        Me.checkPoliza.AutoSize = True
        Me.checkPoliza.Checked = True
        Me.checkPoliza.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkPoliza.Location = New System.Drawing.Point(18, 290)
        Me.checkPoliza.Name = "checkPoliza"
        Me.checkPoliza.Size = New System.Drawing.Size(193, 21)
        Me.checkPoliza.TabIndex = 2
        Me.checkPoliza.Text = "Complete policy download"
        Me.checkPoliza.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = CType(resources.GetObject("botonBuscar.Image"), System.Drawing.Image)
        Me.botonBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonBuscar.Location = New System.Drawing.Point(55, 165)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(110, 63)
        Me.botonBuscar.TabIndex = 1
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'botonSeleccionar
        '
        Me.botonSeleccionar.Image = CType(resources.GetObject("botonSeleccionar.Image"), System.Drawing.Image)
        Me.botonSeleccionar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonSeleccionar.Location = New System.Drawing.Point(55, 51)
        Me.botonSeleccionar.Name = "botonSeleccionar"
        Me.botonSeleccionar.Size = New System.Drawing.Size(110, 65)
        Me.botonSeleccionar.TabIndex = 0
        Me.botonSeleccionar.Text = "Select"
        Me.botonSeleccionar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonSeleccionar.UseVisualStyleBackColor = True
        '
        'panelPrincipal
        '
        Me.panelPrincipal.Controls.Add(Me.dgImportaciones)
        Me.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelPrincipal.Location = New System.Drawing.Point(0, 74)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(1048, 444)
        Me.panelPrincipal.TabIndex = 2
        '
        'dgImportaciones
        '
        Me.dgImportaciones.AllowUserToAddRows = False
        Me.dgImportaciones.AllowUserToDeleteRows = False
        Me.dgImportaciones.AllowUserToOrderColumns = True
        Me.dgImportaciones.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgImportaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgImportaciones.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colTipo, Me.colAnio, Me.colNumero, Me.colFecha, Me.colReferencia, Me.colDocumento, Me.colCantidad, Me.colMonto, Me.colLinea})
        Me.dgImportaciones.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgImportaciones.Location = New System.Drawing.Point(0, 0)
        Me.dgImportaciones.MultiSelect = False
        Me.dgImportaciones.Name = "dgImportaciones"
        Me.dgImportaciones.ReadOnly = True
        Me.dgImportaciones.RowTemplate.Height = 24
        Me.dgImportaciones.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgImportaciones.Size = New System.Drawing.Size(1048, 444)
        Me.dgImportaciones.TabIndex = 0
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1273, 74)
        Me.Encabezado1.TabIndex = 0
        '
        'frmImportaciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1273, 518)
        Me.Controls.Add(Me.panelPrincipal)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmImportaciones"
        Me.Text = "Imports"
        Me.panelBotones.ResumeLayout(False)
        Me.panelBotones.PerformLayout()
        Me.panelPrincipal.ResumeLayout(False)
        CType(Me.dgImportaciones, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents panelBotones As Panel
    Friend WithEvents checkPoliza As System.Windows.Forms.CheckBox
    Friend WithEvents botonBuscar As Button
    Friend WithEvents botonSeleccionar As Button
    Friend WithEvents panelPrincipal As Panel
    Friend WithEvents dgImportaciones As DataGridView
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
End Class
