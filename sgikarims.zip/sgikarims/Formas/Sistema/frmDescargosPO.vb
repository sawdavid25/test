﻿Public Class frmDescargosPO

#Region "Miembros"
    Dim AnioPO As Integer
    Dim NumeroPO As Integer
    Dim LineaPO As Integer
#End Region

#Region "Propiedades"
    Public Property Anio As Integer
        Get
            Return AnioPO
        End Get
        Set(value As Integer)
            AnioPO = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return NumeroPO
        End Get
        Set(value As Integer)
            NumeroPO = value
        End Set
    End Property

    Public Property Linea As Integer
        Get
            Return LineaPO
        End Get
        Set(value As Integer)
            LineaPO = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Function SQLDescargos()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT IDoc_Doc_Lin Linea, IDoc_Itm_QTY Cantidad, IDoc_RF1_Fec, IDoc_Doc_Ano Anio, IDoc_Doc_Num Numero, IFNULL (IDoc_RF2_Cod,'(SIN REF.)') Documento, IDoc_Doc_Itm Fila "
        strSQL &= "   FROM Dcmtos_DTL_Itm "
        strSQL &= "   WHERE IDoc_Sis_Emp={emp} AND IDoc_Doc_Cat=38 AND IDoc_Doc_Ano= {anio} AND IDoc_Doc_Num= {num} "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", AnioPO)
        strSQL = Replace(strSQL, "{num}", NumeroPO)

        Return strSQL

    End Function

    Private Function CalcularLineaDescargo()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intLine As Integer = 0
        strSQL = " SELECT IFNULL(MAX(i.IDoc_Doc_Itm),0)+1 linea FROM Dcmtos_DTL_Itm i WHERE i.IDoc_Sis_Emp={emp} AND i.IDoc_Doc_Cat=38 AND i.IDoc_Doc_Ano={anio} AND i.IDoc_Doc_Num={num}"
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", AnioPO)
        strSQL = Replace(strSQL, "{num}", NumeroPO)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intLine = COM.ExecuteScalar

        Return intLine

    End Function

    Public Sub Descargos()
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strfila As String = STR_VACIO

        Try
            strSQL = SQLDescargos()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDescargos.Rows.Clear()
                Do While REA.Read
                    strfila = REA.GetInt32("Linea") & "|"
                    strfila &= REA.GetInt32("Anio") & "|"
                    strfila &= REA.GetInt32("Numero") & "|"
                    strfila &= REA.GetDateTime("IDoc_RF1_Fec").ToString(FORMATO_MYSQL) & "|"
                    strfila &= REA.GetInt32("Fila") & "|"
                    strfila &= REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "|"
                    strfila &= REA.GetString("Documento") & "|"
                    strfila &= INT_UNO

                    cFunciones.AgregarFila(dgDescargos, strfila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub GuardarDescargoManual()
        Dim tbl As New Tablas.TDCMTOS_DTL_ITM

        tbl.CONEXION = strConexion

        Try

            For i As Integer = 0 To dgDescargos.Rows.Count - 1

                tbl.IDOC_SIS_EMP = Sesion.IdEmpresa
                tbl.IDOC_DOC_CAT = 38
                tbl.IDOC_DOC_ANO = AnioPO
                tbl.IDOC_DOC_NUM = NumeroPO
                tbl.IDOC_DOC_LIN = LineaPO
                tbl.IDOC_ITM_COD = 0
                tbl.IDOC_ITM_QTY = dgDescargos.Rows(i).Cells("colCantidadDescargo").Value
                tbl.IDOC_RF1_TXT = "DESPACHO"
                'dtFechaDescargo = dgDescargos.Rows(i).Cells("ColFechaDescargo").Value
                tbl.IDoc_RF1_Fec_NET = dgDescargos.Rows(i).Cells("ColFechaDescargo").Value
                tbl.IDOC_RF2_COD = dgDescargos.Rows(i).Cells("colReferenciaDescargo").Value

                If dgDescargos.Rows(i).Cells("colExtraDescargo").Value = 0 Then
                    tbl.IDOC_DOC_ITM = CalcularLineaDescargo()
                    If tbl.PINSERT = False Then
                        MsgBox(tbl.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                    End If
                End If
                If dgDescargos.Rows(i).Cells("colExtraDescargo").Value = 1 Then
                    tbl.IDOC_DOC_ITM = dgDescargos.Rows(i).Cells("colFilaDescargo").Value
                    If tbl.PUPDATE = False Then
                        MsgBox(tbl.MERROR.ToString() & " Could Not Modify this document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Eventos"
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim strFila As String = STR_VACIO
        Try
            strFila = Nothing & "|"
            strFila &= Nothing & "|"
            strFila &= Nothing & "|"
            strFila &= Nothing & "|"
            strFila &= Nothing & "|"
            strFila &= Nothing & "|"
            strFila &= Nothing & "|"
            strFila &= INT_CERO

            cFunciones.AgregarFila(dgDescargos, strFila)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmDescargosPO_Load(sender As Object, e As EventArgs) Handles Me.Load
        Descargos()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim strSQL As String = STR_VACIO
        If MsgBox("Do you want to remove the Manual Download?", vbYesNo, "Question") = vbYes Then
            strSQL = "IDoc_Sis_Emp={emp} AND IDoc_Doc_Cat=38 AND IDoc_Doc_Ano={anio} AND IDoc_Doc_Num={num} and IDoc_Doc_Lin = {line} and IDoc_Doc_Itm = {item} "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", AnioPO)
            strSQL = Replace(strSQL, "{num}", NumeroPO)
            strSQL = Replace(strSQL, "{line}", LineaPO)
            strSQL = Replace(strSQL, "{item}", dgDescargos.CurrentRow.Cells("colFilaDescargo").Value)

            Dim itm As New Tablas.TDCMTOS_DTL_ITM
            itm.CONEXION = strConexion
            itm.PDELETE(strSQL)

            Descargos()
        End If
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        GuardarDescargoManual()
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub dgDescargos_DoubleClick(sender As Object, e As EventArgs) Handles dgDescargos.DoubleClick
        Try
            Select Case dgDescargos.CurrentCell.ColumnIndex
                Case 3
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDescargos.CurrentRow.Cells("ColFechaDescargo").Value = frmF.LLave
                    End If
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region


End Class