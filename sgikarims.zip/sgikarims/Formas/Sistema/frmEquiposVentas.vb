﻿Public Class frmEquiposVentas

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

    'Constantes
    Public Const TBL_DOCUMENTOS As String = "clsDcmtos_DTL"

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Dim cAccesos As New clsAccesos

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
        End If
    End Sub

    'Limpiar Campos del Grupos
    Public Sub LimpiarGrupos()
        celdaCodigo.Text = NO_FILA
        celdaNombreGroup.Text = STR_VACIO
        celdaDescripcion.Text = STR_VACIO
        celdaEmpresa.Text = NO_FILA
        celdaUsuario.Text = STR_VACIO
    End Sub

    'Query que carga Lista Usuarios
    Private Function SQLlistaUsuarios() As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT p.per_sisemp empresa, p.per_codigo codigo, p.per_usuario usuario, p.per_apellido1 apellido1, p.per_apellido2 apellido2, p.per_nombre1 nombre1, p.per_nombre2 nombre2, p.per_puesto puesto,pu.pue_descripcion descripcion,  p.per_nivel grupo,  c.cat_clave nombregrupo"
        strsql &= " FROM Personal p"
        strsql &= "   LEFT JOIN Puestos pu ON pu.pue_sisemp = p.per_sisemp and pu.pue_codigo = p.per_puesto "
        strsql &= "      LEFT JOIN Catalogos c ON c.cat_num = p.per_nivel "
        strsql &= " WHERE p.per_sisemp = {empresa} and p.per_puesto = 19 and p.per_estado = 1"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Usuarios
    Public Sub queryListaUsuarios()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim n As Integer

        'Dim Lista As DataGridView

        strSQL = SQLlistaUsuarios()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgListaUsuarios.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("nombre1") & REA.GetString("nombre2") & REA.GetString("apellido1") & REA.GetString("apellido2") & "|"

                    If REA.GetInt32("grupo") = 0 Then
                        strFila &= 0 & "|"
                        strFila &= 0 & "|"

                    Else
                        strFila &= REA.GetString("nombregrupo") & "|"
                        strFila &= REA.GetInt32("grupo") & "|"
                    End If

                    strFila &= REA.GetInt32("puesto") & "|"
                    strFila &= REA.GetString("descripcion")

                    n = REA.GetInt32("grupo")

                    AgregarFila(dgListaUsuarios, strFila, n)
                    'cFunciones.AgregarFila(dgListaUsuarios, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    'Query que carga Lista Grupos
    Private Function SQLlistaGrupos() As String

            Dim strsql As String = STR_VACIO

            strsql = "SELECT c.cat_num numero, c.cat_desc descripcion, c.cat_clase clase, c.cat_clave clave"
            strsql &= " FROM Catalogos c"
            strsql &= "   WHERE c.cat_clase = 'Grupo_Ventas'"

            Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Grupos
    Public Sub queryListaGrupos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow

        'Dim Lista As DataGridView

        strSQL = SQLlistaGrupos()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgListaGrupos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("clase") & "|"
                    strFila &= REA.GetString("clave") & "|"
                    strFila &= REA.GetString("descripcion")

                    cFunciones.AgregarFila(dgListaGrupos, strFila)

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub SeleccionarGrupo(ByVal intNumero As Integer)
        Dim ca As New clsCatalogos

        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        strCampos = " cat_num, cat_desc, cat_clase, cat_clave"
        strCondicion = " cat_clase = 'Grupo_Ventas' AND cat_num = {numero}"
        strCondicion = Replace(strCondicion, "{numero}", intNumero)
        Try
            ca.CONEXION = strConexion
            If ca.Seleccionar(strCondicion, strCampos) Then
                celdaCodigo.Text = ca.CAT_NUM
                celdaNombreGroup.Text = ca.CAT_CLAVE
                celdaDescripcion.Text = ca.CAT_DESC
                celdaEmpresa.Text = Sesion.IdEmpresa
                celdaUsuario.Text = Sesion.Usuario
                celdaTipo.Text = ca.CAT_CLASE
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelEquipos.Dock = DockStyle.None
            panelEquipos.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Equipos de Venta")
            'Cargar Datos
            'cfun.CargarLista(dgListaUsuarios, SQLlistaUsuarios, False)
            queryListaUsuarios()
            queryListaGrupos()
            'Mostrar Panel Filtro
            panelPrincipal.Visible = True
            panelPrincipal.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            'Ocultar Panel Filtro
            panelPrincipal.Visible = False
            panelPrincipal.Dock = DockStyle.None
            'Mostrar panel de documento
            panelEquipos.Dock = DockStyle.Fill
            panelEquipos.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsertar = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                'LimpiarPanelOrden()
            End If

            dgListaUsuarios.DataSource = Nothing
            dgListaGrupos.DataSource = Nothing
        End If

    End Sub

    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean = True
        Try
            Dim ca As New clsCatalogos
            ca.CONEXION = strConexion

            ca.CAT_NUM = celdaCodigo.Text
            ca.CAT_CLASE = celdaTipo.Text
            ca.CAT_CLAVE = celdaNombreGroup.Text
            ca.CAT_DESC = celdaDescripcion.Text

            If Me.Tag = "Mod" Then
                If ca.Actualizar() = False Then
                    MsgBox(ca.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If ca.Guardar() = False Then
                    MsgBox(ca.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub ActualizarGrupo()
        Dim COM As New MySqlCommand
        Dim strSQL As String
        Try
            strSQL = "Update Personal "
            strSQL &= " Set per_nivel = {codigo}"
            strSQL &= "     Where per_puesto = 19 and per_codigo = {usuario} "

            strSQL = Replace(strSQL, "{codigo}", dgListaUsuarios.CurrentRow.Cells("colCodGrupo").Value)
            strSQL = Replace(strSQL, "{usuario}", dgListaUsuarios.CurrentRow.Cells("colCodigo").Value)

            'Ejecuta la instrucción
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub SqlBorrarDocumento()
        Dim ca As New clsCatalogos
        Dim strCondicion As String = STR_VACIO

        strCondicion = " cat_num = {codigo} and  cat_clase ='{tipo}'  AND cat_clave= '{nombre}' AND cat_desc = '{descripcion}'"

        strCondicion = Replace(strCondicion, "{codigo}", celdaCodigo.Text)
        strCondicion = Replace(strCondicion, "{tipo}", celdaTipo.Text)
        strCondicion = Replace(strCondicion, "{nombre}", celdaNombreGroup.Text)
        strCondicion = Replace(strCondicion, "{descripcion}", celdaDescripcion.Text)

        Try
            ca.CONEXION = strConexion
            If ca.Borrar(strCondicion) = False Then
                MsgBox("No se pudo borrar" & ca.MERROR.ToString)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        MostrarLista()
    End Sub

    Private Sub ActualizarPersonal()
        Dim COM As New MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "Update Personal "
            strSQL &= " Set per_nivel = 0"
            strSQL &= "     Where per_puesto = 19 and per_codigo = {usuario}"

            strSQL = Replace(strSQL, "{usuario}", dgListaUsuarios.CurrentRow.Cells("colCodigo").Value)

            'Ejecuta la instrucción
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal nivel As Integer)
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If nivel = 0 Then
                    If i = 3 Then
                        Celda.Style.BackColor = Color.SkyBlue

                    Else
                        Celda.Style.BackColor = Color.White
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next
            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Eventos"

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "Nuevo" Then
            GuardarDocumento()

            Try
                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaCodigo.Text)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            If MsgBox("The document has been save" & vbCr & vbCr & "To close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                MostrarLista()
            End If
        Else
            Me.Tag = "Mod"

            GuardarDocumento()

            Try
                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaCodigo.Text)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            If MsgBox("The document has been Update" & vbCr & vbCr & "To close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                MostrarLista()
            End If

        End If

    End Sub

    Private Sub frmFacturacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Accessos()
        MostrarLista()

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelEquipos.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        logInsertar = True
        Me.Tag = "Nuevo"
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Numero As Integer
        MostrarLista(False)
        LimpiarGrupos()
        celdaEmpresa.Text = Sesion.IdEmpresa
        celdaTipo.Text = "Grupo_Ventas"
        celdaUsuario.Text = Sesion.idUsuario

        Try
            strSQL = "Select max(cat_num) + 1"
            strSQL &= "  From Catalogos"

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Numero = COM.ExecuteScalar
            conec.Close()

            celdaCodigo.Text = Numero
            celdaCodigo.ForeColor = Color.Blue

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgListaUsuarios_DoubleClick(sender As Object, e As EventArgs) Handles dgListaUsuarios.DoubleClick

        Try
            Me.Tag = "Mod"

            Select Case dgListaUsuarios.CurrentCell.ColumnIndex

                Case 3
                    Dim frm As New frmSeleccionar

                    Try
                        frm.Titulo = "Group Type"
                        frm.Campos = " c.cat_num numero, c.cat_clave nombre, c.cat_desc descripcion"
                        frm.Tabla = " Catalogos c"
                        frm.FiltroText = " Enter the Package Type to filter"
                        frm.Filtro = " cat_Desc "
                        frm.Condicion = "  c.cat_clase = 'Grupo_Ventas'"

                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgListaUsuarios.CurrentRow.Cells("colCodGrupo").Value = frm.LLave
                            dgListaUsuarios.CurrentRow.Cells("colGrupo").Value = frm.Dato
                            ActualizarGrupo()
                            queryListaUsuarios()
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgListaGrupos_DoubleClick(sender As Object, e As EventArgs) Handles dgListaGrupos.DoubleClick
        logInsertar = False
        Me.Tag = "Mod"
        Dim intNumero As Integer
        intNumero = dgListaGrupos.SelectedCells(0).Value
        SeleccionarGrupo(intNumero)
        MostrarLista(False)


    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If Me.Tag = "Mod" Then

            For i As Integer = 0 To dgListaUsuarios.Rows.Count - 1
                If celdaCodigo.Text = dgListaUsuarios.Rows(i).Cells("colCodGrupo").Value Then
                    MsgBox("No se puede eliminar este grupo pues ya tienen asignaciones", vbInformation)
                    Exit Sub
                End If
            Next

            If MsgBox("¿Esta seguro que desea borrar este registro?" & vbNewLine & " Si elige 'Si' los datos de este documento " & vbNewLine & "no se podrán recuperar.", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                SqlBorrarDocumento()
                'ActualizarPersonal()
            End If


        End If
    End Sub

#End Region
End Class