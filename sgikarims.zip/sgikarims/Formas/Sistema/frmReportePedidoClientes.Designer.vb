﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReportePedidoClientes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmReportePedidoClientes))
        Me.gbencabezado = New System.Windows.Forms.GroupBox()
        Me.celdaIdPaisOrigen = New System.Windows.Forms.TextBox()
        Me.celdaIdProducto = New System.Windows.Forms.TextBox()
        Me.celdaIDClienteSolicitante = New System.Windows.Forms.TextBox()
        Me.botonClienteSolicitante = New System.Windows.Forms.Button()
        Me.botonPaisOrigen = New System.Windows.Forms.Button()
        Me.celdaPaisOrigen = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.celdaClienteSolicitante = New System.Windows.Forms.TextBox()
        Me.rbSolicitante = New System.Windows.Forms.RadioButton()
        Me.rbCliente = New System.Windows.Forms.RadioButton()
        Me.gbOpciones = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.checkResumen = New System.Windows.Forms.CheckBox()
        Me.checkHeathers = New System.Windows.Forms.CheckBox()
        Me.checkFechaEntrega = New System.Windows.Forms.CheckBox()
        Me.checkTotalSub = New System.Windows.Forms.CheckBox()
        Me.gbLineas = New System.Windows.Forms.GroupBox()
        Me.rbConSaldo = New System.Windows.Forms.RadioButton()
        Me.rbSinSaldo = New System.Windows.Forms.RadioButton()
        Me.rbIncluirTodo = New System.Windows.Forms.RadioButton()
        Me.rbAllLines = New System.Windows.Forms.RadioButton()
        Me.rbCanceledLines = New System.Windows.Forms.RadioButton()
        Me.rbActiveLines = New System.Windows.Forms.RadioButton()
        Me.gbFecha = New System.Windows.Forms.GroupBox()
        Me.botonCancel = New System.Windows.Forms.Button()
        Me.botonAcept = New System.Windows.Forms.Button()
        Me.etiquetaFechaFIn = New System.Windows.Forms.Label()
        Me.etiquetaFechaInicio = New System.Windows.Forms.Label()
        Me.dtpFechaFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.panelPrinicpal = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.gbencabezado.SuspendLayout()
        Me.gbOpciones.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.gbLineas.SuspendLayout()
        Me.gbFecha.SuspendLayout()
        Me.panelPrinicpal.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbencabezado
        '
        Me.gbencabezado.Controls.Add(Me.celdaIdPaisOrigen)
        Me.gbencabezado.Controls.Add(Me.celdaIdProducto)
        Me.gbencabezado.Controls.Add(Me.celdaIDClienteSolicitante)
        Me.gbencabezado.Controls.Add(Me.botonClienteSolicitante)
        Me.gbencabezado.Controls.Add(Me.botonPaisOrigen)
        Me.gbencabezado.Controls.Add(Me.celdaPaisOrigen)
        Me.gbencabezado.Controls.Add(Me.Label1)
        Me.gbencabezado.Controls.Add(Me.botonProducto)
        Me.gbencabezado.Controls.Add(Me.etiquetaProducto)
        Me.gbencabezado.Controls.Add(Me.celdaProducto)
        Me.gbencabezado.Controls.Add(Me.celdaClienteSolicitante)
        Me.gbencabezado.Controls.Add(Me.rbSolicitante)
        Me.gbencabezado.Controls.Add(Me.rbCliente)
        Me.gbencabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbencabezado.Location = New System.Drawing.Point(0, 0)
        Me.gbencabezado.Margin = New System.Windows.Forms.Padding(4)
        Me.gbencabezado.Name = "gbencabezado"
        Me.gbencabezado.Padding = New System.Windows.Forms.Padding(4)
        Me.gbencabezado.Size = New System.Drawing.Size(848, 220)
        Me.gbencabezado.TabIndex = 0
        Me.gbencabezado.TabStop = False
        Me.gbencabezado.Text = "Select Orders By"
        '
        'celdaIdPaisOrigen
        '
        Me.celdaIdPaisOrigen.Location = New System.Drawing.Point(687, 183)
        Me.celdaIdPaisOrigen.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIdPaisOrigen.Name = "celdaIdPaisOrigen"
        Me.celdaIdPaisOrigen.Size = New System.Drawing.Size(32, 22)
        Me.celdaIdPaisOrigen.TabIndex = 12
        Me.celdaIdPaisOrigen.Text = "-1"
        Me.celdaIdPaisOrigen.Visible = False
        '
        'celdaIdProducto
        '
        Me.celdaIdProducto.Location = New System.Drawing.Point(687, 137)
        Me.celdaIdProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIdProducto.Name = "celdaIdProducto"
        Me.celdaIdProducto.Size = New System.Drawing.Size(32, 22)
        Me.celdaIdProducto.TabIndex = 11
        Me.celdaIdProducto.Text = "-1"
        Me.celdaIdProducto.Visible = False
        '
        'celdaIDClienteSolicitante
        '
        Me.celdaIDClienteSolicitante.Location = New System.Drawing.Point(687, 92)
        Me.celdaIDClienteSolicitante.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDClienteSolicitante.Name = "celdaIDClienteSolicitante"
        Me.celdaIDClienteSolicitante.Size = New System.Drawing.Size(32, 22)
        Me.celdaIDClienteSolicitante.TabIndex = 10
        Me.celdaIDClienteSolicitante.Text = "-1"
        Me.celdaIDClienteSolicitante.Visible = False
        '
        'botonClienteSolicitante
        '
        Me.botonClienteSolicitante.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonClienteSolicitante.Image = CType(resources.GetObject("botonClienteSolicitante.Image"), System.Drawing.Image)
        Me.botonClienteSolicitante.Location = New System.Drawing.Point(765, 74)
        Me.botonClienteSolicitante.Margin = New System.Windows.Forms.Padding(4)
        Me.botonClienteSolicitante.Name = "botonClienteSolicitante"
        Me.botonClienteSolicitante.Size = New System.Drawing.Size(51, 40)
        Me.botonClienteSolicitante.TabIndex = 9
        Me.botonClienteSolicitante.Text = "..."
        Me.botonClienteSolicitante.UseVisualStyleBackColor = True
        '
        'botonPaisOrigen
        '
        Me.botonPaisOrigen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPaisOrigen.Image = CType(resources.GetObject("botonPaisOrigen.Image"), System.Drawing.Image)
        Me.botonPaisOrigen.Location = New System.Drawing.Point(765, 167)
        Me.botonPaisOrigen.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPaisOrigen.Name = "botonPaisOrigen"
        Me.botonPaisOrigen.Size = New System.Drawing.Size(51, 43)
        Me.botonPaisOrigen.TabIndex = 8
        Me.botonPaisOrigen.Text = "..."
        Me.botonPaisOrigen.UseVisualStyleBackColor = True
        '
        'celdaPaisOrigen
        '
        Me.celdaPaisOrigen.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPaisOrigen.Location = New System.Drawing.Point(128, 180)
        Me.celdaPaisOrigen.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPaisOrigen.Name = "celdaPaisOrigen"
        Me.celdaPaisOrigen.ReadOnly = True
        Me.celdaPaisOrigen.Size = New System.Drawing.Size(629, 22)
        Me.celdaPaisOrigen.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 183)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Country of origin"
        '
        'botonProducto
        '
        Me.botonProducto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProducto.Image = CType(resources.GetObject("botonProducto.Image"), System.Drawing.Image)
        Me.botonProducto.Location = New System.Drawing.Point(765, 122)
        Me.botonProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(51, 37)
        Me.botonProducto.TabIndex = 5
        Me.botonProducto.Text = "..."
        Me.botonProducto.UseVisualStyleBackColor = True
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(8, 130)
        Me.etiquetaProducto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaProducto.TabIndex = 4
        Me.etiquetaProducto.Text = "Product"
        '
        'celdaProducto
        '
        Me.celdaProducto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProducto.Location = New System.Drawing.Point(74, 129)
        Me.celdaProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.ReadOnly = True
        Me.celdaProducto.Size = New System.Drawing.Size(683, 22)
        Me.celdaProducto.TabIndex = 3
        '
        'celdaClienteSolicitante
        '
        Me.celdaClienteSolicitante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaClienteSolicitante.Location = New System.Drawing.Point(13, 81)
        Me.celdaClienteSolicitante.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaClienteSolicitante.Name = "celdaClienteSolicitante"
        Me.celdaClienteSolicitante.ReadOnly = True
        Me.celdaClienteSolicitante.Size = New System.Drawing.Size(744, 22)
        Me.celdaClienteSolicitante.TabIndex = 2
        '
        'rbSolicitante
        '
        Me.rbSolicitante.AutoSize = True
        Me.rbSolicitante.Location = New System.Drawing.Point(9, 53)
        Me.rbSolicitante.Margin = New System.Windows.Forms.Padding(4)
        Me.rbSolicitante.Name = "rbSolicitante"
        Me.rbSolicitante.Size = New System.Drawing.Size(87, 21)
        Me.rbSolicitante.TabIndex = 1
        Me.rbSolicitante.Text = "Applicant"
        Me.rbSolicitante.UseVisualStyleBackColor = True
        '
        'rbCliente
        '
        Me.rbCliente.AutoSize = True
        Me.rbCliente.Checked = True
        Me.rbCliente.Location = New System.Drawing.Point(9, 25)
        Me.rbCliente.Margin = New System.Windows.Forms.Padding(4)
        Me.rbCliente.Name = "rbCliente"
        Me.rbCliente.Size = New System.Drawing.Size(64, 21)
        Me.rbCliente.TabIndex = 0
        Me.rbCliente.TabStop = True
        Me.rbCliente.Text = "Client"
        Me.rbCliente.UseVisualStyleBackColor = True
        '
        'gbOpciones
        '
        Me.gbOpciones.Controls.Add(Me.Panel1)
        Me.gbOpciones.Controls.Add(Me.gbLineas)
        Me.gbOpciones.Controls.Add(Me.rbAllLines)
        Me.gbOpciones.Controls.Add(Me.rbCanceledLines)
        Me.gbOpciones.Controls.Add(Me.rbActiveLines)
        Me.gbOpciones.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbOpciones.Location = New System.Drawing.Point(0, 0)
        Me.gbOpciones.Margin = New System.Windows.Forms.Padding(4)
        Me.gbOpciones.Name = "gbOpciones"
        Me.gbOpciones.Padding = New System.Windows.Forms.Padding(4)
        Me.gbOpciones.Size = New System.Drawing.Size(848, 257)
        Me.gbOpciones.TabIndex = 1
        Me.gbOpciones.TabStop = False
        Me.gbOpciones.Text = "Additional Options "
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.checkResumen)
        Me.Panel1.Controls.Add(Me.checkHeathers)
        Me.Panel1.Controls.Add(Me.checkFechaEntrega)
        Me.Panel1.Controls.Add(Me.checkTotalSub)
        Me.Panel1.Location = New System.Drawing.Point(312, 22)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(270, 127)
        Me.Panel1.TabIndex = 11
        '
        'checkResumen
        '
        Me.checkResumen.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkResumen.AutoSize = True
        Me.checkResumen.Location = New System.Drawing.Point(4, 16)
        Me.checkResumen.Margin = New System.Windows.Forms.Padding(4)
        Me.checkResumen.Name = "checkResumen"
        Me.checkResumen.Size = New System.Drawing.Size(246, 21)
        Me.checkResumen.TabIndex = 3
        Me.checkResumen.Text = "Summary (Without dispatch detail)"
        Me.checkResumen.UseVisualStyleBackColor = True
        '
        'checkHeathers
        '
        Me.checkHeathers.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkHeathers.AutoSize = True
        Me.checkHeathers.Location = New System.Drawing.Point(4, 74)
        Me.checkHeathers.Margin = New System.Windows.Forms.Padding(4)
        Me.checkHeathers.Name = "checkHeathers"
        Me.checkHeathers.Size = New System.Drawing.Size(121, 21)
        Me.checkHeathers.TabIndex = 5
        Me.checkHeathers.Text = "Only Heathers"
        Me.checkHeathers.UseVisualStyleBackColor = True
        '
        'checkFechaEntrega
        '
        Me.checkFechaEntrega.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkFechaEntrega.AutoSize = True
        Me.checkFechaEntrega.Location = New System.Drawing.Point(4, 45)
        Me.checkFechaEntrega.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFechaEntrega.Name = "checkFechaEntrega"
        Me.checkFechaEntrega.Size = New System.Drawing.Size(194, 21)
        Me.checkFechaEntrega.TabIndex = 4
        Me.checkFechaEntrega.Text = "Show Delivery Date(Dear)"
        Me.checkFechaEntrega.UseVisualStyleBackColor = True
        '
        'checkTotalSub
        '
        Me.checkTotalSub.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkTotalSub.AutoSize = True
        Me.checkTotalSub.Location = New System.Drawing.Point(9, 102)
        Me.checkTotalSub.Margin = New System.Windows.Forms.Padding(4)
        Me.checkTotalSub.Name = "checkTotalSub"
        Me.checkTotalSub.Size = New System.Drawing.Size(196, 21)
        Me.checkTotalSub.TabIndex = 6
        Me.checkTotalSub.Text = "Show Total  and  Sub total"
        Me.checkTotalSub.UseVisualStyleBackColor = True
        '
        'gbLineas
        '
        Me.gbLineas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbLineas.Controls.Add(Me.rbConSaldo)
        Me.gbLineas.Controls.Add(Me.rbSinSaldo)
        Me.gbLineas.Controls.Add(Me.rbIncluirTodo)
        Me.gbLineas.Location = New System.Drawing.Point(3, 144)
        Me.gbLineas.Name = "gbLineas"
        Me.gbLineas.Size = New System.Drawing.Size(585, 113)
        Me.gbLineas.TabIndex = 10
        Me.gbLineas.TabStop = False
        Me.gbLineas.Text = "Lines Options"
        '
        'rbConSaldo
        '
        Me.rbConSaldo.AutoSize = True
        Me.rbConSaldo.Checked = True
        Me.rbConSaldo.Location = New System.Drawing.Point(25, 32)
        Me.rbConSaldo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbConSaldo.Name = "rbConSaldo"
        Me.rbConSaldo.Size = New System.Drawing.Size(112, 21)
        Me.rbConSaldo.TabIndex = 0
        Me.rbConSaldo.TabStop = True
        Me.rbConSaldo.Text = "With Balance"
        Me.rbConSaldo.UseVisualStyleBackColor = True
        '
        'rbSinSaldo
        '
        Me.rbSinSaldo.AutoSize = True
        Me.rbSinSaldo.Location = New System.Drawing.Point(25, 61)
        Me.rbSinSaldo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbSinSaldo.Name = "rbSinSaldo"
        Me.rbSinSaldo.Size = New System.Drawing.Size(132, 21)
        Me.rbSinSaldo.TabIndex = 1
        Me.rbSinSaldo.Text = "Without Balance"
        Me.rbSinSaldo.UseVisualStyleBackColor = True
        '
        'rbIncluirTodo
        '
        Me.rbIncluirTodo.AutoSize = True
        Me.rbIncluirTodo.Location = New System.Drawing.Point(25, 89)
        Me.rbIncluirTodo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbIncluirTodo.Name = "rbIncluirTodo"
        Me.rbIncluirTodo.Size = New System.Drawing.Size(93, 21)
        Me.rbIncluirTodo.TabIndex = 2
        Me.rbIncluirTodo.Text = "Include All"
        Me.rbIncluirTodo.UseVisualStyleBackColor = True
        '
        'rbAllLines
        '
        Me.rbAllLines.AutoSize = True
        Me.rbAllLines.Location = New System.Drawing.Point(8, 96)
        Me.rbAllLines.Margin = New System.Windows.Forms.Padding(4)
        Me.rbAllLines.Name = "rbAllLines"
        Me.rbAllLines.Size = New System.Drawing.Size(82, 21)
        Me.rbAllLines.TabIndex = 9
        Me.rbAllLines.Text = "All Lines"
        Me.rbAllLines.UseVisualStyleBackColor = True
        '
        'rbCanceledLines
        '
        Me.rbCanceledLines.AutoSize = True
        Me.rbCanceledLines.Location = New System.Drawing.Point(8, 66)
        Me.rbCanceledLines.Margin = New System.Windows.Forms.Padding(4)
        Me.rbCanceledLines.Name = "rbCanceledLines"
        Me.rbCanceledLines.Size = New System.Drawing.Size(126, 21)
        Me.rbCanceledLines.TabIndex = 8
        Me.rbCanceledLines.Text = "Canceled Lines"
        Me.rbCanceledLines.UseVisualStyleBackColor = True
        '
        'rbActiveLines
        '
        Me.rbActiveLines.AutoSize = True
        Me.rbActiveLines.Checked = True
        Me.rbActiveLines.Location = New System.Drawing.Point(9, 37)
        Me.rbActiveLines.Margin = New System.Windows.Forms.Padding(4)
        Me.rbActiveLines.Name = "rbActiveLines"
        Me.rbActiveLines.Size = New System.Drawing.Size(105, 21)
        Me.rbActiveLines.TabIndex = 7
        Me.rbActiveLines.TabStop = True
        Me.rbActiveLines.Text = "Active Lines"
        Me.rbActiveLines.UseVisualStyleBackColor = True
        '
        'gbFecha
        '
        Me.gbFecha.Controls.Add(Me.botonCancel)
        Me.gbFecha.Controls.Add(Me.botonAcept)
        Me.gbFecha.Controls.Add(Me.etiquetaFechaFIn)
        Me.gbFecha.Controls.Add(Me.etiquetaFechaInicio)
        Me.gbFecha.Controls.Add(Me.dtpFechaFin)
        Me.gbFecha.Controls.Add(Me.dtpFechaInicio)
        Me.gbFecha.Dock = System.Windows.Forms.DockStyle.Right
        Me.gbFecha.Location = New System.Drawing.Point(587, 0)
        Me.gbFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.gbFecha.Name = "gbFecha"
        Me.gbFecha.Padding = New System.Windows.Forms.Padding(4)
        Me.gbFecha.Size = New System.Drawing.Size(261, 257)
        Me.gbFecha.TabIndex = 2
        Me.gbFecha.TabStop = False
        Me.gbFecha.Text = "Date Range "
        '
        'botonCancel
        '
        Me.botonCancel.Image = Global.KARIMs_SGI.My.Resources.Resources.boton_cerrar
        Me.botonCancel.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancel.Location = New System.Drawing.Point(149, 197)
        Me.botonCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancel.Name = "botonCancel"
        Me.botonCancel.Size = New System.Drawing.Size(80, 47)
        Me.botonCancel.TabIndex = 7
        Me.botonCancel.Text = "Cancel "
        Me.botonCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancel.UseVisualStyleBackColor = True
        '
        'botonAcept
        '
        Me.botonAcept.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAcept.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAcept.Location = New System.Drawing.Point(32, 197)
        Me.botonAcept.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAcept.Name = "botonAcept"
        Me.botonAcept.Size = New System.Drawing.Size(79, 47)
        Me.botonAcept.TabIndex = 6
        Me.botonAcept.Text = "Accept"
        Me.botonAcept.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAcept.UseVisualStyleBackColor = True
        '
        'etiquetaFechaFIn
        '
        Me.etiquetaFechaFIn.AutoSize = True
        Me.etiquetaFechaFIn.Location = New System.Drawing.Point(12, 105)
        Me.etiquetaFechaFIn.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFechaFIn.Name = "etiquetaFechaFIn"
        Me.etiquetaFechaFIn.Size = New System.Drawing.Size(33, 17)
        Me.etiquetaFechaFIn.TabIndex = 3
        Me.etiquetaFechaFIn.Text = "End"
        '
        'etiquetaFechaInicio
        '
        Me.etiquetaFechaInicio.AutoSize = True
        Me.etiquetaFechaInicio.Location = New System.Drawing.Point(8, 52)
        Me.etiquetaFechaInicio.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFechaInicio.Name = "etiquetaFechaInicio"
        Me.etiquetaFechaInicio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFechaInicio.TabIndex = 2
        Me.etiquetaFechaInicio.Text = "Start"
        '
        'dtpFechaFin
        '
        Me.dtpFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFin.Location = New System.Drawing.Point(65, 96)
        Me.dtpFechaFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaFin.Name = "dtpFechaFin"
        Me.dtpFechaFin.Size = New System.Drawing.Size(116, 22)
        Me.dtpFechaFin.TabIndex = 1
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(65, 47)
        Me.dtpFechaInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(116, 22)
        Me.dtpFechaInicio.TabIndex = 0
        Me.dtpFechaInicio.Value = New Date(2017, 1, 1, 0, 0, 0, 0)
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(596, 892)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(100, 28)
        Me.botonAceptar.TabIndex = 4
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(713, 892)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(100, 28)
        Me.botonCancelar.TabIndex = 5
        Me.botonCancelar.Text = "Cancel "
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'panelPrinicpal
        '
        Me.panelPrinicpal.Controls.Add(Me.panelDetalle)
        Me.panelPrinicpal.Controls.Add(Me.gbencabezado)
        Me.panelPrinicpal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelPrinicpal.Location = New System.Drawing.Point(0, 0)
        Me.panelPrinicpal.Name = "panelPrinicpal"
        Me.panelPrinicpal.Size = New System.Drawing.Size(848, 477)
        Me.panelPrinicpal.TabIndex = 6
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.gbFecha)
        Me.panelDetalle.Controls.Add(Me.gbOpciones)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 220)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(848, 257)
        Me.panelDetalle.TabIndex = 1
        '
        'frmReportePedidoClientes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(848, 477)
        Me.Controls.Add(Me.panelPrinicpal)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmReportePedidoClientes"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmReportePedidoClientes"
        Me.gbencabezado.ResumeLayout(False)
        Me.gbencabezado.PerformLayout()
        Me.gbOpciones.ResumeLayout(False)
        Me.gbOpciones.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.gbLineas.ResumeLayout(False)
        Me.gbLineas.PerformLayout()
        Me.gbFecha.ResumeLayout(False)
        Me.gbFecha.PerformLayout()
        Me.panelPrinicpal.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbencabezado As GroupBox
    Friend WithEvents rbSolicitante As RadioButton
    Friend WithEvents rbCliente As RadioButton
    Friend WithEvents botonPaisOrigen As Button
    Friend WithEvents celdaPaisOrigen As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents botonProducto As Button
    Friend WithEvents etiquetaProducto As Label
    Friend WithEvents celdaProducto As TextBox
    Friend WithEvents celdaClienteSolicitante As TextBox
    Friend WithEvents gbOpciones As GroupBox
    Friend WithEvents checkTotalSub As System.Windows.Forms.CheckBox
    Friend WithEvents checkHeathers As System.Windows.Forms.CheckBox
    Friend WithEvents checkFechaEntrega As System.Windows.Forms.CheckBox
    Friend WithEvents checkResumen As System.Windows.Forms.CheckBox
    Friend WithEvents rbIncluirTodo As RadioButton
    Friend WithEvents rbSinSaldo As RadioButton
    Friend WithEvents rbConSaldo As RadioButton
    Friend WithEvents gbFecha As GroupBox
    Friend WithEvents etiquetaFechaFIn As Label
    Friend WithEvents etiquetaFechaInicio As Label
    Friend WithEvents dtpFechaFin As DateTimePicker
    Friend WithEvents dtpFechaInicio As DateTimePicker
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonClienteSolicitante As Button
    Friend WithEvents celdaIdPaisOrigen As TextBox
    Friend WithEvents celdaIdProducto As TextBox
    Friend WithEvents celdaIDClienteSolicitante As TextBox
    Friend WithEvents panelPrinicpal As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents rbAllLines As System.Windows.Forms.RadioButton
    Friend WithEvents rbCanceledLines As System.Windows.Forms.RadioButton
    Friend WithEvents rbActiveLines As System.Windows.Forms.RadioButton
    Friend WithEvents botonCancel As System.Windows.Forms.Button
    Friend WithEvents botonAcept As System.Windows.Forms.Button
    Friend WithEvents gbLineas As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
End Class
