﻿Public Class frmReporteLibroImportacion
#Region "Variables"
    Dim dtFechaInicial As Date
    Dim dtFechaFinal As Date
#End Region
#Region "Procedimiento"
    Public ReadOnly Property SeleccionFechaInicial As Date
        Get
            Return dtFechaInicial
        End Get
    End Property
    Public ReadOnly Property SeleccionFechaFinal As Date
        Get
            Return dtFechaFinal
        End Get
    End Property
#End Region

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Try
            dtFechaInicial = dtpFechaInicial.Value
        dtFechaFinal = dtpFechaFinal.Value


        If dtFechaFinal < dtFechaInicial Then
            MsgBox("La fecha final debe ser mayor o igual que la fecha inicial", MsgBoxStyle.Exclamation, "Rango de fecha")
            Exit Sub
        End If
            Me.DialogResult = DialogResult.OK
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
    End Sub
End Class