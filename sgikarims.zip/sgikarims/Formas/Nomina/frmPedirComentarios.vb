﻿Public Class frmPedirComentarios

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Private logAceptado As Boolean
    Private logBlanco As Boolean
    Private strDato As String
    Dim dblMonnto As Double
    Dim dblTasa As Double
    Dim intIdMoneda As Integer

    Dim logMonto As Boolean = False
    Dim Blan As String
    Dim Acep As Boolean
#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property Blanco As String
        Get
            Return Blan
        End Get
        Set(value As String)
            Blan = value
        End Set
    End Property

    Public Property Aceptado As Boolean
        Get
            Return Acep
        End Get
        Set(value As Boolean)
            Acep = value
        End Set
    End Property

    Public Property Dato As String
        Get
            Return strDato
        End Get
        Set(value As String)
            strDato = value
        End Set
    End Property

    Public WriteOnly Property MostrarMonto As Boolean
        Set(value As Boolean)
            logMonto = value
        End Set
    End Property

    Public ReadOnly Property Monto As Double
        Get
            Return dblMonnto
        End Get
    End Property

    Public ReadOnly Property Tasa As Double
        Get
            Return dblTasa
        End Get
    End Property

    Public ReadOnly Property IdMoneda As Integer
        Get
            Return intIdMoneda
        End Get
    End Property

#End Region

#Region "Procedimiento"

    Public Sub Iniciar(ByVal Dato As String)
        strDato = Dato
        celdaInfo.Text = strDato

    End Sub

#End Region



    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.Close()
        logAceptado = False
        Aceptado = logAceptado
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        If celdaInfo.Text.Length > 0 Then
            If celdaInfo.Text.Length > 5 Then
                strDato = Trim(celdaInfo.Text)
                If logMonto = True Then
                    dblMonnto = CDbl(celdaMonto.Text)
                    dblTasa = CDbl(celdaTasa.Text)
                    intIdMoneda = CInt(IdMoneda)
                End If
                Aceptado = True
                Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Else
                MsgBox("Invalid Comment.")
            End If

        Else
            MsgBox("You need to enter a comment.")
        End If
    End Sub

    Private Sub frmPedirComentarios_Load(sender As Object, e As EventArgs) Handles Me.Load
        If logMonto = True Then
            panelMonto.Visible = logMonto
            celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            celdaidMoneda.Text = 178
            celdaModena.Text = "US$"
        Else
            panelMonto.Visible = False
        End If

    End Sub
 
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency , cat_sist"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidMoneda.Text = frm.LLave
                celdaModena.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class