﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPPlanilla
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle21 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle22 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle23 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle24 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle25 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle26 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle27 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle28 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CeldaTitulo = New System.Windows.Forms.Label()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.ListaEmpleados = New System.Windows.Forms.DataGridView()
        Me.CodigoEmp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AñoContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSueldoBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBonificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSueldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colbonif = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colhoras = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colboni2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalEmpleado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIgss = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colisr = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrestamo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.coladelanto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colotros = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.parqueo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TDescuento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Suspendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Dias = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Suspenidos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Laborados = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mesSalario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.coltotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelControlLista = New System.Windows.Forms.Panel()
        Me.ListaPlanillas = New System.Windows.Forms.DataGridView()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.btnRecibo = New System.Windows.Forms.Button()
        Me.txtDescripcionPL = New System.Windows.Forms.TextBox()
        Me.bntDescrp = New System.Windows.Forms.Label()
        Me.chkigss = New System.Windows.Forms.CheckBox()
        Me.btncsv = New System.Windows.Forms.Button()
        Me.lblcodt = New System.Windows.Forms.Label()
        Me.btnRango = New System.Windows.Forms.Button()
        Me.txtTipo = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Inicio = New System.Windows.Forms.Label()
        Me.dtpFinalPlanilla = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicioPlanilla = New System.Windows.Forms.DateTimePicker()
        Me.celdaFactor = New System.Windows.Forms.TextBox()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.ComboTipo = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.ComboMoneda = New System.Windows.Forms.ComboBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.celdaID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.pnlPlanillas = New System.Windows.Forms.Panel()
        Me.dgPlanilla = New System.Windows.Forms.DataGridView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnFiltrar = New System.Windows.Forms.Button()
        Me.chkRango = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Del = New System.Windows.Forms.Label()
        Me.FinPlanilla = New System.Windows.Forms.DateTimePicker()
        Me.InicioPlanilla = New System.Windows.Forms.DateTimePicker()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Panel2.SuspendLayout()
        Me.panelPrincipal.SuspendLayout()
        CType(Me.ListaEmpleados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelControlLista.SuspendLayout()
        CType(Me.ListaPlanillas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.pnlPlanillas.SuspendLayout()
        CType(Me.dgPlanilla, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Controls.Add(Me.CeldaTitulo)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 72)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(1372, 26)
        Me.Panel2.TabIndex = 15
        '
        'CeldaTitulo
        '
        Me.CeldaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTitulo.AutoSize = True
        Me.CeldaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTitulo.Location = New System.Drawing.Point(18, 3)
        Me.CeldaTitulo.Name = "CeldaTitulo"
        Me.CeldaTitulo.Size = New System.Drawing.Size(50, 18)
        Me.CeldaTitulo.TabIndex = 0
        Me.CeldaTitulo.Text = "Titulo"
        '
        'panelPrincipal
        '
        Me.panelPrincipal.AutoScroll = True
        Me.panelPrincipal.Controls.Add(Me.ListaEmpleados)
        Me.panelPrincipal.Controls.Add(Me.panelControlLista)
        Me.panelPrincipal.Controls.Add(Me.panelEncabezado)
        Me.panelPrincipal.Location = New System.Drawing.Point(12, 115)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(1102, 539)
        Me.panelPrincipal.TabIndex = 16
        '
        'ListaEmpleados
        '
        Me.ListaEmpleados.AllowUserToAddRows = False
        Me.ListaEmpleados.AllowUserToOrderColumns = True
        Me.ListaEmpleados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCellsExceptHeader
        Me.ListaEmpleados.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ListaEmpleados.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.ListaEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaEmpleados.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.CodigoEmp, Me.AñoContrato, Me.colContrato, Me.colNombre, Me.colPuesto, Me.colIdPuesto, Me.colSueldoBase, Me.colBonificacion, Me.colSueldo, Me.colbonif, Me.colhoras, Me.colboni2, Me.colTotalEmpleado, Me.colIgss, Me.colisr, Me.colPrestamo, Me.coladelanto, Me.colotros, Me.parqueo, Me.TDescuento, Me.Suspendido, Me.Dias, Me.Suspenidos, Me.Laborados, Me.mesSalario, Me.coltotal})
        Me.ListaEmpleados.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListaEmpleados.Location = New System.Drawing.Point(0, 107)
        Me.ListaEmpleados.MultiSelect = False
        Me.ListaEmpleados.Name = "ListaEmpleados"
        Me.ListaEmpleados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaEmpleados.Size = New System.Drawing.Size(1037, 432)
        Me.ListaEmpleados.TabIndex = 1
        '
        'CodigoEmp
        '
        Me.CodigoEmp.HeaderText = "Codigo"
        Me.CodigoEmp.MinimumWidth = 70
        Me.CodigoEmp.Name = "CodigoEmp"
        Me.CodigoEmp.ReadOnly = True
        Me.CodigoEmp.Width = 70
        '
        'AñoContrato
        '
        Me.AñoContrato.HeaderText = "Año"
        Me.AñoContrato.MinimumWidth = 70
        Me.AñoContrato.Name = "AñoContrato"
        Me.AñoContrato.Width = 70
        '
        'colContrato
        '
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colContrato.DefaultCellStyle = DataGridViewCellStyle16
        Me.colContrato.HeaderText = "No_Contrato"
        Me.colContrato.MinimumWidth = 70
        Me.colContrato.Name = "colContrato"
        Me.colContrato.ReadOnly = True
        Me.colContrato.Width = 70
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Nombre"
        Me.colNombre.MinimumWidth = 70
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 70
        '
        'colPuesto
        '
        Me.colPuesto.HeaderText = "Puesto"
        Me.colPuesto.MinimumWidth = 70
        Me.colPuesto.Name = "colPuesto"
        Me.colPuesto.ReadOnly = True
        Me.colPuesto.Width = 70
        '
        'colIdPuesto
        '
        Me.colIdPuesto.HeaderText = "Idpuesto"
        Me.colIdPuesto.Name = "colIdPuesto"
        Me.colIdPuesto.ReadOnly = True
        Me.colIdPuesto.Visible = False
        Me.colIdPuesto.Width = 5
        '
        'colSueldoBase
        '
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle17.Format = "N2"
        DataGridViewCellStyle17.NullValue = Nothing
        Me.colSueldoBase.DefaultCellStyle = DataGridViewCellStyle17
        Me.colSueldoBase.HeaderText = "Sueldo Base"
        Me.colSueldoBase.MinimumWidth = 70
        Me.colSueldoBase.Name = "colSueldoBase"
        Me.colSueldoBase.ReadOnly = True
        Me.colSueldoBase.Width = 70
        '
        'colBonificacion
        '
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle18.Format = "N2"
        DataGridViewCellStyle18.NullValue = Nothing
        Me.colBonificacion.DefaultCellStyle = DataGridViewCellStyle18
        Me.colBonificacion.HeaderText = "Bonificacion"
        Me.colBonificacion.MinimumWidth = 70
        Me.colBonificacion.Name = "colBonificacion"
        Me.colBonificacion.ReadOnly = True
        Me.colBonificacion.Width = 70
        '
        'colSueldo
        '
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle19.Format = "N2"
        DataGridViewCellStyle19.NullValue = Nothing
        Me.colSueldo.DefaultCellStyle = DataGridViewCellStyle19
        Me.colSueldo.HeaderText = "Sueldo {tipo}"
        Me.colSueldo.MinimumWidth = 60
        Me.colSueldo.Name = "colSueldo"
        Me.colSueldo.ReadOnly = True
        Me.colSueldo.Width = 60
        '
        'colbonif
        '
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle20.Format = "N2"
        DataGridViewCellStyle20.NullValue = Nothing
        Me.colbonif.DefaultCellStyle = DataGridViewCellStyle20
        Me.colbonif.HeaderText = "Bonficacion 78-89 {tipo}"
        Me.colbonif.MinimumWidth = 70
        Me.colbonif.Name = "colbonif"
        Me.colbonif.ReadOnly = True
        Me.colbonif.Width = 70
        '
        'colhoras
        '
        DataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle21.Format = "N2"
        DataGridViewCellStyle21.NullValue = Nothing
        Me.colhoras.DefaultCellStyle = DataGridViewCellStyle21
        Me.colhoras.HeaderText = "Horas Extra"
        Me.colhoras.MinimumWidth = 60
        Me.colhoras.Name = "colhoras"
        Me.colhoras.Width = 60
        '
        'colboni2
        '
        DataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle22.Format = "N2"
        DataGridViewCellStyle22.NullValue = Nothing
        Me.colboni2.DefaultCellStyle = DataGridViewCellStyle22
        Me.colboni2.HeaderText = "Bonificación Incentivo"
        Me.colboni2.MinimumWidth = 70
        Me.colboni2.Name = "colboni2"
        Me.colboni2.Width = 70
        '
        'colTotalEmpleado
        '
        Me.colTotalEmpleado.HeaderText = "Total "
        Me.colTotalEmpleado.MinimumWidth = 70
        Me.colTotalEmpleado.Name = "colTotalEmpleado"
        Me.colTotalEmpleado.ReadOnly = True
        Me.colTotalEmpleado.Width = 70
        '
        'colIgss
        '
        DataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle23.Format = "N2"
        DataGridViewCellStyle23.NullValue = Nothing
        Me.colIgss.DefaultCellStyle = DataGridViewCellStyle23
        Me.colIgss.HeaderText = "IGSS"
        Me.colIgss.MinimumWidth = 50
        Me.colIgss.Name = "colIgss"
        Me.colIgss.ReadOnly = True
        Me.colIgss.Width = 50
        '
        'colisr
        '
        DataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle24.Format = "N2"
        DataGridViewCellStyle24.NullValue = "0"
        Me.colisr.DefaultCellStyle = DataGridViewCellStyle24
        Me.colisr.HeaderText = "Retencion ISR"
        Me.colisr.MinimumWidth = 50
        Me.colisr.Name = "colisr"
        Me.colisr.Width = 50
        '
        'colPrestamo
        '
        DataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle25.Format = "N2"
        DataGridViewCellStyle25.NullValue = Nothing
        Me.colPrestamo.DefaultCellStyle = DataGridViewCellStyle25
        Me.colPrestamo.HeaderText = "Préstamo"
        Me.colPrestamo.MinimumWidth = 55
        Me.colPrestamo.Name = "colPrestamo"
        Me.colPrestamo.Width = 55
        '
        'coladelanto
        '
        DataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle26.Format = "N2"
        DataGridViewCellStyle26.NullValue = Nothing
        Me.coladelanto.DefaultCellStyle = DataGridViewCellStyle26
        Me.coladelanto.HeaderText = "Adelanto"
        Me.coladelanto.MinimumWidth = 50
        Me.coladelanto.Name = "coladelanto"
        Me.coladelanto.Width = 50
        '
        'colotros
        '
        DataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        DataGridViewCellStyle27.Format = "N2"
        DataGridViewCellStyle27.NullValue = Nothing
        Me.colotros.DefaultCellStyle = DataGridViewCellStyle27
        Me.colotros.HeaderText = "Otros Descuentos"
        Me.colotros.MinimumWidth = 65
        Me.colotros.Name = "colotros"
        Me.colotros.Width = 65
        '
        'parqueo
        '
        Me.parqueo.HeaderText = "Parqueo"
        Me.parqueo.MinimumWidth = 70
        Me.parqueo.Name = "parqueo"
        Me.parqueo.Width = 70
        '
        'TDescuento
        '
        Me.TDescuento.HeaderText = "Total Descuentos"
        Me.TDescuento.MinimumWidth = 70
        Me.TDescuento.Name = "TDescuento"
        Me.TDescuento.ReadOnly = True
        Me.TDescuento.Width = 70
        '
        'Suspendido
        '
        Me.Suspendido.HeaderText = "Suspendido"
        Me.Suspendido.MinimumWidth = 70
        Me.Suspendido.Name = "Suspendido"
        Me.Suspendido.ReadOnly = True
        Me.Suspendido.Width = 70
        '
        'Dias
        '
        Me.Dias.HeaderText = "Dias"
        Me.Dias.MinimumWidth = 70
        Me.Dias.Name = "Dias"
        Me.Dias.ReadOnly = True
        Me.Dias.Width = 70
        '
        'Suspenidos
        '
        Me.Suspenidos.HeaderText = "Suspendidos"
        Me.Suspenidos.MinimumWidth = 70
        Me.Suspenidos.Name = "Suspenidos"
        Me.Suspenidos.ReadOnly = True
        Me.Suspenidos.Width = 70
        '
        'Laborados
        '
        Me.Laborados.HeaderText = "Laborados"
        Me.Laborados.MinimumWidth = 70
        Me.Laborados.Name = "Laborados"
        Me.Laborados.ReadOnly = True
        Me.Laborados.Width = 70
        '
        'mesSalario
        '
        Me.mesSalario.HeaderText = "Monto a Pagar"
        Me.mesSalario.MinimumWidth = 70
        Me.mesSalario.Name = "mesSalario"
        Me.mesSalario.ReadOnly = True
        Me.mesSalario.Width = 70
        '
        'coltotal
        '
        DataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle28.Format = "N2"
        DataGridViewCellStyle28.NullValue = Nothing
        Me.coltotal.DefaultCellStyle = DataGridViewCellStyle28
        Me.coltotal.HeaderText = "Total a Pagar"
        Me.coltotal.MinimumWidth = 50
        Me.coltotal.Name = "coltotal"
        Me.coltotal.ReadOnly = True
        Me.coltotal.Width = 50
        '
        'panelControlLista
        '
        Me.panelControlLista.Controls.Add(Me.ListaPlanillas)
        Me.panelControlLista.Controls.Add(Me.botonQuitar)
        Me.panelControlLista.Controls.Add(Me.botonAgregar)
        Me.panelControlLista.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelControlLista.Location = New System.Drawing.Point(1037, 107)
        Me.panelControlLista.Name = "panelControlLista"
        Me.panelControlLista.Size = New System.Drawing.Size(65, 432)
        Me.panelControlLista.TabIndex = 2
        '
        'ListaPlanillas
        '
        Me.ListaPlanillas.AllowUserToAddRows = False
        Me.ListaPlanillas.AllowUserToDeleteRows = False
        Me.ListaPlanillas.AllowUserToOrderColumns = True
        Me.ListaPlanillas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ListaPlanillas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaPlanillas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaPlanillas.Location = New System.Drawing.Point(6, 247)
        Me.ListaPlanillas.MultiSelect = False
        Me.ListaPlanillas.Name = "ListaPlanillas"
        Me.ListaPlanillas.ReadOnly = True
        Me.ListaPlanillas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaPlanillas.Size = New System.Drawing.Size(51, 41)
        Me.ListaPlanillas.TabIndex = 18
        Me.ListaPlanillas.Visible = False
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonQuitar.Location = New System.Drawing.Point(6, 45)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(52, 35)
        Me.botonQuitar.TabIndex = 1
        Me.botonQuitar.Text = "Quitar"
        Me.botonQuitar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAgregar.Location = New System.Drawing.Point(6, 4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(52, 35)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.Text = "Agregar"
        Me.botonAgregar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.btnRecibo)
        Me.panelEncabezado.Controls.Add(Me.txtDescripcionPL)
        Me.panelEncabezado.Controls.Add(Me.bntDescrp)
        Me.panelEncabezado.Controls.Add(Me.chkigss)
        Me.panelEncabezado.Controls.Add(Me.btncsv)
        Me.panelEncabezado.Controls.Add(Me.lblcodt)
        Me.panelEncabezado.Controls.Add(Me.btnRango)
        Me.panelEncabezado.Controls.Add(Me.txtTipo)
        Me.panelEncabezado.Controls.Add(Me.Label7)
        Me.panelEncabezado.Controls.Add(Me.Inicio)
        Me.panelEncabezado.Controls.Add(Me.dtpFinalPlanilla)
        Me.panelEncabezado.Controls.Add(Me.dtpInicioPlanilla)
        Me.panelEncabezado.Controls.Add(Me.celdaFactor)
        Me.panelEncabezado.Controls.Add(Me.celdaTipo)
        Me.panelEncabezado.Controls.Add(Me.Label6)
        Me.panelEncabezado.Controls.Add(Me.ComboTipo)
        Me.panelEncabezado.Controls.Add(Me.Label5)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.ComboMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaTotal)
        Me.panelEncabezado.Controls.Add(Me.celdaCodigo)
        Me.panelEncabezado.Controls.Add(Me.celdaAño)
        Me.panelEncabezado.Controls.Add(Me.celdaID)
        Me.panelEncabezado.Controls.Add(Me.Label4)
        Me.panelEncabezado.Controls.Add(Me.Label3)
        Me.panelEncabezado.Controls.Add(Me.Label2)
        Me.panelEncabezado.Controls.Add(Me.Label1)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1102, 107)
        Me.panelEncabezado.TabIndex = 0
        '
        'btnRecibo
        '
        Me.btnRecibo.Location = New System.Drawing.Point(620, 71)
        Me.btnRecibo.Name = "btnRecibo"
        Me.btnRecibo.Size = New System.Drawing.Size(130, 23)
        Me.btnRecibo.TabIndex = 19
        Me.btnRecibo.Text = "Generar Recibo"
        Me.btnRecibo.UseVisualStyleBackColor = True
        '
        'txtDescripcionPL
        '
        Me.txtDescripcionPL.Location = New System.Drawing.Point(87, 68)
        Me.txtDescripcionPL.Name = "txtDescripcionPL"
        Me.txtDescripcionPL.Size = New System.Drawing.Size(373, 20)
        Me.txtDescripcionPL.TabIndex = 18
        '
        'bntDescrp
        '
        Me.bntDescrp.AutoSize = True
        Me.bntDescrp.Location = New System.Drawing.Point(17, 76)
        Me.bntDescrp.Name = "bntDescrp"
        Me.bntDescrp.Size = New System.Drawing.Size(63, 13)
        Me.bntDescrp.TabIndex = 17
        Me.bntDescrp.Text = "Descripcion"
        '
        'chkigss
        '
        Me.chkigss.AutoSize = True
        Me.chkigss.Location = New System.Drawing.Point(821, 40)
        Me.chkigss.Name = "chkigss"
        Me.chkigss.Size = New System.Drawing.Size(76, 17)
        Me.chkigss.TabIndex = 16
        Me.chkigss.Text = "Desc. Igss"
        Me.chkigss.UseVisualStyleBackColor = True
        '
        'btncsv
        '
        Me.btncsv.Location = New System.Drawing.Point(508, 71)
        Me.btncsv.Name = "btncsv"
        Me.btncsv.Size = New System.Drawing.Size(95, 23)
        Me.btncsv.TabIndex = 15
        Me.btncsv.Text = "Generar CSV"
        Me.btncsv.UseVisualStyleBackColor = True
        '
        'lblcodt
        '
        Me.lblcodt.AutoSize = True
        Me.lblcodt.Location = New System.Drawing.Point(307, 16)
        Me.lblcodt.Name = "lblcodt"
        Me.lblcodt.Size = New System.Drawing.Size(0, 13)
        Me.lblcodt.TabIndex = 14
        Me.lblcodt.Visible = False
        '
        'btnRango
        '
        Me.btnRango.Location = New System.Drawing.Point(293, 31)
        Me.btnRango.Name = "btnRango"
        Me.btnRango.Size = New System.Drawing.Size(56, 23)
        Me.btnRango.TabIndex = 13
        Me.btnRango.Text = "Tipo"
        Me.btnRango.UseVisualStyleBackColor = True
        '
        'txtTipo
        '
        Me.txtTipo.Location = New System.Drawing.Point(212, 33)
        Me.txtTipo.Name = "txtTipo"
        Me.txtTipo.Size = New System.Drawing.Size(86, 20)
        Me.txtTipo.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(428, 45)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Fin"
        '
        'Inicio
        '
        Me.Inicio.AutoSize = True
        Me.Inicio.Location = New System.Drawing.Point(428, 16)
        Me.Inicio.Name = "Inicio"
        Me.Inicio.Size = New System.Drawing.Size(32, 13)
        Me.Inicio.TabIndex = 11
        Me.Inicio.Text = "Inicio"
        '
        'dtpFinalPlanilla
        '
        Me.dtpFinalPlanilla.Location = New System.Drawing.Point(466, 37)
        Me.dtpFinalPlanilla.Name = "dtpFinalPlanilla"
        Me.dtpFinalPlanilla.Size = New System.Drawing.Size(200, 20)
        Me.dtpFinalPlanilla.TabIndex = 10
        '
        'dtpInicioPlanilla
        '
        Me.dtpInicioPlanilla.CustomFormat = ""
        Me.dtpInicioPlanilla.Location = New System.Drawing.Point(466, 11)
        Me.dtpInicioPlanilla.Name = "dtpInicioPlanilla"
        Me.dtpInicioPlanilla.Size = New System.Drawing.Size(200, 20)
        Me.dtpInicioPlanilla.TabIndex = 9
        '
        'celdaFactor
        '
        Me.celdaFactor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFactor.Location = New System.Drawing.Point(1066, 46)
        Me.celdaFactor.Name = "celdaFactor"
        Me.celdaFactor.ReadOnly = True
        Me.celdaFactor.Size = New System.Drawing.Size(33, 20)
        Me.celdaFactor.TabIndex = 8
        Me.celdaFactor.Text = "1"
        '
        'celdaTipo
        '
        Me.celdaTipo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTipo.Location = New System.Drawing.Point(1066, 25)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.ReadOnly = True
        Me.celdaTipo.Size = New System.Drawing.Size(33, 20)
        Me.celdaTipo.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(209, 11)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Tipo de Planilla"
        '
        'ComboTipo
        '
        Me.ComboTipo.FormattingEnabled = True
        Me.ComboTipo.Location = New System.Drawing.Point(862, 10)
        Me.ComboTipo.Name = "ComboTipo"
        Me.ComboTipo.Size = New System.Drawing.Size(92, 21)
        Me.ComboTipo.TabIndex = 5
        Me.ComboTipo.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(352, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Moneda"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMoneda.Location = New System.Drawing.Point(1066, 4)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(33, 20)
        Me.celdaMoneda.TabIndex = 3
        '
        'ComboMoneda
        '
        Me.ComboMoneda.FormattingEnabled = True
        Me.ComboMoneda.Location = New System.Drawing.Point(355, 33)
        Me.ComboMoneda.Name = "ComboMoneda"
        Me.ComboMoneda.Size = New System.Drawing.Size(58, 21)
        Me.ComboMoneda.TabIndex = 2
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.Location = New System.Drawing.Point(939, 35)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(98, 20)
        Me.celdaTotal.TabIndex = 1
        Me.celdaTotal.Text = "0.00"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Location = New System.Drawing.Point(126, 33)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(66, 20)
        Me.celdaCodigo.TabIndex = 1
        Me.celdaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(63, 35)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(54, 20)
        Me.celdaAño.TabIndex = 1
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaID
        '
        Me.celdaID.Location = New System.Drawing.Point(9, 35)
        Me.celdaID.Name = "celdaID"
        Me.celdaID.ReadOnly = True
        Me.celdaID.Size = New System.Drawing.Size(54, 20)
        Me.celdaID.TabIndex = 1
        Me.celdaID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(986, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Total"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(123, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Código"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Año"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Correlativo"
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonInprimir.Location = New System.Drawing.Point(202, 9)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 45)
        Me.botonInprimir.TabIndex = 18
        Me.botonInprimir.Text = "Imprimir"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'pnlPlanillas
        '
        Me.pnlPlanillas.Controls.Add(Me.dgPlanilla)
        Me.pnlPlanillas.Controls.Add(Me.Panel1)
        Me.pnlPlanillas.Location = New System.Drawing.Point(1159, 115)
        Me.pnlPlanillas.Name = "pnlPlanillas"
        Me.pnlPlanillas.Size = New System.Drawing.Size(73, 474)
        Me.pnlPlanillas.TabIndex = 19
        '
        'dgPlanilla
        '
        Me.dgPlanilla.AllowUserToAddRows = False
        Me.dgPlanilla.AllowUserToDeleteRows = False
        Me.dgPlanilla.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPlanilla.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgPlanilla.Location = New System.Drawing.Point(0, 117)
        Me.dgPlanilla.Name = "dgPlanilla"
        Me.dgPlanilla.ReadOnly = True
        Me.dgPlanilla.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPlanilla.Size = New System.Drawing.Size(73, 357)
        Me.dgPlanilla.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.btnFiltrar)
        Me.Panel1.Controls.Add(Me.chkRango)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Del)
        Me.Panel1.Controls.Add(Me.FinPlanilla)
        Me.Panel1.Controls.Add(Me.InicioPlanilla)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(73, 117)
        Me.Panel1.TabIndex = 1
        '
        'btnFiltrar
        '
        Me.btnFiltrar.Location = New System.Drawing.Point(483, 31)
        Me.btnFiltrar.Name = "btnFiltrar"
        Me.btnFiltrar.Size = New System.Drawing.Size(75, 23)
        Me.btnFiltrar.TabIndex = 5
        Me.btnFiltrar.Text = "Filtrar"
        Me.btnFiltrar.UseVisualStyleBackColor = True
        '
        'chkRango
        '
        Me.chkRango.AutoSize = True
        Me.chkRango.Location = New System.Drawing.Point(16, 27)
        Me.chkRango.Name = "chkRango"
        Me.chkRango.Size = New System.Drawing.Size(58, 17)
        Me.chkRango.TabIndex = 4
        Me.chkRango.Text = "Rango"
        Me.chkRango.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(105, 54)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(16, 13)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Al"
        '
        'Del
        '
        Me.Del.AutoSize = True
        Me.Del.Location = New System.Drawing.Point(98, 31)
        Me.Del.Name = "Del"
        Me.Del.Size = New System.Drawing.Size(23, 13)
        Me.Del.TabIndex = 2
        Me.Del.Text = "Del"
        '
        'FinPlanilla
        '
        Me.FinPlanilla.Location = New System.Drawing.Point(141, 50)
        Me.FinPlanilla.Name = "FinPlanilla"
        Me.FinPlanilla.Size = New System.Drawing.Size(200, 20)
        Me.FinPlanilla.TabIndex = 1
        '
        'InicioPlanilla
        '
        Me.InicioPlanilla.Location = New System.Drawing.Point(139, 26)
        Me.InicioPlanilla.Name = "InicioPlanilla"
        Me.InicioPlanilla.Size = New System.Drawing.Size(200, 20)
        Me.InicioPlanilla.TabIndex = 0
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1372, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmPPlanilla
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1372, 691)
        Me.Controls.Add(Me.pnlPlanillas)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.panelPrincipal)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmPPlanilla"
        Me.Text = "Planilla"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.panelPrincipal.ResumeLayout(False)
        CType(Me.ListaEmpleados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelControlLista.ResumeLayout(False)
        CType(Me.ListaPlanillas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.pnlPlanillas.ResumeLayout(False)
        CType(Me.dgPlanilla, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CeldaTitulo As System.Windows.Forms.Label
    Friend WithEvents panelPrincipal As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents celdaID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents ListaEmpleados As System.Windows.Forms.DataGridView
    Friend WithEvents panelControlLista As System.Windows.Forms.Panel
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents ComboMoneda As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents celdaTipo As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents celdaFactor As System.Windows.Forms.TextBox
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Inicio As System.Windows.Forms.Label
    Friend WithEvents dtpFinalPlanilla As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicioPlanilla As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnRango As System.Windows.Forms.Button
    Friend WithEvents txtTipo As System.Windows.Forms.TextBox
    Friend WithEvents ComboTipo As System.Windows.Forms.ComboBox
    Friend WithEvents pnlPlanillas As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dgPlanilla As System.Windows.Forms.DataGridView
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Del As System.Windows.Forms.Label
    Friend WithEvents FinPlanilla As System.Windows.Forms.DateTimePicker
    Friend WithEvents InicioPlanilla As System.Windows.Forms.DateTimePicker
    Friend WithEvents chkRango As System.Windows.Forms.CheckBox
    Friend WithEvents btnFiltrar As System.Windows.Forms.Button
    Friend WithEvents ListaPlanillas As System.Windows.Forms.DataGridView
    Friend WithEvents lblcodt As System.Windows.Forms.Label
    Friend WithEvents CodigoEmp As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents AñoContrato As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colContrato As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPuesto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colIdPuesto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSueldoBase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBonificacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSueldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colbonif As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colhoras As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colboni2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotalEmpleado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colIgss As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colisr As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrestamo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents coladelanto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colotros As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents parqueo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TDescuento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Suspendido As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dias As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Suspenidos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Laborados As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents mesSalario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents coltotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btncsv As System.Windows.Forms.Button
    Friend WithEvents chkigss As System.Windows.Forms.CheckBox
    Friend WithEvents txtDescripcionPL As System.Windows.Forms.TextBox
    Friend WithEvents bntDescrp As System.Windows.Forms.Label
    Friend WithEvents btnRecibo As System.Windows.Forms.Button
End Class
