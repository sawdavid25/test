﻿Public Class frmPDepartamentos
    Dim cNomina As New ClsNomina
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#Region "Funciones y Procedimientos"

    Private Sub Reset()
        celdaCodigo.Text = -1
        celdaDescripcion.Text = ""
    End Sub

    Private Sub BloquerBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            botonBorrar.Enabled = False
            botonGuardar.Enabled = False
        Else
            botonBorrar.Enabled = True
            botonGuardar.Enabled = True
        End If
       
    End Sub

    Private Sub MostrarLista(Optional ByVal log As Boolean = True)
        Dim strSQL As String = ""
        If log = True Then
            listaDepartamentos.Visible = True
            listaDepartamentos.Dock = DockStyle.Fill
            strSQL = "SELECT dep_no Codigo, dep_descripcion Descripcion FROM Departamentos WHERE dep_sisemp={0} ORDER BY dep_no"
            strSQL = Replace(strSQL, "{0}", Sesion.IdEmpresa)
            cNomina.CargarLista(listaDepartamentos, strSQL)
            CeldaTitulo.Text = "Departamentos"
            Reset()
            BloquerBotones()
        Else
            listaDepartamentos.Visible = False
            listaDepartamentos.Dock = DockStyle.None
            CeldaTitulo.Text = "Modificar Registro"
            BloquerBotones(False)
        End If
    End Sub

    Private Sub SelecionarDepto()
        If logConsultar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If listaDepartamentos.SelectedRows.Count = 0 Then Exit Sub
        celdaCodigo.Text = listaDepartamentos.SelectedCells(0).Value
        celdaDescripcion.Text = listaDepartamentos.SelectedCells(1).Value
        MostrarLista(False)
        Me.Tag = "mod"
    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim logok As Boolean = False
        If celdaCodigo.Text.Length > 0 And celdaDescripcion.Text.Length > 0 Then
            logok = True
            celdaDescripcion.BackColor = Color.White
            celdaCodigo.BackColor = Color.White
        Else
            MsgBox("Todos los campos son obligatorios", MsgBoxStyle.Exclamation)
            celdaDescripcion.BackColor = Color.Coral
            celdaCodigo.BackColor = Color.Coral
        End If
        Return logok
    End Function

#End Region

    Private Sub frmPDepartamentos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmPDepartamentos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    MostrarLista()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        If listaDepartamentos.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        Reset()
        MostrarLista(False)
        ' Permisos()
        Me.Tag = "nuevo"
    End Sub

    Private Sub listaDepartamentos_DoubleClick(sender As Object, e As EventArgs) Handles listaDepartamentos.DoubleClick
        SelecionarDepto()
    End Sub

    Private Sub listaDepartamentos_KeyDown(sender As Object, e As KeyEventArgs) Handles listaDepartamentos.KeyDown
        If e.KeyCode = Keys.Enter Then
            SelecionarDepto()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        If LogBorrar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If Me.Tag = "mod" Then
            Try
                If cNomina.BorrarDepartamento(CInt(celdaCodigo.Text), celdaDescripcion.Text) = True Then
                    MostrarLista()
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        Dim logInsert As Boolean = False
        If Me.Tag = "nuevo" Then
            If logInsertar = False Then
                MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                Exit Sub
            End If
            logInsert = True
        Else
            If logEditar = False Then
                MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                Exit Sub
            End If
            logInsert = False
        End If
        If ComprobarCampos() = True Then
            If cNomina.GuardarDepartamento(CInt(celdaCodigo.Text), celdaDescripcion.Text, logInsert) = True Then
                If logInsert = True Then
                    MsgBox("Departamento agregado correctamente")
                Else : MsgBox("Departamento actualizado correctamente")
                End If
                MostrarLista()
            End If
        End If
    End Sub

End Class