﻿Public Class frmPPuestos
    Dim cNomina As New ClsNomina
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#Region "Funciones y Procedimientos"

    Private Sub Reset()
        CeldaId.Text = NO_FILA
        celdaDescripcion.Text = STR_VACIO
        celdaSbase.Text = STR_CERO_MONEDA
        celdaBono.Text = STR_CERO_MONEDA
        celdaBonificacion.Text = "250.00"
        comboMoneda.Items.Clear()
    End Sub

    Private Sub MostrarLista(Optional ByVal log As Boolean = True)
        Dim strSQL As String = ""
        If log = True Then
            listaPuestos.Visible = True
            listaPuestos.Dock = DockStyle.Fill
            strSQL = "SELECT pue_codigo, pue_descripcion, pue_base, pue_bono1, pue_bono2 " & _
            "FROM Puestos WHERE pue_sisemp={0} ORDER BY pue_codigo"
            strSQL = Replace(strSQL, "{0}", Sesion.IdEmpresa)
            cNomina.CargarLista(listaPuestos, strSQL)
            CeldaTitulo.Text = "Puestos"
            Reset()
            BloquearBotones()
            listaPuestos.Focus()
        Else
            listaPuestos.Visible = False
            listaPuestos.Dock = DockStyle.None
            CeldaTitulo.Text = "Modificar Registro"
            cFunciones.CargarCombo(comboMoneda, "Catalogos", "cat_desc", "cat_num", " cat_clase= 'Monedas'")
            celdaDescripcion.Focus()
            BloquearBotones(False)
        End If
    End Sub

    Private Sub SelecionarPuesto()
        If logConsultar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If listaPuestos.SelectedRows.Count = 0 Then Exit Sub
        CeldaId.Text = listaPuestos.SelectedCells(0).Value
        celdaDescripcion.Text = listaPuestos.SelectedCells(1).Value
        celdaSbase.Text = listaPuestos.SelectedCells(2).Value
        celdaBonificacion.Text = listaPuestos.SelectedCells(3).Value
        celdaBono.Text = listaPuestos.SelectedCells(4).Value
        MostrarLista(False)
        Me.Tag = "mod"
    End Sub

    Private Sub BloquearBotones(Optional logBloquear As Boolean = True)
        If logBloquear = True Then
            botonBorrar.Enabled = False
            botonGuardar.Enabled = False
        Else
            botonBorrar.Enabled = True
            botonGuardar.Enabled = True
        End If
    End Sub

#End Region

    Private Sub frmPPuestos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmPPuestos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    MostrarLista()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        If listaPuestos.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        Reset()
        MostrarLista(False)
        ' Permisos()
        Me.Tag = "nuevo"
    End Sub

    Private Sub listaPuestos_DoubleClick(sender As Object, e As EventArgs) Handles listaPuestos.DoubleClick
        SelecionarPuesto()
    End Sub

    Private Sub listaPuestos_KeyDown(sender As Object, e As KeyEventArgs) Handles listaPuestos.KeyDown
        If e.KeyCode = Keys.Enter Then
            SelecionarPuesto()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub celdaSbase_LostFocus(sender As Object, e As EventArgs) Handles celdaSbase.LostFocus
        cFunciones.ValidarCampoNumerico(celdaSbase)
    End Sub

    Private Sub celdaBono_LostFocus(sender As Object, e As EventArgs) Handles celdaBono.LostFocus
        cFunciones.ValidarCampoNumerico(celdaBono)
    End Sub

    Private Sub celdaBonificacion_LostFocus(sender As Object, e As EventArgs) Handles celdaBonificacion.LostFocus
        cFunciones.ValidarCampoNumerico(celdaBonificacion)
    End Sub

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        If LogBorrar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If Me.Tag = "mod" Then
            Try
                If cNomina.BorrarDepartamento(CInt(CeldaId.Text), celdaDescripcion.Text) = True Then
                    MostrarLista()
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        Dim cNomina As New clsPuesto
        cNomina.PUE_BASE = celdaSbase.Text
        cNomina.PUE_DESCRIPCION = celdaDescripcion.Text
        cNomina.PUE_BONO1 = celdaBonificacion.Text
        cNomina.PUE_BONO2 = celdaBono.Text
        cNomina.PUE_MONEDA = 1
        cNomina.PUE_SISEMP = Sesion.IdEmpresa
        cNomina.PUE_SISTEMA = "Guest"
        Try
            cNomina.CONEXION = strConexion
            If Me.Tag = "nuevo" Then
                If logInsertar = False Then
                    MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                    Exit Sub
                End If
                If cNomina.Guardar() = False Then
                    MsgBox(cNomina.MERROR.ToString)
                Else
                    MostrarLista()
                End If
            Else
                If logEditar = False Then
                    MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                    Exit Sub
                End If
                cNomina.PUE_CODIGO = CeldaId.Text
                If cNomina.Actuallizar() = False Then
                    MsgBox(cNomina.MERROR.ToString)
                Else
                    MostrarLista()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        
    End Sub
End Class