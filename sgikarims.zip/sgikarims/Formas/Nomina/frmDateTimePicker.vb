﻿Public Class frmDateTimePicker

#Region "Variables"
    Dim Hora As Boolean
    Dim strLLave As Date
    Dim CodInv As Boolean
    Dim intLlave As Integer

#End Region

#Region "Propiedades"
    Public Property LLave As String
        Get
            Return strLLave
        End Get
        Set(value As String)
            strLLave = value
        End Set
    End Property
    Public Property Tiempo As Boolean
        Get
            Return Hora
        End Get
        Set(value As Boolean)
            Hora = value
        End Set
    End Property

    Public Property LLaveCod As Integer
        Get
            Return intLlave
        End Get
        Set(value As Integer)
            intLlave = value
        End Set
    End Property

    Public Property CodigosInv As Boolean
        Get
            Return CodInv
        End Get
        Set(value As Boolean)
            CodInv = value
        End Set
    End Property
#End Region

#Region "Funciones"
    Private Sub frmDateTimePicker_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'ShowDialog(Me)

    End Sub

    Private Sub Seleccionar()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Dim intSemana As Integer = INT_CERO
        Try
            If Tiempo = True Then
                strLLave = DateTimePicker1.Value.ToString("hh:mm:ss")
            Else
                strLLave = DateTimePicker1.Value.Date
            End If
            'DateTimePicker1.sh

            If CodigosInv = True Then
                Try

                    intSemana = DatePart(DateInterval.WeekOfYear, DateTimePicker1.Value)

                    LLaveCod = intSemana

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
    End Sub

    Private Sub botonSeleccionar_Click(sender As Object, e As EventArgs) Handles botonSeleccionar.Click
        Seleccionar()
    End Sub

    Private Sub botonCancelar_Click(sender As Object, e As EventArgs) Handles botonCancelar.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End Sub
#End Region

    Private Sub botonSeleccionar_KeyDown(sender As Object, e As KeyEventArgs) Handles botonSeleccionar.KeyDown
        Seleccionar()
    End Sub
End Class