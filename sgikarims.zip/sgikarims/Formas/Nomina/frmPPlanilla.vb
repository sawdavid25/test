﻿Imports System
Imports System.IO
'Imports Microsoft.Office.Core
'Imports Microsoft.Office.Interop.Excel
Imports System.Data

Public Class frmPPlanilla
    Dim strkey As String = STR_VACIO
    Dim cfun As New clsFunciones
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const INT_CATALOGO As Integer = 882
    Dim BonificacionLey As Double = 250.0

    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#Region "Funciones y Procedimientos Locales"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonInprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            botonInprimir.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If
    End Sub

    Private Sub MostrarLista(Optional logMostrar As Boolean = True)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT HDoc_Doc_Num ID, HDoc_Doc_Ano Ano, HDoc_Doc_Fec Fecha, HDoc_Emp_Per Codigo," & _
            " FORMAT(HDoc_RF1_Dbl,2) Total, HDoc_Usuario Usuario " & _
            " FROM Dcmtos_HDR " & _
            " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {cat} ORDER BY HDoc_Doc_Fec DESC LIMIT 24"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", INT_CATALOGO)

        If logMostrar = True Then
            BloquearBotones()
            panelPrincipal.Dock = DockStyle.None
            panelPrincipal.Visible = False
            ListaPlanillas.Dock = DockStyle.Fill
            ListaPlanillas.Visible = False
            CeldaTitulo.Text = "Listado de Planillas"
            cFunciones.CargarLista(ListaPlanillas, strSQL)
            Me.Tag = ""
        Else
            BloquearBotones(False)
            ListaPlanillas.Dock = DockStyle.None
            ListaPlanillas.Visible = False
            panelPrincipal.Dock = DockStyle.Fill
            panelPrincipal.Visible = True
        End If
    End Sub

    Private Sub Reset()
        celdaID.Text = NO_FILA
        celdaAño.Text = NO_FILA
        celdaCodigo.Text = STR_VACIO
        ListaEmpleados.Rows.Clear()
        'celdaTotal.Text = STR_CERO_MONEDA
    End Sub

    Private Function ComprobarCampos() As Boolean
        ComprobarCampos = True
    End Function

    Private Function Guardar(Optional ByVal Tipo As Integer = 856) As Boolean
        Guardar = False

        BuscarPlanilla()

        If BuscarPlanilla() = 0 Then
            Dim cPlanilla As New clsPlanilla
            Try
                If ValidarValores() = True Then
                    celdaTotal.Text = TotalPlanilla()
                    cPlanilla.MonedaPlanilla = celdaMoneda.Text
                    cPlanilla.IDTipo = celdaTipo.Text
                    cPlanilla.TipoPlanilla = txtTipo.Text
                    cPlanilla.TotalPlanilla = celdaTotal.Text
                    cPlanilla.FechaInicioP = dtpInicioPlanilla.Value
                    cPlanilla.FechaFinP = dtpFinalPlanilla.Value
                    cPlanilla.Descripcion = txtDescripcionPL.Text
                    If Tipo = 856 Then
                        cPlanilla.Bonificacion = BonificacionLey
                    Else
                        cPlanilla.Bonificacion = BonificacionLey / 2
                    End If

                    If cPlanilla.GuardarEncabezado = True Then
                        For i As Integer = 0 To ListaEmpleados.Rows.Count - 1
                            cPlanilla.IDEmpleado = CInt(ListaEmpleados.Rows(i).Cells("CodigoEmp").Value)
                            cPlanilla.ContratoAño = CInt(ListaEmpleados.Rows(i).Cells("AñoContrato").Value)
                            cPlanilla.PIDContrato = CInt(ListaEmpleados.Rows(i).Cells("colContrato").Value)
                            cPlanilla.Empleado = ListaEmpleados.Rows(i).Cells("colNombre").Value
                            cPlanilla.Puesto = ListaEmpleados.Rows(i).Cells("colPuesto").Value
                            cPlanilla.IDPuesto = ListaEmpleados.Rows(i).Cells("colIdPuesto").Value
                            cPlanilla.SueldoBase = CDbl(ListaEmpleados.Rows(i).Cells("colSueldoBase").Value)
                            'cPlanilla.Bonificacion = CDbl(ListaEmpleados.Rows(i).Cells("colBonificacion").Value)
                            cPlanilla.B7978 = CDbl(ListaEmpleados.Rows(i).Cells("colbonif").Value)
                            cPlanilla.ParqueoP = CDbl(ListaEmpleados.Rows(i).Cells("parqueo").Value)
                            cPlanilla.Bonificacion2 = CDbl(ListaEmpleados.Rows(i).Cells("colboni2").Value)
                            cPlanilla.HorasExtra = CDbl(ListaEmpleados.Rows(i).Cells("colhoras").Value)
                            cPlanilla.IGSS = CDbl(ListaEmpleados.Rows(i).Cells("colIgss").Value)
                            cPlanilla.ISR = CDbl(ListaEmpleados.Rows(i).Cells("colisr").Value)
                            cPlanilla.Prestamos = CDbl(ListaEmpleados.Rows(i).Cells("colPrestamo").Value)
                            cPlanilla.Adelantos = CDbl(ListaEmpleados.Rows(i).Cells("coladelanto").Value)
                            cPlanilla.Suspendido = ListaEmpleados.Rows(i).Cells("Suspendido").Value
                            cPlanilla.DSuspension = CInt(ListaEmpleados.Rows(i).Cells("Suspenidos").Value)
                            cPlanilla.DLaborados = CInt(ListaEmpleados.Rows(i).Cells("Laborados").Value)
                            cPlanilla.OtrosDescuentos = CDbl(ListaEmpleados.Rows(i).Cells("colotros").Value)
                            'cPlanilla.SueldoLiquido = CDbl(ListaEmpleados.Rows(i).Cells("coltotal").Value)
                            If cPlanilla.GuardarDetalle(i) = False Then
                                MsgBox("Error al guardar el empleado  :" & vbNewLine & cPlanilla.Empleado)
                                Exit Function
                            End If
                        Next
                        Guardar = True
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
            ListaPlanillas.Visible = False
        Else
            MsgBox("YA EXISTE")
        End If


    End Function

    Private Function Actualizar() As Boolean
        Actualizar = False
        Dim cPlanilla As New clsPlanilla
        Dim cEncabezado As New clsDcmtos_HDR
        Try
            If ValidarValores() = True Then
                cEncabezado.CONEXION = strConexion
                'If cEncabezado.Seleccionar("", "") = True Then

                cEncabezado.HDOC_DOC_MON = celdaMoneda.Text
                cEncabezado.HDOC_DR1_CAT = celdaTipo.Text
                cEncabezado.HDOC_DR1_NUM = ComboTipo.Text
                cEncabezado.HDOC_RF1_DBL = celdaTotal.Text
                cEncabezado.HDOC_DOC_NUM = celdaID.Text
                If cEncabezado.Actualizar = True Then
                    cPlanilla.Año = celdaAño.Text
                    cPlanilla.ID = celdaID.Text
                    cPlanilla.Codigo = celdaCodigo.Text
                    cPlanilla.ContratoID = 436
                    If cPlanilla.BorrarDetalle = True Then
                        If cPlanilla.BorrarPro Then
                            For i As Integer = 0 To ListaEmpleados.Rows.Count - 1
                                cPlanilla.IDEmpleado = CInt(ListaEmpleados.Rows(i).Cells("CodigoEmp").Value)
                                cPlanilla.ContratoAño = CInt(ListaEmpleados.Rows(i).Cells("AñoContrato").Value)
                                cPlanilla.PIDContrato = CInt(ListaEmpleados.Rows(i).Cells("colContrato").Value)
                                cPlanilla.Empleado = ListaEmpleados.Rows(i).Cells("colNombre").Value
                                cPlanilla.Puesto = ListaEmpleados.Rows(i).Cells("colPuesto").Value
                                cPlanilla.IDPuesto = ListaEmpleados.Rows(i).Cells("colIdPuesto").Value
                                cPlanilla.SueldoBase = CDbl(ListaEmpleados.Rows(i).Cells("colSueldoBase").Value)
                                cPlanilla.Bonificacion = CDbl(ListaEmpleados.Rows(i).Cells("colBonificacion").Value)
                                cPlanilla.Bonificacion2 = CDbl(ListaEmpleados.Rows(i).Cells("colboni2").Value)
                                cPlanilla.HorasExtra = CDbl(ListaEmpleados.Rows(i).Cells("colhoras").Value)
                                cPlanilla.B7978 = CDbl(ListaEmpleados.Rows(i).Cells("colbonif").Value)
                                cPlanilla.IGSS = CDbl(ListaEmpleados.Rows(i).Cells("colIgss").Value)
                                cPlanilla.ISR = CDbl(ListaEmpleados.Rows(i).Cells("colisr").Value)
                                cPlanilla.Prestamos = CDbl(ListaEmpleados.Rows(i).Cells("colPrestamo").Value)
                                cPlanilla.Adelantos = CDbl(ListaEmpleados.Rows(i).Cells("coladelanto").Value)
                                cPlanilla.Suspendido = ListaEmpleados.Rows(i).Cells("Suspendido").Value
                                cPlanilla.DSuspension = CInt(ListaEmpleados.Rows(i).Cells("Suspenidos").Value)
                                cPlanilla.DLaborados = CInt(ListaEmpleados.Rows(i).Cells("Laborados").Value)
                                cPlanilla.OtrosDescuentos = CDbl(ListaEmpleados.Rows(i).Cells("colotros").Value)
                                cPlanilla.SueldoLiquido = CDbl(ListaEmpleados.Rows(i).Cells("coltotal").Value)
                                If cPlanilla.GuardarDetalle(i) = False Then
                                    MsgBox("Error al guardar el empleado  :" & vbNewLine & cPlanilla.Empleado)
                                End If
                            Next
                        End If

                    End If
                    'End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function ValidarValores() As Boolean
        ValidarValores = True
        Try
            For i As Integer = 0 To ListaEmpleados.Rows.Count - 1
                If CStr(ListaEmpleados.Rows(i).Cells("colSueldo").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colSueldo").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colSueldo").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colSueldo").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colbonif").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colbonif").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colbonif").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colbonif").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colhoras").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colhoras").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colhoras").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colhoras").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colboni2").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colboni2").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colboni2").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colboni2").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colIgss").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colIgss").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colIgss").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colIgss").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("coladelanto").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("coladelanto").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("coladelanto").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("coladelanto").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colisr").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colisr").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colisr").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colisr").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colPrestamo").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colPrestamo").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colPrestamo").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colPrestamo").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
                If CStr(ListaEmpleados.Rows(i).Cells("colotros").Value) = STR_VACIO Then
                    ListaEmpleados.Rows(i).Cells("colotros").Value = Format(INT_CERO, FORMATO_MONEDA)
                ElseIf Not IsNumeric(ListaEmpleados.Rows(i).Cells("colotros").Value) Then
                    MsgBox("El valor debe ser numérico")
                    ListaEmpleados.Rows(i).Cells("colotros").Value = Format(INT_CERO, FORMATO_MONEDA)
                    ValidarValores = False
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function TotalPlanilla(Optional ByVal tipo As Integer = 856) As Double
        Dim dblSueldo As Double
        Dim dblBonificacion As Double
        Dim dblHoras As Double
        Dim dblBoni2 As Double
        Dim dblIgss As Double
        Dim dblAdelanto As Double
        Dim dblIsr As Double
        Dim dblPrestamo As Double
        Dim dblOtros As Double
        Dim dblTotal As Double
        Dim dblParque As Double
        Dim dblGranTotal As Double = INT_CERO
        Dim bonificacionincentivo As Double = INT_CERO
        Dim dblTotalIncentivos As Double = INT_CERO
        Dim dblTotalDescuentos As Double = INT_CERO

        Try
            For i As Integer = 0 To ListaEmpleados.Rows.Count - 1
                dblTotalIncentivos = INT_CERO
                dblSueldo = CDbl(ListaEmpleados.Rows(i).Cells("colSueldoBase").Value)
                dblBonificacion = CDbl(ListaEmpleados.Rows(i).Cells("colBonificacion").Value)
                dblBoni2 = CDbl(ListaEmpleados.Rows(i).Cells("colbonif").Value)
                dblHoras = CDbl(ListaEmpleados.Rows(i).Cells("colhoras").Value)
                bonificacionincentivo = CDbl(ListaEmpleados.Rows(i).Cells("colboni2").Value)
                dblIgss = CDbl(ListaEmpleados.Rows(i).Cells("colIgss").Value)
                dblAdelanto = CDbl(ListaEmpleados.Rows(i).Cells("coladelanto").Value)
                dblParque = CDbl(ListaEmpleados.Rows(i).Cells("parqueo").Value)
                dblIsr = CDbl(ListaEmpleados.Rows(i).Cells("colisr").Value)
                dblPrestamo = CDbl(ListaEmpleados.Rows(i).Cells("colPrestamo").Value)
                dblOtros = CDbl(ListaEmpleados.Rows(i).Cells("colotros").Value)
                dblTotalIncentivos = CDbl(dblSueldo + dblBonificacion + dblHoras + dblBoni2)
                dblTotalDescuentos = CDbl(dblIgss + dblAdelanto + dblIsr + dblPrestamo + dblOtros + dblParque)
                ListaEmpleados.Rows(i).Cells("colTotalEmpleado").Value = FormatNumber(dblTotalIncentivos, 2)
                ListaEmpleados.Rows(i).Cells("TDescuento").Value = dblTotalDescuentos
                dblTotal = dblSueldo + dblBonificacion + dblHoras + dblBoni2 + bonificacionincentivo - dblIgss - dblIsr - dblPrestamo - dblOtros - dblAdelanto - dblParque
                ListaEmpleados.Rows(i).Cells("mesSalario").Value = dblTotal
                ListaEmpleados.Rows(i).Cells("coltotal").Value = dblTotal
                dblGranTotal = dblGranTotal + dblTotal
            Next
        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try
        Return dblGranTotal

    End Function

    Public Function CalcIgss(ByVal empleado As Integer, ByVal fechaIPlanilla As String, ByVal fechaFPlanilla As Date) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection
        Dim REA As MySqlDataReader
        Dim Dia As Integer = INT_CERO
        Dim FechaIS As Date
        Dim FechaFS As Date
        Dim fechaPlanillaI As Date
        Dim fechaPlanillaF As Date


        fechaPlanillaI = fechaIPlanilla
        fechaPlanillaF = fechaFPlanilla

        strSQL = "SELECT date_format(Demp_Inicio,'%d/%m/%Y') InicioS,date_format(Demp_Fin,'%d/%m/%Y') FinS " & _
                 "FROM DTL_Empleados " & _
                 "WHERE Demp_Codigo = {empleado} and Demp_Tipo = 1603 "


        strSQL = Replace(strSQL, "{empleado}", empleado)
        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read

                FechaIS = REA.GetString("InicioS")
                FechaFS = REA.GetString("FinS")

                If fechaPlanillaI <= FechaIS And fechaPlanillaF >= FechaFS Then
                    Dia = DateDiff(DateInterval.Day, FechaIS, FechaFS)
                End If

                If fechaPlanillaI >= FechaIS And fechaPlanillaF <= FechaFS Then
                    Dia = DateDiff(DateInterval.Day, fechaPlanillaI, fechaPlanillaF)
                End If

                If fechaPlanillaI >= FechaIS And fechaPlanillaF >= FechaFS Then
                    Dia = DateDiff(DateInterval.Day, fechaPlanillaI, FechaFS)
                End If

                If fechaPlanillaI <= FechaIS And fechaPlanillaF <= FechaFS Then
                    Dia = DateDiff(DateInterval.Day, FechaIS, fechaPlanillaF)
                End If

            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        CON.Close()

        Return Dia

    End Function

    Public Function CalcISR(ByVal Sueldo As Double) As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim ISR As Double = FormatNumber(0.0, 2)
        Dim SalarioIsr As Double = 0.0

        Dim CON As MySqlConnection

        strSQL = "SELECT cat_ext Porcentaje,cat_dato Salario " & _
                 "FROM Catalogos " & _
                 "WHERE cat_num = 123 "
        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read

                SalarioIsr = CDbl(REA.GetString("Salario"))

                If Sueldo >= SalarioIsr Then
                    If REA.HasRows Then

                        ISR = Sueldo * CDbl(REA.GetString("Porcentaje"))

                    End If
                End If

            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        CON.Close()

        Return ISR

    End Function

    Private Sub NuevoPlanillaBase(Optional ByVal Tipo As Integer = 856)

        Dim cContrato As New clsDcmtos_HDR
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim i As Integer = INT_UNO
        Dim bandera As Integer = 0
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection
        Dim dblIgss As Double = 0.0
        Dim dblSueldo As Double = 0.0
        Dim dblBoni As Double = 0.0
        Dim dblToTal As Double = 0.0
        Dim fechaInicio As String = dtpInicioPlanilla.Value.ToString(FORMATO_MYSQL)
        Dim fechaFin As String = dtpFinalPlanilla.Value.ToString(FORMATO_MYSQL)

        strSQL = "SELECT HDoc_Emp_Cod,HDoc_Doc_Ano,HDoc_Doc_Num,HDoc_RF3_Dbl,HDoc_Emp_Nom,HDoc_RF1_Dbl, HDoc_RF2_Dbl, HDoc_DR1_Emp, pue_descripcion, " & _
                 "IFNULL(( " & _
                 "SELECT  IF( d.Demp_Fin< '{fechainicio}' or d.Demp_Inicio >'{fechafin}','No','Si') estado " & _
                 "FROM DTL_Empleados d " & _
                 "WHERE d.Demp_Sis_Emp = pue_sisemp AND d.Demp_Codigo = HDoc_Emp_Cod AND d.Demp_Tipo = 1603  and d.Demp_Status = 1 " & _
                 "LIMIT 1),'No') suspension, " & _
                 "pue_descripcion,datediff('{fechafin}','{fechainicio}') Dias " & _
                 "FROM Dcmtos_HDR " & _
                 "LEFT JOIN Puestos ON pue_sisemp = 3 AND pue_codigo = HDoc_DR1_Emp " & _
                 "WHERE HDoc_Doc_Cat=436 AND HDoc_Doc_Status = 1 AND HDoc_Sis_Emp = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fechainicio}", fechaInicio)
        strSQL = Replace(strSQL, "{fechafin}", fechaFin)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        Try

            If REA.HasRows Then

                ListaEmpleados.Rows.Clear()

                Do While REA.Read

                    Dim strFila As String = STR_VACIO
                    Dim SueldoBase As Double = INT_CERO
                    Dim Bonificacion7879 As Double = FormatNumber(0.0, 2)
                    Dim BonificacionIncentivo As Double = 0.0
                    Dim horasExtras As Integer = 0.0
                    Dim TotalIncentivos As Double = 0.0
                    Dim CodigoEmpleado As Integer = 0
                    Dim intBonificacion As Double = 0.0
                    Dim Igss As Double = 0.0
                    Dim ISR As Double = 0.0
                    Dim SueldoTipo As Double = FormatNumber(0.0, 2)
                    Dim Prestamo As Double = 0.0
                    Dim Adelanto As Double = 0.0
                    Dim Suspension As String = STR_VACIO
                    Dim OtrosDescuentos As Double = 0.0
                    Dim TotalDescuentos As Double = 0.0
                    Dim DiasSuspendidos As Integer = 0
                    Dim intLaborados As Integer = 0.0
                    Dim GranTotal As Double = 0.0
                    Dim intDias As Double = 0.0
                    Dim dblParqueo As Double = 0.0
                    Dim MesPagar As Double = 0.0
                    Dim mesDividido As Double = 0.0
                    Dim IgssBase As Double = 0


                    CodigoEmpleado = REA.GetInt16("HDoc_Emp_Cod")

                    If Tipo = 856 Then
                        SueldoBase = REA.GetDouble("HDoc_RF1_Dbl")
                        intBonificacion = REA.GetDouble("HDoc_RF2_Dbl")
                        Bonificacion7879 = REA.GetDouble("HDoc_RF3_Dbl")

                    ElseIf Tipo = 857 Then
                        SueldoBase = REA.GetDouble("HDoc_RF1_Dbl") / 2
                        intBonificacion = BonificacionLey / 2
                        Bonificacion7879 = REA.GetDouble("HDoc_RF3_Dbl") / 2
                    ElseIf Tipo = 858 Then

                        SueldoBase = REA.GetDouble("HDoc_RF1_Dbl") / 4
                        intBonificacion = BonificacionLey / 4
                        Bonificacion7879 = REA.GetDouble("HDoc_RF3_Dbl") / 4
                    End If

                    Suspension = REA.GetString("suspension")
                    SueldoTipo = SueldoBase + intBonificacion + Bonificacion7879
                    IgssBase = REA.GetDouble("HDoc_RF1_Dbl")
                    intDias = REA.GetInt16("Dias")
                    TotalIncentivos = SueldoTipo
                    If chkigss.Checked = True Then
                        Igss = IgssBase * 0.0483

                        If bandera = 0 Then
                            MsgBox("Se Realizara el Calculo Sobre Todo el Sueldo Base")
                            bandera = 1
                        End If


                    End If

                    If Suspension = "Si" Then
                        DiasSuspendidos = CalcIgss(CodigoEmpleado, fechaInicio, fechaFin)
                    End If

                    intLaborados = intDias - DiasSuspendidos


                    TotalDescuentos = FormatNumber(Igss + ISR + Prestamo + Adelanto + OtrosDescuentos + dblParqueo, 2)
                    GranTotal = TotalIncentivos - TotalDescuentos

                    If Tipo = 856 Then
                        mesDividido = GranTotal / 30
                        MesPagar = mesDividido * intLaborados
                    ElseIf Tipo = 857 Then
                        mesDividido = GranTotal / 15
                        MesPagar = mesDividido * intLaborados
                    ElseIf Tipo = 858 Then
                        mesDividido = GranTotal / 7
                        MesPagar = mesDividido * intLaborados
                    End If

                    strFila = CodigoEmpleado & "|" & REA.GetInt32("HDoc_Doc_Ano") & "|" & REA.GetInt16("HDoc_Doc_Num") & "|" & REA.GetString("HDoc_Emp_Nom") & "|" &
                      REA.GetString("pue_descripcion") & "|" & REA.GetInt16("HDoc_DR1_Emp") & "|" & FormatNumber(SueldoBase, 2) & "|" &
                      FormatNumber(intBonificacion, 2) & "|" & FormatNumber(SueldoTipo, 2) & "|" & FormatNumber(Bonificacion7879, 2) & "|" &
                      FormatNumber(horasExtras, 2) & "|" & FormatNumber(BonificacionIncentivo, 2) & "|" & FormatNumber(TotalIncentivos, 2) & "|" &
                      FormatNumber(Igss, 2) & "|" & FormatNumber(ISR, 2) & "|" & FormatNumber(Prestamo, 2) & "|" & FormatNumber(Adelanto, 2) & "|" &
                      FormatNumber(OtrosDescuentos, 2) & "|" & FormatNumber(dblParqueo, 2) & "|" & FormatNumber(TotalDescuentos, 2) & "|" & Suspension & "|" &
                      REA.GetInt16("Dias") & "|" & DiasSuspendidos & "|" & intLaborados & "|" & FormatNumber(GranTotal, 2)

                    cfun.AgregarFila(ListaEmpleados, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        celdaTotal.Text = Format(TotalPlanilla(), FORMATO_MONEDA)

    End Sub

    Private Function Seleccionar(ByVal intId As Integer, ByVal intAno As Integer) As Boolean
        Seleccionar = False
        If logConsultar = True Then
            Const CAT_PLANILLA = 882
            Dim Encabezado As New clsDcmtos_HDR
            Dim Detalle As New clsDcmtos_DTL
            Dim strCondicion As String = STR_VACIO
            Dim strCampos As String = STR_VACIO
            Dim DtlPtro As New clsDcmtos_DTL_Pro
            Dim Catalogo As New clsCatalogos
            Dim Celda As DataGridViewTextBoxCell
            Dim Fila As New DataGridViewRow
            Try
                'Seleccionar Encabezado
                strCampos = " HDoc_Doc_Ano,HDoc_Doc_Num,HDoc_Emp_Per, HDoc_DR1_Cat, HDoc_DR1_Num," & _
                    "HDoc_RF1_Dbl, HDoc_Doc_Mon"
                strCondicion = "HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {planilla} and HDoc_Doc_Ano = " & _
                    " {ano} and HDoc_Doc_Num = {id}"
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{planilla}", CAT_PLANILLA)
                strCondicion = Replace(strCondicion, "{ano}", intAno)
                strCondicion = Replace(strCondicion, "{id}", intId)
                Encabezado.CONEXION = strConexion
                If Encabezado.Seleccionar(strCondicion, strCampos) = True Then
                    ComboTipo.Enabled = False
                    ComboMoneda.Enabled = False
                    celdaID.Text = Encabezado.HDOC_DOC_NUM
                    celdaAño.Text = Encabezado.HDOC_DOC_ANO
                    celdaCodigo.Text = Encabezado.HDOC_EMP_PER
                    celdaMoneda.Text = Encabezado.HDOC_DOC_MON
                    celdaTipo.Text = Encabezado.HDOC_DR1_CAT
                    ComboTipo.Text = Encabezado.HDOC_DR1_NUM
                    celdaTotal.Text = Format(Encabezado.HDOC_RF1_DBL, FORMATO_MONEDA)
                    strCondicion = " cat_num = " & Encabezado.HDOC_DOC_MON
                    strCampos = " cat_clave"
                    Catalogo.CONEXION = strConexion
                    If Catalogo.Seleccionar(strCondicion, strCampos) = True Then
                        ComboMoneda.Text = Catalogo.CAT_CLAVE
                    End If
                    'Seleccionar Detalle
                    strCondicion = "DDoc_Sis_Emp= {empresa} and DDoc_Doc_Cat= {planilla} and DDoc_Doc_Num =" & _
                        " {id} and DDoc_Doc_Ano = {ano}"
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{planilla}", CAT_PLANILLA)
                    strCondicion = Replace(strCondicion, "{ano}", intAno)
                    strCondicion = Replace(strCondicion, "{id}", intId)
                    strCampos = STR_ASTERISCO
                    Detalle.CONEXION = strConexion
                    If Detalle.SeleccionarLista(strCondicion, strCampos, 1000000) Then
                        Do While Detalle.SiguienteRegistro = True
                            'Seleccionar Pro
                            strCampos = "PDoc_Par_Ano, PDoc_Par_Num"
                            strCondicion = "PDoc_Chi_Cat ={planilla}  and PDoc_Chi_Ano={ano} and" & _
                                " PDoc_Chi_Num = {id} and PDoc_Sis_Emp = {empresa} and PDoc_Par_Cat = {contrato} " & _
                                "  and PDoc_Chi_Lin = {linea}"
                            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                            strCondicion = Replace(strCondicion, "{planilla}", CAT_PLANILLA)
                            strCondicion = Replace(strCondicion, "{ano}", intAno)
                            strCondicion = Replace(strCondicion, "{id}", intId)
                            strCondicion = Replace(strCondicion, "{contrato}", 436)
                            strCondicion = Replace(strCondicion, "{linea}", Detalle.DDOC_DOC_LIN)
                            DtlPtro.logConexion = True
                            DtlPtro.CONEXION = strConexion
                            If DtlPtro.Seleccionar(strCondicion, strCampos) = True Then
                                Fila = New DataGridViewRow
                                'ID del Contrato
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = DtlPtro.PDOC_PAR_NUM
                                Fila.Cells.Add(Celda)

                                'Año Contrato
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = DtlPtro.PDOC_PAR_ANO
                                Fila.Cells.Add(Celda)

                                'Nombre del empleado
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_DES
                                Fila.Cells.Add(Celda)

                                'Puesto
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_RF1_COD
                                Fila.Cells.Add(Celda)

                                'IDPuesto
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_RF1_NUM
                                Fila.Cells.Add(Celda)

                                'Sueldo Base
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_PUQ * CInt(celdaFactor.Text)
                                Fila.Cells.Add(Celda)

                                'Bonificacion
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_DSP * CInt(celdaFactor.Text)
                                Fila.Cells.Add(Celda)

                                'Sueldo {tipo}
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_PUQ
                                Fila.Cells.Add(Celda)

                                ' Bonificacion {tipo}
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_DSP
                                Fila.Cells.Add(Celda)

                                'Horas Extra
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_NET
                                Fila.Cells.Add(Celda)

                                'Bonificacion
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_DSQ
                                Fila.Cells.Add(Celda)

                                'IGSS
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_QTY
                                Fila.Cells.Add(Celda)

                                'ISR
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_RF1_DBL
                                Fila.Cells.Add(Celda)

                                'Prestamo
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_RF2_DBL
                                Fila.Cells.Add(Celda)

                                'Adelanto
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_RF3_DBL
                                Fila.Cells.Add(Celda)

                                'Otros Descuentos 
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_FOB
                                Fila.Cells.Add(Celda)

                                ' Total
                                Celda = New DataGridViewTextBoxCell
                                Celda.Value = Detalle.DDOC_PRD_CIF
                                Fila.Cells.Add(Celda)
                                ListaEmpleados.Rows.Add(Fila)

                            Else
                                MsgBox(DtlPtro.MERROR.ToString)
                            End If
                        Loop
                    End If
                End If


            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            MsgBox("No dispone de suficientes privilegios para ejectuar esta acción", MsgBoxStyle.Exclamation)
        End If

    End Function

#End Region

    Private Sub frmPPlanilla_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmPPlanilla_Load(sender As Object, e As EventArgs) Handles Me.Load
        mostrarPanel(1)
        Dim cAccesos As New clsAccesos
        txtTipo.Text = "Mensual"
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    MostrarLista()
                    BloquearBotones()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim cPlanilla As New clsPlanilla
        Try
            If LogBorrar = True Then
                If MsgBox("¿Está seguro que desea  borrar este registro?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                    cPlanilla.ID = celdaID.Text
                    cPlanilla.Año = celdaAño.Text
                    If cPlanilla.BorrarDetalle = True Then
                        If cPlanilla.BorrarEncabezado = True Then
                            MsgBox("El registro se ha borrado", MsgBoxStyle.Information)
                        End If
                    End If
                End If
            Else
                MsgBox("No dispone de suficientes privilegios para ejectuar esta acción", MsgBoxStyle.Exclamation)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If ListaPlanillas.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
            mostrarPanel(1)
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        If Me.Tag = "nuevo" Then
            If logInsertar = True Then
                If Guardar(lblcodt.Text) = True Then
                    MsgBox("Documento guardado exitosamente", MsgBoxStyle.Information)
                    MostrarLista()
                End If
            Else
                MsgBox("No dispone de suficientes privilegios para ejectuar esta acción", MsgBoxStyle.Exclamation)
            End If
        Else
            If logEditar = True Then
                If Actualizar() = True Then
                    MsgBox("Documento Actulizado exitosamente", MsgBoxStyle.Information)
                    MostrarLista()
                End If
            Else
                MsgBox("No dispone de suficientes privilegios para ejectuar esta acción", MsgBoxStyle.Exclamation)
            End If

        End If
    End Sub


    Private Function SQLBuscar() As String
        Dim strSQL As String = ""

        strSQL = "SELECT HDoc_Doc_Ano Año, HDoc_Doc_Num Numero, HDoc_Emp_Per Codigo,HDoc_DR1_Num Linea,HDoc_DR1_Fec Inicio,HDoc_DR2_Fec Fin,HDoc_RF1_Dbl Total  "
        strSQL &= "FROM Dcmtos_HDR  "
        strSQL &= "WHERE HDoc_Sis_Emp = {empresa} and  HDoc_Doc_Cat = 882  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        If chkRango.Checked = True Then

            strSQL &= "and HDoc_DR1_Fec between '{inicio}' and '{fin}'    "

            strSQL = Replace(strSQL, "{inicio}", dtpInicioPlanilla.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", dtpFinalPlanilla.Value.ToString(FORMATO_MYSQL))

        End If

        Return strSQL

    End Function

    Private Sub mostrarPanel(ByVal Log As Boolean)

        If Log = True Then
            pnlPlanillas.Visible = True
            pnlPlanillas.Dock = DockStyle.Fill
            cfun.CargarLista(dgPlanilla, SQLBuscar)
            panelPrincipal.Visible = False
        Else
            pnlPlanillas.Visible = False
            panelPrincipal.Visible = True
        End If

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo

        Dim frm As New frmOption
        frm.Titulo = "Tipos de Planilla"
        frm.Mensaje = "Seleccione un tipo de planilla"
        'frm.Opciones = "Base|Bonificación"
        'frm.ShowDialog(Me)
        mostrarPanel(0)
        dtpInicioPlanilla.Enabled = True
        dtpFinalPlanilla.Enabled = True

        Dim inicio As String = dtpInicioPlanilla.Value.ToString(FORMATO_MYSQL)
        Dim final As String = dtpFinalPlanilla.Value.ToString(FORMATO_MYSQL)
        Reset()
        MostrarLista(False)
        CeldaTitulo.Text = "Nueva Planilla"
        Me.Tag = "nuevo"
        cFunciones.CargarCombo(ComboTipo, "Catalogos", "cat_clave", "cat_num", "cat_clase = 'Planilla'")
        cFunciones.CargarCombo(ComboMoneda, "Catalogos a left join Catalogos b  on a.cat_clave = b.cat_num ", "b.cat_clave", "b.cat_num", "a.cat_clase='Defaults' and ( a.cat_sist = 'CUR_EXT' or a.cat_sist='CUR_LOC')")

        NuevoPlanillaBase()
        'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

        'End If

    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim intId As Integer
        Dim Celda As DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim dblIgss As Double = INT_CERO
        Dim dblSueldo As Double = INT_CERO
        Dim dblBoni As Double = INT_CERO
        Dim dblToTal As Double = INT_CERO
        Dim strCondicion As String = STR_VACIO
        Dim cContrato As New clsDcmtos_HDR
        strCondicion = "HDoc_Doc_Cat=436 and HDoc_Doc_Status = 1 and HDoc_Sis_Emp = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            frm.FiltroText = "Ingrese el Nombre o Apellido del empledo para filtrar"
            frm.Filtro = "HDoc_Emp_Nom"
            frm.Campos = "HDoc_Doc_Num No_Contrato,HDoc_Emp_Nom Nombre, HDoc_Emp_Dir Puesto, HDoc_RF1_Dbl Base "
            frm.Limite = 20
            frm.Ordenamiento = "HDoc_Emp_Nom"
            frm.Condicion = strCondicion
            frm.Titulo = "Seleccione un empleado"
            frm.Tabla = "Dcmtos_HDR"
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                For i As Integer = 0 To ListaEmpleados.Rows.Count - 1
                    Celda = ListaEmpleados.Rows(i).Cells(0)
                    intId = CInt(Celda.Value)
                    If intId = frm.LLave Then
                        MsgBox("Este empleado ya esta incluido dentro de la Planilla", MsgBoxStyle.Critical)
                        Exit Sub
                    End If
                Next
                cContrato.CONEXION = strConexion
                strCondicion = "HDoc_Doc_Cat=436 and HDoc_Doc_Status = 1 and HDoc_Sis_Emp = " & Sesion.IdEmpresa & " and HDoc_Doc_Num = " & frm.LLave
                If cContrato.Seleccionar(strCondicion, "HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_RF1_Dbl, HDoc_RF2_Dbl") = True Then
                    dblSueldo = cContrato.HDOC_RF1_DBL / CInt(celdaFactor.Text)
                    dblBoni = cContrato.HDOC_RF2_DBL / CInt(celdaFactor.Text)
                    dblIgss = dblSueldo * 0.0483
                    dblToTal = dblSueldo + dblBoni - dblIgss
                    Fila = New DataGridViewRow
                    'ID del Empleado
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = frm.LLave
                    Fila.Cells.Add(Celda)
                    'Nombre del empleado
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = frm.Dato
                    Fila.Cells.Add(Celda)
                    'Puesto
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = frm.Dato2
                    Fila.Cells.Add(Celda)
                    'Sueldo Base
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = frm.Dato3
                    Fila.Cells.Add(Celda)
                    'Bonificacion
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = cContrato.HDOC_RF2_DBL
                    Fila.Cells.Add(Celda)
                    'Sueldo {tipo}

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = dblSueldo
                    Fila.Cells.Add(Celda)
                    ' Bonificacion {tipo}

                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = dblBoni
                    Fila.Cells.Add(Celda)
                    'Horas Extra
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = 0
                    Fila.Cells.Add(Celda)
                    'Bonificacion
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = 0
                    Fila.Cells.Add(Celda)
                    'IGSS
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = dblIgss
                    Fila.Cells.Add(Celda)
                    'ISR
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = 0
                    Fila.Cells.Add(Celda)
                    ''Prestamo
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = 0
                    Fila.Cells.Add(Celda)
                    ''Adelanto
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = 0
                    Fila.Cells.Add(Celda)
                    ''Otros Descuentos 
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = 0
                    Fila.Cells.Add(Celda)
                    '' Total
                    Celda = New DataGridViewTextBoxCell
                    Celda.Value = dblToTal
                    Fila.Cells.Add(Celda)

                    ListaEmpleados.Rows.Add(Fila)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ListaPlanillas_DoubleClick(sender As Object, e As EventArgs)
        If ListaPlanillas.SelectedRows.Count = INT_CERO Then Exit Sub
        Me.Tag = "mod"
        MostrarLista(False)
        Reset()
        CeldaTitulo.Text = "Modificar Registro"
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        intID = ListaPlanillas.SelectedCells(0).Value
        intAño = ListaPlanillas.SelectedCells(1).Value
        Seleccionar(intID, intAño)
    End Sub

    Private Sub ListaPlanillas_KeyDown(sender As Object, e As KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            If ListaPlanillas.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            MostrarLista(False)
            Reset()
            CeldaTitulo.Text = "Modificar Registro"
            Dim intID As Integer = NO_FILA
            Dim intAño As Integer = NO_FILA
            intID = ListaPlanillas.SelectedCells(0).Value
            intAño = ListaPlanillas.SelectedCells(1).Value
            Seleccionar(intID, intAño)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub ComboMoneda_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboMoneda.SelectedIndexChanged
        celdaMoneda.Text = CType(ComboMoneda.Items(ComboMoneda.SelectedIndex), clsItemData).ItemData.ToString
    End Sub

    Private Sub ComboTipo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboTipo.SelectedIndexChanged
        celdaTipo.Text = CType(ComboTipo.Items(ComboTipo.SelectedIndex), clsItemData).ItemData.ToString
        Dim cCatalogo As New clsCatalogos
        Try
            cCatalogo.CONEXION = strConexion
            Dim strCondicion As String = "cat_num = " & celdaTipo.Text
            If cCatalogo.Seleccionar(strCondicion, "cat_pid") = True Then
                celdaFactor.Text = cCatalogo.CAT_PID
            End If
            NuevoPlanillaBase()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ListaEmpleados_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles ListaEmpleados.CellValueChanged
        If ValidarValores() = True Then
            celdaTotal.Text = Format(TotalPlanilla(), FORMATO_MONEDA)
        End If
    End Sub

    Private Sub ListaEmpleados_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles ListaEmpleados.RowsRemoved
        If ValidarValores() = True Then
            'celdaTotal.Text = Format(TotalPlanilla(), FORMATO_MONEDA)
        End If
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If ListaEmpleados.SelectedRows.Count = INT_CERO Then Exit Sub
        ListaEmpleados.Rows.Remove(ListaEmpleados.CurrentRow)
    End Sub

    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click
        If logConsultar = True Then
            Dim cReporte As New clsReportes
            cReporte.GenerarPlanilla(celdaID.Text, celdaAño.Text)

        Else
            MsgBox("No dispone de suficientes privilegios para ejectuar esta acción", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub dtpInicioPlanilla_ValueChanged(sender As Object, e As EventArgs) Handles dtpInicioPlanilla.ValueChanged
        NuevoPlanillaBase()
    End Sub

    Private Sub dtpFinalPlanilla_ValueChanged(sender As Object, e As EventArgs) Handles dtpFinalPlanilla.ValueChanged
        NuevoPlanillaBase()
    End Sub

    Private Sub btnRango_Click(sender As Object, e As EventArgs) Handles btnRango.Click
        Dim frmSelecionar As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        strCondicion = " cat_clase = 'Planilla' "

        frmSelecionar.Tabla = "Catalogos "
        frmSelecionar.Campos = "cat_num,cat_clave "
        frmSelecionar.Condicion = strCondicion

        If frmSelecionar.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            NuevoPlanillaBase(frmSelecionar.LLave)
            lblcodt.Text = frmSelecionar.LLave
            txtTipo.Text = frmSelecionar.Dato
        End If

    End Sub

    Private Sub btnFiltrar_Click(sender As Object, e As EventArgs) Handles btnFiltrar.Click
        cfun.CargarLista(dgPlanilla, SQLBuscar)
    End Sub


    Public Function BuscarPlanilla() As Integer
        Dim strSQL As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim valorE As Integer


        strSQL = "SELECT COUNT(*) EXISTE " & _
                 "FROM Dcmtos_HDR A " & _
                 "WHERE A.HDoc_Sis_Emp = {empresa} AND A.HDoc_Doc_Cat = 882 AND A.HDoc_Doc_Ano = {año}  " & _
                 "AND A.HDoc_Doc_Num = {numero} AND A.HDoc_Emp_Per = '{codigo}'  "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaID.Text)
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)


        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            valorE = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return valorE
    End Function



    Private Sub LlenarEncabezado(ByVal año As Integer, ByVal numero As Integer, ByVal codigo As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection
        Dim REA As MySqlDataReader

        strSQL = "SELECT HDoc_Doc_Cat,HDoc_DR1_Num,HDoc_Emp_Nom,HDoc_DR1_Cat,HDoc_DR1_Fec,HDoc_DR2_Fec,HDoc_Doc_Mon,HDoc_RF1_Dbl " & _
                 "FROM Dcmtos_HDR HDR " & _
                 "WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = 882 AND HDR.HDoc_Doc_Ano = {año} AND HDR.HDoc_Doc_Num = {numero}  AND HDoc_Emp_Per = '{codigo}' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", año)
        strSQL = Replace(strSQL, "{numero}", numero)
        strSQL = Replace(strSQL, "{codigo}", codigo)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            While REA.Read
                txtTipo.Text = REA.GetString("HDoc_DR1_Num")
                dtpInicioPlanilla.Value = CDate(REA.GetMySqlDateTime("HDoc_DR1_Fec"))
                dtpFinalPlanilla.Value = CDate(REA.GetMySqlDateTime("HDoc_DR2_Fec"))
                celdaMoneda.Text = REA.GetInt32("HDoc_Doc_Mon")
                celdaTipo.Text = REA.GetInt32("HDoc_Doc_Cat")
                celdaTotal.Text = FormatNumber(REA.GetDouble("HDoc_RF1_Dbl"), 2)
                lblcodt.Text = REA.GetInt32("HDoc_DR1_Cat")
                txtDescripcionPL.Text = REA.GetString("HDoc_Emp_Nom")
                celdaID.Text = numero
                celdaAño.Text = año
                celdaCodigo.Text = codigo

            End While

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

    End Sub

    Public Sub LlenarGrid(ByVal año As Integer, ByVal numero As Integer, ByVal codigo As String, Optional ByVal tipo As String = STR_VACIO)
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT HDoc_DR1_Fec,HDoc_DR2_Fec,DDoc_Prd_UM,PDoc_Par_Ano,PDoc_Par_Num,DDoc_Prd_Des,DDoc_RF1_Num,DDoc_RF1_Cod, " & _
                 "DDoc_Prd_PUQ,DDoc_Prd_DSP,DDoc_Prd_NET,DDoc_Prd_DSQ,DDoc_Prd_QTY,DDoc_RF2_Num,DDoc_RF3_Num,DDoc_RF2_Cod,DDoc_RF1_Dbl, " & _
                 "DDoc_RF2_Dbl,DDoc_RF3_Dbl,DDoc_Prd_Fob,DDoc_Prd_Cif " & _
                 "FROM Dcmtos_HDR HDR " & _
                 "LEFT JOIN Dcmtos_DTL_Pro PRO ON PRO.PDoc_Sis_Emp = HDR.HDoc_Sis_Emp AND  PRO.PDoc_Chi_Num = HDR.HDoc_Doc_Num  " & _
                 "AND PRO.PDoc_Chi_Cat = HDR.HDoc_Doc_Cat AND PRO.PDoc_Chi_Ano = HDR.HDoc_Doc_Ano " & _
                 "LEFT JOIN Dcmtos_DTL DTL ON DTL.DDoc_Sis_Emp = HDR.HDoc_Sis_Emp AND DTL.DDoc_Doc_Cat = HDR.HDoc_Doc_Cat AND  " & _
                 "DTL.DDoc_Doc_Ano = HDR.HDoc_Doc_Ano AND HDR.HDoc_Emp_Per = DTL.DDoc_Prd_Ref AND  " & _
                 "DTL.DDoc_Doc_Lin = PRO.PDoc_Chi_Lin " & _
                 "WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = 882  AND HDR.HDoc_Doc_Ano = {año} AND  HDR.HDoc_Doc_Num = {numero} AND HDoc_Emp_Per = '{codigo}' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", año)
        strSQL = Replace(strSQL, "{numero}", numero)
        strSQL = Replace(strSQL, "{codigo}", codigo)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            ListaEmpleados.Rows.Clear()

            If REA.HasRows Then
                Dim intBandera As Integer = 0

                Do While REA.Read

                    Dim fila As String = strSQL
                    Dim cfun As New clsFunciones
                    Dim sueldoBase As Double = 0
                    Dim campo1 As Double = 0
                    Dim campo2 As Double = 0
                    Dim HorasE As Double = 0
                    Dim bonificacionI As Double = 0
                    Dim totalIncentivos As Double = 0
                    Dim descuentoIgss As Double = 0
                    Dim isr As Double = 0
                    Dim Prestamo As Double = 0
                    Dim adelanto As Double = 0
                    Dim Odescuentos As Double = 0
                    Dim Tdescuentos As Double = 0
                    Dim diferenciafechas As Integer = 0
                    Dim strSuspendido As String = STR_VACIO
                    Dim dblGranTotal As Double = 0.0
                    Dim intSupendidos As Double = 0.0
                    Dim dblBonificacion As Double = 0.0
                    Dim intLaborados As Double = 0.0
                    Dim dblParqueo As Double = 0.0
                    Dim mesDDivido As Double = 0.0
                    Dim mesPPagar As Double = 0.0
                    Dim BonificacionValor As Double = 0.0



                    Dim iniciofechap As Date
                    Dim iniciofechaf As Date

                    iniciofechap = dtpInicioPlanilla.Value
                    iniciofechaf = dtpFinalPlanilla.Value

                    diferenciafechas = DateDiff(DateInterval.Day, iniciofechap, iniciofechaf)

                    sueldoBase = REA.GetDouble("DDoc_Prd_PUQ")
                    dblParqueo = REA.GetDouble("DDoc_Prd_DSP")
                    HorasE = REA.GetDouble("DDoc_Prd_NET")
                    bonificacionI = REA.GetDouble("DDoc_Prd_DSQ")
                    campo2 = REA.GetDouble("DDoc_Prd_Cif")

                    If txtTipo.Text = "Mensual" Then
                        dblBonificacion = BonificacionLey
                    ElseIf txtTipo.Text = "Quincenal" Then
                        dblBonificacion = BonificacionLey / 2
                    End If


                    totalIncentivos = sueldoBase + dblBonificacion + campo1 + campo2 + HorasE + bonificacionI
                    campo1 = totalIncentivos

                    descuentoIgss = REA.GetDouble("DDoc_Prd_QTY")
                    isr = REA.GetDouble("DDoc_RF1_Dbl")
                    Prestamo = REA.GetDouble("DDoc_RF2_Dbl")
                    adelanto = REA.GetDouble("DDoc_RF3_Dbl")
                    Odescuentos = REA.GetDouble("DDoc_Prd_Fob")

                    Tdescuentos = descuentoIgss + isr + Prestamo + adelanto + Odescuentos + dblParqueo

                    intSupendidos = REA.GetInt32("DDoc_RF2_Num")
                    intLaborados = REA.GetInt32("DDoc_RF3_Num")
                    strSuspendido = REA.GetString("DDoc_RF2_Cod")

                    dblGranTotal = totalIncentivos - Tdescuentos

                    If lblcodt.Text = 856 Then
                        mesDDivido = dblGranTotal / 30
                        mesPPagar = mesDDivido * intLaborados
                    ElseIf lblcodt.Text = 857 Then
                        mesDDivido = dblGranTotal / 15
                        mesPPagar = mesDDivido * intLaborados
                    End If


                    fila = REA.GetUInt32("DDoc_Prd_UM") & "|" & REA.GetInt32("PDoc_Par_Ano") & "|" & REA.GetInt16("PDoc_Par_Num") & "|" &
                           REA.GetString("DDoc_Prd_Des") & "|" & REA.GetString("DDoc_RF1_Cod") & "|" & REA.GetInt32("DDoc_RF1_Num") & "|" &
                           FormatNumber(sueldoBase, 2) & "|" & FormatNumber(dblBonificacion, 2) & "|" & FormatNumber(campo1, 2) & "|" & FormatNumber(campo2, 2) & "|" &
                           FormatNumber(HorasE, 2) & "|" & FormatNumber(bonificacionI, 2) & "|" & FormatNumber(totalIncentivos, 2) & "|" &
                           FormatNumber(descuentoIgss, 2) & "|" & FormatNumber(isr, 2) & "|" & FormatNumber(Prestamo, 2) & "|" &
                           FormatNumber(adelanto, 2) & "|" & FormatNumber(Odescuentos, 2) & "|" & dblParqueo & "|" & FormatNumber(Tdescuentos, 2) & "|" &
                           strSuspendido & "|" & diferenciafechas & "|" & intSupendidos & "|" & intLaborados & "|" &
                           FormatNumber(mesPPagar, 2) & "|" & FormatNumber(dblGranTotal, 2)
                    cfun.AgregarFila(ListaEmpleados, fila)

                    'End If 

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

    End Sub

    Private Sub dgPlanilla_DoubleClick(sender As Object, e As EventArgs) Handles dgPlanilla.DoubleClick
        Dim año As Integer = 0
        Dim numero As Integer = 0
        Dim codigo As String = STR_VACIO
        Dim tSaldo As Double = 0

        año = dgPlanilla.SelectedCells(0).Value
        numero = dgPlanilla.SelectedCells(1).Value
        codigo = dgPlanilla.SelectedCells(2).Value

        dtpFinalPlanilla.Enabled = False
        dtpInicioPlanilla.Enabled = False

        Encabezado1.botonGuardar.Enabled = True

        panelPrincipal.Visible = True
        panelPrincipal.Dock = DockStyle.Fill
        pnlPlanillas.Visible = False
        ListaPlanillas.Visible = False

        LlenarEncabezado(año, numero, codigo)
        LlenarGrid(año, numero, codigo, txtTipo.Text)

    End Sub

    Private Sub chkigss_CheckedChanged(sender As Object, e As EventArgs) Handles chkigss.CheckedChanged
        NuevoPlanillaBase(CInt(lblcodt.Text))
    End Sub


    Public Sub GenerarCSV(ByVal año As Integer, ByVal numero As Integer, ByVal referencia As String)
        Const Delimitador As String = ","
        Dim strSQL As String = STR_VACIO
        Dim strSQL1 As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim CON1 As MySqlConnection
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA1 As MySqlDataReader
        Dim i As Integer = 0

        Dim Archivo_CSV As String = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\FileExported.csv"
        Dim Archivo_CSVB As String = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\FileExportedb.csv"

        Try
            Using archivo As StreamWriter = New StreamWriter(Archivo_CSV)

                Dim linea As String = String.Empty


                strSQL = "SELECT Nombre,LPAD(Cuenta,10,0) Cuenta, " & _
                         "REPLACE(PL.SB+PL.BL+PL.HE+PL.BI-PL.Igss-PL.Isr-PL.Prestamo-PL.Adelanto-PL.ODesc,',','') SL,Descripcion " & _
                         "FROM( " & _
                         "SELECT DDoc_Prd_Des Nombre,  " & _
                         "IFNULL(IF(Emp.em_deposito='','Sin Cuenta',Emp.em_deposito),'Sin Cuenta') Cuenta,DDoc_Prd_PUQ SB, " & _
                         " HDoc_DR1_Dbl BL,DDoc_Prd_Net HE,DDoc_Prd_DSQ BI,DDoc_Prd_QTY Igss,DDoc_RF1_Dbl Isr,DDoc_RF2_Dbl Prestamo, " & _
                         "DDoc_RF3_Dbl Adelanto,DDoc_Prd_Fob ODesc,HDoc_Emp_Nom Descripcion " & _
                         "FROM Dcmtos_DTL DTL " & _
                         "LEFT JOIN Empleados Emp on Emp.em_empresa = DTL.DDoc_Sis_Emp AND Emp.em_codigo = DTL.DDoc_Prd_UM AND Emp.em_estado = 1 " & _
                         "LEFT JOIN Dcmtos_HDR HDR ON HDR.HDoc_Sis_Emp = DTL.DDoc_Sis_Emp AND HDR.HDoc_Doc_Cat = DTL.DDoc_Doc_Cat AND  " & _
                         "HDR.HDoc_Doc_Ano = DTL.DDoc_Doc_Ano AND HDR.HDoc_Doc_Num =  DTL.DDoc_Doc_Num AND HDR.HDoc_Emp_Per = DTL.DDoc_Prd_Ref " & _
                         "WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = 882 AND DTL.DDoc_Doc_Ano = {año}  " & _
                         "AND DTL.DDoc_Doc_Num = {numero} AND DTL.DDoc_Prd_Ref = '{referencia}') PL "


                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{año}", año)
                strSQL = Replace(strSQL, "{numero}", numero)
                strSQL = Replace(strSQL, "{referencia}", referencia)

                CON = New MySqlConnection(strConexion)
                CON.Open()

                Try

                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then

                        While REA.Read
                            Dim NombreSinAcentos As String

                            NombreSinAcentos = cfun.QuitarAcentos(REA.GetString("Nombre"))

                            i = i + 1


                            linea = linea & "1" & Delimitador & i & Delimitador & NombreSinAcentos & Delimitador &
                                    REA.GetString("Cuenta") & Delimitador & REA.GetString("SL") & Delimitador & REA.GetString("Descripcion")

                            archivo.WriteLine(linea.ToString)

                            linea = STR_VACIO

                        End While


                    End If

                    i = 0

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

                CON.Close()

            End Using

            Using archivo2 As StreamWriter = New StreamWriter(Archivo_CSVB)

                Dim linea As String = String.Empty


                strSQL1 = "SELECT Nombre,Cuenta,REPLACE(PL.BP-PL.Parqueo,',','') SL,Descripcion " & _
                          "FROM( " & _
                          "SELECT DDoc_Prd_Des Nombre,IFNULL(if(Emp.em_deposito='','Sin Cuenta',Emp.em_deposito),'sin Cuenta') Cuenta,	DDoc_Prd_Cif BP, " & _
                          "DDoc_Prd_DSP Parqueo,HDoc_Emp_Nom Descripcion " & _
                          "FROM Dcmtos_DTL DTL " & _
                          "LEFT JOIN Empleados Emp on Emp.em_empresa = DTL.DDoc_Sis_Emp AND Emp.em_codigo = DTL.DDoc_Prd_UM AND Emp.em_estado = 1 " & _
                          "LEFT JOIN Dcmtos_HDR HDR ON HDR.HDoc_Sis_Emp = DTL.DDoc_Sis_Emp AND HDR.HDoc_Doc_Cat = DTL.DDoc_Doc_Cat AND  " & _
                          "HDR.HDoc_Doc_Ano = DTL.DDoc_Doc_Ano AND HDR.HDoc_Doc_Num =  DTL.DDoc_Doc_Num AND HDR.HDoc_Emp_Per = DTL.DDoc_Prd_Ref " & _
                          "WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = 882 AND DTL.DDoc_Doc_Ano = {año}  " & _
                          "AND DTL.DDoc_Doc_Num = {numero} AND DTL.DDoc_Prd_Ref = '{referencia}') PL "

                strSQL1 = Replace(strSQL1, "{empresa}", Sesion.IdEmpresa)
                strSQL1 = Replace(strSQL1, "{año}", año)
                strSQL1 = Replace(strSQL1, "{numero}", numero)
                strSQL1 = Replace(strSQL1, "{referencia}", referencia)

                CON1 = New MySqlConnection(strConexion)
                CON1.Open()

                Try
                    COM1 = New MySqlCommand(strSQL1, CON1)
                    REA1 = COM1.ExecuteReader

                    If REA1.HasRows Then



                        While REA1.Read
                            Dim NombreSinAcentosb As String

                            NombreSinAcentosb = cfun.QuitarAcentos(REA1.GetString("Nombre"))

                            i = i + 1

                            linea = linea & "1" & Delimitador & i & Delimitador & NombreSinAcentosb & Delimitador &
                                 REA1.GetString("Cuenta") & Delimitador & REA1.GetString("SL") & Delimitador & REA1.GetString("Descripcion")

                            archivo2.WriteLine(linea.ToString)

                            linea = STR_VACIO

                        End While

                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

                CON1.Close()

            End Using


            Process.Start(Archivo_CSV)
            Process.Start(Archivo_CSVB)

        Catch ex As Exception
            MsgBox(ex.Message.ToString)
        End Try

    End Sub

    Private Sub btncsv_Click(sender As Object, e As EventArgs) Handles btncsv.Click

        GenerarCSV(celdaAño.Text, celdaID.Text, celdaCodigo.Text)

    End Sub




    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnRecibo.Click

        GenerarRecibo()

    End Sub

    Public Function CrearCarpeta(ByVal referencia As String)

        Dim exist As Boolean
        Dim Bandera As Integer = 1

        exist = System.IO.Directory.Exists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Recibos\" & "Recibos" & referencia)

        If exist = 0 Then
            System.IO.Directory.CreateDirectory(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Recibos\" & "Recibos" & referencia)
        Else
            Bandera = 1
        End If

        Return Bandera

    End Function

    Public Sub GenerarRecibo()
        'Dim CON As MySqlConnection
        'Dim COM As MySqlCommand
        'Dim REA As MySqlDataReader
        'Dim strSQL As String = STR_VACIO


        'strSQL = "SELECT CONCAT(DTL.DDoc_Prd_Des,DTL.DDoc_Prd_Ref) Archivos,DTL.DDoc_Prd_Ref Referencia,DDoc_Prd_PUQ SB, HDoc_DR1_Dbl BL,(DDoc_Prd_PUQ+HDoc_DR1_Dbl) Salario" & _
        '          ",DDoc_Prd_Net HE,DDoc_Prd_DSQ BI,DDoc_Prd_QTY Igss,DDoc_RF1_Dbl Isr,DDoc_RF2_Dbl " & _
        '         "Prestamo, DDoc_RF3_Dbl Adelanto,DDoc_Prd_Fob ODesc,((DDoc_Prd_PUQ+HDoc_DR1_Dbl+DDoc_Prd_Net)-(DDoc_Prd_QTY+DDoc_RF1_Dbl+DDoc_RF2_Dbl+DDoc_RF3_Dbl " & _
        '         "+DDoc_Prd_Fob)) SubTotal,DDoc_Prd_Cif BP " & _
        '         "FROM Dcmtos_DTL DTL " & _
        '         "LEFT JOIN Empleados Emp ON Emp.em_empresa = DTL.DDoc_Sis_Emp AND Emp.em_codigo = DTL.DDoc_Prd_UM AND Emp.em_estado = 1 " & _
        '         "LEFT JOIN Dcmtos_HDR HDR ON HDR.HDoc_Sis_Emp = DTL.DDoc_Sis_Emp AND HDR.HDoc_Doc_Cat = DTL.DDoc_Doc_Cat AND HDR.HDoc_Doc_Ano = DTL.DDoc_Doc_Ano AND  " & _
        '         "HDR.HDoc_Doc_Num = DTL.DDoc_Doc_Num AND HDR.HDoc_Emp_Per = DTL.DDoc_Prd_Ref " & _
        '         "WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = 882 AND DTL.DDoc_Doc_Ano = {año} AND DTL.DDoc_Doc_Num = {numero} AND DTL.DDoc_Prd_Ref = '{referencia}' "

        'strSQL = Replace(strSQL, "{numero}", celdaID.Text)
        'strSQL = Replace(strSQL, "{referencia}", celdaCodigo.Text)

        'CON = New MySqlConnection(strConexion)
        'CON.Open()

        'Try

        '    COM = New MySqlCommand(strSQL, CON)
        '    REA = COM.ExecuteReader

        '    If REA.HasRows Then

        '        Do While REA.Read

        '            Dim xLibro = New Microsoft.Office.Interop.Excel.Application
        '            xLibro.CopyObjectsWithCells = True

        '            CrearCarpeta(REA.GetString("Referencia"))

        '            With xLibro
        '                '.Visible = True
        '                Dim strExcelUbicacion = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\" & "Recibos\Recibos" & REA.GetString("Referencia") & "\"

        '                strExcelUbicacion = strExcelUbicacion + "" & REA.GetString("Archivos") & ".xlsx"


        '                .Workbooks.Add("C:\Sistema.Net\NuevaBaseRecbiso.xlsx")
        '                .Range("G19").Value = REA.GetDouble("SB")
        '                .Range("G19").ColumnWidth = "13.00"
        '                .Range("G20").Value = REA.GetDouble("BL")
        '                .Range("G21").Value = REA.GetDouble("Salario")
        '                .Range("G22").Value = 0
        '                .Range("G23").Value = 0
        '                .Range("G24").Value = REA.GetDouble("HE")
        '                .Range("G25").Value = REA.GetDouble("BI")
        '                .Range("G26").Value = REA.GetDouble("Igss")
        '                .Range("G27").Value = REA.GetDouble("Isr")
        '                .Range("G28").Value = REA.GetDouble("Prestamo")
        '                .Range("G29").Value = REA.GetDouble("Adelanto")
        '                .Range("G30").Value = REA.GetDouble("ODesc")
        '                .Range("G31").Value = REA.GetDouble("SubTotal")
        '                .Range("G32").Value = REA.GetDouble("BP")


        '                xLibro.ActiveWorkbook.SaveAs(strExcelUbicacion)
        '                xLibro.ActiveWorkbook.Close()
        '                xLibro.Quit()

        '            End With

        '        Loop

        '    End If

        'Catch ex As Exception
        '    MsgBox(ex.ToString)
        'End Try

    End Sub

End Class