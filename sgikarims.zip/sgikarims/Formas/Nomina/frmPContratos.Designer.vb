﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPContratos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonExportar = New System.Windows.Forms.Button()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonBorrar = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonNuevo = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.comboDuracion = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.comboMoneda = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaISR = New System.Windows.Forms.TextBox()
        Me.ComboDepartamento = New System.Windows.Forms.ComboBox()
        Me.celdaCodigoContrato = New System.Windows.Forms.TextBox()
        Me.comboPlanilla = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaBono = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaSueldo = New System.Windows.Forms.TextBox()
        Me.comboCentro = New System.Windows.Forms.ComboBox()
        Me.celdaBonificacion = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CeldaCodigoEmpleado = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.ContenedorDias = New System.Windows.Forms.GroupBox()
        Me.checkDomingo = New System.Windows.Forms.CheckBox()
        Me.checkSabado = New System.Windows.Forms.CheckBox()
        Me.checkViernes = New System.Windows.Forms.CheckBox()
        Me.checkJueves = New System.Windows.Forms.CheckBox()
        Me.checkMiercoles = New System.Windows.Forms.CheckBox()
        Me.checkMartes = New System.Windows.Forms.CheckBox()
        Me.checkLunes = New System.Windows.Forms.CheckBox()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.celdaEmpleado = New System.Windows.Forms.TextBox()
        Me.botonSelecionar = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.CeldaTitulo = New System.Windows.Forms.Label()
        Me.PanelDatos = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.celdaDirecionE = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.dtpNacimientoE = New System.Windows.Forms.DateTimePicker()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.celdaMunicipioE = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.celdaDPIE = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.celdaCedulaE = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.celdaNacionalidadE = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.CeldaCivielE = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.celdaSexoE = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.celdaNombreE = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.celdaIdRepresentante = New System.Windows.Forms.TextBox()
        Me.botonSelecionarR = New System.Windows.Forms.Button()
        Me.dtpNacimientoR = New System.Windows.Forms.DateTimePicker()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.celdaMunicipioR = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.celdaDPIR = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.celdaCedulaR = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.celdaNacionalidadR = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.celdaCivilR = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.celdaSexoR = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.celdaNombreR = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.celdaDireccionR = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.ListaHorarios = New System.Windows.Forms.DataGridView()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.horario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.jornda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.horainicio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.horafin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.comboHorario = New System.Windows.Forms.ComboBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.comboJornada = New System.Windows.Forms.ComboBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.celdaDescripcionPuesto = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ComboPuesto = New System.Windows.Forms.ComboBox()
        Me.ListaContratos = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContenedorDias.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.PanelDatos.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.ListaHorarios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        CType(Me.ListaContratos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.botonExportar)
        Me.Panel1.Controls.Add(Me.CuadroLogo)
        Me.Panel1.Controls.Add(Me.botonCerrar)
        Me.Panel1.Controls.Add(Me.botonBorrar)
        Me.Panel1.Controls.Add(Me.botonGuardar)
        Me.Panel1.Controls.Add(Me.botonNuevo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(736, 86)
        Me.Panel1.TabIndex = 2
        '
        'botonExportar
        '
        Me.botonExportar.Image = Global.KARIMs_SGI.My.Resources.Resources.word1
        Me.botonExportar.Location = New System.Drawing.Point(198, 15)
        Me.botonExportar.Name = "botonExportar"
        Me.botonExportar.Size = New System.Drawing.Size(56, 45)
        Me.botonExportar.TabIndex = 2
        Me.botonExportar.Text = "&Exportar"
        Me.botonExportar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportar.UseVisualStyleBackColor = True
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroLogo.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CuadroLogo.Image = Global.KARIMs_SGI.My.Resources.Resources.logokarims
        Me.CuadroLogo.Location = New System.Drawing.Point(634, 4)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(99, 78)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CuadroLogo.TabIndex = 1
        Me.CuadroLogo.TabStop = False
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(558, 15)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(56, 45)
        Me.botonCerrar.TabIndex = 0
        Me.botonCerrar.Text = "&Cerrar"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonBorrar
        '
        Me.botonBorrar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonBorrar.Location = New System.Drawing.Point(136, 15)
        Me.botonBorrar.Name = "botonBorrar"
        Me.botonBorrar.Size = New System.Drawing.Size(56, 45)
        Me.botonBorrar.TabIndex = 0
        Me.botonBorrar.Text = "&Borrar"
        Me.botonBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBorrar.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.botonGuardar.Location = New System.Drawing.Point(74, 15)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(56, 45)
        Me.botonGuardar.TabIndex = 0
        Me.botonGuardar.Text = "&Guardar"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonNuevo
        '
        Me.botonNuevo.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonNuevo.Location = New System.Drawing.Point(12, 15)
        Me.botonNuevo.Name = "botonNuevo"
        Me.botonNuevo.Size = New System.Drawing.Size(56, 45)
        Me.botonNuevo.TabIndex = 0
        Me.botonNuevo.Text = "&Nuevo"
        Me.botonNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevo.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(301, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(54, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Empleado"
        '
        'comboDuracion
        '
        Me.comboDuracion.FormattingEnabled = True
        Me.comboDuracion.Location = New System.Drawing.Point(35, 140)
        Me.comboDuracion.Name = "comboDuracion"
        Me.comboDuracion.Size = New System.Drawing.Size(198, 21)
        Me.comboDuracion.TabIndex = 4
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(20, 249)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Moneda"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(47, 121)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(107, 13)
        Me.Label16.TabIndex = 13
        Me.Label16.Text = "Duración de contrato"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(20, 313)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 13)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Tipo de planilla"
        '
        'comboMoneda
        '
        Me.comboMoneda.FormattingEnabled = True
        Me.comboMoneda.ItemHeight = 13
        Me.comboMoneda.Location = New System.Drawing.Point(19, 265)
        Me.comboMoneda.Name = "comboMoneda"
        Me.comboMoneda.Size = New System.Drawing.Size(222, 21)
        Me.comboMoneda.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(47, 273)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 13)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "Departamento"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(61, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(97, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Código de contrato"
        '
        'celdaISR
        '
        Me.celdaISR.Location = New System.Drawing.Point(19, 217)
        Me.celdaISR.Name = "celdaISR"
        Me.celdaISR.Size = New System.Drawing.Size(136, 20)
        Me.celdaISR.TabIndex = 5
        '
        'ComboDepartamento
        '
        Me.ComboDepartamento.FormattingEnabled = True
        Me.ComboDepartamento.ItemHeight = 13
        Me.ComboDepartamento.Location = New System.Drawing.Point(35, 289)
        Me.ComboDepartamento.Name = "ComboDepartamento"
        Me.ComboDepartamento.Size = New System.Drawing.Size(198, 21)
        Me.ComboDepartamento.TabIndex = 5
        '
        'celdaCodigoContrato
        '
        Me.celdaCodigoContrato.Location = New System.Drawing.Point(64, 23)
        Me.celdaCodigoContrato.Name = "celdaCodigoContrato"
        Me.celdaCodigoContrato.ReadOnly = True
        Me.celdaCodigoContrato.Size = New System.Drawing.Size(101, 20)
        Me.celdaCodigoContrato.TabIndex = 30
        '
        'comboPlanilla
        '
        Me.comboPlanilla.FormattingEnabled = True
        Me.comboPlanilla.ItemHeight = 13
        Me.comboPlanilla.Location = New System.Drawing.Point(19, 329)
        Me.comboPlanilla.Name = "comboPlanilla"
        Me.comboPlanilla.Size = New System.Drawing.Size(222, 21)
        Me.comboPlanilla.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(47, 75)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Terminación"
        '
        'dtpFin
        '
        Me.dtpFin.Checked = False
        Me.dtpFin.Location = New System.Drawing.Point(35, 91)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(198, 20)
        Me.dtpFin.TabIndex = 3
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(24, 201)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(66, 13)
        Me.Label15.TabIndex = 15
        Me.Label15.Text = "Retener ISR"
        '
        'celdaBono
        '
        Me.celdaBono.Location = New System.Drawing.Point(19, 169)
        Me.celdaBono.MaxLength = 255
        Me.celdaBono.Name = "celdaBono"
        Me.celdaBono.Size = New System.Drawing.Size(136, 20)
        Me.celdaBono.TabIndex = 4
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(20, 69)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 13)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Salario base"
        '
        'celdaSueldo
        '
        Me.celdaSueldo.Location = New System.Drawing.Point(19, 85)
        Me.celdaSueldo.MaxLength = 255
        Me.celdaSueldo.Name = "celdaSueldo"
        Me.celdaSueldo.Size = New System.Drawing.Size(136, 20)
        Me.celdaSueldo.TabIndex = 2
        '
        'comboCentro
        '
        Me.comboCentro.ItemHeight = 13
        Me.comboCentro.Location = New System.Drawing.Point(35, 191)
        Me.comboCentro.Name = "comboCentro"
        Me.comboCentro.Size = New System.Drawing.Size(198, 21)
        Me.comboCentro.TabIndex = 5
        '
        'celdaBonificacion
        '
        Me.celdaBonificacion.Location = New System.Drawing.Point(19, 124)
        Me.celdaBonificacion.MaxLength = 255
        Me.celdaBonificacion.Name = "celdaBonificacion"
        Me.celdaBonificacion.Size = New System.Drawing.Size(136, 20)
        Me.celdaBonificacion.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(183, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(104, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Código de empleado"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(47, 175)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(88, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Centro de trabajo"
        '
        'CeldaCodigoEmpleado
        '
        Me.CeldaCodigoEmpleado.Location = New System.Drawing.Point(186, 23)
        Me.CeldaCodigoEmpleado.Name = "CeldaCodigoEmpleado"
        Me.CeldaCodigoEmpleado.ReadOnly = True
        Me.CeldaCodigoEmpleado.Size = New System.Drawing.Size(101, 20)
        Me.CeldaCodigoEmpleado.TabIndex = 30
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(19, 108)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 13)
        Me.Label13.TabIndex = 15
        Me.Label13.Text = "Bonificación"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(47, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Fecha de inicio"
        '
        'dtpInicio
        '
        Me.dtpInicio.Checked = False
        Me.dtpInicio.Location = New System.Drawing.Point(35, 43)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(198, 20)
        Me.dtpInicio.TabIndex = 2
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(19, 153)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 13)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Bono (extra)"
        '
        'ContenedorDias
        '
        Me.ContenedorDias.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ContenedorDias.Controls.Add(Me.checkDomingo)
        Me.ContenedorDias.Controls.Add(Me.checkSabado)
        Me.ContenedorDias.Controls.Add(Me.checkViernes)
        Me.ContenedorDias.Controls.Add(Me.checkJueves)
        Me.ContenedorDias.Controls.Add(Me.checkMiercoles)
        Me.ContenedorDias.Controls.Add(Me.checkMartes)
        Me.ContenedorDias.Controls.Add(Me.checkLunes)
        Me.ContenedorDias.Location = New System.Drawing.Point(773, 33)
        Me.ContenedorDias.Name = "ContenedorDias"
        Me.ContenedorDias.Size = New System.Drawing.Size(105, 206)
        Me.ContenedorDias.TabIndex = 14
        Me.ContenedorDias.TabStop = False
        Me.ContenedorDias.Text = "Días laborales"
        '
        'checkDomingo
        '
        Me.checkDomingo.AutoSize = True
        Me.checkDomingo.Location = New System.Drawing.Point(11, 172)
        Me.checkDomingo.Name = "checkDomingo"
        Me.checkDomingo.Size = New System.Drawing.Size(68, 17)
        Me.checkDomingo.TabIndex = 21
        Me.checkDomingo.Text = "Domingo"
        Me.checkDomingo.UseVisualStyleBackColor = True
        '
        'checkSabado
        '
        Me.checkSabado.AutoSize = True
        Me.checkSabado.Location = New System.Drawing.Point(11, 149)
        Me.checkSabado.Name = "checkSabado"
        Me.checkSabado.Size = New System.Drawing.Size(63, 17)
        Me.checkSabado.TabIndex = 20
        Me.checkSabado.Text = "Sábado"
        Me.checkSabado.UseVisualStyleBackColor = True
        '
        'checkViernes
        '
        Me.checkViernes.AutoSize = True
        Me.checkViernes.Location = New System.Drawing.Point(11, 126)
        Me.checkViernes.Name = "checkViernes"
        Me.checkViernes.Size = New System.Drawing.Size(61, 17)
        Me.checkViernes.TabIndex = 19
        Me.checkViernes.Text = "Viernes"
        Me.checkViernes.UseVisualStyleBackColor = True
        '
        'checkJueves
        '
        Me.checkJueves.AutoSize = True
        Me.checkJueves.Location = New System.Drawing.Point(11, 103)
        Me.checkJueves.Name = "checkJueves"
        Me.checkJueves.Size = New System.Drawing.Size(60, 17)
        Me.checkJueves.TabIndex = 18
        Me.checkJueves.Text = "Jueves"
        Me.checkJueves.UseVisualStyleBackColor = True
        '
        'checkMiercoles
        '
        Me.checkMiercoles.AutoSize = True
        Me.checkMiercoles.Location = New System.Drawing.Point(11, 80)
        Me.checkMiercoles.Name = "checkMiercoles"
        Me.checkMiercoles.Size = New System.Drawing.Size(71, 17)
        Me.checkMiercoles.TabIndex = 17
        Me.checkMiercoles.Text = "Miercoles"
        Me.checkMiercoles.UseVisualStyleBackColor = True
        '
        'checkMartes
        '
        Me.checkMartes.AutoSize = True
        Me.checkMartes.Location = New System.Drawing.Point(11, 57)
        Me.checkMartes.Name = "checkMartes"
        Me.checkMartes.Size = New System.Drawing.Size(58, 17)
        Me.checkMartes.TabIndex = 16
        Me.checkMartes.Text = "Martes"
        Me.checkMartes.UseVisualStyleBackColor = True
        '
        'checkLunes
        '
        Me.checkLunes.AutoSize = True
        Me.checkLunes.Location = New System.Drawing.Point(11, 34)
        Me.checkLunes.Name = "checkLunes"
        Me.checkLunes.Size = New System.Drawing.Size(55, 17)
        Me.checkLunes.TabIndex = 15
        Me.checkLunes.Text = "Lunes"
        Me.checkLunes.UseVisualStyleBackColor = True
        '
        'celdaEstado
        '
        Me.celdaEstado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaEstado.Location = New System.Drawing.Point(558, 23)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.ReadOnly = True
        Me.celdaEstado.Size = New System.Drawing.Size(101, 20)
        Me.celdaEstado.TabIndex = 30
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(539, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Estado del empleado"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.celdaAño)
        Me.Panel5.Controls.Add(Me.Label20)
        Me.Panel5.Controls.Add(Me.Label3)
        Me.Panel5.Controls.Add(Me.celdaEmpleado)
        Me.Panel5.Controls.Add(Me.celdaCodigoContrato)
        Me.Panel5.Controls.Add(Me.celdaEstado)
        Me.Panel5.Controls.Add(Me.Label1)
        Me.Panel5.Controls.Add(Me.Label4)
        Me.Panel5.Controls.Add(Me.botonSelecionar)
        Me.Panel5.Controls.Add(Me.CeldaCodigoEmpleado)
        Me.Panel5.Controls.Add(Me.Label2)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel5.Location = New System.Drawing.Point(0, 112)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(736, 59)
        Me.Panel5.TabIndex = 20
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(10, 23)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(43, 20)
        Me.celdaAño.TabIndex = 32
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(10, 7)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(26, 13)
        Me.Label20.TabIndex = 31
        Me.Label20.Text = "Año"
        '
        'celdaEmpleado
        '
        Me.celdaEmpleado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaEmpleado.Location = New System.Drawing.Point(304, 23)
        Me.celdaEmpleado.Name = "celdaEmpleado"
        Me.celdaEmpleado.ReadOnly = True
        Me.celdaEmpleado.Size = New System.Drawing.Size(229, 20)
        Me.celdaEmpleado.TabIndex = 5
        '
        'botonSelecionar
        '
        Me.botonSelecionar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSelecionar.Location = New System.Drawing.Point(690, 23)
        Me.botonSelecionar.Name = "botonSelecionar"
        Me.botonSelecionar.Size = New System.Drawing.Size(30, 23)
        Me.botonSelecionar.TabIndex = 1
        Me.botonSelecionar.Text = "..."
        Me.botonSelecionar.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel3.Controls.Add(Me.Panel4)
        Me.Panel3.Controls.Add(Me.CeldaTitulo)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 86)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(736, 26)
        Me.Panel3.TabIndex = 7
        '
        'Panel4
        '
        Me.Panel4.Location = New System.Drawing.Point(293, 31)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(200, 100)
        Me.Panel4.TabIndex = 8
        '
        'CeldaTitulo
        '
        Me.CeldaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTitulo.AutoSize = True
        Me.CeldaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTitulo.Location = New System.Drawing.Point(18, 3)
        Me.CeldaTitulo.Name = "CeldaTitulo"
        Me.CeldaTitulo.Size = New System.Drawing.Size(50, 18)
        Me.CeldaTitulo.TabIndex = 0
        Me.CeldaTitulo.Text = "Titulo"
        '
        'PanelDatos
        '
        Me.PanelDatos.Controls.Add(Me.TabPage6)
        Me.PanelDatos.Controls.Add(Me.TabPage1)
        Me.PanelDatos.Controls.Add(Me.TabPage5)
        Me.PanelDatos.Controls.Add(Me.TabPage8)
        Me.PanelDatos.Controls.Add(Me.TabPage7)
        Me.PanelDatos.Location = New System.Drawing.Point(6, 187)
        Me.PanelDatos.Name = "PanelDatos"
        Me.PanelDatos.SelectedIndex = 0
        Me.PanelDatos.Size = New System.Drawing.Size(643, 403)
        Me.PanelDatos.TabIndex = 21
        '
        'TabPage6
        '
        Me.TabPage6.AutoScroll = True
        Me.TabPage6.Controls.Add(Me.celdaDirecionE)
        Me.TabPage6.Controls.Add(Me.Label37)
        Me.TabPage6.Controls.Add(Me.dtpNacimientoE)
        Me.TabPage6.Controls.Add(Me.Label35)
        Me.TabPage6.Controls.Add(Me.celdaMunicipioE)
        Me.TabPage6.Controls.Add(Me.Label36)
        Me.TabPage6.Controls.Add(Me.celdaDPIE)
        Me.TabPage6.Controls.Add(Me.Label38)
        Me.TabPage6.Controls.Add(Me.celdaCedulaE)
        Me.TabPage6.Controls.Add(Me.Label31)
        Me.TabPage6.Controls.Add(Me.celdaNacionalidadE)
        Me.TabPage6.Controls.Add(Me.Label32)
        Me.TabPage6.Controls.Add(Me.CeldaCivielE)
        Me.TabPage6.Controls.Add(Me.Label33)
        Me.TabPage6.Controls.Add(Me.celdaSexoE)
        Me.TabPage6.Controls.Add(Me.Label34)
        Me.TabPage6.Controls.Add(Me.celdaNombreE)
        Me.TabPage6.Controls.Add(Me.Label17)
        Me.TabPage6.Controls.Add(Me.ContenedorDias)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(635, 377)
        Me.TabPage6.TabIndex = 1
        Me.TabPage6.Text = "Empleado"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'celdaDirecionE
        '
        Me.celdaDirecionE.Location = New System.Drawing.Point(25, 335)
        Me.celdaDirecionE.MaxLength = 255
        Me.celdaDirecionE.Name = "celdaDirecionE"
        Me.celdaDirecionE.ReadOnly = True
        Me.celdaDirecionE.Size = New System.Drawing.Size(414, 20)
        Me.celdaDirecionE.TabIndex = 35
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(28, 319)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(52, 13)
        Me.Label37.TabIndex = 34
        Me.Label37.Text = "Dirección"
        '
        'dtpNacimientoE
        '
        Me.dtpNacimientoE.Enabled = False
        Me.dtpNacimientoE.Location = New System.Drawing.Point(25, 374)
        Me.dtpNacimientoE.Name = "dtpNacimientoE"
        Me.dtpNacimientoE.Size = New System.Drawing.Size(194, 20)
        Me.dtpNacimientoE.TabIndex = 33
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(28, 358)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(60, 13)
        Me.Label35.TabIndex = 32
        Me.Label35.Text = "Nacimiento"
        '
        'celdaMunicipioE
        '
        Me.celdaMunicipioE.Location = New System.Drawing.Point(25, 295)
        Me.celdaMunicipioE.MaxLength = 255
        Me.celdaMunicipioE.Name = "celdaMunicipioE"
        Me.celdaMunicipioE.ReadOnly = True
        Me.celdaMunicipioE.Size = New System.Drawing.Size(194, 20)
        Me.celdaMunicipioE.TabIndex = 29
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(28, 279)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(56, 13)
        Me.Label36.TabIndex = 26
        Me.Label36.Text = "Emitido en"
        '
        'celdaDPIE
        '
        Me.celdaDPIE.Location = New System.Drawing.Point(25, 253)
        Me.celdaDPIE.MaxLength = 255
        Me.celdaDPIE.Name = "celdaDPIE"
        Me.celdaDPIE.ReadOnly = True
        Me.celdaDPIE.Size = New System.Drawing.Size(194, 20)
        Me.celdaDPIE.TabIndex = 31
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(31, 237)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(25, 13)
        Me.Label38.TabIndex = 28
        Me.Label38.Text = "DPI"
        '
        'celdaCedulaE
        '
        Me.celdaCedulaE.Location = New System.Drawing.Point(25, 209)
        Me.celdaCedulaE.MaxLength = 255
        Me.celdaCedulaE.Name = "celdaCedulaE"
        Me.celdaCedulaE.ReadOnly = True
        Me.celdaCedulaE.Size = New System.Drawing.Size(194, 20)
        Me.celdaCedulaE.TabIndex = 22
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(26, 193)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(40, 13)
        Me.Label31.TabIndex = 18
        Me.Label31.Text = "Cédula"
        '
        'celdaNacionalidadE
        '
        Me.celdaNacionalidadE.Location = New System.Drawing.Point(25, 170)
        Me.celdaNacionalidadE.MaxLength = 255
        Me.celdaNacionalidadE.Name = "celdaNacionalidadE"
        Me.celdaNacionalidadE.ReadOnly = True
        Me.celdaNacionalidadE.Size = New System.Drawing.Size(194, 20)
        Me.celdaNacionalidadE.TabIndex = 23
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(26, 154)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(69, 13)
        Me.Label32.TabIndex = 19
        Me.Label32.Text = "Nacionalidad"
        '
        'CeldaCivielE
        '
        Me.CeldaCivielE.Location = New System.Drawing.Point(25, 126)
        Me.CeldaCivielE.MaxLength = 255
        Me.CeldaCivielE.Name = "CeldaCivielE"
        Me.CeldaCivielE.ReadOnly = True
        Me.CeldaCivielE.Size = New System.Drawing.Size(194, 20)
        Me.CeldaCivielE.TabIndex = 24
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(28, 110)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(62, 13)
        Me.Label33.TabIndex = 20
        Me.Label33.Text = "Estado Civil"
        '
        'celdaSexoE
        '
        Me.celdaSexoE.Location = New System.Drawing.Point(25, 87)
        Me.celdaSexoE.MaxLength = 255
        Me.celdaSexoE.Name = "celdaSexoE"
        Me.celdaSexoE.ReadOnly = True
        Me.celdaSexoE.Size = New System.Drawing.Size(194, 20)
        Me.celdaSexoE.TabIndex = 25
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(31, 71)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(31, 13)
        Me.Label34.TabIndex = 21
        Me.Label34.Text = "Sexo"
        '
        'celdaNombreE
        '
        Me.celdaNombreE.Location = New System.Drawing.Point(25, 48)
        Me.celdaNombreE.MaxLength = 255
        Me.celdaNombreE.Name = "celdaNombreE"
        Me.celdaNombreE.ReadOnly = True
        Me.celdaNombreE.Size = New System.Drawing.Size(414, 20)
        Me.celdaNombreE.TabIndex = 16
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(26, 31)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(44, 13)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "Nombre"
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.celdaIdRepresentante)
        Me.TabPage1.Controls.Add(Me.botonSelecionarR)
        Me.TabPage1.Controls.Add(Me.dtpNacimientoR)
        Me.TabPage1.Controls.Add(Me.Label30)
        Me.TabPage1.Controls.Add(Me.celdaMunicipioR)
        Me.TabPage1.Controls.Add(Me.Label29)
        Me.TabPage1.Controls.Add(Me.celdaDPIR)
        Me.TabPage1.Controls.Add(Me.Label27)
        Me.TabPage1.Controls.Add(Me.celdaCedulaR)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.celdaNacionalidadR)
        Me.TabPage1.Controls.Add(Me.Label25)
        Me.TabPage1.Controls.Add(Me.celdaCivilR)
        Me.TabPage1.Controls.Add(Me.Label24)
        Me.TabPage1.Controls.Add(Me.celdaSexoR)
        Me.TabPage1.Controls.Add(Me.Label23)
        Me.TabPage1.Controls.Add(Me.celdaNombreR)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(635, 377)
        Me.TabPage1.TabIndex = 4
        Me.TabPage1.Text = "Representante"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'celdaIdRepresentante
        '
        Me.celdaIdRepresentante.Location = New System.Drawing.Point(454, 70)
        Me.celdaIdRepresentante.Name = "celdaIdRepresentante"
        Me.celdaIdRepresentante.ReadOnly = True
        Me.celdaIdRepresentante.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdRepresentante.TabIndex = 19
        Me.celdaIdRepresentante.Text = "4"
        Me.celdaIdRepresentante.Visible = False
        '
        'botonSelecionarR
        '
        Me.botonSelecionarR.Location = New System.Drawing.Point(454, 29)
        Me.botonSelecionarR.Name = "botonSelecionarR"
        Me.botonSelecionarR.Size = New System.Drawing.Size(34, 23)
        Me.botonSelecionarR.TabIndex = 18
        Me.botonSelecionarR.Text = "..."
        Me.botonSelecionarR.UseVisualStyleBackColor = True
        '
        'dtpNacimientoR
        '
        Me.dtpNacimientoR.Enabled = False
        Me.dtpNacimientoR.Location = New System.Drawing.Point(31, 315)
        Me.dtpNacimientoR.Name = "dtpNacimientoR"
        Me.dtpNacimientoR.Size = New System.Drawing.Size(213, 20)
        Me.dtpNacimientoR.TabIndex = 3
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(34, 299)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(60, 13)
        Me.Label30.TabIndex = 2
        Me.Label30.Text = "Nacimiento"
        '
        'celdaMunicipioR
        '
        Me.celdaMunicipioR.Location = New System.Drawing.Point(31, 276)
        Me.celdaMunicipioR.MaxLength = 255
        Me.celdaMunicipioR.Name = "celdaMunicipioR"
        Me.celdaMunicipioR.ReadOnly = True
        Me.celdaMunicipioR.Size = New System.Drawing.Size(213, 20)
        Me.celdaMunicipioR.TabIndex = 1
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(34, 260)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(52, 13)
        Me.Label29.TabIndex = 0
        Me.Label29.Text = "Municipio"
        '
        'celdaDPIR
        '
        Me.celdaDPIR.Location = New System.Drawing.Point(31, 231)
        Me.celdaDPIR.MaxLength = 255
        Me.celdaDPIR.Name = "celdaDPIR"
        Me.celdaDPIR.ReadOnly = True
        Me.celdaDPIR.Size = New System.Drawing.Size(213, 20)
        Me.celdaDPIR.TabIndex = 1
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(37, 215)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(25, 13)
        Me.Label27.TabIndex = 0
        Me.Label27.Text = "DPI"
        '
        'celdaCedulaR
        '
        Me.celdaCedulaR.Location = New System.Drawing.Point(31, 192)
        Me.celdaCedulaR.MaxLength = 255
        Me.celdaCedulaR.Name = "celdaCedulaR"
        Me.celdaCedulaR.ReadOnly = True
        Me.celdaCedulaR.Size = New System.Drawing.Size(213, 20)
        Me.celdaCedulaR.TabIndex = 1
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(32, 176)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(40, 13)
        Me.Label26.TabIndex = 0
        Me.Label26.Text = "Cédula"
        '
        'celdaNacionalidadR
        '
        Me.celdaNacionalidadR.Location = New System.Drawing.Point(31, 153)
        Me.celdaNacionalidadR.MaxLength = 255
        Me.celdaNacionalidadR.Name = "celdaNacionalidadR"
        Me.celdaNacionalidadR.ReadOnly = True
        Me.celdaNacionalidadR.Size = New System.Drawing.Size(213, 20)
        Me.celdaNacionalidadR.TabIndex = 1
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(32, 137)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(69, 13)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Nacionalidad"
        '
        'celdaCivilR
        '
        Me.celdaCivilR.Location = New System.Drawing.Point(31, 109)
        Me.celdaCivilR.MaxLength = 255
        Me.celdaCivilR.Name = "celdaCivilR"
        Me.celdaCivilR.ReadOnly = True
        Me.celdaCivilR.Size = New System.Drawing.Size(213, 20)
        Me.celdaCivilR.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(34, 93)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "Estado Civil"
        '
        'celdaSexoR
        '
        Me.celdaSexoR.Location = New System.Drawing.Point(31, 70)
        Me.celdaSexoR.MaxLength = 255
        Me.celdaSexoR.Name = "celdaSexoR"
        Me.celdaSexoR.ReadOnly = True
        Me.celdaSexoR.Size = New System.Drawing.Size(213, 20)
        Me.celdaSexoR.TabIndex = 1
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(37, 54)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(31, 13)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Sexo"
        '
        'celdaNombreR
        '
        Me.celdaNombreR.Location = New System.Drawing.Point(31, 31)
        Me.celdaNombreR.MaxLength = 255
        Me.celdaNombreR.Name = "celdaNombreR"
        Me.celdaNombreR.ReadOnly = True
        Me.celdaNombreR.Size = New System.Drawing.Size(417, 20)
        Me.celdaNombreR.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(28, 13)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(44, 13)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "Nombre"
        '
        'TabPage5
        '
        Me.TabPage5.AutoScroll = True
        Me.TabPage5.Controls.Add(Me.celdaDireccionR)
        Me.TabPage5.Controls.Add(Me.Label28)
        Me.TabPage5.Controls.Add(Me.comboDuracion)
        Me.TabPage5.Controls.Add(Me.Label5)
        Me.TabPage5.Controls.Add(Me.dtpInicio)
        Me.TabPage5.Controls.Add(Me.Label7)
        Me.TabPage5.Controls.Add(Me.comboCentro)
        Me.TabPage5.Controls.Add(Me.dtpFin)
        Me.TabPage5.Controls.Add(Me.Label8)
        Me.TabPage5.Controls.Add(Me.Label6)
        Me.TabPage5.Controls.Add(Me.ComboDepartamento)
        Me.TabPage5.Controls.Add(Me.Label16)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(635, 377)
        Me.TabPage5.TabIndex = 0
        Me.TabPage5.Text = "Contrato"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'celdaDireccionR
        '
        Me.celdaDireccionR.Location = New System.Drawing.Point(35, 239)
        Me.celdaDireccionR.MaxLength = 255
        Me.celdaDireccionR.Name = "celdaDireccionR"
        Me.celdaDireccionR.ReadOnly = True
        Me.celdaDireccionR.Size = New System.Drawing.Size(569, 20)
        Me.celdaDireccionR.TabIndex = 6
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(38, 223)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(52, 13)
        Me.Label28.TabIndex = 14
        Me.Label28.Text = "Dirección"
        '
        'TabPage8
        '
        Me.TabPage8.AutoScroll = True
        Me.TabPage8.Controls.Add(Me.ListaHorarios)
        Me.TabPage8.Controls.Add(Me.botonAgregar)
        Me.TabPage8.Controls.Add(Me.Label19)
        Me.TabPage8.Controls.Add(Me.comboHorario)
        Me.TabPage8.Controls.Add(Me.Label18)
        Me.TabPage8.Controls.Add(Me.comboJornada)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(635, 377)
        Me.TabPage8.TabIndex = 3
        Me.TabPage8.Text = "Horarios"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'ListaHorarios
        '
        Me.ListaHorarios.AllowUserToAddRows = False
        Me.ListaHorarios.AllowUserToOrderColumns = True
        Me.ListaHorarios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ListaHorarios.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaHorarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaHorarios.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.horario, Me.jornda, Me.horainicio, Me.horafin})
        Me.ListaHorarios.Location = New System.Drawing.Point(16, 108)
        Me.ListaHorarios.MultiSelect = False
        Me.ListaHorarios.Name = "ListaHorarios"
        Me.ListaHorarios.ReadOnly = True
        Me.ListaHorarios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaHorarios.Size = New System.Drawing.Size(517, 173)
        Me.ListaHorarios.TabIndex = 10
        '
        'id
        '
        Me.id.HeaderText = "idhorario"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Visible = False
        Me.id.Width = 72
        '
        'horario
        '
        Me.horario.HeaderText = "Horario"
        Me.horario.Name = "horario"
        Me.horario.ReadOnly = True
        Me.horario.Width = 66
        '
        'jornda
        '
        Me.jornda.HeaderText = "Jornada"
        Me.jornda.Name = "jornda"
        Me.jornda.ReadOnly = True
        Me.jornda.Width = 70
        '
        'horainicio
        '
        Me.horainicio.HeaderText = "Hora inicio"
        Me.horainicio.Name = "horainicio"
        Me.horainicio.ReadOnly = True
        Me.horainicio.Width = 82
        '
        'horafin
        '
        Me.horafin.HeaderText = "Hora fin"
        Me.horafin.Name = "horafin"
        Me.horafin.ReadOnly = True
        Me.horafin.Width = 69
        '
        'botonAgregar
        '
        Me.botonAgregar.Location = New System.Drawing.Point(288, 79)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(75, 23)
        Me.botonAgregar.TabIndex = 3
        Me.botonAgregar.Text = "Agregar"
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(13, 65)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(41, 13)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "Horario"
        '
        'comboHorario
        '
        Me.comboHorario.FormattingEnabled = True
        Me.comboHorario.Location = New System.Drawing.Point(16, 81)
        Me.comboHorario.Name = "comboHorario"
        Me.comboHorario.Size = New System.Drawing.Size(254, 21)
        Me.comboHorario.TabIndex = 2
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(13, 12)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(45, 13)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Jornada"
        '
        'comboJornada
        '
        Me.comboJornada.FormattingEnabled = True
        Me.comboJornada.Location = New System.Drawing.Point(16, 28)
        Me.comboJornada.Name = "comboJornada"
        Me.comboJornada.Size = New System.Drawing.Size(254, 21)
        Me.comboJornada.TabIndex = 1
        '
        'TabPage7
        '
        Me.TabPage7.AutoScroll = True
        Me.TabPage7.Controls.Add(Me.Label21)
        Me.TabPage7.Controls.Add(Me.celdaDescripcionPuesto)
        Me.TabPage7.Controls.Add(Me.Label9)
        Me.TabPage7.Controls.Add(Me.ComboPuesto)
        Me.TabPage7.Controls.Add(Me.Label11)
        Me.TabPage7.Controls.Add(Me.celdaISR)
        Me.TabPage7.Controls.Add(Me.celdaBono)
        Me.TabPage7.Controls.Add(Me.Label15)
        Me.TabPage7.Controls.Add(Me.Label10)
        Me.TabPage7.Controls.Add(Me.celdaSueldo)
        Me.TabPage7.Controls.Add(Me.Label14)
        Me.TabPage7.Controls.Add(Me.comboPlanilla)
        Me.TabPage7.Controls.Add(Me.comboMoneda)
        Me.TabPage7.Controls.Add(Me.celdaBonificacion)
        Me.TabPage7.Controls.Add(Me.Label13)
        Me.TabPage7.Controls.Add(Me.Label12)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(635, 377)
        Me.TabPage7.TabIndex = 2
        Me.TabPage7.Text = "Salario"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(270, 15)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(113, 13)
        Me.Label21.TabIndex = 19
        Me.Label21.Text = "Descripción de puesto"
        '
        'celdaDescripcionPuesto
        '
        Me.celdaDescripcionPuesto.Location = New System.Drawing.Point(264, 31)
        Me.celdaDescripcionPuesto.MaxLength = 255
        Me.celdaDescripcionPuesto.Multiline = True
        Me.celdaDescripcionPuesto.Name = "celdaDescripcionPuesto"
        Me.celdaDescripcionPuesto.Size = New System.Drawing.Size(342, 319)
        Me.celdaDescripcionPuesto.TabIndex = 8
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(31, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Puesto"
        '
        'ComboPuesto
        '
        Me.ComboPuesto.FormattingEnabled = True
        Me.ComboPuesto.ItemHeight = 13
        Me.ComboPuesto.Location = New System.Drawing.Point(19, 31)
        Me.ComboPuesto.Name = "ComboPuesto"
        Me.ComboPuesto.Size = New System.Drawing.Size(227, 21)
        Me.ComboPuesto.TabIndex = 1
        '
        'ListaContratos
        '
        Me.ListaContratos.AllowUserToAddRows = False
        Me.ListaContratos.AllowUserToDeleteRows = False
        Me.ListaContratos.AllowUserToOrderColumns = True
        Me.ListaContratos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.ListaContratos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.ListaContratos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ListaContratos.Location = New System.Drawing.Point(655, 408)
        Me.ListaContratos.MultiSelect = False
        Me.ListaContratos.Name = "ListaContratos"
        Me.ListaContratos.ReadOnly = True
        Me.ListaContratos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.ListaContratos.Size = New System.Drawing.Size(120, 93)
        Me.ListaContratos.TabIndex = 22
        '
        'frmPContratos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(736, 594)
        Me.Controls.Add(Me.ListaContratos)
        Me.Controls.Add(Me.PanelDatos)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmPContratos"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContenedorDias.ResumeLayout(False)
        Me.ContenedorDias.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.PanelDatos.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        CType(Me.ListaHorarios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        CType(Me.ListaContratos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonBorrar As System.Windows.Forms.Button
    Friend WithEvents botonGuardar As System.Windows.Forms.Button
    Friend WithEvents botonNuevo As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents botonSelecionar As System.Windows.Forms.Button
    Friend WithEvents celdaEmpleado As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents celdaBono As System.Windows.Forms.TextBox
    Friend WithEvents celdaISR As System.Windows.Forms.TextBox
    Friend WithEvents celdaBonificacion As System.Windows.Forms.TextBox
    Friend WithEvents celdaSueldo As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ComboDepartamento As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents comboDuracion As System.Windows.Forms.ComboBox
    Friend WithEvents comboMoneda As System.Windows.Forms.ComboBox
    Friend WithEvents comboPlanilla As System.Windows.Forms.ComboBox
    Friend WithEvents comboCentro As System.Windows.Forms.ComboBox
    Friend WithEvents ContenedorDias As System.Windows.Forms.GroupBox
    Friend WithEvents checkDomingo As System.Windows.Forms.CheckBox
    Friend WithEvents checkSabado As System.Windows.Forms.CheckBox
    Friend WithEvents checkViernes As System.Windows.Forms.CheckBox
    Friend WithEvents checkJueves As System.Windows.Forms.CheckBox
    Friend WithEvents checkMiercoles As System.Windows.Forms.CheckBox
    Friend WithEvents checkMartes As System.Windows.Forms.CheckBox
    Friend WithEvents checkLunes As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents celdaEstado As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents celdaCodigoContrato As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents CeldaCodigoEmpleado As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents CeldaTitulo As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents botonExportar As System.Windows.Forms.Button
    Friend WithEvents PanelDatos As System.Windows.Forms.TabControl
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents ListaContratos As System.Windows.Forms.DataGridView
    Friend WithEvents celdaNombreE As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents comboHorario As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents comboJornada As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents celdaNombreR As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents celdaCivilR As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents celdaSexoR As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents celdaDPIR As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents celdaCedulaR As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents celdaNacionalidadR As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents dtpNacimientoR As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents celdaMunicipioR As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents dtpNacimientoE As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents celdaMunicipioE As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents celdaDPIE As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents celdaCedulaE As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents celdaNacionalidadE As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents CeldaCivielE As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents celdaSexoE As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents botonSelecionarR As System.Windows.Forms.Button
    Friend WithEvents celdaIdRepresentante As System.Windows.Forms.TextBox
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents ListaHorarios As System.Windows.Forms.DataGridView
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents celdaDireccionR As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ComboPuesto As System.Windows.Forms.ComboBox
    Friend WithEvents celdaDirecionE As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents celdaDescripcionPuesto As System.Windows.Forms.TextBox
    Friend WithEvents id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents horario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents jornda As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents horainicio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents horafin As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
