﻿Public Class frmPSelecionarEmpleado
    Dim cEmpleados As New clsEmpleado

#Region "Variables"
    Dim intIdEmpresa As Integer = NO_FILA
    Dim intEstado As Integer = INT_CERO
    Dim intIdEmpleado As Integer = NO_FILA
    Dim strDescripcion As String = STR_VACIO
    Dim strSexo As String = STR_VACIO
    Dim strEstadoCivil As String = STR_VACIO
    Dim dateFechaNacimiento As MySqlDateTime
    Dim strNacionalidad As String = STR_VACIO
    Dim strCedula As String = STR_VACIO
    Dim strDPI As String = STR_VACIO
    Dim strDireccion As String = STR_VACIO
    Dim strMunicipio As String = STR_VACIO
#End Region

#Region "Propiedades"
    Public Property idEmpleado As Integer
        Get
            Return intIdEmpleado
        End Get
        Set(value As Integer)
            intIdEmpleado = value
        End Set
    End Property

    Public Property idEmpresa As Integer
        Get
            Return intIdEmpresa
        End Get
        Set(value As Integer)
            intIdEmpresa = value
        End Set
    End Property

    Public Property Estado As Integer
        Get
            Return intEstado
        End Get
        Set(value As Integer)
            intEstado = value
        End Set
    End Property
   
    Public Property Descripcion As String
        Get
            Return strDescripcion
        End Get
        Set(value As String)
            strDescripcion = value
        End Set
    End Property

    Public Property Sexo As String
        Get
            Return strSexo
        End Get
        Set(value As String)
            strSexo = value
        End Set
    End Property

    Public Property EstadoCivil As String
        Get
            Return strEstadoCivil
        End Get
        Set(value As String)
            strEstadoCivil = value
        End Set
    End Property

    

    Public Property FechaNacimiento As MySqlDateTime
        Get
            Return dateFechaNacimiento
        End Get
        Set(value As MySqlDateTime)
            dateFechaNacimiento = value
        End Set
    End Property

    Public WriteOnly Property FechaNacimiento_Net As Date
        Set(value As Date)
            dateFechaNacimiento = New MySqlDateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second)
        End Set
    End Property

    Public Property Nacionalidad As String
        Get
            Return strNacionalidad
        End Get
        Set(value As String)
            strNacionalidad = value
        End Set
    End Property

    Public Property Cedula As String
        Get
            Return strCedula
        End Get
        Set(value As String)
            strCedula = value
        End Set
    End Property

    Public Property DPI As String
        Get
            Return strDPI
        End Get
        Set(value As String)
            strDPI = value
        End Set
    End Property

    Public Property Direccion As String
        Get
            Return strDireccion
        End Get
        Set(value As String)
            strDireccion = value
        End Set
    End Property

    Public Property Municipio As String
        Get
            Return strMunicipio
        End Get
        Set(value As String)
            strMunicipio = value
        End Set
    End Property

#End Region

    Private Sub frmPSelecionarEmpleado_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim strSQL As String = STR_VACIO
        strSQL = "SELECT e.em_codigo Codigo, e.em_descripcion Nombre, ELT(e.em_estado+1,'INACTIVO','') Estado FROM Empleados e " & _
               "WHERE e.em_empresa={0} ORDER BY e.em_estado DESC, e.em_descripcion"
        strSQL = Replace(strSQL, "{0}", Sesion.IdEmpresa)
        cFunciones.CargarLista(ListaEmpleados, strSQL)
    End Sub

    Private Sub ListaEmpleados_DoubleClick(sender As Object, e As EventArgs) Handles ListaEmpleados.DoubleClick
        Dim id As Integer = NO_FILA
        Dim strcondicion As String = STR_VACIO
        If ListaEmpleados.SelectedRows.Count = 0 Then Exit Sub
        id = ListaEmpleados.SelectedCells(INT_CERO).Value
        strcondicion = "em_empresa = {idempresa} And em_codigo = {id}"
        strcondicion = Replace(strcondicion, "{idempresa}", Sesion.IdEmpresa)
        strcondicion = Replace(strcondicion, "{id}", id)
        If cEmpleados.Seleccionar("*", strcondicion) = True Then
            intIdEmpresa = cEmpleados.idEmpresa
            intEstado = cEmpleados.Estado
            intIdEmpleado = cEmpleados.idEmpleado
            strDescripcion = cEmpleados.Descripcion
            strSexo = cEmpleados.Sexo
            strEstadoCivil = cEmpleados.EstadoCivil
            dateFechaNacimiento = cEmpleados.FechaNacimiento
            strNacionalidad = cEmpleados.Nacionalidad
            strCedula = cEmpleados.Cedula
            strDPI = cEmpleados.DPI
            strDireccion = cEmpleados.Direccion
            strMunicipio = cEmpleados.ExtendidaEn
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
        End If
    End Sub
End Class