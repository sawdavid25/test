﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDateTimePicker
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.panelCalendar = New System.Windows.Forms.Panel()
        Me.botonSeleccionar = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.panelCalendar.SuspendLayout()
        Me.SuspendLayout()
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(0, 0)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(267, 22)
        Me.DateTimePicker1.TabIndex = 0
        '
        'panelCalendar
        '
        Me.panelCalendar.Controls.Add(Me.DateTimePicker1)
        Me.panelCalendar.Location = New System.Drawing.Point(16, 15)
        Me.panelCalendar.Margin = New System.Windows.Forms.Padding(4)
        Me.panelCalendar.Name = "panelCalendar"
        Me.panelCalendar.Size = New System.Drawing.Size(267, 26)
        Me.panelCalendar.TabIndex = 1
        '
        'botonSeleccionar
        '
        Me.botonSeleccionar.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonSeleccionar.Location = New System.Drawing.Point(83, 68)
        Me.botonSeleccionar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonSeleccionar.Name = "botonSeleccionar"
        Me.botonSeleccionar.Size = New System.Drawing.Size(96, 55)
        Me.botonSeleccionar.TabIndex = 4
        Me.botonSeleccionar.Text = "&Seleccionar"
        Me.botonSeleccionar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonSeleccionar.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(187, 68)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(96, 55)
        Me.botonCancelar.TabIndex = 5
        Me.botonCancelar.Text = "&Cancelar"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'frmDateTimePicker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(293, 138)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonSeleccionar)
        Me.Controls.Add(Me.panelCalendar)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmDateTimePicker"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmDateTimePicker"
        Me.panelCalendar.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents panelCalendar As System.Windows.Forms.Panel
    Friend WithEvents botonSeleccionar As System.Windows.Forms.Button
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
End Class
