﻿Public Class frmPEmpleados
    Dim cNomina As New ClsNomina
    Dim cEmpleados As New clsEmpleado
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim dtlempleados As New Tablas.TDTL_EMPLEADOS
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property
#Region "Funciones y Procedimientos"

    Private Sub reset()
        celdaNombre1.Text = STR_VACIO
        celdaNombre2.Text = STR_VACIO
        celdaNombre3.Text = STR_VACIO
        celdaApellido1.Text = STR_VACIO
        celdaApellido2.Text = STR_VACIO
        celdaApellidoCasada.Text = STR_VACIO
        celdaDescripcion.Text = STR_VACIO
        celdaCedula.Text = STR_VACIO
        celdaDPI.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaNacionalidad.Text = STR_VACIO
        comboSexo.Text = "MASCULINO"
        comboEstadoCivil.Text = "SOLTERO"
        celdaConyugue.Text = STR_VACIO
        celdaMunicipio.Text = STR_VACIO
        celdaIgss.Text = STR_VACIO
        celdaIrtra.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        celdaTelefono1.Text = STR_VACIO
        celdaTelefono2.Text = STR_VACIO
        TextBox1.Text = STR_VACIO
        celdaObservaciones.Text = STR_VACIO
        TextBox1.BackColor = Color.White
        celdaNombre1.BackColor = Color.White
        celdaNombre2.BackColor = Color.White
        celdaNombre3.BackColor = Color.White
        celdaApellido1.BackColor = Color.White
        celdaApellido2.BackColor = Color.White
        celdaApellidoCasada.BackColor = Color.White
        celdaDescripcion.BackColor = Color.White
        celdaCedula.BackColor = Color.White
        celdaDPI.BackColor = Color.White
        celdaNit.BackColor = Color.White
        celdaNacionalidad.BackColor = Color.White
        comboSexo.BackColor = Color.White
        comboEstadoCivil.BackColor = Color.White
        celdaConyugue.BackColor = Color.White
        celdaMunicipio.BackColor = Color.White
        celdaIgss.BackColor = Color.White
        celdaIrtra.BackColor = Color.White
        celdaDireccion.BackColor = Color.White
        celdaTelefono1.BackColor = Color.White
        celdaTelefono2.BackColor = Color.White
        cuadroFoto.Image = Nothing
    End Sub

    Public Function llenarCentro(ByVal codCentro As Integer) As String
        Dim strSQL As String = STR_VACIO
        Dim Centro As String = STR_VACIO
        Dim CON As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = "SELECT cost_nombre From " & _
                 cfun.ContaEmpresa & ".costos " & _
                 "WHERE cost_num = {centro} "

        strSQL = Replace(strSQL, "{centro}", codCentro)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            Centro = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Centro

    End Function

    Private Sub Selecionar()
        If logConsultar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        Dim id As Integer = NO_FILA
        Dim strcondicion As String = STR_VACIO
        If listaEmpleados.SelectedRows.Count = INT_CERO Then Exit Sub
        id = listaEmpleados.SelectedCells(INT_CERO).Value
        strcondicion = "em_empresa = {idempresa} And em_codigo = {id}"
        strcondicion = Replace(strcondicion, "{idempresa}", Sesion.IdEmpresa)
        strcondicion = Replace(strcondicion, "{id}", id)
        If cEmpleados.Seleccionar(STR_ASTERISCO, strcondicion) = True Then
            If cEmpleados.Estado = 0 Then
                CheckActivo.Checked = False
            Else
                CheckActivo.Checked = True
            End If
            celdaCodigo.Text = cEmpleados.idEmpleado
            celdaNombre1.Text = cEmpleados.Nombre1
            celdaNombre2.Text = cEmpleados.Nombre2
            celdaNombre3.Text = cEmpleados.Nombre3
            celdaApellido1.Text = cEmpleados.Apellido1
            celdaApellido2.Text = cEmpleados.Apellido2
            celdaApellidoCasada.Text = cEmpleados.Apellido3
            celdaDescripcion.Text = cEmpleados.Descripcion
            celdaCedula.Text = cEmpleados.Cedula
            celdaDPI.Text = cEmpleados.DPI
            celdaNit.Text = cEmpleados.Nit
            celdaNacionalidad.Text = cEmpleados.Nacionalidad
            comboSexo.Text = cEmpleados.Sexo
            comboEstadoCivil.Text = cEmpleados.EstadoCivil
            celdaConyugue.Text = cEmpleados.Conyugue
            celdaMunicipio.Text = cEmpleados.Municipio
            celdaIgss.Text = cEmpleados.Igss
            celdaIrtra.Text = cEmpleados.Irtra
            celdaDireccion.Text = cEmpleados.Direccion
            celdaTelefono1.Text = cEmpleados.Telefono1
            celdaTelefono2.Text = cEmpleados.Telefono2
            celdaObservaciones.Text = cEmpleados.Observaciones
            CeldaDeposito.Text = cEmpleados.Depositos
            TextBox1.Text = cEmpleados.ExtendidaEn
            lblcodCentro.Text = cEmpleados.CentroCosto

            CeldaCentro.Text = llenarCentro(CInt(lblcodCentro.Text))


            If cEmpleados.FechaNacimiento.IsValidDateTime Then
                dtpFNacimiento.Value = cEmpleados.FechaNacimiento
            End If


        cuadroFoto.Image = Nothing
        MostrarLista(False)
        Me.Tag = "mod"
        End If

    End Sub

    Private Function QueryHistorico(ByVal empleado As Integer) As String
        Dim Historico As String = STR_VACIO

        Historico = "SELECT A.Demp_Lin Linea, A.Demp_Fecha Creacion,B.cat_desc Descripcion,A.Demp_RF1_Dbl Monto,A.Demp_Inicio Incio,A.Demp_Fin Fin     " & _
                    "FROM  DTL_Empleados A     " & _
                    "LEFT JOIN Catalogos B on B.cat_num = A.Demp_Tipo     " & _
                    "WHERE A.Demp_Sis_Emp = {empresa} AND Demp_Codigo = {empleado}  " & _
                    "Order by A.Demp_Lin "

        Historico = Replace(Historico, "{empresa}", Sesion.IdEmpresa)
        Historico = Replace(Historico, "{empleado}", empleado)

        Return Historico
    End Function

    Public Sub MostrarCentro(Optional ByVal logMostrar As Boolean = True)


        If logMostrar = True Then

            CeldaCentro.Visible = False
            BotonCentro.Visible = False
            lblcodCentro.Visible = False

        Else

            CeldaCentro.Visible = True
            BotonCentro.Visible = True
            lblcodCentro.Visible = True

        End If




    End Sub

    Private Sub MostrarLista(Optional ByVal log As Boolean = True)
        Dim strSQL As String = ""
        Dim strHistorico As String = STR_VACIO
        If log = True Then
            listaEmpleados.Visible = True
            listaEmpleados.Dock = DockStyle.Fill
            ContenedorPrincipal.Visible = False
            ContenedorPrincipal.Dock = DockStyle.None
            ' pnlHistorial.Dock = DockStyle.Fill
            strSQL = "SELECT e.em_codigo Codigo, e.em_descripcion Nombre, ELT(e.em_estado+1,'INACTIVO','ACTIVO') Estado FROM Empleados e " & _
                "WHERE e.em_empresa={0} ORDER BY e.em_estado DESC, e.em_descripcion"
            strSQL = Replace(strSQL, "{0}", Sesion.IdEmpresa)
            cNomina.CargarLista(listaEmpleados, strSQL)
            BloquearBotones()
            reset()
            CeldaTitulo.Text = "Centros de trabajo"
        Else
            ContenedorPrincipal.Visible = True
            ContenedorPrincipal.Dock = DockStyle.Fill
            strHistorico = QueryHistorico(celdaCodigo.Text)
            cFunciones.CargarLista(dgvHistorico, strHistorico)
            pnlAumento.Visible = False
            listaEmpleados.Visible = False
            listaEmpleados.Dock = DockStyle.None
            CeldaTitulo.Text = "Modificar Registro"
            celdaNombre1.Focus()
            BloquearBotones(False)
        End If
    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim logOk As Boolean = False
        If celdaNombre1.Text.Length <= 0 Or celdaApellido1.Text.Length <= 0 Or celdaNacionalidad.Text.Length <= 0 Or celdaDireccion.Text.Length <= 0 Then
            If celdaNombre1.Text.Length <= 0 Then
                celdaNombre1.BackColor = Color.Coral
            Else
                celdaNombre1.BackColor = Color.White
            End If
            If celdaApellido1.Text.Length <= 0 Then
                celdaApellido1.BackColor = Color.Coral
            Else
                celdaApellido1.BackColor = Color.White
            End If
            If celdaNacionalidad.Text.Length <= 0 Then
                celdaNacionalidad.BackColor = Color.Coral
            Else
                celdaNacionalidad.BackColor = Color.White
            End If
            If comboSexo.Text.Length <= 0 Then
                comboSexo.BackColor = Color.Coral
            Else
                comboSexo.BackColor = Color.White
            End If
            If comboEstadoCivil.Text.Length <= 0 Then
                comboEstadoCivil.BackColor = Color.Coral
            Else
                comboEstadoCivil.BackColor = Color.White
            End If
            If celdaDireccion.Text.Length <= 0 Then
                celdaDireccion.BackColor = Color.Coral
            Else
                celdaDireccion.BackColor = Color.White
            End If
        Else
            logOk = True
        End If
        Return logOk
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            botonBorrar.Enabled = False
            botonGuardar.Enabled = False
        Else
            botonBorrar.Enabled = True
            botonGuardar.Enabled = True
        End If
    End Sub

#End Region

    Private Sub TabControl1_SizeChanged(sender As Object, e As EventArgs) Handles TabPage1.SizeChanged
        If TabPage1.Size.Width < 800 Then
            cuadroFoto.Anchor = AnchorStyles.None
        End If
    End Sub

    Private Sub frmPEmpleados_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmPEmpleados_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cAccesos As New clsAccesos

        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                pnlSuspension.Visible = False
                pnlAumento.Visible = False
                If logConsultar = True Then
                    MostrarLista()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        Dim cEmpleados As New clsEmpleado

        If ComprobarCampos() = False Then
            MsgBox("Ingrese todos los campos obligatorios", MsgBoxStyle.Critical)
        Else
            cEmpleados.idEmpresa = Sesion.IdEmpresa
            cEmpleados.Nombre1 = celdaNombre1.Text
            cEmpleados.Nombre2 = celdaNombre2.Text
            cEmpleados.Nombre3 = celdaNombre3.Text
            cEmpleados.Apellido1 = celdaApellido1.Text
            cEmpleados.Apellido2 = celdaApellido2.Text
            cEmpleados.Apellido3 = celdaApellidoCasada.Text
            cEmpleados.Sexo = comboSexo.Text
            cEmpleados.EstadoCivil = comboEstadoCivil.Text
            cEmpleados.Conyugue = celdaConyugue.Text
            cEmpleados.FechaNacimiento_Net = dtpFNacimiento.Value
            cEmpleados.Nacionalidad = celdaNacionalidad.Text
            cEmpleados.Cedula = celdaCedula.Text
            cEmpleados.DPI = celdaDPI.Text
            cEmpleados.Igss = celdaIgss.Text
            cEmpleados.Irtra = celdaIrtra.Text
            cEmpleados.Nit = celdaNit.Text
            cEmpleados.Direccion = celdaDireccion.Text
            cEmpleados.Municipio = celdaMunicipio.Text
            cEmpleados.Telefono1 = celdaTelefono1.Text
            cEmpleados.Telefono2 = celdaTelefono2.Text
            cEmpleados.Observaciones = celdaObservaciones.Text
            cEmpleados.Cuenta1 = ""
            cEmpleados.Cuenta2 = ""
            cEmpleados.Cuenta3 = ""
            cEmpleados.CentroCosto = CInt(lblcodCentro.Text)

            If CheckActivo.Checked = True Then
                cEmpleados.Estado = 1
            Else
                cEmpleados.Estado = 0
            End If

         
            If CeldaDeposito.Text.Trim.Length > 10 Then
                MsgBox("El numero de cuenta tiene mas de 10 Digitos")
            Else

                cEmpleados.Depositos = CeldaDeposito.Text.PadLeft(10, "0000000000")
            End If


            cEmpleados.ExtendidaEn = TextBox1.Text
            If Me.Tag = "nuevo" Then

             
                If logInsertar = False Then
                    MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                    Exit Sub
                End If
                Try
                    If cEmpleados.Guardar() = False Then
                        MsgBox("No se pudo guardar el registro")
                    Else
                        MostrarLista()
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Else
                If logEditar = False Then
                    MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                    Exit Sub
                End If
                cEmpleados.idEmpleado = celdaCodigo.Text
                If cEmpleados.Actualizar = False Then
                    MsgBox("No se pudo actualizar el registro")
                Else
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub listaEmpleados_DoubleClick(sender As Object, e As EventArgs) Handles listaEmpleados.DoubleClick
        Selecionar()
    End Sub

    Private Sub listaEmpleados_KeyDown(sender As Object, e As KeyEventArgs) Handles listaEmpleados.KeyDown
        Selecionar()
    End Sub

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        If listaEmpleados.Visible = True Then
            MostrarLista(False)
            CeldaDeposito.Text = ""
        End If
        reset()
        Me.Tag = "nuevo"
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        If listaEmpleados.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub dtpFNacimiento_KeyDown(sender As Object, e As KeyEventArgs) Handles dtpFNacimiento.KeyDown
        If e.KeyCode = Keys.Tab Or e.KeyCode = Keys.Enter Then
            TabDatos.SelectedIndex = 1
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub celdaTelefono1_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaTelefono1.KeyDown
        If e.KeyCode = Keys.Tab Or e.KeyCode = Keys.Enter Then
            botonGuardar.Focus()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        If LogBorrar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        Dim cContratos As New clsContrato
        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        strCampos = "HDoc_Emp_Cod"
        strCondicion = "HDoc_Sis_Emp= {empresa} AND HDoc_Emp_Cod = {empleado}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{empleado}", celdaCodigo.Text)
        Try
            If cContratos.Seleccionar(strCampos, strCondicion) = True Then
                MsgBox("No se puede eliminar un Empleado que tenga dependencias", MsgBoxStyle.Critical)
            Else
                If cEmpleados.Borrar = False Then
                    MsgBox("ERROR, No se pudo borrar el registro", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function Scalar(ByVal empleado As Integer, ByVal FechaI As String, ByVal Tipo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim valorS As Integer = INT_CERO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection

        strSQL = "SELECT COUNT(*) " & _
                 "FROM  DTL_Empleados A " & _
                 "WHERE A.Demp_Sis_Emp = {empresa} AND A.Demp_Codigo = {empleado} and A.Demp_tipo = {tipo} " & _
                 "and A.Demp_Inicio = '{FechaI}' "

        strSQL = Replace(strSQL, "{empleado}", empleado)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{FechaI}", FechaI)
        strSQL = Replace(strSQL, "{tipo}", Tipo)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            valorS = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return valorS

    End Function


    Private Sub btnGuardarS_Click(sender As Object, e As EventArgs) Handles btnGuardarS.Click
        Dim Fila As Integer = INT_CERO
        Dim Valor As Integer = INT_CERO
        Dim NombreCompleto As String = STR_VACIO
        Dim CodigoEmpleado As Integer = INT_CERO
        Dim FechaInicio As String = STR_VACIO
        Dim Tipo As Integer = INT_CERO
        Dim CorrelativoE As Integer = INT_CERO


        Fila = dgvHistorico.Rows.Count
        NombreCompleto = celdaNombre1.Text & " " & celdaNombre2.Text & "," & celdaApellido1.Text & " " & celdaApellido2.Text

        dtlempleados.CONEXION = strConexion
        CodigoEmpleado = celdaCodigo.Text
        FechaInicio = dtpInicio.Value.ToString(FORMATO_MYSQL)
        Tipo = 1603

        Valor = Scalar(CodigoEmpleado, FechaInicio, Tipo)
        CorrelativoE = Correlativo()

        dtlempleados.DEMP_SIS_EMP = Sesion.IdEmpresa
        dtlempleados.DEMP_CODIGO = CodigoEmpleado
        dtlempleados.Demp_Fecha_NET = cfun.HoyMySQL
        dtlempleados.DEMP_TIPO = Tipo

        If Valor > 0 Then

            dtlempleados.DEMP_LIN = dgvHistorico.SelectedCells(0).Value
            dtlempleados.Demp_Inicio_NET = CDate(FechaInicio)
            dtlempleados.Demp_Fin_NET = dtpFin.Value

            If chkactivo.Checked = True Then
                dtlempleados.DEMP_STATUS = 1
            Else
                dtlempleados.DEMP_STATUS = 0
            End If

            If dtlempleados.PUPDATE = False Then
                MsgBox(dtlempleados.MERROR.ToString)
            End If

            MessageBox.Show("Se Modifico la Suspension de " & NombreCompleto & "", "Suspension", MessageBoxButtons.OK)
            pnlSuspension.Visible = False
            MostrarLista(False)

        Else

            Try

                dtlempleados.DEMP_LIN = CorrelativoE
                dtlempleados.Demp_Inicio_NET = CDate(FechaInicio)
                dtlempleados.Demp_Fin_NET = dtpFin.Value

                If chkactivo.Checked = True Then
                    dtlempleados.DEMP_STATUS = 1
                Else
                    dtlempleados.DEMP_STATUS = 0
                End If



                If dtlempleados.PINSERT = False Then
                    MsgBox(dtlempleados.MERROR.ToString)

                End If

                MessageBox.Show("Suspension Guardada de " & NombreCompleto & "", "Suspension", MessageBoxButtons.OK)
                pnlSuspension.Visible = False
                MostrarLista(False)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        End If

    End Sub

    Private Sub BuscarSuspension(ByVal Empresa As Integer, ByVal Empleado As Integer, ByVal Linea As Integer)
        Dim strBuscar As String = STR_VACIO
        Dim strInicio As String = STR_VACIO
        Dim strFin As String = STR_VACIO
        Dim Tipo As String = INT_CERO
        Dim intStatus As Integer = INT_CERO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection


        strBuscar = "SELECT A.Demp_Inicio Inicio,ifnull(A.Demp_Fin,'') Fin,A.Demp_Tipo Tipo ,A.Demp_Status Status " & _
                    "FROM  DTL_Empleados A " & _
                    "LEFT JOIN Catalogos B on B.cat_num = A.Demp_Tipo " & _
                    "WHERE A.Demp_Sis_Emp = {empresa} AND Demp_Codigo = {empleado} and Demp_Lin = {linea} "

        strBuscar = Replace(strBuscar, "{empresa}", Empresa)
        strBuscar = Replace(strBuscar, "{empleado}", Empleado)
        strBuscar = Replace(strBuscar, "{linea}", Linea)


        CON = New MySqlConnection(strConexion)
        CON.Open()

        COM = New MySqlCommand(strBuscar, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()

            strInicio = REA.GetDateTime("Inicio")
            strFin = REA.GetDateTime("Fin")
            Tipo = REA.GetInt32("Tipo")
            intStatus = REA.GetInt16("Status")

            If Tipo = 1604 Then

       

                dtpInicio.Value = CDate(strInicio)
                pnlAumento.Visible = True
                pnlAumento.Dock = DockStyle.Fill
                pnlSuspension.Visible = False

            End If

            If Tipo = 1603 Then

                dtpInicio.Value = CDate(strInicio)
                dtpFin.Value = CDate(strFin)
                pnlSuspension.Visible = True

                If intStatus = 1 Then
                    chkactivo.Checked = True
                Else
                    chkactivo.Checked = False
                End If

                pnlAumento.Visible = False

            End If

        End If

        CON.Close()
        REA.Close()

    End Sub

    Private Sub btnSuspension_Click(sender As Object, e As EventArgs) Handles btnSuspension.Click
        pnlSuspension.Visible = True
        pnlSuspension.Dock = DockStyle.Fill
    End Sub

    Private Sub dgvHistorico_DoubleClick(sender As Object, e As EventArgs) Handles dgvHistorico.DoubleClick
        Dim LineaSeleccionad As Integer = INT_CERO
        Dim Empleado As Integer = INT_CERO
        Dim Empresa As Integer = INT_CERO

        Empresa = Sesion.IdEmpresa
        Empleado = celdaCodigo.Text
        LineaSeleccionad = dgvHistorico.SelectedCells(0).Value

        lblLineaS.Text = LineaSeleccionad
        lblLineaA.Text = LineaSeleccionad
        BuscarSuspension(Empresa, Empleado, LineaSeleccionad)


    End Sub

    Private Sub btnAumento_Click(sender As Object, e As EventArgs) Handles btnAumento.Click
        pnlAumento.Visible = True
        pnlAumento.Dock = DockStyle.Fill
    End Sub

    Private Sub btnBorrarS_Click(sender As Object, e As EventArgs)
        pnlSuspension.Visible = False
    End Sub

    Private Sub btnGuardarA_Click(sender As Object, e As EventArgs) Handles btnGuardarA.Click
        Dim FilaA As Integer = INT_CERO
        Dim Valor As Integer = INT_CERO
        Dim NombreCompletoA As String = STR_VACIO
        Dim CodigoEmpleado As Integer = INT_CERO
        Dim FechaInicioA As String = STR_VACIO
        Dim tipoA As Integer = INT_CERO
        Dim LineaActualizacion As Integer = 0
        Dim CorrelativoA As Integer = INT_CERO



        LineaActualizacion = dgvHistorico.SelectedCells(0).Value
        FilaA = dgvHistorico.Rows.Count
        NombreCompletoA = celdaNombre1.Text & " " & celdaNombre2.Text & "," & celdaApellido1.Text & " " & celdaApellido2.Text

        dtlempleados.CONEXION = strConexion
        CodigoEmpleado = celdaCodigo.Text
        tipoA = 1604
        FechaInicioA = dtpInicioA.Value.ToString(FORMATO_MYSQL)

        CorrelativoA = Correlativo()
        Valor = Scalar(CodigoEmpleado, FechaInicioA, tipoA)

        dtlempleados.DEMP_SIS_EMP = Sesion.IdEmpresa
        dtlempleados.DEMP_CODIGO = CodigoEmpleado
        dtlempleados.Demp_Fecha_NET = cfun.HoyMySQL
        dtlempleados.DEMP_TIPO = tipoA

        If Valor > 0 Then

            Try

                dtlempleados.Demp_Inicio_NET = dtpInicioA.Value
                dtlempleados.Demp_Fin_NET = dtpInicioA.Value
                dtlempleados.DEMP_RF1_DBL = CDbl(FormatNumber(txtSalario.Text, 2))
                dtlempleados.DEMP_LIN = LineaActualizacion

                If dtlempleados.PUPDATE = False Then
                    MsgBox(dtlempleados.MERROR.ToString)
                End If

                MessageBox.Show("El Aumento fue Modificado con Exito", "Aumento", MessageBoxButtons.OK)
                pnlAumento.Visible = False
                MostrarLista(False)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        Else

            Try
                dtlempleados.DEMP_LIN = CorrelativoA
                dtlempleados.Demp_Inicio_NET = CDate(FechaInicioA)
                dtlempleados.Demp_Fin_NET = CDate(FechaInicioA)
                dtlempleados.DEMP_RF1_DBL = CDbl(FormatNumber(txtSalario.Text, 2))

                If dtlempleados.PINSERT = False Then
                    MsgBox(dtlempleados.MERROR.ToString)
                End If

                MessageBox.Show("El Aumento Fue Aplicado con Exito", "Aumento", MessageBoxButtons.OK)
                pnlAumento.Visible = False
                MostrarLista(False)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        End If

        txtSalario.Text = INT_CERO
        dtlempleados.DEMP_RF1_DBL = INT_CERO

    End Sub

    Public Function Correlativo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim Valor As Integer = INT_CERO
        Dim COM As MySqlCommand
        Dim CON As MySqlConnection

        strSQL = "SELECT ifnull(MAX(Demp_Lin),0) + 1 Maxim " & _
                 "From DTL_Empleados " & _
                 "WHERE Demp_Sis_Emp = {empresa} and Demp_Codigo = {empleado}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{empleado}", celdaCodigo.Text)

        CON = New MySqlConnection(strConexion)
        CON.Open()
        Try
            COM = New MySqlCommand(strSQL, CON)
            Valor = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

        Return Valor

    End Function

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalirS.Click
        pnlSuspension.Visible = False
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnSalirA.Click
        pnlAumento.Visible = False
    End Sub

    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        Dim CodigoEmpleadoE As Integer = INT_CERO
        Dim TipoE As Integer = INT_CERO
        Dim LineaE As Integer = INT_CERO

        CodigoEmpleadoE = celdaCodigo.Text
        TipoE = 1603

        dtlempleados.CONEXION = strConexion

        Try
            dtlempleados.DEMP_SIS_EMP = Sesion.IdEmpresa
            dtlempleados.DEMP_CODIGO = CodigoEmpleadoE
            dtlempleados.DEMP_TIPO = TipoE
            dtlempleados.DEMP_LIN = lblLineaS.Text

            If dtlempleados.PDELETE = True Then
                MsgBox(dtlempleados.MERROR.ToString)
            End If

            pnlSuspension.Visible = False
            MostrarLista(False)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        dtlempleados.DEMP_SIS_EMP = Sesion.IdEmpresa
        dtlempleados.DEMP_CODIGO = INT_CERO
        dtlempleados.DEMP_TIPO = INT_CERO
        dtlempleados.DEMP_LIN = INT_CERO

    End Sub

    Private Sub BotonCentro_Click(sender As Object, e As EventArgs) Handles BotonCentro.Click
        Dim frm As New frmSeleccionar
        Dim frmmjs As New frmMensaje

        frm.Campos = "cost_num,cost_nombre "
        frm.Tabla = cfun.ContaEmpresa & ".costos "
        frm.Condicion = "cost_num >= 0 "
        frm.Ordenamiento = "cost_num"
        frm.Filtro = "cost_nombre"
        frm.TipoOrdenamiento = " ASC "

        frm.Titulo = "Centro de Costo"

        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            lblcodCentro.Text = frm.LLave
            CeldaCentro.Text = frm.Dato

        End If


    End Sub

 
End Class