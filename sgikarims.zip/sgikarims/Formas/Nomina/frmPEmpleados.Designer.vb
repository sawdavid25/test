﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPEmpleados
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CeldaTitulo = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonBorrar = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonNuevo = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.celdaCodigo = New System.Windows.Forms.Label()
        Me.CheckActivo = New System.Windows.Forms.CheckBox()
        Me.celdaDescripcion = New System.Windows.Forms.Label()
        Me.cuadroFoto = New System.Windows.Forms.PictureBox()
        Me.celdaCedula = New System.Windows.Forms.TextBox()
        Me.celdaApellido1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaDPI = New System.Windows.Forms.TextBox()
        Me.celdaApellidoCasada = New System.Windows.Forms.TextBox()
        Me.celdaApellido2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaNombre2 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaNombre3 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaNombre1 = New System.Windows.Forms.TextBox()
        Me.panelObsevaciones = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.TabDatos = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.CeldaDeposito = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.dtpFNacimiento = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.BotonCentro = New System.Windows.Forms.Button()
        Me.CeldaCentro = New System.Windows.Forms.TextBox()
        Me.lblcodCentro = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.comboEstadoCivil = New System.Windows.Forms.ComboBox()
        Me.comboSexo = New System.Windows.Forms.ComboBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaConyugue = New System.Windows.Forms.TextBox()
        Me.celdaMunicipio = New System.Windows.Forms.TextBox()
        Me.celdaTelefono1 = New System.Windows.Forms.TextBox()
        Me.celdaNacionalidad = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.celdaIrtra = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.celdaIgss = New System.Windows.Forms.TextBox()
        Me.celdaTelefono2 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.pnlHistorial = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.btnAumento = New System.Windows.Forms.Button()
        Me.btnSuspension = New System.Windows.Forms.Button()
        Me.dgvHistorico = New System.Windows.Forms.DataGridView()
        Me.pnlOpciones = New System.Windows.Forms.Panel()
        Me.pnlAumento = New System.Windows.Forms.Panel()
        Me.lblLineaA = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.btnSalirA = New System.Windows.Forms.Button()
        Me.btnGuardarA = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtSalario = New System.Windows.Forms.TextBox()
        Me.dtpInicioA = New System.Windows.Forms.DateTimePicker()
        Me.pnlSuspension = New System.Windows.Forms.Panel()
        Me.chkactivo = New System.Windows.Forms.CheckBox()
        Me.btnEliminar = New System.Windows.Forms.Button()
        Me.btnSalirS = New System.Windows.Forms.Button()
        Me.lblLineaS = New System.Windows.Forms.Label()
        Me.lblL = New System.Windows.Forms.Label()
        Me.btnGuardarS = New System.Windows.Forms.Button()
        Me.lblFin = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.lblInicio = New System.Windows.Forms.Label()
        Me.listaEmpleados = New System.Windows.Forms.DataGridView()
        Me.ContenedorPrincipal = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.cuadroFoto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelObsevaciones.SuspendLayout()
        Me.TabDatos.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.pnlHistorial.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.dgvHistorico, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlOpciones.SuspendLayout()
        Me.pnlAumento.SuspendLayout()
        Me.pnlSuspension.SuspendLayout()
        CType(Me.listaEmpleados, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContenedorPrincipal.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Controls.Add(Me.CeldaTitulo)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 86)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(820, 30)
        Me.Panel2.TabIndex = 5
        '
        'CeldaTitulo
        '
        Me.CeldaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTitulo.AutoSize = True
        Me.CeldaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTitulo.Location = New System.Drawing.Point(18, 6)
        Me.CeldaTitulo.Name = "CeldaTitulo"
        Me.CeldaTitulo.Size = New System.Drawing.Size(50, 18)
        Me.CeldaTitulo.TabIndex = 0
        Me.CeldaTitulo.Text = "Titulo"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.CuadroLogo)
        Me.Panel1.Controls.Add(Me.botonCerrar)
        Me.Panel1.Controls.Add(Me.botonBorrar)
        Me.Panel1.Controls.Add(Me.botonGuardar)
        Me.Panel1.Controls.Add(Me.botonNuevo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(820, 86)
        Me.Panel1.TabIndex = 4
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroLogo.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CuadroLogo.Image = Global.KARIMs_SGI.My.Resources.Resources.logokarims
        Me.CuadroLogo.Location = New System.Drawing.Point(714, 3)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(99, 78)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CuadroLogo.TabIndex = 1
        Me.CuadroLogo.TabStop = False
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(652, 15)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(56, 45)
        Me.botonCerrar.TabIndex = 0
        Me.botonCerrar.Text = "&Cerrar"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonBorrar
        '
        Me.botonBorrar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonBorrar.Location = New System.Drawing.Point(136, 15)
        Me.botonBorrar.Name = "botonBorrar"
        Me.botonBorrar.Size = New System.Drawing.Size(56, 45)
        Me.botonBorrar.TabIndex = 0
        Me.botonBorrar.Text = "&Borrar"
        Me.botonBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBorrar.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.botonGuardar.Location = New System.Drawing.Point(74, 15)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(56, 45)
        Me.botonGuardar.TabIndex = 0
        Me.botonGuardar.Text = "&Guardar"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonNuevo
        '
        Me.botonNuevo.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonNuevo.Location = New System.Drawing.Point(12, 15)
        Me.botonNuevo.Name = "botonNuevo"
        Me.botonNuevo.Size = New System.Drawing.Size(56, 45)
        Me.botonNuevo.TabIndex = 0
        Me.botonNuevo.Text = "&Nuevo"
        Me.botonNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevo.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.celdaCodigo)
        Me.Panel3.Controls.Add(Me.CheckActivo)
        Me.Panel3.Controls.Add(Me.celdaDescripcion)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(820, 46)
        Me.Panel3.TabIndex = 9
        '
        'celdaCodigo
        '
        Me.celdaCodigo.AutoSize = True
        Me.celdaCodigo.Location = New System.Drawing.Point(559, 15)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.Size = New System.Drawing.Size(16, 13)
        Me.celdaCodigo.TabIndex = 2
        Me.celdaCodigo.Text = "-1"
        '
        'CheckActivo
        '
        Me.CheckActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckActivo.AutoSize = True
        Me.CheckActivo.Checked = True
        Me.CheckActivo.CheckState = System.Windows.Forms.CheckState.Indeterminate
        Me.CheckActivo.Location = New System.Drawing.Point(741, 15)
        Me.CheckActivo.Name = "CheckActivo"
        Me.CheckActivo.Size = New System.Drawing.Size(56, 17)
        Me.CheckActivo.TabIndex = 1
        Me.CheckActivo.Text = "Activo"
        Me.CheckActivo.UseVisualStyleBackColor = True
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.AutoSize = True
        Me.celdaDescripcion.Location = New System.Drawing.Point(33, 16)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(45, 13)
        Me.celdaDescripcion.TabIndex = 0
        Me.celdaDescripcion.Text = "Label10"
        '
        'cuadroFoto
        '
        Me.cuadroFoto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cuadroFoto.Location = New System.Drawing.Point(242, 16)
        Me.cuadroFoto.Name = "cuadroFoto"
        Me.cuadroFoto.Size = New System.Drawing.Size(131, 125)
        Me.cuadroFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.cuadroFoto.TabIndex = 29
        Me.cuadroFoto.TabStop = False
        '
        'celdaCedula
        '
        Me.celdaCedula.Location = New System.Drawing.Point(42, 301)
        Me.celdaCedula.Name = "celdaCedula"
        Me.celdaCedula.Size = New System.Drawing.Size(198, 20)
        Me.celdaCedula.TabIndex = 6
        '
        'celdaApellido1
        '
        Me.celdaApellido1.Location = New System.Drawing.Point(42, 166)
        Me.celdaApellido1.Name = "celdaApellido1"
        Me.celdaApellido1.Size = New System.Drawing.Size(349, 20)
        Me.celdaApellido1.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Tercer Nombre"
        '
        'celdaDPI
        '
        Me.celdaDPI.Location = New System.Drawing.Point(42, 340)
        Me.celdaDPI.Name = "celdaDPI"
        Me.celdaDPI.Size = New System.Drawing.Size(198, 20)
        Me.celdaDPI.TabIndex = 7
        '
        'celdaApellidoCasada
        '
        Me.celdaApellidoCasada.Location = New System.Drawing.Point(42, 259)
        Me.celdaApellidoCasada.Name = "celdaApellidoCasada"
        Me.celdaApellidoCasada.Size = New System.Drawing.Size(349, 20)
        Me.celdaApellidoCasada.TabIndex = 5
        '
        'celdaApellido2
        '
        Me.celdaApellido2.Location = New System.Drawing.Point(42, 211)
        Me.celdaApellido2.Name = "celdaApellido2"
        Me.celdaApellido2.Size = New System.Drawing.Size(349, 20)
        Me.celdaApellido2.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(39, 57)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(90, 13)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Segundo Nombre"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(39, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Primer Nombre"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(39, 285)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "No. Cédula"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(39, 243)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Apellido de Casada"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(39, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Primer Apellido"
        '
        'celdaNombre2
        '
        Me.celdaNombre2.Location = New System.Drawing.Point(42, 73)
        Me.celdaNombre2.Name = "celdaNombre2"
        Me.celdaNombre2.Size = New System.Drawing.Size(349, 20)
        Me.celdaNombre2.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(43, 411)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(108, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Fecha de Nacimiento"
        '
        'celdaNombre3
        '
        Me.celdaNombre3.Location = New System.Drawing.Point(43, 121)
        Me.celdaNombre3.Name = "celdaNombre3"
        Me.celdaNombre3.Size = New System.Drawing.Size(349, 20)
        Me.celdaNombre3.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(39, 195)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 13)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "SegundoApellido"
        '
        'celdaNombre1
        '
        Me.celdaNombre1.Location = New System.Drawing.Point(42, 30)
        Me.celdaNombre1.Name = "celdaNombre1"
        Me.celdaNombre1.Size = New System.Drawing.Size(349, 20)
        Me.celdaNombre1.TabIndex = 0
        '
        'panelObsevaciones
        '
        Me.panelObsevaciones.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.panelObsevaciones.Controls.Add(Me.Label11)
        Me.panelObsevaciones.Controls.Add(Me.celdaObservaciones)
        Me.panelObsevaciones.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelObsevaciones.Location = New System.Drawing.Point(0, 613)
        Me.panelObsevaciones.MinimumSize = New System.Drawing.Size(142, 50)
        Me.panelObsevaciones.Name = "panelObsevaciones"
        Me.panelObsevaciones.Size = New System.Drawing.Size(820, 62)
        Me.panelObsevaciones.TabIndex = 30
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(18, 13)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(78, 13)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Observaciones"
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservaciones.Location = New System.Drawing.Point(18, 29)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(787, 24)
        Me.celdaObservaciones.TabIndex = 0
        '
        'TabDatos
        '
        Me.TabDatos.Controls.Add(Me.TabPage1)
        Me.TabDatos.Controls.Add(Me.TabPage2)
        Me.TabDatos.Controls.Add(Me.TabPage3)
        Me.TabDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabDatos.Location = New System.Drawing.Point(0, 46)
        Me.TabDatos.Name = "TabDatos"
        Me.TabDatos.SelectedIndex = 0
        Me.TabDatos.Size = New System.Drawing.Size(820, 567)
        Me.TabDatos.TabIndex = 31
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(Me.CeldaDeposito)
        Me.TabPage1.Controls.Add(Me.Label26)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Controls.Add(Me.dtpFNacimiento)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.celdaNombre1)
        Me.TabPage1.Controls.Add(Me.cuadroFoto)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.celdaCedula)
        Me.TabPage1.Controls.Add(Me.celdaNombre3)
        Me.TabPage1.Controls.Add(Me.celdaApellido1)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.celdaNombre2)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.celdaDPI)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.celdaApellidoCasada)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.celdaApellido2)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(812, 541)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Datos Principales"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'CeldaDeposito
        '
        Me.CeldaDeposito.Location = New System.Drawing.Point(43, 490)
        Me.CeldaDeposito.Name = "CeldaDeposito"
        Me.CeldaDeposito.Size = New System.Drawing.Size(197, 20)
        Me.CeldaDeposito.TabIndex = 58
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(39, 474)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(86, 13)
        Me.Label26.TabIndex = 57
        Me.Label26.Text = "Cuenta Bancaria"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(43, 372)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(69, 13)
        Me.Label16.TabIndex = 56
        Me.Label16.Text = "Extendido en"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(43, 388)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(197, 20)
        Me.TextBox1.TabIndex = 8
        '
        'dtpFNacimiento
        '
        Me.dtpFNacimiento.Location = New System.Drawing.Point(42, 431)
        Me.dtpFNacimiento.Name = "dtpFNacimiento"
        Me.dtpFNacimiento.Size = New System.Drawing.Size(198, 20)
        Me.dtpFNacimiento.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(43, 324)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(45, 13)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "No. DPI"
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(Me.BotonCentro)
        Me.TabPage2.Controls.Add(Me.CeldaCentro)
        Me.TabPage2.Controls.Add(Me.lblcodCentro)
        Me.TabPage2.Controls.Add(Me.Label27)
        Me.TabPage2.Controls.Add(Me.celdaNit)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.comboEstadoCivil)
        Me.TabPage2.Controls.Add(Me.comboSexo)
        Me.TabPage2.Controls.Add(Me.celdaDireccion)
        Me.TabPage2.Controls.Add(Me.celdaConyugue)
        Me.TabPage2.Controls.Add(Me.celdaMunicipio)
        Me.TabPage2.Controls.Add(Me.celdaTelefono1)
        Me.TabPage2.Controls.Add(Me.celdaNacionalidad)
        Me.TabPage2.Controls.Add(Me.Label21)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.celdaIrtra)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.celdaIgss)
        Me.TabPage2.Controls.Add(Me.celdaTelefono2)
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(812, 541)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Datos complementarios"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'BotonCentro
        '
        Me.BotonCentro.Location = New System.Drawing.Point(257, 468)
        Me.BotonCentro.Name = "BotonCentro"
        Me.BotonCentro.Size = New System.Drawing.Size(36, 23)
        Me.BotonCentro.TabIndex = 65
        Me.BotonCentro.Text = "..."
        Me.BotonCentro.UseVisualStyleBackColor = True
        '
        'CeldaCentro
        '
        Me.CeldaCentro.Location = New System.Drawing.Point(40, 470)
        Me.CeldaCentro.Name = "CeldaCentro"
        Me.CeldaCentro.ReadOnly = True
        Me.CeldaCentro.Size = New System.Drawing.Size(197, 20)
        Me.CeldaCentro.TabIndex = 64
        '
        'lblcodCentro
        '
        Me.lblcodCentro.AutoSize = True
        Me.lblcodCentro.Location = New System.Drawing.Point(313, 478)
        Me.lblcodCentro.Name = "lblcodCentro"
        Me.lblcodCentro.Size = New System.Drawing.Size(0, 13)
        Me.lblcodCentro.TabIndex = 63
        Me.lblcodCentro.Visible = False
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(40, 454)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(83, 13)
        Me.Label27.TabIndex = 60
        Me.Label27.Text = "Centro de Costo"
        '
        'celdaNit
        '
        Me.celdaNit.Location = New System.Drawing.Point(40, 312)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(181, 20)
        Me.celdaNit.TabIndex = 17
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(37, 296)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(25, 13)
        Me.Label9.TabIndex = 56
        Me.Label9.Text = "NIT"
        '
        'comboEstadoCivil
        '
        Me.comboEstadoCivil.FormattingEnabled = True
        Me.comboEstadoCivil.ItemHeight = 13
        Me.comboEstadoCivil.Items.AddRange(New Object() {"SOLTERO", "UNIDO", "CASADO", "DIVORCIADO", "VIUDO"})
        Me.comboEstadoCivil.Location = New System.Drawing.Point(40, 119)
        Me.comboEstadoCivil.Name = "comboEstadoCivil"
        Me.comboEstadoCivil.Size = New System.Drawing.Size(179, 21)
        Me.comboEstadoCivil.TabIndex = 35
        '
        'comboSexo
        '
        Me.comboSexo.FormattingEnabled = True
        Me.comboSexo.Items.AddRange(New Object() {"MASCULINO", "FEMENINO"})
        Me.comboSexo.Location = New System.Drawing.Point(40, 35)
        Me.comboSexo.Name = "comboSexo"
        Me.comboSexo.Size = New System.Drawing.Size(179, 21)
        Me.comboSexo.TabIndex = 10
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(38, 198)
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(371, 20)
        Me.celdaDireccion.TabIndex = 14
        '
        'celdaConyugue
        '
        Me.celdaConyugue.Location = New System.Drawing.Point(40, 159)
        Me.celdaConyugue.Name = "celdaConyugue"
        Me.celdaConyugue.Size = New System.Drawing.Size(367, 20)
        Me.celdaConyugue.TabIndex = 13
        '
        'celdaMunicipio
        '
        Me.celdaMunicipio.Location = New System.Drawing.Point(40, 235)
        Me.celdaMunicipio.Name = "celdaMunicipio"
        Me.celdaMunicipio.Size = New System.Drawing.Size(181, 20)
        Me.celdaMunicipio.TabIndex = 15
        '
        'celdaTelefono1
        '
        Me.celdaTelefono1.Location = New System.Drawing.Point(40, 429)
        Me.celdaTelefono1.Name = "celdaTelefono1"
        Me.celdaTelefono1.Size = New System.Drawing.Size(181, 20)
        Me.celdaTelefono1.TabIndex = 20
        '
        'celdaNacionalidad
        '
        Me.celdaNacionalidad.Location = New System.Drawing.Point(40, 77)
        Me.celdaNacionalidad.Name = "celdaNacionalidad"
        Me.celdaNacionalidad.Size = New System.Drawing.Size(181, 20)
        Me.celdaNacionalidad.TabIndex = 11
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(37, 336)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(32, 13)
        Me.Label21.TabIndex = 39
        Me.Label21.Text = "IGSS"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(40, 375)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(49, 13)
        Me.Label18.TabIndex = 40
        Me.Label18.Text = "Teléfono"
        '
        'celdaIrtra
        '
        Me.celdaIrtra.Location = New System.Drawing.Point(40, 274)
        Me.celdaIrtra.Name = "celdaIrtra"
        Me.celdaIrtra.Size = New System.Drawing.Size(181, 20)
        Me.celdaIrtra.TabIndex = 16
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(35, 19)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 13)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "Sexo"
        '
        'celdaIgss
        '
        Me.celdaIgss.Location = New System.Drawing.Point(40, 352)
        Me.celdaIgss.Name = "celdaIgss"
        Me.celdaIgss.Size = New System.Drawing.Size(181, 20)
        Me.celdaIgss.TabIndex = 18
        '
        'celdaTelefono2
        '
        Me.celdaTelefono2.Location = New System.Drawing.Point(40, 392)
        Me.celdaTelefono2.Name = "celdaTelefono2"
        Me.celdaTelefono2.Size = New System.Drawing.Size(181, 20)
        Me.celdaTelefono2.TabIndex = 19
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(35, 182)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(52, 13)
        Me.Label22.TabIndex = 46
        Me.Label22.Text = "Dirección"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(37, 219)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(52, 13)
        Me.Label20.TabIndex = 47
        Me.Label20.Text = "Municipio"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(37, 143)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(111, 13)
        Me.Label15.TabIndex = 48
        Me.Label15.Text = "Nombre del conyugue"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(37, 413)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(39, 13)
        Me.Label17.TabIndex = 49
        Me.Label17.Text = "Celular"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(37, 61)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(69, 13)
        Me.Label13.TabIndex = 50
        Me.Label13.Text = "Nacionalidad"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(37, 258)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(40, 13)
        Me.Label19.TabIndex = 36
        Me.Label19.Text = "IRTRA"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(34, 103)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 13)
        Me.Label12.TabIndex = 34
        Me.Label12.Text = "Estado civil"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.pnlHistorial)
        Me.TabPage3.Controls.Add(Me.pnlOpciones)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(812, 541)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Historial"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'pnlHistorial
        '
        Me.pnlHistorial.Controls.Add(Me.Panel4)
        Me.pnlHistorial.Controls.Add(Me.dgvHistorico)
        Me.pnlHistorial.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlHistorial.Location = New System.Drawing.Point(0, 0)
        Me.pnlHistorial.Name = "pnlHistorial"
        Me.pnlHistorial.Size = New System.Drawing.Size(521, 541)
        Me.pnlHistorial.TabIndex = 0
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.btnAumento)
        Me.Panel4.Controls.Add(Me.btnSuspension)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel4.Location = New System.Drawing.Point(434, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(87, 541)
        Me.Panel4.TabIndex = 1
        '
        'btnAumento
        '
        Me.btnAumento.Location = New System.Drawing.Point(6, 70)
        Me.btnAumento.Name = "btnAumento"
        Me.btnAumento.Size = New System.Drawing.Size(75, 49)
        Me.btnAumento.TabIndex = 1
        Me.btnAumento.Text = "Aumento"
        Me.btnAumento.UseVisualStyleBackColor = True
        '
        'btnSuspension
        '
        Me.btnSuspension.Location = New System.Drawing.Point(6, 13)
        Me.btnSuspension.Name = "btnSuspension"
        Me.btnSuspension.Size = New System.Drawing.Size(75, 51)
        Me.btnSuspension.TabIndex = 0
        Me.btnSuspension.Text = "Suspension"
        Me.btnSuspension.UseVisualStyleBackColor = True
        '
        'dgvHistorico
        '
        Me.dgvHistorico.AllowUserToAddRows = False
        Me.dgvHistorico.AllowUserToDeleteRows = False
        Me.dgvHistorico.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvHistorico.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvHistorico.Location = New System.Drawing.Point(0, 0)
        Me.dgvHistorico.Name = "dgvHistorico"
        Me.dgvHistorico.ReadOnly = True
        Me.dgvHistorico.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvHistorico.Size = New System.Drawing.Size(521, 541)
        Me.dgvHistorico.TabIndex = 0
        '
        'pnlOpciones
        '
        Me.pnlOpciones.Controls.Add(Me.pnlAumento)
        Me.pnlOpciones.Controls.Add(Me.pnlSuspension)
        Me.pnlOpciones.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlOpciones.Location = New System.Drawing.Point(521, 0)
        Me.pnlOpciones.Name = "pnlOpciones"
        Me.pnlOpciones.Size = New System.Drawing.Size(291, 541)
        Me.pnlOpciones.TabIndex = 1
        '
        'pnlAumento
        '
        Me.pnlAumento.Controls.Add(Me.lblLineaA)
        Me.pnlAumento.Controls.Add(Me.Label25)
        Me.pnlAumento.Controls.Add(Me.btnSalirA)
        Me.pnlAumento.Controls.Add(Me.btnGuardarA)
        Me.pnlAumento.Controls.Add(Me.Label24)
        Me.pnlAumento.Controls.Add(Me.Label23)
        Me.pnlAumento.Controls.Add(Me.txtSalario)
        Me.pnlAumento.Controls.Add(Me.dtpInicioA)
        Me.pnlAumento.Location = New System.Drawing.Point(20, 276)
        Me.pnlAumento.Name = "pnlAumento"
        Me.pnlAumento.Size = New System.Drawing.Size(255, 210)
        Me.pnlAumento.TabIndex = 1
        '
        'lblLineaA
        '
        Me.lblLineaA.AutoSize = True
        Me.lblLineaA.Location = New System.Drawing.Point(146, 13)
        Me.lblLineaA.Name = "lblLineaA"
        Me.lblLineaA.Size = New System.Drawing.Size(10, 13)
        Me.lblLineaA.TabIndex = 7
        Me.lblLineaA.Text = "."
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(22, 13)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(101, 13)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "Linea Seleccionada"
        '
        'btnSalirA
        '
        Me.btnSalirA.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnSalirA.Image = Global.KARIMs_SGI.My.Resources.Resources.boton_cerrar
        Me.btnSalirA.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSalirA.Location = New System.Drawing.Point(138, 155)
        Me.btnSalirA.Name = "btnSalirA"
        Me.btnSalirA.Size = New System.Drawing.Size(84, 40)
        Me.btnSalirA.TabIndex = 5
        Me.btnSalirA.Text = "Salir"
        Me.btnSalirA.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnSalirA.UseVisualStyleBackColor = True
        '
        'btnGuardarA
        '
        Me.btnGuardarA.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnGuardarA.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.btnGuardarA.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnGuardarA.Location = New System.Drawing.Point(45, 155)
        Me.btnGuardarA.Name = "btnGuardarA"
        Me.btnGuardarA.Size = New System.Drawing.Size(75, 40)
        Me.btnGuardarA.TabIndex = 4
        Me.btnGuardarA.Text = "Guardar"
        Me.btnGuardarA.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnGuardarA.UseVisualStyleBackColor = True
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(19, 45)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(80, 13)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "Fecha de Inicio"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(22, 97)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(74, 13)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "Nuevo Salario"
        '
        'txtSalario
        '
        Me.txtSalario.Location = New System.Drawing.Point(22, 116)
        Me.txtSalario.Name = "txtSalario"
        Me.txtSalario.Size = New System.Drawing.Size(112, 20)
        Me.txtSalario.TabIndex = 1
        '
        'dtpInicioA
        '
        Me.dtpInicioA.Location = New System.Drawing.Point(22, 64)
        Me.dtpInicioA.Name = "dtpInicioA"
        Me.dtpInicioA.Size = New System.Drawing.Size(217, 20)
        Me.dtpInicioA.TabIndex = 0
        '
        'pnlSuspension
        '
        Me.pnlSuspension.Controls.Add(Me.chkactivo)
        Me.pnlSuspension.Controls.Add(Me.btnEliminar)
        Me.pnlSuspension.Controls.Add(Me.btnSalirS)
        Me.pnlSuspension.Controls.Add(Me.lblLineaS)
        Me.pnlSuspension.Controls.Add(Me.lblL)
        Me.pnlSuspension.Controls.Add(Me.btnGuardarS)
        Me.pnlSuspension.Controls.Add(Me.lblFin)
        Me.pnlSuspension.Controls.Add(Me.dtpFin)
        Me.pnlSuspension.Controls.Add(Me.dtpInicio)
        Me.pnlSuspension.Controls.Add(Me.lblInicio)
        Me.pnlSuspension.Location = New System.Drawing.Point(17, 13)
        Me.pnlSuspension.Name = "pnlSuspension"
        Me.pnlSuspension.Size = New System.Drawing.Size(255, 243)
        Me.pnlSuspension.TabIndex = 0
        Me.pnlSuspension.Visible = False
        '
        'chkactivo
        '
        Me.chkactivo.AutoSize = True
        Me.chkactivo.Location = New System.Drawing.Point(28, 166)
        Me.chkactivo.Name = "chkactivo"
        Me.chkactivo.Size = New System.Drawing.Size(56, 17)
        Me.chkactivo.TabIndex = 10
        Me.chkactivo.Text = "Activo"
        Me.chkactivo.UseVisualStyleBackColor = True
        '
        'btnEliminar
        '
        Me.btnEliminar.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnEliminar.Location = New System.Drawing.Point(85, 200)
        Me.btnEliminar.Name = "btnEliminar"
        Me.btnEliminar.Size = New System.Drawing.Size(75, 40)
        Me.btnEliminar.TabIndex = 9
        Me.btnEliminar.Text = "Eliminar"
        Me.btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnEliminar.UseVisualStyleBackColor = True
        '
        'btnSalirS
        '
        Me.btnSalirS.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnSalirS.Image = Global.KARIMs_SGI.My.Resources.Resources.boton_cerrar
        Me.btnSalirS.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnSalirS.Location = New System.Drawing.Point(174, 200)
        Me.btnSalirS.Name = "btnSalirS"
        Me.btnSalirS.Size = New System.Drawing.Size(75, 40)
        Me.btnSalirS.TabIndex = 8
        Me.btnSalirS.Text = "Salir"
        Me.btnSalirS.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnSalirS.UseVisualStyleBackColor = True
        '
        'lblLineaS
        '
        Me.lblLineaS.AutoSize = True
        Me.lblLineaS.Location = New System.Drawing.Point(146, 17)
        Me.lblLineaS.Name = "lblLineaS"
        Me.lblLineaS.Size = New System.Drawing.Size(10, 13)
        Me.lblLineaS.TabIndex = 7
        Me.lblLineaS.Text = "."
        '
        'lblL
        '
        Me.lblL.AutoSize = True
        Me.lblL.Location = New System.Drawing.Point(19, 17)
        Me.lblL.Name = "lblL"
        Me.lblL.Size = New System.Drawing.Size(101, 13)
        Me.lblL.TabIndex = 6
        Me.lblL.Text = "Linea Seleccionada"
        '
        'btnGuardarS
        '
        Me.btnGuardarS.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.btnGuardarS.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.btnGuardarS.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnGuardarS.Location = New System.Drawing.Point(3, 200)
        Me.btnGuardarS.Name = "btnGuardarS"
        Me.btnGuardarS.Size = New System.Drawing.Size(75, 40)
        Me.btnGuardarS.TabIndex = 4
        Me.btnGuardarS.Text = "Guardar"
        Me.btnGuardarS.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.btnGuardarS.UseVisualStyleBackColor = True
        '
        'lblFin
        '
        Me.lblFin.AutoSize = True
        Me.lblFin.Location = New System.Drawing.Point(16, 115)
        Me.lblFin.Name = "lblFin"
        Me.lblFin.Size = New System.Drawing.Size(21, 13)
        Me.lblFin.TabIndex = 3
        Me.lblFin.Text = "Fin"
        '
        'dtpFin
        '
        Me.dtpFin.Location = New System.Drawing.Point(19, 131)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(220, 20)
        Me.dtpFin.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Location = New System.Drawing.Point(19, 66)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(220, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'lblInicio
        '
        Me.lblInicio.AutoSize = True
        Me.lblInicio.Location = New System.Drawing.Point(16, 50)
        Me.lblInicio.Name = "lblInicio"
        Me.lblInicio.Size = New System.Drawing.Size(32, 13)
        Me.lblInicio.TabIndex = 0
        Me.lblInicio.Text = "Inicio"
        '
        'listaEmpleados
        '
        Me.listaEmpleados.AllowUserToAddRows = False
        Me.listaEmpleados.AllowUserToDeleteRows = False
        Me.listaEmpleados.AllowUserToOrderColumns = True
        Me.listaEmpleados.BackgroundColor = System.Drawing.SystemColors.ControlDark
        Me.listaEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.listaEmpleados.Location = New System.Drawing.Point(603, 556)
        Me.listaEmpleados.MultiSelect = False
        Me.listaEmpleados.Name = "listaEmpleados"
        Me.listaEmpleados.ReadOnly = True
        Me.listaEmpleados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.listaEmpleados.Size = New System.Drawing.Size(138, 96)
        Me.listaEmpleados.TabIndex = 32
        '
        'ContenedorPrincipal
        '
        Me.ContenedorPrincipal.AutoScroll = True
        Me.ContenedorPrincipal.Controls.Add(Me.TabDatos)
        Me.ContenedorPrincipal.Controls.Add(Me.panelObsevaciones)
        Me.ContenedorPrincipal.Controls.Add(Me.Panel3)
        Me.ContenedorPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ContenedorPrincipal.Location = New System.Drawing.Point(0, 116)
        Me.ContenedorPrincipal.Name = "ContenedorPrincipal"
        Me.ContenedorPrincipal.Size = New System.Drawing.Size(820, 675)
        Me.ContenedorPrincipal.TabIndex = 33
        '
        'frmPEmpleados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(820, 791)
        Me.Controls.Add(Me.ContenedorPrincipal)
        Me.Controls.Add(Me.listaEmpleados)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmPEmpleados"
        Me.Text = "Empleados"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.cuadroFoto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelObsevaciones.ResumeLayout(False)
        Me.panelObsevaciones.PerformLayout()
        Me.TabDatos.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.pnlHistorial.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        CType(Me.dgvHistorico, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlOpciones.ResumeLayout(False)
        Me.pnlAumento.ResumeLayout(False)
        Me.pnlAumento.PerformLayout()
        Me.pnlSuspension.ResumeLayout(False)
        Me.pnlSuspension.PerformLayout()
        CType(Me.listaEmpleados, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContenedorPrincipal.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CeldaTitulo As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonBorrar As System.Windows.Forms.Button
    Friend WithEvents botonGuardar As System.Windows.Forms.Button
    Friend WithEvents botonNuevo As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents CheckActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDescripcion As System.Windows.Forms.Label
    Friend WithEvents cuadroFoto As System.Windows.Forms.PictureBox
    Friend WithEvents celdaCedula As System.Windows.Forms.TextBox
    Friend WithEvents celdaApellido1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaDPI As System.Windows.Forms.TextBox
    Friend WithEvents celdaApellidoCasada As System.Windows.Forms.TextBox
    Friend WithEvents celdaApellido2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents celdaNombre2 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents celdaNombre3 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents celdaNombre1 As System.Windows.Forms.TextBox
    Friend WithEvents panelObsevaciones As System.Windows.Forms.Panel
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents TabDatos As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents listaEmpleados As System.Windows.Forms.DataGridView
    Friend WithEvents celdaCodigo As System.Windows.Forms.Label
    Friend WithEvents dtpFNacimiento As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaNit As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents comboEstadoCivil As System.Windows.Forms.ComboBox
    Friend WithEvents comboSexo As System.Windows.Forms.ComboBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaConyugue As System.Windows.Forms.TextBox
    Friend WithEvents celdaMunicipio As System.Windows.Forms.TextBox
    Friend WithEvents celdaTelefono1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaNacionalidad As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents celdaIrtra As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents celdaIgss As System.Windows.Forms.TextBox
    Friend WithEvents celdaTelefono2 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ContenedorPrincipal As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents pnlOpciones As System.Windows.Forms.Panel
    Friend WithEvents pnlSuspension As System.Windows.Forms.Panel
    Friend WithEvents btnGuardarS As System.Windows.Forms.Button
    Friend WithEvents lblFin As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents lblInicio As System.Windows.Forms.Label
    Friend WithEvents pnlHistorial As System.Windows.Forms.Panel
    Friend WithEvents dgvHistorico As System.Windows.Forms.DataGridView
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents btnSuspension As System.Windows.Forms.Button
    Friend WithEvents lblLineaS As System.Windows.Forms.Label
    Friend WithEvents lblL As System.Windows.Forms.Label
    Friend WithEvents btnAumento As System.Windows.Forms.Button
    Friend WithEvents pnlAumento As System.Windows.Forms.Panel
    Friend WithEvents btnGuardarA As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtSalario As System.Windows.Forms.TextBox
    Friend WithEvents dtpInicioA As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnSalirS As System.Windows.Forms.Button
    Friend WithEvents btnSalirA As System.Windows.Forms.Button
    Friend WithEvents btnEliminar As System.Windows.Forms.Button
    Friend WithEvents lblLineaA As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents CeldaDeposito As System.Windows.Forms.TextBox
    Friend WithEvents chkactivo As System.Windows.Forms.CheckBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents BotonCentro As System.Windows.Forms.Button
    Friend WithEvents CeldaCentro As System.Windows.Forms.TextBox
    Friend WithEvents lblcodCentro As System.Windows.Forms.Label
End Class
