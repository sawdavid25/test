﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPedirComentarios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.panelComentario = New System.Windows.Forms.Panel()
        Me.panelMonto = New System.Windows.Forms.Panel()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMonto = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaModena = New System.Windows.Forms.TextBox()
        Me.celdaInfo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.panelComentario.SuspendLayout()
        Me.panelMonto.SuspendLayout()
        Me.SuspendLayout()
        '
        'botonCancelar
        '
        Me.botonCancelar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(550, 12)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(100, 59)
        Me.botonCancelar.TabIndex = 2
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(442, 12)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(100, 59)
        Me.botonAceptar.TabIndex = 1
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'panelComentario
        '
        Me.panelComentario.Controls.Add(Me.panelMonto)
        Me.panelComentario.Controls.Add(Me.botonAceptar)
        Me.panelComentario.Controls.Add(Me.botonCancelar)
        Me.panelComentario.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelComentario.Location = New System.Drawing.Point(0, 375)
        Me.panelComentario.Margin = New System.Windows.Forms.Padding(4)
        Me.panelComentario.Name = "panelComentario"
        Me.panelComentario.Size = New System.Drawing.Size(666, 76)
        Me.panelComentario.TabIndex = 0
        '
        'panelMonto
        '
        Me.panelMonto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelMonto.Controls.Add(Me.Label3)
        Me.panelMonto.Controls.Add(Me.Label2)
        Me.panelMonto.Controls.Add(Me.Label1)
        Me.panelMonto.Controls.Add(Me.celdaidMoneda)
        Me.panelMonto.Controls.Add(Me.celdaMonto)
        Me.panelMonto.Controls.Add(Me.celdaTasa)
        Me.panelMonto.Controls.Add(Me.botonMoneda)
        Me.panelMonto.Controls.Add(Me.celdaModena)
        Me.panelMonto.Location = New System.Drawing.Point(12, 12)
        Me.panelMonto.Name = "panelMonto"
        Me.panelMonto.Size = New System.Drawing.Size(418, 59)
        Me.panelMonto.TabIndex = 3
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(6, 31)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.Size = New System.Drawing.Size(44, 22)
        Me.celdaidMoneda.TabIndex = 4
        Me.celdaidMoneda.Text = "178"
        Me.celdaidMoneda.Visible = False
        '
        'celdaMonto
        '
        Me.celdaMonto.Location = New System.Drawing.Point(294, 30)
        Me.celdaMonto.Name = "celdaMonto"
        Me.celdaMonto.Size = New System.Drawing.Size(107, 22)
        Me.celdaMonto.TabIndex = 3
        Me.celdaMonto.Text = "0.00"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(187, 30)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(96, 22)
        Me.celdaTasa.TabIndex = 2
        Me.celdaTasa.Text = "1"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(135, 30)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(32, 23)
        Me.botonMoneda.TabIndex = 1
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaModena
        '
        Me.celdaModena.Location = New System.Drawing.Point(77, 30)
        Me.celdaModena.Name = "celdaModena"
        Me.celdaModena.ReadOnly = True
        Me.celdaModena.Size = New System.Drawing.Size(52, 22)
        Me.celdaModena.TabIndex = 0
        Me.celdaModena.Text = "usd"
        '
        'celdaInfo
        '
        Me.celdaInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.celdaInfo.Location = New System.Drawing.Point(0, 0)
        Me.celdaInfo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaInfo.Multiline = True
        Me.celdaInfo.Name = "celdaInfo"
        Me.celdaInfo.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.celdaInfo.Size = New System.Drawing.Size(666, 451)
        Me.celdaInfo.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(78, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 17)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Currency"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(184, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Exchange rate"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(328, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 17)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Amount"
        '
        'frmPedirComentarios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(666, 451)
        Me.Controls.Add(Me.panelComentario)
        Me.Controls.Add(Me.celdaInfo)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmPedirComentarios"
        Me.Text = "frmComentarios"
        Me.panelComentario.ResumeLayout(False)
        Me.panelMonto.ResumeLayout(False)
        Me.panelMonto.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents panelComentario As System.Windows.Forms.Panel
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
    Friend WithEvents botonAceptar As System.Windows.Forms.Button
    Friend WithEvents celdaInfo As System.Windows.Forms.TextBox
    Friend WithEvents panelMonto As System.Windows.Forms.Panel
    Friend WithEvents celdaMonto As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaModena As System.Windows.Forms.TextBox
    Friend WithEvents celdaidMoneda As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
