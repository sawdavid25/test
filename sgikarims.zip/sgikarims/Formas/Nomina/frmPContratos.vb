﻿Public Class frmPContratos
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property
#Region "Funciones y Procedimientos"

    Private Sub CargarCombos()
        cFunciones.CargarCombo(comboMoneda, "Catalogos", "cat_desc", "cat_num", " cat_clase= 'Monedas'")
        cFunciones.CargarCombo(comboCentro, "Centros", "cen_descripcion", "cen_codigo", "cen_empresa = " & Sesion.IdEmpresa)
        cFunciones.CargarCombo(ComboDepartamento, "Departamentos", "dep_descripcion", "dep_no", "dep_sisemp = " & Sesion.IdEmpresa)
        cFunciones.CargarCombo(ComboPuesto, "Puestos", "pue_descripcion", "pue_codigo", "pue_sisemp= " & Sesion.IdEmpresa)
        cFunciones.CargarCombo(comboJornada, "Catalogos", "cat_clave", "cat_num", "cat_clase= 'Jornada'")
        cFunciones.CargarCombo(comboDuracion, "Catalogos", "cat_clave", "cat_num", "cat_clase='Contrato'")
        cFunciones.CargarCombo(comboPlanilla, "Catalogos", "cat_clave", "cat_num", "cat_clase='Planilla'")
    End Sub

    Private Sub Reset()
        celdaEmpleado.Text = STR_VACIO
        CeldaCodigoEmpleado.Text = NO_FILA
        celdaCodigoContrato.Text = NO_FILA
        dtpInicio.Value = Today
        dtpFin.Value = Today
        comboCentro.Text = STR_VACIO
        ComboDepartamento.Text = STR_VACIO
        ComboPuesto.Text = STR_VACIO
        comboPlanilla.Text = STR_VACIO
        comboMoneda.Text = STR_VACIO
        comboDuracion.Text = STR_VACIO
        celdaSueldo.Text = STR_CERO_MONEDA
        celdaBonificacion.Text = STR_CERO_MONEDA
        celdaBono.Text = STR_CERO_MONEDA
        celdaISR.Text = STR_CERO_MONEDA
        celdaNombreE.Text = STR_VACIO
        celdaSexoE.Text = STR_VACIO
        celdaNacionalidadE.Text = STR_VACIO
        celdaCedulaE.Text = STR_VACIO
        celdaDPIE.Text = STR_VACIO
        celdaDirecionE.Text = STR_VACIO
        CeldaCivielE.Text = STR_VACIO
        celdaMunicipioE.Text = STR_VACIO
        dtpNacimientoE.Value = Today
        celdaNombreR.Text = STR_VACIO
        celdaSexoR.Text = STR_VACIO
        celdaNacionalidadR.Text = STR_VACIO
        celdaCedulaR.Text = STR_VACIO
        celdaDPIR.Text = STR_VACIO
        celdaDireccionR.Text = STR_VACIO
        celdaCivilR.Text = STR_VACIO
        celdaMunicipioR.Text = STR_VACIO
        dtpNacimientoR.Value = Today
        ListaHorarios.Rows.Clear()
    End Sub

    Private Sub MostrarLista(Optional logInsert As Boolean = True)
        Dim strSQL As String = ""
        If logInsert = True Then
            ListaContratos.Visible = True
            Panel5.Visible = False
            ListaContratos.Dock = DockStyle.Fill
            PanelDatos.Visible = False
            PanelDatos.Dock = DockStyle.None
            strSQL = "SELECT HDoc_Doc_Num Codigo, HDoc_Doc_Ano Año, HDoc_Emp_Nom Nombre , HDoc_Usuario Usuario " & _
            "FROM Dcmtos_HDR WHERE HDoc_Sis_Emp={0} AND HDoc_Doc_Cat= 436 ORDER BY HDoc_Doc_Fec"
            strSQL = Replace(strSQL, "{0}", Sesion.IdEmpresa)
            cFunciones.CargarLista(ListaContratos, strSQL)
            Reset()
            CeldaTitulo.Text = "Contratos Laborales"
            BloquearBotones()
        Else
            Panel5.Visible = True
            PanelDatos.Visible = True
            ' PanelDatos.Dock = DockStyle.Fill
            ListaContratos.Visible = False
            ListaContratos.Dock = DockStyle.None
            PanelDatos.Dock = DockStyle.Fill
            CeldaTitulo.Text = "Modificar Registro"
            BloquearBotones(False)
        End If
    End Sub

    Private Sub SelecionarContrato()
        Dim cEmpleado As New clsEmpleado
        Dim cContrato As New clsContrato
        Dim id As Integer = NO_FILA
        Dim strcondicion As String = STR_VACIO
        If ListaContratos.SelectedRows.Count = 0 Then Exit Sub
        id = ListaContratos.SelectedCells(0).Value
        strcondicion = "HDoc_Sis_Emp = {idempresa} And HDoc_Doc_Num = {id} AND HDoc_Doc_Ano = {ano}"
        strcondicion = Replace(strcondicion, "{idempresa}", Sesion.IdEmpresa)
        strcondicion = Replace(strcondicion, "{id}", id)
        strcondicion = Replace(strcondicion, "{ano}", ListaContratos.SelectedCells(1).Value)
        If cContrato.Seleccionar(STR_ASTERISCO, strcondicion, ListaHorarios) = True Then
            celdaAño.Text = cContrato.Anio.ToString
            celdaCodigoContrato.Text = cContrato.IdContrato.ToString
            CeldaCodigoEmpleado.Text = cContrato.IdEmpleado.ToString
            celdaEmpleado.Text = cContrato.NombreEmpleado
            celdaSueldo.Text = Format(cContrato.Sueldo, FORMATO_MONEDA)
            celdaBonificacion.Text = Format(cContrato.Bonificacion, FORMATO_MONEDA)
            celdaBono.Text = Format(cContrato.Bono, FORMATO_MONEDA)
            celdaISR.Text = Format(cContrato.ISR, FORMATO_MONEDA)
            ComboDepartamento.SelectedIndex = ComboDepartamento.FindString(cContrato.IdDepartametno)
            comboDuracion.Text = cContrato.Dias
            comboPlanilla.Text = cContrato.FormaPago
            If cContrato.FechaInicio.IsValidDateTime = False Or cContrato.FechaInicio.IsNull = True Then
                dtpInicio.Value = Today
                dtpInicio.Enabled = False
                dtpInicio.ShowCheckBox = True
                dtpInicio.Checked = True
            Else
                dtpInicio.Value = cContrato.FechaInicio
            End If
            If cContrato.FechaFin.IsValidDateTime = False Or cContrato.FechaFin.IsNull = True Then
                dtpFin.Value = Today
                dtpFin.Enabled = False
                dtpFin.ShowCheckBox = True
                dtpFin.Checked = True
            Else
                dtpFin.Value = cContrato.FechaInicio
            End If
            If cContrato.Estado = 1 Then
                celdaEstado.Text = "Activo"
                celdaEstado.BackColor = Color.LightGreen
            Else
                celdaEstado.Text = "Inactivo"
                celdaEstado.BackColor = Color.LightCoral
            End If
            'Pestaña Empleado
            celdaNombreE.Text = cContrato.NombreEmpleado
            Dim strCondicionEmpleado = "em_empresa = {idempresa} And em_codigo = {id}"
            strCondicionEmpleado = Replace(strCondicionEmpleado, "{idempresa}", Sesion.IdEmpresa)
            strCondicionEmpleado = Replace(strCondicionEmpleado, "{id}", cContrato.IdEmpleado)
            cEmpleado.Seleccionar("*", strCondicionEmpleado)
            celdaSexoE.Text = cEmpleado.Sexo
            CeldaCivielE.Text = cEmpleado.EstadoCivil
            celdaNacionalidadE.Text = cEmpleado.Nacionalidad
            celdaCedulaE.Text = cEmpleado.Cedula
            celdaDPIE.Text = cEmpleado.DPI
            celdaDirecionE.Text = cEmpleado.Direccion
            celdaMunicipioE.Text = cEmpleado.Municipio
            If cEmpleado.FechaNacimiento.IsValidDateTime Then
                dtpNacimientoE.Value = cEmpleado.FechaNacimiento
                dtpNacimientoE.Value = Today
            End If

            'Pestaña Representante
            celdaNombreR.Text = cContrato.RepresentanteNombre
            celdaCivilR.Text = cContrato.RepresentanteCivil
            celdaDireccionR.Text = cContrato.RepresentanteDireccion
            celdaMunicipioR.Text = cContrato.RepresentanteMunicipio
            If cContrato.RepresentanteNacimiento.IsValidDateTime Then
                dtpNacimientoR.Value = cContrato.RepresentanteNacimiento
            Else
                dtpNacimientoR.Value = Today
                dtpNacimientoR.Enabled = False
            End If

            celdaSexoR.Text = cContrato.RepresentanteSexo
            celdaNacionalidadR.Text = cContrato.RepresentanteNacionalidad
            celdaDPIR.Text = cContrato.RepresentanteDPI
            celdaDescripcionPuesto.Text = cContrato.DescripcionPuesto

            'Pestaña
            MostrarLista(False)
            Me.Tag = "mod"
        End If
    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim LogOK As Boolean = True
        If cFunciones.ValidarCampoNumerico(celdaBonificacion) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCampoNumerico(CeldaCodigoEmpleado) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaBono) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaSueldo) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaISR) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCombo(comboCentro) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCombo(ComboPuesto) = False Then
            LogOK = False
        End If
        If cFunciones.ValidarCombo(ComboDepartamento) = False Then
            LogOK = False
        End If
        'If cFunciones.ValidarCombo(comboDuracion) = False Then
        '    LogOK = False
        'End If
        'If cFunciones.ValidarCombo(comboPlanilla) = False Then
        '    LogOK = False
        'End If
        If cFunciones.ValidarCombo(comboMoneda) = False Then
            LogOK = False
        End If
        Return LogOK
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            botonBorrar.Enabled = False
            botonGuardar.Enabled = False
            botonExportar.Enabled = False
        Else
            botonBorrar.Enabled = True
            botonGuardar.Enabled = True
            botonExportar.Enabled = True
        End If
    End Sub

#End Region

    Private Sub frmPContratos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub FrmContratos_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    CargarCombos()
                    MostrarLista()
                    BloquearBotones()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
     
    End Sub

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        Dim cContrato As New clsContrato
        Reset()
        MostrarLista(False)
        BloquearBotones(False)
        Me.Tag = "nuevo"
        If cContrato.SelecionarRepresentanteDefault = True Then
            celdaNombreR.Text = cContrato.RepresentanteNombre
            celdaCivilR.Text = cContrato.RepresentanteCivil
            celdaDireccionR.Text = cContrato.RepresentanteDireccion
            celdaMunicipioR.Text = cContrato.RepresentanteMunicipio
            If cContrato.RepresentanteNacimiento.IsValidDateTime Then
                dtpNacimientoR.Value = cContrato.RepresentanteNacimiento
            Else
                dtpNacimientoR.Value = Today
                dtpNacimientoR.Enabled = False
            End If
            celdaSexoR.Text = cContrato.RepresentanteSexo
            celdaNacionalidadR.Text = cContrato.RepresentanteNacionalidad
            celdaDPIR.Text = cContrato.RepresentanteDPI
            celdaIdRepresentante.Text = cContrato.Representanteid
            celdaCedulaR.Text = cContrato.RepresentanteCedula
        End If
    End Sub

    Private Sub ListaContratos_DoubleClick(sender As Object, e As EventArgs) Handles ListaContratos.DoubleClick
        SelecionarContrato()
        BloquearBotones(False)
    End Sub

    Private Sub ListaContratos_KeyDown(sender As Object, e As KeyEventArgs) Handles ListaContratos.KeyDown
        If e.KeyCode = Keys.Enter Then
            SelecionarContrato()
            BloquearBotones(False)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        If ListaContratos.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
            BloquearBotones()
        End If
    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        Dim cContrato As New clsContrato
       
        If ComprobarCampos() = True Then
            cContrato.IdCentro = CType(comboCentro.Items(comboCentro.SelectedIndex), clsItemData).ItemData
            cContrato.IdDepartametno = CType(ComboDepartamento.Items(ComboDepartamento.SelectedIndex), clsItemData).ItemData
            cContrato.IdEmpleado = CInt(CeldaCodigoEmpleado.Text)
            cContrato.IdEmpresa = Sesion.IdEmpresa
            cContrato.IdMoneda = CType(comboMoneda.Items(comboMoneda.SelectedIndex), clsItemData).ItemData
            cContrato.IdPuesto = CType(ComboPuesto.Items(ComboPuesto.SelectedIndex), clsItemData).ItemData
            cContrato.Bonificacion = CDbl(celdaBonificacion.Text)
            cContrato.Bono = CDbl(celdaBono.Text)
            cContrato.Departamento = CType(ComboDepartamento.Items(ComboDepartamento.SelectedIndex), clsItemData).ToString
            cContrato.Dias = ContenedorDias.Tag
            cContrato.Estado = INT_UNO
            cContrato.FechaInicio_Net = dtpInicio.Value
            cContrato.FormaPago = comboPlanilla.Text
            cContrato.ISR = CDbl(celdaISR.Text)
            cContrato.NombreEmpleado = celdaEmpleado.Text
            cContrato.Sueldo = CDbl(celdaSueldo.Text)
            cContrato.Vigencia = comboDuracion.Text
            'datos del representante
            cContrato.Representanteid = CInt(celdaIdRepresentante.Text)
            cContrato.RepresentanteSexo = celdaSexoR.Text
            cContrato.RepresentanteNacionalidad = celdaNacionalidadR.Text
            cContrato.RepresentanteCivil = celdaCivilR.Text
            cContrato.RepresentanteDireccion = celdaDireccionR.Text
            cContrato.RepresentanteEmpresa = Sesion.Empresa
            cContrato.RepresentanteDepartamento = celdaMunicipioR.Text
            cContrato.RepresentanteMunicipio = celdaMunicipioR.Text
            cContrato.RepresentanteNacimiento_Net = dtpNacimientoR.Value
            cContrato.RepresentanteNombre = celdaNombreR.Text
            cContrato.RepresentanteDPI = celdaDPIR.Text
            cContrato.DescripcionPuesto = celdaDescripcionPuesto.Text
            If Me.Tag = "mod" Then
                Dim cContratoBorrar As New clsContrato
                If cContrato.Borrar(CInt(celdaAño.Text), CInt(celdaCodigoContrato.Text)) = False Then
                    MsgBox("No se puedo borrar el contrato selecionado", MsgBoxStyle.Critical)
                End If
            End If
            If cContrato.Guardar(ListaHorarios) = False Then
                MsgBox("ERROR")
            Else
                MostrarLista()
                BloquearBotones()
            End If
        End If
    End Sub

    Private Sub botonExportar_Click(sender As Object, e As EventArgs) Handles botonExportar.Click
        Dim cContrato As New clsContrato
        Dim strCondicion As String = STR_VACIO
        Dim id As Integer = NO_FILA
        Dim cFunci As New clsFunciones
        id = CInt(celdaCodigoContrato.Text)
        strCondicion = "HDoc_Sis_Emp = {idempresa} And HDoc_Doc_Num = {id} AND HDoc_Doc_Ano = {anio}"
        strCondicion = Replace(strCondicion, "{idempresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{id}", id)
        strCondicion = Replace(strCondicion, "{anio}", celdaAño.Text)
        If cContrato.CopiarArchivo = True Then
            If cContrato.Seleccionar(STR_ASTERISCO, strCondicion, ListaHorarios) = True Then
                ' datos del representante
                strCondicion = "em_codigo= " & cContrato.Representanteid & " and em_empresa = " & Sesion.IdEmpresa
                cFunci.AgregarParametro("{representante}", cContrato.RepresentanteNombre)
                cFunci.AgregarParametro("{edadrepresentate}", cContrato.CalcularEdad(strCondicion))
                cFunci.AgregarParametro("{sexorepresentante}", cContrato.RepresentanteSexo)
                cFunci.AgregarParametro("{civilrepresentante}", cContrato.RepresentanteCivil)
                cFunci.AgregarParametro("{nacionlaidadrepresentate}", cContrato.RepresentanteNacionalidad)
                cFunci.AgregarParametro("{vecinode}", cContrato.RepresentanteMunicipio)
                cFunci.AgregarParametro("{dpirepresentante}", cContrato.RepresentanteDPI)
                cFunci.AgregarParametro("{alcaldede}", cContrato.RepresentanteMunicipio)
                cFunci.AgregarParametro("{departamentode}", cContrato.RepresentanteDepartamento)
                cFunci.AgregarParametro("{empresa_dic}", Sesion.Empresa & cContrato.RepresentanteDireccion)
                ' datos del trabajador
                strCondicion = STR_VACIO
                strCondicion = "em_codigo= " & cContrato.IdEmpleado & " and em_empresa = " & Sesion.IdEmpresa
                cFunci.AgregarParametro("{trabajador}", cContrato.NombreEmpleado)
                cFunci.AgregarParametro("{edadtrabajador}", cContrato.CalcularEdad(strCondicion))
                cFunci.AgregarParametro("{sexotrabajador}", celdaSexoE.Text)
                cFunci.AgregarParametro("{civiltrabajador}", CeldaCivielE.Text)
                cFunci.AgregarParametro("{nacionlaidadtrabajador}", celdaNacionalidadE.Text)
                cFunci.AgregarParametro("{vecinodetrabajador}", celdaMunicipioE.Text)
                cFunci.AgregarParametro("{dpitrabajador}", celdaDPIE.Text)
                cFunci.AgregarParametro("{alcaldedetrabajador}", celdaMunicipioE.Text)
                cFunci.AgregarParametro("{direcciontrabajador}", celdaDirecionE.Text)

                ' cFunci.AgregarParametro("{vecinodetrabajador}", celdaMunicipioE.Text)
                'cFunci.AgregarParametro("{departamentodetrabajador}", cContrato.Departamento)
                ' datos del contrato
                cFunci.AgregarParametro("{diainicio}", dtpInicio.Value.Day)
                cFunci.AgregarParametro("{mesinicio}", dtpInicio.Value.Month)
                cFunci.AgregarParametro("{añoinicio}", dtpInicio.Value.Year)
                cFunci.AgregarParametro("{puesto}", ComboPuesto.Text)
                cFunci.AgregarParametro("{descirpcionpuesto}", cContrato.DescripcionPuesto)
                cFunci.AgregarParametro("{direccioncentro}", celdaDireccionR.Text)
                cFunci.AgregarParametro("{duracion}", "INDEFINIDO")
                cFunci.AgregarParametro("{horasdiarias}", cFunci.ALetras(8))
                cFunci.AgregarParametro("{horasemana}", cFunci.ALetras(44))
                cFunci.AgregarParametro("{lugar}", cFunci.PaisDefault)
                cFunci.AgregarParametro("{dia}", cContrato.Fecha.Day)
                cFunci.AgregarParametro("{mes}", cContrato.Fecha.Month)
                cFunci.AgregarParametro("{año}", cContrato.Fecha.Year)
                cFunci.AgregarParametro("{sueldo}", cFunci.ALetras(cContrato.Sueldo))
                cFunci.AgregarParametro("{sueldoNumeros}", cContrato.Sueldo)
                cFunci.AgregarParametro("{bonificacion}", cFunci.ALetras(cContrato.Bonificacion))
                cFunci.AgregarParametro("{bonificacionNumeros}", cContrato.Bonificacion)
                cFunci.AgregarParametro("{bono}", cContrato.Bono)
                cFunci.AgregarParametro("{tipoplanilla}", cContrato.FormaPago)

                ' horarios
                Dim cDtl As New clsDcmtos_DTL
                cDtl.CONEXION = strConexion
                strCondicion = NO_FILA
                strCondicion = "DDoc_Sis_Emp = {idempresa} AND DDoc_Doc_Num = {id} AND DDoc_Doc_Cat = 436" & _
                    " AND DDoc_Doc_Ano = {año} AND DDoc_Prd_PNr= 'HORARIO'"
                strCondicion = Replace(strCondicion, "{idempresa}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{id}", id)
                strCondicion = Replace(strCondicion, "{año}", cContrato.Anio)
                If cDtl.SeleccionarLista(strCondicion) = True Then
                    Do While cDtl.SiguienteRegistro = True
                        If cDtl.DDOC_PRD_DES = "Diurna" Then
                            Select Case cDtl.DDOC_RF1_COD
                                Case "Matutino"
                                    cFunci.AgregarParametro("{dirunamañanai}", cDtl.DDOC_RF2_COD)
                                    cFunci.AgregarParametro("{dirunamañanaf}", cDtl.DDOC_PRD_REF)
                                Case "Vespertino"
                                    cFunci.AgregarParametro("{diurnatardei}", cDtl.DDOC_RF2_COD)
                                    cFunci.AgregarParametro("{diurnataredef}", cDtl.DDOC_PRD_REF)
                                Case "Sabatino"
                                    cFunci.AgregarParametro("{diaexepto}", "Sábado")
                                    cFunci.AgregarParametro("{exeptoi}", cDtl.DDOC_RF2_COD)
                                    cFunci.AgregarParametro("{exeptof}", cDtl.DDOC_PRD_REF)
                            End Select
                        Else
                            cFunci.AgregarParametro("{dirunamañanai}", STR_RELLENO)
                            cFunci.AgregarParametro("{dirunamañanaf}", STR_RELLENO)
                            cFunci.AgregarParametro("{diurnatardei}", STR_RELLENO)
                            cFunci.AgregarParametro("{diurnataredef}", STR_RELLENO)
                            cFunci.AgregarParametro("{diaexepto}", STR_RELLENO)
                            cFunci.AgregarParametro("{exeptoi}", STR_RELLENO)
                            cFunci.AgregarParametro("{exeptof}", STR_RELLENO)
                        End If
                        If cDtl.DDOC_PRD_DES = "Nocturna" Then
                            cFunci.AgregarParametro("{nocturnai}", cDtl.DDOC_RF2_COD)
                            cFunci.AgregarParametro("{nocturnaf}", cDtl.DDOC_PRD_REF)
                        Else
                            cFunci.AgregarParametro("{nocturnai}", STR_RELLENO)
                            cFunci.AgregarParametro("{nocturnaf}", STR_RELLENO)
                        End If
                        If cDtl.DDOC_PRD_DES = "Mixta" Then
                            cFunci.AgregarParametro("{mixtai}", cDtl.DDOC_RF2_COD)
                            cFunci.AgregarParametro("{mixtaf}", cDtl.DDOC_PRD_REF)
                        Else
                            cFunci.AgregarParametro("{mixtai}", STR_RELLENO)
                            cFunci.AgregarParametro("{mixtaf}", STR_RELLENO)
                        End If
                        If cDtl.DDOC_PRD_DES = "Continua" Then
                            Select Case cDtl.DDOC_RF1_COD
                                Case "Lun-Vien"
                                    cFunci.AgregarParametro("{continuai}", STR_RELLENO)
                                    cFunci.AgregarParametro("{continuef}", STR_RELLENO)
                                Case "Sabado"
                                    cFunci.AgregarParametro("{sabadoi}", STR_RELLENO)
                                    cFunci.AgregarParametro("{sabadof}", STR_RELLENO)
                            End Select
                        Else
                            cFunci.AgregarParametro("{continuai}", STR_RELLENO)
                            cFunci.AgregarParametro("{continuef}", STR_RELLENO)
                            cFunci.AgregarParametro("{sabadoi}", STR_RELLENO)
                            cFunci.AgregarParametro("{sabadof}", STR_RELLENO)
                        End If
                    Loop
                Else
                    MsgBox(cDtl.MERROR.ToString)
                End If
                If cFunci.WordBuscaryReemplazar(cContrato.Path) = True Then
                    MsgBox("EXportacion finalizada")
                End If
            End If
        End If

    End Sub



    Private Sub botonSelecionar_Click(sender As Object, e As EventArgs) Handles botonSelecionar.Click
        Dim frm As New frmPSelecionarEmpleado
        Try
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaEmpleado.Text = frm.Descripcion
                celdaCodigoContrato.Text = NO_FILA.ToString
                CeldaCodigoEmpleado.Text = frm.idEmpleado.ToString
                If frm.Estado = 1 Then
                    celdaEstado.Text = "Activo"
                Else
                    celdaEstado.Text = "Inactivo"
                End If
                celdaNombreE.Text = frm.Descripcion
                celdaSexoE.Text = frm.Sexo
                celdaNacionalidadE.Text = frm.Nacionalidad
                celdaCedulaE.Text = frm.Cedula
                celdaDPIE.Text = frm.DPI
                celdaDirecionE.Text = frm.Direccion
                CeldaCivielE.Text = frm.EstadoCivil
                celdaMunicipioE.Text = frm.Municipio
                dtpNacimientoE.Value = frm.FechaNacimiento
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonSelecionarR_Click(sender As Object, e As EventArgs) Handles botonSelecionarR.Click
        Dim frm As New frmPSelecionarEmpleado
        Try
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaIdRepresentante.Text = frm.idEmpleado.ToString
                celdaNombreR.Text = frm.Descripcion
                celdaSexoR.Text = frm.Sexo
                celdaNacionalidadR.Text = frm.Nacionalidad
                celdaCedulaR.Text = frm.Cedula
                celdaDPIR.Text = frm.DPI
                celdaCivilR.Text = frm.EstadoCivil
                celdaMunicipioR.Text = frm.Municipio
                dtpNacimientoR.Value = frm.FechaNacimiento
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub comboJornada_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboJornada.SelectedIndexChanged
        cFunciones.CargarCombo(comboHorario, "Catalogos", " CONCAT(cat_clave,' De ', cat_desc, ' A ', cat_sist)", "cat_num", "cat_clase = 'Horario' AND cat_pid= " & CType(comboJornada.Items(comboJornada.SelectedIndex), clsItemData).ItemData)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim strCondicion As String = STR_VACIO
        Dim Cell As DataGridViewCell
        Dim Row = New DataGridViewRow
        strCondicion = "cat_num = " & CType(comboHorario.Items(comboHorario.SelectedIndex), clsItemData).ItemData
        Dim cCatalogos As New clsCatalogos
        cCatalogos.CONEXION = strConexion
        If cCatalogos.MERROR.Length > 0 Then
            MsgBox(cCatalogos.MERROR.ToString)
        End If
        Try
            If cCatalogos.Seleccionar(strCondicion) = False Then
                MsgBox(cCatalogos.MERROR.ToString)
            Else
                Cell = New DataGridViewTextBoxCell
                Cell.Value = cCatalogos.CAT_NUM.ToString
                Row.Cells.Add(Cell)
                Cell = New DataGridViewTextBoxCell
                Cell.Value = comboJornada.Text
                Row.Cells.Add(Cell)
                Cell = New DataGridViewTextBoxCell
                Cell.Value = cCatalogos.CAT_CLAVE
                Row.Cells.Add(Cell)
                Cell = New DataGridViewTextBoxCell
                Cell.Value = cCatalogos.CAT_DESC
                Row.Cells.Add(Cell)
                Cell = New DataGridViewTextBoxCell
                Cell.Value = cCatalogos.CAT_SIST
                Row.Cells.Add(Cell)
                ListaHorarios.Rows.Add(Row)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        Dim cContrato As New clsContrato
        If cContrato.Borrar(CInt(celdaAño.Text), CInt(celdaCodigoContrato.Text)) = False Then
            MsgBox("No se puedo borrar el contrato selecionado", MsgBoxStyle.Critical)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub ComboPuesto_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboPuesto.SelectedIndexChanged
       
        '  Dim cPuestos As New clsPuesto
        Dim strCondicon As String = STR_VACIO
        Dim idpuesto As Integer = NO_FILA
        idpuesto = CType(ComboPuesto.Items(ComboPuesto.SelectedIndex), clsItemData).ItemData
        strCondicon = "pue_codigo = " & idpuesto
        'If cPuestos.Selecionar("pue_base, pue_bono1, pue_bono2, pue_moneda", strCondicon) = True Then
        '    celdaSueldo.Text = Format(cPuestos.Sueldo, FORMATO_MONEDA)
        '    celdaBonificacion.Text = Format(cPuestos.Bonificacion, FORMATO_MONEDA)
        '    celdaBono.Text = Format(cPuestos.Bono, FORMATO_MONEDA)
        'End If
        Dim cPuesto As New clsPuesto
        cPuesto.CONEXION = strConexion
        If cPuesto.Seleccionar("pue_base, pue_bono1, pue_bono2, pue_moneda", strCondicon) = True Then
            celdaSueldo.Text = Format(cPuesto.PUE_BASE, FORMATO_MONEDA)
            celdaBonificacion.Text = Format(cPuesto.PUE_BONO1, FORMATO_MONEDA)
            celdaBono.Text = Format(cPuesto.PUE_BONO2, FORMATO_MONEDA)
        Else
            MsgBox(cPuesto.MERROR.ToString)
        End If
    End Sub

    Private Sub comboCentro_SelectedIndexChanged(sender As Object, e As EventArgs) Handles comboCentro.SelectedIndexChanged
        Dim cCentro As New clsCentros
        Dim strCondicon As String = STR_VACIO
        strCondicon = "cen_codigo = " & CType(comboCentro.Items(comboCentro.SelectedIndex), clsItemData).ItemData.ToString
        Try
            cCentro.CONEXION = strConexion
            If cCentro.PSELECT_CONDICION(strCondicon) = True Then
                celdaDireccionR.Text = cCentro.CEN_DIRECCION
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaDescripcionPuesto_TextChanged(sender As Object, e As EventArgs)
        cFunciones.ValidadarLongitudTextBox(celdaDescripcionPuesto, 255)
    End Sub

  
End Class