﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPPuestos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CuadroLogo = New System.Windows.Forms.PictureBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonBorrar = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonNuevo = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CeldaTitulo = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CeldaId = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaSbase = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.comboMoneda = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaBonificacion = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaBono = New System.Windows.Forms.TextBox()
        Me.listaPuestos = New System.Windows.Forms.DataGridView()
        Me.Panel1.SuspendLayout()
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.listaPuestos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.CuadroLogo)
        Me.Panel1.Controls.Add(Me.botonCerrar)
        Me.Panel1.Controls.Add(Me.botonBorrar)
        Me.Panel1.Controls.Add(Me.botonGuardar)
        Me.Panel1.Controls.Add(Me.botonNuevo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(495, 86)
        Me.Panel1.TabIndex = 2
        '
        'CuadroLogo
        '
        Me.CuadroLogo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CuadroLogo.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CuadroLogo.Image = Global.KARIMs_SGI.My.Resources.Resources.logokarims
        Me.CuadroLogo.Location = New System.Drawing.Point(389, 3)
        Me.CuadroLogo.Name = "CuadroLogo"
        Me.CuadroLogo.Size = New System.Drawing.Size(99, 78)
        Me.CuadroLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.CuadroLogo.TabIndex = 1
        Me.CuadroLogo.TabStop = False
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(327, 15)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(56, 45)
        Me.botonCerrar.TabIndex = 0
        Me.botonCerrar.Text = "&Cerrar"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonBorrar
        '
        Me.botonBorrar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonBorrar.Location = New System.Drawing.Point(136, 15)
        Me.botonBorrar.Name = "botonBorrar"
        Me.botonBorrar.Size = New System.Drawing.Size(56, 45)
        Me.botonBorrar.TabIndex = 0
        Me.botonBorrar.Text = "&Borrar"
        Me.botonBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBorrar.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.botonGuardar.Location = New System.Drawing.Point(74, 15)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(56, 45)
        Me.botonGuardar.TabIndex = 0
        Me.botonGuardar.Text = "&Guardar"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonNuevo
        '
        Me.botonNuevo.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonNuevo.Location = New System.Drawing.Point(12, 15)
        Me.botonNuevo.Name = "botonNuevo"
        Me.botonNuevo.Size = New System.Drawing.Size(56, 45)
        Me.botonNuevo.TabIndex = 0
        Me.botonNuevo.Text = "&Nuevo"
        Me.botonNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevo.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.Control
        Me.Panel2.Controls.Add(Me.CeldaTitulo)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 86)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(495, 30)
        Me.Panel2.TabIndex = 3
        '
        'CeldaTitulo
        '
        Me.CeldaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTitulo.AutoSize = True
        Me.CeldaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTitulo.Location = New System.Drawing.Point(18, 6)
        Me.CeldaTitulo.Name = "CeldaTitulo"
        Me.CeldaTitulo.Size = New System.Drawing.Size(50, 18)
        Me.CeldaTitulo.TabIndex = 0
        Me.CeldaTitulo.Text = "Titulo"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(38, 147)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Código"
        '
        'CeldaId
        '
        Me.CeldaId.Location = New System.Drawing.Point(41, 163)
        Me.CeldaId.Name = "CeldaId"
        Me.CeldaId.ReadOnly = True
        Me.CeldaId.Size = New System.Drawing.Size(100, 20)
        Me.CeldaId.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(38, 194)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(63, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Descripción"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDescripcion.Location = New System.Drawing.Point(41, 217)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(244, 20)
        Me.celdaDescripcion.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(38, 250)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Salario base"
        '
        'celdaSbase
        '
        Me.celdaSbase.Location = New System.Drawing.Point(41, 269)
        Me.celdaSbase.Name = "celdaSbase"
        Me.celdaSbase.Size = New System.Drawing.Size(109, 20)
        Me.celdaSbase.TabIndex = 7
        Me.celdaSbase.Text = "0.00"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(168, 249)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Moneda"
        '
        'comboMoneda
        '
        Me.comboMoneda.FormattingEnabled = True
        Me.comboMoneda.Location = New System.Drawing.Point(171, 268)
        Me.comboMoneda.Name = "comboMoneda"
        Me.comboMoneda.Size = New System.Drawing.Size(121, 21)
        Me.comboMoneda.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(38, 301)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Bonificación"
        '
        'celdaBonificacion
        '
        Me.celdaBonificacion.Location = New System.Drawing.Point(41, 320)
        Me.celdaBonificacion.Name = "celdaBonificacion"
        Me.celdaBonificacion.Size = New System.Drawing.Size(109, 20)
        Me.celdaBonificacion.TabIndex = 7
        Me.celdaBonificacion.Text = "250.00"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(38, 350)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Bono (Extra)"
        '
        'celdaBono
        '
        Me.celdaBono.Location = New System.Drawing.Point(41, 369)
        Me.celdaBono.Name = "celdaBono"
        Me.celdaBono.Size = New System.Drawing.Size(109, 20)
        Me.celdaBono.TabIndex = 7
        Me.celdaBono.Text = "0.00"
        '
        'listaPuestos
        '
        Me.listaPuestos.AllowUserToAddRows = False
        Me.listaPuestos.AllowUserToDeleteRows = False
        Me.listaPuestos.AllowUserToOrderColumns = True
        Me.listaPuestos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.listaPuestos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.listaPuestos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.listaPuestos.Location = New System.Drawing.Point(350, 268)
        Me.listaPuestos.MultiSelect = False
        Me.listaPuestos.Name = "listaPuestos"
        Me.listaPuestos.ReadOnly = True
        Me.listaPuestos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.listaPuestos.Size = New System.Drawing.Size(106, 83)
        Me.listaPuestos.TabIndex = 10
        '
        'frmPPuestos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(495, 432)
        Me.Controls.Add(Me.listaPuestos)
        Me.Controls.Add(Me.comboMoneda)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.celdaBono)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.celdaBonificacion)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.celdaSbase)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.celdaDescripcion)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CeldaId)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frmPPuestos"
        Me.ShowIcon = False
        Me.Text = "Puestos"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        CType(Me.CuadroLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.listaPuestos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CuadroLogo As System.Windows.Forms.PictureBox
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonBorrar As System.Windows.Forms.Button
    Friend WithEvents botonGuardar As System.Windows.Forms.Button
    Friend WithEvents botonNuevo As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents CeldaTitulo As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CeldaId As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaSbase As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents comboMoneda As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents celdaBonificacion As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents celdaBono As System.Windows.Forms.TextBox
    Friend WithEvents listaPuestos As System.Windows.Forms.DataGridView
End Class
