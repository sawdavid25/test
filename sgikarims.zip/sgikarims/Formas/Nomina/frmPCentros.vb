﻿Public Class frmPCentros
    Dim cNomina As New ClsNomina
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property
#Region "Funciones y Procedimientos"

    Private Sub reset()
        CeldaId.Text = "-1"
        CeldaDescripcion.Text = ""
        CeldaDireccion.Text = ""
        CeldaMunicipio.Text = ""
    End Sub

    Private Sub MostrarLista(Optional ByVal log As Boolean = True)
        Dim strSQL As String = ""
        If log = True Then
            ListaCentros.Visible = True
            ListaCentros.Dock = DockStyle.Fill
            PanelDatos.Visible = False
            PanelDatos.Dock = DockStyle.None
            strSQL = "SELECT cen_codigo Codigo, cen_descripcion Descripcion, cen_direccion Direccion, cen_municipio Municipio " & _
            "FROM Centros WHERE cen_empresa={0} ORDER BY cen_codigo"
            strSQL = Replace(strSQL, "{0}", Sesion.IdEmpresa)
            cNomina.CargarLista(ListaCentros, strSQL)
            Permisos()
            reset()
            CeldaTitulo.Text = "Centros de trabajo"
        Else
            PanelDatos.Visible = True
            PanelDatos.Dock = DockStyle.Fill
            ListaCentros.Visible = False
            ListaCentros.Dock = DockStyle.None
            CeldaTitulo.Text = "Modificar Registro"
        End If
    End Sub

    Private Sub Permisos()
        If ListaCentros.Visible = True Then
            CeldaTitulo.Text = "Centros de trabajo"
            botonGuardar.Enabled = False
            botonBorrar.Enabled = False
        Else
            CeldaTitulo.Text = "Modificar registros"
            botonGuardar.Enabled = True
            botonBorrar.Enabled = True
        End If

    End Sub

    Private Sub SelecionarCentro()
        If logConsultar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If ListaCentros.SelectedRows.Count = 0 Then Exit Sub
        CeldaId.Text = ListaCentros.SelectedCells(0).Value
        CeldaDescripcion.Text = ListaCentros.SelectedCells(1).Value
        CeldaDireccion.Text = ListaCentros.SelectedCells(2).Value
        CeldaMunicipio.Text = ListaCentros.SelectedCells(3).Value
        MostrarLista(False)
        Me.Tag = "mod"
    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim logOk As Boolean = False
        If CeldaDescripcion.Text.Length < 1 Or CeldaDireccion.Text.Length < 1 Or CeldaMunicipio.Text.Length < 1 Then
            If CeldaDescripcion.Text.Length < 1 Then
                CeldaDescripcion.BackColor = Color.Coral
            Else
                CeldaDescripcion.BackColor = Color.White
            End If
            If CeldaDireccion.Text.Length < 1 Then
                CeldaDireccion.BackColor = Color.Coral
            Else
                CeldaDireccion.BackColor = Color.White
            End If
            If CeldaMunicipio.Text.Length < 1 Then
                CeldaMunicipio.BackColor = Color.Coral
            Else
                CeldaMunicipio.BackColor = Color.White
            End If
            MsgBox("Todos los campos son obligatorios", MsgBoxStyle.Critical)
        Else
            logOk = True
        End If
        Return logOk
    End Function

  

#End Region

    Private Sub frmPCentros_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub
    
    Private Sub frmPCentros_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    MostrarLista()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        If ListaCentros.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        reset()
        MostrarLista(False)
        Permisos()
        Me.Tag = "nuevo"
    End Sub

    Private Sub ListaCentros_DoubleClick(sender As Object, e As EventArgs) Handles ListaCentros.DoubleClick
        SelecionarCentro()
        Permisos()
    End Sub

    Private Sub ListaCentros_KeyDown(sender As Object, e As KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            SelecionarCentro()
            Permisos()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        If LogBorrar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If Me.Tag = "mod" Then
            Try
                If cNomina.BorrarCentro(CInt(CeldaId.Text), CeldaDescripcion.Text) = True Then
                    MostrarLista()
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub botonGuardar_Click(sender As Object, e As EventArgs) Handles botonGuardar.Click
        If ComprobarCampos() = False Then
            Exit Sub
        End If
        If Me.Tag = "nuevo" Then
            If logInsertar = False Then
                MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                Exit Sub
            End If
            If cNomina.GuardarCentro(CInt(CeldaId.Text), CeldaDescripcion.Text, CeldaDireccion.Text, CeldaMunicipio.Text) = True Then
                cFunciones.EscribirRegistro("Centros", clsFunciones.AccEnum.acAdd, CInt(CeldaId.Text))
            End If
        ElseIf Me.Tag = "mod" Then
            If logEditar = False Then
                MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                Exit Sub
            End If
            If cNomina.GuardarCentro(CInt(CeldaId.Text), CeldaDescripcion.Text, CeldaDireccion.Text, CeldaMunicipio.Text, False) = True Then
                cFunciones.EscribirRegistro("Centros", clsFunciones.AccEnum.acUpdate, CInt(CeldaId.Text))
            End If
        End If
        MostrarLista()
    End Sub

 
End Class