﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFernanda
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDet2 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripción = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaNumCentroCostos = New System.Windows.Forms.TextBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDProveedor = New System.Windows.Forms.TextBox()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.EtiquetaObservaciones = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.botonCentroCostos = New System.Windows.Forms.Button()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaCentroCostos = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaCentroCosto = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.etiquetaOrden = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.celdaNoOrden = New System.Windows.Forms.TextBox()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.panelDocumento.SuspendLayout()
        Me.panelDet2.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelLista.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDet2)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(13, 118)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(593, 370)
        Me.panelDocumento.TabIndex = 2
        '
        'panelDet2
        '
        Me.panelDet2.Controls.Add(Me.dgDetalle)
        Me.panelDet2.Controls.Add(Me.panelBotones)
        Me.panelDet2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDet2.Location = New System.Drawing.Point(0, 227)
        Me.panelDet2.Name = "panelDet2"
        Me.panelDet2.Size = New System.Drawing.Size(593, 143)
        Me.panelDet2.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripción, Me.colPrecio, Me.colCantidad, Me.colTotal})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.Size = New System.Drawing.Size(496, 143)
        Me.dgDetalle.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        '
        'colDescripción
        '
        Me.colDescripción.HeaderText = "Description"
        Me.colDescripción.Name = "colDescripción"
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "quantity"
        Me.colCantidad.Name = "colCantidad"
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonQuitar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(496, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(97, 143)
        Me.panelBotones.TabIndex = 0
        '
        'botonQuitar
        '
        Me.botonQuitar.Location = New System.Drawing.Point(49, 85)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(32, 23)
        Me.botonQuitar.TabIndex = 1
        Me.botonQuitar.UseVisualStyleBackColor = True
        Me.botonQuitar.UseWaitCursor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Location = New System.Drawing.Point(49, 46)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(32, 23)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.botonProveedor)
        Me.panelEncabezado.Controls.Add(Me.celdaNumCentroCostos)
        Me.panelEncabezado.Controls.Add(Me.celdaIDMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaIDProveedor)
        Me.panelEncabezado.Controls.Add(Me.celdaObservaciones)
        Me.panelEncabezado.Controls.Add(Me.EtiquetaObservaciones)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.botonCentroCostos)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCentroCostos)
        Me.panelEncabezado.Controls.Add(Me.celdaTasa)
        Me.panelEncabezado.Controls.Add(Me.celdaCentroCosto)
        Me.panelEncabezado.Controls.Add(Me.celdaDireccion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDireccion)
        Me.panelEncabezado.Controls.Add(Me.celdaProveedor)
        Me.panelEncabezado.Controls.Add(Me.etiquetaProveedor)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTotal)
        Me.panelEncabezado.Controls.Add(Me.celdaTotal)
        Me.panelEncabezado.Controls.Add(Me.checkActivo)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAño)
        Me.panelEncabezado.Controls.Add(Me.etiquetaOrden)
        Me.panelEncabezado.Controls.Add(Me.celdaAño)
        Me.panelEncabezado.Controls.Add(Me.celdaNoOrden)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(593, 227)
        Me.panelEncabezado.TabIndex = 0
        '
        'botonProveedor
        '
        Me.botonProveedor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor.Location = New System.Drawing.Point(546, 110)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(31, 23)
        Me.botonProveedor.TabIndex = 27
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaNumCentroCostos
        '
        Me.celdaNumCentroCostos.Location = New System.Drawing.Point(349, 171)
        Me.celdaNumCentroCostos.Name = "celdaNumCentroCostos"
        Me.celdaNumCentroCostos.Size = New System.Drawing.Size(19, 20)
        Me.celdaNumCentroCostos.TabIndex = 26
        Me.celdaNumCentroCostos.Text = "-1"
        Me.celdaNumCentroCostos.Visible = False
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(312, 62)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(15, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDProveedor
        '
        Me.celdaIDProveedor.Location = New System.Drawing.Point(268, 89)
        Me.celdaIDProveedor.Name = "celdaIDProveedor"
        Me.celdaIDProveedor.Size = New System.Drawing.Size(18, 20)
        Me.celdaIDProveedor.TabIndex = 24
        Me.celdaIDProveedor.Text = "-1"
        Me.celdaIDProveedor.Visible = False
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservaciones.Location = New System.Drawing.Point(471, 177)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(66, 38)
        Me.celdaObservaciones.TabIndex = 23
        '
        'EtiquetaObservaciones
        '
        Me.EtiquetaObservaciones.AutoSize = True
        Me.EtiquetaObservaciones.Location = New System.Drawing.Point(396, 201)
        Me.EtiquetaObservaciones.Name = "EtiquetaObservaciones"
        Me.EtiquetaObservaciones.Size = New System.Drawing.Size(69, 13)
        Me.EtiquetaObservaciones.TabIndex = 22
        Me.EtiquetaObservaciones.Text = "Observations"
        Me.EtiquetaObservaciones.UseMnemonic = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(97, 188)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(31, 23)
        Me.botonMoneda.TabIndex = 21
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(17, 190)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(74, 20)
        Me.celdaMoneda.TabIndex = 20
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(14, 174)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 19
        Me.etiquetaMoneda.Text = "Currency"
        '
        'botonCentroCostos
        '
        Me.botonCentroCostos.Location = New System.Drawing.Point(348, 191)
        Me.botonCentroCostos.Name = "botonCentroCostos"
        Me.botonCentroCostos.Size = New System.Drawing.Size(31, 23)
        Me.botonCentroCostos.TabIndex = 18
        Me.botonCentroCostos.Text = "..."
        Me.botonCentroCostos.UseVisualStyleBackColor = True
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(148, 174)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaTasa.TabIndex = 16
        Me.etiquetaTasa.Text = "Exchange"
        '
        'etiquetaCentroCostos
        '
        Me.etiquetaCentroCostos.AutoSize = True
        Me.etiquetaCentroCostos.Location = New System.Drawing.Point(265, 174)
        Me.etiquetaCentroCostos.Name = "etiquetaCentroCostos"
        Me.etiquetaCentroCostos.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaCentroCostos.TabIndex = 15
        Me.etiquetaCentroCostos.Text = "Cost Center"
        Me.etiquetaCentroCostos.UseMnemonic = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(151, 190)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(108, 20)
        Me.celdaTasa.TabIndex = 14
        '
        'celdaCentroCosto
        '
        Me.celdaCentroCosto.Location = New System.Drawing.Point(265, 191)
        Me.celdaCentroCosto.Name = "celdaCentroCosto"
        Me.celdaCentroCosto.Size = New System.Drawing.Size(74, 20)
        Me.celdaCentroCosto.TabIndex = 13
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion.Location = New System.Drawing.Point(17, 151)
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(523, 20)
        Me.celdaDireccion.TabIndex = 12
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(14, 135)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaDireccion.TabIndex = 11
        Me.etiquetaDireccion.Text = "Direction"
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor.Location = New System.Drawing.Point(17, 112)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(523, 20)
        Me.celdaProveedor.TabIndex = 10
        Me.celdaProveedor.UseSystemPasswordChar = True
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(14, 96)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaProveedor.TabIndex = 9
        Me.etiquetaProveedor.Text = "Provider"
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(396, 6)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaTotal.TabIndex = 8
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(399, 22)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(74, 20)
        Me.celdaTotal.TabIndex = 7
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(481, 25)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 6
        Me.checkActivo.Text = "Activo"
        Me.checkActivo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(17, 62)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(121, 20)
        Me.dtpFecha.TabIndex = 5
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(17, 46)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 4
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(79, 6)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 3
        Me.etiquetaAño.Text = "Year"
        '
        'etiquetaOrden
        '
        Me.etiquetaOrden.AutoSize = True
        Me.etiquetaOrden.Location = New System.Drawing.Point(14, 6)
        Me.etiquetaOrden.Name = "etiquetaOrden"
        Me.etiquetaOrden.Size = New System.Drawing.Size(32, 13)
        Me.etiquetaOrden.TabIndex = 2
        Me.etiquetaOrden.Text = "Code"
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAño.Location = New System.Drawing.Point(82, 22)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(56, 20)
        Me.celdaAño.TabIndex = 1
        '
        'celdaNoOrden
        '
        Me.celdaNoOrden.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNoOrden.Location = New System.Drawing.Point(17, 22)
        Me.celdaNoOrden.Name = "celdaNoOrden"
        Me.celdaNoOrden.ReadOnly = True
        Me.celdaNoOrden.Size = New System.Drawing.Size(60, 20)
        Me.celdaNoOrden.TabIndex = 0
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.panelDetalle)
        Me.panelLista.Controls.Add(Me.panelFiltro)
        Me.panelLista.Location = New System.Drawing.Point(612, 118)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(318, 170)
        Me.panelLista.TabIndex = 3
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgLista)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 89)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(318, 81)
        Me.panelDetalle.TabIndex = 0
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(318, 81)
        Me.dgLista.TabIndex = 4
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonFiltrar)
        Me.panelFiltro.Controls.Add(Me.dtpFinal)
        Me.panelFiltro.Controls.Add(Me.checkFechas)
        Me.panelFiltro.Controls.Add(Me.dtpInicio)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(318, 89)
        Me.panelFiltro.TabIndex = 1
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(193, 42)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(57, 23)
        Me.botonFiltrar.TabIndex = 3
        Me.botonFiltrar.Text = "Filter"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(103, 45)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(84, 20)
        Me.dtpFinal.TabIndex = 2
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(13, 22)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(84, 17)
        Me.checkFechas.TabIndex = 1
        Me.checkFechas.Text = "Date Range"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'dtpInicio
        '
        Me.dtpInicio.Location = New System.Drawing.Point(13, 45)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(84, 20)
        Me.dtpInicio.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 61)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(933, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(933, 61)
        Me.Encabezado1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(653, 348)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmFernanda
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(933, 505)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmFernanda"
        Me.Text = "frmFernanda"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDet2.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelDet2 As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents botonFiltrar As System.Windows.Forms.Button
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripción As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents EtiquetaObservaciones As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents botonCentroCostos As System.Windows.Forms.Button
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents etiquetaCentroCostos As System.Windows.Forms.Label
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents celdaCentroCosto As System.Windows.Forms.TextBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents celdaProveedor As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProveedor As System.Windows.Forms.Label
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents etiquetaOrden As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents celdaNoOrden As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDProveedor As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumCentroCostos As System.Windows.Forms.TextBox
    Friend WithEvents botonProveedor As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
