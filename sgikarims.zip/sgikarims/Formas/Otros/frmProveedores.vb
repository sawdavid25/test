﻿Imports System.ComponentModel

Public Class frmProveedores

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLLista() As String
        Dim strsql As String = STR_VACIO
        strsql = "SELECT pro_codigo ID, pro_proveedor Name, pro_nit NIT, pro_status estado, "
        strsql &= "  IFNULL(p.pro_nombre,'N/A') Abbreviation, IFNULL(p.pro_direccion,'N/A') Adress, IFNULL(p.pro_telefono,'N/A') Telephone,p.pro_iva Iva, IFNULL(p.pro_anticipos,'0') recibos"
        strsql &= "     FROM Proveedores p"
        strsql &= "   WHERE p.pro_sisemp = {empresa}"
        strsql &= " Order By pro_codigo Desc"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        Return strsql
    End Function
    Private Function SeleccionarNIT(ByVal intCodigo As Integer)

        Dim strsql As String = STR_VACIO
        Dim CLS As New Tablas.TCLIENTES
        Dim CA As New clsCatalogos

        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        Try

            strsql = " SELECT est.cli_status, cli.cli_exterior, pais.cat_desc pais , cat.cat_desc moneda , c.nombre nombre,"
            strsql &= "    p.* FROM Proveedores p "
            strsql &= "      LEFT JOIN conta.cuentas c on c.empresa = p.pro_sisemp and c.id_cuenta = p.pro_cuenta"
            strsql &= "           LEFT JOIN Catalogos cat on cat.cat_num =  p.pro_moneda "
            strsql &= "      LEFT JOIN Catalogos pais on pais.cat_num =  p.pro_pais"
            strsql &= "    LEFT JOIN Clientes cli on cli.cli_codigo = p.pro_exterior "
            strsql &= "  LEFT JOIN Clientes est on est.cli_status = p.pro_status"
            strsql &= " WHERE p.pro_sisemp = {empresa} and p.pro_codigo = {codigo}"

            strsql = Replace(strsql, "{codigo}", intCodigo)
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read
                    celdaCodigo.Text = REA.GetString("pro_codigo")
                    celdaDesCorta.Text = REA.GetString("nombre")
                    celdaRazonSocial.Text = REA.GetString("pro_proveedor")
                    celdaDireccion.Text = REA.GetString("pro_direccion")
                    celdaTelefono.Text = REA.GetString("pro_telefono")
                    celdaNT.Text = REA.GetString("pro_nit")
                    celdaAreaNegocios.Text = REA.GetString("pro_ramo")
                    celdaRegimen.Text = REA.GetString("cli_exterior")
                    celdaCuentasxPagar.Text = REA.GetString("pro_cuenta")
                    celdaCxPagar.Text = REA.GetString("nombre")
                    celdaPredPro.Text = REA.GetString("pro_cuenta")
                    celdaPreProduct.Text = REA.GetString("nombre")
                    celdaMoneda.Text = REA.GetString("moneda")
                    celdaPais.Text = REA.GetString("pais")
                    celdaMetodoCosteo.Text = REA.GetString("pro_cmethod")
                    celdaEstado.Text = REA.GetString("pro_status")
                Loop

                If REA.GetString("pro_fabricante") = "Si" Then
                    rbotonSi.Checked = True
                Else
                    rbotonNo.Checked = False
                End If
            Else
                'MsgBox(CLS.MERROR.ToString)
            End If
            Return strsql
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function
    Private Sub reset()
        celdaCodigo.Text = NO_FILA
        celdaDesCorta.Text = STR_VACIO
        celdaRazonSocial.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        celdaTelefono.Text = STR_VACIO
        celdaNT.Text = STR_VACIO
        celdaRegimen.Text = "Local"
        celdaMoneda.Text = Divisa.Local.simbolo
        celdaIDMoneda.Text = Divisa.Local.id
        celdaPais.Text = cfun.PaisDefault()
        celdaIDPais.Text = sqlPaisSeleccionado()
        celdaAreaNegocios.Text = "Textil"
        celdaMetodoCosteo.Text = "CIF"
        celdaEstado.Text = "Activo"
        celdaDescuento.Text = "0.00"
        celdaPlazoCredito.Text = "0"
        celdaLimiteCredito.Text = "0.00"
        celdaCuentasxPagar.Clear()
        celdaCtaNombre.Clear()
        celdaCxPagar.Text = "(cuenta no asignada)"
        celdaPredPro.Text = STR_VACIO
        celdaPreProduct.Text = STR_VACIO
        celdaSaldo.Text = "0.00"
        celdaDisponible.Text = "0.00"
        dgDetalle.Rows.Clear()

        celdaCta.Clear()
        celdaCtaNombre.Clear()
        celdaCuentaPadre.Clear()
        celdaNombreCuentaPadre.Clear()
        checkRecibos.Checked = False
        If (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 10) Then
            CuentaporArea(24)
        End If
    End Sub
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Dim recibos As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()

                Do While REA.Read
                    strFila = STR_VACIO
                    strFila = REA.GetInt32("ID") & "|"
                    strFila &= REA.GetString("Name") & "|"
                    strFila &= REA.GetString("NIT") & "|"
                    strFila &= REA.GetString("Abbreviation") & "|"
                    strFila &= REA.GetString("Adress") & "|"
                    strFila &= REA.GetString("Telephone")
                    recibos = REA.GetString("recibos")

                    If REA.GetInt32("Iva") = 0 Then
                        If recibos = "1" Then
                            AgregarFila(dgLista, strFila, INT_UNO, 1)
                        Else
                            AgregarFila(dgLista, strFila, INT_UNO, 0)
                        End If
                    ElseIf REA.GetInt32("Iva") = 1 Then
                        If recibos = "1" Then
                            AgregarFila(dgLista, strFila, INT_CERO, 1)
                        Else
                            AgregarFila(dgLista, strFila, INT_CERO, 0)
                        End If
                    ElseIf REA.GetString("estado") = "Baja" Then
                            cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                        Else
                            cFunciones.AgregarFila(dgLista, strFila)
                    End If

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal IVA As Integer, ByVal Recibos As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If IVA = INT_UNO Then
                    If i = 1 Then
                        Celda.Style.BackColor = Color.Yellow
                    End If
                End If

                If Recibos = INT_UNO Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.GreenYellow
                    End If
                End If
                'Pendiente de Certificado de Origen
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Proveedores")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill

            'Pone visible el boton de emite recibos
            If Sesion.idGiro = 1 Then
                checkRecibos.Visible = True
            Else
                checkRecibos.Visible = False
            End If

            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = ""
                BloquearBotones(False)
                'Pone visible el boton de emite recibos
                If Sesion.idGiro = 1 Then
                    checkRecibos.Visible = True
                Else
                    checkRecibos.Visible = False
                End If
                reset()
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                'Pone visible el boton de emite recibos
                If Sesion.idGiro = 1 Then
                    checkRecibos.Visible = True
                Else
                    checkRecibos.Visible = False
                End If

                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = False
        Dim PRO As New Tablas.TPROVEEDORES
        Dim cls As New clsContabilidad
        Dim intTipoNegocio As Integer = 0
        Dim strSQL2 As String = STR_VACIO
        Dim COM3 As MySqlCommand
        Try

            PRO.CONEXION = strConexion
            PRO.PRO_NOMBRE = If(celdaDesCorta.Text = vbNullString, "", Replace(celdaDesCorta.Text, "|", " "))
            PRO.PRO_DIRECCION = If(celdaDireccion.Text = vbNullString, "", Replace(celdaDireccion.Text, "|", " "))
            PRO.PRO_TELEFONO = celdaTelefono.Text
            PRO.PRO_SISEMP = Sesion.IdEmpresa
            PRO.PRO_MONTOCR = celdaLimiteCredito.Text
            PRO.PRO_PLAZOCR = celdaPlazoCredito.Text
            PRO.PRO_DSCTO = celdaDescuento.Text
            PRO.PRO_EXTERIOR = celdaRegimen.Text
            PRO.PRO_PAIS = celdaIDPais.Text
            PRO.PRO_SALDOCR = If(celdaDisponible.Text = STR_VACIO, 0, CDbl(celdaDisponible.Text))
            If rbotonSi.Checked = True Then
                PRO.PRO_FABRICANTE = "SI"
            ElseIf rbotonNo.Checked = True Then
                PRO.PRO_FABRICANTE = "No"
            End If
            If checkDerechoCreditoFiscal.Checked = True Then
                PRO.PRO_IVA = 0
            Else
                PRO.PRO_IVA = 1
            End If
            PRO.PRO_RAMO = celdaAreaNegocios.Text
            PRO.PRO_MONEDA = celdaIDMoneda.Text
            PRO.PRO_CMETHOD = celdaMetodoCosteo.Text
            PRO.PRO_STATUS = celdaEstado.Text
            PRO.PRO_PRODUCTO = celdaPredPro.Text
            PRO.PRO_INVENTARIO = "No"
            PRO.PRO_COMPRA = "No"
            PRO.PRO_CAJA = "No"
            PRO.PRO_CAI = INT_UNO

            'se guarda el valor del check para saber si el proveedor emite recibos, si es 1 si emite y 0 es que no
            If checkRecibos.Checked = True Then
                PRO.PRO_ANTICIPOS = 1
            Else
                PRO.PRO_ANTICIPOS = 0
            End If

            If rbServicio.Checked = True Then
                PRO.PRO_SERVICIO = 1
            ElseIf rbBien.Checked = True Then
                PRO.PRO_SERVICIO = 0
            End If
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then


                    PRO.PRO_CODIGO = sqlNuevoProveedor()

                    If ProveedorDuplicado(PRO.PRO_CODIGO, celdaRazonSocial.Text) <> vbNullString Then
                        MsgBox("A provider with that name already exists.")
                        Return False
                        Exit Function
                    End If
                    If (celdaNT.Text = "N/A") Or (celdaNT.Text = "n/a") Then
                        If MsgBox("A provider with that tax id already exists do you want to save?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        Else
                            Exit Function
                        End If
                    Else
                        If NitDuplicado(PRO.PRO_CODIGO, celdaNT.Text) <> vbNullString Then
                            MsgBox("A provider with that tax id already exists ")
                            Return False
                            Exit Function
                        End If
                    End If
                    PRO.PRO_PROVEEDOR = celdaRazonSocial.Text
                        PRO.PRO_NIT = celdaNT.Text
                    If celdaAreaNegocios.Text = "Textil" Then
                        intTipoNegocio = 0
                    ElseIf celdaAreaNegocios.Text = "Otros" Then
                        intTipoNegocio = 1
                    End If

                    If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 17) Then
                        If Not celdaCuentasxPagar.Text = vbNullString Then
                            If celdaCta.Text = vbNullString Then
                                MsgBox("Choose an account to associate", vbInformation, "Notice")
                                Return False
                                Exit Function
                            Else
                                strSQL2 = STR_VACIO
                                strSQL2 = " update {conta}.cuentas c 
                                            SET c.id_nomenclatura = '{id}'
                                            WHERE c.empresa = {emp} AND c.id_cuenta = '{cta}'"

                                strSQL2 = strSQL2.Replace("{emp}", Sesion.IdEmpresa)
                                strSQL2 = strSQL2.Replace("{cta}", celdaCuentasxPagar.Text)
                                strSQL2 = strSQL2.Replace("{id}", celdaCta.Text)
                                strSQL2 = strSQL2.Replace("{conta}", Sesion.BaseConta)

                                MyCnn.CONECTAR = strConexion
                                COM3 = New MySqlCommand(strSQL2, CON)
                                COM3.ExecuteNonQuery()
                            End If
                        End If
                    ElseIf (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 22) Then
                        If celdaCuentasxPagar.Text = vbNullString Then
                            If celdaCuentaPadre.Text = vbNullString Then
                                MsgBox("Choose account for creation in nomenclature", vbInformation, "Notice")
                                celdaCuentaPadre.Focus()
                                Return False
                                Exit Function
                            ElseIf celdaCta.Text = vbNullString Then
                                MsgBox("Choose an account to associate", vbInformation, "Notice")
                                celdaCuentasxPagar.Clear()
                                celdaCta.Focus()
                                Return False
                                Exit Function
                            Else
                                GuardarCuentaPadre(PRO.PRO_CODIGO)
                            End If
                        End If
                    ElseIf (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 10) Then
                        If celdaCuentasxPagar.Text = vbNullString Then
                            If celdaCuentaPadre.Text = vbNullString Then
                                MsgBox("Choose account for creation in nomenclature", vbInformation, "Notice")
                                celdaCuentaPadre.Focus()
                                Return False
                                Exit Function
                            ElseIf celdaCta.Text = vbNullString Then
                                MsgBox("Choose an account to associate", vbInformation, "Notice")
                                celdaCuentasxPagar.Clear()
                                celdaCta.Focus()
                                Return False
                                Exit Function
                            Else
                                GuardarCuentaPadre(PRO.PRO_CODIGO)
                            End If
                        End If
                    Else
                            If celdaCuentasxPagar.Text = vbNullString Then
                            celdaCuentasxPagar.Text = cls.CodigoConta("Proveedores", "Nuevo", padre:=intTipoNegocio)
                            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Then
                                If celdaCta.Text = vbNullString Then
                                    MsgBox("Choose an account to associate", vbInformation, "Notice")
                                    celdaCuentasxPagar.Clear()
                                    Return False
                                    Exit Function
                                End If
                            End If
                            cls.CodigoConta("Proveedores", "Guardar", Codigo:=celdaCuentasxPagar.Text, Nombre:=celdaRazonSocial.Text, NIT:=celdaNT.Text, ID:=PRO.PRO_CODIGO, padre:=intTipoNegocio, ctaNomenclatura:=celdaCta.Text)
                        End If
                    End If

                    PRO.PRO_CUENTA = celdaCuentasxPagar.Text '  PRO.PRO_CUENTA

                        cfun.EscribirRegistro("Proveedores", clsFunciones.AccEnum.acAdd, PRO.PRO_CODIGO, , , , celdaRazonSocial.Text & " / " & celdaNT.Text)
                        If PRO.PINSERT = False Then
                            MsgBox(PRO.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                        Else
                            logResultado = True
                        End If
                        GuardarContacto(celdaCodigo.Text)
                    Else
                        MsgBox(" You Doesn't have Permissions ")
                End If
            Else
                If logEditar = True Then
                    PRO.PRO_CODIGO = celdaCodigo.Text
                    If ProveedorDuplicado(celdaCodigo.Text, celdaRazonSocial.Text) <> vbNullString Then
                        MsgBox("there is already a provider with that description")
                        Exit Function
                    End If
                    If (celdaNT.Text = "N/A") Or (celdaNT.Text = "n/a") Then
                        If MsgBox("A provider with that tax id already exists do you want to save?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        Else
                            Exit Function
                        End If
                    Else
                        If NitDuplicado(celdaCodigo.Text, celdaNT.Text) <> vbNullString Then
                            MsgBox("There is already at least one provider with the tax id")
                            Exit Function
                        End If

                    End If
                    If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 17 Then
                        If Not celdaCuentasxPagar.Text = vbNullString Then
                            If celdaCta.Text = vbNullString Or celdaCta.Text = "N/A" Then
                                MsgBox("Choose an account to associate", vbInformation, "Notice")
                                Return False
                                Exit Function
                            Else
                                strSQL2 = STR_VACIO
                                strSQL2 = " update {conta}.cuentas c 
                                            SET c.id_nomenclatura = '{id}'
                                            WHERE c.empresa = {emp} AND c.id_cuenta = '{cta}'"

                                strSQL2 = strSQL2.Replace("{emp}", Sesion.IdEmpresa)
                                strSQL2 = strSQL2.Replace("{cta}", celdaCuentasxPagar.Text)
                                strSQL2 = strSQL2.Replace("{id}", celdaCta.Text)
                                strSQL2 = strSQL2.Replace("{conta}", Sesion.BaseConta)

                                MyCnn.CONECTAR = strConexion
                                COM3 = New MySqlCommand(strSQL2, CON)
                                COM3.ExecuteNonQuery()
                            End If
                        End If
                    Else
                        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 22 Then
                            If celdaCta.Text = vbNullString Or celdaCta.Text = "N/A" Then
                                MsgBox("Choose an account to associate", vbInformation, "Notice")
                                Return False
                                Exit Function
                            Else
                                strSQL2 = STR_VACIO
                                strSQL2 = " update {conta}.cuentas c 
                                            SET c.id_nomenclatura = '{id}'
                                            WHERE c.empresa = {emp} AND c.id_cuenta = '{cta}'"
                                If Sesion.IdEmpresa = 18 Then
                                    strSQL2 &= "; update contapdm.cuentas c 
                                            SET c.id_nomenclatura = '{id}'
                                            WHERE c.empresa = {emp} AND c.id_cuenta = '{cta}'"
                                End If

                                strSQL2 = strSQL2.Replace("{emp}", Sesion.IdEmpresa)
                                strSQL2 = strSQL2.Replace("{cta}", celdaCuentasxPagar.Text)
                                strSQL2 = strSQL2.Replace("{id}", celdaCta.Text)
                                strSQL2 = strSQL2.Replace("{conta}", Sesion.BaseConta)

                                MyCnn.CONECTAR = strConexion
                                COM3 = New MySqlCommand(strSQL2, CON)
                                COM3.ExecuteNonQuery()
                            End If
                        End If

                    End If
                    PRO.PRO_PROVEEDOR = celdaRazonSocial.Text
                        PRO.PRO_NIT = celdaNT.Text
                        PRO.PRO_CUENTA = celdaCuentasxPagar.Text '  PRO.PRO_CUENTA
                        cfun.EscribirRegistro("Proveedores", clsFunciones.AccEnum.acUpdate, celdaCodigo.Text, , , , celdaRazonSocial.Text & " / " & celdaNT.Text)
                        If PRO.PUPDATE = False Then
                            MsgBox(PRO.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                        Else
                            logResultado = True
                        End If
                        GuardarContacto(celdaCodigo.Text)
                    Else
                        MsgBox("Does Not have Permissions")
                End If

            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function GuardarContacto(ByVal Codigo As Integer) As Boolean
        Dim CN As New Tablas.TCONTACTOS
        Dim logResultado As Boolean = True

        CN.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                CN.CNT_SISEMP = Sesion.IdEmpresa
                CN.CNT_CODEMP = Codigo
                CN.CNT_TIPOEMP = "proveedores"
                CN.CNT_NOMBRE = CStr(dgDetalle.Rows(i).Cells("colNombre").Value)
                CN.CNT_PUESTO = CStr(dgDetalle.Rows(i).Cells("colPuesto").Value)
                CN.CNT_CELULAR = CStr(dgDetalle.Rows(i).Cells("colCelular").Value)
                CN.CNT_CORREO = CStr(dgDetalle.Rows(i).Cells("colCorreo").Value)
                CN.CNT_STATUS = CStr(dgDetalle.Rows(i).Cells("colEstado").Value)

                If dgDetalle.Rows(i).Cells("colStatus").Value = 0 Then
                    CN.CNT_CODIGO = sqlNuevoContacto()
                    If CN.PINSERT = False Then
                        MsgBox(CN.MERROR.ToString & "Could not save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logResultado = True
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colStatus").Value = 1 Then
                    CN.CNT_CODIGO = dgDetalle.Rows(i).Cells("colCodigo").Value
                    If CN.PUPDATE = False Then
                        MsgBox(CN.MERROR.ToString & "Could not modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logResultado = True
                    End If
                End If

                If dgDetalle.Rows(i).Cells("colStatus").Value = 2 Then
                    CN.CNT_CODIGO = dgDetalle.Rows(i).Cells("colCodigo").Value
                    If CN.PDELETE = False Then
                        MsgBox(CN.MERROR.ToString & "Could not delete this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logResultado = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function ProveedorDuplicado(ByVal Codigo As Integer, ByVal Proveedor As String) As Integer
        Dim strSQL As String
        Dim intProveedor As Integer
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " SELECT pro_codigo Codigo, pro_proveedor Nombre "
        strSQL &= " FROM Proveedores "
        strSQL &= " WHERE pro_sisemp = {empresa} AND NOT(pro_codigo={codigo}) AND UPPER( "
        strSQL &= " REPLACE( "
        strSQL &= " REPLACE( "
        strSQL &= " REPLACE(TRIM(pro_proveedor),' ',''),',',''),'.','')) = ""{proveedor}"""
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{proveedor}", Proveedor)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intProveedor = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return intProveedor
    End Function
    Private Function NitDuplicado(ByVal Codigo As Integer, ByVal Nit As String) As Integer
        Dim strSQL As String
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim intNit As Integer
        Try
            strSQL = "SELECT pro_codigo Codigo, pro_nit Nit, pro_proveedor Nombre "
            strSQL &= " FROM Proveedores "
            strSQL &= " WHERE pro_sisemp = {empresa} AND NOT(pro_codigo={codigo}) AND TRIM(pro_nit) =  '{nit}'"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", Codigo)
            strSQL = Replace(strSQL, "{nit}", Nit)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            intNit = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intNit
    End Function
    Private Function sqlEncabezado(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT  p.pro_codigo Codigo , p.pro_proveedor Proveedor ,IFNULL(p.pro_nombre,'') Nombre , IFNULL(p.pro_direccion,'') Direccion, IFNULL(p.pro_telefono,'') Telefono,
                    p.pro_nit Nit ,IFNULL(p.pro_montoCR,0) Limite , p.pro_plazoCR Plazo ,p.pro_cuenta Cuenta ,IFNULL(cu.nombre,'') nombre_cuenta,p.pro_producto Producto ,
                    IFNULL(cuen.nombre,'') nombre_producto,p.pro_servicio Servicio ,p.pro_status Estado, IFNULL(p.pro_dscto,0) Descuento , p.pro_fabricante Fabricante , p.pro_ramo AreaNegocio,
                    p.pro_exterior Regimen,p.pro_cmethod Metodo , p.pro_iva Iva, c.cat_desc Pais,c.cat_num Numero,cc.cat_clave Moneda,cc.cat_num numero,cc.cat_sist Cambio, IFNULL(n.idCuenta,'N/A') cta, IFNULL(n.NombreEspanol,'N/A') NCta, IFNULL(co.id_cuenta,'') CuentaPadre,IFNULL(co.nombre,'') NombrePadre, IFNULL(p.pro_anticipos,'') recibos"
        strSQL &= " FROM Proveedores p  "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = p.pro_pais "
        strSQL &= " LEFT JOIN Catalogos cc ON cc.cat_num = p.pro_moneda AND cc.cat_clase = 'Monedas' "
        strSQL &= " LEFT JOIN " & cfun.ContaEmpresa & ".cuentas cu ON cu.id_cuenta = p.pro_cuenta AND cu.empresa = p.pro_sisemp"
        strSQL &= " LEFT JOIN " & cfun.ContaEmpresa & ".cuentas cuen ON cuen.id_cuenta = p.pro_producto AND cuen.empresa = p.pro_sisemp "
        strSQL &= " LEFT JOIN " & cfun.ContaEmpresa & ".nomenclatura n ON n.idEmpresa = cu.empresa AND n.idCuenta = cu.id_nomenclatura "
        strSQL &= " LEFT JOIN " & cfun.ContaEmpresa & ".cuentas co ON co.id_cuenta = cu.pid AND co.empresa = p.pro_sisemp"
        strSQL &= " WHERE p.pro_sisemp = {empresa} AND p.pro_codigo = {codigo} "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        Return strSQL
    End Function
    Private Function sqlDetalle(ByVal Codigo As Integer) As String
        Dim strSQL As String
        Try

            strSQL = " SELECT cn.cnt_codigo Codigo , cn.cnt_nombre Nombre , cn.cnt_puesto Puesto , cn.cnt_correo Correo , cn.cnt_celular Celular , cn.cnt_status Estado "
            strSQL &= " FROM Proveedores p "
            strSQL &= " LEFT JOIN Contactos cn ON cn.cnt_sisemp = p.pro_sisemp AND cn.cnt_tipoemp='Proveedores' AND cn.cnt_codemp = p.pro_codigo "
            strSQL &= " WHERE cn.cnt_sisemp = {empresa}  AND p.pro_codigo = {codigo}   "
            strSQL &= " ORDER BY cnt_codigo; "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", Codigo)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function sqlCargoCuenta(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COALESCE(SUM(ECta_Crgo_Loc),0) Cargos, COALESCE(SUM(ECta_Abno_Loc),0) Abonos "
        strSQL &= " FROM ECtaCte "
        strSQL &= " WHERE ECta_tipoemp = 'Proveedores' AND ECta_codemp = {codigo} AND ECta_Sis_Emp = {empresa};"
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function
    Private Function sqlNuevoContacto() As Integer
        Dim strSQL As String
        Dim intContacto As Integer
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand

        strSQL = " SELECT IFNULL(MAX(cn.cnt_codigo),'')+ 1 Codigo "
        strSQL &= " FROM Contactos cn "
        strSQL &= " WHERE cn.cnt_sisemp = {empresa} AND cn.cnt_tipoemp = 'Proveedores' "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intContacto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return intContacto
    End Function
    Private Function sqlNuevoProveedor() As Integer
        Dim strSQL As String
        Dim intProveedor As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Try

            strSQL = " SELECT IFNULL(MAX(p.pro_codigo),0)+ 1 Codigo "
            strSQL &= " FROM Proveedores p "
            strSQL &= " WHERE p.pro_sisemp = {empresa} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            intProveedor = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intProveedor
    End Function
    Private Function sqlPaisSeleccionado() As Integer
        Dim strSQL As String = STR_VACIO
        Dim intPais As Integer
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Try

            strSQL = " SELECT c.cat_num ID"
            strSQL &= " FROM Empresas  e "
            strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = e.emp_pais  "
            strSQL &= " WHERE e.emp_no = {empresa}  AND c.cat_clase ='paises' "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            intPais = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intPais
    End Function
    Private Sub CargarSaldo(ByVal Codigo As Integer, ByVal Monto As Double, ByVal Cambio As Double)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            MyCnn.CONECTAR = strConexion
            strSQL = sqlCargoCuenta(Codigo)
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaSaldo.Text = Math.Round(REA.GetDouble("Cargos") - REA.GetDouble("Abonos") / Cambio, 2)
                    celdaDisponible.Text = Math.Round(Monto - (REA.GetDouble("Cargos") - REA.GetDouble("Abonos")) / (Cambio), 2)
                    gbPosiCuenta.Enabled = False
                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Seleccionar(ByVal Codigo As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblMonto As Double
        Dim dblCambio As Double
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = sqlEncabezado(Codigo)
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    celdaCodigo.Text = REA.GetInt32("Codigo")
                    celdaDesCorta.Text = REA.GetString("Nombre")
                    celdaRazonSocial.Text = REA.GetString("Proveedor")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaTelefono.Text = REA.GetString("Telefono")
                    celdaNT.Text = REA.GetString("Nit")
                    celdaRegimen.Text = REA.GetString("Regimen")
                    celdaPais.Text = REA.GetString("Pais")
                    celdaIDPais.Text = REA.GetInt32("Numero")
                    celdaEstado.Text = REA.GetString("Estado")
                    If REA.GetString("Estado") = "Activo" Then
                        celdaEstado.BackColor = Color.LimeGreen
                    Else
                        celdaEstado.BackColor = Color.Red
                    End If

                    celdaMetodoCosteo.Text = REA.GetString("Metodo")
                    If REA.GetString("Fabricante") = "Si" Then
                        rbotonSi.Checked = True
                    ElseIf REA.GetString("Fabricante") = "No" Then
                        rbotonNo.Checked = True
                    End If
                    celdaAreaNegocios.Text = REA.GetString("AreaNegocio")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaIDMoneda.Text = REA.GetInt32("numero")
                    If REA.GetInt32("Iva") = 1 Then
                        checkDerechoCreditoFiscal.Checked = False
                    ElseIf REA.GetInt32("Iva") = 0 Then
                        checkDerechoCreditoFiscal.Checked = True
                    End If
                    celdaDescuento.Text = REA.GetInt32("Descuento").ToString(FORMATO_MONEDA)
                    celdaPlazoCredito.Text = REA.GetInt32("Plazo")
                    celdaLimiteCredito.Text = REA.GetInt32("Limite").ToString(FORMATO_MONEDA)
                    celdaCuentasxPagar.Text = REA.GetString("Cuenta")
                    celdaCxPagar.Text = REA.GetString("nombre_cuenta")

                    celdaCta.Text = REA.GetString("cta")
                    celdaCtaNombre.Text = REA.GetString("NCta")
                    GbCuentaMiami.Enabled = True
                    celdaPredPro.Text = REA.GetString("Producto")
                    celdaPreProduct.Text = REA.GetString("nombre_producto")
                    If REA.GetInt32("Servicio") = 0 Then
                        rbBien.Checked = True
                    ElseIf REA.GetInt32("Servicio") = 1 Then
                        rbServicio.Checked = True
                    End If
                    dblMonto = REA.GetDouble("Limite")
                    dblCambio = REA.GetDouble("Cambio")
                    celdaCuentaPadre.Text = REA.GetString("CuentaPadre")
                    celdaNombreCuentaPadre.Text = REA.GetString("NombrePadre")

                    If REA.GetString("recibos") = "1" Then
                        checkRecibos.Checked = True
                    ElseIf REA.GetString("recibos") = " " Then
                        checkRecibos.Checked = False
                    End If
                Loop

            End If
            CargarSaldo(Codigo, dblMonto, dblCambio)
            SeleccionarContacto(Codigo)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub SeleccionarContacto(ByVal Codigo As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Try

            strSQL = sqlDetalle(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()

                Do While REA.Read
                    strFila = REA.GetString("Nombre") & "|"
                    strFila &= REA.GetString("Puesto") & "|"
                    strFila &= REA.GetString("Celular") & "|"
                    strFila &= REA.GetString("Correo") & "|"
                    strFila &= REA.GetString("Estado") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= "1"
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Validacion y metodos de borrar 
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*)"
        strSQL &= "     FROM Dcmtos_HDR h  "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat IN(127,44) AND h.HDoc_Emp_Cod = {num}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{num}", celdaCodigo.Text)
        Return strSQL
    End Function
    Private Sub BorrarProveedor2(ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "pro_sisemp = {empresa} AND pro_codigo = {numero}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim proveedor As New Tablas.TPROVEEDORES
            proveedor.CONEXION = strConexion
            proveedor.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Function BorrarProveedor(ByVal num As Integer) As Boolean
        BorrarProveedor = False
        Dim pro As New Tablas.TPROVEEDORES
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        'strCondicion = " pro_sisemp = {empresa}  AND pro_codigo = {numero}"
        'strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        'strCondicion = Replace(strCondicion, "{numero}", num)
        Try
            pro.CONEXION = strConexion
            pro.PRO_CODIGO = celdaCodigo.Text
            If pro.PDELETE(strCondicion) = True Then
                BorrarProveedor = True
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function
    Private Sub BorrarContacto(ByVal num As Integer)
        Dim CONTAC As New Tablas.TCONTACTOS
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = " cnt_sisemp = {empresa} AND cnt_codemp = {numero}  AND cnt_tipoemp = 'proveedores' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{numero}", num) 'cliente
        Try
            If CONTAC.PDELETE(strCondicion) = True Then 'CONTACTOS
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidacionCuentaPadre() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim cfun1 As New clsContabilidad
        Dim strValor As String = STR_VACIO
        Dim intValidacion As Integer = NO_FILA
        Try

            strSQL = " SELECT Count(*) Valor "
            strSQL &= "     FROM {conta}.cuentas c "
            strSQL &= "         WHERE c.empresa = {empresa} AND c.pid = '{pid}'"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
            strSQL = Replace(strSQL, "{pid}", celdaCuentaPadre.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    intValidacion = REA.GetInt32("Valor")
                Loop
            End If
            COM = Nothing
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    Private Function TraerCuentaPadre() As String
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim cfun1 As New clsContabilidad
        Dim strValor As String = STR_VACIO
        Dim intValidacion As Integer = NO_FILA
        Try

            strSQL = " SELECT c.id_cuenta Cuenta, c.nombre NombreCuenta , IFNULL(n.idCuenta,0) CuentaM, IFNULL(n.NombreEspanol,'') NombreEspanol "
            strSQL &= "     FROM {conta}.cuentas c "
            strSQL &= "             LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = c.empresa AND n.idCuenta = c.id_nomenclatura"
            strSQL &= "         WHERE c.empresa = {empresa} AND c.pid = '{pid}' order By c.id_cuenta DESC"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
            strSQL = Replace(strSQL, "{pid}", celdaCuentaPadre.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaCuentasxPagar.Text = REA.GetString("Cuenta")
                    celdaCxPagar.Text = REA.GetString("NombreCuenta")
                    celdaCta.Text = REA.GetString("CuentaM")
                    celdaCtaNombre.Text = REA.GetString("NombreEspanol")
                Loop
            End If
            COM = Nothing
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strValor
    End Function
    Public Sub LimpiarCuentas()
        celdaCuentasxPagar.Text = STR_VACIO
        celdaCxPagar.Text = STR_VACIO
        celdaCta.Text = STR_VACIO
        celdaCtaNombre.Text = STR_VACIO
    End Sub
    Private Sub GuardarCuentaPadre(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim cfun1 As New clsContabilidad
        Dim strValor As String = STR_VACIO
        Try
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 22 Then
                If celdaCuentasxPagar.Text = STR_VACIO Then
                    strSQL = " SELECT CAST(IFNULL(MAX(c.id_cuenta), CONCAT('{pid}','000')	)+1 AS CHAR) Valor "
                    strSQL &= "     FROM {conta}.cuentas c "
                    strSQL &= "         WHERE c.empresa = {empresa} AND c.pid = '{pid}'"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
                    strSQL = Replace(strSQL, "{pid}", celdaCuentaPadre.Text)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Do While REA.Read
                            If (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 11) Then
                                strValor = "0" & REA.GetString("Valor")
                            Else
                                strValor = REA.GetString("Valor")
                            End If

                        Loop
                    End If
                    celdaCuentasxPagar.Text = strValor
                    cfun1.GuardarCuenta("Nuevo", strValor, celdaRazonSocial.Text, "A", celdaCuentaPadre.Text, 3, celdaNT.Text, Codigo, celdaCta.Text)
                End If
            Else
                strSQL = " SELECT CAST(IFNULL(MAX(c.id_cuenta), CONCAT('{pid}','000')	)+1 AS CHAR) Valor "
                strSQL &= "     FROM {conta}.cuentas c "
                strSQL &= "         WHERE c.empresa = {empresa} AND c.pid = '{pid}'"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
                strSQL = Replace(strSQL, "{pid}", celdaCuentaPadre.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        If (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 11) Or (Sesion.IdEmpresa = 10) Or (Sesion.IdEmpresa = 9) Then
                            strValor = "0" & REA.GetString("Valor")
                        Else
                            strValor = REA.GetString("Valor")
                        End If

                    Loop
                End If
                celdaCuentasxPagar.Text = strValor
                cfun1.GuardarCuenta("Nuevo", strValor, celdaRazonSocial.Text, "A", celdaCuentaPadre.Text, 3, celdaNT.Text, Codigo, celdaCta.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CuentaporArea(ByVal intParametro As Integer)
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Try
            strSQL = " SELECT p.valor ,c.nombre "
            strSQL &= "     FROM {conta}.parametros_empresa p "
            strSQL &= "         LEFT JOIN {conta}.cuentas c ON c.id_cuenta = p.valor "
            strSQL &= "             WHERE p.empresa={empresa} AND p.parametro={parametro} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{parametro}", intParametro)
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaCuentaPadre.Text = REA.GetString("valor")
                    celdaNombreCuentaPadre.Text = REA.GetString("nombre")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region
#Region "Eventos"
    Private Sub frmProveedores_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub frmProveedores_load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub
    Private Sub encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim cls As New clsContabilidad
        MostrarLista(False, True)
        reset()
        Encabezado1.botonBorrar.Enabled = False
    End Sub
    Private Sub botonRegimen_Click(sender As Object, e As EventArgs) Handles botonRegimen.Click
        ' Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = "Regime"
            'frm.FiltroText = "Enter The Regime To Filter"
            'frm.Campos = "  DISTINCT (cli_exterior) Regime"
            'frm.Tabla = "Clientes"
            'frm.Filtro = " cli_exterior "
            'frm.Condicion = "cli_exterior >=0"
            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaRegimen.Text = frm.LLave
            '    '  celdaRegimen.Text = frm.Dato
            'End If
            frm.Mensaje = " Regime"
            frm.Opciones = "Local |" & "Exterior"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaRegimen.Text = "Local"
                    Case 1
                        celdaRegimen.Text = "Exterior"
                End Select
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num id,cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonPais_Click(sender As Object, e As EventArgs) Handles botonPais.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Country"
            frm.Campos = " cat_num id,cat_desc County"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter The Name Of The Country To Filter"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'paises' "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDPais.Text = frm.LLave
                celdaPais.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonCeldaNegocios_Click(sender As Object, e As EventArgs) Handles botonCeldaNegocios.Click
        '  Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = "Business Area"
            'frm.Campos = " DISTINCT(pro_ramo) Bussiness"
            'frm.Tabla = " Proveedores"
            'frm.FiltroText = " Enter The Business Area To Filter"
            'frm.Filtro = " pro_ramo"
            'frm.Condicion = "pro_ramo >=0 "

            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaAreaNegocios.Text = frm.LLave
            '    '  celdaAreaNegocios.Text = frm.Dato
            'End If
            frm.Mensaje = " Business Area"
            frm.Opciones = "Otros |" & "Textil"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaAreaNegocios.Text = "Otros"
                    Case 1
                        celdaAreaNegocios.Text = "Textil"
                End Select
            Else
                Exit Sub
            End If
            If (Sesion.IdEmpresa = 12) Or (Sesion.IdEmpresa = 14) Then
                If celdaAreaNegocios.Text = "Otros" Then
                    CuentaporArea(51)
                Else
                    CuentaporArea(24)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonMetodoCos_Click(sender As Object, e As EventArgs) Handles botonMetodoCos.Click
        '  Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = " Costing Method"
            'frm.Campos = "  DISTINCT(pro_cmethod) Method"
            'frm.Tabla = " Proveedores"
            'frm.FiltroText = " Enter The Costing Method For Filtering"
            'frm.Filtro = " pro_cmethod"
            'frm.Condicion = " pro_cmethod >=0"

            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaMetodoCosteo.Text = frm.LLave
            '    '   celdaMetodoCosteo.Text = frm.Dato
            'End If
            frm.Mensaje = " Costing Method"
            frm.Opciones = "LOCAL |" & "FOB |" & "CIF"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaMetodoCosteo.Text = "LOCAL"
                    Case 1
                        celdaMetodoCosteo.Text = "FOB"
                    Case 2
                        celdaMetodoCosteo.Text = "CIF"
                End Select
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonEstado_Click(sender As Object, e As EventArgs) Handles botonEstado.Click
        '  Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = "State"
            'frm.Campos = " DISTINCT(cli_status) State"
            'frm.Tabla = " Clientes"
            'frm.FiltroText = " Enter The State To Filter"
            'frm.Filtro = " cli_status "
            'frm.Condicion = "cli_status >= 0"

            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaEstado.Text = frm.LLave
            '    '  celdaEstado.Text = frm.Dato
            'End If
            frm.Mensaje = "State"
            frm.Opciones = "Activo |" & "Baja"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaEstado.Text = "Activo"
                    Case 1
                        celdaEstado.Text = "Baja"
                End Select
            Else
                Exit Sub
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonCxP_Click(sender As Object, e As EventArgs) Handles botonCxP.Click

        Dim frm As New frmSeleccionar
        Dim cfun As New clsFunciones
        Dim cls As New clsContabilidad
        Try
            frm.Titulo = " Debts To Pay"
            frm.FiltroText = " Enter The Name Of Account To Filter"
            frm.Campos = " id_cuenta, nombre"
            frm.Tabla = cfun.ContaEmpresa & ".cuentas "
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 22) Then
                frm.Condicion = "CHARACTER_LENGTH(id_cuenta) > 6"
            Else
                frm.Condicion = "id_cuenta >=0"
            End If
            frm.Limite = 20
            frm.Ordenamiento = " id_cuenta"
            frm.Filtro = "nombre"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If cls.UltimoNivle(frm.LLave) <> vbNullString Then
                    MsgBox("the selected account is a father account")
                Else
                    celdaCuentasxPagar.Text = frm.LLave
                    celdaCxPagar.Text = frm.Dato
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonProducPred_Click(sender As Object, e As EventArgs) Handles botonProducPred.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Dim cls As New clsContabilidad
        Try
            frm.Titulo = "Predetermined Product"
            frm.FiltroText = " Enter Product Name To Filter"
            frm.Campos = " id_cuenta, nombre"
            frm.Tabla = CFUN.ContaEmpresa & ".cuentas "
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 22) Then
                frm.Condicion = "CHARACTER_LENGTH(id_cuenta) > 6"
            Else
                frm.Condicion = "id_cuenta >=0"
            End If

            frm.Limite = 20
            frm.Ordenamiento = " id_cuenta"
            frm.Filtro = "nombre"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If cls.UltimoNivle(frm.LLave) <> vbNullString Then
                    MsgBox("the selected account is a father account")
                Else
                    celdaPredPro.Text = frm.LLave
                    celdaPreProduct.Text = frm.Dato
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub rbotonSi_CheckedChanged(sender As Object, e As EventArgs) Handles rbotonSi.CheckedChanged

        If rbotonSi.Checked = True Then
            'MessageBox.Show("Usted ha marcado Si")
        Else
            rbotonNo.Checked = False
            ' MessageBox.Show("Usted ha marcado No")
        End If
    End Sub
    Private Sub rbBien_CheckedChanged(sender As Object, e As EventArgs) Handles rbBien.CheckedChanged

        If rbBien.Checked = True Then
            'MessageBox.Show("Usted ha marcado Si")
        Else
            rbServicio.Checked = False
            ' MessageBox.Show("Usted ha marcado No")
        End If

    End Sub
    Private Sub checkDerechoCreditoFiscal_CheckedChanged(sender As Object, e As EventArgs) Handles checkDerechoCreditoFiscal.CheckedChanged

        If checkDerechoCreditoFiscal.Checked = True Then
        Else
            checkDerechoCreditoFiscal.Checked = False
        End If

    End Sub
    Private Sub botonNit_Click(sender As Object, e As EventArgs) Handles botonNit.Click
        Dim frm As New frmSeleccionar

        'Datospara mostrar en pantalla
        frm.Titulo = "Providers"
        frm.FiltroText = "Enter the NIT to Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "pro_codigo Code, pro_proveedor Provider, pro_nit NIT"
        frm.Tabla = "Proveedores"
        frm.Condicion = "pro_fabricante = 'Si' AND pro_sisemp=" & Sesion.IdEmpresa
        frm.Limite = 20
        frm.Ordenamiento = "pro_nit < 0"
        frm.Filtro = "pro_nit"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDNIT.Text = frm.LLave
            celdaRazonSocial.Text = frm.Dato
            celdaNT.Text = frm.Dato2

            SeleccionarNIT(frm.LLave)
        End If


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim CReportes As New clsReportes

        CReportes.ReporteCommercialInvoice()
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs)

        Dim CReportes As New clsReportes
        Dim ano As Integer
        Dim num As Integer

        CReportes.ReportePOJOB(ano, num)

    End Sub
    Private Sub botonUp_Click(sender As Object, e As EventArgs) Handles botonUp.Click
        Dim strFila As String
        Try
            strFila = "|"
            strFila &= "|"
            strFila &= "|"
            strFila &= "|"
            strFila &= "|"
            strFila &= "|"
            strFila &= "0"

            cFunciones.AgregarFila(dgDetalle, strFila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim frm As New frmOption
        Try
            If dgDetalle.Rows.Count = 0 Then
                Exit Sub
            Else
                Select Case dgDetalle.CurrentCell.ColumnIndex
                    Case 4
                        frm.Mensaje = " State"
                        frm.Opciones = "Activo |" & "Baja"
                        frm.ShowDialog(Me)
                        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                            Select Case frm.Seleccion
                                Case 0
                                    dgDetalle.CurrentRow.Cells("colEstado").Value = "Activo"
                                Case 1
                                    dgDetalle.CurrentRow.Cells("colEstado").Value = "Baja"
                            End Select
                        End If
                End Select
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAbajo_Click(sender As Object, e As EventArgs) Handles botonAbajo.Click
        Try
            Dim Count As Integer
            If dgDetalle.SelectedRows Is Nothing Then Exit Sub
            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CStr(dgDetalle.SelectedCells(0).Value) & ", " &
               CStr(dgDetalle.SelectedCells(1).Value) & " " &
                CStr(dgDetalle.SelectedCells(2).Value) & " " &
                   CStr(dgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgDetalle.SelectedCells(6).Value = 0 Or dgDetalle.SelectedCells(6).Value = 1 Then
                            dgDetalle.SelectedCells(6).Value = 2
                            If dgDetalle.SelectedCells(6).Value = 2 Then
                                dgDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can not delete the last row")
                Exit Sub
            End If
            dgDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Guardar() = True Then
            MostrarLista(True)
        End If

    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim Codigo As Integer = NO_FILA
        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Codigo = dgLista.SelectedCells(0).Value
            MostrarLista(False)
            BloquearBotones(False)
            Me.Tag = "mod"
            Seleccionar(Codigo)

            'Pone visible el boton de emite recibos
            If Sesion.idGiro = 1 Then
                checkRecibos.Visible = True
            Else
                checkRecibos.Visible = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(0, 0, 0, "Proveedores", dgLista.SelectedCells(0).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub frmProveedores_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim IntNumDocs As Integer

            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()
            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarProveedor(celdaCodigo.Text)
                    BorrarContacto(celdaCodigo.Text)
                    cfun.EscribirRegistro("Proveedores", clsFunciones.AccEnum.acDelete, celdaCodigo.Text, , , , celdaRazonSocial.Text & " / " & celdaNT.Text)
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub botonCta_Click(sender As Object, e As EventArgs) Handles botonCta.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "n.idEmpresa = {empresa} AND n.Pertenencia BETWEEN '2101' AND '2102' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Nomenclature"
            frm.Campos = " n.idCuenta Cuenta, n.NombreEspanol Nombre "
            frm.Tabla = cfun.ContaEmpresa & ".nomenclatura n "
            frm.FiltroText = " Enter the account to be filtered"
            frm.Filtro = " n.NombreEspanol "
            frm.Condicion = strCondicion
            frm.Ordenamiento = "n.idCuenta"
            frm.TipoOrdenamiento = " ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaCta.Text = frm.LLave
                celdaCtaNombre.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCuentaPadre_Click(sender As Object, e As EventArgs) Handles botonCuentaPadre.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        If Sesion.IdEmpresa = 22 Then
            strCondicion = "c.empresa = {empresa} AND (c.pid = '2101' and c.id_cuenta <= '210103') or (c.pid= '2102') "
        Else
            strCondicion = "c.empresa = {empresa} AND (c.pid = '2101' AND NOT c.id_cuenta >= '210104') OR (c.pid = '2102' AND NOT c.id_cuenta = '210202' AND NOT c.id_cuenta = '210205') "
        End If
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or Sesion.IdEmpresa = 22 Then
                frm.Titulo = "Nomenclature"
                frm.Campos = " c.id_cuenta Cuenta , c.nombre NombreCuenta"
                frm.Tabla = cfun.ContaEmpresa & ".cuentas c "
                frm.FiltroText = " Enter the account to be filtered"
                frm.Filtro = " c.nombre "
                frm.Condicion = strCondicion
                frm.Ordenamiento = "c.id_cuenta"
                frm.TipoOrdenamiento = " ASC"
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    celdaCuentaPadre.Text = frm.LLave
                    celdaNombreCuentaPadre.Text = frm.Dato
                End If
            End If
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 22 Then
                If ValidacionCuentaPadre() > INT_CERO Then
                    TraerCuentaPadre()
                    GbCuentaMiami.Enabled = False
                Else
                    LimpiarCuentas()
                    GbCuentaMiami.Enabled = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub panelDatosProvedor_Paint(sender As Object, e As PaintEventArgs) Handles panelDatosProvedor.Paint

    End Sub
#End Region

End Class