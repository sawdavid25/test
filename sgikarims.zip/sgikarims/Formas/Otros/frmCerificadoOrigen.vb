﻿Public Class frmCerificadoOrigen
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim CAT_CERTIFICADO As Integer = 0
    Dim selectedOption As Integer = 0

    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#Region "Funciones y Procedimientos Locales"
    Private Function SQLBuscar() As String
        Dim strSQL As String = STR_VACIO
        strSQL = "SELECT h.HDoc_Doc_Num ID, IF(h.HDoc_DR1_Dbl = 0, h.HDoc_Doc_Num,h.HDoc_Dr1_Dbl) correlativo, h.HDoc_Doc_Ano Ano, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Cliente, IF(h.HDoc_Pro_DCat = 36, h.HDoc_Pro_DNum,h.HDoc_RF3_Dbl) Factura, h.HDoc_Doc_Mon Linea, if(h.HDoc_Doc_Status = 1, 'Activo', 'Anulado') Estado, ifnull(a.HDoc_DR1_Dbl,0) HDoc_DR1_Dbl
                    FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_HDR a ON a.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND a.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND a.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND a.HDoc_Doc_Num = h.HDoc_Pro_DNum WHERE h.HDoc_Doc_Cat = 263 AND h.HDoc_Sis_Emp= " & Sesion.IdEmpresa
        If checkFechas.Checked = True Then
            strSQL &= " AND h.HDoc_Doc_Fec between '{INICIO}' AND '{FIN}'"
            strSQL = Replace(strSQL, "{INICIO}", dtpInicio.Value.ToString("yyyy-MM-dd"))
            strSQL = Replace(strSQL, "{FIN}", dtpFin.Value.ToString("yyyy-MM-dd"))
        End If
        If checkCliente.Checked = True Then
            strSQL &= " AND h.HDoc_Emp_Nom like '%{clientef}%'"
            strSQL = Replace(strSQL, "{clientef}", Trim(celdaClienteFlitro.Text))
        End If
        If CheckFactura.Checked = True Then
            strSQL &= " AND h.HDoc_Pro_DCat = 36 AND h.HDoc_Pro_DNum = {factura} "
            strSQL = Replace(strSQL, "{factura}", celdaFacturaFiltro.Text)
        End If
        strSQL &= " ORDER BY h.HDoc_Doc_Fec  DESC, h.HDoc_Doc_Num DESC"
        Return strSQL
    End Function

    Private Sub AsignarSerie()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT c.cat_num, c.cat_sist
                    FROM Catalogos c
                    WHERE c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_CertOrigen' AND c.cat_sist = 'A'"

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        REA.Read()

        celdaIDSerie.Text = REA.GetInt32("cat_num")
        celdaSerie.Text = REA.GetString("cat_sist")

    End Sub

    Public Sub CargarListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim fila As String

        Try
            strSQL = SQLBuscar()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            ListaCertificado.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    fila = REA.GetInt32("ID") & "|"
                    fila &= REA.GetInt32("correlativo") & "|"
                    fila &= REA.GetInt32("Ano") & "|"
                    fila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    fila &= REA.GetString("Cliente") & "|"
                    If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Or Sesion.idGiro = 2 Then
                        fila &= REA.GetInt32("HDoc_DR1_Dbl") & "|"
                    Else
                        fila &= REA.GetInt32("Factura") & "|"
                    End If
                    fila &= REA.GetInt32("Linea") & "|"
                    fila &= REA.GetString("Estado")

                    cFunciones.AgregarFila(ListaCertificado, fila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logInsert As Boolean = True)
        If logInsert = True Then
            panelPrincipal.Dock = DockStyle.None
            panelPrincipal.Visible = False
            ListaCertificado.Visible = True
            CargarListaPrincipal()
            'cFunciones.CargarLista(ListaCertificado, SQLBuscar)
            ListaCertificado.Dock = DockStyle.Fill
            panelBusqueda.Dock = DockStyle.Fill
            panelBusqueda.Visible = True
            CeldaTitulo.Text = "Certificados de Origen"
            ListaCertificado.Focus()

        Else
            ListaCertificado.Visible = False
            ListaCertificado.Dock = DockStyle.None
            panelPrincipal.Dock = DockStyle.Fill
            panelBusqueda.Dock = DockStyle.None
            panelBusqueda.Visible = False
            panelPrincipal.Visible = True
            botonSeleccionarCliente.Focus()
            If {15, 20, 18, 21}.Contains(Sesion.IdEmpresa) Then
                ' Si la condición se cumple, aseguramos que TabPage3 está presente
                If Not TabControl1.TabPages.Contains(TabPage3) Then
                    TabControl1.TabPages.Add(TabPage3) ' Añade la pestaña de nuevo
                End If
            Else
                ' Si no se cumple la condición, removemos TabPage3
                If TabControl1.TabPages.Contains(TabPage3) Then
                    TabControl1.TabPages.Remove(TabPage3) ' Elimina la pestaña
                End If
            End If
        End If
    End Sub

    Private Sub Reset(Optional ByVal strTodo As String = "Contenido")
        If strTodo = "Contenido" Then
            celdaOrigen.Text = STR_VACIO
            celdaArancel.Text = STR_VACIO
            celdaLote.Text = STR_VACIO
            celdaProducto.Text = STR_VACIO
            celdaBruto.Text = STR_CERO_MONEDA
            celdaNeto.Text = STR_CERO_MONEDA
            celdaProveedor.Text = STR_VACIO
            celdaProveedorDic.Text = STR_VACIO
            celdaReferencia.Text = STR_VACIO
            celdaCajas.Text = INT_CERO
            CeldaContenedor.Text = STR_VACIO
            celdaTransporte.Text = STR_VACIO
            celdaIDOrigen.Text = NO_FILA
            celdaIDProducto.Text = NO_FILA
            celdaIDProveedor.Text = NO_FILA
            celdaFirmante.Text = STR_VACIO
            CeldaPuesto.Text = STR_VACIO
            celdaCorreo.Text = STR_VACIO
            celdaDestino.Text = STR_VACIO
            celdaPO.Text = STR_VACIO
        ElseIf strTodo = "Titulo" Then
            celdaCliente.Text = STR_VACIO
            celdaIDCliente.Text = NO_FILA
            celdaAño.Text = NO_FILA
            celdaAñoFactrura.Text = NO_FILA
            celdaFactura.Text = NO_FILA
            celdaLinea.Text = NO_FILA
            celdaIdCertificado.Text = NO_FILA
        End If
        If Sesion.IdEmpresa = 16 Then
            etiquetaHBI.Visible = True
            celdaHBI.Visible = True
        End If
        celdaHBI.Text = STR_VACIO
        checkActivo.Checked = True
        checkActivo.Enabled = True
        celdaFactura.BackColor = Color.White
        'Serie
        celdaIDSerie.Text = INT_CERO
        celdaSerie.Text = STR_VACIO
        celdaCorrelativo.Text = NO_FILA

        celdaSaldoBruto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaSaldoNeto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaSaldoCajas.Text = INT_CERO.ToString(FORMATO_MONEDA)
        checkopc1.Checked = False
        checkopc2.Checked = False
        checkopc3.Checked = False
        dgDetalle.Rows.Clear()
    End Sub

    Private Function ComprobarCampos() As Boolean
        ComprobarCampos = True
        If cFunciones.ValidarCampoTexto(celdaCliente, 250) = False Then
            ComprobarCampos = False
        End If

        If cFunciones.ValidarCampoNumerico(celdaFactura) = False Then
            ComprobarCampos = False
        End If
        If celdaFactura.Text = -1 Then
            celdaFactura.BackColor = Color.Coral
            ComprobarCampos = False
        Else
            celdaFactura.BackColor = Color.White
        End If
        If cFunciones.ValidarCampoNumerico(celdaAñoFactrura) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaLinea) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaOrigen, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaLote, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaAñoFactrura, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaProducto, 250) = False Then
            ComprobarCampos = False
        End If
        'If cFunciones.ValidarCampoTexto(celdaArancel, 250) = False Then
        '    ComprobarCampos = False
        'End If
        If cFunciones.ValidarCampoTexto(CeldaContenedor, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaTransporte, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaProveedor, 250) = False Then
            ComprobarCampos = False
        End If
        'If cFunciones.ValidarCampoTexto(celdaProveedorDic, 250) = False Then
        '    ComprobarCampos = False
        'End If
        If cFunciones.ValidarCampoTexto(celdaReferencia, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaPO, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaFirmante, 250) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(CeldaPuesto, 250) = False Then
            ComprobarCampos = False
        End If

    End Function



    Private Sub Guardar()
        Dim cOrigen As New clsCertificadoOrigen
        Dim logInsert As Boolean = True
        Try
            BloquerarBotones()
            cOrigen.IdCliente = CInt(celdaIDCliente.Text)
            cOrigen.IdFactura = CInt(celdaFactura.Text)
            cOrigen.IdFirmante = CInt(celdaIdFirmante.Text)
            cOrigen.IdOrigen = CInt(celdaIDOrigen.Text)
            cOrigen.IdProducto = CInt(celdaIDProducto.Text)
            cOrigen.IdProveedor = CInt(celdaIDProveedor.Text)
            cOrigen.Origen = celdaOrigen.Text
            cOrigen.Lote = celdaLote.Text
            cOrigen.Invoice = celdaFact2.Text
            cOrigen.Producto = celdaProducto.Text
            cOrigen.Peso_Neto = CDbl(celdaNeto.Text)
            cOrigen.Peso_Bruto = CDbl(celdaBruto.Text)
            cOrigen.Cajas = CInt(celdaCajas.Text)
            cOrigen.Arancel = celdaArancel.Text
            cOrigen.Trasporte = celdaTransporte.Text
            cOrigen.Contenedor = CeldaContenedor.Text
            cOrigen.Proveedor = celdaProveedor.Text
            cOrigen.ProveedorDic = celdaProveedorDic.Text
            cOrigen.Referencia = celdaReferencia.Text
            cOrigen.PO = celdaPO.Text
            cOrigen.AñoFactrua = CInt(celdaAñoFactrura.Text)
            cOrigen.Linea = CInt(celdaLinea.Text)
            cOrigen.IdFirmante = CInt(celdaIdFirmante.Text)
            cOrigen.Firmante = celdaFirmante.Text
            cOrigen.Puesto = CeldaPuesto.Text
            cOrigen.Cliente = celdaCliente.Text
            cOrigen.Correo = celdaCorreo.Text
            cOrigen.Unidad_Medida = celdaMedida.Text
            cOrigen.FechaFactura_Net = DateTimePicker1.Value
            cOrigen.Destino = celdaDestino.Text
            cOrigen.HBI_PART = celdaHBI.Text
            ' Serie
            cOrigen.idSerieCert = celdaIDSerie.Text
            cOrigen.SerieCert = celdaSerie.Text
            cOrigen.intCorrelativoCert = celdaCorrelativo.Text
            cOrigen.Cat_Documento = CAT_CERTIFICADO

            If checkActivo.Checked = True Then
                cOrigen.Estado = 1
                cOrigen.Saldo_Neto = INT_CERO
                cOrigen.Saldo_Bruto = INT_CERO
            Else
                cOrigen.Estado = 0
                cOrigen.Saldo_Neto = CDbl(celdaSaldoNeto.Text)
                cOrigen.Saldo_Bruto = CDbl(celdaSaldoBruto.Text)
                cOrigen.Saldo_Caja = CDbl(celdaSaldoCajas.Text)
            End If
            If ComprobarCampos() = False Then
                MsgBox("Debe llenar todos los campos necesarios antes de guardar")
                BloquerarBotones(False)
                Exit Sub
            End If
            If Not Me.Tag = "nuevo" Then
                If logEditar = False Then
                    MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                    BloquerarBotones(False)
                    Exit Sub
                End If
                cOrigen.IdCertificado = CInt(celdaIdCertificado.Text)
                cOrigen.Año = CInt(celdaAño.Text)
                logInsert = False
            Else
                If logInsertar = False Then
                    MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                    BloquerarBotones(False)
                    Exit Sub
                End If
            End If
            If cOrigen.Guardar(logInsert) = False Then
                MsgBox("No se pudo guardar del documento", MsgBoxStyle.Critical)
                BloquerarBotones(False)
            Else
                celdaIdCertificado.Text = cOrigen.IdCertificado
                celdaAño.Text = cOrigen.Año
                MostrarLista()
                BloquerarBotones()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Seleccionar(ByVal intAño As Integer, ByVal intID As Integer)
        Dim cOrigen As New clsCertificadoOrigen
        If logConsultar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        Try
            cOrigen.Año = intAño
            cOrigen.IdCertificado = intID
            If cOrigen.Seleccionar = True Then
                Reset()
                Reset("Titulo")
                Me.Tag = "Mod"
                MostrarLista(False)

                CAT_CERTIFICADO = cOrigen.Cat_Documento
                celdaIDCliente.Text = cOrigen.IdCliente
                celdaFactura.Text = cOrigen.IdFactura
                celdaFact2.Text = cOrigen.Invoice
                celdaIdFirmante.Text = cOrigen.IdFirmante
                celdaIDOrigen.Text = cOrigen.IdOrigen
                celdaIDProducto.Text = cOrigen.IdProducto
                celdaIDProveedor.Text = cOrigen.IdProveedor
                celdaOrigen.Text = cOrigen.Origen
                celdaLote.Text = cOrigen.Lote
                celdaProducto.Text = cOrigen.Producto
                celdaNeto.Text = Format(cOrigen.Peso_Neto, FORMATO_MONEDA)
                celdaBruto.Text = Format(cOrigen.Peso_Bruto, FORMATO_MONEDA)
                celdaCajas.Text = cOrigen.Cajas
                celdaArancel.Text = cOrigen.Arancel
                celdaTransporte.Text = cOrigen.Trasporte
                CeldaContenedor.Text = cOrigen.Contenedor
                celdaProveedor.Text = cOrigen.Proveedor
                celdaProveedorDic.Text = cOrigen.ProveedorDic
                celdaReferencia.Text = cOrigen.Referencia
                celdaPO.Text = cOrigen.PO
                celdaAñoFactrura.Text = cOrigen.AñoFactrua
                celdaLinea.Text = cOrigen.Linea
                celdaIdCertificado.Text = cOrigen.IdCertificado
                celdaAño.Text = cOrigen.Año
                celdaFirmante.Text = cOrigen.Firmante
                CeldaPuesto.Text = cOrigen.Puesto
                celdaCorreo.Text = cOrigen.Correo
                celdaCliente.Text = cOrigen.Cliente
                celdaMedida.Text = cOrigen.Unidad_Medida
                celdaDestino.Text = cOrigen.Destino
                celdaHBI.Text = cOrigen.HBI_PART
                'Serie
                celdaCorrelativo.Text = IIf(cOrigen.intCorrelativoCert = 0, cOrigen.IdCertificado, cOrigen.intCorrelativoCert)
                celdaIDSerie.Text = cOrigen.idSerieCert
                celdaSerie.Text = cOrigen.SerieCert
                celdaSaldoBruto.Text = cOrigen.Saldo_Bruto
                celdaSaldoNeto.Text = cOrigen.Saldo_Neto
                celdaSaldoCajas.Text = cOrigen.Saldo_Caja
                If cOrigen.Estado = 1 Then
                    checkActivo.Checked = True
                    botonExportar.Visible = True
                    checkActivo.Enabled = True
                    gbAnulación.Enabled = False
                Else
                    checkActivo.Checked = False
                    botonExportar.Visible = False
                    checkActivo.Enabled = True
                End If
                'fibra
                If cOrigen.Intopcfibra1 = 1 Then
                    checkopc1.Checked = True
                ElseIf cOrigen.Intopcfibra1 = 2 Then
                    checkopc2.Checked = True
                ElseIf cOrigen.Intopcfibra1 = 3 Then
                    checkopc3.Checked = True
                End If


            End If
            cargarOrigen()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquerarBotones(Optional ByVal logBloquera As Boolean = True)
        If logBloquera = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonExportar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonExportar.Enabled = True
        End If
    End Sub
    Private Function ClaseProducto(ByVal Anio As Integer, ByVal num As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim intClase As Integer = NO_FILA
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Try
            strSQL = " SELECT a.art_clase Clase "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp And hh.HDoc_Doc_Cat = h.HDoc_Pro_DCat And hh.HDoc_Doc_Ano = h.HDoc_Pro_DAno And hh.HDoc_Doc_Num = h.HDoc_Pro_DNum "
            strSQL &= "             LEFT JOIN Inventarios i ON i.inv_sisemp = h.HDoc_Sis_Emp And i.inv_numero = h.HDoc_DR2_Cat "
            strSQL &= "                 LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo"
            strSQL &= "                     WHERE h.HDoc_Sis_Emp= {empresa} And h.HDoc_Doc_Cat= 263 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num ={num}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    intClase = REA.GetInt32("Clase")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intClase
    End Function


#End Region

    Private Sub frmCerificadoOrigen_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpInicio.Value = dtpInicio.Value.AddDays(-30)
        dtpFin.Value = Today
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    MostrarLista()
                    BloquerarBotones()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub frmCerificadoOrigen_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Try
            Fprincipal.BarraDeTareas1.QuitarFormulario(strkey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonExportar_Click(sender As Object, e As EventArgs) Handles botonExportar.Click
        Dim frmOp As New frmOption
        Dim cOrigen As New clsCertificadoOrigen
        Dim frm As New frmMensaje
        Dim strPath As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim cCat As New clsCatalogos
        Dim COM As MySqlCommand
        Dim strsql1 As String
        Dim paissv As Integer
        Dim intClase As Integer = NO_FILA
        Dim intMes1 As Integer
        Dim intMes2 As Integer
        Dim dtFec As Date

        Dim Sqlfibra As String = STR_VACIO
        Dim REA As MySqlDataReader

        Dim intopcfibra As Integer = NO_FILA
        Dim intidfibra As Integer = NO_FILA
        Dim strfibra As String = STR_VACIO
        Dim intPais As Integer = NO_FILA
        Dim strPais As String = STR_VACIO
        Dim intLinea As Integer = NO_FILA


        Dim contador As Integer = 0

        ' Variables para almacenar las 4 interacciones
        Dim fibra1 As String = String.Empty
        Dim pais1 As String = String.Empty

        Dim fibra2 As String = String.Empty
        Dim pais2 As String = String.Empty

        Dim fibra3 As String = String.Empty
        Dim pais3 As String = String.Empty

        Dim fibra4 As String = String.Empty
        Dim pais4 As String = String.Empty

        'VARIABLES PARA GUARDAR INFO DE CHECKBOX
        Dim hilo1 As String = ""
        Dim hilo2 As String = ""
        Dim hilo3 As String = ""


        If checkopc1.Checked Then
            hilo1 = "( X ) " & checkopc1.Text
            cOrigen.StrHilo11 = hilo1
        End If


        If checkopc2.Checked Then
            hilo2 = "( X ) " & checkopc2.Text
            cOrigen.StrHilo22 = hilo2
        End If

        If checkopc3.Checked Then
            hilo3 = "( X ) " & checkopc3.Text
            cOrigen.StrHilo33 = hilo3
        End If

        cOrigen.Año = CInt(celdaAño.Text)


        Try
            ' Fibra


            Sqlfibra = "SELECT c.cat_desc AS Fibra, c1.cat_desc Country, acc.ADoc_Dta_Num
                        FROM Dcmtos_ACC acc
                        LEFT JOIN Catalogos c ON c.cat_clase = 'ClaseArt' AND c.cat_sist = 'Art_Fibra' AND c.cat_num = acc.ADoc_Dta_Mny
                        LEFT JOIN Catalogos c1 ON c1.cat_clase = 'paises' AND c1.cat_num = acc.ADoc_Dta_Wht"
            Sqlfibra &= " WHERE acc.ADoc_Sis_Emp = {empresa} AND acc.ADoc_Doc_Cat = {certificado} AND acc.ADoc_Doc_Ano = {año} AND acc.ADoc_Doc_Num = {id};"


            Sqlfibra = Replace(Sqlfibra, "{empresa}", Sesion.IdEmpresa)
            Sqlfibra = Replace(Sqlfibra, "{certificado}", 263)
            Sqlfibra = Replace(Sqlfibra, "{año}", celdaAño.Text)
            Sqlfibra = Replace(Sqlfibra, "{id}", celdaIdCertificado.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Sqlfibra, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    intopcfibra = REA("ADoc_Dta_Num")
                    contador += 1

                    Select Case contador
                        Case 1
                            ' Asignar valores para la primera interacción
                            fibra1 = REA.GetString("Fibra")
                            pais1 = REA.GetString("Country")
                        Case 2
                            ' Asignar valores para la segunda interacción
                            fibra2 = REA.GetString("Fibra")
                            pais2 = REA.GetString("Country")
                        Case 3
                            ' Asignar valores para la tercera interacción
                            fibra3 = REA.GetString("Fibra")
                            pais3 = REA.GetString("Country")
                        Case 4
                            ' Asignar valores para la cuarta interacción
                            fibra4 = REA.GetString("Fibra")
                            pais4 = REA.GetString("Country")
                    End Select
                Loop
            End If

            REA.Close()
            REA = Nothing
            COM = Nothing




            intClase = ClaseProducto(celdaAño.Text, celdaIdCertificado.Text)
            MyCnn.CONECTAR = strConexion
            strsql1 = "Select emp_pais From Empresas Where emp_no = " & Sesion.IdEmpresa
            COM = New MySqlCommand(strsql1, CON)
            paissv = COM.ExecuteScalar
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then


                'VALIDAR CAMPO SELECCIONADO CLIENTE...
                If celdaCliente.Text = STR_VACIO Then
                    MsgBox("Select client please", vbCritical)
                    Exit Sub
                End If

                If celdaSerie.Text = STR_VACIO Then
                    MsgBox("Please select a certificate type", vbCritical)
                    Exit Sub
                End If

                If celdaSerie.Text = "B" Then
                    strPath = cFunciones.CopiarArchivo("certificadoAffidavit_" & Sesion.IdEmpresa & ".doc", "Certificado Origen Fibra Fact " & celdaFact2.Text & ".doc")
                ElseIf celdaSerie.Text = "A" Then
                    strPath = cFunciones.CopiarArchivo("certificado1_" & Sesion.IdEmpresa & ".doc", "Certificado Origen Hilo " & celdaFact2.Text & ".doc")
                End If

                'If intopcfibra = 1 Then
                '    strPath = cFunciones.CopiarArchivo("certificado1_" & Sesion.IdEmpresa & ".doc", "certificado1.doc")
                'ElseIf intopcfibra = 2 Then
                '    strPath = cFunciones.CopiarArchivo("certificado1_" & Sesion.IdEmpresa & ".doc", "certificado1.doc")
                'ElseIf intopcfibra = 3 Then
                '    strPath = cFunciones.CopiarArchivo("certificado1_" & Sesion.IdEmpresa & ".doc", "certificado1.doc")
                'End If

            Else
                    If paissv = 310 Or Sesion.IdEmpresa = 16 Then
                    strPath = cFunciones.CopiarArchivo("certificado0" & Sesion.IdEmpresa & "_SV.doc", "certificado1.doc")
                Else
                    If intClase = 416 Then
                        strPath = cFunciones.CopiarArchivo("certificado0" & Sesion.IdEmpresa & "T.doc", "certificado1.doc")
                    Else
                        strPath = cFunciones.CopiarArchivo("certificado0" & Sesion.IdEmpresa & ".doc", "certificado1.doc")
                    End If

                End If
            End If

            frm.Show()
            cOrigen.IdCertificado = CInt(celdaIdCertificado.Text)
            cOrigen.Año = CInt(celdaAño.Text)
            If cOrigen.Seleccionar = True Then
                cFunciones.LimpiarParametros()
                intMes1 = cOrigen.FechaFact.Month
                '   dtFec = DateAdd("d", 364, CDate(cOrigen.FechaFact))
                dtFec = DateAdd("yyyy", 1, CDate(cOrigen.FechaFact))
                dtFec = DateAdd("d", -1, dtFec)

                'cFunciones.AgregarParametro("",cOrigen. )

                intMes2 = dtFec.Month
                cFunciones.AgregarParametro("{numCert}", cOrigen.intCorrelativoCert)
                cFunciones.AgregarParametro("{firmante}", cOrigen.Firmante)
                cFunciones.AgregarParametro("{puesto}", cOrigen.Puesto)
                cFunciones.AgregarParametro("{cliente}", cOrigen.Cliente)
                cFunciones.AgregarParametro("{clienteDireccion}", cOrigen.ClienteDireccion)
                cFunciones.AgregarParametro("{año}", cOrigen.AñoFactrua)
                cFunciones.AgregarParametro("{origen}", cOrigen.Origen)
                cFunciones.AgregarParametro("{proveedor}", cOrigen.Proveedor)
                cFunciones.AgregarParametro("{desproveedor}", cOrigen.ProveedorDic)
                cFunciones.AgregarParametro("{lote}", cOrigen.Lote)
                cFunciones.AgregarParametro("{pof}", cOrigen.PO)
                'cFunciones.AgregarParametro("{invoice}", cOrigen.IdFactura)
                cFunciones.AgregarParametro("{invoice}", cOrigen.Invoice)
                cFunciones.AgregarParametro("{producto}", cOrigen.Producto)
                cFunciones.AgregarParametro("{hbi}", cOrigen.HBI_PART)

                cFunciones.AgregarParametro("{tarif}", cOrigen.Arancel)
                cFunciones.AgregarParametro("{cajas}", cOrigen.Cajas)
                If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                    cFunciones.AgregarParametro("{bruto}", (cOrigen.Peso_Neto.ToString(FORMATO_MONEDA) / 2.2046).ToString(FORMATO_MONEDA))
                Else
                    cFunciones.AgregarParametro("{bruto}", cOrigen.Peso_Neto.ToString(FORMATO_MONEDA))
                End If
                cFunciones.AgregarParametro("{neto}", cOrigen.Peso_Bruto.ToString(FORMATO_MONEDA))
                cFunciones.AgregarParametro("{contenedor}", cOrigen.Contenedor)
                cFunciones.AgregarParametro("{transporte}", cOrigen.Trasporte)
                cFunciones.AgregarParametro("{referencia}", cOrigen.Referencia)
                cFunciones.AgregarParametro("{fecha}", cOrigen.FechaFact)

                ' Fechas
                cFunciones.AgregarParametro("{mes1}", cFunciones.MesIngles(intMes1))
                cFunciones.AgregarParametro("{fec1}", cOrigen.FechaFact.Day & "-" & cOrigen.FechaFact.Year)
                cFunciones.AgregarParametro("{mes2}", cFunciones.MesIngles(intMes2))
                cFunciones.AgregarParametro("{fec2}", dtFec.Day & "-" & dtFec.Year)
                cFunciones.AgregarParametro("{fecTela}", cOrigen.FechaFact)
                cFunciones.AgregarParametro("{UM}", cOrigen.Unidad_Medida)

                cFunciones.AgregarParametro("{correo}", cOrigen.Correo)
                cFunciones.AgregarParametro("{m}", celdaMedida.Text)
                cFunciones.AgregarParametro("{destino}", celdaDestino.Text)
                cFunciones.AgregarParametro("{facthn}", cOrigen.FactHN)
                cFunciones.AgregarParametro("{factfel}", cOrigen.FactFel)
                cFunciones.AgregarParametro("{vendedor}", cOrigen.Vendedor)

                'INFORMACION DE CHECKBOX EN REPORTE
                cFunciones.AgregarParametro("{hilo1}", cOrigen.StrHilo11)
                cFunciones.AgregarParametro("{hilo2}", cOrigen.StrHilo22)
                cFunciones.AgregarParametro("{hilo3}", cOrigen.StrHilo33)

                cFunciones.AgregarParametro("{marcas}", cOrigen.marcasCadena)

                If Not String.IsNullOrEmpty(fibra1) Then
                    cFunciones.AgregarParametro("{fibra1}", fibra1)
                Else
                    fibra1 = ""
                    cFunciones.AgregarParametro("{fibra1}", fibra1)
                End If

                If Not String.IsNullOrEmpty(pais1) Then
                    cFunciones.AgregarParametro("{pais1}", pais1)
                Else
                    pais1 = ""
                    cFunciones.AgregarParametro("{pais1}", pais1)
                End If

                ' Para fibra2 y pais2
                If Not String.IsNullOrEmpty(fibra2) Then
                    cFunciones.AgregarParametro("{fibra2}", fibra2)
                Else
                    fibra2 = ""
                    cFunciones.AgregarParametro("{fibra2}", fibra2)
                End If

                If Not String.IsNullOrEmpty(pais2) Then
                    cFunciones.AgregarParametro("{pais2}", pais2)
                Else
                    pais2 = ""
                    cFunciones.AgregarParametro("{pais2}", pais2)
                End If

                ' Para fibra3 y pais3
                If Not String.IsNullOrEmpty(fibra3) Then
                    cFunciones.AgregarParametro("{fibra3}", fibra3)
                Else
                    fibra3 = ""
                    cFunciones.AgregarParametro("{fibra3}", fibra3)
                End If

                If Not String.IsNullOrEmpty(pais3) Then
                    cFunciones.AgregarParametro("{pais3}", pais3)
                Else
                    pais3 = ""
                    cFunciones.AgregarParametro("{pais3}", pais3)
                End If

                ' Para fibra4 y pais4
                If Not String.IsNullOrEmpty(fibra4) Then
                    cFunciones.AgregarParametro("{fibra4}", fibra4)
                Else
                    fibra4 = ""
                    cFunciones.AgregarParametro("{fibra4}", fibra4)
                End If

                If Not String.IsNullOrEmpty(pais4) Then
                    cFunciones.AgregarParametro("{pais4}", pais4)
                Else
                    pais4 = ""
                    cFunciones.AgregarParametro("{pais4}", pais4)
                End If

                If cOrigen.Telefono.ToUpper = "N/A" Then
                    cFunciones.AgregarParametro("{telefono}", "")
                Else
                    cFunciones.AgregarParametro("{telefono}", "TEL (502)" & cOrigen.Telefono)
                End If
                cFunciones.AgregarParametro("{fecha}", cOrigen.FechaFact)

                strSQL = STR_VACIO
                cCat.CONEXION = strConexion
                If cCat.Seleccionar("cat_num = " & cOrigen.IdOrigen, "cat_pid") = True Then
                    If cCat.CAT_PID = 564 Then
                        cFunciones.AgregarParametro("{cafta}", "")
                    Else
                        cFunciones.AgregarParametro("{cafta}", " For CAFTA USE")
                    End If
                End If
                strSQL = "Select cli_direccion FROM Clientes WHERE cli_codigo = {codigo} And cli_sisemp = " & Sesion.IdEmpresa
                strSQL = Replace(strSQL, "{codigo}", cOrigen.IdCliente)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                cFunciones.AgregarParametro("{diccliente}", COM.ExecuteScalar)
                cFunciones.WordBuscaryReemplazar(strPath)
            End If

            frm.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonSeleccionar_Click(sender As Object, e As EventArgs) Handles botonSeleccionar.Click
        Dim frmFact As New frmSeleccionar
        Dim frmLinea As New frmSeleccionar
        Dim cOrigen As New clsCertificadoOrigen
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        Dim frm As New frmOption

        'VALIDAR CAMPO SELECCIONADO CLIENTE...
        If celdaCliente.Text = STR_VACIO Then
            MsgBox("Select client please", vbCritical)
            Exit Sub
        End If

        frm.Titulo = "Tipo"
        frm.Mensaje = "Seleccione una Opción."
        frm.Opciones = "Factura|Saldo de Certificado"
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            If frm.Seleccion = 0 Then
                CAT_CERTIFICADO = 36
                celdaAñoFactrura.Text = 2000
                celdaFactura.Text = NO_FILA
                celdaLinea.Text = NO_FILA

                strCondicion = "h.HDoc_Sis_Emp = {sesion} And h.HDoc_Doc_Cat = 36 And h.HDoc_Emp_Cod = {cliente} And h.HDoc_Doc_Status = 1 And (ce.HDoc_Sis_Emp Is NULL Or(ce.HDoc_Sis_Emp = {sesion} And ce.HDoc_Doc_Cat = 263 And ce.HDoc_Doc_Status = 0)) "
                strCondicion = Replace(strCondicion, "{sesion}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{cliente}", celdaIDCliente.Text)

                strTabla = "Dcmtos_HDR h"
                strTabla &= " left join Dcmtos_DTL d On d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat"
                strTabla &= " And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strTabla &= " left join Dcmtos_HDR ce On ce.HDoc_Sis_Emp = d.DDoc_Sis_Emp  And ce.HDoc_Pro_DCat = d.DDoc_Doc_Cat And ce.HDoc_Doc_Status = 1 "

                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Or Sesion.idGiro = 2 Then
                    'MOSTRAR CAMPOS ID INTERNO DE FACTURA
                    frmFact.Campos = "h.HDoc_Doc_Ano Ano,h.HDoc_Doc_Num Numero,h.HDoc_Doc_Fec Fecha,h.HDoc_RF2_Dbl Total, h.HDoc_DR1_Dbl Fact"
                Else
                    frmFact.Campos = "h.HDoc_Doc_Ano Ano,h.HDoc_Doc_Num Numero,h.HDoc_Doc_Fec Fecha,h.HDoc_RF2_Dbl Total"
                End If

                If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 20 Then
                    'LEFT JOIN DE LINEA A LINEA POR CERTIFICADO ANULADO
                    strTabla &= " And ce.HDoc_Pro_DAno = d.DDoc_Doc_Ano And ce.HDoc_Pro_DNum = d.DDoc_Doc_Num And ce.HDoc_Doc_Cat = 263 "
                Else
                    strTabla &= " And ce.HDoc_Pro_DAno = d.DDoc_Doc_Ano And ce.HDoc_Pro_DNum = d.DDoc_Doc_Num  And ce.HDoc_Doc_Mon = d.DDoc_Doc_Lin  And ce.HDoc_Doc_Cat = 263 "
                End If

                frmFact.Agrupar = "  h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num "
                frmFact.Ordenamiento = "h.HDoc_Doc_Fec"
                frmFact.Tabla = strTabla

                frmFact.Condicion = strCondicion
                frmFact.Limite = 50
                frmFact.Filtro = "h.HDoc_Doc_Num"
                frmFact.Filtro2 = "h.HDoc_Dr1_Dbl"
                frmFact.Titulo = "Factura"
                frmFact.FiltroText = "Ingrese el número de factura para filtrar"
                If frmFact.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    celdaAñoFactrura.Text = frmFact.LLave
                    celdaFactura.Text = frmFact.Dato
                    If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Or Sesion.idGiro = 2 Then
                        celdaFact2.Text = frmFact.ListaClientes.SelectedCells(4).Value
                    Else
                        celdaFact2.Text = frmFact.Dato
                    End If


                    strTabla = STR_VACIO
                    strTabla = " Dcmtos_DTL d LEFT JOIN Catalogos m On DDoc_Prd_UM = cat_num "
                    strTabla &= " left join Dcmtos_HDR ce On ce.HDoc_Sis_Emp = d.DDoc_Sis_Emp And ce.HDoc_Doc_Cat = 263 And ce.HDoc_Pro_DCat =  d.DDoc_Doc_Cat "
                    strTabla &= " And ce.HDoc_Pro_DAno = d.DDoc_Doc_Ano And ce.HDoc_Pro_DNum = d.DDoc_Doc_Num And ce.HDoc_Doc_Mon = d.DDoc_Doc_Lin  "

                    strCondicion = STR_VACIO
                    strCondicion = "DDoc_Doc_Cat = 36 And DDoc_Doc_Ano ={año} And DDoc_Sis_Emp= {empresa} And DDoc_Doc_num = {numero} And (ce.HDoc_Sis_Emp Is NULL Or(ce.HDoc_Sis_Emp = {empresa} And ce.HDoc_Doc_Cat = 263 And ce.HDoc_Doc_Status = 0))"
                    strCondicion = Replace(strCondicion, "{año}", frmFact.LLave)
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{numero}", frmFact.Dato)
                    DateTimePicker1.Value = CDate(frmFact.Dato2)

                    frmLinea.Tabla = strTabla
                    frmLinea.Campos = "d.DDoc_Doc_Lin Linea, d.DDoc_Prd_Des Producto, m.cat_clave Unidad_de_medida, d.DDoc_Prd_QTY Cantidad"
                    frmLinea.Condicion = strCondicion
                    frmLinea.Limite = 15
                    frmLinea.Filtro = "DDoc_Prd_Des"
                    frmLinea.Agrupar = " d.DDoc_Sis_Emp,d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num,d.DDoc_Doc_Lin "
                    frmLinea.Titulo = " Línea de la factura"
                    frmLinea.FiltroText = "Ingrese la descripción del producto para filtrar"

                    'AGRUPAR LINEAS DE FACTURAS PARA CIERTAS EMPRESAS 15, 18, 20
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 20 Then
                        'If {15, 18, 20}.Contains(Sesion.IdEmpresa) Then
                        frmLinea.Campos = "MIN(d.DDoc_Doc_Lin) Linea, d.DDoc_Prd_Des Producto, m.cat_clave Unidad_de_medida, SUM(d.DDoc_Prd_QTY) Cantidad"
                        frmLinea.Agrupar = " d.DDoc_Prd_Des, m.cat_clave "
                    End If

                    ' Ingresa registro linea por linea de Factura

                    If frmLinea.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        celdaLinea.Text = frmLinea.LLave
                        cOrigen.AñoFactrua = celdaAñoFactrura.Text
                        cOrigen.IdFactura = celdaFactura.Text

                        'SE AGREGA VALIDACION PARA SUMATORIA.
                        If Sesion.idGiro = 2 Then
                            cOrigen.Linea = "dt.DDoc_Doc_Lin"
                        Else
                            cOrigen.Linea = frmLinea.LLave
                        End If

                        cOrigen.IdCliente = celdaIDCliente.Text

                        If cOrigen.SeleccionarNuevo = True Then
                            celdaMedida.Text = frmLinea.Dato2
                            celdaOrigen.Text = cOrigen.Origen
                            celdaArancel.Text = cOrigen.Arancel
                            celdaLote.Text = cOrigen.Lote
                            celdaProducto.Text = cOrigen.Producto
                            celdaBruto.Text = Format(cOrigen.Peso_Bruto, FORMATO_MONEDA)
                            celdaNeto.Text = Format(cOrigen.Peso_Neto, FORMATO_MONEDA)
                            celdaProveedor.Text = cOrigen.Proveedor
                            celdaProveedorDic.Text = cOrigen.ProveedorDic
                            celdaReferencia.Text = cOrigen.Referencia
                            'celdaReferencia.Text = frmFact.Dato4
                            celdaCajas.Text = cOrigen.Cajas
                            CeldaContenedor.Text = cOrigen.Contenedor
                            celdaTransporte.Text = cOrigen.Trasporte
                            celdaIDOrigen.Text = cOrigen.IdOrigen
                            celdaIDProducto.Text = cOrigen.IdProducto
                            celdaIDProveedor.Text = cOrigen.IdProveedor
                            celdaPO.Text = cOrigen.PO
                            celdaDestino.Text = cOrigen.Destino
                            celdaHBI.Text = cOrigen.HBI_PART
                            botonSelFirmante.Focus()
                        End If
                    End If
                End If
            Else 'Saldo de Certificado

                strTabla = " Dcmtos_HDR h "
                strTabla &= " Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strTabla &= " LEFT JOIN Dcmtos_HDR ce ON ce.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND ce.HDoc_Pro_DCat = d.DDoc_Doc_Cat AND ce.HDoc_Doc_Status = 1 AND ce.HDoc_Pro_DAno = d.DDoc_Doc_Ano AND ce.HDoc_Pro_DNum = d.DDoc_Doc_Num AND ce.HDoc_Doc_Mon = d.DDoc_Doc_Lin AND ce.HDoc_Doc_Cat = 263 "

                strCondicion = " h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 263 AND h.HDoc_Emp_Cod = {id} AND h.HDoc_Doc_Status = 0 AND (d.DDoc_Prd_Fob > 0 OR d.DDoc_Prd_Cif>0) 
                                     AND (ce.HDoc_Sis_Emp IS NULL OR(ce.HDoc_Sis_Emp = {empresa} AND ce.HDoc_Doc_Cat = 263 AND ce.HDoc_Doc_Status = 0))"
                strCondicion = Replace(strCondicion, "{id}", celdaIDCliente.Text)
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                If Sesion.IdEmpresa = 16 Then
                    frmFact.Campos = "h.HDoc_Doc_Ano Anio, IF(h.HDoc_DR1_Dbl = 0, h.HDoc_Doc_Num, h.HDoc_DR1_Dbl) Numero,h.HDoc_Doc_Fec Fecha,d.DDoc_Prd_Cif Saldo,  h.HDoc_Doc_Num id, h.HDoc_Dr1_Dbl Fact  "
                Else
                    frmFact.Campos = "h.HDoc_Doc_Ano Anio, IF(h.HDoc_DR1_Dbl = 0, h.HDoc_Doc_Num, h.HDoc_DR1_Dbl) Numero,h.HDoc_Doc_Fec Fecha,d.DDoc_Prd_Cif Saldo,  h.HDoc_Doc_Num id "
                End If
                frmFact.Tabla = strTabla
                frmFact.Condicion = strCondicion
                frmFact.Titulo = "Certificados"
                frmFact.Filtro = "h.HDoc_Doc_Num"
                If frmFact.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    celdaAñoFactrura.Text = frmFact.LLave
                    celdaFactura.Text = frmFact.Dato4
                    celdaFact2.Text = frmFact.Dato4
                    celdaLinea.Text = 2
                    cOrigen.Linea = celdaLinea.Text
                    cOrigen.AñoFactrua = celdaAñoFactrura.Text
                    cOrigen.IdFactura = celdaFactura.Text
                    DateTimePicker1.Value = CDate(frmFact.Dato2)

                    If cOrigen.SeleccionarNuevo(1) = True Then
                        celdaMedida.Text = cOrigen.Unidad_Medida
                        celdaOrigen.Text = cOrigen.Origen
                        celdaArancel.Text = cOrigen.Arancel
                        celdaLote.Text = cOrigen.Lote
                        celdaProducto.Text = cOrigen.Producto
                        celdaBruto.Text = Format(cOrigen.Peso_Bruto, FORMATO_MONEDA)
                        celdaNeto.Text = Format(cOrigen.Peso_Neto, FORMATO_MONEDA)
                        celdaProveedor.Text = cOrigen.Proveedor
                        celdaProveedorDic.Text = cOrigen.ProveedorDic
                        celdaReferencia.Text = cOrigen.Referencia
                        celdaCajas.Text = cOrigen.Cajas
                        CeldaContenedor.Text = cOrigen.Contenedor
                        celdaTransporte.Text = cOrigen.Trasporte
                        celdaIDOrigen.Text = cOrigen.IdOrigen
                        celdaIDProducto.Text = cOrigen.IdProducto
                        celdaIDProveedor.Text = cOrigen.IdProveedor
                        celdaPO.Text = cOrigen.PO
                        celdaDestino.Text = cOrigen.Destino
                        botonSelFirmante.Focus()
                    End If
                    CAT_CERTIFICADO = 263
                End If
            End If

        End If

    End Sub
    Private Sub cargarOrigen()

        Dim Sqlfibra As String = STR_VACIO
        Dim intClase As Integer = NO_FILA
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        Dim intopcfibra As Integer = NO_FILA
        Dim intidfibra As Integer = NO_FILA
        Dim strfibra As String = STR_VACIO
        Dim intPais As Integer = NO_FILA
        Dim strPais As String = STR_VACIO
        Dim intLinea As Integer = NO_FILA
        Try
            ' Fibra

            Sqlfibra = "SELECT c.cat_num id_fibra ,c.cat_desc AS Fibra,c1.cat_num CODE, c1.cat_desc Country, acc.ADoc_Dta_Num , acc.ADoc_Doc_Lin Lin
                        FROM Dcmtos_ACC acc
                        LEFT JOIN Catalogos c ON c.cat_clase = 'ClaseArt' AND c.cat_sist = 'Art_Fibra' AND c.cat_num = acc.ADoc_Dta_Mny
                        LEFT JOIN Catalogos c1 ON c1.cat_clase = 'paises' AND c1.cat_num = acc.ADoc_Dta_Wht"
            Sqlfibra &= " WHERE acc.ADoc_Sis_Emp = {empresa} AND acc.ADoc_Doc_Cat = {certificado} AND acc.ADoc_Doc_Ano = {año} AND acc.ADoc_Doc_Num = {id};"


            Sqlfibra = Replace(Sqlfibra, "{empresa}", Sesion.IdEmpresa)
            Sqlfibra = Replace(Sqlfibra, "{certificado}", 263)
            Sqlfibra = Replace(Sqlfibra, "{año}", celdaAño.Text)
            Sqlfibra = Replace(Sqlfibra, "{id}", celdaIdCertificado.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(Sqlfibra, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    intopcfibra = REA("ADoc_Dta_Num")
                    intidfibra = REA.GetInt32("id_fibra")
                    strfibra = REA.GetString("Fibra")
                    intPais = REA.GetInt32("CODE")
                    strPais = REA.GetString("Country")
                    intLinea = REA.GetInt32("Lin")
                    cFunciones.AgregarFila(dgDetalle, intidfibra & "|" & strfibra & "|" & intPais & "|" & strPais & "|" & 0 & "|" & intLinea)
                    'dgDetalle.Rows.Add(cOrigen.Intidfibra1, cOrigen.Strfibra1, cOrigen.IdOrigen, cOrigen.Origen)
                Loop
            End If
            REA.Close()
            REA = Nothing
            COM = Nothing
            If intopcfibra = 1 Then
                checkopc1.Checked = True
                checkopc2.Checked = False
                checkopc3.Checked = False
            ElseIf intopcfibra = 2 Then
                checkopc1.Checked = False
                checkopc2.Checked = True
                checkopc3.Checked = False
            ElseIf intopcfibra = 3 Then
                checkopc1.Checked = False
                checkopc2.Checked = False
                checkopc3.Checked = True
            Else
                checkopc1.Checked = False
                checkopc2.Checked = False
                checkopc3.Checked = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonSeleccionarCliente_Click(sender As Object, e As EventArgs) Handles botonSeleccionarCliente.Click
        Dim strCondicion As String = STR_VACIO
        Dim frm As New frmSeleccionar

        strCondicion = "cli_sisemp= " & Sesion.IdEmpresa
        frm.Tabla = "Clientes"
        frm.Campos = "cli_codigo Código, cli_cliente Nombre_Cliente"
        frm.Condicion = strCondicion
        frm.Limite = 50
        frm.Filtro = "cli_cliente"
        frm.Titulo = "Cliente"
        frm.FiltroText = "Ingrese el nombre del cliente para filtrar"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            celdaIDCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
            Reset()
            botonSeleccionar.Focus()
            AsignarSerie()
        End If
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim cOrigen As New clsCertificadoOrigen
        If LogBorrar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        Try
            cOrigen.IdCertificado = CInt(celdaIdCertificado.Text)
            cOrigen.Año = CInt(celdaAño.Text)
            If cOrigen.Borrar() = False Then
                MsgBox("No se pudo borrar el registro.")
            Else
                MostrarLista()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If ListaCertificado.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
            BloquerarBotones()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarCampos() = True Then
            Guardar()
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                GuardarDetalleFibra()
            End If
        Else
            MsgBox("Debe llenar todos los campos antes de guardar")
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Reset()
        Reset("Titulo")
        MostrarLista(False)
        CeldaTitulo.Text = "Nuevo registro"
        BloquerarBotones(False)
        Me.Tag = "nuevo"
    End Sub

    Private Sub ListaCertificado_DoubleClick(sender As Object, e As EventArgs) Handles ListaCertificado.DoubleClick
        Me.Tag = "Mod"
        Dim intAño As Integer
        Dim intId As Integer
        If ListaCertificado.SelectedRows.Count = 0 Then Exit Sub
        intId = CInt(ListaCertificado.SelectedCells(0).Value)
        intAño = CInt(ListaCertificado.SelectedCells(2).Value)
        Seleccionar(intAño, intId)
        CeldaTitulo.Text = "Modificar registro"
        BloquerarBotones(False)
    End Sub

    Private Sub botonSelFirmante_Click(sender As Object, e As EventArgs) Handles botonSelFirmante.Click
        Dim strCondicion As String = STR_VACIO
        Dim frm As New frmSeleccionar

        strCondicion = "per_estado = 1 And per_sisemp= " & Sesion.IdEmpresa
        frm.Tabla = "Personal LEFT JOIN Puestos On  per_puesto = pue_codigo And pue_sisemp= per_sisemp"
        frm.Campos = "per_codigo Código, CONCAT(per_nombre1,' ',per_apellido1) Nombre, pue_descripcion Puesto, per_correo Correo "
        frm.Condicion = strCondicion
        frm.Limite = 20
        frm.Filtro = "per_apellido1"
        frm.Ordenamiento = " per_apellido1 "
        frm.Titulo = "Firmante"
        frm.FiltroText = "Ingrese el Apellido para filtrar"
        frm.TipoOrdenamiento = STR_VACIO
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            celdaIdFirmante.Text = frm.LLave
            celdaFirmante.Text = frm.Dato
            CeldaPuesto.Text = frm.Dato2
            celdaCorreo.Text = frm.Dato3

        End If
    End Sub

    Private Sub ListaCertificado_KeyDown(sender As Object, e As KeyEventArgs) Handles ListaCertificado.KeyDown
        Dim cfun As New clsFunciones
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(ListaCertificado)
                e.Handled = True
                e.SuppressKeyPress = True
                'ElseIf e.KeyCode = Keys.F7 Then
                '    Dim rpt As New clsReportes
                '    rpt.Historial(ListaCertificado.SelectedCells(1).Value, ListaCertificado.SelectedCells(0).Value, 263,)
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(263, ListaCertificado.SelectedCells(2).Value, ListaCertificado.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(ListaCertificado.SelectedCells(0).Value, ListaCertificado.SelectedCells(2).Value, 263)
            ElseIf e.KeyCode = Keys.Enter Then
                Me.Tag = "mod"
                Dim intAño As Integer
                Dim intId As Integer
                If ListaCertificado.SelectedRows.Count = 0 Then Exit Sub
                intId = CInt(ListaCertificado.SelectedCells(0).Value)
                intAño = CInt(ListaCertificado.SelectedCells(2).Value)
                Seleccionar(intAño, intId)
                BloquerarBotones(False)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        'cFunciones.CargarLista(ListaCertificado, SQLBuscar)
        CargarListaPrincipal()
    End Sub

    Private Sub celdaFacturaFiltro_LostFocus(sender As Object, e As EventArgs) Handles celdaFacturaFiltro.LostFocus
        If Not IsNumeric(celdaFacturaFiltro.Text) Then
            celdaFacturaFiltro.Text = 0
            MsgBox("Debe ingresar un valor numerico en el campo factura")
        End If
    End Sub

    Private Sub botonSerie_Click(sender As Object, e As EventArgs) Handles botonSerie.Click
        Dim frm As New frmSeleccionar
        frm.Titulo = "Tipo de Certificado"
        frm.Campos = " c.cat_num, c.cat_desc, c.cat_sist "
        frm.Tabla = " Catalogos c"
        frm.Condicion = "c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_CertOrigen' "

        frm.TipoOrdenamiento = STR_VACIO
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            celdaIDSerie.Text = frm.LLave
            celdaSerie.Text = frm.Dato2
        End If
    End Sub

    Private Sub checkActivo_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivo.CheckedChanged
        If checkActivo.Checked = False Then
            gbAnulación.Enabled = True
            'celdaSaldoNeto.Text = INT_CERO.ToString(FORMATO_MONEDA)
            'celdaSaldoBruto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        Else
            gbAnulación.Enabled = False
        End If
    End Sub

    Private Sub botonAdd_Click(sender As Object, e As EventArgs) Handles botonAdd.Click
        Dim strSQL As String = STR_VACIO

        strSQL = "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= 1

        dgDetalle.DefaultCellStyle.BackColor = Color.Beige
        cFunciones.AgregarFila(dgDetalle, strSQL)
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim frm As New frmSeleccionar

        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 1
                    frm.Titulo = "FIBRA"
                    frm.FiltroText = " Enter The fiber To Filter"
                    frm.Campos = "c.cat_num,c.cat_desc AS Fibra"
                    frm.Tabla = " Catalogos c"
                    frm.Filtro = " c.cat_desc "
                    frm.Condicion = "cat_clase = 'ClaseArt' AND cat_sist = 'Art_Fibra'"
                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells(0).Value = frm.LLave
                        dgDetalle.CurrentRow.Cells(1).Value = frm.Dato

                    End If
                    dgDetalle.CurrentRow.ReadOnly = False
                Case 3
                    frm.Titulo = "Country"
                    frm.Campos = " cat_num Code, cat_desc Country"
                    frm.Tabla = " Catalogos"
                    frm.FiltroText = " Ingrese el nombre del país para filtrar"
                    frm.Filtro = " cat_desc "
                    frm.Condicion = "cat_clase = 'paises'"
                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells(2).Value = frm.LLave
                        dgDetalle.CurrentRow.Cells(3).Value = frm.Dato

                    End If
                    dgDetalle.CurrentRow.ReadOnly = False
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonDelete_Click(sender As Object, e As EventArgs) Handles botonDelete.Click
        If dgDetalle.Rows.Count < 1 Then Exit Sub
        Try
            'Dim strFila As String
            If dgDetalle.CurrentRow.Cells(4).Value = 1 Then
                dgDetalle.CurrentRow.Cells(4).Value = 2
                dgDetalle.CurrentRow.Visible = False
            Else
                dgDetalle.CurrentRow.Cells(4).Value = 0
                dgDetalle.CurrentRow.Cells(4).Value = 2
                dgDetalle.CurrentRow.Visible = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



    Private Sub checkopc1_CheckedChanged(sender As Object, e As EventArgs) Handles checkopc1.CheckedChanged
        If checkopc1.Checked Then
            checkopc2.Checked = False
            checkopc3.Checked = False
            selectedOption = 1 ' Se seleccionó la opción 1
        End If
    End Sub

    Private Sub checkopc2_CheckedChanged(sender As Object, e As EventArgs) Handles checkopc2.CheckedChanged
        If checkopc2.Checked Then
            checkopc1.Checked = False
            checkopc3.Checked = False
            selectedOption = 2 ' Se seleccionó la opción 2
        End If
    End Sub

    Private Sub checkopc3_CheckedChanged(sender As Object, e As EventArgs) Handles checkopc3.CheckedChanged
        If checkopc3.Checked Then
            checkopc1.Checked = False
            checkopc2.Checked = False
            selectedOption = 3 ' Se seleccionó la opción 3
        End If
    End Sub

    Private Sub ControlarVisibilidadTabPage()
        ' Verifica una condición y muestra u oculta el TabPage3
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            TabControl1.TabPages("TabPage3").Visible = True  ' Hace visible TabPage3
        Else
            TabControl1.TabPages("TabPage3").Visible = False ' Hace invisible TabPage3
        End If
    End Sub

    Private Function GuardarDetalleFibra() As Boolean
        Dim logResultado As Boolean = True
        Dim Tacc As New Tablas.TDCMTOS_ACC

        Dim i As Integer = INT_CERO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                If (dgDetalle.Rows(i).Cells("colidfibra").Value = vbNullString) And i = dgDetalle.Rows.Count - 1 Then
                    Exit For
                End If

                Tacc.CONEXION = strConexion

                Tacc.ADOC_SIS_EMP = Sesion.IdEmpresa
                Tacc.ADOC_DOC_CAT = 263
                Tacc.ADOC_DOC_ANO = CInt(celdaAño.Text)
                Tacc.ADOC_DOC_NUM = CInt(celdaIdCertificado.Text)
                Tacc.ADOC_DOC_SUB = "Doc_FibDatos"
                Tacc.ADOC_DTA_DES = "Datos Fibra Cert Origen"
                Tacc.ADOC_DTA_MNY = dgDetalle.Rows(i).Cells("colidfibra").Value
                Tacc.ADOC_DTA_WHT = dgDetalle.Rows(i).Cells("colidorigen").Value
                Tacc.ADOC_DTA_NUM = selectedOption


                If Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    Tacc.ADOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea1").Value
                    If Tacc.PUPDATE = False Then
                        MsgBox(Tacc.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                    Tacc.ADOC_DOC_LIN = i + 1
                    If Tacc.PINSERT = False Then
                        MsgBox(Tacc.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    Tacc.ADOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea1").Value
                    If Tacc.PDELETE = False Then
                        MsgBox(Tacc.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function


End Class

