﻿Public Class frmReclamos

    Dim logEditar As Boolean = False
    Dim cfun As New clsFunciones
    Dim codigocustomer As Integer
    Dim cOrigenes As New clsClaimRegister

    Dim strKey As String

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Private Sub BarraTitulo1_Load(sender As Object, e As EventArgs) Handles BarraTitulo1.Load
        BarraTitulo1.CambiarTitulo("Claim Register")
        MostrarLista()
    End Sub

    Private Sub reset()
        CeldaCodCustomer.Text = INT_CERO
        CeldaCustomer.Text = STR_VACIO

        'CeldaRepresentative.Text = STR_VACIO
        'CeldaQuantitySold.Text = INT_CERO
        'CeldaDateInvoce.Text = STR_VACIO
        'CeldaLotNumber.Text = STR_VACIO
        'CeldaYarnDescription.Text = STR_VACIO
        CeldaLocationProblem.Text = STR_VACIO
        CeldaProblem.Text = STR_VACIO
        CeldaYearClaim.Text = "2000"
        celdaLinea.Text = INT_CERO
        'celdaProvider.Text = STR_VACIO
        'CeldaDateInvoce.Text = INT_CERO
        CeldaDificultiesCustomer.Text = STR_VACIO
        LBLTotalQuantity.Text = 0
        CeldaConfirmacionProducto.Text = STR_VACIO
        'CeldaDefect.Text = INT_CERO
        CeldaAnalysisInspection.Text = STR_VACIO
        CeldaActionsDone.Text = STR_VACIO
        txtTotalDefect.Text = 0.0
        CeldaTotalQuantity.Text = INT_CERO
        CeldaComments.Text = STR_VACIO
        celdapais.Text = STR_VACIO
        CeldaConclusions.Text = STR_VACIO
        CeldaClaimRefence.Text = STR_VACIO
        CeldaAmount.Text = INT_CERO
        CeldaChargeback.Text = INT_CERO
        celdaAnoClaim.Text = INT_CERO
        CeldaClaim.Text = INT_CERO
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If TAB_CLAIM.Visible = True Then
            MostrarLista()
            BloquearBotones()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub frmReclamos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Public Function MontoActualizado() As Double
        Dim dblMonto As Double = INT_CERO
        Dim Cell As DataGridViewCell

        For i As Integer = 0 To dgdetalle.Rows.Count - 1
            Cell = dgdetalle.Rows(i).Cells(4)
            dblMonto = dblMonto + Cell.Value
        Next

        Return dblMonto
    End Function

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)

        If logBloquear = True Then
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonBorrar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If

    End Sub

    Private Function ComprobarDatosGeneral() As Boolean
        Dim logCoprobarGeneral As Boolean = True


        If cfun.ValidarCampoTexto(CeldaCustomer) = False Then
            logCoprobarGeneral = False
        End If
        'If cfun.ValidarCampoTexto(CeldaDateInvoce) = False Then
        '    logCoprobarGeneral = False
        'End If
        'If cfun.ValidarCampoNumerico(CeldaQuantitySold) = False Then
        '    logCoprobarGeneral = False
        'End If
        If cfun.ValidarCampoTexto(CeldaLocationProblem) = False Then
            logCoprobarGeneral = False
        End If

        'If cfun.ValidarCampoTexto(CeldaYarnDescription) = False Then
        '    logCoprobarGeneral = False
        'End If

        'If cfun.ValidarCampoTexto(CeldaLotNumber) = False Then
        '    logCoprobarGeneral = False
        'End If

        'If cfun.ValidarCampoTexto(CeldaRepresentative) = False Then
        '    logCoprobarGeneral = False
        'End If

        If cfun.ValidarCampoTexto(CeldaProblem) = False Then
            logCoprobarGeneral = False
        End If

        If cfun.ValidarCampoTexto(CeldaDificultiesCustomer) = False Then
            logCoprobarGeneral = False
        End If

        Return logCoprobarGeneral
    End Function

    Private Function ComprobarDatosAnalisis() As Boolean
        Dim logCopobarAnalisar As Boolean = True

        If cfun.ValidarCampoTexto(CeldaConfirmacionProducto) = False Then
            logCopobarAnalisar = False
        End If

        'If cfun.ValidarCampoNumerico(CeldaDefect) = False Then
        '    logCopobarAnalisar = False
        'End If

        If cfun.ValidarCampoTexto(CeldaAnalysisInspection) = False Then
            logCopobarAnalisar = False
        End If

        If cfun.ValidarCampoTexto(CeldaActionsDone) = False Then
            logCopobarAnalisar = False
        End If

        If cfun.ValidarCampoTexto(CeldaTotalQuantity) = False Then
            logCopobarAnalisar = False
        End If

        Return logCopobarAnalisar
    End Function

    Private Function ComprobarDatosObservacion() As Boolean
        Dim logcopobarobservacion As Boolean = True

        If cfun.ValidarCampoTexto(CeldaComments) = False Then
            logcopobarobservacion = False
        End If

        If cfun.ValidarCampoTexto(CeldaConclusions) = False Then
            logcopobarobservacion = False
        End If

        If cfun.ValidarCampoTexto(CeldaNoExplain) = False Then
            logcopobarobservacion = False
        End If

        If cfun.ValidarCampoNumerico(CeldaAmount) = False Then
            logcopobarobservacion = False
        End If

        If cfun.ValidarCampoNumerico(CeldaChargeback) Then
            logcopobarobservacion = False
        End If

        Return logcopobarobservacion

    End Function

    Private Function SQLBuscar()
        Dim corigenes As New clsClaimRegister
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT  A.HDoc_Doc_Num Claim,A.HDoc_Doc_Ano Year ,A.HDoc_Doc_Fec Date,A.HDoc_Emp_Nom Cliente,"
        strSQL &= "A.HDoc_DR2_Num Referencia , A.HDoc_Emp_Tel Origen "
        strSQL &= "FROM Dcmtos_HDR A "
        strSQL &= "where A.HDoc_Sis_Emp = {empresa} and A.HDoc_Doc_Cat = 984 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        If chkfechas.Checked = True Then
            strSQL &= " and A.Hdoc_Doc_Fec between '{inicio}' and '{fin}' "
            strSQL = Replace(strSQL, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If

        If chkclientes.Checked = True Then

            strSQL &= "and A.HDoc_Emp_Cod  = {codcostumer} "

            strSQL = Replace(strSQL, "{codcostumer}", CInt(txtCli.Text))
        Else
            txtCli.Text = vbEmpty
            CeldaCliente.Text = vbNullString

        End If

        If chkfacturas.Checked = True Then
            strSQL &= "and A.HDoc_Pro_DNum = {factura}"

            strSQL = Replace(strSQL, "{factura}", CInt(CeldaFactura.Text))

        Else

            CeldaFactura.Text = INT_CERO

        End If

        Return strSQL

    End Function

    Private Sub DividirTexto(ByVal Texto As String)
        Dim ArregloTexto() As String
        Dim TextoDivido As String = STR_VACIO


        Try
            ArregloTexto = Texto.Split("|".ToCharArray)

            For i As Integer = 0 To ArregloTexto.Length - 1
                TextoDivido = ArregloTexto(i)

                If i = 0 Then
                    CeldaProblem.Text = TextoDivido
                Else
                    CeldaAnalysisInspection.Text = TextoDivido
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub SeleccionarEncabezado(ByVal intNumero As Integer, ByVal intAño As Integer)
        Dim cHDR As New clsDcmtos_HDR
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strTexto As String = STR_VACIO

        strCampos = "HDoc_Doc_Fec,HDoc_Emp_Cod,HDoc_Emp_Nom,HDoc_Emp_NIT,HDoc_RF1_Txt,HDoc_RF2_Txt," & _
                    "HDoc_RF2_Cod,HDoc_RF3_Dbl,HDoc_Emp_Per," & _
                    "HDoc_Doc_TC ,HDoc_RF1_Cod,HDoc_DR1_Num, HDoc_RF1_Dbl, " & _
                    "HDoc_RF2_Dbl, HDoc_DR2_Num,HDoc_Emp_Tel,HDoc_Doc_Status,HDoc_DR1_Dbl"

        strCondicion = "HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 984 and HDoc_Doc_Ano = {año} and HDoc_Doc_Num = {IdClaim}"


        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", intAño)
        strCondicion = Replace(strCondicion, "{IdClaim}", intNumero)

        Try
            cHDR.CONEXION = strConexion

            If cHDR.Seleccionar(strCondicion, strCampos) = True Then
                Dim fecha As String = STR_VACIO

                CeldaCodCustomer.Text = cHDR.HDOC_EMP_COD
                CeldaCustomer.Text = cHDR.HDOC_EMP_NOM
                CeldaLocationProblem.Text = cHDR.HDOC_EMP_NIT
                fecha = CDate(cHDR.HDOC_DOC_FEC)
                dtp_claim.Value = CDate(fecha)
                strTexto = cHDR.HDOC_RF1_TXT
                DividirTexto(strTexto)
                celdapais.Text = cHDR.HDOC_EMP_TEL
                CeldaDificultiesCustomer.Text = cHDR.HDOC_RF2_TXT
                CeldaConfirmacionProducto.Text = cHDR.HDOC_RF2_COD
                LBLTotalQuantity.Text = cHDR.HDOC_RF3_DBL
                CeldaActionsDone.Text = cHDR.HDOC_EMP_PER
                CeldaTotalQuantity.Text = cHDR.HDOC_DOC_TC
                CeldaComments.Text = cHDR.HDOC_RF1_COD
                CeldaConclusions.Text = cHDR.HDOC_DR1_NUM
                CeldaAmount.Text = cHDR.HDOC_RF1_DBL
                CeldaChargeback.Text = cHDR.HDOC_RF2_DBL
                CeldaClaimRefence.Text = cHDR.HDOC_DR2_NUM
                txtTotalDefect.Text = cHDR.HDOC_DR1_DBL

                If cHDR.HDOC_DOC_STATUS = INT_UNO Then
                    rdbyes.Checked = True
                    rdbno.Checked = False
                Else
                    rdbyes.Checked = False
                    rdbno.Checked = True
                End If
            Else
                MsgBox(cHDR.MERROR.ToString)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub SeleccionarDetalle(ByVal intNumero As Integer, ByVal intAño As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO


        strSQL = "Select PDoc_Par_Num,PDoc_Par_Ano,PDoc_Par_Lin,PDoc_Chi_Ano,DDoc_Prd_DSQ,DDoc_RF1_Cod,DDoc_Prd_Ref," & _
                    "DDoc_Prd_PNr,DDoc_RF2_Cod,DDoc_Prd_Des " & _
                    "FROM  Dcmtos_DTL a " & _
                    "left join Dcmtos_DTL_Pro  b on b.PDoc_Sis_Emp = a.DDoc_Sis_Emp and b.PDoc_Chi_Cat = 984 and  " & _
                    "b.PDoc_Chi_Ano = a.DDoc_Doc_Ano and b.PDoc_Chi_Lin = a.DDoc_Doc_Lin and b.PDoc_Chi_Num = a.DDoc_Doc_Num " & _
                    " where DDoc_Sis_Emp = {empresa} and DDoc_Doc_Ano = {año} and DDoc_Doc_Cat = 984 AND DDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", intAño)
        strSQL = Replace(strSQL, "{numero}", intNumero)

        Try


            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader

            COM = New MySqlCommand(strSQL, CON)

            REA = COM.ExecuteReader

            dgdetalle.Rows.Clear()

            Do While REA.Read

                strFila = REA.GetInt32("PDoc_Par_Num") & "|" & REA.GetInt16("PDoc_Par_Ano") & "|" & REA.GetInt32("PDoc_Par_Lin") & "|" &
                          REA.GetInt16("PDoc_Chi_Ano") & "|" & REA.GetDouble("DDoc_Prd_DSQ") & "|" & REA.GetString("DDoc_RF1_Cod") & "|" &
                          REA.GetString("DDoc_Prd_Ref") & "|" & REA.GetString("DDoc_Prd_PNr") & "|" & REA.GetString("DDoc_RF2_Cod") & "|" &
                          REA.GetString("DDoc_Prd_Des")

                cfun.AgregarFila(dgdetalle, strFila)
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Seleccionar(ByVal intID As Integer, ByVal intAño As Integer)
        SeleccionarEncabezado(intID, intAño)
        SeleccionarDetalle(intID, intAño)
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True)

        If logMostrar = True Then

            BarraTitulo1.CambiarTitulo("Claim Register")
            panelFiltro.Dock = DockStyle.Fill
            panelFiltro.Visible = True
            btnImprimir.Visible = False
            cfun.CargarLista(dglista, SQLBuscar)
            dtp_claim.Visible = False
            TAB_CLAIM.Dock = DockStyle.None
            TAB_CLAIM.Visible = False

        Else

            BarraTitulo1.CambiarTitulo("Modificar Registro")
            panelFiltro.Dock = DockStyle.Fill
            panelFiltro.Visible = False
            btnImprimir.Visible = True
            dtp_claim.Visible = True
            TAB_CLAIM.Dock = DockStyle.Fill
            TAB_CLAIM.Visible = True

        End If

    End Sub

    Private Function BuscarPro()
        Dim strSQL As String = STR_VACIO

        strSQL = "Select PDoc_Chi_Num  " & _
                 "From Dcmtos_DTL_Pro " & _
                 "Where PDoc_Sis_Emp = {empresa} and PDoc_Chi_Cat = 984 and PDoc_Chi_Ano = {Año} AND PDoc_Chi_Num = {numero} " & _
                 "limit 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{Año}", CeldaYearClaim.Text)
        strSQL = Replace(strSQL, "{numero}", CeldaNumClaim.Text)


        Return strSQL

    End Function

#End Region

#Region "Funciones"

    Private Sub frmReclamos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MostrarLista()
        TAB_CLAIM.SelectTab(tga_general)

    End Sub

    Public Sub GuardarDetalle()
        Dim dtl As New clsDcmtos_DTL
        Dim reclamos As New clsClaimRegister
        Dim dtlpro As New clsDcmtos_DTL_Pro
        Dim COM As MySqlCommand
        Dim LineaFactura As Integer = 0
        Dim Factura As Integer = 0
        Dim Linea As Integer = 0
        Dim AnoFactura As Integer = 0
        Dim NumeroClaim As Integer = 0
        Dim strSQL As String = INT_CERO
        Dim Query As String = STR_VACIO
        Dim Valor As Integer = INT_CERO

        dtl.CONEXION = strConexion

        Query = BuscarPro()

        COM = New MySqlCommand(Query, CON)

        Valor = COM.ExecuteScalar()

        If Valor > 0 Then
            Dim strCondicion As String

            strCondicion = " DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = 984 and DDoc_Doc_Ano = {ano} and DDoc_Doc_Num = {numero}  "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{ano}", CInt(lblañoclaim.Text))
            strCondicion = Replace(strCondicion, "{numero}", CInt(lblIdClaim.Text))
            If dtl.Borrar(strCondicion) = True Then
                strCondicion = STR_VACIO
                strCondicion = " PDoc_Sis_Emp = {empresa} and PDoc_Chi_Cat = 984 and PDoc_Chi_Ano = {ano} and PDoc_Chi_Num = {numero}  "
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{ano}", CInt(lblañoclaim.Text))
                strCondicion = Replace(strCondicion, "{numero}", CInt(lblIdClaim.Text))

                If dtlpro.Borrar(strCondicion) = True Then
                    For i As Integer = 0 To dgdetalle.Rows.Count - 1

                        Factura = dgdetalle.Rows(i).Cells("Factura").Value

                        Linea = i + 1

                        dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                        dtl.DDOC_DOC_CAT = 984
                        dtl.DDOC_DOC_NUM = CInt(lblIdClaim.Text)
                        dtl.DDOC_DOC_ANO = CInt(lblañoclaim.Text)
                        dtl.DDOC_DOC_LIN = Linea
                        'dtl.DDOC_RF1_FEC = dgdetalle.Rows(i).Cells("Factura").Value
                        dtl.DDOC_RF1_COD = dgdetalle.Rows(i).Cells("Lote").Value
                        AnoFactura = dgdetalle.Rows(i).Cells("Año").Value
                        LineaFactura = dgdetalle.Rows(i).Cells("Linea").Value
                        dtl.DDOC_PRD_DSQ = dgdetalle.Rows(i).Cells("Quantity").Value
                        dtl.DDOC_PRD_REF = dgdetalle.Rows(i).Cells("Descripcion").Value
                        dtl.DDOC_PRD_PNR = dgdetalle.Rows(i).Cells("Proveedor").Value
                        dtl.DDOC_RF2_COD = dgdetalle.Rows(i).Cells("Usuario").Value
                        dtl.DDOC_PRD_DES = dgdetalle.Rows(i).Cells("ki").Value

                        If dtl.Guardar() = True Then
                            dtlpro.PDOC_SIS_EMP = Sesion.IdEmpresa
                            dtlpro.PDOC_PAR_CAT = 36
                            dtlpro.PDOC_PAR_ANO = AnoFactura
                            dtlpro.PDOC_PAR_NUM = Factura
                            dtlpro.PDOC_PAR_LIN = LineaFactura
                            dtlpro.PDOC_CHI_CAT = 984
                            dtlpro.PDOC_CHI_ANO = CInt(lblañoclaim.Text)
                            dtlpro.PDOC_CHI_NUM = CInt(lblIdClaim.Text)
                            dtlpro.PDOC_CHI_LIN = Linea

                            If dtlpro.Guardar = False Then
                                MsgBox(dtlpro.MERROR.ToString)
                            End If
                        End If

                    Next

                    'MsgBox("Actualizado")
                End If
            End If

        Else

            Try

                For i As Integer = 0 To dgdetalle.Rows.Count - 1

                    Factura = dgdetalle.Rows(i).Cells("Factura").Value

                    Linea = i + 1

                    dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    dtl.DDOC_DOC_CAT = 984
                    dtl.DDOC_DOC_NUM = CInt(CeldaNumClaim.Text)
                    dtl.DDOC_DOC_ANO = CInt(CeldaYearClaim.Text)
                    dtl.DDOC_DOC_LIN = Linea
                    'dtl.DDOC_RF1_FEC = dgdetalle.Rows(i).Cells("Factura").Value
                    dtl.DDOC_RF1_COD = dgdetalle.Rows(i).Cells("Lote").Value
                    AnoFactura = dgdetalle.Rows(i).Cells("Año").Value
                    LineaFactura = dgdetalle.Rows(i).Cells("Linea").Value
                    dtl.DDOC_PRD_DSQ = dgdetalle.Rows(i).Cells("Quantity").Value
                    dtl.DDOC_PRD_REF = dgdetalle.Rows(i).Cells("Descripcion").Value
                    dtl.DDOC_PRD_PNR = dgdetalle.Rows(i).Cells("Proveedor").Value
                    dtl.DDOC_RF2_COD = dgdetalle.Rows(i).Cells("Usuario").Value
                    dtl.DDOC_PRD_DES = dgdetalle.Rows(i).Cells("ki").Value

                    dtl.Guardar()

                    dtlpro.PDOC_SIS_EMP = Sesion.IdEmpresa
                    dtlpro.PDOC_PAR_CAT = 36
                    dtlpro.PDOC_PAR_ANO = AnoFactura
                    dtlpro.PDOC_PAR_NUM = Factura
                    dtlpro.PDOC_PAR_LIN = LineaFactura
                    dtlpro.PDOC_CHI_CAT = 984
                    dtlpro.PDOC_CHI_ANO = CInt(CeldaYearClaim.Text)
                    dtlpro.PDOC_CHI_NUM = CInt(CeldaNumClaim.Text)
                    dtlpro.PDOC_CHI_LIN = Linea


                    If dtlpro.Guardar = False Then
                        MsgBox(dtlpro.MERROR.ToString)
                    End If

                Next

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        End If

    End Sub

    Public Function CargarLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT A.HDoc_Emp_nom Customer, A.HDoc_Doc_Num Invoce, A.HDoc_Doc_Fec Date, B.DDoc_Prd_QTY Quantity ,C.inv_prodlote Lote, D.art_DCorta Descripcion, "
        strSQL &= " E.pro_nombre Proveedor, G.HDoc_Usuario Usuario "
        strSQL &= "FROM Dcmtos_HDR A "
        strSQL &= "LEFT JOIN Dcmtos_DTL B ON B.DDoc_Sis_Emp = A.HDoc_Sis_Emp AND B.DDoc_Doc_Cat = A.HDoc_Doc_Cat AND B.DDoc_Doc_Ano = A.HDoc_Doc_Ano AND "
        strSQL &= "B.DDoc_Doc_Num = A.HDoc_Doc_Num "
        strSQL &= "LEFT JOIN Inventarios C on C.inv_sisemp = B.DDoc_Sis_Emp AND C.inv_numero = B.DDoc_Prd_Cod "
        strSQL &= "LEFT JOIN Articulos D on D.art_sisemp = C.inv_sisemp and D.art_codigo = C.inv_artcodigo   "
        strSQL &= "LEFT JOIN Proveedores E on E.pro_sisemp = C.inv_sisemp  and E.pro_codigo = C.inv_provcod "
        strSQL &= "LEFT JOIN Dcmtos_DTL_Pro F on F.PDoc_Sis_Emp = B.DDoc_Sis_Emp and F.PDoc_Chi_Cat = B.DDoc_Doc_Cat "
        strSQL &= "and F.PDoc_Chi_Ano = B.DDoc_Doc_Ano and F.PDoc_Chi_Num = B.DDoc_Doc_Num "
        strSQL &= "and F.PDoc_Chi_Lin = B.DDoc_Doc_Lin "
        strSQL &= "LEFT JOIN Dcmtos_HDR  G ON  G.HDoc_Sis_Emp = F.PDoc_Sis_Emp AND G.HDoc_Doc_Cat = F.PDoc_Par_Cat "
        strSQL &= "AND G.HDoc_Doc_Ano = F.PDoc_Par_Ano AND G.HDoc_Doc_Num = F.PDoc_Par_Num "
        strSQL &= "WHERE A.HDoc_Sis_Emp = {empresa} and A.Hdoc_Doc_cat=984 and  A.HDoc_Doc_Ano = " & Year(dtp_claim.Text)

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL

    End Function

    Private Sub btncliente_Click(sender As Object, e As EventArgs) Handles btncliente.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        strCondicion = "cli_sisemp= " & Sesion.IdEmpresa
        frm.Tabla = "Clientes"
        frm.Campos = "cli_codigo Código, cli_cliente Nombre_Cliente"
        frm.Condicion = strCondicion
        frm.Limite = 50
        frm.Filtro = "cli_cliente"
        frm.Titulo = "Cliente"
        frm.FiltroText = "Ingrese el nombre del cliente para filtrar"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            CeldaCustomer.Text = frm.Dato
            CeldaCodCustomer.Text = frm.LLave
            txtCli.Text = CInt(frm.LLave)
            CeldaCliente.Text = frm.Dato
        End If

        cfun.CargarLista(dglista, SQLBuscar)

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        Dim objeto As New clsClaimRegister
        Dim factura As Integer = 0
        Dim Year As Integer = 0
        Dim YearFactura As Integer = 0

        Try

            YearFactura = CeldaYearClaim.Text
            'objeto.IdCalim = CeldaClaim.Text
            objeto.CodigoCustomer = CeldaCodCustomer.Text
            objeto.NameCustomer = CeldaCustomer.Text

            objeto.IdCalim = lblIdClaim.Text
            objeto.AnoClaim = lblañoclaim.Text
            'objeto.InvoceNumber = factura
            'objeto.AnoFactura = YearFactura
            'objeto.Linea = CInt(celdaLinea.Text)
            objeto.FechaClaim = dtp_claim.Text
            objeto.Pais = celdapais.Text
            'objeto.Provider = celdaProvider.Text
            'objeto.CustomerRepresentative = CeldaRepresentative.Text
            'objeto.DateInvoce = CeldaDateInvoce.Text
            objeto.TotalDefect = txtTotalDefect.Text
            'objeto.LotNumber = CeldaLotNumber.Text
            'objeto.YarnDescription = CeldaYarnDescription.Text
            objeto.LocationProblem = CeldaLocationProblem.Text
            objeto.TypeProblem = CeldaProblem.Text
            objeto.DificultiesCustomer = CeldaDificultiesCustomer.Text
            objeto.Verificacion = CeldaConfirmacionProducto.Text
            objeto.DefectQuantity = CDbl(LBLTotalQuantity.Text)
            objeto.Analysis = CeldaAnalysisInspection.Text
            objeto.ActionDone = CeldaActionsDone.Text
            objeto.Observaciones = CeldaComments.Text
            objeto.Soluciones = CeldaConclusions.Text
            objeto.SaveQuantity = CeldaTotalQuantity.Text
            objeto.OriginalAmount = CeldaAmount.Text
            objeto.TotalChargeback = CeldaChargeback.Text
            objeto.NoExplain = CeldaNoExplain.Text

            If rdbyes.Checked = True Then
                objeto.Apply = 1
            Else
                objeto.Apply = 0
            End If

            objeto.Guardar()


            CeldaYearClaim.Text = objeto.AnoClaim
            CeldaNumClaim.Text = objeto.IdCalim

            'reset()
            TAB_CLAIM.SelectTab(tga_general)

            GuardarDetalle()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        objeto = Nothing

    End Sub

    Public Sub subDcmtos()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection



        strSQL = "SELECT cat_clave, cat_desc,if(( " & _
                 "SELECT COUNT(*) " & _
                 "FROM Dcmtos_ACC " & _
                 "WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 984 AND ADoc_Doc_Ano ={year}  AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = 'Doc_DGTO') > 0,'SI','NO' )Cantidad " & _
                 "FROM Catalogos " & _
                 "WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_OGTO' AND (cat_sisemp IN (0,3)) " & _
                 "ORDER BY cat_desc "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{year}", lblañoclaim.Text)
        strSQL = Replace(strSQL, "{numero}", lblIdClaim.Text)

        CON = New MySqlConnection(strConexion)

        CON.Open()

        Try
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgvsubDocumentos.Rows.Clear()

                While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetString("cat_desc") & "|" & REA.GetString("Cantidad")

                    cfun.AgregarFila(dgvsubDocumentos, strFila)

                End While

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

    End Sub

    Public Function SQLCopiar(ByVal llave As Integer, ByVal Año As Integer, ByVal Linea As Integer) As String
        Dim strSQL As String = ""

        strSQL = "SELECT A.HDoc_Doc_Ano Año,A.HDoc_Doc_Num Factura,B.DDoc_Doc_Lin Linea, A.HDoc_Doc_Fec DATE, IFNULL(B.DDoc_Prd_QTY,0) Quantity, IFNULL(C.inv_prodlote,'') Lote, "
        strSQL &= "IFNULL(D.art_DCorta,'') Descripcion, IFNULL(E.pro_proveedor,'') Proveedor, IFNULL(G.HDoc_Usuario,'') Usuario, J.cat_clave Pais ,A.HDoc_DR1_Num ki "
        strSQL &= "FROM Dcmtos_HDR A "
        strSQL &= "LEFT JOIN Dcmtos_DTL B ON B.DDoc_Sis_Emp = A.HDoc_Sis_Emp AND B.DDoc_Doc_Cat = A.HDoc_Doc_Cat AND B.DDoc_Doc_Ano = A.HDoc_Doc_Ano AND B.DDoc_Doc_Num = A.HDoc_Doc_Num "
        strSQL &= "LEFT JOIN Inventarios C ON C.inv_sisemp = B.DDoc_Sis_Emp AND C.inv_numero = B.DDoc_Prd_Cod "
        strSQL &= "LEFT JOIN Articulos D ON D.art_sisemp = C.inv_sisemp AND D.art_codigo = C.inv_artcodigo "
        strSQL &= "LEFT JOIN Proveedores E ON E.pro_sisemp = C.inv_sisemp AND E.pro_codigo = C.inv_provcod "
        strSQL &= "LEFT JOIN Dcmtos_DTL_Pro F ON F.PDoc_Sis_Emp = B.DDoc_Sis_Emp AND F.PDoc_Chi_Cat = B.DDoc_Doc_Cat AND F.PDoc_Chi_Ano = B.DDoc_Doc_Ano AND F.PDoc_Chi_Num = B.DDoc_Doc_Num AND F.PDoc_Chi_Lin = B.DDoc_Doc_Lin "
        strSQL &= "LEFT JOIN Dcmtos_DTL_Pro H ON H.PDoc_Sis_Emp = F.PDoc_Sis_Emp AND H.PDoc_Chi_Cat = F.PDoc_Par_Cat AND H.PDoc_Chi_Ano = F.PDoc_Par_Ano AND H.PDoc_Chi_Num = F.PDoc_Par_Num AND H.PDoc_Chi_Lin = F.PDoc_Par_Lin AND H.PDoc_Par_Cat = 75 "
        strSQL &= "LEFT JOIN Clientes I ON I.cli_sisemp = A.HDoc_Sis_Emp AND I.cli_codigo = A.HDoc_Emp_Cod "
        strSQL &= "LEFT JOIN Catalogos J ON J.cat_num = I.cli_pais "
        strSQL &= "LEFT JOIN Dcmtos_HDR G ON G.HDoc_Sis_Emp = H.PDoc_Sis_Emp AND G.HDoc_Doc_Cat = H.PDoc_Par_Cat AND G.HDoc_Doc_Ano = H.PDoc_Par_Ano AND G.HDoc_Doc_Num = H.PDoc_Par_Num "
        strSQL &= "WHERE A.HDoc_Sis_Emp = {empresa} AND A.Hdoc_Doc_cat = 36 AND A.HDoc_Doc_Ano = {año} AND A.HDoc_Doc_Num = {llave} and B.DDoc_Doc_Lin = {linea} "
        strSQL &= "LIMIT 15 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{llave}", llave)
        strSQL = Replace(strSQL, "{año}", Año)
        strSQL = Replace(strSQL, "{linea}", Linea)

        Return strSQL

    End Function

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False)
        lblIdClaim.Visible = False
        lblañoclaim.Visible = False
        CeldaClaimRefence.Visible = False
        Label24.Visible = False
        CeldaNumClaim.Visible = True
        dgdetalle.Rows.Clear()
        lblIdClaim.Text = 0
        lblañoclaim.Text = 0
        subDcmtos()
        reset()
        BloquearBotones(False)
        Me.Tag = "Nuevo"
    End Sub

    Private Sub btninvoice_Click(sender As Object, e As EventArgs) Handles btninvoice.Click

        Dim frmFact As New frmSeleccionar
        Dim frmLinea As New frmSeleccionar
        Dim cOrigenes As New clsClaimRegister
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        CeldaYearClaim.Text = 2000
        CeldaFactura.Text = NO_FILA
        celdaLinea.Text = NO_FILA

        strCondicion = "h.HDoc_Sis_Emp = {sesion} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Emp_Cod = {cliente} and h.HDoc_Doc_Status = 1 and ce.HDoc_Sis_Emp is null "
        strCondicion = Replace(strCondicion, "{sesion}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{cliente}", CeldaCodCustomer.Text)

        strTabla = "Dcmtos_HDR h"
        strTabla &= " left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat"
        strTabla &= " and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strTabla &= " left join Dcmtos_HDR ce on ce.HDoc_Sis_Emp = d.DDoc_Sis_Emp  and ce.HDoc_Pro_DCat = d.DDoc_Doc_Cat "
        strTabla &= " and ce.HDoc_Pro_DAno = d.DDoc_Doc_Ano and ce.HDoc_Pro_DNum = d.DDoc_Doc_Num  and ce.HDoc_Doc_Mon = d.DDoc_Doc_Lin  and ce.HDoc_Doc_Cat = 984 and ce.HDoc_Doc_Status = 1"

        frmFact.Agrupar = " h.HDoc_Doc_Num "
        frmFact.Ordenamiento = "h.HDoc_Doc_Fec"
        frmFact.Tabla = strTabla
        frmFact.Campos = "h.HDoc_Doc_Ano Ano,h.HDoc_Doc_Num Numero,h.HDoc_Doc_Fec Fecha,h.HDoc_RF2_Dbl Total"
        frmFact.Condicion = strCondicion
        'frmFact.Limite = 20
        frmFact.Filtro = "h.HDoc_Doc_Num"
        frmFact.Titulo = "Factura"
        frmFact.FiltroText = "Ingrese el número de factura para filtrar"

        If frmFact.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            ' CeldaYearClaim.Text = frmFact.LLave
            strTabla = STR_VACIO
            strTabla &= "Dcmtos_HDR A "
            strTabla &= "LEFT JOIN Dcmtos_DTL B ON B.DDoc_Sis_Emp = A.HDoc_Sis_Emp AND B.DDoc_Doc_Cat = A.HDoc_Doc_Cat AND B.DDoc_Doc_Ano = A.HDoc_Doc_Ano AND B.DDoc_Doc_Num = A.HDoc_Doc_Num "
            strTabla &= "LEFT JOIN Inventarios C ON C.inv_sisemp = B.DDoc_Sis_Emp AND C.inv_numero = B.DDoc_Prd_Cod "
            strTabla &= "LEFT JOIN Articulos D ON D.art_sisemp = C.inv_sisemp AND D.art_codigo = C.inv_artcodigo "
            strTabla &= "LEFT JOIN Proveedores E ON E.pro_sisemp = C.inv_sisemp AND E.pro_codigo = C.inv_provcod "
            strTabla &= "LEFT JOIN Dcmtos_DTL_Pro F ON F.PDoc_Sis_Emp = B.DDoc_Sis_Emp AND F.PDoc_Chi_Cat = B.DDoc_Doc_Cat AND F.PDoc_Chi_Ano = B.DDoc_Doc_Ano AND F.PDoc_Chi_Num = B.DDoc_Doc_Num AND F.PDoc_Chi_Lin = B.DDoc_Doc_Lin "
            strTabla &= "LEFT JOIN Dcmtos_DTL_Pro H ON H.PDoc_Sis_Emp = F.PDoc_Sis_Emp AND H.PDoc_Chi_Cat = F.PDoc_Par_Cat AND H.PDoc_Chi_Ano = F.PDoc_Par_Ano AND H.PDoc_Chi_Num = F.PDoc_Par_Num AND H.PDoc_Chi_Lin = F.PDoc_Par_Lin AND H.PDoc_Par_Cat = 75 "
            strTabla &= "LEFT JOIN Clientes I ON I.cli_sisemp = A.HDoc_Sis_Emp AND I.cli_codigo = A.HDoc_Emp_Cod "
            strTabla &= "LEFT JOIN Catalogos J ON J.cat_num = I.cli_pais "
            strTabla &= "LEFT JOIN Dcmtos_HDR G ON G.HDoc_Sis_Emp = H.PDoc_Sis_Emp AND G.HDoc_Doc_Cat = H.PDoc_Par_Cat AND G.HDoc_Doc_Ano = H.PDoc_Par_Ano AND G.HDoc_Doc_Num = H.PDoc_Par_Num "


            strCondicion = STR_VACIO
            strCondicion = "A.HDoc_Sis_Emp = {empresa} AND A.Hdoc_Doc_cat = 36 AND A.HDoc_Doc_Ano = {año} AND A.HDoc_Doc_Num = {numero} "
            strCondicion = Replace(strCondicion, "{año}", frmFact.LLave)
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{numero}", frmFact.Dato)


            frmLinea.Tabla = strTabla
            frmLinea.Campos = "A.HDoc_Doc_Num Factura,A.HDoc_Doc_Ano Año ,B.DDoc_Doc_Lin Linea, A.HDoc_Doc_Fec DATE, IFNULL(B.DDoc_Prd_QTY,0) Quantity, " & _
                              "IFNULL(C.inv_prodlote,'') Lote, IFNULL(D.art_DCorta,'') Descripcion, IFNULL(E.pro_proveedor,'') Proveedor, " & _
                              "IFNULL(G.HDoc_Usuario,'') Usuario, A.HDoc_DR1_Num ki "
            frmLinea.Condicion = strCondicion
            'frmLinea.Limite = 15
            'frmLinea.Filtro = "DDoc_Prd_Des"
            frmLinea.Titulo = " Línea de la factura"
            frmLinea.FiltroText = "Ingrese la descripción del producto para filtrar"

            If frmLinea.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Dim Query As String = ""
                Dim fila As String = ""

                Query = SQLCopiar(CInt(frmLinea.LLave), CInt(frmLinea.Dato), CInt(frmLinea.Dato2))

                Dim comando As MySqlCommand
                Dim Reader As MySqlDataReader

                comando = New MySqlCommand(Query, CON)

                Reader = comando.ExecuteReader

                If Reader.HasRows Then
                    Reader.Read()
                    Reader.GetDateTime("DATE").ToString(FORMATO_MYSQL)
                    Reader.GetDouble("Quantity")
                    Reader.GetString("Lote")
                    Reader.GetString("Descripcion")
                    Reader.GetString("ki")
                End If

                fila = frmLinea.LLave & "|" & frmLinea.Dato & "|" & frmLinea.Dato2 & "|" & Reader.GetDateTime("DATE").ToString(FORMATO_MYSQL) & "|" & Reader.GetDouble("Quantity") & "|" &
                        Reader.GetString("Lote") & "|" & Reader.GetString("Descripcion") & "|" & Reader.GetString("Proveedor") & "|" & Reader.GetString("Usuario") & "|" & Reader.GetString("ki")

                cfun.AgregarFila(dgdetalle, fila)

                LBLTotalQuantity.Text = MontoActualizado()

                celdaLinea.Text = frmLinea.Dato2
                'cOrigenes.InvoceNumber = CeldaInvoceNumber.Text
                'cOrigenes.Linea = celdaLinea.Text
                'cOrigenes.AnoFactura = celdaAñoFactrura.Text
                celdapais.Text = Reader.GetString("Pais")
                ''cOrigenes.ClaimRegister()

                'CeldaYarnDescription.Text = cOrigenes.YarnDescription
                'CeldaRepresentative.Text = cOrigenes.CustomerRepresentative
                'celdaProvider.Text = cOrigenes.Provider
                'cOrigenes.Pais = celdapais.Text
                'CeldaDateInvoce.Text = cOrigenes.DateInvoce
                'CeldaQuantitySold.Text = cOrigenes.QuantitySold
                'CeldaLotNumber.Text = cOrigenes.LotNumber

            End If

        End If

        cOrigenes = Nothing

    End Sub

#End Region

    Private Sub btncustomer_Click(sender As Object, e As EventArgs) Handles btncustomer.Click

        Dim strCondicion As String = STR_VACIO
        Dim frm As New frmSeleccionar

        strCondicion = "cli_sisemp= " & Sesion.IdEmpresa
        frm.Tabla = "Clientes"
        frm.Campos = "cli_codigo Código, cli_cliente Nombre_Cliente"
        frm.Condicion = strCondicion
        frm.Limite = 50
        frm.Filtro = "cli_cliente"
        frm.Titulo = "Cliente"
        frm.FiltroText = "Ingrese el nombre del cliente para filtrar"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            CeldaCustomer.Text = frm.Dato
            CeldaCodCustomer.Text = frm.LLave
        End If

    End Sub

    Private Sub btnfiltrar_Click(sender As Object, e As EventArgs) Handles btnfiltrar.Click
        cfun.CargarLista(dglista, SQLBuscar)
    End Sub

    Private Sub dglista_DoubleClick(sender As Object, e As EventArgs) Handles dglista.DoubleClick
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Dim strReferences As String = STR_VACIO
        Dim cls As New clsClaimRegister

        Try

            If dglista.SelectedRows.Count = INT_CERO Then Exit Sub

            Me.Tag = "Mod"

            BarraTitulo1.CambiarTitulo("Modifcar Registro")

            CeldaNumClaim.Text = 0
            CeldaNumClaim.Visible = False
            lblañoclaim.Visible = True
            lblIdClaim.Visible = True
            CeldaClaimRefence.Visible = True
            Label24.Visible = True

            intID = dglista.SelectedCells(0).Value
            intAño = dglista.SelectedCells(1).Value
            cls.ReferenciaClaim = CeldaClaimRefence.Text

            lblIdClaim.Text = intID
            lblañoclaim.Text = intAño
            CeldaClaimRefence.Text = strReferences

            reset()

            Seleccionar(intID, intAño)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        'Me.Tag = "mod"
        'Dim intAño As Integer
        'Dim intId As Integer
        'Dim intLinea As Integer
        'Dim strPais As String

        'If dglista.SelectedRows.Count = 0 Then Exit Sub
        'intId = CInt(dglista.SelectedCells(0).Value)
        'intAño = CInt(dglista.SelectedCells(1).Value)
        'intLinea = CInt(dglista.SelectedCells(5).Value)
        'strPais = CStr(dglista.SelectedCells(9).Value)

        'corigenes.Seleccionar(intAño, intId, intLinea)
        'CeldaClaim.Text = intId
        'celdaAnoClaim.Text = intAño
        'celdaLinea.Text = intLinea
        'corigenes.AnoClaim = celdaAnoClaim.Text
        'corigenes.IdCalim = CeldaClaim.Text
        'CeldaCodCustomer.Text = corigenes.CodigoCustomer
        'CeldaCustomer.Text = corigenes.NameCustomer
        'CeldaInvoceNumber.Text = corigenes.InvoceNumber
        'CeldaYearClaim.Text = corigenes.AnoFactura
        ''celdaProvider.Text = corigenes.Provider
        'celdapais.Text = strPais
        ''CeldaRepresentative.Text = corigenes.CustomerRepresentative
        ''CeldaDateInvoce.Text = corigenes.DateInvoce
        ''CeldaQuantitySold.Text = corigenes.QuantitySold
        ''CeldaLotNumber.Text = corigenes.LotNumber
        '' CeldaYarnDescription.Text = corigenes.YarnDescription
        'CeldaLocationProblem.Text = corigenes.LocationProblem
        'CeldaProblem.Text = corigenes.TypeProblem
        'CeldaDificultiesCustomer.Text = corigenes.DificultiesCustomer
        'CeldaConfirmacionProducto.Text = corigenes.Verificacion
        ''CeldaDefect.Text = corigenes.DefectQuantity
        'CeldaActionsDone.Text = corigenes.ActionDone
        'CeldaClaimRefence.Text = corigenes.ReferenciaClaim
        'CeldaAnalysisInspection.Text = corigenes.Analysis
        'CeldaTotalQuantity.Text = corigenes.SaveQuantity
        'CeldaComments.Text = corigenes.Observaciones
        'CeldaConclusions.Text = corigenes.Soluciones
        'CeldaAmount.Text = corigenes.OriginalAmount
        'CeldaChargeback.Text = corigenes.TotalChargeback

        'If corigenes.Apply = 1 Then
        '    rdbyes.Checked = True
        '    rdbno.Checked = False
        'Else
        '    rdbyes.Checked = False
        '    rdbno.Checked = True
        'End If
        subDcmtos()
        MostrarLista(False)
        BloquearBotones(False)

    End Sub

    Private Sub btnImprimir_Click(sender As Object, e As EventArgs) Handles btnImprimir.Click

        Try
            Dim cRep As New clsReportes
            Dim origenes As New clsClaimRegister

            cRep.ClaimRegister(CInt(lblañoclaim.Text), CInt(lblIdClaim.Text))
            cRep.Parent = frmSeleccionar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub btnfactura_Click(sender As Object, e As EventArgs) Handles btnfactura.Click
        cfun.CargarLista(dglista, SQLBuscar)
    End Sub

    Private Sub btnQuitarFila_Click(sender As Object, e As EventArgs) Handles btnQuitarFila.Click
        If dgdetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        dgdetalle.Rows.Remove(dgdetalle.CurrentRow)
        LBLTotalQuantity.Text = MontoActualizado()
    End Sub

    Private Sub dgvsubDocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgvsubDocumentos.DoubleClick

        Dim frm As New frmSubDocumentos

        frm.Tabla = "Catalogos "
        frm.Condicion = "cat_clase = 'Doc_DGTO' "
        frm.SubDocumento = "Doc_DGTO"
        frm.Catalogo = 984
        frm.Año = CInt(lblañoclaim.Text)
        frm.Numero = CInt(lblIdClaim.Text)

        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

        End If

    End Sub
End Class