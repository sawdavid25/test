﻿Public Class FrmBloqueo
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Visible = False
            Encabezado1.botonGuardar.Visible = False
            Encabezado1.botonNuevo.Visible = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            '  botonImprimir.Enabled = True
        End If

    End Sub

    Private Function sqlBloqueo() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT cat_num,cat_clase,cat_clave  , cat_desc Descripcion,cat_sisemp ,"
        strSQL &= "     If (cat_pid=0,'INACTIVO',IF(cat_pid = 1,'ACTIVO', 'INACTIVO')) Estado  "
        strSQL &= "         FROM Catalogos  "
        strSQL &= "             WHERE cat_clase = 'Bloqueo' AND cat_sisemp = {empresa}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Return strSQL
    End Function
    Private Sub Colorear()

        For i As Integer = 0 To DgBloqueo.RowCount - 1
            Select Case DgBloqueo.Rows(i).Cells("colEstado").Value
                Case "ACTIVO"
                    DgBloqueo.Rows(i).Cells("colEstado").Style.BackColor = Color.LightGreen
                Case "INACTIVO"
                    DgBloqueo.Rows(i).Cells("colEstado").Style.BackColor = Color.Gray
            End Select
        Next
    End Sub
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String

        BarraTitulo1.CambiarTitulo("BLOQUEOS")
        strSQL = sqlBloqueo()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                strFila = REA.GetInt32("cat_num") & "|"
                strFila &= REA.GetString("cat_clase") & "|"
                strFila &= REA.GetString("cat_clave") & "|"
                strFila &= REA.GetString("Descripcion") & "|"
                strFila &= REA.GetInt32("cat_sisemp") & "|"
                strFila &= REA.GetString("Estado") & ""
                cFunciones.AgregarFila(DgBloqueo, strFila)
            Loop
        End If
    End Sub
    Public Sub EstadoBloqueo(ByVal Estado As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try


            strSQL = "  UPDATE Catalogos c set cat_pid = {estado} "
            strSQL &= "     WHERE c.cat_clase = 'Bloqueo' AND c.cat_sisemp = {pais} AND c.cat_num = {numero} "
            strSQL = Replace(strSQL, "{pais}", DgBloqueo.CurrentRow.Cells("colPais").Value)
            strSQL = Replace(strSQL, "{numero}", DgBloqueo.CurrentRow.Cells("colNumero").Value)
            strSQL = Replace(strSQL, "{estado}", Estado)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region
#Region "Eventos"
    Private Sub FrmBloqueo_Load(sender As Object, e As EventArgs) Handles Me.Load
        BloquearBotones(True)
        CargarLista()
        Colorear()
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        Me.Close()
    End Sub
    Private Sub FrmBloqueo_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub DgBloqueo_DoubleClick(sender As Object, e As EventArgs) Handles DgBloqueo.DoubleClick
        Dim intEstado As Integer = NO_FILA
        Dim intAnio As Integer = NO_FILA

        If DgBloqueo.CurrentRow.Cells("colEstado").Value = "INACTIVO" Then
            DgBloqueo.CurrentRow.Cells("colEstado").Value = "ACTIVO"
            intEstado = 1
        ElseIf DgBloqueo.CurrentRow.Cells("colEstado").Value = "ACTIVO" Then
            DgBloqueo.CurrentRow.Cells("ColEstado").Value = "INACTIVO"
            intEstado = 0
        End If

        EstadoBloqueo(intEstado)
        intAnio = cFunciones.AñoMySQL
        cFunciones.EscribirRegistro("Catalogos", clsFunciones.AccEnum.acUpdate, DgBloqueo.CurrentRow.Cells("colNumero").Value, DgBloqueo.CurrentRow.Cells("colNumero").Value, intAnio, 0, DgBloqueo.CurrentRow.Cells("ColEstado").Value)
        Colorear()
    End Sub

    Private Sub DgBloqueo_KeyDown(sender As Object, e As KeyEventArgs) Handles DgBloqueo.KeyDown
        Try
            If e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(0, cFunciones.AñoMySQL, DgBloqueo.CurrentRow.Cells("colNumero").Value, "Catalogos", DgBloqueo.CurrentRow.Cells("colNumero").Value)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click
        Dim rpt As New clsReportes
        rpt.Historial(0, cFunciones.AñoMySQL, DgBloqueo.CurrentRow.Cells("colNumero").Value, "Catalogos", DgBloqueo.CurrentRow.Cells("colNumero").Value)
    End Sub
#End Region

End Class