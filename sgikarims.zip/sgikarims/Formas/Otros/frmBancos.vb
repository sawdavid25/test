﻿Public Class frmBancos

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Private intCuenta As Integer
    Dim cSesion As New clsSesion
    Dim frm As New frmSeleccionar
    Dim strCondicion As String = STR_VACIO
    Dim strTabla As String = STR_VACIO
    Dim strTitulo As String = STR_VACIO
    Dim strCampos As String = STR_VACIO
    Dim strFiltroText As String = STR_VACIO
    Dim strFiltro As String = STR_VACIO
    Dim strOrdenamiento As String = STR_VACIO
    Dim strLimite As Integer = NO_FILA
    Dim strTipoOrdenamiento As String = STR_VACIO
    Dim strOpciones As String = STR_VACIO
    Dim intSeleccion As String = NO_FILA
    Dim strMensaje As String = STR_VACIO
    Dim strBase As String = STR_VACIO
    Dim intGrupo As Integer
    Dim intItem As Integer
    Dim intMonCaja As Integer
    Private lstGrupo(6) As String
    Private strClase As String
    Private logSecreto As Boolean
    Private logModificar As Boolean
    Private intCurrency As Integer
    Private intmodo As Integer

    Private intDeposito As Integer = 54
    Private intCredito As Integer = 53
    Private intCheque As Integer = 51
    Private intDebito As Integer = 52
    Private intIDCompra As Integer = 44

    Dim frmP As New frmXPresupuesto

    Dim intCurLoc As Integer = cFunciones.MonedaDefault(clsFunciones.Monedas.Mlocal)
    Dim intCurExt As Integer = cFunciones.MonedaDefault(clsFunciones.Monedas.Mextrangero)

    'Tipo de movimiento del documento (grupo)
    '******************************
    '   Modos de presentacion
    '******************************
    'Modo de presentación (pantalla)
    Private Enum eMode
        mdLista = vbEmpty
        mdCuenta = 1
        mdDocumento = 2
    End Enum

    'Enumera grupos de transacción
    Private Enum eGroup
        Proveedor = 0
        Caja = 1
        Cliente = 2
        Empleado = 3
        Planilla = 4
        Transferencia = 5
        Impuestos = 6
    End Enum

    Private Enum Items
        rbPago = 0
        rbImpuesto = 1
        rbAnticipo = 2
        rbGasto = 3
    End Enum

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

#End Region

#Region "Constantes"

    Const IGS_PROVEEDOR As String = " Pay|Tax(ISR)|Advance on purchases|Spending"
    Const IGS_LIQUIDACION As String = "Settlement|Open / Funds|Payment of Travel Expenses|Closing"
    Const IGS_CLIENTE As String = "Charge"
    Const IGS_EMPLEADO As String = "Salario|Bonus|Bono 14|Advance | Loan|Return(Advance/Loan)|Settlement|Bonus Incentive|Extra bonus|Holidays|Compensation|Return ISR"
    Const IGS_PLANILLA As String = "Sheet"
    Const IGS_TRANSFERENCIA As String = "Deposits in transit |Against Spending"
    Const IGS_IMPUESTOS As String = "IVA Payable |ISR Employees |ISR Retentions |ISR (Monthly Payment)"

    'Documentos Anulados
    Private Const IDX_ANULADO As Byte = 3

    Public Const TBL_DOCUMENTOS As String = "clsDcmtos_HDR"

#End Region

#Region "Funciones y Procedimientos Locales"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ResetVista2()
        celdaCodigo.Text = NO_FILA
        celdaBanco.Text = STR_VACIO
        celdaChequera.Text = STR_VACIO
        celdaContacto.Text = STR_VACIO
        celdaMonedaClave.Text = STR_VACIO
        celdaNoCuenta.Text = STR_VACIO
        celdaNombre.Text = STR_VACIO 'cfunciones.letras
        celdaPartida.Text = STR_VACIO
        celdaPlazo.Text = STR_VACIO
        celdaSaldo.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaSobregiro.Text = STR_VACIO
        celdaTipoCuenta.Text = STR_VACIO
        celdaTipoDoc.Text = "TODOS"
        celdaID_TDoc.Text = 0
        celdaNomEmisor.Text = STR_VACIO
        celdaDatosProvee.Text = STR_VACIO
        celdaCajas.Text = STR_VACIO
        celdaBeneficiario.Text = STR_VACIO
        dgMovimientos.Rows.Clear()

    End Sub

    Private Sub ResetVista3()
        Dim Tasa As Double
        Tasa = cFunciones.QueryTasa

        celdaDocumento.Text = "Cheque"
        celdaIDDocumento.Text = 244
        celdaAno.Text = NO_FILA
        celdaNum.Text = NO_FILA
        celdaTipo.Text = NO_FILA
        celdaIDDatos.Text = 0
        celdaNumero.Text = NO_FILA
        celdaConcepto.Text = STR_VACIO
        celdaMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaMoned.Text = STR_VACIO
        celdaTasaCambio.Text = Tasa
        celdaReferencia.Text = STR_VACIO
        celdaNotas.Text = STR_VACIO
        celdaGastoCom.Text = STR_VACIO
        celdaDatosProvee.Text = STR_VACIO
        celdaNomEmisor.Text = STR_VACIO
        dgComprs.Rows.Clear()
        frmP.dgDetalle.Rows.Clear()
        frmP.CeldaTotal.Text = NO_FILA
        celdaTotaLetras.Text = STR_VACIO

        If celdaIdMoneda.Text = 177 Then
            celdaMoned.Text = "Quetzales"
        ElseIf celdaIdMoneda.Text = 178 Then
            celdaMoned.Text = "Dolares"
        ElseIf celdaIdMoneda.Text = 179 Then
            celdaMoned.Text = "Euros"
        Else
            celdaMoned.Text = "Lempiras"
        End If

    End Sub

    Private Function SQLCuenta(Optional ByVal intIdCuenta As Integer = NO_FILA) As String
        Dim strsql As String = STR_VACIO

        strsql = " select "
        If intIdCuenta = NO_FILA Then
            strsql &= " c.BCta_Num No, ccc.cat_desc Bank, c.BCta_Num_Cue Account_Number , c.BCta_Nom_Cue Account_Name, c.BCta_Des_Cue Description, cc.cat_desc Currency "
        Else
            strsql &= " c.*,ccc.cat_desc Bank , cc.cat_desc Currency, ifnull(ch.cat_desc,'0') Cheque  "
        End If
        strsql &= "   from CtasBcos c "
        strsql &= "   left join Catalogos cc on cc.cat_num = c.BCta_Mon  "
        strsql &= "   left join Catalogos ccc on ccc.cat_num = c.BCta_Cod_Ban "
        If intIdCuenta = NO_FILA Then
            strsql &= " where c.BCta_Sis_Emp =  {empresa} and c.BCta_Tipo = 0  "
        Else
            strsql &= " left join Catalogos ch on ch.cat_clase = 'Cheques' and ch.cat_sist = c.BCta_Num and ch.cat_clave='Max_Num' and ch.cat_pid = 1 "
            strsql &= " where c.BCta_Sis_Emp =  {empresa} and c.BCta_Tipo = 0 and c.BCta_Num = {cuenta} "
            strsql = Replace(strsql, "{cuenta}", intIdCuenta)

        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql
    End Function

    Private Sub MostrarLista(Optional ByVal panel As Integer = INT_CERO)
        intmodo = panel
        Select Case panel
            Case INT_CERO
                ' muestra lista de bancos
                BarraTitulo1.CambiarTitulo("BANK ACCOUNTS")
                Panel_Cuenta.Visible = False
                Panel_Cuenta.Dock = DockStyle.None
                panelDocumento.Visible = False
                panelDocumento.Dock = DockStyle.None
                panelLIsta.Visible = True
                panelLIsta.Dock = DockStyle.Fill
                cFunciones.CargarLista(dgLista, SQLCuenta)
            Case INT_UNO
                ' muestra panel de movimientos y datos de la cuenta
                BarraTitulo1.CambiarTitulo("BANKING TRANSACTIONS")
                Panel_Cuenta.Visible = True
                Panel_Cuenta.Dock = DockStyle.Fill
                panelDocumento.Visible = False
                panelDocumento.Dock = DockStyle.None
                panelLIsta.Visible = False
                panelLIsta.Dock = DockStyle.None

            Case 2
                BarraTitulo1.CambiarTitulo("BANK ACCOUNTS")
                ' muestra panel para ingresar documentos
                Panel_Cuenta.Visible = False
                Panel_Cuenta.Dock = DockStyle.None
                panelDocumento.Visible = True
                panelDocumento.Dock = DockStyle.Fill
                panelLIsta.Visible = False
                panelLIsta.Dock = DockStyle.None
        End Select

    End Sub

    Private Function sqlBancoSaldosCuenta(ByVal ID As Integer, ByVal Fecha As Date, Optional Todo As Boolean = False)
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        'Dim REA As MySqlDataReader

        strsql = " SELECT IF(b.BCta_Mon = CAST(a.cat_clave AS SIGNED),'Loc','Ext') Clase"
        strsql &= "  FROM Catalogos a"
        strsql &= "   LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = {empresa} AND b.BCta_Num = {id}"
        strsql &= "     WHERE a.cat_sist='CUR_LOC'"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{id}", ID)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        strClase = COM.ExecuteScalar
        If strClase = vbNullString Then
            MsgBox("No sea configurado CUR_LOC", vbExclamation, "Aviso")

        End If

        strsql = vbNullString
        strsql &= "  SELECT COALESCE(SUM(m.BMov_Abno_{clase})-SUM(m.BMov_Crgo_{clase}),0) Saldo"
        strsql &= "   FROM MvtosBcos m"
        strsql &= "     WHERE BMov_Sis_Emp = {empresa} AND BMov_Cta = {id} {fecha}"

        If Todo Then
            strsql = Replace(strsql, "{fecha}", vbNullString)
        Else
            strsql = Replace(strsql, "{fecha}", " AND (BMov_Fec < '{fecha}' )")
        End If

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{id}", ID)
        strsql = Replace(strsql, "{fecha}", Fecha.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{clase}", strClase)


        Return strsql
    End Function

    Private Sub SaldoActual()
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim Saldo As Double
        'Instrucción de selección para recuperar el saldo
        strSQL = sqlBancoSaldosCuenta(celdaCodigo.Text, dtpInicio.Value.ToString(FORMATO_MYSQL), True)

        'Recupera el saldo de la cuenta
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        Saldo = COM.ExecuteScalar
        celdaSaldo.Text = Saldo.ToString(FORMATO_MONEDA)
    End Sub

    Private Function sqlMovimientos(Optional ByVal intIdCuenta As Integer = NO_FILA) As String
        Dim strsql As String = STR_VACIO
        Dim dblSaldo As Double
        Dim COM As MySqlCommand
        Dim intClase As Integer

        intClase = vbEmpty
        If celdaID_TDoc.Text > 0 Then
            intClase = Val(celdaID_TDoc.Text)
        End If

        'Instruccion de seleccion para recuperar el saldo
        strsql = sqlBancoSaldosCuenta(celdaCodigo.Text, dtpInicio.Value.ToString(FORMATO_MYSQL))

        'Recupera el saldo de la cuenta
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        dblSaldo = COM.ExecuteScalar

        strsql = vbNullString
        strsql &= " SELECT IFNULL(h.HDoc_DR2_Emp,0) secreto, m.BMov_Doc_Cat Tipo, m.BMov_Doc_Ano Ano, m.BMov_Doc_Num Numero, m.BMov_Fec Fecha, IFNULL(lt.cat_desc,0) Documento,  m.BMov_Num_Doc Referencia, IF((m.BMov_Abno_{clase} = 0) AND (m.BMov_Crgo_{clase} = 0),'- ANULADO -',m.BMov_Beneficiario) Dato, (m.BMov_Abno_{clase}) Credito,  (m.BMov_Crgo_{clase}) Debito, IFNULL(m.BMov_Concepto,'') Concepto, IFNULL(h.HDoc_DR1_Cat,0) Categoria,IFNULL(h.HDoc_DR2_Cat,0) Sub, IFNULL(c.poliza,0) Poliza, IFNULL(("
        strsql &= "  SELECT 1"
        strsql &= "   FROM contahilos.detalle_presupuesto d"
        strsql &= "     WHERE d.empresa=m.BMov_Sis_Emp AND d.categoria=m.BMov_Doc_Cat AND d.ano=m.BMov_Doc_Ano AND d.numero=m.BMov_Doc_Num"
        strsql &= "       LIMIT 1),0) Presupuesto, IFNULL(h.HDoc_Doc_Status,-1) Estado, IFNULL(("
        strsql &= "         SELECT GROUP_CONCAT(dp.centro_costos SEPARATOR '') AS C_COSTOS"
        strsql &= "           FROM contahilos.detalle_polizas dp"
        strsql &= "              where dp.poliza = c.poliza and dp.empresa = c.empresa and dp.ejercicio = c.ejercicio "
        strsql &= "                 GROUP BY dp.poliza),'0') Costos"
        strsql &= "                    FROM MvtosBcos m"
        strsql &= "                       LEFT JOIN Catalogos lt ON lt.cat_clase = 'DocsBcos' AND lt.cat_num = m.BMov_Cat_Doc"
        strsql &= "                          LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = m.BMov_Sis_Emp AND h.HDoc_Doc_Cat = m.BMov_Doc_Cat AND h.HDoc_Doc_Ano = m.BMov_Doc_Ano AND h.HDoc_Doc_Num = m.BMov_Doc_Num"
        If cFunciones.ContaActiva Then
            strsql = Replace(strsql, "{poliza}", "c.poliza")
            strsql = Replace(strsql, "{presupuesto}", "IFNULL((SELECT 1 FROM {conta}.detalle_presupuesto d WHERE d.empresa=m.BMov_Sis_Emp AND d.categoria=m.BMov_Doc_Cat AND d.ano=m.BMov_Doc_Ano AND d.numero=m.BMov_Doc_Num LIMIT 1),0)")
            strsql = Replace(strsql, "{costos}", "IFNULL((SELECT GROUP_CONCAT(dp.centro_costos SEPARATOR '') AS C_COSTOS FROM contahilos.detalle_polizas dp WHERE c.poliza = dp.poliza AND c.ref_tipo = dp.ref_tipo AND c.ref_ciclo = dp.ref_ciclo AND c.ref_numero = dp.ref_numero GROUP BY dp.poliza),'0')")
            strsql &= "                            LEFT JOIN contahilos.polizas c ON c.empresa = h.HDoc_Sis_Emp AND c.ref_tipo = h.HDoc_Doc_Cat AND c.ref_ciclo = h.HDoc_Doc_Ano AND c.ref_numero = h.HDoc_Doc_Num"
        End If
        strsql &= "  WHERE m.BMov_Sis_Emp = {empresa} AND m.BMov_Cta = {id} AND (m.BMov_Fec BETWEEN '{fechainicio}' AND '{fechafinal}') {tipo}"
        strsql &= "    ORDER BY m.BMov_Fec, m.BMov_Doc_Cat DESC, m.BMov_Num_Doc"

        strsql = Replace(strsql, "{conta}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{poliza}", "NULL")
        strsql = Replace(strsql, "{presupuesto}", vbEmpty)
        strsql = Replace(strsql, "{clase}", strClase)
        strsql = Replace(strsql, "{tipo}", IIf(intClase > vbEmpty, " AND m.BMov_Cat_Doc=" & intClase, vbNullString))


        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{id}", celdaCodigo.Text)
        strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
        strsql = Replace(strsql, "{fechafinal}", dtpFin.Value.ToString(FORMATO_MYSQL))


        Return strsql
    End Function

    'Procedimiento para Cargar dgLista Panel Principal                      
    Public Sub querySqlMovimientos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim dblSaldo As Double
        Dim p As Integer
        Dim c As String = STR_VACIO
        Dim pre As Integer
        Dim t As Integer
        Dim e As Integer

        'Instruccion de seleccion para recuperar el saldo
        strSQL = sqlBancoSaldosCuenta(celdaCodigo.Text, dtpInicio.Value.ToString(FORMATO_MYSQL))

        'Recupera el saldo de la cuenta
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dblSaldo = COM.ExecuteScalar

        'Dim Lista As DataGridView

        strSQL = sqlMovimientos()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgMovimientos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    dblSaldo = (dblSaldo + REA.GetInt32("Credito") - REA.GetInt32("Debito"))
                    strFila = REA.GetInt32("secreto").ToString & "|"
                    strFila &= REA.GetInt32("Tipo") & "|"
                    strFila &= REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Documento") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Dato") & "|"
                    strFila &= REA.GetDouble("Credito") & "|"
                    strFila &= REA.GetDouble("Debito") & "|"
                    strFila &= dblSaldo.ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Concepto") & "|"
                    strFila &= REA.GetInt32("Categoria") & "|"
                    strFila &= REA.GetInt32("Sub") & "|"
                    strFila &= REA.GetInt32("Poliza") & "|"
                    strFila &= REA.GetInt32("Presupuesto") & "|"
                    strFila &= REA.GetInt32("Estado") & "|"
                    strFila &= REA.GetString("Costos")

                    p = REA.GetInt32("Poliza")
                    c = REA.GetString("Costos")
                    pre = REA.GetInt32("Presupuesto")
                    t = REA.GetInt32("Tipo")
                    e = REA.GetInt32("Estado")

                    AgregarFila(dgMovimientos, strFila, p, c, pre, t, e)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Pocedimiento propio de Bancos para agregar listado principal y colores de acuerdo al estado de cada fila
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal poliza As Integer, ByVal costos As String, ByVal presupuesto As Integer, ByVal Tipo As Integer, ByVal Estado As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Dim intPresupuesto As Integer
        Dim j As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If poliza = 0 Then
                    If i = 4 Then
                        Celda.Style.BackColor = Color.Orange
                    End If
                ElseIf costos = "" Or costos = "0" Then
                    If i = 7 Then
                        Celda.Style.BackColor = Color.Yellow
                    Else
                        Celda.Style.BackColor = Color.White
                    End If
                End If

                intPresupuesto = presupuesto
                If intPresupuesto = INT_UNO Then
                    If i = 5 Then
                        Celda.Style.BackColor = Color.SkyBlue
                        Celda.Style.ForeColor = Color.Blue
                    End If
                End If

                If Tipo = 51 Then
                    If Estado = 3 Then
                        If i = 4 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                        If i = 5 Then
                            Celda.Style.ForeColor = Color.White
                            Celda.Style.BackColor = Color.Red
                        End If
                        If i = 6 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                        If i = 7 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                        If i = 8 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                        If i = 9 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                        If i = 10 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                        If i = 11 Then
                            Celda.Style.ForeColor = Color.Red
                        End If
                    End If
                End If


                Fila.Cells.Add(Celda)

            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarDatosCuenta(ByVal intIdCuenta As Integer)
        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader

        strSql = SQLCuenta(intIdCuenta)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                celdaBanco.Text = REA.GetString("Bank")
                celdaChequera.Text = REA.GetString("Cheque")
                celdaCodigo.Text = REA.GetString("BCta_Num")
                celdaContacto.Text = REA.GetString("BCta_Des_Cue")
                celdaIdBanco.Text = REA.GetString("BCta_Cod_Ban")
                celdaIdMoneda.Text = REA.GetString("BCta_Mon")
                celdaMonedaClave.Text = REA.GetString("Currency")
                celdaNoCuenta.Text = REA.GetString("BCta_Num_Cue")
                celdaNombre.Text = REA.GetString("BCta_Nom_Cue")
                celdaPartida.Text = REA.GetString("BCta_Cuenta")
                celdaPlazo.Text = REA.GetString("BCta_Sob_Plz")
                celdaSobregiro.Text = REA.GetString("BCta_Sob_Aut")
                celdaTipoCuenta.Text = REA.GetString("BCta_Tip_Cue")
                BarraTitulo1.CambiarTitulo("BANKING TRANSACTIONS: " & celdaContacto.Text)
                SaldoActual()

                'celdaNumBank.Text = REA.GetInt32("BCta_Num")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Secreto()
        Dim strSql As String
        Dim intResultado As Integer
        Dim COM As New MySqlCommand
        'Dim REA As MySqlDataReader
        Try
            strSql = " SELECT COUNT(*)"
            strSql &= "   FROM Permisos p"
            strSql &= "      WHERE p.pms_empresa =12 AND p.pms_usuario ='{usuario}' AND p.pms_modulo = 94 AND p.pms_id = {cuenta} AND p.pms_codigo = 'SECRET'"

            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{usuario}", Sesion.idUsuario)
            strSql = Replace(strSql, "{cuenta}", Val(celdaCodigo.Text))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            intResultado = COM.ExecuteScalar


            If intResultado = 0 Then
                logSecreto = False
            Else
                logSecreto = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function sqlCargarDocumento()
        Dim strSql As String


        strSql = " SELECT *, IFNULL(HDoc_DR2_Emp,0) secreto, c.cat_desc"
        strSql &= "      FROM Dcmtos_HDR"
        strSql &= "         LEFT JOIN Catalogos c ON cat_num = HDoc_Doc_Cat"
        strSql &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{tipo}", dgMovimientos.SelectedCells(1).Value)
        strSql = Replace(strSql, "{año}", dgMovimientos.SelectedCells(2).Value)
        strSql = Replace(strSql, "{numero}", dgMovimientos.SelectedCells(3).Value)


        Return strSql
    End Function

    Private Sub CargarDocumento()
        'Carga los datos del documento actual
        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim COM2 As New MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim Tipo As Integer
        Dim Categoria As Integer
        Dim strSQL2 As String = STR_VACIO
        Dim año As Integer
        Dim numero As Integer
        Dim Catalogo As Integer
        Dim strTemp As String = STR_VACIO

        intGrupo = NO_FILA
        intItem = NO_FILA

        strSql = "SELECT IFNULL(HDoc_DR1_Cat,0) Grupo, IFNULL(HDoc_DR2_Cat,0) Item"
        strSql &= "   FROM Dcmtos_HDR"
        strSql &= "      WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={cat} AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{cat}", dgMovimientos.SelectedCells(1).Value)
        strSql = Replace(strSql, "{año}", dgMovimientos.SelectedCells(2).Value)
        strSql = Replace(strSql, "{numero}", dgMovimientos.SelectedCells(6).Value)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()
            intGrupo = REA.GetInt32("Grupo")
            intItem = REA.GetInt32("Item")
        End If

        strSql = sqlCargarDocumento()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader


            If REA.HasRows Then
                REA.Read()
                celdaAno.Text = REA.GetInt32("HDoc_Doc_Ano")
                celdaNum.Text = REA.GetInt32("HDoc_Doc_Num")
                celdaIDDocumento.Text = REA.GetInt32("HDoc_RF2_Num")

                'celdaID_TDoc.Text = REA.GetInt32()
                celdaDocumento.Text = REA.GetString("cat_desc")
                celdaNumero.Text = REA.GetString("HDoc_DR1_Num")
                celdaConcepto.Text = REA.GetString("HDOC_RF1_COD")
                celdaMonto.Text = REA.GetDouble("HDOC_RF1_DBL").ToString(FORMATO_MONEDA)
                celdaNotas.Text = REA.GetString("HDOC_RF1_TXT")
                celdaDatosProvee.Text = REA.GetString("HDoc_Emp_Nom")
                celdaNomEmisor.Text = REA.GetString("HDoc_Emp_Per")
                celdaMoned.Text = REA.GetInt32("HDoc_Doc_Mon")
                celdaTasaCambio.Text = REA.GetDouble("HDoc_Doc_TC")
                celdaReferencia.Text = REA.GetString("HDoc_DR2_Num")
                celdaAnticiposSCompras.Text = REA.GetInt32("HDoc_Ant_Com")
                celdaIDMon.Text = REA.GetInt32("HDoc_Doc_Mon")
                celdaCodigoBank.Text = REA.GetInt32("HDoc_RF1_Num")
                celdaGrupo.Text = REA.GetInt32("HDoc_DR1_Cat")
                celdaValorRB.Text = REA.GetInt32("HDoc_DR2_Cat")
                celdaIDDatos.Text = REA.GetUInt32("HDoc_Emp_Cod")

                intGrupo = REA.GetInt32("HDoc_DR1_Cat")
                intItem = REA.GetInt32("HDoc_DR2_Cat")

                intGrupo = Val(vbNullString & REA.GetInt32("HDoc_DR1_Cat"))
                intItem = Val(vbNullString & REA.GetInt32("HDoc_DR2_Cat"))

                'Documento Relacionado
                celdaCatMovimiento.Text = REA.GetInt32("HDoc_Doc_Cat")
                año = REA.GetInt32("HDoc_Pro_DAno")
                numero = REA.GetInt32("HDoc_Pro_DNum")
                Catalogo = REA.GetInt32("HDoc_Pro_DCat")


                'Estado del documento
                casillaAnulada.Checked = IIf(REA.GetInt32("HDoc_Doc_Status") = IDX_ANULADO, True, False)
                casillaEstado.Checked = IIf(REA.GetInt32("HDoc_Doc_Status") = vbEmpty, False, IIf(REA.GetInt32("HDoc_Doc_Status") = IDX_ANULADO, False, True))
                checkSecreto.Checked = IIf(REA.GetInt32("secreto") = vbEmpty, False, True)


                'Cargar el detalle del cheque o Fcaturas
                Tipo = dgMovimientos.SelectedCells(1).Value
                Categoria = dgMovimientos.SelectedCells(12).Value
                Select Case Tipo
                    Case intCheque, intDebito

                        CargarDetalle(Tipo, Categoria)

                        If Categoria = 0 Then

                            'celdaIDCajas.Enabled = 
                        ElseIf Categoria = 1 Then
                            celdaBeneficiario.Text = celdaNomEmisor.Text
                            celdaDiferencia.Text = REA.GetDouble("HDoc_RF2_Dbl")
                            celdaCuentaCont.Text = Trim(vbNullString & REA.GetString("HDoc_RF2_Cod"))

                            'Cargar Datos de Caja
                            strSQL2 = vbNullString
                            strSQL2 &= "SELECT c.BCta_Num ID, e.HDoc_Doc_Ano Año, e.HDoc_Doc_Num Numero, c.BCta_Nom_Cue Caja, e.HDoc_Doc_Mon Divisa, e.HDoc_Doc_TC Tasa, IFNULL(e.HDoc_DR1_Num,0) Documento, e.HDoc_Doc_Fec Fecha, cm.cat_ext"
                            strSQL2 &= " Moneda, e.HDoc_RF2_Dbl Monto, e.HDoc_RF1_Dbl Bruto, e.HDoc_DR1_Fec Inicio, e.HDoc_DR2_Fec Fin"
                            strSQL2 &= "     FROM Dcmtos_HDR e"
                            strSQL2 &= "         LEFT JOIN CtasBcos c ON c.BCta_Sis_Emp=e.HDoc_Sis_Emp AND c.BCta_Num=e.HDoc_DR1_Cat"
                            strSQL2 &= "            LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=e.HDoc_Doc_Mon"
                            strSQL2 &= "         WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={catalogo} AND e.HDoc_Doc_Ano={año} AND e.HDoc_Doc_Num={numero}"
                            strSQL2 &= "      LIMIT 1"

                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{año}", año)
                            strSQL2 = Replace(strSQL2, "{numero}", numero)
                            strSQL2 = Replace(strSQL2, "{catalogo}", Catalogo)

                            MyCnn.CONECTAR = strConexion

                            COM2 = New MySqlCommand(strSQL2, CON)
                            REA2 = COM.ExecuteReader

                            If REA.HasRows Then
                                celdaCajas.Text = REA2.GetString("Caja")
                                celdaIDCajas.Text = REA2.GetInt32("ID")

                                strTemp = "Liquidación No. " & REA2.GetString("Documento") & Space(4) &
                                          "Fecha: " & REA2.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & vbCrLf &
                                          "Periodo: " & REA2.GetDateTime("Inicio") & "-" & REA2.GetDateTime("Fin") &
                                          "Monto: " & REA2.GetString("Moneda") & ":" & REA2.GetDouble("Monto") & IIf(REA2.GetDouble("Bruto") = REA2.GetDouble("Monto"), vbNullString, " / (TOTAL " & REA2.GetDouble("Bruto").ToString(FORMATO_MONEDA))
                                celdaCajaInfo.Text = strTemp

                                intMonCaja = REA2.GetInt32("Divisa")
                            ElseIf intItem = 0 Then
                                MsgBox("No se encuentra la liquidación Asociada", vbCritical, "Aviso")
                            Else


                            End If
                        End If

                End Select

                If Me.Tag = "nuevo" Then
                    'Nuevo Cheque
                    If (celdaCatMovimiento.Text = intCheque) Then
                        NuevoCheque()
                    End If
                End If

                'Convierte el total en Letras
                celdaTotaLetras.Text = cFunciones.ALetras(celdaMonto.Text)

                'CargarPresupuesto()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalle(ByVal Tipo As Integer, ByVal Grupo As Integer)
        'Carga los datos del documento actual
        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Try
            'Tipo = dgMovimientos.SelectedCells(1).Value
            Select Case Tipo
                Case intDeposito
                    'Depósito -> Cargar cheques depositados
                    strSql = "SELECT * "
                    strSql &= "  FROM Dcmtos_DTL "
                    strSql &= "    WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {tipo} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {numero} AND (DDoc_RF2_Cod = 'CHEQUE') "
                    strSql &= "      ORDER BY DDoc_Doc_Lin"
                Case intCheque, intDebito
                    'Cheque -> Cargar facturas de compra / retenciones ISR a proveedores y otros (cuenta)
                    strSql &= "SELECT d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin, IFNULL(d.DDoc_Prd_Cod,0) DDoc_Prd_Cod, IFNULL(DDoc_Prd_PNr,0) IDCCosto, IFNULL(d.DDoc_Prd_Des,0) DDoc_Prd_Des, d.DDoc_Prd_UM, IFNULL(d.DDoc_Prd_PUQ,0) DDoc_Prd_PUQ, d.DDoc_Prd_DSP, d.DDoc_Prd_DSQ, d.DDoc_Prd_NET, d.DDoc_Prd_QTY, d.DDoc_RF1_Num, d. DDoc_RF1_Cod, d.DDoc_RF1_Txt, d.DDoc_RF1_Fec, d.DDoc_RF1_Dbl, d.DDoc_RF2_Num, d.DDoc_RF2_Cod, d.DDoc_RF2_Txt, d.DDoc_RF2_Fec, d.DDoc_RF2_Dbl, d.DDoc_RF3_Num,IFNULL(d.DDoc_RF3_Txt,0) DDoc_RF3_Txt,d.DDoc_RF3_Dbl, d.DDoc_Prd_Fob, d.DDoc_Prd_Cif, d.DDoc_Prd_Ref, COALESCE(e.HDoc_Doc_Mon,0) moneda, COALESCE(e.HDoc_Doc_TC,0) tasa,IFNULL(c.poliza,0) Poliza, IFNULL(co.cost_nombre,'') cost_nombre"
                    strSql &= "   FROM Dcmtos_DTL d "
                    strSql &= "      LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_RF1_Num AND e.HDoc_Doc_Ano = d.DDoc_RF2_Num AND e.HDoc_Doc_Num = d.DDoc_RF3_Num"
                    strSql &= "          LEFT JOIN {conta}.polizas c ON c.empresa = e.HDoc_Sis_Emp AND c.ref_tipo = e.HDoc_Doc_Cat AND c.ref_ciclo = e.HDoc_Doc_Ano AND c.ref_numero = e.HDoc_Doc_Num"
                    strSql &= "      LEFT JOIN {conta}.costos co ON co.cost_num = d.DDoc_Prd_PNr"
                    strSql &= "   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {tipo} AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero} AND NOT(d.DDoc_RF2_Cod = '{venta}') "
                    strSql &= " ORDER BY d.DDoc_Doc_Lin"
            End Select
            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{conta}", cFunciones.ContaEmpresa)
            strSql = Replace(strSql, "{tipo}", dgMovimientos.SelectedCells(1).Value)
            strSql = Replace(strSql, "{año}", Val(celdaAno.Text))
            strSql = Replace(strSql, "{numero}", dgMovimientos.SelectedCells(3).Value)
            strSql = Replace(strSql, "{venta}", IIf(Grupo = eGroup.Caja, "CAJA", "VENTA"))

            Select Case Tipo
                Case intCheque, intDebito
                    'Factura / Retencion / Cuenta
                    MyCnn.CONECTAR = strConexion

                    COM = New MySqlCommand(strSql, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then

                        dgComprs.Rows.Clear()

                        Do While REA.Read
                            Dim strFila As String = STR_VACIO

                            strFila = REA.GetInt32("DDoc_RF2_Num") & "|"
                            strFila &= IIf(REA.GetInt32("DDoc_RF1_Num") = vbEmpty, vbEmpty, Val(vbNullString & REA.GetInt32("DDoc_RF3_Num"))) & "|"
                            strFila &= Val(REA.GetInt32("moneda")) & "|"
                            strFila &= IIf(REA.GetDouble("tasa") = vbEmpty, REA.GetInt32("DDoc_RF3_Num"), REA.GetInt32("tasa")) & "|"
                            strFila &= REA.GetString("DDoc_RF1_Txt") & "|"
                            strFila &= REA.GetDouble("DDoc_RF1_Dbl").ToString(FORMATO_MONEDA) & "|"
                            strFila &= REA.GetString("DDoc_Prd_Ref") & "|"
                            strFila &= REA.GetInt32("DDoc_Prd_Fob") & "|"
                            strFila &= REA.GetInt32("DDoc_Prd_Cif") & "|"
                            strFila &= REA.GetInt32("DDoc_RF1_Num") & "|"
                            strFila &= REA.GetString("IDCCosto") & "|"
                            strFila &= REA.GetString("cost_nombre") & "|"
                            strFila &= ("0") & "|"
                            strFila &= REA.GetInt32("DDoc_Doc_Lin") & "|"
                            strFila &= REA.GetString("DDoc_RF2_Cod")
                            cFunciones.AgregarFila(dgComprs, strFila)
                        Loop
                    End If

                Case intDeposito
                    'Cheque
                    MyCnn.CONECTAR = strConexion

                    COM = New MySqlCommand(strSql, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then

                        dgComprs.Rows.Clear()

                        Do While REA.Read
                            Dim strFila As String = STR_VACIO
                            strFila = FORMATO_MYSQL(REA.GetDateTime("DDoc_RF1_Fec").ToString) & "|"
                            strFila &= REA.GetString("DDoc_RF1_Txt") & "|"
                            strFila &= REA.GetInt32("DDoc_RF1_Cod") & "|"
                            strFila &= REA.GetDouble("DDoc_RF1_Dbl")
                        Loop
                    End If
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function LineaMax(ByVal cat As Integer, ByVal ano As Integer, ByVal numero As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim LineMax As Integer
        Dim COM As New MySqlCommand

        strSQL = " SELECT IFNULL(MAX(DDoc_Doc_Lin),0) +1"
        strSQL &= "  FROM Dcmtos_DTL"
        strSQL &= "     WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {tipo} AND DDoc_Doc_Ano = {año} AND DDoc_Doc_Num = {numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", cat)
        strSQL = Replace(strSQL, "{año}", ano)
        strSQL = Replace(strSQL, "{numero}", numero)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        LineMax = COM.ExecuteScalar

        Return LineMax
    End Function

    ''Query que carga las Detalle del Documento
    'Public Sub queryInstDespacho(ByVal intaño As Integer, ByVal intnumero As Integer)
    '    Dim COM As MySqlCommand
    '    Dim REA As MySqlDataReader
    '    Dim strSQL As String = STR_VACIO

    '    strSQL = CargarDetalle(1, 1)

    '    Try

    '        MyCnn.CONECTAR = strConexion

    '        COM = New MySqlCommand(strSQL, CON)
    '        REA = COM.ExecuteReader

    '        If REA.HasRows Then

    '            dgComprs.Rows.Clear()

    '            Do While REA.Read
    '                Dim strFila As String = STR_VACIO


    '                strFila = REA.GetInt32("HDoc_Doc_Cat") & "|" & REA.GetString("HDoc_Doc_Ano") & "|" & REA.GetInt32("HDoc_Doc_Num") & "|" & REA.GetDateTime("HDoc_Doc_Fec") & "|" & REA.GetString("HDoc_Usuario") & "|" & REA.GetString("HDoc_DR1_Num")


    '                cFunciones.AgregarFila(dgComprs, strFila)


    '                'dgDatos.AlternatingRowsDefaultCellStyle.BackColor = Color.AntiqueWhite

    '            Loop

    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try

    'End Sub

    Private Sub GuardarNumero(ByVal cheq As Integer)
        'Guarda el último número de la chequera actual
        Dim intID As Long
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim strCondicion As String = STR_VACIO
        'Dim strCampos As String = STR_VACIO

        strSQL = " SELECT "
        If intID = NO_FILA Then
            strSQL &= " (IFNULL(MAX(cat_num),0) + 1) Id"
        End If
        strSQL &= "   FROM Catalogos"
        strSQL &= "   WHERE p.pro_sisemp = {empresa}"

        strCondicion = " Catalogos SET cat_num={numero}, cat_clase='cheques', cat_clave='Max_Num', cat_desc={cheque}, cat_sist={cuenta}"
        strSQL = Replace(strSQL, "{numero}", intID)
        strSQL = Replace(strSQL, "{cheque}", strSQL(celdaChequera.Text))
        strSQL = Replace(strSQL, "{cuenta}", strSQL(intCuenta))
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        If intID = NO_FILA Then
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intID = COM.ExecuteScalar
        End If

    End Sub

    'Private Sub CrearOpciones_TipoTransaccion(ByVal lstGrupo As String)
    '    Dim arrayOpciones() As String
    '    Dim intTop As Integer = 10
    '    Try
    '        'panelTipoTransaccion.Controls.Clear()
    '        ' Me.Text = strTitulo
    '        celdaMensaje.Text = strMensaje
    '        If lstGrupo.Length > 0 Then
    '            arrayOpciones = lstGrupo.Split("|".ToCharArray)
    '            For i As Integer = INT_CERO To arrayOpciones.Length - 1
    '                Dim RB As New RadioButton
    '                RB.Top = intTop + 26 * i
    '                RB.Left = 50
    '                RB.Name = i
    '                RB.Width = arrayOpciones(i).Length + 100
    '                RB.Text = arrayOpciones(i)
    '                RB.Parent = Me.panelTipoTransaccion
    '                If i = INT_CERO Then
    '                    RB.Checked = True
    '                End If
    '            Next
    '        Else
    '            MsgBox("frmOpcion: No se indico ninguna opcion que cargar")
    '            Exit Sub
    '        End If
    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    Private Function Funcionamiento_TipoTransaccion() As String
        Dim strResult As String = STR_VACIO

        For Each r As RadioButton In Me.panelTipoTransaccion.Controls
            If r.Checked = True Then
                strResult = r.Text
                Exit For
            End If
        Next
        Return strResult
    End Function

    Private Function SQLParametroCG()
        Dim strSQL As String = STR_VACIO
        Dim cfun As New clsFunciones

        strSQL = vbNullString

        strSQL &= "SELECT valor"
        strSQL &= " FROM {conta}.parametros_empresa"
        strSQL &= "   WHERE empresa = '{empresa}' AND parametro = 27"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)

        Return strSQL
    End Function

    'Procedimiento Propio de Bancos
    Private Sub Redimencionar(ByVal Tipo As Integer, ByVal Opcion As String)
        Dim BarraName As String
        Select Case Tipo
            Case intDeposito
                Select Case Opcion
                    Case 0

                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        'botonCentroCostos.Visible = False
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Location = New System.Drawing.Point(660, 10)
                        panelResuDeposito.Visible = True
                        panelResuDeposito.Location = New System.Drawing.Point(660, 200)
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            panelDocumentoDetalle.Visible = True
                            dgComprs.Visible = False
                            dgVentas.Visible = True
                            dgVentas.Dock = DockStyle.Fill
                            BarraName = "Suppliers Invoices"
                            BarraTitulo2.CambiarTitulo(BarraName)
                        End If
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = True
                            panelProveedores.Dock = DockStyle.Fill
                            rbGasto.Enabled = False
                            rbPago.Enabled = False
                            rbImpuesto.Enabled = False
                        End If
                        ' botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = True
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        'panelAdd.Visible = True
                        'panelAdd.Dock = DockStyle.None
                        'panelAdd.Location = New System.Drawing.Point(300, 640)
                        gbDatosProveedor.Text = "Data Provider"
                        strTitulo = "Providers"
                        strCampos = " pro_codigo ID, pro_proveedor Nombre "
                        strTabla = "  Proveedores "
                        strFiltroText = " Enter The Name Of The Providers To Filter"
                        strFiltro = "  pro_proveedor "
                        strCondicion = strCondicion
                        strOrdenamiento = "  pro_proveedor "
                        strLimite = 20
                        'CrearOpciones_TipoTransaccion(IGS_PROVEEDOR)
                        ResetVista3()
                        celdaMoned.Text = Val(celdaMonedaName.Text)
                        celdaGastoCom.Visible = True
                        etiquetaGastosCom.Visible = True

                    Case 1
                        celdaCajas.Text = STR_VACIO
                        celdaBeneficiario.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        'botonCentroCostos.Visible = False
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            dgComprs.Visible = False
                            dgVentas.Visible = True
                            dgVentas.Dock = DockStyle.Fill
                            BarraName = "Cheques de Otros Bancos"
                            BarraTitulo2.CambiarTitulo(BarraName)
                        End If
                        panelCajaChicaLiq.Visible = True
                        panelCajaChicaLiq.Location = New System.Drawing.Point(660, 10)
                        panelCajaChicaLiq.Dock = DockStyle.None
                        panelCajChiViatics.Visible = False
                        Panel6.Visible = False
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelEmpleado.Visible = False
                            panelTransferencia.Visible = False
                            panelCajaChi.Visible = True
                            panelCajaChi.Dock = DockStyle.Fill
                            rbLiquidacion.Enabled = False
                            rbApertura.Enabled = False
                            rbCobro.Visible = False
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = False
                        panelDatosProveedores.Dock = DockStyle.None
                        strTitulo = "Petty Cash / Settlement"
                        strCampos = " BCta_Num ID, CAST(CONCAT(BCta_Nom_Cue, IF(BCta_Tipo=2,' (VIATICOS)',''),' - N° ', CAST(LPAD(BCta_Num_Cue,4,'0') AS CHAR)) AS CHAR) Nombre"
                        strTabla = "    CtasBcos    "
                        strFiltroText = " Enter The Name Of The Account To Filter"
                        strFiltro = "   BCta_Nom_Cue "
                        strCondicion = strCondicion
                        strOrdenamiento = "     BCta_Tipo, BCta_Nom_Cue"
                        strTipoOrdenamiento = ""
                        strLimite = 20
                        'CrearOpciones_TipoTransaccion(IGS_LIQUIDACION)
                        ResetVista3()
                    Case 2
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        'botonCentroCostos.Visible = False
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Location = New System.Drawing.Point(660, 10)
                        panelResuDeposito.Visible = True
                        panelResuDeposito.Location = New System.Drawing.Point(660, 200)
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            dgComprs.Visible = False
                            dgVentas.Visible = True
                            dgVentas.Dock = DockStyle.Fill
                            BarraName = "Cheques de Otros Bancos"
                            BarraTitulo2.CambiarTitulo(BarraName)
                        End If
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Visible = False
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 170)
                            rbAnticipoSCompras.Visible = False
                            rbGasto.Visible = False
                            rbPago.Visible = False
                            rbImpuesto.Visible = False
                            rbImpuesto.Enabled = False
                        End If
                        ' botonFecha.Visible = True
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.Fill
                        panelFacturas.Visible = True
                        panelFacturas.Dock = DockStyle.None
                        panelFacturas.Location = New System.Drawing.Point(660, 365)
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = True
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Customer Data "
                        strTitulo = "Clients"
                        strCampos = " cli_codigo ID, cli_cliente Nombre "
                        strTabla = "    Clientes "
                        strFiltroText = " Enter The Name Of The Clients To Filter"
                        strFiltro = "   cli_cliente "
                        strCondicion = "    cli_sisemp= {empresa} "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " cli_cliente "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_CLIENTE)
                        ResetVista3()
                        celdaMoned.Text = Val(celdaMonedaName.Text)
                    Case 3
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        'botonCentroCostos.Visible = False
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            dgComprs.Visible = False
                            dgVentas.Visible = True
                            dgVentas.Dock = DockStyle.Fill
                            BarraName = "Cheques de Otros Bancos"
                            BarraTitulo2.CambiarTitulo(BarraName)
                        End If
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelCajaChi.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelEmpleado.Visible = True
                            panelEmpleado.Dock = DockStyle.Fill
                            rbAntPrestamo.Enabled = False
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = True
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Employee Data "
                        strTitulo = "Employees"
                        strCampos = " em_codigo ID, em_descripcion Nombre "
                        strTabla = "    Empleados "
                        strFiltroText = " Enter The Name Of The Employees To Filter"
                        strFiltro = "   em_descripcion "
                        strCondicion = "    em_empresa= {empresa} "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " em_descripcion "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_EMPLEADO)
                        ResetVista3()

                    Case 4

                    Case 5
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        'botonCentroCostos.Visible = False
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            panelDocumentoDetalle.Visible = False
                            panelCompras.Visible = False
                            panelBotonesCompras.Visible = False
                            dgComprs.Visible = False
                            dgVentas.Visible = False
                            BarraTitulo2.Visible = False
                            botonAgregar.Visible = False
                            botonQuitar.Visible = False
                        End If
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelCajaChi.Visible = False
                            panelEmpleado.Visible = False
                            panelTransferencia.Visible = False
                            panelTransferencia.Visible = True
                            panelTransferencia.Dock = DockStyle.Fill
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = True
                        panelOtraCuenta.Dock = DockStyle.None
                        panelOtraCuenta.Location = New System.Drawing.Point(660, 175)
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Bank Account "
                        strTitulo = "Bank Account"
                        strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        strFiltro = "   BCta_Des_Cue "
                        strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = "     BCta_Des_Cue "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        ResetVista3()

                    Case 6
                End Select

            Case intCredito
                Select Case Opcion

                    Case 0

                    Case 1

                    Case 2
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        EtiquetaAnticipo.Visible = False
                        'botonCentroCostos.Visible = False
                        panelDocumentoDetalle.Visible = False
                        panelDocumentoDetalle.Dock = DockStyle.None
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 170)
                            panelProveedores.Visible = False
                            panelEmpleado.Visible = False
                            panelTransferencia.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelCajaChi.Visible = True
                            panelCajaChi.Dock = DockStyle.Fill
                            rbLiquidacion.Visible = False
                            rbApertura.Visible = False
                            rbAntViaticos.Visible = False
                            rbCierre.Visible = False
                            rbCobro.Visible = True
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        panelFacturas.Visible = True
                        panelFacturas.Dock = DockStyle.None
                        panelFacturas.Location = New System.Drawing.Point(660, 370)
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        'panelTipTran2.Location = New System.Drawing.Point(405, 160)
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Customer Data "
                        strTitulo = "Clients"
                        strCampos = " cli_codigo ID, cli_cliente Nombre "
                        strTabla = "    Clientes "
                        strFiltroText = " Enter The Name Of The Clients To Filter"
                        strFiltro = "   cli_cliente "
                        strCondicion = "    cli_sisemp= {empresa} "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " cli_cliente "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_CLIENTE)
                        ResetVista3()

                    Case 3

                    Case 4

                    Case 5
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = False
                        'botonCentroCostos.Visible = False
                        panelDocumentoDetalle.Visible = False
                        panelDocumentoDetalle.Dock = DockStyle.None
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelCajaChi.Visible = False
                            panelEmpleado.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelTransferencia.Visible = True
                            panelTransferencia.Dock = DockStyle.Fill
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = True
                        panelOtraCuenta.Location = New System.Drawing.Point(660, 170)
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Bank Account "
                        strTitulo = "Bank Account"
                        strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        strFiltro = "   BCta_Des_Cue "
                        strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " BCta_Des_Cue "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        ResetVista3()

                    Case 6
                End Select


            Case intCheque

                Select Case Opcion

                    Case 0
                        celdaGrupo.Text = 0
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        'celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        'etiquetaCentroCostos.Visible = True
                        'botonCentroCostos.Visible = True
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            panelDocumentoDetalle.Visible = True
                            dgComprs.Visible = True
                            dgVentas.Visible = False
                            dgComprs.Dock = DockStyle.Fill
                            BarraName = "Facturas de Proveedores"
                            BarraTitulo2.CambiarTitulo(BarraName)
                        End If
                        celdaAnticiposSCompras.Visible = True
                        EtiquetaAnticipo.Visible = True
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelTransferencia.Visible = False
                            panelEmpleado.Visible = False
                            panelCajaChi.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelProveedores.Visible = True
                            panelProveedores.Dock = DockStyle.Fill
                            rbImpuesto.Enabled = False
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Data Provider"
                        strTitulo = "Providers"
                        strCampos = " pro_codigo ID, pro_proveedor Nombre "
                        strTabla = "    Proveedores "
                        strFiltroText = " Enter The Name Of The Providers To Filter"
                        strFiltro = "   pro_proveedor "
                        strCondicion = strCondicion
                        strOrdenamiento = " pro_proveedor "
                        strLimite = 20
                        'CrearOpciones_TipoTransaccion(IGS_PROVEEDOR)
                        celdaDocumento.Text = "Cheque"
                        celdaIDDocumento.Text = 244
                        ResetVista3()

                    Case 1
                        celdaGrupo.Text = 1
                        celdaCajas.Text = STR_VACIO
                        celdaBeneficiario.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = True
                        'botonCentroCostos.Visible = True
                        If panelDocumentoDetalle.Visible = False Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            panelDocumentoDetalle.Visible = True
                            dgComprs.Visible = False
                            dgVentas.Visible = True
                            dgVentas.Dock = DockStyle.Fill
                            'BarraName
                            BarraTitulo2.Visible = False
                        End If
                        panelCajaChicaLiq.Visible = True
                        panelCajaChicaLiq.Location = New System.Drawing.Point(660, 10)
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelTransferencia.Visible = False
                            panelEmpleado.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelCajaChi.Visible = True
                            panelCajaChi.Dock = DockStyle.Fill
                            rbCierre.Enabled = False
                            rbCobro.Visible = False
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = False
                        panelDatosProveedores.Dock = DockStyle.None
                        strTitulo = "Petty Cash / Settlement"
                        strCampos = " BCta_Num ID, CAST(CONCAT(BCta_Nom_Cue, IF(BCta_Tipo=2,' (VIATICOS)',''),' - N° ', CAST(LPAD(BCta_Num_Cue,4,'0') AS CHAR)) AS CHAR) Nombre"
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Account To Filter"
                        strFiltro = " BCta_Nom_Cue "
                        strCondicion = strCondicion
                        strOrdenamiento = " BCta_Tipo, BCta_Nom_Cue "
                        strTipoOrdenamiento = ""
                        strLimite = 20
                        'CrearOpciones_TipoTransaccion(IGS_LIQUIDACION)
                        ResetVista3()

                    Case 2

                    Case 3
                        celdaGrupo.Text = 3
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = True
                        'botonCentroCostos.Visible = True
                        EtiquetaAnticipo.Visible = False
                        celdaAnticiposSCompras.Visible = False
                        panelDocumentoDetalle.Visible = False
                        panelDocumentoDetalle.Dock = DockStyle.None
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 165)
                            panelTransferencia.Visible = False
                            panelProveedores.Visible = False
                            panelCajaChi.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelEmpleado.Visible = True
                            panelEmpleado.Dock = DockStyle.Fill
                            rbDevolucion.Visible = False

                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        panelDatosProveedores.Location = New System.Drawing.Point(660, 5)
                        gbDatosProveedor.Text = " Employee Data"
                        strTitulo = "Employees"
                        strCampos = " em_codigo ID, em_descripcion Nombre "
                        strTabla = "    Empleados "
                        strFiltroText = " Enter The Name Of The Employees To Filter"
                        strFiltro = " em_descripcion "
                        strCondicion = "    em_empresa= {empresa} "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " em_descripcion "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_EMPLEADO)
                        ResetVista3()

                    Case 4
                        'celdaGrupo.Text = 4
                        'BarraTitulo1.CambiarTitulo("DEPOSITS")
                        'Panel_Cuenta.Visible = False
                        'Panel_Cuenta.Dock = DockStyle.None
                        'panelDocumento.Visible = True
                        'panelDocumento.Dock = DockStyle.Fill
                        'celdaAnticiposSCompras.Visible = True
                        ''celdaIDCentroCostos.Visible = False
                        'etiquetaCentroCostos.Visible = True
                        ''botonCentroCostos.Visible = True
                        'panelDocumentoDetalle.Visible = True
                        'panelDocumentoDetalle.Dock = DockStyle.None
                        'panelCajaChicaLiq.Visible = False
                        'panelCajaChicaLiq.Dock = DockStyle.None
                        'If panelTipoTransaccion.Visible = True Then
                        '    panelTipoTransaccion.Dock = DockStyle.None
                        '    panelTipoTransaccion.Location = New System.Drawing.Point(400, 130)
                        '    rbAnticipoSCompras.Visible = True
                        '    rbGasto.Visible = True
                        '    rbPago.Visible = True
                        '    rbImpuesto.Visible = True
                        '    rbImpuesto.Enabled = False
                        'End If
                        ''botonFecha.Visible = False
                        'panelFacturasNoteD.Visible = False
                        'panelFacturasNoteD.Dock = DockStyle.None
                        ''panelTipTran2.Visible = True
                        ''panelTipTran2.Dock = DockStyle.Fill
                        'panelCajChiViatics.Visible = True
                        'panelCajChiViatics.Dock = DockStyle.None
                        'BarraTitulo5.CambiarTitulo("Sheet")
                        'panelCajChiViatics.Location = New System.Drawing.Point(405, 0)
                        'panelFacturas.Visible = False
                        'panelFacturas.Dock = DockStyle.None
                        'panelRegreso.Visible = False
                        'panelRegreso.Dock = DockStyle.None
                        'panelOtraCuenta.Visible = False
                        'panelOtraCuenta.Dock = DockStyle.None
                        'panelCajaChica.Visible = False
                        'panelCajaChica.Dock = DockStyle.None
                        'panelLIsta.Visible = False
                        'panelLIsta.Dock = DockStyle.None
                        'panelResuDeposito.Visible = False
                        'panelResuDeposito.Dock = DockStyle.None
                        'panelDatosProveedores.Visible = False
                        'panelDatosProveedores.Dock = DockStyle.None
                        ''CrearOpciones_TipoTransaccion(IGS_PLANILLA)
                        'ResetVista3()

                    Case 5
                        celdaGrupo.Text = 5
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = True
                        'botonCentroCostos.Visible = True
                        panelDocumentoDetalle.Visible = False
                        panelDocumentoDetalle.Dock = DockStyle.None
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelEmpleado.Visible = False
                            panelCajaChi.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelTransferencia.Visible = True
                            panelTransferencia.Dock = DockStyle.Fill
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = True
                        panelOtraCuenta.Location = New System.Drawing.Point(660, 170)
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Bank Account "
                        strTitulo = "Bank Account"
                        strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        strFiltro = " BCta_Des_Cue "
                        strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " BCta_Des_Cue "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        ResetVista3()

                    Case 6
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        panelDocumentoDetalle.Visible = False
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelTransferencia.Visible = False
                            panelEmpleado.Visible = False
                            panelCajaChi.Visible = False
                            panelOtrosImpuestos.Visible = True
                            panelOtrosImpuestos.Dock = DockStyle.Fill
                            rbIVA.Visible = True
                            rbRetensiones.Visible = True
                            rbAsalariados.Visible = True
                            rbAsalariados.Enabled = False
                            rbPagoMensual.Visible = True
                        End If
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Location = New System.Drawing.Point(660, 170)
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Bank Account "
                        strTitulo = "Bank Account"
                        strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        strFiltro = " BCta_Des_Cue "
                        strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " BCta_Des_Cue "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        ResetVista3()

                End Select


            Case intDebito
                Select Case Opcion

                    Case 0
                        celdaGrupo.Text = 0
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DIBIT NOTE")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        'etiquetaCentroCostos.Visible = True
                        'botonCentroCostos.Visible = True
                        EtiquetaAnticipo.Visible = True
                        If panelDocumentoDetalle.Visible = True Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            panelDocumentoDetalle.Visible = True
                            dgComprs.Visible = True
                            dgVentas.Visible = False
                            dgComprs.Dock = DockStyle.Fill
                            BarraName = "Facturas de Proveedores"
                            BarraTitulo2.CambiarTitulo(BarraName)
                        End If
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelTransferencia.Visible = False
                            panelCajaChi.Visible = False
                            panelEmpleado.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelProveedores.Visible = True
                            panelProveedores.Dock = DockStyle.Fill
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Data Provider"
                        strTitulo = "Providers"
                        strCampos = " pro_codigo ID, pro_proveedor Nombre "
                        strTabla = "    Proveedores "
                        strFiltroText = " Enter The Name Of The Providers To Filter"
                        strFiltro = "   pro_proveedor "
                        strCondicion = strCondicion
                        strOrdenamiento = " pro_proveedor "
                        strLimite = 20
                        'CrearOpciones_TipoTransaccion(IGS_PROVEEDOR)
                        celdaDocumento.Text = "Nota de Debito"
                        celdaIDDocumento.Text = 244
                        ResetVista3()


                    Case 1
                        celdaCajas.Text = STR_VACIO
                        celdaBeneficiario.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = True
                        EtiquetaAnticipo.Visible = False
                        'botonCentroCostos.Visible = True
                        If panelDocumentoDetalle.Visible = False Then
                            panelDocumentoDetalle.Dock = DockStyle.None
                            panelDocumentoDetalle.Visible = True
                            dgComprs.Visible = False
                            dgVentas.Visible = True
                            dgVentas.Dock = DockStyle.Fill
                            'BarraName = "Facturas de Proveedores"
                            BarraTitulo2.Visible = False
                        End If
                        panelCajaChicaLiq.Visible = True
                        panelCajaChicaLiq.Location = New System.Drawing.Point(660, 8)
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelEmpleado.Visible = False
                            panelTransferencia.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelCajaChi.Visible = True
                            panelCajaChi.Dock = DockStyle.Fill
                            rbApertura.Enabled = False
                            rbAntViaticos.Enabled = False
                            rbCierre.Enabled = False
                            rbCobro.Visible = False
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = False
                        panelDatosProveedores.Dock = DockStyle.None
                        strTitulo = "Petty Cash / Settlement"
                        strCampos = " BCta_Num ID, CAST(CONCAT(BCta_Nom_Cue, IF(BCta_Tipo=2,' (VIATICOS)',''),' - N° ', CAST(LPAD(BCta_Num_Cue,4,'0') AS CHAR)) AS CHAR) Nombre"
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Account To Filter"
                        strFiltro = " BCta_Nom_Cue "
                        strCondicion = strCondicion
                        strOrdenamiento = " BCta_Tipo, BCta_Nom_Cue "
                        strTipoOrdenamiento = ""
                        strLimite = 20
                        'CrearOpciones_TipoTransaccion(IGS_LIQUIDACION)
                        ResetVista3()

                    Case 2

                    Case 3
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = True
                        'celdaIDCentroCostos.Visible = False
                        etiquetaCentroCostos.Visible = True
                        'botonCentroCostos.Visible = True
                        panelDocumentoDetalle.Visible = False
                        panelDocumentoDetalle.Dock = DockStyle.None
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 170)
                            panelProveedores.Visible = False
                            panelTransferencia.Visible = False
                            panelCajaChi.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelEmpleado.Visible = True
                            panelEmpleado.Dock = DockStyle.Fill
                            rbDevolucion.Visible = False
                        End If
                        'botonFecha.Visible = False
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        'panelTipTran2.Visible = True
                        'panelTipTran2.Dock = DockStyle.Fill
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Employee Data "
                        strTitulo = "Employees"
                        strCampos = " em_codigo ID, em_descripcion Nombre "
                        strTabla = "    Empleados "
                        strFiltroText = " Enter The Name Of The Employees To Filter"
                        strFiltro = " em_descripcion "
                        strCondicion = "    em_empresa= {empresa} "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " em_descripcion "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_EMPLEADO)
                        ResetVista3()

                    Case 4
                        'celdaNomEmisor.Text = STR_VACIO
                        'celdaDatosProvee.Text = STR_VACIO
                        'BarraTitulo1.CambiarTitulo("DEPOSITS")
                        'Panel_Cuenta.Visible = False
                        'Panel_Cuenta.Dock = DockStyle.None
                        'panelDocumento.Visible = True
                        'panelDocumento.Dock = DockStyle.Fill
                        'celdaAnticiposSCompras.Visible = False
                        ''celdaIDCentroCostos.Visible = False
                        ''etiquetaCentroCostos.Visible = True
                        ''botonCentroCostos.Visible = True
                        'If panelDocumentoDetalle.Visible = True Then
                        '    panelDocumentoDetalle.Dock = DockStyle.None
                        '    panelDocumentoDetalle.Size = New Size(1300, 370)
                        '    panelCompras.Size = New Size(1000, 220)
                        '    panelDocumentoDetalle.Visible = True
                        '    dgComprs.Visible = False
                        '    dgVentas.Visible = True
                        '    dgVentas.Dock = DockStyle.Fill
                        '    'BarraName = "Facturas de Proveedores"
                        '    BarraTitulo2.Visible = False
                        'End If
                        'panelCajaChicaLiq.Visible = False
                        'panelCajaChicaLiq.Dock = DockStyle.None
                        'If panelTipoTransaccion.Visible = True Then
                        '    panelTipoTransaccion.Dock = DockStyle.None
                        '    panelTipoTransaccion.Location = New System.Drawing.Point(660, 155)
                        '    rbAnticipoSCompras.Visible = True
                        '    rbGasto.Visible = True
                        '    rbPago.Visible = True
                        '    rbImpuesto.Visible = True
                        '    rbImpuesto.Enabled = False
                        'End If
                        ''botonFecha.Visible = False
                        'panelFacturasNoteD.Visible = False
                        'panelFacturasNoteD.Dock = DockStyle.None
                        'panelCajChiViatics.Visible = False
                        'panelCajChiViatics.Dock = DockStyle.None
                        'panelFacturas.Visible = False
                        'panelFacturas.Dock = DockStyle.None
                        'panelRegreso.Visible = False
                        'panelRegreso.Dock = DockStyle.None
                        'panelOtraCuenta.Visible = False
                        'panelOtraCuenta.Location = New System.Drawing.Point(405, 130)
                        'panelOtraCuenta.Dock = DockStyle.None
                        'panelCajaChica.Visible = False
                        'panelCajaChica.Dock = DockStyle.None
                        'panelLIsta.Visible = False
                        'panelLIsta.Dock = DockStyle.None
                        'panelResuDeposito.Visible = False
                        'panelResuDeposito.Dock = DockStyle.None
                        'panelDatosProveedores.Visible = False
                        'panelDatosProveedores.Dock = DockStyle.None
                        'gbDatosProveedor.Text = "Bank Account "
                        'strTitulo = "Bank Account"
                        'strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        'strTabla = "    CtasBcos "
                        'strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        'strFiltro = " BCta_Des_Cue "
                        'strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        'strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        'strOrdenamiento = " BCta_Des_Cue "
                        'strLimite = 20
                        'strTipoOrdenamiento = ""
                        ''CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        'ResetVista3()

                    Case 5
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        panelDocumentoDetalle.Visible = False
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelCajaChi.Visible = False
                            panelEmpleado.Visible = False
                            panelOtrosImpuestos.Visible = False
                            panelTransferencia.Visible = True
                            panelTransferencia.Dock = DockStyle.Fill
                        End If
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = True
                        panelOtraCuenta.Location = New System.Drawing.Point(660, 170)
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Bank Account "
                        strTitulo = "Bank Account"
                        strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        strFiltro = " BCta_Des_Cue "
                        strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " BCta_Des_Cue "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        ResetVista3()

                    Case 6
                        celdaNomEmisor.Text = STR_VACIO
                        celdaDatosProvee.Text = STR_VACIO
                        BarraTitulo1.CambiarTitulo("DEPOSITS")
                        Panel_Cuenta.Visible = False
                        Panel_Cuenta.Dock = DockStyle.None
                        panelDocumento.Visible = True
                        panelDocumento.Dock = DockStyle.Fill
                        celdaAnticiposSCompras.Visible = False
                        panelDocumentoDetalle.Visible = False
                        panelCajaChicaLiq.Visible = False
                        panelCajaChicaLiq.Dock = DockStyle.None
                        If panelTipoTransaccion.Visible = True Then
                            panelTipoTransaccion.Dock = DockStyle.None
                            panelTipoTransaccion.Location = New System.Drawing.Point(660, 365)
                            panelProveedores.Visible = False
                            panelCajaChi.Visible = False
                            panelEmpleado.Visible = False
                            panelTransferencia.Visible = False
                            panelOtrosImpuestos.Visible = True
                            panelOtrosImpuestos.Dock = DockStyle.Fill
                            rbAsalariados.Enabled = False
                        End If
                        panelFacturasNoteD.Visible = False
                        panelFacturasNoteD.Dock = DockStyle.None
                        panelCajChiViatics.Visible = False
                        panelCajChiViatics.Dock = DockStyle.None
                        panelFacturas.Visible = False
                        panelFacturas.Dock = DockStyle.None
                        panelRegreso.Visible = False
                        panelRegreso.Dock = DockStyle.None
                        panelOtraCuenta.Visible = False
                        panelOtraCuenta.Location = New System.Drawing.Point(660, 170)
                        panelOtraCuenta.Dock = DockStyle.None
                        panelCajaChica.Visible = False
                        panelCajaChica.Dock = DockStyle.None
                        panelLIsta.Visible = False
                        panelLIsta.Dock = DockStyle.None
                        panelResuDeposito.Visible = False
                        panelResuDeposito.Dock = DockStyle.None
                        panelDatosProveedores.Visible = True
                        panelDatosProveedores.Dock = DockStyle.None
                        gbDatosProveedor.Text = "Bank Account "
                        strTitulo = "Bank Account"
                        strCampos = " BCta_Num Id, CONCAT(BCta_Des_Cue,' (',BCta_Num_Cue,')') Nombre "
                        strTabla = "    CtasBcos "
                        strFiltroText = " Enter The Name Of The Bank Account To Filter"
                        strFiltro = " BCta_Des_Cue "
                        strCondicion = "    BCta_Sis_Emp= {empresa} AND BCta_Tipo = 0 "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                        strOrdenamiento = " BCta_Des_Cue "
                        strLimite = 20
                        strTipoOrdenamiento = ""
                        'CrearOpciones_TipoTransaccion(IGS_TRANSFERENCIA)
                        ResetVista3()
                End Select
        End Select

    End Sub

    Private Sub OptionItems()

        Select Case intGrupo
            Case eGroup.Proveedor
                botonDatosProveedor.Enabled = IIf((rbGasto.Checked = True), False, True)
                celdaDatosProvee.Enabled = IIf((rbGasto.Checked), False, True)

        End Select

        If rbGasto.Checked = True Then
            dgComprs.Columns(11).Visible = True
            etiquetaCentroCostos.Visible = False
            celdaAnticiposSCompras.Visible = False

        Else
            dgComprs.Columns(11).Visible = False

        End If

        If rbPago.Checked = True Then
            etiquetaCentroCostos.Visible = True
            celdaAnticiposSCompras.Visible = True
            etiquetaCentroCostos.Visible = True
            celdaAnticiposSCompras.Visible = True
        Else
            etiquetaCentroCostos.Visible = False
            celdaAnticiposSCompras.Visible = False
        End If

        If rbImpuesto.Checked = True Then
            etiquetaCentroCostos.Visible = False
            celdaAnticiposSCompras.Visible = False
        End If

        If rbPago.Checked = True Then
            celdaValorRB.Text = 0
        End If

        If rbImpuesto.Checked = True Then
            celdaValorRB.Text = 1
        End If

        If rbAnticipoSCompras.Checked = True Then
            celdaValorRB.Text = 2
        End If

        If rbGasto.Checked = True Then
            celdaValorRB.Text = 3
        End If

    End Sub

    Private Sub CambioRB()
        Try
            If dgMovimientos.SelectedCells(13).Value = celdaValorRB.Text Then
                For i As Integer = 0 To dgComprs.Rows.Count - 1
                    If dgComprs.Rows(i).Cells("colOperacion").Value = 2 Then
                        dgComprs.Rows(i).Cells("colOperacion").Value = 0
                        dgComprs.Rows(i).Visible = True
                        ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 1 Then
                            dgComprs.Rows.Remove(dgComprs.Rows(i))
                        End If
                Next
            Else
                For i As Integer = 0 To dgComprs.Rows.Count - 1
                    If dgComprs.Rows(i).Cells("colOperacion").Value = 0 Then
                        dgComprs.Rows(i).Cells("colOperacion").Value = 2
                        dgComprs.Rows(i).Visible = False
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 1 Then
                        dgComprs.Rows.Remove(dgComprs.Rows(i))
                    End If
                Next
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Function ComprobarCampos() As Boolean
        ComprobarCampos = True
        Dim i As Integer
        Dim dblMontoTotal As Double
        Dim dblMon As Double

        Try
            dblMontoTotal = 0

            For i = 0 To dgComprs.Rows.Count - 1
                If dgComprs.Rows(i).Cells("colOperacion").Value <> 2 Then
                    dblMon = CDbl(dgComprs.Rows(i).Cells("colMonto").Value)
                    dblMontoTotal = dblMontoTotal + dblMon
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        If CDbl(celdaMonto.Text) > dblMontoTotal = True Then
            MsgBox("La suma de facturas de compras no coincide con el monto ingresado")
            ComprobarCampos = False
        End If

        If CDbl(celdaMonto.Text) < dblMontoTotal = True Then
            MsgBox("La suma de facturas de compras no coincide con el monto ingresado")
            ComprobarCampos = False
        End If

        If rbPago.Checked = True Then
            If cFunciones.ValidarCampoTexto(celdaDatosProvee, 250) = False Then
                ComprobarCampos = False
            End If

            If cFunciones.ValidarCampoTexto(celdaNomEmisor, 250) = False Then
                ComprobarCampos = False
            End If

            If cFunciones.ValidarCampoTexto(celdaDocumento) = False Then
                ComprobarCampos = False
            End If

        End If

        If rbGasto.Checked = True Then

            If cFunciones.ValidarCampoTexto(celdaNomEmisor, 250) = False Then
                ComprobarCampos = False
            End If

        End If

        'ComprobarFactura(1)


    End Function

    ''Private Function ComprobarFactura(ByVal iRows As Integer, Optional Avisar As Boolean = True) As Boolean
    ''    Dim logRes As Boolean
    ''    With dgComprs
    ''        If ((dgComprs.Rows(iRows).Cells("colDescripcion").Value) = vbNullString) Or (dgComprs.Rows(iRows).Cells("colMonto").Value) Then
    ''            If Avisar Then
    ''                MsgBox("Fila " & (iRows + 1) & ": Revise los datos ingresados", vbExclamation)

    ''            End If
    ''        ElseIf Avisar Then
    ''            logRes = True
    ''        Else
    ''            logRes = celdaMonto.Text > vbEmpty
    ''        End If
    ''    End With
    ''    ComprobarFactura = logRes
    ''End Function

    Private Function GuardarDocumentoEncabezado() As Boolean

        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim logInsert As Boolean = True
        Dim idDoc As Integer
        Dim Tipo As Integer
        Dim strSQL As String

        Try
            Dim chdr As New clsDcmtos_HDR
            Dim Ca As New clsCatalogos
            chdr.CONEXION = strConexion

            If Me.Tag = "mod" Then
                chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                chdr.HDOC_DOC_CAT = celdaCatMovimiento.Text
                chdr.HDOC_DOC_ANO = celdaAno.Text
                chdr.HDOC_DOC_NUM = celdaNum.Text
            Else
                idDoc = cfun.NuevoId(celdaCatMovimiento.Text)
                chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                chdr.HDOC_DOC_CAT = celdaCatMovimiento.Text
                chdr.HDOC_DOC_ANO = cfun.AñoMySQL
                chdr.HDOC_DOC_NUM = idDoc
            End If

            chdr.HDoc_Doc_Fec_NET = dtpDoc.Value
            chdr.HDOC_EMP_COD = celdaIDDatos.Text
            chdr.HDOC_EMP_NOM = celdaDatosProvee.Text
            chdr.HDOC_DR1_NUM = celdaNumero.Text.ToString
            chdr.HDOC_RF1_COD = celdaConcepto.Text
            chdr.HDOC_RF1_DBL = CDbl(celdaMonto.Text)
            chdr.HDOC_DOC_TC = celdaTasaCambio.Text
            chdr.HDOC_DR2_NUM = celdaReferencia.Text
            chdr.HDOC_EMP_PER = celdaNomEmisor.Text
            chdr.HDOC_DOC_MON = celdaIdMoneda.Text
            'chdr.HDOC_ANT_COM = celdaAnticiposSCompras.Text
            chdr.HDOC_RF2_TXT = celdaTotaLetras.Text
            chdr.HDOC_RF1_NUM = celdaCodigoBank.Text
            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_RF2_NUM = celdaIDDocumento.Text
            chdr.HDOC_DR2_EMP = IIf(checkSecreto.Checked = True, 1, 0)
            chdr.HDOC_DR2_CAT = celdaValorRB.Text
            chdr.HDOC_DR1_CAT = celdaGrupo.Text

            Ca.CONEXION = strConexion
            'Ca.CAT_DESC = celdaDocumento.Text

            'celdaNum.Text = idDoc

            If casillaAnulada.Checked = True Then
                chdr.HDOC_DOC_STATUS = 3
            Else
                chdr.HDOC_DOC_STATUS = IIf(casillaEstado.Checked = True, 1, vbEmpty)
            End If


            If Me.Tag = "mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "No se pudo Actualizar el Documento", MsgBoxStyle.Critical)
                End If
                MostrarLista(INT_UNO)
                querySqlMovimientos()
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "No se pudo guardar del documento", MsgBoxStyle.Critical)
                End If
                MostrarLista(INT_UNO)
                querySqlMovimientos()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDocumentoDetalle() As Boolean
        Dim BanderaD As Boolean = False
        Dim clsDTL As New clsDcmtos_DTL
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True

        Try
            For i As Integer = 0 To dgComprs.Rows.Count - 1
                MyCnn.CONECTAR = strConexion
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = celdaCatMovimiento.Text
                clsDTL.DDOC_DOC_ANO = celdaAno.Text

                clsDTL.DDOC_DOC_NUM = celdaNum.Text

                If dgComprs.Rows(i).Cells("colLinea").Value > 0 Then
                    clsDTL.DDOC_DOC_LIN = dgComprs.Rows(i).Cells("colLinea").Value
                Else
                    clsDTL.DDOC_DOC_LIN = LineaMax(celdaCatMovimiento.Text, celdaAno.Text, celdaNum.Text)
                End If


                If rbPago.Checked = True Then
                    clsDTL.DDOC_RF1_TXT = dgComprs.Rows(i).Cells("colDescripcion").Value
                    clsDTL.DDOC_RF1_DBL = dgComprs.Rows(i).Cells("colMonto").Value
                    clsDTL.DDOC_PRD_REF = dgComprs.Rows(i).Cells("colCuenta").Value
                    clsDTL.DDOC_RF2_COD = dgComprs.Rows(i).Cells("colDDoc_RF2_Cod").Value
                    If dgComprs.Rows(i).Cells("colDDoc_RF2_Cod").Value = "COMPRA" Then
                        clsDTL.DDOC_RF1_NUM = dgComprs.Rows(i).Cells("colTip").Value
                        clsDTL.DDOC_RF2_NUM = dgComprs.Rows(i).Cells("colAno").Value
                        clsDTL.DDOC_RF3_NUM = dgComprs.Rows(i).Cells("colNum").Value
                    End If

                    If dgComprs.Rows(i).Cells("colOperacion").Value = 0 Then
                        If clsDTL.Actualizar() = False Then
                            MsgBox(clsDTL.MERROR.ToString)
                        End If
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 1 Then
                        If clsDTL.Guardar() = False Then
                            MsgBox(clsDTL.MERROR.ToString)
                        End If
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 2 Then
                        If clsDTL.Borrar() = False Then
                            MsgBox(clsDTL.MERROR.ToString)
                        End If
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    End If
                End If

                If rbAnticipoSCompras.Checked = True Then
                    clsDTL.DDOC_RF1_TXT = dgComprs.Rows(i).Cells("colDescripcion").Value
                    clsDTL.DDOC_RF1_DBL = dgComprs.Rows(i).Cells("colMonto").Value
                    clsDTL.DDOC_PRD_REF = dgComprs.Rows(i).Cells("colCuenta").Value
                    clsDTL.DDOC_RF2_COD = dgComprs.Rows(i).Cells("colDDoc_RF2_Cod").Value
                    If dgComprs.Rows(i).Cells("colDDoc_RF2_Cod").Value = "COMPRA" Then
                        clsDTL.DDOC_RF1_NUM = dgComprs.Rows(i).Cells("colTip").Value
                        clsDTL.DDOC_RF2_NUM = dgComprs.Rows(i).Cells("colAno").Value
                        clsDTL.DDOC_RF3_NUM = dgComprs.Rows(i).Cells("colNum").Value
                    End If

                    If dgComprs.Rows(i).Cells("colOperacion").Value = 0 Then
                        clsDTL.Actualizar()
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 1 Then
                        clsDTL.Guardar()
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 2 Then
                        clsDTL.Borrar()
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    End If
                End If

                If rbGasto.Checked = True Then
                    clsDTL.DDOC_RF1_TXT = dgComprs.Rows(i).Cells("colDescripcion").Value
                    clsDTL.DDOC_RF1_DBL = dgComprs.Rows(i).Cells("colMonto").Value
                    clsDTL.DDOC_PRD_PNR = dgComprs.Rows(i).Cells("colIDCosto").Value
                    clsDTL.DDOC_RF3_TXT = dgComprs.Rows(i).Cells("colCosto").Value
                    clsDTL.DDOC_PRD_REF = dgComprs.Rows(i).Cells("colCuenta").Value
                    clsDTL.DDOC_RF2_COD = dgComprs.Rows(i).Cells("colDDoc_RF2_Cod").Value
                    If dgComprs.Rows(i).Cells("colDDoc_RF2_Cod").Value = "COMPRA" Then
                        clsDTL.DDOC_RF1_NUM = dgComprs.Rows(i).Cells("colTip").Value
                        clsDTL.DDOC_RF2_NUM = dgComprs.Rows(i).Cells("colAno").Value
                        clsDTL.DDOC_RF3_NUM = dgComprs.Rows(i).Cells("colNum").Value
                    End If

                    If dgComprs.Rows(i).Cells("colOperacion").Value = 0 Then
                        If clsDTL.Actualizar() = False Then
                            MsgBox(clsDTL.MERROR.ToString & "No se pudo Actualizar el Documento", MsgBoxStyle.Critical)
                        End If
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 1 Then
                        If clsDTL.Guardar() = False Then
                            MsgBox(clsDTL.MERROR.ToString & "No se pudo Guardar el Documento", MsgBoxStyle.Critical)
                        End If
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    ElseIf dgComprs.Rows(i).Cells("colOperacion").Value = 2 Then
                        If clsDTL.Borrar() = False Then
                            MsgBox(clsDTL.MERROR.ToString & "No se pudo Eliminar el Documento", MsgBoxStyle.Critical)
                        End If
                        MostrarLista(INT_UNO)
                        querySqlMovimientos()
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function


    Private Sub GuardarMovimientosBancos(ByVal Tipo As String)
        Dim MVTOS As New Tablas.TMVTOSBCOS
        Dim cfun As New clsFunciones
        Dim dblTasa As Double
        Dim dblCargo As Double
        Dim dblAbono As Double
        Dim dblCargoEx As Double
        Dim dblAbonoEx As Double
        'Dim Tipo As Integer
        Dim strTipo As String
        intCurLoc = cFunciones.MonedaDefault(clsFunciones.Monedas.Mlocal)

        dblTasa = Val(celdaTasaCambio.Text)

        Select Case Tipo
            Case intCheque, intDebito
                'Debito
                strTipo = "Proveedores"
                dblCargo = CDbl(celdaMonto.Text)
                dblAbono = vbEmpty

            Case intDeposito, intCredito
                'Credito
                strTipo = "Clientes"
                dblCargo = vbEmpty
                dblAbono = CDbl(celdaMonto.Text)
        End Select

        If intCurrency = intCurLoc Then
            'Documento Actual en Moneda Local
            dblCargoEx = (dblCargo / dblTasa)
            dblAbonoEx = (dblAbono / dblTasa)
        Else
            'Docuemnto Actual en Moneda Exterior
            dblCargoEx = dblCargo
            dblAbonoEx = dblAbono
            dblCargo = (dblCargoEx * dblTasa)
            dblAbono = (dblAbonoEx * dblTasa)
        End If

        MVTOS.CONEXION = strConexion
        Try
            MVTOS.BMOV_SIS_EMP = Sesion.IdEmpresa
            MVTOS.BMOV_CTA = celdaCodigo.Text
            MVTOS.BMov_Fec_NET = dtpDoc.Value
            MVTOS.BMOV_DOC_CAT = celdaCatMovimiento.Text
            MVTOS.BMOV_DOC_ANO = celdaAno.Text
            MVTOS.BMOV_DOC_NUM = celdaNum.Text
            MVTOS.BMOV_BENEFICIARIO = celdaNomEmisor.Text

            If casillaAnulada.Checked = True Then
                dblCargo = vbEmpty
                dblAbono = vbEmpty
                dblCargoEx = vbEmpty
                dblAbonoEx = vbEmpty
            End If

            MVTOS.BMOV_SINI_LOC = vbEmpty
            MVTOS.BMOV_CRGO_LOC = dblCargo
            MVTOS.BMOV_ABNO_LOC = dblAbono
            MVTOS.BMOV_SINI_EXT = vbEmpty
            MVTOS.BMOV_CRGO_EXT = dblCargoEx
            MVTOS.BMOV_ABNO_EXT = dblAbonoEx

            MVTOS.BMOV_CAT_DOC = Val(celdaIDDocumento.Text)
            MVTOS.BMOV_NUM_DOC = celdaNumero.Text.ToString
            MVTOS.BMOV_TIPOEMP = strTipo
            If celdaIDDatos.Text = vbNullString Then
                MVTOS.BMOV_CODEMP = 0
            Else
                MVTOS.BMOV_CODEMP = Val(celdaIDDatos.Text)
            End If
            MVTOS.BMOV_CODEMP = Val(celdaIDDatos.Text)
            MVTOS.BMOV_MONEDA = intCurrency
            MVTOS.BMOV_TC = Val(celdaTasaCambio.Text)
            MVTOS.BMOV_CONCEPTO = celdaConcepto.Text
            MVTOS.BMOV_SALDO = vbEmpty
            MVTOS.BMOV_DIAS_VCTO = vbEmpty

            If Me.Tag = "mod" Then
                If MVTOS.PUPDATE = False Then
                    MsgBox(MVTOS.MERROR.ToString & "No se pudo guardar del documento", MsgBoxStyle.Critical)
                End If
                MostrarLista(INT_UNO)
                querySqlMovimientos()
            Else
                If MVTOS.PINSERT = False Then
                    MsgBox(MVTOS.MERROR.ToString & "No se pudo Actualizar el Documento", MsgBoxStyle.Critical)
                End If
                MostrarLista(INT_UNO)
                querySqlMovimientos()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Registra la transacción de las facturas en cuentas por pagar
    'Private Sub RegistrarCompra()
    '    Dim i As Integer
    '    Dim intAño As Integer
    '    Dim intNumero As Integer
    '    Dim intMoneda As Integer

    '    Dim dblTasa As Double
    '    Dim dblTasaFactura As Double
    '    Dim dblTCEx As Double
    '    Dim dblMonto As Double
    '    Dim dblLocal As Double

    '    Dim dteFecha As Double
    '    Dim strSQL As String
    '    Dim ECta As New Tablas.TECTACTE
    '    Dim COM As New MySqlCommand
    '    Dim Tipo As Integer

    '    intCurExt = cFunciones.MonedaDefault(clsFunciones.Monedas.Mextrangero)
    '    intCurLoc = cFunciones.MonedaDefault(clsFunciones.Monedas.Mlocal)

    '    'Tasa de cambio a moneda exterior y la del documento
    '    strSQL = "SELECT cat_sist FROM Catalogos WHERE cat_clase = 'Monedas' AND  cat_num ={moneda} "
    '    strSQL = Replace(strSQL, "{moneda}", intCurExt)

    '    MyCnn.CONECTAR = strConexion
    '    COM = New MySqlCommand(strSQL, CON)
    '    dblTCEx = COM.ExecuteScalar
    '    dblTasa = Val(celdaTasaCambio.Text)

    '    With dgComprs
    '        Try

    '        Catch ex As Exception

    '        End Try
    '        For i = vbEmpty To dgComprs.Rows.Count - 1
    '            intAño = dgComprs.Rows(i).Cells("colAno").Value
    '            intNumero = dgComprs.Rows(i).Cells("colNum").Value

    '            dteFecha = dteFecha.ToString(FORMATO_MYSQL)

    '            intMoneda = dgComprs.Rows(i).Cells("colMoneda").Value
    '            dblTasaFactura = dgComprs.SelectedCells(3).Value
    '            dblMonto = dgComprs.SelectedCells(5).Value

    '            If (intNumero > vbEmpty) Then
    '                If intCurrency = intCurLoc Then
    '                    'Cheque en moneda Local
    '                    dblLocal = dblMonto
    '                    If intMoneda = intCurExt Then
    '                        'Factura en moneda externa
    '                        dblMonto = (dblMonto / dblTCEx)
    '                    Else
    '                        'Utilizar TC de Factura
    '                        dblMonto = (dblMonto / dblTasaFactura)
    '                    End If
    '                Else
    '                    If (intMoneda = intCurrency) Then
    '                        'Utiliza la TC de la factura ($ -> Q)
    '                        dblLocal = (dblMonto * dblTasaFactura)
    '                    Else
    '                        'Utiliza la TC del documento ($ -> Q)
    '                        dblLocal = (dblMonto * dblTasa)
    '                    End If
    '                End If
    '            End If

    '            ECta.CONEXION = strConexion
    '            'Id. del documento
    '            ECta.ECTA_SIS_EMP = Sesion.IdEmpresa
    '            ECta.ECTA_DOC_CAT = celdaIDDocumento.Text
    '            ECta.ECTA_DOC_ANO = celdaAno.Text
    '            ECta.ECTA_DOC_NUM = Val(celdaNum.Text)
    '            ECta.ECTA_DOC_LIN = (i + 1)

    '            'Empresa
    '            ECta.ECTA_TIPOEMP = "Proveedores"
    '            ECta.ECTA_CODEMP = Val(celdaIDDatos.Text)

    '            'Cargo/abono
    '            ECta.ECTA_SINI_LOC = vbEmpty
    '            ECta.ECTA_CRGO_LOC = vbEmpty
    '            ECta.ECTA_ABNO_LOC = dblLocal

    '            ECta.ECTA_SINI_EXT = vbEmpty
    '            ECta.ECTA_CRGO_EXT = vbEmpty
    '            ECta.ECTA_ABNO_EXT = dblMonto

    '            'Concepto, vencimiento y moneda
    '            ECta.ECTA_CONCEPTO = celdaConcepto.Text
    '            ECta.ECta_FecDcmt_NET = dtpDoc.Value
    '            ECta.ECta_FecVenc_NET = dtpDoc.Value
    '            ECta.ECTA_MONEDA = intCurrency
    '            ECta.ECTA_TC = dblTasa

    '            'Referencia
    '            ECta.ECTA_REF_CAT = intIDCompra
    '            ECta.ECTA_REF_ANO = intAño
    '            ECta.ECTA_REF_NUM = intNumero
    '            strSQL = vbNullString

    '            If ECta.PINSERT = False Then
    '                MsgBox(ECta.MERROR.ToString)
    '            End If
    '        Next
    '    End With
    'End Sub

    Private Function VerificarPresupuesto() As Boolean
        Dim logAceptar As Boolean
        Dim strSQL As String
        Dim i As Integer
        Dim strSQL1 As String
        Dim dblImpoteLocal As Double
        Dim dblSaldo As Double
        Dim COM As New MySqlCommand
        intCurrency = celdaIdMoneda.Text

        logAceptar = False

        strSQL = "Select (p.importe * p.tasa ) - sum(dp.importe_loc ) saldo from conta.pro_presupuesto p "
        strSQL &= "      left join conta.detalle_presupuesto dp on dp.empresa =  p.empresa and p.ano = dp.ano and dp.cuenta = p.cuenta and month(dp.fecha)=p.mes "
        strSQL &= "         where p.empresa = {empresa} and p.ano = {año} and p.mes = {mes} and p.cuenta = {cuenta}"
        strSQL &= "             group by p.cuenta "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", Val(celdaAno.Text))
        strSQL = Replace(strSQL, "{mes}", dtpDoc.Value.Month)

        For i = vbEmpty To frmP.dgDetalle.Rows.Count - 1
            If Not (frmP.dgDetalle.Rows(i).Cells("colNombre").Value) = vbNullString Then
                strSQL1 = Replace(strSQL, "{cuenta}", frmP.dgDetalle.Rows(i).Cells("colCuenta").Value)
                If intCurrency = intCurLoc Then
                    dblImpoteLocal = frmP.dgDetalle.Rows(i).Cells("colMonto").Value
                Else
                    dblImpoteLocal = frmP.dgDetalle.Rows(i).Cells("colMonto").Value * Val(celdaTasaCambio.Text)
                End If
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL1, CON)
                dblSaldo = COM.ExecuteScalar

                If dblSaldo - dblImpoteLocal > 0 Then
                    logAceptar = True
                End If
            End If
        Next

        VerificarPresupuesto = logAceptar
    End Function

    Private Sub CargarPresupuesto()
        Dim strSQL As String

        strSQL = vbNullString
        strSQL &= " SELECT d.transaccion transaccion, d.cuenta cuenta, c.nombre_loc nombre, IF(d.moneda={moneda},d.importe_loc, d.importe_ext) importe"
        strSQL &= "     FROM {conta}.detalle_presupuesto d "
        strSQL &= "          LEFT JOIN contahilos.cuentas_presupuesto c ON c.empresa=d.empresa AND c.id_cuenta=d.cuenta"
        strSQL &= "              WHERE d.empresa={empresa} AND d.categoria={categoria}  AND d.ano={año} AND d.numero={numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{categoria}", Val(celdaCatMovimiento.Text))
        strSQL = Replace(strSQL, "{año}", Val(celdaAno.Text))
        strSQL = Replace(strSQL, "{numero}", Val(celdaNum.Text))
        strSQL = Replace(strSQL, "{moneda}", intCurLoc)

        frmP.CargarDatos(strSQL)


    End Sub

    Private Function GuardarPresupuesto()

        Dim i As Integer
        Dim TDPre As New Tablas.TDETALLE_PRESUPUESTO
        Const STR_CARGO As String = "C"
        Dim logResultado As Boolean = True

        TDPre.CONEXION = strConexion
        Try
            For i = vbEmpty To (frmP.dgDetalle.Rows.Count - 1)
                TDPre.TRANSACCION1 = 0
                TDPre.EMPRESA = Sesion.IdEmpresa
                TDPre.CATEGORIA = celdaCatMovimiento.Text
                TDPre.ANO = celdaAno.Text
                TDPre.NUMERO = celdaNum.Text
                TDPre.MONEDA = intCurrency
                TDPre.TASA = celdaTasaCambio.Text
                TDPre.fecha_NET = dtpDoc.Value
                TDPre.CUENTA = frmP.dgDetalle.Rows(i).Cells("colCuenta").Value

                If intCurrency = INT_LOC Then
                    TDPre.IMPORTE_LOC = frmP.dgDetalle.Rows(i).Cells("colMonto").Value
                    TDPre.IMPORTE_EXT = frmP.dgDetalle.Rows(i).Cells("colMonto").Value / Val(celdaTasaCambio.Text)
                Else
                    TDPre.IMPORTE_LOC = (frmP.dgDetalle.Rows(i).Cells("colMonto").Value) * Val(celdaTasaCambio.Text)
                    TDPre.IMPORTE_EXT = (frmP.dgDetalle.Rows(i).Cells("colMonto").Value)
                End If
                TDPre.OPERACION = STR_CARGO

                If frmP.dgDetalle.Rows(i).Cells("colOperacion").Value = 0 Then
                    TDPre.TRANSACCION1 = frmP.dgDetalle.Rows(i).Cells("colTransaccion").Value
                    If TDPre.PUPDATE() = False Then
                        MsgBox(TDPre.MERROR.ToString & "No se puedo actualizar el dato", MsgBoxStyle.Critical)
                    End If
                    MostrarLista(INT_UNO)
                ElseIf frmP.dgDetalle.Rows(i).Cells("colOperacion").Value = 1 Then
                    If TDPre.PINSERT() = False Then
                        MsgBox(TDPre.MERROR.ToString & "No se puedo insertar el dato", MsgBoxStyle.Critical)
                    End If
                    MostrarLista(INT_UNO)
                ElseIf frmP.dgDetalle.Rows(i).Cells("colOperacion").Value = 2 Then
                    TDPre.TRANSACCION1 = frmP.dgDetalle.Rows(i).Cells("colTransaccion").Value
                    If TDPre.PDELETE() = False Then
                        MsgBox(TDPre.MERROR.ToString & "No se puedo eliminar el dato", MsgBoxStyle.Critical)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Asigna el número del cheque
    Private Sub NuevoCheque()
        Dim strSQL As String
        Dim COM As New MySqlCommand
        'Instrucción de selección
        strSQL = vbNullString
        strSQL &= "SELECT CAST(LPAD(COALESCE(MAX(CAST(HDoc_DR1_Num AS SIGNED)),0) + 1,8,'0') AS CHAR) Numero"
        strSQL &= "  FROM Dcmtos_HDR"
        strSQL &= "      WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = {tipo} AND HDoc_RF1_Num = {id} "
        If (Val(celdaNumero.Text) > vbEmpty) Then
            strSQL &= Replace(" AND CAST(HDoc_DR1_Num AS SIGNED) < {valor}", "{valor}", Val(celdaNumero.Text))
        End If

        'Reemplazar parámetros
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", 51)
        strSQL = Replace(strSQL, "{id}", celdaCodigo.Text)

        'Asignar el valor
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)

        celdaNumero.Text = COM.ExecuteScalar
        celdaReferencia.Text = "-NO NEGOCIABLE-"
    End Sub

#End Region

#Region "Eventos"

    Private Sub frmBancos_FormClosing(sender As Object, e As FormClosingEventArgs)
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmBancos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        Accessos()
        MostrarLista(INT_CERO)

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLIsta.Visible = True Then
            Me.Close()
        ElseIf panelDocumento.Visible = True Then
            MostrarLista(INT_UNO)
        Else
            Panel_Cuenta.Visible = True
            MostrarLista(INT_CERO)
        End If

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        ResetVista2()
        MostrarLista(INT_UNO)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        Select Case intmodo

            Case 2
                If ComprobarCampos() Then
                    If Me.Tag = "nuevo" Then
                        'Asigna el Año
                        celdaAno.Text = dtpDoc.Value.Year

                        'Comprueba la validez del numero

                        celdaNum.Text = cFunciones.Verificacion_Nuevo_Registro(celdaNum.Text, "Dcmtos", celdaCatMovimiento.Text, celdaAno.Text, , True)
                    End If
                    If celdaNum.Text > vbEmpty Then
                        'verificar si se sobre pasa el documento
                        If VerificarPresupuesto() = False Then
                            MsgBox("El presupuesto para esta transaccion ya se ha superado.", vbInformation, "Presupuesto Superado")
                        End If
                        'Encabezado del documento
                        GuardarDocumentoEncabezado()

                        'Borra el detalle del documento, la operación y los créditos en compras
                        Dim tipo As Integer = celdaCatMovimiento.Text
                        Select Case tipo
                            Case intCheque, intDebito, intDeposito, intCredito
                                GuardarDocumentoDetalle()
                        End Select

                        'Movimiento (crédito / débito)
                        GuardarMovimientosBancos(51)
                        GuardarPresupuesto()
                        'Registra la transacción
                        Dim acUpdate As clsFunciones.AccEnum
                        Dim acAdd As clsFunciones.AccEnum
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, IIf(logModificar, acUpdate, acAdd), , Val(celdaCatMovimiento.Text), Val(celdaAno.Text), Val(celdaNum.Text))

                        If Not (strMensaje = vbNullString) Then
                            MsgBox(strMensaje, vbInformation, "Aviso")
                        End If

                    End If
                End If

        End Select

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intID As Integer = NO_FILA
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        Me.Tag = "mod"


        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)
        intID = dgLista.SelectedCells(0).Value
        Reset()
        MostrarLista(INT_UNO)
        CargarDatosCuenta(intID)
        querySqlMovimientos()
        celdaTipoDoc.Text = "Todo"
    End Sub

    Private Sub botonTipoCuenta_Click(sender As Object, e As EventArgs) Handles botonTipoCuenta.Click
        Dim frm As New frmSeleccionar
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strCondicion = " cat_clase = 'Tipo_Cuentas' "
        strCampos = " cat_desc Type "
        Try
            frm.Campos = strCampos
            frm.Condicion = strCondicion
            frm.Tabla = " Catalogos "
            frm.Titulo = "Select type of account."
            frm.Filtro = "cat_desc"
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaTipoCuenta.Text = frm.LLave
            End If
            frm.Dispose()
            frm = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBanco_Click(sender As Object, e As EventArgs) Handles botonBanco.Click
        Dim frm As New frmSeleccionar
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strCondicion = " cat_clase = 'Bancos' "
        strCampos = " cat_num Code , cat_desc Bank "
        Try
            frm.Campos = strCampos
            frm.Condicion = strCondicion
            frm.Tabla = " Catalogos "
            frm.Titulo = "Select bank."
            frm.Filtro = "cat_desc"
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaIdBanco.Text = frm.LLave
                celdaBanco.Text = frm.Dato
            End If
            frm.Dispose()
            frm = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCuentaContable_Click(sender As Object, e As EventArgs) Handles botonCuentaContable.Click
        Dim frm As New frmSeleccionar
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strCondicion = " empresa =  " & Sesion.IdEmpresa
        strCampos = " id_cuenta Account , nombre Name "
        Try
            frm.Campos = strCampos
            frm.Condicion = strCondicion
            frm.Tabla = " conta.cuentas "
            frm.Titulo = "Select Accouting Item."
            frm.Filtro = "nombre"
            frm.FiltroText = "Enter the account name to filter"
            frm.Limite = 20

            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaPartida.Text = frm.LLave
            End If
            frm.Dispose()
            frm = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strCondicion = " cat_clase = 'Monedas' "
        strCampos = " cat_num Code , cat_clave, cat_desc Currency "
        Try
            frm.Campos = strCampos
            frm.Condicion = strCondicion
            frm.Tabla = " Catalogos "
            frm.Titulo = "Select Currency."
            frm.Filtro = "cat_desc"
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMonedaClave.Text = frm.Dato
                celdaMonedaName.Text = frm.Dato2
            End If
            frm.Dispose()
            frm = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonChequera_Click(sender As Object, e As EventArgs) Handles botonChequera.Click

        Dim strDato As String

        strDato = InputBox("Enter The Last Number Of Current Checkbox", "Current Checkbook", celdaChequera.Text)
        'If Not (strDato) = vbEmpty Then
        If IsNumeric(strDato) Then
            celdaChequera.Text = Val(strDato)
            If Not (intCuenta = vbEmpty) Then
                GuardarNumero(1)
            End If
        Else
            MsgBox("You Must Enter a Numerical Data", vbExclamation, "Notice")
        End If
        'End If
    End Sub

    Private Sub botonDeposito_Click(sender As Object, e As EventArgs) Handles botonDeposito.Click
        Dim strOpcion As String = STR_VACIO
        Dim frm As New frmOption
        BarraTitulo1.CambiarTitulo("DEPOSITS: " & botonDeposito.Bottom)
        Me.Tag = "nuevo"
        Try
            frm.Titulo = "Types of Deposits"
            frm.Mensaje = "Select a Type of Deposits"
            frm.Opciones = "0. Providers|" & "1. Petty Cash and Viaticals" & "|" & "2. Clients" & "|" & "3. Employees" & "|" & "@4. Sheet" & "|" & "5. Transfer Between Accounts" & "|" & "@6. Other Taxes"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Redimencionar(54, frm.Seleccion)
            End If

            If MyCnn.ProbarConexiones() = True Then
                cSesion.ComprobarActualizacion()
            Else

                MsgBox("Unable to connect to the server", MsgBoxStyle.Critical)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCredit_Click(sender As Object, e As EventArgs) Handles botonCredit.Click

        Dim frm As New frmOption
        Me.Tag = "nuevo"
        Try
            frm.Titulo = "Types of Credits"
            frm.Mensaje = "Select a Type of Deposits"
            frm.Opciones = "@0. Providers|" & "@1. Petty Cash and Viaticals" & "|" & "2. Clients" & "|" & "@3. Employees" & "|" & "@4. Sheet" & "|" & "5. Transfer Between Accounts" & "|" & "@6. Other Taxes"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Redimencionar(53, frm.Seleccion)
            End If

            If MyCnn.ProbarConexiones() = True Then
                cSesion.ComprobarActualizacion()
            Else

                MsgBox("Unable to connect to the server", MsgBoxStyle.Critical)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonDebito_Click(sender As Object, e As EventArgs) Handles botonDebito.Click
        Me.Tag = "nuevo"
        Dim frm As New frmOption

        Try
            frm.Titulo = "Types of Debits"
            frm.Mensaje = "Select a Type of Deposits"
            frm.Opciones = "0. Providers|" & "1. Petty Cash and Viaticals" & "|" & "@2. Clients" & "|" & "3. Employees" & "|" & "@4. Sheet" & "|" & "5. Transfer Between Accounts" & "|" & "6. Other Taxes"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If frm.Seleccion = 0 Then
                    Redimencionar(52, frm.Seleccion)
                    MostrarLista(2)
                    celdaCatMovimiento.Text = 52
                    celdaDocumento.Text = "Nota de Debito"
                    botonDocumento.Enabled = False

                    If MyCnn.ProbarConexiones() = True Then
                        cSesion.ComprobarActualizacion()
                    Else

                        MsgBox("Unable to connect to the server", MsgBoxStyle.Critical)
                    End If
                Else
                    'MsgBox("Funcion en Desarrollo")
                    'Exit Sub
                    Redimencionar(52, frm.Seleccion)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCheque_Click_1(sender As Object, e As EventArgs) Handles botonCheque.Click
        Me.Tag = "nuevo"
        Dim frm As New frmOption
        Try
            frm.Titulo = "Types of Checks"
            frm.Mensaje = "Select a Type of Deposits"
            frm.Opciones = "0. Providers|" & "1. Petty Cash and Viaticals" & "|" & "@2. Clients" & "|" & "3. Employees" & "|" & "@4. Sheet" & "|" & "5. Transfer Between Accounts" & "|" & "6. Other Taxes"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If frm.Seleccion = 0 Then
                    Redimencionar(51, frm.Seleccion)
                    MostrarLista(2)
                    NuevoCheque()
                    celdaCodigoBank.Text = celdaCodigo.Text
                    celdaCatMovimiento.Text = 51
                    botonDocumento.Enabled = False

                    If MyCnn.ProbarConexiones() = True Then
                        cSesion.ComprobarActualizacion()
                    Else

                        MsgBox("Unable to connect to the server", MsgBoxStyle.Critical)
                    End If
                Else
                    'MsgBox("Funcion en Desarrollo")
                    'Exit Sub
                    Redimencionar(51, frm.Seleccion)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonDatosProveedor_Click(sender As Object, e As EventArgs) Handles botonDatosProveedor.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Dim strCondicion As String = STR_VACIO
        strCondicion = "  pro_sisemp= {empresa} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Providers"
            frm.FiltroText = " Enter The Name Of The Providers To Filter"
            frm.Campos = " pro_codigo ID, pro_proveedor Nombre "
            frm.Tabla = "  Proveedores "
            frm.Condicion = strCondicion
            frm.Filtro = "  pro_proveedor "
            frm.Ordenamiento = "  pro_proveedor "
            frm.TipoOrdenamiento = ""
            strLimite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDDatos.Text = frm.LLave
                celdaDatosProvee.Text = frm.Dato
                celdaNomEmisor.Text = frm.Dato

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCajas_Click(sender As Object, e As EventArgs) Handles botonCajas.Click

        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "BCta_Sis_Emp = {empresa} AND BCta_Tipo IN (1,2,3)"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = strTitulo
            frm.Campos = strCampos
            frm.Tabla = strTabla
            frm.FiltroText = strFiltroText
            frm.Filtro = strFiltro
            frm.Condicion = strCondicion
            frm.Ordenamiento = strOrdenamiento
            frm.TipoOrdenamiento = strTipoOrdenamiento
            frm.Limite = strLimite

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCajas.Text = frm.LLave
                celdaCajas.Text = frm.Dato
                celdaBeneficiario.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Private Sub botonFecha_Click_1(sender As Object, e As EventArgs)
    '    If botonFecha.Tag = "1" Then
    '        'panelTipTran2.Visible = True
    '        'panelTipTran2.Dock = DockStyle.Fill
    '        panelFacturasNoteD.Visible = False
    '        panelFacturasNoteD.Dock = DockStyle.None
    '        botonFecha.Tag = "2"
    '    Else
    '        'panelTipTran2.Visible = False
    '        'panelFacturasNoteD.Visible = True
    '        panelFacturasNoteD.Dock = DockStyle.Fill
    '        botonFecha.Tag = "1"
    '    End If
    'End Sub

    Private Sub botonConciliacion_Click(sender As Object, e As EventArgs) Handles botonConciliacion.Click

        Dim frm As New frmConciliacionBancaria

        If Not (Month(dtpInicio.Value) = Month(dtpFin.Value)) Then
            MsgBox("Check the date range.", vbCritical, "Notice")
            Exit Sub
        End If

        frm.FechaFin = dtpFin.Value
        frm.FechaInicio = dtpInicio.Value
        frm.Banco = CInt(celdaCodigo.Text)
        frm.Clase = strClase
        frm.Inicial = vbEmpty

        frm.Show()

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            querySqlMovimientos()
        End If


        'celdaDocumento.Text = dgMovimientos.SelectedCells(5).Value


    End Sub

    Private Sub botonTiposDocumentos_Click(sender As Object, e As EventArgs) Handles botonTiposDocumentos.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Dim strTabla As String
        strTabla = "(SELECT DISTINCT BMov_Cat_Doc ID FROM MvtosBcos WHERE BMov_Sis_Emp = {empresa} AND BMov_Cta = 1 AND BMov_Cat_Doc > 0) a LEFT JOIN Catalogos c ON c.cat_num = a.ID"
        strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
        strTabla = Replace(strTabla, "{cuenta}", celdaCodigo.Text)

        Try
            frm.Titulo = "Document Type"
            frm.FiltroText = " Enter the Name of Document Type To Filter"

            frm.Campos = " a.ID, c.cat_desc Descripcion"
            frm.Tabla = strTabla
            frm.Condicion = " ID <> 51"
            frm.Filtro = " cat_desc"
            frm.Ordenamiento = " ID"
            frm.TipoOrdenamiento = ""



            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaID_TDoc.Text = frm.LLave
                celdaTipoDoc.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgMovimientos_DoubleClick(sender As Object, e As EventArgs) Handles dgMovimientos.DoubleClick

        Dim intID As Integer = NO_FILA
        Dim Tipo As Integer
        Dim Categoria As Integer
        Me.Tag = "mod"

        Tipo = dgMovimientos.SelectedCells(1).Value
        Categoria = dgMovimientos.SelectedCells(12).Value

        Redimencionar(Tipo, Categoria)
        If dgMovimientos.SelectedRows.Count = INT_CERO Then Exit Sub

        intID = dgMovimientos.SelectedCells(0).Value
        celdaDocumento.Text = dgMovimientos.SelectedCells(5).Value
        celdaIDMon.Text = celdaIdMoneda.Text
        botonDocumento.Enabled = False
        'MostrarLista(2)
        CargarDocumento()
        CargarDetalle(Tipo, Categoria)
        If celdaIdMoneda.Text = 177 Then
            celdaMoned.Text = "Quetzales"
        ElseIf celdaIdMoneda.Text = 178 Then
            celdaMoned.Text = "Dolares"
        ElseIf celdaIdMoneda.Text = 179 Then
            celdaMoned.Text = "Euros"
        Else
            celdaMoned.Text = "Lempiras"
        End If


    End Sub

    Private Sub botonCuentaGastos_Click(sender As Object, e As EventArgs) Handles botonCuentaGastos.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Dim strCondicion As String = STR_VACIO
        Dim strSql As String
        Dim COM As New MySqlCommand
        Dim Parametro As String

        strSql = SQLParametroCG()

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        Parametro = COM.ExecuteScalar

        strCondicion = "empresa = {empresa} AND pid = {parametro}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{parametro}", Parametro)

        Try
            frm.Titulo = "Show Expenses"
            frm.FiltroText = " Enter the Name of Expense To Filter"

            frm.Tabla = "contahilos.cuentas"
            frm.Campos = " id_cuenta, nombre"
            frm.Condicion = strCondicion
            frm.Filtro = " nombre"
            frm.Ordenamiento = " id_cuenta"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Dim strFila As String = STR_VACIO
                strFila = -1 & "|" & -1 & "|" & -1 & "|" & -1 & "|" & frm.Dato & "|" & -1 & "|" & frm.LLave & "|" & -1 & "|" & -1 & "|" & -1 & "|" & -1 & "|" & NO_FILA & "|" & 1 & "|" & -1 & "|" & "CUENTA"

                cFunciones.AgregarFila(dgComprs, strFila)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgComprs_DoubleClick(sender As Object, e As EventArgs) Handles dgComprs.DoubleClick

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones

        Select Case dgComprs.CurrentCell.ColumnIndex

            Case 11

                Try
                    frm.Titulo = "Cost Center"
                    frm.FiltroText = " Enter Cost Name To Filter"
                    frm.Campos = " cost_num, cost_nombre"
                    frm.Tabla = CFUN.ContaEmpresa & ".costos "
                    frm.Condicion = "cost_num >=0"
                    frm.Limite = 20
                    frm.Ordenamiento = " cost_num"
                    frm.Filtro = "cost_nombre"
                    frm.TipoOrdenamiento = ""

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgComprs.SelectedCells(10).Value = frm.LLave
                        dgComprs.SelectedCells(11).Value = frm.Dato

                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

        End Select

    End Sub

    Private Sub botonCuentasContables_Click(sender As Object, e As EventArgs) Handles botonCuentasContables.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Dim strCondicion As String = STR_VACIO
        strCondicion = "empresa = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            frm.Titulo = "Accounting Accounts Show"
            frm.FiltroText = " Enter the Name of Settlement account To Filter"
            frm.Tabla = "contahilos.cuentas"
            frm.Campos = " id_cuenta, nombre"
            frm.Condicion = strCondicion
            frm.Filtro = " nombre"
            frm.Ordenamiento = " id_cuenta"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Dim strFila As String = STR_VACIO
                strFila = -1 & "|" & -1 & "|" & -1 & "|" & -1 & "|" & frm.Dato & "|" & -1 & "|" & frm.LLave & "|" & -1 & "|" & -1 & "|" & -1 & "|" & -1 & "|" & NO_FILA & "|" & 1 & "|" & -1 & "|" & "CUENTA"

                cFunciones.AgregarFila(dgComprs, strFila)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgComprs.SelectedRows.Count = 0 Then Exit Sub
        Try
            'Dim strFila As String
            If dgComprs.CurrentRow.Cells(12).Value = 0 Then
                dgComprs.SelectedCells(12).Value = 2
                dgComprs.CurrentRow.Visible = False
            Else
                dgComprs.Rows.Remove(dgComprs.CurrentRow)
            End If

        Catch ex As Exception
            '    MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click

        Dim strTabla As String = STR_VACIO
        strTabla = " (SELECT ef.HDoc_Doc_Ano ano, ef.HDoc_Doc_Num numero, ef.HDoc_Doc_Fec fecha, CONCAT(ef.HDoc_DR1_Num,' ',ef.HDoc_DR2_Num) referencia, IFNULL(ld.cat_ext,'') grupo, IF(ef.HDoc_Doc_Mon=177,'LOCAL','EXTERNA') divisa, lm.cat_num idmoneda, lm.cat_clave moneda, ef.HDoc_Doc_TC tasa, ROUND((cf.ECta_Crgo_Loc + COALESCE(SUM(cd.ECta_Crgo_Loc),0)) - COALESCE(SUM(cd.ECta_Abno_Loc),0),2) saldo_loc, ROUND((cf.ECta_Crgo_Ext + COALESCE(SUM(cd.ECta_Crgo_Ext),0)) - COALESCE(SUM(cd.ECta_Abno_Ext),0),2) saldo_ext, ef.HDoc_RF1_Txt notas,ef.HDoc_Sis_Emp empresa  FROM Dcmtos_HDR ef       INNER JOIN ECtaCte cf ON cf.ECta_Sis_Emp = ef.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = ef.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = ef.HDoc_Doc_Ano AND cf.ECta_Doc_Num = ef.HDoc_Doc_Num    LEFT JOIN ECtaCte cd ON cd.ECta_Sis_Emp = ef.HDoc_Sis_Emp AND cd.ECta_Ref_Cat = ef.HDoc_Doc_Cat AND cd.ECta_Ref_Ano = ef.HDoc_Doc_Ano AND cd.ECta_Ref_Num = ef.HDoc_Doc_Num AND NOT(cd.ECta_Doc_Cat = ef.HDoc_Doc_Cat)       LEFT JOIN Proveedores lc ON lc.pro_sisemp = ef.HDoc_Sis_Emp AND lc.pro_codigo = ef.HDoc_Emp_Cod      LEFT JOIN Catalogos lm ON lm.cat_clase='Monedas' AND lm.cat_num=ef.HDoc_Doc_Mon   LEFT JOIN Catalogos ld ON ld.cat_clase='Documentos' AND ld.cat_num=ef.HDoc_Doc_Cat    WHERE ef.HDoc_Sis_Emp = {empresa} AND ef.HDoc_Doc_Cat = 44 AND ef.HDoc_Emp_Cod ={id} AND ef.HDoc_Doc_Status = 1   GROUP BY ef.HDoc_Doc_Ano, ef.HDoc_Doc_Num) s1"
        strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
        strTabla = Replace(strTabla, "{id}", Val(celdaIDDatos.Text))
        Try
            frm.Titulo = "Supplier Invoices"
            frm.FiltroText = "Enter the Supplier Invoice to filter"
            frm.Campos = "ROUND(IF(divisa='LOCAL',saldo_loc,saldo_ext),2) saldo, s1.*"
            frm.Tabla = strTabla
            frm.Condicion = " numero > 0"
            frm.Condicion2 = " NOT(saldo=0)"
            frm.Filtro = " numero"
            frm.Ordenamiento = " fecha, numero"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                Dim strFila As String = STR_VACIO
                strFila = frm.Dato & "|" & frm.Dato2 & "|" & -1 & "|" & -1 & "|" & "No. " & frm.Dato4 & "de fecha " & frm.Dato3 & "|" & frm.LLave & "|" & -1 & "|" & -1 & "|" & -1 & "|" & 44 & "|" & NO_FILA & "|" & -1 & "|" & 1 & "|" & -1 & "|" & "COMPRA"

                cFunciones.AgregarFila(dgComprs, strFila)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonDocumento_Click(sender As Object, e As EventArgs) Handles botonDocumento.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Try
            frm.Titulo = "Document Type"
            frm.FiltroText = " Enter the Name of Document Type To Filter"

            frm.Tabla = "(SELECT DISTINCT BMov_Cat_Doc ID FROM MvtosBcos WHERE BMov_Sis_Emp = 12 AND BMov_Cta = 1 AND BMov_Cat_Doc > 0) a LEFT JOIN Catalogos c ON c.cat_num = a.ID"
            frm.Campos = " a.ID, c.cat_desc Descripcion"
            frm.Condicion = " ID <> 51"
            frm.Filtro = " cat_desc"
            frm.Ordenamiento = " ID"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDDocumento.Text = frm.LLave
                celdaDocumento.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonAmarrar_Click(sender As Object, e As EventArgs) Handles botonAmarrar.Click

        Dim frm As New frmSeleccionar
        Dim CFUN As New clsFunciones
        Dim strCondicion As String = STR_VACIO
        strCondicion = "WHERE BCta_Sis_Emp = {empresa} AND BCta_Tipo = 0"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        Try
            frm.Titulo = "Document List"
            frm.FiltroText = " Enter the Name of Document To Filter"

            frm.Tabla = " FROM CtasBcos"
            frm.Campos = " SELECT *"
            frm.Condicion = strCondicion
            frm.Filtro = " BCta_Nom_Cue"
            frm.Ordenamiento = " BCta_Num_Cue"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub rbPago_CheckedChanged(sender As Object, e As EventArgs) Handles rbPago.CheckedChanged
        OptionItems()
        If Me.rbPago.Checked = True Then
            CambioRB()
        End If
    End Sub

    Private Sub rbImpuesto_CheckedChanged(sender As Object, e As EventArgs) Handles rbImpuesto.CheckedChanged
        OptionItems()
        If Me.rbImpuesto.Checked = True Then
            CambioRB()
        End If
    End Sub

    Private Sub rbAnticipoSCompras_CheckedChanged(sender As Object, e As EventArgs) Handles rbAnticipoSCompras.CheckedChanged
        OptionItems()
        If Me.rbAnticipoSCompras.Checked = True Then
            CambioRB()
        End If
    End Sub

    Private Sub rbGasto_CheckedChanged(sender As Object, e As EventArgs) Handles rbGasto.CheckedChanged
        OptionItems()
        If Me.rbGasto.Checked = True Then
            CambioRB()
        End If
    End Sub

    Private Sub botonAsignarPresupuesto_Click(sender As Object, e As EventArgs) Handles botonAsignarPresupuesto.Click
        CargarPresupuesto()
        frmP.Monto = CDbl(celdaMonto.Text)

        frmP.ShowDialog(Me)
        frmP.Hide()
    End Sub

    Private Sub celdaMonto_TextChanged(sender As Object, e As EventArgs) Handles celdaMonto.TextChanged
        Try
            If IsNumeric(celdaMonto.Text) Then
                celdaTotaLetras.Text = cFunciones.ALetras(celdaMonto.Text)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonPolizaContable_Click(sender As Object, e As EventArgs) Handles botonPolizaContable.Click
        Dim PC As New clsPolizaContable


        PC.intModo = 14
        PC.intTipo = 51
        PC.intCiclo = celdaAno.Text
        PC.intNumero = celdaNum.Text
        PC.MostrarPolizaContable()
    End Sub

    Private Sub botonCambiarCategoria_Click(sender As Object, e As EventArgs) Handles botonCambiarCategoria.Click
        Dim Empresa As Integer
        Dim Anio As Integer
        Dim Numero As Integer
        Dim Tipo As Integer

        MsgBox("NOTA:  Después de reclasificar el documento verifique que todos los datos esten correctos" & vbCr & vbCr & "También deberá guardar el documento para que se genere la póliza contable ", vbInformation, "Aviso")

        Empresa = Sesion.IdEmpresa


    End Sub

#End Region
End Class