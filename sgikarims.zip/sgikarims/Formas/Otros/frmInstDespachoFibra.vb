﻿Public Class frmInstDespachoFibra
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 942
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer
    Dim contratoNum As Integer
    Dim Descargos As Integer
    Private Const DOC_NAME As String = "Doc_CPedido"
    Dim strTextoComentario As String

    Private dblSaldo As Double
    Private intLinea As Integer
    Private dblDocCantidad As Double
    Private dblDocTotal As Double

    'Constantes
    Public Const PRE_PF As String = "PF "
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Private Const STR_NOMBRE As String = "cliente"

    'Si el documento tiene descargos indica la línea mayor
    Private intMaxRef As Integer

    Public logRelacion As Boolean

    Dim dtpDetalle As DateTimePicker
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
            ' botonBuscar.Enabled = True

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
            'botonBuscar.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Dispatch Instruction Fiber")
            queryListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                '   BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
            End If
            'Reset()
            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String

        Dim strFiltrarLista As String
        Dim ErrorLog As String

        On Error GoTo e_error

        strFiltrarLista = " SELECT h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom cliente, h.HDoc_Doc_Status estado, h.HDoc_Doc_Ano anio, h.HDoc_emp_Dir Direccion,h.HDoc_Doc_TC Tasa,e.HDoc_DR1_Num PF"
        strFiltrarLista &= "    FROM Dcmtos_HDR h"
        strFiltrarLista &= "        LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num "
        strFiltrarLista &= "    LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = p.PDoc_Par_Cat AND e.HDoc_Doc_Ano = p.PDoc_Par_Ano AND e.HDoc_Doc_Num = p.PDoc_Par_Num "
        strFiltrarLista &= "  Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 942"

        If checkFecha.Checked = True Then

            strFiltrarLista &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strFiltrarLista = Replace(strFiltrarLista, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strFiltrarLista = Replace(strFiltrarLista, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If

        strFiltrarLista &= "   Order By h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC"


        strFiltrarLista = Replace(strFiltrarLista, "{empresa}", Sesion.IdEmpresa)

        Return strFiltrarLista


e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        ' ErrorLog "Formulario -> Form.SqlLista()"
        On Error GoTo 0


    End Function
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = -1
        celdaNumero.Text = -1
        celdaDireccion.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaIDCliente.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        dtpFecha1.Text = STR_VACIO
        celdaTC.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaTotales.Text = 0
        celdaTotales2.Text = 0
        dgDetalle.Rows.Clear()
        celdaImpuestos.Text = NO_FILA
        BotonCliente.Enabled = True
        checkActivo.Checked = False
        checkActivo.Enabled = True
        dgPedidos.Rows.Clear()
        ' logInsertar = False
        LogBorrar = True
    End Sub
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim r As Integer
        strSQL = SQLLista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("cliente") & "|"
                    strFila &= REA.GetString("PF") & "|"
                    strFila &= REA.GetInt32("estado") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("Tasa")

                    r = REA.GetInt32("estado")

                    'cFunciones.AgregarFila(dgLista, strFila)
                    AgregarFila(dgLista, strFila, r)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)
                If Estado = 0 Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Red
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next
            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function SQLDocParaProcesar() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT DISTINCT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat catalogo, e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num pf, e.HDoc_Doc_Fec fecha, COALESCE(e.HDoc_DR1_Num,'') numero, e.HDoc_Usuario usuario"
        strSQL &= "  FROM Dcmtos_HDR e"
        strSQL &= "      LEFT JOIN Dcmtos_DTL d ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSQL &= "          WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 941 AND e.HDoc_Emp_Cod = {cliente} AND e.HDoc_Doc_Status = {activo}  AND (COALESCE(("
        strSQL &= "              SELECT SUM(c.DDoc_Prd_QTY)"
        strSQL &= "                  FROM Dcmtos_DTL c"
        strSQL &= "                      WHERE c.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND c.DDoc_Doc_Cat = d.DDoc_Doc_Cat AND c.DDoc_Doc_Ano = d.DDoc_Doc_Ano AND c.DDoc_Doc_Num = d.DDoc_Doc_Num AND c.DDoc_Prd_Cod = d.DDoc_Prd_Cod),0) > COALESCE(("
        strSQL &= "                          SELECT SUM(p.PDoc_QTY_Pro)"
        strSQL &= "                       FROM Dcmtos_DTL_Pro p"
        strSQL &= "                    WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Cat = 942 AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0))"
        strSQL &= "               ORDER BY e.HDoc_Doc_Ano ASC, e.HDoc_Doc_Num ASC"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cliente}", celdaIDCliente.Text)
        strSQL = Replace(strSQL, "{activo}", 1)

        Return strSQL
    End Function
    Private Sub DocumentosPendientes()
        Me.Tag = "Nuevo"
        Dim strSQL As String
        Dim strTemp As String
        Dim intAño As Integer
        Dim intNumero As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim i As Integer

        intAño = celdaAño.Text
        intNumero = celdaNumero.Text
        'dgInstrucDespacho.ColumnCount = vbEmpty
        If Me.Tag = "Mod" Then
            'strSQL = SQLDocProcesados()
        Else
            strSQL = SQLDocParaProcesar()
        End If
        'Agrega todos los registros de la selección
        MyCnn.CONECTAR = strConexion
        Try
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    strTemp = vbNullString
                    strTemp &= REA.GetInt32("pf") & "|"
                    strTemp &= REA.GetDateTime("fecha") & "|"
                    strTemp &= REA.GetString("usuario") & "|"
                    strTemp &= REA.GetString("numero") & "|"
                    strTemp &= REA.GetInt32("anio") & "|"
                    strTemp &= 1
                    cfun.AgregarFila(dgPedidos, strTemp)
                Loop
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub SqlDetallePorProcesar2(Optional ByVal Preguntar As Boolean = True)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim Array() As String
        Dim strTEMP As String = STR_VACIO
        Dim strTEMP2 As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Dim Temp As Double
        Dim Temp1 As Double
        Dim Temp2 As Double
        Dim contador As Integer = 0

        If dgPedidos.Rows.Count > 0 Then

            If dgPedidos.Rows.Count > 0 Then
                If Preguntar Then
                    If MsgBox("¿Show details of all documents in the list?", vbQuestion + vbYesNo + vbDefaultButton2, "Document detail") = vbNo Then
                        Exit Sub
                    End If
                End If
            End If

            For i = 0 To dgPedidos.Rows.Count - 1
                If i > 0 Then
                    strTEMP = strTEMP & " OR "
                End If
                If dgPedidos.Rows.Count - 1 >= 0 Then
                    strTEMP = strTEMP & " (d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND d.DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value & ")"
                Else
                End If
            Next

            strSQL = vbNullString
            strSQL = "  SELECT l1.*,(l1.Ordenado - l1.Despachado) Saldo FROM( "
            strSQL &= "     SELECT d.DDoc_Doc_Ano Anio,d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Fec Fecha, d.DDoc_Prd_Cod Codigo,"
            strSQL &= "         pf.prf_descripcion Descripcion,d.DDoc_Prd_NET Precio, m.cat_clave Medida, d.DDoc_Prd_UM Unidad, 0 Cantidad, d.DDoc_Prd_UM Base,"
            strSQL &= "          d.DDoc_Prd_QTY Ordenado, IFNULL(d.DDoc_RF2_Txt,'') Observaciones, IFNULL(("
            strSQL &= "             SELECT SUM(p.PDoc_QTY_Pro) Despachado"
            strSQL &= "                 FROM Dcmtos_DTL_Pro p "
            strSQL &= "                     WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat  = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano  = d.DDoc_Doc_Ano AND p.PDoc_Par_Num  = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin),0) Despachado"
            strSQL &= "                         FROM Dcmtos_DTL d  "
            strSQL &= "                             LEFT JOIN Producto_Fibra pf ON pf.prf_sisemp = d.DDoc_Sis_Emp AND pf.prf_numero = d.DDoc_Prd_Cod "
            strSQL &= "                                  LEFT JOIN Catalogos m ON m.cat_num = d.DDoc_Prd_UM AND m.cat_clase = 'Medidas'"
            strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND  d.DDoc_Doc_Cat = {documento} "
            strSQL &= "              And ({lista})"
            strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
            strSQL &= " )l1 HAVING Saldo> 0"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{documento}", 941)
            strSQL = Replace(strSQL, "{lista}", strTEMP)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then

                    dgDetalle.Rows.Clear()
                    Do While REA.Read
                        Dim strFila As String = STR_VACIO

                        strFila = REA.GetInt32("Anio") & "|"
                        strFila &= REA.GetInt32("Catalogo") & "|"
                        strFila &= REA.GetInt32("Numero") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= REA.GetDateTime("Fecha") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        strFila &= REA.GetString("Descripcion") & "|"
                        strFila &= REA.GetString("Medida") & "|"
                        strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                        strFila &= (REA.GetDouble("Ordenado") - REA.GetDouble("Despachado")).ToString(FORMATO_MONEDA) & "|"
                        strFila &= INT_CERO & "|"
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= INT_CERO & "|"
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= 0 & "|"
                        strFila &= REA.GetInt32("Base") & "|"
                        strFila &= REA.GetString("Observaciones")
                        cFunciones.AgregarFila(dgDetalle, strFila)
                    Loop
                End If
                'CalcularTotales()
                For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
                    'If dgDetalle.Rows(i).Selected Then
                    If dgDetalle.Rows(i).Visible = True Then
                        contador = contador + 1
                        dgDetalle.Rows(i).Cells("colLineaDesc").Value = contador
                    End If
                    'End If
                Next
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub
    Private Function SqlDetallePorProcesar(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT l1.*,(l1.Ordenado - l1.Despachado) Saldo"
        strSQL &= " FROM ( "
        strSQL &= "     SELECT d.DDoc_Doc_Ano Anio,d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Fec Fecha, d.DDoc_Prd_Cod Codigo,"
        strSQL &= "         pf.prf_descripcion Descripcion,d.DDoc_Prd_NET Precio, m.cat_clave Medida, d.DDoc_Prd_UM Unidad, 0 Cantidad, d.DDoc_Prd_UM Base,"
        strSQL &= "             d.DDoc_Prd_QTY Ordenado, IFNULL(d.DDoc_RF2_Txt,'') Observaciones, IFNULL(("
        strSQL &= "                 SELECT SUM(p.PDoc_QTY_Pro) Despachado"
        strSQL &= "                     FROM Dcmtos_DTL_Pro p "
        strSQL &= "                         WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat  = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano  = d.DDoc_Doc_Ano AND p.PDoc_Par_Num  = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin),0) Despachado"
        strSQL &= "                       FROM Dcmtos_DTL d  "
        strSQL &= "                             LEFT JOIN Producto_Fibra pf ON pf.prf_sisemp = d.DDoc_Sis_Emp AND pf.prf_numero = d.DDoc_Prd_Cod "
        strSQL &= "                                  LEFT JOIN Catalogos m ON m.cat_num = d.DDoc_Prd_UM AND m.cat_clase = 'Medidas'"
        strSQL &= "                             WHERE d.DDoc_Sis_Emp = {empresa} AND  d.DDoc_Doc_Cat = {documento} AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num={numero} "
        strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strSQL &= " )l1 HAVING Saldo> 0 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 941)
        strSQL = Replace(strSQL, "{año}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function
    Private Function NuevaFactura() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}   "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 942)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean = True
        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = 942
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha1.Value
            chdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, vbEmpty)

            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNit.Text

            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            chdr.HDOC_DOC_TC = celdaTC.Text
            chdr.HDOC_USUARIO = celdaUsuario.Text
            'Proveedor 
            '    chdr.HDOC_PRO_DCAT = celdaRevisado.Text
            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    'Query para guardar el Detalle
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intLinea As Integer = vbEmpty
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                strSQL = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
                strSQL &= "      FROM Dcmtos_DTL d"
                strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{catalogo}", 942)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    intLinea = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using


                If dgDetalle.Rows(i).Visible = True Then
                    Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                    Dtl.DDOC_DOC_CAT = 942
                    Dtl.DDOC_DOC_ANO = celdaAño.Text
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    If Me.Tag = "Nuevo" Or dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                        Dtl.DDOC_DOC_LIN = intLinea
                        dgDetalle.Rows(i).Cells("colLineaDesc").Value = intLinea
                        'dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                    Else
                        Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaDesc").Value

                    End If

                    Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                    Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colArticulo").Value
                    Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value

                    Dtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colExistencia").Value
                    Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colADespachar").Value



                    If dgDetalle.Rows(i).Cells("colFech").Value = "" Then
                        Dtl.DDOC_RF1_FEC = Nothing
                    Else
                        Dtl.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colFech").Value
                    End If
                    If dgDetalle.Rows(i).Cells("colFechaFactura").Value = "" Then
                        Dtl.DDOC_RF2_FEC = Nothing
                    Else
                        Dtl.DDoc_RF2_Fec_NET = dgDetalle.Rows(i).Cells("colFechaFactura").Value
                    End If
                    Dtl.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colBulto").Value
                    Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colFactura").Value
                    Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colLote").Value
                    Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colGRS").Value
                    Dtl.DDOC_RF3_TXT = dgDetalle.Rows(i).Cells("colTC").Value

                    If dgDetalle.Rows(i).Cells("colObservation").Value = vbNullString Then
                    Else
                        Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colObservation").Value
                    End If

                        If dgDetalle.Rows(i).Cells("colXtra").Value = 1 And Me.Tag = "Mod" Then
                            If Dtl.Actualizar() = False Then
                                MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Or Me.Tag = "Nuevo" Then
                            If Dtl.Guardar() = False Then
                                MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        End If
                    End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    'Guardar Descargo
    Private Sub GuardarDescargo()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        'Parent: 75/Pedido
        'Child:  48/Instrucción de despacho
        Dim dblCantidad As Double
        Dim j As Integer = 0
        Dim Linea As Integer = 0
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL2 As String = STR_VACIO

        clsDTLPro.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = celdaEmpresa.Text
                clsDTLPro.PDOC_PAR_CAT = 941
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAno").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNPedido").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                clsDTLPro.PDOC_CHI_CAT = 942
                clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text

                If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then

                    clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaDesc").Value
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaDesc").Value
                End If
                clsDTLPro.PDOC_PROV_COD = celdaIDCliente.Text                                'Cód. del proveedor
                clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value           'Cód. del pedido
                clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value            'DDoc_Prd_NET/Precio neto
                dblCantidad = vbEmpty
                If checkActivo.Checked = True Then
                    dblCantidad = dgDetalle.Rows(i).Cells("colExistencia").Value
                End If
                If checkActivo.Checked = True Then
                    clsDTLPro.PDOC_QTY_ORD = dblCantidad     'A Despachar
                    clsDTLPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colADespachar").Value  'A despachar (vacío para documentos anulados/inactivos)
                Else
                    clsDTLPro.PDOC_QTY_ORD = INT_CERO      'A Despachar
                    clsDTLPro.PDOC_QTY_PRO = INT_CERO                                        'A despachar (vacío para documentos anulados/inactivos)
                End If
                If dgDetalle.Rows(i).Cells("colXtra").Value = 1 And dgDetalle.Rows(i).Visible = True Then
                    If clsDTLPro.Actualizar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If

                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 And dgDetalle.Rows(i).Visible = True Then
                    If clsDTLPro.Guardar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarLineDetalle(ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Visible = False Then

                strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Num ={numero} AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Lin ={linea}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{numero}", intNumero)
                strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaDesc").Value)

                Dim dtl As New clsDcmtos_DTL
                dtl.CONEXION = strConexion
                dtl.Borrar(strSQL)

            End If
        Next
    End Sub
    Private Sub BorrarLineaDescargo()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim dblCantidad As Double
        Dim j As Integer = 0

        clsDTLPro.CONEXION = strConexion
        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    clsDTLPro.PDOC_SIS_EMP = celdaEmpresa.Text
                    clsDTLPro.PDOC_PAR_CAT = 941
                    clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAno").Value
                    clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNPedido").Value
                    clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                    clsDTLPro.PDOC_CHI_CAT = 942
                    clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                    clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text

                    If Me.Tag = "Nuevo" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = j + 1
                        End If
                        clsDTLPro.PDOC_CHI_LIN = j
                    ElseIf Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = dgDetalle.Rows.Count - 1
                            j = j + 1
                        End If
                        clsDTLPro.PDOC_CHI_LIN = j
                    Else
                        clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaDesc").Value
                    End If
                    'clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                    clsDTLPro.PDOC_PROV_COD = celdaIDCliente.Text                                'Cód. del proveedor
                    clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value           'Cód. del pedido
                    clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value            'DDoc_Prd_NET/Precio neto
                    dblCantidad = vbEmpty
                    If checkActivo.Checked = True Then
                        dblCantidad = dgDetalle.Rows(i).Cells("colExistencia").Value
                    End If

                    clsDTLPro.PDOC_QTY_ORD = dblCantidad     'A Despachar
                    clsDTLPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colADespachar").Value  'A despachar (vacío para documentos anulados/inactivos)

                    If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                        If clsDTLPro.Borrar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLSaldoPFFibra(ByVal catalogo As Integer, ByVal anio As Integer, ByVal numero As Integer, ByVal linea As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT ROUND(SUM(d.DDoc_Prd_QTY) - COALESCE(( "
        strSQL &= " SELECT SUM(p.PDoc_QTY_Pro) "
        strSQL &= "     FROM Dcmtos_DTL_Pro p  "
        strSQL &= "         WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin),0),2) Saldo "
        strSQL &= "             FROM Dcmtos_DTL d"
        strSQL &= "         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogo)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)
        strSQL = Replace(strSQL, "{linea}", linea)
        Return strSQL
    End Function
    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        'Revisar que los datos de la cabecera no estén en blanco.
        If celdaEmpresa.Text = vbNullString Or
            celdaCatalogo.Text = vbNullString Or
            celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete Data System", vbCritical)
            'Exit Function
            comprobar = False
        End If
        If celdaAño.Text = NO_FILA Or
            celdaIDCliente.Text = NO_FILA Or
            celdaCliente.Text = STR_VACIO Or
            celdaNit.Text = STR_VACIO Or
            celdaIDMoneda.Text = NO_FILA Or
            celdaTC.Text = NO_FILA Then
            MsgBox("You must enter all minium data", vbCritical)
            'Exit Function
            comprobar = False
        End If
        If Not IsDate(dtpFecha1.Value) Then
            MsgBox("You have not entered a valid date", vbExclamation, "Notice")
            'Exit Function
            comprobar = False
        ElseIf Not Val(celdaAño.Text) = Year(dtpFecha1.Value) Then
            MsgBox("The date entered does not match the year of the document", vbExclamation, "Notice")
            'Exit Function
            comprobar = False
        End If
        Return comprobar
    End Function
    Private Function ComprobarFilaDetalle() As Boolean
        Dim i As Integer = 0
        Dim Comprobacion As Boolean = True
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intLinea As Integer
        Dim intCatalogo As Integer
        Dim Despachar As Double
        Dim intNumInstruccion As Double
        Dim intAnoInstruccion As Double
        Dim intLineaIntruccion As Double
        Dim Saldo As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        For i = 0 To dgDetalle.Rows.Count - 1
            If (dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0) And dgDetalle.Rows(i).Visible = True Then
                ' If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                If dgDetalle.Rows(i).Cells("colCodigo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Article code invalid")
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colArticulo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item description")
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colPrecio").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item Price")
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colADespachar").Value = INT_CERO Then
                    Comprobacion = False
                    MsgBox("Blank item Dispacht")
                    Exit Function
                End If
                If dgDetalle.Rows(i).Cells("colBulto").Value = INT_CERO Then
                    Comprobacion = False
                    MsgBox("Blank Package")
                    Exit Function
                End If
                intCatalogo = dgDetalle.Rows(i).Cells("colCatalogo").Value
                intAnio = dgDetalle.Rows(i).Cells("colAno").Value
                intNumero = dgDetalle.Rows(i).Cells("colNPedido").Value
                intLinea = dgDetalle.Rows(i).Cells("colLinea").Value

                strSQL = SQLSaldoPFFibra(intCatalogo, intAnio, intNumero, intLinea)
                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    Saldo = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using
                Despachar = dgDetalle.Rows(i).Cells("colADespachar").Value
                If CDbl(Despachar > Saldo) Then
                    Comprobacion = False
                    MsgBox("You cant not download one more to its existence", vbExclamation, "Notice")
                    Exit Function
                End If
            End If
        Next
        ComprobarFilaDetalle = Comprobacion
        Return Comprobacion
    End Function
    Private Function SqlEncabezado(ByVal intAnio As Integer, intNumero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Doc_Ano anio , h.HDoc_Doc_Num numero , h.HDoc_Doc_Fec fecha , h.HDoc_Emp_Cod codigoCliente , h.HDoc_Emp_Nom NombreCliente , h.HDoc_Emp_Dir Direccion , "
        strSQL &= "      h.HDoc_Emp_NIT Nit,c.cat_clave Moneda , c.cat_num idMoneda , h.HDoc_Doc_TC Tasa , h.HDoc_Doc_Status Estado  "
        strSQL &= "         FROM Dcmtos_HDR h "
        strSQL &= "             LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_DR1_Emp "
        strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
        strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 942 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        Return strSQL
    End Function
    Private Function SqlDetalle(ByVal intAnio As Integer, intNumero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT dp.PDoc_Par_Ano Anio,dp.PDoc_Par_Cat Catalogo,dp.PDoc_Par_Num NumPF , dp.PDoc_Par_Lin Linea ,d.DDoc_RF1_Fec fecha, pf.prf_numero codigoFibra, pf.prf_descripcion DescripcionFibra, "
        strSQL &= " c.cat_clave Medida , d.DDoc_Prd_NET Precio , d.DDoc_Prd_DSP Disponible, d.DDoc_Doc_Lin Linea2 , d.DDoc_RF1_Cod Factura ,d.DDoc_RF1_Txt Lote , IFNULL(d.DDoc_RF2_Fec,'') FechaFactura,d.DDoc_RF2_Dbl Bulto, d.DDoc_Prd_QTY Cantidad , d.DDoc_RF2_Cod GRS, d.DDoc_RF3_Txt TC ,c.cat_num idMedida,d.DDoc_RF2_Txt Observacion "
        strSQL &= "     FROM Dcmtos_DTL d  "
        strSQL &= "         LEFT JOIN Producto_Fibra pf ON pf.prf_sisemp = d.DDoc_Sis_Emp AND pf.prf_numero = d.DDoc_Prd_Cod "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND dp.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND dp.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND dp.PDoc_Chi_Num = d.DDoc_Doc_Num  "
        strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 942 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL &= "         GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
        strSQL &= "     ORDER BY d.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        Return strSQL
    End Function
    Private Function SqlDocumentosProcesados(ByVal intAnio As Integer, intNumero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT DISTINCT HDoc_Doc_Num PF, HDoc_Doc_Fec Fecha, HDoc_Usuario Usuario, HDoc_DR1_Num Numero, HDoc_Doc_Ano Ano "
        strSQL &= "     FROM Dcmtos_DTL_Pro p "
        strSQL &= "         INNER JOIN Dcmtos_HDR b ON p.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND p.PDoc_Par_Cat = b.HDoc_Doc_Cat AND p.PDoc_Par_Ano = b.HDoc_Doc_Ano AND p.PDoc_Par_Num = b.HDoc_Doc_Num "
        strSQL &= "             WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 941 AND p.PDoc_Chi_Cat = 942 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {numero}  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SqlEncabezado(intAnio, intNumero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaAño.Text = REA.GetInt32("anio")
                    celdaNumero.Text = REA.GetInt32("numero")
                    dtpFecha1.Value = REA.GetDateTime("fecha")
                    celdaIDCliente.Text = REA.GetInt32("codigoCliente")
                    celdaCliente.Text = REA.GetString("NombreCliente")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaNit.Text = REA.GetString("Nit")
                    celdaIDMoneda.Text = REA.GetInt32("idMoneda")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaTC.Text = REA.GetDouble("Tasa")

                    celdaEmpresa.Text = Sesion.IdEmpresa
                    celdaCatalogo.Text = 942
                    If REA.GetInt32("Estado") = 1 Then
                        checkActivo.Enabled = True
                        checkActivo.Checked = True
                    Else
                        checkActivo.Enabled = False
                        checkActivo.Checked = False
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDetalle(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SqlDetalle(intAnio, intNumero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("NumPF") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetInt32("codigoFibra") & "|"
                    strFila &= REA.GetString("DescripcionFibra") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= REA.GetDouble("Disponible") & "|"
                    strFila &= REA.GetInt32("Linea2") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetString("Lote") & "|"
                    strFila &= REA.GetString("FechaFactura") & "|"
                    strFila &= REA.GetDouble("Bulto") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= (REA.GetDouble("Precio") * REA.GetDouble("Cantidad")) & "|"
                    strFila &= REA.GetString("GRS") & "|"
                    strFila &= REA.GetString("TC") & "|"
                    strFila &= 1 & "|"
                    strFila &= REA.GetInt32("idMedida") & "|"
                    strFila &= REA.GetString("Observacion")
                    cfun.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDescargos(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SqlDocumentosProcesados(intAnio, intNumero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgPedidos.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("PF") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Numero") & "|"
                    strFila &= REA.GetInt32("Ano") & "|"
                    strFila &= 2
                    cfun.AgregarFila(dgPedidos, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Metodos de Borrar Documento
    Private Sub EliminarEncabezado()
        Dim strSQL As String = STR_VACIO
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 942
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarDetalle()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = 942 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function BorrarDescargos() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 942 AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero}  "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)

                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double

        Try
            dblDocCantidad = 0
            dblDocTotal = 0
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                dblPrecio = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                dblCant = CDbl(dgDetalle.Rows(i).Cells("colADespachar").Value)

                dblDocTotal = dblDocTotal + (dblCant * dblPrecio)
                dblDocCantidad = dblDocCantidad + dblCant

            Next
            celdaTotales.Text = dblDocCantidad.ToString(FORMATO_MONEDA)
            celdaTotales2.Text = dblDocTotal.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
#End Region
#Region "Eventos"
    Private Sub frmInstDespachoFibra_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpInicio.Value = dtpInicio.Value.AddMonths(NO_FILA)
        dtpFin.Value = Today
        MostrarLista()
        Accessos()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"

        If logInsertar = True Then
            LimpiarPanelOrden()
            celdaTC.Text = cFunciones.QueryTasa("CURDATE()")
            MostrarLista(False, True)
            celdaAño.Text = cFunciones.AñoMySQL
            celdaNumero.Text = -1
            '    celdaFecha.Text = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)
            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 942
            celdaUsuario.Text = Sesion.Usuario
            '     CeldaCarga.Text = 0
            celdaMoneda.Text = "US$"
            celdaIDMoneda.Text = 178
            botonMas.Enabled = True
            botonEliminar.Enabled = True
            botonDelete.Enabled = True
            celdaTotales.Enabled = True
            celdaTotales2.Enabled = True
            checkActivo.Enabled = True
            checkActivo.Checked = True
            '    celdaIdCosteo.Text = INT_CERO
            '     celdaCosteo.Clear()

            '       logComentario = False
            '       logBloquear = False
            dgDetalle.ReadOnly = False

            '     rbFleteCliente.Checked = True
            '     rbGastosCliente.Checked = True
        Else
            MsgBox("You Do Not have access To create a New instruction")
        End If
    End Sub
    Private Sub BotonCliente_Click(sender As Object, e As EventArgs) Handles BotonCliente.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Client"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "cli_codigo code,cli_cliente Client, cli_direccion Direction, cli_telefono Phone, cli_nit NIT"
        frm.Tabla = "Clientes"
        frm.Condicion = strCondicion
        frm.Limite = 20
        frm.Ordenamiento = "cli_cliente < 0"
        frm.Filtro = "cli_cliente"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
            celdaDireccion.Text = frm.Dato2
            celdaNit.Text = frm.Dato4

            dgPedidos.Rows.Clear()
            DocumentosPendientes()
            SqlDetallePorProcesar2(True)
        End If
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
            '  LimpiarPanelOrden()
        End If
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            Else
                Exit Sub
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            celdaTC.Text = Cambio


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgPedidos_DoubleClick(sender As Object, e As EventArgs) Handles dgPedidos.DoubleClick
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strLinea As String = STR_VACIO
        Dim Contador As Integer = 0
        Dim intAnio As Integer = INT_CERO
        Dim intNumero As Integer = INT_CERO
        Try
            dgPedidos.CurrentRow.Cells(5).Value = 2
            For j As Integer = 0 To dgPedidos.Rows.Count - 1
                If dgPedidos.Rows.Count = 1 Then
                    'dgPedidos.Rows.RemoveAt(j)
                ElseIf dgPedidos.Rows(j).Cells("colExtra").Value = 2 Then
                    dgPedidos.CurrentRow.Cells(5).Value = 1
                    strFila = dgPedidos.Rows(j).Cells("colPF").Value & "|" & dgPedidos.Rows(j).Cells("colFecha").Value & "|" & dgPedidos.Rows(j).Cells("colOperador").Value & "|" & dgPedidos.Rows(j).Cells("colPOCliente").Value & "|" & dgPedidos.Rows(j).Cells("colYear").Value & "|" & dgPedidos.Rows(j).Cells("colExtra").Value
                    intNumero = dgPedidos.Rows(j).Cells("colPF").Value
                    intAnio = dgPedidos.Rows(j).Cells("colYear").Value
                End If
            Next
            dgPedidos.Rows.Clear()
            cFunciones.AgregarFila(dgPedidos, strFila)
            MyCnn.CONECTAR = strConexion
            dgDetalle.Rows.Clear()
            strSQL = SqlDetallePorProcesar(intAnio, intNumero)
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = STR_VACIO
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= (REA.GetDouble("Ordenado") - REA.GetDouble("Despachado")).ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("Base") & "|"
                    strFila &= REA.GetString("Observaciones")
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
            'CalcularTotales()
            For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
                'If dgDetalle.Rows(i).Selected Then
                If dgDetalle.Rows(i).Visible = True Then
                    Contador = Contador + 1
                    dgDetalle.Rows(i).Cells("colLineaDesc").Value = Contador
                End If
                'End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim conec As MySqlConnection
            Dim strSQL As String = STR_VACIO
            Dim Codigo As Integer

            'strVal = dgDetalle.SelectedCells(0).Value
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 13
                    Try
                        Dim Calendar As New frmDateTimePicker
                        Calendar.ShowDialog(Me)
                        If Calendar.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.SelectedCells(13).Value = Calendar.LLave
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 17
                    Try
                        Dim opt As New frmOption
                        opt.Titulo = "Option"
                        opt.Mensaje = "Select an option"
                        opt.Opciones = "Sent" & "|" & "Pending" & "|" & "Draft" & "|" & "N/A"

                        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                            Select Case opt.Seleccion
                                Case 0
                                    dgDetalle.SelectedCells(17).Value = "Sent"
                                Case 1
                                    dgDetalle.SelectedCells(17).Value = "Pending"
                                Case 2
                                    dgDetalle.SelectedCells(17).Value = "Draft"
                                Case 3
                                    dgDetalle.SelectedCells(17).Value = "N/A"
                            End Select
                        Else
                            Exit Sub
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
            End Select
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strTabla = "Dcmtos_HDR e  LEFT JOIN Dcmtos_DTL d ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strCondicion = "e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 941 AND e.HDoc_Emp_Cod = {numero} AND e.HDoc_Doc_Status = 1  AND (COALESCE((SELECT SUM(c.DDoc_Prd_QTY)FROM Dcmtos_DTL c WHERE c.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND c.DDoc_Doc_Cat = d.DDoc_Doc_Cat AND c.DDoc_Doc_Ano = d.DDoc_Doc_Ano AND c.DDoc_Doc_Num = d.DDoc_Doc_Num AND c.DDoc_Prd_Cod = d.DDoc_Prd_Cod),0) > COALESCE((SELECT SUM(p.PDoc_QTY_Pro) FROM Dcmtos_DTL_Pro p WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Cat = 942 AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0))"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        strCondicion = Replace(strCondicion, "{numero}", celdaIDCliente.Text)
        Try
            frm.Titulo = "Client"
            frm.Campos = " DISTINCT e.HDoc_Doc_Num pf, e.HDoc_Doc_Fec fecha, e.HDoc_Usuario usuario, COALESCE(e.HDoc_DR1_Num,'') numero, e.HDoc_Doc_Ano anio, e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat catalogo"
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            frm.FiltroText = " Enter the PF Number to filter"
            frm.Filtro = "  e.HDoc_Doc_Num"
            frm.Limite = 30
            frm.Ordenamiento = " e.HDoc_Doc_Num, e.HDoc_Doc_Ano "
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Dim strFila As String = STR_VACIO
                strFila = (frm.LLave) & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & frm.Dato4 & "|" & 2
                cfun.AgregarFila(dgPedidos, strFila)
            Else
                Exit Sub

            End If
            SqlDetallePorProcesar2(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonDelete_Click(sender As Object, e As EventArgs) Handles botonDelete.Click

        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer
            Dim intContador As Integer = INT_CERO

            If dgDetalle.SelectedRows Is Nothing Then Exit Sub

            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & Val(dgDetalle.SelectedCells(3).Value) & " Of the order " & Val(dgDetalle.SelectedCells(1).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                        If dgDetalle.SelectedCells(19).Value = 0 Or dgDetalle.SelectedCells(19).Value = 1 Then
                            dgDetalle.SelectedCells(19).Value = 2
                            If dgDetalle.SelectedCells(19).Value = 2 Then
                                dgDetalle.Rows.Remove(dgDetalle.SelectedRows(0))
                                dgDetalle.Refresh()
                            End If
                        End If
                    End If
                Next
                If Me.Tag = "Nuevo" Then
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        If dgDetalle.Rows(i).Visible = True Then
                            intContador = intContador + 1
                            dgDetalle.Rows(i).Cells("colLineaDesc").Value = intContador
                        End If
                    Next

                End If

            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer
            If dgPedidos.SelectedRows Is Nothing Then Exit Sub
            If dgPedidos.Rows.Count > 1 Then
                Count = dgPedidos.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row Of the PF" & Val(dgPedidos.SelectedCells(0).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                        Me.dgPedidos.Rows.Remove(dgPedidos.SelectedRows(0))
                        dgDetalle.Rows.Clear()
                        SqlDetallePorProcesar2(False)
                    End If
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Encabezado1.botonGuardar.Enabled = False
        Try
            If logInsertar = True Then
                If Me.Tag = "Nuevo" Then
                    If ComprobarCampos() Then
                        If ComprobarFilaDetalle() Then
                            celdaNumero.Text = NuevaFactura()
                            GuardarDocumento()
                            GuardarDetalle()
                            GuardarDescargo()
                            cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 942, Val(celdaAño.Text), Val(celdaNumero.Text), Sistema.Version)
                            MsgBox("The document has been saved.")
                            MostrarLista(True)
                        End If
                    End If
                Else
                    If logEditar = True Then
                        If ComprobarCampos() Then
                            If ComprobarFilaDetalle() Then
                                GuardarDocumento()
                                GuardarDetalle()
                                GuardarDescargo()
                                BorrarLineDetalle(celdaNumero.Text, 942)
                                BorrarLineaDescargo()
                                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 942, Val(celdaAño.Text), Val(celdaNumero.Text), Sistema.Version)
                                MsgBox("The document has been saved.")
                                MostrarLista(True)
                            End If
                        End If
                    Else
                        MsgBox("You do not have permission Reload this Proforma")
                    End If
                End If
            Else
                MsgBox("You do not have permission to create a new proforma")
            End If
            Encabezado1.botonGuardar.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        LimpiarPanelOrden()
        Dim año As Integer = 0
        Dim numero As Integer = 0
        Dim Linea As Integer = 0
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            'captura el año,numero del panelprincipal dglista
            año = dgLista.SelectedCells(5).Value
            numero = dgLista.SelectedCells(0).Value
            CargarEncabezado(año, numero)
            MostrarLista(0)
            CargarDetalle(año, numero)
            CargarDescargos(año, numero)
            'CargarDescargos()
            CalcularTotales()
            'CargarDescargos()
            botonMas.Enabled = False
            botonEliminar.Enabled = False
            botonDelete.Enabled = False
            celdaTotales.Enabled = False
            celdaTotales2.Enabled = False

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(942, dgLista.SelectedCells(5).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(5).Value, 942)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                EliminarEncabezado()
                EliminarDetalle()
                BorrarDescargos()
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 942, Val(celdaAño.Text), Val(celdaNumero.Text), Sistema.Version)
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub
    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim Cantidad As Double
        Dim Precio As Double
        Dim Total As Double

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 15

                Precio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                Cantidad = dgDetalle.CurrentRow.Cells("colADespachar").Value

                Total = (dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colADespachar").Value)

                dgDetalle.CurrentRow.Cells("colPendiente").Value = Total
                CalcularTotales()
                'celdaTotales2.Text = Total.ToString(FORMATO_MONEDA)
                'celdaTotales.Text = Cantidad.ToString(FORMATO_MONEDA)
        End Select
    End Sub
    Private Sub frmInstDespachoFibra_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        queryListaPrincipal()
    End Sub
#End Region
End Class