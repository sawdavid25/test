﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInventarioIT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgCobian = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidDia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHora = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PaneBotones = New System.Windows.Forms.Panel()
        Me.botonAbajo = New System.Windows.Forms.Button()
        Me.botonUp = New System.Windows.Forms.Button()
        Me.PanelNRequerido = New System.Windows.Forms.Panel()
        Me.celdaDisco = New System.Windows.Forms.TextBox()
        Me.EtiquetaDisco = New System.Windows.Forms.Label()
        Me.celdaidSeguro = New System.Windows.Forms.TextBox()
        Me.botonSeguro = New System.Windows.Forms.Button()
        Me.celdaOFFICE = New System.Windows.Forms.TextBox()
        Me.etiquetaOffice = New System.Windows.Forms.Label()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaFactura = New System.Windows.Forms.Label()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.etiquetaSeguro = New System.Windows.Forms.Label()
        Me.celdaSistema = New System.Windows.Forms.TextBox()
        Me.etiquetaSistema = New System.Windows.Forms.Label()
        Me.celdaRam = New System.Windows.Forms.TextBox()
        Me.etiquetaRam = New System.Windows.Forms.Label()
        Me.celdaProcesador = New System.Windows.Forms.TextBox()
        Me.etiquetaProcesador = New System.Windows.Forms.Label()
        Me.celdaServiceTag = New System.Windows.Forms.TextBox()
        Me.etiquetaServiceTag = New System.Windows.Forms.Label()
        Me.celdaModelo = New System.Windows.Forms.TextBox()
        Me.etiquetaModelo = New System.Windows.Forms.Label()
        Me.celdaCodigoEquipo = New System.Windows.Forms.TextBox()
        Me.etiquetaCodigoEquipo = New System.Windows.Forms.Label()
        Me.GbObligatorio = New System.Windows.Forms.GroupBox()
        Me.celdaRazonBaja = New System.Windows.Forms.TextBox()
        Me.etiquetaRazonBaja = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.EtiquetaFecha = New System.Windows.Forms.Label()
        Me.EtiquetaFechaBaja = New System.Windows.Forms.Label()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.dtpFechaBaja = New System.Windows.Forms.DateTimePicker()
        Me.botonUbicacion = New System.Windows.Forms.Button()
        Me.celdaidAsignacion = New System.Windows.Forms.TextBox()
        Me.celdaidInventario = New System.Windows.Forms.TextBox()
        Me.celdaCosto = New System.Windows.Forms.TextBox()
        Me.checkSinAsignar = New System.Windows.Forms.CheckBox()
        Me.etiquetaCosto = New System.Windows.Forms.Label()
        Me.botonAsignacion = New System.Windows.Forms.Button()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaAsignacion = New System.Windows.Forms.TextBox()
        Me.celdaidUbicacion = New System.Windows.Forms.TextBox()
        Me.etiquetaAsignacion = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.etiquetaUbicacion = New System.Windows.Forms.Label()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.etiquetaInventario = New System.Windows.Forms.Label()
        Me.celdaUbicacion = New System.Windows.Forms.TextBox()
        Me.celdaInventario = New System.Windows.Forms.TextBox()
        Me.celdaMarca = New System.Windows.Forms.TextBox()
        Me.botonInventario = New System.Windows.Forms.Button()
        Me.etiquetaMarca = New System.Windows.Forms.Label()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colResponsable = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoEquipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.celdaMacEthernet = New System.Windows.Forms.TextBox()
        Me.etiquetaEthernet = New System.Windows.Forms.Label()
        Me.celdaMacWifi = New System.Windows.Forms.TextBox()
        Me.etiquetaWifi = New System.Windows.Forms.Label()
        Me.celdaComentario = New System.Windows.Forms.TextBox()
        Me.etiquetaComentario = New System.Windows.Forms.Label()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgCobian, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PaneBotones.SuspendLayout()
        Me.PanelNRequerido.SuspendLayout()
        Me.GbObligatorio.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Location = New System.Drawing.Point(33, 133)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(186, 47)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcion, Me.colResponsable, Me.colCodigoEquipo, Me.colEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(186, 47)
        Me.dgLista.TabIndex = 0
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.PanelDetalle)
        Me.PanelDocumento.Controls.Add(Me.GbObligatorio)
        Me.PanelDocumento.Controls.Add(Me.PanelNRequerido)
        Me.PanelDocumento.Location = New System.Drawing.Point(12, 186)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(776, 714)
        Me.PanelDocumento.TabIndex = 3
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgCobian)
        Me.PanelDetalle.Controls.Add(Me.PaneBotones)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 602)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(776, 112)
        Me.PanelDetalle.TabIndex = 34
        '
        'dgCobian
        '
        Me.dgCobian.AllowUserToAddRows = False
        Me.dgCobian.AllowUserToDeleteRows = False
        Me.dgCobian.AllowUserToOrderColumns = True
        Me.dgCobian.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgCobian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCobian.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colidDia, Me.colDia, Me.colNombre, Me.colHora, Me.colidEstado, Me.colEstado1, Me.colExtra})
        Me.dgCobian.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCobian.Location = New System.Drawing.Point(0, 0)
        Me.dgCobian.Name = "dgCobian"
        Me.dgCobian.RowTemplate.Height = 24
        Me.dgCobian.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCobian.Size = New System.Drawing.Size(725, 112)
        Me.dgCobian.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        '
        'colidDia
        '
        Me.colidDia.HeaderText = "id Dia"
        Me.colidDia.Name = "colidDia"
        Me.colidDia.Visible = False
        '
        'colDia
        '
        Me.colDia.HeaderText = "Day"
        Me.colDia.Name = "colDia"
        Me.colDia.ReadOnly = True
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        '
        'colHora
        '
        Me.colHora.HeaderText = "Time"
        Me.colHora.Name = "colHora"
        Me.colHora.ReadOnly = True
        '
        'colidEstado
        '
        Me.colidEstado.HeaderText = "Estado"
        Me.colidEstado.Name = "colidEstado"
        Me.colidEstado.Visible = False
        '
        'colEstado1
        '
        Me.colEstado1.HeaderText = "Status"
        Me.colEstado1.Name = "colEstado1"
        Me.colEstado1.ReadOnly = True
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        '
        'PaneBotones
        '
        Me.PaneBotones.Controls.Add(Me.botonAbajo)
        Me.PaneBotones.Controls.Add(Me.botonUp)
        Me.PaneBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PaneBotones.Location = New System.Drawing.Point(725, 0)
        Me.PaneBotones.Name = "PaneBotones"
        Me.PaneBotones.Size = New System.Drawing.Size(51, 112)
        Me.PaneBotones.TabIndex = 13
        '
        'botonAbajo
        '
        Me.botonAbajo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAbajo.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonAbajo.Location = New System.Drawing.Point(4, 48)
        Me.botonAbajo.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAbajo.Name = "botonAbajo"
        Me.botonAbajo.Size = New System.Drawing.Size(43, 31)
        Me.botonAbajo.TabIndex = 32
        Me.botonAbajo.UseVisualStyleBackColor = True
        '
        'botonUp
        '
        Me.botonUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonUp.Image = Global.KARIMs_SGI.My.Resources.Resources.arrow_up_blue
        Me.botonUp.Location = New System.Drawing.Point(4, 16)
        Me.botonUp.Margin = New System.Windows.Forms.Padding(4)
        Me.botonUp.Name = "botonUp"
        Me.botonUp.Size = New System.Drawing.Size(43, 28)
        Me.botonUp.TabIndex = 31
        Me.botonUp.UseVisualStyleBackColor = True
        '
        'PanelNRequerido
        '
        Me.PanelNRequerido.Controls.Add(Me.celdaMacEthernet)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaEthernet)
        Me.PanelNRequerido.Controls.Add(Me.celdaMacWifi)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaWifi)
        Me.PanelNRequerido.Controls.Add(Me.celdaDisco)
        Me.PanelNRequerido.Controls.Add(Me.EtiquetaDisco)
        Me.PanelNRequerido.Controls.Add(Me.celdaidSeguro)
        Me.PanelNRequerido.Controls.Add(Me.botonSeguro)
        Me.PanelNRequerido.Controls.Add(Me.celdaOFFICE)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaOffice)
        Me.PanelNRequerido.Controls.Add(Me.celdaFactura)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaFactura)
        Me.PanelNRequerido.Controls.Add(Me.celdaSeguro)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaSeguro)
        Me.PanelNRequerido.Controls.Add(Me.celdaSistema)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaSistema)
        Me.PanelNRequerido.Controls.Add(Me.celdaRam)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaRam)
        Me.PanelNRequerido.Controls.Add(Me.celdaProcesador)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaProcesador)
        Me.PanelNRequerido.Controls.Add(Me.celdaServiceTag)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaServiceTag)
        Me.PanelNRequerido.Controls.Add(Me.celdaModelo)
        Me.PanelNRequerido.Controls.Add(Me.etiquetaModelo)
        Me.PanelNRequerido.Location = New System.Drawing.Point(3, 350)
        Me.PanelNRequerido.Name = "PanelNRequerido"
        Me.PanelNRequerido.Size = New System.Drawing.Size(770, 300)
        Me.PanelNRequerido.TabIndex = 15
        '
        'celdaDisco
        '
        Me.celdaDisco.Location = New System.Drawing.Point(99, 152)
        Me.celdaDisco.Name = "celdaDisco"
        Me.celdaDisco.Size = New System.Drawing.Size(249, 22)
        Me.celdaDisco.TabIndex = 15
        '
        'EtiquetaDisco
        '
        Me.EtiquetaDisco.AutoSize = True
        Me.EtiquetaDisco.Location = New System.Drawing.Point(6, 152)
        Me.EtiquetaDisco.Name = "EtiquetaDisco"
        Me.EtiquetaDisco.Size = New System.Drawing.Size(38, 17)
        Me.EtiquetaDisco.TabIndex = 33
        Me.EtiquetaDisco.Text = "HDD"
        '
        'celdaidSeguro
        '
        Me.celdaidSeguro.Location = New System.Drawing.Point(424, 179)
        Me.celdaidSeguro.Name = "celdaidSeguro"
        Me.celdaidSeguro.Size = New System.Drawing.Size(23, 22)
        Me.celdaidSeguro.TabIndex = 30
        Me.celdaidSeguro.Visible = False
        '
        'botonSeguro
        '
        Me.botonSeguro.Location = New System.Drawing.Point(354, 178)
        Me.botonSeguro.Name = "botonSeguro"
        Me.botonSeguro.Size = New System.Drawing.Size(51, 23)
        Me.botonSeguro.TabIndex = 17
        Me.botonSeguro.Text = "..."
        Me.botonSeguro.UseVisualStyleBackColor = True
        '
        'celdaOFFICE
        '
        Me.celdaOFFICE.Location = New System.Drawing.Point(99, 234)
        Me.celdaOFFICE.Name = "celdaOFFICE"
        Me.celdaOFFICE.Size = New System.Drawing.Size(249, 22)
        Me.celdaOFFICE.TabIndex = 19
        '
        'etiquetaOffice
        '
        Me.etiquetaOffice.AutoSize = True
        Me.etiquetaOffice.Location = New System.Drawing.Point(7, 234)
        Me.etiquetaOffice.Name = "etiquetaOffice"
        Me.etiquetaOffice.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaOffice.TabIndex = 24
        Me.etiquetaOffice.Text = "Office"
        '
        'celdaFactura
        '
        Me.celdaFactura.Location = New System.Drawing.Point(99, 206)
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.Size = New System.Drawing.Size(249, 22)
        Me.celdaFactura.TabIndex = 18
        '
        'etiquetaFactura
        '
        Me.etiquetaFactura.AutoSize = True
        Me.etiquetaFactura.Location = New System.Drawing.Point(8, 199)
        Me.etiquetaFactura.Name = "etiquetaFactura"
        Me.etiquetaFactura.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaFactura.TabIndex = 20
        Me.etiquetaFactura.Text = "Invoice"
        '
        'celdaSeguro
        '
        Me.celdaSeguro.Location = New System.Drawing.Point(99, 178)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.ReadOnly = True
        Me.celdaSeguro.Size = New System.Drawing.Size(249, 22)
        Me.celdaSeguro.TabIndex = 16
        '
        'etiquetaSeguro
        '
        Me.etiquetaSeguro.AutoSize = True
        Me.etiquetaSeguro.Location = New System.Drawing.Point(6, 171)
        Me.etiquetaSeguro.Name = "etiquetaSeguro"
        Me.etiquetaSeguro.Size = New System.Drawing.Size(70, 17)
        Me.etiquetaSeguro.TabIndex = 18
        Me.etiquetaSeguro.Text = "Insurance"
        '
        'celdaSistema
        '
        Me.celdaSistema.Location = New System.Drawing.Point(99, 124)
        Me.celdaSistema.Name = "celdaSistema"
        Me.celdaSistema.Size = New System.Drawing.Size(249, 22)
        Me.celdaSistema.TabIndex = 14
        '
        'etiquetaSistema
        '
        Me.etiquetaSistema.AutoSize = True
        Me.etiquetaSistema.Location = New System.Drawing.Point(6, 124)
        Me.etiquetaSistema.Name = "etiquetaSistema"
        Me.etiquetaSistema.Size = New System.Drawing.Size(54, 17)
        Me.etiquetaSistema.TabIndex = 16
        Me.etiquetaSistema.Text = "System"
        '
        'celdaRam
        '
        Me.celdaRam.Location = New System.Drawing.Point(99, 96)
        Me.celdaRam.Name = "celdaRam"
        Me.celdaRam.Size = New System.Drawing.Size(249, 22)
        Me.celdaRam.TabIndex = 13
        '
        'etiquetaRam
        '
        Me.etiquetaRam.AutoSize = True
        Me.etiquetaRam.Location = New System.Drawing.Point(6, 96)
        Me.etiquetaRam.Name = "etiquetaRam"
        Me.etiquetaRam.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaRam.TabIndex = 14
        Me.etiquetaRam.Text = "RAM"
        '
        'celdaProcesador
        '
        Me.celdaProcesador.Location = New System.Drawing.Point(99, 68)
        Me.celdaProcesador.Name = "celdaProcesador"
        Me.celdaProcesador.Size = New System.Drawing.Size(249, 22)
        Me.celdaProcesador.TabIndex = 12
        '
        'etiquetaProcesador
        '
        Me.etiquetaProcesador.AutoSize = True
        Me.etiquetaProcesador.Location = New System.Drawing.Point(6, 68)
        Me.etiquetaProcesador.Name = "etiquetaProcesador"
        Me.etiquetaProcesador.Size = New System.Drawing.Size(72, 17)
        Me.etiquetaProcesador.TabIndex = 12
        Me.etiquetaProcesador.Text = "Processor"
        '
        'celdaServiceTag
        '
        Me.celdaServiceTag.Location = New System.Drawing.Point(99, 37)
        Me.celdaServiceTag.Name = "celdaServiceTag"
        Me.celdaServiceTag.Size = New System.Drawing.Size(249, 22)
        Me.celdaServiceTag.TabIndex = 11
        '
        'etiquetaServiceTag
        '
        Me.etiquetaServiceTag.AutoSize = True
        Me.etiquetaServiceTag.Location = New System.Drawing.Point(3, 40)
        Me.etiquetaServiceTag.Name = "etiquetaServiceTag"
        Me.etiquetaServiceTag.Size = New System.Drawing.Size(84, 17)
        Me.etiquetaServiceTag.TabIndex = 10
        Me.etiquetaServiceTag.Text = "Service Tag"
        '
        'celdaModelo
        '
        Me.celdaModelo.Location = New System.Drawing.Point(99, 6)
        Me.celdaModelo.Name = "celdaModelo"
        Me.celdaModelo.Size = New System.Drawing.Size(249, 22)
        Me.celdaModelo.TabIndex = 10
        '
        'etiquetaModelo
        '
        Me.etiquetaModelo.AutoSize = True
        Me.etiquetaModelo.Location = New System.Drawing.Point(6, 9)
        Me.etiquetaModelo.Name = "etiquetaModelo"
        Me.etiquetaModelo.Size = New System.Drawing.Size(46, 17)
        Me.etiquetaModelo.TabIndex = 8
        Me.etiquetaModelo.Text = "Model"
        '
        'celdaCodigoEquipo
        '
        Me.celdaCodigoEquipo.Location = New System.Drawing.Point(100, 76)
        Me.celdaCodigoEquipo.Name = "celdaCodigoEquipo"
        Me.celdaCodigoEquipo.Size = New System.Drawing.Size(234, 22)
        Me.celdaCodigoEquipo.TabIndex = 9
        '
        'etiquetaCodigoEquipo
        '
        Me.etiquetaCodigoEquipo.AutoSize = True
        Me.etiquetaCodigoEquipo.Location = New System.Drawing.Point(4, 76)
        Me.etiquetaCodigoEquipo.Name = "etiquetaCodigoEquipo"
        Me.etiquetaCodigoEquipo.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaCodigoEquipo.TabIndex = 6
        Me.etiquetaCodigoEquipo.Text = "Code"
        '
        'GbObligatorio
        '
        Me.GbObligatorio.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GbObligatorio.Controls.Add(Me.celdaComentario)
        Me.GbObligatorio.Controls.Add(Me.etiquetaComentario)
        Me.GbObligatorio.Controls.Add(Me.celdaRazonBaja)
        Me.GbObligatorio.Controls.Add(Me.etiquetaRazonBaja)
        Me.GbObligatorio.Controls.Add(Me.dtpFecha)
        Me.GbObligatorio.Controls.Add(Me.EtiquetaFecha)
        Me.GbObligatorio.Controls.Add(Me.EtiquetaFechaBaja)
        Me.GbObligatorio.Controls.Add(Me.celdaidProveedor)
        Me.GbObligatorio.Controls.Add(Me.dtpFechaBaja)
        Me.GbObligatorio.Controls.Add(Me.botonUbicacion)
        Me.GbObligatorio.Controls.Add(Me.celdaidAsignacion)
        Me.GbObligatorio.Controls.Add(Me.celdaidInventario)
        Me.GbObligatorio.Controls.Add(Me.celdaCosto)
        Me.GbObligatorio.Controls.Add(Me.checkSinAsignar)
        Me.GbObligatorio.Controls.Add(Me.etiquetaCosto)
        Me.GbObligatorio.Controls.Add(Me.botonAsignacion)
        Me.GbObligatorio.Controls.Add(Me.botonProveedor)
        Me.GbObligatorio.Controls.Add(Me.celdaAsignacion)
        Me.GbObligatorio.Controls.Add(Me.celdaidUbicacion)
        Me.GbObligatorio.Controls.Add(Me.etiquetaAsignacion)
        Me.GbObligatorio.Controls.Add(Me.etiquetaNumero)
        Me.GbObligatorio.Controls.Add(Me.etiquetaProveedor)
        Me.GbObligatorio.Controls.Add(Me.celdaCodigoEquipo)
        Me.GbObligatorio.Controls.Add(Me.etiquetaUbicacion)
        Me.GbObligatorio.Controls.Add(Me.etiquetaCodigoEquipo)
        Me.GbObligatorio.Controls.Add(Me.celdaSerie)
        Me.GbObligatorio.Controls.Add(Me.checkActivo)
        Me.GbObligatorio.Controls.Add(Me.celdaProveedor)
        Me.GbObligatorio.Controls.Add(Me.celdaNumero)
        Me.GbObligatorio.Controls.Add(Me.etiquetaSerie)
        Me.GbObligatorio.Controls.Add(Me.etiquetaInventario)
        Me.GbObligatorio.Controls.Add(Me.celdaUbicacion)
        Me.GbObligatorio.Controls.Add(Me.celdaInventario)
        Me.GbObligatorio.Controls.Add(Me.celdaMarca)
        Me.GbObligatorio.Controls.Add(Me.botonInventario)
        Me.GbObligatorio.Controls.Add(Me.etiquetaMarca)
        Me.GbObligatorio.Location = New System.Drawing.Point(3, 3)
        Me.GbObligatorio.Name = "GbObligatorio"
        Me.GbObligatorio.Size = New System.Drawing.Size(767, 341)
        Me.GbObligatorio.TabIndex = 14
        Me.GbObligatorio.TabStop = False
        '
        'celdaRazonBaja
        '
        Me.celdaRazonBaja.Location = New System.Drawing.Point(99, 306)
        Me.celdaRazonBaja.Multiline = True
        Me.celdaRazonBaja.Name = "celdaRazonBaja"
        Me.celdaRazonBaja.Size = New System.Drawing.Size(648, 30)
        Me.celdaRazonBaja.TabIndex = 13
        '
        'etiquetaRazonBaja
        '
        Me.etiquetaRazonBaja.AutoSize = True
        Me.etiquetaRazonBaja.Location = New System.Drawing.Point(7, 306)
        Me.etiquetaRazonBaja.Name = "etiquetaRazonBaja"
        Me.etiquetaRazonBaja.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaRazonBaja.TabIndex = 37
        Me.etiquetaRazonBaja.Text = "Reason"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(99, 279)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(119, 22)
        Me.dtpFecha.TabIndex = 11
        '
        'EtiquetaFecha
        '
        Me.EtiquetaFecha.AutoSize = True
        Me.EtiquetaFecha.Location = New System.Drawing.Point(8, 284)
        Me.EtiquetaFecha.Name = "EtiquetaFecha"
        Me.EtiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.EtiquetaFecha.TabIndex = 32
        Me.EtiquetaFecha.Text = "Date"
        '
        'EtiquetaFechaBaja
        '
        Me.EtiquetaFechaBaja.AutoSize = True
        Me.EtiquetaFechaBaja.Location = New System.Drawing.Point(240, 284)
        Me.EtiquetaFechaBaja.Name = "EtiquetaFechaBaja"
        Me.EtiquetaFechaBaja.Size = New System.Drawing.Size(67, 17)
        Me.EtiquetaFechaBaja.TabIndex = 35
        Me.EtiquetaFechaBaja.Text = "Low Date"
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Location = New System.Drawing.Point(364, 217)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(23, 22)
        Me.celdaidProveedor.TabIndex = 30
        Me.celdaidProveedor.Visible = False
        '
        'dtpFechaBaja
        '
        Me.dtpFechaBaja.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaBaja.Location = New System.Drawing.Point(328, 279)
        Me.dtpFechaBaja.Name = "dtpFechaBaja"
        Me.dtpFechaBaja.Size = New System.Drawing.Size(119, 22)
        Me.dtpFechaBaja.TabIndex = 12
        '
        'botonUbicacion
        '
        Me.botonUbicacion.Location = New System.Drawing.Point(354, 163)
        Me.botonUbicacion.Name = "botonUbicacion"
        Me.botonUbicacion.Size = New System.Drawing.Size(51, 23)
        Me.botonUbicacion.TabIndex = 29
        Me.botonUbicacion.Text = "..."
        Me.botonUbicacion.UseVisualStyleBackColor = True
        '
        'celdaidAsignacion
        '
        Me.celdaidAsignacion.Location = New System.Drawing.Point(453, 276)
        Me.celdaidAsignacion.Name = "celdaidAsignacion"
        Me.celdaidAsignacion.Size = New System.Drawing.Size(23, 22)
        Me.celdaidAsignacion.TabIndex = 31
        Me.celdaidAsignacion.Visible = False
        '
        'celdaidInventario
        '
        Me.celdaidInventario.Location = New System.Drawing.Point(354, 21)
        Me.celdaidInventario.Name = "celdaidInventario"
        Me.celdaidInventario.Size = New System.Drawing.Size(23, 22)
        Me.celdaidInventario.TabIndex = 28
        Me.celdaidInventario.Visible = False
        '
        'celdaCosto
        '
        Me.celdaCosto.Location = New System.Drawing.Point(99, 222)
        Me.celdaCosto.Name = "celdaCosto"
        Me.celdaCosto.Size = New System.Drawing.Size(143, 22)
        Me.celdaCosto.TabIndex = 8
        '
        'checkSinAsignar
        '
        Me.checkSinAsignar.AutoSize = True
        Me.checkSinAsignar.Location = New System.Drawing.Point(433, 249)
        Me.checkSinAsignar.Name = "checkSinAsignar"
        Me.checkSinAsignar.Size = New System.Drawing.Size(125, 21)
        Me.checkSinAsignar.TabIndex = 11
        Me.checkSinAsignar.Text = "No Assingment"
        Me.checkSinAsignar.UseVisualStyleBackColor = True
        '
        'etiquetaCosto
        '
        Me.etiquetaCosto.AutoSize = True
        Me.etiquetaCosto.Location = New System.Drawing.Point(6, 222)
        Me.etiquetaCosto.Name = "etiquetaCosto"
        Me.etiquetaCosto.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaCosto.TabIndex = 27
        Me.etiquetaCosto.Text = "Cost"
        '
        'botonAsignacion
        '
        Me.botonAsignacion.Location = New System.Drawing.Point(364, 250)
        Me.botonAsignacion.Name = "botonAsignacion"
        Me.botonAsignacion.Size = New System.Drawing.Size(51, 23)
        Me.botonAsignacion.TabIndex = 10
        Me.botonAsignacion.Text = "..."
        Me.botonAsignacion.UseVisualStyleBackColor = True
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(354, 194)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(51, 23)
        Me.botonProveedor.TabIndex = 7
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaAsignacion
        '
        Me.celdaAsignacion.Location = New System.Drawing.Point(99, 250)
        Me.celdaAsignacion.Name = "celdaAsignacion"
        Me.celdaAsignacion.ReadOnly = True
        Me.celdaAsignacion.Size = New System.Drawing.Size(249, 22)
        Me.celdaAsignacion.TabIndex = 9
        '
        'celdaidUbicacion
        '
        Me.celdaidUbicacion.Location = New System.Drawing.Point(354, 144)
        Me.celdaidUbicacion.Name = "celdaidUbicacion"
        Me.celdaidUbicacion.Size = New System.Drawing.Size(23, 22)
        Me.celdaidUbicacion.TabIndex = 14
        Me.celdaidUbicacion.Visible = False
        '
        'etiquetaAsignacion
        '
        Me.etiquetaAsignacion.AutoSize = True
        Me.etiquetaAsignacion.Location = New System.Drawing.Point(3, 249)
        Me.etiquetaAsignacion.Name = "etiquetaAsignacion"
        Me.etiquetaAsignacion.Size = New System.Drawing.Size(81, 17)
        Me.etiquetaAsignacion.TabIndex = 27
        Me.etiquetaAsignacion.Text = "Assignment"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 18)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(6, 195)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaProveedor.TabIndex = 6
        Me.etiquetaProveedor.Text = "Provider"
        '
        'etiquetaUbicacion
        '
        Me.etiquetaUbicacion.AutoSize = True
        Me.etiquetaUbicacion.Location = New System.Drawing.Point(6, 166)
        Me.etiquetaUbicacion.Name = "etiquetaUbicacion"
        Me.etiquetaUbicacion.Size = New System.Drawing.Size(62, 17)
        Me.etiquetaUbicacion.TabIndex = 10
        Me.etiquetaUbicacion.Text = "Location"
        '
        'celdaSerie
        '
        Me.celdaSerie.Location = New System.Drawing.Point(99, 135)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.Size = New System.Drawing.Size(235, 22)
        Me.celdaSerie.TabIndex = 4
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(266, 21)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 13
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(99, 194)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(235, 22)
        Me.celdaProveedor.TabIndex = 6
        '
        'celdaNumero
        '
        Me.celdaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumero.Location = New System.Drawing.Point(99, 21)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(143, 22)
        Me.celdaNumero.TabIndex = 0
        Me.celdaNumero.Text = "-1"
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(6, 135)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(48, 17)
        Me.etiquetaSerie.TabIndex = 8
        Me.etiquetaSerie.Text = "Series"
        '
        'etiquetaInventario
        '
        Me.etiquetaInventario.AutoSize = True
        Me.etiquetaInventario.Location = New System.Drawing.Point(6, 49)
        Me.etiquetaInventario.Name = "etiquetaInventario"
        Me.etiquetaInventario.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaInventario.TabIndex = 12
        Me.etiquetaInventario.Text = "Inventory"
        '
        'celdaUbicacion
        '
        Me.celdaUbicacion.Location = New System.Drawing.Point(99, 166)
        Me.celdaUbicacion.Name = "celdaUbicacion"
        Me.celdaUbicacion.ReadOnly = True
        Me.celdaUbicacion.Size = New System.Drawing.Size(235, 22)
        Me.celdaUbicacion.TabIndex = 5
        '
        'celdaInventario
        '
        Me.celdaInventario.Location = New System.Drawing.Point(99, 49)
        Me.celdaInventario.Name = "celdaInventario"
        Me.celdaInventario.ReadOnly = True
        Me.celdaInventario.Size = New System.Drawing.Size(235, 22)
        Me.celdaInventario.TabIndex = 1
        '
        'celdaMarca
        '
        Me.celdaMarca.Location = New System.Drawing.Point(99, 105)
        Me.celdaMarca.Name = "celdaMarca"
        Me.celdaMarca.Size = New System.Drawing.Size(235, 22)
        Me.celdaMarca.TabIndex = 3
        '
        'botonInventario
        '
        Me.botonInventario.Location = New System.Drawing.Point(354, 49)
        Me.botonInventario.Name = "botonInventario"
        Me.botonInventario.Size = New System.Drawing.Size(51, 23)
        Me.botonInventario.TabIndex = 2
        Me.botonInventario.Text = "..."
        Me.botonInventario.UseVisualStyleBackColor = True
        '
        'etiquetaMarca
        '
        Me.etiquetaMarca.AutoSize = True
        Me.etiquetaMarca.Location = New System.Drawing.Point(6, 105)
        Me.etiquetaMarca.Name = "etiquetaMarca"
        Me.etiquetaMarca.Size = New System.Drawing.Size(39, 17)
        Me.etiquetaMarca.TabIndex = 4
        Me.etiquetaMarca.Text = "Mark"
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(281, 12)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(72, 55)
        Me.botonImprimir.TabIndex = 5
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 108
        '
        'colResponsable
        '
        Me.colResponsable.HeaderText = "Responsable"
        Me.colResponsable.Name = "colResponsable"
        Me.colResponsable.ReadOnly = True
        Me.colResponsable.Width = 120
        '
        'colCodigoEquipo
        '
        Me.colCodigoEquipo.HeaderText = "Id Equipment"
        Me.colCodigoEquipo.Name = "colCodigoEquipo"
        Me.colCodigoEquipo.ReadOnly = True
        Me.colCodigoEquipo.Width = 119
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Width = 77
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(800, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(800, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'celdaMacEthernet
        '
        Me.celdaMacEthernet.Location = New System.Drawing.Point(383, 91)
        Me.celdaMacEthernet.Name = "celdaMacEthernet"
        Me.celdaMacEthernet.Size = New System.Drawing.Size(249, 22)
        Me.celdaMacEthernet.TabIndex = 37
        '
        'etiquetaEthernet
        '
        Me.etiquetaEthernet.AutoSize = True
        Me.etiquetaEthernet.Location = New System.Drawing.Point(380, 71)
        Me.etiquetaEthernet.Name = "etiquetaEthernet"
        Me.etiquetaEthernet.Size = New System.Drawing.Size(95, 17)
        Me.etiquetaEthernet.TabIndex = 35
        Me.etiquetaEthernet.Text = "MAC Ethernet"
        '
        'celdaMacWifi
        '
        Me.celdaMacWifi.Location = New System.Drawing.Point(383, 35)
        Me.celdaMacWifi.Name = "celdaMacWifi"
        Me.celdaMacWifi.Size = New System.Drawing.Size(249, 22)
        Me.celdaMacWifi.TabIndex = 36
        '
        'etiquetaWifi
        '
        Me.etiquetaWifi.AutoSize = True
        Me.etiquetaWifi.Location = New System.Drawing.Point(380, 9)
        Me.etiquetaWifi.Name = "etiquetaWifi"
        Me.etiquetaWifi.Size = New System.Drawing.Size(70, 17)
        Me.etiquetaWifi.TabIndex = 34
        Me.etiquetaWifi.Text = "MAC W-Fi"
        '
        'celdaComentario
        '
        Me.celdaComentario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaComentario.Location = New System.Drawing.Point(453, 76)
        Me.celdaComentario.Multiline = True
        Me.celdaComentario.Name = "celdaComentario"
        Me.celdaComentario.Size = New System.Drawing.Size(105, 46)
        Me.celdaComentario.TabIndex = 39
        '
        'etiquetaComentario
        '
        Me.etiquetaComentario.AutoSize = True
        Me.etiquetaComentario.Location = New System.Drawing.Point(450, 55)
        Me.etiquetaComentario.Name = "etiquetaComentario"
        Me.etiquetaComentario.Size = New System.Drawing.Size(87, 17)
        Me.etiquetaComentario.TabIndex = 38
        Me.etiquetaComentario.Text = "Commentary"
        '
        'frmInventarioIT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 890)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmInventarioIT"
        Me.Text = "frmInventarioIT"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgCobian, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PaneBotones.ResumeLayout(False)
        Me.PanelNRequerido.ResumeLayout(False)
        Me.PanelNRequerido.PerformLayout()
        Me.GbObligatorio.ResumeLayout(False)
        Me.GbObligatorio.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents PanelNRequerido As Panel
    Friend WithEvents celdaModelo As TextBox
    Friend WithEvents etiquetaModelo As Label
    Friend WithEvents celdaCodigoEquipo As TextBox
    Friend WithEvents etiquetaCodigoEquipo As Label
    Friend WithEvents GbObligatorio As GroupBox
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaidUbicacion As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents etiquetaUbicacion As Label
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents etiquetaInventario As Label
    Friend WithEvents celdaUbicacion As TextBox
    Friend WithEvents celdaInventario As TextBox
    Friend WithEvents celdaMarca As TextBox
    Friend WithEvents botonInventario As Button
    Friend WithEvents etiquetaMarca As Label
    Friend WithEvents checkSinAsignar As System.Windows.Forms.CheckBox
    Friend WithEvents botonAsignacion As Button
    Friend WithEvents celdaAsignacion As TextBox
    Friend WithEvents etiquetaAsignacion As Label
    Friend WithEvents botonSeguro As Button
    Friend WithEvents celdaOFFICE As TextBox
    Friend WithEvents etiquetaOffice As Label
    Friend WithEvents celdaFactura As TextBox
    Friend WithEvents etiquetaFactura As Label
    Friend WithEvents celdaSeguro As TextBox
    Friend WithEvents etiquetaSeguro As Label
    Friend WithEvents celdaSistema As TextBox
    Friend WithEvents etiquetaSistema As Label
    Friend WithEvents celdaRam As TextBox
    Friend WithEvents etiquetaRam As Label
    Friend WithEvents celdaProcesador As TextBox
    Friend WithEvents etiquetaProcesador As Label
    Friend WithEvents celdaServiceTag As TextBox
    Friend WithEvents etiquetaServiceTag As Label
    Friend WithEvents celdaCosto As TextBox
    Friend WithEvents etiquetaCosto As Label
    Friend WithEvents celdaidInventario As TextBox
    Friend WithEvents celdaidAsignacion As TextBox
    Friend WithEvents celdaidSeguro As TextBox
    Friend WithEvents celdaDisco As TextBox
    Friend WithEvents EtiquetaDisco As Label
    Friend WithEvents botonUbicacion As Button
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgCobian As DataGridView
    Friend WithEvents PaneBotones As Panel
    Friend WithEvents botonAbajo As Button
    Friend WithEvents botonUp As Button
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colidDia As DataGridViewTextBoxColumn
    Friend WithEvents colDia As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colHora As DataGridViewTextBoxColumn
    Friend WithEvents colidEstado As DataGridViewTextBoxColumn
    Friend WithEvents colEstado1 As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents EtiquetaFecha As Label
    Friend WithEvents celdaRazonBaja As TextBox
    Friend WithEvents etiquetaRazonBaja As Label
    Friend WithEvents EtiquetaFechaBaja As Label
    Friend WithEvents dtpFechaBaja As DateTimePicker
    Friend WithEvents botonImprimir As Button
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colResponsable As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoEquipo As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents celdaComentario As TextBox
    Friend WithEvents etiquetaComentario As Label
    Friend WithEvents celdaMacEthernet As TextBox
    Friend WithEvents etiquetaEthernet As Label
    Friend WithEvents celdaMacWifi As TextBox
    Friend WithEvents etiquetaWifi As Label
End Class
