﻿Public Class frmRegularTasa

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim bd As String = ""

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub
    Private Sub botonAnio_Click(sender As Object, e As EventArgs) Handles botonAnio.Click
        Dim frm As New frmSeleccionar

        frm.Titulo = "Year"
        frm.Campos = "  Distinct(t.Ano)"
        frm.Tabla = " Regular_Tasa t"
        frm.Condicion = " t.Ano > 0"
        frm.FiltroText = " Enter the Year to filter "
        frm.Filtro = " t.Ano "

        frm.ShowDialog(Me)

        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            celdaAnio.Text = frm.LLave
        End If

    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT t.Ano anio, t.Mes mes, t.Tasa tasa "
        strSQL &= " From Regular_Tasa t "

        If checkFecha.Checked = True Then
            strSQL &= " Where t.Ano = {anio} "
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        Else
            strSQL &= " Where t.Ano > {anio} "
            strSQL = Replace(strSQL, "{anio}", 1)
        End If


        Return strSQL
    End Function

    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strMesLetras

        Try
            strSQL = SQLListaPrincipal()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("mes") & "|"
                    strFila &= MonthName(REA.GetInt32("mes")) & "|"
                    strFila &= REA.GetDouble("tasa")

                    cFunciones.AgregarFila(dgLista, strFila)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub LimpiarCampos()
        celdaTasa.Clear()
        dtFecha.Value = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        dtFecha.Enabled = True
        If Sesion.IdEmpresa = 18 Then
            bd = "PDM."
        End If
    End Sub

    Public Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            panelDetalle.Visible = False
            panelDetalle.Dock = DockStyle.None
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BarraTitulo1.CambiarTitulo("Change Rates Registry")
            ListaPrincipal()
            BloquearBotones()

        Else
            panelDetalle.Visible = True
            panelDetalle.Dock = DockStyle.Top
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            BloquearBotones(False)
            If logInsert = True Then
                BarraTitulo1.CambiarTitulo("New Exchange Rate")
            Else
                BarraTitulo1.CambiarTitulo("Modify Exchange Rate")
            End If
        End If
    End Sub

    Public Sub CargarDatos()
        dtFecha.Text = DateSerial(dgLista.CurrentRow.Cells("colAnio").Value, dgLista.CurrentRow.Cells("colIdMes").Value, 1)
        dtFecha.Enabled = False
        celdaTasa.Text = dgLista.CurrentRow.Cells("colTasa").Value
    End Sub

    Private Function comprobarDatos()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim SaveValido As Integer

        strSQL = " SELECT COUNT(*) FROM Regular_Tasa t WHERE t.Ano = {anio} AND t.Mes = {mes} "

        strSQL = Replace(strSQL, "{anio}", Year(dtFecha.Value))
        strSQL = Replace(strSQL, "{mes}", Month(dtFecha.Value))


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        SaveValido = COM.ExecuteScalar()

        Return SaveValido
    End Function
#End Region


#Region "Eventos"
    Private Sub frmRegularTasa_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accesos()
        celdaAnio.Text = cFunciones.AñoMySQL
        MostrarLista()

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Me.Tag = "Mod"
        LimpiarCampos()
        CargarDatos()
        MostrarLista(False)
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDetalle.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar Then
            Me.Tag = "Nuevo"
            LimpiarCampos()
            MostrarLista(False, True)
        Else
            MsgBox("You do not have permission to perform this action", vbInformation, "Notice")
        End If

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        If celdaTasa.Text = STR_VACIO Then
            MsgBox("Enter the Rate of Change", vbInformation, "Notice")
            Exit Sub
        End If
        If Me.Tag = "Nuevo" = True Then

            If comprobarDatos() = 0 Then
                strSQL = " INSERT INTO " & bd & "Regular_Tasa VALUES({anio},{mes},{tasa})"
                strSQL = Replace(strSQL, "{anio}", Year(dtFecha.Value))
                strSQL = Replace(strSQL, "{mes}", Month(dtFecha.Value))
                strSQL = Replace(strSQL, "{tasa}", celdaTasa.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()

                MsgBox("Successfully Saved Data", vbInformation, "Notice")
            Else
                MsgBox("A record with the selected month already exists", vbInformation, "Notice")
                Exit Sub
            End If

        ElseIf logEditar = True Then

            strSQL = " UPDATE  " & bd & "Regular_Tasa SET Tasa = {tasa} Where Ano = {anio} AND Mes = {mes}"
            strSQL = Replace(strSQL, "{anio}", Year(dtFecha.Value))
            strSQL = Replace(strSQL, "{mes}", Month(dtFecha.Value))
            strSQL = Replace(strSQL, "{tasa}", celdaTasa.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            MsgBox("Successfully Updated Data", vbInformation, "Notice")
        Else
            MsgBox("You do not have permission to perform this action", vbInformation, "Notice")
        End If

        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand

            strSQL = " Delete From " & bd & "Regular_Tasa Where Ano = {anio} AND Mes = {mes} "
            strSQL = Replace(strSQL, "{anio}", Year(dtFecha.Value))
            strSQL = Replace(strSQL, "{mes}", Month(dtFecha.Value))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

            MsgBox("Correctly deleted data", vbInformation, "Notice")
        Else
            MsgBox("You do not have permission to perform this action", vbInformation, "Notice")
        End If
        MostrarLista()
    End Sub
#End Region

End Class