﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBPresupuesto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBPresupuesto))
        Me.Lista = New System.Windows.Forms.DataGridView()
        Me.BotonCerrar = New System.Windows.Forms.Button()
        Me.EtiquetaTotal = New System.Windows.Forms.Label()
        Me.CeldaTotal = New System.Windows.Forms.TextBox()
        Me.PanelTitulo = New System.Windows.Forms.Panel()
        Me.BotonAgregar = New System.Windows.Forms.Button()
        Me.BotonQuitar = New System.Windows.Forms.Button()
        Me.EtiquetaTitulo = New System.Windows.Forms.Label()
        Me.BotonGuardar = New System.Windows.Forms.Button()
        Me.lista_cuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_monto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.Lista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTitulo.SuspendLayout()
        Me.SuspendLayout()
        '
        'Lista
        '
        Me.Lista.AllowUserToAddRows = False
        Me.Lista.AllowUserToDeleteRows = False
        Me.Lista.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Lista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Lista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Lista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Lista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Lista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.lista_cuenta, Me.lista_nombre, Me.lista_name, Me.lista_monto})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Lista.DefaultCellStyle = DataGridViewCellStyle2
        Me.Lista.Location = New System.Drawing.Point(12, 35)
        Me.Lista.MultiSelect = False
        Me.Lista.Name = "Lista"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Lista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Lista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Lista.Size = New System.Drawing.Size(617, 105)
        Me.Lista.TabIndex = 0
        '
        'BotonCerrar
        '
        Me.BotonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.BotonCerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonCerrar.Location = New System.Drawing.Point(353, 151)
        Me.BotonCerrar.Name = "BotonCerrar"
        Me.BotonCerrar.Size = New System.Drawing.Size(55, 40)
        Me.BotonCerrar.TabIndex = 4
        Me.BotonCerrar.Text = "Close"
        Me.BotonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonCerrar.UseVisualStyleBackColor = True
        '
        'EtiquetaTotal
        '
        Me.EtiquetaTotal.AutoSize = True
        Me.EtiquetaTotal.Location = New System.Drawing.Point(9, 174)
        Me.EtiquetaTotal.Name = "EtiquetaTotal"
        Me.EtiquetaTotal.Size = New System.Drawing.Size(70, 13)
        Me.EtiquetaTotal.TabIndex = 1
        Me.EtiquetaTotal.Text = "Total Amount"
        '
        'CeldaTotal
        '
        Me.CeldaTotal.BackColor = System.Drawing.SystemColors.ControlLight
        Me.CeldaTotal.Location = New System.Drawing.Point(85, 171)
        Me.CeldaTotal.Name = "CeldaTotal"
        Me.CeldaTotal.Size = New System.Drawing.Size(80, 20)
        Me.CeldaTotal.TabIndex = 2
        Me.CeldaTotal.TabStop = False
        Me.CeldaTotal.Text = "0.00"
        Me.CeldaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PanelTitulo
        '
        Me.PanelTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelTitulo.Controls.Add(Me.BotonAgregar)
        Me.PanelTitulo.Controls.Add(Me.BotonQuitar)
        Me.PanelTitulo.Controls.Add(Me.EtiquetaTitulo)
        Me.PanelTitulo.Location = New System.Drawing.Point(12, 12)
        Me.PanelTitulo.Name = "PanelTitulo"
        Me.PanelTitulo.Size = New System.Drawing.Size(617, 24)
        Me.PanelTitulo.TabIndex = 5
        '
        'BotonAgregar
        '
        Me.BotonAgregar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonAgregar.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonAgregar.Location = New System.Drawing.Point(516, 2)
        Me.BotonAgregar.Name = "BotonAgregar"
        Me.BotonAgregar.Size = New System.Drawing.Size(46, 20)
        Me.BotonAgregar.TabIndex = 1
        Me.BotonAgregar.Text = "Add"
        Me.BotonAgregar.UseVisualStyleBackColor = True
        '
        'BotonQuitar
        '
        Me.BotonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonQuitar.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BotonQuitar.Location = New System.Drawing.Point(568, 2)
        Me.BotonQuitar.Name = "BotonQuitar"
        Me.BotonQuitar.Size = New System.Drawing.Size(46, 20)
        Me.BotonQuitar.TabIndex = 2
        Me.BotonQuitar.Text = "Delete"
        Me.BotonQuitar.UseVisualStyleBackColor = True
        '
        'EtiquetaTitulo
        '
        Me.EtiquetaTitulo.AutoSize = True
        Me.EtiquetaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaTitulo.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.EtiquetaTitulo.Location = New System.Drawing.Point(6, 3)
        Me.EtiquetaTitulo.Name = "EtiquetaTitulo"
        Me.EtiquetaTitulo.Size = New System.Drawing.Size(122, 16)
        Me.EtiquetaTitulo.TabIndex = 0
        Me.EtiquetaTitulo.Text = "Allocation Detail"
        '
        'BotonGuardar
        '
        Me.BotonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.next_set_2
        Me.BotonGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonGuardar.Location = New System.Drawing.Point(292, 151)
        Me.BotonGuardar.Name = "BotonGuardar"
        Me.BotonGuardar.Size = New System.Drawing.Size(55, 40)
        Me.BotonGuardar.TabIndex = 3
        Me.BotonGuardar.Text = "Save"
        Me.BotonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonGuardar.UseVisualStyleBackColor = True
        '
        'lista_cuenta
        '
        Me.lista_cuenta.HeaderText = "Account"
        Me.lista_cuenta.Name = "lista_cuenta"
        Me.lista_cuenta.ReadOnly = True
        Me.lista_cuenta.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_cuenta.Visible = False
        '
        'lista_nombre
        '
        Me.lista_nombre.HeaderText = "Description"
        Me.lista_nombre.Name = "lista_nombre"
        Me.lista_nombre.ReadOnly = True
        Me.lista_nombre.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_nombre.Width = 230
        '
        'lista_name
        '
        Me.lista_name.HeaderText = "Name"
        Me.lista_name.Name = "lista_name"
        Me.lista_name.ReadOnly = True
        Me.lista_name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_name.Width = 230
        '
        'lista_monto
        '
        Me.lista_monto.HeaderText = "Amount"
        Me.lista_monto.Name = "lista_monto"
        Me.lista_monto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'frmBPresupuesto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(641, 203)
        Me.Controls.Add(Me.BotonGuardar)
        Me.Controls.Add(Me.Lista)
        Me.Controls.Add(Me.PanelTitulo)
        Me.Controls.Add(Me.CeldaTotal)
        Me.Controls.Add(Me.EtiquetaTotal)
        Me.Controls.Add(Me.BotonCerrar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmBPresupuesto"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Budget"
        CType(Me.Lista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTitulo.ResumeLayout(False)
        Me.PanelTitulo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Lista As DataGridView
    Friend WithEvents BotonCerrar As Button
    Friend WithEvents EtiquetaTotal As Label
    Friend WithEvents CeldaTotal As TextBox
    Friend WithEvents PanelTitulo As Panel
    Friend WithEvents BotonAgregar As Button
    Friend WithEvents BotonQuitar As Button
    Friend WithEvents EtiquetaTitulo As Label
    Friend WithEvents BotonGuardar As Button
    Friend WithEvents lista_cuenta As DataGridViewTextBoxColumn
    Friend WithEvents lista_nombre As DataGridViewTextBoxColumn
    Friend WithEvents lista_name As DataGridViewTextBoxColumn
    Friend WithEvents lista_monto As DataGridViewTextBoxColumn
End Class
