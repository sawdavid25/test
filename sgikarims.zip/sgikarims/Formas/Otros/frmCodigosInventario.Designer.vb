﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCodigosInventario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCodigosInventario))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.botonCrearGenericos = New System.Windows.Forms.Button()
        Me.botonMostrarAll = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.panelLista2 = New System.Windows.Forms.Panel()
        Me.panelList2 = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescription = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProvider = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCost = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGenerico = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActive = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelList = New System.Windows.Forms.Panel()
        Me.celdaBuscar = New System.Windows.Forms.TextBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.checkMuestra = New System.Windows.Forms.CheckBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.etiquetaCodigo = New System.Windows.Forms.Label()
        Me.celdaDesactivar = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.checkDesactivar = New System.Windows.Forms.CheckBox()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.celdaIDProducto = New System.Windows.Forms.TextBox()
        Me.etiquetaArticulo = New System.Windows.Forms.Label()
        Me.celdaIDCompra = New System.Windows.Forms.TextBox()
        Me.celdaArticulo = New System.Windows.Forms.TextBox()
        Me.celdaIDVenta = New System.Windows.Forms.TextBox()
        Me.etiquetaNParte = New System.Windows.Forms.Label()
        Me.rbotonBaja = New System.Windows.Forms.RadioButton()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.rbotonActivo = New System.Windows.Forms.RadioButton()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.celdaIDPais = New System.Windows.Forms.TextBox()
        Me.celdaNParte = New System.Windows.Forms.TextBox()
        Me.celdaIDProveedor = New System.Windows.Forms.TextBox()
        Me.etiquetaNumLote = New System.Windows.Forms.Label()
        Me.checkActivoFijo = New System.Windows.Forms.CheckBox()
        Me.etiquetaPais = New System.Windows.Forms.Label()
        Me.checkGenerico = New System.Windows.Forms.CheckBox()
        Me.celdaPais = New System.Windows.Forms.TextBox()
        Me.celdaContenido = New System.Windows.Forms.TextBox()
        Me.celdaLoteNumb = New System.Windows.Forms.TextBox()
        Me.etiquetaContenido = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.botonCompra = New System.Windows.Forms.Button()
        Me.etiquetaSemana = New System.Windows.Forms.Label()
        Me.celdaCompra = New System.Windows.Forms.TextBox()
        Me.etiquetaSituacion = New System.Windows.Forms.Label()
        Me.etiquetaCompra = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.botonVenta = New System.Windows.Forms.Button()
        Me.celdaSemana = New System.Windows.Forms.TextBox()
        Me.celdaVenta = New System.Windows.Forms.TextBox()
        Me.etiquetaNotas = New System.Windows.Forms.Label()
        Me.etiquetaVenta = New System.Windows.Forms.Label()
        Me.celdaNotas = New System.Windows.Forms.TextBox()
        Me.botonPais = New System.Windows.Forms.Button()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.gbCostos = New System.Windows.Forms.GroupBox()
        Me.celdaCIFAnterior = New System.Windows.Forms.TextBox()
        Me.celdaIDCostoCIF = New System.Windows.Forms.TextBox()
        Me.botonCostoCIF = New System.Windows.Forms.Button()
        Me.celdaFactor = New System.Windows.Forms.TextBox()
        Me.etiquetaFactor = New System.Windows.Forms.Label()
        Me.celdaPrecioMax = New System.Windows.Forms.TextBox()
        Me.etiquetaPrecioMax = New System.Windows.Forms.Label()
        Me.celdaPrecioMin = New System.Windows.Forms.TextBox()
        Me.etiquetaPrecio = New System.Windows.Forms.Label()
        Me.celdaCostoCIF = New System.Windows.Forms.TextBox()
        Me.etiquetaCostosCIF = New System.Windows.Forms.Label()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonCopiarDatos = New System.Windows.Forms.Button()
        Me.botonSepCopiar = New System.Windows.Forms.Button()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        Me.panelLista2.SuspendLayout()
        Me.panelList2.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelList.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        Me.gbCostos.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 11)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 17)
        Me.Label1.TabIndex = 2
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.botonCrearGenericos)
        Me.panelLista.Controls.Add(Me.botonMostrarAll)
        Me.panelLista.Controls.Add(Me.botonActualizar)
        Me.panelLista.Controls.Add(Me.botonBuscar)
        Me.panelLista.Controls.Add(Me.panelLista2)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 126)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1073, 146)
        Me.panelLista.TabIndex = 22
        '
        'botonCrearGenericos
        '
        Me.botonCrearGenericos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCrearGenericos.Image = CType(resources.GetObject("botonCrearGenericos.Image"), System.Drawing.Image)
        Me.botonCrearGenericos.Location = New System.Drawing.Point(1019, 25)
        Me.botonCrearGenericos.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCrearGenericos.Name = "botonCrearGenericos"
        Me.botonCrearGenericos.Size = New System.Drawing.Size(40, 32)
        Me.botonCrearGenericos.TabIndex = 5
        Me.botonCrearGenericos.UseVisualStyleBackColor = True
        Me.botonCrearGenericos.Visible = False
        '
        'botonMostrarAll
        '
        Me.botonMostrarAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonMostrarAll.Location = New System.Drawing.Point(783, 27)
        Me.botonMostrarAll.Margin = New System.Windows.Forms.Padding(4)
        Me.botonMostrarAll.Name = "botonMostrarAll"
        Me.botonMostrarAll.Size = New System.Drawing.Size(145, 28)
        Me.botonMostrarAll.TabIndex = 4
        Me.botonMostrarAll.Text = "Show Everything ..."
        Me.botonMostrarAll.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(549, 27)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Location = New System.Drawing.Point(441, 27)
        Me.botonBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(100, 28)
        Me.botonBuscar.TabIndex = 2
        Me.botonBuscar.Text = "Look"
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'panelLista2
        '
        Me.panelLista2.Controls.Add(Me.panelList2)
        Me.panelLista2.Controls.Add(Me.panelList)
        Me.panelLista2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelLista2.Location = New System.Drawing.Point(0, 0)
        Me.panelLista2.Margin = New System.Windows.Forms.Padding(4)
        Me.panelLista2.Name = "panelLista2"
        Me.panelLista2.Size = New System.Drawing.Size(1073, 146)
        Me.panelLista2.TabIndex = 0
        '
        'panelList2
        '
        Me.panelList2.Controls.Add(Me.dgLista)
        Me.panelList2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelList2.Location = New System.Drawing.Point(0, 73)
        Me.panelList2.Margin = New System.Windows.Forms.Padding(4)
        Me.panelList2.Name = "panelList2"
        Me.panelList2.Size = New System.Drawing.Size(1073, 73)
        Me.panelList2.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumber, Me.colDescription, Me.colProvider, Me.colCost, Me.colGenerico, Me.colActive})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1073, 73)
        Me.dgLista.TabIndex = 0
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 87
        '
        'colDescription
        '
        Me.colDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescription.HeaderText = "Description"
        Me.colDescription.Name = "colDescription"
        Me.colDescription.ReadOnly = True
        Me.colDescription.Width = 108
        '
        'colProvider
        '
        Me.colProvider.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colProvider.HeaderText = "Provider"
        Me.colProvider.Name = "colProvider"
        Me.colProvider.ReadOnly = True
        Me.colProvider.Width = 90
        '
        'colCost
        '
        Me.colCost.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCost.HeaderText = "Cost"
        Me.colCost.Name = "colCost"
        Me.colCost.ReadOnly = True
        Me.colCost.Width = 65
        '
        'colGenerico
        '
        Me.colGenerico.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGenerico.HeaderText = "Generic Inventory"
        Me.colGenerico.Name = "colGenerico"
        Me.colGenerico.ReadOnly = True
        Me.colGenerico.Visible = False
        Me.colGenerico.Width = 149
        '
        'colActive
        '
        Me.colActive.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActive.HeaderText = "Active Inventory"
        Me.colActive.Name = "colActive"
        Me.colActive.ReadOnly = True
        Me.colActive.Visible = False
        Me.colActive.Width = 137
        '
        'panelList
        '
        Me.panelList.BackColor = System.Drawing.SystemColors.Info
        Me.panelList.Controls.Add(Me.celdaBuscar)
        Me.panelList.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelList.Location = New System.Drawing.Point(0, 0)
        Me.panelList.Margin = New System.Windows.Forms.Padding(4)
        Me.panelList.Name = "panelList"
        Me.panelList.Size = New System.Drawing.Size(1073, 73)
        Me.panelList.TabIndex = 1
        '
        'celdaBuscar
        '
        Me.celdaBuscar.Location = New System.Drawing.Point(23, 30)
        Me.celdaBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaBuscar.Name = "celdaBuscar"
        Me.celdaBuscar.Size = New System.Drawing.Size(409, 22)
        Me.celdaBuscar.TabIndex = 1
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.panelDatos)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumento.Location = New System.Drawing.Point(0, 272)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1073, 377)
        Me.panelDocumento.TabIndex = 23
        Me.panelDocumento.Visible = False
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.checkMuestra)
        Me.panelEncabezado.Controls.Add(Me.celdaDescripcion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDescripcion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCodigo)
        Me.panelEncabezado.Controls.Add(Me.celdaDesactivar)
        Me.panelEncabezado.Controls.Add(Me.celdaCodigo)
        Me.panelEncabezado.Controls.Add(Me.checkDesactivar)
        Me.panelEncabezado.Controls.Add(Me.etiquetaProducto)
        Me.panelEncabezado.Controls.Add(Me.botonProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaIDProducto)
        Me.panelEncabezado.Controls.Add(Me.etiquetaArticulo)
        Me.panelEncabezado.Controls.Add(Me.celdaIDCompra)
        Me.panelEncabezado.Controls.Add(Me.celdaArticulo)
        Me.panelEncabezado.Controls.Add(Me.celdaIDVenta)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNParte)
        Me.panelEncabezado.Controls.Add(Me.rbotonBaja)
        Me.panelEncabezado.Controls.Add(Me.etiquetaProveedor)
        Me.panelEncabezado.Controls.Add(Me.rbotonActivo)
        Me.panelEncabezado.Controls.Add(Me.celdaProveedor)
        Me.panelEncabezado.Controls.Add(Me.celdaIDPais)
        Me.panelEncabezado.Controls.Add(Me.celdaNParte)
        Me.panelEncabezado.Controls.Add(Me.celdaIDProveedor)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumLote)
        Me.panelEncabezado.Controls.Add(Me.checkActivoFijo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaPais)
        Me.panelEncabezado.Controls.Add(Me.checkGenerico)
        Me.panelEncabezado.Controls.Add(Me.celdaPais)
        Me.panelEncabezado.Controls.Add(Me.celdaContenido)
        Me.panelEncabezado.Controls.Add(Me.celdaLoteNumb)
        Me.panelEncabezado.Controls.Add(Me.etiquetaContenido)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAño)
        Me.panelEncabezado.Controls.Add(Me.botonCompra)
        Me.panelEncabezado.Controls.Add(Me.etiquetaSemana)
        Me.panelEncabezado.Controls.Add(Me.celdaCompra)
        Me.panelEncabezado.Controls.Add(Me.etiquetaSituacion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCompra)
        Me.panelEncabezado.Controls.Add(Me.celdaAño)
        Me.panelEncabezado.Controls.Add(Me.botonVenta)
        Me.panelEncabezado.Controls.Add(Me.celdaSemana)
        Me.panelEncabezado.Controls.Add(Me.celdaVenta)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNotas)
        Me.panelEncabezado.Controls.Add(Me.etiquetaVenta)
        Me.panelEncabezado.Controls.Add(Me.celdaNotas)
        Me.panelEncabezado.Controls.Add(Me.botonPais)
        Me.panelEncabezado.Controls.Add(Me.botonProveedor)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1073, 185)
        Me.panelEncabezado.TabIndex = 48
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(339, 12)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(127, 22)
        Me.dtpFecha.TabIndex = 52
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(278, 17)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaFecha.TabIndex = 51
        Me.etiquetaFecha.Text = "Fecha"
        '
        'checkMuestra
        '
        Me.checkMuestra.AutoSize = True
        Me.checkMuestra.Location = New System.Drawing.Point(643, 14)
        Me.checkMuestra.Name = "checkMuestra"
        Me.checkMuestra.Size = New System.Drawing.Size(77, 21)
        Me.checkMuestra.TabIndex = 50
        Me.checkMuestra.Text = "Sample"
        Me.checkMuestra.UseVisualStyleBackColor = True
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDescripcion.Location = New System.Drawing.Point(476, 378)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(437, 39)
        Me.celdaDescripcion.TabIndex = 49
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(473, 357)
        Me.etiquetaDescripcion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 48
        Me.etiquetaDescripcion.Text = "Description"
        '
        'etiquetaCodigo
        '
        Me.etiquetaCodigo.AutoSize = True
        Me.etiquetaCodigo.Location = New System.Drawing.Point(11, 17)
        Me.etiquetaCodigo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCodigo.Name = "etiquetaCodigo"
        Me.etiquetaCodigo.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaCodigo.TabIndex = 0
        Me.etiquetaCodigo.Text = "Code"
        '
        'celdaDesactivar
        '
        Me.celdaDesactivar.AutoSize = True
        Me.celdaDesactivar.BackColor = System.Drawing.Color.Red
        Me.celdaDesactivar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDesactivar.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.celdaDesactivar.Location = New System.Drawing.Point(919, 13)
        Me.celdaDesactivar.Name = "celdaDesactivar"
        Me.celdaDesactivar.Size = New System.Drawing.Size(140, 20)
        Me.celdaDesactivar.TabIndex = 47
        Me.celdaDesactivar.Text = "DESACTIVADO"
        Me.celdaDesactivar.Visible = False
        '
        'celdaCodigo
        '
        Me.celdaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigo.Location = New System.Drawing.Point(133, 13)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.Size = New System.Drawing.Size(120, 22)
        Me.celdaCodigo.TabIndex = 1
        Me.celdaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'checkDesactivar
        '
        Me.checkDesactivar.AutoSize = True
        Me.checkDesactivar.Checked = True
        Me.checkDesactivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkDesactivar.Location = New System.Drawing.Point(766, 15)
        Me.checkDesactivar.Name = "checkDesactivar"
        Me.checkDesactivar.Size = New System.Drawing.Size(129, 21)
        Me.checkDesactivar.TabIndex = 1
        Me.checkDesactivar.Text = "Disable product"
        Me.checkDesactivar.UseVisualStyleBackColor = True
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(11, 62)
        Me.etiquetaProducto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaProducto.TabIndex = 2
        Me.etiquetaProducto.Text = "Product"
        '
        'botonProducto
        '
        Me.botonProducto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProducto.Location = New System.Drawing.Point(904, 56)
        Me.botonProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(45, 28)
        Me.botonProducto.TabIndex = 46
        Me.botonProducto.Text = "..."
        Me.botonProducto.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProducto.Location = New System.Drawing.Point(133, 58)
        Me.celdaProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaProducto.Multiline = True
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.ReadOnly = True
        Me.celdaProducto.Size = New System.Drawing.Size(754, 24)
        Me.celdaProducto.TabIndex = 3
        '
        'celdaIDProducto
        '
        Me.celdaIDProducto.Location = New System.Drawing.Point(904, 92)
        Me.celdaIDProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDProducto.Multiline = True
        Me.celdaIDProducto.Name = "celdaIDProducto"
        Me.celdaIDProducto.Size = New System.Drawing.Size(25, 24)
        Me.celdaIDProducto.TabIndex = 45
        Me.celdaIDProducto.Text = "-1"
        Me.celdaIDProducto.Visible = False
        '
        'etiquetaArticulo
        '
        Me.etiquetaArticulo.AutoSize = True
        Me.etiquetaArticulo.Location = New System.Drawing.Point(8, 103)
        Me.etiquetaArticulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaArticulo.Name = "etiquetaArticulo"
        Me.etiquetaArticulo.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaArticulo.TabIndex = 4
        Me.etiquetaArticulo.Text = "Article"
        '
        'celdaIDCompra
        '
        Me.celdaIDCompra.Location = New System.Drawing.Point(587, 174)
        Me.celdaIDCompra.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDCompra.Multiline = True
        Me.celdaIDCompra.Name = "celdaIDCompra"
        Me.celdaIDCompra.Size = New System.Drawing.Size(25, 24)
        Me.celdaIDCompra.TabIndex = 44
        Me.celdaIDCompra.Text = "-1"
        Me.celdaIDCompra.Visible = False
        '
        'celdaArticulo
        '
        Me.celdaArticulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaArticulo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaArticulo.Enabled = False
        Me.celdaArticulo.Location = New System.Drawing.Point(133, 100)
        Me.celdaArticulo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaArticulo.Multiline = True
        Me.celdaArticulo.Name = "celdaArticulo"
        Me.celdaArticulo.Size = New System.Drawing.Size(754, 45)
        Me.celdaArticulo.TabIndex = 5
        '
        'celdaIDVenta
        '
        Me.celdaIDVenta.Location = New System.Drawing.Point(846, 103)
        Me.celdaIDVenta.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDVenta.Multiline = True
        Me.celdaIDVenta.Name = "celdaIDVenta"
        Me.celdaIDVenta.Size = New System.Drawing.Size(25, 24)
        Me.celdaIDVenta.TabIndex = 43
        Me.celdaIDVenta.Text = "-1"
        Me.celdaIDVenta.Visible = False
        '
        'etiquetaNParte
        '
        Me.etiquetaNParte.AutoSize = True
        Me.etiquetaNParte.Location = New System.Drawing.Point(8, 203)
        Me.etiquetaNParte.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNParte.Name = "etiquetaNParte"
        Me.etiquetaNParte.Size = New System.Drawing.Size(88, 17)
        Me.etiquetaNParte.TabIndex = 6
        Me.etiquetaNParte.Text = "Part Number"
        '
        'rbotonBaja
        '
        Me.rbotonBaja.AutoSize = True
        Me.rbotonBaja.Location = New System.Drawing.Point(209, 398)
        Me.rbotonBaja.Margin = New System.Windows.Forms.Padding(4)
        Me.rbotonBaja.Name = "rbotonBaja"
        Me.rbotonBaja.Size = New System.Drawing.Size(57, 21)
        Me.rbotonBaja.TabIndex = 42
        Me.rbotonBaja.TabStop = True
        Me.rbotonBaja.Text = "Baja"
        Me.rbotonBaja.UseVisualStyleBackColor = True
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(8, 165)
        Me.etiquetaProveedor.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaProveedor.TabIndex = 7
        Me.etiquetaProveedor.Text = "Provider"
        '
        'rbotonActivo
        '
        Me.rbotonActivo.AutoSize = True
        Me.rbotonActivo.Location = New System.Drawing.Point(133, 398)
        Me.rbotonActivo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbotonActivo.Name = "rbotonActivo"
        Me.rbotonActivo.Size = New System.Drawing.Size(67, 21)
        Me.rbotonActivo.TabIndex = 41
        Me.rbotonActivo.TabStop = True
        Me.rbotonActivo.Text = "Activo"
        Me.rbotonActivo.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(133, 161)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaProveedor.Multiline = True
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(288, 24)
        Me.celdaProveedor.TabIndex = 8
        '
        'celdaIDPais
        '
        Me.celdaIDPais.Location = New System.Drawing.Point(484, 240)
        Me.celdaIDPais.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDPais.Multiline = True
        Me.celdaIDPais.Name = "celdaIDPais"
        Me.celdaIDPais.Size = New System.Drawing.Size(25, 24)
        Me.celdaIDPais.TabIndex = 40
        Me.celdaIDPais.Text = "-1"
        Me.celdaIDPais.Visible = False
        '
        'celdaNParte
        '
        Me.celdaNParte.Location = New System.Drawing.Point(133, 199)
        Me.celdaNParte.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNParte.Multiline = True
        Me.celdaNParte.Name = "celdaNParte"
        Me.celdaNParte.Size = New System.Drawing.Size(136, 24)
        Me.celdaNParte.TabIndex = 9
        Me.celdaNParte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaIDProveedor
        '
        Me.celdaIDProveedor.Location = New System.Drawing.Point(484, 161)
        Me.celdaIDProveedor.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDProveedor.Multiline = True
        Me.celdaIDProveedor.Name = "celdaIDProveedor"
        Me.celdaIDProveedor.Size = New System.Drawing.Size(25, 24)
        Me.celdaIDProveedor.TabIndex = 39
        Me.celdaIDProveedor.Text = "0"
        Me.celdaIDProveedor.Visible = False
        '
        'etiquetaNumLote
        '
        Me.etiquetaNumLote.AutoSize = True
        Me.etiquetaNumLote.Location = New System.Drawing.Point(8, 283)
        Me.etiquetaNumLote.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNumLote.Name = "etiquetaNumLote"
        Me.etiquetaNumLote.Size = New System.Drawing.Size(82, 17)
        Me.etiquetaNumLote.TabIndex = 10
        Me.etiquetaNumLote.Text = "Lot Number"
        '
        'checkActivoFijo
        '
        Me.checkActivoFijo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivoFijo.AutoSize = True
        Me.checkActivoFijo.Location = New System.Drawing.Point(962, 69)
        Me.checkActivoFijo.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActivoFijo.Name = "checkActivoFijo"
        Me.checkActivoFijo.Size = New System.Drawing.Size(109, 21)
        Me.checkActivoFijo.TabIndex = 38
        Me.checkActivoFijo.Text = "Fixed Assets"
        Me.checkActivoFijo.UseVisualStyleBackColor = True
        '
        'etiquetaPais
        '
        Me.etiquetaPais.AutoSize = True
        Me.etiquetaPais.Location = New System.Drawing.Point(8, 244)
        Me.etiquetaPais.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPais.Name = "etiquetaPais"
        Me.etiquetaPais.Size = New System.Drawing.Size(118, 17)
        Me.etiquetaPais.TabIndex = 11
        Me.etiquetaPais.Text = "Country Of Origin"
        '
        'checkGenerico
        '
        Me.checkGenerico.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkGenerico.AutoSize = True
        Me.checkGenerico.Checked = True
        Me.checkGenerico.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkGenerico.Location = New System.Drawing.Point(962, 41)
        Me.checkGenerico.Margin = New System.Windows.Forms.Padding(4)
        Me.checkGenerico.Name = "checkGenerico"
        Me.checkGenerico.Size = New System.Drawing.Size(80, 21)
        Me.checkGenerico.TabIndex = 37
        Me.checkGenerico.Text = "Generic"
        Me.checkGenerico.UseVisualStyleBackColor = True
        '
        'celdaPais
        '
        Me.celdaPais.Location = New System.Drawing.Point(133, 240)
        Me.celdaPais.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPais.Multiline = True
        Me.celdaPais.Name = "celdaPais"
        Me.celdaPais.ReadOnly = True
        Me.celdaPais.Size = New System.Drawing.Size(288, 24)
        Me.celdaPais.TabIndex = 12
        '
        'celdaContenido
        '
        Me.celdaContenido.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaContenido.Location = New System.Drawing.Point(717, 252)
        Me.celdaContenido.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaContenido.Multiline = True
        Me.celdaContenido.Name = "celdaContenido"
        Me.celdaContenido.Size = New System.Drawing.Size(178, 24)
        Me.celdaContenido.TabIndex = 36
        '
        'celdaLoteNumb
        '
        Me.celdaLoteNumb.Location = New System.Drawing.Point(133, 279)
        Me.celdaLoteNumb.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLoteNumb.Multiline = True
        Me.celdaLoteNumb.Name = "celdaLoteNumb"
        Me.celdaLoteNumb.Size = New System.Drawing.Size(288, 24)
        Me.celdaLoteNumb.TabIndex = 13
        '
        'etiquetaContenido
        '
        Me.etiquetaContenido.AutoSize = True
        Me.etiquetaContenido.Location = New System.Drawing.Point(652, 256)
        Me.etiquetaContenido.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaContenido.Name = "etiquetaContenido"
        Me.etiquetaContenido.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaContenido.TabIndex = 35
        Me.etiquetaContenido.Text = "Content"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(8, 321)
        Me.etiquetaAño.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(43, 17)
        Me.etiquetaAño.TabIndex = 14
        Me.etiquetaAño.Text = "Year*"
        '
        'botonCompra
        '
        Me.botonCompra.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCompra.Location = New System.Drawing.Point(904, 212)
        Me.botonCompra.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCompra.Name = "botonCompra"
        Me.botonCompra.Size = New System.Drawing.Size(45, 28)
        Me.botonCompra.TabIndex = 34
        Me.botonCompra.Text = "..."
        Me.botonCompra.UseVisualStyleBackColor = True
        '
        'etiquetaSemana
        '
        Me.etiquetaSemana.AutoSize = True
        Me.etiquetaSemana.Location = New System.Drawing.Point(8, 360)
        Me.etiquetaSemana.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSemana.Name = "etiquetaSemana"
        Me.etiquetaSemana.Size = New System.Drawing.Size(44, 17)
        Me.etiquetaSemana.TabIndex = 15
        Me.etiquetaSemana.Text = "Week"
        '
        'celdaCompra
        '
        Me.celdaCompra.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCompra.Location = New System.Drawing.Point(717, 214)
        Me.celdaCompra.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCompra.Multiline = True
        Me.celdaCompra.Name = "celdaCompra"
        Me.celdaCompra.ReadOnly = True
        Me.celdaCompra.Size = New System.Drawing.Size(178, 24)
        Me.celdaCompra.TabIndex = 33
        '
        'etiquetaSituacion
        '
        Me.etiquetaSituacion.AutoSize = True
        Me.etiquetaSituacion.Location = New System.Drawing.Point(8, 400)
        Me.etiquetaSituacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSituacion.Name = "etiquetaSituacion"
        Me.etiquetaSituacion.Size = New System.Drawing.Size(63, 17)
        Me.etiquetaSituacion.TabIndex = 16
        Me.etiquetaSituacion.Text = "Situation"
        '
        'etiquetaCompra
        '
        Me.etiquetaCompra.AutoSize = True
        Me.etiquetaCompra.Location = New System.Drawing.Point(640, 218)
        Me.etiquetaCompra.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCompra.Name = "etiquetaCompra"
        Me.etiquetaCompra.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaCompra.TabIndex = 32
        Me.etiquetaCompra.Text = "UM / Buy"
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAño.Enabled = False
        Me.celdaAño.Location = New System.Drawing.Point(133, 317)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAño.Multiline = True
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(59, 24)
        Me.celdaAño.TabIndex = 17
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonVenta
        '
        Me.botonVenta.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonVenta.Location = New System.Drawing.Point(904, 170)
        Me.botonVenta.Margin = New System.Windows.Forms.Padding(4)
        Me.botonVenta.Name = "botonVenta"
        Me.botonVenta.Size = New System.Drawing.Size(45, 28)
        Me.botonVenta.TabIndex = 31
        Me.botonVenta.Text = "..."
        Me.botonVenta.UseVisualStyleBackColor = True
        '
        'celdaSemana
        '
        Me.celdaSemana.Location = New System.Drawing.Point(133, 356)
        Me.celdaSemana.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSemana.Multiline = True
        Me.celdaSemana.Name = "celdaSemana"
        Me.celdaSemana.Size = New System.Drawing.Size(59, 24)
        Me.celdaSemana.TabIndex = 18
        Me.celdaSemana.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaVenta
        '
        Me.celdaVenta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaVenta.Location = New System.Drawing.Point(717, 174)
        Me.celdaVenta.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaVenta.Multiline = True
        Me.celdaVenta.Name = "celdaVenta"
        Me.celdaVenta.ReadOnly = True
        Me.celdaVenta.Size = New System.Drawing.Size(178, 24)
        Me.celdaVenta.TabIndex = 30
        '
        'etiquetaNotas
        '
        Me.etiquetaNotas.AutoSize = True
        Me.etiquetaNotas.Location = New System.Drawing.Point(473, 270)
        Me.etiquetaNotas.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNotas.Name = "etiquetaNotas"
        Me.etiquetaNotas.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaNotas.TabIndex = 20
        Me.etiquetaNotas.Text = "Notes"
        '
        'etiquetaVenta
        '
        Me.etiquetaVenta.AutoSize = True
        Me.etiquetaVenta.Location = New System.Drawing.Point(640, 177)
        Me.etiquetaVenta.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaVenta.Name = "etiquetaVenta"
        Me.etiquetaVenta.Size = New System.Drawing.Size(69, 17)
        Me.etiquetaVenta.TabIndex = 29
        Me.etiquetaVenta.Text = "UM / Sale"
        '
        'celdaNotas
        '
        Me.celdaNotas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNotas.Location = New System.Drawing.Point(476, 291)
        Me.celdaNotas.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNotas.Multiline = True
        Me.celdaNotas.Name = "celdaNotas"
        Me.celdaNotas.Size = New System.Drawing.Size(437, 56)
        Me.celdaNotas.TabIndex = 21
        '
        'botonPais
        '
        Me.botonPais.Location = New System.Drawing.Point(431, 238)
        Me.botonPais.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPais.Name = "botonPais"
        Me.botonPais.Size = New System.Drawing.Size(45, 28)
        Me.botonPais.TabIndex = 27
        Me.botonPais.Text = "..."
        Me.botonPais.UseVisualStyleBackColor = True
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(431, 158)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(4)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(45, 28)
        Me.botonProveedor.TabIndex = 26
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.gbCostos)
        Me.panelDatos.Controls.Add(Me.panelDetalle)
        Me.panelDatos.Controls.Add(Me.botonCopiarDatos)
        Me.panelDatos.Controls.Add(Me.botonSepCopiar)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelDatos.Location = New System.Drawing.Point(0, 185)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1073, 192)
        Me.panelDatos.TabIndex = 49
        '
        'gbCostos
        '
        Me.gbCostos.Controls.Add(Me.celdaCIFAnterior)
        Me.gbCostos.Controls.Add(Me.celdaIDCostoCIF)
        Me.gbCostos.Controls.Add(Me.botonCostoCIF)
        Me.gbCostos.Controls.Add(Me.celdaFactor)
        Me.gbCostos.Controls.Add(Me.etiquetaFactor)
        Me.gbCostos.Controls.Add(Me.celdaPrecioMax)
        Me.gbCostos.Controls.Add(Me.etiquetaPrecioMax)
        Me.gbCostos.Controls.Add(Me.celdaPrecioMin)
        Me.gbCostos.Controls.Add(Me.etiquetaPrecio)
        Me.gbCostos.Controls.Add(Me.celdaCostoCIF)
        Me.gbCostos.Controls.Add(Me.etiquetaCostosCIF)
        Me.gbCostos.Location = New System.Drawing.Point(13, 8)
        Me.gbCostos.Margin = New System.Windows.Forms.Padding(4)
        Me.gbCostos.Name = "gbCostos"
        Me.gbCostos.Padding = New System.Windows.Forms.Padding(4)
        Me.gbCostos.Size = New System.Drawing.Size(352, 194)
        Me.gbCostos.TabIndex = 22
        Me.gbCostos.TabStop = False
        Me.gbCostos.Text = "Costs And Prices"
        '
        'celdaCIFAnterior
        '
        Me.celdaCIFAnterior.Location = New System.Drawing.Point(196, 12)
        Me.celdaCIFAnterior.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCIFAnterior.Multiline = True
        Me.celdaCIFAnterior.Name = "celdaCIFAnterior"
        Me.celdaCIFAnterior.Size = New System.Drawing.Size(99, 24)
        Me.celdaCIFAnterior.TabIndex = 42
        Me.celdaCIFAnterior.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaCIFAnterior.Visible = False
        '
        'celdaIDCostoCIF
        '
        Me.celdaIDCostoCIF.Location = New System.Drawing.Point(301, 66)
        Me.celdaIDCostoCIF.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDCostoCIF.Multiline = True
        Me.celdaIDCostoCIF.Name = "celdaIDCostoCIF"
        Me.celdaIDCostoCIF.Size = New System.Drawing.Size(25, 24)
        Me.celdaIDCostoCIF.TabIndex = 41
        Me.celdaIDCostoCIF.Text = "-1"
        Me.celdaIDCostoCIF.Visible = False
        '
        'botonCostoCIF
        '
        Me.botonCostoCIF.Location = New System.Drawing.Point(283, 36)
        Me.botonCostoCIF.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCostoCIF.Name = "botonCostoCIF"
        Me.botonCostoCIF.Size = New System.Drawing.Size(45, 28)
        Me.botonCostoCIF.TabIndex = 29
        Me.botonCostoCIF.Text = "..."
        Me.botonCostoCIF.UseVisualStyleBackColor = True
        '
        'celdaFactor
        '
        Me.celdaFactor.Location = New System.Drawing.Point(137, 140)
        Me.celdaFactor.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaFactor.Multiline = True
        Me.celdaFactor.Name = "celdaFactor"
        Me.celdaFactor.Size = New System.Drawing.Size(103, 24)
        Me.celdaFactor.TabIndex = 31
        Me.celdaFactor.Text = "1"
        Me.celdaFactor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaFactor
        '
        Me.etiquetaFactor.AutoSize = True
        Me.etiquetaFactor.Location = New System.Drawing.Point(64, 144)
        Me.etiquetaFactor.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFactor.Name = "etiquetaFactor"
        Me.etiquetaFactor.Size = New System.Drawing.Size(64, 17)
        Me.etiquetaFactor.TabIndex = 30
        Me.etiquetaFactor.Text = "Factor %"
        '
        'celdaPrecioMax
        '
        Me.celdaPrecioMax.Location = New System.Drawing.Point(137, 105)
        Me.celdaPrecioMax.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPrecioMax.Multiline = True
        Me.celdaPrecioMax.Name = "celdaPrecioMax"
        Me.celdaPrecioMax.Size = New System.Drawing.Size(136, 24)
        Me.celdaPrecioMax.TabIndex = 29
        Me.celdaPrecioMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaPrecioMax
        '
        Me.etiquetaPrecioMax.AutoSize = True
        Me.etiquetaPrecioMax.Location = New System.Drawing.Point(36, 108)
        Me.etiquetaPrecioMax.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPrecioMax.Name = "etiquetaPrecioMax"
        Me.etiquetaPrecioMax.Size = New System.Drawing.Size(94, 17)
        Me.etiquetaPrecioMax.TabIndex = 28
        Me.etiquetaPrecioMax.Text = "Miximun Price"
        '
        'celdaPrecioMin
        '
        Me.celdaPrecioMin.Location = New System.Drawing.Point(137, 71)
        Me.celdaPrecioMin.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPrecioMin.Multiline = True
        Me.celdaPrecioMin.Name = "celdaPrecioMin"
        Me.celdaPrecioMin.Size = New System.Drawing.Size(136, 24)
        Me.celdaPrecioMin.TabIndex = 27
        Me.celdaPrecioMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaPrecio
        '
        Me.etiquetaPrecio.AutoSize = True
        Me.etiquetaPrecio.Location = New System.Drawing.Point(36, 75)
        Me.etiquetaPrecio.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPrecio.Name = "etiquetaPrecio"
        Me.etiquetaPrecio.Size = New System.Drawing.Size(91, 17)
        Me.etiquetaPrecio.TabIndex = 26
        Me.etiquetaPrecio.Text = "Minimal Price"
        '
        'celdaCostoCIF
        '
        Me.celdaCostoCIF.Location = New System.Drawing.Point(137, 38)
        Me.celdaCostoCIF.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCostoCIF.Multiline = True
        Me.celdaCostoCIF.Name = "celdaCostoCIF"
        Me.celdaCostoCIF.Size = New System.Drawing.Size(136, 24)
        Me.celdaCostoCIF.TabIndex = 25
        Me.celdaCostoCIF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaCostosCIF
        '
        Me.etiquetaCostosCIF.AutoSize = True
        Me.etiquetaCostosCIF.Location = New System.Drawing.Point(65, 42)
        Me.etiquetaCostosCIF.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCostosCIF.Name = "etiquetaCostosCIF"
        Me.etiquetaCostosCIF.Size = New System.Drawing.Size(60, 17)
        Me.etiquetaCostosCIF.TabIndex = 24
        Me.etiquetaCostosCIF.Text = "Cost CIF"
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Location = New System.Drawing.Point(476, 8)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(486, 118)
        Me.panelDetalle.TabIndex = 23
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colReferencia, Me.colCantida, Me.colPrecio, Me.colAño, Me.colLinea})
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.ShowRowErrors = False
        Me.dgDetalle.Size = New System.Drawing.Size(470, 118)
        Me.dgDetalle.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colCantida
        '
        Me.colCantida.HeaderText = "Quantity"
        Me.colCantida.Name = "colCantida"
        Me.colCantida.ReadOnly = True
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'botonCopiarDatos
        '
        Me.botonCopiarDatos.Location = New System.Drawing.Point(476, 148)
        Me.botonCopiarDatos.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCopiarDatos.Name = "botonCopiarDatos"
        Me.botonCopiarDatos.Size = New System.Drawing.Size(117, 54)
        Me.botonCopiarDatos.TabIndex = 25
        Me.botonCopiarDatos.Text = "Copy Data"
        Me.botonCopiarDatos.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCopiarDatos.UseVisualStyleBackColor = True
        Me.botonCopiarDatos.Visible = False
        '
        'botonSepCopiar
        '
        Me.botonSepCopiar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSepCopiar.Location = New System.Drawing.Point(832, 150)
        Me.botonSepCopiar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonSepCopiar.Name = "botonSepCopiar"
        Me.botonSepCopiar.Size = New System.Drawing.Size(117, 54)
        Me.botonSepCopiar.TabIndex = 24
        Me.botonSepCopiar.Text = "Detach / Copy"
        Me.botonSepCopiar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonSepCopiar.UseVisualStyleBackColor = True
        Me.botonSepCopiar.Visible = False
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = CType(resources.GetObject("botonInprimir.Image"), System.Drawing.Image)
        Me.botonInprimir.Location = New System.Drawing.Point(277, 11)
        Me.botonInprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(79, 57)
        Me.botonInprimir.TabIndex = 21
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1073, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1073, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCodigosInventario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1073, 649)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmCodigosInventario"
        Me.Text = "frmCodigosInventario"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        Me.panelLista2.ResumeLayout(False)
        Me.panelList2.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelList.ResumeLayout(False)
        Me.panelList.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelDatos.ResumeLayout(False)
        Me.gbCostos.ResumeLayout(False)
        Me.gbCostos.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents celdaBuscar As System.Windows.Forms.TextBox
    Friend WithEvents panelLista2 As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonCrearGenericos As System.Windows.Forms.Button
    Friend WithEvents botonMostrarAll As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents botonCopiarDatos As System.Windows.Forms.Button
    Friend WithEvents botonSepCopiar As System.Windows.Forms.Button
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents gbCostos As System.Windows.Forms.GroupBox
    Friend WithEvents celdaFactor As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaFactor As System.Windows.Forms.Label
    Friend WithEvents celdaPrecioMax As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaPrecioMax As System.Windows.Forms.Label
    Friend WithEvents celdaPrecioMin As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaPrecio As System.Windows.Forms.Label
    Friend WithEvents celdaCostoCIF As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCostosCIF As System.Windows.Forms.Label
    Friend WithEvents celdaNotas As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNotas As System.Windows.Forms.Label
    Friend WithEvents celdaSemana As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSituacion As System.Windows.Forms.Label
    Friend WithEvents etiquetaSemana As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents celdaLoteNumb As System.Windows.Forms.TextBox
    Friend WithEvents celdaPais As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaPais As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumLote As System.Windows.Forms.Label
    Friend WithEvents celdaNParte As System.Windows.Forms.TextBox
    Friend WithEvents celdaProveedor As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProveedor As System.Windows.Forms.Label
    Friend WithEvents etiquetaNParte As System.Windows.Forms.Label
    Friend WithEvents celdaArticulo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaArticulo As System.Windows.Forms.Label
    Friend WithEvents celdaProducto As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProducto As System.Windows.Forms.Label
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCodigo As System.Windows.Forms.Label
    Friend WithEvents checkActivoFijo As System.Windows.Forms.CheckBox
    Friend WithEvents checkGenerico As System.Windows.Forms.CheckBox
    Friend WithEvents celdaContenido As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaContenido As System.Windows.Forms.Label
    Friend WithEvents botonCompra As System.Windows.Forms.Button
    Friend WithEvents celdaCompra As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCompra As System.Windows.Forms.Label
    Friend WithEvents botonVenta As System.Windows.Forms.Button
    Friend WithEvents celdaVenta As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaVenta As System.Windows.Forms.Label
    Friend WithEvents botonPais As System.Windows.Forms.Button
    Friend WithEvents botonProveedor As System.Windows.Forms.Button
    Friend WithEvents botonCostoCIF As System.Windows.Forms.Button
    Friend WithEvents celdaIDProveedor As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDPais As System.Windows.Forms.TextBox
    Friend WithEvents rbotonBaja As System.Windows.Forms.RadioButton
    Friend WithEvents rbotonActivo As System.Windows.Forms.RadioButton
    Friend WithEvents celdaIDCostoCIF As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCompra As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDVenta As System.Windows.Forms.TextBox
    Friend WithEvents botonProducto As System.Windows.Forms.Button
    Friend WithEvents celdaIDProducto As System.Windows.Forms.TextBox
    Friend WithEvents panelList2 As System.Windows.Forms.Panel
    Friend WithEvents panelList As System.Windows.Forms.Panel
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colCantida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents checkDesactivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDesactivar As Label
    Friend WithEvents panelDatos As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDescription As DataGridViewTextBoxColumn
    Friend WithEvents colProvider As DataGridViewTextBoxColumn
    Friend WithEvents colCost As DataGridViewTextBoxColumn
    Friend WithEvents colGenerico As DataGridViewTextBoxColumn
    Friend WithEvents colActive As DataGridViewTextBoxColumn
    Friend WithEvents celdaCIFAnterior As TextBox
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents etiquetaDescripcion As Label
    Friend WithEvents checkMuestra As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
End Class
