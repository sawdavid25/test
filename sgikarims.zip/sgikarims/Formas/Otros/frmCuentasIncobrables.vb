﻿Public Class frmCuentasIncobrables

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim SDoc As New frmSubDocumentos
    Dim Tbl_Documentos As String = "Dcmtos_HDR"

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub


    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            panelDetalle.Visible = False
            panelDetalle.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Uncollectible accounts")

            dtpInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
            dtpFinal.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            queryListaPrincipal()

        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDetalle.Visible = True
            panelDetalle.Dock = DockStyle.Fill
            BarraTitulo1.CambiarTitulo("Modify record")
        End If

    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Cliente, p.PDoc_Par_Num NumFactura, h.HDoc_Doc_Ano Anio"
        strsql &= "  FROM Dcmtos_HDR h"
        strsql &= "   LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Num = h.HDoc_Doc_Num"
        strsql &= "    WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=677"

        If checkFechas.Checked = True Then

            strsql &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicial.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "      GROUP BY  p.PDoc_Sis_Emp, p.PDoc_Chi_Cat, p.PDoc_Chi_Num "
        strsql &= "  ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim e As Integer
        Dim c As Integer
        Dim r As Integer
        Dim ch As Integer

        strSQL = SQLlista()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Numero") & "|" & REA.GetDateTime("Fecha") & "|" & REA.GetString("Cliente") & "|" & REA.GetInt32("NumFactura") & "|" & REA.GetInt32("Anio")


                    cfun.AgregarFila(dgLista, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SQLDetalle(ByVal numero As String, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT d.DDoc_Sis_Emp empresa, p.PDoc_Par_Num Factura, d.DDoc_RF1_Fec Fecha, d.DDoc_RF1_Cod Referencia, d.DDoc_Doc_Ano Anio, p.PDoc_Par_Cat Catalogo, p.PDoc_Par_Lin LinFactura, p.PDoc_Prd_NET Total, p.PDoc_QTY_Ord Saldo, p.PDoc_QTY_Pro Deuda, d.DDoc_RF1_Txt Orden, p.PDoc_Chi_Lin LinCuenta"
        strSql &= "     FROM Dcmtos_DTL d"
        strSql &= "         LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strSql &= " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 677 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
       
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{anio}", anio)

        Return strSql

    End Function

    'Procedimiento para CargardgDetalle 
    Public Sub queryDetalle(ByVal numero As String, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader

        strSQL = SQLDetalle(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgFactura.Rows.Clear()
                Dim intID As Integer
                Dim i As Integer = 0
                Dim contador As Integer
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("empresa") & "|"
                    strFila &= REA.GetInt32("Factura") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("LinFactura") & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetDouble("Saldo") & "|"
                    strFila &= REA.GetDouble("Deuda") & "|"
                    strFila &= REA.GetString("Orden") & "|"
                    strFila &= REA.GetInt32("LinCuenta") & "|"
                    strFila &= 0

                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CalcularTotales()
        'Dim Cantidad As Double
        Dim Total As Double
        Dim i As Integer
        For i = 0 To dgFactura.Rows.Count - 1

            'Cantidad = Cantidad + CDbl(dgFactura.Rows(i).Cells("colCantidadKG").Value)
            Total = Total + CDbl(dgFactura.Rows(i).Cells("colCuentaIncobrable").Value)

        Next

        celdaTotalCantidad.Text = CDbl(Total)

    End Sub



    Public Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL

        celdaNumero.Text = NO_FILA
        celdaCatalogo.Text = 677
        dtpFecha.Text = cfun.HoyMySQL
        celdaDate.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        celdaCliente.Clear()
        celdaIdCliente.Clear()
        celdaNIT.Clear()
        celdaDireccion.Clear()
        celdaMoneda.Clear()
        celdaIdMoneda.Text = INT_LOC
        celdaTasa.Clear()
        celdaUsuario.Clear()

        celdaTotalCantidad.Clear()

        dgFactura.Rows.Clear()
        'DgDetalle.Rows.Clear()

    End Sub

    Private Sub SeleccionarCliente(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim HDR As New clsDcmtos_HDR
        Dim CA As New clsCatalogos
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCampos = " HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Tel, HDoc_Emp_NIT, HDoc_Doc_Tc, HDoc_Doc_Status, HDoc_RF1_Txt, HDoc_DR2_Emp, HDoc_RF2_Cod,HDoc_Usuario, HDoc_Doc_Mon, Hdoc_DR1_Cat, HDoc_RF1_Num, HDoc_RF2_Num, HDoc_RF2_Txt, HDoc_DR1_Emp, HDoc_RF1_Cod"
        strCondicion = " HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 677 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", intaño)
        strCondicion = Replace(strCondicion, "{numero}", intnumero)

        Try
            HDR.CONEXION = strConexion
            If HDR.Seleccionar(strCondicion, strCampos) Then
                celdaAnio.Text = HDR.HDOC_DOC_ANO
                celdaNumero.Text = HDR.HDOC_DOC_NUM
                celdaDate.Text = HDR.HDOC_DOC_FEC
                celdaIDCliente.Text = HDR.HDOC_EMP_COD
                celdaCliente.Text = HDR.HDOC_EMP_NOM
                celdaDireccion.Text = HDR.HDOC_EMP_DIR
                celdaNIT.Text = HDR.HDOC_EMP_NIT
                celdaTasa.Text = HDR.HDOC_DOC_TC
                celdaEmpresa.Text = Sesion.IdEmpresa
                celdaCatalogo.Text = 677
                celdaUsuario.Text = HDR.HDOC_USUARIO

                If CA.Seleccionar(" cat_num = " & HDR.HDOC_DOC_MON, "cat_clave") Then
                    celdaMoneda.Text = CA.CAT_CLAVE
                    celdaIDMoneda.Text = HDR.HDOC_DOC_MON
                Else
                    MsgBox(CA.MERROR.ToString)
                End If

                If HDR.HDOC_DOC_STATUS = 1 Then
                    checkActivo.Checked = True
                    checkActivo.Enabled = True
                Else
                    checkActivo.Checked = False
                    checkActivo.Enabled = False
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Function GuardarDocumento() As Boolean
        Dim strSQL As String
        Dim intNumero As Integer
        Dim logResultado As Boolean = True
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAnio.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)

            chdr.HDOC_DR1_DBL = intNumero

            chdr.HDOC_EMP_COD = celdaIdCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNIT.Text

            chdr.HDOC_DOC_MON = celdaIdMoneda.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text

            chdr.HDOC_USUARIO = celdaUsuario.Text
            chdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, vbEmpty)


            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDocumentoDetalle() As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim logResultado As Boolean = True
        clsDTL.CONEXION = strConexion
        Dim j As Integer = 0
        Try
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = celdaEmpresa.Text
                clsDTL.DDOC_DOC_CAT = celdaCatalogo.Text
                clsDTL.DDOC_DOC_ANO = celdaAnio.Text
                clsDTL.DDOC_DOC_NUM = celdaNumero.Text

                If dgFactura.Rows(i).Cells("colXtra").Value = 1 Then
                    j = i + 1
                    clsDTL.DDOC_DOC_LIN = j
                Else
                    clsDTL.DDOC_DOC_LIN = dgFactura.Rows(i).Cells("colLineaCuenta").Value
                End If

                clsDTL.DDOC_PRD_COD = dgFactura.Rows(i).Cells("colNumeroF").Value
                clsDTL.DDoc_RF1_Fec_NET = dgFactura.Rows(i).Cells("colFechaF").Value
                clsDTL.DDOC_RF1_COD = dgFactura.Rows(i).Cells("colReferenciaF").Value

                clsDTL.DDOC_RF1_NUM = dgFactura.Rows(i).Cells("colAnioF").Value    'Anio Factura
                clsDTL.DDOC_RF2_NUM = dgFactura.Rows(i).Cells("colCatalogoF").Value    'Catalogo Fcatura
                clsDTL.DDOC_PRD_QTY = dgFactura.Rows(i).Cells("colTotal").Value  'Total

                clsDTL.DDOC_PRD_DSQ = dgFactura.Rows(i).Cells("colSaldo").Value    'Saldo
                clsDTL.DDOC_RF2_COD = dgFactura.Rows(i).Cells("colCuentaIncobrable").Value    'Cuenta Incobrable
                clsDTL.DDOC_RF1_TXT = dgFactura.Rows(i).Cells("colOrden").Value     'Orden


                If dgFactura.Rows(i).Cells("colXtra").Value = 0 And Me.Tag = "Mod" Then
                    If clsDTL.Actualizar() = False Then
                        MsgBox(clsDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgFactura.Rows(i).Cells("colXtra").Value = 1 Then
                    If clsDTL.Guardar() = False Then
                        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Query para guardar Descargos
    Private Sub GuargarDescargos()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim j As Integer = 0


        Try
            For i As Integer = 0 To dgFactura.Rows.Count - 1

                MyCnn.CONECTAR = strConexion

                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 296
                clsDTLPro.PDOC_PAR_ANO = dgFactura.Rows(i).Cells("colAnioF").Value
                clsDTLPro.PDOC_PAR_NUM = dgFactura.Rows(i).Cells("colNumeroF").Value
                clsDTLPro.PDOC_PAR_LIN = dgFactura.Rows(i).Cells("colLineaF").Value
                clsDTLPro.PDOC_CHI_CAT = 677
                clsDTLPro.PDOC_CHI_ANO = Val(celdaAnio.Text)
                clsDTLPro.PDOC_CHI_NUM = Val(celdaNumero.Text)

                If dgFactura.Rows(i).Cells("colXtra").Value = 1 Then
                    j = i + 1
                    clsDTLPro.PDOC_CHI_LIN = j
                Else
                    clsDTLPro.PDOC_CHI_LIN = dgFactura.Rows(i).Cells("colLineaCuenta").Value
                End If





                clsDTLPro.PDOC_PROV_COD = Val(celdaIdCliente.Text)
                clsDTLPro.PDOC_PRD_COD = dgFactura.Rows(i).Cells("colOrden").Value
                clsDTLPro.PDOC_PRD_NET = dgFactura.Rows(i).Cells("colTotal").Value
                clsDTLPro.PDOC_QTY_ORD = dgFactura.Rows(i).Cells("colSaldo").Value
                clsDTLPro.PDOC_QTY_PRO = dgFactura.Rows(i).Cells("colCuentaIncobrable").Value

                If dgFactura.Rows(i).Cells("colXtra").Value = 0 Then
                    If clsDTLPro.Actualizar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If

                ElseIf dgFactura.Rows(i).Cells("colXtra").Value = 1 Then
                    If clsDTLPro.Guardar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        'Revisar que los datos de la cabecera no estén en blanco.

        If celdaEmpresa.Text = vbNullString Or
            celdaCatalogo.Text = vbNullString Or
            celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete Data System", vbCritical)
            'Exit Function
            comprobar = False
        End If

        If celdaAnio.Text = NO_FILA Or
            celdaIdCliente.Text = NO_FILA Or
            celdaCliente.Text = STR_VACIO Or
            celdaNIT.Text = STR_VACIO Or
            celdaIdMoneda.Text = NO_FILA Or
            celdaTasa.Text = NO_FILA Then
            MsgBox("You must enter all minium data", vbCritical)
            'Exit Function
            comprobar = False
        End If

        Return comprobar
    End Function

    Private Function ComprobarFilaDetalle() As Boolean
        ComprobarFilaDetalle = True
        Dim i As Integer = 0
        Dim Comprobacion As Boolean = True
        Dim strSQL As String = STR_VACIO

        If dgFactura.Rows.Count > 0 Then
            For i = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colXtra").Value = 1 Or dgFactura.Rows(i).Cells("colXtra").Value = 0 Then
                    If dgFactura.Rows(i).Cells("colCuentaIncobrable").Value = vbNullString Then
                        MsgBox("Specify the amount of the correct bad account", vbExclamation, "Notice")
                        Comprobacion = False
                        'Exit Function
                    End If
                    If Val(dgFactura.Rows(i).Cells("colSaldo").Value) < Val(dgFactura.Rows(i).Cells("colCuentaIncobrable").Value) Then
                        MsgBox("You can not add an uncollectible account greater than your balance", vbExclamation, "Notice")
                        Comprobacion = False
                        dgFactura.Rows(i).Cells("colCuentaIncobrable").Value = vbNullString
                        'Exit Function
                    End If
                End If
            Next
        Else
            MsgBox("It is not possible to save this uncollectible account because it has not added a detail", vbExclamation, "Notice")
            Comprobacion = False
        End If
        ComprobarFilaDetalle = Comprobacion
        Return Comprobacion
    End Function


    Private Sub EliminarLineasDetalle()
        Me.Tag = "Mod"
        Dim i As Integer = 0
        Try
            For i = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colXtra").Value = 2 Then

                    Dim Dtl As New clsDcmtos_DTL
                    Dim COM As MySqlCommand
                    Dim conec As MySqlConnection
                    Dim strSQL As String = STR_VACIO
                    Dim Orden As Double
                    Dim j As Integer = 0

                    Dtl.CONEXION = strConexion

                    'If dgFactura.Rows(i).Visible = False Then
                    Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                    Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                    Dtl.DDOC_DOC_ANO = celdaAnio.Text
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    Dtl.DDOC_DOC_LIN = dgFactura.Rows(i).Cells("colLineaCuenta").Value


                    Dtl.DDOC_PRD_COD = dgFactura.Rows(i).Cells("colNumeroF").Value
                    Dtl.DDoc_RF1_Fec_NET = dgFactura.Rows(i).Cells("colFechaF").Value
                    Dtl.DDOC_RF1_COD = dgFactura.Rows(i).Cells("colReferenciaF").Value

                    Dtl.DDOC_RF1_NUM = dgFactura.Rows(i).Cells("colAnioF").Value    'Anio Factura
                    Dtl.DDOC_RF2_NUM = dgFactura.Rows(i).Cells("colCatalogoF").Value    'Catalogo Fcatura
                    Dtl.DDOC_PRD_QTY = dgFactura.Rows(i).Cells("colTotal").Value  'Total

                    Dtl.DDOC_PRD_DSQ = dgFactura.Rows(i).Cells("colSaldo").Value    'Saldo
                    Dtl.DDOC_RF2_COD = dgFactura.Rows(i).Cells("colCuentaIncobrable").Value    'Cuenta Incobrable
                    Dtl.DDOC_RF1_TXT = dgFactura.Rows(i).Cells("colOrden").Value     'Orden


                    If dgFactura.Rows(i).Cells("colXtra").Value = 2 Then
                        If Dtl.Borrar = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                        End If
                    End If

                    'dgDetalle.Rows.Remove(dgDetalle.Rows(i))
                End If
                'End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarOperacion()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            'Ejecuta la transacción (borrado)
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {catalogo} AND ECta_Doc_Ano = {año} AND ECta_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
            strSQL = Replace(strSQL, "{año}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Try
            strSQL = "INSERT INTO ECtaCte"
            strSQL &= "  SELECT p.PDoc_Sis_Emp, Pdoc_Chi_Cat, Pdoc_Chi_Ano, Pdoc_Chi_Num, 1, 'Clientes', Pdoc_Prov_Cod,0,0, (p.PDoc_QTY_Pro * h.HDoc_Doc_TC), 0, 0, sum(p.PDoc_QTY_Pro), "
            strSQL &= "     CONCAT('Cuenta Incobrable No.', h.HDoc_Doc_Num), h.HDoc_Doc_Fec, h.HDoc_Doc_Fec, h.HDoc_Doc_Mon, h.HDoc_Doc_TC, 0, Pdoc_Par_Cat, Pdoc_Par_Ano, Pdoc_Par_Num"
            strSQL &= "         FROM Dcmtos_DTL_Pro p"
            strSQL &= "               LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND h.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND h.HDoc_Doc_Num = p.PDoc_Chi_Num"
            strSQL &= "          WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 677 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {numero}"
            strSQL &= "      GROUP BY p.PDoc_Par_Cat, p.PDoc_Par_Ano,p.PDoc_Par_Num"

            If Sesion.IdEmpresa = 18 Then
                strSQL &= ";INSERT INTO PDM.ECtaCte"
                strSQL &= "  SELECT p.PDoc_Sis_Emp, Pdoc_Chi_Cat, Pdoc_Chi_Ano, Pdoc_Chi_Num, 1, 'Clientes', Pdoc_Prov_Cod,0,0, (p.PDoc_QTY_Pro * h.HDoc_Doc_TC), 0, 0, sum(p.PDoc_QTY_Pro), "
                strSQL &= "     CONCAT('Cuenta Incobrable No.', h.HDoc_Doc_Num), h.HDoc_Doc_Fec, h.HDoc_Doc_Fec, h.HDoc_Doc_Mon, h.HDoc_Doc_TC, 0, Pdoc_Par_Cat, Pdoc_Par_Ano, Pdoc_Par_Num"
                strSQL &= "         FROM Dcmtos_DTL_Pro p"
                strSQL &= "               LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND h.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND h.HDoc_Doc_Num = p.PDoc_Chi_Num"
                strSQL &= "          WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 677 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {numero}"
                strSQL &= "      GROUP BY p.PDoc_Par_Cat, p.PDoc_Par_Ano,p.PDoc_Par_Num"
            End If

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region

#Region "Eventos"

    Private Sub frmCuentasIncobrables_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        LimpiarCampos()

        MostrarLista(False)
        celdaEmpresa.Text = Sesion.IdEmpresa
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaCatalogo.Text = 677
        celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
        celdaUsuario.Text = Sesion.Usuario

    End Sub


    Private Sub frmCuentasIncobrables_Load(sender As Object, e As EventArgs) Handles Me.Load
        MostrarLista()

    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar
        Dim condicion As String = STR_VACIO
        condicion = " cli_sisemp = {empresa}"
        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
        Try

            frm.Titulo = "Customers"
            frm.Campos = " cli_codigo IdCliente, cli_cliente Cliente, cli_direccion Direccion, cli_nit NIT, cli_moneda IdMoneda, cat_clave Simbolo, cat_sist TC "
            frm.Tabla = " Clientes LEFT JOIN Catalogos On cat_num = cli_moneda "
            frm.FiltroText = "Enter the Name Of the Client To Filter"
            frm.Filtro = "cli_cliente"
            frm.Condicion = condicion
            frm.Ordenamiento = "cli_cliente"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente.Text = frm.ListaClientes.SelectedCells(0).Value
                celdaCliente.Text = frm.ListaClientes.SelectedCells(1).Value
                celdaDireccion.Text = frm.ListaClientes.SelectedCells(2).Value
                celdaNIT.Text = frm.ListaClientes.SelectedCells(3).Value
                celdaIdMoneda.Text = frm.ListaClientes.SelectedCells(4).Value
                celdaMoneda.Text = frm.ListaClientes.SelectedCells(5).Value
                celdaTasa.Text = frm.ListaClientes.SelectedCells(6).Value
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        ElseIf panelDetalle.Visible = True Then
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "Nuevo" Then
            If ComprobarCampos() Then
                If ComprobarFilaDetalle() = True Then
                    celdaNumero.Text = cFunciones.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 677, celdaAnio.Text)
                    If (celdaNumero.Text > 0) Then
                        GuardarDocumento()
                        GuardarDocumentoDetalle()
                        GuargarDescargos()
                        GuardarOperacion()

                        cfun.EscribirRegistro("TBL_DOCUMENTOS", clsFunciones.AccEnum.acAdd, 677, celdaAnio.Text, celdaNumero.Text)

                        MsgBox("The document has been saved", vbInformation)


                        MostrarLista()
                    End If
                End If
            End If
        ElseIf Me.Tag = "Mod" Then
            EliminarLineasDetalle()
            If ComprobarCampos() Then
                If ComprobarFilaDetalle() = True Then
                    GuardarDocumento()
                    GuardarDocumentoDetalle()
                    GuargarDescargos()
                    GuardarOperacion()

                    cfun.EscribirRegistro("TBL_DOCUMENTOS", clsFunciones.AccEnum.acUpdate, 677, celdaAnio.Text, celdaNumero.Text)

                    MsgBox("The document has been modified", vbInformation)

                    MostrarLista()
                End If
            End If
        Else
            MsgBox("It was not possible to classify the operation to save", vbExclamation, "Notice")
            Exit Sub
        End If
    End Sub

    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click

        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        strRemplazo = " h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Emp_Cod = {codigo}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        strRemplazo = Replace(strRemplazo, "{codigo}", celdaIdCliente.Text)

        Try
            frm.Titulo = "Bills"
            frm.Campos = " hh.HDoc_Doc_Num Orden, h.HDoc_Sis_Emp Empresa, h.HDoc_Doc_Num Factura, h.HDoc_Doc_Fec Fecha, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Cat Catalgo, h.HDoc_DR1_Num Referencia, p.PDoc_Chi_Lin LineaF, h.HDoc_RF1_Dbl total, (IFNULL(( SELECT SUM(c.ECta_Crgo_Loc) - SUM(c.ECta_Abno_Loc) FROM ECtaCte c WHERE c.ECta_Sis_Emp = h.HDoc_Sis_Emp AND c.ECta_Ref_Cat = h.HDoc_Doc_Cat AND c.ECta_Ref_Ano = h.HDoc_Doc_Ano AND c.ECta_Ref_Num = h.HDoc_Doc_Num),h.HDoc_RF1_Dbl))saldo "
            frm.Tabla = " Dcmtos_HDR h INNER JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp =h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Num = h.HDoc_Doc_Num  AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  "
            frm.FiltroText = " Enter the Bills To filter"
            frm.Filtro = " h.HDoc_Doc_Num "
            frm.Condicion2 = " saldo > 0"
            frm.Ordenamiento = " h.HDoc_Doc_Num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strFila = frm.ListaClientes.SelectedCells(1).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(6).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(4).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(7).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(8).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(9).Value & "|"
                strFila &= "" & "|"
                strFila &= frm.ListaClientes.SelectedCells(0).Value & "|"
                strFila &= 0 & "|"
                strFila &= 1

                cFunciones.AgregarFila(dgFactura, strFila)

                'QueryDetalle(frm.ListaClientes.SelectedCells(1).Value, frm.ListaClientes.SelectedCells(4).Value)
            End If
            'QueryDatosFactura(frm.LLave, frm.Dato3)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFactura_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgFactura.CellEndEdit
        CalcularTotales()
    End Sub

    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click

        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer

            If dgFactura.SelectedRows Is Nothing Then Exit Sub

            If dgFactura.Rows.Count > 1 Then
                Count = dgFactura.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & Val(dgFactura.SelectedCells(6).Value) & " Of the Invoice " & Val(dgFactura.SelectedCells(1).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then

                        If dgFactura.SelectedCells(12).Value = 0 Or dgFactura.SelectedCells(12).Value = 1 Then
                            dgFactura.SelectedCells(12).Value = 2
                            If dgFactura.SelectedCells(12).Value = 2 Then
                                dgFactura.CurrentRow.Visible = False
                            End If
                        End If

                    End If
                Next
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        LimpiarCampos()
        Dim año As Integer = 0
        Dim numero As Integer = 0
        Dim Linea As Integer = 0

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            'captura el año,numero del panelprincipal dglista
            año = dgLista.SelectedCells(4).Value
            numero = dgLista.SelectedCells(0).Value
            SeleccionarCliente(año, numero)
            MostrarLista(0)
            queryDetalle(numero, año)
            'queryDocProcesados()
            'CargarDescargos()
            CalcularTotales()
            'CargarDescargos()
            celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            botonMas.Enabled = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        queryListaPrincipal()
    End Sub

#End Region

    Private Sub botonClienteE_Click(sender As Object, e As EventArgs) Handles botonClienteE.Click

    End Sub
End Class