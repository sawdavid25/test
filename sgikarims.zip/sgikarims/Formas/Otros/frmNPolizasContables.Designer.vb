﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNPolizasContables
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNPolizasContables))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelIconosDetalle = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.gbDatosPoliza = New System.Windows.Forms.GroupBox()
        Me.celdaFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaIDTPoliza = New System.Windows.Forms.TextBox()
        Me.botonTPoliza = New System.Windows.Forms.Button()
        Me.etiqFecha = New System.Windows.Forms.Label()
        Me.celdaCampo7 = New System.Windows.Forms.TextBox()
        Me.celdaCampo6 = New System.Windows.Forms.TextBox()
        Me.celdaCampo5 = New System.Windows.Forms.TextBox()
        Me.celdaCampo4 = New System.Windows.Forms.TextBox()
        Me.celdaCampo3 = New System.Windows.Forms.TextBox()
        Me.celdaCampo1 = New System.Windows.Forms.TextBox()
        Me.etiquetaEjer = New System.Windows.Forms.Label()
        Me.etiqUser = New System.Windows.Forms.Label()
        Me.botonSRevisar = New System.Windows.Forms.Button()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.etiquetaObservaciones = New System.Windows.Forms.Label()
        Me.celdaConcepto = New System.Windows.Forms.TextBox()
        Me.celdaTPoliza = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaOperator = New System.Windows.Forms.TextBox()
        Me.celdaEmp = New System.Windows.Forms.TextBox()
        Me.celdaPoliza = New System.Windows.Forms.TextBox()
        Me.etiquetaUFRevision = New System.Windows.Forms.Label()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.etiquetaTipoPoliza = New System.Windows.Forms.Label()
        Me.etiquetFecha = New System.Windows.Forms.Label()
        Me.celdaTipoCambio = New System.Windows.Forms.Label()
        Me.EtiquetaEmpresa = New System.Windows.Forms.Label()
        Me.EtiquetaOperador = New System.Windows.Forms.Label()
        Me.EtiquetaConcepto = New System.Windows.Forms.Label()
        Me.EtiquetaNPoliza = New System.Windows.Forms.Label()
        Me.botonComprobar = New System.Windows.Forms.Button()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.panelSaldos = New System.Windows.Forms.Panel()
        Me.celdaHaber = New System.Windows.Forms.TextBox()
        Me.etiquetaDebito = New System.Windows.Forms.Label()
        Me.celdaDebito = New System.Windows.Forms.TextBox()
        Me.etiquetaHaber = New System.Windows.Forms.Label()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelListPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colModo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelCheck = New System.Windows.Forms.Panel()
        Me.panelListaEncab = New System.Windows.Forms.Panel()
        Me.botonTipo = New System.Windows.Forms.Button()
        Me.celdaIDTipo = New System.Windows.Forms.TextBox()
        Me.celdaIDEjercicio = New System.Windows.Forms.TextBox()
        Me.botonEjercicio = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.etiquetaTipo = New System.Windows.Forms.Label()
        Me.etiquetaY = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.celdaEjercicio = New System.Windows.Forms.TextBox()
        Me.etiquetaEjercicio = New System.Windows.Forms.Label()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colNum = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDebe = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHaber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCostos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPresupuestal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTransaccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelIconosDetalle.SuspendLayout()
        Me.gbDatosPoliza.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        Me.panelSaldos.SuspendLayout()
        Me.panelLista.SuspendLayout()
        Me.panelListPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelCheck.SuspendLayout()
        Me.panelListaEncab.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelDetalle
        '
        Me.panelDetalle.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelIconosDetalle)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 238)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1011, 271)
        Me.panelDetalle.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.dgDetalle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNum, Me.colCuenta, Me.colNombre, Me.colDebe, Me.colHaber, Me.colIDCosto, Me.colCostos, Me.colPresupuestal, Me.colExtra, Me.colRef_id, Me.colTransaccion})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(912, 271)
        Me.dgDetalle.TabIndex = 0
        '
        'panelIconosDetalle
        '
        Me.panelIconosDetalle.BackColor = System.Drawing.SystemColors.Control
        Me.panelIconosDetalle.Controls.Add(Me.botonAgregar)
        Me.panelIconosDetalle.Controls.Add(Me.botonQuitar)
        Me.panelIconosDetalle.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelIconosDetalle.Location = New System.Drawing.Point(912, 0)
        Me.panelIconosDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelIconosDetalle.Name = "panelIconosDetalle"
        Me.panelIconosDetalle.Size = New System.Drawing.Size(99, 271)
        Me.panelIconosDetalle.TabIndex = 6
        '
        'botonAgregar
        '
        Me.botonAgregar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(28, 52)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(56, 38)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(28, 114)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(56, 37)
        Me.botonQuitar.TabIndex = 3
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'gbDatosPoliza
        '
        Me.gbDatosPoliza.Controls.Add(Me.celdaFecha)
        Me.gbDatosPoliza.Controls.Add(Me.celdaIDTPoliza)
        Me.gbDatosPoliza.Controls.Add(Me.botonTPoliza)
        Me.gbDatosPoliza.Controls.Add(Me.etiqFecha)
        Me.gbDatosPoliza.Controls.Add(Me.celdaCampo7)
        Me.gbDatosPoliza.Controls.Add(Me.celdaCampo6)
        Me.gbDatosPoliza.Controls.Add(Me.celdaCampo5)
        Me.gbDatosPoliza.Controls.Add(Me.celdaCampo4)
        Me.gbDatosPoliza.Controls.Add(Me.celdaCampo3)
        Me.gbDatosPoliza.Controls.Add(Me.celdaCampo1)
        Me.gbDatosPoliza.Controls.Add(Me.etiquetaEjer)
        Me.gbDatosPoliza.Controls.Add(Me.etiqUser)
        Me.gbDatosPoliza.Controls.Add(Me.botonSRevisar)
        Me.gbDatosPoliza.Controls.Add(Me.celdaObservaciones)
        Me.gbDatosPoliza.Controls.Add(Me.etiquetaObservaciones)
        Me.gbDatosPoliza.Controls.Add(Me.celdaConcepto)
        Me.gbDatosPoliza.Controls.Add(Me.celdaTPoliza)
        Me.gbDatosPoliza.Controls.Add(Me.celdaTasa)
        Me.gbDatosPoliza.Controls.Add(Me.celdaOperator)
        Me.gbDatosPoliza.Controls.Add(Me.celdaEmp)
        Me.gbDatosPoliza.Controls.Add(Me.celdaPoliza)
        Me.gbDatosPoliza.Controls.Add(Me.etiquetaUFRevision)
        Me.gbDatosPoliza.Controls.Add(Me.etiquetaUsuario)
        Me.gbDatosPoliza.Controls.Add(Me.etiquetaTipoPoliza)
        Me.gbDatosPoliza.Controls.Add(Me.etiquetFecha)
        Me.gbDatosPoliza.Controls.Add(Me.celdaTipoCambio)
        Me.gbDatosPoliza.Controls.Add(Me.EtiquetaEmpresa)
        Me.gbDatosPoliza.Controls.Add(Me.EtiquetaOperador)
        Me.gbDatosPoliza.Controls.Add(Me.EtiquetaConcepto)
        Me.gbDatosPoliza.Controls.Add(Me.EtiquetaNPoliza)
        Me.gbDatosPoliza.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbDatosPoliza.Location = New System.Drawing.Point(0, 0)
        Me.gbDatosPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbDatosPoliza.Name = "gbDatosPoliza"
        Me.gbDatosPoliza.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbDatosPoliza.Size = New System.Drawing.Size(1011, 238)
        Me.gbDatosPoliza.TabIndex = 3
        Me.gbDatosPoliza.TabStop = False
        Me.gbDatosPoliza.Text = "Data Policy"
        '
        'celdaFecha
        '
        Me.celdaFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.celdaFecha.Location = New System.Drawing.Point(452, 83)
        Me.celdaFecha.Name = "celdaFecha"
        Me.celdaFecha.Size = New System.Drawing.Size(108, 22)
        Me.celdaFecha.TabIndex = 31
        '
        'celdaIDTPoliza
        '
        Me.celdaIDTPoliza.Location = New System.Drawing.Point(656, 126)
        Me.celdaIDTPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIDTPoliza.Name = "celdaIDTPoliza"
        Me.celdaIDTPoliza.Size = New System.Drawing.Size(70, 22)
        Me.celdaIDTPoliza.TabIndex = 30
        Me.celdaIDTPoliza.Text = "-1"
        Me.celdaIDTPoliza.Visible = False
        '
        'botonTPoliza
        '
        Me.botonTPoliza.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonTPoliza.Location = New System.Drawing.Point(617, 126)
        Me.botonTPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonTPoliza.Name = "botonTPoliza"
        Me.botonTPoliza.Size = New System.Drawing.Size(35, 22)
        Me.botonTPoliza.TabIndex = 29
        Me.botonTPoliza.Text = "..."
        Me.botonTPoliza.UseVisualStyleBackColor = True
        '
        'etiqFecha
        '
        Me.etiqFecha.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiqFecha.AutoSize = True
        Me.etiqFecha.Location = New System.Drawing.Point(905, 38)
        Me.etiqFecha.Name = "etiqFecha"
        Me.etiqFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiqFecha.TabIndex = 28
        Me.etiqFecha.Text = "Date"
        '
        'celdaCampo7
        '
        Me.celdaCampo7.Location = New System.Drawing.Point(912, 143)
        Me.celdaCampo7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCampo7.Name = "celdaCampo7"
        Me.celdaCampo7.Size = New System.Drawing.Size(24, 22)
        Me.celdaCampo7.TabIndex = 27
        Me.celdaCampo7.Text = "07"
        Me.celdaCampo7.Visible = False
        '
        'celdaCampo6
        '
        Me.celdaCampo6.Location = New System.Drawing.Point(883, 142)
        Me.celdaCampo6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCampo6.Name = "celdaCampo6"
        Me.celdaCampo6.Size = New System.Drawing.Size(24, 22)
        Me.celdaCampo6.TabIndex = 26
        Me.celdaCampo6.Text = "06"
        Me.celdaCampo6.Visible = False
        '
        'celdaCampo5
        '
        Me.celdaCampo5.Location = New System.Drawing.Point(852, 142)
        Me.celdaCampo5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCampo5.Name = "celdaCampo5"
        Me.celdaCampo5.Size = New System.Drawing.Size(24, 22)
        Me.celdaCampo5.TabIndex = 25
        Me.celdaCampo5.Text = "05"
        Me.celdaCampo5.Visible = False
        '
        'celdaCampo4
        '
        Me.celdaCampo4.Location = New System.Drawing.Point(821, 142)
        Me.celdaCampo4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCampo4.Name = "celdaCampo4"
        Me.celdaCampo4.Size = New System.Drawing.Size(24, 22)
        Me.celdaCampo4.TabIndex = 24
        Me.celdaCampo4.Text = "04"
        Me.celdaCampo4.Visible = False
        '
        'celdaCampo3
        '
        Me.celdaCampo3.Location = New System.Drawing.Point(791, 142)
        Me.celdaCampo3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCampo3.Name = "celdaCampo3"
        Me.celdaCampo3.Size = New System.Drawing.Size(24, 22)
        Me.celdaCampo3.TabIndex = 23
        Me.celdaCampo3.Text = "03"
        Me.celdaCampo3.Visible = False
        '
        'celdaCampo1
        '
        Me.celdaCampo1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaCampo1.Location = New System.Drawing.Point(713, 41)
        Me.celdaCampo1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCampo1.Name = "celdaCampo1"
        Me.celdaCampo1.ReadOnly = True
        Me.celdaCampo1.Size = New System.Drawing.Size(37, 15)
        Me.celdaCampo1.TabIndex = 22
        Me.celdaCampo1.Text = "01"
        Me.celdaCampo1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaCampo1.Visible = False
        '
        'etiquetaEjer
        '
        Me.etiquetaEjer.AutoSize = True
        Me.etiquetaEjer.Location = New System.Drawing.Point(584, 41)
        Me.etiquetaEjer.Name = "etiquetaEjer"
        Me.etiquetaEjer.Size = New System.Drawing.Size(123, 17)
        Me.etiquetaEjer.TabIndex = 21
        Me.etiquetaEjer.Text = "Ejercicio En Curso"
        Me.etiquetaEjer.Visible = False
        '
        'etiqUser
        '
        Me.etiqUser.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiqUser.AutoSize = True
        Me.etiqUser.Location = New System.Drawing.Point(828, 64)
        Me.etiqUser.Name = "etiqUser"
        Me.etiqUser.Size = New System.Drawing.Size(38, 17)
        Me.etiqUser.TabIndex = 20
        Me.etiqUser.Text = "User"
        '
        'botonSRevisar
        '
        Me.botonSRevisar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSRevisar.BackColor = System.Drawing.Color.Orange
        Me.botonSRevisar.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonSRevisar.Location = New System.Drawing.Point(843, 92)
        Me.botonSRevisar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonSRevisar.Name = "botonSRevisar"
        Me.botonSRevisar.Size = New System.Drawing.Size(125, 46)
        Me.botonSRevisar.TabIndex = 18
        Me.botonSRevisar.Text = "Without Reviewed"
        Me.botonSRevisar.UseVisualStyleBackColor = False
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservaciones.Location = New System.Drawing.Point(683, 170)
        Me.celdaObservaciones.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(325, 52)
        Me.celdaObservaciones.TabIndex = 17
        '
        'etiquetaObservaciones
        '
        Me.etiquetaObservaciones.AutoSize = True
        Me.etiquetaObservaciones.Location = New System.Drawing.Point(679, 149)
        Me.etiquetaObservaciones.Name = "etiquetaObservaciones"
        Me.etiquetaObservaciones.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaObservaciones.TabIndex = 16
        Me.etiquetaObservaciones.Text = "Observations"
        '
        'celdaConcepto
        '
        Me.celdaConcepto.Location = New System.Drawing.Point(103, 170)
        Me.celdaConcepto.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaConcepto.Multiline = True
        Me.celdaConcepto.Name = "celdaConcepto"
        Me.celdaConcepto.Size = New System.Drawing.Size(548, 52)
        Me.celdaConcepto.TabIndex = 15
        Me.celdaConcepto.Text = "04"
        '
        'celdaTPoliza
        '
        Me.celdaTPoliza.Location = New System.Drawing.Point(452, 126)
        Me.celdaTPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTPoliza.Name = "celdaTPoliza"
        Me.celdaTPoliza.ReadOnly = True
        Me.celdaTPoliza.Size = New System.Drawing.Size(159, 22)
        Me.celdaTPoliza.TabIndex = 14
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(452, 38)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(127, 22)
        Me.celdaTasa.TabIndex = 12
        Me.celdaTasa.Text = "05"
        '
        'celdaOperator
        '
        Me.celdaOperator.Location = New System.Drawing.Point(103, 128)
        Me.celdaOperator.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaOperator.Name = "celdaOperator"
        Me.celdaOperator.ReadOnly = True
        Me.celdaOperator.Size = New System.Drawing.Size(219, 22)
        Me.celdaOperator.TabIndex = 11
        Me.celdaOperator.Text = "03"
        '
        'celdaEmp
        '
        Me.celdaEmp.Location = New System.Drawing.Point(105, 87)
        Me.celdaEmp.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaEmp.Name = "celdaEmp"
        Me.celdaEmp.ReadOnly = True
        Me.celdaEmp.Size = New System.Drawing.Size(219, 22)
        Me.celdaEmp.TabIndex = 10
        Me.celdaEmp.Text = "02"
        '
        'celdaPoliza
        '
        Me.celdaPoliza.Location = New System.Drawing.Point(109, 38)
        Me.celdaPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPoliza.Name = "celdaPoliza"
        Me.celdaPoliza.ReadOnly = True
        Me.celdaPoliza.Size = New System.Drawing.Size(121, 22)
        Me.celdaPoliza.TabIndex = 9
        Me.celdaPoliza.Text = "00"
        '
        'etiquetaUFRevision
        '
        Me.etiquetaUFRevision.AutoSize = True
        Me.etiquetaUFRevision.Location = New System.Drawing.Point(781, 38)
        Me.etiquetaUFRevision.Name = "etiquetaUFRevision"
        Me.etiquetaUFRevision.Size = New System.Drawing.Size(122, 17)
        Me.etiquetaUFRevision.TabIndex = 8
        Me.etiquetaUFRevision.Text = "Last Review Date:"
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(784, 64)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(42, 17)
        Me.etiquetaUsuario.TabIndex = 7
        Me.etiquetaUsuario.Text = "User:"
        '
        'etiquetaTipoPoliza
        '
        Me.etiquetaTipoPoliza.AutoSize = True
        Me.etiquetaTipoPoliza.Location = New System.Drawing.Point(341, 130)
        Me.etiquetaTipoPoliza.Name = "etiquetaTipoPoliza"
        Me.etiquetaTipoPoliza.Size = New System.Drawing.Size(81, 17)
        Me.etiquetaTipoPoliza.TabIndex = 6
        Me.etiquetaTipoPoliza.Text = "Policy Type"
        '
        'etiquetFecha
        '
        Me.etiquetFecha.AutoSize = True
        Me.etiquetFecha.Location = New System.Drawing.Point(341, 90)
        Me.etiquetFecha.Name = "etiquetFecha"
        Me.etiquetFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetFecha.TabIndex = 5
        Me.etiquetFecha.Text = "Date"
        '
        'celdaTipoCambio
        '
        Me.celdaTipoCambio.AutoSize = True
        Me.celdaTipoCambio.Location = New System.Drawing.Point(341, 41)
        Me.celdaTipoCambio.Name = "celdaTipoCambio"
        Me.celdaTipoCambio.Size = New System.Drawing.Size(104, 17)
        Me.celdaTipoCambio.TabIndex = 4
        Me.celdaTipoCambio.Text = "Exchange Rate"
        '
        'EtiquetaEmpresa
        '
        Me.EtiquetaEmpresa.AutoSize = True
        Me.EtiquetaEmpresa.Location = New System.Drawing.Point(32, 90)
        Me.EtiquetaEmpresa.Name = "EtiquetaEmpresa"
        Me.EtiquetaEmpresa.Size = New System.Drawing.Size(67, 17)
        Me.EtiquetaEmpresa.TabIndex = 3
        Me.EtiquetaEmpresa.Text = "Company"
        '
        'EtiquetaOperador
        '
        Me.EtiquetaOperador.AutoSize = True
        Me.EtiquetaOperador.Location = New System.Drawing.Point(32, 130)
        Me.EtiquetaOperador.Name = "EtiquetaOperador"
        Me.EtiquetaOperador.Size = New System.Drawing.Size(65, 17)
        Me.EtiquetaOperador.TabIndex = 2
        Me.EtiquetaOperador.Text = "Operator"
        '
        'EtiquetaConcepto
        '
        Me.EtiquetaConcepto.AutoSize = True
        Me.EtiquetaConcepto.Location = New System.Drawing.Point(32, 174)
        Me.EtiquetaConcepto.Name = "EtiquetaConcepto"
        Me.EtiquetaConcepto.Size = New System.Drawing.Size(60, 17)
        Me.EtiquetaConcepto.TabIndex = 1
        Me.EtiquetaConcepto.Text = "Concept"
        '
        'EtiquetaNPoliza
        '
        Me.EtiquetaNPoliza.AutoSize = True
        Me.EtiquetaNPoliza.Location = New System.Drawing.Point(32, 41)
        Me.EtiquetaNPoliza.Name = "EtiquetaNPoliza"
        Me.EtiquetaNPoliza.Size = New System.Drawing.Size(71, 17)
        Me.EtiquetaNPoliza.TabIndex = 0
        Me.EtiquetaNPoliza.Text = "Policy No."
        '
        'botonComprobar
        '
        Me.botonComprobar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonComprobar.Location = New System.Drawing.Point(867, 16)
        Me.botonComprobar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonComprobar.Name = "botonComprobar"
        Me.botonComprobar.Size = New System.Drawing.Size(100, 57)
        Me.botonComprobar.TabIndex = 18
        Me.botonComprobar.Text = "Check..."
        Me.botonComprobar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonComprobar.UseVisualStyleBackColor = True
        Me.botonComprobar.Visible = False
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelDatos)
        Me.panelDocumento.Controls.Add(Me.panelSaldos)
        Me.panelDocumento.Location = New System.Drawing.Point(0, 180)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1011, 580)
        Me.panelDocumento.TabIndex = 4
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.gbDatosPoliza)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1011, 238)
        Me.panelDatos.TabIndex = 5
        '
        'panelSaldos
        '
        Me.panelSaldos.Controls.Add(Me.celdaHaber)
        Me.panelSaldos.Controls.Add(Me.etiquetaDebito)
        Me.panelSaldos.Controls.Add(Me.celdaDebito)
        Me.panelSaldos.Controls.Add(Me.etiquetaHaber)
        Me.panelSaldos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelSaldos.Location = New System.Drawing.Point(0, 509)
        Me.panelSaldos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelSaldos.Name = "panelSaldos"
        Me.panelSaldos.Size = New System.Drawing.Size(1011, 71)
        Me.panelSaldos.TabIndex = 4
        '
        'celdaHaber
        '
        Me.celdaHaber.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaHaber.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaHaber.Location = New System.Drawing.Point(763, 46)
        Me.celdaHaber.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaHaber.Name = "celdaHaber"
        Me.celdaHaber.ReadOnly = True
        Me.celdaHaber.Size = New System.Drawing.Size(160, 22)
        Me.celdaHaber.TabIndex = 20
        Me.celdaHaber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaDebito
        '
        Me.etiquetaDebito.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaDebito.AutoSize = True
        Me.etiquetaDebito.Location = New System.Drawing.Point(707, 14)
        Me.etiquetaDebito.Name = "etiquetaDebito"
        Me.etiquetaDebito.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaDebito.TabIndex = 8
        Me.etiquetaDebito.Text = "Debit"
        '
        'celdaDebito
        '
        Me.celdaDebito.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDebito.BackColor = System.Drawing.SystemColors.Control
        Me.celdaDebito.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDebito.Location = New System.Drawing.Point(763, 10)
        Me.celdaDebito.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaDebito.Name = "celdaDebito"
        Me.celdaDebito.ReadOnly = True
        Me.celdaDebito.Size = New System.Drawing.Size(160, 22)
        Me.celdaDebito.TabIndex = 19
        Me.celdaDebito.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaHaber
        '
        Me.etiquetaHaber.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaHaber.AutoSize = True
        Me.etiquetaHaber.Location = New System.Drawing.Point(707, 48)
        Me.etiquetaHaber.Name = "etiquetaHaber"
        Me.etiquetaHaber.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaHaber.TabIndex = 9
        Me.etiquetaHaber.Text = "Have"
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.panelListPrincipal)
        Me.panelLista.Controls.Add(Me.panelCheck)
        Me.panelLista.Controls.Add(Me.panelListaEncab)
        Me.panelLista.Location = New System.Drawing.Point(12, 114)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1011, 196)
        Me.panelLista.TabIndex = 5
        '
        'panelListPrincipal
        '
        Me.panelListPrincipal.Controls.Add(Me.dgLista)
        Me.panelListPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelListPrincipal.Location = New System.Drawing.Point(0, 62)
        Me.panelListPrincipal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelListPrincipal.Name = "panelListPrincipal"
        Me.panelListPrincipal.Size = New System.Drawing.Size(1011, 56)
        Me.panelListPrincipal.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colTipo, Me.colConcepto, Me.colFecha, Me.colModo, Me.colEstado, Me.colDocumento})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1011, 56)
        Me.dgLista.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "No."
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        '
        'colConcepto
        '
        Me.colConcepto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.Name = "colConcepto"
        Me.colConcepto.ReadOnly = True
        Me.colConcepto.Width = 89
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colModo
        '
        Me.colModo.HeaderText = "Mode"
        Me.colModo.Name = "colModo"
        Me.colModo.ReadOnly = True
        Me.colModo.Visible = False
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "State"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        Me.colDocumento.Visible = False
        '
        'panelCheck
        '
        Me.panelCheck.Controls.Add(Me.botonComprobar)
        Me.panelCheck.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelCheck.Location = New System.Drawing.Point(0, 118)
        Me.panelCheck.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelCheck.Name = "panelCheck"
        Me.panelCheck.Size = New System.Drawing.Size(1011, 78)
        Me.panelCheck.TabIndex = 1
        '
        'panelListaEncab
        '
        Me.panelListaEncab.BackColor = System.Drawing.SystemColors.Info
        Me.panelListaEncab.Controls.Add(Me.botonTipo)
        Me.panelListaEncab.Controls.Add(Me.celdaIDTipo)
        Me.panelListaEncab.Controls.Add(Me.celdaIDEjercicio)
        Me.panelListaEncab.Controls.Add(Me.botonEjercicio)
        Me.panelListaEncab.Controls.Add(Me.botonActualizar)
        Me.panelListaEncab.Controls.Add(Me.celdaTipo)
        Me.panelListaEncab.Controls.Add(Me.etiquetaTipo)
        Me.panelListaEncab.Controls.Add(Me.etiquetaY)
        Me.panelListaEncab.Controls.Add(Me.dtpFin)
        Me.panelListaEncab.Controls.Add(Me.dtpInicio)
        Me.panelListaEncab.Controls.Add(Me.checkFecha)
        Me.panelListaEncab.Controls.Add(Me.celdaEjercicio)
        Me.panelListaEncab.Controls.Add(Me.etiquetaEjercicio)
        Me.panelListaEncab.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaEncab.Location = New System.Drawing.Point(0, 0)
        Me.panelListaEncab.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelListaEncab.Name = "panelListaEncab"
        Me.panelListaEncab.Size = New System.Drawing.Size(1011, 62)
        Me.panelListaEncab.TabIndex = 0
        '
        'botonTipo
        '
        Me.botonTipo.Location = New System.Drawing.Point(885, 23)
        Me.botonTipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonTipo.Name = "botonTipo"
        Me.botonTipo.Size = New System.Drawing.Size(35, 22)
        Me.botonTipo.TabIndex = 22
        Me.botonTipo.Text = "..."
        Me.botonTipo.UseVisualStyleBackColor = True
        '
        'celdaIDTipo
        '
        Me.celdaIDTipo.Location = New System.Drawing.Point(885, 0)
        Me.celdaIDTipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIDTipo.Name = "celdaIDTipo"
        Me.celdaIDTipo.Size = New System.Drawing.Size(23, 22)
        Me.celdaIDTipo.TabIndex = 21
        Me.celdaIDTipo.Text = "-1"
        Me.celdaIDTipo.Visible = False
        '
        'celdaIDEjercicio
        '
        Me.celdaIDEjercicio.Location = New System.Drawing.Point(201, 2)
        Me.celdaIDEjercicio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIDEjercicio.Name = "celdaIDEjercicio"
        Me.celdaIDEjercicio.Size = New System.Drawing.Size(23, 22)
        Me.celdaIDEjercicio.TabIndex = 20
        Me.celdaIDEjercicio.Text = "-1"
        Me.celdaIDEjercicio.Visible = False
        '
        'botonEjercicio
        '
        Me.botonEjercicio.Location = New System.Drawing.Point(201, 22)
        Me.botonEjercicio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonEjercicio.Name = "botonEjercicio"
        Me.botonEjercicio.Size = New System.Drawing.Size(35, 22)
        Me.botonEjercicio.TabIndex = 18
        Me.botonEjercicio.Text = "..."
        Me.botonEjercicio.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(983, 20)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(80, 25)
        Me.botonActualizar.TabIndex = 17
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(692, 21)
        Me.celdaTipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.ReadOnly = True
        Me.celdaTipo.Size = New System.Drawing.Size(188, 22)
        Me.celdaTipo.TabIndex = 16
        '
        'etiquetaTipo
        '
        Me.etiquetaTipo.AutoSize = True
        Me.etiquetaTipo.Location = New System.Drawing.Point(645, 25)
        Me.etiquetaTipo.Name = "etiquetaTipo"
        Me.etiquetaTipo.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTipo.TabIndex = 15
        Me.etiquetaTipo.Text = "Type"
        '
        'etiquetaY
        '
        Me.etiquetaY.AutoSize = True
        Me.etiquetaY.Location = New System.Drawing.Point(488, 25)
        Me.etiquetaY.Name = "etiquetaY"
        Me.etiquetaY.Size = New System.Drawing.Size(33, 17)
        Me.etiquetaY.TabIndex = 14
        Me.etiquetaY.Text = "And"
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(527, 21)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 13
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(369, 20)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(113, 22)
        Me.dtpInicio.TabIndex = 12
        Me.dtpInicio.Value = New Date(2016, 3, 30, 9, 7, 0, 0)
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(267, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(96, 21)
        Me.checkFecha.TabIndex = 11
        Me.checkFecha.Text = "From Date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'celdaEjercicio
        '
        Me.celdaEjercicio.Location = New System.Drawing.Point(73, 22)
        Me.celdaEjercicio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaEjercicio.Name = "celdaEjercicio"
        Me.celdaEjercicio.ReadOnly = True
        Me.celdaEjercicio.Size = New System.Drawing.Size(121, 22)
        Me.celdaEjercicio.TabIndex = 10
        Me.celdaEjercicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaEjercicio
        '
        Me.etiquetaEjercicio.AutoSize = True
        Me.etiquetaEjercicio.Location = New System.Drawing.Point(15, 22)
        Me.etiquetaEjercicio.Name = "etiquetaEjercicio"
        Me.etiquetaEjercicio.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaEjercicio.TabIndex = 1
        Me.etiquetaEjercicio.Text = "Exercice"
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(279, 14)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(79, 53)
        Me.botonImprimir.TabIndex = 23
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 81)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1007, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1007, 81)
        Me.Encabezado1.TabIndex = 0
        '
        'colNum
        '
        Me.colNum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colNum.HeaderText = "No."
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colNum.Width = 36
        '
        'colCuenta
        '
        Me.colCuenta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCuenta.HeaderText = "Account"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.ReadOnly = True
        Me.colCuenta.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCuenta.Width = 65
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colNombre.Width = 51
        '
        'colDebe
        '
        Me.colDebe.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colDebe.DefaultCellStyle = DataGridViewCellStyle1
        Me.colDebe.HeaderText = "Debit"
        Me.colDebe.Name = "colDebe"
        Me.colDebe.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDebe.Width = 47
        '
        'colHaber
        '
        Me.colHaber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colHaber.DefaultCellStyle = DataGridViewCellStyle2
        Me.colHaber.HeaderText = "Have"
        Me.colHaber.Name = "colHaber"
        Me.colHaber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colHaber.Width = 47
        '
        'colIDCosto
        '
        Me.colIDCosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colIDCosto.HeaderText = "IDCost"
        Me.colIDCosto.Name = "colIDCosto"
        Me.colIDCosto.ReadOnly = True
        Me.colIDCosto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colIDCosto.Visible = False
        Me.colIDCosto.Width = 55
        '
        'colCostos
        '
        Me.colCostos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCostos.HeaderText = "C. of Cost"
        Me.colCostos.Name = "colCostos"
        Me.colCostos.ReadOnly = True
        Me.colCostos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCostos.Width = 75
        '
        'colPresupuestal
        '
        Me.colPresupuestal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPresupuestal.HeaderText = "Budget"
        Me.colPresupuestal.Name = "colPresupuestal"
        Me.colPresupuestal.ReadOnly = True
        Me.colPresupuestal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPresupuestal.Width = 59
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExtra.Visible = False
        '
        'colRef_id
        '
        Me.colRef_id.HeaderText = "Ref_id"
        Me.colRef_id.Name = "colRef_id"
        Me.colRef_id.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colRef_id.Visible = False
        '
        'colTransaccion
        '
        Me.colTransaccion.HeaderText = "Transaccion"
        Me.colTransaccion.Name = "colTransaccion"
        Me.colTransaccion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTransaccion.Visible = False
        '
        'frmNPolizasContables
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1007, 750)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.ForeColor = System.Drawing.Color.Black
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmNPolizasContables"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmNPolizasContables"
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelIconosDetalle.ResumeLayout(False)
        Me.gbDatosPoliza.ResumeLayout(False)
        Me.gbDatosPoliza.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDatos.ResumeLayout(False)
        Me.panelSaldos.ResumeLayout(False)
        Me.panelSaldos.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        Me.panelListPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelCheck.ResumeLayout(False)
        Me.panelListaEncab.ResumeLayout(False)
        Me.panelListaEncab.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents gbDatosPoliza As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaUFRevision As System.Windows.Forms.Label
    Friend WithEvents etiquetaUsuario As System.Windows.Forms.Label
    Friend WithEvents etiquetaTipoPoliza As System.Windows.Forms.Label
    Friend WithEvents etiquetFecha As System.Windows.Forms.Label
    Friend WithEvents celdaTipoCambio As System.Windows.Forms.Label
    Friend WithEvents EtiquetaEmpresa As System.Windows.Forms.Label
    Friend WithEvents EtiquetaOperador As System.Windows.Forms.Label
    Friend WithEvents EtiquetaConcepto As System.Windows.Forms.Label
    Friend WithEvents EtiquetaNPoliza As System.Windows.Forms.Label
    Friend WithEvents celdaConcepto As System.Windows.Forms.TextBox
    Friend WithEvents celdaTPoliza As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents celdaOperator As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmp As System.Windows.Forms.TextBox
    Friend WithEvents celdaPoliza As System.Windows.Forms.TextBox
    Friend WithEvents botonSRevisar As System.Windows.Forms.Button
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaObservaciones As System.Windows.Forms.Label
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents celdaHaber As System.Windows.Forms.TextBox
    Friend WithEvents celdaDebito As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaHaber As System.Windows.Forms.Label
    Friend WithEvents etiquetaDebito As System.Windows.Forms.Label
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents botonComprobar As System.Windows.Forms.Button
    Friend WithEvents panelListaEncab As System.Windows.Forms.Panel
    Friend WithEvents botonEjercicio As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents celdaTipo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTipo As System.Windows.Forms.Label
    Friend WithEvents etiquetaY As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents celdaEjercicio As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEjercicio As System.Windows.Forms.Label
    Friend WithEvents panelCheck As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents celdaIDEjercicio As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDTipo As System.Windows.Forms.TextBox
    Friend WithEvents botonTipo As System.Windows.Forms.Button
    Friend WithEvents etiqUser As System.Windows.Forms.Label
    Friend WithEvents panelListPrincipal As System.Windows.Forms.Panel
    Friend WithEvents celdaCampo5 As System.Windows.Forms.TextBox
    Friend WithEvents celdaCampo4 As System.Windows.Forms.TextBox
    Friend WithEvents celdaCampo3 As System.Windows.Forms.TextBox
    Friend WithEvents celdaCampo1 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEjer As System.Windows.Forms.Label
    Friend WithEvents celdaCampo6 As System.Windows.Forms.TextBox
    Friend WithEvents celdaCampo7 As System.Windows.Forms.TextBox
    Friend WithEvents etiqFecha As System.Windows.Forms.Label
    Friend WithEvents botonTPoliza As System.Windows.Forms.Button
    Friend WithEvents celdaIDTPoliza As System.Windows.Forms.TextBox
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents panelIconosDetalle As System.Windows.Forms.Panel
    Friend WithEvents panelDatos As System.Windows.Forms.Panel
    Friend WithEvents panelSaldos As System.Windows.Forms.Panel
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colModo As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents celdaFecha As DateTimePicker
    Friend WithEvents colNum As DataGridViewButtonColumn
    Friend WithEvents colCuenta As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colDebe As DataGridViewTextBoxColumn
    Friend WithEvents colHaber As DataGridViewTextBoxColumn
    Friend WithEvents colIDCosto As DataGridViewTextBoxColumn
    Friend WithEvents colCostos As DataGridViewTextBoxColumn
    Friend WithEvents colPresupuestal As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents colRef_id As DataGridViewTextBoxColumn
    Friend WithEvents colTransaccion As DataGridViewTextBoxColumn
End Class
