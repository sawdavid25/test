﻿Imports KARIMs_SGI.Tablas.TCORREO
Imports Microsoft.Office.Interop.Word

Public Class frmRequisa
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strMensaje As String = STR_VACIO
    Dim codDepartamento As Int32 = 0
    Dim intTipo As Integer
    Dim intAutoriza As Integer
    Dim cfun As New clsFunciones
    Dim DepartamentoArray() As Integer
    Dim MaquinaArray() As Integer

    Public Const catalogos = 734
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Funciones"

    Private Function sqlDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT d.DDoc_Prd_Cod cod,d.DDoc_Prd_Des producto, d.DDoc_Prd_UM UM, c.cat_clave, d.DDoc_Prd_QTY Cantidad, cc.cost_num CodCentroCosto, cc.cost_nombre CentroCosto, 
                            IFNULL(d.DDoc_RF2_Num,0) CodMaquina, IFNULL(d.DDoc_RF3_Txt,'') Departamento, IFNULL(d.DDoc_RF2_Txt,'') DescripcionMaquina, IFNULL(d.DDoc_RF2_Cod,'') Marca, IFNULL(d.DDoc_RF1_Cod,'') Modelo, 
                            IFNULL(d.DDoc_RF1_Txt,'') Serie, IFNULL(d.DDoc_RF4_Num,0) Presupuesto, d.DDoc_Doc_Lin linea, IFNULL(d.DDoc_RF3_Num,0) Approval, IFNULL(d.DDoc_RF3_Dbl,0) codDepartamento, d.DDoc_Prd_PUQ UltimoPrecio, d.DDoc_RF1_Dbl Stock,
                            d.DDoc_RF4_Txt Catalogo, d.DDoc_RF4_Dbl Prioridad, d.DDoc_RF2_Dbl StockWarehouse, d.DDoc_RF4_Cod Parte, d.DDoc_Prd_DSP MontoAprox,COALESCE( IF(pro1.PDoc_Chi_Num IS NULL, pro1.PDoc_Chi_Num, 'OC'), IF(pro.PDoc_Chi_Num IS  NULL, pro.PDoc_Chi_Num, 'Quoted'),   ' ') Fase
                    FROM Dcmtos_DTL d
                    LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM
                    LEFT JOIN {conta}.costos cc ON cc.cost_num = d.DDoc_RF1_Num
                    LEFT JOIN Dcmtos_DTL_Pro pro ON pro.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND pro.PDoc_Par_Cat = d.DDoc_Doc_Cat AND pro.PDoc_Par_Ano = d.DDoc_Doc_Ano 
										AND pro.PDoc_Par_Num = d.DDoc_Doc_Num AND pro.PDoc_Chi_Cat = 736
                    LEFT JOIN Dcmtos_DTL_Pro pro1 ON pro1.PDoc_Sis_Emp = pro.PDoc_Sis_Emp AND pro1.PDoc_Par_Cat = pro.PDoc_Chi_Cat AND pro1.PDoc_Par_Ano = pro.PDoc_Chi_Ano 
										AND pro1.PDoc_Par_Num = pro.PDoc_Chi_Num AND pro1.PDoc_Chi_Cat = 777
                            WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}
                            GROUP BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)
        strSQL = strSQL.Replace("{conta}", cfun.ContaEmpresa)

        Return strSQL
    End Function

    Private Sub CargarDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strArea As String = STR_VACIO
        Dim contador As Integer = 0
        'Dim dblcantidad As Double = 0
        'Dim dblTotal As Double = 0
        'Dim dblTotalLinea As Double = 0

        Try
            strSQL = sqlDetalle(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read

                    strFila = REA.GetInt32("cod") & "|"
                    strFila &= REA.GetString("producto") & "|"
                    strFila &= REA.GetInt32("UM") & "|"
                    If REA.GetInt32("UM") = 0 Then
                        strFila &= "" & "|"
                    Else
                        strFila &= REA.GetString("cat_clave") & "|"
                    End If

                    strFila &= REA.GetInt32("Cantidad") & "|"
                    strFila &= REA.GetInt32("CodCentroCosto") & "|"
                    strFila &= REA.GetString("CentroCosto") & "|"
                    strFila &= REA.GetInt32("CodMaquina") & "|"
                    strFila &= REA.GetString("Departamento") & "|"
                    strFila &= REA.GetString("DescripcionMaquina") & "|"
                    strFila &= REA.GetString("Parte") & "|"
                    strFila &= REA.GetString("Marca") & "|"
                    strFila &= REA.GetString("Modelo") & "|"
                    'strFila &= REA.GetString("Serie") & "|"
                    strFila &= " " & "|"
                    strFila &= REA.GetString("Catalogo") & "|"
                    strFila &= REA.GetString("StockWarehouse") & "|"
                    strFila &= REA.GetInt32("Stock") & "|"
                    strFila &= REA.GetDouble("UltimoPrecio") & "|"
                    strFila &= REA.GetDouble("MontoAprox") & "|"

                    If REA.GetInt32("Presupuesto") = 1 Then
                        strFila &= "YES" & "|"
                    ElseIf REA.GetInt32("Presupuesto") = 2 Then
                        strFila &= "NO" & "|"
                    Else
                        strFila &= "" & "|"
                    End If

                    strFila &= REA.GetInt32("linea") & "|"

                    If REA.GetInt32("Approval") = 1 Then
                        strFila &= "Approved" & "|"
                    ElseIf REA.GetInt32("Approval") = 2 Then
                        strFila &= "Rejected" & "|"
                    ElseIf REA.GetInt32("Approval") = 3 Then
                        strFila &= "Canceled" & "|"
                    ElseIf REA.GetInt32("Approval") = 4 Then
                        strFila &= "Pending" & "|"
                    Else
                        strFila &= "" & "|"
                    End If
                    strFila &= REA.GetInt32("CodDepartamento") & "|"
                    strFila &= REA.GetInt32("CodMaquina") & "|"
                    strFila &= REA.GetInt32("CodDepartamento") & "|"

                    If REA.GetInt32("Prioridad") = 1 Then
                        strFila &= "Urgent" & "|"
                    Else
                        strFila &= "Standard" & "|"
                    End If
                    strFila &= REA.GetString("Fase")


                    cFunciones.AgregarFila(dgDetalle, strFila)
                    contador = contador + 1
                Loop
                calcularTotal()
                OcultarCampos()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom nombre, h.HDoc_Doc_Status status, h.HDoc_RF1_Num Autorizar, 
                    h.HDoc_RF2_Num TipoCompra, h.HDoc_RF3_Dbl TipoRequisa, h.HDoc_DR1_Num Comentarios
                    FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 734 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)

        Return strSQL
    End Function

    Private Sub CargarEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlEncabezado(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaNumero.Text = REA.GetInt32("Numero")

                    celdaAño.Text = REA.GetInt32("anio")
                    dtpFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    celdaNombre.Text = REA.GetString("nombre")
                    celdaComentarios.Text = REA.GetString("Comentarios")

                    If REA.GetInt32("status") = 1 Then
                        checkActive.Checked = True
                    Else
                        checkActive.Checked = False
                    End If

                    If REA.GetInt32("Autorizar") = 1 Then
                        checkAutorizar.Checked = True
                        intAutoriza = 1
                    Else
                        checkAutorizar.Checked = False
                        intAutoriza = 0
                    End If

                    If REA.GetInt32("TipoCompra") = 1 Then
                        rbInternacional.Checked = True
                    ElseIf REA.GetInt32("TipoCompra") = 2 Then
                        rbLocal.Checked = True
                    End If

                    If REA.GetInt32("TipoRequisa") = 1 Then
                        intTipo = 1
                    Else
                        intTipo = 0
                    End If

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub OcultarCampos()
        If intTipo = 1 Then
            dgDetalle.Columns("colDepartamento").Visible = False
            dgDetalle.Columns("colDescripcionMaquina").Visible = False
            dgDetalle.Columns("colMarca").Visible = False
            dgDetalle.Columns("colModelo").Visible = False
            ' dgDetalle.Columns("colSerie").Visible = False
            dgDetalle.Columns("colUltimoPrecio").Visible = False
            dgDetalle.Columns("colStock").Visible = False
            dgDetalle.Columns("colCatalogo").Visible = False
            dgDetalle.Columns("colNumeroParte").Visible = False
            dgDetalle.Columns("colStockWarehouse").Visible = False
            dgDetalle.Columns("colUM").Visible = False

        Else
            dgDetalle.Columns("colDepartamento").Visible = True
            dgDetalle.Columns("colDescripcionMaquina").Visible = True
            dgDetalle.Columns("colMarca").Visible = True
            dgDetalle.Columns("colModelo").Visible = True
            ' dgDetalle.Columns("colSerie").Visible = True
            dgDetalle.Columns("colUltimoPrecio").Visible = True
            dgDetalle.Columns("colStock").Visible = True
            dgDetalle.Columns("colCatalogo").Visible = True
            dgDetalle.Columns("colNumeroParte").Visible = True
            dgDetalle.Columns("colStockWarehouse").Visible = True
            dgDetalle.Columns("colUM").Visible = True
        End If

    End Sub
    Private Function LimpiarCampos()
        celdaNombre.ReadOnly = False
        celdaNumero.Text = NO_FILA
        celdaAño.Text = cFunciones.AñoMySQL
        dtpFecha.Text = Now.ToString(FORMATO_MYSQL)
        celdaNombre.Clear()
        dgDetalle.Rows.Clear()
        celdaComentarios.Clear()
        OcultarCampos()
        checkActive.Checked = True
        checkAutorizar.Checked = False
        rbLocal.Checked = False
        rbInternacional.Checked = False
        intAutoriza = 0
    End Function

    Private Function VerificarDatos() As Boolean
        Dim verificar As Boolean = True
        Dim intLineas As Integer = 0
        Try
            If celdaNombre.Text.Length < 3 Then
                verificar = False
                MsgBox("Enter the Requester's name", vbInformation, "Notice")
                celdaNombre.Focus()
                Exit Function
            End If
            If dgDetalle.Rows.Count > 0 Then
                For i As Integer = 0 To dgDetalle.Rows.Count - 1

                    If dgDetalle.Rows(i).Cells("colCodigo").Value = 0 Then

                        verificar = False
                        MsgBox("Article code invalid", vbInformation, "Notice")
                        Exit Function

                    End If

                    If intTipo = 0 Then
                        If dgDetalle.Rows(i).Cells("colIdMedida").Value = STR_VACIO Then
                            verificar = False
                            MsgBox("Article UM is invalid", vbInformation, "Notice")
                            Exit Function
                        End If
                    End If


                    If dgDetalle.Rows(i).Cells("colCantidad").Value = STR_VACIO Then
                        verificar = False
                        MsgBox("Quantity is invalid", vbInformation, "Notice")
                        Exit Function
                    End If

                    If dgDetalle.Rows(i).Cells("colNumeroCosto").Value = STR_VACIO Then
                        verificar = False
                        MsgBox("Cost Center is invalid", vbInformation, "Notice")
                        Exit Function
                    End If
                    If checkAutorizar.Checked = True Then
                        If dgDetalle.Rows(i).Cells("colPresupuesto").Value = STR_VACIO Then
                            verificar = False
                            MsgBox("Budget is invalid", vbInformation, "Notice")
                            Exit Function
                        End If
                    End If


                    'If dgDetalle.Rows(i).Cells("colStatus").Value = STR_VACIO Then
                    '    verificar = False
                    '    MsgBox("Status approval is invalid", vbInformation, "Notice")
                    '    Exit Function
                    'End If

                    If (dgDetalle.Rows(i).Cells("colCodDepartamento").Value <> 0 And dgDetalle.Rows(i).Cells("colCodMaquina").Value = 0) Or
                        (dgDetalle.Rows(i).Cells("colCodDepartamento").Value = 0 And dgDetalle.Rows(i).Cells("colCodMaquina").Value <> 0) Then
                        verificar = False
                        MsgBox("Please, complete data machine", vbInformation, "Notice")
                        Exit Function
                    End If
                Next
            Else
                MsgBox("invalid detail", vbInformation, "Notice")
                verificar = False
                Exit Function
            End If






        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return verificar
    End Function

    Private Function Sinpresupuesto(ByRef Numero As Integer, ByRef Anio As Integer) As Integer

        Dim Cantidad As Integer = INT_CERO

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colPresupuesto").Value = "NO" And dgDetalle.CurrentRow.Cells("colStatus").Value = "Pending" Then
                Cantidad = Cantidad + 1
            End If
        Next



        Return Cantidad
    End Function

    Private Function GuardarEncabezado(Optional strTexto As String = STR_VACIO) As Boolean
        Dim hdr As New clsDcmtos_HDR
        Dim Correcto As Boolean = False


        Try
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 734
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_EMP_NOM = celdaNombre.Text
            hdr.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, 0)
            hdr.HDOC_RF1_NUM = IIf(checkAutorizar.Checked = True, 1, 0)
            hdr.HDOC_RF2_NUM = IIf(rbInternacional.Checked = True, 1, 2)
            hdr.HDOC_RF3_DBL = IIf(intTipo = 1, 1, 0)
            hdr.HDOC_DR1_NUM = strTexto



            hdr.CONEXION = strConexion
            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    Correcto = False
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 734, celdaAño.Text, celdaNumero.Text)
                    Correcto = True
                End If
            Else
                If hdr.Guardar() = False Then
                    Correcto = False
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 734, celdaAño.Text, celdaNumero.Text)
                    Correcto = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Correcto
    End Function

    Private Sub GuardarDetalle()
        Dim dtl As New clsDcmtos_DTL

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                dtl.DDOC_DOC_ANO = celdaAño.Text
                dtl.DDOC_DOC_CAT = 734
                dtl.DDOC_DOC_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Cells("colLinea").Value = 0 Then
                    dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
                    dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                Else
                    dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                End If
                dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcionArticulo").Value
                If dgDetalle.Rows(i).Cells("colIdMedida").Value <> STR_VACIO Then
                    dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value
                End If

                dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colNumeroCosto").Value
                If dgDetalle.Rows(i).Cells("colCodMaquina").Value = STR_VACIO Then
                    dtl.DDOC_RF2_NUM = 0
                Else
                    dtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colCodMaquina").Value
                End If

                If dgDetalle.Rows(i).Cells("colDescripcionMaquina").Value = STR_VACIO Then
                    dtl.DDOC_RF2_TXT = STR_VACIO
                Else
                    dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colDescripcionMaquina").Value
                End If


                If dgDetalle.Rows(i).Cells("colMarca").Value = STR_VACIO Then
                    dtl.DDOC_RF2_COD = STR_VACIO
                Else
                    dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colMarca").Value
                End If

                If dgDetalle.Rows(i).Cells("colModelo").Value = STR_VACIO Then
                    dtl.DDOC_RF1_COD = STR_VACIO
                Else
                    dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colModelo").Value
                End If

                'If dgDetalle.Rows(i).Cells("colSerie").Value = STR_VACIO Then
                '    dtl.DDOC_RF1_TXT = STR_VACIO
                'Else
                '    dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colSerie").Value
                'End If


                If dgDetalle.Rows(i).Cells("colCodDepartamento").Value = STR_VACIO Then
                    dtl.DDOC_RF3_DBL = 0
                Else
                    dtl.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colCodDepartamento").Value
                End If


                If dgDetalle.Rows(i).Cells("colDepartamento").Value = STR_VACIO Then
                    dtl.DDOC_RF3_TXT = STR_VACIO
                Else
                    dtl.DDOC_RF3_TXT = dgDetalle.Rows(i).Cells("colDepartamento").Value
                End If



                If dgDetalle.Rows(i).Cells("colPresupuesto").Value = "YES" Then
                    dtl.DDOC_RF4_NUM = 1
                ElseIf dgDetalle.Rows(i).Cells("colPresupuesto").Value = "NO" Then
                    dtl.DDOC_RF4_NUM = 2
                Else
                    dtl.DDOC_RF4_NUM = 0
                End If

                If dgDetalle.Rows(i).Cells("colStatus").Value = "Approved" Then
                    dtl.DDOC_RF3_NUM = 1
                ElseIf dgDetalle.Rows(i).Cells("colStatus").Value = "Rejected" Then
                    dtl.DDOC_RF3_NUM = 2
                ElseIf dgDetalle.Rows(i).Cells("colStatus").Value = "Canceled" Then
                    dtl.DDOC_RF3_NUM = 3
                ElseIf dgDetalle.Rows(i).Cells("colStatus").Value = "Pending" Then
                    dtl.DDOC_RF3_NUM = 4
                End If

                If dgDetalle.Rows(i).Cells("colUltimoPrecio").Value <> STR_VACIO Then
                    dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colUltimoPrecio").Value
                End If

                If dgDetalle.Rows(i).Cells("colStock").Value <> STR_VACIO Then
                    dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colStock").Value
                End If

                If dgDetalle.Rows(i).Cells("colCatalogo").Value <> STR_VACIO Then
                    dtl.DDOC_RF4_TXT = dgDetalle.Rows(i).Cells("colCatalogo").Value
                End If


                If dgDetalle.Rows(i).Cells("colPrioridad").Value = "Urgent" Then
                    dtl.DDOC_RF4_DBL = 1

                Else
                    dtl.DDOC_RF4_DBL = 0
                End If


                If dgDetalle.Rows(i).Cells("colStockWareHouse").Value <> STR_VACIO Then
                    dtl.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colStockWareHouse").Value

                End If

                If dgDetalle.Rows(i).Cells("colMontoAprox").Value <> STR_VACIO Then
                    dtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colMontoAprox").Value

                End If

                dtl.DDOC_RF4_COD = dgDetalle.Rows(i).Cells("colNumeroParte").Value

                If dgDetalle.Rows(i).Cells("colFase").Value = STR_VACIO Then
                    dtl.DDOC_PRD_REF = 0
                ElseIf dgDetalle.Rows(i).Cells("colFase").Value = "Quoted" Then
                    dtl.DDOC_PRD_REF = 1
                ElseIf dgDetalle.Rows(i).Cells("colFase").Value = "OC" Then
                    dtl.DDOC_PRD_REF = 2
                Else
                    dtl.DDOC_PRD_REF = 0
                End If


                dtl.CONEXION = strConexion

                If Me.Tag = "Mod" Then
                    If dtl.Actualizar() = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)

                    End If
                Else
                    If dtl.Guardar() = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            'botonImprimir.Enabled = False

        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True

            'botonImprimir.Enabled = False 

        End If
    End Sub
    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Requester, h.HDoc_Doc_Status Estado, h.HDoc_RF1_Num Autorizar, h.HDOC_RF2_Num Tipo
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d
                    ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and
                    d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                    Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 734 
                    "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "And h.HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}' "
            strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        End If
        If checkUrgente.Checked = True Then
            strSQL &= " AND d.DDoc_RF4_Dbl = 1 "
        End If

        If checkLocal.Checked = True And checkInternacional.Checked = False Then
            strSQL &= "AND h.HDoc_RF2_Num = 2 "
        ElseIf checkLocal.Checked = False And checkInternacional.Checked = True Then
            strSQL &= "AND h.HDoc_RF2_Num = 1 "
        ElseIf checkLocal.Checked = True And checkInternacional.Checked = True Then
            strSQL &= "AND (h.HDoc_RF2_Num = 1 OR h.HDoc_RF2_Num = 2) "
        Else
            strSQL &= "AND (h.HDoc_RF2_Num = 1 AND h.HDoc_RF2_Num = 2) "
        End If




        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL &= " GROUP BY   h.HDoc_Doc_Ano , h.HDoc_Doc_Num "
        strSQL &= " ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC "
        Return strSQL
    End Function
    Private Function RequisasSinCotizacion(ByRef Numero As Integer, ByRef Anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Cantidad As Integer

        strSQL = " SELECT COUNT(*)
                    FROM (
		                    SELECT *
                         FROM Dcmtos_DTL d
                          LEFT JOIN Dcmtos_DTL_Pro pro ON pro.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND pro.PDoc_Par_Cat = d.DDoc_Doc_Cat AND pro.PDoc_Par_Ano = d.DDoc_Doc_Ano 
				 	                    AND pro.PDoc_Par_Num = d.DDoc_Doc_Num AND pro.PDoc_Par_Lin = d.DDoc_Doc_Lin  AND pro.PDoc_Chi_Cat = 736
                         WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {Anio} AND d.DDoc_Doc_Num = {Numero}  AND pro.PDoc_Par_Num IS NULL
     
	                      )A"
        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{Anio}", Anio)
        strSQL = strSQL.Replace("{Numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Cantidad = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()



        Return Cantidad
    End Function

    Private Function RequisasSinOrdenCompra(ByRef Numero As Integer, ByRef Anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Cantidad As Integer

        strSQL = " SELECT COUNT(*)
                    FROM (
		                    SELECT d.*
                         FROM Dcmtos_DTL d
                          LEFT JOIN Dcmtos_DTL_Pro pro ON pro.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND pro.PDoc_Par_Cat = d.DDoc_Doc_Cat AND pro.PDoc_Par_Ano = d.DDoc_Doc_Ano 
				 	                    AND pro.PDoc_Par_Num = d.DDoc_Doc_Num AND pro.PDoc_Par_Lin = d.DDoc_Doc_Lin  AND pro.PDoc_Chi_Cat = 736
		                    LEFT JOIN Dcmtos_DTL_Pro pro1 ON pro1.PDoc_Sis_Emp = pro.PDoc_Sis_Emp AND pro1.PDoc_Par_Cat = pro.PDoc_Chi_Cat AND pro1.PDoc_Par_Ano = pro.PDoc_Chi_Ano 
										                    AND pro1.PDoc_Par_Num = pro.PDoc_Chi_Num AND pro1.PDoc_Par_Lin = pro.PDoc_Chi_Lin  AND pro1.PDoc_Chi_Cat = 777
                         WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {Anio} AND d.DDoc_Doc_Num = {Numero}  AND pro1.PDoc_Par_Num IS NULL
     
	                      )A"
        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{Anio}", Anio)
        strSQL = strSQL.Replace("{Numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Cantidad = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()



        Return Cantidad
    End Function

    Private Function PendientedeAprobacion(ByRef Numero As Integer, ByRef Anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Cantidad As Integer

        strSQL = " SELECT COUNT(*)
                    FROM Dcmtos_DTL d
                    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {Anio} AND d.DDoc_Doc_Num = {Numero} AND d.DDoc_RF3_Num = 4"
        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{Anio}", Anio)
        strSQL = strSQL.Replace("{Numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Cantidad = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()



        Return Cantidad
    End Function
    Private Function EstadoUrgente(ByRef Numero As Integer, ByRef Anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Cantidad As Integer

        strSQL = " SELECT COUNT(*)
                    FROM Dcmtos_DTL d
                    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {Anio} AND d.DDoc_Doc_Num = {Numero} AND d.DDoc_RF4_Dbl = 1"
        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{Anio}", Anio)
        strSQL = strSQL.Replace("{Numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Cantidad = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()



        Return Cantidad
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Anio As Integer
        Dim Numero As Integer


        strSQL = sqlLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        dgLista.Rows.Clear()
        If REA.HasRows Then
            Do While REA.Read

                strFila = REA.GetInt32("Anio") & "|"
                strFila &= REA.GetInt32("Numero") & "|"
                strFila &= REA.GetDateTime("Fecha") & "|"
                strFila &= REA.GetString("Requester") & "|"
                If REA.GetInt32("Tipo") = 1 Then
                    strFila &= "International |"
                Else
                    strFila &= "Local |"
                End If

                If REA.GetInt32("Estado") = 1 Then
                    strFila &= "Activo" & "|"
                Else
                    strFila &= "Inactivo" & "|"
                End If

                strFila &= REA.GetInt32("Autorizar")


                Anio = REA.GetInt32("Anio")
                Numero = REA.GetInt32("Numero")

                If REA.GetInt32("Estado") = 0 Then
                    cFunciones.AgregarFila(dgLista, strFila, Color.LightCoral)

                Else
                    If rbCotizacion.Checked = True Then
                        If RequisasSinCotizacion(Numero, Anio) = 0 Then
                            cFunciones.AgregarFila(dgLista, strFila)
                        End If
                    ElseIf rbOrdenCompra.Checked = True Then
                        If RequisasSinOrdenCompra(Numero, Anio) = 0 Then
                            cFunciones.AgregarFila(dgLista, strFila)
                        End If
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If


                End If

            Loop

            'Colorea
            For i As Integer = 0 To Me.dgLista.Rows.Count - 1

                Anio = dgLista.Rows(i).Cells("colAnio").Value
                Numero = dgLista.Rows(i).Cells("colNumero").Value

                If dgLista.Rows(i).Cells("colAutorizar").Value = 0 Then
                    dgLista.Rows(i).Cells(1).Style.BackColor = Color.YellowGreen
                End If

                If PendientedeAprobacion(Numero, Anio) > 0 Then
                    dgLista.Rows(i).Cells(2).Style.BackColor = Color.SkyBlue
                End If

                If EstadoUrgente(Numero, Anio) > 0 Then
                    dgLista.Rows(i).Cells(3).Style.BackColor = Color.Orange

                End If

            Next

        End If

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)

        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("List Processing")
            'Cargar Datos

            CargarLista()
            'Mostrar Panel Filtro

            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()

        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                checkAutorizar.Enabled = True
                '     botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                checkAutorizar.Enabled = False
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub EnviarCorreo()
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strConexion2 As String = STR_VACIO
        Dim strInsert As String = STR_VACIO
        Dim COMM As MySqlCommand
        Dim ConPresupuesto As String = STR_VACIO
        Dim SinPresupuesto As String = STR_VACIO
        Dim conec2 As MySqlConnection
        Dim contador1 As Integer = 0
        Dim contador2 As Integer = 0

        ArrayServer = strConexion.Split(";".ToCharArray)

        strConexion2 = "server={server};port={puerto};uid={user};password={password};database={database} ;Allow User Variables=True"
        ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

        If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
            strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
        Else
            strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
            strConexion2 = Replace(strConexion2, "{puerto}", "3308")
        End If

        strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
        strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
        strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)


        ConPresupuesto = "REQUISITIONS" & vbCrLf
        ConPresupuesto = "REQUISITIONS" & vbCrLf
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colPresupuesto").Value = "YES" Then
                contador1 = contador1 + 1
                ConPresupuesto &= 734 & "-" & dgDetalle.Rows(i).Cells("colCodigo").Value & "-" & dgDetalle.Rows(i).Cells("colDescripcionArticulo").Value & " --> " & celdaNombre.Text & vbCrLf
            Else
                contador2 = contador2 + 1
                SinPresupuesto &= 734 & "-" & dgDetalle.Rows(i).Cells("colCodigo").Value & "-" & dgDetalle.Rows(i).Cells("colDescripcionArticulo").Value & " --> " & celdaNombre.Text & vbCrLf
            End If
        Next

        If contador1 > 0 Then
            strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "developer@sierratextiles.com'" & "," & "'Requisition Approved'" & ",'" & ConPresupuesto & "',0);")
            conec2 = New MySqlConnection(strConexion2)
            conec2.Open()
            Using conec2
                COMM = New MySqlCommand(strInsert, conec2)
                COMM.ExecuteNonQuery()
                COMM.Dispose()
                System.GC.Collect()

                COMM.Dispose()
                COMM = Nothing
                conec2.Close()
                conec2.Dispose()
                conec2 = Nothing
                System.GC.Collect()
            End Using
        End If

        If contador2 > 0 Then
            strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "developer@sierratextiles.com'" & "," & "'Requisition pending approval'" & ",'" & SinPresupuesto & "',0);")
            conec2 = New MySqlConnection(strConexion2)
            conec2.Open()
            Using conec2
                COMM = New MySqlCommand(strInsert, conec2)
                COMM.ExecuteNonQuery()
                COMM.Dispose()
                System.GC.Collect()

                COMM.Dispose()
                COMM = Nothing
                conec2.Close()
                conec2.Dispose()
                conec2 = Nothing
                System.GC.Collect()
            End Using
        End If






    End Sub

    Private Sub BorrarEncabezado(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 734
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDetalle(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = 734 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function PermisosAprobar(ByVal tipo As Integer) As Boolean
        Dim logRes As Boolean = False
        Dim str_Margen As String = STR_VACIO
        If tipo = 1 Then
            str_Margen = "AprobarRequisa"
        Else
            str_Margen = "AutorizarRequisa"
        End If

        Dim frm As New frmAutorización
        Try
            frm.Iniciar(734, str_Margen, 0, "Authorize Approve, Requisition Existing")
            frm.ShowDialog(Fprincipal)
            If frm.Aceptado Then
                If frm.Nivel Then
                    logRes = True
                Else
                    MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logRes
    End Function
    Private Sub Guardar()
        If VerificarDatos() = True Then
            If celdaNumero.Text = NO_FILA Then
                celdaNumero.Text = cFunciones.NuevoId(catalogos)

            End If



            If GuardarEncabezado(celdaComentarios.Text) = True Then
                GuardarDetalle()
                MsgBox("Successfully Saved Document", vbInformation, "Notice")
                'EnviarCorreo()
                MostrarLista()


            End If
        End If
    End Sub

    Private Sub calcularTotal()
        Dim dblTotal As Double = 0


        For i As Integer = 0 To dgDetalle.Rows.Count - 1

            dblTotal = dblTotal + dgDetalle.Rows(i).Cells("colMontoAprox").Value

        Next

        celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
    End Sub

#End Region

#Region "Eventos"
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Try
            If LogBorrar = True Then
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarEncabezado(celdaNumero.Text, celdaAño.Text)
                    BorrarDetalle(celdaNumero.Text, celdaAño.Text)

                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 691, celdaAño.Text, celdaNumero.Text)
                    MostrarLista()
                End If
            Else
                MsgBox("You do not have permission for this action", vbInformation, "Notice")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer
        Dim numero As Integer
        Me.Tag = "Mod"
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        MostrarLista(False)
        año = dgLista.SelectedCells(0).Value
        numero = dgLista.SelectedCells(1).Value
        LimpiarCampos()
        CargarEncabezado(año, numero)
        CargarDetalle(año, numero)
        botonAgregar.Enabled = False
        botonEliminar.Enabled = False
        celdaNombre.ReadOnly = True
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim PD As New frmPedirComentarios
        Dim strTexto As String = STR_VACIO
        If VerificarDatos() = True Then
            If celdaNumero.Text = NO_FILA Then
                celdaNumero.Text = cFunciones.NuevoId(catalogos)

            End If

            If Me.Tag = "Nuevo" Then
                If GuardarEncabezado() = True Then
                    GuardarDetalle()
                    MsgBox("Successfully Saved Document", vbInformation, "Notice")
                    'EnviarCorreo()
                    MostrarLista()
                End If
            Else

                If Sinpresupuesto(celdaNumero.Text, celdaAño.Text) > 0 Then

                    PD.ShowDialog(Me)
                    If PD.DialogResult = DialogResult.Cancel Then
                        'MENSAJE
                        MsgBox("It is necessary to leave a comment to save", vbInformation, "Notice")
                        Exit Sub
                    Else
                        strTexto = celdaComentarios.Text & vbCrLf & vbCrLf
                        strTexto &= PD.celdaInfo.Text
                        PD.Iniciar(strTexto)

                    End If

                Else
                    strTexto = celdaComentarios.Text

                End If


                If checkAutorizar.Checked = True Then
                    If PermisosAprobar(2) Then
                        If GuardarEncabezado(strTexto) = True Then
                            GuardarDetalle()
                            MsgBox("Successfully Saved Document", vbInformation, "Notice")
                            'EnviarCorreo()
                            MostrarLista()
                        End If
                    End If
                Else
                    If GuardarEncabezado(strTexto) = True Then
                        GuardarDetalle()
                        MsgBox("Successfully Saved Document", vbInformation, "Notice")
                        ' EnviarCorreo()
                        MostrarLista()
                    End If
                End If


            End If


        End If

    End Sub
    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        If MsgBox("Are you sure to delete this items?", vbYesNo + vbQuestion) = vbNo Then
            Exit Sub
        End If
        Dim intRow As Integer =
               dgDetalle.CurrentCell.RowIndex


        If logEditar = True Then
            dgDetalle.Rows.RemoveAt(intRow)
        End If

    End Sub
    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim opt As New frmOption
        Dim intopt As Integer
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 3
                    If Me.Tag = "Nuevo" Then
                        If intTipo = 1 Then
                            Dim frm As New frmSeleccionar
                            Try
                                frm.Titulo = "Select a Unit Measure"
                                frm.Campos = " c.cat_num, c.cat_clave "
                                frm.Tabla = "Catalogos c"
                                frm.FiltroText = "Enter the name of the unit measure to filter"
                                frm.Filtro = " c.cat_desc "
                                frm.Condicion = "c.cat_clase = 'Medidas' AND c.cat_dato ='OCE'"

                                frm.ShowDialog(Me)
                                If frm.DialogResult = DialogResult.OK Then
                                    dgDetalle.CurrentRow.Cells("colIdMedida").Value = frm.LLave
                                    dgDetalle.CurrentRow.Cells("colUM").Value = frm.Dato
                                End If
                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try

                        End If
                    End If



                Case 6
                    If Me.Tag = "Nuevo" Then
                        Dim frmF As New frmSeleccionar
                        frmF.Titulo = "Select a cost center"
                        frmF.Campos = " cost_num Numero, cost_nombre Nombre, cost_desc Descripcion"
                        frmF.Tabla = cfun.ContaEmpresa & ".costos "

                        frmF.FiltroText = "Enter the name of the cost center to filter"
                        frmF.Filtro = " cost_nombre "
                        frmF.Condicion = " cost_num >=0"
                        frmF.ShowDialog(Me)
                        If frmF.DialogResult = DialogResult.OK Then
                            dgDetalle.CurrentRow.Cells("colNumeroCosto").Value = frmF.LLave
                            dgDetalle.CurrentRow.Cells("colCentroCosto").Value = frmF.Dato
                        End If
                    End If

                Case 8
                    If Me.Tag = "Nuevo" Then
                        Dim frmF As New frmSeleccionar
                        frmF.Titulo = "Select a department"
                        frmF.Campos = " Correlativo Codigo, Departamento"
                        frmF.Tabla = "Maquinaria"

                        frmF.FiltroText = "Enter the name of department"
                        frmF.Filtro = " Departamento "
                        frmF.Condicion = " Estado = 1 AND  NoCorrelativo = 0"
                        frmF.ShowDialog(Me)
                        If frmF.DialogResult = DialogResult.OK Then

                            dgDetalle.CurrentRow.Cells("colDepartamento").Value = frmF.Dato
                            dgDetalle.CurrentRow.Cells("colCodDepartamento").Value = frmF.LLave
                        End If
                        dgDetalle.CurrentRow.Cells("colCodMaquina").Value = 0
                        dgDetalle.CurrentRow.Cells("colDescripcionMaquina").Value = STR_VACIO
                        dgDetalle.CurrentRow.Cells("colMarca").Value = STR_VACIO
                        dgDetalle.CurrentRow.Cells("colModelo").Value = STR_VACIO
                        dgDetalle.CurrentRow.Cells("colSerie").Value = STR_VACIO
                    Else
                        If dgDetalle.CurrentRow.Cells("colCodDepartamentoRef").Value = 0 Then
                            Dim frmF As New frmSeleccionar
                            frmF.Titulo = "Select a department"
                            frmF.Campos = " Correlativo Codigo, Departamento"
                            frmF.Tabla = "Maquinaria"

                            frmF.FiltroText = "Enter the name of department"
                            frmF.Filtro = " Departamento "
                            frmF.Condicion = " Estado = 1 AND  NoCorrelativo = 0"
                            frmF.ShowDialog(Me)
                            If frmF.DialogResult = DialogResult.OK Then

                                dgDetalle.CurrentRow.Cells("colDepartamento").Value = frmF.Dato
                                dgDetalle.CurrentRow.Cells("colCodDepartamento").Value = frmF.LLave
                            End If
                            dgDetalle.CurrentRow.Cells("colCodMaquina").Value = 0
                            dgDetalle.CurrentRow.Cells("colDescripcionMaquina").Value = STR_VACIO
                            dgDetalle.CurrentRow.Cells("colMarca").Value = STR_VACIO
                            dgDetalle.CurrentRow.Cells("colModelo").Value = STR_VACIO
                            dgDetalle.CurrentRow.Cells("colSerie").Value = STR_VACIO
                        End If
                    End If


                Case 9
                    If Me.Tag = "Nuevo" Then
                        Dim frmF As New frmSeleccionar
                        frmF.Titulo = "Select a Machine"
                        frmF.Campos = " Correlativo Codigo, Descripcion, Marca, Modelo"
                        frmF.Tabla = "Maquinaria"

                        frmF.FiltroText = "Enter the name of department"
                        frmF.Filtro = " Descripcion "
                        frmF.Agrupar = "Modelo"
                        If dgDetalle.CurrentRow.Cells("colCodDepartamento").Value = 0 Then
                            frmF.Condicion = " Estado = 1 AND NoCorrelativo > 0 "
                        Else
                            frmF.Condicion = " Estado = 1 AND  NoCorrelativo = " & dgDetalle.CurrentRow.Cells("colCodDepartamento").Value
                        End If

                        frmF.ShowDialog(Me)
                        If frmF.DialogResult = DialogResult.OK Then
                            dgDetalle.CurrentRow.Cells("colCodMaquina").Value = frmF.LLave
                            dgDetalle.CurrentRow.Cells("colDescripcionMaquina").Value = frmF.Dato
                            dgDetalle.CurrentRow.Cells("colMarca").Value = frmF.Dato2
                            dgDetalle.CurrentRow.Cells("colModelo").Value = frmF.Dato3
                            'dgDetalle.CurrentRow.Cells("colSerie").Value = frmF.Dato4

                        End If
                    Else
                        If dgDetalle.CurrentRow.Cells("colCodMaquinaRef").Value = 0 Then

                            Dim frmF As New frmSeleccionar
                            frmF.Titulo = "Select a Machine"
                            frmF.Campos = " Correlativo Codigo, Descripcion, Marca, Modelo"
                            frmF.Tabla = "Maquinaria"

                            frmF.FiltroText = "Enter the name of department"
                            frmF.Filtro = " Descripcion "
                            If dgDetalle.CurrentRow.Cells("colCodDepartamento").Value = 0 Then
                                frmF.Condicion = " Estado = 1 AND NoCorrelativo > 0 "
                            Else
                                frmF.Condicion = " Estado = 1 AND  NoCorrelativo = " & dgDetalle.CurrentRow.Cells("colCodDepartamento").Value
                            End If
                            frmF.ShowDialog(Me)
                            If frmF.DialogResult = DialogResult.OK Then
                                dgDetalle.CurrentRow.Cells("colCodMaquina").Value = frmF.LLave
                                dgDetalle.CurrentRow.Cells("colDescripcionMaquina").Value = frmF.Dato
                                dgDetalle.CurrentRow.Cells("colMarca").Value = frmF.Dato2
                                dgDetalle.CurrentRow.Cells("colModelo").Value = frmF.Dato3
                                'dgDetalle.CurrentRow.Cells("colSerie").Value = frmF.Dato4

                            End If

                        End If
                    End If
                Case 19
                    If Me.Tag = "Mod" Then
                        If checkAutorizar.Checked = True Then

                            If dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "YES" Then
                                dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "NO"
                                dgDetalle.CurrentRow.Cells("colStatus").Value = "Pending"
                            ElseIf dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "NO" Then
                                dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "YES"
                                dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved"

                            Else
                                dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "YES"
                                dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved"
                            End If
                        End If
                    End If


                Case 21
                    If Me.Tag = "Mod" Then
                        If checkAutorizar.Checked = True Then
                            If dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "YES" Then

                                If dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved" Then
                                    opt.Titulo = "Option"
                                    opt.Mensaje = "Select an option"
                                    opt.Opciones = "Approve" & "|" & "Cancel"
                                    If opt.ShowDialog = DialogResult.OK Then

                                        Select Case opt.Seleccion
                                            Case 0
                                                intopt = 0
                                            Case 1
                                                intopt = 1

                                        End Select
                                    Else
                                        Exit Sub
                                    End If

                                    If intopt = 0 Then
                                        dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved"
                                    Else
                                        dgDetalle.CurrentRow.Cells("colStatus").Value = "Canceled"
                                    End If
                                End If

                            Else
                                If dgDetalle.CurrentRow.Cells("colStatus").Value = "Pending" Then
                                    opt.Titulo = "Option"
                                    opt.Mensaje = "Select an option"
                                    opt.Opciones = "Approve" & "|" & "Reject" & "|" & "Cancel"
                                    If opt.ShowDialog = DialogResult.OK Then

                                        Select Case opt.Seleccion
                                            Case 0
                                                intopt = 0
                                            Case 1
                                                intopt = 1
                                            Case 2
                                                intopt = 2

                                        End Select
                                    Else
                                        Exit Sub
                                    End If

                                    If intopt = 0 Then
                                        If PermisosAprobar(1) Then
                                            dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved"
                                            Guardar()
                                        End If
                                    ElseIf intopt = 1 Then
                                        If PermisosAprobar(1) Then
                                            dgDetalle.CurrentRow.Cells("colStatus").Value = "Rejected"
                                            Guardar()
                                        End If
                                    Else
                                        dgDetalle.CurrentRow.Cells("colStatus").Value = "Canceled"
                                        Guardar()
                                    End If
                                End If
                            End If
                        End If

                        'Else
                        '    If dgDetalle.CurrentRow.Cells("colPresupuesto").Value = "YES" Then


                        '        opt.Titulo = "Option"
                        '        opt.Mensaje = "Select an option"
                        '        opt.Opciones = "Approve" & "|" & "Cancel"
                        '        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                        '            Select Case opt.Seleccion
                        '                Case 0
                        '                    intopt = 0
                        '                Case 1
                        '                    intopt = 1

                        '            End Select
                        '        Else
                        '            Exit Sub
                        '        End If

                        '        If intopt = 0 Then
                        '            dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved"
                        '        Else
                        '            dgDetalle.CurrentRow.Cells("colStatus").Value = "Canceled"
                        '        End If


                        '    Else

                        '        opt.Titulo = "Option"
                        '        opt.Mensaje = "Select an option"
                        '        opt.Opciones = "Approve" & "|" & "Reject" & "|" & "Cancel"
                        '        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                        '            Select Case opt.Seleccion
                        '                Case 0
                        '                    intopt = 0
                        '                Case 1
                        '                    intopt = 1
                        '                Case 2
                        '                    intopt = 2

                        '            End Select
                        '        Else
                        '            Exit Sub
                        '        End If

                        '        If intopt = 0 Then
                        '            If PermisosAprobar(1) Then
                        '                dgDetalle.CurrentRow.Cells("colStatus").Value = "Approved"
                        '                Guardar()
                        '            End If
                        '        ElseIf intopt = 1 Then
                        '            If PermisosAprobar(1) Then
                        '                dgDetalle.CurrentRow.Cells("colStatus").Value = "Rejected"
                        '                Guardar()
                        '            End If
                        '        Else
                        '            dgDetalle.CurrentRow.Cells("colStatus").Value = "Canceled"
                        '            Guardar()
                        '        End If

                        '    End If
                    End If

                Case 25

                    opt.Titulo = "Option"
                    opt.Mensaje = "Select an option"
                    opt.Opciones = "Standard" & "|" & "Urgent"
                    If opt.ShowDialog = DialogResult.OK Then

                        Select Case opt.Seleccion
                            Case 0
                                intopt = 0
                            Case 1
                                intopt = 1

                        End Select
                    Else
                        Exit Sub
                    End If

                    If intopt = 0 Then
                        dgDetalle.CurrentRow.Cells("colPrioridad").Value = "Standard"
                    Else
                        dgDetalle.CurrentRow.Cells("colPrioridad").Value = "Urgent"
                    End If





            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Codigo As Integer = NO_FILA
        Dim Validar As Boolean = True
        Dim i As Integer = 0
        Dim strCapturaCodigoProd As String

        Try


            If intTipo = 0 Then
                frm.ParametroCrear = "Consumables"
                frm.Titulo = " Please select the product"
                frm.Campos = " i.inv_numero ,a.art_desc Descripcion , 
                                IFNULL((SELECT d.DDoc_Prd_PUQ FROM Dcmtos_DTL d WHERE d.DDoc_Doc_Cat = 47 AND d.DDoc_Prd_Cod = i.inv_numero ORDER BY d.DDoc_Doc_Num desc LIMIT 1 ),0) Precio, 
                                ca.cat_num CodigoUM, ca.cat_clave UM "
                frm.Tabla = "  Inventarios i LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  LEFT JOIN Catalogos c ON c.cat_num = a.art_clase   LEFT JOIN Catalogos ca ON ca.cat_num = inV_UMVenta "
                frm.Condicion = "   i.inv_sisemp  = " & Sesion.IdEmpresa & " AND i.inv_generico = 1 AND i.inv_status = 'Activo' AND c.cat_ext = 'Repuestos'    "
                frm.Limite = 25
                frm.Filtro = " a.art_desc"
                frm.FiltroText = " enter the product description to search "
                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    strFila = frm.LLave & "|" & frm.Dato & "|" & frm.Dato3 & "|" & frm.Dato4 & "||||0||||||||||" & frm.Dato2 & "|0||0||0|||Standard  "

                    cfun.AgregarFila(dgDetalle, strFila)
                End If



            Else
                'frm.LCrear = True

                frm.Titulo = "Please select the product"
                frm.Campos = " * "
                frm.Tabla = " (

                                SELECT  cat_num Codigo, cat_desc  Descripcion , cat_dato  Precio  
                                FROM  Catalogos  WHERE  cat_clase = 'Insumos'   
                                UNION
                                SELECT i.inv_numero Codigo ,a.art_desc Descripcion, i.inv_costo Precio
                                FROM Inventarios i
                                LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo
                                LEFT JOIN Catalogos c ON c.cat_num = a.art_clase
                                LEFT JOIN Catalogos ca ON ca.cat_num = inV_UMVenta
                                WHERE i.inv_sisemp = 15 AND i.inv_generico = 1 AND i.inv_status = 'Activo' AND (c.cat_ext = 'Consumibles' OR c.cat_ext = 'Material de empaque'  OR c.cat_ext= 'Inventario en Custodia' OR c.cat_ext= 'Combustible' OR c.cat_ext= 'Maquinaria')
                                )A "
                frm.Condicion = " 1=1 "
                frm.Limite = 10
                frm.Filtro = " A.Descripcion "
                frm.FiltroText = " enter the product description to search"
                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    strFila = frm.LLave & "|" & frm.Dato & "||||||0|||||||||||0||0||0|||Standard|  "
                    cfun.AgregarFila(dgDetalle, strFila)
                End If


            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()

        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)

        End If

    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim opt As New frmOption
        If logInsertar = True Then
            Me.Tag = "Nuevo"
            opt.Titulo = "Option"
            opt.Mensaje = "Select an option"
            opt.Opciones = "Spare parts" & "|" & " Consumables - Supplies - Services "
            If opt.ShowDialog = DialogResult.OK Then

                Select Case opt.Seleccion
                    Case 0
                        intTipo = 0
                    Case 1
                        intTipo = 1

                End Select
            Else
                Exit Sub
            End If

            LimpiarCampos()
            MostrarLista(False, True)
            Encabezado1.botonBorrar.Enabled = False
            botonAgregar.Enabled = True
            botonEliminar.Enabled = True

        Else
            MsgBox("No Posee permisos para esta acción", vbInformation)
        End If
    End Sub
    Private Sub frmDescargoConsumibles_Load(sender As Object, e As EventArgs) Handles Me.Load


        Accessos()
        dtpFechaFinal.Value = Today.ToString(FORMATO_MYSQL)
        dtpFechaInicial.Value = dtpFechaInicial.Value.AddMonths(NO_FILA).ToString(FORMATO_MYSQL)
        MostrarLista()
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub

    Private Sub etiquetaNaranja_Click(sender As Object, e As EventArgs) Handles etiquetaNaranja.Click

    End Sub



    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        calcularTotal()
    End Sub


#End Region
End Class