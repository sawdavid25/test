﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPedidoProduccionHilo
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colRefAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasaCambio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.etiquetaSaldo2 = New System.Windows.Forms.Label()
        Me.celdaSaldo2 = New System.Windows.Forms.TextBox()
        Me.celdaSaldo = New System.Windows.Forms.TextBox()
        Me.etiquetaSaldo = New System.Windows.Forms.Label()
        Me.celdaTotalLibras = New System.Windows.Forms.TextBox()
        Me.etiquetaTotalLibras = New System.Windows.Forms.Label()
        Me.celdaLibras = New System.Windows.Forms.TextBox()
        Me.etiquetaLibras = New System.Windows.Forms.Label()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.panelCliente = New System.Windows.Forms.Panel()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.panelAbajo = New System.Windows.Forms.Panel()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaPeso = New System.Windows.Forms.TextBox()
        Me.etiquetaPeso = New System.Windows.Forms.Label()
        Me.celdaPrecio = New System.Windows.Forms.TextBox()
        Me.etiquetaPrecio = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.panelCliente.SuspendLayout()
        Me.panelAbajo.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 126)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(894, 90)
        Me.panelListaPrincipal.TabIndex = 5
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAnio, Me.colNumber, Me.colDate, Me.colReferencia, Me.colProducto})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 54)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(894, 36)
        Me.dgLista.TabIndex = 3
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 87
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 67
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Product"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        Me.colProducto.Visible = False
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(894, 54)
        Me.panelFecha.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(581, 15)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(435, 17)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(361, 21)
        Me.etiquetaFin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(243, 16)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(224, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.panelAbajo)
        Me.panelDocumento.Location = New System.Drawing.Point(36, 244)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(953, 295)
        Me.panelDocumento.TabIndex = 6
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 170)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(953, 82)
        Me.panelDetalle.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colRefAnio, Me.colRefCatalogo, Me.colRefNum, Me.colCodigo, Me.colLinea, Me.colMarca, Me.colReferenciaP, Me.colDescripcion, Me.colPrecio, Me.colCantidad, Me.colPrecioMedida, Me.colTotal, Me.colidMedida, Me.colMedida, Me.colReferencia1, Me.colRefLin, Me.colBultoB, Me.colExtra, Me.colFecha, Me.colTasaCambio})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(953, 82)
        Me.dgDetalle.TabIndex = 1
        '
        'colRefAnio
        '
        Me.colRefAnio.HeaderText = "Anio"
        Me.colRefAnio.Name = "colRefAnio"
        Me.colRefAnio.ReadOnly = True
        Me.colRefAnio.Visible = False
        Me.colRefAnio.Width = 65
        '
        'colRefCatalogo
        '
        Me.colRefCatalogo.HeaderText = "Catalogo"
        Me.colRefCatalogo.Name = "colRefCatalogo"
        Me.colRefCatalogo.ReadOnly = True
        Me.colRefCatalogo.Visible = False
        Me.colRefCatalogo.Width = 93
        '
        'colRefNum
        '
        Me.colRefNum.HeaderText = "Numero"
        Me.colRefNum.Name = "colRefNum"
        Me.colRefNum.ReadOnly = True
        Me.colRefNum.Visible = False
        Me.colRefNum.Width = 87
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 64
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Mark"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Width = 68
        '
        'colReferenciaP
        '
        Me.colReferenciaP.HeaderText = "Production"
        Me.colReferenciaP.Name = "colReferenciaP"
        Me.colReferenciaP.ReadOnly = True
        Me.colReferenciaP.Width = 105
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDescripcion.Width = 85
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price Fyber"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecio.Width = 86
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Weight"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCantidad.Width = 58
        '
        'colPrecioMedida
        '
        Me.colPrecioMedida.HeaderText = "Estimated Price"
        Me.colPrecioMedida.Name = "colPrecioMedida"
        Me.colPrecioMedida.ReadOnly = True
        Me.colPrecioMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecioMedida.Visible = False
        Me.colPrecioMedida.Width = 112
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTotal.Width = 46
        '
        'colidMedida
        '
        Me.colidMedida.HeaderText = "idMedida"
        Me.colidMedida.Name = "colidMedida"
        Me.colidMedida.ReadOnly = True
        Me.colidMedida.Visible = False
        Me.colidMedida.Width = 94
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMedida.Width = 69
        '
        'colReferencia1
        '
        Me.colReferencia1.HeaderText = "Reference"
        Me.colReferencia1.Name = "colReferencia1"
        Me.colReferencia1.ReadOnly = True
        Me.colReferencia1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colReferencia1.Width = 80
        '
        'colRefLin
        '
        Me.colRefLin.HeaderText = "Linea"
        Me.colRefLin.Name = "colRefLin"
        Me.colRefLin.ReadOnly = True
        Me.colRefLin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colRefLin.Visible = False
        Me.colRefLin.Width = 49
        '
        'colBultoB
        '
        Me.colBultoB.HeaderText = "Bulto"
        Me.colBultoB.Name = "colBultoB"
        Me.colBultoB.ReadOnly = True
        Me.colBultoB.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBultoB.Visible = False
        Me.colBultoB.Width = 46
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        Me.colExtra.Width = 69
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colTasaCambio
        '
        Me.colTasaCambio.HeaderText = "Rate"
        Me.colTasaCambio.Name = "colTasaCambio"
        Me.colTasaCambio.ReadOnly = True
        Me.colTasaCambio.Visible = False
        Me.colTasaCambio.Width = 67
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.etiquetaSaldo2)
        Me.panelEncabezado.Controls.Add(Me.celdaSaldo2)
        Me.panelEncabezado.Controls.Add(Me.celdaSaldo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaSaldo)
        Me.panelEncabezado.Controls.Add(Me.celdaTotalLibras)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTotalLibras)
        Me.panelEncabezado.Controls.Add(Me.celdaLibras)
        Me.panelEncabezado.Controls.Add(Me.etiquetaLibras)
        Me.panelEncabezado.Controls.Add(Me.checkActivar)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaTasa)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.panelEncabezado.Controls.Add(Me.celdaReferencia)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDescripcion)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.panelCliente)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(953, 170)
        Me.panelEncabezado.TabIndex = 1
        '
        'etiquetaSaldo2
        '
        Me.etiquetaSaldo2.AutoSize = True
        Me.etiquetaSaldo2.Location = New System.Drawing.Point(797, 100)
        Me.etiquetaSaldo2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSaldo2.Name = "etiquetaSaldo2"
        Me.etiquetaSaldo2.Size = New System.Drawing.Size(121, 17)
        Me.etiquetaSaldo2.TabIndex = 57
        Me.etiquetaSaldo2.Text = "Pounds Produced"
        '
        'celdaSaldo2
        '
        Me.celdaSaldo2.Location = New System.Drawing.Point(808, 127)
        Me.celdaSaldo2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaSaldo2.Name = "celdaSaldo2"
        Me.celdaSaldo2.ReadOnly = True
        Me.celdaSaldo2.Size = New System.Drawing.Size(99, 22)
        Me.celdaSaldo2.TabIndex = 56
        '
        'celdaSaldo
        '
        Me.celdaSaldo.Location = New System.Drawing.Point(675, 127)
        Me.celdaSaldo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaSaldo.Name = "celdaSaldo"
        Me.celdaSaldo.ReadOnly = True
        Me.celdaSaldo.Size = New System.Drawing.Size(99, 22)
        Me.celdaSaldo.TabIndex = 55
        '
        'etiquetaSaldo
        '
        Me.etiquetaSaldo.AutoSize = True
        Me.etiquetaSaldo.Location = New System.Drawing.Point(671, 100)
        Me.etiquetaSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSaldo.Name = "etiquetaSaldo"
        Me.etiquetaSaldo.Size = New System.Drawing.Size(124, 17)
        Me.etiquetaSaldo.TabIndex = 54
        Me.etiquetaSaldo.Text = "Missing fiber (Lbs)"
        '
        'celdaTotalLibras
        '
        Me.celdaTotalLibras.Location = New System.Drawing.Point(545, 127)
        Me.celdaTotalLibras.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotalLibras.Name = "celdaTotalLibras"
        Me.celdaTotalLibras.ReadOnly = True
        Me.celdaTotalLibras.Size = New System.Drawing.Size(99, 22)
        Me.celdaTotalLibras.TabIndex = 53
        '
        'etiquetaTotalLibras
        '
        Me.etiquetaTotalLibras.AutoSize = True
        Me.etiquetaTotalLibras.Location = New System.Drawing.Point(533, 100)
        Me.etiquetaTotalLibras.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTotalLibras.Name = "etiquetaTotalLibras"
        Me.etiquetaTotalLibras.Size = New System.Drawing.Size(131, 17)
        Me.etiquetaTotalLibras.TabIndex = 52
        Me.etiquetaTotalLibras.Text = "Fiber Needed (Lbs)"
        '
        'celdaLibras
        '
        Me.celdaLibras.Location = New System.Drawing.Point(413, 127)
        Me.celdaLibras.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaLibras.Name = "celdaLibras"
        Me.celdaLibras.Size = New System.Drawing.Size(99, 22)
        Me.celdaLibras.TabIndex = 51
        '
        'etiquetaLibras
        '
        Me.etiquetaLibras.AutoSize = True
        Me.etiquetaLibras.Location = New System.Drawing.Point(395, 100)
        Me.etiquetaLibras.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaLibras.Name = "etiquetaLibras"
        Me.etiquetaLibras.Size = New System.Drawing.Size(129, 17)
        Me.etiquetaLibras.TabIndex = 50
        Me.etiquetaLibras.Text = "Pounds Requested"
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(364, 12)
        Me.checkActivar.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(68, 21)
        Me.checkActivar.TabIndex = 49
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(191, 129)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(33, 23)
        Me.botonMoneda.TabIndex = 48
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(303, 17)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.ReadOnly = True
        Me.celdaIdMoneda.Size = New System.Drawing.Size(31, 22)
        Me.celdaIdMoneda.TabIndex = 47
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(100, 128)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 22)
        Me.celdaMoneda.TabIndex = 46
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(15, 135)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 45
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(294, 127)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 22)
        Me.celdaTasa.TabIndex = 32
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(250, 132)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 31
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(100, 100)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(295, 22)
        Me.celdaReferencia.TabIndex = 24
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(4, 103)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 23
        Me.etiquetaDescripcion.Text = "Description"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(100, 69)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(124, 22)
        Me.celdaNumero.TabIndex = 22
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 71)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(21, 17)
        Me.etiquetaNumero.TabIndex = 21
        Me.etiquetaNumero.Text = "ID"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(6, 43)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 19
        Me.etiquetaAnio.Text = "Year"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(100, 38)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(124, 22)
        Me.celdaAnio.TabIndex = 20
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(100, 10)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(124, 22)
        Me.dtpFecha.TabIndex = 18
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(5, 17)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 17
        Me.etiquetaFecha.Text = "Date"
        '
        'panelCliente
        '
        Me.panelCliente.Controls.Add(Me.botonCliente)
        Me.panelCliente.Controls.Add(Me.celdaIdCliente)
        Me.panelCliente.Controls.Add(Me.celdaCliente)
        Me.panelCliente.Controls.Add(Me.etiquetaCliente)
        Me.panelCliente.Location = New System.Drawing.Point(389, 32)
        Me.panelCliente.Name = "panelCliente"
        Me.panelCliente.Size = New System.Drawing.Size(419, 59)
        Me.panelCliente.TabIndex = 62
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(312, 31)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(33, 23)
        Me.botonCliente.TabIndex = 60
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(101, 2)
        Me.celdaIdCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.ReadOnly = True
        Me.celdaIdCliente.Size = New System.Drawing.Size(53, 22)
        Me.celdaIdCliente.TabIndex = 61
        Me.celdaIdCliente.Visible = False
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(11, 31)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(295, 22)
        Me.celdaCliente.TabIndex = 59
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(8, 12)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(86, 17)
        Me.etiquetaCliente.TabIndex = 58
        Me.etiquetaCliente.Text = "Select Client"
        '
        'panelAbajo
        '
        Me.panelAbajo.Controls.Add(Me.celdaTotal)
        Me.panelAbajo.Controls.Add(Me.etiquetaTotal)
        Me.panelAbajo.Controls.Add(Me.celdaPeso)
        Me.panelAbajo.Controls.Add(Me.etiquetaPeso)
        Me.panelAbajo.Controls.Add(Me.celdaPrecio)
        Me.panelAbajo.Controls.Add(Me.etiquetaPrecio)
        Me.panelAbajo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelAbajo.Location = New System.Drawing.Point(0, 252)
        Me.panelAbajo.Margin = New System.Windows.Forms.Padding(4)
        Me.panelAbajo.Name = "panelAbajo"
        Me.panelAbajo.Size = New System.Drawing.Size(953, 43)
        Me.panelAbajo.TabIndex = 3
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(480, 12)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(124, 22)
        Me.celdaTotal.TabIndex = 25
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(429, 16)
        Me.etiquetaTotal.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTotal.TabIndex = 24
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaPeso
        '
        Me.celdaPeso.Location = New System.Drawing.Point(284, 12)
        Me.celdaPeso.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPeso.Name = "celdaPeso"
        Me.celdaPeso.ReadOnly = True
        Me.celdaPeso.Size = New System.Drawing.Size(124, 22)
        Me.celdaPeso.TabIndex = 23
        '
        'etiquetaPeso
        '
        Me.etiquetaPeso.AutoSize = True
        Me.etiquetaPeso.Location = New System.Drawing.Point(224, 16)
        Me.etiquetaPeso.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPeso.Name = "etiquetaPeso"
        Me.etiquetaPeso.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaPeso.TabIndex = 22
        Me.etiquetaPeso.Text = "Weight"
        '
        'celdaPrecio
        '
        Me.celdaPrecio.Location = New System.Drawing.Point(81, 12)
        Me.celdaPrecio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaPrecio.Name = "celdaPrecio"
        Me.celdaPrecio.ReadOnly = True
        Me.celdaPrecio.Size = New System.Drawing.Size(124, 22)
        Me.celdaPrecio.TabIndex = 21
        Me.celdaPrecio.Visible = False
        '
        'etiquetaPrecio
        '
        Me.etiquetaPrecio.AutoSize = True
        Me.etiquetaPrecio.Location = New System.Drawing.Point(31, 16)
        Me.etiquetaPrecio.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPrecio.Name = "etiquetaPrecio"
        Me.etiquetaPrecio.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaPrecio.TabIndex = 0
        Me.etiquetaPrecio.Text = "Price"
        Me.etiquetaPrecio.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(894, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(894, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmPedidoProduccionHilo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(894, 580)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmPedidoProduccionHilo"
        Me.Text = "frmPedidoProduccionHilo"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelCliente.ResumeLayout(False)
        Me.panelCliente.PerformLayout()
        Me.panelAbajo.ResumeLayout(False)
        Me.panelAbajo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaReferencia As TextBox
    Friend WithEvents etiquetaDescripcion As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents panelAbajo As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents celdaPeso As TextBox
    Friend WithEvents etiquetaPeso As Label
    Friend WithEvents celdaPrecio As TextBox
    Friend WithEvents etiquetaPrecio As Label
    Friend WithEvents etiquetaLibras As Label
    Friend WithEvents celdaSaldo As TextBox
    Friend WithEvents etiquetaSaldo As Label
    Friend WithEvents celdaTotalLibras As TextBox
    Friend WithEvents etiquetaTotalLibras As Label
    Friend WithEvents celdaLibras As TextBox
    Friend WithEvents etiquetaSaldo2 As Label
    Friend WithEvents celdaSaldo2 As TextBox
    Friend WithEvents colRefAnio As DataGridViewTextBoxColumn
    Friend WithEvents colRefCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colRefNum As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaP As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioMedida As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colidMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia1 As DataGridViewTextBoxColumn
    Friend WithEvents colRefLin As DataGridViewTextBoxColumn
    Friend WithEvents colBultoB As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colTasaCambio As DataGridViewTextBoxColumn
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents panelCliente As Panel
End Class
