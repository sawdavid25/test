﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBancos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle34 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle35 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle36 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle37 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle38 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle39 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle40 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle41 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle42 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle43 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle44 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle45 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle46 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle47 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle48 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle49 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle62 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle63 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle50 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle51 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle52 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle53 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle54 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle55 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle56 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle57 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle58 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle59 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle60 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle61 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle64 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle65 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle66 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLIsta = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.celdaMonedaName = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.Label()
        Me.celdaIdBanco = New System.Windows.Forms.Label()
        Me.botonChequera = New System.Windows.Forms.Button()
        Me.celdaChequera = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMonedaClave = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.botonCuentaContable = New System.Windows.Forms.Button()
        Me.celdaPartida = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.botonBanco = New System.Windows.Forms.Button()
        Me.celdaBanco = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.botonTipoCuenta = New System.Windows.Forms.Button()
        Me.celdaTipoCuenta = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaPlazo = New System.Windows.Forms.TextBox()
        Me.celdaSobregiro = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaContacto = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaNoCuenta = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.celdaID_TDoc = New System.Windows.Forms.Label()
        Me.botonTiposDocumentos = New System.Windows.Forms.Button()
        Me.celdaTipoDoc = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaSaldo = New System.Windows.Forms.TextBox()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.etiquetaTipoDoc = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonDebito = New System.Windows.Forms.Button()
        Me.botonDeposito = New System.Windows.Forms.Button()
        Me.botonCredit = New System.Windows.Forms.Button()
        Me.botonCheque = New System.Windows.Forms.Button()
        Me.Panel_Cuenta = New System.Windows.Forms.Panel()
        Me.panelMovimientos = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.celdaSCCost = New System.Windows.Forms.TextBox()
        Me.etiquetaCostCenter = New System.Windows.Forms.Label()
        Me.botonConciliacion = New System.Windows.Forms.Button()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.etiquetaPresupuesto = New System.Windows.Forms.Label()
        Me.celdaSPoliza = New System.Windows.Forms.TextBox()
        Me.etiquetaSPoliza = New System.Windows.Forms.Label()
        Me.etiquetaAnulado = New System.Windows.Forms.Label()
        Me.celdaAnulado = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.panelInfoCheques = New System.Windows.Forms.Panel()
        Me.dgInfCheque = New System.Windows.Forms.DataGridView()
        Me.botonCambiarCategoria = New System.Windows.Forms.Button()
        Me.celdaInfCheque = New System.Windows.Forms.TextBox()
        Me.dgMovimientos = New System.Windows.Forms.DataGridView()
        Me.colSecreto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNUmero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCredito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDebito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoria = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSub = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPresupuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstados = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCostos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbAgregarDoc = New System.Windows.Forms.GroupBox()
        Me.celdaCatMovimiento = New System.Windows.Forms.TextBox()
        Me.celdaCodigoBank = New System.Windows.Forms.Label()
        Me.celdaIDFecha = New System.Windows.Forms.TextBox()
        Me.celdaIDMon = New System.Windows.Forms.Label()
        Me.celdaMoned = New System.Windows.Forms.TextBox()
        Me.casillaAnulada = New System.Windows.Forms.CheckBox()
        Me.celdaIDDocumento = New System.Windows.Forms.TextBox()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.celdaNum = New System.Windows.Forms.TextBox()
        Me.celdaAno = New System.Windows.Forms.TextBox()
        Me.botonDocumento = New System.Windows.Forms.Button()
        Me.casillaEstado = New System.Windows.Forms.CheckBox()
        Me.checkSecreto = New System.Windows.Forms.CheckBox()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.celdaTasaCambio = New System.Windows.Forms.TextBox()
        Me.etiquetaReferencia = New System.Windows.Forms.Label()
        Me.etiquetaTasaCam = New System.Windows.Forms.Label()
        Me.dtpDoc = New System.Windows.Forms.DateTimePicker()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonPolizaContable = New System.Windows.Forms.Button()
        Me.botonAmarrar = New System.Windows.Forms.Button()
        Me.botonCuentaGastos = New System.Windows.Forms.Button()
        Me.botonCuentasContables = New System.Windows.Forms.Button()
        Me.botonAsignarPresupuesto = New System.Windows.Forms.Button()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.celdaGastoCom = New System.Windows.Forms.TextBox()
        Me.etiquetaGastosCom = New System.Windows.Forms.Label()
        Me.celdaNotas = New System.Windows.Forms.TextBox()
        Me.etiquetasNotasObser = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaConcepto = New System.Windows.Forms.TextBox()
        Me.celdaMonto = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaConcepto = New System.Windows.Forms.Label()
        Me.etiquetaMonto = New System.Windows.Forms.Label()
        Me.etiquetaDocumento = New System.Windows.Forms.Label()
        Me.celdaDocumento = New System.Windows.Forms.TextBox()
        Me.panelOtrosImpuestos = New System.Windows.Forms.Panel()
        Me.rbPagoMensual = New System.Windows.Forms.RadioButton()
        Me.rbRetensiones = New System.Windows.Forms.RadioButton()
        Me.rbAsalariados = New System.Windows.Forms.RadioButton()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.rbIVA = New System.Windows.Forms.RadioButton()
        Me.etiquetaCentroCostos = New System.Windows.Forms.Label()
        Me.celdaAnticiposSCompras = New System.Windows.Forms.TextBox()
        Me.celdaMontoDesc = New System.Windows.Forms.TextBox()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.panelFacturasNoteD = New System.Windows.Forms.Panel()
        Me.botonAgregarDoc = New System.Windows.Forms.Button()
        Me.botonQuitarDoc = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.panelCajaChicaLiq = New System.Windows.Forms.Panel()
        Me.dbCajaChicaLiq = New System.Windows.Forms.GroupBox()
        Me.EtiquetaAnticipo = New System.Windows.Forms.Label()
        Me.panelFacturas = New System.Windows.Forms.Panel()
        Me.PanelFact = New System.Windows.Forms.Panel()
        Me.etiquetaFactura = New System.Windows.Forms.TextBox()
        Me.botopnQuita = New System.Windows.Forms.Button()
        Me.botnAgrega = New System.Windows.Forms.Button()
        Me.etiquetaCobro = New System.Windows.Forms.TextBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.dgCobros = New System.Windows.Forms.DataGridView()
        Me.etiquetaDiferencia = New System.Windows.Forms.Label()
        Me.celdaCajaInfo = New System.Windows.Forms.TextBox()
        Me.etiquetaCuentaCont = New System.Windows.Forms.Label()
        Me.celdaIDCajas = New System.Windows.Forms.TextBox()
        Me.etiquetaCC = New System.Windows.Forms.Label()
        Me.botonQuintarCC = New System.Windows.Forms.Button()
        Me.etiquetaBeneficiario = New System.Windows.Forms.Label()
        Me.celdaCuentaCont = New System.Windows.Forms.TextBox()
        Me.botonCC = New System.Windows.Forms.Button()
        Me.celdaBeneficiario = New System.Windows.Forms.TextBox()
        Me.celdaDiferencia = New System.Windows.Forms.TextBox()
        Me.botonCajas = New System.Windows.Forms.Button()
        Me.celdaCajas = New System.Windows.Forms.TextBox()
        Me.panelCajaChica = New System.Windows.Forms.Panel()
        Me.celdaCajaChica = New System.Windows.Forms.TextBox()
        Me.panelDocumentoDetalle = New System.Windows.Forms.Panel()
        Me.panelBotonesCompras = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.panelCompras = New System.Windows.Forms.Panel()
        Me.dgVentas = New System.Windows.Forms.DataGridView()
        Me.colFech = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEmisor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNCheque = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMont = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgComprs = New System.Windows.Forms.DataGridView()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRetAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRetNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTip = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colOperacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDDoc_RF2_Cod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelRegreso = New System.Windows.Forms.Panel()
        Me.gdRegreso = New System.Windows.Forms.GroupBox()
        Me.panelRegres = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.celdaRegreso = New System.Windows.Forms.TextBox()
        Me.celdaInfoAdd = New System.Windows.Forms.TextBox()
        Me.panelResuDeposito = New System.Windows.Forms.Panel()
        Me.gbResumenDeposito = New System.Windows.Forms.GroupBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaSumaCostos = New System.Windows.Forms.Label()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaOtrosBancos = New System.Windows.Forms.TextBox()
        Me.etiquetaOtrosBancos = New System.Windows.Forms.Label()
        Me.celdaCheck = New System.Windows.Forms.TextBox()
        Me.etiquetCheques = New System.Windows.Forms.Label()
        Me.celdaEfectivo = New System.Windows.Forms.TextBox()
        Me.etiquetaEfectivo = New System.Windows.Forms.Label()
        Me.panelOtraCuenta = New System.Windows.Forms.Panel()
        Me.gbOtraCuenta = New System.Windows.Forms.GroupBox()
        Me.botonCuentaCont = New System.Windows.Forms.Button()
        Me.checkCuentaExterna = New System.Windows.Forms.CheckBox()
        Me.celdaEtiquetaContable = New System.Windows.Forms.TextBox()
        Me.etiquetaCuentaContable = New System.Windows.Forms.Label()
        Me.celdaNombreCuenta = New System.Windows.Forms.TextBox()
        Me.etiquetaNombreCuenta = New System.Windows.Forms.Label()
        Me.panelDatosProveedores = New System.Windows.Forms.Panel()
        Me.gbDatosProveedor = New System.Windows.Forms.GroupBox()
        Me.checkGastosMultiples = New System.Windows.Forms.CheckBox()
        Me.celdaIDDatos = New System.Windows.Forms.TextBox()
        Me.etiquetaREF = New System.Windows.Forms.Label()
        Me.botonDatosProveedor = New System.Windows.Forms.Button()
        Me.celdaNomEmisor = New System.Windows.Forms.TextBox()
        Me.celdaDatosProvee = New System.Windows.Forms.TextBox()
        Me.etiquetaNomEmisor = New System.Windows.Forms.Label()
        Me.panelTipoTransaccion = New System.Windows.Forms.Panel()
        Me.panelEmpleado = New System.Windows.Forms.Panel()
        Me.rbDevolucion = New System.Windows.Forms.RadioButton()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.celdaMensaje3 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.rbAntPrestamo = New System.Windows.Forms.RadioButton()
        Me.panelTransferencia = New System.Windows.Forms.Panel()
        Me.rbContraGasto = New System.Windows.Forms.RadioButton()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.celdaMensaje4 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.rbDepositos = New System.Windows.Forms.RadioButton()
        Me.panelCajaChi = New System.Windows.Forms.Panel()
        Me.rbCobro = New System.Windows.Forms.RadioButton()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.celdaMensaje2 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.rbCierre = New System.Windows.Forms.RadioButton()
        Me.rbAntViaticos = New System.Windows.Forms.RadioButton()
        Me.rbApertura = New System.Windows.Forms.RadioButton()
        Me.rbLiquidacion = New System.Windows.Forms.RadioButton()
        Me.panelProveedores = New System.Windows.Forms.Panel()
        Me.celdaGrupo = New System.Windows.Forms.TextBox()
        Me.rbImpuesto = New System.Windows.Forms.RadioButton()
        Me.celdaMensaje = New System.Windows.Forms.TextBox()
        Me.rbPago = New System.Windows.Forms.RadioButton()
        Me.celdaValorRB = New System.Windows.Forms.TextBox()
        Me.rbAnticipoSCompras = New System.Windows.Forms.RadioButton()
        Me.rbGasto = New System.Windows.Forms.RadioButton()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.dgCompras = New System.Windows.Forms.DataGridView()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelInAdicional = New System.Windows.Forms.Panel()
        Me.celdaTotaLetras = New System.Windows.Forms.TextBox()
        Me.panelCajChiViatics = New System.Windows.Forms.Panel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.BarraTitulo6 = New KARIMs_SGI.BarraTitulo()
        Me.BarraTitulo3 = New KARIMs_SGI.BarraTitulo()
        Me.BarraTitulo2 = New KARIMs_SGI.BarraTitulo()
        Me.BarraTitulo7 = New KARIMs_SGI.BarraTitulo()
        Me.BarraTitulo4 = New KARIMs_SGI.BarraTitulo()
        Me.BarraTitulo5 = New KARIMs_SGI.BarraTitulo()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.panelLIsta.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel_Cuenta.SuspendLayout()
        Me.panelMovimientos.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.panelInfoCheques.SuspendLayout()
        CType(Me.dgInfCheque, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgMovimientos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbAgregarDoc.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelOtrosImpuestos.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.panelFacturasNoteD.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelCajaChicaLiq.SuspendLayout()
        Me.dbCajaChicaLiq.SuspendLayout()
        Me.panelFacturas.SuspendLayout()
        CType(Me.dgCobros, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelCajaChica.SuspendLayout()
        Me.panelDocumentoDetalle.SuspendLayout()
        Me.panelBotonesCompras.SuspendLayout()
        Me.panelCompras.SuspendLayout()
        CType(Me.dgVentas, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgComprs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelRegreso.SuspendLayout()
        Me.gdRegreso.SuspendLayout()
        Me.panelRegres.SuspendLayout()
        Me.panelResuDeposito.SuspendLayout()
        Me.gbResumenDeposito.SuspendLayout()
        Me.panelOtraCuenta.SuspendLayout()
        Me.gbOtraCuenta.SuspendLayout()
        Me.panelDatosProveedores.SuspendLayout()
        Me.gbDatosProveedor.SuspendLayout()
        Me.panelTipoTransaccion.SuspendLayout()
        Me.panelEmpleado.SuspendLayout()
        Me.panelTransferencia.SuspendLayout()
        Me.panelCajaChi.SuspendLayout()
        Me.panelProveedores.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.dgCompras, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.panelInAdicional.SuspendLayout()
        Me.panelCajChiViatics.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLIsta
        '
        Me.panelLIsta.Controls.Add(Me.dgLista)
        Me.panelLIsta.Location = New System.Drawing.Point(19, 153)
        Me.panelLIsta.Name = "panelLIsta"
        Me.panelLIsta.Size = New System.Drawing.Size(179, 79)
        Me.panelLIsta.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle34.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle34
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle35.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle35.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle35
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle36.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle36
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(179, 79)
        Me.dgLista.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.celdaMonedaName)
        Me.Panel2.Controls.Add(Me.celdaIdMoneda)
        Me.Panel2.Controls.Add(Me.celdaIdBanco)
        Me.Panel2.Controls.Add(Me.botonChequera)
        Me.Panel2.Controls.Add(Me.celdaChequera)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.botonMoneda)
        Me.Panel2.Controls.Add(Me.celdaMonedaClave)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.botonCuentaContable)
        Me.Panel2.Controls.Add(Me.celdaPartida)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.botonBanco)
        Me.Panel2.Controls.Add(Me.celdaBanco)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.botonTipoCuenta)
        Me.Panel2.Controls.Add(Me.celdaTipoCuenta)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.celdaPlazo)
        Me.Panel2.Controls.Add(Me.celdaSobregiro)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.celdaContacto)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.celdaNombre)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.celdaNoCuenta)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.celdaCodigo)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(825, 228)
        Me.Panel2.TabIndex = 3
        '
        'celdaMonedaName
        '
        Me.celdaMonedaName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMonedaName.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMonedaName.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMonedaName.ForeColor = System.Drawing.Color.Green
        Me.celdaMonedaName.Location = New System.Drawing.Point(617, 146)
        Me.celdaMonedaName.Name = "celdaMonedaName"
        Me.celdaMonedaName.Size = New System.Drawing.Size(87, 19)
        Me.celdaMonedaName.TabIndex = 29
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.AutoSize = True
        Me.celdaIdMoneda.Location = New System.Drawing.Point(595, 128)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(16, 13)
        Me.celdaIdMoneda.TabIndex = 28
        Me.celdaIdMoneda.Text = "-1"
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdBanco
        '
        Me.celdaIdBanco.AutoSize = True
        Me.celdaIdBanco.Location = New System.Drawing.Point(289, 72)
        Me.celdaIdBanco.Name = "celdaIdBanco"
        Me.celdaIdBanco.Size = New System.Drawing.Size(16, 13)
        Me.celdaIdBanco.TabIndex = 27
        Me.celdaIdBanco.Text = "-1"
        Me.celdaIdBanco.Visible = False
        '
        'botonChequera
        '
        Me.botonChequera.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonChequera.Location = New System.Drawing.Point(711, 182)
        Me.botonChequera.Name = "botonChequera"
        Me.botonChequera.Size = New System.Drawing.Size(29, 23)
        Me.botonChequera.TabIndex = 26
        Me.botonChequera.Text = "..."
        Me.botonChequera.UseVisualStyleBackColor = True
        '
        'celdaChequera
        '
        Me.celdaChequera.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaChequera.Location = New System.Drawing.Point(500, 185)
        Me.celdaChequera.Name = "celdaChequera"
        Me.celdaChequera.ReadOnly = True
        Me.celdaChequera.Size = New System.Drawing.Size(205, 20)
        Me.celdaChequera.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(496, 169)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(191, 13)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "Last number of the current checkbook."
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(582, 144)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(29, 23)
        Me.botonMoneda.TabIndex = 23
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMonedaClave
        '
        Me.celdaMonedaClave.Location = New System.Drawing.Point(500, 146)
        Me.celdaMonedaClave.Name = "celdaMonedaClave"
        Me.celdaMonedaClave.ReadOnly = True
        Me.celdaMonedaClave.Size = New System.Drawing.Size(78, 20)
        Me.celdaMonedaClave.TabIndex = 22
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(496, 130)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "Currency"
        '
        'botonCuentaContable
        '
        Me.botonCuentaContable.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCuentaContable.Location = New System.Drawing.Point(711, 104)
        Me.botonCuentaContable.Name = "botonCuentaContable"
        Me.botonCuentaContable.Size = New System.Drawing.Size(29, 23)
        Me.botonCuentaContable.TabIndex = 20
        Me.botonCuentaContable.Text = "..."
        Me.botonCuentaContable.UseVisualStyleBackColor = True
        '
        'celdaPartida
        '
        Me.celdaPartida.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPartida.Location = New System.Drawing.Point(500, 107)
        Me.celdaPartida.Name = "celdaPartida"
        Me.celdaPartida.ReadOnly = True
        Me.celdaPartida.Size = New System.Drawing.Size(205, 20)
        Me.celdaPartida.TabIndex = 19
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(496, 91)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(83, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Accounting item"
        '
        'botonBanco
        '
        Me.botonBanco.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonBanco.Location = New System.Drawing.Point(711, 65)
        Me.botonBanco.Name = "botonBanco"
        Me.botonBanco.Size = New System.Drawing.Size(29, 23)
        Me.botonBanco.TabIndex = 17
        Me.botonBanco.Text = "..."
        Me.botonBanco.UseVisualStyleBackColor = True
        '
        'celdaBanco
        '
        Me.celdaBanco.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaBanco.Location = New System.Drawing.Point(500, 68)
        Me.celdaBanco.Name = "celdaBanco"
        Me.celdaBanco.ReadOnly = True
        Me.celdaBanco.Size = New System.Drawing.Size(205, 20)
        Me.celdaBanco.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(496, 52)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Bank"
        '
        'botonTipoCuenta
        '
        Me.botonTipoCuenta.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonTipoCuenta.Location = New System.Drawing.Point(711, 26)
        Me.botonTipoCuenta.Name = "botonTipoCuenta"
        Me.botonTipoCuenta.Size = New System.Drawing.Size(29, 23)
        Me.botonTipoCuenta.TabIndex = 14
        Me.botonTipoCuenta.Text = "..."
        Me.botonTipoCuenta.UseVisualStyleBackColor = True
        '
        'celdaTipoCuenta
        '
        Me.celdaTipoCuenta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTipoCuenta.Location = New System.Drawing.Point(500, 29)
        Me.celdaTipoCuenta.Name = "celdaTipoCuenta"
        Me.celdaTipoCuenta.ReadOnly = True
        Me.celdaTipoCuenta.Size = New System.Drawing.Size(205, 20)
        Me.celdaTipoCuenta.TabIndex = 13
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(496, 13)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Account type"
        '
        'celdaPlazo
        '
        Me.celdaPlazo.Location = New System.Drawing.Point(152, 185)
        Me.celdaPlazo.Name = "celdaPlazo"
        Me.celdaPlazo.ReadOnly = True
        Me.celdaPlazo.Size = New System.Drawing.Size(130, 20)
        Me.celdaPlazo.TabIndex = 11
        '
        'celdaSobregiro
        '
        Me.celdaSobregiro.Location = New System.Drawing.Point(22, 185)
        Me.celdaSobregiro.Name = "celdaSobregiro"
        Me.celdaSobregiro.ReadOnly = True
        Me.celdaSobregiro.Size = New System.Drawing.Size(124, 20)
        Me.celdaSobregiro.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(163, 169)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Term"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(24, 169)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Overdraft"
        '
        'celdaContacto
        '
        Me.celdaContacto.Location = New System.Drawing.Point(22, 146)
        Me.celdaContacto.Name = "celdaContacto"
        Me.celdaContacto.ReadOnly = True
        Me.celdaContacto.Size = New System.Drawing.Size(260, 20)
        Me.celdaContacto.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 130)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Contact"
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(22, 107)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.ReadOnly = True
        Me.celdaNombre.Size = New System.Drawing.Size(260, 20)
        Me.celdaNombre.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 91)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Name"
        '
        'celdaNoCuenta
        '
        Me.celdaNoCuenta.Location = New System.Drawing.Point(22, 68)
        Me.celdaNoCuenta.Name = "celdaNoCuenta"
        Me.celdaNoCuenta.ReadOnly = True
        Me.celdaNoCuenta.Size = New System.Drawing.Size(260, 20)
        Me.celdaNoCuenta.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Bank account"
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Location = New System.Drawing.Point(22, 29)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(100, 20)
        Me.celdaCodigo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Code"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.botonImprimir)
        Me.Panel3.Controls.Add(Me.celdaID_TDoc)
        Me.Panel3.Controls.Add(Me.botonTiposDocumentos)
        Me.Panel3.Controls.Add(Me.celdaTipoDoc)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.celdaSaldo)
        Me.Panel3.Controls.Add(Me.botonActualizar)
        Me.Panel3.Controls.Add(Me.Label14)
        Me.Panel3.Controls.Add(Me.Label13)
        Me.Panel3.Controls.Add(Me.etiquetaTipoDoc)
        Me.Panel3.Controls.Add(Me.dtpFin)
        Me.Panel3.Controls.Add(Me.dtpInicio)
        Me.Panel3.Controls.Add(Me.botonDebito)
        Me.Panel3.Controls.Add(Me.botonDeposito)
        Me.Panel3.Controls.Add(Me.botonCredit)
        Me.Panel3.Controls.Add(Me.botonCheque)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel3.Location = New System.Drawing.Point(0, 228)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(825, 50)
        Me.Panel3.TabIndex = 4
        '
        'celdaID_TDoc
        '
        Me.celdaID_TDoc.AutoSize = True
        Me.celdaID_TDoc.Location = New System.Drawing.Point(334, 11)
        Me.celdaID_TDoc.Name = "celdaID_TDoc"
        Me.celdaID_TDoc.Size = New System.Drawing.Size(16, 13)
        Me.celdaID_TDoc.TabIndex = 28
        Me.celdaID_TDoc.Text = "-1"
        Me.celdaID_TDoc.Visible = False
        '
        'botonTiposDocumentos
        '
        Me.botonTiposDocumentos.Location = New System.Drawing.Point(354, 24)
        Me.botonTiposDocumentos.Name = "botonTiposDocumentos"
        Me.botonTiposDocumentos.Size = New System.Drawing.Size(24, 20)
        Me.botonTiposDocumentos.TabIndex = 27
        Me.botonTiposDocumentos.Text = "..."
        Me.botonTiposDocumentos.UseVisualStyleBackColor = True
        '
        'celdaTipoDoc
        '
        Me.celdaTipoDoc.Location = New System.Drawing.Point(236, 24)
        Me.celdaTipoDoc.Name = "celdaTipoDoc"
        Me.celdaTipoDoc.Size = New System.Drawing.Size(116, 20)
        Me.celdaTipoDoc.TabIndex = 13
        '
        'Label15
        '
        Me.Label15.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(733, 9)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(82, 13)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Current balance"
        '
        'celdaSaldo
        '
        Me.celdaSaldo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSaldo.Location = New System.Drawing.Point(719, 25)
        Me.celdaSaldo.Name = "celdaSaldo"
        Me.celdaSaldo.Size = New System.Drawing.Size(100, 20)
        Me.celdaSaldo.TabIndex = 11
        Me.celdaSaldo.Text = "0.00"
        Me.celdaSaldo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonActualizar
        '
        Me.botonActualizar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonActualizar.Location = New System.Drawing.Point(597, 14)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(52, 30)
        Me.botonActualizar.TabIndex = 10
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(511, 7)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(53, 13)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "End date."
        '
        'Label13
        '
        Me.Label13.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(394, 7)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 13)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Start date"
        '
        'etiquetaTipoDoc
        '
        Me.etiquetaTipoDoc.AutoSize = True
        Me.etiquetaTipoDoc.Location = New System.Drawing.Point(251, 10)
        Me.etiquetaTipoDoc.Name = "etiquetaTipoDoc"
        Me.etiquetaTipoDoc.Size = New System.Drawing.Size(79, 13)
        Me.etiquetaTipoDoc.TabIndex = 7
        Me.etiquetaTipoDoc.Text = "Document type"
        '
        'dtpFin
        '
        Me.dtpFin.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(491, 21)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(100, 20)
        Me.dtpFin.TabIndex = 6
        '
        'dtpInicio
        '
        Me.dtpInicio.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(384, 20)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(100, 20)
        Me.dtpInicio.TabIndex = 5
        '
        'botonDebito
        '
        Me.botonDebito.Image = Global.KARIMs_SGI.My.Resources.Resources.minus
        Me.botonDebito.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonDebito.Location = New System.Drawing.Point(172, 8)
        Me.botonDebito.Name = "botonDebito"
        Me.botonDebito.Size = New System.Drawing.Size(51, 38)
        Me.botonDebito.TabIndex = 3
        Me.botonDebito.Text = "Debit"
        Me.botonDebito.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonDebito.UseVisualStyleBackColor = True
        '
        'botonDeposito
        '
        Me.botonDeposito.Image = Global.KARIMs_SGI.My.Resources.Resources.currency1
        Me.botonDeposito.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonDeposito.Location = New System.Drawing.Point(5, 6)
        Me.botonDeposito.Name = "botonDeposito"
        Me.botonDeposito.Size = New System.Drawing.Size(52, 38)
        Me.botonDeposito.TabIndex = 0
        Me.botonDeposito.Text = "Deposit"
        Me.botonDeposito.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonDeposito.UseVisualStyleBackColor = True
        '
        'botonCredit
        '
        Me.botonCredit.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonCredit.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCredit.Location = New System.Drawing.Point(63, 7)
        Me.botonCredit.Name = "botonCredit"
        Me.botonCredit.Size = New System.Drawing.Size(47, 38)
        Me.botonCredit.TabIndex = 1
        Me.botonCredit.Text = "Credit"
        Me.botonCredit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCredit.UseVisualStyleBackColor = True
        '
        'botonCheque
        '
        Me.botonCheque.Image = Global.KARIMs_SGI.My.Resources.Resources.edit_2
        Me.botonCheque.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCheque.Location = New System.Drawing.Point(116, 8)
        Me.botonCheque.Name = "botonCheque"
        Me.botonCheque.Size = New System.Drawing.Size(50, 38)
        Me.botonCheque.TabIndex = 2
        Me.botonCheque.Text = "Check"
        Me.botonCheque.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCheque.UseVisualStyleBackColor = True
        '
        'Panel_Cuenta
        '
        Me.Panel_Cuenta.Controls.Add(Me.panelMovimientos)
        Me.Panel_Cuenta.Controls.Add(Me.Panel3)
        Me.Panel_Cuenta.Controls.Add(Me.Panel2)
        Me.Panel_Cuenta.Location = New System.Drawing.Point(204, 105)
        Me.Panel_Cuenta.Name = "Panel_Cuenta"
        Me.Panel_Cuenta.Size = New System.Drawing.Size(825, 500)
        Me.Panel_Cuenta.TabIndex = 5
        '
        'panelMovimientos
        '
        Me.panelMovimientos.Controls.Add(Me.Panel8)
        Me.panelMovimientos.Controls.Add(Me.dgMovimientos)
        Me.panelMovimientos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelMovimientos.Location = New System.Drawing.Point(0, 278)
        Me.panelMovimientos.Name = "panelMovimientos"
        Me.panelMovimientos.Size = New System.Drawing.Size(825, 222)
        Me.panelMovimientos.TabIndex = 6
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.Panel4)
        Me.Panel8.Controls.Add(Me.panelInfoCheques)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel8.Location = New System.Drawing.Point(0, 141)
        Me.Panel8.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(825, 81)
        Me.Panel8.TabIndex = 7
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.celdaSCCost)
        Me.Panel4.Controls.Add(Me.etiquetaCostCenter)
        Me.Panel4.Controls.Add(Me.botonConciliacion)
        Me.Panel4.Controls.Add(Me.TextBox7)
        Me.Panel4.Controls.Add(Me.etiquetaPresupuesto)
        Me.Panel4.Controls.Add(Me.celdaSPoliza)
        Me.Panel4.Controls.Add(Me.etiquetaSPoliza)
        Me.Panel4.Controls.Add(Me.etiquetaAnulado)
        Me.Panel4.Controls.Add(Me.celdaAnulado)
        Me.Panel4.Controls.Add(Me.TextBox8)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel4.Location = New System.Drawing.Point(517, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(308, 81)
        Me.Panel4.TabIndex = 8
        '
        'celdaSCCost
        '
        Me.celdaSCCost.BackColor = System.Drawing.Color.Lime
        Me.celdaSCCost.Location = New System.Drawing.Point(20, 39)
        Me.celdaSCCost.Multiline = True
        Me.celdaSCCost.Name = "celdaSCCost"
        Me.celdaSCCost.Size = New System.Drawing.Size(14, 14)
        Me.celdaSCCost.TabIndex = 25
        '
        'etiquetaCostCenter
        '
        Me.etiquetaCostCenter.AutoSize = True
        Me.etiquetaCostCenter.Location = New System.Drawing.Point(38, 41)
        Me.etiquetaCostCenter.Name = "etiquetaCostCenter"
        Me.etiquetaCostCenter.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaCostCenter.TabIndex = 26
        Me.etiquetaCostCenter.Tag = ""
        Me.etiquetaCostCenter.Text = "Cost Center"
        '
        'botonConciliacion
        '
        Me.botonConciliacion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonConciliacion.Image = Global.KARIMs_SGI.My.Resources.Resources.cabinet2
        Me.botonConciliacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonConciliacion.Location = New System.Drawing.Point(223, 28)
        Me.botonConciliacion.Name = "botonConciliacion"
        Me.botonConciliacion.Size = New System.Drawing.Size(69, 41)
        Me.botonConciliacion.TabIndex = 24
        Me.botonConciliacion.Text = "Conciliation"
        Me.botonConciliacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonConciliacion.UseVisualStyleBackColor = True
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.LightSteelBlue
        Me.TextBox7.Location = New System.Drawing.Point(195, 11)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(14, 14)
        Me.TextBox7.TabIndex = 20
        '
        'etiquetaPresupuesto
        '
        Me.etiquetaPresupuesto.AutoSize = True
        Me.etiquetaPresupuesto.Location = New System.Drawing.Point(210, 12)
        Me.etiquetaPresupuesto.Name = "etiquetaPresupuesto"
        Me.etiquetaPresupuesto.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaPresupuesto.TabIndex = 23
        Me.etiquetaPresupuesto.Text = "Estimation"
        '
        'celdaSPoliza
        '
        Me.celdaSPoliza.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.celdaSPoliza.Location = New System.Drawing.Point(20, 10)
        Me.celdaSPoliza.Multiline = True
        Me.celdaSPoliza.Name = "celdaSPoliza"
        Me.celdaSPoliza.Size = New System.Drawing.Size(14, 14)
        Me.celdaSPoliza.TabIndex = 18
        '
        'etiquetaSPoliza
        '
        Me.etiquetaSPoliza.AutoSize = True
        Me.etiquetaSPoliza.Location = New System.Drawing.Point(38, 12)
        Me.etiquetaSPoliza.Name = "etiquetaSPoliza"
        Me.etiquetaSPoliza.Size = New System.Drawing.Size(75, 13)
        Me.etiquetaSPoliza.TabIndex = 19
        Me.etiquetaSPoliza.Text = "Without Policy"
        '
        'etiquetaAnulado
        '
        Me.etiquetaAnulado.AutoSize = True
        Me.etiquetaAnulado.Location = New System.Drawing.Point(135, 12)
        Me.etiquetaAnulado.Name = "etiquetaAnulado"
        Me.etiquetaAnulado.Size = New System.Drawing.Size(48, 13)
        Me.etiquetaAnulado.TabIndex = 22
        Me.etiquetaAnulado.Text = "Annulled"
        '
        'celdaAnulado
        '
        Me.celdaAnulado.BackColor = System.Drawing.Color.Red
        Me.celdaAnulado.Location = New System.Drawing.Point(119, 11)
        Me.celdaAnulado.Multiline = True
        Me.celdaAnulado.Name = "celdaAnulado"
        Me.celdaAnulado.Size = New System.Drawing.Size(14, 14)
        Me.celdaAnulado.TabIndex = 21
        '
        'TextBox8
        '
        Me.TextBox8.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox8.Location = New System.Drawing.Point(13, 8)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(284, 64)
        Me.TextBox8.TabIndex = 0
        '
        'panelInfoCheques
        '
        Me.panelInfoCheques.Controls.Add(Me.dgInfCheque)
        Me.panelInfoCheques.Controls.Add(Me.botonCambiarCategoria)
        Me.panelInfoCheques.Controls.Add(Me.celdaInfCheque)
        Me.panelInfoCheques.Controls.Add(Me.BarraTitulo7)
        Me.panelInfoCheques.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelInfoCheques.Location = New System.Drawing.Point(0, 0)
        Me.panelInfoCheques.Name = "panelInfoCheques"
        Me.panelInfoCheques.Size = New System.Drawing.Size(469, 81)
        Me.panelInfoCheques.TabIndex = 7
        '
        'dgInfCheque
        '
        Me.dgInfCheque.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle37.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle37.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgInfCheque.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle37
        Me.dgInfCheque.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle38.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgInfCheque.DefaultCellStyle = DataGridViewCellStyle38
        Me.dgInfCheque.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgInfCheque.Location = New System.Drawing.Point(0, 30)
        Me.dgInfCheque.Name = "dgInfCheque"
        DataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle39.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle39.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle39.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgInfCheque.RowHeadersDefaultCellStyle = DataGridViewCellStyle39
        Me.dgInfCheque.Size = New System.Drawing.Size(469, 51)
        Me.dgInfCheque.TabIndex = 37
        '
        'botonCambiarCategoria
        '
        Me.botonCambiarCategoria.Location = New System.Drawing.Point(428, 8)
        Me.botonCambiarCategoria.Name = "botonCambiarCategoria"
        Me.botonCambiarCategoria.Size = New System.Drawing.Size(32, 23)
        Me.botonCambiarCategoria.TabIndex = 36
        Me.botonCambiarCategoria.Text = "..."
        Me.botonCambiarCategoria.UseVisualStyleBackColor = True
        '
        'celdaInfCheque
        '
        Me.celdaInfCheque.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfCheque.Location = New System.Drawing.Point(322, 10)
        Me.celdaInfCheque.Name = "celdaInfCheque"
        Me.celdaInfCheque.Size = New System.Drawing.Size(100, 20)
        Me.celdaInfCheque.TabIndex = 11
        Me.celdaInfCheque.Text = "0.00"
        Me.celdaInfCheque.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'dgMovimientos
        '
        Me.dgMovimientos.AllowUserToAddRows = False
        Me.dgMovimientos.AllowUserToDeleteRows = False
        Me.dgMovimientos.AllowUserToOrderColumns = True
        Me.dgMovimientos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        DataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle40.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle40.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle40.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle40.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle40.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgMovimientos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle40
        Me.dgMovimientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgMovimientos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colSecreto, Me.colTipo, Me.colAño, Me.colNUmero, Me.colFecha, Me.colDocumento, Me.colReferencia, Me.colDato, Me.colCredito, Me.colDebito, Me.colSaldo, Me.colConcepto, Me.colCategoria, Me.colSub, Me.colPoliza, Me.colPresupuesto, Me.colEstados, Me.colCostos})
        DataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle41.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle41.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgMovimientos.DefaultCellStyle = DataGridViewCellStyle41
        Me.dgMovimientos.Location = New System.Drawing.Point(0, 0)
        Me.dgMovimientos.MultiSelect = False
        Me.dgMovimientos.Name = "dgMovimientos"
        Me.dgMovimientos.ReadOnly = True
        DataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle42.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgMovimientos.RowHeadersDefaultCellStyle = DataGridViewCellStyle42
        Me.dgMovimientos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgMovimientos.Size = New System.Drawing.Size(825, 140)
        Me.dgMovimientos.TabIndex = 5
        '
        'colSecreto
        '
        Me.colSecreto.HeaderText = "Secret"
        Me.colSecreto.Name = "colSecreto"
        Me.colSecreto.ReadOnly = True
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colNUmero
        '
        Me.colNUmero.HeaderText = "Number"
        Me.colNUmero.Name = "colNUmero"
        Me.colNUmero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Transaction"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Numero"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colDato
        '
        Me.colDato.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDato.HeaderText = "Dato"
        Me.colDato.Name = "colDato"
        Me.colDato.ReadOnly = True
        Me.colDato.Width = 55
        '
        'colCredito
        '
        Me.colCredito.HeaderText = "Credit"
        Me.colCredito.Name = "colCredito"
        Me.colCredito.ReadOnly = True
        '
        'colDebito
        '
        Me.colDebito.HeaderText = "Debit"
        Me.colDebito.Name = "colDebito"
        Me.colDebito.ReadOnly = True
        '
        'colSaldo
        '
        Me.colSaldo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSaldo.HeaderText = "Saldo"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Width = 59
        '
        'colConcepto
        '
        Me.colConcepto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.Name = "colConcepto"
        Me.colConcepto.ReadOnly = True
        Me.colConcepto.Width = 72
        '
        'colCategoria
        '
        Me.colCategoria.HeaderText = "Category"
        Me.colCategoria.Name = "colCategoria"
        Me.colCategoria.ReadOnly = True
        '
        'colSub
        '
        Me.colSub.HeaderText = "Sub"
        Me.colSub.Name = "colSub"
        Me.colSub.ReadOnly = True
        '
        'colPoliza
        '
        Me.colPoliza.HeaderText = "Policy"
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        '
        'colPresupuesto
        '
        Me.colPresupuesto.HeaderText = "Presupposition"
        Me.colPresupuesto.Name = "colPresupuesto"
        Me.colPresupuesto.ReadOnly = True
        '
        'colEstados
        '
        Me.colEstados.HeaderText = "State"
        Me.colEstados.Name = "colEstados"
        Me.colEstados.ReadOnly = True
        '
        'colCostos
        '
        Me.colCostos.HeaderText = "Cost"
        Me.colCostos.Name = "colCostos"
        Me.colCostos.ReadOnly = True
        '
        'gbAgregarDoc
        '
        Me.gbAgregarDoc.Controls.Add(Me.celdaCatMovimiento)
        Me.gbAgregarDoc.Controls.Add(Me.celdaCodigoBank)
        Me.gbAgregarDoc.Controls.Add(Me.celdaIDFecha)
        Me.gbAgregarDoc.Controls.Add(Me.celdaIDMon)
        Me.gbAgregarDoc.Controls.Add(Me.celdaMoned)
        Me.gbAgregarDoc.Controls.Add(Me.casillaAnulada)
        Me.gbAgregarDoc.Controls.Add(Me.celdaIDDocumento)
        Me.gbAgregarDoc.Controls.Add(Me.celdaTipo)
        Me.gbAgregarDoc.Controls.Add(Me.celdaNum)
        Me.gbAgregarDoc.Controls.Add(Me.celdaAno)
        Me.gbAgregarDoc.Controls.Add(Me.botonDocumento)
        Me.gbAgregarDoc.Controls.Add(Me.casillaEstado)
        Me.gbAgregarDoc.Controls.Add(Me.checkSecreto)
        Me.gbAgregarDoc.Controls.Add(Me.celdaReferencia)
        Me.gbAgregarDoc.Controls.Add(Me.celdaTasaCambio)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaReferencia)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaTasaCam)
        Me.gbAgregarDoc.Controls.Add(Me.dtpDoc)
        Me.gbAgregarDoc.Controls.Add(Me.Panel1)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaFecha)
        Me.gbAgregarDoc.Controls.Add(Me.celdaNumero)
        Me.gbAgregarDoc.Controls.Add(Me.celdaConcepto)
        Me.gbAgregarDoc.Controls.Add(Me.celdaMonto)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaNumero)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaConcepto)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaMonto)
        Me.gbAgregarDoc.Controls.Add(Me.etiquetaDocumento)
        Me.gbAgregarDoc.Controls.Add(Me.celdaDocumento)
        Me.gbAgregarDoc.Location = New System.Drawing.Point(5, 12)
        Me.gbAgregarDoc.Name = "gbAgregarDoc"
        Me.gbAgregarDoc.Size = New System.Drawing.Size(650, 350)
        Me.gbAgregarDoc.TabIndex = 0
        Me.gbAgregarDoc.TabStop = False
        Me.gbAgregarDoc.Text = "Document Data"
        '
        'celdaCatMovimiento
        '
        Me.celdaCatMovimiento.Location = New System.Drawing.Point(202, 5)
        Me.celdaCatMovimiento.Name = "celdaCatMovimiento"
        Me.celdaCatMovimiento.Size = New System.Drawing.Size(16, 20)
        Me.celdaCatMovimiento.TabIndex = 50
        Me.celdaCatMovimiento.Text = "-1"
        Me.celdaCatMovimiento.Visible = False
        '
        'celdaCodigoBank
        '
        Me.celdaCodigoBank.AutoSize = True
        Me.celdaCodigoBank.Location = New System.Drawing.Point(15, 155)
        Me.celdaCodigoBank.Name = "celdaCodigoBank"
        Me.celdaCodigoBank.Size = New System.Drawing.Size(16, 13)
        Me.celdaCodigoBank.TabIndex = 54
        Me.celdaCodigoBank.Text = "-1"
        Me.celdaCodigoBank.Visible = False
        '
        'celdaIDFecha
        '
        Me.celdaIDFecha.Location = New System.Drawing.Point(266, 0)
        Me.celdaIDFecha.Name = "celdaIDFecha"
        Me.celdaIDFecha.Size = New System.Drawing.Size(16, 20)
        Me.celdaIDFecha.TabIndex = 53
        Me.celdaIDFecha.Text = "-1"
        Me.celdaIDFecha.Visible = False
        '
        'celdaIDMon
        '
        Me.celdaIDMon.AutoSize = True
        Me.celdaIDMon.Location = New System.Drawing.Point(44, 134)
        Me.celdaIDMon.Name = "celdaIDMon"
        Me.celdaIDMon.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDMon.TabIndex = 52
        Me.celdaIDMon.Text = "-1"
        Me.celdaIDMon.Visible = False
        '
        'celdaMoned
        '
        Me.celdaMoned.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMoned.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMoned.ForeColor = System.Drawing.Color.Green
        Me.celdaMoned.Location = New System.Drawing.Point(63, 169)
        Me.celdaMoned.Multiline = True
        Me.celdaMoned.Name = "celdaMoned"
        Me.celdaMoned.ReadOnly = True
        Me.celdaMoned.Size = New System.Drawing.Size(179, 21)
        Me.celdaMoned.TabIndex = 50
        Me.celdaMoned.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'casillaAnulada
        '
        Me.casillaAnulada.AutoSize = True
        Me.casillaAnulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.casillaAnulada.ForeColor = System.Drawing.Color.Red
        Me.casillaAnulada.Location = New System.Drawing.Point(513, 62)
        Me.casillaAnulada.Name = "casillaAnulada"
        Me.casillaAnulada.Size = New System.Drawing.Size(72, 17)
        Me.casillaAnulada.TabIndex = 49
        Me.casillaAnulada.Text = "Anulada"
        Me.casillaAnulada.UseVisualStyleBackColor = True
        '
        'celdaIDDocumento
        '
        Me.celdaIDDocumento.Location = New System.Drawing.Point(157, 0)
        Me.celdaIDDocumento.Name = "celdaIDDocumento"
        Me.celdaIDDocumento.Size = New System.Drawing.Size(16, 20)
        Me.celdaIDDocumento.TabIndex = 48
        Me.celdaIDDocumento.Text = "-1"
        Me.celdaIDDocumento.Visible = False
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(361, 0)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.Size = New System.Drawing.Size(15, 20)
        Me.celdaTipo.TabIndex = 46
        Me.celdaTipo.Text = "-1"
        Me.celdaTipo.Visible = False
        '
        'celdaNum
        '
        Me.celdaNum.Location = New System.Drawing.Point(329, -1)
        Me.celdaNum.Name = "celdaNum"
        Me.celdaNum.Size = New System.Drawing.Size(31, 20)
        Me.celdaNum.TabIndex = 45
        Me.celdaNum.Text = "-1"
        Me.celdaNum.Visible = False
        '
        'celdaAno
        '
        Me.celdaAno.Location = New System.Drawing.Point(312, -1)
        Me.celdaAno.Name = "celdaAno"
        Me.celdaAno.Size = New System.Drawing.Size(16, 20)
        Me.celdaAno.TabIndex = 44
        Me.celdaAno.Text = "-1"
        Me.celdaAno.Visible = False
        '
        'botonDocumento
        '
        Me.botonDocumento.Location = New System.Drawing.Point(164, 17)
        Me.botonDocumento.Name = "botonDocumento"
        Me.botonDocumento.Size = New System.Drawing.Size(32, 23)
        Me.botonDocumento.TabIndex = 35
        Me.botonDocumento.Tag = "Tipo Documento"
        Me.botonDocumento.Text = "..."
        Me.botonDocumento.UseVisualStyleBackColor = True
        '
        'casillaEstado
        '
        Me.casillaEstado.AutoSize = True
        Me.casillaEstado.Location = New System.Drawing.Point(513, 45)
        Me.casillaEstado.Name = "casillaEstado"
        Me.casillaEstado.Size = New System.Drawing.Size(62, 17)
        Me.casillaEstado.TabIndex = 33
        Me.casillaEstado.Text = "Cashed"
        Me.casillaEstado.UseVisualStyleBackColor = True
        '
        'checkSecreto
        '
        Me.checkSecreto.AutoSize = True
        Me.checkSecreto.Location = New System.Drawing.Point(513, 30)
        Me.checkSecreto.Name = "checkSecreto"
        Me.checkSecreto.Size = New System.Drawing.Size(57, 17)
        Me.checkSecreto.TabIndex = 32
        Me.checkSecreto.Text = "Secret"
        Me.checkSecreto.UseVisualStyleBackColor = True
        '
        'celdaReferencia
        '
        Me.celdaReferencia.BackColor = System.Drawing.SystemColors.ControlLight
        Me.celdaReferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaReferencia.ForeColor = System.Drawing.Color.MediumBlue
        Me.celdaReferencia.Location = New System.Drawing.Point(460, 182)
        Me.celdaReferencia.Multiline = True
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.ReadOnly = True
        Me.celdaReferencia.Size = New System.Drawing.Size(125, 22)
        Me.celdaReferencia.TabIndex = 24
        '
        'celdaTasaCambio
        '
        Me.celdaTasaCambio.BackColor = System.Drawing.SystemColors.ControlLight
        Me.celdaTasaCambio.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTasaCambio.ForeColor = System.Drawing.SystemColors.ControlText
        Me.celdaTasaCambio.Location = New System.Drawing.Point(460, 157)
        Me.celdaTasaCambio.Multiline = True
        Me.celdaTasaCambio.Name = "celdaTasaCambio"
        Me.celdaTasaCambio.ReadOnly = True
        Me.celdaTasaCambio.Size = New System.Drawing.Size(125, 21)
        Me.celdaTasaCambio.TabIndex = 23
        Me.celdaTasaCambio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaReferencia
        '
        Me.etiquetaReferencia.AutoSize = True
        Me.etiquetaReferencia.Location = New System.Drawing.Point(399, 186)
        Me.etiquetaReferencia.Name = "etiquetaReferencia"
        Me.etiquetaReferencia.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaReferencia.TabIndex = 22
        Me.etiquetaReferencia.Text = "Reference"
        '
        'etiquetaTasaCam
        '
        Me.etiquetaTasaCam.AutoSize = True
        Me.etiquetaTasaCam.Location = New System.Drawing.Point(373, 160)
        Me.etiquetaTasaCam.Name = "etiquetaTasaCam"
        Me.etiquetaTasaCam.Size = New System.Drawing.Size(84, 13)
        Me.etiquetaTasaCam.TabIndex = 21
        Me.etiquetaTasaCam.Text = "Exchange  Rate"
        '
        'dtpDoc
        '
        Me.dtpDoc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDoc.Location = New System.Drawing.Point(396, 19)
        Me.dtpDoc.Name = "dtpDoc"
        Me.dtpDoc.Size = New System.Drawing.Size(96, 20)
        Me.dtpDoc.TabIndex = 20
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.botonPolizaContable)
        Me.Panel1.Controls.Add(Me.botonAmarrar)
        Me.Panel1.Controls.Add(Me.botonCuentaGastos)
        Me.Panel1.Controls.Add(Me.botonCuentasContables)
        Me.Panel1.Controls.Add(Me.botonAsignarPresupuesto)
        Me.Panel1.Controls.Add(Me.checkRevisado)
        Me.Panel1.Controls.Add(Me.celdaGastoCom)
        Me.Panel1.Controls.Add(Me.etiquetaGastosCom)
        Me.Panel1.Controls.Add(Me.celdaNotas)
        Me.Panel1.Controls.Add(Me.etiquetasNotasObser)
        Me.Panel1.Location = New System.Drawing.Point(9, 226)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(622, 114)
        Me.Panel1.TabIndex = 25
        '
        'botonPolizaContable
        '
        Me.botonPolizaContable.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaContable.Location = New System.Drawing.Point(487, 72)
        Me.botonPolizaContable.Name = "botonPolizaContable"
        Me.botonPolizaContable.Size = New System.Drawing.Size(31, 23)
        Me.botonPolizaContable.TabIndex = 33
        Me.botonPolizaContable.UseVisualStyleBackColor = True
        '
        'botonAmarrar
        '
        Me.botonAmarrar.Image = Global.KARIMs_SGI.My.Resources.Resources.book_blue_view
        Me.botonAmarrar.Location = New System.Drawing.Point(123, 3)
        Me.botonAmarrar.Name = "botonAmarrar"
        Me.botonAmarrar.Size = New System.Drawing.Size(32, 23)
        Me.botonAmarrar.TabIndex = 32
        Me.botonAmarrar.UseVisualStyleBackColor = True
        '
        'botonCuentaGastos
        '
        Me.botonCuentaGastos.Image = Global.KARIMs_SGI.My.Resources.Resources.currency1
        Me.botonCuentaGastos.Location = New System.Drawing.Point(450, 50)
        Me.botonCuentaGastos.Name = "botonCuentaGastos"
        Me.botonCuentaGastos.Size = New System.Drawing.Size(32, 23)
        Me.botonCuentaGastos.TabIndex = 31
        Me.botonCuentaGastos.UseVisualStyleBackColor = True
        '
        'botonCuentasContables
        '
        Me.botonCuentasContables.Image = Global.KARIMs_SGI.My.Resources.Resources.align_full_41
        Me.botonCuentasContables.Location = New System.Drawing.Point(487, 50)
        Me.botonCuentasContables.Name = "botonCuentasContables"
        Me.botonCuentasContables.Size = New System.Drawing.Size(31, 23)
        Me.botonCuentasContables.TabIndex = 30
        Me.botonCuentasContables.UseVisualStyleBackColor = True
        '
        'botonAsignarPresupuesto
        '
        Me.botonAsignarPresupuesto.Image = Global.KARIMs_SGI.My.Resources.Resources.cashier2
        Me.botonAsignarPresupuesto.Location = New System.Drawing.Point(450, 72)
        Me.botonAsignarPresupuesto.Name = "botonAsignarPresupuesto"
        Me.botonAsignarPresupuesto.Size = New System.Drawing.Size(32, 23)
        Me.botonAsignarPresupuesto.TabIndex = 29
        Me.botonAsignarPresupuesto.UseVisualStyleBackColor = True
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.Location = New System.Drawing.Point(533, 70)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(74, 17)
        Me.checkRevisado.TabIndex = 28
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        '
        'celdaGastoCom
        '
        Me.celdaGastoCom.Location = New System.Drawing.Point(496, 5)
        Me.celdaGastoCom.Name = "celdaGastoCom"
        Me.celdaGastoCom.Size = New System.Drawing.Size(121, 20)
        Me.celdaGastoCom.TabIndex = 27
        Me.celdaGastoCom.Visible = False
        '
        'etiquetaGastosCom
        '
        Me.etiquetaGastosCom.AutoSize = True
        Me.etiquetaGastosCom.Location = New System.Drawing.Point(383, 8)
        Me.etiquetaGastosCom.Name = "etiquetaGastosCom"
        Me.etiquetaGastosCom.Size = New System.Drawing.Size(101, 13)
        Me.etiquetaGastosCom.TabIndex = 26
        Me.etiquetaGastosCom.Text = "Fees And Expenses"
        Me.etiquetaGastosCom.Visible = False
        '
        'celdaNotas
        '
        Me.celdaNotas.Location = New System.Drawing.Point(20, 26)
        Me.celdaNotas.Multiline = True
        Me.celdaNotas.Name = "celdaNotas"
        Me.celdaNotas.Size = New System.Drawing.Size(424, 83)
        Me.celdaNotas.TabIndex = 25
        '
        'etiquetasNotasObser
        '
        Me.etiquetasNotasObser.AutoSize = True
        Me.etiquetasNotasObser.Location = New System.Drawing.Point(3, 6)
        Me.etiquetasNotasObser.Name = "etiquetasNotasObser"
        Me.etiquetasNotasObser.Size = New System.Drawing.Size(117, 13)
        Me.etiquetasNotasObser.TabIndex = 23
        Me.etiquetasNotasObser.Text = "Note And Observations"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(360, 22)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 19
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.Color.MediumBlue
        Me.celdaNumero.Location = New System.Drawing.Point(63, 42)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(429, 21)
        Me.celdaNumero.TabIndex = 18
        '
        'celdaConcepto
        '
        Me.celdaConcepto.Location = New System.Drawing.Point(63, 64)
        Me.celdaConcepto.Multiline = True
        Me.celdaConcepto.Name = "celdaConcepto"
        Me.celdaConcepto.Size = New System.Drawing.Size(429, 73)
        Me.celdaConcepto.TabIndex = 17
        '
        'celdaMonto
        '
        Me.celdaMonto.Location = New System.Drawing.Point(63, 144)
        Me.celdaMonto.Name = "celdaMonto"
        Me.celdaMonto.Size = New System.Drawing.Size(179, 20)
        Me.celdaMonto.TabIndex = 16
        Me.celdaMonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 45)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 15
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaConcepto
        '
        Me.etiquetaConcepto.AutoSize = True
        Me.etiquetaConcepto.Location = New System.Drawing.Point(6, 67)
        Me.etiquetaConcepto.Name = "etiquetaConcepto"
        Me.etiquetaConcepto.Size = New System.Drawing.Size(47, 13)
        Me.etiquetaConcepto.TabIndex = 14
        Me.etiquetaConcepto.Text = "Concept"
        '
        'etiquetaMonto
        '
        Me.etiquetaMonto.AutoSize = True
        Me.etiquetaMonto.Location = New System.Drawing.Point(6, 147)
        Me.etiquetaMonto.Name = "etiquetaMonto"
        Me.etiquetaMonto.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaMonto.TabIndex = 13
        Me.etiquetaMonto.Text = "Rode"
        '
        'etiquetaDocumento
        '
        Me.etiquetaDocumento.AutoSize = True
        Me.etiquetaDocumento.Location = New System.Drawing.Point(6, 23)
        Me.etiquetaDocumento.Name = "etiquetaDocumento"
        Me.etiquetaDocumento.Size = New System.Drawing.Size(56, 13)
        Me.etiquetaDocumento.TabIndex = 12
        Me.etiquetaDocumento.Text = "Document"
        '
        'celdaDocumento
        '
        Me.celdaDocumento.BackColor = System.Drawing.Color.CornflowerBlue
        Me.celdaDocumento.ForeColor = System.Drawing.SystemColors.Window
        Me.celdaDocumento.Location = New System.Drawing.Point(63, 20)
        Me.celdaDocumento.Name = "celdaDocumento"
        Me.celdaDocumento.ReadOnly = True
        Me.celdaDocumento.Size = New System.Drawing.Size(100, 20)
        Me.celdaDocumento.TabIndex = 11
        '
        'panelOtrosImpuestos
        '
        Me.panelOtrosImpuestos.Controls.Add(Me.rbPagoMensual)
        Me.panelOtrosImpuestos.Controls.Add(Me.rbRetensiones)
        Me.panelOtrosImpuestos.Controls.Add(Me.rbAsalariados)
        Me.panelOtrosImpuestos.Controls.Add(Me.TextBox3)
        Me.panelOtrosImpuestos.Controls.Add(Me.TextBox10)
        Me.panelOtrosImpuestos.Controls.Add(Me.TextBox13)
        Me.panelOtrosImpuestos.Controls.Add(Me.rbIVA)
        Me.panelOtrosImpuestos.Location = New System.Drawing.Point(123, 36)
        Me.panelOtrosImpuestos.Name = "panelOtrosImpuestos"
        Me.panelOtrosImpuestos.Size = New System.Drawing.Size(344, 194)
        Me.panelOtrosImpuestos.TabIndex = 56
        Me.panelOtrosImpuestos.Visible = False
        '
        'rbPagoMensual
        '
        Me.rbPagoMensual.AutoSize = True
        Me.rbPagoMensual.Location = New System.Drawing.Point(52, 143)
        Me.rbPagoMensual.Margin = New System.Windows.Forms.Padding(2)
        Me.rbPagoMensual.Name = "rbPagoMensual"
        Me.rbPagoMensual.Size = New System.Drawing.Size(120, 17)
        Me.rbPagoMensual.TabIndex = 56
        Me.rbPagoMensual.TabStop = True
        Me.rbPagoMensual.Text = "ISR (Pago Mensual)"
        Me.rbPagoMensual.UseVisualStyleBackColor = True
        '
        'rbRetensiones
        '
        Me.rbRetensiones.AutoSize = True
        Me.rbRetensiones.Location = New System.Drawing.Point(52, 118)
        Me.rbRetensiones.Margin = New System.Windows.Forms.Padding(2)
        Me.rbRetensiones.Name = "rbRetensiones"
        Me.rbRetensiones.Size = New System.Drawing.Size(105, 17)
        Me.rbRetensiones.TabIndex = 55
        Me.rbRetensiones.TabStop = True
        Me.rbRetensiones.Text = "ISR Retensiones"
        Me.rbRetensiones.UseVisualStyleBackColor = True
        '
        'rbAsalariados
        '
        Me.rbAsalariados.AutoSize = True
        Me.rbAsalariados.Location = New System.Drawing.Point(52, 94)
        Me.rbAsalariados.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAsalariados.Name = "rbAsalariados"
        Me.rbAsalariados.Size = New System.Drawing.Size(100, 17)
        Me.rbAsalariados.TabIndex = 54
        Me.rbAsalariados.TabStop = True
        Me.rbAsalariados.Text = "ISR Asalariados"
        Me.rbAsalariados.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(307, 7)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(16, 20)
        Me.TextBox3.TabIndex = 53
        Me.TextBox3.Text = "-1"
        Me.TextBox3.Visible = False
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(36, 10)
        Me.TextBox10.Multiline = True
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(257, 27)
        Me.TextBox10.TabIndex = 51
        Me.TextBox10.Visible = False
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(159, 69)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(16, 20)
        Me.TextBox13.TabIndex = 52
        Me.TextBox13.Text = "0"
        Me.TextBox13.Visible = False
        '
        'rbIVA
        '
        Me.rbIVA.AutoSize = True
        Me.rbIVA.Location = New System.Drawing.Point(53, 70)
        Me.rbIVA.Margin = New System.Windows.Forms.Padding(2)
        Me.rbIVA.Name = "rbIVA"
        Me.rbIVA.Size = New System.Drawing.Size(81, 17)
        Me.rbIVA.TabIndex = 36
        Me.rbIVA.TabStop = True
        Me.rbIVA.Text = "IVA x Pagar"
        Me.rbIVA.UseVisualStyleBackColor = True
        '
        'etiquetaCentroCostos
        '
        Me.etiquetaCentroCostos.AutoSize = True
        Me.etiquetaCentroCostos.Location = New System.Drawing.Point(7, 141)
        Me.etiquetaCentroCostos.Name = "etiquetaCentroCostos"
        Me.etiquetaCentroCostos.Size = New System.Drawing.Size(120, 13)
        Me.etiquetaCentroCostos.TabIndex = 41
        Me.etiquetaCentroCostos.Text = "Advance On Purchases"
        Me.etiquetaCentroCostos.Visible = False
        '
        'celdaAnticiposSCompras
        '
        Me.celdaAnticiposSCompras.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAnticiposSCompras.Location = New System.Drawing.Point(745, 266)
        Me.celdaAnticiposSCompras.Name = "celdaAnticiposSCompras"
        Me.celdaAnticiposSCompras.Size = New System.Drawing.Size(399, 20)
        Me.celdaAnticiposSCompras.TabIndex = 40
        Me.celdaAnticiposSCompras.Visible = False
        '
        'celdaMontoDesc
        '
        Me.celdaMontoDesc.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMontoDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMontoDesc.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.celdaMontoDesc.Location = New System.Drawing.Point(19, 62)
        Me.celdaMontoDesc.Name = "celdaMontoDesc"
        Me.celdaMontoDesc.Size = New System.Drawing.Size(93, 20)
        Me.celdaMontoDesc.TabIndex = 34
        Me.celdaMontoDesc.Text = "..."
        Me.celdaMontoDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.panelFacturasNoteD)
        Me.Panel6.Location = New System.Drawing.Point(486, 120)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(332, 200)
        Me.Panel6.TabIndex = 52
        Me.Panel6.Visible = False
        '
        'panelFacturasNoteD
        '
        Me.panelFacturasNoteD.Controls.Add(Me.botonAgregarDoc)
        Me.panelFacturasNoteD.Controls.Add(Me.botonQuitarDoc)
        Me.panelFacturasNoteD.Controls.Add(Me.DataGridView1)
        Me.panelFacturasNoteD.Controls.Add(Me.TextBox5)
        Me.panelFacturasNoteD.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelFacturasNoteD.Location = New System.Drawing.Point(0, 0)
        Me.panelFacturasNoteD.Name = "panelFacturasNoteD"
        Me.panelFacturasNoteD.Size = New System.Drawing.Size(332, 200)
        Me.panelFacturasNoteD.TabIndex = 49
        Me.panelFacturasNoteD.Visible = False
        '
        'botonAgregarDoc
        '
        Me.botonAgregarDoc.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarDoc.Location = New System.Drawing.Point(272, 1)
        Me.botonAgregarDoc.Name = "botonAgregarDoc"
        Me.botonAgregarDoc.Size = New System.Drawing.Size(22, 23)
        Me.botonAgregarDoc.TabIndex = 51
        Me.botonAgregarDoc.Text = "..."
        Me.botonAgregarDoc.UseVisualStyleBackColor = True
        '
        'botonQuitarDoc
        '
        Me.botonQuitarDoc.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonQuitarDoc.Location = New System.Drawing.Point(297, 2)
        Me.botonQuitarDoc.Name = "botonQuitarDoc"
        Me.botonQuitarDoc.Size = New System.Drawing.Size(22, 23)
        Me.botonQuitarDoc.TabIndex = 52
        Me.botonQuitarDoc.Text = "..."
        Me.botonQuitarDoc.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption
        DataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle43.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle43.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle43.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle43.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle43.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle43
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle44.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle44.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle44.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle44.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle44
        Me.DataGridView1.Location = New System.Drawing.Point(3, 29)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle45.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle45.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle45.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle45.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle45.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle45
        Me.DataGridView1.Size = New System.Drawing.Size(331, 82)
        Me.DataGridView1.TabIndex = 24
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.LightSteelBlue
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox5.Location = New System.Drawing.Point(0, 0)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(334, 28)
        Me.TextBox5.TabIndex = 23
        Me.TextBox5.Text = "Invoices / Debit Notes"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'panelCajaChicaLiq
        '
        Me.panelCajaChicaLiq.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelCajaChicaLiq.Controls.Add(Me.dbCajaChicaLiq)
        Me.panelCajaChicaLiq.Location = New System.Drawing.Point(659, 17)
        Me.panelCajaChicaLiq.Name = "panelCajaChicaLiq"
        Me.panelCajaChicaLiq.Size = New System.Drawing.Size(729, 337)
        Me.panelCajaChicaLiq.TabIndex = 29
        Me.panelCajaChicaLiq.Visible = False
        '
        'dbCajaChicaLiq
        '
        Me.dbCajaChicaLiq.Controls.Add(Me.EtiquetaAnticipo)
        Me.dbCajaChicaLiq.Controls.Add(Me.panelFacturas)
        Me.dbCajaChicaLiq.Controls.Add(Me.Button11)
        Me.dbCajaChicaLiq.Controls.Add(Me.Button10)
        Me.dbCajaChicaLiq.Controls.Add(Me.BarraTitulo6)
        Me.dbCajaChicaLiq.Controls.Add(Me.etiquetaCentroCostos)
        Me.dbCajaChicaLiq.Controls.Add(Me.dgCobros)
        Me.dbCajaChicaLiq.Controls.Add(Me.etiquetaDiferencia)
        Me.dbCajaChicaLiq.Controls.Add(Me.celdaCajaInfo)
        Me.dbCajaChicaLiq.Controls.Add(Me.etiquetaCuentaCont)
        Me.dbCajaChicaLiq.Controls.Add(Me.celdaIDCajas)
        Me.dbCajaChicaLiq.Controls.Add(Me.etiquetaCC)
        Me.dbCajaChicaLiq.Controls.Add(Me.botonQuintarCC)
        Me.dbCajaChicaLiq.Controls.Add(Me.etiquetaBeneficiario)
        Me.dbCajaChicaLiq.Controls.Add(Me.celdaCuentaCont)
        Me.dbCajaChicaLiq.Controls.Add(Me.botonCC)
        Me.dbCajaChicaLiq.Controls.Add(Me.celdaBeneficiario)
        Me.dbCajaChicaLiq.Controls.Add(Me.celdaDiferencia)
        Me.dbCajaChicaLiq.Controls.Add(Me.botonCajas)
        Me.dbCajaChicaLiq.Controls.Add(Me.celdaCajas)
        Me.dbCajaChicaLiq.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dbCajaChicaLiq.Location = New System.Drawing.Point(0, 0)
        Me.dbCajaChicaLiq.Name = "dbCajaChicaLiq"
        Me.dbCajaChicaLiq.Size = New System.Drawing.Size(729, 337)
        Me.dbCajaChicaLiq.TabIndex = 0
        Me.dbCajaChicaLiq.TabStop = False
        Me.dbCajaChicaLiq.Text = "Petty Cash / Settlement"
        '
        'EtiquetaAnticipo
        '
        Me.EtiquetaAnticipo.AutoSize = True
        Me.EtiquetaAnticipo.Location = New System.Drawing.Point(7, 243)
        Me.EtiquetaAnticipo.Name = "EtiquetaAnticipo"
        Me.EtiquetaAnticipo.Size = New System.Drawing.Size(120, 13)
        Me.EtiquetaAnticipo.TabIndex = 53
        Me.EtiquetaAnticipo.Text = "Anticipo Sobre Compras"
        Me.EtiquetaAnticipo.Visible = False
        '
        'panelFacturas
        '
        Me.panelFacturas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelFacturas.Controls.Add(Me.PanelFact)
        Me.panelFacturas.Controls.Add(Me.etiquetaFactura)
        Me.panelFacturas.Controls.Add(Me.botopnQuita)
        Me.panelFacturas.Controls.Add(Me.botnAgrega)
        Me.panelFacturas.Controls.Add(Me.etiquetaCobro)
        Me.panelFacturas.Location = New System.Drawing.Point(13, 132)
        Me.panelFacturas.Name = "panelFacturas"
        Me.panelFacturas.Size = New System.Drawing.Size(742, 160)
        Me.panelFacturas.TabIndex = 26
        '
        'PanelFact
        '
        Me.PanelFact.Location = New System.Drawing.Point(0, 53)
        Me.PanelFact.Name = "PanelFact"
        Me.PanelFact.Size = New System.Drawing.Size(726, 100)
        Me.PanelFact.TabIndex = 55
        '
        'etiquetaFactura
        '
        Me.etiquetaFactura.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaFactura.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.etiquetaFactura.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaFactura.ForeColor = System.Drawing.SystemColors.Window
        Me.etiquetaFactura.Location = New System.Drawing.Point(0, 25)
        Me.etiquetaFactura.Multiline = True
        Me.etiquetaFactura.Name = "etiquetaFactura"
        Me.etiquetaFactura.Size = New System.Drawing.Size(689, 25)
        Me.etiquetaFactura.TabIndex = 54
        Me.etiquetaFactura.Text = "Invoices / Debit Notes"
        Me.etiquetaFactura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botopnQuita
        '
        Me.botopnQuita.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botopnQuita.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botopnQuita.Location = New System.Drawing.Point(717, 27)
        Me.botopnQuita.Name = "botopnQuita"
        Me.botopnQuita.Size = New System.Drawing.Size(22, 23)
        Me.botopnQuita.TabIndex = 53
        Me.botopnQuita.Text = "..."
        Me.botopnQuita.UseVisualStyleBackColor = True
        '
        'botnAgrega
        '
        Me.botnAgrega.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botnAgrega.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botnAgrega.Location = New System.Drawing.Point(689, 28)
        Me.botnAgrega.Name = "botnAgrega"
        Me.botnAgrega.Size = New System.Drawing.Size(22, 23)
        Me.botnAgrega.TabIndex = 52
        Me.botnAgrega.UseVisualStyleBackColor = True
        '
        'etiquetaCobro
        '
        Me.etiquetaCobro.BackColor = System.Drawing.Color.DarkGreen
        Me.etiquetaCobro.Dock = System.Windows.Forms.DockStyle.Top
        Me.etiquetaCobro.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCobro.ForeColor = System.Drawing.SystemColors.Window
        Me.etiquetaCobro.Location = New System.Drawing.Point(0, 0)
        Me.etiquetaCobro.Multiline = True
        Me.etiquetaCobro.Name = "etiquetaCobro"
        Me.etiquetaCobro.Size = New System.Drawing.Size(742, 25)
        Me.etiquetaCobro.TabIndex = 24
        Me.etiquetaCobro.Text = "* * * COBRO * * *"
        Me.etiquetaCobro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button11
        '
        Me.Button11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button11.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button11.Location = New System.Drawing.Point(649, 48)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(28, 26)
        Me.Button11.TabIndex = 49
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button10.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.Button10.Location = New System.Drawing.Point(611, 49)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(32, 25)
        Me.Button10.TabIndex = 48
        Me.Button10.UseVisualStyleBackColor = True
        '
        'dgCobros
        '
        Me.dgCobros.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption
        DataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle46.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle46.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCobros.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle46
        Me.dgCobros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle47.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle47.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle47.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle47.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle47.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgCobros.DefaultCellStyle = DataGridViewCellStyle47
        Me.dgCobros.Location = New System.Drawing.Point(116, 208)
        Me.dgCobros.Name = "dgCobros"
        DataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle48.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle48.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle48.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle48.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle48.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCobros.RowHeadersDefaultCellStyle = DataGridViewCellStyle48
        Me.dgCobros.Size = New System.Drawing.Size(479, 89)
        Me.dgCobros.TabIndex = 25
        Me.dgCobros.Visible = False
        '
        'etiquetaDiferencia
        '
        Me.etiquetaDiferencia.AutoSize = True
        Me.etiquetaDiferencia.Location = New System.Drawing.Point(10, 260)
        Me.etiquetaDiferencia.Name = "etiquetaDiferencia"
        Me.etiquetaDiferencia.Size = New System.Drawing.Size(56, 13)
        Me.etiquetaDiferencia.TabIndex = 39
        Me.etiquetaDiferencia.Text = "Difference"
        '
        'celdaCajaInfo
        '
        Me.celdaCajaInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCajaInfo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCajaInfo.Location = New System.Drawing.Point(4, 75)
        Me.celdaCajaInfo.Multiline = True
        Me.celdaCajaInfo.Name = "celdaCajaInfo"
        Me.celdaCajaInfo.Size = New System.Drawing.Size(698, 110)
        Me.celdaCajaInfo.TabIndex = 46
        Me.celdaCajaInfo.Text = "Info..."
        '
        'etiquetaCuentaCont
        '
        Me.etiquetaCuentaCont.AutoSize = True
        Me.etiquetaCuentaCont.Location = New System.Drawing.Point(311, 260)
        Me.etiquetaCuentaCont.Name = "etiquetaCuentaCont"
        Me.etiquetaCuentaCont.Size = New System.Drawing.Size(83, 13)
        Me.etiquetaCuentaCont.TabIndex = 41
        Me.etiquetaCuentaCont.Text = "Ledger Account"
        '
        'celdaIDCajas
        '
        Me.celdaIDCajas.Location = New System.Drawing.Point(693, 24)
        Me.celdaIDCajas.Name = "celdaIDCajas"
        Me.celdaIDCajas.Size = New System.Drawing.Size(15, 20)
        Me.celdaIDCajas.TabIndex = 36
        Me.celdaIDCajas.Text = "-1"
        Me.celdaIDCajas.Visible = False
        '
        'etiquetaCC
        '
        Me.etiquetaCC.AutoSize = True
        Me.etiquetaCC.Location = New System.Drawing.Point(102, 240)
        Me.etiquetaCC.Name = "etiquetaCC"
        Me.etiquetaCC.Size = New System.Drawing.Size(15, 13)
        Me.etiquetaCC.TabIndex = 45
        Me.etiquetaCC.Text = "**"
        Me.etiquetaCC.Visible = False
        '
        'botonQuintarCC
        '
        Me.botonQuintarCC.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuintarCC.Image = Global.KARIMs_SGI.My.Resources.Resources.edit
        Me.botonQuintarCC.Location = New System.Drawing.Point(670, 273)
        Me.botonQuintarCC.Name = "botonQuintarCC"
        Me.botonQuintarCC.Size = New System.Drawing.Size(32, 23)
        Me.botonQuintarCC.TabIndex = 44
        Me.botonQuintarCC.UseVisualStyleBackColor = True
        '
        'etiquetaBeneficiario
        '
        Me.etiquetaBeneficiario.AutoSize = True
        Me.etiquetaBeneficiario.Location = New System.Drawing.Point(7, 194)
        Me.etiquetaBeneficiario.Name = "etiquetaBeneficiario"
        Me.etiquetaBeneficiario.Size = New System.Drawing.Size(59, 13)
        Me.etiquetaBeneficiario.TabIndex = 38
        Me.etiquetaBeneficiario.Text = "Beneficiary"
        '
        'celdaCuentaCont
        '
        Me.celdaCuentaCont.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCuentaCont.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCuentaCont.Location = New System.Drawing.Point(305, 276)
        Me.celdaCuentaCont.Multiline = True
        Me.celdaCuentaCont.Name = "celdaCuentaCont"
        Me.celdaCuentaCont.Size = New System.Drawing.Size(311, 27)
        Me.celdaCuentaCont.TabIndex = 42
        '
        'botonCC
        '
        Me.botonCC.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCC.Image = Global.KARIMs_SGI.My.Resources.Resources.zoom1
        Me.botonCC.Location = New System.Drawing.Point(631, 274)
        Me.botonCC.Name = "botonCC"
        Me.botonCC.Size = New System.Drawing.Size(32, 23)
        Me.botonCC.TabIndex = 43
        Me.botonCC.UseVisualStyleBackColor = True
        '
        'celdaBeneficiario
        '
        Me.celdaBeneficiario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaBeneficiario.Location = New System.Drawing.Point(4, 210)
        Me.celdaBeneficiario.Multiline = True
        Me.celdaBeneficiario.Name = "celdaBeneficiario"
        Me.celdaBeneficiario.Size = New System.Drawing.Size(659, 27)
        Me.celdaBeneficiario.TabIndex = 37
        '
        'celdaDiferencia
        '
        Me.celdaDiferencia.Location = New System.Drawing.Point(7, 276)
        Me.celdaDiferencia.Multiline = True
        Me.celdaDiferencia.Name = "celdaDiferencia"
        Me.celdaDiferencia.Size = New System.Drawing.Size(293, 26)
        Me.celdaDiferencia.TabIndex = 40
        '
        'botonCajas
        '
        Me.botonCajas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCajas.Location = New System.Drawing.Point(669, 16)
        Me.botonCajas.Name = "botonCajas"
        Me.botonCajas.Size = New System.Drawing.Size(32, 27)
        Me.botonCajas.TabIndex = 35
        Me.botonCajas.Text = "..."
        Me.botonCajas.UseVisualStyleBackColor = True
        '
        'celdaCajas
        '
        Me.celdaCajas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCajas.Location = New System.Drawing.Point(6, 17)
        Me.celdaCajas.Multiline = True
        Me.celdaCajas.Name = "celdaCajas"
        Me.celdaCajas.Size = New System.Drawing.Size(657, 26)
        Me.celdaCajas.TabIndex = 34
        '
        'panelCajaChica
        '
        Me.panelCajaChica.Controls.Add(Me.celdaCajaChica)
        Me.panelCajaChica.Controls.Add(Me.BarraTitulo4)
        Me.panelCajaChica.Location = New System.Drawing.Point(1194, 323)
        Me.panelCajaChica.Name = "panelCajaChica"
        Me.panelCajaChica.Size = New System.Drawing.Size(241, 86)
        Me.panelCajaChica.TabIndex = 36
        Me.panelCajaChica.Visible = False
        '
        'celdaCajaChica
        '
        Me.celdaCajaChica.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCajaChica.Location = New System.Drawing.Point(0, 22)
        Me.celdaCajaChica.Multiline = True
        Me.celdaCajaChica.Name = "celdaCajaChica"
        Me.celdaCajaChica.Size = New System.Drawing.Size(241, 61)
        Me.celdaCajaChica.TabIndex = 23
        Me.celdaCajaChica.Text = "Info..."
        '
        'panelDocumentoDetalle
        '
        Me.panelDocumentoDetalle.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.panelDocumentoDetalle.Controls.Add(Me.panelBotonesCompras)
        Me.panelDocumentoDetalle.Controls.Add(Me.panelCompras)
        Me.panelDocumentoDetalle.Controls.Add(Me.BarraTitulo2)
        Me.panelDocumentoDetalle.Location = New System.Drawing.Point(5, 368)
        Me.panelDocumentoDetalle.Name = "panelDocumentoDetalle"
        Me.panelDocumentoDetalle.Size = New System.Drawing.Size(650, 350)
        Me.panelDocumentoDetalle.TabIndex = 28
        '
        'panelBotonesCompras
        '
        Me.panelBotonesCompras.Controls.Add(Me.botonAgregar)
        Me.panelBotonesCompras.Controls.Add(Me.botonQuitar)
        Me.panelBotonesCompras.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotonesCompras.Location = New System.Drawing.Point(573, 30)
        Me.panelBotonesCompras.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBotonesCompras.Name = "panelBotonesCompras"
        Me.panelBotonesCompras.Size = New System.Drawing.Size(77, 320)
        Me.panelBotonesCompras.TabIndex = 40
        '
        'botonAgregar
        '
        Me.botonAgregar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(18, 67)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(40, 28)
        Me.botonAgregar.TabIndex = 39
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(18, 105)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(40, 28)
        Me.botonQuitar.TabIndex = 38
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'panelCompras
        '
        Me.panelCompras.Controls.Add(Me.dgVentas)
        Me.panelCompras.Controls.Add(Me.dgComprs)
        Me.panelCompras.Controls.Add(Me.panelRegreso)
        Me.panelCompras.Location = New System.Drawing.Point(0, 30)
        Me.panelCompras.Margin = New System.Windows.Forms.Padding(2)
        Me.panelCompras.Name = "panelCompras"
        Me.panelCompras.Size = New System.Drawing.Size(572, 292)
        Me.panelCompras.TabIndex = 37
        '
        'dgVentas
        '
        Me.dgVentas.AllowUserToAddRows = False
        Me.dgVentas.AllowUserToDeleteRows = False
        Me.dgVentas.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.dgVentas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgVentas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFech, Me.colEmisor, Me.colNCheque, Me.colMont, Me.colEstado})
        Me.dgVentas.Location = New System.Drawing.Point(0, 73)
        Me.dgVentas.Name = "dgVentas"
        Me.dgVentas.Size = New System.Drawing.Size(376, 72)
        Me.dgVentas.TabIndex = 40
        '
        'colFech
        '
        Me.colFech.HeaderText = "Date"
        Me.colFech.Name = "colFech"
        '
        'colEmisor
        '
        Me.colEmisor.HeaderText = "Check Issuer"
        Me.colEmisor.Name = "colEmisor"
        '
        'colNCheque
        '
        Me.colNCheque.HeaderText = "Check Number"
        Me.colNCheque.Name = "colNCheque"
        '
        'colMont
        '
        Me.colMont.HeaderText = "Amount"
        Me.colMont.Name = "colMont"
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        '
        'dgComprs
        '
        Me.dgComprs.AllowUserToAddRows = False
        Me.dgComprs.AllowUserToDeleteRows = False
        Me.dgComprs.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption
        DataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle49.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle49.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle49.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle49.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgComprs.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle49
        Me.dgComprs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgComprs.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAno, Me.colNum, Me.colMoneda, Me.colTasa, Me.colDescripcion, Me.colMonto, Me.colCuenta, Me.colRetAno, Me.colRetNumero, Me.colTip, Me.colIDCosto, Me.colCosto, Me.colOperacion, Me.colLinea, Me.colDDoc_RF2_Cod})
        DataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle62.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle62.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle62.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle62.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle62.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgComprs.DefaultCellStyle = DataGridViewCellStyle62
        Me.dgComprs.Location = New System.Drawing.Point(0, 0)
        Me.dgComprs.MultiSelect = False
        Me.dgComprs.Name = "dgComprs"
        DataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle63.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle63.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle63.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle63.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle63.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle63.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgComprs.RowHeadersDefaultCellStyle = DataGridViewCellStyle63
        Me.dgComprs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgComprs.Size = New System.Drawing.Size(376, 67)
        Me.dgComprs.TabIndex = 1
        '
        'colAno
        '
        DataGridViewCellStyle50.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle50.NullValue = "-1"
        Me.colAno.DefaultCellStyle = DataGridViewCellStyle50
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        '
        'colNum
        '
        DataGridViewCellStyle51.NullValue = "-1"
        Me.colNum.DefaultCellStyle = DataGridViewCellStyle51
        Me.colNum.HeaderText = "Number"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Visible = False
        '
        'colMoneda
        '
        DataGridViewCellStyle52.NullValue = "-1"
        Me.colMoneda.DefaultCellStyle = DataGridViewCellStyle52
        Me.colMoneda.HeaderText = "Currency"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.Visible = False
        '
        'colTasa
        '
        DataGridViewCellStyle53.NullValue = "-1"
        Me.colTasa.DefaultCellStyle = DataGridViewCellStyle53
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.Visible = False
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle54.NullValue = "NA"
        Me.colDescripcion.DefaultCellStyle = DataGridViewCellStyle54
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colDescripcion.Width = 85
        '
        'colMonto
        '
        Me.colMonto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle55.NullValue = "-1"
        Me.colMonto.DefaultCellStyle = DataGridViewCellStyle55
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.Width = 81
        '
        'colCuenta
        '
        DataGridViewCellStyle56.NullValue = "-1"
        Me.colCuenta.DefaultCellStyle = DataGridViewCellStyle56
        Me.colCuenta.HeaderText = "Accounting"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.ReadOnly = True
        Me.colCuenta.Visible = False
        '
        'colRetAno
        '
        DataGridViewCellStyle57.NullValue = "-1"
        Me.colRetAno.DefaultCellStyle = DataGridViewCellStyle57
        Me.colRetAno.HeaderText = "Ret_Año"
        Me.colRetAno.Name = "colRetAno"
        Me.colRetAno.ReadOnly = True
        Me.colRetAno.Visible = False
        '
        'colRetNumero
        '
        DataGridViewCellStyle58.NullValue = "-1"
        Me.colRetNumero.DefaultCellStyle = DataGridViewCellStyle58
        Me.colRetNumero.HeaderText = "Ret_Number"
        Me.colRetNumero.Name = "colRetNumero"
        Me.colRetNumero.ReadOnly = True
        Me.colRetNumero.Visible = False
        '
        'colTip
        '
        DataGridViewCellStyle59.NullValue = "-1"
        Me.colTip.DefaultCellStyle = DataGridViewCellStyle59
        Me.colTip.HeaderText = "Type"
        Me.colTip.Name = "colTip"
        Me.colTip.ReadOnly = True
        Me.colTip.Visible = False
        '
        'colIDCosto
        '
        DataGridViewCellStyle60.NullValue = "-1"
        Me.colIDCosto.DefaultCellStyle = DataGridViewCellStyle60
        Me.colIDCosto.HeaderText = "IDCost"
        Me.colIDCosto.Name = "colIDCosto"
        Me.colIDCosto.ReadOnly = True
        Me.colIDCosto.Visible = False
        '
        'colCosto
        '
        Me.colCosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle61.NullValue = "NA"
        Me.colCosto.DefaultCellStyle = DataGridViewCellStyle61
        Me.colCosto.HeaderText = "Cost_Center"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        Me.colCosto.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colCosto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'colOperacion
        '
        Me.colOperacion.HeaderText = "Operacion"
        Me.colOperacion.Name = "colOperacion"
        Me.colOperacion.Visible = False
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        '
        'colDDoc_RF2_Cod
        '
        Me.colDDoc_RF2_Cod.HeaderText = "DDoc_RF2_Cod"
        Me.colDDoc_RF2_Cod.Name = "colDDoc_RF2_Cod"
        Me.colDDoc_RF2_Cod.Visible = False
        '
        'panelRegreso
        '
        Me.panelRegreso.Controls.Add(Me.gdRegreso)
        Me.panelRegreso.Location = New System.Drawing.Point(230, 105)
        Me.panelRegreso.Name = "panelRegreso"
        Me.panelRegreso.Size = New System.Drawing.Size(307, 117)
        Me.panelRegreso.TabIndex = 29
        '
        'gdRegreso
        '
        Me.gdRegreso.Controls.Add(Me.panelRegres)
        Me.gdRegreso.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gdRegreso.Location = New System.Drawing.Point(0, 0)
        Me.gdRegreso.Name = "gdRegreso"
        Me.gdRegreso.Size = New System.Drawing.Size(307, 117)
        Me.gdRegreso.TabIndex = 0
        Me.gdRegreso.TabStop = False
        Me.gdRegreso.Text = "Return"
        '
        'panelRegres
        '
        Me.panelRegres.BackColor = System.Drawing.SystemColors.Control
        Me.panelRegres.Controls.Add(Me.Button8)
        Me.panelRegres.Controls.Add(Me.celdaMontoDesc)
        Me.panelRegres.Controls.Add(Me.Button7)
        Me.panelRegres.Controls.Add(Me.celdaRegreso)
        Me.panelRegres.Controls.Add(Me.BarraTitulo3)
        Me.panelRegres.Location = New System.Drawing.Point(15, 14)
        Me.panelRegres.Name = "panelRegres"
        Me.panelRegres.Size = New System.Drawing.Size(296, 94)
        Me.panelRegres.TabIndex = 1
        '
        'Button8
        '
        Me.Button8.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button8.Location = New System.Drawing.Point(261, 3)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(32, 23)
        Me.Button8.TabIndex = 33
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button7.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.Button7.Location = New System.Drawing.Point(227, 3)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(32, 23)
        Me.Button7.TabIndex = 32
        Me.Button7.UseVisualStyleBackColor = True
        '
        'celdaRegreso
        '
        Me.celdaRegreso.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRegreso.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRegreso.Location = New System.Drawing.Point(-1, 27)
        Me.celdaRegreso.Multiline = True
        Me.celdaRegreso.Name = "celdaRegreso"
        Me.celdaRegreso.Size = New System.Drawing.Size(297, 67)
        Me.celdaRegreso.TabIndex = 22
        Me.celdaRegreso.Text = "Info..."
        '
        'celdaInfoAdd
        '
        Me.celdaInfoAdd.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoAdd.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.celdaInfoAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaInfoAdd.Location = New System.Drawing.Point(0, 6)
        Me.celdaInfoAdd.Multiline = True
        Me.celdaInfoAdd.Name = "celdaInfoAdd"
        Me.celdaInfoAdd.Size = New System.Drawing.Size(1406, 44)
        Me.celdaInfoAdd.TabIndex = 33
        Me.celdaInfoAdd.Text = "Total Lyrics: "
        '
        'panelResuDeposito
        '
        Me.panelResuDeposito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelResuDeposito.Controls.Add(Me.gbResumenDeposito)
        Me.panelResuDeposito.Location = New System.Drawing.Point(663, 177)
        Me.panelResuDeposito.Name = "panelResuDeposito"
        Me.panelResuDeposito.Size = New System.Drawing.Size(742, 161)
        Me.panelResuDeposito.TabIndex = 47
        Me.panelResuDeposito.Visible = False
        '
        'gbResumenDeposito
        '
        Me.gbResumenDeposito.Controls.Add(Me.Panel6)
        Me.gbResumenDeposito.Controls.Add(Me.celdaTotal)
        Me.gbResumenDeposito.Controls.Add(Me.etiquetaSumaCostos)
        Me.gbResumenDeposito.Controls.Add(Me.etiquetaTotal)
        Me.gbResumenDeposito.Controls.Add(Me.celdaOtrosBancos)
        Me.gbResumenDeposito.Controls.Add(Me.etiquetaOtrosBancos)
        Me.gbResumenDeposito.Controls.Add(Me.celdaCheck)
        Me.gbResumenDeposito.Controls.Add(Me.etiquetCheques)
        Me.gbResumenDeposito.Controls.Add(Me.celdaEfectivo)
        Me.gbResumenDeposito.Controls.Add(Me.etiquetaEfectivo)
        Me.gbResumenDeposito.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbResumenDeposito.Location = New System.Drawing.Point(0, 0)
        Me.gbResumenDeposito.Name = "gbResumenDeposito"
        Me.gbResumenDeposito.Size = New System.Drawing.Size(742, 161)
        Me.gbResumenDeposito.TabIndex = 27
        Me.gbResumenDeposito.TabStop = False
        Me.gbResumenDeposito.Text = "Deposit Summary"
        '
        'celdaTotal
        '
        Me.celdaTotal.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaTotal.Location = New System.Drawing.Point(126, 105)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(93, 13)
        Me.celdaTotal.TabIndex = 25
        Me.celdaTotal.Text = "00"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSumaCostos
        '
        Me.etiquetaSumaCostos.AutoSize = True
        Me.etiquetaSumaCostos.Location = New System.Drawing.Point(223, 108)
        Me.etiquetaSumaCostos.Name = "etiquetaSumaCostos"
        Me.etiquetaSumaCostos.Size = New System.Drawing.Size(77, 13)
        Me.etiquetaSumaCostos.TabIndex = 24
        Me.etiquetaSumaCostos.Text = "**(sum + costs)"
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(89, 108)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaTotal.TabIndex = 22
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaOtrosBancos
        '
        Me.celdaOtrosBancos.Location = New System.Drawing.Point(127, 79)
        Me.celdaOtrosBancos.Name = "celdaOtrosBancos"
        Me.celdaOtrosBancos.Size = New System.Drawing.Size(93, 20)
        Me.celdaOtrosBancos.TabIndex = 21
        '
        'etiquetaOtrosBancos
        '
        Me.etiquetaOtrosBancos.AutoSize = True
        Me.etiquetaOtrosBancos.Location = New System.Drawing.Point(55, 86)
        Me.etiquetaOtrosBancos.Name = "etiquetaOtrosBancos"
        Me.etiquetaOtrosBancos.Size = New System.Drawing.Size(66, 13)
        Me.etiquetaOtrosBancos.TabIndex = 20
        Me.etiquetaOtrosBancos.Text = "Other Banks"
        '
        'celdaCheck
        '
        Me.celdaCheck.Location = New System.Drawing.Point(127, 53)
        Me.celdaCheck.Name = "celdaCheck"
        Me.celdaCheck.Size = New System.Drawing.Size(93, 20)
        Me.celdaCheck.TabIndex = 19
        '
        'etiquetCheques
        '
        Me.etiquetCheques.AutoSize = True
        Me.etiquetCheques.Location = New System.Drawing.Point(82, 58)
        Me.etiquetCheques.Name = "etiquetCheques"
        Me.etiquetCheques.Size = New System.Drawing.Size(38, 13)
        Me.etiquetCheques.TabIndex = 18
        Me.etiquetCheques.Text = "Check"
        '
        'celdaEfectivo
        '
        Me.celdaEfectivo.Location = New System.Drawing.Point(127, 28)
        Me.celdaEfectivo.Name = "celdaEfectivo"
        Me.celdaEfectivo.Size = New System.Drawing.Size(93, 20)
        Me.celdaEfectivo.TabIndex = 17
        '
        'etiquetaEfectivo
        '
        Me.etiquetaEfectivo.AutoSize = True
        Me.etiquetaEfectivo.Location = New System.Drawing.Point(89, 35)
        Me.etiquetaEfectivo.Name = "etiquetaEfectivo"
        Me.etiquetaEfectivo.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaEfectivo.TabIndex = 14
        Me.etiquetaEfectivo.Text = "Cash"
        '
        'panelOtraCuenta
        '
        Me.panelOtraCuenta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelOtraCuenta.Controls.Add(Me.gbOtraCuenta)
        Me.panelOtraCuenta.Location = New System.Drawing.Point(661, 175)
        Me.panelOtraCuenta.Name = "panelOtraCuenta"
        Me.panelOtraCuenta.Size = New System.Drawing.Size(741, 184)
        Me.panelOtraCuenta.TabIndex = 29
        '
        'gbOtraCuenta
        '
        Me.gbOtraCuenta.Controls.Add(Me.botonCuentaCont)
        Me.gbOtraCuenta.Controls.Add(Me.checkCuentaExterna)
        Me.gbOtraCuenta.Controls.Add(Me.celdaEtiquetaContable)
        Me.gbOtraCuenta.Controls.Add(Me.etiquetaCuentaContable)
        Me.gbOtraCuenta.Controls.Add(Me.celdaNombreCuenta)
        Me.gbOtraCuenta.Controls.Add(Me.etiquetaNombreCuenta)
        Me.gbOtraCuenta.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbOtraCuenta.Location = New System.Drawing.Point(0, 0)
        Me.gbOtraCuenta.Name = "gbOtraCuenta"
        Me.gbOtraCuenta.Size = New System.Drawing.Size(741, 184)
        Me.gbOtraCuenta.TabIndex = 0
        Me.gbOtraCuenta.TabStop = False
        Me.gbOtraCuenta.Text = "Another Account "
        '
        'botonCuentaCont
        '
        Me.botonCuentaCont.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCuentaCont.Location = New System.Drawing.Point(679, 111)
        Me.botonCuentaCont.Name = "botonCuentaCont"
        Me.botonCuentaCont.Size = New System.Drawing.Size(32, 23)
        Me.botonCuentaCont.TabIndex = 34
        Me.botonCuentaCont.Text = "Button7"
        Me.botonCuentaCont.UseVisualStyleBackColor = True
        '
        'checkCuentaExterna
        '
        Me.checkCuentaExterna.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkCuentaExterna.AutoSize = True
        Me.checkCuentaExterna.Location = New System.Drawing.Point(605, 27)
        Me.checkCuentaExterna.Name = "checkCuentaExterna"
        Me.checkCuentaExterna.Size = New System.Drawing.Size(107, 17)
        Me.checkCuentaExterna.TabIndex = 33
        Me.checkCuentaExterna.Text = "External Account"
        Me.checkCuentaExterna.UseVisualStyleBackColor = True
        '
        'celdaEtiquetaContable
        '
        Me.celdaEtiquetaContable.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaEtiquetaContable.Location = New System.Drawing.Point(28, 117)
        Me.celdaEtiquetaContable.Name = "celdaEtiquetaContable"
        Me.celdaEtiquetaContable.Size = New System.Drawing.Size(645, 20)
        Me.celdaEtiquetaContable.TabIndex = 22
        '
        'etiquetaCuentaContable
        '
        Me.etiquetaCuentaContable.AutoSize = True
        Me.etiquetaCuentaContable.Location = New System.Drawing.Point(28, 101)
        Me.etiquetaCuentaContable.Name = "etiquetaCuentaContable"
        Me.etiquetaCuentaContable.Size = New System.Drawing.Size(83, 13)
        Me.etiquetaCuentaContable.TabIndex = 21
        Me.etiquetaCuentaContable.Text = "Ledger Account"
        '
        'celdaNombreCuenta
        '
        Me.celdaNombreCuenta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNombreCuenta.Location = New System.Drawing.Point(28, 67)
        Me.celdaNombreCuenta.Name = "celdaNombreCuenta"
        Me.celdaNombreCuenta.Size = New System.Drawing.Size(645, 20)
        Me.celdaNombreCuenta.TabIndex = 20
        '
        'etiquetaNombreCuenta
        '
        Me.etiquetaNombreCuenta.AutoSize = True
        Me.etiquetaNombreCuenta.Location = New System.Drawing.Point(28, 51)
        Me.etiquetaNombreCuenta.Name = "etiquetaNombreCuenta"
        Me.etiquetaNombreCuenta.Size = New System.Drawing.Size(78, 13)
        Me.etiquetaNombreCuenta.TabIndex = 0
        Me.etiquetaNombreCuenta.Text = "Account Name"
        '
        'panelDatosProveedores
        '
        Me.panelDatosProveedores.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDatosProveedores.Controls.Add(Me.gbDatosProveedor)
        Me.panelDatosProveedores.Location = New System.Drawing.Point(659, 19)
        Me.panelDatosProveedores.Name = "panelDatosProveedores"
        Me.panelDatosProveedores.Size = New System.Drawing.Size(742, 150)
        Me.panelDatosProveedores.TabIndex = 48
        Me.panelDatosProveedores.Visible = False
        '
        'gbDatosProveedor
        '
        Me.gbDatosProveedor.Controls.Add(Me.checkGastosMultiples)
        Me.gbDatosProveedor.Controls.Add(Me.celdaIDDatos)
        Me.gbDatosProveedor.Controls.Add(Me.etiquetaREF)
        Me.gbDatosProveedor.Controls.Add(Me.botonDatosProveedor)
        Me.gbDatosProveedor.Controls.Add(Me.celdaNomEmisor)
        Me.gbDatosProveedor.Controls.Add(Me.celdaDatosProvee)
        Me.gbDatosProveedor.Controls.Add(Me.etiquetaNomEmisor)
        Me.gbDatosProveedor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbDatosProveedor.Location = New System.Drawing.Point(0, 0)
        Me.gbDatosProveedor.Name = "gbDatosProveedor"
        Me.gbDatosProveedor.Size = New System.Drawing.Size(742, 150)
        Me.gbDatosProveedor.TabIndex = 26
        Me.gbDatosProveedor.TabStop = False
        Me.gbDatosProveedor.Text = "Customer Data / Provider"
        '
        'checkGastosMultiples
        '
        Me.checkGastosMultiples.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkGastosMultiples.AutoSize = True
        Me.checkGastosMultiples.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.checkGastosMultiples.Location = New System.Drawing.Point(528, 62)
        Me.checkGastosMultiples.Name = "checkGastosMultiples"
        Me.checkGastosMultiples.Size = New System.Drawing.Size(170, 17)
        Me.checkGastosMultiples.TabIndex = 36
        Me.checkGastosMultiples.Text = "Suppliers / Multiples Expenses"
        Me.checkGastosMultiples.UseVisualStyleBackColor = True
        '
        'celdaIDDatos
        '
        Me.celdaIDDatos.Location = New System.Drawing.Point(298, 46)
        Me.celdaIDDatos.Name = "celdaIDDatos"
        Me.celdaIDDatos.Size = New System.Drawing.Size(43, 20)
        Me.celdaIDDatos.TabIndex = 35
        Me.celdaIDDatos.Text = "0"
        Me.celdaIDDatos.Visible = False
        '
        'etiquetaREF
        '
        Me.etiquetaREF.AutoSize = True
        Me.etiquetaREF.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaREF.ForeColor = System.Drawing.Color.Green
        Me.etiquetaREF.Location = New System.Drawing.Point(13, 121)
        Me.etiquetaREF.Name = "etiquetaREF"
        Me.etiquetaREF.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaREF.TabIndex = 34
        Me.etiquetaREF.Text = "REF."
        Me.etiquetaREF.Visible = False
        '
        'botonDatosProveedor
        '
        Me.botonDatosProveedor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonDatosProveedor.Location = New System.Drawing.Point(703, 18)
        Me.botonDatosProveedor.Name = "botonDatosProveedor"
        Me.botonDatosProveedor.Size = New System.Drawing.Size(32, 23)
        Me.botonDatosProveedor.TabIndex = 33
        Me.botonDatosProveedor.Text = "..."
        Me.botonDatosProveedor.UseVisualStyleBackColor = True
        '
        'celdaNomEmisor
        '
        Me.celdaNomEmisor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNomEmisor.Location = New System.Drawing.Point(13, 94)
        Me.celdaNomEmisor.Name = "celdaNomEmisor"
        Me.celdaNomEmisor.Size = New System.Drawing.Size(722, 20)
        Me.celdaNomEmisor.TabIndex = 20
        '
        'celdaDatosProvee
        '
        Me.celdaDatosProvee.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDatosProvee.Location = New System.Drawing.Point(13, 20)
        Me.celdaDatosProvee.Name = "celdaDatosProvee"
        Me.celdaDatosProvee.Size = New System.Drawing.Size(684, 20)
        Me.celdaDatosProvee.TabIndex = 19
        '
        'etiquetaNomEmisor
        '
        Me.etiquetaNomEmisor.AutoSize = True
        Me.etiquetaNomEmisor.Location = New System.Drawing.Point(10, 79)
        Me.etiquetaNomEmisor.Name = "etiquetaNomEmisor"
        Me.etiquetaNomEmisor.Size = New System.Drawing.Size(97, 13)
        Me.etiquetaNomEmisor.TabIndex = 13
        Me.etiquetaNomEmisor.Text = "Sender / Recipient"
        '
        'panelTipoTransaccion
        '
        Me.panelTipoTransaccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelTipoTransaccion.BackColor = System.Drawing.SystemColors.Control
        Me.panelTipoTransaccion.Controls.Add(Me.panelOtrosImpuestos)
        Me.panelTipoTransaccion.Controls.Add(Me.panelEmpleado)
        Me.panelTipoTransaccion.Controls.Add(Me.panelTransferencia)
        Me.panelTipoTransaccion.Controls.Add(Me.panelCajaChi)
        Me.panelTipoTransaccion.Controls.Add(Me.panelProveedores)
        Me.panelTipoTransaccion.Controls.Add(Me.Panel7)
        Me.panelTipoTransaccion.Location = New System.Drawing.Point(659, 354)
        Me.panelTipoTransaccion.Name = "panelTipoTransaccion"
        Me.panelTipoTransaccion.Size = New System.Drawing.Size(742, 209)
        Me.panelTipoTransaccion.TabIndex = 0
        '
        'panelEmpleado
        '
        Me.panelEmpleado.Controls.Add(Me.rbDevolucion)
        Me.panelEmpleado.Controls.Add(Me.TextBox9)
        Me.panelEmpleado.Controls.Add(Me.celdaMensaje3)
        Me.panelEmpleado.Controls.Add(Me.TextBox11)
        Me.panelEmpleado.Controls.Add(Me.rbAntPrestamo)
        Me.panelEmpleado.Location = New System.Drawing.Point(7, 96)
        Me.panelEmpleado.Name = "panelEmpleado"
        Me.panelEmpleado.Size = New System.Drawing.Size(344, 194)
        Me.panelEmpleado.TabIndex = 55
        Me.panelEmpleado.Visible = False
        '
        'rbDevolucion
        '
        Me.rbDevolucion.AutoSize = True
        Me.rbDevolucion.Location = New System.Drawing.Point(51, 104)
        Me.rbDevolucion.Margin = New System.Windows.Forms.Padding(2)
        Me.rbDevolucion.Name = "rbDevolucion"
        Me.rbDevolucion.Size = New System.Drawing.Size(172, 17)
        Me.rbDevolucion.TabIndex = 54
        Me.rbDevolucion.TabStop = True
        Me.rbDevolucion.Text = "Devolución(Anticipo/Préstamo)"
        Me.rbDevolucion.UseVisualStyleBackColor = True
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(307, 7)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(16, 20)
        Me.TextBox9.TabIndex = 53
        Me.TextBox9.Text = "-1"
        Me.TextBox9.Visible = False
        '
        'celdaMensaje3
        '
        Me.celdaMensaje3.Location = New System.Drawing.Point(36, 10)
        Me.celdaMensaje3.Multiline = True
        Me.celdaMensaje3.Name = "celdaMensaje3"
        Me.celdaMensaje3.Size = New System.Drawing.Size(257, 27)
        Me.celdaMensaje3.TabIndex = 51
        Me.celdaMensaje3.Visible = False
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(147, 80)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(16, 20)
        Me.TextBox11.TabIndex = 52
        Me.TextBox11.Text = "0"
        Me.TextBox11.Visible = False
        '
        'rbAntPrestamo
        '
        Me.rbAntPrestamo.AutoSize = True
        Me.rbAntPrestamo.Location = New System.Drawing.Point(53, 70)
        Me.rbAntPrestamo.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAntPrestamo.Name = "rbAntPrestamo"
        Me.rbAntPrestamo.Size = New System.Drawing.Size(112, 17)
        Me.rbAntPrestamo.TabIndex = 36
        Me.rbAntPrestamo.TabStop = True
        Me.rbAntPrestamo.Text = "Anticipo/Préstamo"
        Me.rbAntPrestamo.UseVisualStyleBackColor = True
        '
        'panelTransferencia
        '
        Me.panelTransferencia.Controls.Add(Me.rbContraGasto)
        Me.panelTransferencia.Controls.Add(Me.TextBox12)
        Me.panelTransferencia.Controls.Add(Me.celdaMensaje4)
        Me.panelTransferencia.Controls.Add(Me.TextBox14)
        Me.panelTransferencia.Controls.Add(Me.rbDepositos)
        Me.panelTransferencia.Location = New System.Drawing.Point(380, 99)
        Me.panelTransferencia.Name = "panelTransferencia"
        Me.panelTransferencia.Size = New System.Drawing.Size(344, 194)
        Me.panelTransferencia.TabIndex = 56
        Me.panelTransferencia.Visible = False
        '
        'rbContraGasto
        '
        Me.rbContraGasto.AutoSize = True
        Me.rbContraGasto.Location = New System.Drawing.Point(53, 102)
        Me.rbContraGasto.Margin = New System.Windows.Forms.Padding(2)
        Me.rbContraGasto.Name = "rbContraGasto"
        Me.rbContraGasto.Size = New System.Drawing.Size(87, 17)
        Me.rbContraGasto.TabIndex = 54
        Me.rbContraGasto.TabStop = True
        Me.rbContraGasto.Text = "Contra Gasto"
        Me.rbContraGasto.UseVisualStyleBackColor = True
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(307, 7)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(16, 20)
        Me.TextBox12.TabIndex = 53
        Me.TextBox12.Text = "-1"
        Me.TextBox12.Visible = False
        '
        'celdaMensaje4
        '
        Me.celdaMensaje4.Location = New System.Drawing.Point(36, 10)
        Me.celdaMensaje4.Multiline = True
        Me.celdaMensaje4.Name = "celdaMensaje4"
        Me.celdaMensaje4.Size = New System.Drawing.Size(257, 27)
        Me.celdaMensaje4.TabIndex = 51
        Me.celdaMensaje4.Visible = False
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(181, 69)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(16, 20)
        Me.TextBox14.TabIndex = 52
        Me.TextBox14.Text = "0"
        Me.TextBox14.Visible = False
        '
        'rbDepositos
        '
        Me.rbDepositos.AutoSize = True
        Me.rbDepositos.Location = New System.Drawing.Point(53, 70)
        Me.rbDepositos.Margin = New System.Windows.Forms.Padding(2)
        Me.rbDepositos.Name = "rbDepositos"
        Me.rbDepositos.Size = New System.Drawing.Size(128, 17)
        Me.rbDepositos.TabIndex = 36
        Me.rbDepositos.TabStop = True
        Me.rbDepositos.Text = "Depositos en Tránsito"
        Me.rbDepositos.UseVisualStyleBackColor = True
        '
        'panelCajaChi
        '
        Me.panelCajaChi.Controls.Add(Me.rbCobro)
        Me.panelCajaChi.Controls.Add(Me.TextBox1)
        Me.panelCajaChi.Controls.Add(Me.celdaMensaje2)
        Me.panelCajaChi.Controls.Add(Me.TextBox6)
        Me.panelCajaChi.Controls.Add(Me.rbCierre)
        Me.panelCajaChi.Controls.Add(Me.rbAntViaticos)
        Me.panelCajaChi.Controls.Add(Me.rbApertura)
        Me.panelCajaChi.Controls.Add(Me.rbLiquidacion)
        Me.panelCajaChi.Location = New System.Drawing.Point(380, 39)
        Me.panelCajaChi.Name = "panelCajaChi"
        Me.panelCajaChi.Size = New System.Drawing.Size(344, 167)
        Me.panelCajaChi.TabIndex = 52
        Me.panelCajaChi.Visible = False
        '
        'rbCobro
        '
        Me.rbCobro.AutoSize = True
        Me.rbCobro.Location = New System.Drawing.Point(43, 129)
        Me.rbCobro.Margin = New System.Windows.Forms.Padding(2)
        Me.rbCobro.Name = "rbCobro"
        Me.rbCobro.Size = New System.Drawing.Size(53, 17)
        Me.rbCobro.TabIndex = 54
        Me.rbCobro.TabStop = True
        Me.rbCobro.Text = "Cobro"
        Me.rbCobro.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(307, 7)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(16, 20)
        Me.TextBox1.TabIndex = 53
        Me.TextBox1.Text = "-1"
        Me.TextBox1.Visible = False
        '
        'celdaMensaje2
        '
        Me.celdaMensaje2.Location = New System.Drawing.Point(31, 7)
        Me.celdaMensaje2.Multiline = True
        Me.celdaMensaje2.Name = "celdaMensaje2"
        Me.celdaMensaje2.Size = New System.Drawing.Size(257, 27)
        Me.celdaMensaje2.TabIndex = 51
        Me.celdaMensaje2.Visible = False
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(166, 43)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(16, 20)
        Me.TextBox6.TabIndex = 52
        Me.TextBox6.Text = "0"
        Me.TextBox6.Visible = False
        '
        'rbCierre
        '
        Me.rbCierre.AutoSize = True
        Me.rbCierre.Location = New System.Drawing.Point(44, 105)
        Me.rbCierre.Margin = New System.Windows.Forms.Padding(2)
        Me.rbCierre.Name = "rbCierre"
        Me.rbCierre.Size = New System.Drawing.Size(52, 17)
        Me.rbCierre.TabIndex = 39
        Me.rbCierre.TabStop = True
        Me.rbCierre.Text = "Cierre"
        Me.rbCierre.UseVisualStyleBackColor = True
        '
        'rbAntViaticos
        '
        Me.rbAntViaticos.AutoSize = True
        Me.rbAntViaticos.Location = New System.Drawing.Point(44, 82)
        Me.rbAntViaticos.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAntViaticos.Name = "rbAntViaticos"
        Me.rbAntViaticos.Size = New System.Drawing.Size(118, 17)
        Me.rbAntViaticos.TabIndex = 38
        Me.rbAntViaticos.TabStop = True
        Me.rbAntViaticos.Text = "Anticipo de Viaticos"
        Me.rbAntViaticos.UseVisualStyleBackColor = True
        '
        'rbApertura
        '
        Me.rbApertura.AutoSize = True
        Me.rbApertura.Location = New System.Drawing.Point(44, 59)
        Me.rbApertura.Margin = New System.Windows.Forms.Padding(2)
        Me.rbApertura.Name = "rbApertura"
        Me.rbApertura.Size = New System.Drawing.Size(111, 17)
        Me.rbApertura.TabIndex = 37
        Me.rbApertura.TabStop = True
        Me.rbApertura.Text = "Apertura / Fondos"
        Me.rbApertura.UseVisualStyleBackColor = True
        '
        'rbLiquidacion
        '
        Me.rbLiquidacion.AutoSize = True
        Me.rbLiquidacion.Location = New System.Drawing.Point(46, 37)
        Me.rbLiquidacion.Margin = New System.Windows.Forms.Padding(2)
        Me.rbLiquidacion.Name = "rbLiquidacion"
        Me.rbLiquidacion.Size = New System.Drawing.Size(79, 17)
        Me.rbLiquidacion.TabIndex = 36
        Me.rbLiquidacion.TabStop = True
        Me.rbLiquidacion.Text = "Liquidacion"
        Me.rbLiquidacion.UseVisualStyleBackColor = True
        '
        'panelProveedores
        '
        Me.panelProveedores.Controls.Add(Me.celdaGrupo)
        Me.panelProveedores.Controls.Add(Me.rbImpuesto)
        Me.panelProveedores.Controls.Add(Me.celdaMensaje)
        Me.panelProveedores.Controls.Add(Me.rbPago)
        Me.panelProveedores.Controls.Add(Me.celdaValorRB)
        Me.panelProveedores.Controls.Add(Me.rbAnticipoSCompras)
        Me.panelProveedores.Controls.Add(Me.rbGasto)
        Me.panelProveedores.Location = New System.Drawing.Point(13, 38)
        Me.panelProveedores.Name = "panelProveedores"
        Me.panelProveedores.Size = New System.Drawing.Size(361, 201)
        Me.panelProveedores.TabIndex = 51
        Me.panelProveedores.Visible = False
        '
        'celdaGrupo
        '
        Me.celdaGrupo.Location = New System.Drawing.Point(284, 15)
        Me.celdaGrupo.Name = "celdaGrupo"
        Me.celdaGrupo.Size = New System.Drawing.Size(16, 20)
        Me.celdaGrupo.TabIndex = 50
        Me.celdaGrupo.Text = "-1"
        Me.celdaGrupo.Visible = False
        '
        'rbImpuesto
        '
        Me.rbImpuesto.AutoSize = True
        Me.rbImpuesto.Location = New System.Drawing.Point(24, 86)
        Me.rbImpuesto.Margin = New System.Windows.Forms.Padding(2)
        Me.rbImpuesto.Name = "rbImpuesto"
        Me.rbImpuesto.Size = New System.Drawing.Size(78, 17)
        Me.rbImpuesto.TabIndex = 38
        Me.rbImpuesto.TabStop = True
        Me.rbImpuesto.Text = "Taxes(ISR)"
        Me.rbImpuesto.UseVisualStyleBackColor = True
        '
        'celdaMensaje
        '
        Me.celdaMensaje.Location = New System.Drawing.Point(13, 18)
        Me.celdaMensaje.Multiline = True
        Me.celdaMensaje.Name = "celdaMensaje"
        Me.celdaMensaje.Size = New System.Drawing.Size(257, 27)
        Me.celdaMensaje.TabIndex = 33
        Me.celdaMensaje.Visible = False
        '
        'rbPago
        '
        Me.rbPago.AutoSize = True
        Me.rbPago.Location = New System.Drawing.Point(24, 59)
        Me.rbPago.Margin = New System.Windows.Forms.Padding(2)
        Me.rbPago.Name = "rbPago"
        Me.rbPago.Size = New System.Drawing.Size(43, 17)
        Me.rbPago.TabIndex = 35
        Me.rbPago.TabStop = True
        Me.rbPago.Text = "Pay"
        Me.rbPago.UseVisualStyleBackColor = True
        '
        'celdaValorRB
        '
        Me.celdaValorRB.Location = New System.Drawing.Point(120, 58)
        Me.celdaValorRB.Name = "celdaValorRB"
        Me.celdaValorRB.Size = New System.Drawing.Size(16, 20)
        Me.celdaValorRB.TabIndex = 49
        Me.celdaValorRB.Text = "0"
        Me.celdaValorRB.Visible = False
        '
        'rbAnticipoSCompras
        '
        Me.rbAnticipoSCompras.AutoSize = True
        Me.rbAnticipoSCompras.Location = New System.Drawing.Point(23, 122)
        Me.rbAnticipoSCompras.Margin = New System.Windows.Forms.Padding(2)
        Me.rbAnticipoSCompras.Name = "rbAnticipoSCompras"
        Me.rbAnticipoSCompras.Size = New System.Drawing.Size(138, 17)
        Me.rbAnticipoSCompras.TabIndex = 36
        Me.rbAnticipoSCompras.TabStop = True
        Me.rbAnticipoSCompras.Text = "Advance On Purchases"
        Me.rbAnticipoSCompras.UseVisualStyleBackColor = True
        '
        'rbGasto
        '
        Me.rbGasto.AutoSize = True
        Me.rbGasto.Location = New System.Drawing.Point(24, 153)
        Me.rbGasto.Margin = New System.Windows.Forms.Padding(2)
        Me.rbGasto.Name = "rbGasto"
        Me.rbGasto.Size = New System.Drawing.Size(70, 17)
        Me.rbGasto.TabIndex = 37
        Me.rbGasto.TabStop = True
        Me.rbGasto.Text = "Spending"
        Me.rbGasto.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.TextBox2)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel7.Location = New System.Drawing.Point(0, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(742, 30)
        Me.Panel7.TabIndex = 34
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.DarkGreen
        Me.TextBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox2.Location = New System.Drawing.Point(0, 0)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(742, 30)
        Me.TextBox2.TabIndex = 21
        Me.TextBox2.Text = "(Transaction Type)"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.dgCompras)
        Me.Panel5.Location = New System.Drawing.Point(0, 27)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(340, 74)
        Me.Panel5.TabIndex = 0
        '
        'dgCompras
        '
        Me.dgCompras.BackgroundColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle64.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle64.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle64.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCompras.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle64
        Me.dgCompras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle65.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle65.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgCompras.DefaultCellStyle = DataGridViewCellStyle65
        Me.dgCompras.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCompras.Location = New System.Drawing.Point(0, 0)
        Me.dgCompras.MultiSelect = False
        Me.dgCompras.Name = "dgCompras"
        Me.dgCompras.ReadOnly = True
        DataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle66.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle66.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle66.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle66.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle66.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle66.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCompras.RowHeadersDefaultCellStyle = DataGridViewCellStyle66
        Me.dgCompras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCompras.Size = New System.Drawing.Size(340, 74)
        Me.dgCompras.TabIndex = 0
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.panelInAdicional)
        Me.panelDocumento.Controls.Add(Me.panelCajaChicaLiq)
        Me.panelDocumento.Controls.Add(Me.panelOtraCuenta)
        Me.panelDocumento.Controls.Add(Me.panelTipoTransaccion)
        Me.panelDocumento.Controls.Add(Me.panelDocumentoDetalle)
        Me.panelDocumento.Controls.Add(Me.panelResuDeposito)
        Me.panelDocumento.Controls.Add(Me.panelDatosProveedores)
        Me.panelDocumento.Controls.Add(Me.celdaAnticiposSCompras)
        Me.panelDocumento.Controls.Add(Me.gbAgregarDoc)
        Me.panelDocumento.Location = New System.Drawing.Point(19, 599)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1406, 566)
        Me.panelDocumento.TabIndex = 6
        '
        'panelInAdicional
        '
        Me.panelInAdicional.Controls.Add(Me.celdaTotaLetras)
        Me.panelInAdicional.Controls.Add(Me.celdaInfoAdd)
        Me.panelInAdicional.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInAdicional.Location = New System.Drawing.Point(0, 516)
        Me.panelInAdicional.Name = "panelInAdicional"
        Me.panelInAdicional.Size = New System.Drawing.Size(1406, 50)
        Me.panelInAdicional.TabIndex = 49
        '
        'celdaTotaLetras
        '
        Me.celdaTotaLetras.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotaLetras.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaTotaLetras.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotaLetras.Location = New System.Drawing.Point(77, 15)
        Me.celdaTotaLetras.Multiline = True
        Me.celdaTotaLetras.Name = "celdaTotaLetras"
        Me.celdaTotaLetras.ReadOnly = True
        Me.celdaTotaLetras.Size = New System.Drawing.Size(395, 21)
        Me.celdaTotaLetras.TabIndex = 34
        '
        'panelCajChiViatics
        '
        Me.panelCajChiViatics.Controls.Add(Me.Panel5)
        Me.panelCajChiViatics.Controls.Add(Me.Button9)
        Me.panelCajChiViatics.Controls.Add(Me.Button4)
        Me.panelCajChiViatics.Controls.Add(Me.BarraTitulo5)
        Me.panelCajChiViatics.Location = New System.Drawing.Point(1061, 196)
        Me.panelCajChiViatics.Name = "panelCajChiViatics"
        Me.panelCajChiViatics.Size = New System.Drawing.Size(340, 117)
        Me.panelCajChiViatics.TabIndex = 2
        Me.panelCajChiViatics.Visible = False
        '
        'Button9
        '
        Me.Button9.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button9.Location = New System.Drawing.Point(268, 3)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(32, 23)
        Me.Button9.TabIndex = 34
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button4.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.Button4.Location = New System.Drawing.Point(301, 2)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(32, 23)
        Me.Button4.TabIndex = 33
        Me.Button4.UseVisualStyleBackColor = True
        '
        'BarraTitulo6
        '
        Me.BarraTitulo6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BarraTitulo6.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BarraTitulo6.Location = New System.Drawing.Point(4, 47)
        Me.BarraTitulo6.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo6.Name = "BarraTitulo6"
        Me.BarraTitulo6.Size = New System.Drawing.Size(697, 29)
        Me.BarraTitulo6.TabIndex = 47
        '
        'BarraTitulo3
        '
        Me.BarraTitulo3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BarraTitulo3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BarraTitulo3.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo3.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo3.Name = "BarraTitulo3"
        Me.BarraTitulo3.Size = New System.Drawing.Size(296, 30)
        Me.BarraTitulo3.TabIndex = 0
        '
        'BarraTitulo2
        '
        Me.BarraTitulo2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BarraTitulo2.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo2.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo2.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo2.Name = "BarraTitulo2"
        Me.BarraTitulo2.Size = New System.Drawing.Size(650, 30)
        Me.BarraTitulo2.TabIndex = 0
        '
        'BarraTitulo7
        '
        Me.BarraTitulo7.BackColor = System.Drawing.Color.SteelBlue
        Me.BarraTitulo7.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo7.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo7.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo7.Name = "BarraTitulo7"
        Me.BarraTitulo7.Size = New System.Drawing.Size(469, 30)
        Me.BarraTitulo7.TabIndex = 0
        '
        'BarraTitulo4
        '
        Me.BarraTitulo4.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BarraTitulo4.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo4.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo4.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo4.Name = "BarraTitulo4"
        Me.BarraTitulo4.Size = New System.Drawing.Size(241, 25)
        Me.BarraTitulo4.TabIndex = 0
        '
        'BarraTitulo5
        '
        Me.BarraTitulo5.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BarraTitulo5.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo5.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo5.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo5.Name = "BarraTitulo5"
        Me.BarraTitulo5.Size = New System.Drawing.Size(340, 29)
        Me.BarraTitulo5.TabIndex = 0
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 69)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1438, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1438, 69)
        Me.Encabezado1.TabIndex = 0
        '
        'botonImprimir
        '
        Me.botonImprimir.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonImprimir.Location = New System.Drawing.Point(655, 14)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(52, 30)
        Me.botonImprimir.TabIndex = 29
        Me.botonImprimir.Text = "Imprimir"
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'frmBancos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1438, 1028)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.Panel_Cuenta)
        Me.Controls.Add(Me.panelCajaChica)
        Me.Controls.Add(Me.panelCajChiViatics)
        Me.Controls.Add(Me.panelLIsta)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmBancos"
        Me.Text = " "
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLIsta.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel_Cuenta.ResumeLayout(False)
        Me.panelMovimientos.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.panelInfoCheques.ResumeLayout(False)
        Me.panelInfoCheques.PerformLayout()
        CType(Me.dgInfCheque, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgMovimientos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbAgregarDoc.ResumeLayout(False)
        Me.gbAgregarDoc.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelOtrosImpuestos.ResumeLayout(False)
        Me.panelOtrosImpuestos.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.panelFacturasNoteD.ResumeLayout(False)
        Me.panelFacturasNoteD.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelCajaChicaLiq.ResumeLayout(False)
        Me.dbCajaChicaLiq.ResumeLayout(False)
        Me.dbCajaChicaLiq.PerformLayout()
        Me.panelFacturas.ResumeLayout(False)
        Me.panelFacturas.PerformLayout()
        CType(Me.dgCobros, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelCajaChica.ResumeLayout(False)
        Me.panelCajaChica.PerformLayout()
        Me.panelDocumentoDetalle.ResumeLayout(False)
        Me.panelBotonesCompras.ResumeLayout(False)
        Me.panelCompras.ResumeLayout(False)
        CType(Me.dgVentas, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgComprs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelRegreso.ResumeLayout(False)
        Me.gdRegreso.ResumeLayout(False)
        Me.panelRegres.ResumeLayout(False)
        Me.panelRegres.PerformLayout()
        Me.panelResuDeposito.ResumeLayout(False)
        Me.gbResumenDeposito.ResumeLayout(False)
        Me.gbResumenDeposito.PerformLayout()
        Me.panelOtraCuenta.ResumeLayout(False)
        Me.gbOtraCuenta.ResumeLayout(False)
        Me.gbOtraCuenta.PerformLayout()
        Me.panelDatosProveedores.ResumeLayout(False)
        Me.gbDatosProveedor.ResumeLayout(False)
        Me.gbDatosProveedor.PerformLayout()
        Me.panelTipoTransaccion.ResumeLayout(False)
        Me.panelEmpleado.ResumeLayout(False)
        Me.panelEmpleado.PerformLayout()
        Me.panelTransferencia.ResumeLayout(False)
        Me.panelTransferencia.PerformLayout()
        Me.panelCajaChi.ResumeLayout(False)
        Me.panelCajaChi.PerformLayout()
        Me.panelProveedores.ResumeLayout(False)
        Me.panelProveedores.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        CType(Me.dgCompras, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.panelInAdicional.ResumeLayout(False)
        Me.panelInAdicional.PerformLayout()
        Me.panelCajChiViatics.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLIsta As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents botonChequera As System.Windows.Forms.Button
    Friend WithEvents celdaChequera As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaMonedaClave As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents botonCuentaContable As System.Windows.Forms.Button
    Friend WithEvents celdaPartida As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents botonBanco As System.Windows.Forms.Button
    Friend WithEvents celdaBanco As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents botonTipoCuenta As System.Windows.Forms.Button
    Friend WithEvents celdaTipoCuenta As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents celdaPlazo As System.Windows.Forms.TextBox
    Friend WithEvents celdaSobregiro As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents celdaContacto As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents celdaNombre As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaNoCuenta As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents botonDebito As System.Windows.Forms.Button
    Friend WithEvents botonDeposito As System.Windows.Forms.Button
    Friend WithEvents botonCredit As System.Windows.Forms.Button
    Friend WithEvents botonCheque As System.Windows.Forms.Button
    Friend WithEvents etiquetaTipoDoc As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents Panel_Cuenta As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents celdaSaldo As System.Windows.Forms.TextBox
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonTiposDocumentos As System.Windows.Forms.Button
    Friend WithEvents celdaTipoDoc As System.Windows.Forms.TextBox
    Friend WithEvents celdaID_TDoc As System.Windows.Forms.Label
    Friend WithEvents celdaIdMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaIdBanco As System.Windows.Forms.Label
    Friend WithEvents gbAgregarDoc As System.Windows.Forms.GroupBox
    Friend WithEvents botonDocumento As System.Windows.Forms.Button
    Friend WithEvents celdaMontoDesc As System.Windows.Forms.TextBox
    Friend WithEvents casillaEstado As System.Windows.Forms.CheckBox
    Friend WithEvents checkSecreto As System.Windows.Forms.CheckBox
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasaCambio As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaReferencia As System.Windows.Forms.Label
    Friend WithEvents etiquetaTasaCam As System.Windows.Forms.Label
    Friend WithEvents dtpDoc As System.Windows.Forms.DateTimePicker
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents botonPolizaContable As System.Windows.Forms.Button
    Friend WithEvents botonAmarrar As System.Windows.Forms.Button
    Friend WithEvents botonCuentaGastos As System.Windows.Forms.Button
    Friend WithEvents botonCuentasContables As System.Windows.Forms.Button
    Friend WithEvents botonAsignarPresupuesto As System.Windows.Forms.Button
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents celdaGastoCom As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaGastosCom As System.Windows.Forms.Label
    Friend WithEvents celdaNotas As System.Windows.Forms.TextBox
    Friend WithEvents etiquetasNotasObser As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaConcepto As System.Windows.Forms.TextBox
    Friend WithEvents celdaMonto As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaConcepto As System.Windows.Forms.Label
    Friend WithEvents etiquetaMonto As System.Windows.Forms.Label
    Friend WithEvents etiquetaDocumento As System.Windows.Forms.Label
    Friend WithEvents celdaDocumento As System.Windows.Forms.TextBox
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents panelFacturasNoteD As System.Windows.Forms.Panel
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents panelDocumentoDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgComprs As System.Windows.Forms.DataGridView
    Friend WithEvents panelCajaChica As System.Windows.Forms.Panel
    Friend WithEvents celdaCajaChica As System.Windows.Forms.TextBox
    Friend WithEvents BarraTitulo4 As KARIMs_SGI.BarraTitulo
    Friend WithEvents BarraTitulo2 As KARIMs_SGI.BarraTitulo
    Friend WithEvents celdaInfoAdd As System.Windows.Forms.TextBox
    Friend WithEvents panelResuDeposito As System.Windows.Forms.Panel
    Friend WithEvents gbResumenDeposito As System.Windows.Forms.GroupBox
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents panelOtraCuenta As System.Windows.Forms.Panel
    Friend WithEvents gbOtraCuenta As System.Windows.Forms.GroupBox
    Friend WithEvents botonCuentaCont As System.Windows.Forms.Button
    Friend WithEvents checkCuentaExterna As System.Windows.Forms.CheckBox
    Friend WithEvents celdaEtiquetaContable As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCuentaContable As System.Windows.Forms.Label
    Friend WithEvents celdaNombreCuenta As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNombreCuenta As System.Windows.Forms.Label
    Friend WithEvents etiquetaSumaCostos As System.Windows.Forms.Label
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents celdaOtrosBancos As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaOtrosBancos As System.Windows.Forms.Label
    Friend WithEvents celdaCheck As System.Windows.Forms.TextBox
    Friend WithEvents etiquetCheques As System.Windows.Forms.Label
    Friend WithEvents celdaEfectivo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEfectivo As System.Windows.Forms.Label
    Friend WithEvents panelDatosProveedores As System.Windows.Forms.Panel
    Friend WithEvents gbDatosProveedor As System.Windows.Forms.GroupBox
    Friend WithEvents celdaIDDatos As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaREF As System.Windows.Forms.Label
    Friend WithEvents botonDatosProveedor As System.Windows.Forms.Button
    Friend WithEvents celdaNomEmisor As System.Windows.Forms.TextBox
    Friend WithEvents celdaDatosProvee As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNomEmisor As System.Windows.Forms.Label
    Friend WithEvents panelTipoTransaccion As System.Windows.Forms.Panel
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents panelCajaChicaLiq As System.Windows.Forms.Panel
    Friend WithEvents dbCajaChicaLiq As System.Windows.Forms.GroupBox
    Friend WithEvents celdaIDCajas As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCC As System.Windows.Forms.Label
    Friend WithEvents botonQuintarCC As System.Windows.Forms.Button
    Friend WithEvents botonCC As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents BarraTitulo5 As KARIMs_SGI.BarraTitulo
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents celdaCuentaCont As System.Windows.Forms.TextBox
    Friend WithEvents panelRegreso As System.Windows.Forms.Panel
    Friend WithEvents gdRegreso As System.Windows.Forms.GroupBox
    Friend WithEvents panelRegres As System.Windows.Forms.Panel
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents celdaRegreso As System.Windows.Forms.TextBox
    Friend WithEvents BarraTitulo3 As KARIMs_SGI.BarraTitulo
    Friend WithEvents etiquetaCuentaCont As System.Windows.Forms.Label
    Friend WithEvents celdaDiferencia As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDiferencia As System.Windows.Forms.Label
    Friend WithEvents etiquetaBeneficiario As System.Windows.Forms.Label
    Friend WithEvents celdaBeneficiario As System.Windows.Forms.TextBox
    Friend WithEvents botonCajas As System.Windows.Forms.Button
    Friend WithEvents celdaCajas As System.Windows.Forms.TextBox
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents botonQuitarDoc As System.Windows.Forms.Button
    Friend WithEvents botonAgregarDoc As System.Windows.Forms.Button
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents dgCompras As System.Windows.Forms.DataGridView
    Friend WithEvents panelCajChiViatics As System.Windows.Forms.Panel
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents BarraTitulo6 As KARIMs_SGI.BarraTitulo
    Friend WithEvents celdaCajaInfo As System.Windows.Forms.TextBox
    Friend WithEvents panelFacturas As System.Windows.Forms.Panel
    Friend WithEvents botopnQuita As System.Windows.Forms.Button
    Friend WithEvents botnAgrega As System.Windows.Forms.Button
    Friend WithEvents dgCobros As System.Windows.Forms.DataGridView
    Friend WithEvents etiquetaCobro As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents panelInfoCheques As System.Windows.Forms.Panel
    Friend WithEvents botonCambiarCategoria As System.Windows.Forms.Button
    Friend WithEvents celdaInfCheque As System.Windows.Forms.TextBox
    Friend WithEvents BarraTitulo7 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelMovimientos As System.Windows.Forms.Panel
    Friend WithEvents dgMovimientos As System.Windows.Forms.DataGridView
    Friend WithEvents botonConciliacion As System.Windows.Forms.Button
    Friend WithEvents etiquetaPresupuesto As System.Windows.Forms.Label
    Friend WithEvents etiquetaAnulado As System.Windows.Forms.Label
    Friend WithEvents celdaAnulado As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSPoliza As System.Windows.Forms.Label
    Friend WithEvents celdaSPoliza As System.Windows.Forms.TextBox
    Friend WithEvents dgInfCheque As System.Windows.Forms.DataGridView
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCentroCostos As System.Windows.Forms.Label
    Friend WithEvents celdaAnticiposSCompras As System.Windows.Forms.TextBox
    Friend WithEvents panelInAdicional As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents celdaTipo As System.Windows.Forms.TextBox
    Friend WithEvents celdaNum As System.Windows.Forms.TextBox
    Friend WithEvents celdaAno As System.Windows.Forms.TextBox
    Friend WithEvents celdaMensaje As System.Windows.Forms.TextBox
    Friend WithEvents panelCompras As System.Windows.Forms.Panel
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents rbPago As System.Windows.Forms.RadioButton
    Friend WithEvents celdaIDDocumento As System.Windows.Forms.TextBox
    Friend WithEvents rbGasto As System.Windows.Forms.RadioButton
    Friend WithEvents rbAnticipoSCompras As System.Windows.Forms.RadioButton
    Friend WithEvents rbImpuesto As System.Windows.Forms.RadioButton
    Friend WithEvents casillaAnulada As System.Windows.Forms.CheckBox
    Friend WithEvents celdaMoned As System.Windows.Forms.TextBox
    Friend WithEvents celdaMonedaName As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDFecha As System.Windows.Forms.TextBox
    Friend WithEvents celdaTotaLetras As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMon As System.Windows.Forms.Label
    Friend WithEvents celdaCodigoBank As System.Windows.Forms.Label
    Friend WithEvents celdaCatMovimiento As System.Windows.Forms.TextBox
    Friend WithEvents celdaValorRB As System.Windows.Forms.TextBox
    Friend WithEvents celdaGrupo As System.Windows.Forms.TextBox
    Friend WithEvents celdaSCCost As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCostCenter As System.Windows.Forms.Label
    Friend WithEvents panelBotonesCompras As System.Windows.Forms.Panel
    Friend WithEvents colAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTasa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCuenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRetAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRetNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTip As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colIDCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCosto As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colOperacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDDoc_RF2_Cod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgVentas As System.Windows.Forms.DataGridView
    Friend WithEvents colFech As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEmisor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNCheque As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMont As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEstado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents etiquetaFactura As System.Windows.Forms.TextBox
    Friend WithEvents PanelFact As System.Windows.Forms.Panel
    Friend WithEvents EtiquetaAnticipo As System.Windows.Forms.Label
    Friend WithEvents panelCajaChi As System.Windows.Forms.Panel
    Friend WithEvents rbCierre As System.Windows.Forms.RadioButton
    Friend WithEvents rbAntViaticos As System.Windows.Forms.RadioButton
    Friend WithEvents rbApertura As System.Windows.Forms.RadioButton
    Friend WithEvents rbLiquidacion As System.Windows.Forms.RadioButton
    Friend WithEvents panelProveedores As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaMensaje2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents panelTransferencia As System.Windows.Forms.Panel
    Friend WithEvents rbContraGasto As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents celdaMensaje4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents rbDepositos As System.Windows.Forms.RadioButton
    Friend WithEvents panelEmpleado As System.Windows.Forms.Panel
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents celdaMensaje3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents rbAntPrestamo As System.Windows.Forms.RadioButton
    Friend WithEvents rbDevolucion As System.Windows.Forms.RadioButton
    Friend WithEvents rbCobro As System.Windows.Forms.RadioButton
    Friend WithEvents panelOtrosImpuestos As System.Windows.Forms.Panel
    Friend WithEvents rbAsalariados As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents rbIVA As System.Windows.Forms.RadioButton
    Friend WithEvents rbPagoMensual As System.Windows.Forms.RadioButton
    Friend WithEvents rbRetensiones As System.Windows.Forms.RadioButton
    Friend WithEvents colSecreto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAño As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNUmero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDato As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCredito As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDebito As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCategoria As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSub As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPresupuesto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEstados As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCostos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents checkGastosMultiples As System.Windows.Forms.CheckBox
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
End Class
