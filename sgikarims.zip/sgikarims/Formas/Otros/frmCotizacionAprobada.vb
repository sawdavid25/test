﻿Public Class frmCotizacionAprobada
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Public Const catalogos = 948
    Public Const CatalogosCotizacion = 949
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonInprimir.Enabled = True
        End If

    End Sub
    Private Function SQLLista() As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Num CODE,HDR.HDoc_Doc_Ano YEAR , HDR.HDoc_Emp_Nom NAME , HDR.HDoc_Emp_Dir REASON,IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Job , IF(HDR.HDoc_Doc_Status=0,'CANCELED','ACTIVE') Estado  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " LEFT JOIN Personal pe ON pe.per_sisemp = HDR.HDoc_Sis_Emp AND pe.per_usuario = HDR.HDoc_Emp_Per "
        strSQL &= " LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo}  "
        strSQL &= " ORDER by HDR.HDoc_Doc_Fec desc , HDR.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)

        Return strSQL
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelDocumento.Dock = DockStyle.None
            PanelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("QUOTATION")
            'Cargar Datos
            '  cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            PanelDocumento.Dock = DockStyle.Fill
            PanelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '  botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub
    Private Function SQLDetalle(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_UM medida,    c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Doc_Ano Anio,DTL.DDoc_RF1_Txt Comentario,IFNULL((SELECT l.DDoc_Prd_QTY FROM Dcmtos_DTL l WHERE l.DDoc_Sis_Emp = DTL.DDoc_Sis_Emp AND l.DDoc_Doc_Cat = 44 AND l.DDoc_Prd_Cod = i.inv_numero ORDER BY l.DDoc_Doc_Num DESC LIMIT 1),0) ultimoprecio "
        strSQL &= "  FROM Dcmtos_DTL DTL"
        strSQL &= "  LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
        strSQL &= "  LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "  LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "  WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {anio} AND DTL.DDoc_Doc_Num = {codigo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)

        Return strSQL
    End Function
    Private Function SQLCargarProveedor(ByVal Codigo As Integer, ByVal Proveedor As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_UM medida, c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Doc_Ano Anio, p.pro_codigo Code, pro_proveedor Provider, p.pro_plazoCR Plazo ,IFNULL((SELECT l.DDoc_Prd_QTY FROM Dcmtos_DTL l WHERE l.DDoc_Sis_Emp = DTL.DDoc_Sis_Emp AND l.DDoc_Doc_Cat = 44 AND l.DDoc_Prd_Cod = i.inv_numero ORDER BY l.DDoc_Doc_Num DESC LIMIT 1),0) ultimoprecio "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
        strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= " LEFT JOIN Proveedores p ON p.pro_sisemp = DTL.DDoc_Sis_Emp "
        strSQL &= " WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {Anio} AND DTL.DDoc_Doc_Num = {codigo} AND p.pro_codigo = {proveedor} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{Anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", celdaNumeroCotizacion.Text)
        strSQL = Replace(strSQL, "{proveedor}", Proveedor)
        Return strSQL
    End Function
    Private Function NuevaCotizacion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} And HDR.HDoc_Doc_Ano = {anio} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub Reset()
        celdaObservaciones.Text = STR_VACIO
        celdaAnio.Text = cfun.AñoMySQL
        celdaCodigo.Text = STR_VACIO
        celdaCotizacion.Text = STR_VACIO
        celdaSolicitado.Text = STR_VACIO
        celdaidSolitado.Text = STR_VACIO
        celdaNumeroCotizacion.Text = NO_FILA
        celdaRason.Text = STR_VACIO
        celdaAño.Text = STR_VACIO
        celdaProveedor1.Text = STR_VACIO
        celdaidProveedor.Text = NO_FILA
        celdaidProveedor2.Text = NO_FILA
        celdaidProveedor3.Text = NO_FILA
        celdaProveedor2.Text = STR_VACIO
        celdaProveedor3.Text = STR_VACIO
        celdaTotal.Text = STR_VACIO
        celdaTotal2.Text = STR_VACIO
        celdaTotal3.Text = STR_VACIO
        celdaMoneda.Text = cfun.SimboloMoneda(cfun.DivisaLocal)
        celdaidMoneda.Text = cfun.DivisaLocal
        celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")


        CheckAnulado.Checked = True
        If dtpFechaInicio.Format = DateTimePickerFormat.Custom Then
        Else
            dtpFechaInicio.Value = Now.ToString(FORMATO_MYSQL)
        End If

        dgCotizacion.Rows.Clear()
    End Sub
    Public Sub Limpiar()
        dgCotizacion.Rows.Clear()
        dgCotizacion2.Rows.Clear()
        dgCotizacion3.Rows.Clear()
    End Sub
    Private Function GuardarDetalle(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean = False
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgCotizacion.RowCount - 1
                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = CatalogosCotizacion
                DTL.DDOC_DOC_ANO = celdaAnio.Text
                DTL.DDOC_PRD_COD = dgCotizacion.Rows(i).Cells("colCodigo").Value ' Codigo
                DTL.DDOC_PRD_DES = dgCotizacion.Rows(i).Cells("colProducto").Value ' Producto
                DTL.DDOC_PRD_QTY = dgCotizacion.Rows(i).Cells("colCantidad").Value ' Cantidad
                DTL.DDOC_PRD_UM = dgCotizacion.Rows(i).Cells("colId").Value ' Medida
                DTL.DDOC_PRD_NET = CDbl(dgCotizacion.Rows(i).Cells("colPrecio").Value) ' Precio
                DTL.DDOC_RF1_DBL = CDbl(dgCotizacion.Rows(i).Cells("colPrecioAnterior").Value) ' Precio Anterior 
                DTL.DDOC_RF1_NUM = celdaidProveedor.Text ' Proveedor
                DTL.DDOC_RF1_COD = dgCotizacion.Rows(i).Cells("colPago").Value ' Formas de Pago 
                DTL.DDOC_RF1_TXT = dgCotizacion.Rows(i).Cells("colComentario").Value ' Comentario 
                If dgCotizacion.Rows(i).Cells("colTiempo").Value = vbNullString Then
                    dgCotizacion.Rows(i).Cells("colTiempo").Value = STR_VACIO
                End If
                DTL.DDOC_RF2_COD = dgCotizacion.Rows(i).Cells("colTiempo").Value ' Tiempo de Entrega 
                If dgCotizacion.Rows(i).Cells("colAprobacion").Value = "UNFAIR" Then
                    DTL.DDOC_RF3_NUM = 0 ' NO aprobado
                Else
                    DTL.DDOC_RF3_NUM = 1
                End If
                If dgCotizacion.Rows(i).Cells("colEstado").Value = 0 Then
                    DTL.DDOC_DOC_NUM = Codigo
                    DTL.DDOC_DOC_LIN = NuevaLinea(Codigo)
                    DTL.DDOC_RF2_NUM = 1
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                ' Metodo para Actualizar
                If dgCotizacion.Rows(i).Cells("colEstado").Value = 1 Then
                    DTL.DDOC_DOC_NUM = celdaCodigo.Text
                    DTL.DDOC_DOC_LIN = dgCotizacion.Rows(i).Cells("colLinea").Value
                    DTL.DDOC_RF2_NUM = 1
                    If dgCotizacion.Rows(i).Cells("colAprobacion").Value = "APPROVED" Then
                        DTL.DDOC_RF3_NUM = 1 ' Aprobacion
                    Else
                        DTL.DDOC_RF3_NUM = 0
                    End If
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Function GuardarCotizacion(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean = False
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgCotizacion3.RowCount - 1
                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = CatalogosCotizacion
                DTL.DDOC_DOC_ANO = celdaAnio.Text
                DTL.DDOC_PRD_COD = dgCotizacion3.Rows(i).Cells("colCode").Value ' Codigo
                DTL.DDOC_PRD_DES = dgCotizacion3.Rows(i).Cells("colDescripcion").Value ' Producto
                DTL.DDOC_PRD_QTY = dgCotizacion3.Rows(i).Cells("colCantidad1").Value ' Cantidad
                DTL.DDOC_PRD_UM = dgCotizacion3.Rows(i).Cells("colidMedida").Value ' Medida
                DTL.DDOC_PRD_NET = CDbl(dgCotizacion3.Rows(i).Cells("colprice").Value) ' Precio
                DTL.DDOC_RF1_DBL = CDbl(dgCotizacion3.Rows(i).Cells("col_precio_anterior").Value) ' Precio Anterior 
                DTL.DDOC_RF1_NUM = celdaidProveedor2.Text ' Proveedor
                DTL.DDOC_RF1_COD = dgCotizacion3.Rows(i).Cells("colPago1").Value ' Metodo de Pago 
                If dgCotizacion3.Rows(i).Cells("colTiempo1").Value = vbNullString Then
                    dgCotizacion3.Rows(i).Cells("colTiempo1").Value = STR_VACIO
                End If
                DTL.DDOC_RF2_COD = dgCotizacion3.Rows(i).Cells("colTiempo1").Value ' Tiempo de Entrega
                DTL.DDOC_RF1_TXT = dgCotizacion3.Rows(i).Cells("col_Comentario").Value ' Comentario
                If dgCotizacion3.Rows(i).Cells("colAprobacion1").Value = "UNFAIR" Then
                    DTL.DDOC_RF3_NUM = 0 ' No Aprobado 
                Else
                    DTL.DDOC_RF3_NUM = 1
                End If
                    If dgCotizacion3.Rows(i).Cells("colEstado1").Value = 0 Then
                    DTL.DDOC_DOC_NUM = Codigo
                    DTL.DDOC_DOC_LIN = NuevaLinea(Codigo)
                    DTL.DDOC_RF2_NUM = 2
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                ' Metodo para Actualizar
                If dgCotizacion3.Rows(i).Cells("colEstado1").Value = 1 Then
                    DTL.DDOC_DOC_NUM = Codigo
                    DTL.DDOC_DOC_LIN = dgCotizacion3.Rows(i).Cells("colLinea1").Value
                    DTL.DDOC_RF2_NUM = 2
                    If dgCotizacion3.Rows(i).Cells("colAprobacion1").Value = "APPROVED" Then
                        DTL.DDOC_RF3_NUM = 1 ' Aprobacion
                    Else
                        DTL.DDOC_RF3_NUM = 0
                    End If
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If


                End If


            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Function GuardarCotizacion2(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean = False
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgCotizacion2.RowCount - 1
                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = CatalogosCotizacion
                DTL.DDOC_DOC_ANO = celdaAnio.Text
                DTL.DDOC_PRD_COD = dgCotizacion2.Rows(i).Cells("col_codigo").Value ' Codigo
                DTL.DDOC_PRD_DES = dgCotizacion2.Rows(i).Cells("col_descripcion").Value ' Producto
                DTL.DDOC_PRD_QTY = dgCotizacion2.Rows(i).Cells("col_cantidad").Value ' Cantidad
                DTL.DDOC_PRD_UM = dgCotizacion2.Rows(i).Cells("col_id").Value ' Medida
                DTL.DDOC_PRD_NET = CDbl(dgCotizacion2.Rows(i).Cells("col_price").Value) ' Precio
                DTL.DDOC_RF1_DBL = CDbl(dgCotizacion2.Rows(i).Cells("col_PrecioAnterior").Value)
                DTL.DDOC_RF1_NUM = celdaidProveedor3.Text ' Proveedor
                DTL.DDOC_RF1_COD = dgCotizacion2.Rows(i).Cells("col_Pago").Value
                If dgCotizacion2.Rows(i).Cells("col_Tiempo").Value = vbNullString Then
                    dgCotizacion2.Rows(i).Cells("col_Tiempo").Value = STR_VACIO
                End If

                DTL.DDOC_RF2_COD = dgCotizacion2.Rows(i).Cells("col_Tiempo").Value
                DTL.DDOC_RF1_TXT = dgCotizacion2.Rows(i).Cells("colComentario1").Value ' Comentario 
                If dgCotizacion2.Rows(i).Cells("col_aprobacion").Value = "UNFAIR" Then
                    DTL.DDOC_RF3_NUM = 0 ' No Aprobado
                Else
                    DTL.DDOC_RF3_NUM = 1
                End If
                If dgCotizacion2.Rows(i).Cells("col_estado").Value = 0 Then
                    DTL.DDOC_DOC_NUM = Codigo
                    DTL.DDOC_DOC_LIN = NuevaLinea(Codigo)
                    DTL.DDOC_RF2_NUM = 3
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                ' Metodo para Actualizar
                If dgCotizacion2.Rows(i).Cells("col_estado").Value = 1 Then
                    DTL.DDOC_RF2_NUM = 3
                    DTL.DDOC_DOC_NUM = celdaCodigo.Text
                    DTL.DDOC_DOC_LIN = dgCotizacion2.Rows(i).Cells("col_linea").Value
                    If dgCotizacion2.Rows(i).Cells("col_aprobacion").Value = "APPROVED" Then
                        DTL.DDOC_RF3_NUM = 1 ' Aprobacion
                    Else
                        DTL.DDOC_RF3_NUM = 0
                    End If
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero

    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva


    End Function
    Private Function Guardar() As Boolean
        Dim Aceptado As Boolean
        Dim HDR As New clsDcmtos_HDR
        Try
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = CatalogosCotizacion
            HDR.HDOC_DOC_ANO = celdaAnio.Text
            HDR.HDOC_EMP_NOM = celdaCotizacion.Text
            HDR.HDOC_EMP_DIR = celdaRason.Text
            HDR.HDOC_EMP_PER = celdaidSolitado.Text
            HDR.HDOC_PRO_DCAT = catalogos
            HDR.HDOC_PRO_DANO = celdaAño.Text
            HDR.HDOC_PRO_DNUM = celdaNumeroCotizacion.Text
            HDR.HDOC_DOC_TC = CDbl(celdaTasa.Text)
            HDR.HDOC_DOC_MON = CInt(celdaidMoneda.Text)
            HDR.HDOC_RF1_TXT = celdaObservaciones.Text


            If CheckAnulado.Checked = True Then
                HDR.HDOC_DOC_STATUS = 1 ' Check Activo
            Else
                HDR.HDOC_DOC_STATUS = 0  ' ANULADO

            End If

            If dtpFechaInicio.Format = DateTimePickerFormat.Custom Then
            Else
                HDR.HDoc_Doc_Fec_NET = dtpFechaInicio.Value
            End If
            HDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then


                If logInsertar = True Then
                    HDR.HDOC_USUARIO = Sesion.Usuario
                    HDR.HDOC_DOC_NUM = NuevaCotizacion()
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, CatalogosCotizacion, celdaAño.Text, HDR.HDOC_DOC_NUM)
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                    Else
                        Aceptado = True
                        If GuardarDetalle(HDR.HDOC_DOC_NUM) Then
                            Aceptado = True
                        Else
                            Aceptado = False
                        End If
                        If GuardarCotizacion(HDR.HDOC_DOC_NUM) Then
                            Aceptado = True
                        Else
                            Aceptado = False
                        End If
                        If GuardarCotizacion2(HDR.HDOC_DOC_NUM) Then
                            Aceptado = True
                        Else
                            Aceptado = False
                        End If

                    End If
                Else
                    MsgBox("Does Not Have Permissions")
                End If
            Else
                If logEditar = True Then

                    HDR.HDOC_DOC_NUM = celdaCodigo.Text
                    HDR.HDOC_PRO_DNUM = celdaNumeroCotizacion.Text

                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, CatalogosCotizacion, celdaAño.Text, celdaCodigo.Text)
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                    Else
                        Aceptado = True
                        If GuardarDetalle(HDR.HDOC_DOC_NUM) Then
                            Aceptado = True
                        Else
                            Aceptado = False
                        End If
                        If GuardarCotizacion(HDR.HDOC_DOC_NUM) Then
                            Aceptado = True
                        Else
                            Aceptado = False
                        End If
                        If GuardarCotizacion2(HDR.HDOC_DOC_NUM) Then
                            Aceptado = True
                        Else
                            Aceptado = False
                        End If
                    End If
                Else
                    MsgBox("Does Not Have Permissions")
                End If



            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Aceptado
    End Function
    Private Function SQLEncabezado(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Num NUMBER,HDR.HDoc_Doc_Ano Anio,HDR.HDoc_Doc_Fec Fecha, HDR.HDoc_Emp_Nom NAME , HDR.HDoc_Emp_Dir REASON , HDR.HDoc_Emp_Per REQUESTED ,HDR.HDoc_Emp_Per Job,HDR.HDoc_Doc_Status Status, HDR.HDoc_Pro_DAno Anio , HDR.HDoc_Pro_DNum Codigo ,HDR.HDoc_Doc_TC Tasa,HDR.HDoc_Doc_Mon clave , c.cat_clave  Moneda, HDR.HDoc_RF1_Txt Observacion "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " LEFT JOIN Personal pe ON pe.per_sisemp = HDR.HDoc_Sis_Emp AND pe.per_usuario = HDR.HDoc_Emp_Per "
        strSQL &= " LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto"
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = HDR.HDoc_Doc_Mon "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio} AND HDR.HDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Sub CargarDetalle(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO

        strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_Net Precio,IFNULL(DTL.DDoc_RF1_Dbl,0) UltimoPrecio,DTL.DDoc_Prd_UM medida, c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Doc_Ano Anio,IFNULL(p.pro_codigo,-1) Code,IFNULL(pro_proveedor,'') Provider,DTL.DDoc_RF3_Num Aprobacion ,DTL.DDoc_RF2_Num Grupo, DTL.DDoc_RF1_Cod Pago , DTL.DDoc_RF2_Cod Tiempo,DTL.DDoc_RF1_Txt Comentario  "
        strSQL &= " FROM Dcmtos_DTL DTL"
        strSQL &= " LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
        strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= " LEFT JOIN Proveedores p ON p.pro_sisemp = DTL.DDoc_Sis_Emp AND p.pro_codigo = DTL.DDoc_RF1_Num "
        strSQL &= " WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {anio} AND DTL.DDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgCotizacion.Rows.Clear()
            Do While REA.Read
                If REA.GetInt32("Grupo") = 1 Then
                    strLinea = REA.GetInt32("codigo") & "|" 'ID CODIGO
                    strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                    strLinea &= REA.GetInt32("cantidad") & "|" ' Cantidad
                    strLinea &= REA.GetDouble("Precio") & "|" ' Precio
                    strLinea &= REA.GetDouble("UltimoPrecio") & "|" ' Ultimo Precio 
                    strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                    strLinea &= REA.GetInt32("medida") & "|" ' id
                    strLinea &= REA.GetInt32("Linea") & "|" '  LINE
                    strLinea &= REA.GetInt32("Anio") & "|" ' Año 
                    strLinea &= (REA.GetDouble("Precio") * REA.GetInt32("cantidad")).ToString(FORMATO_MONEDA) & "|" ' Total 

                    If REA.GetInt32("Aprobacion") = 0 Then
                        strLinea &= "UNFAIR|"  ' Aprobado
                    Else
                        strLinea &= "APPROVED|" ' Aprobado
                    End If

                    strLinea &= REA.GetString("Pago") & "|"   'Forma de pago 
                    strLinea &= REA.GetString("Tiempo") & "|"   'Tiempo de Entrega
                    strLinea &= REA.GetString("Comentario") & "|" ' Comentario
                    strLinea &= "1" ' Status
                    cFunciones.AgregarFila(dgCotizacion, strLinea)
                    celdaProveedor1.Text = REA.GetString("Provider")
                    celdaidProveedor.Text = REA.GetString("Code")
                End If
            Loop
            celdaTotal.Text = CalcularTotal().ToString(FORMATO_MONEDA)
            Colorear()
        End If


    End Sub
    Private Sub CargarCotizacion2(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Try
            strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_Net Precio,IFNULL(DTL.DDoc_RF1_Dbl,0) UltimoPrecio,DTL.DDoc_Prd_UM medida, c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Doc_Ano Anio, IFNULL(p.pro_codigo,-1) Code,IFNULL(pro_proveedor,'') Provider,DTL.DDoc_RF3_Num Aprobacion ,DTL.DDoc_RF2_Num Grupo, DTL.DDoc_RF1_Cod Pago , DTL.DDoc_RF2_Cod Tiempo,DTL.DDoc_RF1_Txt Comentario  "
            strSQL &= " FROM Dcmtos_DTL DTL"
            strSQL &= " LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
            strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
            strSQL &= " LEFT JOIN Proveedores p ON p.pro_sisemp = DTL.DDoc_Sis_Emp AND p.pro_codigo = DTL.DDoc_RF1_Num "
            strSQL &= " WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {anio} AND DTL.DDoc_Doc_Num = {codigo} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)
            strSQL = Replace(strSQL, "{anio}", Año)
            strSQL = Replace(strSQL, "{codigo}", Codigo)


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgCotizacion3.Rows.Clear()
                Do While REA.Read
                    If REA.GetInt32("Grupo") = 2 Then
                        strLinea = REA.GetInt32("codigo") & "|" 'ID CODIGO
                        strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                        strLinea &= REA.GetInt32("cantidad") & "|" ' Cantidad
                        strLinea &= REA.GetDouble("Precio") & "|" ' Precio
                        strLinea &= REA.GetDouble("UltimoPrecio") & "|" ' Ultimo Precio 
                        strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                        strLinea &= REA.GetInt32("medida") & "|" ' id
                        strLinea &= REA.GetInt32("Linea") & "|" '  LINE
                        strLinea &= REA.GetInt32("Anio") & "|" ' Año
                        strLinea &= (REA.GetDouble("Precio") * REA.GetInt32("cantidad")).ToString(FORMATO_MONEDA) & "|" ' Total
                        If REA.GetInt32("Aprobacion") = 0 Then
                            strLinea &= "UNFAIR|" ' Aprobado
                        Else
                            strLinea &= "APPROVED|" ' Aprobado
                        End If
                        strLinea &= REA.GetString("Pago") & "|"   'Forma de pago 
                        strLinea &= REA.GetString("Tiempo") & "|"   'Tiempo de Entrega
                        strLinea &= REA.GetString("Comentario") & "|" ' Comentario
                        strLinea &= "1" ' Status
                        cFunciones.AgregarFila(dgCotizacion3, strLinea)
                        celdaProveedor2.Text = REA.GetString("Provider")
                        celdaidProveedor2.Text = REA.GetInt32("Code")
                    End If
                Loop
                celdaTotal2.Text = CalcularTotal2().ToString(FORMATO_MONEDA)
                Colorear()
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarCotizacion3(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Try
            strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_Net Precio,IFNULL(DTL.DDoc_RF1_Dbl,0) UltimoPrecio,DTL.DDoc_Prd_UM medida, c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Doc_Ano Anio,IFNULL(p.pro_codigo,-1) Code,IFNULL(pro_proveedor,'') Provider,DTL.DDoc_RF3_Num Aprobacion ,DTL.DDoc_RF2_Num Grupo, DTL.DDoc_RF1_Cod Pago , DTL.DDoc_RF2_Cod Tiempo,DTL.DDoc_RF1_Txt Comentario "
            strSQL &= " FROM Dcmtos_DTL DTL"
            strSQL &= " LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
            strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
            strSQL &= " LEFT JOIN Proveedores p ON p.pro_sisemp = DTL.DDoc_Sis_Emp AND p.pro_codigo = DTL.DDoc_RF1_Num"
            strSQL &= " WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {anio} AND DTL.DDoc_Doc_Num = {codigo} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", CatalogosCotizacion)
            strSQL = Replace(strSQL, "{anio}", Año)
            strSQL = Replace(strSQL, "{codigo}", Codigo)


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgCotizacion2.Rows.Clear()
                Do While REA.Read
                    If REA.GetInt32("Grupo") = 3 Then
                        strLinea = REA.GetInt32("codigo") & "|" 'ID CODIGO
                        strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                        strLinea &= REA.GetInt32("cantidad") & "|" ' Cantidad
                        strLinea &= REA.GetDouble("Precio") & "|" ' Precio
                        strLinea &= REA.GetDouble("UltimoPrecio") & "|" ' Ultimo Precio 
                        strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                        strLinea &= REA.GetInt32("medida") & "|" ' id
                        strLinea &= REA.GetInt32("Linea") & "|" '  LINE
                        strLinea &= REA.GetInt32("Anio") & "|" ' Año 
                        strLinea &= (REA.GetDouble("Precio") * REA.GetInt32("cantidad")).ToString(FORMATO_MONEDA) & "|" ' Total
                        If REA.GetInt32("Aprobacion") = 0 Then
                            strLinea &= "UNFAIR|" ' Aprobado
                        Else
                            strLinea &= "APPROVED|" ' Aprobado
                        End If
                        strLinea &= REA.GetString("Pago") & "|"   'Forma de pago 
                        strLinea &= REA.GetString("Tiempo") & "|"   'Tiempo de Entrega
                        strLinea &= REA.GetString("Comentario") & "|" ' Comentario 
                        strLinea &= "1" ' Status
                        cFunciones.AgregarFila(dgCotizacion2, strLinea)
                        celdaProveedor3.Text = REA.GetString("Provider")
                        celdaidProveedor3.Text = REA.GetInt32("Code")
                    End If
                Loop
                celdaTotal3.Text = CalcularTotal3().ToString(FORMATO_MONEDA)
                Colorear()
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub Seleccionar(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLEncabezado(Codigo, Año)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaAnio.Text = REA.GetInt32("Anio")
                    celdaCodigo.Text = REA.GetInt32("NUMBER")
                    dtpFechaInicio.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaCotizacion.Text = REA.GetString("NAME")
                    celdaRason.Text = REA.GetString("REASON")
                    celdaSolicitado.Text = REA.GetString("Job")
                    celdaidSolitado.Text = REA.GetString("REQUESTED")
                    celdaNumeroCotizacion.Text = REA.GetInt32("Codigo")
                    celdaAño.Text = REA.GetInt32("Anio")
                    celdaidMoneda.Text = REA.GetInt32("clave")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaObservaciones.Text = REA.GetString("Observacion")
                    If REA.GetInt32("Status") = 0 Then
                        DesbloquearFormas()
                    Else
                        HabilitarFormas()
                    End If
                Loop
            End If
            CargarDetalle(Codigo, Año)
            CargarCotizacion2(Codigo, Año)
            CargarCotizacion3(Codigo, Año)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function CalcularTotal() As Double
        Dim Aceptado As Boolean = False
        Dim sumaTotal As Double = 0
        For i As Integer = 0 To dgCotizacion.RowCount - 1

            dgCotizacion.Rows(i).Cells("colTotal").Value = CDbl((dgCotizacion.Rows(i).Cells("colPrecio").Value) * CDbl(dgCotizacion.Rows(i).Cells("colCantidad").Value)).ToString(FORMATO_MONEDA)
            sumaTotal = sumaTotal + dgCotizacion.Rows(i).Cells("colTotal").Value
        Next
        celdaTotal.Text = sumaTotal.ToString(FORMATO_MONEDA)
        Aceptado = True
        Return sumaTotal
    End Function
    Private Function CalcularTotal2() As Double
        Dim Aceptado As Boolean = False
        Dim sumaTotal As Double = 0

        For i As Integer = 0 To dgCotizacion3.RowCount - 1

            dgCotizacion3.Rows(i).Cells("colTotal1").Value = CDbl((dgCotizacion3.Rows(i).Cells("colprice").Value) * CDbl(dgCotizacion3.Rows(i).Cells("colCantidad1").Value)).ToString(FORMATO_MONEDA)
            sumaTotal = sumaTotal + dgCotizacion3.Rows(i).Cells("colTotal1").Value
        Next
        celdaTotal2.Text = sumaTotal.ToString(FORMATO_MONEDA)
        Aceptado = True
        Return sumaTotal
    End Function
    Private Function CalcularTotal3() As Double
        Dim Aceptado As Boolean = False
        Dim sumaTotal As Double = 0
        If dgCotizacion2.Rows.Count = 0 Then Exit Function
        For i As Integer = 0 To dgCotizacion2.RowCount - 1

            dgCotizacion2.Rows(i).Cells("col_total").Value = CDbl((dgCotizacion2.Rows(i).Cells("col_price").Value) * CDbl(dgCotizacion2.Rows(i).Cells("col_cantidad").Value)).ToString(FORMATO_MONEDA)
            sumaTotal = sumaTotal + dgCotizacion2.Rows(i).Cells("col_total").Value
        Next
        celdaTotal3.Text = sumaTotal.ToString(FORMATO_MONEDA)
        Aceptado = True
        Return sumaTotal
    End Function
    Public Sub CargarLista()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim strLinea As String

        strSQL = SQLLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strLinea = REA.GetInt32("CODE") & "|" 'ID CODIGO
                strLinea &= REA.GetInt32("YEAR") & "|"  ' Año 
                strLinea &= REA.GetString("NAME") & "|" 'Titulo de producto cotizado   
                strLinea &= REA.GetString("REASON") & "|" ' Cantidad
                strLinea &= REA.GetString("Job") & "|"  ' Medida
                strLinea &= REA.GetString("Estado") ' ESTADO 
                If REA.GetString("Estado") = "CANCELED" Then
                    cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                Else
                    cFunciones.AgregarFila(dgLista, strLinea)
                End If
            Loop

        End If

    End Sub
    Public Sub DesbloquearFormas()
        celdaCodigo.Enabled = False
        celdaObservaciones.Enabled = False
        celdaProveedor1.Enabled = False
        celdaProveedor2.Enabled = False
        celdaProveedor3.Enabled = False
        celdaRason.Enabled = False
        celdaSolicitado.Enabled = False
        celdaTotal.Enabled = False
        celdaTotal2.Enabled = False
        celdaTotal2.Enabled = False
        celdaTotal3.Enabled = False
        celdaProveedor1.Enabled = False
        celdaProveedor2.Enabled = False
        celdaProveedor3.Enabled = False
        dgCotizacion.ReadOnly = True
        dgCotizacion2.ReadOnly = True
        dgCotizacion3.ReadOnly = True

    End Sub
    Public Sub HabilitarFormas()
        celdaCodigo.Enabled = True
        celdaObservaciones.Enabled = True
        celdaProveedor1.Enabled = True
        celdaProveedor2.Enabled = True
        celdaProveedor3.Enabled = True
        celdaRason.Enabled = True
        celdaSolicitado.Enabled = True
        celdaTotal.Enabled = True
        celdaTotal2.Enabled = True
        celdaTotal2.Enabled = True
        celdaTotal3.Enabled = True
        celdaProveedor1.Enabled = True
        celdaProveedor2.Enabled = True
        celdaProveedor3.Enabled = True
        dgCotizacion.ReadOnly = False
        dgCotizacion2.ReadOnly = False
        dgCotizacion3.ReadOnly = False
    End Sub
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgCotizacion.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        If dgCotizacion3.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        If dgCotizacion2.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If

        For i As Integer = 0 To dgCotizacion.RowCount - 1
            If celdaidProveedor.Text > NO_FILA Then
                If dgCotizacion.Rows(i).Visible = True Then
                    If CDbl(dgCotizacion.Rows(i).Cells("colPrecio").Value) = INT_CERO Then
                        MsgBox("Amount invalid please add another number")
                        LogVerdadero = False
                    End If
                    If CStr(dgCotizacion.Rows(i).Cells("colPago").Value) = vbNullString Then
                        MsgBox("BLANK PAyment Method")
                        LogVerdadero = False
                    End If
                End If
            End If
        Next

        For J As Integer = 0 To dgCotizacion3.RowCount - 1
            If celdaidProveedor2.Text > NO_FILA Then
                If dgCotizacion3.Rows(J).Visible = True Then
                    If CDbl(dgCotizacion3.Rows(J).Cells("colprice").Value) = INT_CERO Then
                        MsgBox("Amount invalid please add another number")
                        LogVerdadero = False
                    End If
                End If
            End If
        Next

        For k As Integer = 0 To dgCotizacion2.RowCount - 1
            If celdaidProveedor3.Text > NO_FILA Then
                If dgCotizacion2.Rows(k).Visible = True Then
                    If CDbl(dgCotizacion2.Rows(k).Cells("col_price").Value) = INT_CERO Then
                        MsgBox("Amount invalid please add another number")
                        LogVerdadero = False
                    End If
                    If CStr(dgCotizacion2.Rows(k).Cells("col_Pago").Value) = vbNullString Then
                        MsgBox("BLANK Payment Method")
                        LogVerdadero = False
                    End If
                End If
            End If
        Next
        Return LogVerdadero
    End Function
    Private Function SQLCargarDatos(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT HDR.HDoc_Doc_Num NUMBER,HDR.HDoc_Doc_Ano Anio,HDR.HDoc_Doc_Fec Fecha, HDR.HDoc_Emp_Nom NAME, HDR.HDoc_Emp_Dir REASON, HDR.HDoc_Emp_Per REQUESTED, HDR.HDoc_Emp_Per Job "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " LEFT JOIN Personal pe ON pe.per_sisemp = HDR.HDoc_Sis_Emp AND pe.per_usuario = HDR.HDoc_Emp_Per "
        strSQL &= " LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio} AND HDR.HDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)

        Return strSQL
    End Function
    Public Sub CargarDatos()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLCargarDatos(celdaNumeroCotizacion.Text, celdaAño.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaCotizacion.Text = REA.GetString("NAME")
                celdaRason.Text = REA.GetString("REASON")
                celdaidSolitado.Text = REA.GetString("REQUESTED")
                celdaSolicitado.Text = REA.GetString("Job")


            Loop
        End If
    End Sub
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaCotizacion.Text = vbNullString Then
            MsgBox("BLANK Quotation")
            Comprobar = False
            Exit Function
        End If
        If celdaRason.Text = vbNullString Then
            MsgBox("BLANK REASON")
            Comprobar = False
            Exit Function
        End If
        If celdaSolicitado.Text = vbNullString Then
            MsgBox("BLANK REQUESTED BY")
            Comprobar = False
            Exit Function
        End If

        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Sub Colorear()

        For i As Integer = 0 To dgCotizacion.RowCount - 1
            Select Case dgCotizacion.Rows(i).Cells("colAprobacion").Value
                Case "APPROVED"
                    dgCotizacion.Rows(i).Cells("colAprobacion").Style.BackColor = Color.Green
            End Select
        Next

        For j As Integer = 0 To dgCotizacion2.RowCount - 1
            Select Case dgCotizacion2.Rows(j).Cells("col_aprobacion").Value
                Case "APPROVED"
                    dgCotizacion2.Rows(j).Cells("col_aprobacion").Style.BackColor = Color.Green
            End Select
        Next
        For k As Integer = 0 To dgCotizacion3.RowCount - 1
            Select Case dgCotizacion3.Rows(k).Cells("colAprobacion1").Value
                Case "APPROVED"
                    dgCotizacion3.Rows(k).Cells("colAprobacion1").Style.BackColor = Color.Green
            End Select
        Next
    End Sub
#End Region
#Region "Eventos"
    Private Sub botonCotizacion_Click(sender As Object, e As EventArgs) Handles botonCotizacion.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = " quotation "
            frm.Campos = " h.HDoc_Doc_Ano YEAR,h.HDoc_Doc_Num CODE, h.HDoc_Emp_Nom NAME, h.HDoc_Emp_Dir REASON, IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Job, pe.per_usuario Code "
            frm.Tabla = "  Dcmtos_HDR h LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Doc_Cat = 949 AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num AND hh.HDoc_Doc_Status = 1 LEFT JOIN Personal pe ON pe.per_sisemp = h.HDoc_Sis_Emp AND pe.per_usuario = h.HDoc_Emp_Per LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto "
            frm.FiltroText = " Enter the quotation Name "
            frm.Filtro = " h.HDoc_Emp_Nom"
            frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = " & catalogos & " AND h.HDoc_Doc_Status = 1  AND hh.HDoc_Sis_Emp IS NULL "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                celdaNumeroCotizacion.Text = frm.Dato
                celdaAño.Text = frm.LLave
                CargarDatos()

                strSQL = SQLDetalle(celdaNumeroCotizacion.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Limpiar()
                    Do While REA.Read
                        strLinea = REA.GetInt32("codigo") & "|" 'ID CODIGO
                        strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                        strLinea &= REA.GetInt32("cantidad") & "|" ' Cantidad
                        strLinea &= "0|" ' Precio 
                        strLinea &= REA.GetInt32("ultimoprecio") & "|" ' Precio 
                        strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                        strLinea &= REA.GetInt32("medida") & "|" ' id
                        strLinea &= REA.GetInt32("Linea") & "|" '  LINE
                        strLinea &= REA.GetInt32("Anio") & "|" ' Año 
                        strLinea &= "0|" ' TOTAL 
                        strLinea &= "UNFAIR|" ' Aprobado
                        strLinea &= "|"   'Forma de pago 
                        strLinea &= "|"   'Tiempo de Entrega
                        strLinea &= REA.GetString("Comentario") & "|"   'Comentario
                        strLinea &= "0" ' Status
                        cFunciones.AgregarFila(dgCotizacion, strLinea)
                        cFunciones.AgregarFila(dgCotizacion2, strLinea)
                        cFunciones.AgregarFila(dgCotizacion3, strLinea)

                    Loop
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmCotizacionAprobada_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub frmCotizacionAprobada_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        Reset()
        Limpiar()
        MostrarLista(False, True)
    End Sub
    Private Sub botonArriba_Click(sender As Object, e As EventArgs)
        Dim frm As New frmSeleccionar
        Dim strSQl As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = "Provider"
            frm.Campos = " pro_codigo Code , pro_proveedor Provider "
            frm.Tabla = " Proveedores "
            frm.FiltroText = " Enter the Provider Name"
            frm.Filtro = " pro_proveedor "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & ""
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strSQl = SQLCargarProveedor(celdaNumeroCotizacion.Text, frm.LLave)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    dgCotizacion3.Rows.Clear()
                    Do While REA.Read
                        strLinea = REA.GetInt32("codigo") & "|" 'ID CODIGO
                        strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                        strLinea &= REA.GetInt32("cantidad") & "|" ' Cantidad
                        strLinea &= "|" ' Precio
                        strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                        strLinea &= REA.GetInt32("medida") & "|" ' id
                        strLinea &= REA.GetInt32("Linea") & "|" '  LINE
                        strLinea &= REA.GetInt32("Anio") & "|" ' Año 
                        strLinea &= REA.GetString("Provider") & "|" ' Proveedor 
                        strLinea &= REA.GetString("Code") & "|" ' id Proveedor
                        strLinea &= "UNFAIR|" ' APROBACION 
                        strLinea &= "0" ' Status
                        cFunciones.AgregarFila(dgCotizacion3, strLinea)


                    Loop
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If PanelDocumento.Visible = True Then
            MostrarLista(True)
        Else
            Me.Close()
        End If
    End Sub
    Private Sub dgCotizacion_DoubleClick(sender As Object, e As EventArgs) Handles dgCotizacion.DoubleClick
        If dgCotizacion.Rows.Count = 0 Then Exit Sub
        Try

            Select Case dgCotizacion.CurrentCell.ColumnIndex
                Case 10
                    Dim frm As New frmOption

                    frm.Opciones = "APPROVED |" & "UNFAIR "
                    frm.ShowDialog(Me)
                    If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case 0
                                dgCotizacion.CurrentRow.Cells("colAprobacion").Value = "APPROVED"
                            Case 1
                                dgCotizacion.CurrentRow.Cells("colAprobacion").Value = "UNFAIR"
                        End Select
                    Else
                        Exit Sub
                    End If
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgCotizacion2_DoubleClick(sender As Object, e As EventArgs) Handles dgCotizacion2.DoubleClick
        If dgCotizacion2.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgCotizacion2.CurrentCell.ColumnIndex
                Case 10
                    Dim frm As New frmOption

                    frm.Opciones = "APPROVED |" & "UNFAIR "
                    frm.ShowDialog(Me)
                    If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case 0
                                dgCotizacion2.CurrentRow.Cells("col_aprobacion").Value = "APPROVED"
                            Case 1
                                dgCotizacion2.CurrentRow.Cells("col_aprobacion").Value = "UNFAIR"
                        End Select
                    Else
                        Exit Sub
                    End If
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgCotizacion3_DoubleClick(sender As Object, e As EventArgs) Handles dgCotizacion3.DoubleClick
        If dgCotizacion3.Rows.Count = 0 Then Exit Sub
        Try

            Select Case dgCotizacion3.CurrentCell.ColumnIndex
                Case 10
                    Dim frm As New frmOption

                    frm.Opciones = "APPROVED |" & "UNFAIR "
                    frm.ShowDialog(Me)
                    If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case 0
                                dgCotizacion3.CurrentRow.Cells("colAprobacion1").Value = "APPROVED"
                            Case 1
                                dgCotizacion3.CurrentRow.Cells("colAprobacion1").Value = "UNFAIR"
                        End Select
                    Else
                        Exit Sub
                    End If
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If ComprobarFila() Then
                    If Guardar() = True Then
                        MostrarLista(True)
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick

        Dim Codigo As Integer = NO_FILA
        Dim Año As Integer = NO_FILA
        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Codigo = dgLista.SelectedCells(0).Value
            Año = dgLista.SelectedCells(1).Value
            Limpiar()
            Reset()
            MostrarLista(False)
            BloquearBotones(False)
            Me.Tag = "mod"
            Seleccionar(Codigo, Año)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonProveedor2_Click(sender As Object, e As EventArgs) Handles botonProveedor2.Click
        Dim frm As New frmSeleccionar
        Dim strSQl As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = "Provider"
            frm.Campos = " pro_codigo Code , pro_proveedor Provider "
            frm.Tabla = " Proveedores "
            frm.FiltroText = " Enter the Provider Name"
            frm.Filtro = " pro_proveedor "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & ""
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If celdaNumeroCotizacion.Text = NO_FILA Then
                    MsgBox("Please select a quote")
                End If
                strSQl = SQLCargarProveedor(celdaNumeroCotizacion.Text, frm.LLave)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then

                    Do While REA.Read
                        celdaProveedor1.Text = REA.GetString("Provider")
                        celdaidProveedor.Text = REA.GetInt32("Code")

                        For i As Integer = 0 To dgCotizacion.RowCount - 1
                            If REA.GetInt32("Plazo") = 0 Then
                                dgCotizacion.Rows(i).Cells("colPago").Value = "CASH"   'Forma de pago
                            Else
                                dgCotizacion.Rows(i).Cells("colPago").Value = REA.GetInt32("Plazo") & " CREDIT DAYS"   'Forma de pago 
                            End If

                            dgCotizacion.Rows(i).Cells("colPrecioAnterior").Value = REA.GetInt32("ultimoprecio")
                        Next
                    Loop
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Dim strSQl As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = "Provider"
            frm.Campos = " pro_codigo Code , pro_proveedor Provider "
            frm.Tabla = " Proveedores "
            frm.FiltroText = " Enter the Provider Name"
            frm.Filtro = " pro_proveedor "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & ""
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If celdaNumeroCotizacion.Text = NO_FILA Then
                    MsgBox("Please select a quote")
                End If
                strSQl = SQLCargarProveedor(celdaNumeroCotizacion.Text, frm.LLave)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQl, CON)
                    REA = COM.ExecuteReader
                If REA.HasRows Then

                    Do While REA.Read
                        celdaProveedor2.Text = REA.GetString("Provider")
                        celdaidProveedor2.Text = REA.GetInt32("Code")

                        For i As Integer = 0 To dgCotizacion.RowCount - 1
                            If REA.GetInt32("Plazo") = 0 Then
                                dgCotizacion3.Rows(i).Cells("colPago1").Value = "CASH"   'Forma de pago
                            Else
                                dgCotizacion3.Rows(i).Cells("colPago1").Value = REA.GetInt32("Plazo") & " CREDIT DAYS"   'Forma de pago 
                            End If

                            dgCotizacion3.Rows(i).Cells("col_precio_anterior").Value = REA.GetInt32("ultimoprecio")
                        Next
                    Loop
                End If


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonProveedor3_Click(sender As Object, e As EventArgs) Handles botonProveedor3.Click
        Dim frm As New frmSeleccionar
        Dim strSQl As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = "Provider"
            frm.Campos = " pro_codigo Code , pro_proveedor Provider "
            frm.Tabla = " Proveedores "
            frm.FiltroText = " Enter the Provider Name"
            frm.Filtro = " pro_proveedor "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa & ""
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If celdaNumeroCotizacion.Text = NO_FILA Then
                    MsgBox("Please select a quote")
                End If
                strSQl = SQLCargarProveedor(celdaNumeroCotizacion.Text, frm.LLave)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQl, CON)
                    REA = COM.ExecuteReader
                If REA.HasRows Then


                    Do While REA.Read
                        celdaProveedor3.Text = REA.GetString("Provider")
                        celdaidProveedor3.Text = REA.GetInt32("Code")


                        For i As Integer = 0 To dgCotizacion.RowCount - 1
                            If REA.GetInt32("Plazo") = 0 Then
                                dgCotizacion2.Rows(i).Cells("col_Pago").Value = "CASH"   'Forma de pago
                            Else
                                dgCotizacion2.Rows(i).Cells("col_Pago").Value = REA.GetInt32("Plazo") & " CREDIT DAYS"   'Forma de pago 
                            End If

                            dgCotizacion2.Rows(i).Cells("col_PrecioAnterior").Value = REA.GetInt32("ultimoprecio")
                        Next


                    Loop
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub dgCotizacion_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgCotizacion.CellEndEdit
        CalcularTotal()
    End Sub
    Private Sub dgCotizacion3_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgCotizacion3.CellEndEdit
        CalcularTotal2()
    End Sub
    Private Sub dgCotizacion2_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgCotizacion2.CellEndEdit
        CalcularTotal3()
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaidMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click
        If logConsultar = True Then
            Dim cRep As New clsReportes
            Try
                cRep.ReporteCotizacion(CatalogosCotizacion, CInt(celdaAño.Text), CInt(celdaCodigo.Text))
                cRep.Parent = Fprincipal
            Catch ex As Exception
                MsgBox(ex.ToString)

            End Try
        Else
            MsgBox("No posee suficientes Privilegios para ejecutar esta acción", MsgBoxStyle.Critical)
        End If

    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(949, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value, 949)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaSolicitado_TextChanged(sender As Object, e As EventArgs) Handles celdaSolicitado.TextChanged

    End Sub


#End Region

End Class