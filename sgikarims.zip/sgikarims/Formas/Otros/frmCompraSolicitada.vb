﻿Public Class frmCompraSolicitada
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strTexto As String
    Dim cfun As New clsFunciones
    Public Const catalogos = 948
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            botonInprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            '  botonImprimir.Enabled = True
        End If

    End Sub
    Private Function SQLLista() As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Num CODE, HDR.HDoc_Doc_Ano YEAR , HDR.HDoc_Emp_Nom NAME , HDR.HDoc_Emp_Dir REASON,IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Job, IF(HDR.HDoc_Doc_Status=0,'CANCELED','ACTIVE') Estado  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " LEFT JOIN Personal pe ON pe.per_sisemp = HDR.HDoc_Sis_Emp AND pe.per_usuario = HDR.HDoc_Emp_Per "
        strSQL &= " LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} "
        strSQL &= " ORDER by HDR.HDoc_Doc_Fec desc , HDR.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)

        Return strSQL
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelDocumento.Dock = DockStyle.None
            PanelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("PURCHASE REQUESTS")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarListaPrincipal()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            PanelDocumento.Dock = DockStyle.Fill
            PanelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "mod"
                BloquearBotones(False)
                botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '  botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub
    Private Sub Reset()
        celdaAño.Text = cfun.AñoMySQL
        celdaCodigo.Text = STR_VACIO
        celdaNombre.Text = STR_VACIO
        celdaSolicitado.Text = STR_VACIO
        celdaRason.Text = STR_VACIO
        celdaIdSolicitado.Text = STR_VACIO
        If dtpFecha.Format = DateTimePickerFormat.Custom Then
        Else
            dtpFecha.Value = Now.ToString(FORMATO_MYSQL)
        End If

        dgCotizacion.Rows.Clear()
    End Sub
    Private Sub Limpiar()
        dgCotizacion.Rows.Clear()
    End Sub
    Private Function Guardar() As Boolean
        Dim LogVerdadero As Boolean = False
        Dim HDR As New clsDcmtos_HDR
        Try

            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = catalogos
            HDR.HDOC_DOC_ANO = celdaAño.Text
            HDR.HDOC_EMP_NOM = celdaNombre.Text
            HDR.HDOC_EMP_DIR = celdaRason.Text
            HDR.HDOC_EMP_PER = celdaIdSolicitado.Text


            If CheckActivo.Checked = True Then
                HDR.HDOC_DOC_STATUS = 1 ' Check Activo
            Else
                HDR.HDOC_DOC_STATUS = 0 ' ANULADO

            End If
            If dtpFecha.Format = DateTimePickerFormat.Custom Then
            Else
                HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            End If

            HDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    HDR.HDOC_USUARIO = Sesion.Usuario
                    HDR.HDOC_DOC_NUM = NuevaCotizacion()
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, catalogos, celdaAño.Text, HDR.HDOC_DOC_NUM)
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True

                        If GuardarDetalle(HDR.HDOC_DOC_NUM) = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If

                    End If
                Else
                    MsgBox("Does Not have Permissions")
                End If
            Else
                'codigo para actualizar CompraSolicitada
                If logEditar = True Then
                    HDR.HDOC_DOC_NUM = celdaCodigo.Text
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, catalogos, celdaAño.Text, celdaCodigo.Text)
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not Modify this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True
                        If GuardarDetalle(HDR.HDOC_DOC_NUM) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                    End If
                Else
                    MsgBox("Does Not Have Permissions")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogVerdadero
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean = False
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgCotizacion.RowCount - 1

                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = catalogos
                DTL.DDOC_DOC_ANO = celdaAño.Text
                DTL.DDOC_PRD_COD = dgCotizacion.Rows(i).Cells("colCodigo").Value
                DTL.DDOC_PRD_DES = dgCotizacion.Rows(i).Cells("colArticulo").Value
                DTL.DDOC_PRD_QTY = dgCotizacion.Rows(i).Cells("colCantidad").Value
                DTL.DDOC_PRD_UM = dgCotizacion.Rows(i).Cells("colIdMedida").Value
                DTL.DDOC_RF1_TXT = dgCotizacion.Rows(i).Cells("colComentario").Value
                If dgCotizacion.Rows(i).Cells("colEstado").Value = 0 Then
                    DTL.DDOC_DOC_LIN = NuevaLinea(Codigo)
                    DTL.DDOC_DOC_NUM = Codigo
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgCotizacion.Rows(i).Cells("colEstado").Value = 1 Then
                    DTL.DDOC_DOC_LIN = dgCotizacion.Rows(i).Cells("colLinea").Value
                    DTL.DDOC_DOC_NUM = celdaCodigo.Text
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString & " Could Not Modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgCotizacion.Rows(i).Cells("colEstado").Value = 2 Then
                    BorrarDetalle(Codigo)

                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Function NuevaCotizacion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} And HDR.HDoc_Doc_Ano = {anio} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", cfun.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva


    End Function
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaNombre.Text = vbNullString Then
            MsgBox("BLANK NAME ")
            Comprobar = False
            Exit Function

        End If
        If celdaIdSolicitado.Text = vbNullString Then
            MsgBox("BLANK REQUESTED BY")
            Comprobar = False
            Exit Function
        End If
        'If celdaIdSolicitado.Text = vbNullString Then
        '    MsgBox("BLANK REQUESTED")
        '    Comprobar = False
        '    Exit Function
        'End If
        If celdaRason.Text = vbNullString Then
            MsgBox("BLANK REASON")
            Comprobar = False
            Exit Function
        End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgCotizacion.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If

        For i As Integer = 0 To dgCotizacion.RowCount - 1
            If dgCotizacion.Rows(i).Visible = True Then
                If dgCotizacion.Rows(i).Cells("colCodigo").Value = NO_FILA Then
                    LogVerdadero = False
                    MsgBox("Blank Code")
                End If
                If dgCotizacion.Rows(i).Cells("colArticulo").Value = vbNullString Then
                    MsgBox("Blank Product")
                    LogVerdadero = False
                End If

                If dgCotizacion.Rows(i).Cells("colCantidad").Value = INT_CERO Then
                    MsgBox("Amount invalid please add another number")
                    LogVerdadero = False
                End If
            End If
        Next
        Return LogVerdadero
    End Function
    Private Function SQLEncabezado(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Num NUMBER,HDR.HDoc_Doc_Ano Anio,HDR.HDoc_Doc_Fec Fecha, HDR.HDoc_Emp_Nom NAME , HDR.HDoc_Emp_Dir REASON , HDR.HDoc_Emp_Per REQUESTED ,IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Job,HDR.HDoc_Doc_Status Estado "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " LEFT JOIN Personal pe ON pe.per_sisemp = HDR.HDoc_Sis_Emp AND pe.per_usuario = HDR.HDoc_Emp_Per "
        strSQL &= " LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio} AND HDR.HDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_UM medida,    c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Doc_Ano Anio,DTL.DDoc_RF1_txt Comentario "
        strSQL &= "  FROM Dcmtos_DTL DTL"
        strSQL &= "  LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
        strSQL &= "  LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "  LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "  WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {anio} AND DTL.DDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Sub CargarDetalle(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        strSQL = SQLDetalle(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgCotizacion.Rows.Clear()
            Do While REA.Read

                strLinea = REA.GetInt32("codigo") & "|" 'ID CODIGO
                strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                strLinea &= REA.GetInt32("cantidad") & "|" ' Cantidad
                strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                strLinea &= REA.GetInt32("medida") & "|" ' id
                strLinea &= REA.GetString("Comentario") & "|" ' Comentario 
                strLinea &= REA.GetInt32("Linea") & "|" '  LINE
                strLinea &= REA.GetInt32("Anio") & "|" ' Año 
                strLinea &= "1" ' Status
                cFunciones.AgregarFila(dgCotizacion, strLinea)

            Loop
        End If


    End Sub
    Public Sub Seleccionar(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLEncabezado(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAño.Text = REA.GetInt32("Anio")
                celdaCodigo.Text = REA.GetInt32("NUMBER")
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                celdaNombre.Text = REA.GetString("NAME")
                celdaRason.Text = REA.GetString("REASON")
                celdaSolicitado.Text = REA.GetString("Job")
                celdaIdSolicitado.Text = REA.GetString("REQUESTED")
                If REA.GetInt32("Estado") = 0 Then
                    DeshabilitarFormas()
                Else
                    HabilitarFormas()
                End If
            Loop
        End If
        CargarDetalle(Codigo, Año)






    End Sub
    Public Function BorrarDetalle(ByVal Codigo As Integer) As Boolean
        Dim LogAceptado As Boolean = False
        Dim DTL As New clsDcmtos_DTL
        Try

            For i As Integer = 0 To dgCotizacion.RowCount - 1
                If Me.Tag = "Nuevo" Then
                Else

                    DTL.CONEXION = strConexion
                    DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                    DTL.DDOC_DOC_CAT = catalogos
                    DTL.DDOC_DOC_ANO = dgCotizacion.Rows(i).Cells("colAnio").Value
                    If dgCotizacion.Rows(i).Cells("colEstado").Value = 2 Then
                        DTL.DDOC_DOC_LIN = dgCotizacion.Rows(i).Cells("colLinea").Value
                        DTL.DDOC_DOC_NUM = Codigo

                        If DTL.Borrar = False Then
                            MsgBox(DTL.MERROR.ToString & " Could Not Delete this document", MsgBoxStyle.Critical)
                            Return False
                            Exit Function
                        Else
                            LogAceptado = True
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogAceptado
    End Function
    Public Sub CargarListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO

        strSQL = SQLLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strLinea = REA.GetInt32("CODE") & "|" 'ID CODIGO
                strLinea &= REA.GetInt32("YEAR") & "|" 'ID CODIGO
                strLinea &= REA.GetString("NAME") & "|" 'Titulo de producto cotizado   
                strLinea &= REA.GetString("REASON") & "|" ' Cantidad
                strLinea &= REA.GetString("Job") & "|"  ' Medida
                strLinea &= REA.GetString("Estado") ' ESTADO 
                If REA.GetString("Estado") = "CANCELED" Then
                    cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                Else
                    cFunciones.AgregarFila(dgLista, strLinea)
                End If
            Loop

        End If

    End Sub
    Public Sub DeshabilitarFormas()
        celdaNombre.Enabled = False
        celdaSolicitado.Enabled = False
        celdaRason.Enabled = False
        dgCotizacion.ReadOnly = True
        ' Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonNuevo.Enabled = False
        botonUp.Enabled = False
        botonAbajo.Enabled = False
    End Sub
    Public Sub HabilitarFormas()
        celdaNombre.Enabled = True
        celdaSolicitado.Enabled = True
        celdaRason.Enabled = True
        dgCotizacion.ReadOnly = False
        botonUp.Enabled = True
        botonAbajo.Enabled = True

    End Sub
#End Region

#Region "Eventos"

    Private Sub frmCompraSolicitada_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        Reset()
        MostrarLista(False, True)

    End Sub

    Private Sub frmCompraSolicitada_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub botonUp_Click(sender As Object, e As EventArgs) Handles botonUp.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        Try
            frm.Titulo = "Article"
            frm.Campos = " i.inv_numero Number, a.art_DCorta Description, c.cat_clave Measure"
            frm.Tabla = " Inventarios i LEFT JOIN Articulos a On a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo LEFT JOIN Catalogos c On c.cat_num = i.inv_UMcmpra And c.cat_clase ='Medidas' "
            frm.Limite = 10
            frm.FiltroText = " Enter the Article to  Filtered"
            frm.Filtro = " art_DCorta  "
            frm.Condicion = " i.inv_sisemp =" & Sesion.IdEmpresa
            frm.Ordenamiento = " i.inv_numero "


            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strSQL = " SELECT i.inv_numero Number, a.art_DCorta Description, c.cat_clave Measure,c.cat_num id "
                strSQL &= " FROM Inventarios i "
                strSQL &= " LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
                strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = i.inv_UMcmpra AND c.cat_clase ='Medidas'"
                strSQL &= " WHERE i.inv_sisemp = {empresa} AND i.inv_numero = {codigo} "
                strSQL &= " LIMIT 20"

                strSQL = Replace(strSQL, "{codigo}", frm.LLave)
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then
                    Do While REA.Read

                        strLinea = REA.GetInt32("Number") & "|" 'ID CODIGO
                        strLinea &= REA.GetString("Description") & "|" 'Titulo de producto cotizado   
                        strLinea &= "0" & "|" ' Cantidad
                        strLinea &= REA.GetString("Measure") & "|"  ' Medida
                        strLinea &= REA.GetInt32("id") & "|" ' id
                        strLinea &= "|" 'COMENTARIO
                        strLinea &= "0" & "|" '  LINE
                        strLinea &= "0" ' StatuS
                        cFunciones.AgregarFila(dgCotizacion, strLinea)
                    Loop
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAbajo_Click(sender As Object, e As EventArgs) Handles botonAbajo.Click
        Try
            Dim Count As Integer
            If dgCotizacion.SelectedRows Is Nothing Then Exit Sub
            If dgCotizacion.Rows.Count > 1 Then
                Count = dgCotizacion.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    strTexto = "Remove " & CStr(dgCotizacion.SelectedCells(1).Value) & vbCrLf
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgCotizacion.SelectedCells(0).Value) & ", " &
                   strTexto & ", " &
               CStr(dgCotizacion.SelectedCells(1).Value) & " " &
                CStr(dgCotizacion.SelectedCells(2).Value) & " " &
                   CStr(dgCotizacion.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgCotizacion.SelectedCells(8).Value = 0 Or dgCotizacion.SelectedCells(8).Value = 1 Then
                            dgCotizacion.SelectedCells(8).Value = 2
                            If dgCotizacion.SelectedCells(8).Value = 2 Then
                                dgCotizacion.CurrentRow.Visible = False
                            End If
                        ElseIf dgCotizacion.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgCotizacion.Rows.RemoveAt(dgCotizacion.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can not delete the last row")
                Exit Sub
            End If
            dgCotizacion.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If PanelDocumento.Visible = True Then
            MostrarLista(True)
        Else
            Me.Close()
        End If
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim Codigo As Integer = NO_FILA
        Dim Año As Integer = NO_FILA
        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Codigo = dgLista.SelectedCells(0).Value
            Año = dgLista.SelectedCells(1).Value
            Limpiar()
            MostrarLista(False)
            BloquearBotones(False)
            Me.Tag = "mod"
            Seleccionar(Codigo, Año)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub dgCotizacion_DoubleClick(sender As Object, e As EventArgs) Handles dgCotizacion.DoubleClick
        If dgCotizacion.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgCotizacion.CurrentCell.ColumnIndex
                Case 3
                    Dim frm As New frmSeleccionar
                    frm.Titulo = "Measure"
                    frm.Campos = " cat_num Number,cat_clave Description  "
                    frm.Tabla = " Catalogos "
                    frm.FiltroText = " Enter the name of the Measure to filter"
                    frm.Filtro = " cat_clave "
                    frm.Condicion = " cat_clase ='Medidas' ORDER BY cat_num  ASC "


                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgCotizacion.CurrentRow.Cells("colIdMedida").Value = frm.LLave
                        dgCotizacion.CurrentRow.Cells("colMedida").Value = frm.Dato

                    End If
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If ComprobarFila() Then
                    If Guardar() = True Then
                        MostrarLista(True)
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonSolicitado_Click(sender As Object, e As EventArgs) Handles botonSolicitado.Click
        Dim frm As New frmSeleccionar
        Try

            frm.Titulo = "Name List"
            frm.Campos = " DISTINCT(h.HDoc_Emp_Per) "
            frm.Tabla = " Dcmtos_HDR h "
            frm.FiltroText = " Enter the User Filtered"
            frm.Filtro = " h.HDoc_Emp_Per "
            frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 948  "
            frm.Ordenamiento = " h.HDoc_Emp_Per"


            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                ''celda.Text = frm.LLave
                celdaIdSolicitado.Text = frm.LLave
                'celdaSolicitado.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub dgCotizacion_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgCotizacion.CellContentClick

    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(948, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value, 948)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click
        If logConsultar = True Then
            Dim cRep As New clsReportes
            Try
                cRep.ReporteSolicitudCompra(CInt(celdaAño.Text), CInt(celdaCodigo.Text))
                cRep.Parent = Fprincipal
            Catch ex As Exception
                MsgBox(ex.ToString)

            End Try
        Else
            MsgBox("No posee suficientes Privilegios para ejecutar esta acción", MsgBoxStyle.Critical)
        End If


    End Sub


#End Region


End Class