﻿Public Class frmPedidoProduccionHilo
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim Proceso As Integer
    Dim CodigosMat As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim NotaDev As String
    Dim VerOpcion As Integer
    Dim varPromedioCosto As Double = 0
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select h.HDoc_Sis_Emp Empresa, h.HDoc_Doc_Cat Catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num Referencia, h.HDoc_RF2_Txt Producto, h.HDoc_Doc_Status estatus "
        strSQL &= "     From Dcmtos_HDR h"
        strSQL &= "         Where h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = 980 "

        If checkFecha.Checked = True Then

            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        ' strSQL = Replace(strSQL, "{NumProceso}", NumProceso)

        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Producto")

                    If REA.GetInt32("estatus") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            panelDocumento.Visible = False
            panelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("PO Production")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

            ListaPrincipal()

        Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDocumento.Visible = True
            panelDocumento.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '      LimpiarCampos()
                'CargarCostos()
                '        ColocaMoneda()
            End If

        End If

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Reset()
        celdaTasa.Text = cFunciones.QueryTasa()
        dtpFecha.Value = Today
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = NO_FILA
        celdaReferencia.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        celdaIdMoneda.Text = 178 'dolares
        celdaMoneda.Text = "USD $"
        celdaTotal.Text = INT_CERO
        celdaPrecio.Text = INT_CERO
        celdaPeso.Text = INT_CERO
        celdaLibras.Text = INT_CERO
        celdaTotalLibras.Text = INT_CERO
        celdaSaldo.Text = INT_CERO
        celdaIdCliente.Text = INT_CERO
        celdaCliente.Clear()
        If Sesion.IdEmpresa = 22 Then
            panelCliente.Visible = True
        Else
            panelCliente.Visible = False
        End If
    End Sub
    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0
        Try
            If celdaReferencia.Text = vbNullString Then
                MsgBox("Blank reference", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If celdaLibras.Text = INT_CERO Then
                MsgBox("Blank Pounds", vbCritical)
                Comprobar = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Comprobar
    End Function
    Private Function GuardarEncabezado() As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim logResultado As Boolean = True
        Try

            CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            CHDR.HDOC_DOC_CAT = 980
            CHDR.HDOC_DOC_ANO = celdaAnio.Text
            CHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            CHDR.HDOC_DOC_MON = celdaIdMoneda.Text
            CHDR.HDOC_DOC_TC = celdaTasa.Text
            CHDR.HDOC_DR1_NUM = celdaReferencia.Text
            CHDR.HDOC_RF1_DBL = celdaLibras.Text
            CHDR.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)
            CHDR.HDOC_RF2_DBL = varPromedioCosto
            CHDR.HDOC_EMP_COD = IIf(celdaIdCliente.Text = vbNullString, 0, celdaIdCliente.Text)
            CHDR.HDOC_EMP_NOM = IIf(celdaCliente.Text = vbNullString, STR_VACIO, celdaCliente.Text)
            CHDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                celdaNumero.Text = cFunciones.NuevoId(980)
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Guardar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            Else
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Actualizar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function SQLEncabezado(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT h.HDoc_Emp_Cod idCliente, h.HDoc_Emp_Nom cliente, h.HDoc_Doc_Ano Anio , h.HDoc_Doc_Num Numero , h.HDoc_Doc_Fec Fecha , h.HDoc_DR1_Num Referencia , h.HDoc_Doc_TC Tasa , h.HDoc_Doc_Mon idMoneda , c.cat_clave Moneda,h.HDoc_DR1_Cat opciones,h.HDoc_RF1_Dbl Libras,h.HDoc_Doc_Status Estado"
            strSQL &= "     FROM Dcmtos_HDR h  "
            strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase='Monedas' "
            strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 980 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = SQLEncabezado(Anio, Num)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaIdCliente.Text = REA.GetInt32("idCliente")
                celdaCliente.Text = REA.GetString("cliente")
                celdaAnio.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("Numero")
                celdaReferencia.Text = REA.GetString("Referencia")
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                celdaTasa.Text = REA.GetDouble("Tasa")
                celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                celdaMoneda.Text = REA.GetString("Moneda")
                celdaLibras.Text = REA.GetDouble("Libras")
            Loop
        End If

    End Sub
    'Borrar Encabezado Ingreso
    Public Function BorrarEncabezado() As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 980
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Detalle Ingreso
    Private Function BorrarDetalle() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                MyCnn.CONECTAR = strConexion
                strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 980 AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero} "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                Dim dtl As New clsDcmtos_DTL
                dtl.CONEXION = strConexion
                dtl.Borrar(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDescargosPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 980 AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea} ;"
                    strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                    strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                    strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                    strSQl = Replace(strSQl, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    Dim pro As New clsDcmtos_DTL_Pro
                    pro.CONEXION = strConexion
                    pro.Borrar(strSQl)
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultosPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQl = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = 980 AND BDoc_Doc_Ano  = {anio} AND BDoc_Doc_Num = {numero} AND BDoc_Doc_Lin = {linea}  ;"
                    strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                    strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                    strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                    strSQl = Replace(strSQl, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    Dim box As New Tablas.TDCMTOS_DTL_BOX
                    box.CONEXION = strConexion
                    box.PDELETE(strSQl)
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultosProPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = 980 AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {numero} AND  BPDoc_Chi_Lin = {linea};"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                    box.CONEXION = strConexion
                    box.PDELETE(strSQL)
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function ActualizarRelacionProduccion() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        For i = 0 To dgDetalle.Rows.Count - 1
            strSQL = " UPDATE  Dcmtos_HDR h SET h.HDoc_Pro_DCat  = 0, h.HDoc_Pro_DAno = 0 , h.HDoc_Pro_DNum = 0   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            If Sesion.IdEmpresa = 18 Then
                strSQL = "; UPDATE PDM.Dcmtos_HDR h SET h.HDoc_Pro_DCat  = 0, h.HDoc_Pro_DAno = 0 , h.HDoc_Pro_DNum = 0   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", dgDetalle.Rows(i).Cells("colRefCatalogo").Value)
            strSQL = Replace(strSQL, "{anio}", dgDetalle.Rows(i).Cells("colRefNum").Value)
            strSQL = Replace(strSQL, "{num}", dgDetalle.Rows(i).Cells("colRefLin").Value)
        Next
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        COM = Nothing
        logGuardar = True
        Return logGuardar
    End Function
    Private Function SQLDetalle(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT h980.HDoc_Doc_Fec Fecha,d.DDoc_Doc_Lin Linea,d.DDoc_Prd_Cod Codigo,	d.DDoc_Prd_Des Descripcion ,d.DDoc_Prd_UM idMedida , c.cat_clave Medida ,d.DDoc_Prd_NET Precio, d.DDoc_Prd_QTY Cantidad , d.DDoc_RF1_Cod Referencia, "
            strSQL &= "     IFNULL(dp.PDoc_Par_Cat,0) Catalogo , IFNULL(dp.PDoc_Par_Ano,0) Anio, IFNULL(dp.PDoc_Par_Num,0) Num, IFNULL(dp.PDoc_Par_Lin,0) LineaRef, "
            strSQL &= "         IFNULL(dbp.BPDoc_Box_Lin,0) LineaBultos,d.DDoc_RF1_Dbl PrecioEstimado,d.DDoc_Prd_PNr Marca,h980.HDoc_DR1_Num ReferenciaP, "
            strSQL &= "                 IFNULL(( "
            strSQL &= "                     SELECT SUM(ROUND(p.BDoc_Box_LB,2)) "
            strSQL &= "                         FROM Dcmtos_DTL_Box p "
            strSQL &= "                      WHERE p.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND p.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND p.BDoc_Doc_Num = d.DDoc_Doc_Num),0) Saldo, "
            strSQL &= "           IFNULL((  SELECT SUM(d47.DDoc_Prd_QTY)
                                    FROM Dcmtos_DTL_Pro pr 
                                LEFT JOIN Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = pr.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = pr.PDoc_Chi_Cat AND d47.DDoc_Doc_Ano = pr.PDoc_Chi_Ano AND d47.DDoc_Doc_Num = pr.PDoc_Chi_Num AND d47.DDoc_Doc_Lin = pr.PDoc_Chi_Lin
                            WHERE pr.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND pr.PDoc_Par_Cat = d.DDoc_Doc_Cat AND pr.PDoc_Par_Ano = d.DDoc_Doc_Ano AND pr.PDoc_Par_Num = d.DDoc_Doc_Num AND pr.PDoc_Chi_Cat = 47),0) Ingreso, h952.HDoc_Doc_TC TipoCambio "
            strSQL &= "             FROM Dcmtos_DTL d  "
            strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND dp.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND dp.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND dp.PDoc_Chi_Num = d.DDoc_Doc_Num AND dp.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND db.BDoc_Doc_Num = d.DDoc_Doc_Num AND db.BDoc_Doc_Lin = d.DDoc_Doc_Lin "
            strSQL &= "                         LEFT JOIN Dcmtos_DTL_Box_Pro dbp ON dbp.BPDoc_Sis_Emp = d.DDoc_Sis_Emp AND dbp.BPDoc_Chi_Cat = d.DDoc_Doc_Cat AND dbp.BPDoc_Chi_Ano = d.DDoc_Doc_Ano AND dbp.BPDoc_Chi_Num = d.DDoc_Doc_Num AND dbp.BPDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strSQL &= "                     LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
            strSQL &= "                 LEFT JOIN Dcmtos_HDR h980 ON h980.HDoc_Sis_Emp = dbp.BPDoc_Sis_Emp AND h980.HDoc_Doc_Cat = dbp.BPDoc_Par_Cat AND h980.HDoc_Doc_Ano = dbp.BPDoc_Par_Ano AND h980.HDoc_Doc_Num = dbp.BPDoc_Par_Num "
            strSQL &= "                 LEFT JOIN Dcmtos_HDR h952	ON h952.HDoc_Sis_Emp = dp.PDoc_Sis_Emp AND h952.HDoc_Doc_Cat = dp.PDoc_Par_Cat AND h952.HDoc_Doc_Ano = dp.PDoc_Par_Ano AND h952.HDoc_Doc_Num = dp.PDoc_Par_Num "
            strSQL &= "                 WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 980 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "
            strSQL &= "             ORDER BY d.DDoc_Sis_Emp,d.DDoc_Doc_Cat,d.DDoc_Doc_Num,d.DDoc_Doc_Lin"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim sumaCant As Double = 0
        Try
            strSQL = SQLDetalle(Anio, Num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    sumaCant = INT_CERO
                    celdaSaldo.Text = (celdaTotalLibras.Text - REA.GetDouble("Saldo")).ToString(FORMATO_MONEDA)
                    celdaSaldo2.Text = REA.GetDouble("Ingreso")
                    strFila = REA.GetInt32("Anio") & "|" 'Anio
                    strFila &= REA.GetInt32("Catalogo") & "|" 'Catalogo
                    strFila &= REA.GetInt32("Num") & "|" 'Numero
                    strFila &= REA.GetInt32("Codigo") & "|" 'Codigo
                    strFila &= REA.GetInt32("Linea") & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                    strFila &= REA.GetString("Marca") & "|" ' Marca
                    strFila &= REA.GetString("ReferenciaP") & "|" ' Producion Referencia 
                    strFila &= REA.GetString("Descripcion") & "|" ' Descripcion
                    '    strFila &= "" & "|" 'Clasificacion
                    strFila &= REA.GetDouble("Precio") & "|" ' Costo
                    sumaCant = sumaCant + REA.GetDouble("Cantidad")
                    strFila &= sumaCant.ToString(FORMATO_MONEDA) & "|" 'Cantidad
                    '  strFila &= "" & "|" 'Porcentaje
                    strFila &= REA.GetDouble("PrecioEstimado") & "|" ' Precio Estimado
                    strFila &= ((REA.GetDouble("Precio")) * (sumaCant)).ToString(FORMATO_MONEDA) & "|" ' Total
                    strFila &= REA.GetInt32("idMedida") & "|" 'Id Medida
                    strFila &= REA.GetString("Medida") & "|" 'Medida
                    '   strFila &= "" & "|" ' Verificador
                    strFila &= REA.GetString("Referencia") & "|" ' Referencia
                    strFila &= REA.GetInt32("LineaRef") & "|" '  Linea
                    strFila &= REA.GetInt32("LineaBultos") & "|" '  Linea Bulto
                    strFila &= INT_UNO & "|"  'Extra 
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetDouble("TipoCambio").ToString("#,#00.0000")
                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop
            End If
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CalcularTotales()
        Dim dblTotal As Double = INT_CERO
        Dim dblPeso As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim vTCPromedio As Double = INT_CERO

        Dim intlinea As Integer = INT_CERO
        Dim i As Integer = 0
        For i = 0 To dgDetalle.Rows.Count - 1
            If Not dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                intlinea = intlinea + 1
                dgDetalle.Rows(i).Cells("colTotal").Value = (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)).ToString(FORMATO_MONEDA)
                dblTotal = dblTotal + (dgDetalle.Rows(i).Cells("colTotal").Value)
                dblPeso = dblPeso + (dgDetalle.Rows(i).Cells("colCantidad").Value)
                dblPrecio = dblPrecio + (dgDetalle.Rows(i).Cells("colPrecio").Value)
                vTCPromedio = vTCPromedio + (dgDetalle.Rows(i).Cells("colTasaCambio").Value)
                varPromedioCosto += CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
            End If

        Next

        celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
        celdaPeso.Text = dblPeso.ToString(FORMATO_MONEDA)
        celdaPrecio.Text = (dblPrecio / intlinea).ToString(FORMATO_MONEDA)
        celdaTasa.Text = (vTCPromedio / intlinea).ToString("#,##0.0000")
        varPromedioCosto = varPromedioCosto / (dgDetalle.Rows.Count - 1)
    End Sub
    Private Function GuardarDetalleBultosPO()
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim DetBox As New Tablas.TDCMTOS_DTL_BOX_PRO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                DetBox.BPDOC_SIS_EMP = Sesion.IdEmpresa
                If checkActivar.Checked = True Then
                    DetBox.BPDOC_PAR_CAT = 952
                    DetBox.BPDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colRefAnio").Value
                    DetBox.BPDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colRefNum").Value
                    DetBox.BPDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colRefLin").Value
                    DetBox.BPDOC_BOX_LIN = dgDetalle.Rows(i).Cells("colBultoB").Value
                Else
                    DetBox.BPDOC_PAR_CAT = INT_CERO
                    DetBox.BPDOC_PAR_ANO = INT_CERO
                    DetBox.BPDOC_PAR_NUM = INT_CERO
                    DetBox.BPDOC_PAR_LIN = INT_CERO
                    DetBox.BPDOC_BOX_LIN = INT_CERO
                End If
                DetBox.BPDOC_CHI_CAT = 980
                DetBox.BPDOC_CHI_ANO = celdaAnio.Text
                DetBox.BPDOC_CHI_NUM = celdaNumero.Text
                DetBox.BPDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                DetBox.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If DetBox.PINSERT = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                    'ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    ' If DetBox.PUPDATE = False Then
                    '  MsgBox(DetBox.MERROR.ToString & "Could Not Update the document", MsgBoxStyle.Critical)
                    'End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If DetBox.PDELETE = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not Delete the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 3 Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Par_Cat = {catP} AND BPDoc_Par_Ano = {anioP} AND BPDoc_Par_Num ={numP} AND BPDoc_Par_Lin = {LinP} AND BPDoc_Chi_Cat = {catC} AND BPDoc_Chi_Ano = {anioC} AND BPDoc_Chi_Num = {numC} AND BPDoc_Chi_Lin ={LinC} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{catP}", dgDetalle.Rows(i).Cells("colRefCatalogo").Value)
                    strSQL = Replace(strSQL, "{anioP}", dgDetalle.Rows(i).Cells("colRefAnio").Value)
                    strSQL = Replace(strSQL, "{numP}", dgDetalle.Rows(i).Cells("colRefNum").Value)
                    strSQL = Replace(strSQL, "{LinP}", dgDetalle.Rows(i).Cells("colRefLin").Value)
                    strSQL = Replace(strSQL, "{catC}", 952)
                    strSQL = Replace(strSQL, "{anioC}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numC}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{LinC}", dgDetalle.Rows(i).Cells("colLinea").Value)

                    Dim bp As New Tablas.TDCMTOS_DTL_BOX_PRO
                    bp.CONEXION = strConexion
                    bp.PDELETE(strSQL)

                End If
                If checkActivar.Checked = False Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = {cat} AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {num} AND BPDoc_Chi_Lin= {linea} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 980)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)

                    Dim bp As New Tablas.TDCMTOS_DTL_BOX_PRO
                    bp.CONEXION = strConexion
                    bp.PDELETE(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function
    Private Function GuardarDescargosPO() As Boolean
        Dim logResultado As Boolean = True
        Dim i As Integer
        Dim pro As New clsDcmtos_DTL_Pro
        Dim strSQL As String = STR_VACIO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = 952
                pro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colRefAnio").Value
                pro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colRefNum").Value
                pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colRefLin").Value   ' Que linea debe guardar aqui????????????????????
                pro.PDOC_CHI_CAT = 980
                pro.PDOC_CHI_ANO = celdaAnio.Text
                pro.PDOC_CHI_NUM = celdaNumero.Text
                pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                If checkActivar.Checked = True Then
                    pro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value
                Else
                    pro.PDOC_QTY_PRO = INT_CERO
                End If
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If pro.Actualizar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If pro.Borrar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
                If checkActivar.Checked = False Then
                    strSQL = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {cat}  AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num= {num} AND PDoc_Chi_Lin= {linea} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 980)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    Dim dpro As New clsDcmtos_DTL_Pro
                    dpro.CONEXION = strConexion
                    dpro.Borrar(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function
    Private Function PorcentajePO() As Double
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim dblPorcentaje As Double
        Try
            strSQL = " SELECT c.cat_sist Porcentaje "
            strSQL &= "     FROM Catalogos c  "
            strSQL &= "         WHERE c.cat_clase = 'PoP' "
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            dblPorcentaje = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblPorcentaje
    End Function
#End Region
#Region "Eventos"
    Private Sub frmPedidoProduccionHilo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)
        MostrarLista()
        If Sesion.IdEmpresa = 22 Then
            etiquetaDescripcion.Text = "Customer PO"
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        MostrarLista(False)
        celdaAnio.Text = cfun.AñoMySQL
        Reset()
        ' Activar()
    End Sub

    Private Sub frmPedidoProduccionHilo_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        End If
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency, cat_sist Rate"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(980, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value, 980)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim NumLong As Long
        Dim i As Integer
        Dim clsConta As New clsContabilidad
        Try
            If Me.Tag = "Nuevo" Then
                NumLong = celdaNumero.Text
                celdaNumero.Text = cfun.Verificacion_Nuevo_Registro(NumLong, "Dcmtos", 980, celdaAnio.Text)
                If celdaNumero.Text > 0 Then
                    If ComprobarCampos() = True Then

                        GuardarEncabezado()
                        ' GuardarCostos() ya no se usará
                        cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 980, celdaAnio.Text, celdaNumero.Text)
                        'GuardarCostosTiempo()
                        'GuardarCostosFijos()
                        'ActualizarTareas()

                        If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        Else
                            Me.Tag = "Mod"
                        End If
                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If
                End If
            ElseIf Me.Tag = "Mod" Then
                GuardarEncabezado()
                If checkActivar.Checked = False Then
                    GuardarDescargosPO()
                    GuardarDetalleBultosPO()
                End If
                ' GuardarCostos() ya no se usará
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 980, celdaAnio.Text, celdaNumero.Text)
                If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                    MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Reset()
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intCat As Integer
        Try
            If dgLista.Rows.Count = 0 Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(1).Value
            intNumero = dgLista.SelectedCells(2).Value
            intCat = dgLista.SelectedCells(0).Value
            CargarEncabezado(intAnio, intNumero)
            CargarDetalle(intAnio, intNumero)
            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarEncabezado()
                BorrarDetalle()
                BorrarDescargosPO()
                BorrarBultosPO()
                BorrarBultosProPO()
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 980, celdaAnio.Text, celdaNumero.Text)
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub

    Private Sub celdaLibras_TextChanged(sender As Object, e As EventArgs) Handles celdaLibras.TextChanged
        If cfun.ValidarCampoNumerico(celdaLibras) Then
            celdaTotalLibras.Text = CDbl(celdaLibras.Text / PorcentajePO()).ToString(FORMATO_MONEDA)
        End If
    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa} AND cli_status = 'Activo'"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Client"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "cli_codigo code,cli_cliente Client "
        frm.Tabla = "Clientes"
        frm.Condicion = strCondicion
        frm.Limite = 20
        frm.Ordenamiento = "cli_cliente < 0"
        frm.Filtro = "cli_cliente"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
        End If
    End Sub

#End Region
End Class