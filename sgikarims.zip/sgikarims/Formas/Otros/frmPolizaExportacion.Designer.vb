﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPolizaExportacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPolizaExportacion))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoDoc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezadoLista = New System.Windows.Forms.Panel()
        Me.botonClienteE = New System.Windows.Forms.Button()
        Me.celdaClienteE = New System.Windows.Forms.TextBox()
        Me.etiquetaClienteE = New System.Windows.Forms.Label()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.celdaTexto = New System.Windows.Forms.TextBox()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTotalCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.panelDgTotales = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.gbReferencia = New System.Windows.Forms.GroupBox()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.celdaFlete = New System.Windows.Forms.TextBox()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaSeguro = New System.Windows.Forms.Label()
        Me.etiquetaFlete = New System.Windows.Forms.Label()
        Me.etiquetaFactura = New System.Windows.Forms.Label()
        Me.gbDatosPoliza = New System.Windows.Forms.GroupBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.dgPolizaExportacion = New System.Windows.Forms.DataGridView()
        Me.colNumeroDR1_Dbl = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperadorP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colnumFel = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbPoliza = New System.Windows.Forms.GroupBox()
        Me.celdaNumero2 = New System.Windows.Forms.TextBox()
        Me.celdaRef2 = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.celdaDate = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.botonTipo = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCodigoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescuentoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMontoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colParteDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoUMDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colInciso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKgBrutos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKgNetos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFOB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFlete = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSeguro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtros = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCIF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDAI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGranTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.egress_line = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezadoLista.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.panelDgTotales.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDatos.SuspendLayout()
        Me.gbReferencia.SuspendLayout()
        Me.gbDatosPoliza.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgPolizaExportacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbPoliza.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelEncabezadoLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 92)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1072, 145)
        Me.panelLista.TabIndex = 7
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colNumero2, Me.colFecha, Me.colCliente, Me.colClase, Me.colReferencia, Me.colAnio, Me.colTipoDoc, Me.colEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 69)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1072, 76)
        Me.dgLista.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 69
        '
        'colNumero2
        '
        Me.colNumero2.HeaderText = "Number_"
        Me.colNumero2.Name = "colNumero2"
        Me.colNumero2.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        '
        'colClase
        '
        Me.colClase.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colClase.HeaderText = "Class"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colTipoDoc
        '
        Me.colTipoDoc.HeaderText = "TipoDoc"
        Me.colTipoDoc.Name = "colTipoDoc"
        Me.colTipoDoc.ReadOnly = True
        Me.colTipoDoc.Visible = False
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'panelEncabezadoLista
        '
        Me.panelEncabezadoLista.Controls.Add(Me.botonClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaFechas)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpInicial)
        Me.panelEncabezadoLista.Controls.Add(Me.checkFechas)
        Me.panelEncabezadoLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelEncabezadoLista.Name = "panelEncabezadoLista"
        Me.panelEncabezadoLista.Size = New System.Drawing.Size(1072, 69)
        Me.panelEncabezadoLista.TabIndex = 0
        '
        'botonClienteE
        '
        Me.botonClienteE.Location = New System.Drawing.Point(430, 44)
        Me.botonClienteE.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonClienteE.Name = "botonClienteE"
        Me.botonClienteE.Size = New System.Drawing.Size(28, 23)
        Me.botonClienteE.TabIndex = 7
        Me.botonClienteE.Text = "..."
        Me.botonClienteE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonClienteE.UseVisualStyleBackColor = True
        '
        'celdaClienteE
        '
        Me.celdaClienteE.Location = New System.Drawing.Point(98, 46)
        Me.celdaClienteE.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaClienteE.Name = "celdaClienteE"
        Me.celdaClienteE.Size = New System.Drawing.Size(325, 20)
        Me.celdaClienteE.TabIndex = 6
        '
        'etiquetaClienteE
        '
        Me.etiquetaClienteE.AutoSize = True
        Me.etiquetaClienteE.Location = New System.Drawing.Point(34, 48)
        Me.etiquetaClienteE.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaClienteE.Name = "etiquetaClienteE"
        Me.etiquetaClienteE.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaClienteE.TabIndex = 5
        Me.etiquetaClienteE.Text = "Cliente"
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(556, 8)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 21)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(364, 11)
        Me.etiquetaFechas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaFechas.TabIndex = 3
        Me.etiquetaFechas.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(426, 9)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(92, 20)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(262, 9)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(92, 20)
        Me.dtpInicial.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(37, 12)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(181, 17)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Show Documents Between Date"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.dgDetalle)
        Me.panelDocumento.Controls.Add(Me.celdaTexto)
        Me.panelDocumento.Controls.Add(Me.panelTotales)
        Me.panelDocumento.Controls.Add(Me.panelDatos)
        Me.panelDocumento.Location = New System.Drawing.Point(18, 247)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(932, 500)
        Me.panelDocumento.TabIndex = 8
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigoDet, Me.colDescripcionDet, Me.colMedidaDet, Me.colPrecioDet, Me.colDescuentoDet, Me.colMontoDet, Me.colBultos, Me.colCantidadDet, Me.colTotalDet, Me.colParteDet, Me.colCodigoUMDet, Me.colInciso, Me.colDescripDet, Me.colKgBrutos, Me.colKgNetos, Me.colFOB, Me.colFlete, Me.colSeguro, Me.colOtros, Me.colCIF, Me.colDAI, Me.colIVA, Me.colCosto, Me.colGranTotal, Me.colLinea, Me.egress_line})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 304)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(932, 103)
        Me.dgDetalle.TabIndex = 1
        '
        'celdaTexto
        '
        Me.celdaTexto.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.celdaTexto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaTexto.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaTexto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTexto.ForeColor = System.Drawing.Color.DodgerBlue
        Me.celdaTexto.Location = New System.Drawing.Point(0, 263)
        Me.celdaTexto.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTexto.Multiline = True
        Me.celdaTexto.Name = "celdaTexto"
        Me.celdaTexto.ReadOnly = True
        Me.celdaTexto.Size = New System.Drawing.Size(932, 41)
        Me.celdaTexto.TabIndex = 0
        Me.celdaTexto.Text = resources.GetString("celdaTexto.Text")
        Me.celdaTexto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaUsuario)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotalCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotales)
        Me.panelTotales.Controls.Add(Me.panelDgTotales)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 407)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(932, 93)
        Me.panelTotales.TabIndex = 2
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(605, 56)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(76, 20)
        Me.celdaUsuario.TabIndex = 21
        Me.celdaUsuario.Visible = False
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(794, 18)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(86, 20)
        Me.celdaTotal.TabIndex = 20
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotalCantidad
        '
        Me.celdaTotalCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalCantidad.Location = New System.Drawing.Point(669, 18)
        Me.celdaTotalCantidad.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTotalCantidad.Name = "celdaTotalCantidad"
        Me.celdaTotalCantidad.ReadOnly = True
        Me.celdaTotalCantidad.Size = New System.Drawing.Size(86, 20)
        Me.celdaTotalCantidad.TabIndex = 19
        Me.celdaTotalCantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(576, 22)
        Me.etiquetaTotales.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(42, 13)
        Me.etiquetaTotales.TabIndex = 1
        Me.etiquetaTotales.Text = "Totales"
        '
        'panelDgTotales
        '
        Me.panelDgTotales.Controls.Add(Me.dgDocumentos)
        Me.panelDgTotales.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDgTotales.Location = New System.Drawing.Point(0, 0)
        Me.panelDgTotales.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDgTotales.Name = "panelDgTotales"
        Me.panelDgTotales.Size = New System.Drawing.Size(375, 93)
        Me.panelDgTotales.TabIndex = 0
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.AllowUserToOrderColumns = True
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumento, Me.colDatos})
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumentos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDocumentos.MultiSelect = False
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.RowTemplate.Height = 24
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(375, 93)
        Me.dgDocumentos.TabIndex = 1
        '
        'colClave
        '
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        Me.colClave.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colDatos
        '
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.gbReferencia)
        Me.panelDatos.Controls.Add(Me.gbDatosPoliza)
        Me.panelDatos.Controls.Add(Me.gbPoliza)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(932, 263)
        Me.panelDatos.TabIndex = 0
        '
        'gbReferencia
        '
        Me.gbReferencia.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbReferencia.Controls.Add(Me.celdaSeguro)
        Me.gbReferencia.Controls.Add(Me.celdaFlete)
        Me.gbReferencia.Controls.Add(Me.celdaFactura)
        Me.gbReferencia.Controls.Add(Me.etiquetaSeguro)
        Me.gbReferencia.Controls.Add(Me.etiquetaFlete)
        Me.gbReferencia.Controls.Add(Me.etiquetaFactura)
        Me.gbReferencia.Location = New System.Drawing.Point(476, 149)
        Me.gbReferencia.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbReferencia.Name = "gbReferencia"
        Me.gbReferencia.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbReferencia.Size = New System.Drawing.Size(442, 112)
        Me.gbReferencia.TabIndex = 2
        Me.gbReferencia.TabStop = False
        Me.gbReferencia.Text = "Reference and Expenses"
        '
        'celdaSeguro
        '
        Me.celdaSeguro.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSeguro.Location = New System.Drawing.Point(68, 84)
        Me.celdaSeguro.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.ReadOnly = True
        Me.celdaSeguro.Size = New System.Drawing.Size(86, 20)
        Me.celdaSeguro.TabIndex = 28
        Me.celdaSeguro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaFlete
        '
        Me.celdaFlete.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFlete.Location = New System.Drawing.Point(68, 54)
        Me.celdaFlete.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaFlete.Name = "celdaFlete"
        Me.celdaFlete.ReadOnly = True
        Me.celdaFlete.Size = New System.Drawing.Size(86, 20)
        Me.celdaFlete.TabIndex = 27
        Me.celdaFlete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaFactura
        '
        Me.celdaFactura.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFactura.Location = New System.Drawing.Point(68, 22)
        Me.celdaFactura.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.ReadOnly = True
        Me.celdaFactura.Size = New System.Drawing.Size(179, 20)
        Me.celdaFactura.TabIndex = 19
        '
        'etiquetaSeguro
        '
        Me.etiquetaSeguro.AutoSize = True
        Me.etiquetaSeguro.Location = New System.Drawing.Point(4, 86)
        Me.etiquetaSeguro.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSeguro.Name = "etiquetaSeguro"
        Me.etiquetaSeguro.Size = New System.Drawing.Size(54, 13)
        Me.etiquetaSeguro.TabIndex = 24
        Me.etiquetaSeguro.Text = "Insurance"
        '
        'etiquetaFlete
        '
        Me.etiquetaFlete.AutoSize = True
        Me.etiquetaFlete.Location = New System.Drawing.Point(4, 57)
        Me.etiquetaFlete.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFlete.Name = "etiquetaFlete"
        Me.etiquetaFlete.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaFlete.TabIndex = 23
        Me.etiquetaFlete.Text = "Freight"
        '
        'etiquetaFactura
        '
        Me.etiquetaFactura.AutoSize = True
        Me.etiquetaFactura.Location = New System.Drawing.Point(4, 26)
        Me.etiquetaFactura.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFactura.Name = "etiquetaFactura"
        Me.etiquetaFactura.Size = New System.Drawing.Size(42, 13)
        Me.etiquetaFactura.TabIndex = 19
        Me.etiquetaFactura.Text = "Invoice"
        '
        'gbDatosPoliza
        '
        Me.gbDatosPoliza.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbDatosPoliza.Controls.Add(Me.panelBotones)
        Me.gbDatosPoliza.Controls.Add(Me.dgPolizaExportacion)
        Me.gbDatosPoliza.Location = New System.Drawing.Point(476, 4)
        Me.gbDatosPoliza.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbDatosPoliza.Name = "gbDatosPoliza"
        Me.gbDatosPoliza.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbDatosPoliza.Size = New System.Drawing.Size(444, 141)
        Me.gbDatosPoliza.TabIndex = 1
        Me.gbDatosPoliza.TabStop = False
        Me.gbDatosPoliza.Text = "Data for Export policy"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonMenos)
        Me.panelBotones.Controls.Add(Me.botonMas)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(396, 15)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(46, 124)
        Me.panelBotones.TabIndex = 1
        '
        'botonMenos
        '
        Me.botonMenos.Enabled = False
        Me.botonMenos.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonMenos.Location = New System.Drawing.Point(11, 46)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(26, 25)
        Me.botonMenos.TabIndex = 45
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Enabled = False
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(11, 10)
        Me.botonMas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(26, 25)
        Me.botonMas.TabIndex = 4
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'dgPolizaExportacion
        '
        Me.dgPolizaExportacion.AllowUserToAddRows = False
        Me.dgPolizaExportacion.AllowUserToDeleteRows = False
        Me.dgPolizaExportacion.AllowUserToOrderColumns = True
        Me.dgPolizaExportacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgPolizaExportacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPolizaExportacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPolizaExportacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumeroDR1_Dbl, Me.colNumeroP, Me.colFechaP, Me.colOperadorP, Me.colReferenciaP, Me.colAnioP, Me.colCatalogoP, Me.colnumFel, Me.colExtra})
        Me.dgPolizaExportacion.Location = New System.Drawing.Point(2, 15)
        Me.dgPolizaExportacion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgPolizaExportacion.MultiSelect = False
        Me.dgPolizaExportacion.Name = "dgPolizaExportacion"
        Me.dgPolizaExportacion.ReadOnly = True
        Me.dgPolizaExportacion.RowTemplate.Height = 24
        Me.dgPolizaExportacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPolizaExportacion.Size = New System.Drawing.Size(389, 98)
        Me.dgPolizaExportacion.TabIndex = 0
        '
        'colNumeroDR1_Dbl
        '
        Me.colNumeroDR1_Dbl.HeaderText = "Number"
        Me.colNumeroDR1_Dbl.Name = "colNumeroDR1_Dbl"
        Me.colNumeroDR1_Dbl.ReadOnly = True
        '
        'colNumeroP
        '
        Me.colNumeroP.HeaderText = "Number"
        Me.colNumeroP.Name = "colNumeroP"
        Me.colNumeroP.ReadOnly = True
        '
        'colFechaP
        '
        Me.colFechaP.HeaderText = "Date"
        Me.colFechaP.Name = "colFechaP"
        Me.colFechaP.ReadOnly = True
        '
        'colOperadorP
        '
        Me.colOperadorP.HeaderText = "Operator"
        Me.colOperadorP.Name = "colOperadorP"
        Me.colOperadorP.ReadOnly = True
        '
        'colReferenciaP
        '
        Me.colReferenciaP.HeaderText = "Reference"
        Me.colReferenciaP.Name = "colReferenciaP"
        Me.colReferenciaP.ReadOnly = True
        '
        'colAnioP
        '
        Me.colAnioP.HeaderText = "Anio"
        Me.colAnioP.Name = "colAnioP"
        Me.colAnioP.ReadOnly = True
        Me.colAnioP.Visible = False
        '
        'colCatalogoP
        '
        Me.colCatalogoP.HeaderText = "Catalogo"
        Me.colCatalogoP.Name = "colCatalogoP"
        Me.colCatalogoP.ReadOnly = True
        Me.colCatalogoP.Visible = False
        '
        'colnumFel
        '
        Me.colnumFel.HeaderText = "Numero Fel"
        Me.colnumFel.Name = "colnumFel"
        Me.colnumFel.ReadOnly = True
        Me.colnumFel.Visible = False
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'gbPoliza
        '
        Me.gbPoliza.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gbPoliza.Controls.Add(Me.celdaNumero2)
        Me.gbPoliza.Controls.Add(Me.celdaRef2)
        Me.gbPoliza.Controls.Add(Me.botonMoneda)
        Me.gbPoliza.Controls.Add(Me.dtpFecha)
        Me.gbPoliza.Controls.Add(Me.celdaNIT)
        Me.gbPoliza.Controls.Add(Me.celdaIdMoneda)
        Me.gbPoliza.Controls.Add(Me.celdaIdCliente)
        Me.gbPoliza.Controls.Add(Me.celdaDate)
        Me.gbPoliza.Controls.Add(Me.checkActivo)
        Me.gbPoliza.Controls.Add(Me.celdaTasa)
        Me.gbPoliza.Controls.Add(Me.celdaMoneda)
        Me.gbPoliza.Controls.Add(Me.celdaDireccion)
        Me.gbPoliza.Controls.Add(Me.botonCliente)
        Me.gbPoliza.Controls.Add(Me.celdaCliente)
        Me.gbPoliza.Controls.Add(Me.celdaNumero)
        Me.gbPoliza.Controls.Add(Me.celdaCatalogo)
        Me.gbPoliza.Controls.Add(Me.celdaAnio)
        Me.gbPoliza.Controls.Add(Me.etiquetaTasa)
        Me.gbPoliza.Controls.Add(Me.etiquetaMoneda)
        Me.gbPoliza.Controls.Add(Me.etiquetaDireccion)
        Me.gbPoliza.Controls.Add(Me.etiquetaCliente)
        Me.gbPoliza.Controls.Add(Me.etiquetaFecha)
        Me.gbPoliza.Controls.Add(Me.etiquetaNumero)
        Me.gbPoliza.Controls.Add(Me.etiquetaAnio)
        Me.gbPoliza.Location = New System.Drawing.Point(2, 6)
        Me.gbPoliza.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbPoliza.Name = "gbPoliza"
        Me.gbPoliza.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbPoliza.Size = New System.Drawing.Size(457, 257)
        Me.gbPoliza.TabIndex = 0
        Me.gbPoliza.TabStop = False
        Me.gbPoliza.Text = "Export policy"
        '
        'celdaNumero2
        '
        Me.celdaNumero2.Location = New System.Drawing.Point(80, 56)
        Me.celdaNumero2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumero2.Name = "celdaNumero2"
        Me.celdaNumero2.Size = New System.Drawing.Size(86, 20)
        Me.celdaNumero2.TabIndex = 25
        Me.celdaNumero2.Visible = False
        '
        'celdaRef2
        '
        Me.celdaRef2.Location = New System.Drawing.Point(383, 169)
        Me.celdaRef2.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRef2.Name = "celdaRef2"
        Me.celdaRef2.Size = New System.Drawing.Size(29, 20)
        Me.celdaRef2.TabIndex = 24
        Me.celdaRef2.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(170, 193)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(37, 20)
        Me.botonMoneda.TabIndex = 22
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(80, 88)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(86, 20)
        Me.dtpFecha.TabIndex = 20
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(336, 126)
        Me.celdaNIT.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(76, 20)
        Me.celdaNIT.TabIndex = 19
        Me.celdaNIT.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(224, 193)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(29, 20)
        Me.celdaIdMoneda.TabIndex = 18
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(201, 93)
        Me.celdaIdCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(62, 20)
        Me.celdaIdCliente.TabIndex = 18
        Me.celdaIdCliente.Visible = False
        '
        'celdaDate
        '
        Me.celdaDate.Location = New System.Drawing.Point(168, 89)
        Me.celdaDate.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDate.Name = "celdaDate"
        Me.celdaDate.Size = New System.Drawing.Size(62, 20)
        Me.celdaDate.TabIndex = 17
        Me.celdaDate.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(298, 33)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 16
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(80, 224)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(86, 20)
        Me.celdaTasa.TabIndex = 15
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(80, 193)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(86, 20)
        Me.celdaMoneda.TabIndex = 14
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(80, 145)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(271, 40)
        Me.celdaDireccion.TabIndex = 13
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(297, 116)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(28, 24)
        Me.botonCliente.TabIndex = 8
        Me.botonCliente.Text = "..."
        Me.botonCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(80, 119)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(214, 20)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(80, 59)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(86, 20)
        Me.celdaNumero.TabIndex = 10
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(145, 13)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(62, 20)
        Me.celdaCatalogo.TabIndex = 8
        Me.celdaCatalogo.Visible = False
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(80, 32)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(86, 20)
        Me.celdaAnio.TabIndex = 7
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(14, 224)
        Me.etiquetaTasa.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 6
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(14, 193)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 5
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(12, 145)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(40, 13)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Addres"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(12, 119)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(12, 89)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(12, 60)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(12, 32)
        Me.etiquetaAnio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'botonTipo
        '
        Me.botonTipo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonTipo.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonTipo.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonTipo.Location = New System.Drawing.Point(206, 9)
        Me.botonTipo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonTipo.Name = "botonTipo"
        Me.botonTipo.Size = New System.Drawing.Size(76, 43)
        Me.botonTipo.TabIndex = 22
        Me.botonTipo.Text = "Change Type"
        Me.botonTipo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonTipo.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 62)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1072, 30)
        Me.BarraTitulo1.TabIndex = 6
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1072, 62)
        Me.Encabezado1.TabIndex = 5
        '
        'colCodigoDet
        '
        Me.colCodigoDet.HeaderText = "Code"
        Me.colCodigoDet.Name = "colCodigoDet"
        Me.colCodigoDet.ReadOnly = True
        '
        'colDescripcionDet
        '
        Me.colDescripcionDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcionDet.HeaderText = "Description"
        Me.colDescripcionDet.Name = "colDescripcionDet"
        Me.colDescripcionDet.ReadOnly = True
        Me.colDescripcionDet.Width = 85
        '
        'colMedidaDet
        '
        Me.colMedidaDet.HeaderText = "Measure"
        Me.colMedidaDet.Name = "colMedidaDet"
        Me.colMedidaDet.ReadOnly = True
        '
        'colPrecioDet
        '
        Me.colPrecioDet.HeaderText = "Price"
        Me.colPrecioDet.Name = "colPrecioDet"
        Me.colPrecioDet.ReadOnly = True
        '
        'colDescuentoDet
        '
        Me.colDescuentoDet.HeaderText = "Discount %"
        Me.colDescuentoDet.Name = "colDescuentoDet"
        Me.colDescuentoDet.ReadOnly = True
        '
        'colMontoDet
        '
        Me.colMontoDet.HeaderText = "Discount $"
        Me.colMontoDet.Name = "colMontoDet"
        Me.colMontoDet.ReadOnly = True
        '
        'colBultos
        '
        Me.colBultos.HeaderText = "Packages"
        Me.colBultos.Name = "colBultos"
        '
        'colCantidadDet
        '
        Me.colCantidadDet.HeaderText = "Quantity"
        Me.colCantidadDet.Name = "colCantidadDet"
        Me.colCantidadDet.ReadOnly = True
        '
        'colTotalDet
        '
        Me.colTotalDet.HeaderText = "Total"
        Me.colTotalDet.Name = "colTotalDet"
        Me.colTotalDet.ReadOnly = True
        '
        'colParteDet
        '
        Me.colParteDet.HeaderText = "Part"
        Me.colParteDet.Name = "colParteDet"
        Me.colParteDet.ReadOnly = True
        Me.colParteDet.Visible = False
        '
        'colCodigoUMDet
        '
        Me.colCodigoUMDet.HeaderText = "Unit Code"
        Me.colCodigoUMDet.Name = "colCodigoUMDet"
        Me.colCodigoUMDet.ReadOnly = True
        Me.colCodigoUMDet.Visible = False
        '
        'colInciso
        '
        Me.colInciso.HeaderText = "Item"
        Me.colInciso.Name = "colInciso"
        '
        'colDescripDet
        '
        Me.colDescripDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripDet.HeaderText = "Description"
        Me.colDescripDet.Name = "colDescripDet"
        Me.colDescripDet.Width = 85
        '
        'colKgBrutos
        '
        Me.colKgBrutos.HeaderText = "KG Gross"
        Me.colKgBrutos.Name = "colKgBrutos"
        '
        'colKgNetos
        '
        Me.colKgNetos.HeaderText = "KG Net"
        Me.colKgNetos.Name = "colKgNetos"
        '
        'colFOB
        '
        Me.colFOB.HeaderText = "FOB ($)"
        Me.colFOB.Name = "colFOB"
        '
        'colFlete
        '
        Me.colFlete.HeaderText = "Freight ($)"
        Me.colFlete.Name = "colFlete"
        '
        'colSeguro
        '
        Me.colSeguro.HeaderText = "Insurance ($)"
        Me.colSeguro.Name = "colSeguro"
        '
        'colOtros
        '
        Me.colOtros.HeaderText = "Others ($)"
        Me.colOtros.Name = "colOtros"
        '
        'colCIF
        '
        Me.colCIF.HeaderText = "CIF ($)"
        Me.colCIF.Name = "colCIF"
        '
        'colDAI
        '
        Me.colDAI.HeaderText = "DAI (Q)"
        Me.colDAI.Name = "colDAI"
        '
        'colIVA
        '
        Me.colIVA.HeaderText = "IVA (Q)"
        Me.colIVA.Name = "colIVA"
        '
        'colCosto
        '
        Me.colCosto.HeaderText = "CostoU"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.Visible = False
        '
        'colGranTotal
        '
        Me.colGranTotal.HeaderText = "GranTotal"
        Me.colGranTotal.Name = "colGranTotal"
        Me.colGranTotal.Visible = False
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        '
        'egress_line
        '
        Me.egress_line.HeaderText = "egress line"
        Me.egress_line.Name = "egress_line"
        Me.egress_line.Visible = False
        '
        'frmPolizaExportacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1072, 756)
        Me.Controls.Add(Me.botonTipo)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmPolizaExportacion"
        Me.Text = "frmPolizaExportacion"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezadoLista.ResumeLayout(False)
        Me.panelEncabezadoLista.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelDgTotales.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDatos.ResumeLayout(False)
        Me.gbReferencia.ResumeLayout(False)
        Me.gbReferencia.PerformLayout()
        Me.gbDatosPoliza.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgPolizaExportacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbPoliza.ResumeLayout(False)
        Me.gbPoliza.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelEncabezadoLista As Panel
    Friend WithEvents botonClienteE As Button
    Friend WithEvents celdaClienteE As TextBox
    Friend WithEvents etiquetaClienteE As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents celdaTexto As TextBox
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaTotalCantidad As TextBox
    Friend WithEvents etiquetaTotales As Label
    Friend WithEvents panelDgTotales As Panel
    Friend WithEvents dgDocumentos As DataGridView
    Friend WithEvents panelDatos As Panel
    Friend WithEvents gbReferencia As GroupBox
    Friend WithEvents celdaSeguro As TextBox
    Friend WithEvents celdaFlete As TextBox
    Friend WithEvents celdaFactura As TextBox
    Friend WithEvents etiquetaSeguro As Label
    Friend WithEvents etiquetaFlete As Label
    Friend WithEvents etiquetaFactura As Label
    Friend WithEvents gbDatosPoliza As GroupBox
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents dgPolizaExportacion As DataGridView
    Friend WithEvents gbPoliza As GroupBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaNIT As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents celdaDate As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents botonTipo As Button
    Friend WithEvents celdaRef2 As TextBox
    Friend WithEvents colClave As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colDatos As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroDR1_Dbl As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroP As DataGridViewTextBoxColumn
    Friend WithEvents colFechaP As DataGridViewTextBoxColumn
    Friend WithEvents colOperadorP As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaP As DataGridViewTextBoxColumn
    Friend WithEvents colAnioP As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoP As DataGridViewTextBoxColumn
    Friend WithEvents colnumFel As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents celdaNumero2 As TextBox
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colNumero2 As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colClase As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colTipoDoc As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionDet As DataGridViewTextBoxColumn
    Friend WithEvents colMedidaDet As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescuentoDet As DataGridViewTextBoxColumn
    Friend WithEvents colMontoDet As DataGridViewTextBoxColumn
    Friend WithEvents colBultos As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadDet As DataGridViewTextBoxColumn
    Friend WithEvents colTotalDet As DataGridViewTextBoxColumn
    Friend WithEvents colParteDet As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoUMDet As DataGridViewTextBoxColumn
    Friend WithEvents colInciso As DataGridViewTextBoxColumn
    Friend WithEvents colDescripDet As DataGridViewTextBoxColumn
    Friend WithEvents colKgBrutos As DataGridViewTextBoxColumn
    Friend WithEvents colKgNetos As DataGridViewTextBoxColumn
    Friend WithEvents colFOB As DataGridViewTextBoxColumn
    Friend WithEvents colFlete As DataGridViewTextBoxColumn
    Friend WithEvents colSeguro As DataGridViewTextBoxColumn
    Friend WithEvents colOtros As DataGridViewTextBoxColumn
    Friend WithEvents colCIF As DataGridViewTextBoxColumn
    Friend WithEvents colDAI As DataGridViewTextBoxColumn
    Friend WithEvents colIVA As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colGranTotal As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents egress_line As DataGridViewTextBoxColumn
End Class
