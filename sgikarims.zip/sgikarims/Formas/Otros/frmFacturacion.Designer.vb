﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFacturacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFacturacion))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelColores = New System.Windows.Forms.Panel()
        Me.CheckMuestraDetalle = New System.Windows.Forms.CheckBox()
        Me.celdaInfoDetalle = New System.Windows.Forms.TextBox()
        Me.celdaColorVerde = New System.Windows.Forms.TextBox()
        Me.colorAqua = New System.Windows.Forms.TextBox()
        Me.celdaColorNaranja = New System.Windows.Forms.TextBox()
        Me.celdaColorRosado = New System.Windows.Forms.TextBox()
        Me.celdaColorAmarillo = New System.Windows.Forms.TextBox()
        Me.celdaColorRojo = New System.Windows.Forms.TextBox()
        Me.etiquetaSinPoliza = New System.Windows.Forms.Label()
        Me.etiquetaNoCargado = New System.Windows.Forms.Label()
        Me.etiquetaNoImpreso = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.etiquetaSalidaPendiente = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSalida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpues = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBloqueado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizacionF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabLista = New System.Windows.Forms.Panel()
        Me.botonPoliza = New System.Windows.Forms.Button()
        Me.botonLiberar = New System.Windows.Forms.Button()
        Me.botonSalida = New System.Windows.Forms.Button()
        Me.botonCarga = New System.Windows.Forms.Button()
        Me.botonConcolidacion = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaAnd = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.celdaTipoFactura = New System.Windows.Forms.TextBox()
        Me.gbFel = New System.Windows.Forms.GroupBox()
        Me.celdaNumeroFel = New System.Windows.Forms.TextBox()
        Me.celdaSerieFelServi = New System.Windows.Forms.TextBox()
        Me.etiquetaNumFel = New System.Windows.Forms.Label()
        Me.etiquetaSerieFel = New System.Windows.Forms.Label()
        Me.celdaIDEmpPagadora = New System.Windows.Forms.TextBox()
        Me.celdaEmpPagadora = New System.Windows.Forms.TextBox()
        Me.etiquetaEmpPagadora = New System.Windows.Forms.Label()
        Me.panelInfoFinal = New System.Windows.Forms.Panel()
        Me.celdaGranTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaGranTotal = New System.Windows.Forms.Label()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.etiquetaTotalDesc = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaTotalDescuento = New System.Windows.Forms.TextBox()
        Me.celdaDescuento = New System.Windows.Forms.TextBox()
        Me.celdaTotal1 = New System.Windows.Forms.TextBox()
        Me.celdaTotal2 = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.checkDetGatos = New System.Windows.Forms.CheckBox()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.dgDatos = New System.Windows.Forms.DataGridView()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecDoc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAbono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDias = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelSubDocumentos = New System.Windows.Forms.Panel()
        Me.dgSubdocumentos = New System.Windows.Forms.DataGridView()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgrega = New System.Windows.Forms.Button()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.gbInfoAdd = New System.Windows.Forms.GroupBox()
        Me.panelPlantas = New System.Windows.Forms.Panel()
        Me.checkDestino = New System.Windows.Forms.CheckBox()
        Me.dgReferencia = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPolicy = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaInstruccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisponible = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantDescargada = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colModificado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colQuitar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colInstruccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaValidacionFlete = New System.Windows.Forms.TextBox()
        Me.botonSeguro = New System.Windows.Forms.Button()
        Me.rbExportacion = New System.Windows.Forms.RadioButton()
        Me.rbNacionalizacion = New System.Windows.Forms.RadioButton()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.celdaFlete = New System.Windows.Forms.TextBox()
        Me.etiquetaSeguro = New System.Windows.Forms.Label()
        Me.etiquetaFlete = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaNotas = New System.Windows.Forms.TextBox()
        Me.panelListaDespachInstr = New System.Windows.Forms.Panel()
        Me.dgInstrucDespacho = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñ = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colInst = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFech = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperador = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbInvoiceInfo = New System.Windows.Forms.GroupBox()
        Me.celdaIDSerie = New System.Windows.Forms.TextBox()
        Me.celdaFechaEmisionDocumento = New System.Windows.Forms.TextBox()
        Me.celdaFechaHoraCertificacion = New System.Windows.Forms.TextBox()
        Me.celdaSerieFel = New System.Windows.Forms.TextBox()
        Me.celdaUUID = New System.Windows.Forms.TextBox()
        Me.celdaFechavencimiento = New System.Windows.Forms.TextBox()
        Me.celdaCAI = New System.Windows.Forms.TextBox()
        Me.etiquetaCAI = New System.Windows.Forms.Label()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.celdaNum2 = New System.Windows.Forms.TextBox()
        Me.celdaSubDocumento = New System.Windows.Forms.TextBox()
        Me.celdaSalida = New System.Windows.Forms.TextBox()
        Me.celdaImpreso = New System.Windows.Forms.TextBox()
        Me.celdaPoliza = New System.Windows.Forms.TextBox()
        Me.celdaBloqueado = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaCargado = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.etiquetaAnulada = New System.Windows.Forms.Label()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaNit = New System.Windows.Forms.Label()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.botonPrevio = New System.Windows.Forms.Button()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.etiquetaAutorizacion = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDescrip = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDespacho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescDolar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoBulto = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colBobina = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDistribucion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodLugar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLugDestino = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colLBS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKGS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKGNetos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKGNetosExt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOriginal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferences = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioPF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEliminar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombreCta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteNuevo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        Me.panelColores.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabLista.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.gbFel.SuspendLayout()
        Me.panelInfoFinal.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSubDocumentos.SuspendLayout()
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbInfoAdd.SuspendLayout()
        Me.panelPlantas.SuspendLayout()
        CType(Me.dgReferencia, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.panelListaDespachInstr.SuspendLayout()
        CType(Me.dgInstrucDespacho, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbInvoiceInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.panelColores)
        Me.panelLista.Controls.Add(Me.Panel1)
        Me.panelLista.Controls.Add(Me.panelEncabLista)
        Me.panelLista.Location = New System.Drawing.Point(11, 227)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1007, 262)
        Me.panelLista.TabIndex = 2
        '
        'panelColores
        '
        Me.panelColores.BackColor = System.Drawing.SystemColors.Info
        Me.panelColores.Controls.Add(Me.CheckMuestraDetalle)
        Me.panelColores.Controls.Add(Me.celdaInfoDetalle)
        Me.panelColores.Controls.Add(Me.celdaColorVerde)
        Me.panelColores.Controls.Add(Me.colorAqua)
        Me.panelColores.Controls.Add(Me.celdaColorNaranja)
        Me.panelColores.Controls.Add(Me.celdaColorRosado)
        Me.panelColores.Controls.Add(Me.celdaColorAmarillo)
        Me.panelColores.Controls.Add(Me.celdaColorRojo)
        Me.panelColores.Controls.Add(Me.etiquetaSinPoliza)
        Me.panelColores.Controls.Add(Me.etiquetaNoCargado)
        Me.panelColores.Controls.Add(Me.etiquetaNoImpreso)
        Me.panelColores.Controls.Add(Me.Label1)
        Me.panelColores.Controls.Add(Me.Label2)
        Me.panelColores.Controls.Add(Me.etiquetaSalidaPendiente)
        Me.panelColores.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelColores.Location = New System.Drawing.Point(0, 121)
        Me.panelColores.Name = "panelColores"
        Me.panelColores.Size = New System.Drawing.Size(1007, 141)
        Me.panelColores.TabIndex = 2
        '
        'CheckMuestraDetalle
        '
        Me.CheckMuestraDetalle.AutoSize = True
        Me.CheckMuestraDetalle.CheckAlign = System.Drawing.ContentAlignment.TopRight
        Me.CheckMuestraDetalle.Location = New System.Drawing.Point(897, 20)
        Me.CheckMuestraDetalle.Name = "CheckMuestraDetalle"
        Me.CheckMuestraDetalle.Size = New System.Drawing.Size(104, 21)
        Me.CheckMuestraDetalle.TabIndex = 37
        Me.CheckMuestraDetalle.Text = "Show Detail"
        Me.CheckMuestraDetalle.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckMuestraDetalle.UseVisualStyleBackColor = True
        '
        'celdaInfoDetalle
        '
        Me.celdaInfoDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaInfoDetalle.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoDetalle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfoDetalle.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaInfoDetalle.Location = New System.Drawing.Point(16, 4)
        Me.celdaInfoDetalle.Multiline = True
        Me.celdaInfoDetalle.Name = "celdaInfoDetalle"
        Me.celdaInfoDetalle.ReadOnly = True
        Me.celdaInfoDetalle.Size = New System.Drawing.Size(872, 103)
        Me.celdaInfoDetalle.TabIndex = 38
        '
        'celdaColorVerde
        '
        Me.celdaColorVerde.BackColor = System.Drawing.Color.Lime
        Me.celdaColorVerde.Location = New System.Drawing.Point(767, 109)
        Me.celdaColorVerde.Name = "celdaColorVerde"
        Me.celdaColorVerde.ReadOnly = True
        Me.celdaColorVerde.Size = New System.Drawing.Size(21, 22)
        Me.celdaColorVerde.TabIndex = 29
        '
        'colorAqua
        '
        Me.colorAqua.BackColor = System.Drawing.Color.Cyan
        Me.colorAqua.Location = New System.Drawing.Point(624, 109)
        Me.colorAqua.Name = "colorAqua"
        Me.colorAqua.ReadOnly = True
        Me.colorAqua.Size = New System.Drawing.Size(21, 22)
        Me.colorAqua.TabIndex = 28
        '
        'celdaColorNaranja
        '
        Me.celdaColorNaranja.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.celdaColorNaranja.Location = New System.Drawing.Point(464, 109)
        Me.celdaColorNaranja.Name = "celdaColorNaranja"
        Me.celdaColorNaranja.ReadOnly = True
        Me.celdaColorNaranja.Size = New System.Drawing.Size(21, 22)
        Me.celdaColorNaranja.TabIndex = 27
        '
        'celdaColorRosado
        '
        Me.celdaColorRosado.BackColor = System.Drawing.Color.Magenta
        Me.celdaColorRosado.Location = New System.Drawing.Point(318, 109)
        Me.celdaColorRosado.Name = "celdaColorRosado"
        Me.celdaColorRosado.Size = New System.Drawing.Size(21, 22)
        Me.celdaColorRosado.TabIndex = 26
        '
        'celdaColorAmarillo
        '
        Me.celdaColorAmarillo.BackColor = System.Drawing.Color.Yellow
        Me.celdaColorAmarillo.Location = New System.Drawing.Point(186, 109)
        Me.celdaColorAmarillo.Name = "celdaColorAmarillo"
        Me.celdaColorAmarillo.ReadOnly = True
        Me.celdaColorAmarillo.Size = New System.Drawing.Size(21, 22)
        Me.celdaColorAmarillo.TabIndex = 30
        '
        'celdaColorRojo
        '
        Me.celdaColorRojo.BackColor = System.Drawing.Color.Red
        Me.celdaColorRojo.Location = New System.Drawing.Point(27, 109)
        Me.celdaColorRojo.Name = "celdaColorRojo"
        Me.celdaColorRojo.ReadOnly = True
        Me.celdaColorRojo.Size = New System.Drawing.Size(21, 22)
        Me.celdaColorRojo.TabIndex = 25
        '
        'etiquetaSinPoliza
        '
        Me.etiquetaSinPoliza.AutoSize = True
        Me.etiquetaSinPoliza.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaSinPoliza.Location = New System.Drawing.Point(794, 113)
        Me.etiquetaSinPoliza.Name = "etiquetaSinPoliza"
        Me.etiquetaSinPoliza.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaSinPoliza.TabIndex = 36
        Me.etiquetaSinPoliza.Text = "No Policy"
        '
        'etiquetaNoCargado
        '
        Me.etiquetaNoCargado.AutoSize = True
        Me.etiquetaNoCargado.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaNoCargado.Location = New System.Drawing.Point(653, 113)
        Me.etiquetaNoCargado.Name = "etiquetaNoCargado"
        Me.etiquetaNoCargado.Size = New System.Drawing.Size(78, 17)
        Me.etiquetaNoCargado.TabIndex = 35
        Me.etiquetaNoCargado.Text = "Uncharged"
        '
        'etiquetaNoImpreso
        '
        Me.etiquetaNoImpreso.AutoSize = True
        Me.etiquetaNoImpreso.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaNoImpreso.Location = New System.Drawing.Point(212, 113)
        Me.etiquetaNoImpreso.Name = "etiquetaNoImpreso"
        Me.etiquetaNoImpreso.Size = New System.Drawing.Size(70, 17)
        Me.etiquetaNoImpreso.TabIndex = 32
        Me.etiquetaNoImpreso.Text = "Unprinted"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Info
        Me.Label1.Location = New System.Drawing.Point(57, 113)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 17)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "-ANNULLED-"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Info
        Me.Label2.Location = New System.Drawing.Point(347, 113)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 17)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Uncertificated"
        '
        'etiquetaSalidaPendiente
        '
        Me.etiquetaSalidaPendiente.AutoSize = True
        Me.etiquetaSalidaPendiente.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaSalidaPendiente.Location = New System.Drawing.Point(493, 113)
        Me.etiquetaSalidaPendiente.Name = "etiquetaSalidaPendiente"
        Me.etiquetaSalidaPendiente.Size = New System.Drawing.Size(71, 17)
        Me.etiquetaSalidaPendiente.TabIndex = 34
        Me.etiquetaSalidaPendiente.Text = "Slope Out"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.dgLista)
        Me.Panel1.Location = New System.Drawing.Point(0, 61)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1007, 51)
        Me.Panel1.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colYear, Me.colNum2, Me.colNumero, Me.colFecha, Me.colCliente, Me.colReferencia, Me.colImpreso, Me.colStatus, Me.colSalida, Me.colImpues, Me.colBloqueado, Me.colCargado, Me.colPoliza, Me.colDireccion, Me.colNit, Me.colSerieF, Me.colAutorizacionF})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowHeadersWidth = 51
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1007, 51)
        Me.dgLista.TabIndex = 3
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.MinimumWidth = 6
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        Me.colYear.Visible = False
        Me.colYear.Width = 125
        '
        'colNum2
        '
        Me.colNum2.HeaderText = "Num"
        Me.colNum2.MinimumWidth = 6
        Me.colNum2.Name = "colNum2"
        Me.colNum2.ReadOnly = True
        Me.colNum2.Visible = False
        Me.colNum2.Width = 125
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.MinimumWidth = 6
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 125
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.MinimumWidth = 6
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.MinimumWidth = 6
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 72
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.MinimumWidth = 6
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colImpreso
        '
        Me.colImpreso.HeaderText = "Impreso"
        Me.colImpreso.MinimumWidth = 6
        Me.colImpreso.Name = "colImpreso"
        Me.colImpreso.ReadOnly = True
        Me.colImpreso.Visible = False
        Me.colImpreso.Width = 125
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.MinimumWidth = 6
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Visible = False
        Me.colStatus.Width = 125
        '
        'colSalida
        '
        Me.colSalida.HeaderText = "Salida"
        Me.colSalida.MinimumWidth = 6
        Me.colSalida.Name = "colSalida"
        Me.colSalida.ReadOnly = True
        Me.colSalida.Visible = False
        Me.colSalida.Width = 125
        '
        'colImpues
        '
        Me.colImpues.HeaderText = "Impuesto"
        Me.colImpues.MinimumWidth = 6
        Me.colImpues.Name = "colImpues"
        Me.colImpues.ReadOnly = True
        Me.colImpues.Visible = False
        Me.colImpues.Width = 125
        '
        'colBloqueado
        '
        Me.colBloqueado.HeaderText = "bloqueado"
        Me.colBloqueado.MinimumWidth = 6
        Me.colBloqueado.Name = "colBloqueado"
        Me.colBloqueado.ReadOnly = True
        Me.colBloqueado.Visible = False
        Me.colBloqueado.Width = 125
        '
        'colCargado
        '
        Me.colCargado.HeaderText = "Cargado"
        Me.colCargado.MinimumWidth = 6
        Me.colCargado.Name = "colCargado"
        Me.colCargado.ReadOnly = True
        Me.colCargado.Visible = False
        Me.colCargado.Width = 125
        '
        'colPoliza
        '
        Me.colPoliza.HeaderText = "Poliza"
        Me.colPoliza.MinimumWidth = 6
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        Me.colPoliza.Visible = False
        Me.colPoliza.Width = 125
        '
        'colDireccion
        '
        Me.colDireccion.HeaderText = "Direction"
        Me.colDireccion.MinimumWidth = 6
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.ReadOnly = True
        Me.colDireccion.Visible = False
        Me.colDireccion.Width = 125
        '
        'colNit
        '
        Me.colNit.HeaderText = "Nit"
        Me.colNit.MinimumWidth = 6
        Me.colNit.Name = "colNit"
        Me.colNit.ReadOnly = True
        Me.colNit.Visible = False
        Me.colNit.Width = 125
        '
        'colSerieF
        '
        Me.colSerieF.HeaderText = "Serie Fel"
        Me.colSerieF.MinimumWidth = 6
        Me.colSerieF.Name = "colSerieF"
        Me.colSerieF.ReadOnly = True
        Me.colSerieF.Width = 125
        '
        'colAutorizacionF
        '
        Me.colAutorizacionF.HeaderText = "Autorizacion Fel"
        Me.colAutorizacionF.MinimumWidth = 6
        Me.colAutorizacionF.Name = "colAutorizacionF"
        Me.colAutorizacionF.ReadOnly = True
        Me.colAutorizacionF.Width = 125
        '
        'panelEncabLista
        '
        Me.panelEncabLista.Controls.Add(Me.botonPoliza)
        Me.panelEncabLista.Controls.Add(Me.botonLiberar)
        Me.panelEncabLista.Controls.Add(Me.botonSalida)
        Me.panelEncabLista.Controls.Add(Me.botonCarga)
        Me.panelEncabLista.Controls.Add(Me.botonConcolidacion)
        Me.panelEncabLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabLista.Controls.Add(Me.etiquetaAnd)
        Me.panelEncabLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabLista.Controls.Add(Me.dtpInicio)
        Me.panelEncabLista.Controls.Add(Me.checkFecha)
        Me.panelEncabLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabLista.Name = "panelEncabLista"
        Me.panelEncabLista.Size = New System.Drawing.Size(1007, 61)
        Me.panelEncabLista.TabIndex = 0
        '
        'botonPoliza
        '
        Me.botonPoliza.Enabled = False
        Me.botonPoliza.Image = CType(resources.GetObject("botonPoliza.Image"), System.Drawing.Image)
        Me.botonPoliza.Location = New System.Drawing.Point(837, 18)
        Me.botonPoliza.Name = "botonPoliza"
        Me.botonPoliza.Size = New System.Drawing.Size(33, 28)
        Me.botonPoliza.TabIndex = 9
        Me.botonPoliza.UseVisualStyleBackColor = True
        '
        'botonLiberar
        '
        Me.botonLiberar.Enabled = False
        Me.botonLiberar.Image = Global.KARIMs_SGI.My.Resources.Resources.lock_open
        Me.botonLiberar.Location = New System.Drawing.Point(878, 18)
        Me.botonLiberar.Name = "botonLiberar"
        Me.botonLiberar.Size = New System.Drawing.Size(33, 28)
        Me.botonLiberar.TabIndex = 8
        Me.botonLiberar.UseVisualStyleBackColor = True
        '
        'botonSalida
        '
        Me.botonSalida.Enabled = False
        Me.botonSalida.Image = CType(resources.GetObject("botonSalida.Image"), System.Drawing.Image)
        Me.botonSalida.Location = New System.Drawing.Point(919, 17)
        Me.botonSalida.Name = "botonSalida"
        Me.botonSalida.Size = New System.Drawing.Size(33, 28)
        Me.botonSalida.TabIndex = 7
        Me.botonSalida.UseVisualStyleBackColor = True
        '
        'botonCarga
        '
        Me.botonCarga.BackColor = System.Drawing.SystemColors.Control
        Me.botonCarga.Enabled = False
        Me.botonCarga.Image = CType(resources.GetObject("botonCarga.Image"), System.Drawing.Image)
        Me.botonCarga.Location = New System.Drawing.Point(796, 18)
        Me.botonCarga.Name = "botonCarga"
        Me.botonCarga.Size = New System.Drawing.Size(33, 28)
        Me.botonCarga.TabIndex = 6
        Me.botonCarga.UseVisualStyleBackColor = False
        '
        'botonConcolidacion
        '
        Me.botonConcolidacion.Location = New System.Drawing.Point(697, 18)
        Me.botonConcolidacion.Name = "botonConcolidacion"
        Me.botonConcolidacion.Size = New System.Drawing.Size(92, 28)
        Me.botonConcolidacion.TabIndex = 5
        Me.botonConcolidacion.Text = "Consolidation"
        Me.botonConcolidacion.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(542, 18)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(87, 28)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaAnd
        '
        Me.etiquetaAnd.AutoSize = True
        Me.etiquetaAnd.Location = New System.Drawing.Point(358, 24)
        Me.etiquetaAnd.Name = "etiquetaAnd"
        Me.etiquetaAnd.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaAnd.TabIndex = 3
        Me.etiquetaAnd.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(422, 17)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(112, 22)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(237, 17)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(20, 23)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(94, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "ShowDate"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.celdaTipoFactura)
        Me.panelDocumento.Controls.Add(Me.gbFel)
        Me.panelDocumento.Controls.Add(Me.celdaIDEmpPagadora)
        Me.panelDocumento.Controls.Add(Me.celdaEmpPagadora)
        Me.panelDocumento.Controls.Add(Me.etiquetaEmpPagadora)
        Me.panelDocumento.Controls.Add(Me.panelInfoFinal)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.gbInfoAdd)
        Me.panelDocumento.Controls.Add(Me.GroupBox1)
        Me.panelDocumento.Controls.Add(Me.gbInvoiceInfo)
        Me.panelDocumento.Location = New System.Drawing.Point(60, 200)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1114, 654)
        Me.panelDocumento.TabIndex = 3
        '
        'celdaTipoFactura
        '
        Me.celdaTipoFactura.Location = New System.Drawing.Point(568, 13)
        Me.celdaTipoFactura.Name = "celdaTipoFactura"
        Me.celdaTipoFactura.Size = New System.Drawing.Size(34, 22)
        Me.celdaTipoFactura.TabIndex = 51
        Me.celdaTipoFactura.Text = "-1"
        Me.celdaTipoFactura.Visible = False
        '
        'gbFel
        '
        Me.gbFel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFel.BackColor = System.Drawing.SystemColors.Info
        Me.gbFel.Controls.Add(Me.celdaNumeroFel)
        Me.gbFel.Controls.Add(Me.celdaSerieFelServi)
        Me.gbFel.Controls.Add(Me.etiquetaNumFel)
        Me.gbFel.Controls.Add(Me.etiquetaSerieFel)
        Me.gbFel.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbFel.Location = New System.Drawing.Point(607, 7)
        Me.gbFel.Margin = New System.Windows.Forms.Padding(2)
        Me.gbFel.Name = "gbFel"
        Me.gbFel.Padding = New System.Windows.Forms.Padding(2)
        Me.gbFel.Size = New System.Drawing.Size(457, 56)
        Me.gbFel.TabIndex = 26
        Me.gbFel.TabStop = False
        Me.gbFel.Text = "FEL Data"
        '
        'celdaNumeroFel
        '
        Me.celdaNumeroFel.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumeroFel.Location = New System.Drawing.Point(249, 19)
        Me.celdaNumeroFel.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroFel.Name = "celdaNumeroFel"
        Me.celdaNumeroFel.Size = New System.Drawing.Size(202, 22)
        Me.celdaNumeroFel.TabIndex = 3
        '
        'celdaSerieFelServi
        '
        Me.celdaSerieFelServi.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSerieFelServi.Location = New System.Drawing.Point(46, 19)
        Me.celdaSerieFelServi.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSerieFelServi.Name = "celdaSerieFelServi"
        Me.celdaSerieFelServi.Size = New System.Drawing.Size(136, 22)
        Me.celdaSerieFelServi.TabIndex = 2
        '
        'etiquetaNumFel
        '
        Me.etiquetaNumFel.AutoSize = True
        Me.etiquetaNumFel.Location = New System.Drawing.Point(193, 23)
        Me.etiquetaNumFel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumFel.Name = "etiquetaNumFel"
        Me.etiquetaNumFel.Size = New System.Drawing.Size(55, 16)
        Me.etiquetaNumFel.TabIndex = 1
        Me.etiquetaNumFel.Text = "Number"
        '
        'etiquetaSerieFel
        '
        Me.etiquetaSerieFel.AutoSize = True
        Me.etiquetaSerieFel.Location = New System.Drawing.Point(4, 24)
        Me.etiquetaSerieFel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerieFel.Name = "etiquetaSerieFel"
        Me.etiquetaSerieFel.Size = New System.Drawing.Size(39, 16)
        Me.etiquetaSerieFel.TabIndex = 0
        Me.etiquetaSerieFel.Text = "Serie"
        '
        'celdaIDEmpPagadora
        '
        Me.celdaIDEmpPagadora.Location = New System.Drawing.Point(487, 9)
        Me.celdaIDEmpPagadora.Name = "celdaIDEmpPagadora"
        Me.celdaIDEmpPagadora.Size = New System.Drawing.Size(34, 22)
        Me.celdaIDEmpPagadora.TabIndex = 25
        Me.celdaIDEmpPagadora.Text = "-1"
        Me.celdaIDEmpPagadora.Visible = False
        '
        'celdaEmpPagadora
        '
        Me.celdaEmpPagadora.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaEmpPagadora.BackColor = System.Drawing.SystemColors.Info
        Me.celdaEmpPagadora.Enabled = False
        Me.celdaEmpPagadora.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaEmpPagadora.ForeColor = System.Drawing.Color.MediumBlue
        Me.celdaEmpPagadora.Location = New System.Drawing.Point(538, 35)
        Me.celdaEmpPagadora.Name = "celdaEmpPagadora"
        Me.celdaEmpPagadora.ReadOnly = True
        Me.celdaEmpPagadora.Size = New System.Drawing.Size(16, 22)
        Me.celdaEmpPagadora.TabIndex = 11
        '
        'etiquetaEmpPagadora
        '
        Me.etiquetaEmpPagadora.AutoSize = True
        Me.etiquetaEmpPagadora.Location = New System.Drawing.Point(466, 35)
        Me.etiquetaEmpPagadora.Name = "etiquetaEmpPagadora"
        Me.etiquetaEmpPagadora.Size = New System.Drawing.Size(75, 17)
        Me.etiquetaEmpPagadora.TabIndex = 10
        Me.etiquetaEmpPagadora.Text = "Paymaster"
        '
        'panelInfoFinal
        '
        Me.panelInfoFinal.Controls.Add(Me.celdaGranTotal)
        Me.panelInfoFinal.Controls.Add(Me.etiquetaGranTotal)
        Me.panelInfoFinal.Controls.Add(Me.etiquetaCantidad)
        Me.panelInfoFinal.Controls.Add(Me.etiquetaTotalDesc)
        Me.panelInfoFinal.Controls.Add(Me.Label3)
        Me.panelInfoFinal.Controls.Add(Me.celdaTotalDescuento)
        Me.panelInfoFinal.Controls.Add(Me.celdaDescuento)
        Me.panelInfoFinal.Controls.Add(Me.celdaTotal1)
        Me.panelInfoFinal.Controls.Add(Me.celdaTotal2)
        Me.panelInfoFinal.Controls.Add(Me.etiquetaTotales)
        Me.panelInfoFinal.Controls.Add(Me.checkDetGatos)
        Me.panelInfoFinal.Controls.Add(Me.panelDatos)
        Me.panelInfoFinal.Controls.Add(Me.panelSubDocumentos)
        Me.panelInfoFinal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInfoFinal.Location = New System.Drawing.Point(0, 490)
        Me.panelInfoFinal.Name = "panelInfoFinal"
        Me.panelInfoFinal.Size = New System.Drawing.Size(1114, 164)
        Me.panelInfoFinal.TabIndex = 4
        '
        'celdaGranTotal
        '
        Me.celdaGranTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaGranTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaGranTotal.Location = New System.Drawing.Point(1004, 35)
        Me.celdaGranTotal.Name = "celdaGranTotal"
        Me.celdaGranTotal.ReadOnly = True
        Me.celdaGranTotal.Size = New System.Drawing.Size(106, 22)
        Me.celdaGranTotal.TabIndex = 25
        Me.celdaGranTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaGranTotal
        '
        Me.etiquetaGranTotal.AutoSize = True
        Me.etiquetaGranTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaGranTotal.Location = New System.Drawing.Point(1002, 14)
        Me.etiquetaGranTotal.Name = "etiquetaGranTotal"
        Me.etiquetaGranTotal.Size = New System.Drawing.Size(89, 16)
        Me.etiquetaGranTotal.TabIndex = 24
        Me.etiquetaGranTotal.Text = "Grand Total"
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.Location = New System.Drawing.Point(477, 8)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaCantidad.TabIndex = 23
        Me.etiquetaCantidad.Text = "Quantity"
        '
        'etiquetaTotalDesc
        '
        Me.etiquetaTotalDesc.AutoSize = True
        Me.etiquetaTotalDesc.Location = New System.Drawing.Point(723, 35)
        Me.etiquetaTotalDesc.Name = "etiquetaTotalDesc"
        Me.etiquetaTotalDesc.Size = New System.Drawing.Size(99, 17)
        Me.etiquetaTotalDesc.TabIndex = 22
        Me.etiquetaTotalDesc.Text = "Total Discount"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(723, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 17)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Discount"
        '
        'celdaTotalDescuento
        '
        Me.celdaTotalDescuento.Location = New System.Drawing.Point(813, 35)
        Me.celdaTotalDescuento.Name = "celdaTotalDescuento"
        Me.celdaTotalDescuento.ReadOnly = True
        Me.celdaTotalDescuento.Size = New System.Drawing.Size(104, 22)
        Me.celdaTotalDescuento.TabIndex = 20
        Me.celdaTotalDescuento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaDescuento
        '
        Me.celdaDescuento.Location = New System.Drawing.Point(813, 3)
        Me.celdaDescuento.Name = "celdaDescuento"
        Me.celdaDescuento.ReadOnly = True
        Me.celdaDescuento.Size = New System.Drawing.Size(104, 22)
        Me.celdaDescuento.TabIndex = 19
        Me.celdaDescuento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotal1
        '
        Me.celdaTotal1.Location = New System.Drawing.Point(541, 6)
        Me.celdaTotal1.Name = "celdaTotal1"
        Me.celdaTotal1.ReadOnly = True
        Me.celdaTotal1.Size = New System.Drawing.Size(106, 22)
        Me.celdaTotal1.TabIndex = 18
        Me.celdaTotal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotal2
        '
        Me.celdaTotal2.Location = New System.Drawing.Point(542, 35)
        Me.celdaTotal2.Name = "celdaTotal2"
        Me.celdaTotal2.ReadOnly = True
        Me.celdaTotal2.Size = New System.Drawing.Size(104, 22)
        Me.celdaTotal2.TabIndex = 17
        Me.celdaTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(478, 35)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(60, 17)
        Me.etiquetaTotales.TabIndex = 3
        Me.etiquetaTotales.Text = "Subtotal"
        '
        'checkDetGatos
        '
        Me.checkDetGatos.AutoSize = True
        Me.checkDetGatos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkDetGatos.Location = New System.Drawing.Point(293, 39)
        Me.checkDetGatos.Name = "checkDetGatos"
        Me.checkDetGatos.Size = New System.Drawing.Size(212, 21)
        Me.checkDetGatos.TabIndex = 2
        Me.checkDetGatos.Text = "Print Details of Expenses"
        Me.checkDetGatos.UseVisualStyleBackColor = True
        Me.checkDetGatos.Visible = False
        '
        'panelDatos
        '
        Me.panelDatos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDatos.Controls.Add(Me.dgDatos)
        Me.panelDatos.Location = New System.Drawing.Point(310, 66)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(780, 94)
        Me.panelDatos.TabIndex = 1
        '
        'dgDatos
        '
        Me.dgDatos.AllowUserToAddRows = False
        Me.dgDatos.AllowUserToDeleteRows = False
        Me.dgDatos.AllowUserToOrderColumns = True
        Me.dgDatos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDatos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDatos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNombre, Me.colFecDoc, Me.colConcepto, Me.colMonto, Me.colTC, Me.colCargo, Me.colAbono, Me.colDias})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDatos.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDatos.Location = New System.Drawing.Point(0, 0)
        Me.dgDatos.Name = "dgDatos"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDatos.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgDatos.RowHeadersWidth = 51
        Me.dgDatos.Size = New System.Drawing.Size(780, 94)
        Me.dgDatos.TabIndex = 0
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.MinimumWidth = 6
        Me.colNombre.Name = "colNombre"
        Me.colNombre.Width = 125
        '
        'colFecDoc
        '
        Me.colFecDoc.HeaderText = "Date"
        Me.colFecDoc.MinimumWidth = 6
        Me.colFecDoc.Name = "colFecDoc"
        Me.colFecDoc.Width = 125
        '
        'colConcepto
        '
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.MinimumWidth = 6
        Me.colConcepto.Name = "colConcepto"
        Me.colConcepto.Width = 200
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.MinimumWidth = 6
        Me.colMonto.Name = "colMonto"
        Me.colMonto.Width = 125
        '
        'colTC
        '
        Me.colTC.HeaderText = "T/C"
        Me.colTC.MinimumWidth = 6
        Me.colTC.Name = "colTC"
        Me.colTC.Width = 125
        '
        'colCargo
        '
        Me.colCargo.HeaderText = "Charge"
        Me.colCargo.MinimumWidth = 6
        Me.colCargo.Name = "colCargo"
        Me.colCargo.Width = 125
        '
        'colAbono
        '
        Me.colAbono.HeaderText = "Payment"
        Me.colAbono.MinimumWidth = 6
        Me.colAbono.Name = "colAbono"
        Me.colAbono.Width = 125
        '
        'colDias
        '
        Me.colDias.HeaderText = "Days"
        Me.colDias.MinimumWidth = 6
        Me.colDias.Name = "colDias"
        Me.colDias.Width = 125
        '
        'panelSubDocumentos
        '
        Me.panelSubDocumentos.Controls.Add(Me.dgSubdocumentos)
        Me.panelSubDocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelSubDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.panelSubDocumentos.Name = "panelSubDocumentos"
        Me.panelSubDocumentos.Size = New System.Drawing.Size(283, 164)
        Me.panelSubDocumentos.TabIndex = 0
        '
        'dgSubdocumentos
        '
        Me.dgSubdocumentos.AllowUserToAddRows = False
        Me.dgSubdocumentos.AllowUserToDeleteRows = False
        Me.dgSubdocumentos.AllowUserToOrderColumns = True
        Me.dgSubdocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgSubdocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSubdocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colDescripcion, Me.colDocumento, Me.colDatos})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgSubdocumentos.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgSubdocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgSubdocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgSubdocumentos.Name = "dgSubdocumentos"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgSubdocumentos.RowHeadersWidth = 51
        Me.dgSubdocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgSubdocumentos.Size = New System.Drawing.Size(283, 164)
        Me.dgSubdocumentos.TabIndex = 0
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.MinimumWidth = 6
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.MinimumWidth = 6
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.Width = 125
        '
        'colDatos
        '
        Me.colDatos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.MinimumWidth = 6
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        Me.colDatos.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.botonQuitar)
        Me.panelDetalle.Controls.Add(Me.botonAgrega)
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Location = New System.Drawing.Point(3, 334)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1089, 146)
        Me.panelDetalle.TabIndex = 3
        '
        'botonQuitar
        '
        Me.botonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(1045, 70)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(39, 29)
        Me.botonQuitar.TabIndex = 6
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgrega
        '
        Me.botonAgrega.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgrega.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgrega.Location = New System.Drawing.Point(1045, 20)
        Me.botonAgrega.Name = "botonAgrega"
        Me.botonAgrega.Size = New System.Drawing.Size(38, 28)
        Me.botonAgrega.TabIndex = 5
        Me.botonAgrega.UseVisualStyleBackColor = True
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNum, Me.colCode, Me.colAño, Me.colLinea, Me.colLinea2, Me.ColDescrip, Me.colCodMedida, Me.colMedida, Me.colDespacho, Me.colPrecio, Me.colDesc, Me.colDescDolar, Me.colCantidad, Me.colTotal, Me.colBulto, Me.colTipoBulto, Me.colBobina, Me.colDistribucion, Me.colCodLugar, Me.colLugDestino, Me.colLBS, Me.colKGS, Me.colKGNetos, Me.colKGNetosExt, Me.colOriginal, Me.colReferences, Me.colBase, Me.colPrecioPF, Me.colEliminar, Me.colCta, Me.colNombreCta, Me.colLoteNuevo})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgDetalle.RowHeadersWidth = 51
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(1038, 142)
        Me.dgDetalle.TabIndex = 0
        '
        'gbInfoAdd
        '
        Me.gbInfoAdd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbInfoAdd.Controls.Add(Me.panelPlantas)
        Me.gbInfoAdd.Controls.Add(Me.dgReferencia)
        Me.gbInfoAdd.Controls.Add(Me.celdaValidacionFlete)
        Me.gbInfoAdd.Controls.Add(Me.botonSeguro)
        Me.gbInfoAdd.Controls.Add(Me.rbExportacion)
        Me.gbInfoAdd.Controls.Add(Me.rbNacionalizacion)
        Me.gbInfoAdd.Controls.Add(Me.celdaSeguro)
        Me.gbInfoAdd.Controls.Add(Me.celdaFlete)
        Me.gbInfoAdd.Controls.Add(Me.etiquetaSeguro)
        Me.gbInfoAdd.Controls.Add(Me.etiquetaFlete)
        Me.gbInfoAdd.Location = New System.Drawing.Point(463, 237)
        Me.gbInfoAdd.Name = "gbInfoAdd"
        Me.gbInfoAdd.Size = New System.Drawing.Size(629, 88)
        Me.gbInfoAdd.TabIndex = 2
        Me.gbInfoAdd.TabStop = False
        Me.gbInfoAdd.Text = "Addittional Information"
        '
        'panelPlantas
        '
        Me.panelPlantas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelPlantas.Controls.Add(Me.checkDestino)
        Me.panelPlantas.Location = New System.Drawing.Point(470, 11)
        Me.panelPlantas.Margin = New System.Windows.Forms.Padding(2)
        Me.panelPlantas.Name = "panelPlantas"
        Me.panelPlantas.Size = New System.Drawing.Size(79, 77)
        Me.panelPlantas.TabIndex = 32
        '
        'checkDestino
        '
        Me.checkDestino.AutoSize = True
        Me.checkDestino.Location = New System.Drawing.Point(10, 14)
        Me.checkDestino.Margin = New System.Windows.Forms.Padding(2)
        Me.checkDestino.Name = "checkDestino"
        Me.checkDestino.Size = New System.Drawing.Size(134, 21)
        Me.checkDestino.TabIndex = 32
        Me.checkDestino.Text = "Origin Honduras"
        Me.checkDestino.UseVisualStyleBackColor = True
        '
        'dgReferencia
        '
        Me.dgReferencia.AllowUserToAddRows = False
        Me.dgReferencia.AllowUserToDeleteRows = False
        Me.dgReferencia.AllowUserToOrderColumns = True
        Me.dgReferencia.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgReferencia.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.dgReferencia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgReferencia.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colTipo, Me.colAno, Me.colNumber, Me.colDate, Me.colPolicy, Me.colReference, Me.colLine, Me.colLineaInstruccion, Me.colCod, Me.colDisponible, Me.colDescargo, Me.colDescargado, Me.colAmount, Me.colCantDescargada, Me.colModificado, Me.colUnidad, Me.colMedid, Me.colCantida, Me.colQuitar, Me.colInstruccion})
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgReferencia.DefaultCellStyle = DataGridViewCellStyle14
        Me.dgReferencia.Location = New System.Drawing.Point(555, -15)
        Me.dgReferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.dgReferencia.MultiSelect = False
        Me.dgReferencia.Name = "dgReferencia"
        Me.dgReferencia.ReadOnly = True
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgReferencia.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.dgReferencia.RowHeadersWidth = 51
        Me.dgReferencia.RowTemplate.Height = 24
        Me.dgReferencia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgReferencia.Size = New System.Drawing.Size(564, 260)
        Me.dgReferencia.TabIndex = 1
        Me.dgReferencia.Visible = False
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.MinimumWidth = 6
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Width = 125
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.MinimumWidth = 6
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Width = 125
        '
        'colAno
        '
        Me.colAno.HeaderText = "Ano"
        Me.colAno.MinimumWidth = 6
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Width = 125
        '
        'colNumber
        '
        Me.colNumber.HeaderText = "Numero"
        Me.colNumber.MinimumWidth = 6
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 125
        '
        'colDate
        '
        Me.colDate.HeaderText = "Fecha"
        Me.colDate.MinimumWidth = 6
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 125
        '
        'colPolicy
        '
        Me.colPolicy.HeaderText = "Poliza"
        Me.colPolicy.MinimumWidth = 6
        Me.colPolicy.Name = "colPolicy"
        Me.colPolicy.ReadOnly = True
        Me.colPolicy.Width = 125
        '
        'colReference
        '
        Me.colReference.HeaderText = "Referencia"
        Me.colReference.MinimumWidth = 6
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        Me.colReference.Width = 125
        '
        'colLine
        '
        Me.colLine.HeaderText = "Linea"
        Me.colLine.MinimumWidth = 6
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        Me.colLine.Width = 125
        '
        'colLineaInstruccion
        '
        Me.colLineaInstruccion.HeaderText = "Linea Instruccion"
        Me.colLineaInstruccion.MinimumWidth = 6
        Me.colLineaInstruccion.Name = "colLineaInstruccion"
        Me.colLineaInstruccion.ReadOnly = True
        Me.colLineaInstruccion.Width = 125
        '
        'colCod
        '
        Me.colCod.HeaderText = "Codigo"
        Me.colCod.MinimumWidth = 6
        Me.colCod.Name = "colCod"
        Me.colCod.ReadOnly = True
        Me.colCod.Width = 125
        '
        'colDisponible
        '
        Me.colDisponible.HeaderText = "Disponible"
        Me.colDisponible.MinimumWidth = 6
        Me.colDisponible.Name = "colDisponible"
        Me.colDisponible.ReadOnly = True
        Me.colDisponible.Width = 125
        '
        'colDescargo
        '
        Me.colDescargo.HeaderText = "A Descargar"
        Me.colDescargo.MinimumWidth = 6
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.ReadOnly = True
        Me.colDescargo.Width = 125
        '
        'colDescargado
        '
        Me.colDescargado.HeaderText = "Existe"
        Me.colDescargado.MinimumWidth = 6
        Me.colDescargado.Name = "colDescargado"
        Me.colDescargado.ReadOnly = True
        Me.colDescargado.Width = 125
        '
        'colAmount
        '
        Me.colAmount.HeaderText = "Saldo Actual"
        Me.colAmount.MinimumWidth = 6
        Me.colAmount.Name = "colAmount"
        Me.colAmount.ReadOnly = True
        Me.colAmount.Width = 125
        '
        'colCantDescargada
        '
        Me.colCantDescargada.HeaderText = "Cantidad Descargada"
        Me.colCantDescargada.MinimumWidth = 6
        Me.colCantDescargada.Name = "colCantDescargada"
        Me.colCantDescargada.ReadOnly = True
        Me.colCantDescargada.Width = 125
        '
        'colModificado
        '
        Me.colModificado.HeaderText = "Modificado"
        Me.colModificado.MinimumWidth = 6
        Me.colModificado.Name = "colModificado"
        Me.colModificado.ReadOnly = True
        Me.colModificado.Width = 125
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unidad"
        Me.colUnidad.MinimumWidth = 6
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        Me.colUnidad.Width = 125
        '
        'colMedid
        '
        Me.colMedid.HeaderText = "Medida"
        Me.colMedid.MinimumWidth = 6
        Me.colMedid.Name = "colMedid"
        Me.colMedid.ReadOnly = True
        Me.colMedid.Width = 125
        '
        'colCantida
        '
        Me.colCantida.HeaderText = "Cantidad"
        Me.colCantida.MinimumWidth = 6
        Me.colCantida.Name = "colCantida"
        Me.colCantida.ReadOnly = True
        Me.colCantida.Width = 125
        '
        'colQuitar
        '
        Me.colQuitar.HeaderText = "Quitar"
        Me.colQuitar.MinimumWidth = 6
        Me.colQuitar.Name = "colQuitar"
        Me.colQuitar.ReadOnly = True
        Me.colQuitar.Width = 125
        '
        'colInstruccion
        '
        Me.colInstruccion.HeaderText = "Instruccion"
        Me.colInstruccion.MinimumWidth = 6
        Me.colInstruccion.Name = "colInstruccion"
        Me.colInstruccion.ReadOnly = True
        Me.colInstruccion.Width = 125
        '
        'celdaValidacionFlete
        '
        Me.celdaValidacionFlete.Location = New System.Drawing.Point(223, 25)
        Me.celdaValidacionFlete.Name = "celdaValidacionFlete"
        Me.celdaValidacionFlete.Size = New System.Drawing.Size(34, 22)
        Me.celdaValidacionFlete.TabIndex = 31
        Me.celdaValidacionFlete.Text = "1"
        Me.celdaValidacionFlete.Visible = False
        '
        'botonSeguro
        '
        Me.botonSeguro.Location = New System.Drawing.Point(170, 51)
        Me.botonSeguro.Name = "botonSeguro"
        Me.botonSeguro.Size = New System.Drawing.Size(36, 28)
        Me.botonSeguro.TabIndex = 19
        Me.botonSeguro.Text = "%"
        Me.botonSeguro.UseVisualStyleBackColor = True
        '
        'rbExportacion
        '
        Me.rbExportacion.AutoSize = True
        Me.rbExportacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbExportacion.ForeColor = System.Drawing.Color.Green
        Me.rbExportacion.Location = New System.Drawing.Point(284, 61)
        Me.rbExportacion.Name = "rbExportacion"
        Me.rbExportacion.Size = New System.Drawing.Size(75, 21)
        Me.rbExportacion.TabIndex = 18
        Me.rbExportacion.TabStop = True
        Me.rbExportacion.Text = "Export"
        Me.rbExportacion.UseVisualStyleBackColor = True
        '
        'rbNacionalizacion
        '
        Me.rbNacionalizacion.AutoSize = True
        Me.rbNacionalizacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbNacionalizacion.ForeColor = System.Drawing.Color.Red
        Me.rbNacionalizacion.Location = New System.Drawing.Point(284, 25)
        Me.rbNacionalizacion.Name = "rbNacionalizacion"
        Me.rbNacionalizacion.Size = New System.Drawing.Size(137, 21)
        Me.rbNacionalizacion.TabIndex = 17
        Me.rbNacionalizacion.TabStop = True
        Me.rbNacionalizacion.Text = "Nationalization"
        Me.rbNacionalizacion.UseVisualStyleBackColor = True
        '
        'celdaSeguro
        '
        Me.celdaSeguro.Enabled = False
        Me.celdaSeguro.Location = New System.Drawing.Point(86, 55)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.Size = New System.Drawing.Size(76, 22)
        Me.celdaSeguro.TabIndex = 16
        Me.celdaSeguro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaFlete
        '
        Me.celdaFlete.Location = New System.Drawing.Point(86, 25)
        Me.celdaFlete.Name = "celdaFlete"
        Me.celdaFlete.Size = New System.Drawing.Size(119, 22)
        Me.celdaFlete.TabIndex = 15
        Me.celdaFlete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSeguro
        '
        Me.etiquetaSeguro.AutoSize = True
        Me.etiquetaSeguro.Location = New System.Drawing.Point(12, 57)
        Me.etiquetaSeguro.Name = "etiquetaSeguro"
        Me.etiquetaSeguro.Size = New System.Drawing.Size(70, 17)
        Me.etiquetaSeguro.TabIndex = 1
        Me.etiquetaSeguro.Text = "Insurance"
        '
        'etiquetaFlete
        '
        Me.etiquetaFlete.AutoSize = True
        Me.etiquetaFlete.Location = New System.Drawing.Point(12, 29)
        Me.etiquetaFlete.Name = "etiquetaFlete"
        Me.etiquetaFlete.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaFlete.TabIndex = 0
        Me.etiquetaFlete.Text = "Freight"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.celdaNotas)
        Me.GroupBox1.Controls.Add(Me.panelListaDespachInstr)
        Me.GroupBox1.Location = New System.Drawing.Point(463, 66)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(629, 171)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Dispatching Instructions to Include"
        '
        'celdaNotas
        '
        Me.celdaNotas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNotas.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNotas.Location = New System.Drawing.Point(6, 131)
        Me.celdaNotas.Multiline = True
        Me.celdaNotas.Name = "celdaNotas"
        Me.celdaNotas.ReadOnly = True
        Me.celdaNotas.Size = New System.Drawing.Size(615, 37)
        Me.celdaNotas.TabIndex = 1
        '
        'panelListaDespachInstr
        '
        Me.panelListaDespachInstr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelListaDespachInstr.Controls.Add(Me.dgInstrucDespacho)
        Me.panelListaDespachInstr.Location = New System.Drawing.Point(6, 25)
        Me.panelListaDespachInstr.Name = "panelListaDespachInstr"
        Me.panelListaDespachInstr.Size = New System.Drawing.Size(615, 104)
        Me.panelListaDespachInstr.TabIndex = 0
        '
        'dgInstrucDespacho
        '
        Me.dgInstrucDespacho.AllowUserToAddRows = False
        Me.dgInstrucDespacho.AllowUserToDeleteRows = False
        Me.dgInstrucDespacho.AllowUserToOrderColumns = True
        Me.dgInstrucDespacho.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgInstrucDespacho.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle16
        Me.dgInstrucDespacho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgInstrucDespacho.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAñ, Me.colInst, Me.colFech, Me.colOperador, Me.colRef, Me.colMarca})
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle17.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgInstrucDespacho.DefaultCellStyle = DataGridViewCellStyle17
        Me.dgInstrucDespacho.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgInstrucDespacho.Location = New System.Drawing.Point(0, 0)
        Me.dgInstrucDespacho.MultiSelect = False
        Me.dgInstrucDespacho.Name = "dgInstrucDespacho"
        Me.dgInstrucDespacho.ReadOnly = True
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgInstrucDespacho.RowHeadersDefaultCellStyle = DataGridViewCellStyle18
        Me.dgInstrucDespacho.RowHeadersWidth = 51
        Me.dgInstrucDespacho.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgInstrucDespacho.Size = New System.Drawing.Size(615, 104)
        Me.dgInstrucDespacho.TabIndex = 0
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Cat"
        Me.colCatalogo.MinimumWidth = 6
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 125
        '
        'colAñ
        '
        Me.colAñ.HeaderText = "Year"
        Me.colAñ.MinimumWidth = 6
        Me.colAñ.Name = "colAñ"
        Me.colAñ.ReadOnly = True
        Me.colAñ.Visible = False
        Me.colAñ.Width = 125
        '
        'colInst
        '
        Me.colInst.HeaderText = "Inst."
        Me.colInst.MinimumWidth = 6
        Me.colInst.Name = "colInst"
        Me.colInst.ReadOnly = True
        Me.colInst.Width = 125
        '
        'colFech
        '
        Me.colFech.HeaderText = "Date"
        Me.colFech.MinimumWidth = 6
        Me.colFech.Name = "colFech"
        Me.colFech.ReadOnly = True
        Me.colFech.Width = 125
        '
        'colOperador
        '
        Me.colOperador.HeaderText = "Operator"
        Me.colOperador.MinimumWidth = 6
        Me.colOperador.Name = "colOperador"
        Me.colOperador.ReadOnly = True
        Me.colOperador.Width = 125
        '
        'colRef
        '
        Me.colRef.HeaderText = "Reference"
        Me.colRef.MinimumWidth = 6
        Me.colRef.Name = "colRef"
        Me.colRef.ReadOnly = True
        Me.colRef.Width = 125
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Marca"
        Me.colMarca.MinimumWidth = 6
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Visible = False
        Me.colMarca.Width = 125
        '
        'gbInvoiceInfo
        '
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIDSerie)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaFechaEmisionDocumento)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaFechaHoraCertificacion)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSerieFel)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaUUID)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaFechavencimiento)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCAI)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaCAI)
        Me.gbInvoiceInfo.Controls.Add(Me.botonSerie)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNum2)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSubDocumento)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSalida)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaImpreso)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaPoliza)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaBloqueado)
        Me.gbInvoiceInfo.Controls.Add(Me.dtpFecha)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCargado)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaUsuario)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTipo)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaEmpresa)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaAnulada)
        Me.gbInvoiceInfo.Controls.Add(Me.botonPolizaC)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIdMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.botonMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIdCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.botonCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.checkActivar)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSerie)
        Me.gbInvoiceInfo.Controls.Add(Me.checkRevisado)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTasa)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaTasa)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNIT)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTelefono)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaDireccion)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNumero)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaAño)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaNit)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaTelefono)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaDireccion)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaNumero)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaFecha)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaAño)
        Me.gbInvoiceInfo.Location = New System.Drawing.Point(3, 3)
        Me.gbInvoiceInfo.Name = "gbInvoiceInfo"
        Me.gbInvoiceInfo.Size = New System.Drawing.Size(452, 322)
        Me.gbInvoiceInfo.TabIndex = 0
        Me.gbInvoiceInfo.TabStop = False
        Me.gbInvoiceInfo.Text = "Invoice Information"
        '
        'celdaIDSerie
        '
        Me.celdaIDSerie.Location = New System.Drawing.Point(330, 44)
        Me.celdaIDSerie.Name = "celdaIDSerie"
        Me.celdaIDSerie.Size = New System.Drawing.Size(34, 22)
        Me.celdaIDSerie.TabIndex = 51
        Me.celdaIDSerie.Text = "0"
        Me.celdaIDSerie.Visible = False
        '
        'celdaFechaEmisionDocumento
        '
        Me.celdaFechaEmisionDocumento.Location = New System.Drawing.Point(192, 99)
        Me.celdaFechaEmisionDocumento.Name = "celdaFechaEmisionDocumento"
        Me.celdaFechaEmisionDocumento.Size = New System.Drawing.Size(12, 22)
        Me.celdaFechaEmisionDocumento.TabIndex = 50
        Me.celdaFechaEmisionDocumento.Visible = False
        '
        'celdaFechaHoraCertificacion
        '
        Me.celdaFechaHoraCertificacion.Location = New System.Drawing.Point(206, 99)
        Me.celdaFechaHoraCertificacion.Name = "celdaFechaHoraCertificacion"
        Me.celdaFechaHoraCertificacion.Size = New System.Drawing.Size(12, 22)
        Me.celdaFechaHoraCertificacion.TabIndex = 49
        Me.celdaFechaHoraCertificacion.Visible = False
        '
        'celdaSerieFel
        '
        Me.celdaSerieFel.Location = New System.Drawing.Point(219, 99)
        Me.celdaSerieFel.Name = "celdaSerieFel"
        Me.celdaSerieFel.Size = New System.Drawing.Size(12, 22)
        Me.celdaSerieFel.TabIndex = 48
        Me.celdaSerieFel.Visible = False
        '
        'celdaUUID
        '
        Me.celdaUUID.Location = New System.Drawing.Point(237, 95)
        Me.celdaUUID.Name = "celdaUUID"
        Me.celdaUUID.Size = New System.Drawing.Size(166, 22)
        Me.celdaUUID.TabIndex = 46
        Me.celdaUUID.Visible = False
        '
        'celdaFechavencimiento
        '
        Me.celdaFechavencimiento.Location = New System.Drawing.Point(247, 15)
        Me.celdaFechavencimiento.Name = "celdaFechavencimiento"
        Me.celdaFechavencimiento.Size = New System.Drawing.Size(85, 22)
        Me.celdaFechavencimiento.TabIndex = 43
        Me.celdaFechavencimiento.Visible = False
        '
        'celdaCAI
        '
        Me.celdaCAI.Location = New System.Drawing.Point(247, 227)
        Me.celdaCAI.Multiline = True
        Me.celdaCAI.Name = "celdaCAI"
        Me.celdaCAI.Size = New System.Drawing.Size(154, 56)
        Me.celdaCAI.TabIndex = 42
        Me.celdaCAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaCAI.Visible = False
        '
        'etiquetaCAI
        '
        Me.etiquetaCAI.AutoSize = True
        Me.etiquetaCAI.Location = New System.Drawing.Point(219, 232)
        Me.etiquetaCAI.Name = "etiquetaCAI"
        Me.etiquetaCAI.Size = New System.Drawing.Size(29, 17)
        Me.etiquetaCAI.TabIndex = 41
        Me.etiquetaCAI.Text = "CAI"
        Me.etiquetaCAI.Visible = False
        '
        'botonSerie
        '
        Me.botonSerie.Location = New System.Drawing.Point(326, 70)
        Me.botonSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(34, 23)
        Me.botonSerie.TabIndex = 40
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        '
        'celdaNum2
        '
        Me.celdaNum2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNum2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNum2.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNum2.Location = New System.Drawing.Point(72, 71)
        Me.celdaNum2.Name = "celdaNum2"
        Me.celdaNum2.Size = New System.Drawing.Size(83, 22)
        Me.celdaNum2.TabIndex = 39
        Me.celdaNum2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaSubDocumento
        '
        Me.celdaSubDocumento.Location = New System.Drawing.Point(320, 263)
        Me.celdaSubDocumento.Name = "celdaSubDocumento"
        Me.celdaSubDocumento.Size = New System.Drawing.Size(34, 22)
        Me.celdaSubDocumento.TabIndex = 38
        Me.celdaSubDocumento.Text = "0"
        Me.celdaSubDocumento.Visible = False
        '
        'celdaSalida
        '
        Me.celdaSalida.Location = New System.Drawing.Point(358, 274)
        Me.celdaSalida.Name = "celdaSalida"
        Me.celdaSalida.Size = New System.Drawing.Size(85, 22)
        Me.celdaSalida.TabIndex = 37
        Me.celdaSalida.Visible = False
        '
        'celdaImpreso
        '
        Me.celdaImpreso.Location = New System.Drawing.Point(409, 244)
        Me.celdaImpreso.Name = "celdaImpreso"
        Me.celdaImpreso.Size = New System.Drawing.Size(34, 22)
        Me.celdaImpreso.TabIndex = 36
        Me.celdaImpreso.Text = "-1"
        Me.celdaImpreso.Visible = False
        '
        'celdaPoliza
        '
        Me.celdaPoliza.Location = New System.Drawing.Point(410, 185)
        Me.celdaPoliza.Name = "celdaPoliza"
        Me.celdaPoliza.Size = New System.Drawing.Size(34, 22)
        Me.celdaPoliza.TabIndex = 35
        Me.celdaPoliza.Text = "0"
        Me.celdaPoliza.Visible = False
        '
        'celdaBloqueado
        '
        Me.celdaBloqueado.Location = New System.Drawing.Point(410, 156)
        Me.celdaBloqueado.Name = "celdaBloqueado"
        Me.celdaBloqueado.Size = New System.Drawing.Size(34, 22)
        Me.celdaBloqueado.TabIndex = 34
        Me.celdaBloqueado.Text = "0"
        Me.celdaBloqueado.Visible = False
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(66, 95)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(112, 22)
        Me.dtpFecha.TabIndex = 33
        '
        'celdaCargado
        '
        Me.celdaCargado.Location = New System.Drawing.Point(409, 216)
        Me.celdaCargado.Name = "celdaCargado"
        Me.celdaCargado.Size = New System.Drawing.Size(34, 22)
        Me.celdaCargado.TabIndex = 32
        Me.celdaCargado.Text = "-1"
        Me.celdaCargado.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(410, 82)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(34, 22)
        Me.celdaUsuario.TabIndex = 31
        Me.celdaUsuario.Text = "25"
        Me.celdaUsuario.Visible = False
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(410, 51)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.Size = New System.Drawing.Size(34, 22)
        Me.celdaTipo.TabIndex = 30
        Me.celdaTipo.Text = "1"
        Me.celdaTipo.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(410, 25)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(34, 22)
        Me.celdaEmpresa.TabIndex = 29
        Me.celdaEmpresa.Text = "0"
        Me.celdaEmpresa.Visible = False
        '
        'etiquetaAnulada
        '
        Me.etiquetaAnulada.AutoSize = True
        Me.etiquetaAnulada.BackColor = System.Drawing.Color.Red
        Me.etiquetaAnulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaAnulada.Location = New System.Drawing.Point(205, 41)
        Me.etiquetaAnulada.Name = "etiquetaAnulada"
        Me.etiquetaAnulada.Size = New System.Drawing.Size(83, 18)
        Me.etiquetaAnulada.TabIndex = 28
        Me.etiquetaAnulada.Text = "ANULADA"
        Me.etiquetaAnulada.Visible = False
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(320, 289)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(33, 28)
        Me.botonPolizaC.TabIndex = 27
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(27, 274)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(34, 22)
        Me.celdaIdMoneda.TabIndex = 26
        Me.celdaIdMoneda.Text = "-1"
        Me.celdaIdMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(139, 289)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(34, 28)
        Me.botonMoneda.TabIndex = 25
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(368, 124)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(34, 22)
        Me.celdaIdCliente.TabIndex = 24
        Me.celdaIdCliente.Text = "-1"
        Me.celdaIdCliente.Visible = False
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(326, 121)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(34, 28)
        Me.botonCliente.TabIndex = 23
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(351, 23)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(68, 21)
        Me.checkActivar.TabIndex = 22
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'celdaSerie
        '
        Me.celdaSerie.Location = New System.Drawing.Point(158, 71)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.Size = New System.Drawing.Size(161, 22)
        Me.celdaSerie.TabIndex = 21
        Me.celdaSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.Location = New System.Drawing.Point(361, 295)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(91, 21)
        Me.checkRevisado.TabIndex = 20
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(221, 290)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(69, 22)
        Me.celdaTasa.TabIndex = 19
        Me.celdaTasa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(179, 294)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 18
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(65, 290)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(69, 22)
        Me.celdaMoneda.TabIndex = 17
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(65, 259)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(148, 22)
        Me.celdaNIT.TabIndex = 16
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(65, 226)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(148, 22)
        Me.celdaTelefono.TabIndex = 15
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(65, 152)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(337, 65)
        Me.celdaDireccion.TabIndex = 13
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(66, 124)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(252, 22)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(65, 70)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(83, 22)
        Me.celdaNumero.TabIndex = 10
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaNumero.Visible = False
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.80000019!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaAño.Location = New System.Drawing.Point(66, 39)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(83, 22)
        Me.celdaAño.TabIndex = 9
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 294)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaMoneda.TabIndex = 8
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaNit
        '
        Me.etiquetaNit.AutoSize = True
        Me.etiquetaNit.Location = New System.Drawing.Point(6, 263)
        Me.etiquetaNit.Name = "etiquetaNit"
        Me.etiquetaNit.Size = New System.Drawing.Size(25, 17)
        Me.etiquetaNit.TabIndex = 7
        Me.etiquetaNit.Text = "Nit"
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(6, 226)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(49, 17)
        Me.etiquetaTelefono.TabIndex = 6
        Me.etiquetaTelefono.Text = "Phone"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 127)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(43, 17)
        Me.etiquetaCliente.TabIndex = 4
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(6, 156)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(64, 17)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 73)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(6, 100)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 1
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(6, 41)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(243, 13)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(68, 52)
        Me.botonImprimir.TabIndex = 22
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonBuscar.Location = New System.Drawing.Point(319, 13)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(75, 51)
        Me.botonBuscar.TabIndex = 26
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'botonPrevio
        '
        Me.botonPrevio.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonPrevio.Location = New System.Drawing.Point(402, 13)
        Me.botonPrevio.Name = "botonPrevio"
        Me.botonPrevio.Size = New System.Drawing.Size(75, 51)
        Me.botonPrevio.TabIndex = 28
        Me.botonPrevio.Text = "Preview"
        Me.botonPrevio.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevio.UseVisualStyleBackColor = True
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(400, 93)
        Me.etiquetaSerie.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(51, 17)
        Me.etiquetaSerie.TabIndex = 29
        Me.etiquetaSerie.Text = "Label4"
        '
        'etiquetaAutorizacion
        '
        Me.etiquetaAutorizacion.AutoSize = True
        Me.etiquetaAutorizacion.Location = New System.Drawing.Point(471, 93)
        Me.etiquetaAutorizacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizacion.Name = "etiquetaAutorizacion"
        Me.etiquetaAutorizacion.Size = New System.Drawing.Size(51, 17)
        Me.etiquetaAutorizacion.TabIndex = 30
        Me.etiquetaAutorizacion.Text = "Label4"
        Me.etiquetaAutorizacion.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 88)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1775, 36)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1775, 88)
        Me.Encabezado1.TabIndex = 0
        '
        'colNum
        '
        Me.colNum.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNum.HeaderText = "Number"
        Me.colNum.MinimumWidth = 6
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Visible = False
        Me.colNum.Width = 87
        '
        'colCode
        '
        Me.colCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCode.HeaderText = "Code*"
        Me.colCode.MinimumWidth = 6
        Me.colCode.Name = "colCode"
        Me.colCode.ReadOnly = True
        Me.colCode.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colCode.Width = 52
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.MinimumWidth = 6
        Me.colAño.Name = "colAño"
        Me.colAño.Visible = False
        Me.colAño.Width = 125
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.MinimumWidth = 6
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 125
        '
        'colLinea2
        '
        Me.colLinea2.HeaderText = "Line2"
        Me.colLinea2.MinimumWidth = 6
        Me.colLinea2.Name = "colLinea2"
        Me.colLinea2.Visible = False
        Me.colLinea2.Width = 125
        '
        'ColDescrip
        '
        Me.ColDescrip.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ColDescrip.HeaderText = "Description"
        Me.ColDescrip.MinimumWidth = 6
        Me.ColDescrip.Name = "ColDescrip"
        Me.ColDescrip.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ColDescrip.Width = 85
        '
        'colCodMedida
        '
        Me.colCodMedida.HeaderText = "CodMedida"
        Me.colCodMedida.MinimumWidth = 6
        Me.colCodMedida.Name = "colCodMedida"
        Me.colCodMedida.Visible = False
        Me.colCodMedida.Width = 125
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.MinimumWidth = 6
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMedida.Width = 69
        '
        'colDespacho
        '
        Me.colDespacho.HeaderText = "Dispatch"
        Me.colDespacho.MinimumWidth = 6
        Me.colDespacho.Name = "colDespacho"
        Me.colDespacho.Visible = False
        Me.colDespacho.Width = 125
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.MinimumWidth = 6
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecio.Width = 46
        '
        'colDesc
        '
        Me.colDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDesc.HeaderText = "Desc.%"
        Me.colDesc.MinimumWidth = 6
        Me.colDesc.Name = "colDesc"
        Me.colDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDesc.Width = 62
        '
        'colDescDolar
        '
        Me.colDescDolar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescDolar.HeaderText = "Desc.$"
        Me.colDescDolar.MinimumWidth = 6
        Me.colDescDolar.Name = "colDescDolar"
        Me.colDescDolar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDescDolar.Width = 58
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Quantity*"
        Me.colCantidad.MinimumWidth = 6
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colCantidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCantidad.Width = 72
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.MinimumWidth = 6
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTotal.Width = 46
        '
        'colBulto
        '
        Me.colBulto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBulto.HeaderText = "Package"
        Me.colBulto.MinimumWidth = 6
        Me.colBulto.Name = "colBulto"
        Me.colBulto.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colBulto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBulto.Width = 69
        '
        'colTipoBulto
        '
        Me.colTipoBulto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTipoBulto.HeaderText = "Package Type"
        Me.colTipoBulto.MinimumWidth = 6
        Me.colTipoBulto.Name = "colTipoBulto"
        Me.colTipoBulto.ReadOnly = True
        Me.colTipoBulto.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colTipoBulto.Width = 105
        '
        'colBobina
        '
        Me.colBobina.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBobina.HeaderText = "Coils"
        Me.colBobina.MinimumWidth = 6
        Me.colBobina.Name = "colBobina"
        Me.colBobina.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colBobina.Width = 44
        '
        'colDistribucion
        '
        Me.colDistribucion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDistribucion.HeaderText = "Distribution"
        Me.colDistribucion.MinimumWidth = 6
        Me.colDistribucion.Name = "colDistribucion"
        Me.colDistribucion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDistribucion.Width = 85
        '
        'colCodLugar
        '
        Me.colCodLugar.HeaderText = "Instead Destination"
        Me.colCodLugar.MinimumWidth = 6
        Me.colCodLugar.Name = "colCodLugar"
        Me.colCodLugar.Visible = False
        Me.colCodLugar.Width = 125
        '
        'colLugDestino
        '
        Me.colLugDestino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLugDestino.HeaderText = "Destination Place*"
        Me.colLugDestino.MinimumWidth = 6
        Me.colLugDestino.Name = "colLugDestino"
        Me.colLugDestino.ReadOnly = True
        Me.colLugDestino.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colLugDestino.Width = 116
        '
        'colLBS
        '
        Me.colLBS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLBS.HeaderText = "LBS"
        Me.colLBS.MinimumWidth = 6
        Me.colLBS.Name = "colLBS"
        Me.colLBS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colLBS.Width = 40
        '
        'colKGS
        '
        Me.colKGS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKGS.HeaderText = "KGS Brutos"
        Me.colKGS.MinimumWidth = 6
        Me.colKGS.Name = "colKGS"
        Me.colKGS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colKGS.Width = 79
        '
        'colKGNetos
        '
        Me.colKGNetos.HeaderText = "KG Netos"
        Me.colKGNetos.MinimumWidth = 6
        Me.colKGNetos.Name = "colKGNetos"
        Me.colKGNetos.ReadOnly = True
        Me.colKGNetos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colKGNetos.Width = 125
        '
        'colKGNetosExt
        '
        Me.colKGNetosExt.HeaderText = "KG Netos Ext"
        Me.colKGNetosExt.MinimumWidth = 6
        Me.colKGNetosExt.Name = "colKGNetosExt"
        Me.colKGNetosExt.Visible = False
        '
        'colOriginal
        '
        Me.colOriginal.HeaderText = "Original"
        Me.colOriginal.MinimumWidth = 6
        Me.colOriginal.Name = "colOriginal"
        Me.colOriginal.Visible = False
        Me.colOriginal.Width = 125
        '
        'colReferences
        '
        Me.colReferences.HeaderText = "Referencia"
        Me.colReferences.MinimumWidth = 6
        Me.colReferences.Name = "colReferences"
        Me.colReferences.Visible = False
        Me.colReferences.Width = 125
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.MinimumWidth = 6
        Me.colBase.Name = "colBase"
        Me.colBase.Visible = False
        Me.colBase.Width = 125
        '
        'colPrecioPF
        '
        Me.colPrecioPF.HeaderText = "PrecioPF"
        Me.colPrecioPF.MinimumWidth = 6
        Me.colPrecioPF.Name = "colPrecioPF"
        Me.colPrecioPF.Visible = False
        Me.colPrecioPF.Width = 125
        '
        'colEliminar
        '
        Me.colEliminar.HeaderText = "Eliminar"
        Me.colEliminar.MinimumWidth = 6
        Me.colEliminar.Name = "colEliminar"
        Me.colEliminar.Visible = False
        Me.colEliminar.Width = 125
        '
        'colCta
        '
        Me.colCta.HeaderText = "Cuenta"
        Me.colCta.MinimumWidth = 6
        Me.colCta.Name = "colCta"
        Me.colCta.ReadOnly = True
        Me.colCta.Visible = False
        Me.colCta.Width = 125
        '
        'colNombreCta
        '
        Me.colNombreCta.HeaderText = "Account"
        Me.colNombreCta.MinimumWidth = 6
        Me.colNombreCta.Name = "colNombreCta"
        Me.colNombreCta.ReadOnly = True
        Me.colNombreCta.Visible = False
        Me.colNombreCta.Width = 125
        '
        'colLoteNuevo
        '
        Me.colLoteNuevo.HeaderText = "New Lot"
        Me.colLoteNuevo.MinimumWidth = 6
        Me.colLoteNuevo.Name = "colLoteNuevo"
        Me.colLoteNuevo.Width = 125
        '
        'frmFacturacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1796, 749)
        Me.Controls.Add(Me.etiquetaAutorizacion)
        Me.Controls.Add(Me.etiquetaSerie)
        Me.Controls.Add(Me.botonPrevio)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmFacturacion"
        Me.Text = "frmFacturacion"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        Me.panelColores.ResumeLayout(False)
        Me.panelColores.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabLista.ResumeLayout(False)
        Me.panelEncabLista.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.gbFel.ResumeLayout(False)
        Me.gbFel.PerformLayout()
        Me.panelInfoFinal.ResumeLayout(False)
        Me.panelInfoFinal.PerformLayout()
        Me.panelDatos.ResumeLayout(False)
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSubDocumentos.ResumeLayout(False)
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbInfoAdd.ResumeLayout(False)
        Me.gbInfoAdd.PerformLayout()
        Me.panelPlantas.ResumeLayout(False)
        Me.panelPlantas.PerformLayout()
        CType(Me.dgReferencia, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelListaDespachInstr.ResumeLayout(False)
        CType(Me.dgInstrucDespacho, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbInvoiceInfo.ResumeLayout(False)
        Me.gbInvoiceInfo.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents panelEncabLista As System.Windows.Forms.Panel
    Friend WithEvents botonPoliza As System.Windows.Forms.Button
    Friend WithEvents botonLiberar As System.Windows.Forms.Button
    Friend WithEvents botonSalida As System.Windows.Forms.Button
    Friend WithEvents botonCarga As System.Windows.Forms.Button
    Friend WithEvents botonConcolidacion As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents etiquetaAnd As System.Windows.Forms.Label
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents gbInvoiceInfo As System.Windows.Forms.GroupBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaNit As System.Windows.Forms.Label
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents gbInfoAdd As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaSeguro As System.Windows.Forms.Label
    Friend WithEvents etiquetaFlete As System.Windows.Forms.Label
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaNotas As System.Windows.Forms.TextBox
    Friend WithEvents panelListaDespachInstr As System.Windows.Forms.Panel
    Friend WithEvents dgInstrucDespacho As System.Windows.Forms.DataGridView
    Friend WithEvents rbNacionalizacion As System.Windows.Forms.RadioButton
    Friend WithEvents celdaSeguro As System.Windows.Forms.TextBox
    Friend WithEvents celdaFlete As System.Windows.Forms.TextBox
    Friend WithEvents rbExportacion As System.Windows.Forms.RadioButton
    Friend WithEvents panelInfoFinal As System.Windows.Forms.Panel
    Friend WithEvents checkDetGatos As System.Windows.Forms.CheckBox
    Friend WithEvents panelDatos As System.Windows.Forms.Panel
    Friend WithEvents dgDatos As System.Windows.Forms.DataGridView
    Friend WithEvents panelSubDocumentos As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents botonSeguro As System.Windows.Forms.Button
    Friend WithEvents celdaTotal1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotales As System.Windows.Forms.Label
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents celdaIdCliente As System.Windows.Forms.TextBox
    Friend WithEvents botonCliente As System.Windows.Forms.Button
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaSerie As System.Windows.Forms.TextBox
    Friend WithEvents celdaIdMoneda As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents panelColores As System.Windows.Forms.Panel
    Friend WithEvents etiquetaNoImpreso As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaColorAmarillo As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorVerde As System.Windows.Forms.TextBox
    Friend WithEvents colorAqua As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorNaranja As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRosado As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRojo As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents etiquetaSalidaPendiente As System.Windows.Forms.Label
    Friend WithEvents etiquetaNoCargado As System.Windows.Forms.Label
    Friend WithEvents etiquetaSinPoliza As System.Windows.Forms.Label
    Friend WithEvents dgSubdocumentos As System.Windows.Forms.DataGridView
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonPolizaC As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CheckMuestraDetalle As System.Windows.Forms.CheckBox
    Friend WithEvents celdaInfoDetalle As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAnulada As System.Windows.Forms.Label
    Friend WithEvents dgReferencia As System.Windows.Forms.DataGridView
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaTipo As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents celdaCargado As System.Windows.Forms.TextBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaPoliza As System.Windows.Forms.TextBox
    Friend WithEvents celdaBloqueado As System.Windows.Forms.TextBox
    Friend WithEvents celdaSalida As System.Windows.Forms.TextBox
    Friend WithEvents celdaImpreso As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotalDesc As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaTotalDescuento As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescuento As System.Windows.Forms.TextBox
    Friend WithEvents celdaSubDocumento As System.Windows.Forms.TextBox
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPolicy As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReference As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaInstruccion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDisponible As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAmount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantDescargada As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colModificado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colQuitar As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colInstruccion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDatos As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colCatalogo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAñ As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colInst As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFech As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOperador As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRef As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarca As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaNum2 As System.Windows.Forms.TextBox
    Friend WithEvents botonSerie As System.Windows.Forms.Button
    Friend WithEvents celdaEmpPagadora As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEmpPagadora As System.Windows.Forms.Label
    Friend WithEvents celdaIDEmpPagadora As System.Windows.Forms.TextBox
    Friend WithEvents celdaCAI As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCAI As System.Windows.Forms.Label
    Friend WithEvents celdaFechavencimiento As System.Windows.Forms.TextBox
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents celdaGranTotal As TextBox
    Friend WithEvents etiquetaGranTotal As Label
    Friend WithEvents etiquetaCantidad As Label
    Friend WithEvents celdaFechaEmisionDocumento As TextBox
    Friend WithEvents celdaFechaHoraCertificacion As TextBox
    Friend WithEvents celdaSerieFel As TextBox
    Friend WithEvents celdaUUID As TextBox
    Friend WithEvents botonPrevio As Button
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents etiquetaAutorizacion As Label
    Friend WithEvents gbFel As GroupBox
    Friend WithEvents celdaNumeroFel As TextBox
    Friend WithEvents celdaSerieFelServi As TextBox
    Friend WithEvents etiquetaNumFel As Label
    Friend WithEvents etiquetaSerieFel As Label
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colFecDoc As DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colTC As DataGridViewTextBoxColumn
    Friend WithEvents colCargo As DataGridViewTextBoxColumn
    Friend WithEvents colAbono As DataGridViewTextBoxColumn
    Friend WithEvents colDias As DataGridViewTextBoxColumn
    Friend WithEvents celdaValidacionFlete As TextBox
    Friend WithEvents botonAgrega As Button
    Friend WithEvents botonQuitar As Button
    Friend WithEvents celdaTipoFactura As TextBox
    Friend WithEvents checkDestino As System.Windows.Forms.CheckBox
    Friend WithEvents panelPlantas As Panel
    Friend WithEvents celdaIDSerie As TextBox
    Friend WithEvents colYear As DataGridViewTextBoxColumn
    Friend WithEvents colNum2 As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colImpreso As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents colSalida As DataGridViewTextBoxColumn
    Friend WithEvents colImpues As DataGridViewTextBoxColumn
    Friend WithEvents colBloqueado As DataGridViewTextBoxColumn
    Friend WithEvents colCargado As DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As DataGridViewTextBoxColumn
    Friend WithEvents colNit As DataGridViewTextBoxColumn
    Friend WithEvents colSerieF As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizacionF As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colCode As DataGridViewButtonColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colLinea2 As DataGridViewTextBoxColumn
    Friend WithEvents ColDescrip As DataGridViewTextBoxColumn
    Friend WithEvents colCodMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colDespacho As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colDesc As DataGridViewTextBoxColumn
    Friend WithEvents colDescDolar As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colBulto As DataGridViewTextBoxColumn
    Friend WithEvents colTipoBulto As DataGridViewButtonColumn
    Friend WithEvents colBobina As DataGridViewTextBoxColumn
    Friend WithEvents colDistribucion As DataGridViewTextBoxColumn
    Friend WithEvents colCodLugar As DataGridViewTextBoxColumn
    Friend WithEvents colLugDestino As DataGridViewButtonColumn
    Friend WithEvents colLBS As DataGridViewTextBoxColumn
    Friend WithEvents colKGS As DataGridViewTextBoxColumn
    Friend WithEvents colKGNetos As DataGridViewTextBoxColumn
    Friend WithEvents colKGNetosExt As DataGridViewTextBoxColumn
    Friend WithEvents colOriginal As DataGridViewTextBoxColumn
    Friend WithEvents colReferences As DataGridViewTextBoxColumn
    Friend WithEvents colBase As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioPF As DataGridViewTextBoxColumn
    Friend WithEvents colEliminar As DataGridViewTextBoxColumn
    Friend WithEvents colCta As DataGridViewTextBoxColumn
    Friend WithEvents colNombreCta As DataGridViewTextBoxColumn
    Friend WithEvents colLoteNuevo As DataGridViewTextBoxColumn
End Class
