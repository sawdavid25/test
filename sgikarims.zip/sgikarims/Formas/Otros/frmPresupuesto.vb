﻿Public Class frmPresupuesto

    Dim cfun As New clsFunciones
    Dim Presupuesto As New clsPresupuesto
    Dim frmOpcion As New frmOption
    Dim frmPrincipal As New clsPrincipal
    Dim frmRPresupuesto As New frmRPresupuesto
    Dim frmXDocumentos As New frmXDocumento
    Dim frmMensaje As New frmMensaje
    Dim strKey As String
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strDatePicker As String = STR_VACIO
    Private Const logLoc As Byte = vbEmpty

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmPresupuesto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        Encabezado1.botonBorrar.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonNuevo.Enabled = False
        Mes.Value = DateSerial(Year(Date.Now), Month(Date.Now), 1)
            dtpIncio.Value = DateSerial(Year(Date.Now), Month(Date.Now), 1)
            dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            CargarPresupuesto()
            frmMensaje.Close()

    End Sub

    Public Function MontoMes()
        Dim dblMonto As Double = 0.0

        Dim Cell As DataGridViewCell

        For i As Integer = 0 To dgwPresupuesto.Rows.Count - 1
            Cell = dgwPresupuesto.Rows(i).Cells(5)
            dblMonto = dblMonto + Cell.Value
        Next

        Return dblMonto

    End Function

    Private Sub Permisos()

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CON As MySqlConnection
        Dim strFila As String = STR_VACIO
        Dim intBandera As Integer = 0
        strSQL = "SELECT A.cost_num Codigo,cost_nombre Centro " & _
                 "FROM conta.costos A  " & _
                 "WHERE cost_num in(SELECT B.pms_id " & _
                 "FROM Contabilidad.Permisos B " & _
                 "WHERE B.pms_empresa = {empresa} AND B.pms_modulo = 151 AND B.pms_usuario = '{usuario}' " & _
                 ") "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)

        CON = New MySqlConnection(strConexion)
        CON.Open()

        Try

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read()

                    If intBandera = 0 Then
                        strFila = strFila & REA.GetInt16("Codigo") & " - " & REA.GetString("Centro") & "|"
                        intBandera = 1
                    Else
                        strFila = strFila & REA.GetInt16("Codigo") & " - " & REA.GetString("Centro")
                    End If

                Loop

            End If

            frmOpcion.Opciones = strFila

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        CON.Close()

    End Sub

    Public Sub QueryPresupuesto()
        Dim strSQL As String = STR_VACIO
        Dim CON1 As MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim acPresupuesto As Double = 0.0
        Dim acMonto As Double = 0.0
        Dim i As Integer
        Dim strFila As String = STR_VACIO
        Dim funcion As New clsFunciones
        Dim tipo As Integer = 0

        CON1 = New MySqlConnection(strConexion)
        CON1.Open()

        strSQL = "SELECT r.linea Item, r.tipocampo Tipo, r.valorcampo Cuenta, r.col1_func Funcion, IFNULL((IFNULL(( " &
               "SELECT p.nombre_{idioma} " &
               "FROM  {conta}.cuentas_presupuesto p " &
               "WHERE p.empresa = r.empresa And p.id_cuenta = r.valorcampo " &
               "LIMIT 1), ( " &
               "Select p.nombre_{idioma} " &
               "FROM {conta}.cuentas_presupuesto p " &
               "WHERE p.empresa = r.empresa AND p.id_cuenta = r.valorcampo))), r.valorcampo) Descripcion, ROUND(IFNULL(( " &
               "SELECT IF(moneda={valor}, importe, (importe * tasa)) Importe " &
               "FROM {conta}.pro_presupuesto " &
               "WHERE empresa = r.empresa AND cuenta = r.valorcampo AND mes = MONTH('{FechaI}') " &
               "AND ano = YEAR('{FechaI}')),0),2) Presupuesto, IFNULL(( " &
               "SELECT SUM(d.importe_{moneda}) Monto " &
               "FROM {conta}.detalle_presupuesto d " &
               "LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=d.empresa AND e.HDoc_Doc_Cat=d.categoria " &
               "AND e.HDoc_Doc_Ano=d.ano AND e.HDoc_Doc_Num=d.numero " &
               "WHERE d.empresa = r.empresa AND d.cuenta = r.valorcampo AND " &
               "d.fecha BETWEEN '{FechaI}' AND '{FechaF}' AND d. " &
               "operacion='C' AND IFNULL(e.HDoc_Doc_Status,-1)!=3),0) Monto " &
               "FROM {conta}.rpt_strc r " &
               "WHERE r.empresa = {empresa} AND r.reporte = {reporte} "

        If rbQuetzal.Checked = True Then
            strSQL = Replace(strSQL, "{moneda}", STR_LOC)
            strSQL = Replace(strSQL, "{valor}", INT_LOC)
        End If

        If rbDolar.Checked = True Then
            strSQL = Replace(strSQL, "{moneda}", STR_EXT)
            strSQL = Replace(strSQL, "{valor}", INT_EXT)
        End If

        If rbEspañol.Checked = True Then
            strSQL = Replace(strSQL, "{idioma}", STR_LOC)
        End If

        If rbIngles.Checked = True Then
            strSQL = Replace(strSQL, "{reporte}", STR_EXT)
        End If

        If Year(Mes.Value).ToString < 2024 Then
            strSQL = Replace(strSQL, "{reporte}", 8)
        Else
            strSQL = Replace(strSQL, "{reporte}", 12)
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{FechaI}", dtpIncio.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{FechaF}", dtpFin.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
        strSQL = Replace(strSQL, "{idioma}", IIf(rbEspañol.Checked = True, STR_LOC, STR_EXT))

        Try
            COM = New MySqlCommand(strSQL, CON1)
            REA = COM.ExecuteReader

        If REA.HasRows Then
            dgwPresupuesto.Rows.Clear()
            acPresupuesto = 0.0
            Dim acRestaPresupuestoMonto As Double = 0.0

            i = vbEmpty
            While REA.Read

                    tipo = REA.GetInt16("Tipo")
                acPresupuesto = acPresupuesto + REA.GetDouble("Presupuesto")
                acMonto = acMonto + REA.GetDouble("Monto")
                acRestaPresupuestoMonto = REA.GetDouble("Presupuesto") - REA.GetDouble("Monto")

                    strFila = REA.GetString("Cuenta") & "|" & REA.GetString("Descripcion") & "|" &
                          IIf(REA.GetDouble("Presupuesto") = 0, vbNullString, FormatNumber(REA.GetDouble("Presupuesto"), 2)) & "|" &
                          IIf(REA.GetDouble("Monto") = 0, vbNullString, FormatNumber(REA.GetDouble("Monto"), 2)) & "|" &
                          IIf(acRestaPresupuestoMonto = 0, vbNullString, FormatNumber(acRestaPresupuestoMonto, 2))

                    funcion.AgregarFila(dgwPresupuesto, strFila)

                Select Case tipo

                    Case 2
                            dgwPresupuesto.Rows(i).Cells(0).Style.BackColor = Color.LightSteelBlue
                            dgwPresupuesto.Rows(i).Cells(1).Style.BackColor = Color.LightSteelBlue
                            dgwPresupuesto.Rows(i).Cells(2).Style.BackColor = Color.LightSteelBlue
                            dgwPresupuesto.Rows(i).Cells(3).Style.BackColor = Color.LightSteelBlue
                            dgwPresupuesto.Rows(i).Cells(4).Style.BackColor = Color.LightSteelBlue
                            dgwPresupuesto.Rows(i).Cells(5).Style.BackColor = Color.LightSteelBlue


                            dgwPresupuesto.Rows(i).Cells(4).ReadOnly = True

                        Case 5
                            dgwPresupuesto.Rows(i).Cells(0).Style.BackColor = Color.DarkGray
                            dgwPresupuesto.Rows(i).Cells(1).Style.BackColor = Color.DarkGray
                            dgwPresupuesto.Rows(i).Cells(2).Style.BackColor = Color.DarkGray
                            dgwPresupuesto.Rows(i).Cells(3).Style.BackColor = Color.DarkGray
                            dgwPresupuesto.Rows(i).Cells(4).Style.BackColor = Color.DarkGray
                            dgwPresupuesto.Rows(i).Cells(5).Style.BackColor = Color.LightSteelBlue
                            dgwPresupuesto.Rows(i).Cells(4).ReadOnly = True

                    End Select

                i = i + 1

            End While

            DOC_Total0.Text = FormatNumber(acPresupuesto, 2)
            DOC_Total1.Text = FormatNumber(acMonto, 2)
            DOC_Total2.Text = FormatNumber(acPresupuesto - acMonto, 2)
            DOC_Total3.Text = FormatNumber(MontoMes(), 2)
            dgwPresupuesto.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells

        End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        CON.Close()
        CON1.Close()
    End Sub

    Public Sub CargarPresupuesto()
        Dim dblTasa As Double = 0.0
        Dim DLocal As String = STR_VACIO
        Dim DExtranjero As String = STR_VACIO
        Dim strFecha As String = STR_VACIO

        strFecha = Format(Mes.Value, "yyyy-MM")
        dgwPresupuesto.Columns(2).HeaderText = cfun.MesALetras(Mes.Value.Month)
        dgwPresupuesto.Columns(4).HeaderText = cfun.MesALetras(Mes.Value.Month + 1)

        dblTasa = cfun.QueryTasa(strFecha)

        QueryPresupuesto()

        'dgwPresupuesto.ReadOnly = True

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        Me.Close()
    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load
        BarraTitulo1.CambiarTitulo("Presupuesto")
    End Sub

    Private Sub btnActualizar_Click(sender As Object, e As EventArgs) Handles btnActualizar.Click
        Dim frmMensajeS As New frmMensaje

        frmMensajeS.Mensaje = "Loading budget"
        frmMensajeS.Show()
        system.Windows.Forms.Application.DoEvents()
        CargarPresupuesto()
        frmMensajeS.Close()
    End Sub

    Private Sub Mes_Validated(sender As Object, e As EventArgs) Handles Mes.Validated
        dtpIncio.Value = DateSerial(Year(Mes.Value), Month(Mes.Value), 1)
        dtpFin.Value = DateSerial(Year(Mes.Value), Month(Mes.Value) + 1, vbEmpty)
    End Sub

    Private Sub dgwPresupuesto_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles dgwPresupuesto.CellValueChanged
        DOC_Total3.Text = FormatNumber(MontoMes(), 2)
    End Sub

    Private Sub btnPresupuesto_Click(sender As Object, e As EventArgs) Handles btnPresupuesto.Click
        Dim strIdioma As String = STR_VACIO

        If rbEspañol.Checked = True Then
            strIdioma = STR_LOC
        End If

        If rbIngles.Checked = True Then
            strIdioma = STR_EXT
        End If

        If logConsultar = True Then
            frmRPresupuesto.strFormulario = strKey
            frmRPresupuesto.Idioma = strIdioma
            If frmRPresupuesto.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            End If
        Else
            MsgBox("You do not have permissions for this action", vbInformation, "Notice ")
        End If

    End Sub

    Private Sub btnCentro_Click(sender As Object, e As EventArgs) Handles btnCentro.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim frmmensajef As New frmMensaje

        strCondicion = " cost_num in(SELECT B.pms_id " & _
                       "FROM Contabilidad.Permisos B  " & _
                       "WHERE B.pms_empresa = {empresa} AND B.pms_modulo = 151 AND B.pms_usuario = '{usuario}' )"

        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{usuario}", Sesion.Usuario)

        frm.Tabla = "{conta}.costos A "
        frm.Campos = "A.cost_num Codigo,cost_nombre Centro "
        frm.Condicion = strCondicion
        frm.Filtro = "cost_nombre "
        frm.Titulo = "Centro de Costo "
        frm.FiltroText = "Ingrese el Centro de Costo a Filtrar "
     
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            lblCodigo.Text = frm.LLave
            lblCosto.Text = frm.Dato
            frmmensajef.Mensaje = "Cambiando Centro de Costo a " & lblCosto.Text & " "
            frmmensajef.Show()
            system.Windows.Forms.Application.DoEvents()

            QueryPresupuesto()
            frmmensajef.Close()
        End If

    End Sub

    Private Sub btnCargar_Click(sender As Object, e As EventArgs) Handles btnCargar.Click
        Dim frmMensajeS As New frmMensaje

        frmMensajeS.Mensaje = "Loading budget"
        frmMensajeS.Show()
        system.Windows.Forms.Application.DoEvents()
        QueryPresupuesto()
        frmMensajeS.Close()

    End Sub

    Private Sub Mes_ValueChanged(sender As Object, e As EventArgs) Handles Mes.ValueChanged
        dtpIncio.Value = DateSerial(Year(Mes.Value), Month(Mes.Value), 1)
        dtpFin.Value = DateSerial(Year(Mes.Value), Month(Mes.Value) + 1, vbEmpty)
    End Sub

    Private Sub btnImprimir_Click(sender As Object, e As EventArgs) Handles btnImprimir.Click
        Dim rpt As New clsReportes
        Dim intDetalle As Integer
        Dim intLenguaje As Integer
        Dim intMoneda As Integer
        Dim dtFecha As Date
        'intLenguaje, 1 = español, 0 = Ingles
        intLenguaje = IIf(rbEspañol.Checked = True, 1, 0)
        ' intMoneda, 1 = quetzales, 0 = dolares
        intMoneda = IIf(rbQuetzal.Checked = True, 1, 0)
        dtFecha = Mes.Value
        If MsgBox("¿Include document detail?", vbYesNo + vbQuestion, "Print") = vbYes Then
            intDetalle = 1
            rpt.ImprimirPresupuesto(intLenguaje, intMoneda, intDetalle, dtFecha)
        Else
            intDetalle = 0
            rpt.ImprimirPresupuesto(intLenguaje, intMoneda, intDetalle, dtFecha)
        End If
    End Sub

    Private Sub dgwPresupuesto_DoubleClick(sender As Object, e As EventArgs) Handles dgwPresupuesto.DoubleClick
        frmXDocumentos.FechaInicio = dtpIncio.Value
        frmXDocumentos.FechaFinal = dtpFin.Value
        frmXDocumentos.Cuenta = dgwPresupuesto.SelectedCells(0).Value
        If frmXDocumentos.ShowDialog = System.Windows.Forms.DialogResult.OK Then

        End If

    End Sub

    Private Sub frmPresupuesto_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
End Class