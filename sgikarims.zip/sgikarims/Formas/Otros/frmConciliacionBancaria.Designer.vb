﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConciliacionBancaria
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmConciliacionBancaria))
        Me.panelResumen = New System.Windows.Forms.Panel()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.panelResumen1 = New System.Windows.Forms.Panel()
        Me.celdaIDConciliacion = New System.Windows.Forms.TextBox()
        Me.botonAcFecha = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaY = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.celdaBuscar = New System.Windows.Forms.TextBox()
        Me.etiquetaBuscar = New System.Windows.Forms.Label()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.botonPoliza = New System.Windows.Forms.Button()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonGuardar = New System.Windows.Forms.Button()
        Me.botonConciliacion = New System.Windows.Forms.Button()
        Me.celdaSaldoFinalConta = New System.Windows.Forms.TextBox()
        Me.celdaSaldoFinalBank = New System.Windows.Forms.TextBox()
        Me.etiquetaSFConta = New System.Windows.Forms.Label()
        Me.etiquetaSFBank = New System.Windows.Forms.Label()
        Me.etiquetaDatSaldo = New System.Windows.Forms.Label()
        Me.etiquetaSaldo = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.etiquetaDatoDebit = New System.Windows.Forms.Label()
        Me.etiquetaDebito = New System.Windows.Forms.Label()
        Me.etiquetaDatoCred = New System.Windows.Forms.Label()
        Me.etiquetaCredito = New System.Windows.Forms.Label()
        Me.etiquetaResumen = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetSFBank = New System.Windows.Forms.Label()
        Me.celdaSubtotal2 = New System.Windows.Forms.TextBox()
        Me.celdaSubtotal1 = New System.Windows.Forms.TextBox()
        Me.celdaSubTotal3 = New System.Windows.Forms.TextBox()
        Me.celdaSubtotal0 = New System.Windows.Forms.TextBox()
        Me.celdaSubtotal4 = New System.Windows.Forms.TextBox()
        Me.etiquetaSubNCredit = New System.Windows.Forms.Label()
        Me.etiquetaSubDepositos = New System.Windows.Forms.Label()
        Me.etiquetaSubDebit = New System.Windows.Forms.Label()
        Me.etiquetaSubCheques = New System.Windows.Forms.Label()
        Me.etiquetaSInicialBank = New System.Windows.Forms.Label()
        Me.gbSaldoAnt = New System.Windows.Forms.GroupBox()
        Me.etiquetaMoneda3 = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda2 = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDiferencia = New System.Windows.Forms.TextBox()
        Me.etiquetaDiferencia = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.celdaSInicialConta = New System.Windows.Forms.TextBox()
        Me.celdaSInicialBanco = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.etiquetaSaldoIBank = New System.Windows.Forms.Label()
        Me.panelSigMes = New System.Windows.Forms.Panel()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarActual4 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.checkActualDebitNotes = New System.Windows.Forms.CheckBox()
        Me.dgActNoteDebit = New System.Windows.Forms.DataGridView()
        Me.Column12 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colActNumber4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActNum4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActAnio4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarActual3 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.checkActualCreditNotes = New System.Windows.Forms.CheckBox()
        Me.dgActNotCredit = New System.Windows.Forms.DataGridView()
        Me.Column11 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colActNumber3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActNum3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActAnio3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarActual = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.checkActualCheques = New System.Windows.Forms.CheckBox()
        Me.dgActCheques = New System.Windows.Forms.DataGridView()
        Me.Column9 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colActNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarActual2 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.checkActualDepositos = New System.Windows.Forms.CheckBox()
        Me.dgActDepositos = New System.Windows.Forms.DataGridView()
        Me.Column10 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colActNumber2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActNum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colActAnio2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.etiquetaMesSiguiente = New System.Windows.Forms.Label()
        Me.panelMesAnterior = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarPendientes4 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.checkPenDebitNotes = New System.Windows.Forms.CheckBox()
        Me.dgPenNotasDebit = New System.Windows.Forms.DataGridView()
        Me.Column8 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colNumber4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarPendientes3 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.checkPenCreditNotes = New System.Windows.Forms.CheckBox()
        Me.dgPenNotasCredito = New System.Windows.Forms.DataGridView()
        Me.Column7 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colNumber3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarPendientes = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.checkPenCheques = New System.Windows.Forms.CheckBox()
        Me.dgPenCheques = New System.Windows.Forms.DataGridView()
        Me.colSeleccionar = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarPendientes2 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.checkPenDeposito = New System.Windows.Forms.CheckBox()
        Me.dgPenDepositos = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colNumber2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.etiquetaMesesPendientes = New System.Windows.Forms.Label()
        Me.panelMesActual = New System.Windows.Forms.Panel()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarDoc4 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.checkDocDebitNotes = New System.Windows.Forms.CheckBox()
        Me.dgDocNotDebit = New System.Windows.Forms.DataGridView()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colDocNumber4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocNum4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocAnio4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarDoc3 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.checkDocCrediNotes = New System.Windows.Forms.CheckBox()
        Me.dgDocNotasCredit = New System.Windows.Forms.DataGridView()
        Me.DataGridViewCheckBoxColumn2 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colDocNumber3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocNum3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocAnio3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarDoc = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.checkDocCheques = New System.Windows.Forms.CheckBox()
        Me.dgDocCheques = New System.Windows.Forms.DataGridView()
        Me.DataGridViewCheckBoxColumn3 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colDocNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.celdaLiquidarDoc2 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.checkDocDepositos = New System.Windows.Forms.CheckBox()
        Me.dgDocDepositos = New System.Windows.Forms.DataGridView()
        Me.DataGridViewCheckBoxColumn4 = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colDocNumber2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocNum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocAnio2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.etiquetaMesActual = New System.Windows.Forms.Label()
        Me.panelResumen.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.panelResumen1.SuspendLayout()
        Me.gbSaldoAnt.SuspendLayout()
        Me.panelSigMes.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.dgActNoteDebit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.dgActNotCredit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.dgActCheques, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.dgActDepositos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelMesAnterior.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgPenNotasDebit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgPenNotasCredito, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.dgPenCheques, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.dgPenDepositos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelMesActual.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.dgDocNotDebit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        CType(Me.dgDocNotasCredit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox11.SuspendLayout()
        CType(Me.dgDocCheques, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox12.SuspendLayout()
        CType(Me.dgDocDepositos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelResumen
        '
        Me.panelResumen.Controls.Add(Me.panelTotales)
        Me.panelResumen.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelResumen.Location = New System.Drawing.Point(0, 775)
        Me.panelResumen.Margin = New System.Windows.Forms.Padding(4)
        Me.panelResumen.Name = "panelResumen"
        Me.panelResumen.Size = New System.Drawing.Size(1438, 219)
        Me.panelResumen.TabIndex = 1
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.panelResumen1)
        Me.panelTotales.Controls.Add(Me.gbSaldoAnt)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelTotales.Location = New System.Drawing.Point(0, 0)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1438, 219)
        Me.panelTotales.TabIndex = 2
        '
        'panelResumen1
        '
        Me.panelResumen1.Controls.Add(Me.celdaIDConciliacion)
        Me.panelResumen1.Controls.Add(Me.botonAcFecha)
        Me.panelResumen1.Controls.Add(Me.dtpFin)
        Me.panelResumen1.Controls.Add(Me.etiquetaY)
        Me.panelResumen1.Controls.Add(Me.dtpInicio)
        Me.panelResumen1.Controls.Add(Me.etiquetaFecha)
        Me.panelResumen1.Controls.Add(Me.botonBuscar)
        Me.panelResumen1.Controls.Add(Me.celdaBuscar)
        Me.panelResumen1.Controls.Add(Me.etiquetaBuscar)
        Me.panelResumen1.Controls.Add(Me.botonCerrar)
        Me.panelResumen1.Controls.Add(Me.botonPoliza)
        Me.panelResumen1.Controls.Add(Me.botonEliminar)
        Me.panelResumen1.Controls.Add(Me.botonImprimir)
        Me.panelResumen1.Controls.Add(Me.botonGuardar)
        Me.panelResumen1.Controls.Add(Me.botonConciliacion)
        Me.panelResumen1.Controls.Add(Me.celdaSaldoFinalConta)
        Me.panelResumen1.Controls.Add(Me.celdaSaldoFinalBank)
        Me.panelResumen1.Controls.Add(Me.etiquetaSFConta)
        Me.panelResumen1.Controls.Add(Me.etiquetaSFBank)
        Me.panelResumen1.Controls.Add(Me.etiquetaDatSaldo)
        Me.panelResumen1.Controls.Add(Me.etiquetaSaldo)
        Me.panelResumen1.Controls.Add(Me.Label11)
        Me.panelResumen1.Controls.Add(Me.etiquetaDatoDebit)
        Me.panelResumen1.Controls.Add(Me.etiquetaDebito)
        Me.panelResumen1.Controls.Add(Me.etiquetaDatoCred)
        Me.panelResumen1.Controls.Add(Me.etiquetaCredito)
        Me.panelResumen1.Controls.Add(Me.etiquetaResumen)
        Me.panelResumen1.Controls.Add(Me.Label10)
        Me.panelResumen1.Controls.Add(Me.celdaTotal)
        Me.panelResumen1.Controls.Add(Me.etiquetSFBank)
        Me.panelResumen1.Controls.Add(Me.celdaSubtotal2)
        Me.panelResumen1.Controls.Add(Me.celdaSubtotal1)
        Me.panelResumen1.Controls.Add(Me.celdaSubTotal3)
        Me.panelResumen1.Controls.Add(Me.celdaSubtotal0)
        Me.panelResumen1.Controls.Add(Me.celdaSubtotal4)
        Me.panelResumen1.Controls.Add(Me.etiquetaSubNCredit)
        Me.panelResumen1.Controls.Add(Me.etiquetaSubDepositos)
        Me.panelResumen1.Controls.Add(Me.etiquetaSubDebit)
        Me.panelResumen1.Controls.Add(Me.etiquetaSubCheques)
        Me.panelResumen1.Controls.Add(Me.etiquetaSInicialBank)
        Me.panelResumen1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelResumen1.Location = New System.Drawing.Point(0, 0)
        Me.panelResumen1.Margin = New System.Windows.Forms.Padding(4)
        Me.panelResumen1.Name = "panelResumen1"
        Me.panelResumen1.Size = New System.Drawing.Size(1118, 219)
        Me.panelResumen1.TabIndex = 0
        '
        'celdaIDConciliacion
        '
        Me.celdaIDConciliacion.BackColor = System.Drawing.SystemColors.Control
        Me.celdaIDConciliacion.Location = New System.Drawing.Point(656, 109)
        Me.celdaIDConciliacion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDConciliacion.Multiline = True
        Me.celdaIDConciliacion.Name = "celdaIDConciliacion"
        Me.celdaIDConciliacion.Size = New System.Drawing.Size(31, 25)
        Me.celdaIDConciliacion.TabIndex = 39
        Me.celdaIDConciliacion.Text = "-1"
        Me.celdaIDConciliacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaIDConciliacion.Visible = False
        '
        'botonAcFecha
        '
        Me.botonAcFecha.Location = New System.Drawing.Point(1065, 77)
        Me.botonAcFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAcFecha.Name = "botonAcFecha"
        Me.botonAcFecha.Size = New System.Drawing.Size(40, 28)
        Me.botonAcFecha.TabIndex = 38
        Me.botonAcFecha.Text = "..."
        Me.botonAcFecha.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(951, 77)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(104, 22)
        Me.dtpFin.TabIndex = 37
        '
        'etiquetaY
        '
        Me.etiquetaY.AutoSize = True
        Me.etiquetaY.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaY.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaY.ForeColor = System.Drawing.Color.Black
        Me.etiquetaY.Location = New System.Drawing.Point(910, 80)
        Me.etiquetaY.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaY.Name = "etiquetaY"
        Me.etiquetaY.Size = New System.Drawing.Size(33, 17)
        Me.etiquetaY.TabIndex = 36
        Me.etiquetaY.Text = "And"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(797, 77)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(104, 22)
        Me.dtpInicio.TabIndex = 35
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaFecha.ForeColor = System.Drawing.Color.Black
        Me.etiquetaFecha.Location = New System.Drawing.Point(749, 81)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 34
        Me.etiquetaFecha.Text = "Date"
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = CType(resources.GetObject("botonBuscar.Image"), System.Drawing.Image)
        Me.botonBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonBuscar.Location = New System.Drawing.Point(1065, 18)
        Me.botonBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(40, 33)
        Me.botonBuscar.TabIndex = 33
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'celdaBuscar
        '
        Me.celdaBuscar.BackColor = System.Drawing.SystemColors.Info
        Me.celdaBuscar.Location = New System.Drawing.Point(872, 18)
        Me.celdaBuscar.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaBuscar.Multiline = True
        Me.celdaBuscar.Name = "celdaBuscar"
        Me.celdaBuscar.Size = New System.Drawing.Size(185, 20)
        Me.celdaBuscar.TabIndex = 32
        Me.celdaBuscar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaBuscar
        '
        Me.etiquetaBuscar.AutoSize = True
        Me.etiquetaBuscar.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaBuscar.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaBuscar.ForeColor = System.Drawing.Color.Black
        Me.etiquetaBuscar.Location = New System.Drawing.Point(818, 23)
        Me.etiquetaBuscar.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaBuscar.Name = "etiquetaBuscar"
        Me.etiquetaBuscar.Size = New System.Drawing.Size(53, 17)
        Me.etiquetaBuscar.TabIndex = 31
        Me.etiquetaBuscar.Text = "Search"
        '
        'botonCerrar
        '
        Me.botonCerrar.Image = CType(resources.GetObject("botonCerrar.Image"), System.Drawing.Image)
        Me.botonCerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCerrar.Location = New System.Drawing.Point(1043, 142)
        Me.botonCerrar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(69, 50)
        Me.botonCerrar.TabIndex = 30
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'botonPoliza
        '
        Me.botonPoliza.Image = CType(resources.GetObject("botonPoliza.Image"), System.Drawing.Image)
        Me.botonPoliza.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonPoliza.Location = New System.Drawing.Point(966, 143)
        Me.botonPoliza.Margin = New System.Windows.Forms.Padding(4)
        Me.botonPoliza.Name = "botonPoliza"
        Me.botonPoliza.Size = New System.Drawing.Size(69, 50)
        Me.botonPoliza.TabIndex = 29
        Me.botonPoliza.Text = "Policy"
        Me.botonPoliza.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPoliza.UseVisualStyleBackColor = True
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = CType(resources.GetObject("botonEliminar.Image"), System.Drawing.Image)
        Me.botonEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonEliminar.Location = New System.Drawing.Point(889, 142)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(69, 50)
        Me.botonEliminar.TabIndex = 28
        Me.botonEliminar.Text = "Delete"
        Me.botonEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonImprimir.Location = New System.Drawing.Point(734, 142)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(69, 50)
        Me.botonImprimir.TabIndex = 27
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonGuardar
        '
        Me.botonGuardar.Image = CType(resources.GetObject("botonGuardar.Image"), System.Drawing.Image)
        Me.botonGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonGuardar.Location = New System.Drawing.Point(811, 142)
        Me.botonGuardar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonGuardar.Name = "botonGuardar"
        Me.botonGuardar.Size = New System.Drawing.Size(69, 50)
        Me.botonGuardar.TabIndex = 26
        Me.botonGuardar.Text = "Save"
        Me.botonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGuardar.UseVisualStyleBackColor = True
        '
        'botonConciliacion
        '
        Me.botonConciliacion.Image = CType(resources.GetObject("botonConciliacion.Image"), System.Drawing.Image)
        Me.botonConciliacion.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonConciliacion.Location = New System.Drawing.Point(618, 142)
        Me.botonConciliacion.Margin = New System.Windows.Forms.Padding(4)
        Me.botonConciliacion.Name = "botonConciliacion"
        Me.botonConciliacion.Size = New System.Drawing.Size(108, 50)
        Me.botonConciliacion.TabIndex = 25
        Me.botonConciliacion.Text = "Conciliations"
        Me.botonConciliacion.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonConciliacion.UseVisualStyleBackColor = True
        '
        'celdaSaldoFinalConta
        '
        Me.celdaSaldoFinalConta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSaldoFinalConta.Location = New System.Drawing.Point(468, 167)
        Me.celdaSaldoFinalConta.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSaldoFinalConta.Multiline = True
        Me.celdaSaldoFinalConta.Name = "celdaSaldoFinalConta"
        Me.celdaSaldoFinalConta.ReadOnly = True
        Me.celdaSaldoFinalConta.Size = New System.Drawing.Size(103, 20)
        Me.celdaSaldoFinalConta.TabIndex = 24
        Me.celdaSaldoFinalConta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSaldoFinalBank
        '
        Me.celdaSaldoFinalBank.BackColor = System.Drawing.SystemColors.Control
        Me.celdaSaldoFinalBank.Location = New System.Drawing.Point(468, 139)
        Me.celdaSaldoFinalBank.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSaldoFinalBank.Multiline = True
        Me.celdaSaldoFinalBank.Name = "celdaSaldoFinalBank"
        Me.celdaSaldoFinalBank.Size = New System.Drawing.Size(103, 20)
        Me.celdaSaldoFinalBank.TabIndex = 23
        Me.celdaSaldoFinalBank.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSFConta
        '
        Me.etiquetaSFConta.AutoSize = True
        Me.etiquetaSFConta.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaSFConta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSFConta.ForeColor = System.Drawing.Color.Black
        Me.etiquetaSFConta.Location = New System.Drawing.Point(297, 170)
        Me.etiquetaSFConta.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSFConta.Name = "etiquetaSFConta"
        Me.etiquetaSFConta.Size = New System.Drawing.Size(167, 17)
        Me.etiquetaSFConta.TabIndex = 22
        Me.etiquetaSFConta.Text = "Final Balance Accounting"
        '
        'etiquetaSFBank
        '
        Me.etiquetaSFBank.AutoSize = True
        Me.etiquetaSFBank.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaSFBank.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSFBank.ForeColor = System.Drawing.Color.Black
        Me.etiquetaSFBank.Location = New System.Drawing.Point(297, 142)
        Me.etiquetaSFBank.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSFBank.Name = "etiquetaSFBank"
        Me.etiquetaSFBank.Size = New System.Drawing.Size(129, 17)
        Me.etiquetaSFBank.TabIndex = 21
        Me.etiquetaSFBank.Text = "Final Balance Bank"
        '
        'etiquetaDatSaldo
        '
        Me.etiquetaDatSaldo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaDatSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDatSaldo.ForeColor = System.Drawing.Color.Black
        Me.etiquetaDatSaldo.Location = New System.Drawing.Point(359, 103)
        Me.etiquetaDatSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDatSaldo.Name = "etiquetaDatSaldo"
        Me.etiquetaDatSaldo.Size = New System.Drawing.Size(127, 23)
        Me.etiquetaDatSaldo.TabIndex = 20
        Me.etiquetaDatSaldo.Text = "Balance"
        Me.etiquetaDatSaldo.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'etiquetaSaldo
        '
        Me.etiquetaSaldo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSaldo.ForeColor = System.Drawing.SystemColors.Highlight
        Me.etiquetaSaldo.Location = New System.Drawing.Point(291, 105)
        Me.etiquetaSaldo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSaldo.Name = "etiquetaSaldo"
        Me.etiquetaSaldo.Size = New System.Drawing.Size(76, 21)
        Me.etiquetaSaldo.TabIndex = 19
        Me.etiquetaSaldo.Text = "Balance"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label11.Location = New System.Drawing.Point(295, 79)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(203, 26)
        Me.Label11.TabIndex = 18
        Me.Label11.Text = "_________________________"
        '
        'etiquetaDatoDebit
        '
        Me.etiquetaDatoDebit.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaDatoDebit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDatoDebit.ForeColor = System.Drawing.Color.Black
        Me.etiquetaDatoDebit.Location = New System.Drawing.Point(371, 65)
        Me.etiquetaDatoDebit.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDatoDebit.Name = "etiquetaDatoDebit"
        Me.etiquetaDatoDebit.Size = New System.Drawing.Size(115, 17)
        Me.etiquetaDatoDebit.TabIndex = 17
        Me.etiquetaDatoDebit.Text = "Debit"
        Me.etiquetaDatoDebit.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'etiquetaDebito
        '
        Me.etiquetaDebito.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaDebito.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDebito.ForeColor = System.Drawing.SystemColors.Highlight
        Me.etiquetaDebito.Location = New System.Drawing.Point(291, 63)
        Me.etiquetaDebito.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDebito.Name = "etiquetaDebito"
        Me.etiquetaDebito.Size = New System.Drawing.Size(61, 21)
        Me.etiquetaDebito.TabIndex = 16
        Me.etiquetaDebito.Text = "Debit"
        '
        'etiquetaDatoCred
        '
        Me.etiquetaDatoCred.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaDatoCred.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDatoCred.ForeColor = System.Drawing.Color.Black
        Me.etiquetaDatoCred.Location = New System.Drawing.Point(368, 41)
        Me.etiquetaDatoCred.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDatoCred.Name = "etiquetaDatoCred"
        Me.etiquetaDatoCred.Size = New System.Drawing.Size(118, 21)
        Me.etiquetaDatoCred.TabIndex = 15
        Me.etiquetaDatoCred.Text = "Credit"
        Me.etiquetaDatoCred.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'etiquetaCredito
        '
        Me.etiquetaCredito.AutoSize = True
        Me.etiquetaCredito.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaCredito.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCredito.ForeColor = System.Drawing.SystemColors.Highlight
        Me.etiquetaCredito.Location = New System.Drawing.Point(291, 42)
        Me.etiquetaCredito.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCredito.Name = "etiquetaCredito"
        Me.etiquetaCredito.Size = New System.Drawing.Size(51, 17)
        Me.etiquetaCredito.TabIndex = 14
        Me.etiquetaCredito.Text = "Credit"
        '
        'etiquetaResumen
        '
        Me.etiquetaResumen.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaResumen.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaResumen.Location = New System.Drawing.Point(297, 21)
        Me.etiquetaResumen.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaResumen.Name = "etiquetaResumen"
        Me.etiquetaResumen.Size = New System.Drawing.Size(163, 21)
        Me.etiquetaResumen.TabIndex = 13
        Me.etiquetaResumen.Text = "Summary"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label10.Location = New System.Drawing.Point(15, 126)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(280, 17)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "__________________________________"
        '
        'celdaTotal
        '
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Location = New System.Drawing.Point(185, 153)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTotal.Multiline = True
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ShortcutsEnabled = False
        Me.celdaTotal.Size = New System.Drawing.Size(103, 20)
        Me.celdaTotal.TabIndex = 11
        Me.celdaTotal.Text = "0.00"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetSFBank
        '
        Me.etiquetSFBank.BackColor = System.Drawing.Color.Red
        Me.etiquetSFBank.ForeColor = System.Drawing.Color.White
        Me.etiquetSFBank.Location = New System.Drawing.Point(15, 153)
        Me.etiquetSFBank.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetSFBank.Name = "etiquetSFBank"
        Me.etiquetSFBank.Size = New System.Drawing.Size(163, 21)
        Me.etiquetSFBank.TabIndex = 10
        Me.etiquetSFBank.Text = "Final Balance Bank"
        '
        'celdaSubtotal2
        '
        Me.celdaSubtotal2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSubtotal2.Location = New System.Drawing.Point(185, 105)
        Me.celdaSubtotal2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSubtotal2.Multiline = True
        Me.celdaSubtotal2.Name = "celdaSubtotal2"
        Me.celdaSubtotal2.ReadOnly = True
        Me.celdaSubtotal2.Size = New System.Drawing.Size(103, 20)
        Me.celdaSubtotal2.TabIndex = 9
        Me.celdaSubtotal2.Text = "0.00"
        Me.celdaSubtotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSubtotal1
        '
        Me.celdaSubtotal1.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSubtotal1.Location = New System.Drawing.Point(185, 84)
        Me.celdaSubtotal1.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSubtotal1.Multiline = True
        Me.celdaSubtotal1.Name = "celdaSubtotal1"
        Me.celdaSubtotal1.ReadOnly = True
        Me.celdaSubtotal1.Size = New System.Drawing.Size(103, 20)
        Me.celdaSubtotal1.TabIndex = 8
        Me.celdaSubtotal1.Text = "0.00"
        Me.celdaSubtotal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSubTotal3
        '
        Me.celdaSubTotal3.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSubTotal3.Location = New System.Drawing.Point(185, 63)
        Me.celdaSubTotal3.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSubTotal3.Multiline = True
        Me.celdaSubTotal3.Name = "celdaSubTotal3"
        Me.celdaSubTotal3.ReadOnly = True
        Me.celdaSubTotal3.Size = New System.Drawing.Size(103, 20)
        Me.celdaSubTotal3.TabIndex = 7
        Me.celdaSubTotal3.Text = "0.00"
        Me.celdaSubTotal3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSubtotal0
        '
        Me.celdaSubtotal0.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSubtotal0.Location = New System.Drawing.Point(185, 42)
        Me.celdaSubtotal0.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSubtotal0.Multiline = True
        Me.celdaSubtotal0.Name = "celdaSubtotal0"
        Me.celdaSubtotal0.ReadOnly = True
        Me.celdaSubtotal0.Size = New System.Drawing.Size(103, 20)
        Me.celdaSubtotal0.TabIndex = 6
        Me.celdaSubtotal0.Text = "0.00"
        Me.celdaSubtotal0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSubtotal4
        '
        Me.celdaSubtotal4.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSubtotal4.Location = New System.Drawing.Point(185, 21)
        Me.celdaSubtotal4.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSubtotal4.Multiline = True
        Me.celdaSubtotal4.Name = "celdaSubtotal4"
        Me.celdaSubtotal4.ReadOnly = True
        Me.celdaSubtotal4.Size = New System.Drawing.Size(103, 20)
        Me.celdaSubtotal4.TabIndex = 5
        Me.celdaSubtotal4.Text = "0.00"
        Me.celdaSubtotal4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSubNCredit
        '
        Me.etiquetaSubNCredit.BackColor = System.Drawing.Color.SteelBlue
        Me.etiquetaSubNCredit.ForeColor = System.Drawing.Color.White
        Me.etiquetaSubNCredit.Location = New System.Drawing.Point(15, 105)
        Me.etiquetaSubNCredit.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSubNCredit.Name = "etiquetaSubNCredit"
        Me.etiquetaSubNCredit.Size = New System.Drawing.Size(163, 21)
        Me.etiquetaSubNCredit.TabIndex = 4
        Me.etiquetaSubNCredit.Text = "Sub-Total Ntas Credit"
        '
        'etiquetaSubDepositos
        '
        Me.etiquetaSubDepositos.BackColor = System.Drawing.Color.SteelBlue
        Me.etiquetaSubDepositos.ForeColor = System.Drawing.Color.White
        Me.etiquetaSubDepositos.Location = New System.Drawing.Point(15, 84)
        Me.etiquetaSubDepositos.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSubDepositos.Name = "etiquetaSubDepositos"
        Me.etiquetaSubDepositos.Size = New System.Drawing.Size(163, 21)
        Me.etiquetaSubDepositos.TabIndex = 3
        Me.etiquetaSubDepositos.Text = "Sub-Total Deposits"
        '
        'etiquetaSubDebit
        '
        Me.etiquetaSubDebit.BackColor = System.Drawing.Color.SteelBlue
        Me.etiquetaSubDebit.ForeColor = System.Drawing.Color.White
        Me.etiquetaSubDebit.Location = New System.Drawing.Point(15, 63)
        Me.etiquetaSubDebit.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSubDebit.Name = "etiquetaSubDebit"
        Me.etiquetaSubDebit.Size = New System.Drawing.Size(163, 21)
        Me.etiquetaSubDebit.TabIndex = 2
        Me.etiquetaSubDebit.Text = "Sub-Total Ntas Debit"
        '
        'etiquetaSubCheques
        '
        Me.etiquetaSubCheques.BackColor = System.Drawing.Color.SteelBlue
        Me.etiquetaSubCheques.ForeColor = System.Drawing.Color.White
        Me.etiquetaSubCheques.Location = New System.Drawing.Point(15, 42)
        Me.etiquetaSubCheques.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSubCheques.Name = "etiquetaSubCheques"
        Me.etiquetaSubCheques.Size = New System.Drawing.Size(163, 21)
        Me.etiquetaSubCheques.TabIndex = 1
        Me.etiquetaSubCheques.Text = "Sub-Total Checks"
        '
        'etiquetaSInicialBank
        '
        Me.etiquetaSInicialBank.BackColor = System.Drawing.Color.SteelBlue
        Me.etiquetaSInicialBank.ForeColor = System.Drawing.Color.White
        Me.etiquetaSInicialBank.Location = New System.Drawing.Point(15, 21)
        Me.etiquetaSInicialBank.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSInicialBank.Name = "etiquetaSInicialBank"
        Me.etiquetaSInicialBank.Size = New System.Drawing.Size(163, 21)
        Me.etiquetaSInicialBank.TabIndex = 0
        Me.etiquetaSInicialBank.Text = "Opening Balance Banks"
        '
        'gbSaldoAnt
        '
        Me.gbSaldoAnt.Controls.Add(Me.etiquetaMoneda3)
        Me.gbSaldoAnt.Controls.Add(Me.etiquetaMoneda2)
        Me.gbSaldoAnt.Controls.Add(Me.etiquetaMoneda)
        Me.gbSaldoAnt.Controls.Add(Me.celdaDiferencia)
        Me.gbSaldoAnt.Controls.Add(Me.etiquetaDiferencia)
        Me.gbSaldoAnt.Controls.Add(Me.Label13)
        Me.gbSaldoAnt.Controls.Add(Me.celdaSInicialConta)
        Me.gbSaldoAnt.Controls.Add(Me.celdaSInicialBanco)
        Me.gbSaldoAnt.Controls.Add(Me.Label12)
        Me.gbSaldoAnt.Controls.Add(Me.etiquetaSaldoIBank)
        Me.gbSaldoAnt.Dock = System.Windows.Forms.DockStyle.Right
        Me.gbSaldoAnt.Location = New System.Drawing.Point(1118, 0)
        Me.gbSaldoAnt.Margin = New System.Windows.Forms.Padding(4)
        Me.gbSaldoAnt.Name = "gbSaldoAnt"
        Me.gbSaldoAnt.Padding = New System.Windows.Forms.Padding(4)
        Me.gbSaldoAnt.Size = New System.Drawing.Size(320, 219)
        Me.gbSaldoAnt.TabIndex = 1
        Me.gbSaldoAnt.TabStop = False
        Me.gbSaldoAnt.Text = "Previous Balance"
        '
        'etiquetaMoneda3
        '
        Me.etiquetaMoneda3.BackColor = System.Drawing.SystemColors.Control
        Me.etiquetaMoneda3.Location = New System.Drawing.Point(300, 151)
        Me.etiquetaMoneda3.Margin = New System.Windows.Forms.Padding(4)
        Me.etiquetaMoneda3.Multiline = True
        Me.etiquetaMoneda3.Name = "etiquetaMoneda3"
        Me.etiquetaMoneda3.Size = New System.Drawing.Size(31, 25)
        Me.etiquetaMoneda3.TabIndex = 42
        Me.etiquetaMoneda3.Text = "-1"
        Me.etiquetaMoneda3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.etiquetaMoneda3.Visible = False
        '
        'etiquetaMoneda2
        '
        Me.etiquetaMoneda2.BackColor = System.Drawing.SystemColors.Control
        Me.etiquetaMoneda2.Location = New System.Drawing.Point(286, 100)
        Me.etiquetaMoneda2.Margin = New System.Windows.Forms.Padding(4)
        Me.etiquetaMoneda2.Multiline = True
        Me.etiquetaMoneda2.Name = "etiquetaMoneda2"
        Me.etiquetaMoneda2.Size = New System.Drawing.Size(31, 25)
        Me.etiquetaMoneda2.TabIndex = 41
        Me.etiquetaMoneda2.Text = "-1"
        Me.etiquetaMoneda2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.etiquetaMoneda2.Visible = False
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.BackColor = System.Drawing.SystemColors.Control
        Me.etiquetaMoneda.Location = New System.Drawing.Point(286, 63)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(4)
        Me.etiquetaMoneda.Multiline = True
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(31, 25)
        Me.etiquetaMoneda.TabIndex = 40
        Me.etiquetaMoneda.Text = "-1"
        Me.etiquetaMoneda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.etiquetaMoneda.Visible = False
        '
        'celdaDiferencia
        '
        Me.celdaDiferencia.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDiferencia.Location = New System.Drawing.Point(177, 155)
        Me.celdaDiferencia.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDiferencia.Name = "celdaDiferencia"
        Me.celdaDiferencia.Size = New System.Drawing.Size(103, 22)
        Me.celdaDiferencia.TabIndex = 38
        Me.celdaDiferencia.Text = "0.00"
        Me.celdaDiferencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaDiferencia
        '
        Me.etiquetaDiferencia.AutoSize = True
        Me.etiquetaDiferencia.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaDiferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDiferencia.ForeColor = System.Drawing.Color.Black
        Me.etiquetaDiferencia.Location = New System.Drawing.Point(101, 160)
        Me.etiquetaDiferencia.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDiferencia.Name = "etiquetaDiferencia"
        Me.etiquetaDiferencia.Size = New System.Drawing.Size(73, 17)
        Me.etiquetaDiferencia.TabIndex = 37
        Me.etiquetaDiferencia.Text = "Difference"
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label13.Location = New System.Drawing.Point(7, 129)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(335, 26)
        Me.Label13.TabIndex = 36
        Me.Label13.Text = "________________________________________________"
        '
        'celdaSInicialConta
        '
        Me.celdaSInicialConta.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSInicialConta.Location = New System.Drawing.Point(177, 101)
        Me.celdaSInicialConta.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSInicialConta.Name = "celdaSInicialConta"
        Me.celdaSInicialConta.Size = New System.Drawing.Size(103, 22)
        Me.celdaSInicialConta.TabIndex = 35
        Me.celdaSInicialConta.Text = "0.00"
        Me.celdaSInicialConta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSInicialBanco
        '
        Me.celdaSInicialBanco.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSInicialBanco.Location = New System.Drawing.Point(177, 69)
        Me.celdaSInicialBanco.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSInicialBanco.Name = "celdaSInicialBanco"
        Me.celdaSInicialBanco.Size = New System.Drawing.Size(103, 22)
        Me.celdaSInicialBanco.TabIndex = 34
        Me.celdaSInicialBanco.Text = "0.00"
        Me.celdaSInicialBanco.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(4, 106)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(172, 17)
        Me.Label12.TabIndex = 33
        Me.Label12.Text = "Opening Balance Account"
        '
        'etiquetaSaldoIBank
        '
        Me.etiquetaSaldoIBank.AutoSize = True
        Me.etiquetaSaldoIBank.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaSaldoIBank.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSaldoIBank.ForeColor = System.Drawing.Color.Black
        Me.etiquetaSaldoIBank.Location = New System.Drawing.Point(20, 78)
        Me.etiquetaSaldoIBank.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSaldoIBank.Name = "etiquetaSaldoIBank"
        Me.etiquetaSaldoIBank.Size = New System.Drawing.Size(153, 17)
        Me.etiquetaSaldoIBank.TabIndex = 32
        Me.etiquetaSaldoIBank.Text = "Opening Balance Bank"
        '
        'panelSigMes
        '
        Me.panelSigMes.Controls.Add(Me.GroupBox5)
        Me.panelSigMes.Controls.Add(Me.GroupBox6)
        Me.panelSigMes.Controls.Add(Me.GroupBox7)
        Me.panelSigMes.Controls.Add(Me.GroupBox8)
        Me.panelSigMes.Controls.Add(Me.etiquetaMesSiguiente)
        Me.panelSigMes.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelSigMes.Location = New System.Drawing.Point(0, 535)
        Me.panelSigMes.Margin = New System.Windows.Forms.Padding(4)
        Me.panelSigMes.Name = "panelSigMes"
        Me.panelSigMes.Size = New System.Drawing.Size(1438, 240)
        Me.panelSigMes.TabIndex = 2
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.celdaLiquidarActual4)
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.checkActualDebitNotes)
        Me.GroupBox5.Controls.Add(Me.dgActNoteDebit)
        Me.GroupBox5.Location = New System.Drawing.Point(1084, 23)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(359, 213)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Debit Notes"
        '
        'celdaLiquidarActual4
        '
        Me.celdaLiquidarActual4.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarActual4.Location = New System.Drawing.Point(200, 188)
        Me.celdaLiquidarActual4.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarActual4.Name = "celdaLiquidarActual4"
        Me.celdaLiquidarActual4.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarActual4.TabIndex = 7
        Me.celdaLiquidarActual4.Text = "0.00"
        Me.celdaLiquidarActual4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label6.Location = New System.Drawing.Point(156, 192)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 17)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Total"
        '
        'checkActualDebitNotes
        '
        Me.checkActualDebitNotes.AutoSize = True
        Me.checkActualDebitNotes.Location = New System.Drawing.Point(8, 185)
        Me.checkActualDebitNotes.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActualDebitNotes.Name = "checkActualDebitNotes"
        Me.checkActualDebitNotes.Size = New System.Drawing.Size(45, 21)
        Me.checkActualDebitNotes.TabIndex = 5
        Me.checkActualDebitNotes.Text = "All"
        Me.checkActualDebitNotes.UseVisualStyleBackColor = True
        '
        'dgActNoteDebit
        '
        Me.dgActNoteDebit.AllowUserToAddRows = False
        Me.dgActNoteDebit.AllowUserToDeleteRows = False
        Me.dgActNoteDebit.AllowUserToResizeRows = False
        Me.dgActNoteDebit.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgActNoteDebit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgActNoteDebit.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column12, Me.colActNumber4, Me.DataGridViewTextBoxColumn23, Me.colActMonto, Me.colActNum4, Me.colActAnio4})
        Me.dgActNoteDebit.Location = New System.Drawing.Point(8, 21)
        Me.dgActNoteDebit.Margin = New System.Windows.Forms.Padding(4)
        Me.dgActNoteDebit.Name = "dgActNoteDebit"
        Me.dgActNoteDebit.ReadOnly = True
        Me.dgActNoteDebit.RowHeadersVisible = False
        Me.dgActNoteDebit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgActNoteDebit.Size = New System.Drawing.Size(343, 160)
        Me.dgActNoteDebit.TabIndex = 4
        '
        'Column12
        '
        Me.Column12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column12.HeaderText = ""
        Me.Column12.MinimumWidth = 4
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        Me.Column12.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column12.Width = 23
        '
        'colActNumber4
        '
        Me.colActNumber4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActNumber4.HeaderText = "Number"
        Me.colActNumber4.Name = "colActNumber4"
        Me.colActNumber4.ReadOnly = True
        Me.colActNumber4.Width = 87
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn23.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.Width = 67
        '
        'colActMonto
        '
        Me.colActMonto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActMonto.HeaderText = "Monto"
        Me.colActMonto.Name = "colActMonto"
        Me.colActMonto.ReadOnly = True
        Me.colActMonto.Width = 76
        '
        'colActNum4
        '
        Me.colActNum4.HeaderText = "Num"
        Me.colActNum4.Name = "colActNum4"
        Me.colActNum4.ReadOnly = True
        Me.colActNum4.Visible = False
        '
        'colActAnio4
        '
        Me.colActAnio4.HeaderText = "Anio"
        Me.colActAnio4.Name = "colActAnio4"
        Me.colActAnio4.ReadOnly = True
        Me.colActAnio4.Visible = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.celdaLiquidarActual3)
        Me.GroupBox6.Controls.Add(Me.Label7)
        Me.GroupBox6.Controls.Add(Me.checkActualCreditNotes)
        Me.GroupBox6.Controls.Add(Me.dgActNotCredit)
        Me.GroupBox6.Location = New System.Drawing.Point(724, 23)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Size = New System.Drawing.Size(355, 213)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Credit Notes"
        '
        'celdaLiquidarActual3
        '
        Me.celdaLiquidarActual3.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarActual3.Location = New System.Drawing.Point(197, 185)
        Me.celdaLiquidarActual3.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarActual3.Name = "celdaLiquidarActual3"
        Me.celdaLiquidarActual3.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarActual3.TabIndex = 7
        Me.celdaLiquidarActual3.Text = "0.00"
        Me.celdaLiquidarActual3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label7.Location = New System.Drawing.Point(153, 192)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Total"
        '
        'checkActualCreditNotes
        '
        Me.checkActualCreditNotes.AutoSize = True
        Me.checkActualCreditNotes.Location = New System.Drawing.Point(8, 187)
        Me.checkActualCreditNotes.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActualCreditNotes.Name = "checkActualCreditNotes"
        Me.checkActualCreditNotes.Size = New System.Drawing.Size(45, 21)
        Me.checkActualCreditNotes.TabIndex = 5
        Me.checkActualCreditNotes.Text = "All"
        Me.checkActualCreditNotes.UseVisualStyleBackColor = True
        '
        'dgActNotCredit
        '
        Me.dgActNotCredit.AllowUserToAddRows = False
        Me.dgActNotCredit.AllowUserToDeleteRows = False
        Me.dgActNotCredit.AllowUserToResizeRows = False
        Me.dgActNotCredit.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgActNotCredit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgActNotCredit.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column11, Me.colActNumber3, Me.DataGridViewTextBoxColumn26, Me.DataGridViewTextBoxColumn27, Me.colActNum3, Me.colActAnio3})
        Me.dgActNotCredit.Location = New System.Drawing.Point(8, 21)
        Me.dgActNotCredit.Margin = New System.Windows.Forms.Padding(4)
        Me.dgActNotCredit.Name = "dgActNotCredit"
        Me.dgActNotCredit.ReadOnly = True
        Me.dgActNotCredit.RowHeadersVisible = False
        Me.dgActNotCredit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgActNotCredit.Size = New System.Drawing.Size(339, 160)
        Me.dgActNotCredit.TabIndex = 4
        '
        'Column11
        '
        Me.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column11.HeaderText = ""
        Me.Column11.MinimumWidth = 4
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        Me.Column11.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column11.Width = 23
        '
        'colActNumber3
        '
        Me.colActNumber3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActNumber3.HeaderText = "Number"
        Me.colActNumber3.Name = "colActNumber3"
        Me.colActNumber3.ReadOnly = True
        Me.colActNumber3.Width = 87
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn26.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.ReadOnly = True
        Me.DataGridViewTextBoxColumn26.Width = 67
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn27.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        Me.DataGridViewTextBoxColumn27.ReadOnly = True
        Me.DataGridViewTextBoxColumn27.Width = 76
        '
        'colActNum3
        '
        Me.colActNum3.HeaderText = "Num"
        Me.colActNum3.Name = "colActNum3"
        Me.colActNum3.ReadOnly = True
        Me.colActNum3.Visible = False
        '
        'colActAnio3
        '
        Me.colActAnio3.HeaderText = "Anio"
        Me.colActAnio3.Name = "colActAnio3"
        Me.colActAnio3.ReadOnly = True
        Me.colActAnio3.Visible = False
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.celdaLiquidarActual)
        Me.GroupBox7.Controls.Add(Me.Label8)
        Me.GroupBox7.Controls.Add(Me.checkActualCheques)
        Me.GroupBox7.Controls.Add(Me.dgActCheques)
        Me.GroupBox7.Location = New System.Drawing.Point(12, 23)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox7.Size = New System.Drawing.Size(343, 214)
        Me.GroupBox7.TabIndex = 5
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Checks"
        '
        'celdaLiquidarActual
        '
        Me.celdaLiquidarActual.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarActual.Location = New System.Drawing.Point(200, 185)
        Me.celdaLiquidarActual.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarActual.Name = "celdaLiquidarActual"
        Me.celdaLiquidarActual.ReadOnly = True
        Me.celdaLiquidarActual.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarActual.TabIndex = 3
        Me.celdaLiquidarActual.Text = "0.00"
        Me.celdaLiquidarActual.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label8.Location = New System.Drawing.Point(151, 193)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(40, 17)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Total"
        '
        'checkActualCheques
        '
        Me.checkActualCheques.AutoSize = True
        Me.checkActualCheques.Location = New System.Drawing.Point(11, 188)
        Me.checkActualCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActualCheques.Name = "checkActualCheques"
        Me.checkActualCheques.Size = New System.Drawing.Size(45, 21)
        Me.checkActualCheques.TabIndex = 1
        Me.checkActualCheques.Text = "All"
        Me.checkActualCheques.UseVisualStyleBackColor = True
        '
        'dgActCheques
        '
        Me.dgActCheques.AllowUserToAddRows = False
        Me.dgActCheques.AllowUserToDeleteRows = False
        Me.dgActCheques.AllowUserToResizeRows = False
        Me.dgActCheques.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgActCheques.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgActCheques.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column9, Me.colActNumber, Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30, Me.colActNum, Me.colActAnio})
        Me.dgActCheques.Location = New System.Drawing.Point(8, 21)
        Me.dgActCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.dgActCheques.Name = "dgActCheques"
        Me.dgActCheques.ReadOnly = True
        Me.dgActCheques.RowHeadersVisible = False
        Me.dgActCheques.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgActCheques.Size = New System.Drawing.Size(327, 160)
        Me.dgActCheques.TabIndex = 0
        '
        'Column9
        '
        Me.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column9.HeaderText = ""
        Me.Column9.MinimumWidth = 4
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        Me.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column9.Width = 23
        '
        'colActNumber
        '
        Me.colActNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActNumber.HeaderText = "Number"
        Me.colActNumber.Name = "colActNumber"
        Me.colActNumber.ReadOnly = True
        Me.colActNumber.Width = 87
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn29.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        Me.DataGridViewTextBoxColumn29.ReadOnly = True
        Me.DataGridViewTextBoxColumn29.Width = 67
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn30.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        Me.DataGridViewTextBoxColumn30.ReadOnly = True
        Me.DataGridViewTextBoxColumn30.Width = 76
        '
        'colActNum
        '
        Me.colActNum.HeaderText = "Num"
        Me.colActNum.Name = "colActNum"
        Me.colActNum.ReadOnly = True
        Me.colActNum.Visible = False
        '
        'colActAnio
        '
        Me.colActAnio.HeaderText = "Anio"
        Me.colActAnio.Name = "colActAnio"
        Me.colActAnio.ReadOnly = True
        Me.colActAnio.Visible = False
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.celdaLiquidarActual2)
        Me.GroupBox8.Controls.Add(Me.Label9)
        Me.GroupBox8.Controls.Add(Me.checkActualDepositos)
        Me.GroupBox8.Controls.Add(Me.dgActDepositos)
        Me.GroupBox8.Location = New System.Drawing.Point(363, 23)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox8.Size = New System.Drawing.Size(353, 214)
        Me.GroupBox8.TabIndex = 8
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Deposits"
        '
        'celdaLiquidarActual2
        '
        Me.celdaLiquidarActual2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarActual2.Location = New System.Drawing.Point(200, 186)
        Me.celdaLiquidarActual2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarActual2.Name = "celdaLiquidarActual2"
        Me.celdaLiquidarActual2.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarActual2.TabIndex = 7
        Me.celdaLiquidarActual2.Text = "0.00"
        Me.celdaLiquidarActual2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label9.Location = New System.Drawing.Point(151, 193)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 17)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Total"
        '
        'checkActualDepositos
        '
        Me.checkActualDepositos.AutoSize = True
        Me.checkActualDepositos.Location = New System.Drawing.Point(8, 192)
        Me.checkActualDepositos.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActualDepositos.Name = "checkActualDepositos"
        Me.checkActualDepositos.Size = New System.Drawing.Size(45, 21)
        Me.checkActualDepositos.TabIndex = 5
        Me.checkActualDepositos.Text = "All"
        Me.checkActualDepositos.UseVisualStyleBackColor = True
        '
        'dgActDepositos
        '
        Me.dgActDepositos.AllowUserToAddRows = False
        Me.dgActDepositos.AllowUserToDeleteRows = False
        Me.dgActDepositos.AllowUserToResizeRows = False
        Me.dgActDepositos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgActDepositos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgActDepositos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column10, Me.colActNumber2, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.colActNum2, Me.colActAnio2})
        Me.dgActDepositos.Location = New System.Drawing.Point(8, 21)
        Me.dgActDepositos.Margin = New System.Windows.Forms.Padding(4)
        Me.dgActDepositos.Name = "dgActDepositos"
        Me.dgActDepositos.ReadOnly = True
        Me.dgActDepositos.RowHeadersVisible = False
        Me.dgActDepositos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgActDepositos.Size = New System.Drawing.Size(337, 161)
        Me.dgActDepositos.TabIndex = 4
        '
        'Column10
        '
        Me.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column10.HeaderText = ""
        Me.Column10.MinimumWidth = 4
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        Me.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column10.Width = 23
        '
        'colActNumber2
        '
        Me.colActNumber2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colActNumber2.HeaderText = "Number"
        Me.colActNumber2.Name = "colActNumber2"
        Me.colActNumber2.ReadOnly = True
        Me.colActNumber2.Width = 87
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn32.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        Me.DataGridViewTextBoxColumn32.ReadOnly = True
        Me.DataGridViewTextBoxColumn32.Width = 67
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn33.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        Me.DataGridViewTextBoxColumn33.ReadOnly = True
        Me.DataGridViewTextBoxColumn33.Width = 76
        '
        'colActNum2
        '
        Me.colActNum2.HeaderText = "Num"
        Me.colActNum2.Name = "colActNum2"
        Me.colActNum2.ReadOnly = True
        Me.colActNum2.Visible = False
        '
        'colActAnio2
        '
        Me.colActAnio2.HeaderText = "Anio"
        Me.colActAnio2.Name = "colActAnio2"
        Me.colActAnio2.ReadOnly = True
        Me.colActAnio2.Visible = False
        '
        'etiquetaMesSiguiente
        '
        Me.etiquetaMesSiguiente.AutoSize = True
        Me.etiquetaMesSiguiente.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaMesSiguiente.Location = New System.Drawing.Point(19, 4)
        Me.etiquetaMesSiguiente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMesSiguiente.Name = "etiquetaMesSiguiente"
        Me.etiquetaMesSiguiente.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaMesSiguiente.TabIndex = 4
        Me.etiquetaMesSiguiente.Text = "Enero/2016"
        '
        'panelMesAnterior
        '
        Me.panelMesAnterior.Controls.Add(Me.GroupBox1)
        Me.panelMesAnterior.Controls.Add(Me.GroupBox2)
        Me.panelMesAnterior.Controls.Add(Me.GroupBox3)
        Me.panelMesAnterior.Controls.Add(Me.GroupBox4)
        Me.panelMesAnterior.Controls.Add(Me.etiquetaMesesPendientes)
        Me.panelMesAnterior.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelMesAnterior.Location = New System.Drawing.Point(0, 0)
        Me.panelMesAnterior.Margin = New System.Windows.Forms.Padding(4)
        Me.panelMesAnterior.Name = "panelMesAnterior"
        Me.panelMesAnterior.Size = New System.Drawing.Size(1438, 274)
        Me.panelMesAnterior.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaLiquidarPendientes4)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.checkPenDebitNotes)
        Me.GroupBox1.Controls.Add(Me.dgPenNotasDebit)
        Me.GroupBox1.Location = New System.Drawing.Point(1084, 27)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(359, 222)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Debit Notes"
        '
        'celdaLiquidarPendientes4
        '
        Me.celdaLiquidarPendientes4.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarPendientes4.Location = New System.Drawing.Point(200, 194)
        Me.celdaLiquidarPendientes4.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarPendientes4.Name = "celdaLiquidarPendientes4"
        Me.celdaLiquidarPendientes4.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarPendientes4.TabIndex = 7
        Me.celdaLiquidarPendientes4.Text = "0.00"
        Me.celdaLiquidarPendientes4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label1.Location = New System.Drawing.Point(156, 199)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 17)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Total"
        '
        'checkPenDebitNotes
        '
        Me.checkPenDebitNotes.AutoSize = True
        Me.checkPenDebitNotes.Location = New System.Drawing.Point(8, 194)
        Me.checkPenDebitNotes.Margin = New System.Windows.Forms.Padding(4)
        Me.checkPenDebitNotes.Name = "checkPenDebitNotes"
        Me.checkPenDebitNotes.Size = New System.Drawing.Size(45, 21)
        Me.checkPenDebitNotes.TabIndex = 5
        Me.checkPenDebitNotes.Text = "All"
        Me.checkPenDebitNotes.UseVisualStyleBackColor = True
        '
        'dgPenNotasDebit
        '
        Me.dgPenNotasDebit.AllowUserToAddRows = False
        Me.dgPenNotasDebit.AllowUserToDeleteRows = False
        Me.dgPenNotasDebit.AllowUserToResizeRows = False
        Me.dgPenNotasDebit.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPenNotasDebit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPenNotasDebit.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column8, Me.colNumber4, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.colNum4, Me.colAnio4})
        Me.dgPenNotasDebit.Location = New System.Drawing.Point(8, 25)
        Me.dgPenNotasDebit.Margin = New System.Windows.Forms.Padding(4)
        Me.dgPenNotasDebit.Name = "dgPenNotasDebit"
        Me.dgPenNotasDebit.ReadOnly = True
        Me.dgPenNotasDebit.RowHeadersVisible = False
        Me.dgPenNotasDebit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPenNotasDebit.Size = New System.Drawing.Size(343, 162)
        Me.dgPenNotasDebit.TabIndex = 4
        '
        'Column8
        '
        Me.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column8.HeaderText = ""
        Me.Column8.MinimumWidth = 4
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        Me.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column8.Width = 23
        '
        'colNumber4
        '
        Me.colNumber4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber4.HeaderText = "Number"
        Me.colNumber4.Name = "colNumber4"
        Me.colNumber4.ReadOnly = True
        Me.colNumber4.Width = 87
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn11.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        Me.DataGridViewTextBoxColumn11.Width = 67
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn12.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Width = 76
        '
        'colNum4
        '
        Me.colNum4.HeaderText = "Numero4"
        Me.colNum4.Name = "colNum4"
        Me.colNum4.ReadOnly = True
        Me.colNum4.Visible = False
        '
        'colAnio4
        '
        Me.colAnio4.HeaderText = "Anio"
        Me.colAnio4.Name = "colAnio4"
        Me.colAnio4.ReadOnly = True
        Me.colAnio4.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.celdaLiquidarPendientes3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.checkPenCreditNotes)
        Me.GroupBox2.Controls.Add(Me.dgPenNotasCredito)
        Me.GroupBox2.Location = New System.Drawing.Point(724, 28)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(355, 222)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Credit Notes"
        '
        'celdaLiquidarPendientes3
        '
        Me.celdaLiquidarPendientes3.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarPendientes3.Location = New System.Drawing.Point(197, 191)
        Me.celdaLiquidarPendientes3.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarPendientes3.Name = "celdaLiquidarPendientes3"
        Me.celdaLiquidarPendientes3.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarPendientes3.TabIndex = 7
        Me.celdaLiquidarPendientes3.Text = "0.00"
        Me.celdaLiquidarPendientes3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label2.Location = New System.Drawing.Point(151, 198)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Total"
        '
        'checkPenCreditNotes
        '
        Me.checkPenCreditNotes.AutoSize = True
        Me.checkPenCreditNotes.Location = New System.Drawing.Point(8, 197)
        Me.checkPenCreditNotes.Margin = New System.Windows.Forms.Padding(4)
        Me.checkPenCreditNotes.Name = "checkPenCreditNotes"
        Me.checkPenCreditNotes.Size = New System.Drawing.Size(45, 21)
        Me.checkPenCreditNotes.TabIndex = 5
        Me.checkPenCreditNotes.Text = "All"
        Me.checkPenCreditNotes.UseVisualStyleBackColor = True
        '
        'dgPenNotasCredito
        '
        Me.dgPenNotasCredito.AllowUserToAddRows = False
        Me.dgPenNotasCredito.AllowUserToDeleteRows = False
        Me.dgPenNotasCredito.AllowUserToResizeRows = False
        Me.dgPenNotasCredito.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPenNotasCredito.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPenNotasCredito.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column7, Me.colNumber3, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.colNum3, Me.colAnio3})
        Me.dgPenNotasCredito.Location = New System.Drawing.Point(8, 23)
        Me.dgPenNotasCredito.Margin = New System.Windows.Forms.Padding(4)
        Me.dgPenNotasCredito.Name = "dgPenNotasCredito"
        Me.dgPenNotasCredito.ReadOnly = True
        Me.dgPenNotasCredito.RowHeadersVisible = False
        Me.dgPenNotasCredito.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPenNotasCredito.Size = New System.Drawing.Size(339, 162)
        Me.dgPenNotasCredito.TabIndex = 4
        '
        'Column7
        '
        Me.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column7.HeaderText = ""
        Me.Column7.MinimumWidth = 4
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        Me.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column7.Width = 23
        '
        'colNumber3
        '
        Me.colNumber3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber3.HeaderText = "Number"
        Me.colNumber3.Name = "colNumber3"
        Me.colNumber3.ReadOnly = True
        Me.colNumber3.Width = 87
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn14.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.ReadOnly = True
        Me.DataGridViewTextBoxColumn14.Width = 67
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn15.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Width = 76
        '
        'colNum3
        '
        Me.colNum3.HeaderText = "Number2"
        Me.colNum3.Name = "colNum3"
        Me.colNum3.ReadOnly = True
        Me.colNum3.Visible = False
        '
        'colAnio3
        '
        Me.colAnio3.HeaderText = "Anio"
        Me.colAnio3.Name = "colAnio3"
        Me.colAnio3.ReadOnly = True
        Me.colAnio3.Visible = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.celdaLiquidarPendientes)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.checkPenCheques)
        Me.GroupBox3.Controls.Add(Me.dgPenCheques)
        Me.GroupBox3.Location = New System.Drawing.Point(13, 28)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(341, 222)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Checks"
        '
        'celdaLiquidarPendientes
        '
        Me.celdaLiquidarPendientes.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarPendientes.Location = New System.Drawing.Point(199, 191)
        Me.celdaLiquidarPendientes.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarPendientes.Name = "celdaLiquidarPendientes"
        Me.celdaLiquidarPendientes.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarPendientes.TabIndex = 3
        Me.celdaLiquidarPendientes.Text = "0.00"
        Me.celdaLiquidarPendientes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label3.Location = New System.Drawing.Point(149, 198)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Total"
        '
        'checkPenCheques
        '
        Me.checkPenCheques.AutoSize = True
        Me.checkPenCheques.Location = New System.Drawing.Point(7, 193)
        Me.checkPenCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.checkPenCheques.Name = "checkPenCheques"
        Me.checkPenCheques.Size = New System.Drawing.Size(45, 21)
        Me.checkPenCheques.TabIndex = 1
        Me.checkPenCheques.Text = "All"
        Me.checkPenCheques.UseVisualStyleBackColor = True
        '
        'dgPenCheques
        '
        Me.dgPenCheques.AllowUserToAddRows = False
        Me.dgPenCheques.AllowUserToDeleteRows = False
        Me.dgPenCheques.AllowUserToResizeRows = False
        Me.dgPenCheques.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPenCheques.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPenCheques.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colSeleccionar, Me.colNumber, Me.DataGridViewTextBoxColumn17, Me.colMonto, Me.colNum, Me.colAnio})
        Me.dgPenCheques.Location = New System.Drawing.Point(8, 23)
        Me.dgPenCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.dgPenCheques.MultiSelect = False
        Me.dgPenCheques.Name = "dgPenCheques"
        Me.dgPenCheques.ReadOnly = True
        Me.dgPenCheques.RowHeadersVisible = False
        Me.dgPenCheques.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPenCheques.Size = New System.Drawing.Size(325, 162)
        Me.dgPenCheques.TabIndex = 0
        '
        'colSeleccionar
        '
        Me.colSeleccionar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSeleccionar.HeaderText = ""
        Me.colSeleccionar.MinimumWidth = 4
        Me.colSeleccionar.Name = "colSeleccionar"
        Me.colSeleccionar.ReadOnly = True
        Me.colSeleccionar.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colSeleccionar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colSeleccionar.Width = 23
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 87
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn17.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 67
        '
        'colMonto
        '
        Me.colMonto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMonto.HeaderText = "Monto"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        Me.colMonto.Width = 76
        '
        'colNum
        '
        Me.colNum.HeaderText = "Numero2"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.celdaLiquidarPendientes2)
        Me.GroupBox4.Controls.Add(Me.Label4)
        Me.GroupBox4.Controls.Add(Me.checkPenDeposito)
        Me.GroupBox4.Controls.Add(Me.dgPenDepositos)
        Me.GroupBox4.Location = New System.Drawing.Point(363, 28)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Size = New System.Drawing.Size(353, 222)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Deposits"
        '
        'celdaLiquidarPendientes2
        '
        Me.celdaLiquidarPendientes2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarPendientes2.Location = New System.Drawing.Point(200, 191)
        Me.celdaLiquidarPendientes2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarPendientes2.Name = "celdaLiquidarPendientes2"
        Me.celdaLiquidarPendientes2.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarPendientes2.TabIndex = 7
        Me.celdaLiquidarPendientes2.Text = "0.00"
        Me.celdaLiquidarPendientes2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label4.Location = New System.Drawing.Point(151, 198)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Total"
        '
        'checkPenDeposito
        '
        Me.checkPenDeposito.AutoSize = True
        Me.checkPenDeposito.Location = New System.Drawing.Point(8, 197)
        Me.checkPenDeposito.Margin = New System.Windows.Forms.Padding(4)
        Me.checkPenDeposito.Name = "checkPenDeposito"
        Me.checkPenDeposito.Size = New System.Drawing.Size(45, 21)
        Me.checkPenDeposito.TabIndex = 5
        Me.checkPenDeposito.Text = "All"
        Me.checkPenDeposito.UseVisualStyleBackColor = True
        '
        'dgPenDepositos
        '
        Me.dgPenDepositos.AllowUserToAddRows = False
        Me.dgPenDepositos.AllowUserToDeleteRows = False
        Me.dgPenDepositos.AllowUserToResizeRows = False
        Me.dgPenDepositos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPenDepositos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPenDepositos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.colNumber2, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.colNum2, Me.colAnio2})
        Me.dgPenDepositos.Location = New System.Drawing.Point(8, 23)
        Me.dgPenDepositos.Margin = New System.Windows.Forms.Padding(4)
        Me.dgPenDepositos.Name = "dgPenDepositos"
        Me.dgPenDepositos.ReadOnly = True
        Me.dgPenDepositos.RowHeadersVisible = False
        Me.dgPenDepositos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPenDepositos.Size = New System.Drawing.Size(337, 162)
        Me.dgPenDepositos.TabIndex = 4
        '
        'Column1
        '
        Me.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Column1.HeaderText = ""
        Me.Column1.MinimumWidth = 4
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Column1.Width = 23
        '
        'colNumber2
        '
        Me.colNumber2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber2.HeaderText = "Number"
        Me.colNumber2.Name = "colNumber2"
        Me.colNumber2.ReadOnly = True
        Me.colNumber2.Width = 87
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn20.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        Me.DataGridViewTextBoxColumn20.Width = 67
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn21.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.ReadOnly = True
        Me.DataGridViewTextBoxColumn21.Width = 76
        '
        'colNum2
        '
        Me.colNum2.HeaderText = "Numero2"
        Me.colNum2.Name = "colNum2"
        Me.colNum2.ReadOnly = True
        Me.colNum2.Visible = False
        '
        'colAnio2
        '
        Me.colAnio2.HeaderText = "Anio"
        Me.colAnio2.Name = "colAnio2"
        Me.colAnio2.ReadOnly = True
        Me.colAnio2.Visible = False
        '
        'etiquetaMesesPendientes
        '
        Me.etiquetaMesesPendientes.AutoSize = True
        Me.etiquetaMesesPendientes.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaMesesPendientes.Location = New System.Drawing.Point(16, 4)
        Me.etiquetaMesesPendientes.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMesesPendientes.Name = "etiquetaMesesPendientes"
        Me.etiquetaMesesPendientes.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaMesesPendientes.TabIndex = 3
        Me.etiquetaMesesPendientes.Text = "Enero/2016"
        '
        'panelMesActual
        '
        Me.panelMesActual.Controls.Add(Me.GroupBox9)
        Me.panelMesActual.Controls.Add(Me.GroupBox10)
        Me.panelMesActual.Controls.Add(Me.GroupBox11)
        Me.panelMesActual.Controls.Add(Me.GroupBox12)
        Me.panelMesActual.Controls.Add(Me.etiquetaMesActual)
        Me.panelMesActual.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelMesActual.Location = New System.Drawing.Point(0, 274)
        Me.panelMesActual.Margin = New System.Windows.Forms.Padding(4)
        Me.panelMesActual.Name = "panelMesActual"
        Me.panelMesActual.Size = New System.Drawing.Size(1438, 261)
        Me.panelMesActual.TabIndex = 4
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.celdaLiquidarDoc4)
        Me.GroupBox9.Controls.Add(Me.Label14)
        Me.GroupBox9.Controls.Add(Me.checkDocDebitNotes)
        Me.GroupBox9.Controls.Add(Me.dgDocNotDebit)
        Me.GroupBox9.Location = New System.Drawing.Point(1084, 27)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox9.Size = New System.Drawing.Size(359, 222)
        Me.GroupBox9.TabIndex = 5
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Debit Notes"
        '
        'celdaLiquidarDoc4
        '
        Me.celdaLiquidarDoc4.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarDoc4.Location = New System.Drawing.Point(200, 194)
        Me.celdaLiquidarDoc4.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarDoc4.Name = "celdaLiquidarDoc4"
        Me.celdaLiquidarDoc4.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarDoc4.TabIndex = 7
        Me.celdaLiquidarDoc4.Text = "0.00"
        Me.celdaLiquidarDoc4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label14.Location = New System.Drawing.Point(156, 199)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(40, 17)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Total"
        '
        'checkDocDebitNotes
        '
        Me.checkDocDebitNotes.AutoSize = True
        Me.checkDocDebitNotes.Location = New System.Drawing.Point(8, 194)
        Me.checkDocDebitNotes.Margin = New System.Windows.Forms.Padding(4)
        Me.checkDocDebitNotes.Name = "checkDocDebitNotes"
        Me.checkDocDebitNotes.Size = New System.Drawing.Size(45, 21)
        Me.checkDocDebitNotes.TabIndex = 5
        Me.checkDocDebitNotes.Text = "All"
        Me.checkDocDebitNotes.UseVisualStyleBackColor = True
        '
        'dgDocNotDebit
        '
        Me.dgDocNotDebit.AllowUserToAddRows = False
        Me.dgDocNotDebit.AllowUserToDeleteRows = False
        Me.dgDocNotDebit.AllowUserToResizeRows = False
        Me.dgDocNotDebit.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocNotDebit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocNotDebit.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewCheckBoxColumn1, Me.colDocNumber4, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.colDocNum4, Me.colDocAnio4})
        Me.dgDocNotDebit.Location = New System.Drawing.Point(8, 23)
        Me.dgDocNotDebit.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDocNotDebit.Name = "dgDocNotDebit"
        Me.dgDocNotDebit.ReadOnly = True
        Me.dgDocNotDebit.RowHeadersVisible = False
        Me.dgDocNotDebit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocNotDebit.Size = New System.Drawing.Size(343, 164)
        Me.dgDocNotDebit.TabIndex = 4
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewCheckBoxColumn1.HeaderText = ""
        Me.DataGridViewCheckBoxColumn1.MinimumWidth = 4
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.ReadOnly = True
        Me.DataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewCheckBoxColumn1.Width = 23
        '
        'colDocNumber4
        '
        Me.colDocNumber4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocNumber4.HeaderText = "Number"
        Me.colDocNumber4.Name = "colDocNumber4"
        Me.colDocNumber4.ReadOnly = True
        Me.colDocNumber4.Width = 87
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn2.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 67
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn3.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Width = 76
        '
        'colDocNum4
        '
        Me.colDocNum4.HeaderText = "Num"
        Me.colDocNum4.Name = "colDocNum4"
        Me.colDocNum4.ReadOnly = True
        Me.colDocNum4.Visible = False
        '
        'colDocAnio4
        '
        Me.colDocAnio4.HeaderText = "Anio"
        Me.colDocAnio4.Name = "colDocAnio4"
        Me.colDocAnio4.ReadOnly = True
        Me.colDocAnio4.Visible = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.celdaLiquidarDoc3)
        Me.GroupBox10.Controls.Add(Me.Label15)
        Me.GroupBox10.Controls.Add(Me.checkDocCrediNotes)
        Me.GroupBox10.Controls.Add(Me.dgDocNotasCredit)
        Me.GroupBox10.Location = New System.Drawing.Point(724, 28)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox10.Size = New System.Drawing.Size(355, 222)
        Me.GroupBox10.TabIndex = 6
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "Credit Notes"
        '
        'celdaLiquidarDoc3
        '
        Me.celdaLiquidarDoc3.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarDoc3.Location = New System.Drawing.Point(197, 191)
        Me.celdaLiquidarDoc3.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarDoc3.Name = "celdaLiquidarDoc3"
        Me.celdaLiquidarDoc3.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarDoc3.TabIndex = 7
        Me.celdaLiquidarDoc3.Text = "0.00"
        Me.celdaLiquidarDoc3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label15.Location = New System.Drawing.Point(151, 198)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(40, 17)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "Total"
        '
        'checkDocCrediNotes
        '
        Me.checkDocCrediNotes.AutoSize = True
        Me.checkDocCrediNotes.Location = New System.Drawing.Point(8, 197)
        Me.checkDocCrediNotes.Margin = New System.Windows.Forms.Padding(4)
        Me.checkDocCrediNotes.Name = "checkDocCrediNotes"
        Me.checkDocCrediNotes.Size = New System.Drawing.Size(45, 21)
        Me.checkDocCrediNotes.TabIndex = 5
        Me.checkDocCrediNotes.Text = "All"
        Me.checkDocCrediNotes.UseVisualStyleBackColor = True
        '
        'dgDocNotasCredit
        '
        Me.dgDocNotasCredit.AllowUserToAddRows = False
        Me.dgDocNotasCredit.AllowUserToDeleteRows = False
        Me.dgDocNotasCredit.AllowUserToResizeRows = False
        Me.dgDocNotasCredit.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocNotasCredit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocNotasCredit.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewCheckBoxColumn2, Me.colDocNumber3, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.colDocNum3, Me.colDocAnio3})
        Me.dgDocNotasCredit.Location = New System.Drawing.Point(8, 23)
        Me.dgDocNotasCredit.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDocNotasCredit.Name = "dgDocNotasCredit"
        Me.dgDocNotasCredit.ReadOnly = True
        Me.dgDocNotasCredit.RowHeadersVisible = False
        Me.dgDocNotasCredit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocNotasCredit.Size = New System.Drawing.Size(339, 162)
        Me.dgDocNotasCredit.TabIndex = 4
        '
        'DataGridViewCheckBoxColumn2
        '
        Me.DataGridViewCheckBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewCheckBoxColumn2.HeaderText = ""
        Me.DataGridViewCheckBoxColumn2.MinimumWidth = 4
        Me.DataGridViewCheckBoxColumn2.Name = "DataGridViewCheckBoxColumn2"
        Me.DataGridViewCheckBoxColumn2.ReadOnly = True
        Me.DataGridViewCheckBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCheckBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewCheckBoxColumn2.Width = 23
        '
        'colDocNumber3
        '
        Me.colDocNumber3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocNumber3.HeaderText = "Number"
        Me.colDocNumber3.Name = "colDocNumber3"
        Me.colDocNumber3.ReadOnly = True
        Me.colDocNumber3.Width = 87
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn5.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 67
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn6.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Width = 76
        '
        'colDocNum3
        '
        Me.colDocNum3.HeaderText = "Num"
        Me.colDocNum3.Name = "colDocNum3"
        Me.colDocNum3.ReadOnly = True
        Me.colDocNum3.Visible = False
        '
        'colDocAnio3
        '
        Me.colDocAnio3.HeaderText = "Anio"
        Me.colDocAnio3.Name = "colDocAnio3"
        Me.colDocAnio3.ReadOnly = True
        Me.colDocAnio3.Visible = False
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.celdaLiquidarDoc)
        Me.GroupBox11.Controls.Add(Me.Label16)
        Me.GroupBox11.Controls.Add(Me.checkDocCheques)
        Me.GroupBox11.Controls.Add(Me.dgDocCheques)
        Me.GroupBox11.Location = New System.Drawing.Point(13, 28)
        Me.GroupBox11.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox11.Size = New System.Drawing.Size(341, 222)
        Me.GroupBox11.TabIndex = 4
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Checks"
        '
        'celdaLiquidarDoc
        '
        Me.celdaLiquidarDoc.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarDoc.Location = New System.Drawing.Point(199, 191)
        Me.celdaLiquidarDoc.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarDoc.Name = "celdaLiquidarDoc"
        Me.celdaLiquidarDoc.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarDoc.TabIndex = 3
        Me.celdaLiquidarDoc.Text = "0.00"
        Me.celdaLiquidarDoc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label16.Location = New System.Drawing.Point(149, 198)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(40, 17)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Total"
        '
        'checkDocCheques
        '
        Me.checkDocCheques.AutoSize = True
        Me.checkDocCheques.Location = New System.Drawing.Point(7, 193)
        Me.checkDocCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.checkDocCheques.Name = "checkDocCheques"
        Me.checkDocCheques.Size = New System.Drawing.Size(45, 21)
        Me.checkDocCheques.TabIndex = 1
        Me.checkDocCheques.Text = "All"
        Me.checkDocCheques.UseVisualStyleBackColor = True
        '
        'dgDocCheques
        '
        Me.dgDocCheques.AllowUserToAddRows = False
        Me.dgDocCheques.AllowUserToDeleteRows = False
        Me.dgDocCheques.AllowUserToResizeRows = False
        Me.dgDocCheques.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocCheques.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocCheques.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewCheckBoxColumn3, Me.colDocNumber, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.colDocNum, Me.colDocAnio})
        Me.dgDocCheques.Location = New System.Drawing.Point(8, 23)
        Me.dgDocCheques.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDocCheques.Name = "dgDocCheques"
        Me.dgDocCheques.ReadOnly = True
        Me.dgDocCheques.RowHeadersVisible = False
        Me.dgDocCheques.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocCheques.Size = New System.Drawing.Size(325, 162)
        Me.dgDocCheques.TabIndex = 0
        '
        'DataGridViewCheckBoxColumn3
        '
        Me.DataGridViewCheckBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewCheckBoxColumn3.HeaderText = ""
        Me.DataGridViewCheckBoxColumn3.MinimumWidth = 4
        Me.DataGridViewCheckBoxColumn3.Name = "DataGridViewCheckBoxColumn3"
        Me.DataGridViewCheckBoxColumn3.ReadOnly = True
        Me.DataGridViewCheckBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCheckBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewCheckBoxColumn3.Width = 23
        '
        'colDocNumber
        '
        Me.colDocNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocNumber.HeaderText = "Number"
        Me.colDocNumber.Name = "colDocNumber"
        Me.colDocNumber.ReadOnly = True
        Me.colDocNumber.Width = 87
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn8.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 67
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn9.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Width = 76
        '
        'colDocNum
        '
        Me.colDocNum.HeaderText = "Num"
        Me.colDocNum.Name = "colDocNum"
        Me.colDocNum.ReadOnly = True
        Me.colDocNum.Visible = False
        '
        'colDocAnio
        '
        Me.colDocAnio.HeaderText = "Anio"
        Me.colDocAnio.Name = "colDocAnio"
        Me.colDocAnio.ReadOnly = True
        Me.colDocAnio.Visible = False
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.celdaLiquidarDoc2)
        Me.GroupBox12.Controls.Add(Me.Label17)
        Me.GroupBox12.Controls.Add(Me.checkDocDepositos)
        Me.GroupBox12.Controls.Add(Me.dgDocDepositos)
        Me.GroupBox12.Location = New System.Drawing.Point(363, 28)
        Me.GroupBox12.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox12.Size = New System.Drawing.Size(353, 222)
        Me.GroupBox12.TabIndex = 7
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Deposits"
        '
        'celdaLiquidarDoc2
        '
        Me.celdaLiquidarDoc2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLiquidarDoc2.Location = New System.Drawing.Point(200, 191)
        Me.celdaLiquidarDoc2.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaLiquidarDoc2.Name = "celdaLiquidarDoc2"
        Me.celdaLiquidarDoc2.Size = New System.Drawing.Size(103, 22)
        Me.celdaLiquidarDoc2.TabIndex = 7
        Me.celdaLiquidarDoc2.Text = "0.00"
        Me.celdaLiquidarDoc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Label17.Location = New System.Drawing.Point(151, 198)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(40, 17)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "Total"
        '
        'checkDocDepositos
        '
        Me.checkDocDepositos.AutoSize = True
        Me.checkDocDepositos.Location = New System.Drawing.Point(8, 197)
        Me.checkDocDepositos.Margin = New System.Windows.Forms.Padding(4)
        Me.checkDocDepositos.Name = "checkDocDepositos"
        Me.checkDocDepositos.Size = New System.Drawing.Size(45, 21)
        Me.checkDocDepositos.TabIndex = 5
        Me.checkDocDepositos.Text = "All"
        Me.checkDocDepositos.UseVisualStyleBackColor = True
        '
        'dgDocDepositos
        '
        Me.dgDocDepositos.AllowUserToAddRows = False
        Me.dgDocDepositos.AllowUserToDeleteRows = False
        Me.dgDocDepositos.AllowUserToResizeRows = False
        Me.dgDocDepositos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocDepositos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocDepositos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewCheckBoxColumn4, Me.colDocNumber2, Me.DataGridViewTextBoxColumn35, Me.DataGridViewTextBoxColumn36, Me.colDocNum2, Me.colDocAnio2})
        Me.dgDocDepositos.Location = New System.Drawing.Point(8, 23)
        Me.dgDocDepositos.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDocDepositos.Name = "dgDocDepositos"
        Me.dgDocDepositos.ReadOnly = True
        Me.dgDocDepositos.RowHeadersVisible = False
        Me.dgDocDepositos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocDepositos.Size = New System.Drawing.Size(337, 162)
        Me.dgDocDepositos.TabIndex = 4
        '
        'DataGridViewCheckBoxColumn4
        '
        Me.DataGridViewCheckBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewCheckBoxColumn4.HeaderText = ""
        Me.DataGridViewCheckBoxColumn4.MinimumWidth = 4
        Me.DataGridViewCheckBoxColumn4.Name = "DataGridViewCheckBoxColumn4"
        Me.DataGridViewCheckBoxColumn4.ReadOnly = True
        Me.DataGridViewCheckBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCheckBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewCheckBoxColumn4.Width = 23
        '
        'colDocNumber2
        '
        Me.colDocNumber2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocNumber2.HeaderText = "Number"
        Me.colDocNumber2.Name = "colDocNumber2"
        Me.colDocNumber2.ReadOnly = True
        Me.colDocNumber2.Width = 87
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn35.HeaderText = "Date"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.ReadOnly = True
        Me.DataGridViewTextBoxColumn35.Width = 67
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.DataGridViewTextBoxColumn36.HeaderText = "Monto"
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        Me.DataGridViewTextBoxColumn36.ReadOnly = True
        Me.DataGridViewTextBoxColumn36.Width = 76
        '
        'colDocNum2
        '
        Me.colDocNum2.HeaderText = "Num"
        Me.colDocNum2.Name = "colDocNum2"
        Me.colDocNum2.ReadOnly = True
        Me.colDocNum2.Visible = False
        '
        'colDocAnio2
        '
        Me.colDocAnio2.HeaderText = "Anio"
        Me.colDocAnio2.Name = "colDocAnio2"
        Me.colDocAnio2.ReadOnly = True
        Me.colDocAnio2.Visible = False
        '
        'etiquetaMesActual
        '
        Me.etiquetaMesActual.AutoSize = True
        Me.etiquetaMesActual.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaMesActual.Location = New System.Drawing.Point(16, 4)
        Me.etiquetaMesActual.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMesActual.Name = "etiquetaMesActual"
        Me.etiquetaMesActual.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaMesActual.TabIndex = 3
        Me.etiquetaMesActual.Text = "Enero/2016"
        '
        'frmConciliacionBancaria
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.ClientSize = New System.Drawing.Size(1459, 793)
        Me.Controls.Add(Me.panelResumen)
        Me.Controls.Add(Me.panelSigMes)
        Me.Controls.Add(Me.panelMesActual)
        Me.Controls.Add(Me.panelMesAnterior)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmConciliacionBancaria"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Conciliacion Bancaria"
        Me.panelResumen.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelResumen1.ResumeLayout(False)
        Me.panelResumen1.PerformLayout()
        Me.gbSaldoAnt.ResumeLayout(False)
        Me.gbSaldoAnt.PerformLayout()
        Me.panelSigMes.ResumeLayout(False)
        Me.panelSigMes.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.dgActNoteDebit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.dgActNotCredit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.dgActCheques, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.dgActDepositos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelMesAnterior.ResumeLayout(False)
        Me.panelMesAnterior.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.dgPenNotasDebit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dgPenNotasCredito, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.dgPenCheques, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.dgPenDepositos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelMesActual.ResumeLayout(False)
        Me.panelMesActual.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.dgDocNotDebit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.dgDocNotasCredit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.dgDocCheques, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        CType(Me.dgDocDepositos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelResumen As System.Windows.Forms.Panel
    Friend WithEvents panelSigMes As System.Windows.Forms.Panel
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarActual4 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents checkActualDebitNotes As System.Windows.Forms.CheckBox
    Friend WithEvents dgActNoteDebit As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarActual3 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents checkActualCreditNotes As System.Windows.Forms.CheckBox
    Friend WithEvents dgActNotCredit As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarActual As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents checkActualCheques As System.Windows.Forms.CheckBox
    Friend WithEvents dgActCheques As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarActual2 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents checkActualDepositos As System.Windows.Forms.CheckBox
    Friend WithEvents dgActDepositos As System.Windows.Forms.DataGridView
    Friend WithEvents etiquetaMesSiguiente As System.Windows.Forms.Label
    Friend WithEvents panelMesAnterior As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarPendientes4 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents checkPenDebitNotes As System.Windows.Forms.CheckBox
    Friend WithEvents dgPenNotasDebit As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarPendientes3 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents checkPenCreditNotes As System.Windows.Forms.CheckBox
    Friend WithEvents dgPenNotasCredito As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarPendientes As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents checkPenCheques As System.Windows.Forms.CheckBox
    Friend WithEvents dgPenCheques As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarPendientes2 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents checkPenDeposito As System.Windows.Forms.CheckBox
    Friend WithEvents dgPenDepositos As System.Windows.Forms.DataGridView
    Friend WithEvents etiquetaMesesPendientes As System.Windows.Forms.Label
    Friend WithEvents panelResumen1 As System.Windows.Forms.Panel
    Friend WithEvents celdaSubtotal4 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSubNCredit As System.Windows.Forms.Label
    Friend WithEvents etiquetaSubDepositos As System.Windows.Forms.Label
    Friend WithEvents etiquetaSubDebit As System.Windows.Forms.Label
    Friend WithEvents etiquetaSubCheques As System.Windows.Forms.Label
    Friend WithEvents etiquetaSInicialBank As System.Windows.Forms.Label
    Friend WithEvents celdaSubtotal1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaSubTotal3 As System.Windows.Forms.TextBox
    Friend WithEvents celdaSubtotal0 As System.Windows.Forms.TextBox
    Friend WithEvents celdaSaldoFinalConta As System.Windows.Forms.TextBox
    Friend WithEvents celdaSaldoFinalBank As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSFConta As System.Windows.Forms.Label
    Friend WithEvents etiquetaSFBank As System.Windows.Forms.Label
    Friend WithEvents etiquetaDatSaldo As System.Windows.Forms.Label
    Friend WithEvents etiquetaSaldo As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents etiquetaDatoDebit As System.Windows.Forms.Label
    Friend WithEvents etiquetaDebito As System.Windows.Forms.Label
    Friend WithEvents etiquetaDatoCred As System.Windows.Forms.Label
    Friend WithEvents etiquetaCredito As System.Windows.Forms.Label
    Friend WithEvents etiquetaResumen As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents etiquetSFBank As System.Windows.Forms.Label
    Friend WithEvents celdaSubtotal2 As System.Windows.Forms.TextBox
    Friend WithEvents botonConciliacion As System.Windows.Forms.Button
    Friend WithEvents botonCerrar As System.Windows.Forms.Button
    Friend WithEvents botonPoliza As System.Windows.Forms.Button
    Friend WithEvents botonEliminar As System.Windows.Forms.Button
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents botonGuardar As System.Windows.Forms.Button
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents celdaBuscar As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaBuscar As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaY As System.Windows.Forms.Label
    Friend WithEvents gbSaldoAnt As System.Windows.Forms.GroupBox
    Friend WithEvents celdaDiferencia As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDiferencia As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents celdaSInicialConta As System.Windows.Forms.TextBox
    Friend WithEvents celdaSInicialBanco As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents etiquetaSaldoIBank As System.Windows.Forms.Label
    Friend WithEvents botonAcFecha As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents panelMesActual As System.Windows.Forms.Panel
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarDoc4 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents checkDocDebitNotes As System.Windows.Forms.CheckBox
    Friend WithEvents dgDocNotDebit As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarDoc3 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents checkDocCrediNotes As System.Windows.Forms.CheckBox
    Friend WithEvents dgDocNotasCredit As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarDoc As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents checkDocCheques As System.Windows.Forms.CheckBox
    Friend WithEvents dgDocCheques As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaLiquidarDoc2 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents checkDocDepositos As System.Windows.Forms.CheckBox
    Friend WithEvents dgDocDepositos As System.Windows.Forms.DataGridView
    Friend WithEvents etiquetaMesActual As System.Windows.Forms.Label
    Friend WithEvents celdaIDConciliacion As System.Windows.Forms.TextBox
    Friend WithEvents colSeleccionar As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colNumber2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colNumber3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colNumber4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn3 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colDocNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colDocNumber4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocNum4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocAnio4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn2 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colDocNumber3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocNum3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocAnio3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn4 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colDocNumber2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocNum2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocAnio2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colActNumber4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActNum4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActAnio4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colActNumber3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActNum3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActAnio3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colActNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colActNumber2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActNum2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colActAnio2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents etiquetaMoneda3 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents panelTotales As Panel
End Class
