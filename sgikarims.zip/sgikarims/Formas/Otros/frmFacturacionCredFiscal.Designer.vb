﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFacturacionCredFiscal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmFacturacionCredFiscal))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelColores = New System.Windows.Forms.Panel()
        Me.CheckMuestraDetalle = New System.Windows.Forms.CheckBox()
        Me.celdaInfoDetalle = New System.Windows.Forms.TextBox()
        Me.celdaColorVerde = New System.Windows.Forms.TextBox()
        Me.colorAqua = New System.Windows.Forms.TextBox()
        Me.celdaColorNaranja = New System.Windows.Forms.TextBox()
        Me.celdaColorRosado = New System.Windows.Forms.TextBox()
        Me.celdaColorAmarillo = New System.Windows.Forms.TextBox()
        Me.celdaColorRojo = New System.Windows.Forms.TextBox()
        Me.etiquetaSinPoliza = New System.Windows.Forms.Label()
        Me.etiquetaNoCargado = New System.Windows.Forms.Label()
        Me.etiquetaNoImpreso = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.etiquetaSalidaPendiente = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSalida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpues = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBloqueado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabLista = New System.Windows.Forms.Panel()
        Me.botonPoliza = New System.Windows.Forms.Button()
        Me.botonLiberar = New System.Windows.Forms.Button()
        Me.botonSalida = New System.Windows.Forms.Button()
        Me.botonCarga = New System.Windows.Forms.Button()
        Me.botonConcolidacion = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaAnd = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelInfoFinal = New System.Windows.Forms.Panel()
        Me.celdaTotal1 = New System.Windows.Forms.TextBox()
        Me.celdaTotal2 = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.checkDetGatos = New System.Windows.Forms.CheckBox()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.dgDatos = New System.Windows.Forms.DataGridView()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colConcepto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAbono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDias = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelSubDocumentos = New System.Windows.Forms.Panel()
        Me.dgSubdocumentos = New System.Windows.Forms.DataGridView()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDescrip = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDespacho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescDolar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoBulto = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colBobina = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDistribucion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodLugar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLugDestino = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colLBS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKGS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOriginal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferences = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbInfoAdd = New System.Windows.Forms.GroupBox()
        Me.botonSeguro = New System.Windows.Forms.Button()
        Me.rbExportacion = New System.Windows.Forms.RadioButton()
        Me.rbNacionalizacion = New System.Windows.Forms.RadioButton()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.celdaFlete = New System.Windows.Forms.TextBox()
        Me.etiquetaSeguro = New System.Windows.Forms.Label()
        Me.etiquetaFlete = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaNotas = New System.Windows.Forms.TextBox()
        Me.panelListaDespachInstr = New System.Windows.Forms.Panel()
        Me.dgFacturacion = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñ = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFact = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFech = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperador = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbInvoiceInfo = New System.Windows.Forms.GroupBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaCargado = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.etiquetaAnulada = New System.Windows.Forms.Label()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaNit = New System.Windows.Forms.Label()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.dgReferencia = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPolicy = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisponible = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantDescargada = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colModificado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        Me.panelColores.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabLista.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelInfoFinal.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelSubDocumentos.SuspendLayout()
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbInfoAdd.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.panelListaDespachInstr.SuspendLayout()
        CType(Me.dgFacturacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbInvoiceInfo.SuspendLayout()
        CType(Me.dgReferencia, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.panelColores)
        Me.panelLista.Controls.Add(Me.Panel1)
        Me.panelLista.Controls.Add(Me.panelEncabLista)
        Me.panelLista.Location = New System.Drawing.Point(0, 110)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1024, 213)
        Me.panelLista.TabIndex = 3
        '
        'panelColores
        '
        Me.panelColores.BackColor = System.Drawing.SystemColors.Info
        Me.panelColores.Controls.Add(Me.CheckMuestraDetalle)
        Me.panelColores.Controls.Add(Me.celdaInfoDetalle)
        Me.panelColores.Controls.Add(Me.celdaColorVerde)
        Me.panelColores.Controls.Add(Me.colorAqua)
        Me.panelColores.Controls.Add(Me.celdaColorNaranja)
        Me.panelColores.Controls.Add(Me.celdaColorRosado)
        Me.panelColores.Controls.Add(Me.celdaColorAmarillo)
        Me.panelColores.Controls.Add(Me.celdaColorRojo)
        Me.panelColores.Controls.Add(Me.etiquetaSinPoliza)
        Me.panelColores.Controls.Add(Me.etiquetaNoCargado)
        Me.panelColores.Controls.Add(Me.etiquetaNoImpreso)
        Me.panelColores.Controls.Add(Me.Label1)
        Me.panelColores.Controls.Add(Me.Label2)
        Me.panelColores.Controls.Add(Me.etiquetaSalidaPendiente)
        Me.panelColores.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelColores.Location = New System.Drawing.Point(0, 98)
        Me.panelColores.Name = "panelColores"
        Me.panelColores.Size = New System.Drawing.Size(1024, 115)
        Me.panelColores.TabIndex = 2
        '
        'CheckMuestraDetalle
        '
        Me.CheckMuestraDetalle.AutoSize = True
        Me.CheckMuestraDetalle.CheckAlign = System.Drawing.ContentAlignment.TopRight
        Me.CheckMuestraDetalle.Location = New System.Drawing.Point(769, 17)
        Me.CheckMuestraDetalle.Name = "CheckMuestraDetalle"
        Me.CheckMuestraDetalle.Size = New System.Drawing.Size(83, 17)
        Me.CheckMuestraDetalle.TabIndex = 37
        Me.CheckMuestraDetalle.Text = "Show Detail"
        Me.CheckMuestraDetalle.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.CheckMuestraDetalle.UseVisualStyleBackColor = True
        '
        'celdaInfoDetalle
        '
        Me.celdaInfoDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaInfoDetalle.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfoDetalle.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaInfoDetalle.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaInfoDetalle.Location = New System.Drawing.Point(14, 4)
        Me.celdaInfoDetalle.Multiline = True
        Me.celdaInfoDetalle.Name = "celdaInfoDetalle"
        Me.celdaInfoDetalle.ReadOnly = True
        Me.celdaInfoDetalle.Size = New System.Drawing.Size(909, 84)
        Me.celdaInfoDetalle.TabIndex = 38
        '
        'celdaColorVerde
        '
        Me.celdaColorVerde.BackColor = System.Drawing.Color.Lime
        Me.celdaColorVerde.Location = New System.Drawing.Point(658, 89)
        Me.celdaColorVerde.Name = "celdaColorVerde"
        Me.celdaColorVerde.ReadOnly = True
        Me.celdaColorVerde.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorVerde.TabIndex = 29
        '
        'colorAqua
        '
        Me.colorAqua.BackColor = System.Drawing.Color.Cyan
        Me.colorAqua.Location = New System.Drawing.Point(535, 89)
        Me.colorAqua.Name = "colorAqua"
        Me.colorAqua.ReadOnly = True
        Me.colorAqua.Size = New System.Drawing.Size(19, 20)
        Me.colorAqua.TabIndex = 28
        '
        'celdaColorNaranja
        '
        Me.celdaColorNaranja.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.celdaColorNaranja.Location = New System.Drawing.Point(398, 89)
        Me.celdaColorNaranja.Name = "celdaColorNaranja"
        Me.celdaColorNaranja.ReadOnly = True
        Me.celdaColorNaranja.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorNaranja.TabIndex = 27
        '
        'celdaColorRosado
        '
        Me.celdaColorRosado.BackColor = System.Drawing.Color.Magenta
        Me.celdaColorRosado.Location = New System.Drawing.Point(273, 89)
        Me.celdaColorRosado.Name = "celdaColorRosado"
        Me.celdaColorRosado.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorRosado.TabIndex = 26
        '
        'celdaColorAmarillo
        '
        Me.celdaColorAmarillo.BackColor = System.Drawing.Color.Yellow
        Me.celdaColorAmarillo.Location = New System.Drawing.Point(160, 89)
        Me.celdaColorAmarillo.Name = "celdaColorAmarillo"
        Me.celdaColorAmarillo.ReadOnly = True
        Me.celdaColorAmarillo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorAmarillo.TabIndex = 30
        '
        'celdaColorRojo
        '
        Me.celdaColorRojo.BackColor = System.Drawing.Color.Red
        Me.celdaColorRojo.Location = New System.Drawing.Point(24, 89)
        Me.celdaColorRojo.Name = "celdaColorRojo"
        Me.celdaColorRojo.ReadOnly = True
        Me.celdaColorRojo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorRojo.TabIndex = 25
        '
        'etiquetaSinPoliza
        '
        Me.etiquetaSinPoliza.AutoSize = True
        Me.etiquetaSinPoliza.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaSinPoliza.Location = New System.Drawing.Point(681, 92)
        Me.etiquetaSinPoliza.Name = "etiquetaSinPoliza"
        Me.etiquetaSinPoliza.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaSinPoliza.TabIndex = 36
        Me.etiquetaSinPoliza.Text = "No Policy"
        '
        'etiquetaNoCargado
        '
        Me.etiquetaNoCargado.AutoSize = True
        Me.etiquetaNoCargado.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaNoCargado.Location = New System.Drawing.Point(560, 92)
        Me.etiquetaNoCargado.Name = "etiquetaNoCargado"
        Me.etiquetaNoCargado.Size = New System.Drawing.Size(60, 13)
        Me.etiquetaNoCargado.TabIndex = 35
        Me.etiquetaNoCargado.Text = "Uncharged"
        '
        'etiquetaNoImpreso
        '
        Me.etiquetaNoImpreso.AutoSize = True
        Me.etiquetaNoImpreso.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaNoImpreso.Location = New System.Drawing.Point(182, 92)
        Me.etiquetaNoImpreso.Name = "etiquetaNoImpreso"
        Me.etiquetaNoImpreso.Size = New System.Drawing.Size(53, 13)
        Me.etiquetaNoImpreso.TabIndex = 32
        Me.etiquetaNoImpreso.Text = "Unprinted"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.Info
        Me.Label1.Location = New System.Drawing.Point(49, 92)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 31
        Me.Label1.Text = "-ANNULLED-"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.SystemColors.Info
        Me.Label2.Location = New System.Drawing.Point(298, 92)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Uncertificated"
        '
        'etiquetaSalidaPendiente
        '
        Me.etiquetaSalidaPendiente.AutoSize = True
        Me.etiquetaSalidaPendiente.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaSalidaPendiente.Location = New System.Drawing.Point(423, 92)
        Me.etiquetaSalidaPendiente.Name = "etiquetaSalidaPendiente"
        Me.etiquetaSalidaPendiente.Size = New System.Drawing.Size(54, 13)
        Me.etiquetaSalidaPendiente.TabIndex = 34
        Me.etiquetaSalidaPendiente.Text = "Slope Out"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.dgLista)
        Me.Panel1.Location = New System.Drawing.Point(0, 50)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1024, 42)
        Me.Panel1.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colYear, Me.colNumero, Me.colFecha, Me.colCliente, Me.colReferencia, Me.colImpreso, Me.colStatus, Me.colSalida, Me.colImpues, Me.colBloqueado, Me.colCargado, Me.colPoliza, Me.colDireccion, Me.colNit})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1024, 42)
        Me.dgLista.TabIndex = 3
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        Me.colYear.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 58
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colImpreso
        '
        Me.colImpreso.HeaderText = "Impreso"
        Me.colImpreso.Name = "colImpreso"
        Me.colImpreso.ReadOnly = True
        Me.colImpreso.Visible = False
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Visible = False
        '
        'colSalida
        '
        Me.colSalida.HeaderText = "Salida"
        Me.colSalida.Name = "colSalida"
        Me.colSalida.ReadOnly = True
        Me.colSalida.Visible = False
        '
        'colImpues
        '
        Me.colImpues.HeaderText = "Impuesto"
        Me.colImpues.Name = "colImpues"
        Me.colImpues.ReadOnly = True
        Me.colImpues.Visible = False
        '
        'colBloqueado
        '
        Me.colBloqueado.HeaderText = "bloqueado"
        Me.colBloqueado.Name = "colBloqueado"
        Me.colBloqueado.ReadOnly = True
        Me.colBloqueado.Visible = False
        '
        'colCargado
        '
        Me.colCargado.HeaderText = "Cargado"
        Me.colCargado.Name = "colCargado"
        Me.colCargado.ReadOnly = True
        Me.colCargado.Visible = False
        '
        'colPoliza
        '
        Me.colPoliza.HeaderText = "Poliza"
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        Me.colPoliza.Visible = False
        '
        'colDireccion
        '
        Me.colDireccion.HeaderText = "Direction"
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.ReadOnly = True
        Me.colDireccion.Visible = False
        '
        'colNit
        '
        Me.colNit.HeaderText = "Nit"
        Me.colNit.Name = "colNit"
        Me.colNit.ReadOnly = True
        Me.colNit.Visible = False
        '
        'panelEncabLista
        '
        Me.panelEncabLista.Controls.Add(Me.botonPoliza)
        Me.panelEncabLista.Controls.Add(Me.botonLiberar)
        Me.panelEncabLista.Controls.Add(Me.botonSalida)
        Me.panelEncabLista.Controls.Add(Me.botonCarga)
        Me.panelEncabLista.Controls.Add(Me.botonConcolidacion)
        Me.panelEncabLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabLista.Controls.Add(Me.etiquetaAnd)
        Me.panelEncabLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabLista.Controls.Add(Me.dtpInicio)
        Me.panelEncabLista.Controls.Add(Me.checkFecha)
        Me.panelEncabLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabLista.Name = "panelEncabLista"
        Me.panelEncabLista.Size = New System.Drawing.Size(1024, 53)
        Me.panelEncabLista.TabIndex = 0
        '
        'botonPoliza
        '
        Me.botonPoliza.Image = CType(resources.GetObject("botonPoliza.Image"), System.Drawing.Image)
        Me.botonPoliza.Location = New System.Drawing.Point(718, 15)
        Me.botonPoliza.Name = "botonPoliza"
        Me.botonPoliza.Size = New System.Drawing.Size(29, 23)
        Me.botonPoliza.TabIndex = 9
        Me.botonPoliza.UseVisualStyleBackColor = True
        '
        'botonLiberar
        '
        Me.botonLiberar.Image = Global.KARIMs_SGI.My.Resources.Resources.lock_open
        Me.botonLiberar.Location = New System.Drawing.Point(753, 15)
        Me.botonLiberar.Name = "botonLiberar"
        Me.botonLiberar.Size = New System.Drawing.Size(29, 23)
        Me.botonLiberar.TabIndex = 8
        Me.botonLiberar.UseVisualStyleBackColor = True
        '
        'botonSalida
        '
        Me.botonSalida.Image = CType(resources.GetObject("botonSalida.Image"), System.Drawing.Image)
        Me.botonSalida.Location = New System.Drawing.Point(788, 14)
        Me.botonSalida.Name = "botonSalida"
        Me.botonSalida.Size = New System.Drawing.Size(29, 23)
        Me.botonSalida.TabIndex = 7
        Me.botonSalida.UseVisualStyleBackColor = True
        '
        'botonCarga
        '
        Me.botonCarga.BackColor = System.Drawing.SystemColors.Control
        Me.botonCarga.Image = CType(resources.GetObject("botonCarga.Image"), System.Drawing.Image)
        Me.botonCarga.Location = New System.Drawing.Point(683, 15)
        Me.botonCarga.Name = "botonCarga"
        Me.botonCarga.Size = New System.Drawing.Size(29, 23)
        Me.botonCarga.TabIndex = 6
        Me.botonCarga.UseVisualStyleBackColor = False
        '
        'botonConcolidacion
        '
        Me.botonConcolidacion.Location = New System.Drawing.Point(598, 15)
        Me.botonConcolidacion.Name = "botonConcolidacion"
        Me.botonConcolidacion.Size = New System.Drawing.Size(79, 23)
        Me.botonConcolidacion.TabIndex = 5
        Me.botonConcolidacion.Text = "Consolidation"
        Me.botonConcolidacion.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(465, 15)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaAnd
        '
        Me.etiquetaAnd.AutoSize = True
        Me.etiquetaAnd.Location = New System.Drawing.Point(307, 20)
        Me.etiquetaAnd.Name = "etiquetaAnd"
        Me.etiquetaAnd.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaAnd.TabIndex = 3
        Me.etiquetaAnd.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(362, 14)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(97, 20)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(204, 14)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(97, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(18, 19)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(76, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "ShowDate"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelInfoFinal)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.gbInfoAdd)
        Me.panelDocumento.Controls.Add(Me.GroupBox1)
        Me.panelDocumento.Controls.Add(Me.gbInvoiceInfo)
        Me.panelDocumento.Location = New System.Drawing.Point(0, 329)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(861, 532)
        Me.panelDocumento.TabIndex = 4
        '
        'panelInfoFinal
        '
        Me.panelInfoFinal.Controls.Add(Me.celdaTotal1)
        Me.panelInfoFinal.Controls.Add(Me.celdaTotal2)
        Me.panelInfoFinal.Controls.Add(Me.etiquetaTotales)
        Me.panelInfoFinal.Controls.Add(Me.checkDetGatos)
        Me.panelInfoFinal.Controls.Add(Me.panelDatos)
        Me.panelInfoFinal.Controls.Add(Me.panelSubDocumentos)
        Me.panelInfoFinal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInfoFinal.Location = New System.Drawing.Point(0, 389)
        Me.panelInfoFinal.Name = "panelInfoFinal"
        Me.panelInfoFinal.Size = New System.Drawing.Size(861, 143)
        Me.panelInfoFinal.TabIndex = 4
        '
        'celdaTotal1
        '
        Me.celdaTotal1.Location = New System.Drawing.Point(634, 12)
        Me.celdaTotal1.Name = "celdaTotal1"
        Me.celdaTotal1.Size = New System.Drawing.Size(92, 20)
        Me.celdaTotal1.TabIndex = 18
        Me.celdaTotal1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotal2
        '
        Me.celdaTotal2.Location = New System.Drawing.Point(730, 11)
        Me.celdaTotal2.Name = "celdaTotal2"
        Me.celdaTotal2.Size = New System.Drawing.Size(90, 20)
        Me.celdaTotal2.TabIndex = 17
        Me.celdaTotal2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(592, 15)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(36, 13)
        Me.etiquetaTotales.TabIndex = 3
        Me.etiquetaTotales.Text = "Totals"
        '
        'checkDetGatos
        '
        Me.checkDetGatos.AutoSize = True
        Me.checkDetGatos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkDetGatos.Location = New System.Drawing.Point(310, 13)
        Me.checkDetGatos.Name = "checkDetGatos"
        Me.checkDetGatos.Size = New System.Drawing.Size(168, 17)
        Me.checkDetGatos.TabIndex = 2
        Me.checkDetGatos.Text = "Print Details of Expenses"
        Me.checkDetGatos.UseVisualStyleBackColor = True
        Me.checkDetGatos.Visible = False
        '
        'panelDatos
        '
        Me.panelDatos.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDatos.Controls.Add(Me.dgDatos)
        Me.panelDatos.Location = New System.Drawing.Point(266, 37)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(575, 102)
        Me.panelDatos.TabIndex = 1
        '
        'dgDatos
        '
        Me.dgDatos.AllowUserToAddRows = False
        Me.dgDatos.AllowUserToDeleteRows = False
        Me.dgDatos.AllowUserToOrderColumns = True
        Me.dgDatos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDatos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNombre, Me.colConcepto, Me.colMonto, Me.colTC, Me.colCargo, Me.colAbono, Me.colDias})
        Me.dgDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDatos.Location = New System.Drawing.Point(0, 0)
        Me.dgDatos.Name = "dgDatos"
        Me.dgDatos.Size = New System.Drawing.Size(575, 102)
        Me.dgDatos.TabIndex = 0
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        '
        'colConcepto
        '
        Me.colConcepto.HeaderText = "Concept"
        Me.colConcepto.Name = "colConcepto"
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        '
        'colTC
        '
        Me.colTC.HeaderText = "T/C"
        Me.colTC.Name = "colTC"
        '
        'colCargo
        '
        Me.colCargo.HeaderText = "Charge"
        Me.colCargo.Name = "colCargo"
        '
        'colAbono
        '
        Me.colAbono.HeaderText = "Payment"
        Me.colAbono.Name = "colAbono"
        '
        'colDias
        '
        Me.colDias.HeaderText = "Days"
        Me.colDias.Name = "colDias"
        '
        'panelSubDocumentos
        '
        Me.panelSubDocumentos.Controls.Add(Me.dgSubdocumentos)
        Me.panelSubDocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelSubDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.panelSubDocumentos.Name = "panelSubDocumentos"
        Me.panelSubDocumentos.Size = New System.Drawing.Size(243, 143)
        Me.panelSubDocumentos.TabIndex = 0
        '
        'dgSubdocumentos
        '
        Me.dgSubdocumentos.AllowUserToAddRows = False
        Me.dgSubdocumentos.AllowUserToDeleteRows = False
        Me.dgSubdocumentos.AllowUserToOrderColumns = True
        Me.dgSubdocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgSubdocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSubdocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colDescripcion, Me.colDocumento, Me.colDatos})
        Me.dgSubdocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgSubdocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgSubdocumentos.Name = "dgSubdocumentos"
        Me.dgSubdocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgSubdocumentos.Size = New System.Drawing.Size(243, 143)
        Me.dgSubdocumentos.TabIndex = 0
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        '
        'colDatos
        '
        Me.colDatos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colDatos.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Location = New System.Drawing.Point(3, 272)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(840, 107)
        Me.panelDetalle.TabIndex = 3
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNum, Me.colCode, Me.colAño, Me.colLinea, Me.colLinea2, Me.ColDescrip, Me.colCodMedida, Me.colMedida, Me.colDespacho, Me.colPrecio, Me.colDesc, Me.colDescDolar, Me.colCantidad, Me.colTotal, Me.colBulto, Me.colTipoBulto, Me.colBobina, Me.colDistribucion, Me.colCodLugar, Me.colLugDestino, Me.colLBS, Me.colKGS, Me.colOriginal, Me.colReferences, Me.colBase})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(840, 107)
        Me.dgDetalle.TabIndex = 0
        '
        'colNum
        '
        Me.colNum.HeaderText = "Number"
        Me.colNum.Name = "colNum"
        Me.colNum.Visible = False
        '
        'colCode
        '
        Me.colCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCode.HeaderText = "Code*"
        Me.colCode.Name = "colCode"
        Me.colCode.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colCode.Width = 61
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.Visible = False
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        '
        'colLinea2
        '
        Me.colLinea2.HeaderText = "Line2"
        Me.colLinea2.Name = "colLinea2"
        Me.colLinea2.Visible = False
        '
        'ColDescrip
        '
        Me.ColDescrip.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ColDescrip.HeaderText = "Description"
        Me.ColDescrip.Name = "ColDescrip"
        Me.ColDescrip.Width = 85
        '
        'colCodMedida
        '
        Me.colCodMedida.HeaderText = "CodMedida"
        Me.colCodMedida.Name = "colCodMedida"
        Me.colCodMedida.Visible = False
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.Width = 73
        '
        'colDespacho
        '
        Me.colDespacho.HeaderText = "Dispatch"
        Me.colDespacho.Name = "colDespacho"
        Me.colDespacho.Visible = False
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colDesc
        '
        Me.colDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDesc.HeaderText = "Desc.%"
        Me.colDesc.Name = "colDesc"
        Me.colDesc.Width = 68
        '
        'colDescDolar
        '
        Me.colDescDolar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescDolar.HeaderText = "Desc.$"
        Me.colDescDolar.Name = "colDescDolar"
        Me.colDescDolar.Width = 66
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Quantity*"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colCantidad.Width = 75
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.Width = 56
        '
        'colBulto
        '
        Me.colBulto.HeaderText = "Package"
        Me.colBulto.Name = "colBulto"
        Me.colBulto.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'colTipoBulto
        '
        Me.colTipoBulto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTipoBulto.HeaderText = "Package Type"
        Me.colTipoBulto.Name = "colTipoBulto"
        Me.colTipoBulto.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colTipoBulto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colTipoBulto.Width = 94
        '
        'colBobina
        '
        Me.colBobina.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBobina.HeaderText = "Coils"
        Me.colBobina.Name = "colBobina"
        Me.colBobina.Width = 54
        '
        'colDistribucion
        '
        Me.colDistribucion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDistribucion.HeaderText = "Distribution"
        Me.colDistribucion.Name = "colDistribucion"
        Me.colDistribucion.Width = 84
        '
        'colCodLugar
        '
        Me.colCodLugar.HeaderText = "Instead Destination"
        Me.colCodLugar.Name = "colCodLugar"
        Me.colCodLugar.Visible = False
        '
        'colLugDestino
        '
        Me.colLugDestino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLugDestino.HeaderText = "Destination Place*"
        Me.colLugDestino.Name = "colLugDestino"
        Me.colLugDestino.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colLugDestino.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colLugDestino.Width = 109
        '
        'colLBS
        '
        Me.colLBS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLBS.HeaderText = "LBS"
        Me.colLBS.Name = "colLBS"
        Me.colLBS.Width = 52
        '
        'colKGS
        '
        Me.colKGS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKGS.HeaderText = "KGS"
        Me.colKGS.Name = "colKGS"
        Me.colKGS.Width = 54
        '
        'colOriginal
        '
        Me.colOriginal.HeaderText = "Original"
        Me.colOriginal.Name = "colOriginal"
        Me.colOriginal.Visible = False
        '
        'colReferences
        '
        Me.colReferences.HeaderText = "Referencia"
        Me.colReferences.Name = "colReferences"
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.Name = "colBase"
        Me.colBase.Visible = False
        '
        'gbInfoAdd
        '
        Me.gbInfoAdd.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbInfoAdd.Controls.Add(Me.botonSeguro)
        Me.gbInfoAdd.Controls.Add(Me.rbExportacion)
        Me.gbInfoAdd.Controls.Add(Me.rbNacionalizacion)
        Me.gbInfoAdd.Controls.Add(Me.celdaSeguro)
        Me.gbInfoAdd.Controls.Add(Me.celdaFlete)
        Me.gbInfoAdd.Controls.Add(Me.etiquetaSeguro)
        Me.gbInfoAdd.Controls.Add(Me.etiquetaFlete)
        Me.gbInfoAdd.Location = New System.Drawing.Point(397, 171)
        Me.gbInfoAdd.Name = "gbInfoAdd"
        Me.gbInfoAdd.Size = New System.Drawing.Size(446, 94)
        Me.gbInfoAdd.TabIndex = 2
        Me.gbInfoAdd.TabStop = False
        Me.gbInfoAdd.Text = "Addittional Information"
        '
        'botonSeguro
        '
        Me.botonSeguro.Location = New System.Drawing.Point(162, 61)
        Me.botonSeguro.Name = "botonSeguro"
        Me.botonSeguro.Size = New System.Drawing.Size(31, 23)
        Me.botonSeguro.TabIndex = 19
        Me.botonSeguro.Text = "%"
        Me.botonSeguro.UseVisualStyleBackColor = True
        '
        'rbExportacion
        '
        Me.rbExportacion.AutoSize = True
        Me.rbExportacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbExportacion.ForeColor = System.Drawing.Color.Green
        Me.rbExportacion.Location = New System.Drawing.Point(260, 64)
        Me.rbExportacion.Name = "rbExportacion"
        Me.rbExportacion.Size = New System.Drawing.Size(61, 17)
        Me.rbExportacion.TabIndex = 18
        Me.rbExportacion.TabStop = True
        Me.rbExportacion.Text = "Export"
        Me.rbExportacion.UseVisualStyleBackColor = True
        '
        'rbNacionalizacion
        '
        Me.rbNacionalizacion.AutoSize = True
        Me.rbNacionalizacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbNacionalizacion.ForeColor = System.Drawing.Color.Red
        Me.rbNacionalizacion.Location = New System.Drawing.Point(260, 33)
        Me.rbNacionalizacion.Name = "rbNacionalizacion"
        Me.rbNacionalizacion.Size = New System.Drawing.Size(109, 17)
        Me.rbNacionalizacion.TabIndex = 17
        Me.rbNacionalizacion.TabStop = True
        Me.rbNacionalizacion.Text = "Nationalization"
        Me.rbNacionalizacion.UseVisualStyleBackColor = True
        '
        'celdaSeguro
        '
        Me.celdaSeguro.Location = New System.Drawing.Point(90, 63)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.Size = New System.Drawing.Size(66, 20)
        Me.celdaSeguro.TabIndex = 16
        Me.celdaSeguro.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaFlete
        '
        Me.celdaFlete.Location = New System.Drawing.Point(90, 32)
        Me.celdaFlete.Name = "celdaFlete"
        Me.celdaFlete.Size = New System.Drawing.Size(103, 20)
        Me.celdaFlete.TabIndex = 15
        Me.celdaFlete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSeguro
        '
        Me.etiquetaSeguro.AutoSize = True
        Me.etiquetaSeguro.Location = New System.Drawing.Point(27, 66)
        Me.etiquetaSeguro.Name = "etiquetaSeguro"
        Me.etiquetaSeguro.Size = New System.Drawing.Size(54, 13)
        Me.etiquetaSeguro.TabIndex = 1
        Me.etiquetaSeguro.Text = "Insurance"
        '
        'etiquetaFlete
        '
        Me.etiquetaFlete.AutoSize = True
        Me.etiquetaFlete.Location = New System.Drawing.Point(27, 35)
        Me.etiquetaFlete.Name = "etiquetaFlete"
        Me.etiquetaFlete.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaFlete.TabIndex = 0
        Me.etiquetaFlete.Text = "Freight"
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.celdaNotas)
        Me.GroupBox1.Controls.Add(Me.panelListaDespachInstr)
        Me.GroupBox1.Location = New System.Drawing.Point(397, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(446, 164)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Invoice to Include Shipping"
        '
        'celdaNotas
        '
        Me.celdaNotas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNotas.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNotas.Location = New System.Drawing.Point(6, 127)
        Me.celdaNotas.Multiline = True
        Me.celdaNotas.Name = "celdaNotas"
        Me.celdaNotas.ReadOnly = True
        Me.celdaNotas.Size = New System.Drawing.Size(434, 31)
        Me.celdaNotas.TabIndex = 1
        '
        'panelListaDespachInstr
        '
        Me.panelListaDespachInstr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelListaDespachInstr.Controls.Add(Me.dgFacturacion)
        Me.panelListaDespachInstr.Location = New System.Drawing.Point(6, 21)
        Me.panelListaDespachInstr.Name = "panelListaDespachInstr"
        Me.panelListaDespachInstr.Size = New System.Drawing.Size(434, 100)
        Me.panelListaDespachInstr.TabIndex = 0
        '
        'dgFacturacion
        '
        Me.dgFacturacion.AllowUserToAddRows = False
        Me.dgFacturacion.AllowUserToDeleteRows = False
        Me.dgFacturacion.AllowUserToOrderColumns = True
        Me.dgFacturacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFacturacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFacturacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAñ, Me.colFact, Me.colFech, Me.colOperador, Me.DataGridViewTextBoxColumn2, Me.colMarca})
        Me.dgFacturacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgFacturacion.Location = New System.Drawing.Point(0, 0)
        Me.dgFacturacion.MultiSelect = False
        Me.dgFacturacion.Name = "dgFacturacion"
        Me.dgFacturacion.ReadOnly = True
        Me.dgFacturacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFacturacion.Size = New System.Drawing.Size(434, 100)
        Me.dgFacturacion.TabIndex = 0
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Cat"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAñ
        '
        Me.colAñ.HeaderText = "Year"
        Me.colAñ.Name = "colAñ"
        Me.colAñ.ReadOnly = True
        Me.colAñ.Visible = False
        '
        'colFact
        '
        Me.colFact.HeaderText = "Fact"
        Me.colFact.Name = "colFact"
        Me.colFact.ReadOnly = True
        '
        'colFech
        '
        Me.colFech.HeaderText = "Date"
        Me.colFech.Name = "colFech"
        Me.colFech.ReadOnly = True
        '
        'colOperador
        '
        Me.colOperador.HeaderText = "Operator"
        Me.colOperador.Name = "colOperador"
        Me.colOperador.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Reference"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Marca"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Visible = False
        '
        'gbInvoiceInfo
        '
        Me.gbInvoiceInfo.Controls.Add(Me.dtpFecha)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCargado)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaUsuario)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTipo)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaEmpresa)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaAnulada)
        Me.gbInvoiceInfo.Controls.Add(Me.botonPolizaC)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIdMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.botonMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaIdCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.botonCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.checkActivar)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaSerie)
        Me.gbInvoiceInfo.Controls.Add(Me.checkRevisado)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTasa)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaTasa)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNIT)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaTelefono)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaDireccion)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaNumero)
        Me.gbInvoiceInfo.Controls.Add(Me.celdaAño)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaMoneda)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaNit)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaTelefono)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaCliente)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaDireccion)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaNumero)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaFecha)
        Me.gbInvoiceInfo.Controls.Add(Me.etiquetaAño)
        Me.gbInvoiceInfo.Location = New System.Drawing.Point(3, 3)
        Me.gbInvoiceInfo.Name = "gbInvoiceInfo"
        Me.gbInvoiceInfo.Size = New System.Drawing.Size(388, 262)
        Me.gbInvoiceInfo.TabIndex = 0
        Me.gbInvoiceInfo.TabStop = False
        Me.gbInvoiceInfo.Text = "Invoice Information"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(56, 81)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(97, 20)
        Me.dtpFecha.TabIndex = 33
        '
        'celdaCargado
        '
        Me.celdaCargado.Location = New System.Drawing.Point(198, 212)
        Me.celdaCargado.Name = "celdaCargado"
        Me.celdaCargado.Size = New System.Drawing.Size(30, 20)
        Me.celdaCargado.TabIndex = 32
        Me.celdaCargado.Text = "-1"
        Me.celdaCargado.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(352, 67)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(30, 20)
        Me.celdaUsuario.TabIndex = 31
        Me.celdaUsuario.Text = "25"
        Me.celdaUsuario.Visible = False
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(352, 42)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.Size = New System.Drawing.Size(30, 20)
        Me.celdaTipo.TabIndex = 30
        Me.celdaTipo.Text = "1"
        Me.celdaTipo.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(352, 21)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(30, 20)
        Me.celdaEmpresa.TabIndex = 29
        Me.celdaEmpresa.Text = "0"
        Me.celdaEmpresa.Visible = False
        '
        'etiquetaAnulada
        '
        Me.etiquetaAnulada.AutoSize = True
        Me.etiquetaAnulada.BackColor = System.Drawing.Color.Red
        Me.etiquetaAnulada.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaAnulada.Location = New System.Drawing.Point(176, 34)
        Me.etiquetaAnulada.Name = "etiquetaAnulada"
        Me.etiquetaAnulada.Size = New System.Drawing.Size(69, 15)
        Me.etiquetaAnulada.TabIndex = 28
        Me.etiquetaAnulada.Text = "ANULADA"
        Me.etiquetaAnulada.Visible = False
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(275, 235)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(29, 23)
        Me.botonPolizaC.TabIndex = 27
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(154, 211)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(30, 20)
        Me.celdaIdMoneda.TabIndex = 26
        Me.celdaIdMoneda.Text = "-1"
        Me.celdaIdMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(120, 235)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 25
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(316, 101)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(30, 20)
        Me.celdaIdCliente.TabIndex = 24
        Me.celdaIdCliente.Text = "-1"
        Me.celdaIdCliente.Visible = False
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(280, 99)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(30, 23)
        Me.botonCliente.TabIndex = 23
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(301, 19)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 22
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'celdaSerie
        '
        Me.celdaSerie.Location = New System.Drawing.Point(135, 57)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.ReadOnly = True
        Me.celdaSerie.Size = New System.Drawing.Size(139, 20)
        Me.celdaSerie.TabIndex = 21
        Me.celdaSerie.Text = """A"""
        Me.celdaSerie.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.Location = New System.Drawing.Point(310, 240)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(74, 17)
        Me.checkRevisado.TabIndex = 20
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(190, 236)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(60, 20)
        Me.celdaTasa.TabIndex = 19
        Me.celdaTasa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(154, 239)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 18
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(56, 236)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(60, 20)
        Me.celdaMoneda.TabIndex = 17
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(56, 211)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(94, 20)
        Me.celdaNIT.TabIndex = 16
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(56, 184)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(158, 20)
        Me.celdaTelefono.TabIndex = 15
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(56, 124)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(290, 54)
        Me.celdaDireccion.TabIndex = 13
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(57, 101)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(217, 20)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(57, 57)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(72, 20)
        Me.celdaNumero.TabIndex = 10
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(57, 31)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(72, 20)
        Me.celdaAño.TabIndex = 9
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 239)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 8
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaNit
        '
        Me.etiquetaNit.AutoSize = True
        Me.etiquetaNit.Location = New System.Drawing.Point(6, 214)
        Me.etiquetaNit.Name = "etiquetaNit"
        Me.etiquetaNit.Size = New System.Drawing.Size(20, 13)
        Me.etiquetaNit.TabIndex = 7
        Me.etiquetaNit.Text = "Nit"
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(6, 184)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(38, 13)
        Me.etiquetaTelefono.TabIndex = 6
        Me.etiquetaTelefono.Text = "Phone"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 104)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 4
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(6, 127)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 60)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(6, 82)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 1
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(6, 34)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'dgReferencia
        '
        Me.dgReferencia.AllowUserToAddRows = False
        Me.dgReferencia.AllowUserToDeleteRows = False
        Me.dgReferencia.AllowUserToOrderColumns = True
        Me.dgReferencia.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgReferencia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgReferencia.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colTipo, Me.colAno, Me.colNumber, Me.colDate, Me.colPolicy, Me.colReference, Me.colLine, Me.colCod, Me.colDisponible, Me.colDescargo, Me.colDescargado, Me.colAmount, Me.colCantDescargada, Me.colModificado, Me.colUnidad, Me.colMedid, Me.colCantida})
        Me.dgReferencia.Location = New System.Drawing.Point(866, 739)
        Me.dgReferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.dgReferencia.MultiSelect = False
        Me.dgReferencia.Name = "dgReferencia"
        Me.dgReferencia.ReadOnly = True
        Me.dgReferencia.RowTemplate.Height = 24
        Me.dgReferencia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgReferencia.Size = New System.Drawing.Size(399, 101)
        Me.dgReferencia.TabIndex = 5
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        '
        'colAno
        '
        Me.colAno.HeaderText = "Ano"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        '
        'colNumber
        '
        Me.colNumber.HeaderText = "Numero"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.HeaderText = "Fecha"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        '
        'colPolicy
        '
        Me.colPolicy.HeaderText = "Poliza"
        Me.colPolicy.Name = "colPolicy"
        Me.colPolicy.ReadOnly = True
        '
        'colReference
        '
        Me.colReference.HeaderText = "Referencia"
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        '
        'colLine
        '
        Me.colLine.HeaderText = "Linea"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        '
        'colCod
        '
        Me.colCod.HeaderText = "Codigo"
        Me.colCod.Name = "colCod"
        Me.colCod.ReadOnly = True
        '
        'colDisponible
        '
        Me.colDisponible.HeaderText = "Disponible"
        Me.colDisponible.Name = "colDisponible"
        Me.colDisponible.ReadOnly = True
        '
        'colDescargo
        '
        Me.colDescargo.HeaderText = "A Descargar"
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.ReadOnly = True
        '
        'colDescargado
        '
        Me.colDescargado.HeaderText = "Existe"
        Me.colDescargado.Name = "colDescargado"
        Me.colDescargado.ReadOnly = True
        '
        'colAmount
        '
        Me.colAmount.HeaderText = "Saldo Actual"
        Me.colAmount.Name = "colAmount"
        Me.colAmount.ReadOnly = True
        '
        'colCantDescargada
        '
        Me.colCantDescargada.HeaderText = "Cantidad Descargada"
        Me.colCantDescargada.Name = "colCantDescargada"
        Me.colCantDescargada.ReadOnly = True
        '
        'colModificado
        '
        Me.colModificado.HeaderText = "Modificado"
        Me.colModificado.Name = "colModificado"
        Me.colModificado.ReadOnly = True
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unidad"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        '
        'colMedid
        '
        Me.colMedid.HeaderText = "Medida"
        Me.colMedid.Name = "colMedid"
        Me.colMedid.ReadOnly = True
        '
        'colCantida
        '
        Me.colCantida.HeaderText = "Cantidad"
        Me.colCantida.Name = "colCantida"
        Me.colCantida.ReadOnly = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(204, 11)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(59, 43)
        Me.botonImprimir.TabIndex = 23
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1024, 30)
        Me.BarraTitulo1.TabIndex = 2
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1024, 72)
        Me.Encabezado1.TabIndex = 1
        '
        'frmFacturacionCredFiscal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1024, 849)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.dgReferencia)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmFacturacionCredFiscal"
        Me.Text = "frmFacturacionCredFiscal"
        Me.panelLista.ResumeLayout(False)
        Me.panelColores.ResumeLayout(False)
        Me.panelColores.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabLista.ResumeLayout(False)
        Me.panelEncabLista.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelInfoFinal.ResumeLayout(False)
        Me.panelInfoFinal.PerformLayout()
        Me.panelDatos.ResumeLayout(False)
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelSubDocumentos.ResumeLayout(False)
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbInfoAdd.ResumeLayout(False)
        Me.gbInfoAdd.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelListaDespachInstr.ResumeLayout(False)
        CType(Me.dgFacturacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbInvoiceInfo.ResumeLayout(False)
        Me.gbInvoiceInfo.PerformLayout()
        CType(Me.dgReferencia, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents panelColores As System.Windows.Forms.Panel
    Friend WithEvents CheckMuestraDetalle As System.Windows.Forms.CheckBox
    Friend WithEvents celdaInfoDetalle As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorVerde As System.Windows.Forms.TextBox
    Friend WithEvents colorAqua As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorNaranja As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRosado As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorAmarillo As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRojo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSinPoliza As System.Windows.Forms.Label
    Friend WithEvents etiquetaNoCargado As System.Windows.Forms.Label
    Friend WithEvents etiquetaNoImpreso As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents etiquetaSalidaPendiente As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents colYear As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colImpreso As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSalida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colImpues As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBloqueado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCargado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNit As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelEncabLista As System.Windows.Forms.Panel
    Friend WithEvents botonPoliza As System.Windows.Forms.Button
    Friend WithEvents botonLiberar As System.Windows.Forms.Button
    Friend WithEvents botonSalida As System.Windows.Forms.Button
    Friend WithEvents botonCarga As System.Windows.Forms.Button
    Friend WithEvents botonConcolidacion As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents etiquetaAnd As System.Windows.Forms.Label
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelInfoFinal As System.Windows.Forms.Panel
    Friend WithEvents celdaTotal1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotales As System.Windows.Forms.Label
    Friend WithEvents checkDetGatos As System.Windows.Forms.CheckBox
    Friend WithEvents panelDatos As System.Windows.Forms.Panel
    Friend WithEvents dgDatos As System.Windows.Forms.DataGridView
    Friend WithEvents colNombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colConcepto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAbono As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDias As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelSubDocumentos As System.Windows.Forms.Panel
    Friend WithEvents dgSubdocumentos As System.Windows.Forms.DataGridView
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDatos As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents colNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCode As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colAño As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ColDescrip As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCodMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDespacho As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDesc As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescDolar As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBulto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipoBulto As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colBobina As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDistribucion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCodLugar As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLugDestino As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents colLBS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colKGS As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOriginal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferences As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gbInfoAdd As System.Windows.Forms.GroupBox
    Friend WithEvents botonSeguro As System.Windows.Forms.Button
    Friend WithEvents rbExportacion As System.Windows.Forms.RadioButton
    Friend WithEvents rbNacionalizacion As System.Windows.Forms.RadioButton
    Friend WithEvents celdaSeguro As System.Windows.Forms.TextBox
    Friend WithEvents celdaFlete As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSeguro As System.Windows.Forms.Label
    Friend WithEvents etiquetaFlete As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaNotas As System.Windows.Forms.TextBox
    Friend WithEvents panelListaDespachInstr As System.Windows.Forms.Panel
    Friend WithEvents dgFacturacion As System.Windows.Forms.DataGridView
    Friend WithEvents gbInvoiceInfo As System.Windows.Forms.GroupBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaCargado As System.Windows.Forms.TextBox
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaTipo As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAnulada As System.Windows.Forms.Label
    Friend WithEvents botonPolizaC As System.Windows.Forms.Button
    Friend WithEvents celdaIdMoneda As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaIdCliente As System.Windows.Forms.TextBox
    Friend WithEvents botonCliente As System.Windows.Forms.Button
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaSerie As System.Windows.Forms.TextBox
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaNit As System.Windows.Forms.Label
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents dgReferencia As System.Windows.Forms.DataGridView
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPolicy As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReference As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDisponible As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAmount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantDescargada As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colModificado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents colCatalogo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAñ As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFact As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFech As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOperador As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarca As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
