﻿Imports System.ComponentModel

Public Class frmDescargoConsumibles

#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strMensaje As String = STR_VACIO
    Dim cfun As New clsFunciones
    Dim intTipo As Integer
    Public Const catalogos = 691
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function LimpiarCampos()
        celdaNumero.Text = NO_FILA
        celdaAño.Text = cFunciones.AñoMySQL
        celdaNumeroAutorizado.Text = NO_FILA
        dtpFecha.Text = Now.ToString(FORMATO_MYSQL)
        celdaNombre.Clear()
        celdaDepartamento.Clear()
        celdaArea.Clear()
        dgDetalle.Rows.Clear()
        checkCuenta.Checked = True
        checkCuenta.Enabled = True
        OcultarCampos()
    End Function

    Private Sub OcultarCampos()
        If intTipo = 1 Then
            dgDetalle.Columns("colDepartamento").Visible = False
            dgDetalle.Columns("colDescripcionMaquina").Visible = False
            dgDetalle.Columns("colMarca").Visible = False
            dgDetalle.Columns("colModelo").Visible = False
            dgDetalle.Columns("colSerie").Visible = False

        Else
            dgDetalle.Columns("colDepartamento").Visible = True
            dgDetalle.Columns("colDescripcionMaquina").Visible = True
            dgDetalle.Columns("colMarca").Visible = True
            dgDetalle.Columns("colModelo").Visible = True
            dgDetalle.Columns("colSerie").Visible = True




        End If

    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            botonImprimir.Enabled = False

        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = False 

        End If
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)

        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("List Processing")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()

        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                '     botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                dgDetalle.Columns(7).ReadOnly = False
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_DR1_Dbl Num, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Solicitante, h.HDoc_Doc_Status Estado, h.HDoc_Ant_Com impreso
                        From Dcmtos_HDR h
                    Where h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 691 "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "And h.HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}' "
            strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Return strSQL
    End Function

    Private Function sqlSaldos()
        Dim strsql As String = STR_VACIO

        strsql = " Select d.DDoc_Prd_Cod id, d.DDoc_Prd_Des Product, d.DDoc_Prd_NET Price, SUM(d.DDoc_Prd_QTY - IFNULL(l.DDoc_Prd_QTY,0)) Balance, d.DDoc_Prd_UM id_Measure, c.cat_clave Measure
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM
                        LEFT JOIN Dcmtos_HDR a ON a.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND a.HDoc_Doc_Cat = 691 AND a.HDoc_Doc_Status = 1 AND a.HDoc_Ant_Com = 1
                        LEFT JOIN Dcmtos_DTL l ON l.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND l.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND l.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND l.DDoc_Doc_Num = a.HDoc_Doc_Num AND l.DDoc_Prd_Cod = d.DDoc_Prd_Cod
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Ant_Com = 3
                            GROUP BY d.DDoc_Prd_Cod, d.DDoc_Prd_NET
                            HAVING Balance >0"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql
    End Function

    Private Function sqlEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_DR2_Cat tipoDescargo, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num Numero, h.HDoc_DR1_Dbl num2, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom nombre, h.HDoc_Emp_Dir CCosto, h.HDoc_Doc_Status estatus,h.HDoc_DR1_Cat Cuenta,  h.HDoc_RF3_Dbl TipoRequisa
                    FROM Dcmtos_HDR h
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)

        Return strSQL
    End Function

    Private Function sqlDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT d.DDoc_Prd_Cod cod,d.DDoc_Prd_Des producto, d.DDoc_Prd_UM UM, d.DDoc_Doc_Lin linea, c.cat_clave, d.DDoc_Prd_DSP saldo, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidad, (d.DDoc_Prd_NET * d.DDoc_Prd_QTY) Total, d.DDoc_RF2_Cod cta, IFNULL(n.nombre,'') NCta, d.DDoc_Prd_Cif TC,d.DDoc_RF1_Txt Area,
                        IFNULL(DDoc_RF1_Num,'') CodigoDepartamento, IFNULL(DDoc_RF1_Cod,'') Departamento, IFNULL(DDoc_RF3_Num,'') CodigoMaquina, IFNULL(DDoc_RF4_Cod,'') DescripcionMaquina, IFNULL(DDoc_RF4_Txt,'') Marca, IFNULL(DDoc_RF3_Txt, '') Modelo, IFNULL(DDoc_RF2_Txt,'') Serie
                        FROM Dcmtos_DTL d
                        LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM
                        LEFT JOIN {conta}.cuentas n ON n.empresa = d.DDoc_Sis_Emp AND n.id_cuenta = d.DDoc_RF2_Cod
                            WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 691 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num}"

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)
        strSQL = strSQL.Replace("{conta}", cfun.ContaEmpresa)

        Return strSQL
    End Function

    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader



        strSQL = sqlLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        dgLista.Rows.Clear()
        If REA.HasRows Then
            Do While REA.Read
                strFila = REA.GetInt32("Anio") & "|"
                strFila &= REA.GetInt32("Numero") & "|"
                strFila &= REA.GetInt32("Num") & "|"
                strFila &= REA.GetDateTime("Fecha") & "|"
                strFila &= REA.GetString("Solicitante") & "|"
                strFila &= REA.GetInt32("impreso")

                If REA.GetInt32("Estado") = 0 Then
                    cfun.AgregarFila(dgLista, strFila, Color.Coral)
                Else
                    cfun.AgregarFila(dgLista, strFila)
                End If

            Loop
            For i As Integer = 0 To Me.dgLista.Rows.Count - 1
                If Me.dgLista.Rows(i).Cells("colReferencia").Value = 1 Then
                    Me.dgLista.Rows(i).Cells("colAnio").Style.BackColor = Color.YellowGreen
                End If
            Next
        End If

    End Sub

    Private Sub CargarEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlEncabezado(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaNumero.Text = REA.GetInt32("Numero")
                    celdaNumeroAutorizado.Text = REA.GetInt32("num2")
                    celdaAño.Text = REA.GetInt32("anio")
                    dtpFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    celdaNombre.Text = REA.GetString("nombre")
                    celdaDepartamento.Text = REA.GetString("CCosto")
                    If REA.GetInt32("tipoDescargo") = 1 Then
                        checkOtraPlanta.Checked = True
                    Else
                        checkOtraPlanta.Checked = False
                    End If
                    If REA.GetInt32("estatus") = 1 Then
                        checkActive.Checked = True
                    Else
                        checkActive.Checked = False
                    End If

                    If REA.GetInt32("TipoRequisa") = 1 Then
                        intTipo = 1
                    Else
                        intTipo = 0
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strArea As String = STR_VACIO
        'Dim dblcantidad As Double = 0
        'Dim dblTotal As Double = 0
        'Dim dblTotalLinea As Double = 0
        Try
            strSQL = sqlDetalle(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read

                    strFila = REA.GetInt32("cod") & "|"
                    strFila &= REA.GetString("producto") & "|"
                    strFila &= REA.GetString("UM") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetInt32("CodigoDepartamento") & "|"
                    strFila &= REA.GetString("Departamento") & "|"
                    strFila &= REA.GetInt32("CodigoMaquina") & "|"
                    strFila &= REA.GetString("DescripcionMaquina") & "|"
                    strFila &= REA.GetString("Marca") & "|"
                    strFila &= REA.GetString("Modelo") & "|"
                    strFila &= REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("saldo") & "|"
                    strFila &= REA.GetDouble("precio").ToString(FMT_MSO_UNITARIO) & "|"
                    strFila &= REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= 1 & "|"
                    strFila &= REA.GetString("cta") & "|"
                    'If .Item("hora_cierre").ToString.Trim IsNot "" Then TxtHora_fin_A.Text = Format(.Item("hora_cierre"), "dd/MM/yyyy HH:mm")
                    'If REA.GetString("NCta").Trim IsNot "" Then strFila &= REA.GetString("NCta") & "|"

                    If REA.GetString("NCta").Trim IsNot "" Then
                        strFila &= REA.GetString("NCta") & "|"
                    Else
                        strFila &= "|"
                    End If

                    'strFila &= REA.GetString("NCta") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    strFila &= REA.GetString("Area")

                    cFunciones.AgregarFila(dgDetalle, strFila)
                    strArea = REA.GetString("Area")
                    'dblcantidad = dblcantidad + REA.GetDouble("cantidad")
                    'dblTotal = dblTotal + dblTotalLinea

                Loop
                dgDetalle.Columns(7).ReadOnly = True
                celdaArea.Text = strArea
                'celdaCantidad.Text = dblcantidad.ToString(FORMATO_MONEDA)
                'celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
                OcultarCampos()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function VerificarDatos() As Boolean
        Dim verificar As Boolean = False
        Dim intLineas As Integer = 0
        Try
            If celdaNombre.Text = vbNullString Then
                verificar = False
                MsgBox("Enter the Applicant's name", vbInformation, "Notice")
                celdaNombre.Focus()
                Exit Function
            Else
                verificar = True
            End If
            If celdaDepartamento.Text = vbNullString Then
                verificar = False
                MsgBox("Enter Cost Center", vbInformation, "Notice")
                celdaDepartamento.Focus()
                Exit Function
            Else
                verificar = True
            End If
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If Me.Tag = "Nuevo" Then
                    If CDbl(dgDetalle.Rows(i).Cells("col_Saldo").Value) >= CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) Then
                        verificar = True
                    Else
                        MsgBox("Quantity is greater than inventory", vbInformation, "Notice")
                        verificar = False
                        Exit Function
                    End If
                End If
                If Not dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    intLineas = intLineas + 1
                End If
                If dgDetalle.Rows(i).Cells("col_Cta").Value = vbNullString Or dgDetalle.Rows(i).Cells("col_Cta").Value = STR_VACIO Then
                    verificar = False
                    MsgBox("Select a ledger account", vbInformation, "Notice")
                    Exit Function
                End If
            Next
            If intLineas >= 1 Then
                verificar = True
            Else
                verificar = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return verificar
    End Function

    Private Function GuardarEncabezado() As Boolean
        Dim hdr As New clsDcmtos_HDR
        Dim Correcto As Boolean = False
        Try
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 691
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_DR1_CAT = IIf(checkCuenta.Checked = True, 1, 0)
            hdr.HDOC_EMP_NOM = celdaNombre.Text
            hdr.HDOC_EMP_DIR = celdaDepartamento.Text
            hdr.HDOC_DR1_DBL = celdaNumeroAutorizado.Text
            hdr.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, 0)
            hdr.HDOC_DR2_CAT = IIf(checkOtraPlanta.Checked = True, 1, 0)
            hdr.HDOC_RF3_DBL = IIf(intTipo = 1, 1, 0)

            hdr.CONEXION = strConexion
            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    Correcto = False
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 691, celdaAño.Text, celdaNumero.Text)
                    Correcto = True
                End If
            Else
                If hdr.Guardar() = False Then
                    Correcto = False
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 691, celdaAño.Text, celdaNumero.Text)
                    Correcto = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Correcto
    End Function

    Private Sub GuardarDetalle()
        Dim dtl As New clsDcmtos_DTL

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                dtl.DDOC_DOC_ANO = celdaAño.Text
                dtl.DDOC_DOC_CAT = 691
                dtl.DDOC_DOC_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Cells("colLinea").Value = 0 Then
                    dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
                    dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                Else
                    dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                End If
                dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colProducto").Value
                dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value
                dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("col_Cta").Value
                dtl.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("col_TC").Value
                dtl.DDOC_RF1_TXT = celdaArea.Text 'dgDetalle.Rows(i).Cells("colArea").Value

                If dgDetalle.Rows(i).Cells("colCodDepartamento").Value = STR_VACIO Then
                    dtl.DDOC_RF1_NUM = 0
                Else
                    dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCodDepartamento").Value
                End If

                If dgDetalle.Rows(i).Cells("colDepartamento").Value = STR_VACIO Then
                    dtl.DDOC_RF1_COD = STR_VACIO
                Else
                    dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colDepartamento").Value
                End If

                If dgDetalle.Rows(i).Cells("colCodMaquina").Value = STR_VACIO Then
                    dtl.DDOC_RF3_NUM = 0
                Else
                    dtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colCodMaquina").Value
                End If

                If dgDetalle.Rows(i).Cells("colDescripcionMaquina").Value = STR_VACIO Then
                    dtl.DDOC_RF4_COD = STR_VACIO
                Else
                    dtl.DDOC_RF4_COD = dgDetalle.Rows(i).Cells("colDescripcionMaquina").Value
                End If

                If dgDetalle.Rows(i).Cells("colMarca").Value = STR_VACIO Then
                    dtl.DDOC_RF4_TXT = STR_VACIO
                Else
                    dtl.DDOC_RF4_TXT = dgDetalle.Rows(i).Cells("colMarca").Value
                End If

                If dgDetalle.Rows(i).Cells("colModelo").Value = STR_VACIO Then
                    dtl.DDOC_RF3_TXT = STR_VACIO
                Else
                    dtl.DDOC_RF3_TXT = dgDetalle.Rows(i).Cells("colModelo").Value
                End If

                If dgDetalle.Rows(i).Cells("colSerie").Value = STR_VACIO Then
                    dtl.DDOC_RF2_TXT = STR_VACIO
                Else
                    dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colSerie").Value
                End If



                dtl.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If dtl.Actualizar() = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)

                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If dtl.Guardar() = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                    DeleteReserved(dgDetalle.Rows(i).Cells("colidreserva").Value)
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If dtl.Borrar() = False Then

                        MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colCancelado").Value = vbNullString Then
                    dtl.DDOC_RF2_NUM = 0
                Else
                    dtl.DDOC_RF2_NUM = 1
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub BorrarEncabezado(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = catalogos
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDetalle(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = {cata} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", catalogos)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function PermisosImprimir() As Integer
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0

        Try
            strsql = " SELECT COUNT(*)
                        FROM Permisos p
                            WHERE p.pms_empresa = {emp} AND p.pms_usuario = '{user}' AND p.pms_modulo = 648 AND p.pms_codigo ='ImprimirConsumibles'"

            strsql = Replace(strsql, "{emp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{user}", Sesion.Usuario)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intResultado
    End Function

    Private Sub ActualizarEstadoDeImpresion()
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0

        Try
            strsql = " UPDATE Dcmtos_HDR h SET h.HDoc_Ant_Com = 1
                          WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"
            If Sesion.IdEmpresa = 18 Then
                strsql &= "; UPDATE PDM.Dcmtos_HDR h SET h.HDoc_Ant_Com = 1
                          WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"
            End If
            strsql = Replace(strsql, "{emp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAño.Text)
            strsql = Replace(strsql, "{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function VerificaImpresion()
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0

        Try
            strsql = " SELECT h.HDoc_Ant_Com
                            FROM Dcmtos_HDR h
                            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"

            strsql = Replace(strsql, "{emp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAño.Text)
            strsql = Replace(strsql, "{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intResultado
    End Function
    Private Function ActualizarFechaImpresion()
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0

        Try
            strsql = " UPDATE Dcmtos_HDR h SET h.HDoc_Doc_Fec = NOW()
                            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            If Sesion.IdEmpresa = 18 Then
                strsql &= "; UPDATE PDM.Dcmtos_HDR h SET h.HDoc_Doc_Fec = NOW()
                            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            End If
            strsql = Replace(strsql, "{emp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAño.Text)
            strsql = Replace(strsql, "{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        dtpFecha.Value = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
        Return intResultado
    End Function
    Private Function BuscarRegistrosDcmtos_HDR_NSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FCNSM")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturaConsumibleNSM.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_DTL_NSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FCNSM2")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturaConsumibleNSMDTL.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Sub ImpresionFacturaConsumible()
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO
        Dim strSQL5 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim clsConta As New clsContabilidad
        Dim rep4 As New FacturaConsumible1


        strSQL = " SELECT CAST(LPAD(h.HDoc_Doc_Num,7,0) AS CHAR) num,h.HDoc_Emp_Nom  Solicitado , h.HDoc_Emp_Dir Departamento, h.HDoc_Doc_Fec Fecha "
        strSQL &= "     FROM Dcmtos_HDR h "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NSM(strSQL) = True Then
        End If
        strSQL2 &= "    SELECT d.DDoc_Doc_Lin Item, d.DDoc_Prd_QTY Cantidad , d.DDoc_Prd_Des Descripcion, d.DDoc_RF1_Txt Area "
        strSQL2 &= "        FROM Dcmtos_DTL d  "
        strSQL2 &= "            WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 691 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num  = {numero} "
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_DTL_NSM(strSQL2) = True Then
        End If
        rep4.Load("C:\XML\FacturaConsumibleNSM.xml")
        rep4.Load("C:\XML\FacturaConsumibleNSMDTL.xml")
        Dim frm3 As New FrmFacturaHSM
        frm3.Reporte_A_VerHSM = rep4
        frm3.Name = "Factura Consumible"
        frm3.CrystalReportViewer1.ReportSource = rep4
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\FacturaConsumibleNSM.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturaConsumibleNSMDTL.xml")
    End Sub
    Private Function PermisoCuenta() As Integer
        Dim strsql As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0

        Try
            strsql = " SELECT COUNT(*)
                        FROM Permisos p
                            WHERE p.pms_empresa = {emp} AND p.pms_usuario = '{user}' AND p.pms_modulo = 648 AND p.pms_codigo ='CuentasConsumibles'"

            strsql = Replace(strsql, "{emp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{user}", Sesion.Usuario)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intResultado
    End Function
#End Region

#Region "Eventos"
    Private Sub frmDescargoConsumibles_Load(sender As Object, e As EventArgs) Handles Me.Load
        '        ClearReserved(Sesion.Usuario)
        ClearReservedByUser()

        Accessos()
        dtpFechaFinal.Value = Today.ToString(FORMATO_MYSQL)
        dtpFechaInicial.Value = dtpFechaInicial.Value.AddMonths(NO_FILA).ToString(FORMATO_MYSQL)
        MostrarLista()
    End Sub
    Private Sub ClearReserved(sIdusuario)
        Dim strsql As String = STR_VACIO
        strsql = "nota < (
                       SELECT CAST(MAX(id_sesion) AS UNSIGNED) ultima FROM Sesiones
                       WHERE usuario = '" & Sesion.Usuario & "')
                        AND usuario = '" & Sesion.Usuario & "'"


        Dim reserva As New Tablas.TRESERVA
        reserva.CONEXION = strConexion
        reserva.PDELETE(strsql)
    End Sub
    Private Sub ClearReservedClosedForm(sIdusuario)
        Dim strsql As String = STR_VACIO
        strsql = "nota = (
                       SELECT MAX(id_sesion) ultima FROM Sesiones
                       WHERE usuario = '" & Sesion.Usuario & "')
                        AND usuario = '" & Sesion.Usuario & "'"

        Dim reserva As New Tablas.TRESERVA
        reserva.CONEXION = strConexion
        reserva.PDELETE(strsql)
    End Sub
    Private Sub ClearReservedByUser()
        Dim strsql As String = STR_VACIO
        strsql = "nota = '" & Sesion.Usuario & "'"

        Dim reserva As New Tablas.TRESERVA
        reserva.CONEXION = strConexion
        reserva.PDELETE(strsql)
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim opt As New frmOption
        If logInsertar = True Then
            Me.Tag = "Nuevo"
            opt.Titulo = "Option"
            opt.Mensaje = "Select an option"
            opt.Opciones = "Spare parts" & "|" & " Consumables "
            If opt.ShowDialog = DialogResult.OK Then

                Select Case opt.Seleccion
                    Case 0
                        intTipo = 0
                    Case 1
                        intTipo = 1

                End Select
            Else
                Exit Sub
            End If
            LimpiarCampos()
            MostrarLista(False, True)
            Encabezado1.botonBorrar.Enabled = False
            botonAgregar.Enabled = True
            botonEliminar.Enabled = True
            botonCCostos.Enabled = True
            botonCCostos.Visible = True
        Else
            MsgBox("No Posee permisos para esta acción", vbInformation)
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
            ClearReservedByUser()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
            ClearReservedByUser()
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer
        Dim numero As Integer
        Me.Tag = "Mod"
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        MostrarLista(False)
        año = dgLista.SelectedCells(0).Value
        numero = dgLista.SelectedCells(1).Value
        LimpiarCampos()
        CargarEncabezado(año, numero)
        CargarDetalle(año, numero)
        botonAgregar.Enabled = False
        botonEliminar.Enabled = False
        calcularTotales()
        'PermisosImprimir
        If PermisosImprimir() > 0 Then
            botonImprimir.Enabled = True
        Else
            botonImprimir.Enabled = False
        End If
        ' Permiso Cuentas Consumibles
        'If PermisoCuenta() > 0 Then
        '    checkCuenta.Enabled = True
        'Else
        '    checkCuenta.Enabled = False
        'End If


    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim strQuery As String = ""
        Try
            frm.Titulo = "Discharge"
            frm.Campos = "a2.id id, a2.Product Product , a2.Price Price , a2.Balance Balance , a2.id_Measure id_Measure, a2.Measure Measure, a2.TC TC, Reservado reserved,idreserva idreserva, usuario ReservadoPor, a2.Empresa empresa, a2.catalogo catalogo, a2.ano ano, a2.numero numero,a2.linea linea, a2.producto producto"

            strQuery = "  (
                                    SELECT 
                                     a1.idreserva, 
                                    a1.id id, a1.Product Product, a1.Price Price, 
                                    (a1.Balance - a1.Cantidad - a1.Cantidad48) - IFNULL(r.cantidad,0) Balance, 
                                    a1.id_Measure id_Measure, a1.Measure Measure, a1.TC TC,IFNULL(r.cantidad,0) Reservado, IFNULL(r.usuario,'None') usuario,
                                    a1.empresa empresa,a1.catalogo catalogo, a1.ano ano, a1.numero numero,
                                    a1.linea linea, a1.producto producto
                                    FROM (
                                    SELECT d.DDoc_Sis_Emp empresa,d.DDoc_Doc_Cat catalogo, d.DDoc_Doc_Ano ano, d.DDoc_Doc_Num numero,
                                        d.DDoc_Doc_Lin linea,d.DDoc_Prd_Cod producto,
                                     CONCAT(d.DDoc_Doc_Lin,d.DDoc_Prd_Cod) idreserva,
                                            d.DDoc_Prd_Cod id, d.DDoc_Prd_Des Product, d.DDoc_Prd_NET Price,
                                      SUM(d.DDoc_Prd_QTY) Balance, d.DDoc_Prd_UM id_Measure, 
                                            c.cat_clave Measure, h.HDoc_Doc_TC TC, 
                                    IFNULL(subquery.Cantidad, 0) Cantidad, 
                                     /*IFNULL((
                                            SELECT SUM(IFNULL(l.DDoc_Prd_QTY,0))
                                            FROM Dcmtos_HDR a
                                            LEFT JOIN Dcmtos_DTL l ON l.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND l.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND l.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND l.DDoc_Doc_Num = a.HDoc_Doc_Num
                                            WHERE a.HDoc_Sis_Emp = h.HDoc_Sis_emp AND a.HDoc_Doc_Cat IN(48) AND a.HDoc_Doc_Status = 1 
                                             --  AND a.HDoc_Ant_Com = 1 
                                             -- and a.HDoc_Doc_Ano = 2023
                                            AND l.DDoc_Prd_Cod = d.DDoc_Prd_Cod 
                                            -- AND l.DDoc_Prd_NET = d.DDoc_Prd_NET 
                                            ),0) Cantidad48 -- Descargo de consumibles por una instruccion de despacho
                                      */

                                    SUM(IFNULL((
                                            SELECT SUM(IFNULL(d48.DDoc_Prd_QTY,0)) 
                                            FROM Dcmtos_DTL_Pro a47 
                                            LEFT JOIN Dcmtos_DTL d48 ON d48.DDoc_Sis_Emp=a47.PDoc_Sis_Emp 
                                                AND d48.DDoc_Doc_Cat=a47.PDoc_Chi_Cat AND d48.DDoc_Doc_Ano =a47.PDoc_Chi_Ano 
                                                AND d48.DDoc_Doc_Num=a47.PDoc_Chi_Num AND d48.DDoc_Doc_Lin=a47.PDoc_Chi_Lin 
                                            LEFT JOIN Dcmtos_HDR h48 ON h48.HDoc_Sis_Emp=a47.PDoc_Sis_Emp 
                                                and h48.HDoc_Doc_Cat =a47.PDoc_Chi_Cat AND h48.HDoc_Doc_Ano =a47.PDoc_Chi_Ano 
                                                AND h48.HDoc_Doc_Num =a47.PDoc_Chi_Num 
                                            WHERE a47.PDoc_Sis_Emp = h.HDoc_Sis_emp AND a47.PDoc_Par_Cat=d.DDoc_Doc_Cat 
                                                AND a47.PDoc_Par_Ano=d.DDoc_Doc_Ano  AND a47.PDoc_Par_Num=d.DDoc_Doc_Num 
                                                AND a47.PDoc_Par_Lin=d.DDoc_Doc_Lin AND a47.PDoc_Chi_Cat IN(48) 
                                                AND h48.HDoc_Doc_Status = 1 ),0)) Cantidad48

                                    FROM Dcmtos_HDR h
                                        LEFT JOIN Dcmtos_DTL d 
                                            ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp
                                                AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat 
                                                    AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano 
                                                        AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                                        LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM
LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
LEFT JOIN Articulos ar ON ar.art_sisemp = i.inv_sisemp AND ar.art_codigo = i.inv_artcodigo
LEFT JOIN Catalogos cat ON cat.cat_num = ar.art_clase 
      LEFT JOIN (SELECT l.DDoc_Prd_Cod, l.DDoc_Prd_NET, SUM(DDoc_Prd_QTY) AS Cantidad
        FROM Dcmtos_HDR a
        LEFT JOIN Dcmtos_DTL l ON l.DDoc_Sis_Emp = a.HDoc_Sis_Emp
        AND l.DDoc_Doc_Cat = a.HDoc_Doc_Cat
        AND l.DDoc_Doc_Ano = a.HDoc_Doc_Ano
        AND l.DDoc_Doc_Num = a.HDoc_Doc_Num
		WHERE a.HDoc_Doc_Cat = 691
        AND a.HDoc_Doc_Status = 1
        GROUP BY l.DDoc_Prd_Cod,
        l.DDoc_Prd_NET) AS subquery 
		ON subquery.DDoc_Prd_Cod = d.DDoc_Prd_Cod
        AND subquery.DDoc_Prd_NET = d.DDoc_Prd_NET

                                            WHERE h.HDoc_Sis_Emp = {emp} 
                                             AND h.HDoc_Doc_Cat = 47 
                                                AND (h.HDoc_DR1_Cat = 3 OR h.HDoc_DR1_Cat = 0 OR h.HDoc_DR1_Cat >6)
AND cat.cat_clase = 'ClaseArt' AND cat.cat_sisemp = 1
                                        
                                        GROUP BY d.DDoc_Prd_Cod, d.DDoc_Prd_NET
                                    ) a1
                                    LEFT JOIN Reserva r 
                                       ON CONCAT(r.doc_lin,r.id_entidad) = a1.idreserva)a2"

            strQuery = Replace(strQuery, "{ciclo}", celdaAño.Text)
            strQuery = Replace(strQuery, "{emp}", Sesion.IdEmpresa)

            frm.Tabla = strQuery
            frm.Condicion = " a2.id > 0  HAVING (Balance + Reserved) > 0"
            frm.Filtro = " a2.Product "
            frm.Filtro2 = " a2.id "
            frm.Limite = 25
            frm.Multiple = True

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                If CDbl(frm.ListaClientes.Rows(frm.ListaClientes.CurrentCell.RowIndex).Cells(4).Value) <= 0 Then
                    MsgBox("Product is reserved, please check", vbInformation)
                    Exit Sub
                End If

                Dim dCantSelecion As Double = 0
                Dim dCantSelecionConfir As String = 0
                Dim sIdReserva As String = ""

                For r = 0 To frm.ListaClientes.Rows.Count - 1
                    If frm.ListaClientes.Rows(r).Cells("colCheck").Value = True Then
                        dCantSelecion = frm.ListaClientes.Rows(r).Cells(4).Value
                        Exit For
                    End If
                Next





                For i = 0 To frm.DataGrid.Rows.Count - 1

                    If frm.ListaClientes.Rows(i).Cells("colCheck").Value = True And frm.ListaClientes.Rows(i).Cells("col_reserved").Value = 0 Then


                        sIdReserva = frm.ListaClientes.Rows(i).Cells(9).Value

                        dCantSelecionConfir = InputBox("quantity to download ? " + vbCrLf +
                                                       frm.ListaClientes.Rows(i).Cells(2).Value, "", dCantSelecion)

                        dCantSelecion = frm.ListaClientes.Rows(i).Cells(4).Value

                        If Not IsNumeric(dCantSelecionConfir) Then
                            MsgBox("Enter only numerical data, and that it is not greater than the availability of: [" &
                                   dCantSelecion & "]", vbInformation)
                            Exit Sub
                        ElseIf (dCantSelecionConfir > dCantSelecion) Then
                            MsgBox("Insufficient quantity for this download, available quantity is: [" &
                                   dCantSelecion & "]", vbInformation)
                            Exit Sub
                        End If


                        strFila = frm.ListaClientes.Rows(i).Cells(1).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(2).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(5).Value & "|"
                        strFila &= 0 & "|" 'frm.ListaClientes.Rows(i).Cells(0).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(6).Value & "||||||||"

                        strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|"
                        strFila &= dCantSelecionConfir & "|" 'frm.ListaClientes.Rows(i).Cells(2).Value & "|"
                        strFila &= ((frm.ListaClientes.Rows(i).Cells(3).Value) * dCantSelecionConfir) & "|"
                        strFila &= INT_CERO & "|" ' 0 Nueva Linea, 1 Linea a actualizar
                        strFila &= "" & "|"
                        strFila &= "" & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|"
                        strFila &= "" & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(9).Value & ""



                        cfun.AgregarFila(dgDetalle, strFila)

                        ReservedQuantity(sIdReserva, dCantSelecionConfir, frm.ListaClientes.Rows(i).Cells(13).Value, frm.ListaClientes.Rows(i).Cells(14).Value)
                    End If

                Next
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ReservedQuantity(idreserva As String, dCantidad As Double, vAno As Integer, vNumero As Integer)
        Dim currentesssion As New clsSesion
        Dim strsql As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0
        strsql = " insert into Reserva 	
			SELECT d.Ddoc_Sis_Emp id_empresa,
			d.DDoc_Doc_Cat doc_tipo,
			d.DDoc_Doc_Ano doc_ciclo,
			d.DDoc_Doc_Num doc_num,
			d.DDoc_Doc_Lin doc_lin,1 linea,
			d.DDoc_Prd_Cod id_entidad,
			d.DDoc_Prd_DSP nombre,
			" & dCantidad & " cantidad,
			'" & Sesion.Usuario & "' nota,
			NOW() marca,
			'Reserva en Descarga' referencia,
			0 estado,
			'" & Sesion.Usuario & "' usuario
			 FROM Dcmtos_DTL d
			WHERE   
            	d.DDoc_Sis_Emp=" & Sesion.IdEmpresa & "
			    and d.DDoc_Doc_Cat=47
                and DDoc_Doc_Ano=" & vAno & " 
                and DDoc_Doc_Num= " & vNumero & " 
                and CONCAT(d.DDoc_Doc_Lin,d.DDoc_Prd_Cod) =  '" & idreserva & "'"

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        COM.ExecuteNonQuery()

        Return Nothing
    End Function

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        If dgDetalle.CurrentRow.Cells(7).Value > 0 Then
            dgDetalle.CurrentRow.Cells(8).Value = CDbl(dgDetalle.CurrentRow.Cells(6).Value * dgDetalle.CurrentRow.Cells(7).Value)
        End If
        calcularTotales()
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 6
                    Dim frmF As New frmSeleccionar
                    frmF.Titulo = "Select a department"
                    frmF.Campos = " Correlativo Codigo, Departamento"
                    frmF.Tabla = "Maquinaria"

                    frmF.FiltroText = "Enter the name of department"
                    frmF.Filtro = " Departamento "
                    frmF.Condicion = " Estado = 1 AND  NoCorrelativo = 0"
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = DialogResult.OK Then

                        dgDetalle.CurrentRow.Cells("colDepartamento").Value = frmF.Dato
                        dgDetalle.CurrentRow.Cells("colCodDepartamento").Value = frmF.LLave
                    End If
                    dgDetalle.CurrentRow.Cells("colCodMaquina").Value = 0
                    dgDetalle.CurrentRow.Cells("colDescripcionMaquina").Value = STR_VACIO
                    dgDetalle.CurrentRow.Cells("colMarca").Value = STR_VACIO
                    dgDetalle.CurrentRow.Cells("colModelo").Value = STR_VACIO
                    dgDetalle.CurrentRow.Cells("colSerie").Value = STR_VACIO
                Case 8
                    Dim frmF As New frmSeleccionar
                    frmF.Titulo = "Select a Machine"
                    frmF.Campos = " Correlativo Codigo, Descripcion, Marca, Modelo, Serie"
                    frmF.Tabla = "Maquinaria"

                    frmF.FiltroText = "Enter the name of department"
                    frmF.Filtro = " Descripcion "

                    If dgDetalle.CurrentRow.Cells("colCodDepartamento").Value = 0 Then
                        frmF.Condicion = " Estado = 1 AND NoCorrelativo > 0 "
                    Else
                        frmF.Condicion = " Estado = 1 AND  NoCorrelativo = " & dgDetalle.CurrentRow.Cells("colCodDepartamento").Value
                    End If

                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("colCodMaquina").Value = frmF.LLave
                        dgDetalle.CurrentRow.Cells("colDescripcionMaquina").Value = frmF.Dato
                        dgDetalle.CurrentRow.Cells("colMarca").Value = frmF.Dato2
                        dgDetalle.CurrentRow.Cells("colModelo").Value = frmF.Dato3
                        dgDetalle.CurrentRow.Cells("colSerie").Value = frmF.Dato4

                    End If
                Case 18
                    Dim frmF As New frmSeleccionar
                    frmF.Titulo = "Entry To Account"
                    frmF.Campos = " DISTINCT(i.costo) Account_, c.nombre Name_ "
                    frmF.Tabla = cfun.ContaEmpresa & ".inventario_codigos i
                                    LEFT JOIN " & cfun.ContaEmpresa & ".cuentas c ON c.empresa = i.empresa AND c.id_cuenta = i.costo"
                    frmF.Condicion = " i.empresa = " & Sesion.IdEmpresa & " AND i.ejercicio >0"
                    frmF.FiltroText = "Select an Account"
                    frmF.Filtro = " c.nombre "
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_Cta").Value = frmF.LLave
                        dgDetalle.CurrentRow.Cells("col_NombreCta").Value = frmF.Dato
                    End If
                Case 22

                    Try
                        If dgDetalle.SelectedCells(0).Value > 0 Then
                            Dim Opt As New frmOption
                            Dim cancel As String
                            Opt.Titulo = "State"
                            Opt.Mensaje = "Select an Option"
                            Opt.Opciones = "Activo" & "|" & "Canceled (Dispatched)"
                            'Opt.ShowDialog(Me)


                            If Opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                                Select Case Opt.Seleccion

                                    Case 0
                                        If Opt.Seleccion = 0 Then
                                            cancel = ""
                                            dgDetalle.SelectedCells(15).Value = cancel
                                        End If

                                    Case 1
                                        If Opt.Seleccion = 1 Then
                                            cancel = "Si"
                                            dgDetalle.SelectedCells(15).Value = cancel
                                        End If
                                End Select
                            End If
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.ToString)
                    End Try
            End Select
            calcularTotales()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub calcularTotales()
        Dim totalCantidad As Double = 0
        Dim total As Double = 0
        For i = 0 To dgDetalle.Rows.Count - 1
            totalCantidad += dgDetalle.Rows(i).Cells("colCantidad").Value
            total += dgDetalle.Rows(i).Cells("colTotal").Value
        Next
        celdaTCantidad.Text = totalCantidad
        celdaTotal.Text = total
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intNumAutorizado As Integer = 0
        Dim conta As New clsContabilidad
        If logEditar = True Or Me.Tag = "Nuevo" Then

            If VerificarDatos() = True Then
                If celdaNumero.Text = NO_FILA Then
                    celdaNumero.Text = cFunciones.NuevoId(catalogos)

                End If
                If celdaNumeroAutorizado.Text = NO_FILA Then
                    strSQL = " SELECT ifnull(MAX(HDoc_DR1_Dbl),0)+1"
                    strSQL &= "     FROM Dcmtos_HDR"
                    strSQL &= "         WHERE HDoc_Sis_Emp ={empresa} and HDoc_Doc_Cat = 691 and HDoc_Doc_Ano = {anio}"

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    intNumAutorizado = COM.ExecuteScalar
                    celdaNumeroAutorizado.Text = intNumAutorizado
                Else
                    strSQL = " SELECT COUNT(*)
                                    FROM Dcmtos_HDR h
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 691 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_DR1_Dbl = {num}"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{num}", celdaNumeroAutorizado.Text)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    intNumAutorizado = COM.ExecuteScalar
                    If intNumAutorizado > 0 And Me.Tag = "Nuevo" Then
                        MsgBox("Registration number already exists", vbInformation, "Notice")
                        celdaNumeroAutorizado.Focus()
                        Exit Sub
                    End If
                End If
                If GuardarEncabezado() = True Then
                    GuardarDetalle()
                    MsgBox("Successfully Saved Document", vbInformation, "Notice")
                    MostrarLista()
                    conta.GenerarPoliza(691, celdaAño.Text, celdaNumero.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
                    ClearReservedByUser()
                End If
            End If
        End If
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Try
            If LogBorrar = True Then
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarEncabezado(celdaNumero.Text, celdaAño.Text)
                    BorrarDetalle(celdaNumero.Text, celdaAño.Text)
                    cFunciones.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAño.Text, 691)
                    cFunciones.BorrarDetallePoliza(celdaNumero.Text, celdaAño.Text, 691)
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 691, celdaAño.Text, celdaNumero.Text)
                    MostrarLista()
                End If
            Else
                MsgBox("You do not have permission for this action", vbInformation, "Notice")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        'Dim conta As New clsContabilidad
        Try
            'If VerificaImpresion() = 0 Then ' Imprime, actualiza el estado y genera póliza

            '    ActualizarFechaImpresion()
            '    ActualizarEstadoDeImpresion()
            '    conta.GenerarPoliza(691, celdaAño.Text, celdaNumero.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
            '    ImpresionFacturaConsumible()
            '    'MsgBox("impresion", vbInformation, "Notice")
            'Else

            '*****************   solo Imprime ******************
            ImpresionFacturaConsumible()
            ' MsgBox("impresion", vbInformation, "Notice")
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click
        Dim PC As New clsPolizaContable
        PC.intTipo = 691
        PC.intCiclo = celdaAño.Text
        PC.intNumero = celdaNumero.Text
        PC.intModo = 33
        PC.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 691)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub


    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        If MsgBox("Are you sure to delete this items?", vbYesNo + vbQuestion) = vbNo Then
            Exit Sub
        End If
        Dim intRow As Integer =
               dgDetalle.CurrentCell.RowIndex
        Dim sIdReserved As String =
                dgDetalle.Rows(intRow).Cells("colidreserva").Value

        If logEditar = True Then
            DeleteReserved(sIdReserved)
            dgDetalle.Rows.RemoveAt(intRow)
        End If

    End Sub

    Private Function DeleteReserved(idreserva As String)
        '     Private Function ReservedQuantity(idreserva As String, dCantidad As Double)
        Dim strsql As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim intResultado As Integer = 0
        strsql = " delete from Reserva 
            where CONCAT(id_empresa,doc_tipo,doc_ciclo,doc_num,doc_lin,id_entidad) = 
			 " & idreserva


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strsql, CON)
        COM.ExecuteNonQuery()

        Return Nothing

    End Function

    Private Sub frmDescargoConsumibles_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        ClearReservedByUser()
        'ClearReservedClosedForm(Sesion.Usuario)
    End Sub

    Private Sub frmDescargoConsumibles_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        ClearReservedByUser()
        'ClearReservedClosedForm(Sesion.Usuario)
    End Sub

    Private Sub botonCCostos_Click(sender As Object, e As EventArgs) Handles botonCCostos.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Seleccione un centro de costos"
            frm.Campos = " cost_num Codigo, cost_nombre Nombre "
            frm.Tabla = cfun.ContaEmpresa & ".costos "
            frm.FiltroText = " Ingrese el nombre del centro de costo para filtrar"
            frm.Filtro = " cost_nombre "
            frm.Condicion = "cost_num >=0"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDCosto.Text = frm.LLave
                celdaDepartamento.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

    Private Sub dgDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellContentClick

    End Sub

    Private Sub celdaNumero_TextChanged(sender As Object, e As EventArgs) Handles celdaNumero.TextChanged

    End Sub

#End Region

End Class