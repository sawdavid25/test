﻿Public Class frmInstDespacho

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim LogPago As Boolean = False

    Const CAT_ORD As Integer = 777
    Dim intCurDoc As Integer
    Dim strReferencia As String
    Dim cfun As New clsFunciones


    Dim intMarca As Integer = vbEmpty
    Dim intActual As Integer = vbEmpty
    Dim intUltima As Integer = vbEmpty

    Private intCurPro As Integer

    Private dblDocCantidad As Double
    Private dblDocTotal As Double

    Private intLbs As Integer
    Private intKgs As Integer
    Private dblFactorKgs As Double
    Private dblFactorLbs As Double

    Private logComentario As Boolean
    Private logBloquear As Boolean
    Private logLibre As Boolean
    Private intCambio As Integer
    Private validacionDatosInicio As Boolean = False



    '********CONSTANTES************
    Private Const ID_MOD = 56
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            LogPago = PermisoPago()
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function PermisoPago() As Boolean
        Dim logResultado As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = "  SELECT COUNT(*) FROM Permisos p
                     WHERE p.pms_empresa = {empresa} AND p.pms_modulo = 56 AND p.pms_usuario ='{usario}' AND p.pms_codigo = 'PAGO'"

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{usario}", Sesion.Usuario)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            logResultado = COM.ExecuteScalar > 0

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = True
            botonBuscar.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            botonBuscar.Enabled = False
        End If
    End Sub

    'Limpia todos los campos y datagrid's del panel de Fcaturacion
    Public Sub Limpiar()
        checkTarifa.Checked = False
        checkConsignacion.Checked = False
        checkPago.Checked = False
        celdaAño.Text = -1
        celdaNumero.Text = -1
        celdaDireccion.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
        celdaFecha.Text = Now()
        celdaTelefono.Text = STR_VACIO
        celdaNIT.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        dgPedidos.Rows.Clear()
        celdaObservaciones.Text = STR_VACIO
        rbOpcionPagoSI.Checked = False
        rbOpcionPagoNO.Checked = False
        dgDetalle.Rows.Clear()
        celdaTotal.Text = STR_VACIO
        celdaSubTotal.Text = STR_VACIO
        dgReferencias.Rows.Clear()
        dgbultos1.Rows.Clear()
        celdaUsuario.Text = STR_VACIO
        intCambio = vbEmpty
        celdaComentario.Text = STR_VACIO
        celdaDetalle.Text = STR_VACIO
        If Sesion.idGiro = 2 Then
            checkFibra.Visible = True
            checkFibra.Checked = False
            dgDetalle.Columns("collibrasAdicionales").Visible = False
        Else
            checkFibra.Visible = False
            checkFibra.Checked = False
            dgDetalle.Columns("collibrasAdicionales").Visible = False
        End If
    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha,HDoc_Emp_Cod Codigo, HDoc_Emp_Nom Nombre, HDoc_emp_Dir Direccion, HDoc_Emp_Tel Telefono, HDoc_Emp_Nit NIT, HDoc_Doc_TC Tasa, HDoc_DR1_Num Referencia, IFNULL(HDoc_RF1_Txt,'') Observaciones, HDoc_Doc_Status Estado, HDoc_Usuario usuario, HDoc_Doc_Ano Ano, IFNULL(HDoc_DR1_Cat,0) Control, IFNULL(("
        strsql &= "  SELECT COUNT(*)"
        strsql &= "   FROM Dcmtos_DTL_Pro"
        strsql &= "     WHERE PDoc_Sis_Emp=HDoc_Sis_Emp AND PDoc_Par_Cat=HDoc_Doc_Cat AND PDoc_Par_Ano=HDoc_Doc_Ano AND PDoc_Par_Num=HDoc_Doc_Num AND PDoc_Chi_Cat=36"
        strsql &= "         LIMIT 1),0) Relacion, IFNULL(HDoc_RF2_Cod,0)Carga, HDoc_Pro_DAno Consignacion "
        strsql &= "      FROM Dcmtos_HDR"
        strsql &= "    WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=48"

        If checkFecha.Checked = True Then

            strsql &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "  ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim e As Integer
        Dim c As Integer
        Dim r As Integer
        Dim ch As Integer
        Dim cn As Integer

        strSQL = SQLlista()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Numero") & "|" & REA.GetDateTime("Fecha") & "|" & REA.GetInt32("Codigo") & "|" & REA.GetString("Nombre") & "|" & REA.GetString("Referencia") & "|" & REA.GetString("Observaciones") & "|" &
                              REA.GetInt32("Estado") & "|" & REA.GetInt32("Ano") & "|" & REA.GetInt32("Control") & "|" & REA.GetInt32("Relacion") & "|" & REA.GetInt32("Carga") & "|" & REA.GetString("Direccion") & "|" &
                              REA.GetString("Telefono") & "|" & REA.GetString("NIT") & "|" & REA.GetDouble("Tasa")

                    e = REA.GetInt32("Estado")
                    c = REA.GetInt32("Control")
                    r = REA.GetInt32("Relacion")
                    ch = REA.GetInt32("Carga")
                    cn = REA.GetInt32("Consignacion")

                    AgregarFila(dgLista, strFila, e, c, r, ch, cn)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer, ByVal Control As Integer, ByVal Relacion As Integer, ByVal Carga As Integer, ByVal Consignacion As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Estado = 0 Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Red
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                Else
                    If Control > 0 Then
                        If i = 0 Then
                            Celda.Style.BackColor = Color.Yellow
                            'Else
                            '    Celda.Style.BackColor = Color.White
                        End If
                    End If
                    If Relacion = vbEmpty Then
                        If i = 1 Then
                            Celda.Style.BackColor = Color.Orange
                            'Else
                            '    Celda.Style.BackColor = Color.White
                        End If
                        If Carga = 0 Then
                            If Consignacion = 1 Then
                                If i = 3 Then
                                    Celda.Style.BackColor = Color.GreenYellow
                                End If
                            Else
                                If i = 3 Then
                                    Celda.Style.BackColor = Color.Cyan
                                End If
                            End If

                        End If
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista Detalle
    Private Function SQLDetalle() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT a.DDoc_Prd_Cif LibrasAdicionales, b.PDoc_Par_Ano Ano, b.PDoc_Par_Num Numero, b.PDoc_Par_Lin Linea,b.PDoc_Chi_Lin Linea2, a.DDoc_RF1_Fec Fecha, a.DDoc_Prd_Cod codigo, a.DDoc_Prd_Des descripcion, c.cat_clave medida, a.DDoc_Prd_NET precio, a.DDoc_Prd_DSQ pedido, a.DDoc_Prd_DSP existencia, IF(a.DDoc_RF3_Dbl=0,a.DDoc_Prd_QTY,a.DDoc_RF3_Dbl) conversion, a.DDoc_RF1_Dbl pendiente, a.DDoc_RF1_Txt referencia, COALESCE(l.cli_cliente,'')"
        strsql &= "     lugar, a.DDoc_RF1_Num destino, a.DDoc_RF1_Cod original, a.DDoc_RF2_Txt datos, a.DDoc_Prd_UM unidad, a.DDoc_Prd_PNr parte, COALESCE(a.DDoc_RF3_Num, a.DDoc_Prd_UM) base, a.DDoc_Prd_QTY cantidad, box.BDoc_Box_QTY cantidadBulto, IFNULL(a.DDoc_RF2_Cod,'') Observaciones,"
        strsql &= "         h.HDoc_Doc_Cat Tipo, h.HDoc_Doc_Ano AnoDesc, h.HDoc_Doc_Num NumeroDesc, h.HDoc_Doc_Fec FechaDesc, h.HDoc_DR1_Num Referencia, q.PDoc_Par_Lin LineaDesc, q .PDoc_Prd_Cod CodigoDesc, q.PDoc_QTY_Ord Disponible, q.PDoc_QTY_Pro Descargo, q.PDoc_Chi_Lin ID, q.PDoc_QTY_Pro Cantidad, IFNULL(("
        strsql &= "             SELECT n.ADoc_Dta_Txt"
        strsql &= "                 FROM Dcmtos_ACC n"
        strsql &= "                      WHERE n.ADoc_Sis_Emp=h.HDoc_Sis_Emp AND n.ADoc_Doc_Cat=h.HDoc_Doc_Cat AND n.ADoc_Doc_Ano=h.HDoc_Doc_Ano AND n.ADoc_Doc_Num=h.HDoc_Doc_Num AND n.ADoc_Doc_Sub='Doc_DIngreso' AND n.ADoc_Doc_Lin='04'"
        strsql &= "                          LIMIT 1),'') nota1, IFNULL(df.DDoc_RF1_Txt,'') nota2"
        strsql &= "                              FROM Dcmtos_DTL a"
        strsql &= "                                 LEFT JOIN Dcmtos_DTL_Pro b ON b.PDoc_Par_Cat = 75 AND b.PDoc_Chi_Cat = a.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = a.DDoc_Doc_Ano AND b.PDoc_Chi_Num = a.DDoc_Doc_Num AND b.PDoc_Chi_Lin = a.DDoc_Doc_Lin"
        strsql &= "                                     LEFT JOIN Catalogos c ON c.cat_num = COALESCE(a.DDoc_RF3_Num,a.DDoc_Prd_UM) AND c.cat_clase = 'Medidas'"
        strsql &= "                                 LEFT JOIN Inventarios i ON i.inv_numero = a.DDoc_Prd_Cod AND i.inv_sisemp = a.DDoc_Sis_Emp"
        strsql &= "                              LEFT JOIN Clientes l ON l.cli_sisemp = a.DDoc_Sis_Emp AND l.cli_codigo = a.DDoc_RF1_Num"
        strsql &= "                          LEFT JOIN Dcmtos_DTL_Box box ON box.BDoc_Sis_Emp = a.DDoc_Sis_Emp AND box.BDoc_Doc_Cat = a.DDoc_Doc_Cat AND box.BDoc_Doc_Ano = a.DDoc_Doc_Ano AND box.BDoc_Doc_Num= a.DDoc_Doc_Num AND box.BDoc_Doc_Lin =a.DDoc_Doc_Lin"
        strsql &= "                      LEFT JOIN Dcmtos_DTL_Pro q ON q.PDoc_Par_Cat = 47 AND q.PDoc_Chi_Cat = a.DDoc_Doc_Cat AND q.PDoc_Chi_Ano = a.DDoc_Doc_Ano AND q.PDoc_Chi_Num = a.DDoc_Doc_Num AND q.PDoc_Chi_Lin = a.DDoc_Doc_Lin"
        strsql &= "                 INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = q.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = q.PDoc_Par_Cat AND h.HDoc_Doc_Ano = q.PDoc_Par_Ano AND h.HDoc_Doc_Num = q.PDoc_Par_Num"
        strsql &= "             INNER JOIN Dcmtos_DTL df ON df.DDoc_Sis_Emp = q.PDoc_Sis_Emp AND df.DDoc_Doc_Cat = q.PDoc_Par_Cat AND df.DDoc_Doc_Ano = q.PDoc_Par_Ano AND df.DDoc_Doc_Num = q.PDoc_Par_Num AND df.DDoc_Doc_Lin = q.PDoc_Par_Lin"
        strsql &= "         WHERE a.DDoc_Doc_Cat = 48 AND a.DDoc_Sis_Emp = {empresa} AND a.DDoc_Doc_Ano = {año} AND a.DDoc_Doc_Num = {numero}"
        strsql &= "      GROUP BY a.DDoc_Doc_Ano, a.DDoc_Doc_Num, a.DDoc_Doc_Lin"
        strsql &= "   ORDER BY a.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", Val(celdaAño.Text))
        strsql = Replace(strsql, "{numero}", Val(celdaNumero.Text))

        Return strsql
    End Function

    'Procedimiento para CargardgDetalle 
    Public Sub queryDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim k As Integer = 0
        Dim contarBultos As Integer = 0

        strSQL = SQLDetalle()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()
                Dim intID As Integer
                Dim i As Integer = 0
                Dim contador As Integer
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    contarBultos = 0
                    contador = i
                    strFila = REA.GetInt32("Ano") & "|"
                    strFila &= 75 & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("existencia") & "|"
                    strFila &= REA.GetDouble("pedido").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("conversion").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("LibrasAdicionales").ToString(FORMATO_MONEDA) & "|"
                    If (Sesion.idGiro = 2) Then
                        For k = 0 To dgbultos1.Rows.Count - 1
                            If REA.GetInt32("ID") = dgbultos1.Rows(k).Cells("colLineaDet").Value Then
                                contarBultos = contarBultos + 1
                            End If
                        Next
                        strFila &= contarBultos & "|"
                    Else
                        strFila &= REA.GetInt32("cantidadBulto") & "|"
                    End If

                    strFila &= REA.GetDouble("pendiente").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetString("lugar") & "|"
                    strFila &= REA.GetInt32("destino") & "|"
                    strFila &= REA.GetInt32("original") & "|"
                    strFila &= REA.GetString("datos") & "|"
                    strFila &= REA.GetString("parte") & "|"
                    strFila &= REA.GetInt32("Linea2") & "|"
                    i = i + 1
                    contador = contador + i
                    strFila &= REA.GetInt32("unidad") & "|"
                    strFila &= REA.GetInt32("base") & "|"
                    strFila &= REA.GetInt32("Cantidad") & "|"
                    strFila &= REA.GetInt32("Pedido") & "|"
                    strFila &= REA.GetInt32("Original") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("Observaciones") & "|"
                    strFila &= REA.GetInt32("ID") & "|"
                    strFila &= REA.GetInt32("AnoDesc") & "|"
                    strFila &= REA.GetInt32("Tipo") & "|"
                    strFila &= REA.GetInt32("NumeroDesc") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("FechaDesc") & "|"
                    strFila &= PolizaDeIngreso(REA.GetInt32("AnoDesc"), REA.GetInt32("NumeroDesc")) & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("LineaDesc") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    If REA.GetString("medida") = "LBS" Then
                        strFila &= 69 & "|"
                    Else
                        strFila &= 70 & "|"
                    End If
                    strFila &= REA.GetDouble("Descargo") & "|"
                    strFila &= (REA.GetDouble("Existencia") - REA.GetDouble("Descargo")) & "|"
                    strFila &= REA.GetString("nota1") & "|"
                    strFila &= REA.GetString("nota2")

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista de DocumentosParaProcesar
    Private Function SQLDocParaProcesar() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT DISTINCT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat catalogo, e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num pf, e.HDoc_Doc_Fec fecha, COALESCE(e.HDoc_DR1_Num,'') numero, e.HDoc_Usuario usuario, IFNULL(e.HDoc_DR2_Emp,0) Impuesto"
        strSQL &= "  FROM Dcmtos_HDR e"
        strSQL &= "      LEFT JOIN Dcmtos_DTL d ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strSQL &= "          WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 75 AND e.HDoc_Emp_Cod = {cliente} AND e.HDoc_Doc_Status = {activo} and e.HDoc_Doc_Fec<='{fechaFiltro}' AND d.DDoc_RF2_Num = {estado} AND (COALESCE(("
        strSQL &= "              SELECT SUM(c.DDoc_Prd_QTY)"
        strSQL &= "                  FROM Dcmtos_DTL c"
        strSQL &= "                      WHERE c.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND c.DDoc_Doc_Cat = d.DDoc_Doc_Cat AND c.DDoc_Doc_Ano = d.DDoc_Doc_Ano AND c.DDoc_Doc_Num = d.DDoc_Doc_Num AND c.DDoc_Prd_Cod = d.DDoc_Prd_Cod),0) > COALESCE(("
        If Sesion.idGiro = 1 Then
            strSQL &= "                          SELECT SUM(p.PDoc_QTY_Pro)"
        Else
            strSQL &= "                          SELECT ROUND(SUM(p.PDoc_QTY_Pro),2)"
        End If
        strSQL &= "                       FROM Dcmtos_DTL_Pro p"
        strSQL &= "                    WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0))"
        strSQL &= "               ORDER BY e.HDoc_Doc_Ano ASC, e.HDoc_Doc_Num ASC"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cliente}", celdaIDCliente.Text)
        strSQL = Replace(strSQL, "{activo}", 1)
        strSQL = Replace(strSQL, "{estado}", vbEmpty)
        strSQL = Replace(strSQL, "{fechaFiltro}", Format(CDate(celdaFecha.Text), "yyyy-MM-dd"))


        Return strSQL
    End Function

    'Query de Verificacion en Inventario
    Private Function SqlVerificacionInventario(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intLinea As Integer, ByVal intNumInstruccion As Integer, ByVal intAnoInstruccion As Integer, ByVal intLineaInstruccion As Integer) As String
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "   SELECT ROUND(SUM(b.DDoc_Prd_QTY) - COALESCE(("
            strSQL &= "      SELECT SUM(c.PDoc_QTY_Pro)"
            strSQL &= "          FROM Dcmtos_DTL_Pro c"
            strSQL &= "              WHERE c.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND c.PDoc_Par_Cat = a.HDoc_Doc_Cat AND c.PDoc_Par_Ano = a.HDoc_Doc_Ano AND c.PDoc_Par_Num = a.HDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND NOT (c.PDoc_Chi_Cat = 48 AND c.PDoc_Chi_Num = {numInst} AND c.PDoc_Chi_Ano = {AnoInst} AND c.PDoc_Chi_Lin ={LineaInst})), 0),2) Saldo"
            strSQL &= "          FROM Dcmtos_HDR a"
            strSQL &= "       INNER JOIN Dcmtos_DTL b ON b.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND b.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND b.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND b.DDoc_Doc_Num = a.HDoc_Doc_Num"
            strSQL &= "     WHERE a.HDoc_Sis_Emp = {empresa} AND a.HDoc_Doc_Cat = 47 AND a.HDoc_Doc_Ano = {anio} AND a.HDoc_Doc_Num = {numero} AND b.DDoc_Doc_Lin = {linea}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", intAnio)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{linea}", intLinea)
            strSQL = Replace(strSQL, "{numInst}", intNumInstruccion)
            strSQL = Replace(strSQL, "{AnoInst}", intAnoInstruccion)
            strSQL = Replace(strSQL, "{LineaInst}", intLineaInstruccion)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function

    Private Function SQLDocProcesados() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT DISTINCT HDoc_Doc_Num PF, HDoc_Doc_Fec Fecha, HDoc_Usuario Usuario, HDoc_DR1_Num Numero, HDoc_Doc_Ano Ano, IFNULL(HDoc_DR2_Emp,0) Impuesto"
        strsql &= "  FROM Dcmtos_DTL_Pro a"
        strsql &= "   INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num"
        strsql &= "         WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Par_Cat = 75 AND a.PDoc_Chi_Cat = 48 AND a.PDoc_Chi_Ano = {año} AND a.PDoc_Chi_Num = {numero}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", Val(celdaAño.Text))
        strsql = Replace(strsql, "{numero}", Val(celdaNumero.Text))

        Return strsql

    End Function

    Private Function SQLCargarBultos()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT IFNULL(p.BPDoc_Par_Num,0) Numero, p.BPDoc_Par_Lin Linea, d.BDoc_Box_Lin Bulto, B47.BDOC_BOX_HSM BultoVista, dd.DDoc_Prd_Cod productoCod, dd.DDoc_Prd_Des Marca, d.BDoc_Box_Ctg Categoria, d.BDoc_Box_LB peso, p.BPDoc_Par_Cat catalogo, p.BPDoc_Par_Ano anio,p.BPDoc_Chi_Lin ChiLin "
        strSQL &= "    From Dcmtos_DTL_Box d "
        strSQL &= "        Left JOIN Dcmtos_DTL_Box_Pro p ON p.BPDoc_Sis_Emp = d.BDoc_Sis_Emp AND p.BPDoc_Chi_Cat = d.BDoc_Doc_Cat  AND p.BPDoc_Chi_Ano = d.BDoc_Doc_Ano AND p.BPDoc_Chi_Num = d.BDoc_Doc_Num AND p.BPDoc_Chi_Lin = d.BDoc_Doc_Lin AND p.BPDoc_Box_Lin = d.BDoc_Box_lin "
        strSQL &= "        LEFT JOIN Dcmtos_DTL_Box B47 ON B47.BDoc_Sis_Emp = p.BPDoc_Sis_Emp AND B47.BDoc_Doc_Cat =   p.BPDoc_Par_Cat AND B47.BDoc_Doc_Ano =   p.BPDoc_Par_Ano AND B47.BDoc_Doc_Num =   p.BPDoc_Par_Num AND B47.BDoc_Doc_Lin =   p.BPDoc_Par_Lin AND B47.BDoc_Box_Lin =   p.BPDoc_Box_Lin "
        strSQL &= "Left Join Dcmtos_DTL dd ON dd.DDoc_Sis_Emp=d.BDoc_Sis_Emp And dd.DDoc_Doc_Cat=d.BDoc_Doc_Cat And dd.DDoc_Doc_Ano=d.BDoc_Doc_Ano And dd.DDoc_Doc_Num=d.BDoc_Doc_Num And dd.DDoc_Doc_Lin=d.BDoc_Doc_Lin"

        strSQL &= "            WHERE d.BDoc_Sis_Emp = {empresa} AND d.BDoc_Doc_Cat = 48 AND d.BDoc_Doc_Ano = {anio} AND d.BDoc_Doc_Num = {numero} "
        strSQL &= "               ORDER BY d.BDoc_Doc_Num, d.BDoc_Doc_Lin, d.BDoc_Box_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", dgLista.SelectedCells(7).Value)
        strSQL = Replace(strSQL, "{numero}", dgLista.SelectedCells(0).Value)

        Return strSQL

    End Function

    'Procedimiento para Cargar Documentos Procesado
    Public Sub queryDocProcesados()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLDocProcesados()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgPedidos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("PF") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Numero") & "|"
                    strFila &= REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetInt32("Impuesto") & "|"
                    strFila &= 2

                    cFunciones.AgregarFila(dgPedidos, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Instruction Dispatch")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            queryListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
                botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Private Sub CargarBultos()
        Dim strsql As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strFila As String = STR_VACIO

        Try
            strsql = SQLCargarBultos()


            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgbultos1.Rows.Clear()
                dgBultosInicio.Rows.Clear()


                Do While REA.Read
                    If REA.GetInt32("Numero") = 0 Then
                        Exit Do
                    End If
                    strFila = REA.GetInt32("catalogo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("Bulto") & "|"
                    strFila &= REA.GetInt32("BultoVista") & "|"
                    strFila &= REA.GetInt32("productoCod") & "|"
                    strFila &= REA.GetString("Marca") & "|"
                    strFila &= REA.GetString("Categoria") & "|"
                    strFila &= REA.GetDouble("peso") & "|"
                    strFila &= REA.GetInt32("ChiLin") & "|"
                    strFila &= 1

                    cFunciones.AgregarFila(dgbultos1, strFila)
                    cFunciones.AgregarFila(dgBultosInicio, strFila)


                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Seleccionar(ByVal intaño As Integer, ByVal intnumero As Integer)
        SeleccionarCliente(intaño, intnumero)
        'SeleccionarSubdocumentos(año, numero)

    End Sub

    Private Sub SeleccionarCliente(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim HDR As New clsDcmtos_HDR
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CA As New clsCatalogos
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Try
            strSQL = " SELECT HDoc_RF1_Dbl traslado_, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Tel, HDoc_Emp_NIT, HDoc_Doc_Tc, "
            strSQL &= "     HDoc_Doc_Status, HDoc_RF1_Txt, HDoc_DR2_Emp, HDoc_RF2_Cod,HDoc_Usuario, HDoc_Doc_Mon, Hdoc_DR1_Cat, HDoc_RF1_Num, HDoc_RF2_Num, HDoc_RF2_Txt, HDoc_DR1_Emp, HDoc_RF1_Cod, HDoc_DR2_Cat, "
            strSQL &= "         HDoc_Pro_DAno, HDoc_Pro_DNum, HDoc_Ant_Com,c.cat_clave,co.cat_clave Costeo "
            strSQL &= "             FROM Dcmtos_HDR "
            strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
                        strsql &= "                     LEFT JOIN Catalogos co ON co.cat_num = HDoc_DR2_Cat AND co.cat_clase = 'Costeo' "
            strSQL &= "                         WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 48 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", intaño)
            strSQL = Replace(strSQL, "{numero}", intnumero)
            'strCampos = " HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Tel, HDoc_Emp_NIT, HDoc_Doc_Tc, HDoc_Doc_Status, HDoc_RF1_Txt, HDoc_DR2_Emp, HDoc_RF2_Cod,HDoc_Usuario, HDoc_Doc_Mon, Hdoc_DR1_Cat, HDoc_RF1_Num, HDoc_RF2_Num, HDoc_RF2_Txt, HDoc_DR1_Emp, HDoc_RF1_Cod, HDoc_DR2_Cat , HDoc_Pro_DAno, HDoc_Pro_DNum, HDoc_Ant_Com "
            'strCondicion = " HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 48 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
            'strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            'strCondicion = Replace(strCondicion, "{año}", intaño)
            'strCondicion = Replace(strCondicion, "{numero}", intnumero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaAño.Text = REA.GetInt32("HDOc_Doc_Ano")
                    celdaNumero.Text = REA.GetInt32("HDoc_Doc_Num")
                    celdaFecha.Text = REA.GetDateTime("HDoc_Doc_Fec").ToString(FORMATO_MYSQL)
                    celdaIDCliente.Text = REA.GetInt32("HDoc_Emp_Cod")
                    celdaCliente.Text = REA.GetString("HDoc_Emp_Nom")
                    celdaDireccion.Text = REA.GetString("HDoc_Emp_Dir")
                    celdaTelefono.Text = REA.GetString("HDoc_Emp_Tel")
                    celdaNIT.Text = REA.GetString("HDoc_Emp_NIT")
                    celdaTasa.Text = REA.GetDouble("HDoc_Doc_Tc")
                    celdaObservaciones.Text = REA.GetString("HDoc_RF1_Txt")
                    celdaDetalle.Text = REA.GetString("HDoc_RF1_Cod")
                    If REA.GetString("HDoc_RF2_Cod") = "NULL" Then
                        CeldaCarga.Text = vbEmpty
                    Else
                        CeldaCarga.Text = REA.GetString("HDoc_RF2_Cod")
                    End If
                    'Tarifa Muestra
                    If REA.GetInt32("HDoc_Ant_Com") = 1 Then
                        checkTarifa.Checked = True
                    Else
                        checkTarifa.Checked = False
                    End If
                    celdaEmpresa.Text = Sesion.IdEmpresa
                    celdaCatalogo.Text = 48
                    celdaUsuario.Text = REA.GetString("HDoc_Usuario")
                    celdaMoneda.Text = REA.GetString("cat_clave")
                    celdaIDMoneda.Text = REA.GetInt32("HDoc_Doc_Mon")
                    'Proceso del Costeo
                    If REA.GetInt32("HDoc_DR2_Cat") = 0 Then
                        celdaIdCosteo.Text = INT_CERO
                        celdaCosteo.Text = STR_VACIO
                    Else
                        If REA.GetString("Costeo") <> STR_VACIO Then
                            celdaIdCosteo.Text = REA.GetInt32("HDoc_DR2_Cat")
                            celdaCosteo.Text = REA.GetString("Costeo")
                        Else
                            celdaIdCosteo.Text = INT_CERO
                            celdaCosteo.Text = STR_VACIO
                        End If
                    End If
                    If REA.GetInt32("HDoc_Doc_Status") = 1 Then
                        checkActivar.Checked = True
                        checkActivar.Enabled = True
                    Else
                        checkActivar.Checked = False
                        checkActivar.Enabled = False
                    End If
                    If Sesion.idGiro = 2 Then

                        rbOpcionPagoNO.Checked = True
                        rbOpcionPagoSI.Checked = False
                        rbOpcionPagoNO.ForeColor = Color.Blue

                    Else
                        If REA.GetInt32("HDoc_DR1_Emp") = 0 Then
                            rbOpcionPagoNO.Checked = True
                            rbOpcionPagoSI.Checked = False
                            rbOpcionPagoNO.ForeColor = Color.Blue
                        Else
                            rbOpcionPagoSI.Checked = True
                            rbOpcionPagoNO.Checked = False
                            rbOpcionPagoSI.ForeColor = Color.Red
                        End If
                    End If
                    intCambio = REA.GetInt32("HDoc_DR1_Cat")
                    If REA.GetInt32("HDoc_Pro_DAno") = INT_UNO Then
                        checkConsignacion.Checked = True
                    Else
                        checkConsignacion.Checked = False
                    End If
                    If REA.GetInt32("HDoc_Pro_DNum") = INT_UNO Then
                        checkPago.Checked = True
                    Else
                        checkPago.Checked = False
                    End If
                    logBloquear = False
                    If SqlDependientes() > vbEmpty Then
                        logBloquear = True
                    End If
                    If REA.GetInt32("HDoc_RF1_Num") = INT_CERO Then
                        rbFleteEmpresa.Checked = True
                        rbFleteOtro.Checked = False
                        rbFleteCliente.Checked = False
                    ElseIf REA.GetInt32("HDoc_RF1_Num") = INT_UNO Then
                        rbFleteCliente.Checked = False
                        rbFleteOtro.Checked = True
                        rbFleteEmpresa.Checked = False
                    Else
                        rbFleteOtro.Checked = False
                        rbFleteEmpresa.Checked = False
                        rbFleteCliente.Checked = True
                    End If
                    If REA.GetInt32("HDoc_RF2_Num") = INT_CERO Then
                        rbGastosEmpresa.Checked = True
                        rbGastosOtros.Checked = False
                        rbGastosCliente.Checked = False
                    ElseIf REA.GetInt32("HDoc_RF2_Num") = INT_UNO Then
                        rbGastosCliente.Checked = False
                        rbGastosEmpresa.Checked = False
                        rbGastosOtros.Checked = True
                    Else
                        rbGastosOtros.Checked = False
                        rbGastosCliente.Checked = True
                        rbGastosEmpresa.Checked = False
                    End If
                    If REA.GetInt32("traslado_") = INT_UNO Then
                        checkTraslado.Checked = True
                    Else
                        checkTraslado.Checked = False
                    End If
                    celdaComentario.Text = REA.GetString("HDoc_RF2_Txt")
                    dgDetalle.ReadOnly = logBloquear
                Loop
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Function SqlDependientes() As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Dependientes As Integer = vbEmpty

        Try
            strSQL = "Select"
            strSQL &= "  count(*)"
            strSQL &= "     FROM"
            strSQL &= "         Dcmtos_DTL_Pro a"
            strSQL &= "              WHERE a.PDoc_Sis_Emp = {empresa}   AND a.PDoc_Par_Cat = 48  AND a.PDoc_Par_Ano ={año}  AND a.PDoc_Par_Num ={numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Dependientes = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Dependientes
    End Function

    'Devuelve la póliza para un documento de ingreso
    Private Function PolizaDeIngreso(ByVal Ciclo As String, ByVal Numero As String) As String
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Poliza As String

        strSQL = "SELECT Distinct(a.ADoc_Dta_Chr) Poliza"
        strSQL &= "  FROM Dcmtos_DTL_Pro p"
        strSQL &= "      INNER JOIN Catalogos c ON c.cat_num = p.PDoc_Par_Cat AND c.cat_clase = 'Documentos'"
        strSQL &= "          INNER JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp = p.PDoc_Sis_Emp AND a.ADoc_Doc_Cat = p.PDoc_Par_Cat AND a.ADoc_Doc_Ano = p.PDoc_Par_Ano AND a.ADoc_Doc_Num = p.PDoc_Par_Num"
        strSQL &= "      WHERE p.PDoc_Sis_Emp ={empresa} AND p.PDoc_Chi_Cat =47 AND p.PDoc_Chi_Ano ={año} AND p.PDoc_Chi_Num ={numero} AND c.cat_sist = 'Doc_ODesImp' AND a.ADoc_Doc_Lin = '01'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Poliza = COM.ExecuteScalar
        conec.Close()

        Return Poliza
    End Function

    Private Sub DocumentosPendientes()
        Me.Tag = "Nuevo"
        Dim strSQL As String
        Dim strTemp As String
        Dim intAño As Integer
        Dim intNumero As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim i As Integer

        intAño = celdaAño.Text
        intNumero = celdaNumero.Text
        'dgInstrucDespacho.ColumnCount = vbEmpty
        If Me.Tag = "Mod" Then
            'strSQL = SQLDocProcesados()
        Else
            strSQL = SQLDocParaProcesar()
        End If

        'Agrega todos los registros de la selección
        MyCnn.CONECTAR = strConexion
        Try

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    strTemp = vbNullString
                    strTemp &= REA.GetInt32("pf") & "|"
                    strTemp &= REA.GetDateTime("fecha") & "|"
                    strTemp &= REA.GetString("usuario") & "|"
                    strTemp &= REA.GetString("numero") & "|"
                    strTemp &= REA.GetInt32("anio") & "|"
                    strTemp &= REA.GetInt32("impuesto") & "|"
                    strTemp &= 1

                    i = REA.GetInt32("impuesto")


                    AgregarFilaDocPendientes(dgPedidos, strTemp, i)
                Loop
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub AgregarFilaDocPendientes(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Impuesto As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Impuesto = 1 Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Violet
                        'Else
                        '    Celda.Style.BackColor = Color.White
                    End If
                End If
                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Genera la consulta de facturas con saldo o que ya están incluídas
    Private Function SqlReferencias(ByVal EsGenerico As Boolean, ByVal Codigo As String, ByVal Articulo As String, ByRef Info As String)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim REA As MySqlDataReader


        'NOTA: intCurRef = ingreso a bodega
        strSQL = "SELECT a.HDoc_Doc_Cat Tipo, a.HDoc_Doc_Ano Anio, a.HDoc_Doc_Num Numero, b.DDoc_Doc_Lin Linea, a.HDoc_Doc_Fec Fecha, a.HDoc_DR1_Num Referencia, p.cat_desc pais,  b.DDoc_Prd_Cod Codigo, m.cat_clave Medida, m.cat_num Unidad, SUM(b.DDoc_Prd_QTY) - COALESCE(("
        strSQL &= "  SELECT SUM(c.PDoc_QTY_Pro)"
        strSQL &= "      FROM Dcmtos_DTL_Pro c"
        strSQL &= "          WHERE c.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND c.PDoc_Par_Cat = a.HDoc_Doc_Cat AND c.PDoc_Par_Ano = a.HDoc_Doc_Ano AND c.PDoc_Par_Num = a.HDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin), 0) Saldo, IFNULL(("
        strSQL &= "              SELECT n.ADoc_Dta_Txt"
        strSQL &= "                  FROM Dcmtos_ACC n"
        strSQL &= "                     WHERE n.ADoc_Sis_Emp=a.HDoc_Sis_Emp AND n.ADoc_Doc_Cat=a.HDoc_Doc_Cat AND n.ADoc_Doc_Ano=a.HDoc_Doc_Ano AND n.ADoc_Doc_Num=a.HDoc_Doc_Num AND n.ADoc_Doc_Sub='Doc_DIngreso' AND n.ADoc_Doc_Lin='04'"
        strSQL &= "                              LIMIT 1),'') nota1, IFNULL(b.DDoc_RF1_Txt,'') nota2, IFNULL(("
        strSQL &= "                          SELECT SUM(v.cantidad) Cantidad"
        strSQL &= "                      FROM Reserva v"
        strSQL &= "                  WHERE v.id_empresa=b.DDoc_Sis_Emp AND v.doc_tipo=b.DDoc_Doc_Cat AND v.doc_ciclo=b.DDoc_Doc_Ano AND v.doc_num=b.DDoc_Doc_Num AND v.doc_lin=b.DDoc_Doc_Lin AND NOT(v.estado=2)),0) Reservado"
        strSQL &= "              FROM Dcmtos_HDR a"
        strSQL &= "           INNER JOIN Dcmtos_DTL b ON b.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND b.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND b.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND b.DDoc_Doc_Num = a.HDoc_Doc_Num"
        strSQL &= "              LEFT JOIN Inventarios d ON d.inv_numero = b.DDoc_Prd_Cod AND d.inv_sisemp = b.DDoc_Sis_Emp"
        strSQL &= "         LEFT JOIN Catalogos  p on p.cat_num = d.inv_lugarfab"
        strSQL &= "       LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = b.DDoc_Prd_UM"
        strSQL &= "     WHERE a.HDoc_Sis_Emp = {empresa} AND a.HDoc_Doc_Cat = 47 AND a.HDoc_Doc_Fec <='{fec}' AND "


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", dgDetalle.SelectedCells(5).Value)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{lugar}", dgDetalle.SelectedCells(16).Value)
        strSQL = Replace(strSQL, "{linea}", dgDetalle.SelectedCells(3).Value)
        strSQL = Replace(strSQL, "{fec}", Format(CDate(celdaFecha.Text), "yyyy-MM-dd"))

        'Información del producto
        Info = vbNullString

        'Si es genérico carga todos los artículos similares
        If EsGenerico Then
            strSQL = strSQL & "d.inv_artcodigo = " & Articulo & ""

            Dim strQuery As String

            'Agrega a la cláusula WHERE las características del genérico
            strQuery = "Select COALESCE(inv_provcod,-1)  provcod,COALESCE(inv_lugarfab,-1) lugarfab, COALESCE(inv_prodlote,'') prodlote"
            strQuery &= "   FROM Inventarios"
            strQuery &= "       WHERE inv_sisemp= {empresa} AND inv_numero= " & Codigo & ""

            strQuery = Replace(strQuery, "{empresa}", Sesion.IdEmpresa)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strQuery, CON)
            REA = COM.ExecuteReader
            REA.Read()

            'Fabricante
            Dim Fab As String
            Dim strSQL2 As String = STR_VACIO
            If REA.GetInt32("provcod") > vbEmpty Then
                strSQL = strSQL & " AND inv_provcod = " & REA.GetInt32("provcod")

                strSQL2 = "SELECT pro_proveedor "
                strSQL2 &= "  FROM Proveedores"
                strSQL2 &= "      WHERE pro_sisemp={empresa} AND pro_codigo=" & REA.GetInt32("provcod") & ""
                strSQL2 &= "  LIMIT 1"

                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL2, conec)
                Fab = COM.ExecuteScalar
                conec.Close()
                Info = "Proveedor: " & Fab
            End If

            'Lugar de fabricación
            Dim Lugfab As String
            Dim strSQL3 As String = STR_VACIO
            If (REA.GetInt32("lugarfab") >= vbEmpty) Then
                strSQL3 = "SELECT cat_desc"
                strSQL3 &= "   FROM Catalogos"
                strSQL3 &= "      WHERE cat_num=" & REA.GetString("lugarfab") & ""
                strSQL3 &= "  LIMIT 1"

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL3, conec)
                Lugfab = COM.ExecuteScalar
                conec.Close()

                strSQL = strSQL & " AND inv_lugarfab=" & REA.GetString("lugarfab")
                Info = Info & IIf(Info = vbNullString, vbNullString, vbCr) &
                "Lugar de Fabricación: " & Lugfab
            End If

            'Lote de producción
            If Not (REA.GetString("prodlote") = vbNullString) Then
                strSQL = strSQL & " AND inv_prodlote=" & "'" & REA.GetString("prodlote") & "'"
                Info = Info & IIf(Info = vbNullString, vbNullString, vbCr) &
                "Lote de Producción: " & REA.GetString("prodlote")
            End If
        Else
            strSQL = strSQL & " b.DDoc_Prd_Cod=" & Codigo & ""
        End If

        'NOTA: Sólo se muestran líneas con más de 0.9 de saldo
        strSQL = strSQL & " Group By a.HDoc_Doc_Ano,  a.HDoc_Doc_Num, b.DDoc_Doc_Lin"
        If Sesion.idGiro = 2 Then
            strSQL &= "     HAVING  Saldo > 0"
        Else
            strSQL &= "     HAVING  Saldo > 0.05"
        End If

        strSQL &= "         ORDER BY  a.HDoc_DR1_Num, a.HDoc_Doc_Ano,  a.HDoc_Doc_Num"

        'Devuelve la consulta
        SqlReferencias = strSQL
    End Function

    'Carga a la ventana de referencias el listado actual
    Private Sub CargarListadoActual(ByRef frmDatos As frmFacturasRef_Aux_, ByVal Pedido As String, ByVal Fila As Integer)
        Dim i As Integer
        Dim j As Integer
        Dim strFila As String
        j = vbEmpty
        For i = vbEmpty To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                ' Exit For
            Else
                'Sólo para la línea del pedido actual
                If dgDetalle.Rows(i).Cells("colNPedidoDesc").Value = Pedido And
                    Val(dgDetalle.Rows(i).Cells("colLineaDesc").Value) = Fila Then

                    strFila = dgDetalle.Rows(i).Cells("colAnioDesc").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colNumDesc").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colFecha2").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colPolizaDesc").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colRefDesc").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colLinea2Desc").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colCodDesc").Value & "|"
                    'La existencia es igual a la existencia actual más la cantidad ya descargada
                    'strFila &= (CDbl(dgDetalle.Rows(i).Cells("colSaldoActual").Value) + (dgDetalle.Rows(i).Cells("colCantDescargo").Value)) & "|"
                    strFila &= (CDbl(dgDetalle.Rows(i).Cells("colSaldoActual").Value) + CDbl(dgDetalle.Rows(i).Cells("colCantDescargo").Value)).ToString("F2") & "|"

                    strFila &= dgDetalle.Rows(i).Cells("colMedDesc").Value & "|"
                    strFila &= dgDetalle.Rows(i).Cells("colUnidadDesc").Value & "|"
                    strFila &= (dgDetalle.Rows(i).Cells("colCantDescargo").Value) & "|"

                    ''Notas de documento y de línea
                    strFila &= (dgDetalle.Rows(i).Cells("colNota1Desc").Value) & "|"
                    strFila &= (dgDetalle.Rows(i).Cells("colNota2Desc").Value)

                    cfun.AgregarFila(frmDatos.dgLista, strFila)
                End If
            End If
        Next
    End Sub
    Private Sub CargarMedidaPF(ByVal codigo As Integer, ByVal ciclo As Integer)
        Dim strSQL As String
        Dim strFila As String
        Dim frmLista As New frmFacturasRef_Aux_
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "  SELECT c.cat_clave Medida "
        strSQL &= "     FROM  Dcmtos_DTL d "
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 75 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", ciclo)
        strSQL = Replace(strSQL, "{numero}", codigo)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                For i As Integer = 0 To frmLista.dgLista.Rows.Count - 1
                    frmLista.dgLista.Rows(i).Cells("colAño").Value = frmLista.dgLista.Rows(i).Cells("colAño").Value
                    frmLista.dgLista.Rows(i).Cells("colNumero").Value = frmLista.dgLista.Rows(i).Cells("colNumero").Value
                    frmLista.dgLista.Rows(i).Cells("colFecha").Value = frmLista.dgLista.Rows(i).Cells("colFecha").Value
                    frmLista.dgLista.Rows(i).Cells("colPoliza").Value = frmLista.dgLista.Rows(i).Cells("colPoliza").Value
                    frmLista.dgLista.Rows(i).Cells("colReferencia").Value = frmLista.dgLista.Rows(i).Cells("colReferencia").Value
                    frmLista.dgLista.Rows(i).Cells("colLinea").Value = frmLista.dgLista.Rows(i).Cells("colLinea").Value
                    frmLista.dgLista.Rows(i).Cells("colCodigo").Value = frmLista.dgLista.Rows(i).Cells("colCodigo").Value
                    frmLista.dgLista.Rows(i).Cells("colDisponible").Value = frmLista.dgLista.Rows(i).Cells("colDisponible").Value
                    frmLista.dgLista.Rows(i).Cells("colMedida").Value = frmLista.dgLista.Rows(i).Cells("colMedida").Value
                    frmLista.dgLista.Rows(i).Cells("colUnidad").Value = frmLista.dgLista.Rows(i).Cells("colUnidad").Value
                    frmLista.dgLista.Rows(i).Cells("colDescargo").Value = frmLista.dgLista.Rows(i).Cells("colDescargo").Value
                    frmLista.dgLista.Rows(i).Cells("colNota1").Value = frmLista.dgLista.Rows(i).Cells("colNota1").Value
                    frmLista.dgLista.Rows(i).Cells("colNota2").Value = frmLista.dgLista.Rows(i).Cells("colNota1").Value
                    frmLista.dgLista.Rows(i).Cells("colReserva").Value = frmLista.dgLista.Rows(i).Cells("colReserva").Value
                    frmLista.dgLista.Rows(i).Cells("colDetalle").Value = frmLista.dgLista.Rows(i).Cells("colDetalle").Value
                    frmLista.dgLista.Rows(i).Cells("colPF").Value = REA.GetString("Medida")
                    frmLista.dgLista.Rows(i).Cells("colFila").Value = frmLista.dgLista.Rows(i).Cells("colFila").Value
                Next
            Loop
        End If


    End Sub

    'Muestra el listado de documentos de referencia para descargo
    Private Sub MostrarReferencias(ByVal Codigo As String, ByVal EsGenerico As Boolean)
        'Código: código original (del pedido)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim frmLista As New frmFacturasRef_Aux_
        Dim strFila As String
        Dim descargo As Double

        Dim dblPedidoLbs As Double
        Dim dblPedidoKgs As Double
        Dim Valor1 As Integer
        Dim Valor2 As Integer

        Dim l As Integer = 0
        Dim i As Integer
        Dim j As Integer
        Dim intID As Integer
        Dim intMedida As Integer
        Dim intUnidad As Integer
        Dim intLinea As Integer      'Línea de la rejilla
        Dim intFila As Integer      'Línea del pedido

        Dim strArticulo As String = STR_VACIO
        Dim strInfo As String = STR_VACIO
        Dim strInfo1 As String = STR_VACIO
        Dim strCiclo As String = STR_VACIO
        Dim strPedido As String      'Número de pedido
        Dim strSQL As String = STR_VACIO
        Dim strSQL1 As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim dblExiste As Double
        Dim dblDescargo As Double
        Dim dblFactor As Double
        Dim dblPrecio As Double
        Dim dblValor As Double
        Dim Code As Integer
        Dim CodigoDesc As Integer
        Dim contador As Integer = 0

        Dim Medida As String = STR_VACIO
        Dim strSQL3 As String

        Dim logBloquear As Boolean

        Dim NumDescargo As Integer      'Numero del Descargo - X Linea -> InstDespacho
        Dim LineaDescargo As Integer      'Línea del pedido  Descargo X Linea -> InstDespacho


        Try

            'Recupera los datos de la fila actual
            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = True Then
                    intLinea = i
                End If
            Next


            intMedida = dgDetalle.Rows(intLinea).Cells("colBase").Value
            intUnidad = CInt(dgDetalle.Rows(intLinea).Cells("colUnit").Value)

            'Cantidad solicitada
            If intMedida = intKgs Then
                dblPedidoKgs = CDbl(dgDetalle.CurrentRow.Cells("colOrden").Value)
                If intUnidad = intLbs Then
                    dblPedidoLbs = CDbl(dgDetalle.CurrentRow.Cells("colPedido").Value)
                Else
                    dblPedidoLbs = (dblPedidoKgs / dblFactorLbs)
                End If
            ElseIf intMedida = intLbs Then
                dblPedidoLbs = CDbl(dgDetalle.CurrentRow.Cells("colOrden").Value)
                If intUnidad = intKgs Then
                    dblPedidoKgs = CDbl(dgDetalle.CurrentRow.Cells("colPedido").Value)
                Else
                    dblPedidoKgs = (dblPedidoLbs / dblFactorKgs)
                End If
            Else
                dblPedidoKgs = CDbl(dgDetalle.CurrentRow.Cells("colOrden").Value)
                dblPedidoLbs = dblPedidoKgs
            End If

            intID = CInt(dgDetalle.SelectedCells(21).Value)
            strCiclo = dgDetalle.SelectedCells(0).Value
            strPedido = dgDetalle.SelectedCells(2).Value
            intFila = dgDetalle.SelectedCells(3).Value
            Code = dgDetalle.SelectedCells(5).Value

            NumDescargo = dgDetalle.CurrentRow.Cells(32).Value
            'LineaDescargo = dgDetalle.CurrentRow.Cells(33).Value
            LineaDescargo = Convert.ToInt32(dgDetalle.SelectedRows(0).Cells("colLinea2Desc").Value)


            'Si es genérico obtiene el código de artículo
            If EsGenerico Then

                strSQL1 = "SELECT inv_artcodigo"
                strSQL1 &= "      FROM Inventarios"
                strSQL1 &= "          WHERE inv_sisemp={empresa} And inv_numero = {codigo}"

                strSQL1 = Replace(strSQL1, "{empresa}", Sesion.IdEmpresa)
                strSQL1 = Replace(strSQL1, "{codigo}", dgDetalle.SelectedCells(18).Value)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL1, conec)
                strArticulo = COM.ExecuteScalar
                conec.Close()
            End If

            'Genera el listado de referencias con saldo
            strSQL = SqlReferencias(EsGenerico, Codigo, strArticulo, strInfo)

            Dim catDesc As String
            strSQL2 = "SELECT cat_desc"
            strSQL2 &= "     FROM Catalogos"
            strSQL2 &= "         WHERE cat_clase='Medidas' AND cat_num=" & dgDetalle.SelectedCells(2).Value & " LIMIT 1"

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL2, conec)
            catDesc = COM.ExecuteScalar
            conec.Close()

            strInfo = strInfo & vbCrLf & "Medida: " & catDesc


            'Inicializa la ventana
            frmLista.Unidad = intUnidad
            frmLista.dgLista.Rows.Clear()
            frmLista.Informacion = strInfo
            If dgDetalle.ReadOnly Or (checkActivar.Checked = False) Then
                logBloquear = True
                frmLista.dgLista.ReadOnly = True
                frmLista.botonAceptar.Enabled = False
            Else
                frmLista.dgReservacion.Tag = vbEmpty
            End If

            'Obtiene los datos de la base de datos
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If Not (REA.HasRows) Or Not (logBloquear) Then

                'If dgReferencias.Rows.Count > vbEmpty Then
                '        'Busca saldos para la línea del pedido

                'For i = vbEmpty To dgReferencias.Rows.Count - 1
                '    '            'Sólo si corresponde a la línea del pedido actual
                '    CodigoDesc = dgReferencias.Rows(i).Cells("colCod").Value
                '    If dgReferencias.Rows(i).Cells("colNumero").Value = strPedido And
                '        dgReferencias.Rows(i).Cells("colCod").Value = Code Then
                'descargo = dgReferencias.Rows(i).Cells("colDescargo").Value

                '        Else
                '            descargo = vbEmpty
                '        End If
                '    Next
                'End If
                For i = vbEmpty To dgDetalle.Rows.Count - 1
                    'CodigoDesc = dgDetalle.Rows(i).Cells("colCodDesc").Value
                    If dgDetalle.Rows(i).Cells("colNPedidoDesc").Value = strPedido And
                        dgDetalle.Rows(i).Cells("colCodDesc").Value = Code Then
                        descargo = dgDetalle.Rows(i).Cells("colCantDescargo").Value
                        CodigoDesc = dgDetalle.Rows(i).Cells("colCodDesc").Value
                    Else
                        descargo = vbEmpty
                        CodigoDesc = vbEmpty
                    End If
                Next




                'strPedido = frmLista.dgLista.Rows(intLinea).Cells("colNPedido").Value
                'intFila = frmLista.dgLista.Rows(intLinea).Cells("colLinea").Value
                'Carga a la ventana desde el listado para la línea de pedido actual
                'Next
                'End If

                'Carga a la ventana desde el listado para la línea de pedido actual
                CargarListadoActual(frmLista, strPedido, intFila)


                'Carga a la ventana las referencias que no están en el listado

                'Dim strFila As String
                Dim strTemp As String
                While REA.Read
                    If LineaDeReferencia(REA.GetInt32("Anio"), REA.GetInt32("Numero"), REA.GetInt32("Linea"), strPedido, intFila) = NO_FILA Then


                        strFila = REA.GetInt32("Anio") & "|"
                        strFila &= REA.GetInt32("Numero") & "|"
                        strFila &= REA.GetDateTime("Fecha") & "|"
                        strFila &= PolizaDeIngreso(REA.GetInt32("Anio"), REA.GetInt32("Numero")) & "|"
                        strFila &= REA.GetString("Referencia") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        'strFila &= (CDbl(dgDetalle.CurrentRow.Cells("colSaldoActual").Value) + CDbl(dgDetalle.CurrentRow.Cells("colCantDescargo").Value)) & "|"
                        strFila &= REA.GetDouble("Saldo").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetString("Medida") & "|"
                        strFila &= REA.GetInt32("Unidad") & "|"
                        If REA.GetInt32("Codigo") = CodigoDesc And REA.GetInt32("Numero") = NumDescargo And REA.GetInt32("Linea") = LineaDescargo Then
                            strFila &= descargo & "|"
                        Else
                            strFila &= vbEmpty & "|"
                        End If
                        strFila &= REA.GetString("Nota1") & "|"
                        strFila &= REA.GetString("Nota2") & "|"
                        strFila &= REA.GetDouble("Reservado") & "|"
                        strFila &= vbEmpty & "|"
                        strFila &= vbEmpty & "|"
                        strFila &= 1

                        cfun.AgregarFila(frmLista.dgLista, strFila)
                        l = l + 1
                    Else
                        frmLista.dgLista.Rows(0).Cells("colReserva").Value = REA.GetDouble("Reservado")
                        frmLista.dgLista.Rows(0).Cells("colDetalle").Value = vbEmpty
                        frmLista.dgLista.Rows(0).Cells("colPF").Value = vbEmpty
                        frmLista.dgLista.Rows(0).Cells("colFila").Value = 1
                    End If

                    strTemp = vbNullString
                    strTemp = "Lugar de Fabricación:" & Space(3) & REA.GetString("pais") & vbNewLine
                    strTemp &= "Medida:" & Space(17) & REA.GetString("Medida") & vbNewLine
                    frmLista.celdaInfoFin.Text = strTemp

                End While
            Else
                'Carga a la ventana desde el listado para la línea de pedido actual
                CargarListadoActual(frmLista, strPedido, intFila)

            End If

            'Muestra el formulario
            'frmLista.ActualizarTotales()
            frmLista.Unidad = IIf(intUnidad = intKgs, 70, intUnidad)
            frmLista.Pedido = dgDetalle.SelectedCells(10).Value
            frmLista.Generico = EsGenerico
            frmLista.Codigo = dgDetalle.SelectedCells(2).Value
            frmLista.AnioPF = strCiclo
            frmLista.Iniciar()

            frmLista.ShowDialog(Me)
            frmLista.Hide()

            If frmLista.Aceptado Then
                ' If descargo = 0 Then
                intActual = vbEmpty
                'Buscar y eliminar referencias que estén en el listado y no hayan sido seleccionadas
                intMarca = NO_FILA
                With frmLista.dgLista
                    For i = (dgDetalle.Rows.Count - 1) To vbEmpty Step NO_FILA
                        If dgDetalle.Rows(i).Cells("colNPedidoDesc").Value = strPedido And
                           dgDetalle.Rows(i).Cells("colLineaDesc").Value = intFila Then
                            If Not ExisteEnSeleccion(frmLista.dgLista, dgDetalle.Rows(i).Cells("colAnioDesc").Value, dgDetalle.Rows(i).Cells("colNumDesc").Value, dgDetalle.Rows(i).Cells("colLinea2Desc").Value) Then
                                'Poner referencia en blanco
                                j = SetById(dgDetalle, 14, dgDetalle.Rows(i).Cells("colIDDesc").Value, vbNullString)

                                If Not (j = NO_FILA) Then
                                    If LineasDePedido(strPedido, intFila, intMarca) > 1 Then
                                        'dgDetalle.Rows.RemoveAt(j)
                                        dgDetalle.Rows(j).Cells("colXtra").Value = 2
                                        dgDetalle.Rows(j).Visible = False
                                    Else
                                        'Coloca la línea en su estado original (sin despacho)
                                        dgDetalle.Rows(j).Cells("colExistencia").Value = INT_CERO
                                        dgDetalle.Rows(j).Cells("colADespachar").Value = INT_CERO
                                        dgDetalle.Rows(j).Cells("colLibrasAdicionales").Value = INT_CERO
                                        dgDetalle.Rows(j).Cells("colCantidad").Value = INT_CERO
                                        dgDetalle.Rows(j).Cells("colPendiente").Value = dgDetalle.Rows(j).Cells("colOrden").Value
                                        dgDetalle.Rows(j).Cells("colOriginal").Value = dgDetalle.Rows(j).Cells("colOriginal").Value

                                        intMedida = Val(dgDetalle.Rows(j).Cells("colBase").Value)
                                        If Not (intLinea = intUnidad) Then
                                            dgDetalle.Rows(j).Cells("colBase").Value = dgDetalle.Rows(j).Cells("colUnit").Value
                                            strSQL3 = "SELECT cat_clave"
                                            strSQL3 &= "     FROM Catalogos"
                                            strSQL3 &= "       WHERE cat_clase='Medidas' AND cat_num={id} LIMIT 1"

                                            strSQL3 = Replace(strSQL3, "{id}", dgDetalle.Rows(j).Cells("colUnit").Value)

                                            conec = New MySqlConnection(strConexion)
                                            conec.Open()
                                            COM = New MySqlCommand(strSQL, conec)
                                            Medida = COM.ExecuteScalar
                                            conec.Close()

                                            dgDetalle.Rows(j).Cells("colMedida").Value = Medida

                                            'Factor de conversión
                                            dblFactor = IIf(intUnidad = intKgs, dblFactorKgs, dblFactorLbs)
                                            dgDetalle.Rows(j).Cells("colOrden").Value = (dgDetalle.Rows(j).Cells("colOrden").Value / dblFactor)

                                            'Restablece el precio original
                                            PrecioDePedido(j, strCiclo, strPedido, intFila)
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    Next
                End With

                'Busca la última línea de detalle para este pedido
                Call LineasDePedido(strPedido, intFila, intMarca)
                If Not (intMarca = NO_FILA) Then
                    intUltima = intMarca
                    'Recorrer la selección de la ventana
                    With frmLista.dgLista
                        For k As Integer = 0 To frmLista.dgLista.Rows.Count - 1

                            'Linea a ser actualizada
                            intActual = NO_FILA

                            'Unidad de medida del inventario
                            intMedida = frmLista.dgLista.Rows(k).Cells("colUnidad").Value

                            'Si hay descargo
                            If Val(frmLista.dgLista.Rows(k).Cells("colDescargo").Value) > vbEmpty Then

                                'Buscar referencia en lista

                                j = LineaDeReferencia(frmLista.dgLista.Rows(k).Cells("colAño").Value, frmLista.dgLista.Rows(k).Cells("colNumero").Value, frmLista.dgLista.Rows(k).Cells("colLinea").Value, strPedido, intFila)
                                If (j = NO_FILA) Then
                                    'Buscar línea de detalle en blanco
                                    Call LineasDePedido(strPedido, intFila, intActual, True)
                                    If intActual = NO_FILA Then
                                        'Si no existe linea en blanco duplicar actual
                                        intActual = DuplicarLinea(intMarca, intUltima)
                                        intUltima = intActual
                                        ' intMarca = intUltima


                                        'Coloca el precio del pedido
                                        strCiclo = dgDetalle.Rows(intActual).Cells("colAno").Value
                                        strPedido = strPedido
                                        ' intFila = frmLista.dgLista.Rows(k).Cells("colLinea").Value

                                        dgDetalle.Rows(intActual).Cells("colXtra").Value = 1

                                        PrecioDePedido(intActual, strCiclo, strPedido, intFila)
                                    End If
                                    'Agregar al listado de referencias (j=?)
                                    j = dgReferencias.Rows.Count
                                Else
                                    'Buscar su línea del detalle relacionada
                                    intActual = SetById(dgDetalle, 14, dgDetalle.Rows(j).Cells("colIDDesc").Value, vbNullString)
                                    If intActual = NO_FILA Then
                                        intActual = DuplicarLinea(intMarca)
                                        intUltima = intActual

                                        dgDetalle.Rows(intActual).Cells("colXtra").Value = 1
                                        'Coloca el precio del pedido
                                        PrecioDePedido(intActual, strCiclo, strPedido, intFila)
                                    End If
                                End If

                                intID = dgDetalle.Rows(intActual).Cells("colIDD").Value
                                'If frmLista.Aceptado Then
                                ' If dgReferencias.Rows.Count = 0 Then

                                If Not (j = NO_FILA) Then

                                    'Dim b As Integer = vbEmpty
                                    'Dim strFila2 As String

                                    'strFila2 = intID & "|"
                                    'strFila2 &= strPedido & "|"
                                    'strFila2 &= dgDetalle.Rows(intActual).Cells("colLinea").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colAño").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colNumero").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colFecha").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colReferencia").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colPoliza").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colLinea").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colCodigo").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colDisponible").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colMedida").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colUnidad").Value & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colDescargo").Value & "|"
                                    'strFila2 &= 1 & "|"
                                    'strFila2 &= frmLista.dgLista.Rows(k).Cells("colDisponible").Value


                                    'If frmLista.dgLista.Rows(k).Cells("colDescargo").Value > 0 Then
                                    '    Dim valorAnio As Integer
                                    '    Dim valorNum As Integer
                                    '    Valor1 = frmLista.dgLista.Rows(k).Cells("colNumero").Value

                                    '    For j = 0 To dgReferencias.Rows.Count - 1
                                    '        Valor2 = dgReferencias.Rows(j).Cells("colNum").Value
                                    '        valorAnio = dgReferencias.Rows(j).Cells("colAnio").Value
                                    '        valorNum = dgReferencias.Rows(j).Cells("colLinea2").Value
                                    '        If Valor1 = Valor2 Then
                                    '            Exit For
                                    '        End If
                                    '    Next
                                    '    If Valor1 = Valor2 And
                                    '            frmLista.dgLista.Rows(k).Cells("colAño").Value = valorAnio And
                                    '            frmLista.dgLista.Rows(k).Cells("colLinea").Value = valorNum Then
                                    '    Else
                                    '        cfun.AgregarFila(dgReferencias, strFila2)
                                    '    End If
                                    'End If


                                    dgDetalle.Rows(intActual).Cells("colIDDesc").Value = intID
                                    dgDetalle.Rows(intActual).Cells("colAnioDesc").Value = frmLista.dgLista.Rows(k).Cells("colAño").Value
                                    dgDetalle.Rows(intActual).Cells("colCatDesc").Value = 47
                                    dgDetalle.Rows(intActual).Cells("colNumDesc").Value = frmLista.dgLista.Rows(k).Cells("colNumero").Value
                                    dgDetalle.Rows(intActual).Cells("colLineaDesc").Value = dgDetalle.Rows(intActual).Cells("colLinea").Value
                                    dgDetalle.Rows(intActual).Cells("colCantDescargo").Value = frmLista.dgLista.Rows(k).Cells("colDescargo").Value
                                    dgDetalle.Rows(intActual).Cells("colCodDesc").Value = frmLista.dgLista.Rows(k).Cells("colCodigo").Value
                                    dgDetalle.Rows(intActual).Cells("colNPedidoDesc").Value = strPedido
                                    dgDetalle.Rows(intActual).Cells("colFecha2").Value = frmLista.dgLista.Rows(k).Cells("colFecha").Value
                                    dgDetalle.Rows(intActual).Cells("colPolizaDesc").Value = frmLista.dgLista.Rows(k).Cells("colPoliza").Value
                                    dgDetalle.Rows(intActual).Cells("colRefDesc").Value = frmLista.dgLista.Rows(k).Cells("colReferencia").Value
                                    dgDetalle.Rows(intActual).Cells("colLinea2Desc").Value = frmLista.dgLista.Rows(k).Cells("colLinea").Value
                                    dgDetalle.Rows(intActual).Cells("colMedDesc").Value = frmLista.dgLista.Rows(k).Cells("colMedida").Value
                                    dgDetalle.Rows(intActual).Cells("colUnidadDesc").Value = 69
                                    dgDetalle.Rows(intActual).Cells("colDisponibleDesc").Value = frmLista.dgLista.Rows(k).Cells("colDisponible").Value
                                    dgDetalle.Rows(intActual).Cells("colSaldoActual").Value = CDbl((frmLista.dgLista.Rows(k).Cells("colDisponible").Value) - CDbl(frmLista.dgLista.Rows(k).Cells("colDescargo").Value))
                                    dgDetalle.Rows(intActual).Cells("colBulto").Value = 1
                                End If

                                If Not (intActual = NO_FILA) Then

                                    'Asignar datos a la línea del detalle
                                    dgDetalle.Rows(intActual).Cells("colCodigo").Value = frmLista.dgLista.Rows(k).Cells("colCodigo").Value
                                    dgDetalle.Rows(intActual).Cells("colReference").Value = frmLista.dgLista.Rows(k).Cells("colReferencia").Value
                                    'dgDetalle.Rows(intActual).Cells("colXtra").Value = 1

                                    dblExiste = frmLista.dgLista.Rows(k).Cells("colDisponible").Value
                                    dblDescargo = frmLista.dgLista.Rows(k).Cells("colDescargo").Value
                                    'Existencia y descargo
                                    dgDetalle.Rows(intActual).Cells("colExistencia").Value = dblExiste.ToString(FORMATO_MONEDA)
                                    dgDetalle.Rows(intActual).Cells("colADespachar").Value = dblDescargo.ToString(FORMATO_MONEDA)
                                    dgDetalle.Rows(intActual).Cells("colLibrasAdicionales").Value = INT_CERO.ToString(FORMATO_MONEDA)
                                    'Unidad de medida distinta 
                                    If Not (intMedida = dgDetalle.Rows(intActual).Cells("colUnit").Value) Then
                                        dblFactor = IIf(intMedida = intKgs, dblFactorLbs, dblFactorKgs)
                                        dblDescargo = (dblDescargo / dblFactor)
                                        dgDetalle.Rows(intActual).Cells("colBase").Value = 69
                                        If Not (intMedida = dgDetalle.Rows(intActual).Cells("colBase").Value) Then

                                            strSQL3 = " SELECT d.DDoc_Prd_Cif precio
                                                                FROM Dcmtos_HDR h
                                                                LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num AND d.DDoc_Doc_Lin = {line}
                                                                WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 75 AND h.HDoc_Doc_Ano={anio} AND h.HDoc_Doc_Num = {num}"

                                            strSQL3 = strSQL3.Replace("{emp}", Sesion.IdEmpresa)
                                            strSQL3 = strSQL3.Replace("{anio}", strCiclo)
                                            strSQL3 = strSQL3.Replace("{num}", strPedido)
                                            strSQL3 = strSQL3.Replace("{line}", intFila)

                                            conec = New MySqlConnection(strConexion)
                                            conec.Open()
                                            COM = New MySqlCommand(strSQL3, conec)
                                            dblPrecio = COM.ExecuteScalar
                                            If dblPrecio = 0 Then
                                                'Realiza la conversión del precio
                                                dblPrecio = Val(dgDetalle.Rows(intActual).Cells("colPrecio").Value)

                                                strInfo = vbNullString
                                                strInfo = "Precio " & IIf(dgDetalle.Rows(intActual).Cells("colBase").Value = intLbs, "LBS", "KGS") & ": " & dblPrecio.ToString(FORMATO_MONEDA)

                                                'Para redondear al inmediato superior
                                                If Sesion.idGiro = 2 Then
                                                    dblPrecio = (dblPrecio / dblFactor)
                                                Else
                                                    dblPrecio = (dblPrecio / dblFactor).ToString(FORMATO_MONEDA)
                                                End If

                                            End If
                                            strInfo1 = "Precio " & IIf(intMedida = intLbs, "LBS", "KGS") & ": " & dblPrecio
                                            dgDetalle.Rows(intActual).Cells("colPrecio").Value = dblPrecio
                                            MsgBox("Fila " & (intActual + 1) & ": Check the Price." & vbCr & vbCr & "Automatic conversion by units of measurement" & vbCrLf & vbCrLf & strInfo & vbCrLf & vbCrLf & strInfo1, vbExclamation, "Notice")

                                        Else
                                            'Realiza la conversión del precio
                                            dblPrecio = Val(dgDetalle.Rows(intActual).Cells("colPrecio").Value)

                                            strInfo = vbNullString
                                            strInfo = "Precio " & IIf(dgDetalle.Rows(intActual).Cells("colBase").Value = intLbs, "LBS", "KGS") & ": " & dblPrecio.ToString(FORMATO_MONEDA)

                                            'Para redondear al inmediato superior
                                            If Sesion.idGiro = 2 Then
                                                dblPrecio = (dblPrecio / dblFactor)
                                            Else
                                                dblPrecio = (dblPrecio / dblFactor).ToString(FORMATO_MONEDA)
                                            End If


                                            strInfo1 = "Precio " & IIf(intMedida = intLbs, "LBS", "KGS") & ": " & dblPrecio
                                            dgDetalle.Rows(intActual).Cells("colPrecio").Value = dblPrecio
                                            MsgBox("Fila " & (intActual + 1) & ": Check the Price." & vbCr & vbCr & "Automatic conversion by units of measurement" & vbCrLf & vbCrLf & strInfo & vbCrLf & vbCrLf & strInfo1, vbExclamation, "Notice")

                                        End If
                                        Dim strSQL4 As String
                                        strSQL4 = "SELECT cat_clave"
                                        strSQL4 &= "  FROM Catalogos"
                                        strSQL4 &= "      WHERE cat_clase='Medidas' AND cat_num={id} "
                                        strSQL4 &= "   LIMIT 1"

                                        strSQL4 = Replace(strSQL4, "{id}", intMedida)

                                        conec = New MySqlConnection(strConexion)
                                        conec.Open()
                                        COM = New MySqlCommand(strSQL4, conec)
                                        Medida = COM.ExecuteScalar
                                        conec.Close()
                                        dgDetalle.Rows(intActual).Cells("colMedida").Value = Medida
                                        dgDetalle.Rows(intActual).Cells("colBase").Value = intMedida
                                    End If
                                    'Conversión (cantidad)
                                    dgDetalle.Rows(intActual).Cells("colCantidad").Value = dblDescargo.ToString(FORMATO_MONEDA)

                                End If
                            End If
                            'End If
                        Next
                    End With


                    Dim dblSaldoLbs As Double
                    Dim dblSaldoKgs As Double
                    Dim dblLibras As Double
                    Dim dblKilos As Double


                    ''Cantidad solicitada
                    'dblSaldoKgs = dblPedidoKgs
                    'dblSaldoLbs = dblPedidoLbs

                    With dgDetalle
                        For i = 0 To dgDetalle.Rows.Count - 1

                            'Cantidad solicitada
                            If intMedida = intKgs Then
                                dblPedidoKgs = CDbl(dgDetalle.Rows(i).Cells("colOrden").Value)
                                If intUnidad = intLbs Then
                                    dblPedidoLbs = CDbl(dgDetalle.Rows(i).Cells("colPedido").Value)
                                Else
                                    dblPedidoLbs = (dblPedidoKgs / dblFactorLbs)
                                End If
                            ElseIf intMedida = intLbs Then
                                dblPedidoLbs = CDbl(dgDetalle.Rows(i).Cells("colOrden").Value)
                                If intUnidad = intKgs Then
                                    dblPedidoKgs = CDbl(dgDetalle.Rows(i).Cells("colPedido").Value)
                                Else
                                    dblPedidoKgs = (dblPedidoLbs / dblFactorKgs)
                                End If
                            Else
                                dblPedidoKgs = CDbl(dgDetalle.Rows(i).Cells("colOrden").Value)
                                dblPedidoLbs = dblPedidoKgs
                            End If

                            ''Cantidad solicitada
                            dblSaldoKgs = dblPedidoKgs
                            dblSaldoLbs = dblPedidoLbs

                            If dgDetalle.Rows(i).Cells("colNPedido").Value = strPedido And
                        dgDetalle.Rows(i).Cells("colLinea").Value = intFila Then

                                'Actualiza la cantidad pendiente para el pedido/línea colLibrasAdicionales
                                intMedida = dgDetalle.Rows(i).Cells("colBase").Value
                                If intMedida = intKgs Then
                                    dblKilos = dgDetalle.Rows(i).Cells("colADespachar").Value
                                    dblLibras = (dblKilos / dblFactorLbs)
                                ElseIf intMedida = intLbs Then
                                    dblLibras = dgDetalle.Rows(i).Cells("colADespachar").Value
                                    dblKilos = (dblLibras / dblFactorKgs)
                                Else
                                    dblKilos = dgDetalle.Rows(i).Cells("colADespachar").Value
                                    dblLibras = dblKilos
                                End If

                                dblSaldoLbs = (dblSaldoLbs - dblLibras)
                                dblSaldoKgs = (dblSaldoKgs - dblKilos)

                                If dblSaldoKgs < vbEmpty Then
                                    dblSaldoKgs = vbEmpty
                                End If

                                If dblSaldoLbs < vbEmpty Then
                                    dblSaldoLbs = vbEmpty
                                End If




                                dgDetalle.Rows(i).Cells("colOrden").Value = IIf(intMedida = intKgs, dblPedidoKgs.ToString(FORMATO_MONEDA), dblPedidoLbs.ToString(FORMATO_MONEDA))
                                dgDetalle.Rows(i).Cells("colPendiente").Value = IIf(intMedida = intKgs, dblSaldoKgs.ToString(FORMATO_MONEDA), dblSaldoLbs.ToString(FORMATO_MONEDA))

                                'Compara el precio de la fila contra el precio de inventario
                                Dim strSQL5 As String
                                strSQL5 = "SELECT inv_PRECIOmax, inv_PRECIOfac, inv_partnum"
                                strSQL5 &= "     FROM Inventarios"
                                strSQL5 &= "         WHERE inv_sisemp={empresa} AND inv_numero={codigo}"

                                strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                                strSQL5 = Replace(strSQL5, "{codigo}", dgDetalle.Rows(i).Cells("colCodigo").Value)

                                MyCnn.CONECTAR = strConexion

                                COM = New MySqlCommand(strSQL5, CON)
                                REA = COM.ExecuteReader

                                If REA.HasRows Then
                                    Do While REA.Read
                                        'Asigna el número de parte
                                        dgDetalle.Rows(i).Cells("colNumParte").Value = REA.GetString("inv_partnum")
                                    Loop
                                End If
                                REA.Close()
                                COM = Nothing
                                Dim strSQL6 As String
                                strSQL6 = " SELECT i.DDoc_RF3_Dbl PrecioAduanal "
                                strSQL6 &= "    FROM Dcmtos_DTL d  "
                                strSQL6 &= "         LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
                                strSQL6 &= "                LEFT JOIN Dcmtos_DTL i ON i.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND i.DDoc_Doc_Cat = p.PDoc_Par_Cat AND i.DDoc_Doc_Ano = p.PDoc_Par_Ano AND i.DDoc_Doc_Num = p.PDoc_Par_Num AND i.DDoc_Doc_Lin = p.PDoc_Par_Lin  "
                                strSQL6 &= "                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea} "
                                strSQL6 = Replace(strSQL6, "{empresa}", Sesion.IdEmpresa)
                                strSQL6 = Replace(strSQL6, "{anio}", dgDetalle.Rows(i).Cells("colAnioDesc").Value)
                                strSQL6 = Replace(strSQL6, "{numero}", dgDetalle.Rows(i).Cells("colNumDesc").Value)
                                strSQL6 = Replace(strSQL6, "{linea}", dgDetalle.Rows(i).Cells("colLinea2Desc").Value)
                                If Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 14 Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or (Sesion.IdEmpresa = 20) Or (Sesion.IdEmpresa = 21) Then
                                Else
                                    MyCnn.CONECTAR = strConexion
                                    COM = New MySqlCommand(strSQL6, CON)
                                    REA = COM.ExecuteReader
                                    If REA.HasRows Then
                                        Do While REA.Read
                                            If Sesion.idGiro = 2 Then
                                                dblPrecio = REA.GetDouble("PrecioAduanal")
                                            Else
                                                dblPrecio = REA.GetDouble("PrecioAduanal").ToString(FORMATO_MONEDA)
                                            End If
                                            dblValor = dgDetalle.Rows(i).Cells("colPrecio").Value
                                        Loop
                                    End If
                                    strSQL6 = STR_VACIO
                                    REA.Close()
                                    COM.Dispose()
                                    'Si el precio de inventario es mayor da el aviso
                                    If dblPrecio > dblValor Then
                                        MsgBox("Row " & (i + 1) & " : It found a price difference with the inventory" & vbCr & vbCr & "Actual:" & Space(4) & vbTab & dblValor.ToString(FORMATO_MONEDA) & vbCr & "Inventory: " & dblPrecio.ToString(FORMATO_MONEDA) & vbCr & vbCr & "NOTE:" & vbCr & vbCr & "The price will be used " & IIf(logLibre, "Of the order (actual)", "inventory"), vbExclamation, "Price difference")
                                        If Not logLibre Then
                                            dgDetalle.Rows(i).Cells("colPrecio").Value = dblPrecio
                                        End If
                                    End If
                                End If
                            End If
                        Next
                    End With
                End If
            End If
            'dgDetalle.SelectedCells(26).Value = 2
            'For i = 0 To dgDetalle.Rows.Count - 1
            '    If dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
            '        dgDetalle.Rows(i).Visible = False
            '    End If
            'Next
            'End If
            CalcularTotales()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    '*******************VALIDACION DE DETALLE*****************'
    Private Function ComprobarFilaDetalle() As Boolean
        ComprobarFilaDetalle = True
        Dim i As Integer = 0
        Dim Comprobacion As Boolean = True
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intLinea As Integer
        Dim Despachar As Double
        Dim intNumInstruccion As Double
        Dim intAnoInstruccion As Double
        Dim intLineaIntruccion As Double
        Dim Saldo As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        For i = 0 To dgDetalle.Rows.Count - 1
            If (dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0) And dgDetalle.Rows(i).Visible = True Then
                ' If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                If dgDetalle.Rows(i).Cells("colLugar").Value = vbNullString Then
                    MsgBox("Specify the destination place", vbExclamation, "Aviso")
                    Comprobacion = False
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colCodigo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Article code invalid")
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colArticulo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item description")
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colPrecio").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item description")
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colBulto").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item Package")
                    Exit Function
                End If
                If (Not Sesion.IdEmpresa = 15) Or (Not Sesion.IdEmpresa = 18) Or (Not Sesion.IdEmpresa = 19) Then
                    If dgDetalle.Rows(i).Cells("colReference").Value = vbNullString Then
                        Comprobacion = False
                        MsgBox("Blank item Reference")
                        ' Exit Function
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colADespachar").Value = INT_CERO Then
                    Comprobacion = False
                    MsgBox("Blank item Dispacht")
                    'Exit Function
                End If

                If sqlEsGenerico(dgDetalle.Rows(i).Cells("colCodigo").Value) And dgDetalle.Rows(i).Cells("colCodigo").Value = vbNullString Then
                    MsgBox("Row #" & i + 1 & ": It has not been assigned a specific  thread.", vbExclamation, "Notice")
                    Comprobacion = False
                    Exit Function
                End If

                If dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    intAnio = dgDetalle.Rows(i).Cells("colAnioDesc").Value
                    intNumero = dgDetalle.Rows(i).Cells("colNumDesc").Value
                    intLinea = dgDetalle.Rows(i).Cells("colLinea2Desc").Value
                    Despachar = CDbl(dgDetalle.Rows(i).Cells("colADespachar").Value)
                    Despachar = CDbl(dgDetalle.Rows(i).Cells("colADespachar").Value)
                    intNumInstruccion = celdaNumero.Text
                    intAnoInstruccion = celdaAño.Text
                    intLineaIntruccion = dgDetalle.Rows(i).Cells("colIDD").Value


                    strSQL = SqlVerificacionInventario(intAnio, intNumero, intLinea, intNumInstruccion, intAnoInstruccion, intLineaIntruccion)
                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        Saldo = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using
                    If checkPago.Visible = False Or checkPago.Checked = False Then
                        If (Despachar > Saldo) Then
                            MsgBox("You cant not download one more to its existence please check their inventory in line number " & intLinea, vbExclamation, "Notice")
                            Comprobacion = False
                            ComprobarFilaDetalle = Comprobacion
                            Exit Function
                        End If
                    End If
                End If

            End If
        Next
        ComprobarFilaDetalle = Comprobacion
        Return Comprobacion
    End Function

    'Comprueba que no se mezclen grupos de paises (p.e.: USA, ASIA)
    Private Function ComprobarOrigenes() As Boolean
        Const STR_GRUPOS As String = "'ASIA','USA'"
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Dim logEx As Boolean
        Dim strCod As String
        Dim strLista As String
        Dim strSQL As String
        Dim strTemp As String

        Dim i As Integer
        Dim c As Integer

        logEx = False
        c = vbEmpty

        strCod = vbNullString
        strLista = vbNullString
        For i = 0 To dgDetalle.Rows.Count - 1
            strCod = dgDetalle.Rows(i).Cells("colCodigo").Value
            If Not (strCod = vbNullString) Then
                strCod = "|" & strCod & "|"
                If InStr(1, strLista, strCod) = vbEmpty Then
                    strLista = strLista & strCod
                    c = c + 1
                End If
            End If
        Next
        'Sólo si hay más de un código involucrado
        If c > INT_UNO Then
            strLista = Replace(strLista, "||", ",")
            strLista = Replace(strLista, "|", vbNullString)

            strSQL = vbNullString
            strSQL &= "SELECT GROUP_CONCAT(DISTINCT g.cat_clave ORDER BY g.cat_clave SEPARATOR ',') Grupos "
            strSQL &= "      FROM Inventarios i "
            strSQL &= "              INNER JOIN Catalogos c ON c.cat_clase='Paises' AND c.cat_num=i.inv_lugarfab"
            strSQL &= "       INNER JOIN Catalogos g ON g.cat_clase='Countries' AND g.cat_num=c.cat_pid"
            strSQL &= "   WHERE i.inv_sisemp={empresa} AND i.inv_numero IN ({lista}) AND g.cat_clave IN ({grupos}) "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{lista}", strLista)
            strSQL = Replace(strSQL, "{grupos}", STR_GRUPOS)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                strTemp = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            If Not (strTemp = vbNullString) Then
                If InStr(1, strTemp, ",") > vbEmpty Then
                    MsgBox("You can not mix products originating " & Replace(Replace(STR_GRUPOS, ",", ""), ",", " and "), vbExclamation, "Origin")
                    logEx = True
                End If
            End If
        End If

        ComprobarOrigenes = Not logEx
    End Function

    'Comprueba si alguno de los pedidos tiene pago de impuestos
    Private Function ComprobarPago() As Boolean
        Dim i As Integer, j As Integer
        Dim logPago As Boolean, logSi As Boolean, logEx As Boolean
        Dim strSQL As String
        Dim strTemp As String = STR_VACIO
        Dim strTemp1 As String = STR_VACIO
        Dim strDato As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        logEx = True
        logPago = rbOpcionPagoSI.Checked
        If Not logPago Then
            '0 - número / 4 - año
            j = vbEmpty
            For i = vbEmpty To dgPedidos.Rows.Count - 1
                j = j + 1
                If Val(dgPedidos.Rows(i).Cells("colYear").Value) Then
                    strTemp = IIf(strTemp = vbNullString, vbNullString, " OR ")
                    strTemp &= "(HDoc_Doc_Ano= {año} AND HDoc_Doc_Num= {numero})"
                    strTemp &= Replace(strTemp, "{año}", dgPedidos.Rows(i).Cells("colYear").Value)
                    strTemp &= Replace(strTemp, "{numero}", dgPedidos.Rows(i).Cells(vbEmpty).Value)
                End If
            Next
            If Not (strTemp1 = vbNullString) Then
                strTemp1 = "HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={tipo} AND (" & strTemp & ")"
                strTemp1 = Replace(strTemp1, "{empresa}", Sesion.IdEmpresa)
                strTemp1 = Replace(strTemp1, "{tipo}", 75)

                strSQL = "SELECT CAST(GROUP_CONCAT(CONCAT('PF-',HDoc_Doc_Num) SEPARATOR ', ') AS CHAR)"
                strSQL &= "     FROM Dcmtos_HDR"
                strSQL &= "          WHERE HDoc_DR2_Emp=1 AND " & strTemp1

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    strDato = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using
                logSi = Not (strDato = vbNullString)
            End If

            If logSi Then
                MsgBox(IIf(j = INT_UNO, "The request ", "One or more orders ") & "customer includes tax" & vbCr & vbCr & "Revise: " & vbCr & vbCr & Space(15) & strDato, vbExclamation, "Tax payment")
                logEx = False
            End If
        End If

        ComprobarPago = logEx
    End Function

    Public Sub DuplicarFila(ByRef lista As DataGridView, ByRef fila As Integer)

        lista.Rows.Insert(fila)
        'lista.Rows.AddCopy(fila)
    End Sub

    'Duplica la línea origen después de la última posición
    Private Function DuplicarLinea(ByVal Origen As Integer, Optional Ultima As Integer = NO_FILA)
        Dim dblFactor As Double
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim i As Integer
        Dim intPos As Integer
        Dim intUnidad As Integer
        Dim medida As String

        'Establece la posición de la nueva fila
        If Ultima = NO_FILA Then
            intPos = dgDetalle.Rows.Count
        Else
            ' intPos = (dgDetalle.Rows.Count - 1) + 1
            intPos = Ultima + 1
        End If

        'Agregar fila en blanco
        DuplicarFila(dgDetalle, intPos)

        'Factor de conversión
        intUnidad = Val(dgDetalle.Rows(Origen).Cells("colUnit").Value)
        If Not Val(dgDetalle.Rows(Origen).Cells("colBase").Value) = intUnidad Then
            dblFactor = IIf(intUnidad = intKgs, dblFactorKgs, dblFactorLbs)
        Else
            dblFactor = 1
        End If

        'Copia el contenido
        For i = vbEmpty To dgDetalle.ColumnCount - 1
            'Dim strSQL As String
            Select Case i
                Case dgDetalle.Rows(intPos).Cells("colAno").Value
                    dgDetalle.Rows(intPos).Cells("colAno").Value = dgDetalle.Rows(Origen).Cells(i).Value
                Case dgDetalle.Rows(intPos).Cells("colOrden").Value
                    dgDetalle.Rows(intPos).Cells("colOrden").Value = CDbl(dgDetalle.Rows(Origen).Cells("colOrden").Value / dblFactor).ToString(FORMATO_MONEDA)
                Case dgDetalle.Rows(intPos).Cells("colExistencia").Value, dgDetalle.Rows(intPos).Cells("colADespachar").Value, dgDetalle.Rows(intPos).Cells("colPendiente").Value, dgDetalle.Rows(intPos).Cells("colCantidad").Value, dgDetalle.Rows(intPos).Cells("colIDD").Value
                    'Asignar 0.00
                    dgDetalle.Rows(intPos).Cells(i).Value = vbEmpty
                    'Case dgDetalle.Rows(intPos).Cells("colReference").Value, dgDetalle.Rows(intPos).Cells("colDatosOriginales").Value, dgDetalle.Rows(intPos).Cells("colNumParte").Value
                    '    'Dejar en blanco
                    '    dgDetalle.Rows(intPos).Cells(i).Value = vbNullString
                Case dgDetalle.Rows(intPos).Cells("colBase").Value
                    dgDetalle.Rows(intPos).Cells(i).Value = dgDetalle.Rows(Origen).Cells("colBase").Value
                    'Case dgDetalle.Rows(intPos).Cells("colMedida").Value
                    '    strSQL = "SELECT cat_clave"
                    '    strSQL &= "  FROM Catalogos"
                    '    strSQL &= "      WHERE cat_clase='Medidas' AND cat_num={id} "
                    '    strSQL &= "   LIMIT 1"

                    '    strSQL = Replace(strSQL, "{id}", dgDetalle.Rows(Origen).Cells("colUnit").Value)

                    '    conec = New MySqlConnection(strConexion)
                    '    conec.Open()
                    '    COM = New MySqlCommand(strSQL, conec)
                    '    medida = COM.ExecuteScalar
                    '    conec.Close()
                    '    dgDetalle.Rows(intPos).Cells(i).Value = medida
                Case Else
                    'Copiar contenido
                    dgDetalle.Rows(intPos).Cells(i).Value = dgDetalle.Rows(Origen).Cells(i).Value
            End Select
        Next
        'Asignar identificador y devolver posición
        dgDetalle.Rows(intPos).Cells("colIDD").Value = GetId()
        DuplicarLinea = intPos
    End Function

    'Coloca el precio del pedido en la línea del detalle
    Private Sub PrecioDePedido(ByVal Index As Integer, ByVal Ciclo As String, ByVal Numero As String, ByVal Linea As String)
        Dim dblPrecio As Double
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "SELECT DDoc_Prd_NET"
        strSQL &= " FROM Dcmtos_DTL"
        strSQL &= "      WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat=75 AND DDoc_Doc_Ano={año} AND DDoc_Doc_Num={numero} AND DDoc_Doc_Lin={linea}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", Ciclo)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{linea}", Linea)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            dblPrecio = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        dgDetalle.Rows(Index).Cells("colPrecio").Value = dblPrecio.ToString

    End Sub

    'Genera un identificador para la fila
    Private Function GetId() As Integer
        Dim i As Integer
        Dim intDato As Integer
        Dim intMax As Integer
        'Recorre toda la rejilla

        For i = vbEmpty To dgDetalle.Rows.Count - 1
            intDato = CInt(Val(dgDetalle.Rows(i).Cells("colIDD").Value))
            If intDato > intMax Then
                intMax = intDato
            End If
        Next
        'Devuelve el valor más alto (+1)
        GetId = (intMax + 1)
    End Function

    'Cuenta las líneas del detalle para una línea de pedido
    Private Function LineasDePedido(ByVal Pedido As String, ByVal Linea As Integer, ByRef Marca As Integer, Optional Blanca As Boolean = False) As Integer
        Dim i As Integer = 0
        Dim j As Integer = 0
        Marca = NO_FILA



        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Visible = True Then
                If dgDetalle.Rows(i).Cells("colNPedido").Value = Pedido And
                    dgDetalle.Rows(i).Cells("colLinea").Value = Linea Then
                    If Blanca Then
                        'Primera referencia vacía
                        If Marca = NO_FILA And dgDetalle.Rows(i).Cells("colreference").Value = vbNullString Then
                            Marca = i
                        End If
                    Else
                        'La Ultima
                        Marca = i
                    End If
                    'Incrementa el Contador
                    j = j + 1
                End If
            End If
        Next


        LineasDePedido = j
    End Function

    'Comprueba si una referencia existe en la selección de descargos
    Private Function ExisteEnSeleccion(ByVal Datos As DataGridView, ByVal Ciclo As Integer, ByVal Numero As Integer, ByVal Linea As Integer) As Boolean
        Dim i As Integer
        Dim logEx As Boolean

        For i = vbEmpty To Datos.Rows.Count - 1
            'Buscar documento
            If Datos.Rows(i).Cells("colAño").Value = Ciclo And
                Datos.Rows(i).Cells("colNumero").Value = Numero And
                Datos.Rows(i).Cells("colLinea").Value = Linea Then
                'Comprobar descargo
                If Val(Datos.Rows(i).Cells("colDescargo").Value > vbEmpty) Then
                    logEx = True
                    Exit For
                End If
            End If
        Next
        ExisteEnSeleccion = logEx
    End Function

    'Devuelve la posición de un documento en el listado
    Private Function LineaDeReferencia(ByVal Ciclo As String, ByVal Numero As String, ByVal Linea As String, ByVal Pedido As String, ByVal Fila As Integer) As Integer
        Dim i As Integer
        Dim intPos As Integer
        intPos = NO_FILA
        'Busca una referencia para la línea de pedido dada

        For i = vbEmpty To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                If dgDetalle.Rows(i).Cells("colAnioDesc").Value = Ciclo And
                    dgDetalle.Rows(i).Cells("colNumDesc").Value = Numero And
                    dgDetalle.Rows(i).Cells("colLinea2Desc").Value = Linea Then
                    If dgDetalle.Rows(i).Cells("colNPedido").Value = Pedido And
                        Val(dgDetalle.Rows(i).Cells("colLinea").Value) = Fila Then
                        'Posición actual
                        intPos = i
                        Exit For
                    End If

                End If
            End If
        Next

        LineaDeReferencia = intPos
    End Function

    Public Sub queryFacturasRef(ByVal EsGenerico As Boolean, ByVal Codigo As String, ByVal Articulo As String, ByRef Info As String)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim frmLista As New frmFacturasRef_Aux_

        strSQL = SqlReferencias(EsGenerico, Codigo, Articulo, Info)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                'frmLista.dglista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= PolizaDeIngreso(REA.GetInt32("Anio"), REA.GetInt32("Numero")) & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetDouble("Saldo").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetInt32("Unidad") & "|"
                    strFila &= vbEmpty & "|"
                    strFila &= REA.GetString("Nota1") & "|"
                    strFila &= REA.GetString("Nota2") & "|"
                    strFila &= REA.GetDouble("Reservado") & "|"
                    strFila &= vbEmpty

                    cfun.AgregarFila(frmLista.dgLista, strFila)

                Loop

            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Fija un valor para un ID
    Private Function SetById(ByRef Data As DataGridView, ByVal Col As Integer, ByVal ID As String, ByVal Value As String) As Integer
        Dim i As Integer
        Dim j As Integer
        j = NO_FILA
        For i = 0 To (Data.Rows.Count - 1)
            'Si el ID corresponde
            If Data.Rows(i).Cells("colIDD").Value = ID Then
                'Asigna el valor
                Data.Rows(i).Cells(Col).Value = Value
                j = i
            End If
        Next
        'Devuelve la última línea modificada
        SetById = j
    End Function

    Private Function sqlEsGenerico(nItem As String) As Boolean
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        strSQL = vbNullString
        strSQL &= "SELECT  inv_generico"
        strSQL &= "      FROM Inventarios"
        strSQL &= "              WHERE inv_sisemp = {empresa} AND inv_numero=" & nItem & ""
        strSQL &= "       LIMIT 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If Not REA.Read() Then
            sqlEsGenerico = False
        Else
            If REA.GetInt32("inv_generico") = 1 Then
                sqlEsGenerico = True
            Else
                sqlEsGenerico = False
            End If
        End If
    End Function

    'Carga notas de pedido de cliente 
    Private Sub CargarNota()
        Dim strTemp As String
        Dim strDato As String
        Dim strSQL As String = vbNullString
        Dim strSQL2 As String = vbNullString
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Dim logEx As Boolean

        'Recorrer pedidos
        For i = 0 To dgPedidos.Rows.Count - 1
            If dgPedidos.Rows.Count > vbEmpty Then
                strSQL2 = strSQL2 & IIf(strSQL2 = vbNullString, vbNullString, "OR")
                strSQL2 &= "(e.HDoc_Doc_Ano ={año} AND HDoc_Doc_Num={numero} ) "

                strSQL2 = Replace(strSQL2, "{año}", dgPedidos.Rows(i).Cells("colYear").Value)
                strSQL2 = Replace(strSQL2, "{numero}", dgPedidos.Rows(i).Cells("colPF").Value)
            End If
        Next
        If Not strSQL2 = vbNullString Then
            strSQL = "SELECT CONCAT('COLOCAR EN CARTA DE PORTE: ', e.HDoc_Emp_Nom,' / ',IFNULL(c.cli_cliente,'')) dato"
            strSQL &= "     FROM Dcmtos_HDR e"
            strSQL &= "          LEFT JOIN Clientes c ON c.cli_sisemp = e.HDoc_Sis_Emp AND c.cli_codigo=e.HDoc_DR1_Emp"
            strSQL &= "              WHERE e.HDoc_Sis_Emp={empresa} AND NOT(e.HDoc_Emp_Cod=e.HDoc_DR1_Emp) AND e.HDoc_Doc_Cat= 75 AND (" & strSQL2 & " " & ")"
            strSQL &= "           GROUP BY e.HDoc_DR1_Emp "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        End If

        strTemp = vbNullString
        If Not (strSQL = vbNullString) Then
            'Nota actual

            strDato = celdaObservaciones.Text

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.Read Then

                strTemp = REA.GetString("Dato")

                If InStr(1, celdaObservaciones.Text, strTemp) = vbNullString Then
                    strDato = strTemp & "."
                    celdaObservaciones.Text = strDato
                Else : logEx = True
                End If
            End If
        End If
        If Not ((strTemp = vbNullString) Or logEx) Then
            MsgBox(strTemp, vbInformation, "Aviso")
        End If

    End Sub

    'Recupera el detalle de los documentos por procesar
    Private Sub ProcesarDocumentos(Optional Preguntar As Boolean = True)
        Me.Tag = "Nuevo"
        Dim strBase As String
        Dim strManual As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Dim i As Integer
        Dim j As Integer

        'dgDetalle.Rows.Clear()
        If dgPedidos.Rows.Count > 0 Then
            If Preguntar Then
                If MsgBox("¿Show details of all documents in the list?", vbQuestion + vbYesNo + vbDefaultButton2, "Document detail") = vbNo Then
                    Exit Sub
                End If
            End If
        End If

        If dgPedidos.Rows.Count > vbEmpty Then

            'Construir criterio para documentos con saldo y agregados manualmente

            strBase = vbNullString
            strManual = vbNullString
            For j = 0 To dgPedidos.Rows.Count - 1
                If Not ((dgPedidos.Rows(j).Cells("colPF").Value) = vbNullString) Then
                    If (dgPedidos.Rows(j).Cells("colImpuesto").Value) = "X" And Preguntar = False Then
                        strBase = strBase & IIf(strBase = vbNullString, vbNullString, "OR") & "(DDoc_Doc_Ano={0} AND DDoc_Doc_Num={1})"
                        strBase = Replace(strBase, "{0}", dgPedidos.Rows(j).Cells("colYear").Value)
                        strBase = Replace(strBase, "{1}", dgPedidos.Rows(j).Cells("colPF").Value)
                    ElseIf Preguntar = True Then
                        strManual = strManual & IIf(strManual = vbNullString, vbNullString, "OR") & "(DDoc_Doc_Ano={0} AND DDoc_Doc_Num={1})"
                        strBase = Replace(strBase, "{0}", dgPedidos.Rows(j).Cells("colYear").Value)
                        strBase = Replace(strBase, "{1}", dgPedidos.Rows(j).Cells("colPF").Value)
                    End If
                End If
            Next

            i = vbEmpty

            Dim strSQL As String = STR_VACIO
            If Not (strManual = vbNullString) Then
                SqlDetallePorProcesar2()
            End If

            If Not (strBase = vbNullString) Then
                SqlDetallePorProcesar2()
            End If
        End If
        'End If

    End Sub

    Private Sub SqlDetallePorProcesar2(Optional ByVal Preguntar As Boolean = True)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim Array() As String
        Dim strTEMP As String = STR_VACIO
        Dim strTEMP2 As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Dim Temp As Double
        Dim Temp1 As Double
        Dim Temp2 As Double
        Dim contador As Integer = 0

        If dgPedidos.Rows.Count > 0 Then

            If dgPedidos.Rows.Count > 0 Then
                If Preguntar Then
                    If MsgBox("¿Show details of all documents in the list?", vbQuestion + vbYesNo + vbDefaultButton2, "Document detail") = vbNo Then
                        Exit Sub
                    End If
                End If
            End If

            For i = 0 To dgPedidos.Rows.Count - 1
                If i > 0 Then
                    strTEMP = strTEMP & " OR "
                End If
                If dgPedidos.Rows.Count - 1 >= 0 Then
                    strTEMP = strTEMP & " (d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND d.DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value & ")"
                Else
                End If
            Next

            strSQL = vbNullString
            strSQL &= " SELECT d.DDoc_Doc_Ano Anio,d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Fec Fecha, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Cod Original, d "
            strSQL &= "     .DDoc_Prd_NET Precio, m.cat_clave Medida, d.DDoc_Prd_UM Unidad, 0 Cantidad, d.DDoc_Prd_UM Base, 0 Conversion, d.DDoc_Prd_PNr Parte, 0 Existencia"
            strSQL &= "         , d.DDoc_Prd_QTY Ordenado, 0 Pendiente, '' Referencia, '' Datos, CONCAT(a.art_DCorta,' ', COALESCE(p.cat_clave,'')) Descripcion, COALESCE(l "
            strSQL &= "             .cli_cliente,'') Lugar, IFNULL(d.DDoc_RF1_Num,0) Destino, IFNULL(d.DDoc_RF2_Txt,'') Observaciones, (("
            strSQL &= "                 SELECT IFNULL(SUM(r.PDoc_QTY_Pro),0) despacho"
            strSQL &= "                     FROM Dcmtos_DTL_Pro r"
            strSQL &= "                         WHERE r.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r.PDoc_Par_Num = d"
            strSQL &= "                             .DDoc_Doc_Num AND r.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat IN (22,48)) + ("
            strSQL &= "                                  SELECT IFNULL(SUM(IDoc_Itm_QTY),0) manual"
            strSQL &= "                                     FROM Dcmtos_DTL_Itm"
            strSQL &= "                                          WHERE IDoc_Sis_Emp=d.DDoc_Sis_Emp AND IDoc_Doc_Cat=d.DDoc_Doc_Cat AND IDoc_Doc_Ano=d.DDoc_Doc_Ano AND IDoc_Doc_Num=d.DDoc_Doc_Num AND"
            strSQL &= "                                     IDoc_Doc_Lin=d.DDoc_Doc_Lin)) Despachado"
            strSQL &= "                             FROM Dcmtos_DTL d"
            strSQL &= "                         LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
            strSQL &= "                     LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
            strSQL &= "                 LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
            strSQL &= "             LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = d.DDoc_Prd_UM"
            strSQL &= "          LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab"
            strSQL &= "    WHERE d.DDoc_Sis_Emp = {empresa} AND  d.DDoc_RF2_Num = 0 AND "
            strSQL &= "             d.DDoc_Doc_Cat = {documento} And ({lista})"
            strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{documento}", 75)
            strSQL = Replace(strSQL, "{lista}", strTEMP)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then

                    dgDetalle.Rows.Clear()
                    Do While REA.Read
                        Dim strFila As String = STR_VACIO

                        strFila = REA.GetInt32("Anio") & "|"
                        strFila &= REA.GetInt32("Catalogo") & "|"
                        strFila &= REA.GetInt32("Numero") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= REA.GetDateTime("Fecha") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        strFila &= REA.GetString("Descripcion") & "|"
                        strFila &= REA.GetString("Medida") & "|"
                        If Sesion.idGiro = 2 Then
                            strFila &= REA.GetDouble("Precio") & "|"
                        Else
                            strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                        End If
                        strFila &= REA.GetDouble("Existencia").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("Conversion").ToString(FORMATO_MONEDA) & "|"
                        strFila &= INT_CERO.ToString(FORMATO_MONEDA) & "|"
                        strFila &= INT_UNO & "|"
                        strFila &= REA.GetString("Pendiente").ToString & "|"
                        strFila &= REA.GetString("Referencia") & "|"
                        strFila &= REA.GetString("Lugar") & "|"
                        strFila &= REA.GetInt32("Destino") & "|"
                        strFila &= REA.GetInt32("Original") & "|"
                        strFila &= "e/ " & REA.GetDouble("Existencia").ToString(FORMATO_MONEDA) & "/ p /" & REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "/ d /" & REA.GetDouble("Conversion").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetString("Parte") & "|"
                        strFila &= 0 & "|"
                        strFila &= REA.GetInt32("Unidad") & "|"
                        strFila &= REA.GetInt32("Base") & "|"
                        strFila &= REA.GetInt32("Cantidad") & "|"
                        strFila &= REA.GetInt32("Ordenado").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("Despachado") & "|"
                        strFila &= 1 & "|"
                        strFila &= REA.GetString("Observaciones")

                        cFunciones.AgregarFila(dgDetalle, strFila)


                    Loop

                    For i = 0 To dgDetalle.Rows.Count - 1

                        'Identificador de la fila: año, numero, codigo, u/m
                        strTEMP2 = dgDetalle.Rows(i).Cells("colAno").Value & "," & dgDetalle.Rows(i).Cells("colNPedido").Value & "," & dgDetalle.Rows(i).Cells("colCodigo").Value

                        'Si no es el mismo hilo limpia los totales
                        If Not (strLinea = strTEMP2) Then
                            If (Temp2 > vbEmpty) Then
                                strLinea = strLinea & "," & (Temp2)
                            End If
                            Temp2 = vbEmpty
                            strLinea = strTEMP2
                        End If

                        Temp = dgDetalle.Rows(i).Cells("colOrden").Value
                        Temp1 = Temp2 + dgDetalle.Rows(i).Cells("colOriginal").Value
                        Temp2 = (Temp - Temp1)

                        If CDbl(Temp2 <= 0) Then
                            Temp2 = (Temp2 * (-1))
                            'Si se despacho de más
                            dgDetalle.Rows(i).Visible = False
                        Else
                            dgDetalle.Rows(i).Cells("colOrden").Value = Temp2.ToString(FORMATO_MONEDA)
                            dgDetalle.Rows(i).Cells("colPendiente").Value = Temp2.ToString(FORMATO_MONEDA)
                            dgDetalle.Rows(i).Cells("colPedido").Value = Temp2.ToString(FORMATO_MONEDA)
                            Temp2 = vbEmpty
                        End If
                    Next

                End If

                CalcularTotales()

                For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
                    'If dgDetalle.Rows(i).Selected Then
                    If dgDetalle.Rows(i).Visible = True Then
                        contador = contador + 1
                        dgDetalle.Rows(i).Cells("colIDD").Value = contador
                    End If
                    'End If
                Next
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Function SqlDetallePorProcesar() As String
        Dim strSQL As String


        strSQL = vbNullString
        strSQL &= "  SELECT d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Fec Fecha, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Cod Original, d "
        strSQL &= "     .DDoc_Prd_NET Precio, m.cat_clave Medida, d.DDoc_Prd_UM Unidad, 0 Cantidad, d.DDoc_Prd_UM Base, 0 Conversion, d.DDoc_Prd_PNr Parte, 0 Existencia"
        strSQL &= "         , d.DDoc_Prd_QTY Ordenado, 0 Pendiente, '' Referencia, '' Datos, CONCAT(a.art_DCorta,' ', COALESCE(p.cat_clave,'')) Descripcion, COALESCE(l "
        strSQL &= "             .cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino,  d.DDoc_RF2_Txt Observaciones, (("
        strSQL &= "                 SELECT IFNULL(SUM(r.PDoc_QTY_Pro),0) despacho"
        strSQL &= "                     FROM Dcmtos_DTL_Pro r"
        strSQL &= "                         WHERE r.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r.PDoc_Par_Num = d"
        strSQL &= "                             .DDoc_Doc_Num AND r.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat IN (22,48)) + ("
        strSQL &= "                                  SELECT IFNULL(SUM(IDoc_Itm_QTY),0) manual"
        strSQL &= "                                     FROM Dcmtos_DTL_Itm"
        strSQL &= "                                          WHERE IDoc_Sis_Emp=d.DDoc_Sis_Emp AND IDoc_Doc_Cat=d.DDoc_Doc_Cat AND IDoc_Doc_Ano=d.DDoc_Doc_Ano AND IDoc_Doc_Num=d.DDoc_Doc_Num AND"
        strSQL &= "                                     IDoc_Doc_Lin=d.DDoc_Doc_Lin)) Despachado"
        strSQL &= "                             FROM Dcmtos_DTL d"
        strSQL &= "                         LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strSQL &= "                     LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSQL &= "                 LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strSQL &= "             LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = d.DDoc_Prd_UM"
        strSQL &= "          LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab"
        strSQL &= "    WHERE d.DDoc_Sis_Emp = {empresa} AND"
        strSQL &= "             d.DDoc_Doc_Cat = {documento} AND d.DDoc_RF2_Num = 0 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num={numero} "
        strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 75)
        strSQL = Replace(strSQL, "{año}", dgPedidos.SelectedCells(4).Value)
        strSQL = Replace(strSQL, "{numero}", dgPedidos.SelectedCells(0).Value)

        SqlDetallePorProcesar = strSQL

    End Function

    Private Function SqlSeleccionados() As String
        Dim wSql As String = STR_VACIO

        For i As Integer = 0 To dgPedidos.Rows.Count - 1
            If Me.Tag = "Nuevo" Then
                If (dgPedidos.Rows(i).Cells("colImpuesto").Value = "0" Or dgPedidos.Rows(i).Cells("colImpuesto").Value = "1") Then
                    wSql &= IIf(i = vbEmpty, "(", " OR(")
                    wSql &= "d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND "
                    wSql &= "d.DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value & ") "
                ElseIf dgPedidos.Rows(i).Cells("colImpuesto").Value = "X" And dgPedidos.Rows(i).Visible = True Then
                    wSql &= IIf(i = vbEmpty, "(", " OR(")
                    wSql &= "d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND "
                    wSql &= "d.DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value & ") "
                End If
            Else
                If dgPedidos.Rows.Count < 1 And (dgPedidos.Rows(i).Cells("colImpuesto").Value = "0" Or dgPedidos.Rows(i).Cells("colImpuesto").Value = "1") Then
                    wSql &= IIf(i = vbEmpty, "(", " OR(")
                    wSql &= "d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND "
                    wSql &= "d.DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value & ") "
                ElseIf dgPedidos.Rows(i).Cells("colImpuesto").Value = "X" And dgPedidos.Rows(i).Visible = True Then
                    wSql &= "d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND "
                    wSql &= "d.DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value
                End If
            End If

        Next
        If wSql = vbNullString Then
            SqlSeleccionados = "AND 1 = 0 "
        Else
            SqlSeleccionados = "AND (" & wSql & ")"
        End If

    End Function

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        'Revisar que los datos de la cabecera no estén en blanco.

        If celdaEmpresa.Text = vbNullString Or
            celdaCatalogo.Text = vbNullString Or
            celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete Data System", vbCritical)
            'Exit Function
            comprobar = False
        End If

        If celdaAño.Text = NO_FILA Or
            celdaIDCliente.Text = NO_FILA Or
            celdaCliente.Text = STR_VACIO Or
            celdaNIT.Text = STR_VACIO Or
            celdaIDMoneda.Text = NO_FILA Or
            celdaTasa.Text = NO_FILA Or
            celdaCosteo.Text = STR_VACIO Then
            MsgBox("You must enter all minium data", vbCritical)
            'Exit Function
            comprobar = False
        End If

        If Not IsDate(celdaFecha.Text) Then
            MsgBox("You have not entered a valid date", vbExclamation, "Notice")
            'Exit Function
            comprobar = False
        ElseIf Not Val(celdaAño.Text) = Year(celdaFecha.Text) Then
            MsgBox("The date entered does not match the year of the document", vbExclamation, "Notice")
            'Exit Function
            comprobar = False
        End If
        If Sesion.idGiro = 2 Then
            rbOpcionPagoNO.Checked = True
            rbOpcionPagoSI.Checked = False
        Else
            If rbOpcionPagoSI.Checked = False And rbOpcionPagoNO.Checked = False Then
                MsgBox("You did not specify if the office is with tax payment", vbExclamation, "Taxes")
                'Exit Function
                'rbOpcionPagoSI.Focus()
                comprobar = False
            End If
        End If
        Return comprobar
    End Function

    Private Function ClientesPrivilegio() As Boolean
        Dim logResult As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cliente As String = STR_VACIO

        Try
            strSQL = "SELECT c.cat_sist IDCliente"
            strSQL &= "      FROM Catalogos c"
            strSQL &= "           WHERE c.cat_clase = 'ConCredito' and c.cat_clave = 'CREDITO' and c.cat_sist ={IDCLiente} "

            strSQL = Replace(strSQL, "{IDCLiente}", celdaIDCliente.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cliente = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            If Cliente = celdaIDCliente.Text Then
                logResult = True
            Else
                logResult = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Function ClienteCash() As Boolean
        Dim logResult As Boolean = True
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim Cliente As String = STR_VACIO

        Try
            strSQL = "SELECT c.cli_forma Forma , c.cli_montoCR Plazo"
            strSQL &= "      FROM Clientes c"
            strSQL &= "           WHERE c.cli_sisemp = {empresa} AND c.cli_codigo = {IDCLiente}"

            strSQL = Replace(strSQL, "{IDCLiente}", celdaIDCliente.Text)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If (REA.GetString("Forma") = "CASH") Or (REA.GetDouble("Plazo") = INT_CERO) Then
                        logResult = True
                    Else
                        logResult = False
                    End If
                Loop
            End If
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Function ComprobarCredito() As Boolean
        Dim logResult As Boolean = True
        Dim strSQL As String
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        If ClientesPrivilegio() = False Then

            strSQL = "SELECT IFNULL(s2.plazo,0) plazo, IFNULL(ROUND((SUM(s2.saldo)-s2.credito),2),0) sobregiro, IFNULL(SUM(s2.vencida),0) vencidas, IFNULL(GROUP_CONCAT(IF(s2.vencida = 1, s2.doc, '') SEPARATOR '-'),'') fact_vencidas"
            strSQL &= "  FROM ("
            strSQL &= "     SELECT s1.Codigo, UPPER(c.cli_cliente) Nombre, s1.Fecha, s1.Numero doc, s1.Referencia, ROUND((s1.Total+s1.Cargos)-s1.Abonos,2) Saldo, s1.Tasa, c.cli_forma Forma, c.cli_montoCR Credito, IFNULL(Extension,c.cli_plazoCR) Plazo, DATE_ADD(s1.Fecha, INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY)Vence, DATEDIFF(CURDATE(), DATE_ADD(s1.Fecha, INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY)) Dias, IF(DATEDIFF(CURDATE(), DATE_ADD(s1.Fecha,"
            strSQL &= "          INTERVAL IFNULL(Extension,c.cli_plazoCR) DAY))>0,1, 0) vencida"
            strSQL &= "              FROM ("
            strSQL &= "                  SELECT ef.HDoc_Sis_Emp Empresa, ef.HDoc_Doc_Cat Tipo, ef.HDoc_Doc_Num Numero, ef.HDoc_DR1_Num Referencia, ef.HDoc_Doc_Fec Fecha, cf.ECta_Crgo_Ext Total, ef.HDoc_Doc_TC Tasa, ef.HDoc_DR1_Emp IDC, ef.HDoc_RF2_Num Extension, IFNULL(("
            strSQL &= "                     SELECT SUM(a1.ECta_Crgo_Ext)"
            strSQL &= "                         FROM ECtaCte a1"
            strSQL &= "                              WHERE a1.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND a1.ECta_Ref_Cat=ef.HDoc_Doc_Cat AND a1.ECta_Ref_Ano=ef.HDoc_Doc_Ano AND a1.ECta_Ref_Num=ef.HDoc_Doc_Num AND a1.ECta_FecDcmt <= CURDATE() AND NOT(a1.ECta_Doc_Cat=ef.HDoc_Doc_Cat)),0) Cargos, IFNULL(("
            strSQL &= "                                  SELECT SUM(a1.ECta_Abno_Ext)"
            strSQL &= "                                      FROM ECtaCte a1"
            strSQL &= "                                          WHERE a1.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND a1.ECta_Ref_Cat=ef.HDoc_Doc_Cat AND a1.ECta_Ref_Ano=ef.HDoc_Doc_Ano AND a1.ECta_Ref_Num=ef.HDoc_Doc_Num AND a1.ECta_FecDcmt <= CURDATE()),0) Abonos, IFNULL(("
            strSQL &= "                                       SELECT e1.HDoc_DR1_Emp"
            strSQL &= "                                    FROM Dcmtos_DTL_Pro r1"
            strSQL &= "                               LEFT JOIN Dcmtos_HDR e1 ON e1.HDoc_Sis_Emp=r1.PDoc_Sis_Emp AND e1.HDoc_Doc_Cat=r1.PDoc_Chi_Cat AND e1.HDoc_Doc_Ano=r1.PDoc_Chi_Ano AND e1.HDoc_Doc_Num=r1.PDoc_Chi_Num"
            strSQL &= "                          WHERE r1.PDoc_Sis_Emp = ef.HDoc_Sis_Emp AND r1.PDoc_Par_Cat=ef.HDoc_Doc_Cat AND r1.PDoc_Par_Ano=ef.HDoc_Doc_Ano AND r1.PDoc_Par_Num=ef.HDoc_Doc_Num AND r1.PDoc_Chi_Cat=395"
            strSQL &= "                       LIMIT 1),-1) Codigo"
            strSQL &= "                     FROM Dcmtos_HDR ef"
            strSQL &= "                  INNER JOIN ECtaCte cf ON cf.ECta_Sis_Emp=ef.HDoc_Sis_Emp AND cf.ECta_Doc_Cat = ef.HDoc_Doc_Cat AND cf.ECta_Doc_Ano = ef.HDoc_Doc_Ano AND cf.ECta_Doc_Num = ef.HDoc_Doc_Num"
            strSQL &= "             WHERE ef.HDoc_Sis_Emp={empresa} AND ef.HDoc_Doc_Cat=36 AND ef.HDoc_Doc_Fec <= curdate() AND ef.HDoc_Doc_Status=1 AND ef.HDoc_Emp_Cod = {cliente}) s1 "
            strSQL &= "           LEFT JOIN Clientes c ON c.cli_sisemp=s1.Empresa AND c.cli_codigo=s1.Codigo"
            strSQL &= "         WHERE NOT(ISNULL(c.cli_codigo))"
            strSQL &= "      HAVING (Saldo <> 0))s2 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cliente}", celdaIDCliente.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            REA.Read()
            If ClienteCash() = False Then
                If REA.GetDouble("sobregiro") > 0 Or REA.GetInt32("vencidas") > 0 Then
                    logResult = False
                    If REA.GetDouble("sobregiro") > 0 Then
                        MsgBox("Can not save the client is overdrawn. Rode: " & REA.GetDouble("sobregiro").ToString(FORMATO_MONEDA))
                    End If

                    If REA.GetString("vencidas") > 0 Then
                        MsgBox("This customer has overdue invoices. Bills: " & REA.GetString("fact_vencidas"))
                    End If
                End If
            Else
                logResult = False
            End If
            If logResult = False Then
                If PedirAutorizacionCredito("Cliente Insolvente") = True Then
                    logResult = True
                End If
            End If
            ComprobarCredito = logResult
        Else
            ComprobarCredito = logResult
        End If
    End Function

    Private Function PedirAutorizacionCredito(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "CREDITO"
        Dim frm As frmAutorización
        PedirAutorizacionCredito = False

        frm = New frmAutorización
        frm.Iniciar(ID_MOD, STR_MARGEN, 0, "Autorizar Despacho")
        If Sesion.idGiro = 2 Then ' Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            PedirAutorizacionCredito = True
        Else
            frm.ShowDialog(Me)
            If frm.Aceptado Then
                If frm.Nivel Then
                    PedirAutorizacionCredito = True
                Else
                    MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
                End If
            End If
        End If
        'frm.ShowDialog(Me)
        'If frm.Aceptado Then
        '    If frm.Nivel Then
        '        PedirAutorizacionCredito = True
        '    Else
        '        MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
        '    End If
        'End If
        LogResult = True
    End Function

    'Quita del listado todas las referencias con descargo igual a cero
    Private Sub DepurarReferencias()
        Dim i As Integer
        For i = dgReferencias.Rows.Count - 1 To vbEmpty Step NO_FILA
            If dgReferencias.Rows(i).Cells("colDescargo").Value = vbEmpty Then
                'Sólo quita las referencias vacías si no están ya guardadas
                'Los descargos vacíos corresponden a facturas anuladas
                If dgReferencias.Rows(i).Cells("colExist").Value = vbEmpty Then
                    dgReferencias.Rows.RemoveAt(i)
                End If
            End If
        Next
    End Sub

    Private Function sqlGuardarEncabezado() As Boolean
        Dim logResultado As Boolean = True
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try

            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAño.Text           'Documento
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = celdaFecha.Text

            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text     'Coctacto
            chdr.HDOC_EMP_NIT = celdaNIT.Text
            chdr.HDOC_EMP_TEL = celdaTelefono.Text

            chdr.HDOC_DOC_TC = celdaTasa.Text           'Cod Moneda
            chdr.HDOC_DOC_MON = celdaIDMoneda.Text      ' Tasa de Cambio

            chdr.HDOC_RF1_COD = celdaDetalle.Text       'Detalle
            chdr.HDOC_RF1_TXT = celdaObservaciones.Text     'Observaciones

            If Me.Tag = "Nuevo" Then
                chdr.HDOC_DR1_CAT = vbEmpty                     'Control de cambios
            Else
                chdr.HDOC_DR1_CAT = (intCambio + 1)
            End If

            'Campo para Guardar Incoterm
            chdr.HDOC_DR2_CAT = celdaIdCosteo.Text
            ' Tarifa de Muestra
            chdr.HDOC_ANT_COM = IIf(checkTarifa.Checked = True, INT_UNO, INT_CERO)

            chdr.HDOC_DR1_NUM = GetReferencia()            'Referencia
            chdr.HDOC_DR1_EMP = IIf(rbOpcionPagoSI.Checked = True, INT_UNO, vbEmpty)        'Pago de impuestos

            chdr.HDOC_USUARIO = celdaUsuario.Text           'Usuario
            chdr.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)         'Estado: 1/Activo
            chdr.HDOC_RF2_COD = CeldaCarga.Text

            If rbFleteEmpresa.Checked = True Then
                chdr.HDOC_RF1_NUM = INT_CERO
            ElseIf rbFleteCliente.Checked = True Then
                chdr.HDOC_RF1_NUM = CInt(celdaIDCliente.Text)
            Else
                chdr.HDOC_RF1_NUM = INT_UNO
            End If

            If rbGastosEmpresa.Checked = True Then
                chdr.HDOC_RF2_NUM = INT_CERO
            ElseIf rbGastosCliente.Checked = True Then
                chdr.HDOC_RF2_NUM = CInt(celdaIDCliente.Text)
            Else
                chdr.HDOC_RF2_NUM = INT_UNO
            End If

            chdr.HDOC_RF2_TXT = celdaComentario.Text            'Guarda comentario de Gastos
            chdr.HDOC_PRO_DCAT = 1

            If checkConsignacion.Checked = True Then
                chdr.HDOC_PRO_DANO = 1
            Else
                chdr.HDOC_PRO_DANO = 0
            End If

            If checkPago.Checked = True Then
                chdr.HDOC_PRO_DNUM = 1
            Else
                chdr.HDOC_PRO_DNUM = 0
            End If
            If checkTraslado.Checked = True Then
                chdr.HDOC_RF1_DBL = 1
            Else
                chdr.HDOC_RF1_DBL = 0
            End If

            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function sqlGuardarDetalle() As Boolean

        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim Orden As Double
        Dim Linea As Integer = 0
        Dim j As Integer = 0
        Dim Detalle As Integer = 0

        Dtl.CONEXION = strConexion

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                Dtl.DDOC_DOC_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                    strSQL2 = "SELECT IFNULL(MAX(d.DDoc_Doc_Lin + 1),1) Linea"
                    strSQL2 &= "     FROM Dcmtos_DTL d"
                    strSQL2 &= "          WHERE d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 48 and d.DDoc_Doc_Ano = {anio} and d.DDoc_Doc_Num = {numero}"

                    strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                    strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
                    strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL2, conec)
                    Using conec
                        Linea = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using
                    Dtl.DDOC_DOC_LIN = Linea
                    dgDetalle.Rows(i).Cells("colIDD").Value = Linea
                    dgDetalle.Rows(i).Cells("colIDDesc").Value = Linea
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                End If

                Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                Dtl.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colNumParte").Value
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colArticulo").Value
                Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colBase").Value
                Dtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colBase").Value

                Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                Dtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colExistencia").Value
                If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    strSQL = "SELECT d.DDoc_Prd_QTY - ifnull((SELECT SUM(p.PDoc_QTY_Pro)"
                    strSQL &= "      FROM Dcmtos_DTL_Pro p"
                    strSQL &= "          WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDOc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND NOT(p.PDoc_Chi_Cat = 48 AND p.PDoc_Par_Ano = {año} AND p.PDoc_Chi_Num = {numeroInst} AND p.PDoc_Chi_Lin ={lineaIns})),0)"
                    strSQL &= "      FROM Dcmtos_DTL d"
                    strSQL &= "    WHERE d.DDoc_Sis_Emp  = {empresa} AND d.DDoc_Doc_Cat  = 75 AND d.DDoc_Doc_Ano  = {anio} AND d.DDoc_Doc_Num  IN({numero}) AND d.DDoc_Doc_Lin = {linea}"

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", dgDetalle.Rows(i).Cells("colAno").Value)
                    strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colNPedido").Value)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    strSQL = Replace(strSQL, "{año}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{numeroInst}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{lineaIns}", dgDetalle.Rows(i).Cells("colIDD").Value)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        Orden = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using
                    Dtl.DDOC_PRD_DSQ = Orden

                    If CDbl(Orden - dgDetalle.Rows(i).Cells("colADespachar").Value) < 0 Then
                        Dtl.DDOC_RF1_DBL = 0
                    Else
                        Dtl.DDOC_RF1_DBL = CDbl(Orden - dgDetalle.Rows(i).Cells("colADespachar").Value)
                    End If
                Else
                    Dtl.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("colOrden").Value
                    Dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colPendiente").Value
                End If

                Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colADespachar").Value

                Dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCodDestino").Value
                Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colCodOriginal").Value

                Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReference").Value
                Dtl.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colFech").Value
                If dgDetalle.Rows(i).Cells("colObservation").Value = vbNullString Then
                Else
                    Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colObservation").Value
                End If

                Dtl.DDOC_RF2_TXT = "e/" & dgDetalle.Rows(i).Cells("colExistencia").Value & "/p/" & dgDetalle.Rows(i).Cells("colNPedido").Value & "/d/" & dgDetalle.Rows(i).Cells("colADespachar").Value

                Dtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colCodDestino").Value
                Dtl.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colADespachar").Value
                Dtl.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colLibrasAdicionales").Value
                Dtl.DDOC_PRD_FOB = ((CDbl(dgDetalle.Rows(i).Cells("colADespachar").Value) + CDbl(dgDetalle.Rows(i).Cells("colLibrasAdicionales").Value)) * dgDetalle.Rows(i).Cells("colPrecio").Value)

                If dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    If Dtl.Actualizar() = False And dgDetalle.Rows(i).Visible = True Then
                        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 And dgDetalle.Rows(i).Visible = True Then
                    If Dtl.Guardar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
                sqlGuardarDescargo(i)
                sqlAgregarDescargo(i)

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub sqlGuardarDescargo(ByVal i As Integer)
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        'Parent: 75/Pedido
        'Child:  48/Instrucción de despacho
        Dim dblCantidad As Double
        Dim j As Integer = 0
        Dim Linea As Integer = 0
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL2 As String = STR_VACIO

        clsDTLPro.CONEXION = strConexion
        Try
            clsDTLPro.PDOC_SIS_EMP = celdaEmpresa.Text
            clsDTLPro.PDOC_PAR_CAT = 75
            clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAno").Value
            clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNPedido").Value
            clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

            clsDTLPro.PDOC_CHI_CAT = 48
            clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
            clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text

            If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then

                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
            ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
            End If

            clsDTLPro.PDOC_PROV_COD = celdaIDCliente.Text                                'Cód. del proveedor
            clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodOriginal").Value           'Cód. del pedido
            clsDTLPro.PDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colNumParte").Value         'DDoc_Prd_PNr/N° de parte
            clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value            'DDoc_Prd_NET/Precio neto

            dblCantidad = vbEmpty
            If checkActivar.Checked = True Then
                If Sesion.idGiro = 2 Then
                    dblCantidad = dgDetalle.Rows(i).Cells("colADespachar").Value
                Else
                    dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                End If

            End If

            If checkActivar.Checked = True Then
                clsDTLPro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantDescargo").Value     'A Despachar
                clsDTLPro.PDOC_QTY_PRO = dblCantidad                                        'A despachar (vacío para documentos anulados/inactivos)
            Else
                clsDTLPro.PDOC_QTY_ORD = INT_CERO      'A Despachar
                clsDTLPro.PDOC_QTY_PRO = INT_CERO                                        'A despachar (vacío para documentos anulados/inactivos)

            End If

            If dgDetalle.Rows(i).Cells("colXtra").Value = 0 And dgDetalle.Rows(i).Visible = True Then
                If clsDTLPro.Actualizar() = False Then
                    MsgBox(clsDTLPro.MERROR.ToString)
                End If

            ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 And dgDetalle.Rows(i).Visible = True Then
                If clsDTLPro.Guardar() = False Then
                    MsgBox(clsDTLPro.MERROR.ToString)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Guarda los bultos/cajas de este documento
    Private Function GuardarBultos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        Dim j As Integer = 0
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Linea As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                DtlBox.BDOC_DOC_CAT = celdaCatalogo.Text
                DtlBox.BDOC_DOC_ANO = celdaAño.Text
                DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                    DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                End If

                DtlBox.BDOC_BOX_LIN = 1
                DtlBox.BDOC_BOX_ORD = I_CODIGO
                DtlBox.BDOC_BOX_COD = I_CODIGO
                DtlBox.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBulto").Value
                DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colADespachar").Value

                If dgDetalle.Rows(i).Cells("colXtra").Value = 0 And dgDetalle.Rows(i).Visible = True Then
                    If DtlBox.PUPDATE = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 And dgDetalle.Rows(i).Visible = True Then
                    If DtlBox.PINSERT = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function


    Private Function GuardarBultosHSM() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        'Dim k As Integer = 0
        Dim strSQL2 As String = STR_VACIO
        Dim Linea As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                For j As Integer = 0 To dgbultos1.Rows.Count - 1
                    If dgDetalle.Rows(i).Cells("colIDD").Value = dgbultos1.Rows(j).Cells("colLineaDet").Value Then
                        DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                        DtlBox.BDOC_DOC_CAT = celdaCatalogo.Text
                        DtlBox.BDOC_DOC_ANO = celdaAño.Text
                        DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                        If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                            DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                        ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                            DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                        End If

                        DtlBox.BDOC_BOX_LIN = dgbultos1.Rows(j).Cells("colBultoNo").Value
                        DtlBox.BDOC_BOX_REF = dgbultos1.Rows(j).Cells("productoCod").Value
                        DtlBox.BDOC_BOX_COD = dgbultos1.Rows(j).Cells("colMarca").Value
                        DtlBox.BDOC_BOX_CTG = dgbultos1.Rows(j).Cells("colCategoria").Value

                        DtlBox.BDOC_BOX_ORD = INT_CERO
                        DtlBox.BDOC_BOX_QTY = INT_UNO
                        DtlBox.BDOC_BOX_LB = dgbultos1.Rows(j).Cells("colPeso").Value

                        If dgbultos1.Rows(j).Cells("colExtra1").Value = 0 Then
                            If DtlBox.PINSERT = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgbultos1.Rows(j).Cells("colExtra1").Value = 1 Then
                            If DtlBox.PUPDATE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgbultos1.Rows(j).Cells("colExtra1").Value = 2 Then
                            If DtlBox.PDELETE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not Delete the document", MsgBoxStyle.Critical)
                            End If
                        End If
                    End If
                Next
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarCajas() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        'Dim k As Integer = 0
        Dim strSQL2 As String = STR_VACIO
        Dim Linea As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                For j As Integer = 0 To dgbultos1.Rows.Count - 1
                    If dgDetalle.Rows(i).Cells("colIDD").Value = dgbultos1.Rows(j).Cells("colLineaDet").Value Then
                        DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                        DtlBox.BDOC_DOC_CAT = celdaCatalogo.Text
                        DtlBox.BDOC_DOC_ANO = celdaAño.Text
                        DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                        If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                            DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                        ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                            DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                        End If

                        DtlBox.BDOC_BOX_LIN = dgbultos1.Rows(j).Cells("colBultoNo").Value
                        DtlBox.BDOC_BOX_COD = dgbultos1.Rows(j).Cells("colMarca").Value
                        DtlBox.BDOC_BOX_CTG = dgbultos1.Rows(j).Cells("colCategoria").Value

                        DtlBox.BDOC_BOX_ORD = INT_CERO
                        DtlBox.BDOC_BOX_QTY = INT_UNO
                        DtlBox.BDOC_BOX_LB = dgbultos1.Rows(j).Cells("colPeso").Value

                        If dgbultos1.Rows(j).Cells("colExtra1").Value = 0 Then
                            If DtlBox.PINSERT = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgbultos1.Rows(j).Cells("colExtra1").Value = 1 Then
                            If DtlBox.PUPDATE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                            End If
                        ElseIf dgbultos1.Rows(j).Cells("colExtra1").Value = 2 Then
                            If DtlBox.PDELETE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not Delete the document", MsgBoxStyle.Critical)
                            End If
                        End If
                    End If
                Next
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Query para guardar Existencias
    Private Sub sqlGuardarExistencias()
        Dim logResultado As Boolean = True
        Dim Ex As New Tablas.TEXISTENCIA
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim i As Integer
        Dim dblBultos As Double
        Dim dblSalida As Double
        Dim strSQL As String
        Dim j As Integer
        Dim strSQL2 As String = STR_VACIO
        Dim Linea As Integer = 0

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                strSQL = "SELECT (SELECT (IFNULL(MAX(Ex_Id),0) + 1) ID FROM Existencia) ID, inv_artcodigo Articulo, inv_lugarfab Pais, inv_prodlote Lote, inv_prodano Ciclo, inv_prodsem Semana, inv_costo Costo "
                strSQL &= "   FROM Inventarios "
                strSQL &= "     WHERE inv_sisemp ={empresa}  AND inv_numero ={codigo} "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{codigo}", dgDetalle.Rows(i).Cells("colCodigo").Value)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()

                dblSalida = dgDetalle.Rows(i).Cells("colADespachar").Value
                dblBultos = dgDetalle.Rows(i).Cells("colBulto").Value

                Ex.CONEXION = strConexion

                Ex.EX_DOC_EMP = celdaEmpresa.Text
                Ex.EX_DOC_TIPO = celdaCatalogo.Text
                Ex.EX_DOC_CICLO = celdaAño.Text
                Ex.EX_DOC_NUM = celdaNumero.Text
                Ex.Ex_Doc_Fec_NET = celdaFecha.Text

                'If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                Ex.EX_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                'ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                '    Ex.EX_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                'End If
                Ex.Ex_Fec_NET = Now
                Ex.EX_ID = REA.GetInt32("ID")
                Ex.EX_ARTICULO = REA.GetString("Articulo")
                Ex.EX_CODIGO = dgDetalle.Rows(i).Cells("colCodigo").Value
                Ex.EX_DESCRIPCION = dgDetalle.Rows(i).Cells("colArticulo").Value
                Ex.EX_PAIS = REA.GetString("Pais")
                Ex.EX_REFERENCIA = dgDetalle.Rows(i).Cells("colReference").Value
                Ex.EX_LOTE = REA.GetString("Lote")
                Ex.EX_CICLO = REA.GetInt32("Ciclo")
                Ex.EX_SEMANA = REA.GetInt32("semana")
                Ex.EX_UM = dgDetalle.Rows(i).Cells("colBase").Value
                Ex.EX_INGRESO = vbEmpty
                Ex.EX_EGRESO = dblSalida
                Ex.EX_BULTOS = dblBultos
                Ex.EX_MONEDA = celdaIDMoneda.Text
                Ex.EX_TC = celdaTasa.Text
                Ex.EX_COSTO = REA.GetDouble("Costo").ToString(FORMATO_MONEDA)
                Ex.EX_TOTAL = (REA.GetDouble("Costo") * dblSalida)

                If dgDetalle.Rows(i).Cells("colXtra").Value = 0 And dgDetalle.Rows(i).Visible = True Then
                    If Ex.PUPDATE = False Then
                        MsgBox(Ex.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 And dgDetalle.Rows(i).Visible = True Then
                    If Ex.PINSERT = False Then
                        MsgBox(Ex.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                    End If
                End If
            End If
        Next

    End Sub

    Private Sub GuardarBultosDet()
        Dim boxPro As New Tablas.TDCMTOS_DTL_BOX_PRO
        Dim i As Integer = 0

        boxPro.CONEXION = strConexion

        Try
            For i = 0 To dgbultos1.Rows.Count - 1
                boxPro.BPDOC_SIS_EMP = Sesion.IdEmpresa
                boxPro.BPDOC_PAR_CAT = dgbultos1.Rows(i).Cells("colCatalogo1").Value
                boxPro.BPDOC_PAR_ANO = dgbultos1.Rows(i).Cells("colAnio1").Value
                boxPro.BPDOC_PAR_NUM = dgbultos1.Rows(i).Cells("colNumero1").Value
                boxPro.BPDOC_PAR_LIN = dgbultos1.Rows(i).Cells("colLinea1").Value
                boxPro.BPDOC_BOX_LIN = dgbultos1.Rows(i).Cells("colBultoNo").Value
                boxPro.BPDOC_CHI_CAT = celdaCatalogo.Text
                boxPro.BPDOC_CHI_ANO = celdaAño.Text
                boxPro.BPDOC_CHI_NUM = celdaNumero.Text
                boxPro.BPDOC_CHI_LIN = dgbultos1.Rows(i).Cells("colLineaDet").Value

                If dgbultos1.Rows(i).Cells("colExtra1").Value = 0 Then
                    If boxPro.PINSERT = False Then
                        MsgBox(boxPro.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgbultos1.Rows(i).Cells("colExtra1").Value = 1 Then
                    'If boxPro.PUPDATE = False Then
                    '    MsgBox(boxPro.MERROR.ToString & "Could not Update the document", MsgBoxStyle.Critical)
                    'End If

                    'NO HAY NECESIDAD DE ACTUALIZAR PORQUE GUARDA LLAVE COMPLETA, ENTONCES SOLO NECESITA INSERTAR Y BORRAR

                ElseIf dgbultos1.Rows(i).Cells("colExtra1").Value = 2 Then
                    If boxPro.PDELETE = False Then
                        MsgBox(boxPro.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub sqlAgregarDescargo(ByVal i As Integer)
        Dim clsDTLPro2 As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intID As Integer
        Dim j As Integer = 0
        Dim dblCantidad As Double
        Dim strSQL2 As String = STR_VACIO
        Dim Linea As Integer = 0

        clsDTLPro2.CONEXION = strConexion
        Try
            clsDTLPro2.PDOC_SIS_EMP = celdaEmpresa.Text
            clsDTLPro2.PDOC_PAR_CAT = 47
            clsDTLPro2.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioDesc").Value
            clsDTLPro2.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumDesc").Value
            clsDTLPro2.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea2Desc").Value

            clsDTLPro2.PDOC_CHI_CAT = 48
            clsDTLPro2.PDOC_CHI_ANO = celdaAño.Text
            clsDTLPro2.PDOC_CHI_NUM = celdaNumero.Text

            If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                clsDTLPro2.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
            ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                clsDTLPro2.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
            End If

            clsDTLPro2.PDOC_PROV_COD = celdaIDCliente.Text                                'Cód. del proveedor
            clsDTLPro2.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodDesc").Value          'Cód. del pedido
            clsDTLPro2.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value            'DDoc_Prd_NET/Precio neto

            dblCantidad = vbEmpty
            If checkActivar.Checked = True Then
                'dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                If Sesion.idGiro = 2 Then
                    dblCantidad = dgDetalle.Rows(i).Cells("colADespachar").Value
                Else
                    dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                End If
                clsDTLPro2.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantDescargo").Value
                If dgDetalle.Rows(i).Cells("colBase").Value = intKgs Then
                    clsDTLPro2.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantDescargo").Value
                Else
                    clsDTLPro2.PDOC_QTY_PRO = dblCantidad
                End If
            Else
                clsDTLPro2.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantDescargo").Value
                clsDTLPro2.PDOC_QTY_PRO = dblCantidad
            End If


            If dgDetalle.Rows(i).Cells("colXtra").Value = 0 And dgDetalle.Rows(i).Visible = True Then
                ActualizarDTL_PRO(dblCantidad, i)
            ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 And dgDetalle.Rows(i).Visible = True Then
                If clsDTLPro2.Guardar() = False Then
                    MsgBox(clsDTLPro2.MERROR.ToString)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function ActualizarDTL_PRO(ByVal Cantidad As Double, ByVal i As Integer)
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = " UPDATE Dcmtos_DTL_Pro p "
            strSQL &= "   SET p.PDoc_Sis_Emp = {empresa}, p.PDoc_Par_Cat = 47, p.PDoc_Par_Ano = {anio}, p.PDoc_Par_Num = {num}, p.PDoc_Par_Lin = {linea}, p.PDoc_Prd_Cod = {cod}, p.PDoc_Prd_NET = {net}, p.PDoc_QTY_Ord = {ord}, p.PDoc_QTY_Pro = {pro} "
            strSQL &= "        WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Chi_Ano = {chiAnio} AND p.PDoc_Chi_Num = {chiNum} AND p.PDoc_Chi_Lin = {chiLin} AND p.PDoc_Par_Cat = 47 "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Dcmtos_DTL_Pro p "
                strSQL &= "   SET p.PDoc_Sis_Emp = {empresa}, p.PDoc_Par_Cat = 47, p.PDoc_Par_Ano = {anio}, p.PDoc_Par_Num = {num}, p.PDoc_Par_Lin = {linea}, p.PDoc_Prd_Cod = {cod}, p.PDoc_Prd_NET = {net}, p.PDoc_QTY_Ord = {ord}, p.PDoc_QTY_Pro = {pro} "
                strSQL &= "        WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Chi_Ano = {chiAnio} AND p.PDoc_Chi_Num = {chiNum} AND p.PDoc_Chi_Lin = {chiLin} AND p.PDoc_Par_Cat = 47 "
            End If
            ' DATOS QUE SE VAN A ACTUALIZAR
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgDetalle.Rows(i).Cells("colAnioDesc").Value)
            strSQL = Replace(strSQL, "{num}", dgDetalle.Rows(i).Cells("colNumDesc").Value)
            strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea2Desc").Value)
            strSQL = Replace(strSQL, "{cod}", dgDetalle.Rows(i).Cells("colCodDesc").Value)
            strSQL = Replace(strSQL, "{net}", dgDetalle.Rows(i).Cells("colPrecio").Value)
            strSQL = Replace(strSQL, "{ord}", dgDetalle.Rows(i).Cells("colCantDescargo").Value)
            strSQL = Replace(strSQL, "{pro}", Cantidad)

            ' DATOS DEL WHERE
            strSQL = Replace(strSQL, "{chiAnio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{chiNum}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{chiLin}", dgDetalle.Rows(i).Cells("colIDD").Value)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Using conec
            Return COM.ExecuteNonQuery
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        End Using

    End Function

    Public Function GetReferencia() As String
        Dim i As Integer
        Dim strReferencia As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim referencia As String = STR_VACIO

        Try
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(j).Visible = True Then

                    If j = 0 Then
                        referencia = dgDetalle.Rows(j).Cells("colReference").Value
                    Else
                        referencia = referencia & " / " & dgDetalle.Rows(j).Cells("colReference").Value
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return referencia
    End Function
    Public Function ValidarDependencia() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logValidar As Boolean = True
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strTemp As String
        strSQL = "SELECT COUNT(PDoc_Chi_Num)"
        strSQL &= "     FROM Dcmtos_DTL_Pro"
        strSQL &= "  WHERE PDoc_Par_Cat= 48 AND PDoc_Par_Ano= {año} AND PDoc_Par_Num={numero}"

        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            strTemp = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
        If strTemp > 0 Then
            logValidar = False
        End If
        Return logValidar
    End Function
    'Bprrar encabezado
    Public Function BorrarEncabezadoInstruccion() As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 48
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Detalle Instruccion 
    Private Function BorrarDetalleInst() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO

        Try
            If LogBorrar = True Then
                strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 48 AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero}  ; "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                Dim dtl As New clsDcmtos_DTL
                dtl.CONEXION = strConexion
                dtl.Borrar(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Bultos 
    Private Function BorrarBultosInstruccion() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '   For i = 0 To dgDetalle.Rows.Count - 1
                strSQl &= "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = 48 AND BDoc_Doc_Ano  = {anio} AND BDoc_Doc_Num = {numero}  ;"
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                '    Next
                Dim box As New Tablas.TDCMTOS_DTL_BOX
                box.CONEXION = strConexion
                box.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Function BorrarBultosInstPro() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '   For i = 0 To dgDetalle.Rows.Count - 1
                strSQl &= "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = 48 AND BPDoc_Chi_Ano  = {anio} AND BPDoc_Chi_Num = {numero}  ;"
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                '    Next
                Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                box.CONEXION = strConexion
                box.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Relacion 
    Private Function BorrarDescargosInst() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 48 AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero}  "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)

                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Existencia 
    Private Function BorrarExistenciaInst() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                strSQl = "Ex_Doc_Emp = {empresa} AND Ex_Doc_Tipo = 48 AND Ex_Doc_Ciclo = {anio} AND Ex_Doc_Num = {numero}  "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)

                Dim existencia As New Tablas.TEXISTENCIA
                existencia.CONEXION = strConexion
                existencia.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
#End Region

#Region "Eventos"

    Private Sub frmIntDespacho_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim logLibre As String = STR_VACIO

        'Id para KGS y LBS
        Dim strSQL As String
        strSQL = "SELECT cat_num "
        strSQL &= "  FROM Catalogos"
        strSQL &= "      WHERE cat_clase='Medidas' AND cat_clave='LBS'"

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intLbs = COM.ExecuteScalar
        conec.Close()

        Dim strSQL2 As String
        strSQL2 = "SELECT cat_num "
        strSQL2 &= "  FROM Catalogos"
        strSQL2 &= "      WHERE cat_clase='Medidas' AND cat_clave='KGS'"
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL2, conec)
        Using conec
            intKgs = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        Dim strSQL3 As String
        strSQL3 = "SELECT cat_sist "
        strSQL3 &= "  FROM Catalogos"
        strSQL3 &= "      WHERE  cat_clase='Despacho' AND cat_clave ='Libre'"
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL3, conec)
        Using conec
            logLibre = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        'Factor de conversión de medidas (división)
        Dim strSQL4 As String
        strSQL4 = "SELECT cat_sist "
        strSQL4 &= "  FROM Catalogos"
        strSQL4 &= "      WHERE cat_clase='Medidas' AND cat_clave='KGS'"
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL4, conec)
        Using conec
            dblFactorKgs = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        dblFactorLbs = (1 / dblFactorKgs)

        dtpInicio.Value = Today.AddMonths(NO_FILA)
        dtpFin.Value = Today


        rbFleteEmpresa.Text = Sesion.Empresa
        rbFleteCliente.Text = "Customer"
        rbFleteOtro.Text = "Not Apply"

        rbGastosEmpresa.Text = Sesion.Empresa
        rbGastosCliente.Text = "Customer"
        rbGastosOtros.Text = "Not Apply"

        Accessos()
        MostrarLista()
    End Sub

    Private Sub frmIntDespacho_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Function NuevaInst() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}   "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 48)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim clsConta As New clsContabilidad
        Dim longID As Long
        Dim logPrint As Boolean
        Dim Cantidad As Integer = 0
        Dim intLimiteLineas As Integer = 1000

        If logEditar = True Then
            If logBloquear Then
                strSQL = "SELECT COUNT(PDoc_Chi_Num)"
                strSQL &= "     FROM Dcmtos_DTL_Pro"
                strSQL &= "  WHERE PDoc_Par_Cat= 48 AND PDoc_Par_Ano= {año} AND PDoc_Par_Num={numero}"

                strSQL = Replace(strSQL, "{año}", celdaAño.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    strTemp = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using

                If strTemp > 0 Then
                    MsgBox("This instruction has already been billed" & vbCr & vbCr & "Invoicing: " & strTemp & vbCr & vbCr & "The changes were saved but will not be reflected in the bill", vbExclamation, "Notice")
                    Exit Sub
                End If
            End If

            If logInsertar Then

                If Me.Tag = "Nuevo" Then
                    If ComprobarCampos() Then
                        ComprobarCampos()
                        If ComprobarFilaDetalle() = True Then
                            If ComprobarPago() Then
                                'EliminarLineas()
                                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                    ' If dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                                    If (dgDetalle.Rows(i).Cells("colXtra").Value = 1 Or dgDetalle.Rows(i).Cells("colXtra").Value = 0) And dgDetalle.Rows(i).Visible = True Then
                                        Cantidad = Cantidad + 1
                                    End If
                                Next
                                If Sesion.idGiro = 2 Then
                                    intLimiteLineas = 500
                                    'ElseIf Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Then
                                    '    intLimiteLineas = 4
                                End If
                                If Cantidad > intLimiteLineas Then

                                    MsgBox("It is not possible to save an instruction with more than " & intLimiteLineas & " lines of detail", MsgBoxStyle.Information)
                                    Exit Sub


                                Else

                                    If Sesion.IdEmpresa = 12 Then
                                        If MsgBox("Are you sure to continue with selected freigth and customs charges?", vbQuestion + vbYesNo, "Question") = vbNo Then
                                            Exit Sub
                                        End If
                                    End If
                                    If ComprobarCredito() Then
                                        longID = celdaNumero.Text
                                        celdaNumero.Text = NuevaInst()

                                        If celdaNumero.Text > 0 Then
                                            sqlGuardarEncabezado()

                                            sqlGuardarDetalle()

                                            'Quita del listado las referencias sin descargo
                                            DepurarReferencias()

                                            'sqlGuardarDescargo()
                                            'sqlAgregarDescargo()

                                            sqlGuardarExistencias()

                                            If (Sesion.idGiro = 2) Then
                                                GuardarBultosHSM() 'Guarda en dtl_box catalogo 48
                                                GuardarBultosDet() ' Guarda en dtl_box_pro con la llave del 47 y 48
                                            Else
                                                GuardarBultos()
                                            End If

                                            If Sesion.idGiro = 2 Then
                                                If checkTraslado.Checked = True Then
                                                    If cFunciones.SQLVerificarCierre(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text) = 0 Then
                                                        clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, celdaFecha.Text)
                                                    Else
                                                        clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                                                    End If
                                                End If
                                            End If
                                            'Dim acAdd As clsFunciones.AccEnum
                                            cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, -1, 48, Val(celdaAño.Text), Val(celdaNumero.Text), Sistema.Version)

                                            If MsgBox("The document has been saved." & vbCr & vbCr & "¿To Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                                logPrint = True
                                                Dim intNumero As Integer
                                                Dim intAnio As Integer

                                                intNumero = celdaNumero.Text
                                                intAnio = celdaAño.Text
                                                Dim CReportes As New clsReportes
                                                CReportes.InstruccionDDespacho(celdaNumero.Text, celdaAño.Text)
                                            End If

                                            MostrarLista()
                                            queryListaPrincipal()
                                        End If
                                        'End If
                                    End If
                                End If
                            End If
                        End If
                    End If

                    'ElseIf logEditar Then
                ElseIf Me.Tag = "Mod" Then    'ACTUALIZAR
                    ComprobarCampos()
                    If ComprobarFilaDetalle() = True Then


                        EliminarLineas()

                        If Sesion.idGiro = 2 Then
                            intLimiteLineas = 75
                            'ElseIf Sesion.IdEmpresa = 11 Then
                            '    intLimiteLineas = 4
                        End If
                        If dgDetalle.Rows.Count > intLimiteLineas Then
                            MsgBox("It is not possible to save an instruction with more than " & intLimiteLineas & " lines of detail", MsgBoxStyle.Information)
                            Exit Sub
                        Else

                            sqlGuardarEncabezado()
                            'EliminarLineas()
                            sqlGuardarDetalle()

                            'sqlGuardarDescargo()
                            'sqlAgregarDescargo()

                            sqlGuardarExistencias()

                            If (Sesion.idGiro = 2) Then
                                GuardarBultosHSM() 'Guarda en dtl_box catalogo 48
                                GuardarBultosDet() ' Guarda en dtl_box_pro con la llave del 47 y 48

                            Else
                                GuardarBultos()
                            End If
                            If Sesion.idGiro = 2 Then
                                If checkTraslado.Checked = True Then
                                    If cFunciones.SQLVerificarCierre(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text) = 0 Then
                                        clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, celdaFecha.Text)
                                    Else
                                        clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                                    End If

                                End If
                            End If

                            'Dim acUpdate As clsFunciones.AccEnum
                            cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, -1, 48, Val(celdaAño.Text), Val(celdaNumero.Text), Sistema.Version)

                            If MsgBox("The document has been updated." & vbCr & vbCr & "¿To Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                logPrint = True
                                Dim intNumero As Integer
                                Dim intAnio As Integer

                                intNumero = celdaNumero.Text
                                intAnio = celdaAño.Text
                                Dim CReportes As New clsReportes
                                CReportes.InstruccionDDespacho(celdaNumero.Text, celdaAño.Text)
                            End If
                        End If
                        MostrarLista()
                        queryListaPrincipal()
                    End If
                Else
                    MsgBox("It was not possible to classify the operation to save", vbExclamation, "Notice")
                End If
            End If
        Else
            MsgBox("You do not have access to save a new instruction", vbInformation)
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim selectFecha As New frmDateTimePicker
        Me.Tag = "Nuevo"

        If logInsertar = True Then
            Limpiar()
            celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            MostrarLista(False, True)
            celdaAño.Text = cFunciones.AñoMySQL
            celdaNumero.Text = -1

            selectFecha.ShowDialog(Me)
            If selectFecha.DialogResult = DialogResult.OK Then
                celdaFecha.Text = selectFecha.LLave
            End If
            celdaFecha.Enabled = False

            '            celdaFecha.Text = (cFunciones.HoyMySQL).ToString(FORMATO_MYSQL)

            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 48
            celdaUsuario.Text = Sesion.Usuario
            CeldaCarga.Text = 0
            celdaMoneda.Text = "US$"
            celdaIDMoneda.Text = 178
            botonMas.Enabled = True
            botonEliminar.Enabled = True
            botonQuitDetalle.Enabled = True
            celdaSubTotal.Enabled = True
            celdaTotal.Enabled = True
            checkActivar.Enabled = True
            checkActivar.Checked = True
            celdaIdCosteo.Text = INT_CERO
            celdaCosteo.Clear()

            logComentario = False
            logBloquear = False
            dgDetalle.ReadOnly = False

            rbFleteCliente.Checked = True
            rbGastosCliente.Checked = True

            If Sesion.idGiro = 2 Then
                rbOpcionPagoNO.Checked = True
                rbOpcionPagoNO.Enabled = False
                rbOpcionPagoSI.Enabled = False
                checkTraslado.Visible = True
                checkTraslado.Checked = False
            Else
                rbOpcionPagoNO.Enabled = True
                rbOpcionPagoSI.Enabled = True
                checkTraslado.Visible = False
                checkTraslado.Checked = False
            End If

        Else
            MsgBox("You do not have access to create a new instruction")
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If

        intMarca = vbEmpty
        intActual = vbEmpty
        intUltima = vbEmpty

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            queryListaPrincipal()
        End If

    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonClientes.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa} and cli_tipo = 0  and cli_status = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try

            frm.Titulo = "Client"
            frm.Campos = " DISTINCT cli_codigo Code, cli_cliente Client, cli_direccion Direction, cli_telefono Phone, cli_nit NIT"
            frm.Tabla = " Clientes"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = " cli_cliente "
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaTelefono.Text = frm.Dato3
                celdaNIT.Text = frm.Dato4

                dgPedidos.Rows.Clear()
                DocumentosPendientes()
                SqlDetallePorProcesar2(True)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato


                strSQL = " SELECT cat_sist"
                strSQL &= "      FROM Catalogos"
                strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

                strSQL = Replace(strSQL, "{Numero}", frm.LLave)


                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    Cambio = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using
                If Cambio > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(celdaFecha.Text)
                Else
                    celdaTasa.Text = Cambio
                End If
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Limpiar()
        Dim año As Integer = 0
        Dim numero As Integer = 0
        Dim Linea As Integer = 0

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            logBloquear = False
            'captura el año,numero del panelprincipal dglista
            año = dgLista.SelectedCells(7).Value
            numero = dgLista.SelectedCells(0).Value
            Seleccionar(año, numero)
            MostrarLista(0)
            If (Sesion.idGiro = 2) Then
                CargarBultos()
            End If
            queryDetalle()

            queryDocProcesados()

            'CargarDescargos()
            CalcularTotales()
            'CargarDescargos()
            'celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            botonMas.Enabled = True
            botonEliminar.Enabled = True
            botonQuitDetalle.Enabled = False
            celdaSubTotal.Enabled = False
            celdaTotal.Enabled = False
            celdaFecha.Enabled = False
            If Sesion.idGiro = 2 Then
                rbOpcionPagoNO.Enabled = False
                rbOpcionPagoSI.Enabled = False
            Else
                rbOpcionPagoNO.Enabled = True
                rbOpcionPagoSI.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double

        Try
            dblDocCantidad = 0
            dblDocTotal = 0
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                dblPrecio = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                dblCant = (CDbl(dgDetalle.Rows(i).Cells("colADespachar").Value) + CDbl(dgDetalle.Rows(i).Cells("colLibrasAdicionales").Value))

                dblDocTotal = dblDocTotal + (dblCant * dblPrecio)
                dblDocCantidad = dblDocCantidad + dblCant

            Next
            celdaSubTotal.Text = dblDocCantidad.ToString(FORMATO_MONEDA)
            celdaTotal.Text = dblDocTotal.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles rbOpcionPagoSI.CheckedChanged

        If rbOpcionPagoSI.Checked = True Then
            rbOpcionPagoSI.ForeColor = System.Drawing.Color.Red
            rbOpcionPagoSI.Checked = True
            rbOpcionPagoNO.ForeColor = System.Drawing.Color.Black
            rbOpcionPagoNO.Checked = False
        ElseIf rbOpcionPagoNO.Checked = True Then
            rbOpcionPagoNO.ForeColor = System.Drawing.Color.Blue
            rbOpcionPagoNO.Checked = True
            rbOpcionPagoSI.ForeColor = System.Drawing.Color.Black
            rbOpcionPagoSI.Checked = False
        End If

    End Sub

    Private Sub botonPendientes_Click(sender As Object, e As EventArgs) Handles botonPendientes.Click

        Dim CReportes As New clsReportes

        CReportes.ReportePendingBilling()

    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim intNumero As Integer
        Dim intAnio As Integer
        Dim CReportes As New clsReportes
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQLUpdate As String = STR_VACIO
        Dim COMUpdate As MySqlCommand
        Dim Nota As String = STR_VACIO
        Dim intLinea As Integer = 0
        Dim opt As New frmOption
        Dim strRespuesta As String = STR_VACIO

        If Me.Tag = "Mod" Then
            intNumero = celdaNumero.Text
            intAnio = celdaAño.Text
        Else
            intNumero = dgLista.SelectedCells(0).Value
            intAnio = dgLista.SelectedCells(7).Value
        End If

        If dgDetalle.SelectedRows.Count > 0 Then

            opt.Titulo = "Impresion Format"
            opt.Mensaje = "Select an option"
            opt.Opciones = "Instruction Dispatch" & "|" & "Packing List"

            ' Mostrar el cuadro de diálogo para la selección
            If opt.ShowDialog = DialogResult.OK Then
                ' Procesar la opción seleccionada
                Select Case opt.Seleccion
                    Case 0
                        strSQL = " SELECT g.Linea, CONCAT('LEITZ: ',g.Leitz,' | CORRELATIVO: ',g.Correlativo,' | ',g.Tipo,': ', CAST(IF(g.Tipo='BODEGA',g.Bodega,g.Contenedor) AS CHAR),' | CAJAS: ', CAST(g.Cajas AS CHAR)) Notas "
                        strSQL &= "    FROM ( "
                        strSQL &= "    Select d.DDoc_Doc_Lin Linea, IFNULL(c.ADoc_Dta_Chr,'N/A') Correlativo, IFNULL(l.ADoc_Dta_Chr,'N/A') Leitz, IF(e.DDoc_RF2_Cod IN ('','R','P'),'CONTENEDOR','BODEGA') Tipo, e.DDoc_RF2_Cod Bodega, IFNULL(o.ADoc_Dta_Txt,'') Contenedor, IFNULL(( "
                        strSQL &= "    Select SUM(b.BDoc_Box_QTY) "
                        strSQL &= "    From Dcmtos_DTL_Box b "
                        strSQL &= "    WHERE b.BDoc_Sis_Emp=d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat=d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano=d.DDoc_Doc_Ano AND b.BDoc_Doc_Num=d.DDoc_Doc_Num AND b.BDoc_Doc_Lin=d.DDoc_Doc_Lin),0) Cajas "
                        strSQL &= "        From Dcmtos_DTL d "
                        strSQL &= "        Left JOIN Dcmtos_DTL_Pro r ON r.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND r.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND r.PDoc_Chi_Num=d.DDoc_Doc_Num AND r.PDoc_Chi_Lin=d.DDoc_Doc_Lin AND r.PDoc_Par_Cat=47 "
                        strSQL &= "        Left JOIN Dcmtos_HDR n ON n.HDoc_Sis_Emp=r.PDoc_Sis_Emp AND n.HDoc_Doc_Cat =r.PDoc_Par_Cat AND n.HDoc_Doc_Ano=r.PDoc_Par_Ano AND n.HDoc_Doc_Num=r.PDoc_Par_Num "
                        strSQL &= "        Left JOIN Dcmtos_DTL e ON e.DDoc_Sis_Emp=r.PDoc_Sis_Emp AND e.DDoc_Doc_Cat=r.PDoc_Par_Cat AND e.DDoc_Doc_Ano=r.PDoc_Par_Ano AND e.DDoc_Doc_Num=r.PDoc_Par_Num AND e.DDoc_Doc_Lin=r.PDoc_Par_Lin "
                        strSQL &= "        Left JOIN Dcmtos_ACC c ON c.ADoc_Sis_Emp=n.HDoc_Sis_Emp AND c.ADoc_Doc_Cat=n.HDoc_Doc_Cat AND c.ADoc_Doc_Ano=n.HDoc_Doc_Ano AND c.ADoc_Doc_Num=n.HDoc_Doc_Num AND c.ADoc_Doc_Sub='Doc_DIngreso' AND c.ADoc_Doc_Lin='01' "
                        strSQL &= "        Left JOIN Dcmtos_ACC l ON l.ADoc_Sis_Emp=n.HDoc_Sis_Emp AND l.ADoc_Doc_Cat=n.HDoc_Doc_Cat AND l.ADoc_Doc_Ano=n.HDoc_Doc_Ano AND l.ADoc_Doc_Num=n.HDoc_Doc_Num AND l.ADoc_Doc_Sub='Doc_DIngreso' AND l.ADoc_Doc_Lin='03' "
                        strSQL &= "        Left JOIN Dcmtos_DTL_Pro r1 ON r1.PDoc_Sis_Emp=e.DDoc_Sis_Emp AND r1.PDoc_Chi_Cat=e.DDoc_Doc_Cat AND r1.PDoc_Chi_Ano=e.DDoc_Doc_Ano AND r1.PDoc_Chi_Num=e.DDoc_Doc_Num AND r1.PDoc_Chi_Lin=e.DDoc_Doc_Lin AND r1.PDoc_Par_Cat=180 "
                        strSQL &= "        Left JOIN Dcmtos_DTL_Pro r2 ON r2.PDoc_Sis_Emp=r1.PDoc_Sis_Emp AND r2.PDoc_Chi_Cat=r1.PDoc_Par_Cat AND r2.PDoc_Chi_Ano=r1.PDoc_Par_Ano AND r2.PDoc_Chi_Num=r1.PDoc_Par_Num AND r2.PDoc_Chi_Lin=r1.PDoc_Par_Lin AND r2.PDoc_Par_Cat=55 "
                        strSQL &= "        Left JOIN Dcmtos_ACC o ON o.ADoc_Sis_Emp=r2.PDoc_Sis_Emp AND o.ADoc_Doc_Cat=r2.PDoc_Par_Cat AND o.ADoc_Doc_Ano=r2.PDoc_Par_Ano AND o.ADoc_Doc_Num=r2.PDoc_Par_Num AND o.ADoc_Doc_Sub='Doc_PBLading' AND o.ADoc_Doc_Lin='04' "
                        strSQL &= "        WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=48 AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num= {num} "
                        strSQL &= "        GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin) g "
                        strSQL &= "        ORDER BY g.Correlativo "

                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{anio}", intAnio)
                        strSQL = Replace(strSQL, "{num}", intNumero)

                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader
                        If REA.HasRows Then
                            Do While REA.Read
                                Dim conect As MySqlConnection
                                strSQLUpdate = " UPDATE Dcmtos_DTL SET DDoc_RF3_Txt= '{notas}' WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat=48 AND DDoc_Doc_Ano={anio} AND DDoc_Doc_Num={num} AND DDoc_Doc_Lin= {linea} "
                                If Sesion.IdEmpresa = 18 Then
                                    strSQLUpdate &= "; UPDATE PDM.Dcmtos_DTL SET DDoc_RF3_Txt= '{notas}' WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat=48 AND DDoc_Doc_Ano={anio} AND DDoc_Doc_Num={num} AND DDoc_Doc_Lin= {linea} "
                                End If
                                strSQLUpdate = Replace(strSQLUpdate, "{empresa}", Sesion.IdEmpresa)
                                strSQLUpdate = Replace(strSQLUpdate, "{anio}", intAnio)
                                strSQLUpdate = Replace(strSQLUpdate, "{num}", intNumero)
                                strSQLUpdate = Replace(strSQLUpdate, "{notas}", REA.GetString("Notas"))
                                strSQLUpdate = Replace(strSQLUpdate, "{linea}", REA.GetInt32("Linea"))

                                conect = New MySqlConnection(strConexion)
                                conect.Open()
                                COMUpdate = New MySqlCommand(strSQLUpdate, conect)
                                Using conect
                                    COMUpdate.ExecuteNonQuery()
                                    COMUpdate.Dispose()
                                    COMUpdate = Nothing
                                    conect.Close()
                                    conect.Dispose()
                                    conect = Nothing
                                    System.GC.Collect()
                                End Using
                            Loop
                        End If


                        If Me.Tag = "Mod" Then

                            CReportes.InstruccionDDespacho(celdaNumero.Text, celdaAño.Text)
                        Else
                            CReportes.InstruccionDDespacho(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(7).Value)
                        End If
                    Case 1
                        CReportes.ReporteDeCajas(intAnio, intNumero)
                End Select
            Else
                ' Si se cancela el diálogo, salir del Sub
                Exit Sub
            End If
        Else
            MessageBox.Show("No hay ninguna fila seleccionada.")
        End If




    End Sub


    Private Sub EliminarLineasDetalle()
        Dim i As Integer = 0
        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then

                    Dim Dtl As New clsDcmtos_DTL
                    Dim COM As MySqlCommand
                    Dim conec As MySqlConnection
                    Dim strSQL As String = STR_VACIO
                    Dim Orden As Double
                    Dim j As Integer = 0

                    Dtl.CONEXION = strConexion

                    If dgDetalle.Rows(i).Visible = False Then
                        Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                        Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                        Dtl.DDOC_DOC_ANO = celdaAño.Text
                        Dtl.DDOC_DOC_NUM = celdaNumero.Text
                        If Me.Tag = "Nuevo" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                            If dgDetalle.Rows(i).Visible = True Then
                                j = j + 1
                            End If
                            Dtl.DDOC_DOC_LIN = j
                        ElseIf Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                            If dgDetalle.Rows(i).Visible = True Then
                                j = dgDetalle.Rows.Count - 1
                                j = j + 1
                            End If
                            Dtl.DDOC_DOC_LIN = j
                        Else
                            Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                        End If

                        'Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value

                        Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                        Dtl.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colNumParte").Value
                        Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colArticulo").Value
                        Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colBase").Value
                        Dtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colUnit").Value

                        Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                        Dtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colExistencia").Value
                        If Me.Tag = "Nuevo" Then
                            strSQL = "SELECT d.DDoc_Prd_QTY - ifnull((SELECT SUM(p.PDoc_QTY_Pro)"
                            strSQL &= "      FROM Dcmtos_DTL_Pro p"
                            strSQL &= "          WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDOc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin = d.DDoc_Doc_Lin ),0)"
                            strSQL &= "      FROM Dcmtos_DTL d"
                            strSQL &= "    WHERE d.DDoc_Sis_Emp  = {empresa} AND d.DDoc_Doc_Cat  = 75 AND d.DDoc_Doc_Ano  = {anio} AND d.DDoc_Doc_Num  IN({numero}) AND d.DDoc_Doc_Lin = {linea}"

                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{anio}", dgDetalle.Rows(i).Cells("colAno").Value)
                            strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colNPedido").Value)
                            strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)

                            conec = New MySqlConnection(strConexion)
                            conec.Open()
                            COM = New MySqlCommand(strSQL, conec)
                            Using conec
                                Orden = COM.ExecuteScalar
                                COM.Dispose()
                                COM = Nothing
                                conec.Close()
                                conec.Dispose()
                                conec = Nothing
                                System.GC.Collect()
                            End Using
                            Dtl.DDOC_PRD_DSQ = Orden
                            If CDbl(Orden - dgDetalle.Rows(i).Cells("colADespachar").Value) < 0 Then
                                Dtl.DDOC_RF1_DBL = 0
                            Else
                                Dtl.DDOC_RF1_DBL = CDbl(Orden - dgDetalle.Rows(i).Cells("colADespachar").Value)
                            End If

                        Else
                            Dtl.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("colOrden").Value
                            Dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colPendiente").Value
                        End If

                        Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                        Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colADespachar").Value

                        Dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCodDestino").Value
                        Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colCodOriginal").Value

                        Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReference").Value
                        Dtl.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colFech").Value
                        If dgDetalle.Rows(i).Cells("colObservation").Value = vbNullString Then
                        Else
                            Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colObservation").Value
                        End If

                        Dtl.DDOC_RF2_TXT = "e/" & dgDetalle.Rows(i).Cells("colExistencia").Value & "/p/" & dgDetalle.Rows(i).Cells("colNPedido").Value & "/d/" & dgDetalle.Rows(i).Cells("colADespachar").Value

                        Dtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colCodDestino").Value
                        Dtl.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colADespachar").Value
                        Dtl.DDOC_PRD_FOB = (dgDetalle.Rows(i).Cells("colADespachar").Value * dgDetalle.Rows(i).Cells("colPrecio").Value)

                        If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                            If Dtl.Borrar = False Then
                                MsgBox(Dtl.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                            End If
                        End If

                        'dgDetalle.Rows.Remove(dgDetalle.Rows(i))
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarLineasBultos()
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        Dim j As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                    DtlBox.BDOC_DOC_CAT = celdaCatalogo.Text
                    DtlBox.BDOC_DOC_ANO = celdaAño.Text
                    DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                    If Me.Tag = "Nuevo" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = j + 1
                        End If
                        DtlBox.BDOC_DOC_LIN = j
                    ElseIf Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = j + 1
                            If j = dgDetalle.Rows.Count - 1 Then
                                j = dgDetalle.Rows.Count - 1
                                j = j + 1
                            Else
                                j = j + 1
                            End If
                        End If
                        DtlBox.BDOC_DOC_LIN = j
                    Else
                        DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                    End If
                    DtlBox.BDOC_BOX_LIN = 1
                    DtlBox.BDOC_BOX_ORD = I_CODIGO
                    DtlBox.BDOC_BOX_COD = I_CODIGO
                    DtlBox.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBulto").Value
                    DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colADespachar").Value


                    If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                        If DtlBox.PDELETE = False Then
                            MsgBox(DtlBox.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarLineasDescargo()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim dblCantidad As Double
        Dim j As Integer = 0

        clsDTLPro.CONEXION = strConexion
        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    clsDTLPro.PDOC_SIS_EMP = celdaEmpresa.Text
                    clsDTLPro.PDOC_PAR_CAT = 75
                    clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAno").Value
                    clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNPedido").Value
                    clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                    clsDTLPro.PDOC_CHI_CAT = 48
                    clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                    clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text

                    If Me.Tag = "Nuevo" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = j + 1
                        End If
                        clsDTLPro.PDOC_CHI_LIN = j
                    ElseIf Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = dgDetalle.Rows.Count - 1
                            j = j + 1
                        End If
                        clsDTLPro.PDOC_CHI_LIN = j
                    Else
                        clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                    End If
                    'clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                    clsDTLPro.PDOC_PROV_COD = celdaIDCliente.Text                                'Cód. del proveedor
                    clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodOriginal").Value           'Cód. del pedido
                    clsDTLPro.PDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colNumParte").Value         'DDoc_Prd_PNr/N° de parte
                    clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value            'DDoc_Prd_NET/Precio neto

                    dblCantidad = vbEmpty
                    If checkActivar.Checked = True Then
                        'dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                        If Sesion.idGiro = 2 Then
                            dblCantidad = dgDetalle.Rows(i).Cells("colADespachar").Value
                        Else
                            dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                        End If
                    End If

                    clsDTLPro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantDescargo").Value     'A Despachar
                    clsDTLPro.PDOC_QTY_PRO = dblCantidad                                        'A despachar (vacío para documentos anulados/inactivos)

                    If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                        If clsDTLPro.Borrar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarLineaAgregarDescargo()
        Dim clsDTLPro2 As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim intID As Integer
        Dim j As Integer = 0
        Dim dblCantidad As Double

        clsDTLPro2.CONEXION = strConexion
        Try

            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    clsDTLPro2.PDOC_SIS_EMP = celdaEmpresa.Text
                    clsDTLPro2.PDOC_PAR_CAT = 47
                    clsDTLPro2.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioDesc").Value
                    clsDTLPro2.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumDesc").Value
                    clsDTLPro2.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea2Desc").Value

                    clsDTLPro2.PDOC_CHI_CAT = 48
                    clsDTLPro2.PDOC_CHI_ANO = celdaAño.Text
                    clsDTLPro2.PDOC_CHI_NUM = celdaNumero.Text
                    If Me.Tag = "Nuevo" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = j + 1
                        End If
                        clsDTLPro2.PDOC_CHI_LIN = j
                    ElseIf Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = dgDetalle.Rows.Count - 1
                            j = j + 1
                        End If
                        clsDTLPro2.PDOC_CHI_LIN = j
                    Else
                        clsDTLPro2.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                    End If
                    clsDTLPro2.PDOC_PROV_COD = celdaIDCliente.Text                                'Cód. del proveedor
                    clsDTLPro2.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodDesc").Value          'Cód. del pedido
                    clsDTLPro2.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value            'DDoc_Prd_NET/Precio neto

                    dblCantidad = vbEmpty
                    If checkActivar.Checked = True Then
                        'dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                        If Sesion.idGiro = 2 Then
                            dblCantidad = dgDetalle.Rows(i).Cells("colADespachar").Value
                        Else
                            dblCantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                        End If
                    End If
                    clsDTLPro2.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantDescargo").Value
                    clsDTLPro2.PDOC_QTY_PRO = dblCantidad

                    If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                        If clsDTLPro2.Borrar = False Then
                            MsgBox(clsDTLPro2.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarLineaExistencia()
        Dim Ex As New Tablas.TEXISTENCIA
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim i As Integer
        Dim dblBultos As Double
        Dim dblSalida As Double
        Dim strSQL As String
        Dim j As Integer
        Dim cantLineas As Integer
        cantLineas = dgDetalle.Rows.Count

        For i = 0 To cantLineas
            If i < cantLineas Then
                If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then

                    strSQL = "SELECT (SELECT (IFNULL(MAX(Ex_Id),0) + 1) ID FROM Existencia) ID, inv_artcodigo Articulo, inv_lugarfab Pais, inv_prodlote Lote, inv_prodano Ciclo, inv_prodsem Semana, inv_costo Costo "
                    strSQL &= "   FROM Inventarios "
                    strSQL &= "     WHERE inv_sisemp ={empresa}  AND inv_numero ={codigo} "

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{codigo}", dgDetalle.Rows(i).Cells("colCodigo").Value)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    REA.Read()

                    dblSalida = dgDetalle.Rows(i).Cells("colADespachar").Value
                    dblBultos = dgDetalle.Rows(i).Cells("colBulto").Value

                    Ex.CONEXION = strConexion

                    Ex.EX_DOC_EMP = celdaEmpresa.Text
                    Ex.EX_DOC_TIPO = celdaCatalogo.Text
                    Ex.EX_DOC_CICLO = celdaAño.Text
                    Ex.EX_DOC_NUM = celdaNumero.Text
                    Ex.Ex_Doc_Fec_NET = celdaFecha.Text
                    If Me.Tag = "Nuevo" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = j + 1
                        End If
                        Ex.EX_DOC_LIN = j
                    ElseIf Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                        If dgDetalle.Rows(i).Visible = True Then
                            j = dgDetalle.Rows.Count - 1
                            j = j + 1
                        End If
                        Ex.EX_DOC_LIN = j
                    Else
                        Ex.EX_DOC_LIN = dgDetalle.Rows(i).Cells("colIDD").Value
                    End If
                    'Ex.EX_DOC_LIN = i + 1
                    Ex.Ex_Fec_NET = Now
                    Ex.EX_ID = REA.GetInt32("ID")
                    Ex.EX_ARTICULO = REA.GetString("Articulo")
                    Ex.EX_CODIGO = dgDetalle.Rows(i).Cells("colCodigo").Value
                    Ex.EX_DESCRIPCION = dgDetalle.Rows(i).Cells("colArticulo").Value
                    Ex.EX_PAIS = REA.GetString("Pais")
                    Ex.EX_REFERENCIA = dgDetalle.Rows(i).Cells("colReference").Value
                    Ex.EX_LOTE = REA.GetString("Lote")
                    Ex.EX_CICLO = REA.GetInt32("Ciclo")
                    Ex.EX_SEMANA = REA.GetInt32("semana")
                    Ex.EX_UM = dgDetalle.Rows(i).Cells("colBase").Value
                    Ex.EX_INGRESO = vbEmpty
                    Ex.EX_EGRESO = dblSalida
                    Ex.EX_BULTOS = dblBultos
                    Ex.EX_MONEDA = celdaIDMoneda.Text
                    Ex.EX_TC = celdaTasa.Text
                    Ex.EX_COSTO = REA.GetDouble("Costo").ToString(FORMATO_MONEDA)
                    Ex.EX_TOTAL = (REA.GetDouble("Costo") * dblSalida)

                    If dgDetalle.Rows(i).Visible = False And dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                        If Ex.PDELETE = False Then
                            MsgBox(Ex.MERROR.ToString & "Could not Save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                    dgDetalle.Rows.Remove(dgDetalle.Rows(i))
                End If
            End If
            cantLineas = dgDetalle.Rows.Count

        Next
    End Sub

    Private Sub EliminarLineas()
        EliminarLineasBultos()
        EliminarLineasDetalle()
        EliminarLineasDescargo()
        EliminarLineaAgregarDescargo()
        EliminarLineaExistencia()
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Try

            Dim FRef As New frmFacturasRef_Aux_
            Dim logGenerico As Boolean
            Dim strCodigo As String

            If dgDetalle.Rows.Count = vbEmpty Then Exit Sub

            strCodigo = dgDetalle.SelectedCells(18).Value
            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 5
                    If Not logComentario Then
                        CargarNota()
                    End If
                    logGenerico = sqlEsGenerico(strCodigo)


                    'For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
                    '    If dgDetalle.Rows(i).Selected Then
                    '        If dgDetalle.Rows(i).Visible = True Then
                    '            contador = contador + 1
                    '            dgDetalle.Rows(i).Cells("colIDD").Value = contador
                    '        End If     
                    '    End If
                    'Next

                    MostrarReferencias(strCodigo, logGenerico)


                Case 13 'bultos
                    If (Sesion.idGiro = 2) Then
                        Dim i As Integer = 0
                        Dim k As Integer = 0
                        Dim frmB As New frmBultos
                        Dim SumaMod As Double = 0
                        validacionDatosInicio = False


                        'toma datos del dgdetalle para utilizarlos en el query de frmbultos (cuando se van a seleccionar los bultos)
                        frmB.CatalogoP = dgDetalle.CurrentRow.Cells("colCatDesc").Value
                        frmB.AnioP = dgDetalle.CurrentRow.Cells("colAnioDesc").Value
                        frmB.NumeroP = dgDetalle.CurrentRow.Cells("colNumDesc").Value
                        frmB.LineaP = dgDetalle.CurrentRow.Cells("colLinea2Desc").Value
                        frmB.CatalogoChi = dgDetalle.CurrentRow.Cells("colCatalogo").Value
                        frmB.AnioChi = dgDetalle.CurrentRow.Cells("colAno").Value
                        frmB.Libras = dgDetalle.CurrentRow.Cells("colADespachar").Value
                        frmB.NumeroChi = dgDetalle.CurrentRow.Cells("colNPedido").Value
                        frmB.LineaChi = dgDetalle.CurrentRow.Cells("colIDD").Value
                        frmB.DataGridIn = dgbultos1
                        'frmB.NumInstru = celdaNumero.Text

                        'Validacion para solo visualizar informacion ya una vez guardada la instruccion.
                        'If Me.Tag = "Mod" Then
                        '    frmB.VisualizarInfoUp = True
                        'Else
                        '    frmB.VisualizarInfoUp = False
                        'End If
                        'dgDetalle.Columns("colCatDesc").Visible = True
                        'dgDetalle.Columns("colAnioDesc").Visible = True
                        'dgDetalle.Columns("colNumDesc").Visible = True
                        'dgDetalle.Columns("colLinea").Visible = True

                        If dgBultosInicio.Rows.Count > 0 Then
                            For j = 0 To dgBultosInicio.Rows.Count - 1
                                If dgBultosInicio.Rows(j).Cells("dgCatalogo").Value = dgDetalle.CurrentRow.Cells("colCatDesc").Value And dgBultosInicio.Rows(j).Cells("dgAnio").Value = dgDetalle.CurrentRow.Cells("colAnioDesc").Value And dgBultosInicio.Rows(j).Cells("dgNumber").Value = dgDetalle.CurrentRow.Cells("colNumDesc").Value And dgBultosInicio.Rows(j).Cells("dgLinea").Value = dgDetalle.CurrentRow.Cells("colLinea").Value Then

                                    '    If dgBultosInicio.Rows(j).Cells("dgCatalogo").Value = dgDetalle.CurrentRow.Cells("colCatDesc").Value And dgBultosInicio.Rows(j).Cells("dgAnio").Value = dgDetalle.CurrentRow.Cells("colAnioDesc").Value And dgBultosInicio.Rows(j).Cells("dgNumber").Value = dgDetalle.CurrentRow.Cells("colNumDesc").Value And dgBultosInicio.Rows(j).Cells("dgLineaDet").Value = dgDetalle.CurrentRow.Cells("colLinea").Value Then
                                    validacionDatosInicio = True
                                End If
                            Next
                        End If

                        frmB.VisualizarInfoUp = validacionDatosInicio


                        If dgbultos1.Rows.Count > 0 Then
                            Dim FBultos As String = STR_VACIO
                            i = 0
                            For i = 0 To dgbultos1.Rows.Count - 1 ' carga los datos del dgbultos que está oculto en frmBultos
                                If dgbultos1.Rows(i).Cells("colLineaDet").Value = dgDetalle.CurrentRow.Cells("colIDD").Value Then

                                    If dgbultos1.Rows(i).Visible = True Then

                                        ' Crear una nueva fila
                                        Dim Fila As New DataGridViewRow()
                                        ' Crear la celda CheckBox y asignarle un valor basado en el colExtra1
                                        Dim Check As New DataGridViewCheckBoxCell()

                                        'Se mandan Activos por que son los selecionados, ya limpiados.
                                        Check.Value = True ' Asigna False o True según tu lógica

                                        Fila.Cells.Add(Check)

                                        ' Agregar celdas en el orden correcto
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colCatalogo1").Value})    ' catalogo
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colAnio1").Value})       ' Año
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colNumero1").Value})     ' numero
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colLinea1").Value})      ' Línea Ingreso Caja
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colBultoNo").Value})     ' Número Caja
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("NumBulto1").Value})     ' Número Caja
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("productoCod").Value})       ' Marca
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colMarca").Value})       ' Marca
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colCategoria").Value})  ' Categoria
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgbultos1.Rows(i).Cells("colPeso").Value})        ' Peso Caja
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = dgDetalle.CurrentRow.Cells("colIDD").Value})      ' Línea adicional
                                        Fila.Cells.Add(New DataGridViewTextBoxCell() With {.Value = 0})



                                        SumaMod = SumaMod + CDbl(dgbultos1.Rows(i).Cells("colPeso").Value)

                                        frmB.dgbultos.Rows.Add(Fila)


                                        'cFunciones.AgregarFila(frmB.dgbultos, FBultos)


                                    End If
                                End If
                            Next

                            frmB.celdaLibras.Text = SumaMod
                        End If

                        frmB.ShowDialog(Me)


                        If frmB.DialogResult = DialogResult.OK Then
                            Dim contarBultos As Integer = 0
                            'dgbultos1.Rows.Clear()

                            intActual = 0
                            Dim filaBultos As String = STR_VACIO
                            Dim Total As Double = frmB.txtSumaSelect.Text

                            dgDetalle.CurrentRow.Cells("colADespachar").Value = frmB.txtSumaSelect.Text

                            'COLUMNA UTILIZADA PARA GUARDAR colCantDescargo Y mostrar en seleccion de ingreso
                            'Columna utilizada en mostrar en el detalle colADespachar
                            dgDetalle.CurrentRow.Cells("colCantDescargo").Value = dgDetalle.CurrentRow.Cells("colADespachar").Value

                            dgDetalle.CurrentRow.Cells("colCantidad").Value = dgDetalle.CurrentRow.Cells("colADespachar").Value
                            dgDetalle.CurrentRow.Cells("colPendiente").Value = (dgDetalle.CurrentRow.Cells("colOrden").Value) - (dgDetalle.CurrentRow.Cells("colADespachar").Value)
                            'dgDetalle.CurrentRow.Cells("colCantDescargo").Value = dgDetalle.CurrentRow.Cells("colCantidad").Value

                            'borra los bultos de la linea seleccionada
                            For j As Integer = 0 To dgbultos1.Rows.Count - 1
                                If dgbultos1.Rows(j).Cells("colLineaDet").Value = dgDetalle.CurrentRow.Cells("colIDD").Value Then
                                    dgbultos1.Rows(j).Visible = False
                                    dgbultos1.Rows(j).Cells("colExtra1").Value = 2
                                End If
                            Next

                            For i = 0 To frmB.dgbultos.Rows.Count - 1

                                If (frmB.dgbultos.Rows(i).Cells("colExtra").Value = 0) Then

                                    filaBultos = frmB.dgbultos.Rows(i).Cells("colCatalogo").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colAnio").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colNumero").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colLinea").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colBultoNo").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("BoxNumberVista").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("productoCod").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colMarca").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colCategoria").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colPeso").Value & "|"
                                    filaBultos &= dgDetalle.CurrentRow.Cells("colIDD").Value & "|"
                                    filaBultos &= frmB.dgbultos.Rows(i).Cells("colExtra").Value
                                    If frmB.dgbultos.Rows(i).Cells("colExtra").Value = 0 Then
                                        contarBultos = contarBultos + 1
                                    End If


                                    cFunciones.AgregarFila(dgbultos1, filaBultos)
                                End If

                            Next

                            For k = 0 To dgbultos1.Rows.Count - 1

                                If dgbultos1.Rows(k).Cells("colExtra1").Value = 2 Then
                                    dgbultos1.Rows(k).Visible = False
                                Else
                                    ' contarBultos = contarBultos + 1
                                End If

                            Next

                            dgDetalle.CurrentRow.Cells("colBulto").Value = contarBultos
                            'celdaSubTotal.Text = (dgDetalle.CurrentRow.Cells("colADespachar").Value + dgDetalle.CurrentRow.Cells("colLibrasAdicionales").Value)
                            'celdaTotal.Text = (dgDetalle.CurrentRow.Cells("colADespachar").Value + dgDetalle.CurrentRow.Cells("colLibrasAdicionales").Value) * (dgDetalle.CurrentRow.Cells("colPrecio").Value)

                            ''Declarar variables de tipo Double
                            'Dim colADespachar As Double
                            'Dim colLibrasAdicionales As Double
                            'Dim colPrecio As Double

                            '' Verificar si la conversión de las celdas es exitosa
                            'Double.TryParse(dgDetalle.CurrentRow.Cells("colADespachar").Value.ToString(), colADespachar)
                            'Double.TryParse(dgDetalle.CurrentRow.Cells("colLibrasAdicionales").Value.ToString(), colLibrasAdicionales)
                            'Double.TryParse(dgDetalle.CurrentRow.Cells("colPrecio").Value.ToString(), colPrecio)

                            '' Realizar las operaciones matemáticas
                            'Dim subTotal As Double = colADespachar + colLibrasAdicionales
                            'Dim totalsss As Double = subTotal * colPrecio

                            '' Asignar los resultados a los controles de texto
                            'celdaSubTotal.Text = subTotal.ToString()
                            'celdaTotal.Text = totalsss.ToString()

                            CalcularTotales()

                        End If

                    End If

                Case 16 ' destino
                    Dim frm As New frmSeleccionar
                    Dim strCondicion As String = STR_VACIO
                    strCondicion = "cli_sisemp = {empresa}"
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    Try
                        frm.Titulo = "Sales Catalog"
                        frm.Campos = " cli_codigo, cli_cliente, cli_status"
                        frm.Tabla = " Clientes"
                        frm.FiltroText = " Enter the Client Name to filter"
                        frm.Filtro = " cli_cliente "
                        frm.Condicion = strCondicion

                        frm.ShowDialog(Me)
                        If frm.DialogResult = DialogResult.OK Then

                            dgDetalle.SelectedCells(17).Value = frm.LLave
                            dgDetalle.SelectedCells(16).Value = frm.Dato

                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMas_Click(sender As Object, e As EventArgs) Handles botonMas.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        strTabla = "Dcmtos_HDR e  LEFT JOIN Dcmtos_DTL d ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strCondicion = "e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 75 AND e.HDoc_Emp_Cod = {numero} AND e.HDoc_Doc_Status = 1 AND d.DDoc_RF2_Num = 0 AND (COALESCE((SELECT SUM(c.DDoc_Prd_QTY)FROM Dcmtos_DTL c WHERE c.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND c.DDoc_Doc_Cat = d.DDoc_Doc_Cat AND c.DDoc_Doc_Ano = d.DDoc_Doc_Ano AND c.DDoc_Doc_Num = d.DDoc_Doc_Num AND c.DDoc_Prd_Cod = d.DDoc_Prd_Cod),0) > COALESCE((SELECT SUM(p.PDoc_QTY_Pro) FROM Dcmtos_DTL_Pro p WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0))"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        strCondicion = Replace(strCondicion, "{numero}", celdaIDCliente.Text)
        Try
            frm.Titulo = "Client"
            frm.Campos = " DISTINCT e.HDoc_Doc_Num pf, e.HDoc_Doc_Fec fecha, e.HDoc_Usuario usuario, COALESCE(e.HDoc_DR1_Num,'') numero, e.HDoc_Doc_Ano anio, IFNULL(e.HDoc_DR2_Emp,0) Impuesto, e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat catalogo"
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            frm.FiltroText = " Enter the PF Number to filter"
            frm.Filtro = "  e.HDoc_Doc_Num"
            frm.Limite = 30
            frm.Ordenamiento = " e.HDoc_Doc_Num, e.HDoc_Doc_Ano "
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                Dim strFila As String = STR_VACIO
                strFila = (frm.LLave) & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & frm.Dato4 & "|" & "X" & "|" & 2
                cfun.AgregarFila(dgPedidos, strFila)
            Else
                Exit Sub

            End If
            For i As Integer = 0 To dgPedidos.Rows.Count - 1
                If dgPedidos.Rows(i).Cells("colImpuesto").Value = "X" And dgPedidos.Rows(i).Visible = True Then
                    dgPedidos.Item(0, i).Style.BackColor = Color.Yellow

                End If
            Next

            SqlDetallePorProcesar2(False)
            For i As Integer = 0 To dgPedidos.Rows.Count - 1
                If dgPedidos.Rows(i).Cells("colImpuesto").Value = "X" Then
                    For j As Integer = 0 To dgDetalle.Rows.Count - 1
                        If dgPedidos.Rows(i).Cells("colPF").Value = dgDetalle.Rows(j).Cells("colNPedido").Value Then
                            dgDetalle.Item(1, j).Style.BackColor = Color.Yellow

                        End If
                    Next
                End If
                'dgPedidos.Rows(i).Cells("colImpuesto").Value = 0
            Next

            For i As Integer = 0 To dgPedidos.Rows.Count - 1
                If dgPedidos.Rows(i).Cells("colImpuesto").Value = "X" Or dgPedidos.Rows(i).Cells("colImpuesto").Value = "1" Then
                    dgPedidos.Rows(i).Cells("colImpuesto").Value = "0"
                    'dgPedidos.Rows(i).Cells("colExtra").Value = 1
                End If
                'If dgPedidos.Rows(i).Cells("colExtra").Value = 2 Then
                '    dgPedidos.Rows(i).Cells("colExtra").Value = 1
                'End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitDetalle_Click(sender As Object, e As EventArgs) Handles botonQuitDetalle.Click



        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer
            Dim intContador As Integer = INT_CERO

            If dgDetalle.SelectedRows Is Nothing Then Exit Sub

            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & Val(dgDetalle.SelectedCells(3).Value) & " Of the order " & Val(dgDetalle.SelectedCells(1).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then

                        If dgDetalle.SelectedCells(27).Value = 0 Or dgDetalle.SelectedCells(27).Value = 1 Then
                            dgDetalle.SelectedCells(27).Value = 2
                            If dgDetalle.SelectedCells(27).Value = 2 Then

                                dgDetalle.Rows.Remove(dgDetalle.SelectedRows(0))
                                dgDetalle.Refresh()
                            End If

                        End If

                    End If
                Next
                If Me.Tag = "Nuevo" Then
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        If dgDetalle.Rows(i).Visible = True Then
                            intContador = intContador + 1
                            dgDetalle.Rows(i).Cells("colIDD").Value = intContador
                        End If
                    Next

                End If

            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBanderaAzul_Click(sender As Object, e As EventArgs) Handles botonBanderaAzul.Click
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer
        Dim strSQL As String

        If Not (dgLista.Rows.Count = 0) Then
            tipo = 48
            año = dgLista.SelectedCells(7).Value
            numero = dgLista.SelectedCells(0).Value

            strSQL = "SELECT IFNULL(h.HDoc_RF2_Cod,0) cargado,h.HDoc_Doc_Status estado"
            strSQL &= "  From Dcmtos_HDR h"
            strSQL &= "      WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat={tipo} AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero} LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{tipo}", tipo)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Cargado") = vbEmpty Then
                        If MsgBox("Indicara que la instruccion: " & numero & " fue cargada. " & vbNewLine & vbNewLine & "NOTA: Estos cambios no seran reversibles. Desea Continuar?", vbQuestion + vbYesNo + vbDefaultButton2, "Confirmacion de Carga") = vbYes Then
                            strSQL = ""
                            strSQL &= "    UPDATE Dcmtos_HDR h set h.HDoc_RF2_Cod = 1 "
                            strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=48 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR h set h.HDoc_RF2_Cod = 1 "
                                strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=48 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)

                            dgLista.SelectedCells(3).Style.BackColor = Color.White
                        End If
                    Else
                        MsgBox("The document was already loaded")
                    End If
                End If
                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL, CON)
                COM2.ExecuteNonQuery()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmntos_HDR", clsFunciones.AccEnum.acCargar, -1, 48, numero, año)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub dgDetalle_LostFocus(sender As Object, e As EventArgs)
        CalcularTotales()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(48, dgLista.SelectedCells(7).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(7).Value, 48)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgPedidos_DoubleClick(sender As Object, e As EventArgs) Handles dgPedidos.DoubleClick

        Dim i As Integer
        Dim strTemp As String
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim array() As String
        Dim Temp As Double
        Dim Temp1 As Double
        Dim Temp2 As Double
        Dim strTemp2 As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Dim Despachado As Double
        Dim Ordenadao As Double
        Dim Contador As Integer = 0

        If dgPedidos.Rows.Count < 1 Then
            Exit Sub
        Else
            For i = 0 To dgPedidos.Rows.Count - 1
                If dgPedidos.Rows.Count > vbEmpty Then
                    If Not (dgPedidos.Rows(i).Cells(0).Value) = vbNullString Then
                        strSQL = SqlDetallePorProcesar()
                    End If
                End If

            Next

            Try
                Dim strFila As String = STR_VACIO
                dgPedidos.CurrentRow.Cells(6).Value = 2
                For j As Integer = 0 To dgPedidos.Rows.Count - 1
                    If dgPedidos.Rows.Count = 1 Then
                        'dgPedidos.Rows.RemoveAt(j)
                    ElseIf dgPedidos.Rows(j).Cells("colExtra").Value = 2 Then
                        dgPedidos.CurrentRow.Cells(6).Value = 1
                        strFila = dgPedidos.Rows(j).Cells("colPF").Value & "|" & dgPedidos.Rows(j).Cells("colFecha").Value & "|" & dgPedidos.Rows(j).Cells("colOperador").Value & "|" & dgPedidos.Rows(j).Cells("colPOCliente").Value & "|" & dgPedidos.Rows(j).Cells("colYear").Value & "|" & dgPedidos.Rows(j).Cells("colImpuesto").Value & "|" & dgPedidos.Rows(j).Cells("colExtra").Value
                    End If
                Next


                dgPedidos.Rows.Clear()
                cFunciones.AgregarFila(dgPedidos, strFila)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            MyCnn.CONECTAR = strConexion
            Try
                'SqlDetallePorProcesar2()
                strSQL = SqlDetallePorProcesar()
                dgDetalle.Rows.Clear()
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("Precio").ToString & "|"
                    strFila &= REA.GetDouble("Existencia").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Conversion").ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_CERO.ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_UNO & "|"
                    strFila &= REA.GetString("Pendiente").ToString & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Lugar") & "|"
                    strFila &= REA.GetInt32("Destino") & "|"
                    strFila &= REA.GetInt32("Original") & "|"
                    strFila &= "e/ " & REA.GetDouble("Existencia").ToString(FORMATO_MONEDA) & "/ p /" & REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "/ d /" & REA.GetDouble("Conversion").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Parte") & "|"
                    strFila &= vbEmpty & "|"
                    strFila &= REA.GetInt32("Unidad") & "|"
                    strFila &= REA.GetInt32("Base") & "|"
                    strFila &= REA.GetInt32("Cantidad") & "|"
                    strFila &= REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Despachado") & "|"
                    strFila &= 1 & "|"
                    strFila &= REA.GetString("Observaciones")

                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop

                For i = 0 To dgDetalle.Rows.Count - 1
                    'Identificador de la fila: año, numero, codigo, u/m
                    strTemp2 = dgDetalle.Rows(i).Cells("colAno").Value & "," & dgDetalle.Rows(i).Cells("colNPedido").Value & "," & dgDetalle.Rows(i).Cells("colCodigo").Value

                    'Si no es el mismo hilo limpia los totales
                    If Not (strLinea = strTemp2) Then
                        If (Temp2 > vbEmpty) Then
                            strLinea = strLinea & "," & (Temp2)
                        End If
                        Temp2 = vbEmpty
                        strLinea = strTemp2
                    End If
                    Temp = dgDetalle.Rows(i).Cells("colOrden").Value
                    Temp1 = Temp2 + dgDetalle.Rows(i).Cells("colOriginal").Value
                    Temp2 = (Temp - Temp1)

                    If CDbl(Temp2 <= 0) Then
                        Temp2 = (Temp2 * (-1))
                        dgDetalle.Rows(i).Visible = False
                        dgDetalle.Rows(i).Cells("colXtra").Value = 2
                    Else
                        dgDetalle.Rows(i).Cells("colOrden").Value = Temp2.ToString(FORMATO_MONEDA)
                        dgDetalle.Rows(i).Cells("colPendiente").Value = Temp2.ToString(FORMATO_MONEDA)
                        dgDetalle.Rows(i).Cells("colPedido").Value = Temp2.ToString(FORMATO_MONEDA)
                        Temp2 = vbEmpty
                    End If
                Next

                CalcularTotales()

                For j As Integer = 0 To dgDetalle.Rows.Count - 1
                    'If dgDetalle.Rows(i).Selected Then
                    If dgDetalle.Rows(j).Visible = True Then
                        Contador = Contador + 1
                        dgDetalle.Rows(j).Cells("colIDD").Value = Contador
                    End If
                    'End If
                Next

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub dgPedidos_KeyDown(sender As Object, e As KeyEventArgs) Handles dgPedidos.KeyDown
        If e.KeyCode = Keys.F9 Then
            If dgPedidos.SelectedRows.Count = 0 Then Exit Sub
            Try
                If dgPedidos.CurrentRow.Cells(6).Value = 2 Then
                    dgPedidos.CurrentRow.Cells(6).Value = 1

                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        If dgPedidos.CurrentRow.Cells(6).Value = 1 Then
                            If dgPedidos.CurrentRow.Cells("colPF").Value = dgDetalle.Rows(i).Cells("colNPedido").Value Then
                                dgDetalle.Rows(i).Cells("colXtra").Value = 2
                            End If
                        End If
                    Next

                    For k As Integer = 0 To dgDetalle.Rows.Count - 1
                        If dgPedidos.CurrentRow.Cells("colPF").Value = dgDetalle.Rows(k).Cells("colNPedido").Value Then
                            If dgDetalle.Rows(k).Cells("colXtra").Value = 2 Then
                                dgDetalle.Rows(k).Visible = False
                            End If
                        End If
                    Next

                    For j As Integer = 0 To dgPedidos.Rows.Count - 1
                        If dgPedidos.Rows(j).Cells("colExtra").Value = 1 Then
                            dgPedidos.Rows(j).Visible = False
                        End If
                    Next

                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Try
            cfun.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub NuevoDetalle(ByVal IDCliente As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim Array() As String
        Dim strTEMP As String = STR_VACIO
        Dim strTEMP2 As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Dim Temp As Double
        Dim Temp1 As Double
        Dim Temp2 As Double
        Dim contador As Integer = 0

        For i = 0 To dgPedidos.Rows.Count - 1
            If i > 0 Then
                strTEMP = strTEMP & " OR "
            End If
            If dgPedidos.Rows.Count - 1 >= 0 Then
                strTEMP = strTEMP & " ( d.DDoc_Doc_Ano = " & dgPedidos.Rows(i).Cells("colYear").Value & " AND DDoc_Doc_Num = " & dgPedidos.Rows(i).Cells("colPF").Value & ")"
            Else
            End If

        Next

        strSQL = vbNullString
        strSQL &= " SELECT d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Fec Fecha, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Cod Original, d "
        strSQL &= "     .DDoc_Prd_NET Precio, m.cat_clave Medida, d.DDoc_Prd_UM Unidad, 0 Cantidad, d.DDoc_Prd_UM Base, 0 Conversion, d.DDoc_Prd_PNr Parte, 0 Existencia"
        strSQL &= "         , d.DDoc_Prd_QTY Ordenado, 0 Pendiente, '' Referencia, '' Datos, CONCAT(a.art_DCorta,' ', COALESCE(p.cat_clave,'')) Descripcion, COALESCE(l "
        strSQL &= "             .cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino, (("
        strSQL &= "                 SELECT IFNULL(SUM(r.PDoc_QTY_Pro),0) despacho"
        strSQL &= "                     FROM Dcmtos_DTL_Pro r"
        strSQL &= "                         WHERE r.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND r.PDoc_Par_Cat = d.DDoc_Doc_Cat AND r.PDoc_Par_Ano = d.DDoc_Doc_Ano AND r.PDoc_Par_Num = d"
        strSQL &= "                             .DDoc_Doc_Num AND r.PDoc_Par_Lin = d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat IN (22,48)) + ("
        strSQL &= "                                  SELECT IFNULL(SUM(IDoc_Itm_QTY),0) manual"
        strSQL &= "                                     FROM Dcmtos_DTL_Itm"
        strSQL &= "                                          WHERE IDoc_Sis_Emp=d.DDoc_Sis_Emp AND IDoc_Doc_Cat=d.DDoc_Doc_Cat AND IDoc_Doc_Ano=d.DDoc_Doc_Ano AND IDoc_Doc_Num=d.DDoc_Doc_Num AND"
        strSQL &= "                                     IDoc_Doc_Lin=d.DDoc_Doc_Lin)) Despachado"
        strSQL &= "                             FROM Dcmtos_DTL d"
        strSQL &= "                         LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strSQL &= "                     LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSQL &= "                 LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strSQL &= "             LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = d.DDoc_Prd_UM"
        strSQL &= "          LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab"
        strSQL &= "    WHERE d.DDoc_Sis_Emp = {empresa} AND  d.DDoc_RF2_Num = 0 AND "
        strSQL &= "             d.DDoc_Doc_Cat = {documento} AND ({lista})"
        strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 75)
        strSQL = Replace(strSQL, "{lista}", strTEMP)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= 75 & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("Precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Existencia").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Conversion").ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_CERO.ToString(FORMATO_MONEDA) & "|"
                    strFila &= INT_UNO & "|"
                    strFila &= REA.GetString("Pendiente").ToString & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Lugar") & "|"
                    strFila &= REA.GetInt32("Destino") & "|"
                    strFila &= REA.GetInt32("Original") & "|"
                    strFila &= "e/ " & REA.GetDouble("Existencia").ToString(FORMATO_MONEDA) & "/ p /" & REA.GetDouble("Ordenado").ToString(FORMATO_MONEDA) & "/ d /" & REA.GetDouble("Conversion").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Parte") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("Unidad") & "|"
                    strFila &= REA.GetInt32("Base") & "|"
                    strFila &= REA.GetInt32("Cantidad") & "|"
                    strFila &= REA.GetInt32("Ordenado").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Despachado") & "|"
                    strFila &= 1

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop


                For i = 0 To dgDetalle.Rows.Count - 1
                    'Identificador de la fila: año, numero, codigo, u/m
                    strTEMP2 = dgDetalle.Rows(i).Cells("colAno").Value & "," & dgDetalle.Rows(i).Cells("colNPedido").Value & "," & dgDetalle.Rows(i).Cells("colCodigo").Value

                    'Si no es el mismo hilo limpia los totales
                    If Not (strLinea = strTEMP2) Then
                        If (Temp2 > vbEmpty) Then
                            strLinea = strLinea & "," & (Temp2)
                        End If
                        Temp2 = vbEmpty
                        strLinea = strTEMP2
                    End If

                    Temp = dgDetalle.Rows(i).Cells("colOrden").Value
                    Temp1 = Temp2 + CDbl(dgDetalle.Rows(i).Cells("colOriginal").Value)
                    Temp2 = (Temp - Temp1)

                    If CDbl(Temp2 <= 0) Then
                        Temp2 = (Temp2 * (-1))
                        dgDetalle.Rows(i).Visible = False
                        dgDetalle.Rows(i).Cells("colXtra").Value = 2
                    Else
                        dgDetalle.Rows(i).Cells("colOrden").Value = Math.Round(Temp2, 2)
                        dgDetalle.Rows(i).Cells("colPendiente").Value = Math.Round(Temp2, 2)
                        dgDetalle.Rows(i).Cells("colPedido").Value = Math.Round(Temp2, 2)
                        Temp2 = vbEmpty
                    End If
                Next

                'CalcularTotales()
            End If

            CalcularTotales()

            For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
                'If dgDetalle.Rows(i).Selected Then
                If dgDetalle.Rows(i).Visible = True Then
                    contador = contador + 1
                    dgDetalle.Rows(i).Cells("colIDD").Value = contador
                End If
                'End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click

        Try
            Dim intaño As Integer = vbEmpty
            Dim intNumero As Integer = vbEmpty
            Dim Count As Integer

            If dgPedidos.SelectedRows Is Nothing Then Exit Sub

            If dgPedidos.Rows.Count > 1 Then
                Count = dgPedidos.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1


                    If MsgBox("You sure you want to delete the row Of the PF" & Val(dgPedidos.SelectedCells(0).Value) & " ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                        Me.dgPedidos.Rows.Remove(dgPedidos.SelectedRows(0))
                        dgDetalle.Rows.Clear()
                        NuevoDetalle(celdaIDCliente.Text)
                    End If
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_KeyDown(sender As Object, e As KeyEventArgs) Handles dgDetalle.KeyDown
        Dim i As Integer = 0

        If e.KeyCode = Keys.F8 Then
            If dgDetalle.Rows.Count = 1 Then Exit Sub
            Try
                'For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.SelectedCells(27).Value = 0 Or dgDetalle.SelectedCells(27).Value = 1 Then
                    dgDetalle.SelectedCells(27).Value = 2
                    If dgDetalle.SelectedCells(27).Value = 2 Then
                        dgDetalle.CurrentRow.Visible = False
                    End If
                End If
                'Next
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If ValidarDependencia() = False Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(48, celdaAño.Text, celdaNumero.Text)
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarEncabezadoInstruccion()
                    BorrarDetalleInst()
                    BorrarBultosInstruccion()
                    BorrarBultosInstPro()
                    BorrarDescargosInst()
                    BorrarExistenciaInst()
                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, -1, 48, Val(celdaAño.Text), Val(celdaNumero.Text), Sistema.Version)
                    MsgBox("Delete Complete")
                    MostrarLista()

                End If
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub botonCosteo_Click(sender As Object, e As EventArgs) Handles botonCosteo.Click
        Try
            Dim strCondicion As String = STR_VACIO
            Dim frm As New frmSeleccionar

            frm.Tabla = "Catalogos"
            frm.Campos = "  cat_num, cat_desc"
            frm.Condicion = "  cat_clase = 'Costeo'"
            frm.Filtro = "cli_desc"
            frm.Titulo = "Costing"
            frm.FiltroText = "Enter the costing to filter out"
            If frm.ShowDialog = DialogResult.OK Then
                celdaIdCosteo.Text = frm.LLave
                celdaCosteo.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub checkConsignacion_CheckedChanged(sender As Object, e As EventArgs) Handles checkConsignacion.CheckedChanged
        If checkConsignacion.Checked = True Then
            checkConsignacion.BackColor = Color.DarkOrange
            checkPago.Checked = False
            checkPago.Visible = True
        Else
            checkConsignacion.BackColor = Nothing
            checkPago.Visible = False
        End If
    End Sub


    Private Sub checkPago_Click(sender As Object, e As EventArgs) Handles checkPago.Click
        If LogPago = True Then
            If checkPago.Checked = True Then
                checkPago.BackColor = Color.DarkOliveGreen
            Else
                checkPago.BackColor = Nothing
            End If
        Else
            If checkPago.Checked = True Then
                checkPago.Checked = False
                checkPago.BackColor = Nothing

            Else
                checkPago.BackColor = Color.DarkOliveGreen
                checkPago.Checked = True
            End If
            MsgBox(" You don´t have access to this option ")
        End If

    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit

        Dim Cantidad As Double
        Dim Precio As Double
        Dim Total As Double
        Dim subTotal As Double

        Select Case dgDetalle.CurrentCell.ColumnIndex

            Case 10
                Precio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                Cantidad = dgDetalle.CurrentRow.Cells("colADespachar").Value

                Total = Total + (Precio * Cantidad)
                subTotal = subTotal + Cantidad

                celdaSubTotal.Text = Total
                celdaTotal.Text = subTotal
            Case 12
                CalcularTotales()

        End Select
        If Me.Tag = "Mod" And checkConsignacion.Checked = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand

            strSQL = " Update Dcmtos_DTL_Box SET BDoc_Box_QTY = {bultos}
                        Where BDoc_Sis_Emp = {emp} and BDoc_Doc_Cat = {cat} and BDoc_Doc_Ano= {anio} and BDoc_Doc_Num = {num} and BDoc_Doc_Lin = {line} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; Update PDM.Dcmtos_DTL_Box SET BDoc_Box_QTY = {bultos}
                        Where BDoc_Sis_Emp = {emp} and BDoc_Doc_Cat = {cat} and BDoc_Doc_Ano= {anio} and BDoc_Doc_Num = {num} and BDoc_Doc_Lin = {line} "
            End If
            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{cat}", celdaCatalogo.Text)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)
            strSQL = strSQL.Replace("{line}", dgDetalle.SelectedCells(21).Value)
            strSQL = strSQL.Replace("{bultos}", dgDetalle.SelectedCells(13).Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            MsgBox("Data has been updated, no need to click Save", vbInformation, "Notice")
        End If
    End Sub

    Private Sub celdaFecha_TextChanged(sender As Object, e As EventArgs) Handles celdaFecha.TextChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(celdaFecha.Text)
        End If
    End Sub

    Private Sub dgDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellContentClick

    End Sub

    Private Sub checkFibra_CheckedChanged(sender As Object, e As EventArgs) Handles checkFibra.CheckedChanged
        If checkFibra.Checked = True Then
            dgDetalle.Columns("colLibrasAdicionales").Visible = True
            dgDetalle.Columns("colLibrasAdicionales").ReadOnly = False
        Else
            dgDetalle.Columns("colLibrasAdicionales").Visible = False
            dgDetalle.Columns("colLibrasAdicionales").ReadOnly = True
        End If
    End Sub

    Private Sub checkTraslado_Click(sender As Object, e As EventArgs) Handles checkTraslado.Click
        If checkTraslado.Checked = True Then
            botonPolizaC.Visible = True
        Else
            botonPolizaC.Visible = False
        End If
    End Sub

    Private Sub checkTraslado_CheckedChanged(sender As Object, e As EventArgs) Handles checkTraslado.CheckedChanged
        If checkTraslado.Checked = True Then
            botonPolizaC.Visible = True
        Else
            botonPolizaC.Visible = False
        End If
    End Sub

    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click
        Dim PC As New clsPolizaContable
        PC.intTipo = celdaCatalogo.Text 
        PC.intCiclo = celdaAño.Text
        PC.intNumero = celdaNumero.Text
        PC.intModo = 37
        PC.MostrarPolizaContable()
    End Sub

    Private Sub checkActivar_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivar.CheckedChanged
        ' Verifica si el CheckBox está marcado
        If checkActivar.Checked Then
            ' Si está marcado, poner el valor de la columna "colExtra1" en 1
            For Each row As DataGridViewRow In dgbultos1.Rows
                ' Verificar si la fila no es nueva
                If Not row.IsNewRow Then
                    row.Cells("colExtra1").Value = 1
                End If
            Next
        Else
            ' Si está desmarcado, poner el valor de la columna "colExtra1" en 2
            For Each row As DataGridViewRow In dgbultos1.Rows
                ' Verificar si la fila no es nueva
                If Not row.IsNewRow Then
                    row.Cells("colExtra1").Value = 2
                End If
            Next
        End If
    End Sub
#End Region


End Class