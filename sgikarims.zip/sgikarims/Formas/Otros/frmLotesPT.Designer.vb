﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLotesPT
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.col_catalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_ano = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_numLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_correlativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_PesoNeto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_PesoBruto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.celdaNumeroLote = New System.Windows.Forms.TextBox()
        Me.celdaCorrelativo = New System.Windows.Forms.TextBox()
        Me.etiquetaCorrelativo = New System.Windows.Forms.Label()
        Me.celdaidAnoPO = New System.Windows.Forms.TextBox()
        Me.celdaIdProducto = New System.Windows.Forms.TextBox()
        Me.celdaIdTipoLote = New System.Windows.Forms.TextBox()
        Me.celdaIdEmpacador = New System.Windows.Forms.TextBox()
        Me.celdaIdFrame = New System.Windows.Forms.TextBox()
        Me.celdaIdColorEtiqueta = New System.Windows.Forms.TextBox()
        Me.celdaIdColorCono = New System.Windows.Forms.TextBox()
        Me.celdaIdPO = New System.Windows.Forms.TextBox()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.celdaProducto = New System.Windows.Forms.TextBox()
        Me.botonEmpacador = New System.Windows.Forms.Button()
        Me.celdaEmpacador = New System.Windows.Forms.TextBox()
        Me.etiquetaEmpacador = New System.Windows.Forms.Label()
        Me.botonTipoLote = New System.Windows.Forms.Button()
        Me.celdaTipoLote = New System.Windows.Forms.TextBox()
        Me.etiquetaTipoLote = New System.Windows.Forms.Label()
        Me.lblNumeroLote = New System.Windows.Forms.Label()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.botonColorCono = New System.Windows.Forms.Button()
        Me.celdaColorCono = New System.Windows.Forms.TextBox()
        Me.etiquetaColorCono = New System.Windows.Forms.Label()
        Me.botonPO = New System.Windows.Forms.Button()
        Me.celdaPO = New System.Windows.Forms.TextBox()
        Me.etiquetaPO = New System.Windows.Forms.Label()
        Me.celdaTara = New System.Windows.Forms.TextBox()
        Me.etiquetaTara = New System.Windows.Forms.Label()
        Me.celdaRollosCaja = New System.Windows.Forms.TextBox()
        Me.etiquetaRollosCaja = New System.Windows.Forms.Label()
        Me.botonFrame = New System.Windows.Forms.Button()
        Me.celdaFrame = New System.Windows.Forms.TextBox()
        Me.etiquetaFrame = New System.Windows.Forms.Label()
        Me.botonEtiquetaColor = New System.Windows.Forms.Button()
        Me.celdaEtiquetaColor = New System.Windows.Forms.TextBox()
        Me.etiquetaEtiquetaColor = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaIdEmbalaje = New System.Windows.Forms.TextBox()
        Me.botonEmbalaje = New System.Windows.Forms.Button()
        Me.celdaEmbalaje = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colColorCono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colColorEtiqueta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFrame = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRollosCaja = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipoLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 102)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(1249, 73)
        Me.panelListaPrincipal.TabIndex = 8
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAnio, Me.colNumber, Me.colLoteNumero, Me.colDate, Me.colColorCono, Me.colProducto, Me.colColorEtiqueta, Me.colFrame, Me.colRollosCaja, Me.colTipoLote})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 44)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1249, 29)
        Me.dgLista.TabIndex = 1
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(1249, 44)
        Me.panelFecha.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(436, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(327, 15)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 3
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 2
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(183, 14)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1249, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1249, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.dgDetalle)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(7, 180)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(684, 375)
        Me.panelDocumento.TabIndex = 11
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_catalogo, Me.col_ano, Me.col_numero, Me.col_linea, Me.col_numLote, Me.col_fecha, Me.col_correlativo, Me.col_PesoNeto, Me.col_PesoBruto, Me.col_estado})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 214)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(684, 161)
        Me.dgDetalle.TabIndex = 1
        '
        'col_catalogo
        '
        Me.col_catalogo.HeaderText = "Catalogo"
        Me.col_catalogo.Name = "col_catalogo"
        Me.col_catalogo.ReadOnly = True
        Me.col_catalogo.Visible = False
        '
        'col_ano
        '
        Me.col_ano.HeaderText = "Year"
        Me.col_ano.Name = "col_ano"
        Me.col_ano.ReadOnly = True
        Me.col_ano.Visible = False
        '
        'col_numero
        '
        Me.col_numero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_numero.HeaderText = "Number"
        Me.col_numero.Name = "col_numero"
        Me.col_numero.ReadOnly = True
        Me.col_numero.Visible = False
        '
        'col_linea
        '
        Me.col_linea.HeaderText = "Linea"
        Me.col_linea.Name = "col_linea"
        Me.col_linea.ReadOnly = True
        '
        'col_numLote
        '
        Me.col_numLote.HeaderText = "No. Lote"
        Me.col_numLote.Name = "col_numLote"
        Me.col_numLote.ReadOnly = True
        '
        'col_fecha
        '
        Me.col_fecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_fecha.HeaderText = "Date"
        Me.col_fecha.Name = "col_fecha"
        Me.col_fecha.ReadOnly = True
        Me.col_fecha.Width = 55
        '
        'col_correlativo
        '
        Me.col_correlativo.HeaderText = "Correlativo"
        Me.col_correlativo.Name = "col_correlativo"
        Me.col_correlativo.ReadOnly = True
        '
        'col_PesoNeto
        '
        Me.col_PesoNeto.HeaderText = "Peso Neto"
        Me.col_PesoNeto.Name = "col_PesoNeto"
        Me.col_PesoNeto.ReadOnly = True
        '
        'col_PesoBruto
        '
        Me.col_PesoBruto.HeaderText = "Peso Bruto"
        Me.col_PesoBruto.Name = "col_PesoBruto"
        Me.col_PesoBruto.ReadOnly = True
        '
        'col_estado
        '
        Me.col_estado.HeaderText = "Estado"
        Me.col_estado.Name = "col_estado"
        Me.col_estado.ReadOnly = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.panelEncabezado.Controls.Add(Me.celdaIdEmbalaje)
        Me.panelEncabezado.Controls.Add(Me.botonEmbalaje)
        Me.panelEncabezado.Controls.Add(Me.celdaEmbalaje)
        Me.panelEncabezado.Controls.Add(Me.Label1)
        Me.panelEncabezado.Controls.Add(Me.celdaNumeroLote)
        Me.panelEncabezado.Controls.Add(Me.celdaCorrelativo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCorrelativo)
        Me.panelEncabezado.Controls.Add(Me.celdaidAnoPO)
        Me.panelEncabezado.Controls.Add(Me.celdaIdProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaIdTipoLote)
        Me.panelEncabezado.Controls.Add(Me.celdaIdEmpacador)
        Me.panelEncabezado.Controls.Add(Me.celdaIdFrame)
        Me.panelEncabezado.Controls.Add(Me.celdaIdColorEtiqueta)
        Me.panelEncabezado.Controls.Add(Me.celdaIdColorCono)
        Me.panelEncabezado.Controls.Add(Me.celdaIdPO)
        Me.panelEncabezado.Controls.Add(Me.checkActivar)
        Me.panelEncabezado.Controls.Add(Me.botonProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaProducto)
        Me.panelEncabezado.Controls.Add(Me.botonEmpacador)
        Me.panelEncabezado.Controls.Add(Me.celdaEmpacador)
        Me.panelEncabezado.Controls.Add(Me.etiquetaEmpacador)
        Me.panelEncabezado.Controls.Add(Me.botonTipoLote)
        Me.panelEncabezado.Controls.Add(Me.celdaTipoLote)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTipoLote)
        Me.panelEncabezado.Controls.Add(Me.lblNumeroLote)
        Me.panelEncabezado.Controls.Add(Me.etiquetaProducto)
        Me.panelEncabezado.Controls.Add(Me.botonColorCono)
        Me.panelEncabezado.Controls.Add(Me.celdaColorCono)
        Me.panelEncabezado.Controls.Add(Me.etiquetaColorCono)
        Me.panelEncabezado.Controls.Add(Me.botonPO)
        Me.panelEncabezado.Controls.Add(Me.celdaPO)
        Me.panelEncabezado.Controls.Add(Me.etiquetaPO)
        Me.panelEncabezado.Controls.Add(Me.celdaTara)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTara)
        Me.panelEncabezado.Controls.Add(Me.celdaRollosCaja)
        Me.panelEncabezado.Controls.Add(Me.etiquetaRollosCaja)
        Me.panelEncabezado.Controls.Add(Me.botonFrame)
        Me.panelEncabezado.Controls.Add(Me.celdaFrame)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFrame)
        Me.panelEncabezado.Controls.Add(Me.botonEtiquetaColor)
        Me.panelEncabezado.Controls.Add(Me.celdaEtiquetaColor)
        Me.panelEncabezado.Controls.Add(Me.etiquetaEtiquetaColor)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(684, 214)
        Me.panelEncabezado.TabIndex = 0
        '
        'celdaNumeroLote
        '
        Me.celdaNumeroLote.Location = New System.Drawing.Point(111, 33)
        Me.celdaNumeroLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroLote.Name = "celdaNumeroLote"
        Me.celdaNumeroLote.Size = New System.Drawing.Size(202, 20)
        Me.celdaNumeroLote.TabIndex = 5
        '
        'celdaCorrelativo
        '
        Me.celdaCorrelativo.Location = New System.Drawing.Point(111, 160)
        Me.celdaCorrelativo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCorrelativo.Name = "celdaCorrelativo"
        Me.celdaCorrelativo.Size = New System.Drawing.Size(202, 20)
        Me.celdaCorrelativo.TabIndex = 7
        Me.celdaCorrelativo.Text = "1"
        Me.celdaCorrelativo.Visible = False
        '
        'etiquetaCorrelativo
        '
        Me.etiquetaCorrelativo.AutoSize = True
        Me.etiquetaCorrelativo.Location = New System.Drawing.Point(14, 163)
        Me.etiquetaCorrelativo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCorrelativo.Name = "etiquetaCorrelativo"
        Me.etiquetaCorrelativo.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaCorrelativo.TabIndex = 6
        Me.etiquetaCorrelativo.Text = "Correlativo"
        Me.etiquetaCorrelativo.Visible = False
        '
        'celdaidAnoPO
        '
        Me.celdaidAnoPO.Location = New System.Drawing.Point(379, 102)
        Me.celdaidAnoPO.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidAnoPO.Name = "celdaidAnoPO"
        Me.celdaidAnoPO.ReadOnly = True
        Me.celdaidAnoPO.Size = New System.Drawing.Size(34, 20)
        Me.celdaidAnoPO.TabIndex = 36
        '
        'celdaIdProducto
        '
        Me.celdaIdProducto.Location = New System.Drawing.Point(57, 184)
        Me.celdaIdProducto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdProducto.Name = "celdaIdProducto"
        Me.celdaIdProducto.ReadOnly = True
        Me.celdaIdProducto.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdProducto.TabIndex = 19
        Me.celdaIdProducto.Visible = False
        '
        'celdaIdTipoLote
        '
        Me.celdaIdTipoLote.Location = New System.Drawing.Point(73, 58)
        Me.celdaIdTipoLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdTipoLote.Name = "celdaIdTipoLote"
        Me.celdaIdTipoLote.ReadOnly = True
        Me.celdaIdTipoLote.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdTipoLote.TabIndex = 9
        Me.celdaIdTipoLote.Visible = False
        '
        'celdaIdEmpacador
        '
        Me.celdaIdEmpacador.Location = New System.Drawing.Point(414, 34)
        Me.celdaIdEmpacador.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdEmpacador.Name = "celdaIdEmpacador"
        Me.celdaIdEmpacador.ReadOnly = True
        Me.celdaIdEmpacador.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdEmpacador.TabIndex = 24
        Me.celdaIdEmpacador.Visible = False
        '
        'celdaIdFrame
        '
        Me.celdaIdFrame.Location = New System.Drawing.Point(417, 78)
        Me.celdaIdFrame.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdFrame.Name = "celdaIdFrame"
        Me.celdaIdFrame.ReadOnly = True
        Me.celdaIdFrame.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdFrame.TabIndex = 32
        Me.celdaIdFrame.Visible = False
        '
        'celdaIdColorEtiqueta
        '
        Me.celdaIdColorEtiqueta.Location = New System.Drawing.Point(417, 55)
        Me.celdaIdColorEtiqueta.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdColorEtiqueta.Name = "celdaIdColorEtiqueta"
        Me.celdaIdColorEtiqueta.ReadOnly = True
        Me.celdaIdColorEtiqueta.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdColorEtiqueta.TabIndex = 28
        Me.celdaIdColorEtiqueta.Visible = False
        '
        'celdaIdColorCono
        '
        Me.celdaIdColorCono.Location = New System.Drawing.Point(74, 107)
        Me.celdaIdColorCono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdColorCono.Name = "celdaIdColorCono"
        Me.celdaIdColorCono.ReadOnly = True
        Me.celdaIdColorCono.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdColorCono.TabIndex = 15
        Me.celdaIdColorCono.Visible = False
        '
        'celdaIdPO
        '
        Me.celdaIdPO.Location = New System.Drawing.Point(414, 102)
        Me.celdaIdPO.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdPO.Name = "celdaIdPO"
        Me.celdaIdPO.ReadOnly = True
        Me.celdaIdPO.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdPO.TabIndex = 37
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(363, 9)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 22
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'botonProducto
        '
        Me.botonProducto.Location = New System.Drawing.Point(629, 184)
        Me.botonProducto.Margin = New System.Windows.Forms.Padding(2)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(25, 19)
        Me.botonProducto.TabIndex = 21
        Me.botonProducto.Text = "..."
        Me.botonProducto.UseVisualStyleBackColor = True
        '
        'celdaProducto
        '
        Me.celdaProducto.Location = New System.Drawing.Point(95, 184)
        Me.celdaProducto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProducto.Name = "celdaProducto"
        Me.celdaProducto.ReadOnly = True
        Me.celdaProducto.Size = New System.Drawing.Size(530, 20)
        Me.celdaProducto.TabIndex = 20
        '
        'botonEmpacador
        '
        Me.botonEmpacador.Location = New System.Drawing.Point(629, 34)
        Me.botonEmpacador.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEmpacador.Name = "botonEmpacador"
        Me.botonEmpacador.Size = New System.Drawing.Size(25, 19)
        Me.botonEmpacador.TabIndex = 26
        Me.botonEmpacador.Text = "..."
        Me.botonEmpacador.UseVisualStyleBackColor = True
        '
        'celdaEmpacador
        '
        Me.celdaEmpacador.Location = New System.Drawing.Point(452, 33)
        Me.celdaEmpacador.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEmpacador.Name = "celdaEmpacador"
        Me.celdaEmpacador.ReadOnly = True
        Me.celdaEmpacador.Size = New System.Drawing.Size(173, 20)
        Me.celdaEmpacador.TabIndex = 25
        '
        'etiquetaEmpacador
        '
        Me.etiquetaEmpacador.AutoSize = True
        Me.etiquetaEmpacador.Location = New System.Drawing.Point(355, 37)
        Me.etiquetaEmpacador.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaEmpacador.Name = "etiquetaEmpacador"
        Me.etiquetaEmpacador.Size = New System.Drawing.Size(64, 13)
        Me.etiquetaEmpacador.TabIndex = 23
        Me.etiquetaEmpacador.Text = "Empacador:"
        '
        'botonTipoLote
        '
        Me.botonTipoLote.Location = New System.Drawing.Point(288, 59)
        Me.botonTipoLote.Margin = New System.Windows.Forms.Padding(2)
        Me.botonTipoLote.Name = "botonTipoLote"
        Me.botonTipoLote.Size = New System.Drawing.Size(25, 19)
        Me.botonTipoLote.TabIndex = 11
        Me.botonTipoLote.Text = "..."
        Me.botonTipoLote.UseVisualStyleBackColor = True
        '
        'celdaTipoLote
        '
        Me.celdaTipoLote.Location = New System.Drawing.Point(111, 58)
        Me.celdaTipoLote.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTipoLote.Name = "celdaTipoLote"
        Me.celdaTipoLote.ReadOnly = True
        Me.celdaTipoLote.Size = New System.Drawing.Size(173, 20)
        Me.celdaTipoLote.TabIndex = 10
        '
        'etiquetaTipoLote
        '
        Me.etiquetaTipoLote.AutoSize = True
        Me.etiquetaTipoLote.Location = New System.Drawing.Point(14, 62)
        Me.etiquetaTipoLote.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTipoLote.Name = "etiquetaTipoLote"
        Me.etiquetaTipoLote.Size = New System.Drawing.Size(55, 13)
        Me.etiquetaTipoLote.TabIndex = 8
        Me.etiquetaTipoLote.Text = "Tipo Lote:"
        '
        'lblNumeroLote
        '
        Me.lblNumeroLote.AutoSize = True
        Me.lblNumeroLote.Location = New System.Drawing.Point(16, 36)
        Me.lblNumeroLote.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblNumeroLote.Name = "lblNumeroLote"
        Me.lblNumeroLote.Size = New System.Drawing.Size(51, 13)
        Me.lblNumeroLote.TabIndex = 4
        Me.lblNumeroLote.Text = "No. Lote:"
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(16, 187)
        Me.etiquetaProducto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(53, 13)
        Me.etiquetaProducto.TabIndex = 18
        Me.etiquetaProducto.Text = "Producto:"
        '
        'botonColorCono
        '
        Me.botonColorCono.Location = New System.Drawing.Point(288, 107)
        Me.botonColorCono.Margin = New System.Windows.Forms.Padding(2)
        Me.botonColorCono.Name = "botonColorCono"
        Me.botonColorCono.Size = New System.Drawing.Size(25, 19)
        Me.botonColorCono.TabIndex = 17
        Me.botonColorCono.Text = "..."
        Me.botonColorCono.UseVisualStyleBackColor = True
        '
        'celdaColorCono
        '
        Me.celdaColorCono.Location = New System.Drawing.Point(111, 107)
        Me.celdaColorCono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaColorCono.Name = "celdaColorCono"
        Me.celdaColorCono.ReadOnly = True
        Me.celdaColorCono.Size = New System.Drawing.Size(173, 20)
        Me.celdaColorCono.TabIndex = 16
        '
        'etiquetaColorCono
        '
        Me.etiquetaColorCono.AutoSize = True
        Me.etiquetaColorCono.Location = New System.Drawing.Point(14, 110)
        Me.etiquetaColorCono.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaColorCono.Name = "etiquetaColorCono"
        Me.etiquetaColorCono.Size = New System.Drawing.Size(77, 13)
        Me.etiquetaColorCono.TabIndex = 14
        Me.etiquetaColorCono.Text = "Color de Cono:"
        '
        'botonPO
        '
        Me.botonPO.Location = New System.Drawing.Point(629, 103)
        Me.botonPO.Margin = New System.Windows.Forms.Padding(2)
        Me.botonPO.Name = "botonPO"
        Me.botonPO.Size = New System.Drawing.Size(25, 19)
        Me.botonPO.TabIndex = 39
        Me.botonPO.Text = "..."
        Me.botonPO.UseVisualStyleBackColor = True
        '
        'celdaPO
        '
        Me.celdaPO.Location = New System.Drawing.Point(452, 102)
        Me.celdaPO.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPO.Name = "celdaPO"
        Me.celdaPO.Size = New System.Drawing.Size(173, 20)
        Me.celdaPO.TabIndex = 38
        '
        'etiquetaPO
        '
        Me.etiquetaPO.AutoSize = True
        Me.etiquetaPO.Location = New System.Drawing.Point(355, 106)
        Me.etiquetaPO.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaPO.Name = "etiquetaPO"
        Me.etiquetaPO.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaPO.TabIndex = 35
        Me.etiquetaPO.Text = "PO:"
        '
        'celdaTara
        '
        Me.celdaTara.Location = New System.Drawing.Point(111, 79)
        Me.celdaTara.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTara.Name = "celdaTara"
        Me.celdaTara.Size = New System.Drawing.Size(202, 20)
        Me.celdaTara.TabIndex = 13
        '
        'etiquetaTara
        '
        Me.etiquetaTara.AutoSize = True
        Me.etiquetaTara.Location = New System.Drawing.Point(14, 82)
        Me.etiquetaTara.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTara.Name = "etiquetaTara"
        Me.etiquetaTara.Size = New System.Drawing.Size(32, 13)
        Me.etiquetaTara.TabIndex = 12
        Me.etiquetaTara.Text = "Tara:"
        '
        'celdaRollosCaja
        '
        Me.celdaRollosCaja.Location = New System.Drawing.Point(452, 128)
        Me.celdaRollosCaja.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRollosCaja.Name = "celdaRollosCaja"
        Me.celdaRollosCaja.Size = New System.Drawing.Size(202, 20)
        Me.celdaRollosCaja.TabIndex = 41
        '
        'etiquetaRollosCaja
        '
        Me.etiquetaRollosCaja.AutoSize = True
        Me.etiquetaRollosCaja.Location = New System.Drawing.Point(355, 131)
        Me.etiquetaRollosCaja.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRollosCaja.Name = "etiquetaRollosCaja"
        Me.etiquetaRollosCaja.Size = New System.Drawing.Size(84, 13)
        Me.etiquetaRollosCaja.TabIndex = 40
        Me.etiquetaRollosCaja.Text = "Rollos por Bulto:"
        '
        'botonFrame
        '
        Me.botonFrame.Location = New System.Drawing.Point(629, 79)
        Me.botonFrame.Margin = New System.Windows.Forms.Padding(2)
        Me.botonFrame.Name = "botonFrame"
        Me.botonFrame.Size = New System.Drawing.Size(25, 19)
        Me.botonFrame.TabIndex = 34
        Me.botonFrame.Text = "..."
        Me.botonFrame.UseVisualStyleBackColor = True
        '
        'celdaFrame
        '
        Me.celdaFrame.Location = New System.Drawing.Point(452, 78)
        Me.celdaFrame.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaFrame.Name = "celdaFrame"
        Me.celdaFrame.ReadOnly = True
        Me.celdaFrame.Size = New System.Drawing.Size(173, 20)
        Me.celdaFrame.TabIndex = 33
        '
        'etiquetaFrame
        '
        Me.etiquetaFrame.AutoSize = True
        Me.etiquetaFrame.Location = New System.Drawing.Point(355, 82)
        Me.etiquetaFrame.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFrame.Name = "etiquetaFrame"
        Me.etiquetaFrame.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaFrame.TabIndex = 31
        Me.etiquetaFrame.Text = "Frame:"
        '
        'botonEtiquetaColor
        '
        Me.botonEtiquetaColor.Location = New System.Drawing.Point(629, 55)
        Me.botonEtiquetaColor.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEtiquetaColor.Name = "botonEtiquetaColor"
        Me.botonEtiquetaColor.Size = New System.Drawing.Size(25, 19)
        Me.botonEtiquetaColor.TabIndex = 30
        Me.botonEtiquetaColor.Text = "..."
        Me.botonEtiquetaColor.UseVisualStyleBackColor = True
        '
        'celdaEtiquetaColor
        '
        Me.celdaEtiquetaColor.Location = New System.Drawing.Point(452, 54)
        Me.celdaEtiquetaColor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEtiquetaColor.Name = "celdaEtiquetaColor"
        Me.celdaEtiquetaColor.ReadOnly = True
        Me.celdaEtiquetaColor.Size = New System.Drawing.Size(173, 20)
        Me.celdaEtiquetaColor.TabIndex = 29
        '
        'etiquetaEtiquetaColor
        '
        Me.etiquetaEtiquetaColor.AutoSize = True
        Me.etiquetaEtiquetaColor.Location = New System.Drawing.Point(355, 58)
        Me.etiquetaEtiquetaColor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaEtiquetaColor.Name = "etiquetaEtiquetaColor"
        Me.etiquetaEtiquetaColor.Size = New System.Drawing.Size(91, 13)
        Me.etiquetaEtiquetaColor.TabIndex = 27
        Me.etiquetaEtiquetaColor.Text = "Color de Etiqueta:"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(211, 9)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(34, 20)
        Me.celdaNumero.TabIndex = 3
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(173, 9)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(34, 20)
        Me.celdaAnio.TabIndex = 2
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(76, 10)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(94, 20)
        Me.dtpFecha.TabIndex = 1
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(16, 12)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(40, 13)
        Me.etiquetaFecha.TabIndex = 0
        Me.etiquetaFecha.Text = "Fecha:"
        '
        'celdaIdEmbalaje
        '
        Me.celdaIdEmbalaje.Location = New System.Drawing.Point(73, 132)
        Me.celdaIdEmbalaje.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdEmbalaje.Name = "celdaIdEmbalaje"
        Me.celdaIdEmbalaje.ReadOnly = True
        Me.celdaIdEmbalaje.Size = New System.Drawing.Size(34, 20)
        Me.celdaIdEmbalaje.TabIndex = 43
        Me.celdaIdEmbalaje.Visible = False
        '
        'botonEmbalaje
        '
        Me.botonEmbalaje.Location = New System.Drawing.Point(287, 132)
        Me.botonEmbalaje.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEmbalaje.Name = "botonEmbalaje"
        Me.botonEmbalaje.Size = New System.Drawing.Size(25, 19)
        Me.botonEmbalaje.TabIndex = 45
        Me.botonEmbalaje.Text = "..."
        Me.botonEmbalaje.UseVisualStyleBackColor = True
        '
        'celdaEmbalaje
        '
        Me.celdaEmbalaje.Location = New System.Drawing.Point(110, 132)
        Me.celdaEmbalaje.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaEmbalaje.Name = "celdaEmbalaje"
        Me.celdaEmbalaje.ReadOnly = True
        Me.celdaEmbalaje.Size = New System.Drawing.Size(173, 20)
        Me.celdaEmbalaje.TabIndex = 44
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 135)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "Embalaje"
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Visible = False
        Me.colNumber.Width = 69
        '
        'colLoteNumero
        '
        Me.colLoteNumero.HeaderText = "No. Lote"
        Me.colLoteNumero.Name = "colLoteNumero"
        Me.colLoteNumero.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 55
        '
        'colColorCono
        '
        Me.colColorCono.HeaderText = "ColorCono"
        Me.colColorCono.Name = "colColorCono"
        Me.colColorCono.ReadOnly = True
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Product"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        '
        'colColorEtiqueta
        '
        Me.colColorEtiqueta.HeaderText = "Color Etiqueta"
        Me.colColorEtiqueta.Name = "colColorEtiqueta"
        Me.colColorEtiqueta.ReadOnly = True
        '
        'colFrame
        '
        Me.colFrame.HeaderText = "Frame"
        Me.colFrame.Name = "colFrame"
        Me.colFrame.ReadOnly = True
        '
        'colRollosCaja
        '
        Me.colRollosCaja.HeaderText = "Rollos por bulto"
        Me.colRollosCaja.Name = "colRollosCaja"
        Me.colRollosCaja.ReadOnly = True
        '
        'colTipoLote
        '
        Me.colTipoLote.HeaderText = "Tipo Lote"
        Me.colTipoLote.Name = "colTipoLote"
        Me.colTipoLote.ReadOnly = True
        '
        'frmLotesPT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1249, 605)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmLotesPT"
        Me.Text = "frmLotesPT"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents celdaNumeroLote As TextBox
    Friend WithEvents celdaCorrelativo As TextBox
    Friend WithEvents etiquetaCorrelativo As Label
    Friend WithEvents celdaidAnoPO As TextBox
    Friend WithEvents celdaIdProducto As TextBox
    Friend WithEvents celdaIdTipoLote As TextBox
    Friend WithEvents celdaIdEmpacador As TextBox
    Friend WithEvents celdaIdFrame As TextBox
    Friend WithEvents celdaIdColorEtiqueta As TextBox
    Friend WithEvents celdaIdColorCono As TextBox
    Friend WithEvents celdaIdPO As TextBox
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents botonProducto As Button
    Friend WithEvents celdaProducto As TextBox
    Friend WithEvents botonEmpacador As Button
    Friend WithEvents celdaEmpacador As TextBox
    Friend WithEvents etiquetaEmpacador As Label
    Friend WithEvents botonTipoLote As Button
    Friend WithEvents celdaTipoLote As TextBox
    Friend WithEvents etiquetaTipoLote As Label
    Friend WithEvents lblNumeroLote As Label
    Friend WithEvents etiquetaProducto As Label
    Friend WithEvents botonColorCono As Button
    Friend WithEvents celdaColorCono As TextBox
    Friend WithEvents etiquetaColorCono As Label
    Friend WithEvents botonPO As Button
    Friend WithEvents celdaPO As TextBox
    Friend WithEvents etiquetaPO As Label
    Friend WithEvents celdaTara As TextBox
    Friend WithEvents etiquetaTara As Label
    Friend WithEvents celdaRollosCaja As TextBox
    Friend WithEvents etiquetaRollosCaja As Label
    Friend WithEvents botonFrame As Button
    Friend WithEvents celdaFrame As TextBox
    Friend WithEvents etiquetaFrame As Label
    Friend WithEvents botonEtiquetaColor As Button
    Friend WithEvents celdaEtiquetaColor As TextBox
    Friend WithEvents etiquetaEtiquetaColor As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents col_catalogo As DataGridViewTextBoxColumn
    Friend WithEvents col_ano As DataGridViewTextBoxColumn
    Friend WithEvents col_numero As DataGridViewTextBoxColumn
    Friend WithEvents col_linea As DataGridViewTextBoxColumn
    Friend WithEvents col_numLote As DataGridViewTextBoxColumn
    Friend WithEvents col_fecha As DataGridViewTextBoxColumn
    Friend WithEvents col_correlativo As DataGridViewTextBoxColumn
    Friend WithEvents col_PesoNeto As DataGridViewTextBoxColumn
    Friend WithEvents col_PesoBruto As DataGridViewTextBoxColumn
    Friend WithEvents col_estado As DataGridViewTextBoxColumn
    Friend WithEvents celdaIdEmbalaje As TextBox
    Friend WithEvents botonEmbalaje As Button
    Friend WithEvents celdaEmbalaje As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colLoteNumero As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colColorCono As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents colColorEtiqueta As DataGridViewTextBoxColumn
    Friend WithEvents colFrame As DataGridViewTextBoxColumn
    Friend WithEvents colRollosCaja As DataGridViewTextBoxColumn
    Friend WithEvents colTipoLote As DataGridViewTextBoxColumn
End Class
