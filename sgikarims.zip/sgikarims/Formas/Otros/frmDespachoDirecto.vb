﻿Imports System.ComponentModel

Public Class frmDespachoDirecto
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Private Const CXC_NAME As String = "Despacho"
#End Region

#Region "Procedimiento"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones y procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelDocumento.Dock = DockStyle.None
            PanelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Direct Dispatch")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            PanelDocumento.Dock = DockStyle.Fill
            PanelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                Reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            ' SUM((l1.Saldo - l1.Monto)) monto
            strSql = "      SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Emp_Nom Provider, c.cli_nombre Cliente, IF(h.HDoc_Doc_Status = 0,'CANCELED', 'ACTIVE') Estado  
                                FROM Dcmtos_HDR h  
                        LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_DR1_Emp
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 446 "


            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            ' strSql = strSql.Replace("{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            ' strSql = strSql.Replace("{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read

                    strLinea = REA.GetInt32("Anio") & "|" 'Anio
                    strLinea &= REA.GetString("Numero") & "|" 'Numero
                    strLinea &= REA.GetString("Provider") & "|" 'Proveedor
                    strLinea &= REA.GetString("Cliente") & "|" 'Numero
                    strLinea &= REA.GetString("Estado") ' Estado
                    If REA.GetString("Estado") = "CANCELED" Then
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub reset()
        celdaNumero.Text = NO_FILA
        celdaAño.Text = NO_FILA
        dtpFecha.Value = Now()
        celdaCliente.Text = STR_VACIO
        celdaidCliente.Text = NO_FILA
        celdaDireccionCliente.Text = STR_VACIO
        celdaProveedor.Text = STR_VACIO
        celdaDireccionProveedor.Text = STR_VACIO
        celdaidProveedor.Text = NO_FILA
        checkActive.Checked = True
        dgDetalle.Rows.Clear()
        celdaAño.Text = cFunciones.AñoMySQL
        celdaMoneda.Text = "US$"
        celdaIDMoneda.Text = 178
        celdaTC.Text = cFunciones.QueryTasa("CURDATE()")

    End Sub
    Public Sub ValidarComision()
        If PermisoComision() = True Then
            dgDetalle.Columns(8).Visible = True
            dgDetalle.Columns(9).Visible = True
            etiquetaComision.Visible = True
            etiquetaComisionPorcentaje.Visible = True
            celdaComision.Visible = True
            celdaComisionPorcentaje.Visible = True
        Else
            dgDetalle.Columns(8).Visible = False
            dgDetalle.Columns(9).Visible = False
            etiquetaComision.Visible = False
            etiquetaComisionPorcentaje.Visible = False
            celdaComision.Visible = False
            celdaComisionPorcentaje.Visible = False
        End If
    End Sub
    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double
        Dim dblDocCantidad As Double = INT_CERO
        Dim dblComision As Double = 0
        Dim dblPorcentaje As Double = INT_CERO
        Dim dblDocTotal As Double
        Try
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = True Then
                    dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                    dblCant = dgDetalle.Rows(i).Cells("colCantidad").Value
                    dblComision = (dblComision) + (dgDetalle.Rows(i).Cells("colComision").Value)
                    dblPorcentaje = (dblPorcentaje) + (dgDetalle.Rows(i).Cells("colPorcentajeC").Value)
                    dblDocCantidad = dblDocCantidad + dblCant
                    dblDocTotal = dblDocTotal + (dblCant * dblPrecio)
                End If
            Next
            celdaComision.Text = dblComision.ToString(FORMATO_MONEDA) ' Comision 
            celdaTotal.Text = dblDocTotal.ToString(FORMATO_MONEDA) ' Total
            celdaCantidad.Text = dblDocCantidad.ToString(FORMATO_MONEDA) ' Cantidad
            celdaComisionPorcentaje.Text = dblPorcentaje.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function PermisoComision() As Boolean

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_codigo Permiso"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_usuario = '{usuario}' AND p.pms_modulo = 602 AND p.pms_codigo  ='SECRET'"
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetString("Permiso") = "SECRET" Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    Private Function NuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " SELECT IFNULL(MAX(h.HDoc_Doc_Num),0)  + 1 Codigo "
        strSQL &= " FROM Dcmtos_HDR h "
        strSQL &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 446  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", Codigo)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{catalogo}", 446)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaidProveedor.Text = NO_FILA Then
            MsgBox("BLANK Provider")
            celdaProveedor.Focus()
            Comprobar = False
        End If
        If celdaidCliente.Text = NO_FILA Then
            celdaCliente.Focus()
            MsgBox("BLANK Client")
            Comprobar = False
        End If

        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFilaDetalle() As Boolean

        Dim i As Integer
        Dim Comprobacion As Boolean = True
        If dgDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            Comprobacion = False
        Else
            Comprobacion = True
        End If
        For i = 0 To dgDetalle.Rows.Count - 1

            If dgDetalle.Rows(i).Cells("colPrecio").Value = vbNullString Then
                Comprobacion = False
                MsgBox("ZERO price items")
            End If

            If dgDetalle.Rows(i).Cells("colCantidad").Value = vbNullString Then
                Comprobacion = False
                MsgBox("Item number ZERO")
            End If
        Next
        Return Comprobacion
    End Function
    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean = True
        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 446
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value
            chdr.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, vbEmpty)

            chdr.HDOC_EMP_COD = celdaidProveedor.Text
            chdr.HDOC_EMP_NOM = celdaProveedor.Text
            chdr.HDOC_EMP_DIR = celdaDireccionProveedor.Text
            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            chdr.HDOC_DOC_TC = celdaTC.Text
            chdr.HDOC_DR1_EMP = celdaidCliente.Text
            chdr.HDOC_USUARIO = Sesion.idUsuario
            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, celdaidProveedor.Text, 446, celdaAño.Text, celdaNumero.Text)
                If GuardarDetalle(celdaNumero.Text) = True Then
                    logResultado = True
                Else
                    logResultado = False
                End If
                If GuardarOperacion(celdaNumero.Text) = True Then
                    logResultado = True
                Else
                    logResultado = False
                End If
            Else
                celdaNumero.Text = NuevoCodigo()
                chdr.HDOC_DOC_NUM = celdaNumero.Text
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, celdaidProveedor.Text, 446, celdaAño.Text, celdaNumero.Text)
                If GuardarDetalle(celdaNumero.Text) = True Then
                    logResultado = True
                Else
                    logResultado = False
                End If
                If GuardarOperacion(celdaNumero.Text) = True Then
                    logResultado = True
                Else
                    logResultado = False
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    'Query para guardar el Detalle
    Private Function GuardarDetalle(ByVal Codigo As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intLinea As Integer = vbEmpty


        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = True Then
                    Dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    Dtl.DDOC_DOC_CAT = 446
                    Dtl.DDOC_DOC_ANO = celdaAño.Text
                    Dtl.DDOC_DOC_NUM = Codigo

                    Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                    Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                    Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value


                    Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value

                    Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colComision").Value

                    If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                        dgDetalle.Rows(i).Cells("colLinea").Value = NuevaLinea(Codigo)
                        Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        If Dtl.Guardar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                    If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                        Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        If Dtl.Actualizar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    End If
                Else
                    If dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                        Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        If Dtl.Borrar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Sub ActualizarReferencia()
        Dim COM As MySqlCommand
        Dim strSQL As String
        Dim dblAbonoExt As Double = 0
        Dim dblAbonoLoc As Double = 0
        Dim dblTotal As Double
        Dim dblCredito As Double
        Dim dblDebito As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO
        Dim cat As Integer = NO_FILA
        Dim anioRef As Integer = NO_FILA
        Dim numref As Integer = NO_FILA
        Try

            dblTasa = celdaTC.Text

            For i = 0 To dgDetalle.Rows.Count - 1
                dblCredito = vbEmpty
                dblDebito = vbEmpty

                If (checkActive.Checked) = True And (dgDetalle.Rows.Count > vbEmpty) Then
                    dblTotal = CDbl((dgDetalle.Rows(i).Cells("colComision").Value * dgDetalle.Rows(i).Cells("colCantidad").Value))
                End If
                strDato = CXC_NAME & "No." & CDbl(celdaNumero.Text)

                'Documento de referencia (factura)
                anioRef = celdaAño.Text
                numref = celdaNumero.Text
                'Transacción: cargo/abono local y en moneda del doc.
                dblCredito = (dblTotal * dblTasa).ToString(FORMATO_MONEDA)
            Next

            strSQL = " UPDATE  ECtaCte  e  SET e.ECta_codemp = {cliente},e.ECta_Abno_Loc = {total}, e.ECta_Abno_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fecha}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
            strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 446  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE  PDM.ECtaCte  e  SET e.ECta_codemp = {cliente},e.ECta_Abno_Loc = {total}, e.ECta_Abno_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fecha}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
                strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 446  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{total}", dblCredito)
            strSQL = Replace(strSQL, "{totalext}", dblTotal)
            strSQL = Replace(strSQL, "{dato}", strDato)
            strSQL = Replace(strSQL, "{cliente}", celdaidProveedor.Text)
            strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{moneda}", celdaIDMoneda.Text)
            strSQL = Replace(strSQL, "{tasa}", celdaTC.Text)
            strSQL = Replace(strSQL, "{catref}", 446)
            strSQL = Replace(strSQL, "{anioref}", anioRef)
            strSQL = Replace(strSQL, "{numref}", numref)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarOperacion(ByVal Codigo As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim EC As New Tablas.TECTACTE
        EC.CONEXION = strConexion
        Dim i As Integer = vbEmpty
        Dim dblCredito As Double
        Dim dblDebito As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO

        Try
            dblTasa = celdaTC.Text

            For i = 0 To dgDetalle.Rows.Count - 1
                dblCredito = vbEmpty
                dblDebito = vbEmpty

                If (checkActive.Checked) = True And (dgDetalle.Rows.Count > vbEmpty) Then
                    dblDebito = CDbl((dgDetalle.Rows(i).Cells("colComision").Value * dgDetalle.Rows(i).Cells("colCantidad").Value))
                End If


                'Datos de la Nota
                EC.ECTA_SIS_EMP = Sesion.IdEmpresa
                EC.ECTA_DOC_CAT = 446
                EC.ECTA_DOC_ANO = celdaAño.Text
                EC.ECTA_DOC_NUM = celdaNumero.Text

                EC.ECTA_DOC_LIN = i + 1

                strDato = CXC_NAME & "No." & CDbl(Codigo)

                'Documento de referencia 
                EC.ECTA_REF_CAT = 446
                EC.ECTA_REF_ANO = celdaAño.Text
                EC.ECTA_REF_NUM = Codigo



                'Empresa 
                EC.ECTA_TIPOEMP = "Proveedores"
                EC.ECTA_CODEMP = celdaidProveedor.Text

                'Transacción: cargo/abono local y en moneda del doc.
                EC.ECTA_SINI_LOC = vbEmpty
                EC.ECTA_CRGO_LOC = (dblDebito * dblTasa)
                EC.ECTA_ABNO_LOC = (dblCredito * dblTasa).ToString(FORMATO_MONEDA)
                EC.ECTA_SINI_EXT = vbEmpty
                EC.ECTA_CRGO_EXT = dblDebito.ToString(FORMATO_MONEDA)
                EC.ECTA_ABNO_EXT = dblCredito.ToString(FORMATO_MONEDA)
                EC.ECTA_CONCEPTO = strDato
                EC.ECta_FecDcmt_NET = dtpFecha.Value
                EC.ECta_FecVenc_NET = dtpFecha.Value
                EC.ECTA_MONEDA = celdaIDMoneda.Text
                EC.ECTA_TC = celdaTC.Text

                If Me.Tag = "Mod" Then
                    ActualizarReferencia()
                    'If EC.PUPDATE() = False Then
                    '    MsgBox(EC.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    'End If
                ElseIf Me.Tag = "Nuevo" Then
                    If EC.PINSERT() = False Then
                        MsgBox(EC.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function SQLEncabezado(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Num NUMBER,HDR.HDoc_Doc_Ano Anio,HDR.HDoc_Doc_Fec Fecha,HDR.HDoc_Emp_Cod idProveedor, HDR.HDoc_Emp_Nom Proveedor, HDR.HDoc_Emp_Dir DireccionProveedor,HDR.HDoc_Doc_Mon idMoneda ,c.cat_clave Moneda,HDR.HDoc_Doc_TC Tasa,HDR.HDoc_DR1_Emp idCliente ,cl.cli_cliente NombreCliente,cl.cli_direccion DireccionCliente,HDR.HDoc_Doc_Status Estado "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = HDR.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
        strSQL &= " LEFT JOIN Clientes cl ON cl.cli_sisemp = HDR.HDoc_Sis_Emp AND cl.cli_codigo = HDR.HDoc_DR1_Emp "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio} AND HDR.HDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 446)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT DTL.DDoc_Prd_Cod codigo,DTL.DDoc_Prd_Des Producto,DTL.DDoc_Prd_QTY cantidad,DTL.DDoc_Prd_NET Precio,DTL.DDoc_Prd_UM medida, c.cat_clave Descripcion,DTL.DDoc_Doc_Lin Linea,DTL.DDoc_Prd_PUQ Comision  "
        strSQL &= "  FROM Dcmtos_DTL DTL"
        strSQL &= "  LEFT JOIN Inventarios i ON i.inv_sisemp = DTL.DDoc_Sis_Emp AND i.inv_numero = DTL.DDoc_Prd_Cod AND i.inv_UMcmpra = DTL.DDoc_Prd_UM "
        strSQL &= "  LEFT JOIN Articulos a ON a.art_sisemp =i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "  LEFT JOIN Catalogos c ON c.cat_num = DTL.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
        strSQL &= "  WHERE DTL.DDoc_Sis_Emp = {empresa} AND DTL.DDoc_Doc_Cat = {catalogo} AND DTL.DDoc_Doc_Ano = {anio} AND DTL.DDoc_Doc_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 446)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Sub CargarDetalle(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        Dim dblPrecio As Double
        Dim dblCantidad As Double
        strSQL = SQLDetalle(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgDetalle.Rows.Clear()
            Do While REA.Read
                dblPrecio = REA.GetDouble("Precio")
                dblCantidad = REA.GetDouble("cantidad")
                strLinea = REA.GetInt32("Linea") & "|" '  LINE
                strLinea &= REA.GetInt32("codigo") & "|" 'ID CODIGO
                strLinea &= REA.GetString("Producto") & "|" 'Titulo de producto cotizado   
                strLinea &= REA.GetInt32("medida") & "|" ' id
                strLinea &= REA.GetString("Descripcion") & "|"  ' Medida
                strLinea &= REA.GetDouble("Precio") & "|" ' Price
                strLinea &= REA.GetDouble("cantidad") & "|" ' Cantidad
                strLinea &= (dblPrecio * dblCantidad).ToString(FORMATO_MONEDA) & "|" ' Total 
                strLinea &= REA.GetDouble("Comision") & "|" ' Comision 
                strLinea &= ((REA.GetDouble("Comision") * 100) / dblPrecio).ToString(FORMATO_MONEDA) & "|" ' Comision 
                strLinea &= "1" ' Status
                cFunciones.AgregarFila(dgDetalle, strLinea)
            Loop
        End If
    End Sub
    Public Sub Seleccionar(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLEncabezado(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAño.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("NUMBER")
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                celdaidProveedor.Text = REA.GetInt32("idProveedor")
                celdaProveedor.Text = REA.GetString("Proveedor")
                celdaDireccionProveedor.Text = REA.GetString("DireccionProveedor")
                celdaIDMoneda.Text = REA.GetInt32("idMoneda")
                celdaMoneda.Text = REA.GetString("Moneda")
                celdaTC.Text = REA.GetDouble("Tasa")
                celdaidCliente.Text = REA.GetInt32("idCliente")
                celdaCliente.Text = REA.GetString("NombreCliente")
                celdaDireccionCliente.Text = REA.GetString("DireccionCliente")
                If REA.GetInt32("Estado") = INT_CERO Then
                    checkActive.Checked = False
                Else
                    checkActive.Checked = True
                End If
            Loop
        End If
        CargarDetalle(Codigo, Año)
        CalcularTotales()
    End Sub
    Private Sub EliminarEncabezado()
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 446
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarDetalle()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = 446 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarEctate(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 446 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)

            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*)  "
        strSQL &= " FROM ECtaCte e  "
        strSQL &= " WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Ref_Cat = 446 AND e.ECta_Ref_Ano = {anio} AND e.ECta_Ref_Num = {num} AND e.ECta_Doc_Cat NOT IN(446)  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        Return strSQL
    End Function
#End Region
#Region "Eventos"
    Private Sub frmDespachoDirecto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        reset()
        MostrarLista(False, True)
        Encabezado1.botonBorrar.Enabled = False
        ValidarComision()
    End Sub

    Private Sub frmDespachoDirecto_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "p.pro_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Providers"
            frm.Campos = "p.pro_codigo id, p.pro_proveedor Proveedor, p.pro_direccion Direccion"
            frm.Tabla = "Proveedores p"
            frm.FiltroText = "Enter the provider to filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Ordenamiento = "p.pro_proveedor, p.pro_status"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato
                celdaDireccionProveedor.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Client"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "cli_codigo code,cli_cliente Client, cli_direccion Direction"
        frm.Tabla = "Clientes"
        frm.Condicion = strCondicion
        frm.Limite = 20
        frm.Ordenamiento = "cli_cliente < 0"
        frm.Filtro = "cli_cliente"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaidCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
            celdaDireccionCliente.Text = frm.Dato2

        End If
    End Sub
    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim dblPorcentaje As Double
        Dim dblComision As Double
        Dim dblPrecio As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Dim Total As Double
        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 5 'Precio
                dblPrecio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                dblCantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                Total = (dblPrecio * dblCantidad).ToString(FORMATO_MONEDA)
                dgDetalle.CurrentRow.Cells("colTotal").Value = Total
                CalcularTotales()
            Case 6 'Cantidad 
                dblPrecio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                dblCantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                Total = (dblPrecio * dblCantidad).ToString(FORMATO_MONEDA)
                dgDetalle.CurrentRow.Cells("colTotal").Value = Total
                CalcularTotales()

            Case 8 'Comision Centavos
                If dgDetalle.Columns(8).Visible = True Then
                    If dgDetalle.CurrentRow.Cells("colPrecio").Value <> STR_VACIO Then
                        dblPrecio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                        dblComision = dgDetalle.CurrentRow.Cells("colComision").Value
                        Total = ((dblComision * 100) / dblPrecio)
                        dgDetalle.CurrentRow.Cells("colPorcentajeC").Value = Total.ToString(FORMATO_MONEDA)
                        CalcularTotales()
                    End If
                End If
            Case 9 ' Comision Dolares
                If dgDetalle.Columns(9).Visible = True Then
                    If dgDetalle.CurrentRow.Cells("colPrecio").Value <> STR_VACIO Then
                        dblPrecio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                        dblPorcentaje = dgDetalle.CurrentRow.Cells("colPorcentajeC").Value
                        Total = ((dblPrecio * dblPorcentaje) / 100)
                        dgDetalle.CurrentRow.Cells("colComision").Value = Total.ToString(FORMATO_MONEDA)
                        CalcularTotales()
                    End If
                End If
        End Select
    End Sub
    Private Sub botonUp_Click(sender As Object, e As EventArgs) Handles botonUp.Click
        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim conec As MySqlConnection
            Dim strSQL As String = STR_VACIO

            Dim Codigo As Integer


            strCondicion = "inv_generico = 1 AND inv_sisemp = {empresa} AND inv_status = 'Activo' AND f.cat_clave = 'FIBRA' /* AND art_DCorta LIKE '%20/1 100% COTTON CD RS%' */ "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            Frm.Titulo = "List of Product"
            Frm.FiltroText = "Enter the name Product"
            Frm.Campos = " inv_numero Inventory,  art_DCorta Description, m.cat_num NumMedida, m.cat_clave Measure, p.cat_clave Origin"
            Frm.Tabla = "Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo  LEFT JOIN Catalogos f ON f.cat_num = art_clase AND f.cat_clave ='FIBRA'  LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab"
            Frm.Condicion = strCondicion
            Frm.Ordenamiento = "inv_numero"
            Frm.Filtro = " art_DCorta"
            Frm.ShowDialog(Me)
            Try
                If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    strSQL = "SELECT inv_artcodigo"
                    strSQL &= " FROM Inventarios"
                    strSQL &= "      WHERE inv_numero = {codArt}"

                    strSQL = Replace(strSQL, "{codArt}", Frm.LLave)


                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Codigo = COM.ExecuteScalar()
                    conec.Close()

                    strFila = INT_CERO & "|" 'Linea
                    strFila &= Frm.LLave & "|" ' Codigo
                    strFila &= Frm.Dato & "|" 'Descripcion 
                    strFila &= Frm.Dato2 & "|" ' id Medida
                    strFila &= Frm.Dato3 & "|" ' Medida
                    strFila &= 0.0 & "|" ' Precio 
                    strFila &= INT_CERO & "|" ' Cantidad
                    strFila &= 0.0 & "|" ' Total
                    strFila &= 0.0 & "|" ' Comision Centavos
                    strFila &= 0.0 & "|" ' Comision Porcentaje 
                    strFila &= INT_CERO ' Extra 
                    cfun.AgregarFila(dgDetalle, strFila)
                End If
            Catch ex As Exception
                MessageBox.Show(ex.ToString)
            End Try
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            If Cambio > 1 Then
                celdaTC.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
            Else
                celdaTC.Text = Cambio
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAbajo_Click(sender As Object, e As EventArgs) Handles botonAbajo.Click
        Try
            Dim Count As Integer
            If dgDetalle.SelectedRows Is Nothing Then Exit Sub
            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgDetalle.SelectedCells(0).Value) & ", " &
               CStr(dgDetalle.SelectedCells(1).Value) & " " &
                CStr(dgDetalle.SelectedCells(2).Value) & " " &
                   CStr(dgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgDetalle.SelectedCells(10).Value = 0 Or dgDetalle.SelectedCells(10).Value = 1 Then
                            dgDetalle.SelectedCells(10).Value = 2
                            If dgDetalle.SelectedCells(10).Value = 2 Then
                                dgDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can not delete the last row")
                Exit Sub
            End If
            dgDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If ComprobarFilaDetalle() Then
                    If GuardarDocumento() = True Then
                        MsgBox("save successful")
                        MostrarLista(True)
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            reset()
            ValidarComision()
            Seleccionar(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim IntNumDocs As Integer
        If LogBorrar = True Then
            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()
            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    EliminarEncabezado()
                    EliminarDetalle()
                    BorrarEctate(celdaNumero.Text, celdaAño.Text)
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, celdaidProveedor.Text, 446, celdaAño.Text, celdaNumero.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        Else
            MsgBox("You don't have permission to delete ")
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(446, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 446)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub frmDespachoDirecto_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTC.Text > 1 Then
            celdaTC.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub



#End Region
End Class