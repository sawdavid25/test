﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNotasDeCredito
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNotasDeCredito))
        Me.panelNotasCredito = New System.Windows.Forms.Panel()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.gbFelServi = New System.Windows.Forms.GroupBox()
        Me.celdaNumeroFelServi = New System.Windows.Forms.TextBox()
        Me.etiquetaNumeroFel = New System.Windows.Forms.Label()
        Me.celdaSeriFelServi = New System.Windows.Forms.TextBox()
        Me.etiquetaSerieFel = New System.Windows.Forms.Label()
        Me.celdaSub = New System.Windows.Forms.TextBox()
        Me.etiquetaSubTotal = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaExepcion = New System.Windows.Forms.TextBox()
        Me.etiquetaExepcion = New System.Windows.Forms.Label()
        Me.celdaImpuesto = New System.Windows.Forms.TextBox()
        Me.etiquetaImpuesto = New System.Windows.Forms.Label()
        Me.celdaTotalLetras = New System.Windows.Forms.TextBox()
        Me.celdaSubTotal = New System.Windows.Forms.TextBox()
        Me.CeldaTotalEnLetras = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.panelImpuestos = New System.Windows.Forms.Panel()
        Me.dgImpuestos = New System.Windows.Forms.DataGridView()
        Me.colLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCanti = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTag = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgDetalleNC = New System.Windows.Forms.DataGridView()
        Me.colCatalogoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUMedidaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionNCDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLibrasDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpuestoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExcepcionDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalNCDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescription = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnitario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExepcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.gbInformación = New System.Windows.Forms.GroupBox()
        Me.etiquetaGiro = New System.Windows.Forms.Label()
        Me.celdaGiro = New System.Windows.Forms.TextBox()
        Me.rbOtros = New System.Windows.Forms.RadioButton()
        Me.rbDevoluciones = New System.Windows.Forms.RadioButton()
        Me.rbDifPrecio = New System.Windows.Forms.RadioButton()
        Me.celdaNotasObservaciones = New System.Windows.Forms.TextBox()
        Me.etiquetraNotasObservaciones = New System.Windows.Forms.Label()
        Me.celdaDeclaracion = New System.Windows.Forms.TextBox()
        Me.EtiquetaDeclaracion = New System.Windows.Forms.Label()
        Me.celdaTasaFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaTasaFactura = New System.Windows.Forms.Label()
        Me.gbFacturas = New System.Windows.Forms.GroupBox()
        Me.checkFacturaFiscal = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonAgregarFactura = New System.Windows.Forms.Button()
        Me.dgFacturacion = New System.Windows.Forms.DataGridView()
        Me.gbDatosDocumento = New System.Windows.Forms.GroupBox()
        Me.celdaCatalogoCAI = New System.Windows.Forms.TextBox()
        Me.celdaResolucion = New System.Windows.Forms.TextBox()
        Me.celdaSerieGF = New System.Windows.Forms.TextBox()
        Me.celdaAutFact = New System.Windows.Forms.TextBox()
        Me.celdaUIDDFact = New System.Windows.Forms.TextBox()
        Me.celdaSerieFel = New System.Windows.Forms.TextBox()
        Me.celdaFechaHoraCertificacion = New System.Windows.Forms.TextBox()
        Me.celdaFechaEmisionDocumento = New System.Windows.Forms.TextBox()
        Me.celdaUUID = New System.Windows.Forms.TextBox()
        Me.celdaRangoFechaAutorizado = New System.Windows.Forms.TextBox()
        Me.celdaTemporal = New System.Windows.Forms.TextBox()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.celdaSerie1 = New System.Windows.Forms.TextBox()
        Me.celdaCAI = New System.Windows.Forms.TextBox()
        Me.etiquetaCAI = New System.Windows.Forms.Label()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.dtpFech = New System.Windows.Forms.DateTimePicker()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.botonClientes = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizacionF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.botonPrevio = New System.Windows.Forms.Button()
        Me.etiquetaAutorizacion = New System.Windows.Forms.Label()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cloDr1Dbl = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.saldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelNotasCredito.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.gbFelServi.SuspendLayout()
        Me.panelImpuestos.SuspendLayout()
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgDetalleNC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.gbInformación.SuspendLayout()
        Me.gbFacturas.SuspendLayout()
        CType(Me.dgFacturacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDatosDocumento.SuspendLayout()
        Me.panelLista.SuspendLayout()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelNotasCredito
        '
        Me.panelNotasCredito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelNotasCredito.Controls.Add(Me.panelDocumento)
        Me.panelNotasCredito.Location = New System.Drawing.Point(0, 115)
        Me.panelNotasCredito.Name = "panelNotasCredito"
        Me.panelNotasCredito.Size = New System.Drawing.Size(820, 835)
        Me.panelNotasCredito.TabIndex = 0
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.panelTotales)
        Me.panelDocumento.Controls.Add(Me.panelImpuestos)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.gbInformación)
        Me.panelDocumento.Controls.Add(Me.gbFacturas)
        Me.panelDocumento.Controls.Add(Me.gbDatosDocumento)
        Me.panelDocumento.Location = New System.Drawing.Point(11, 18)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(723, 795)
        Me.panelDocumento.TabIndex = 5
        '
        'panelTotales
        '
        Me.panelTotales.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelTotales.Controls.Add(Me.gbFelServi)
        Me.panelTotales.Controls.Add(Me.celdaSub)
        Me.panelTotales.Controls.Add(Me.etiquetaSubTotal)
        Me.panelTotales.Controls.Add(Me.Label2)
        Me.panelTotales.Controls.Add(Me.celdaExepcion)
        Me.panelTotales.Controls.Add(Me.etiquetaExepcion)
        Me.panelTotales.Controls.Add(Me.celdaImpuesto)
        Me.panelTotales.Controls.Add(Me.etiquetaImpuesto)
        Me.panelTotales.Controls.Add(Me.celdaTotalLetras)
        Me.panelTotales.Controls.Add(Me.celdaSubTotal)
        Me.panelTotales.Controls.Add(Me.CeldaTotalEnLetras)
        Me.panelTotales.Controls.Add(Me.etiquetaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Location = New System.Drawing.Point(4, 445)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(714, 127)
        Me.panelTotales.TabIndex = 12
        '
        'gbFelServi
        '
        Me.gbFelServi.Controls.Add(Me.celdaNumeroFelServi)
        Me.gbFelServi.Controls.Add(Me.etiquetaNumeroFel)
        Me.gbFelServi.Controls.Add(Me.celdaSeriFelServi)
        Me.gbFelServi.Controls.Add(Me.etiquetaSerieFel)
        Me.gbFelServi.Location = New System.Drawing.Point(7, 65)
        Me.gbFelServi.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbFelServi.Name = "gbFelServi"
        Me.gbFelServi.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbFelServi.Size = New System.Drawing.Size(579, 49)
        Me.gbFelServi.TabIndex = 21
        Me.gbFelServi.TabStop = False
        Me.gbFelServi.Text = "FEL Data"
        '
        'celdaNumeroFelServi
        '
        Me.celdaNumeroFelServi.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNumeroFelServi.Location = New System.Drawing.Point(298, 18)
        Me.celdaNumeroFelServi.Name = "celdaNumeroFelServi"
        Me.celdaNumeroFelServi.Size = New System.Drawing.Size(210, 20)
        Me.celdaNumeroFelServi.TabIndex = 24
        Me.celdaNumeroFelServi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaNumeroFel
        '
        Me.etiquetaNumeroFel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaNumeroFel.AutoSize = True
        Me.etiquetaNumeroFel.Location = New System.Drawing.Point(254, 22)
        Me.etiquetaNumeroFel.Name = "etiquetaNumeroFel"
        Me.etiquetaNumeroFel.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumeroFel.TabIndex = 23
        Me.etiquetaNumeroFel.Text = "Number"
        '
        'celdaSeriFelServi
        '
        Me.celdaSeriFelServi.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSeriFelServi.Location = New System.Drawing.Point(34, 18)
        Me.celdaSeriFelServi.Name = "celdaSeriFelServi"
        Me.celdaSeriFelServi.Size = New System.Drawing.Size(210, 20)
        Me.celdaSeriFelServi.TabIndex = 22
        Me.celdaSeriFelServi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSerieFel
        '
        Me.etiquetaSerieFel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaSerieFel.AutoSize = True
        Me.etiquetaSerieFel.Location = New System.Drawing.Point(4, 22)
        Me.etiquetaSerieFel.Name = "etiquetaSerieFel"
        Me.etiquetaSerieFel.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaSerieFel.TabIndex = 22
        Me.etiquetaSerieFel.Text = "Serie"
        '
        'celdaSub
        '
        Me.celdaSub.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSub.Location = New System.Drawing.Point(604, 68)
        Me.celdaSub.Name = "celdaSub"
        Me.celdaSub.Size = New System.Drawing.Size(97, 20)
        Me.celdaSub.TabIndex = 20
        Me.celdaSub.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSubTotal
        '
        Me.etiquetaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaSubTotal.AutoSize = True
        Me.etiquetaSubTotal.Location = New System.Drawing.Point(625, 51)
        Me.etiquetaSubTotal.Name = "etiquetaSubTotal"
        Me.etiquetaSubTotal.Size = New System.Drawing.Size(50, 13)
        Me.etiquetaSubTotal.TabIndex = 19
        Me.etiquetaSubTotal.Text = "SubTotal"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(625, 4)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 18
        Me.Label2.Text = "Total"
        '
        'celdaExepcion
        '
        Me.celdaExepcion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaExepcion.Location = New System.Drawing.Point(510, 68)
        Me.celdaExepcion.Name = "celdaExepcion"
        Me.celdaExepcion.Size = New System.Drawing.Size(80, 20)
        Me.celdaExepcion.TabIndex = 17
        Me.celdaExepcion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaExepcion.Visible = False
        '
        'etiquetaExepcion
        '
        Me.etiquetaExepcion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaExepcion.AutoSize = True
        Me.etiquetaExepcion.Location = New System.Drawing.Point(424, 72)
        Me.etiquetaExepcion.Name = "etiquetaExepcion"
        Me.etiquetaExepcion.Size = New System.Drawing.Size(71, 13)
        Me.etiquetaExepcion.TabIndex = 16
        Me.etiquetaExepcion.Text = "Exempt Sales"
        Me.etiquetaExepcion.Visible = False
        '
        'celdaImpuesto
        '
        Me.celdaImpuesto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaImpuesto.Location = New System.Drawing.Point(510, 44)
        Me.celdaImpuesto.Name = "celdaImpuesto"
        Me.celdaImpuesto.Size = New System.Drawing.Size(80, 20)
        Me.celdaImpuesto.TabIndex = 15
        Me.celdaImpuesto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaImpuesto.Visible = False
        '
        'etiquetaImpuesto
        '
        Me.etiquetaImpuesto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaImpuesto.AutoSize = True
        Me.etiquetaImpuesto.Location = New System.Drawing.Point(448, 46)
        Me.etiquetaImpuesto.Name = "etiquetaImpuesto"
        Me.etiquetaImpuesto.Size = New System.Drawing.Size(36, 13)
        Me.etiquetaImpuesto.TabIndex = 14
        Me.etiquetaImpuesto.Text = "Taxes"
        Me.etiquetaImpuesto.Visible = False
        '
        'celdaTotalLetras
        '
        Me.celdaTotalLetras.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotalLetras.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaTotalLetras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalLetras.Location = New System.Drawing.Point(9, 3)
        Me.celdaTotalLetras.Name = "celdaTotalLetras"
        Me.celdaTotalLetras.Size = New System.Drawing.Size(112, 13)
        Me.celdaTotalLetras.TabIndex = 13
        Me.celdaTotalLetras.Text = "ToTal En Letras:"
        Me.celdaTotalLetras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSubTotal
        '
        Me.celdaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSubTotal.Location = New System.Drawing.Point(510, 21)
        Me.celdaSubTotal.Name = "celdaSubTotal"
        Me.celdaSubTotal.Size = New System.Drawing.Size(80, 20)
        Me.celdaSubTotal.TabIndex = 5
        Me.celdaSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CeldaTotalEnLetras
        '
        Me.CeldaTotalEnLetras.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaTotalEnLetras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotalEnLetras.Location = New System.Drawing.Point(9, 16)
        Me.CeldaTotalEnLetras.Multiline = True
        Me.CeldaTotalEnLetras.Name = "CeldaTotalEnLetras"
        Me.CeldaTotalEnLetras.Size = New System.Drawing.Size(578, 46)
        Me.CeldaTotalEnLetras.TabIndex = 12
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(522, 3)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaTotal.TabIndex = 4
        Me.etiquetaTotal.Text = "Cantidad"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(604, 21)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(97, 20)
        Me.celdaTotal.TabIndex = 6
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'panelImpuestos
        '
        Me.panelImpuestos.Controls.Add(Me.dgImpuestos)
        Me.panelImpuestos.Location = New System.Drawing.Point(308, 544)
        Me.panelImpuestos.Name = "panelImpuestos"
        Me.panelImpuestos.Size = New System.Drawing.Size(356, 85)
        Me.panelImpuestos.TabIndex = 1
        '
        'dgImpuestos
        '
        Me.dgImpuestos.AllowUserToAddRows = False
        Me.dgImpuestos.AllowUserToDeleteRows = False
        Me.dgImpuestos.AllowUserToOrderColumns = True
        Me.dgImpuestos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgImpuestos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgImpuestos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgImpuestos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLin, Me.colID, Me.colCode, Me.colTipo, Me.colDescripcion, Me.colBase, Me.colCanti, Me.colFactor, Me.colMonto, Me.colTag, Me.colOrigen})
        Me.dgImpuestos.Location = New System.Drawing.Point(0, 3)
        Me.dgImpuestos.Name = "dgImpuestos"
        Me.dgImpuestos.Size = New System.Drawing.Size(356, 97)
        Me.dgImpuestos.TabIndex = 0
        Me.dgImpuestos.Visible = False
        '
        'colLin
        '
        Me.colLin.HeaderText = "Line"
        Me.colLin.Name = "colLin"
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        '
        'colCode
        '
        Me.colCode.HeaderText = "Codigo"
        Me.colCode.Name = "colCode"
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Descripcion"
        Me.colDescripcion.Name = "colDescripcion"
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.Name = "colBase"
        '
        'colCanti
        '
        Me.colCanti.HeaderText = "Cantidad"
        Me.colCanti.Name = "colCanti"
        '
        'colFactor
        '
        Me.colFactor.HeaderText = "Factor"
        Me.colFactor.Name = "colFactor"
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Monto"
        Me.colMonto.Name = "colMonto"
        '
        'colTag
        '
        Me.colTag.HeaderText = "Tag"
        Me.colTag.Name = "colTag"
        '
        'colOrigen
        '
        Me.colOrigen.HeaderText = "Origen"
        Me.colOrigen.Name = "colOrigen"
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel2)
        Me.panelDetalle.Location = New System.Drawing.Point(7, 293)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(711, 147)
        Me.panelDetalle.TabIndex = 8
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.dgDetalleNC)
        Me.Panel2.Controls.Add(Me.dgDetalle)
        Me.Panel2.Controls.Add(Me.panelBotones)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(711, 147)
        Me.Panel2.TabIndex = 2
        '
        'dgDetalleNC
        '
        Me.dgDetalleNC.AllowUserToAddRows = False
        Me.dgDetalleNC.AllowUserToDeleteRows = False
        Me.dgDetalleNC.AllowUserToOrderColumns = True
        Me.dgDetalleNC.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalleNC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalleNC.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogoDet, Me.colAnioDet, Me.colNumeroDet, Me.colLineaDet, Me.colCantidadDet, Me.colUMedidaDet, Me.colDescripcionDet, Me.colReferenciaDet, Me.colPrecioDet, Me.colTotalDet, Me.colDescripcionNCDet, Me.colLibrasDet, Me.colImpuestoDet, Me.colExcepcionDet, Me.colTotalNCDet, Me.colLinea, Me.colExtraDet})
        Me.dgDetalleNC.Location = New System.Drawing.Point(266, 14)
        Me.dgDetalleNC.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDetalleNC.Name = "dgDetalleNC"
        Me.dgDetalleNC.RowTemplate.Height = 24
        Me.dgDetalleNC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalleNC.Size = New System.Drawing.Size(274, 102)
        Me.dgDetalleNC.TabIndex = 1
        '
        'colCatalogoDet
        '
        Me.colCatalogoDet.HeaderText = "Catalogo"
        Me.colCatalogoDet.Name = "colCatalogoDet"
        Me.colCatalogoDet.ReadOnly = True
        Me.colCatalogoDet.Visible = False
        '
        'colAnioDet
        '
        Me.colAnioDet.HeaderText = "Anio"
        Me.colAnioDet.Name = "colAnioDet"
        Me.colAnioDet.ReadOnly = True
        Me.colAnioDet.Visible = False
        '
        'colNumeroDet
        '
        Me.colNumeroDet.HeaderText = "Number"
        Me.colNumeroDet.Name = "colNumeroDet"
        Me.colNumeroDet.ReadOnly = True
        Me.colNumeroDet.Visible = False
        '
        'colLineaDet
        '
        Me.colLineaDet.HeaderText = "Invoice Line"
        Me.colLineaDet.Name = "colLineaDet"
        Me.colLineaDet.ReadOnly = True
        '
        'colCantidadDet
        '
        Me.colCantidadDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidadDet.HeaderText = "Quantity"
        Me.colCantidadDet.Name = "colCantidadDet"
        Me.colCantidadDet.ReadOnly = True
        Me.colCantidadDet.Width = 71
        '
        'colUMedidaDet
        '
        Me.colUMedidaDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colUMedidaDet.HeaderText = "Measure"
        Me.colUMedidaDet.Name = "colUMedidaDet"
        Me.colUMedidaDet.ReadOnly = True
        Me.colUMedidaDet.Width = 73
        '
        'colDescripcionDet
        '
        Me.colDescripcionDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcionDet.HeaderText = "Product"
        Me.colDescripcionDet.Name = "colDescripcionDet"
        Me.colDescripcionDet.ReadOnly = True
        Me.colDescripcionDet.Width = 69
        '
        'colReferenciaDet
        '
        Me.colReferenciaDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReferenciaDet.HeaderText = "Reference"
        Me.colReferenciaDet.Name = "colReferenciaDet"
        Me.colReferenciaDet.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colReferenciaDet.Width = 82
        '
        'colPrecioDet
        '
        Me.colPrecioDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecioDet.HeaderText = "Price $"
        Me.colPrecioDet.Name = "colPrecioDet"
        Me.colPrecioDet.ReadOnly = True
        Me.colPrecioDet.Width = 65
        '
        'colTotalDet
        '
        Me.colTotalDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotalDet.HeaderText = "Total $"
        Me.colTotalDet.Name = "colTotalDet"
        Me.colTotalDet.ReadOnly = True
        Me.colTotalDet.Width = 65
        '
        'colDescripcionNCDet
        '
        Me.colDescripcionNCDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcionNCDet.HeaderText = "Description"
        Me.colDescripcionNCDet.Name = "colDescripcionNCDet"
        Me.colDescripcionNCDet.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.colDescripcionNCDet.Width = 85
        '
        'colLibrasDet
        '
        Me.colLibrasDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLibrasDet.HeaderText = "Return Pounds"
        Me.colLibrasDet.Name = "colLibrasDet"
        Me.colLibrasDet.Width = 95
        '
        'colImpuestoDet
        '
        Me.colImpuestoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colImpuestoDet.HeaderText = "Taxes"
        Me.colImpuestoDet.Name = "colImpuestoDet"
        Me.colImpuestoDet.Width = 61
        '
        'colExcepcionDet
        '
        Me.colExcepcionDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colExcepcionDet.HeaderText = "Exempt Sales"
        Me.colExcepcionDet.Name = "colExcepcionDet"
        Me.colExcepcionDet.Width = 88
        '
        'colTotalNCDet
        '
        Me.colTotalNCDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotalNCDet.HeaderText = "Total NC"
        Me.colTotalNCDet.Name = "colTotalNCDet"
        Me.colTotalNCDet.Width = 69
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 58
        '
        'colExtraDet
        '
        Me.colExtraDet.HeaderText = "Extra"
        Me.colExtraDet.Name = "colExtraDet"
        Me.colExtraDet.ReadOnly = True
        Me.colExtraDet.Visible = False
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCantidad, Me.colDescription, Me.colUnitario, Me.colImpuesto, Me.colExepcion, Me.colTotal})
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(209, 127)
        Me.dgDetalle.TabIndex = 0
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colDescription
        '
        Me.colDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescription.HeaderText = "Description"
        Me.colDescription.Name = "colDescription"
        Me.colDescription.Width = 85
        '
        'colUnitario
        '
        Me.colUnitario.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colUnitario.HeaderText = "Price $"
        Me.colUnitario.Name = "colUnitario"
        Me.colUnitario.Width = 65
        '
        'colImpuesto
        '
        Me.colImpuesto.HeaderText = "Taxes"
        Me.colImpuesto.Name = "colImpuesto"
        Me.colImpuesto.ReadOnly = True
        Me.colImpuesto.Visible = False
        '
        'colExepcion
        '
        Me.colExepcion.HeaderText = "Exempt Sales"
        Me.colExepcion.Name = "colExepcion"
        Me.colExepcion.ReadOnly = True
        Me.colExepcion.Visible = False
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total$"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 62
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.Button2)
        Me.panelBotones.Controls.Add(Me.Button3)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(667, 0)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(44, 147)
        Me.panelBotones.TabIndex = 2
        '
        'Button2
        '
        Me.Button2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button2.Image = Global.KARIMs_SGI.My.Resources.Resources.row_delete
        Me.Button2.Location = New System.Drawing.Point(5, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(31, 29)
        Me.Button2.TabIndex = 13
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button3.BackColor = System.Drawing.SystemColors.Control
        Me.Button3.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.Button3.Location = New System.Drawing.Point(5, 14)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(31, 28)
        Me.Button3.TabIndex = 12
        Me.Button3.UseVisualStyleBackColor = False
        '
        'gbInformación
        '
        Me.gbInformación.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbInformación.Controls.Add(Me.etiquetaGiro)
        Me.gbInformación.Controls.Add(Me.celdaGiro)
        Me.gbInformación.Controls.Add(Me.rbOtros)
        Me.gbInformación.Controls.Add(Me.rbDevoluciones)
        Me.gbInformación.Controls.Add(Me.rbDifPrecio)
        Me.gbInformación.Controls.Add(Me.celdaNotasObservaciones)
        Me.gbInformación.Controls.Add(Me.etiquetraNotasObservaciones)
        Me.gbInformación.Controls.Add(Me.celdaDeclaracion)
        Me.gbInformación.Controls.Add(Me.EtiquetaDeclaracion)
        Me.gbInformación.Controls.Add(Me.celdaTasaFactura)
        Me.gbInformación.Controls.Add(Me.etiquetaTasaFactura)
        Me.gbInformación.Location = New System.Drawing.Point(433, 128)
        Me.gbInformación.Name = "gbInformación"
        Me.gbInformación.Size = New System.Drawing.Size(284, 166)
        Me.gbInformación.TabIndex = 3
        Me.gbInformación.TabStop = False
        Me.gbInformación.Text = "Additional Information"
        '
        'etiquetaGiro
        '
        Me.etiquetaGiro.AutoSize = True
        Me.etiquetaGiro.Location = New System.Drawing.Point(182, 83)
        Me.etiquetaGiro.Name = "etiquetaGiro"
        Me.etiquetaGiro.Size = New System.Drawing.Size(70, 13)
        Me.etiquetaGiro.TabIndex = 75
        Me.etiquetaGiro.Text = "Business turn"
        Me.etiquetaGiro.Visible = False
        '
        'celdaGiro
        '
        Me.celdaGiro.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaGiro.Location = New System.Drawing.Point(257, 79)
        Me.celdaGiro.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaGiro.Name = "celdaGiro"
        Me.celdaGiro.Size = New System.Drawing.Size(15, 20)
        Me.celdaGiro.TabIndex = 76
        Me.celdaGiro.Visible = False
        '
        'rbOtros
        '
        Me.rbOtros.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbOtros.AutoSize = True
        Me.rbOtros.Location = New System.Drawing.Point(284, 60)
        Me.rbOtros.Name = "rbOtros"
        Me.rbOtros.Size = New System.Drawing.Size(56, 17)
        Me.rbOtros.TabIndex = 16
        Me.rbOtros.TabStop = True
        Me.rbOtros.Text = "Others"
        Me.rbOtros.UseVisualStyleBackColor = True
        '
        'rbDevoluciones
        '
        Me.rbDevoluciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbDevoluciones.AutoSize = True
        Me.rbDevoluciones.Location = New System.Drawing.Point(284, 37)
        Me.rbDevoluciones.Name = "rbDevoluciones"
        Me.rbDevoluciones.Size = New System.Drawing.Size(57, 17)
        Me.rbDevoluciones.TabIndex = 15
        Me.rbDevoluciones.TabStop = True
        Me.rbDevoluciones.Text = "Return"
        Me.rbDevoluciones.UseVisualStyleBackColor = True
        '
        'rbDifPrecio
        '
        Me.rbDifPrecio.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbDifPrecio.AutoSize = True
        Me.rbDifPrecio.Location = New System.Drawing.Point(284, 14)
        Me.rbDifPrecio.Name = "rbDifPrecio"
        Me.rbDifPrecio.Size = New System.Drawing.Size(101, 17)
        Me.rbDifPrecio.TabIndex = 14
        Me.rbDifPrecio.TabStop = True
        Me.rbDifPrecio.Text = "Price Difference"
        Me.rbDifPrecio.UseVisualStyleBackColor = True
        '
        'celdaNotasObservaciones
        '
        Me.celdaNotasObservaciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNotasObservaciones.Location = New System.Drawing.Point(9, 100)
        Me.celdaNotasObservaciones.Multiline = True
        Me.celdaNotasObservaciones.Name = "celdaNotasObservaciones"
        Me.celdaNotasObservaciones.Size = New System.Drawing.Size(269, 60)
        Me.celdaNotasObservaciones.TabIndex = 13
        '
        'etiquetraNotasObservaciones
        '
        Me.etiquetraNotasObservaciones.AutoSize = True
        Me.etiquetraNotasObservaciones.Location = New System.Drawing.Point(5, 84)
        Me.etiquetraNotasObservaciones.Name = "etiquetraNotasObservaciones"
        Me.etiquetraNotasObservaciones.Size = New System.Drawing.Size(124, 13)
        Me.etiquetraNotasObservaciones.TabIndex = 12
        Me.etiquetraNotasObservaciones.Text = "Notes  and Observations"
        '
        'celdaDeclaracion
        '
        Me.celdaDeclaracion.BackColor = System.Drawing.SystemColors.Window
        Me.celdaDeclaracion.Enabled = False
        Me.celdaDeclaracion.Location = New System.Drawing.Point(121, 50)
        Me.celdaDeclaracion.Name = "celdaDeclaracion"
        Me.celdaDeclaracion.Size = New System.Drawing.Size(97, 20)
        Me.celdaDeclaracion.TabIndex = 3
        Me.celdaDeclaracion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaDeclaracion
        '
        Me.EtiquetaDeclaracion.AutoSize = True
        Me.EtiquetaDeclaracion.Location = New System.Drawing.Point(5, 54)
        Me.EtiquetaDeclaracion.Name = "EtiquetaDeclaracion"
        Me.EtiquetaDeclaracion.Size = New System.Drawing.Size(61, 13)
        Me.EtiquetaDeclaracion.TabIndex = 2
        Me.EtiquetaDeclaracion.Text = "Declaration"
        '
        'celdaTasaFactura
        '
        Me.celdaTasaFactura.BackColor = System.Drawing.SystemColors.Window
        Me.celdaTasaFactura.Enabled = False
        Me.celdaTasaFactura.Location = New System.Drawing.Point(121, 21)
        Me.celdaTasaFactura.Name = "celdaTasaFactura"
        Me.celdaTasaFactura.Size = New System.Drawing.Size(97, 20)
        Me.celdaTasaFactura.TabIndex = 1
        Me.celdaTasaFactura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaTasaFactura
        '
        Me.etiquetaTasaFactura.AutoSize = True
        Me.etiquetaTasaFactura.Location = New System.Drawing.Point(6, 24)
        Me.etiquetaTasaFactura.Name = "etiquetaTasaFactura"
        Me.etiquetaTasaFactura.Size = New System.Drawing.Size(71, 13)
        Me.etiquetaTasaFactura.TabIndex = 0
        Me.etiquetaTasaFactura.Text = "Rate(Invoice)"
        '
        'gbFacturas
        '
        Me.gbFacturas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFacturas.Controls.Add(Me.checkFacturaFiscal)
        Me.gbFacturas.Controls.Add(Me.Button1)
        Me.gbFacturas.Controls.Add(Me.botonAgregarFactura)
        Me.gbFacturas.Controls.Add(Me.dgFacturacion)
        Me.gbFacturas.Location = New System.Drawing.Point(436, 8)
        Me.gbFacturas.Name = "gbFacturas"
        Me.gbFacturas.Size = New System.Drawing.Size(281, 119)
        Me.gbFacturas.TabIndex = 2
        Me.gbFacturas.TabStop = False
        Me.gbFacturas.Text = "Invoice"
        '
        'checkFacturaFiscal
        '
        Me.checkFacturaFiscal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkFacturaFiscal.AutoSize = True
        Me.checkFacturaFiscal.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.checkFacturaFiscal.Location = New System.Drawing.Point(232, 24)
        Me.checkFacturaFiscal.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkFacturaFiscal.Name = "checkFacturaFiscal"
        Me.checkFacturaFiscal.Size = New System.Drawing.Size(46, 17)
        Me.checkFacturaFiscal.TabIndex = 12
        Me.checkFacturaFiscal.Text = "CCF"
        Me.checkFacturaFiscal.UseVisualStyleBackColor = True
        Me.checkFacturaFiscal.Visible = False
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.row_delete
        Me.Button1.Location = New System.Drawing.Point(238, 73)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(31, 29)
        Me.Button1.TabIndex = 11
        Me.Button1.UseVisualStyleBackColor = True
        '
        'botonAgregarFactura
        '
        Me.botonAgregarFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregarFactura.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregarFactura.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarFactura.Location = New System.Drawing.Point(238, 41)
        Me.botonAgregarFactura.Name = "botonAgregarFactura"
        Me.botonAgregarFactura.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregarFactura.TabIndex = 10
        Me.botonAgregarFactura.UseVisualStyleBackColor = False
        '
        'dgFacturacion
        '
        Me.dgFacturacion.AllowUserToAddRows = False
        Me.dgFacturacion.AllowUserToDeleteRows = False
        Me.dgFacturacion.AllowUserToOrderColumns = True
        Me.dgFacturacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFacturacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgFacturacion.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgFacturacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFacturacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFacturacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colNumero, Me.colFecha, Me.colUsuario, Me.colReference, Me.cloDr1Dbl, Me.saldo})
        Me.dgFacturacion.Location = New System.Drawing.Point(6, 25)
        Me.dgFacturacion.MultiSelect = False
        Me.dgFacturacion.Name = "dgFacturacion"
        Me.dgFacturacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFacturacion.Size = New System.Drawing.Size(226, 88)
        Me.dgFacturacion.TabIndex = 0
        '
        'gbDatosDocumento
        '
        Me.gbDatosDocumento.Controls.Add(Me.celdaCatalogoCAI)
        Me.gbDatosDocumento.Controls.Add(Me.celdaResolucion)
        Me.gbDatosDocumento.Controls.Add(Me.celdaSerieGF)
        Me.gbDatosDocumento.Controls.Add(Me.celdaAutFact)
        Me.gbDatosDocumento.Controls.Add(Me.celdaUIDDFact)
        Me.gbDatosDocumento.Controls.Add(Me.celdaSerieFel)
        Me.gbDatosDocumento.Controls.Add(Me.celdaFechaHoraCertificacion)
        Me.gbDatosDocumento.Controls.Add(Me.celdaFechaEmisionDocumento)
        Me.gbDatosDocumento.Controls.Add(Me.celdaUUID)
        Me.gbDatosDocumento.Controls.Add(Me.celdaRangoFechaAutorizado)
        Me.gbDatosDocumento.Controls.Add(Me.celdaTemporal)
        Me.gbDatosDocumento.Controls.Add(Me.botonSerie)
        Me.gbDatosDocumento.Controls.Add(Me.celdaSerie1)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCAI)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaCAI)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaNIT)
        Me.gbDatosDocumento.Controls.Add(Me.celdaNIT)
        Me.gbDatosDocumento.Controls.Add(Me.checkActivar)
        Me.gbDatosDocumento.Controls.Add(Me.Label1)
        Me.gbDatosDocumento.Controls.Add(Me.celdaTelefono)
        Me.gbDatosDocumento.Controls.Add(Me.checkRevisado)
        Me.gbDatosDocumento.Controls.Add(Me.botonPolizaC)
        Me.gbDatosDocumento.Controls.Add(Me.celdaEmpresa)
        Me.gbDatosDocumento.Controls.Add(Me.dtpFech)
        Me.gbDatosDocumento.Controls.Add(Me.celdaUsuario)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCatalogo)
        Me.gbDatosDocumento.Controls.Add(Me.celdaIDMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaIDCliente)
        Me.gbDatosDocumento.Controls.Add(Me.celdaTasa)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaTasa)
        Me.gbDatosDocumento.Controls.Add(Me.botonMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDireccion)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaDireccion)
        Me.gbDatosDocumento.Controls.Add(Me.botonClientes)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCliente)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaCliente)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaFecha)
        Me.gbDatosDocumento.Controls.Add(Me.celdaNumero)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaNumero)
        Me.gbDatosDocumento.Controls.Add(Me.celdaAño)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaAño)
        Me.gbDatosDocumento.Location = New System.Drawing.Point(3, 3)
        Me.gbDatosDocumento.Name = "gbDatosDocumento"
        Me.gbDatosDocumento.Size = New System.Drawing.Size(424, 291)
        Me.gbDatosDocumento.TabIndex = 1
        Me.gbDatosDocumento.TabStop = False
        Me.gbDatosDocumento.Text = "Document Data"
        '
        'celdaCatalogoCAI
        '
        Me.celdaCatalogoCAI.Location = New System.Drawing.Point(323, 245)
        Me.celdaCatalogoCAI.Name = "celdaCatalogoCAI"
        Me.celdaCatalogoCAI.Size = New System.Drawing.Size(78, 20)
        Me.celdaCatalogoCAI.TabIndex = 74
        Me.celdaCatalogoCAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaCatalogoCAI.Visible = False
        '
        'celdaResolucion
        '
        Me.celdaResolucion.Location = New System.Drawing.Point(219, 11)
        Me.celdaResolucion.Name = "celdaResolucion"
        Me.celdaResolucion.Size = New System.Drawing.Size(32, 20)
        Me.celdaResolucion.TabIndex = 73
        Me.celdaResolucion.Visible = False
        '
        'celdaSerieGF
        '
        Me.celdaSerieGF.Location = New System.Drawing.Point(182, 70)
        Me.celdaSerieGF.Name = "celdaSerieGF"
        Me.celdaSerieGF.Size = New System.Drawing.Size(32, 20)
        Me.celdaSerieGF.TabIndex = 72
        Me.celdaSerieGF.Visible = False
        '
        'celdaAutFact
        '
        Me.celdaAutFact.Location = New System.Drawing.Point(182, 46)
        Me.celdaAutFact.Name = "celdaAutFact"
        Me.celdaAutFact.Size = New System.Drawing.Size(32, 20)
        Me.celdaAutFact.TabIndex = 71
        Me.celdaAutFact.Visible = False
        '
        'celdaUIDDFact
        '
        Me.celdaUIDDFact.Location = New System.Drawing.Point(182, 19)
        Me.celdaUIDDFact.Name = "celdaUIDDFact"
        Me.celdaUIDDFact.Size = New System.Drawing.Size(32, 20)
        Me.celdaUIDDFact.TabIndex = 70
        Me.celdaUIDDFact.Visible = False
        '
        'celdaSerieFel
        '
        Me.celdaSerieFel.Location = New System.Drawing.Point(128, 11)
        Me.celdaSerieFel.Name = "celdaSerieFel"
        Me.celdaSerieFel.Size = New System.Drawing.Size(11, 20)
        Me.celdaSerieFel.TabIndex = 69
        Me.celdaSerieFel.Visible = False
        '
        'celdaFechaHoraCertificacion
        '
        Me.celdaFechaHoraCertificacion.Location = New System.Drawing.Point(112, 11)
        Me.celdaFechaHoraCertificacion.Name = "celdaFechaHoraCertificacion"
        Me.celdaFechaHoraCertificacion.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaHoraCertificacion.TabIndex = 68
        Me.celdaFechaHoraCertificacion.Visible = False
        '
        'celdaFechaEmisionDocumento
        '
        Me.celdaFechaEmisionDocumento.Location = New System.Drawing.Point(98, 11)
        Me.celdaFechaEmisionDocumento.Name = "celdaFechaEmisionDocumento"
        Me.celdaFechaEmisionDocumento.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaEmisionDocumento.TabIndex = 67
        Me.celdaFechaEmisionDocumento.Visible = False
        '
        'celdaUUID
        '
        Me.celdaUUID.Location = New System.Drawing.Point(143, 11)
        Me.celdaUUID.Name = "celdaUUID"
        Me.celdaUUID.Size = New System.Drawing.Size(32, 20)
        Me.celdaUUID.TabIndex = 66
        Me.celdaUUID.Visible = False
        '
        'celdaRangoFechaAutorizado
        '
        Me.celdaRangoFechaAutorizado.Location = New System.Drawing.Point(302, 195)
        Me.celdaRangoFechaAutorizado.Name = "celdaRangoFechaAutorizado"
        Me.celdaRangoFechaAutorizado.Size = New System.Drawing.Size(78, 20)
        Me.celdaRangoFechaAutorizado.TabIndex = 48
        Me.celdaRangoFechaAutorizado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaRangoFechaAutorizado.Visible = False
        '
        'celdaTemporal
        '
        Me.celdaTemporal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTemporal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaTemporal.Location = New System.Drawing.Point(71, 63)
        Me.celdaTemporal.Multiline = True
        Me.celdaTemporal.Name = "celdaTemporal"
        Me.celdaTemporal.Size = New System.Drawing.Size(89, 19)
        Me.celdaTemporal.TabIndex = 47
        Me.celdaTemporal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonSerie
        '
        Me.botonSerie.Location = New System.Drawing.Point(386, 28)
        Me.botonSerie.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(30, 19)
        Me.botonSerie.TabIndex = 46
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        '
        'celdaSerie1
        '
        Me.celdaSerie1.Location = New System.Drawing.Point(241, 30)
        Me.celdaSerie1.Name = "celdaSerie1"
        Me.celdaSerie1.ReadOnly = True
        Me.celdaSerie1.Size = New System.Drawing.Size(139, 20)
        Me.celdaSerie1.TabIndex = 45
        Me.celdaSerie1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCAI
        '
        Me.celdaCAI.Location = New System.Drawing.Point(71, 245)
        Me.celdaCAI.Name = "celdaCAI"
        Me.celdaCAI.Size = New System.Drawing.Size(247, 20)
        Me.celdaCAI.TabIndex = 44
        Me.celdaCAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaCAI.Visible = False
        '
        'etiquetaCAI
        '
        Me.etiquetaCAI.AutoSize = True
        Me.etiquetaCAI.Location = New System.Drawing.Point(17, 245)
        Me.etiquetaCAI.Name = "etiquetaCAI"
        Me.etiquetaCAI.Size = New System.Drawing.Size(24, 13)
        Me.etiquetaCAI.TabIndex = 43
        Me.etiquetaCAI.Text = "CAI"
        Me.etiquetaCAI.Visible = False
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(17, 199)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 42
        Me.etiquetaNIT.Text = "NIT"
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(69, 199)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(142, 20)
        Me.celdaNIT.TabIndex = 41
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(263, 56)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 39
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 175)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Phone"
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(69, 175)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(142, 20)
        Me.celdaTelefono.TabIndex = 33
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.Location = New System.Drawing.Point(282, 177)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(74, 17)
        Me.checkRevisado.TabIndex = 32
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(247, 174)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(29, 23)
        Me.botonPolizaC.TabIndex = 31
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(247, 40)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(20, 20)
        Me.celdaEmpresa.TabIndex = 30
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'dtpFech
        '
        Me.dtpFech.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFech.Location = New System.Drawing.Point(302, 80)
        Me.dtpFech.Name = "dtpFech"
        Me.dtpFech.Size = New System.Drawing.Size(85, 20)
        Me.dtpFech.TabIndex = 29
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(392, 19)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(20, 20)
        Me.celdaUsuario.TabIndex = 28
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(247, 66)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(20, 20)
        Me.celdaCatalogo.TabIndex = 27
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(227, 221)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(392, 78)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDCliente.TabIndex = 24
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(305, 219)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(101, 20)
        Me.celdaTasa.TabIndex = 23
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(260, 221)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 22
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(195, 219)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(26, 20)
        Me.botonMoneda.TabIndex = 21
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(69, 221)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(97, 20)
        Me.celdaMoneda.TabIndex = 20
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(17, 225)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 19
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(70, 136)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(310, 35)
        Me.celdaDireccion.TabIndex = 11
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(11, 139)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 10
        Me.etiquetaDireccion.Text = "Address"
        '
        'botonClientes
        '
        Me.botonClientes.Location = New System.Drawing.Point(386, 104)
        Me.botonClientes.Name = "botonClientes"
        Me.botonClientes.Size = New System.Drawing.Size(26, 20)
        Me.botonClientes.TabIndex = 9
        Me.botonClientes.Text = "..."
        Me.botonClientes.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(70, 105)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(310, 20)
        Me.celdaCliente.TabIndex = 8
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(5, 108)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 7
        Me.etiquetaCliente.Text = "Customer"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(260, 86)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 5
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(71, 63)
        Me.celdaNumero.Multiline = True
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(89, 19)
        Me.celdaNumero.TabIndex = 3
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(11, 66)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaAño
        '
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaAño.Location = New System.Drawing.Point(70, 36)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(90, 19)
        Me.celdaAño.TabIndex = 1
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(26, 36)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.panelListaPrincipal)
        Me.panelLista.Controls.Add(Me.panelFecha)
        Me.panelLista.Location = New System.Drawing.Point(188, 75)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(275, 125)
        Me.panelLista.TabIndex = 4
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 46)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(275, 79)
        Me.panelListaPrincipal.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumber, Me.colNo, Me.colDate, Me.colNombre, Me.colReferencia, Me.colEstado, Me.colSerieF, Me.colAutorizacionF})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(275, 79)
        Me.dgLista.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Width = 54
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 69
        '
        'colNo
        '
        Me.colNo.HeaderText = "N°"
        Me.colNo.Name = "colNo"
        Me.colNo.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 55
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 60
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        Me.colEstado.Width = 65
        '
        'colSerieF
        '
        Me.colSerieF.HeaderText = "SerieF"
        Me.colSerieF.Name = "colSerieF"
        Me.colSerieF.ReadOnly = True
        Me.colSerieF.Visible = False
        '
        'colAutorizacionF
        '
        Me.colAutorizacionF.HeaderText = "Autorizacion Fel"
        Me.colAutorizacionF.Name = "colAutorizacionF"
        Me.colAutorizacionF.ReadOnly = True
        Me.colAutorizacionF.Visible = False
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(275, 46)
        Me.panelFecha.TabIndex = 1
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(432, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(328, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(182, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(209, 11)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(59, 43)
        Me.botonImprimir.TabIndex = 23
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = CType(resources.GetObject("botonBuscar.Image"), System.Drawing.Image)
        Me.botonBuscar.Location = New System.Drawing.Point(272, 11)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(59, 43)
        Me.botonBuscar.TabIndex = 25
        Me.botonBuscar.Text = "Look"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseMnemonic = False
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'botonPrevio
        '
        Me.botonPrevio.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonPrevio.Location = New System.Drawing.Point(335, 11)
        Me.botonPrevio.Name = "botonPrevio"
        Me.botonPrevio.Size = New System.Drawing.Size(65, 42)
        Me.botonPrevio.TabIndex = 30
        Me.botonPrevio.Text = "Preview"
        Me.botonPrevio.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevio.UseVisualStyleBackColor = True
        '
        'etiquetaAutorizacion
        '
        Me.etiquetaAutorizacion.AutoSize = True
        Me.etiquetaAutorizacion.Location = New System.Drawing.Point(425, 86)
        Me.etiquetaAutorizacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizacion.Name = "etiquetaAutorizacion"
        Me.etiquetaAutorizacion.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaAutorizacion.TabIndex = 32
        Me.etiquetaAutorizacion.Text = "Label4"
        Me.etiquetaAutorizacion.Visible = False
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(362, 86)
        Me.etiquetaSerie.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaSerie.TabIndex = 31
        Me.etiquetaSerie.Text = "Label4"
        Me.etiquetaSerie.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 75)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(868, 33)
        Me.BarraTitulo1.TabIndex = 6
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(868, 75)
        Me.Encabezado1.TabIndex = 2
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Width = 54
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 69
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        Me.colUsuario.Width = 54
        '
        'colReference
        '
        Me.colReference.HeaderText = "Reference"
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        Me.colReference.Width = 82
        '
        'cloDr1Dbl
        '
        Me.cloDr1Dbl.HeaderText = "Invoice"
        Me.cloDr1Dbl.Name = "cloDr1Dbl"
        Me.cloDr1Dbl.Width = 67
        '
        'saldo
        '
        Me.saldo.HeaderText = "Saldo"
        Me.saldo.Name = "saldo"
        Me.saldo.Width = 59
        '
        'frmNotasDeCredito
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(868, 716)
        Me.Controls.Add(Me.etiquetaAutorizacion)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.etiquetaSerie)
        Me.Controls.Add(Me.botonPrevio)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Controls.Add(Me.panelNotasCredito)
        Me.Name = "frmNotasDeCredito"
        Me.Text = "frmNotasDeCredito"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelNotasCredito.ResumeLayout(False)
        Me.panelDocumento.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.gbFelServi.ResumeLayout(False)
        Me.gbFelServi.PerformLayout()
        Me.panelImpuestos.ResumeLayout(False)
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgDetalleNC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.gbInformación.ResumeLayout(False)
        Me.gbInformación.PerformLayout()
        Me.gbFacturas.ResumeLayout(False)
        Me.gbFacturas.PerformLayout()
        CType(Me.dgFacturacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDatosDocumento.ResumeLayout(False)
        Me.gbDatosDocumento.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents panelNotasCredito As System.Windows.Forms.Panel
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFecha As System.Windows.Forms.Panel
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFin As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents gbDatosDocumento As System.Windows.Forms.GroupBox
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents botonPolizaC As System.Windows.Forms.Button
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents dtpFech As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents botonClientes As System.Windows.Forms.Button
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents gbFacturas As System.Windows.Forms.GroupBox
    Friend WithEvents dgFacturacion As System.Windows.Forms.DataGridView
    Friend WithEvents gbInformación As System.Windows.Forms.GroupBox
    Friend WithEvents celdaDeclaracion As System.Windows.Forms.TextBox
    Friend WithEvents EtiquetaDeclaracion As System.Windows.Forms.Label
    Friend WithEvents celdaTasaFactura As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasaFactura As System.Windows.Forms.Label
    Friend WithEvents rbOtros As System.Windows.Forms.RadioButton
    Friend WithEvents rbDevoluciones As System.Windows.Forms.RadioButton
    Friend WithEvents rbDifPrecio As System.Windows.Forms.RadioButton
    Friend WithEvents celdaNotasObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents etiquetraNotasObservaciones As System.Windows.Forms.Label
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelTotales As System.Windows.Forms.Panel
    Friend WithEvents celdaSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents CeldaTotalEnLetras As System.Windows.Forms.TextBox
    Friend WithEvents panelListaPrincipal As System.Windows.Forms.Panel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents botonAgregarFactura As System.Windows.Forms.Button
    Friend WithEvents panelImpuestos As System.Windows.Forms.Panel
    Friend WithEvents dgImpuestos As System.Windows.Forms.DataGridView
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTotalLetras As System.Windows.Forms.TextBox
    Friend WithEvents colLin As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCanti As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFactor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTag As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents celdaCAI As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCAI As System.Windows.Forms.Label
    Friend WithEvents botonSerie As System.Windows.Forms.Button
    Friend WithEvents celdaSerie1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaTemporal As TextBox
    Friend WithEvents celdaRangoFechaAutorizado As System.Windows.Forms.TextBox
    Friend WithEvents botonBuscar As Button
    Friend WithEvents celdaSerieFel As TextBox
    Friend WithEvents celdaFechaHoraCertificacion As TextBox
    Friend WithEvents celdaFechaEmisionDocumento As TextBox
    Friend WithEvents celdaUUID As TextBox
    Friend WithEvents botonPrevio As Button
    Friend WithEvents celdaUIDDFact As TextBox
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colNo As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colSerieF As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizacionF As DataGridViewTextBoxColumn
    Friend WithEvents etiquetaAutorizacion As Label
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents celdaAutFact As TextBox
    Friend WithEvents celdaSerieGF As TextBox
    Friend WithEvents celdaResolucion As TextBox
    Friend WithEvents checkFacturaFiscal As System.Windows.Forms.CheckBox
    Friend WithEvents celdaExepcion As TextBox
    Friend WithEvents etiquetaExepcion As Label
    Friend WithEvents celdaImpuesto As TextBox
    Friend WithEvents etiquetaImpuesto As Label
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colDescription As DataGridViewTextBoxColumn
    Friend WithEvents colUnitario As DataGridViewTextBoxColumn
    Friend WithEvents colImpuesto As DataGridViewTextBoxColumn
    Friend WithEvents colExepcion As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents celdaSub As TextBox
    Friend WithEvents etiquetaSubTotal As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents etiquetaGiro As Label
    Friend WithEvents celdaGiro As TextBox
    Friend WithEvents dgDetalleNC As DataGridView
    Friend WithEvents panelBotones As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents colCatalogoDet As DataGridViewTextBoxColumn
    Friend WithEvents colAnioDet As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroDet As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDet As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadDet As DataGridViewTextBoxColumn
    Friend WithEvents colUMedidaDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionDet As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaDet As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioDet As DataGridViewTextBoxColumn
    Friend WithEvents colTotalDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionNCDet As DataGridViewTextBoxColumn
    Friend WithEvents colLibrasDet As DataGridViewTextBoxColumn
    Friend WithEvents colImpuestoDet As DataGridViewTextBoxColumn
    Friend WithEvents colExcepcionDet As DataGridViewTextBoxColumn
    Friend WithEvents colTotalNCDet As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colExtraDet As DataGridViewTextBoxColumn
    Friend WithEvents gbFelServi As GroupBox
    Friend WithEvents etiquetaSerieFel As Label
    Friend WithEvents etiquetaNumeroFel As Label
    Friend WithEvents celdaSeriFelServi As TextBox
    Friend WithEvents celdaNumeroFelServi As TextBox
    Friend WithEvents celdaCatalogoCAI As TextBox
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As DataGridViewTextBoxColumn
    Friend WithEvents colReference As DataGridViewTextBoxColumn
    Friend WithEvents cloDr1Dbl As DataGridViewTextBoxColumn
    Friend WithEvents saldo As DataGridViewTextBoxColumn
End Class
