﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmPresupuestoMes
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.txtAnio = New System.Windows.Forms.TextBox()
        Me.btnCCosto = New System.Windows.Forms.Button()
        Me.txtCCosto = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.dgNomenclatura = New System.Windows.Forms.DataGridView()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.dtpAnios = New System.Windows.Forms.DateTimePicker()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtidPresupuesto = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.txtidDescripcion = New System.Windows.Forms.TextBox()
        Me.txtidCCosto = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaEnero = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.celdaJunio = New System.Windows.Forms.TextBox()
        Me.celdaJulio = New System.Windows.Forms.TextBox()
        Me.celdaDiciembre = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaMarzo = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.celdaMayo = New System.Windows.Forms.TextBox()
        Me.celdaAgosto = New System.Windows.Forms.TextBox()
        Me.celdaNoviembre = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.January = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.celdaAbril = New System.Windows.Forms.TextBox()
        Me.celdaFebrero = New System.Windows.Forms.TextBox()
        Me.celdaSeptiembre = New System.Windows.Forms.TextBox()
        Me.celdaOctubre = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Colfecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColCCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbFilter = New System.Windows.Forms.GroupBox()
        Me.txtIdCCost2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtCCosto2 = New System.Windows.Forms.TextBox()
        Me.btnCCosto2 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.btnFilter = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.botonExportar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.nCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombreCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumeroCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CuentaLocal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.enero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.febrero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.marzo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.abril = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mayo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.junio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.julio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.agosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.septiembre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.octubre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.noviembre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.diciembre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDocumento.SuspendLayout()
        CType(Me.dgNomenclatura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbFilter.SuspendLayout()
        Me.SuspendLayout()
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(78, 73)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(107, 20)
        Me.dtpFecha.TabIndex = 1
        '
        'txtAnio
        '
        Me.txtAnio.Location = New System.Drawing.Point(78, 99)
        Me.txtAnio.Name = "txtAnio"
        Me.txtAnio.Size = New System.Drawing.Size(107, 20)
        Me.txtAnio.TabIndex = 2
        '
        'btnCCosto
        '
        Me.btnCCosto.Location = New System.Drawing.Point(371, 46)
        Me.btnCCosto.Name = "btnCCosto"
        Me.btnCCosto.Size = New System.Drawing.Size(33, 25)
        Me.btnCCosto.TabIndex = 3
        Me.btnCCosto.Text = "..."
        Me.btnCCosto.UseVisualStyleBackColor = True
        '
        'txtCCosto
        '
        Me.txtCCosto.Enabled = False
        Me.txtCCosto.Location = New System.Drawing.Point(78, 48)
        Me.txtCCosto.Name = "txtCCosto"
        Me.txtCCosto.Size = New System.Drawing.Size(264, 20)
        Me.txtCCosto.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 53)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Costs Center"
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.dgNomenclatura)
        Me.panelDocumento.Controls.Add(Me.GroupBox1)
        Me.panelDocumento.Controls.Add(Me.Panel1)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumento.Location = New System.Drawing.Point(0, 102)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1404, 562)
        Me.panelDocumento.TabIndex = 6
        '
        'dgNomenclatura
        '
        Me.dgNomenclatura.AllowUserToAddRows = False
        Me.dgNomenclatura.AllowUserToOrderColumns = True
        Me.dgNomenclatura.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgNomenclatura.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgNomenclatura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgNomenclatura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.nCuenta, Me.linea, Me.NombreCuenta, Me.NumeroCuenta, Me.CuentaLocal, Me.enero, Me.febrero, Me.marzo, Me.abril, Me.mayo, Me.junio, Me.julio, Me.agosto, Me.septiembre, Me.octubre, Me.noviembre, Me.diciembre})
        Me.dgNomenclatura.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgNomenclatura.Location = New System.Drawing.Point(0, 131)
        Me.dgNomenclatura.MultiSelect = False
        Me.dgNomenclatura.Name = "dgNomenclatura"
        Me.dgNomenclatura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgNomenclatura.Size = New System.Drawing.Size(1404, 367)
        Me.dgNomenclatura.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label20)
        Me.GroupBox1.Controls.Add(Me.dtpAnios)
        Me.GroupBox1.Controls.Add(Me.txtTotal)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtidPresupuesto)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.celdaIdMoneda)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.botonMoneda)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.celdaTasa)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.celdaMoneda)
        Me.GroupBox1.Controls.Add(Me.txtCCosto)
        Me.GroupBox1.Controls.Add(Me.txtAnio)
        Me.GroupBox1.Controls.Add(Me.txtidDescripcion)
        Me.GroupBox1.Controls.Add(Me.btnCCosto)
        Me.GroupBox1.Controls.Add(Me.txtidCCosto)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1404, 131)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Budget data"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(804, 26)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(31, 13)
        Me.Label20.TabIndex = 50
        Me.Label20.Text = "Total"
        '
        'dtpAnios
        '
        Me.dtpAnios.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpAnios.Location = New System.Drawing.Point(78, 99)
        Me.dtpAnios.Name = "dtpAnios"
        Me.dtpAnios.Size = New System.Drawing.Size(107, 20)
        Me.dtpAnios.TabIndex = 22
        '
        'txtTotal
        '
        Me.txtTotal.Enabled = False
        Me.txtTotal.Location = New System.Drawing.Point(807, 42)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.Size = New System.Drawing.Size(107, 20)
        Me.txtTotal.TabIndex = 21
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(9, 26)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Number"
        '
        'txtidPresupuesto
        '
        Me.txtidPresupuesto.Location = New System.Drawing.Point(78, 24)
        Me.txtidPresupuesto.Name = "txtidPresupuesto"
        Me.txtidPresupuesto.Size = New System.Drawing.Size(107, 20)
        Me.txtidPresupuesto.TabIndex = 19
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(9, 79)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(30, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Date"
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(775, 27)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(18, 20)
        Me.celdaIdMoneda.TabIndex = 17
        Me.celdaIdMoneda.Text = "-1"
        Me.celdaIdMoneda.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Year"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(722, 24)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(37, 27)
        Me.botonMoneda.TabIndex = 16
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(537, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Coin"
        '
        'celdaTasa
        '
        Me.celdaTasa.Enabled = False
        Me.celdaTasa.Location = New System.Drawing.Point(590, 53)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(107, 20)
        Me.celdaTasa.TabIndex = 15
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(537, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Rate"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Enabled = False
        Me.celdaMoneda.Location = New System.Drawing.Point(590, 27)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(107, 20)
        Me.celdaMoneda.TabIndex = 14
        '
        'txtidDescripcion
        '
        Me.txtidDescripcion.Location = New System.Drawing.Point(379, 92)
        Me.txtidDescripcion.Name = "txtidDescripcion"
        Me.txtidDescripcion.Size = New System.Drawing.Size(18, 20)
        Me.txtidDescripcion.TabIndex = 11
        Me.txtidDescripcion.Text = "-1"
        Me.txtidDescripcion.Visible = False
        '
        'txtidCCosto
        '
        Me.txtidCCosto.Location = New System.Drawing.Point(403, 92)
        Me.txtidCCosto.Name = "txtidCCosto"
        Me.txtidCCosto.Size = New System.Drawing.Size(18, 20)
        Me.txtidCCosto.TabIndex = 8
        Me.txtidCCosto.Text = "-1"
        Me.txtidCCosto.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.celdaEnero)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.celdaJunio)
        Me.Panel1.Controls.Add(Me.celdaJulio)
        Me.Panel1.Controls.Add(Me.celdaDiciembre)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.celdaMarzo)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.celdaMayo)
        Me.Panel1.Controls.Add(Me.celdaAgosto)
        Me.Panel1.Controls.Add(Me.celdaNoviembre)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.January)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.celdaAbril)
        Me.Panel1.Controls.Add(Me.celdaFebrero)
        Me.Panel1.Controls.Add(Me.celdaSeptiembre)
        Me.Panel1.Controls.Add(Me.celdaOctubre)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 498)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1404, 64)
        Me.Panel1.TabIndex = 50
        '
        'celdaEnero
        '
        Me.celdaEnero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaEnero.Enabled = False
        Me.celdaEnero.Location = New System.Drawing.Point(3, 13)
        Me.celdaEnero.Name = "celdaEnero"
        Me.celdaEnero.Size = New System.Drawing.Size(83, 20)
        Me.celdaEnero.TabIndex = 25
        Me.celdaEnero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(474, 36)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(30, 13)
        Me.Label13.TabIndex = 37
        Me.Label13.Text = "June"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(992, 36)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(56, 13)
        Me.Label19.TabIndex = 49
        Me.Label19.Text = "December"
        '
        'celdaJunio
        '
        Me.celdaJunio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaJunio.Enabled = False
        Me.celdaJunio.Location = New System.Drawing.Point(445, 13)
        Me.celdaJunio.Name = "celdaJunio"
        Me.celdaJunio.Size = New System.Drawing.Size(83, 20)
        Me.celdaJunio.TabIndex = 36
        Me.celdaJunio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaJulio
        '
        Me.celdaJulio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaJulio.Enabled = False
        Me.celdaJulio.Location = New System.Drawing.Point(533, 13)
        Me.celdaJulio.Name = "celdaJulio"
        Me.celdaJulio.Size = New System.Drawing.Size(83, 20)
        Me.celdaJulio.TabIndex = 38
        Me.celdaJulio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaDiciembre
        '
        Me.celdaDiciembre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaDiciembre.Enabled = False
        Me.celdaDiciembre.Location = New System.Drawing.Point(976, 13)
        Me.celdaDiciembre.Name = "celdaDiciembre"
        Me.celdaDiciembre.Size = New System.Drawing.Size(83, 20)
        Me.celdaDiciembre.TabIndex = 48
        Me.celdaDiciembre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(375, 36)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(27, 13)
        Me.Label12.TabIndex = 35
        Me.Label12.Text = "May"
        '
        'celdaMarzo
        '
        Me.celdaMarzo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaMarzo.Enabled = False
        Me.celdaMarzo.Location = New System.Drawing.Point(180, 13)
        Me.celdaMarzo.Name = "celdaMarzo"
        Me.celdaMarzo.Size = New System.Drawing.Size(83, 20)
        Me.celdaMarzo.TabIndex = 30
        Me.celdaMarzo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(563, 36)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(25, 13)
        Me.Label14.TabIndex = 39
        Me.Label14.Text = "July"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(903, 36)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(56, 13)
        Me.Label18.TabIndex = 47
        Me.Label18.Text = "November"
        '
        'celdaMayo
        '
        Me.celdaMayo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaMayo.Enabled = False
        Me.celdaMayo.Location = New System.Drawing.Point(356, 13)
        Me.celdaMayo.Name = "celdaMayo"
        Me.celdaMayo.Size = New System.Drawing.Size(83, 20)
        Me.celdaMayo.TabIndex = 34
        Me.celdaMayo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaAgosto
        '
        Me.celdaAgosto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaAgosto.Enabled = False
        Me.celdaAgosto.Location = New System.Drawing.Point(620, 13)
        Me.celdaAgosto.Name = "celdaAgosto"
        Me.celdaAgosto.Size = New System.Drawing.Size(83, 20)
        Me.celdaAgosto.TabIndex = 40
        Me.celdaAgosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaNoviembre
        '
        Me.celdaNoviembre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaNoviembre.Enabled = False
        Me.celdaNoviembre.Location = New System.Drawing.Point(887, 13)
        Me.celdaNoviembre.Name = "celdaNoviembre"
        Me.celdaNoviembre.Size = New System.Drawing.Size(83, 20)
        Me.celdaNoviembre.TabIndex = 46
        Me.celdaNoviembre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(299, 36)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(27, 13)
        Me.Label11.TabIndex = 33
        Me.Label11.Text = "April"
        '
        'January
        '
        Me.January.AutoSize = True
        Me.January.Location = New System.Drawing.Point(19, 36)
        Me.January.Name = "January"
        Me.January.Size = New System.Drawing.Size(44, 13)
        Me.January.TabIndex = 27
        Me.January.Text = "January"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(646, 36)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(40, 13)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "August"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(814, 36)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 13)
        Me.Label17.TabIndex = 45
        Me.Label17.Text = "October"
        '
        'celdaAbril
        '
        Me.celdaAbril.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaAbril.Enabled = False
        Me.celdaAbril.Location = New System.Drawing.Point(268, 13)
        Me.celdaAbril.Name = "celdaAbril"
        Me.celdaAbril.Size = New System.Drawing.Size(83, 20)
        Me.celdaAbril.TabIndex = 32
        Me.celdaAbril.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaFebrero
        '
        Me.celdaFebrero.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaFebrero.Enabled = False
        Me.celdaFebrero.Location = New System.Drawing.Point(92, 13)
        Me.celdaFebrero.Name = "celdaFebrero"
        Me.celdaFebrero.Size = New System.Drawing.Size(83, 20)
        Me.celdaFebrero.TabIndex = 28
        Me.celdaFebrero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaSeptiembre
        '
        Me.celdaSeptiembre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaSeptiembre.Enabled = False
        Me.celdaSeptiembre.Location = New System.Drawing.Point(708, 13)
        Me.celdaSeptiembre.Name = "celdaSeptiembre"
        Me.celdaSeptiembre.Size = New System.Drawing.Size(83, 20)
        Me.celdaSeptiembre.TabIndex = 42
        Me.celdaSeptiembre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaOctubre
        '
        Me.celdaOctubre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaOctubre.Enabled = False
        Me.celdaOctubre.Location = New System.Drawing.Point(798, 13)
        Me.celdaOctubre.Name = "celdaOctubre"
        Me.celdaOctubre.Size = New System.Drawing.Size(83, 20)
        Me.celdaOctubre.TabIndex = 44
        Me.celdaOctubre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(203, 36)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(37, 13)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "March"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(108, 36)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 29
        Me.Label9.Text = "February"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(724, 36)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(58, 13)
        Me.Label16.TabIndex = 43
        Me.Label16.Text = "September"
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.gbFilter)
        Me.panelLista.Location = New System.Drawing.Point(4, 102)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(784, 108)
        Me.panelLista.TabIndex = 7
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.id, Me.idC, Me.Colfecha, Me.ColCCosto, Me.ColDes})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 47)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(784, 61)
        Me.dgLista.TabIndex = 0
        '
        'id
        '
        Me.id.HeaderText = "#"
        Me.id.Name = "id"
        Me.id.ReadOnly = True
        Me.id.Width = 39
        '
        'idC
        '
        Me.idC.HeaderText = "idC"
        Me.idC.Name = "idC"
        Me.idC.ReadOnly = True
        Me.idC.Visible = False
        Me.idC.Width = 47
        '
        'Colfecha
        '
        Me.Colfecha.HeaderText = "Date"
        Me.Colfecha.Name = "Colfecha"
        Me.Colfecha.ReadOnly = True
        Me.Colfecha.Width = 55
        '
        'ColCCosto
        '
        Me.ColCCosto.HeaderText = "Cost Center"
        Me.ColCCosto.Name = "ColCCosto"
        Me.ColCCosto.ReadOnly = True
        Me.ColCCosto.Width = 87
        '
        'ColDes
        '
        Me.ColDes.HeaderText = "Description"
        Me.ColDes.Name = "ColDes"
        Me.ColDes.ReadOnly = True
        Me.ColDes.Width = 85
        '
        'gbFilter
        '
        Me.gbFilter.Controls.Add(Me.txtIdCCost2)
        Me.gbFilter.Controls.Add(Me.Label6)
        Me.gbFilter.Controls.Add(Me.txtCCosto2)
        Me.gbFilter.Controls.Add(Me.btnCCosto2)
        Me.gbFilter.Controls.Add(Me.Label5)
        Me.gbFilter.Controls.Add(Me.checkFecha)
        Me.gbFilter.Controls.Add(Me.btnFilter)
        Me.gbFilter.Controls.Add(Me.dtpFin)
        Me.gbFilter.Controls.Add(Me.dtpInicio)
        Me.gbFilter.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbFilter.Location = New System.Drawing.Point(0, 0)
        Me.gbFilter.Name = "gbFilter"
        Me.gbFilter.Size = New System.Drawing.Size(784, 47)
        Me.gbFilter.TabIndex = 1
        Me.gbFilter.TabStop = False
        Me.gbFilter.Text = "Filter by"
        '
        'txtIdCCost2
        '
        Me.txtIdCCost2.Location = New System.Drawing.Point(926, 13)
        Me.txtIdCCost2.Name = "txtIdCCost2"
        Me.txtIdCCost2.Size = New System.Drawing.Size(24, 20)
        Me.txtIdCCost2.TabIndex = 8
        Me.txtIdCCost2.Text = "-1"
        Me.txtIdCCost2.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(551, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 13)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Cost C."
        '
        'txtCCosto2
        '
        Me.txtCCosto2.Location = New System.Drawing.Point(606, 20)
        Me.txtCCosto2.Name = "txtCCosto2"
        Me.txtCCosto2.Size = New System.Drawing.Size(264, 20)
        Me.txtCCosto2.TabIndex = 6
        '
        'btnCCosto2
        '
        Me.btnCCosto2.Location = New System.Drawing.Point(907, 17)
        Me.btnCCosto2.Name = "btnCCosto2"
        Me.btnCCosto2.Size = New System.Drawing.Size(33, 25)
        Me.btnCCosto2.TabIndex = 5
        Me.btnCCosto2.Text = "..."
        Me.btnCCosto2.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(254, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "and date"
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(8, 22)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(121, 17)
        Me.checkFecha.TabIndex = 3
        Me.checkFecha.Text = "Show between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'btnFilter
        '
        Me.btnFilter.Location = New System.Drawing.Point(443, 19)
        Me.btnFilter.Name = "btnFilter"
        Me.btnFilter.Size = New System.Drawing.Size(98, 24)
        Me.btnFilter.TabIndex = 2
        Me.btnFilter.Text = "Filtered"
        Me.btnFilter.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(319, 19)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(104, 20)
        Me.dtpFin.TabIndex = 1
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(132, 19)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(104, 20)
        Me.dtpInicio.TabIndex = 0
        '
        'botonExportar
        '
        Me.botonExportar.Image = Global.KARIMs_SGI.My.Resources.Resources.doc_excel
        Me.botonExportar.Location = New System.Drawing.Point(203, 9)
        Me.botonExportar.Name = "botonExportar"
        Me.botonExportar.Size = New System.Drawing.Size(56, 45)
        Me.botonExportar.TabIndex = 8
        Me.botonExportar.Text = "Export"
        Me.botonExportar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonExportar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1404, 30)
        Me.BarraTitulo1.TabIndex = 7
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1404, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'nCuenta
        '
        Me.nCuenta.HeaderText = "#"
        Me.nCuenta.Name = "nCuenta"
        Me.nCuenta.ReadOnly = True
        Me.nCuenta.Width = 39
        '
        'linea
        '
        Me.linea.HeaderText = "Linea"
        Me.linea.Name = "linea"
        Me.linea.Visible = False
        Me.linea.Width = 58
        '
        'NombreCuenta
        '
        Me.NombreCuenta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.NombreCuenta.FillWeight = 75.0!
        Me.NombreCuenta.HeaderText = "Name"
        Me.NombreCuenta.Name = "NombreCuenta"
        Me.NombreCuenta.ReadOnly = True
        Me.NombreCuenta.Width = 200
        '
        'NumeroCuenta
        '
        Me.NumeroCuenta.HeaderText = "# Account"
        Me.NumeroCuenta.Name = "NumeroCuenta"
        Me.NumeroCuenta.ReadOnly = True
        Me.NumeroCuenta.Width = 82
        '
        'CuentaLocal
        '
        Me.CuentaLocal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.CuentaLocal.FillWeight = 75.0!
        Me.CuentaLocal.HeaderText = "Local Account"
        Me.CuentaLocal.Name = "CuentaLocal"
        Me.CuentaLocal.ReadOnly = True
        Me.CuentaLocal.Width = 200
        '
        'enero
        '
        Me.enero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.enero.DefaultCellStyle = DataGridViewCellStyle1
        Me.enero.HeaderText = "January"
        Me.enero.Name = "enero"
        Me.enero.Width = 83
        '
        'febrero
        '
        Me.febrero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.febrero.DefaultCellStyle = DataGridViewCellStyle2
        Me.febrero.HeaderText = "February"
        Me.febrero.Name = "febrero"
        Me.febrero.Width = 83
        '
        'marzo
        '
        Me.marzo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.marzo.DefaultCellStyle = DataGridViewCellStyle3
        Me.marzo.HeaderText = "March"
        Me.marzo.Name = "marzo"
        Me.marzo.Width = 83
        '
        'abril
        '
        Me.abril.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.abril.DefaultCellStyle = DataGridViewCellStyle4
        Me.abril.HeaderText = "April"
        Me.abril.Name = "abril"
        Me.abril.Width = 83
        '
        'mayo
        '
        Me.mayo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.mayo.DefaultCellStyle = DataGridViewCellStyle5
        Me.mayo.HeaderText = "May"
        Me.mayo.Name = "mayo"
        Me.mayo.Width = 83
        '
        'junio
        '
        Me.junio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.junio.DefaultCellStyle = DataGridViewCellStyle6
        Me.junio.HeaderText = "June"
        Me.junio.Name = "junio"
        Me.junio.Width = 83
        '
        'julio
        '
        Me.julio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight
        Me.julio.DefaultCellStyle = DataGridViewCellStyle7
        Me.julio.HeaderText = "July"
        Me.julio.Name = "julio"
        Me.julio.Width = 83
        '
        'agosto
        '
        Me.agosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.agosto.DefaultCellStyle = DataGridViewCellStyle8
        Me.agosto.HeaderText = "August"
        Me.agosto.Name = "agosto"
        Me.agosto.Width = 83
        '
        'septiembre
        '
        Me.septiembre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.septiembre.DefaultCellStyle = DataGridViewCellStyle9
        Me.septiembre.HeaderText = "September"
        Me.septiembre.Name = "septiembre"
        Me.septiembre.Width = 83
        '
        'octubre
        '
        Me.octubre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.octubre.DefaultCellStyle = DataGridViewCellStyle10
        Me.octubre.HeaderText = "October"
        Me.octubre.Name = "octubre"
        Me.octubre.Width = 83
        '
        'noviembre
        '
        Me.noviembre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.noviembre.DefaultCellStyle = DataGridViewCellStyle11
        Me.noviembre.HeaderText = "November"
        Me.noviembre.Name = "noviembre"
        Me.noviembre.Width = 83
        '
        'diciembre
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.diciembre.DefaultCellStyle = DataGridViewCellStyle12
        Me.diciembre.HeaderText = "December"
        Me.diciembre.Name = "diciembre"
        Me.diciembre.Width = 81
        '
        'frmPresupuestoMes
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1404, 664)
        Me.Controls.Add(Me.botonExportar)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmPresupuestoMes"
        Me.Text = "Budget"
        Me.panelDocumento.ResumeLayout(False)
        CType(Me.dgNomenclatura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbFilter.ResumeLayout(False)
        Me.gbFilter.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents txtAnio As TextBox
    Friend WithEvents btnCCosto As Button
    Friend WithEvents txtCCosto As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents dgNomenclatura As DataGridView
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents txtidCCosto As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtidDescripcion As TextBox
    Friend WithEvents gbFilter As GroupBox
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents btnFilter As Button
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtCCosto2 As TextBox
    Friend WithEvents btnCCosto2 As Button
    Friend WithEvents txtIdCCost2 As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtidPresupuesto As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents dtpAnios As DateTimePicker
    Friend WithEvents txtTotal As TextBox
    Friend WithEvents id As DataGridViewTextBoxColumn
    Friend WithEvents idC As DataGridViewTextBoxColumn
    Friend WithEvents Colfecha As DataGridViewTextBoxColumn
    Friend WithEvents ColCCosto As DataGridViewTextBoxColumn
    Friend WithEvents ColDes As DataGridViewTextBoxColumn
    Friend WithEvents Label15 As Label
    Friend WithEvents celdaAgosto As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents celdaJulio As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents celdaJunio As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents celdaMayo As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents celdaAbril As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents celdaMarzo As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaFebrero As TextBox
    Friend WithEvents January As Label
    Friend WithEvents celdaEnero As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents celdaDiciembre As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents celdaNoviembre As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents celdaOctubre As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents celdaSeptiembre As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonExportar As Button
    Friend WithEvents nCuenta As DataGridViewTextBoxColumn
    Friend WithEvents linea As DataGridViewTextBoxColumn
    Friend WithEvents NombreCuenta As DataGridViewTextBoxColumn
    Friend WithEvents NumeroCuenta As DataGridViewTextBoxColumn
    Friend WithEvents CuentaLocal As DataGridViewTextBoxColumn
    Friend WithEvents enero As DataGridViewTextBoxColumn
    Friend WithEvents febrero As DataGridViewTextBoxColumn
    Friend WithEvents marzo As DataGridViewTextBoxColumn
    Friend WithEvents abril As DataGridViewTextBoxColumn
    Friend WithEvents mayo As DataGridViewTextBoxColumn
    Friend WithEvents junio As DataGridViewTextBoxColumn
    Friend WithEvents julio As DataGridViewTextBoxColumn
    Friend WithEvents agosto As DataGridViewTextBoxColumn
    Friend WithEvents septiembre As DataGridViewTextBoxColumn
    Friend WithEvents octubre As DataGridViewTextBoxColumn
    Friend WithEvents noviembre As DataGridViewTextBoxColumn
    Friend WithEvents diciembre As DataGridViewTextBoxColumn
End Class
