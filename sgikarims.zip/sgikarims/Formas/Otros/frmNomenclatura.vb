﻿Public Class frmNomenclatura

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub LimpiarCampos()
        celdaOrigen.Clear()
        celdaPid.Clear()
        celdaCuenta.Clear()
        celdaCompania.Clear()
        celdaNombre.Clear()
        celdaDescripcion.Clear()
        celdaNombreCta.Clear()
        celdaNumeroCta.Clear()

    End Sub
    Private Sub MostrarLista(Optional logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            panelEdicion.Dock = DockStyle.None
            panelEdicion.Visible = False
            BarraTitulo1.CambiarTitulo("Nomenclature")
            CargarCuentas()
            panelLista.Dock = DockStyle.Fill
            panelLista.Visible = True
        Else
            panelEdicion.Dock = DockStyle.Fill
            panelEdicion.Visible = True
            panelLista.Dock = DockStyle.None
            panelLista.Visible = False
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Nomenclature")
            Else
                BarraTitulo1.CambiarTitulo("New Account")
            End If
        End If
    End Sub

    Private Function SQLCargarCuentas()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT c.empresa,c.id_cuenta,c.tipo_saldo,c.nombre,c.pid  FROM {conta}.cuentas c "
        strSQL &= "   WHERE c.empresa={emp} ORDER BY id_cuenta "

        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)

        Return strSQL
    End Function
    Public Sub CargarCuentas()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Dim par As TreeNode
        Dim nod As TreeNode
        Dim nod1 As TreeNode
        Dim nod2 As TreeNode
        Dim nod3 As TreeNode
        Dim nod4 As TreeNode
        Dim nod5 As TreeNode

        Dim strVerPid As String = STR_VACIO
        Dim VerCta1 As String
        Dim VerCta0 As String
        Dim VerCta2 As String
        Dim VerCta3 As String
        Dim VerCta4 As String
        Dim VerCta5 As String

        Dim KeyPar As String
        Dim VerRaiz As String

        Dim j As Integer = 0
        Dim K As Integer = 0
        Dim l As Integer = 0
        Dim m As Integer = 0
        tvLista.Nodes.Clear()

        Try
            strSQL = SQLCargarCuentas()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then


                Do While REA.Read
                    If REA.GetString("pid") = vbEmpty Then

                        VerCta0 = REA.GetString("id_cuenta") ' Guarda la cuenta de la Raiz
                        'agrega los nodos padre del treeview (principales)
                        nod = tvLista.Nodes.Add(REA.GetString("id_cuenta"), REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"))
                        'nod.StateImageIndex = j
                        nod.Tag = REA.GetString("id_cuenta")
                        nod.EnsureVisible()
                        nod.Expand()
                        j = j + 1
                        'CuentaRaiz = CuentaRaiz + 1

                    Else
                        par = BuscarPadre(REA.GetString("pid")) 'dgCuentas.Rows(i).Cells("colIdCuenta").Value & " - " & dgCuentas.Rows(i).Cells("colNombre").Value)
                        If par Is Nothing Then

                            If REA.GetString("pid") = VerCta1 Then
                                par = nod1
                                KeyPar = REA.GetString("id_cuenta")
                                VerCta2 = REA.GetString("id_cuenta")
                                nod2 = par.Nodes.Add(KeyPar, REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"))
                            ElseIf REA.GetString("pid") = VerCta2 Then
                                par = nod2
                                KeyPar = REA.GetString("id_cuenta")
                                VerCta3 = REA.GetString("id_cuenta")
                                nod3 = par.Nodes.Add(KeyPar, REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"))
                                strVerPid = REA.GetString("pid")
                            ElseIf REA.GetString("pid") = VerCta3 Then
                                par = nod3
                                KeyPar = REA.GetString("id_cuenta")
                                VerCta4 = REA.GetString("id_cuenta")
                                nod4 = par.Nodes.Add(KeyPar, REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"))
                                strVerPid = REA.GetString("pid")
                            ElseIf REA.GetString("pid") = VerCta4 Then
                                par = nod4
                                KeyPar = REA.GetString("id_cuenta")
                                VerCta5 = REA.GetString("id_cuenta")
                                nod5 = par.Nodes.Add(KeyPar, REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"))
                                strVerPid = REA.GetString("pid")
                            ElseIf REA.GetString("pid") = VerCta5 Then
                                par = nod5
                                KeyPar = REA.GetString("id_cuenta")
                                VerCta5 = REA.GetString("id_cuenta")
                                nod5 = par.Nodes.Add(KeyPar, REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"))
                                strVerPid = REA.GetString("pid")
                            End If

                        Else
                            VerCta1 = REA.GetString("id_cuenta") ' Guarda la cuenta del Arbol de 1er Nivel
                            'Agrega los nodos hijos de los principales

                            nod1 = par.Nodes.Add(REA.GetString("id_cuenta"), REA.GetString("id_cuenta") & " - " & REA.GetString("nombre"), 5)
                            nod1.Tag = REA.GetString("id_cuenta")

                        End If

                    End If

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function BuscarPadre(ByVal codigo As String) As TreeNode
        Dim nod As TreeNode
        nod = tvLista.Nodes(codigo)

        Return nod
    End Function

    Private Sub NuevaCuenta(ByVal strNodo As String)

        Dim strEmp As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim strNuevoCodigo As String = STR_VACIO
        Dim strCodigo As String()

        strCodigo = strNodo.Split(" - ")
        strSQL = " SELECT razon_social FROM {conta}.empresas WHERE id_empresa = " & Sesion.IdEmpresa
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        strEmp = COM.ExecuteScalar 'Razón social de la empresa

        strSQL = STR_VACIO
        If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
            strSQL = " SELECT IFNULL(MAX(cast(id_cuenta AS UNSIGNED )), CONCAT({cod},'{ceros}')) abc  FROM {conta}.cuentas WHERE pid = {cod} AND empresa = " & Sesion.IdEmpresa
        Else
            strSQL = " SELECT IFNULL(MAX(id_cuenta), CONCAT({cod},'{ceros}')) abc  FROM {conta}.cuentas WHERE pid = {cod} AND empresa = " & Sesion.IdEmpresa
        End If

        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{cod}", strCodigo(0))
        If (Sesion.IdEmpresa = 16) Then
            strSQL = Replace(strSQL, "{ceros}", "00")
        Else
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18) Then
                If strCodigo(0).Length < 6 Then
                    strSQL = Replace(strSQL, "{ceros}", "00")
                Else
                    strSQL = Replace(strSQL, "{ceros}", "000")
                End If
            Else
                strSQL = Replace(strSQL, "{ceros}", "000")
            End If

        End If

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        strNuevoCodigo = COM.ExecuteScalar ' Nuevo código para la cuenta que se va a crear

        MostrarLista(False)
        If strNuevoCodigo.Length > 16 Then
        Else
            If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18) Then
                celdaCuenta.Text = CStr(strNuevoCodigo + 1)
            Else
                celdaCuenta.Text = "0" & CStr(strNuevoCodigo + 1)
            End If
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18) Then
                celdaCuenta.ReadOnly = False
            End If
            celdaCompania.Text = strEmp
            celdaOrigen.Text = strNodo
            celdaPid.Text = strCodigo(0)
            rbDeudor.Checked = True
            rbActivo.Checked = True
        End If


    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim ValidarDatos As Boolean = False
        If Trim(celdaNombre.Text) = vbNullString Then
            MsgBox("Add a name to the account", vbInformation, "Notice")
            celdaNombre.Focus()

        ElseIf Trim(celdaNumeroCta.Text) = vbNullString Then
            If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or (Sesion.IdEmpresa >= 18) Then
                MsgBox("Add account", vbInformation, "Notice")
                celdaNumeroCta.Focus()
            Else
                ValidarDatos = True
            End If
        Else
            ValidarDatos = True
        End If
        Return ValidarDatos
    End Function

    Private Sub GuardarCuenta()
        Dim TipoSaldo As String = STR_VACIO
        Dim TipoCuenta As Integer = 0

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        If rbAcreedor.Checked = True Then
            TipoSaldo = "A"
        ElseIf rbDeudor.Checked = True Then
            TipoSaldo = "D"
        End If

        If rbActivo.Checked = True Then
            TipoCuenta = 1
        ElseIf rbPatrimonio.Checked = True Then
            TipoCuenta = 2
        ElseIf rbPasivo.Checked = True Then
            TipoCuenta = 3
        ElseIf rbIngresos.Checked = True Then
            TipoCuenta = 4
        ElseIf rbGastos.Checked = True Then
            TipoCuenta = 5
        End If

        strSQL = " INSERT INTO {conta}.cuentas "
        strSQL &= " (id_cuenta, empresa, nombre, descripcion, tipo_saldo, pid, pem, tipo_cuenta,id_nomenclatura) "
        strSQL &= "  VALUES('{cuenta}', {empresa}, '{nombre}', '{descripcion}', '{saldo}', '{pid}', {pem}, {tipo_cuenta},'{cta_}') "
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{cuenta}", celdaCuenta.Text)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{nombre}", celdaNombre.Text)
        strSQL = Replace(strSQL, "{descripcion}", celdaDescripcion.Text)
        strSQL = Replace(strSQL, "{saldo}", TipoSaldo)
        strSQL = Replace(strSQL, "{pid}", celdaPid.Text)
        strSQL = Replace(strSQL, "{pem}", 1)
        strSQL = Replace(strSQL, "{tipo_cuenta}", TipoCuenta)
        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or (Sesion.IdEmpresa >= 18) Then
            strSQL = Replace(strSQL, "{cta_}", celdaNumeroCta.Text)
        Else
            strSQL = Replace(strSQL, "{cta_}", "0")
        End If

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        MsgBox("Account added successfully", vbInformation, "Notice")

    End Sub


#End Region

#Region "Eventos"
    Private Sub frmNomenclatura_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelEdicion.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If tvLista.SelectedNode Is Nothing Then
            MsgBox("Select the account where you want to create a new one", vbInformation, "Notice")
        Else
            LimpiarCampos()
            NuevaCuenta(tvLista.SelectedNode.Text)
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarDatos() = True Then
            GuardarCuenta()
            MostrarLista()
        Else

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "n.idEmpresa = {empresa} AND n.NivelCta = 3 "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Nomenclature"
            frm.Campos = " n.idCuenta Cuenta, n.NombreEspanol Nombre "
            frm.Tabla = cFunciones.ContaEmpresa & ".nomenclatura n "
            frm.FiltroText = " Enter the account to be filtered"
            frm.Filtro = " n.idCuenta "
            frm.Condicion = strCondicion
            frm.Ordenamiento = "n.idCuenta"
            frm.TipoOrdenamiento = " ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaNumeroCta.Text = frm.LLave
                celdaNombreCta.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

End Class