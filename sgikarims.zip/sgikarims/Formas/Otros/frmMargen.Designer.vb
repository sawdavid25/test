﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMargen
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.panelResultados = New System.Windows.Forms.Panel()
        Me.gdFacturas = New System.Windows.Forms.GroupBox()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaTotalCostos = New System.Windows.Forms.TextBox()
        Me.etiquetaTotalVentas = New System.Windows.Forms.Label()
        Me.celdaTotalVentas = New System.Windows.Forms.TextBox()
        Me.dgFactSinPoliza = New System.Windows.Forms.DataGridView()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbResultados = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaIndicadorMO = New System.Windows.Forms.TextBox()
        Me.celdaIndicadorRealMO = New System.Windows.Forms.TextBox()
        Me.celdaProyeccionMB = New System.Windows.Forms.TextBox()
        Me.etiquetaProyeccion = New System.Windows.Forms.Label()
        Me.etiquetaIndicadorReal = New System.Windows.Forms.Label()
        Me.celdaIndicadorRealMB = New System.Windows.Forms.TextBox()
        Me.panelProyeccion = New System.Windows.Forms.Panel()
        Me.gbBotones = New System.Windows.Forms.GroupBox()
        Me.etiquetaProyeccionMargenBruto = New System.Windows.Forms.Label()
        Me.celdaMargenBrutoProyeccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDatoReal = New System.Windows.Forms.Label()
        Me.celdaMargenOpatativoProyeccion = New System.Windows.Forms.TextBox()
        Me.celdaMargenOperativo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.etiquetaMargenBruto = New System.Windows.Forms.Label()
        Me.celdaMargenBruto = New System.Windows.Forms.TextBox()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaPeriodo = New System.Windows.Forms.Label()
        Me.botonPeriodo = New System.Windows.Forms.Button()
        Me.celdaPeriodo = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.botonDatosInventario = New System.Windows.Forms.Button()
        Me.etiquetaProyecccionCostos = New System.Windows.Forms.Label()
        Me.etiquetaVentasProyeccion = New System.Windows.Forms.Label()
        Me.celdaProyeccionCostos = New System.Windows.Forms.TextBox()
        Me.celdaProyeccionVentas = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.celdaDescuentos = New System.Windows.Forms.TextBox()
        Me.celdaDevoluciones = New System.Windows.Forms.TextBox()
        Me.celdaCostoVentas = New System.Windows.Forms.TextBox()
        Me.celdacostosOperacion = New System.Windows.Forms.TextBox()
        Me.celdaVentas = New System.Windows.Forms.TextBox()
        Me.etiquetaIntereses = New System.Windows.Forms.Label()
        Me.etiquetaCostosOpeativos = New System.Windows.Forms.Label()
        Me.etiquetaCostoDeVenta = New System.Windows.Forms.Label()
        Me.etiquetaDevoluciones = New System.Windows.Forms.Label()
        Me.etiquetaDescuentos = New System.Windows.Forms.Label()
        Me.etiquetaVentas = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.panelPrincipal.SuspendLayout()
        Me.panelResultados.SuspendLayout()
        Me.gdFacturas.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        CType(Me.dgFactSinPoliza, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbResultados.SuspendLayout()
        Me.panelProyeccion.SuspendLayout()
        Me.gbBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelPrincipal
        '
        Me.panelPrincipal.Controls.Add(Me.panelResultados)
        Me.panelPrincipal.Controls.Add(Me.panelProyeccion)
        Me.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelPrincipal.Location = New System.Drawing.Point(0, 0)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(1041, 618)
        Me.panelPrincipal.TabIndex = 0
        '
        'panelResultados
        '
        Me.panelResultados.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelResultados.Controls.Add(Me.gdFacturas)
        Me.panelResultados.Controls.Add(Me.gbResultados)
        Me.panelResultados.Location = New System.Drawing.Point(528, 0)
        Me.panelResultados.Name = "panelResultados"
        Me.panelResultados.Size = New System.Drawing.Size(513, 615)
        Me.panelResultados.TabIndex = 5
        '
        'gdFacturas
        '
        Me.gdFacturas.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gdFacturas.Controls.Add(Me.panelTotales)
        Me.gdFacturas.Controls.Add(Me.dgFactSinPoliza)
        Me.gdFacturas.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gdFacturas.Location = New System.Drawing.Point(0, 322)
        Me.gdFacturas.Name = "gdFacturas"
        Me.gdFacturas.Size = New System.Drawing.Size(513, 290)
        Me.gdFacturas.TabIndex = 0
        Me.gdFacturas.TabStop = False
        Me.gdFacturas.Text = "Bill List Without Policy"
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.Label2)
        Me.panelTotales.Controls.Add(Me.celdaTotalCostos)
        Me.panelTotales.Controls.Add(Me.etiquetaTotalVentas)
        Me.panelTotales.Controls.Add(Me.celdaTotalVentas)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(3, 223)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(507, 64)
        Me.panelTotales.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(268, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Total Cost"
        '
        'celdaTotalCostos
        '
        Me.celdaTotalCostos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalCostos.Location = New System.Drawing.Point(356, 17)
        Me.celdaTotalCostos.Name = "celdaTotalCostos"
        Me.celdaTotalCostos.ReadOnly = True
        Me.celdaTotalCostos.Size = New System.Drawing.Size(118, 22)
        Me.celdaTotalCostos.TabIndex = 15
        Me.celdaTotalCostos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotalVentas
        '
        Me.etiquetaTotalVentas.AutoSize = True
        Me.etiquetaTotalVentas.Location = New System.Drawing.Point(3, 20)
        Me.etiquetaTotalVentas.Name = "etiquetaTotalVentas"
        Me.etiquetaTotalVentas.Size = New System.Drawing.Size(90, 17)
        Me.etiquetaTotalVentas.TabIndex = 14
        Me.etiquetaTotalVentas.Text = "Total Sales"
        '
        'celdaTotalVentas
        '
        Me.celdaTotalVentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalVentas.Location = New System.Drawing.Point(98, 17)
        Me.celdaTotalVentas.Name = "celdaTotalVentas"
        Me.celdaTotalVentas.ReadOnly = True
        Me.celdaTotalVentas.Size = New System.Drawing.Size(118, 22)
        Me.celdaTotalVentas.TabIndex = 11
        Me.celdaTotalVentas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'dgFactSinPoliza
        '
        Me.dgFactSinPoliza.AllowUserToAddRows = False
        Me.dgFactSinPoliza.AllowUserToDeleteRows = False
        Me.dgFactSinPoliza.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFactSinPoliza.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactSinPoliza.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.dgFactSinPoliza.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactSinPoliza.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFactura, Me.colFecha, Me.colVenta, Me.colCosto})
        Me.dgFactSinPoliza.Location = New System.Drawing.Point(3, 21)
        Me.dgFactSinPoliza.Name = "dgFactSinPoliza"
        Me.dgFactSinPoliza.ReadOnly = True
        Me.dgFactSinPoliza.RowTemplate.Height = 24
        Me.dgFactSinPoliza.Size = New System.Drawing.Size(507, 202)
        Me.dgFactSinPoliza.TabIndex = 0
        '
        'colFactura
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.NullValue = Nothing
        Me.colFactura.DefaultCellStyle = DataGridViewCellStyle12
        Me.colFactura.HeaderText = "Invoice"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        '
        'colFecha
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colFecha.DefaultCellStyle = DataGridViewCellStyle13
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colVenta
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colVenta.DefaultCellStyle = DataGridViewCellStyle14
        Me.colVenta.HeaderText = "Sales"
        Me.colVenta.Name = "colVenta"
        Me.colVenta.ReadOnly = True
        '
        'colCosto
        '
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colCosto.DefaultCellStyle = DataGridViewCellStyle15
        Me.colCosto.HeaderText = "Cost"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        Me.colCosto.Width = 164
        '
        'gbResultados
        '
        Me.gbResultados.Controls.Add(Me.Panel1)
        Me.gbResultados.Controls.Add(Me.celdaIndicadorMO)
        Me.gbResultados.Controls.Add(Me.celdaIndicadorRealMO)
        Me.gbResultados.Controls.Add(Me.celdaProyeccionMB)
        Me.gbResultados.Controls.Add(Me.etiquetaProyeccion)
        Me.gbResultados.Controls.Add(Me.etiquetaIndicadorReal)
        Me.gbResultados.Controls.Add(Me.celdaIndicadorRealMB)
        Me.gbResultados.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbResultados.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbResultados.Location = New System.Drawing.Point(0, 0)
        Me.gbResultados.Name = "gbResultados"
        Me.gbResultados.Size = New System.Drawing.Size(513, 322)
        Me.gbResultados.TabIndex = 3
        Me.gbResultados.TabStop = False
        Me.gbResultados.Text = "Percentage of Indicators"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Info
        Me.Panel1.Location = New System.Drawing.Point(271, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(10, 302)
        Me.Panel1.TabIndex = 21
        '
        'celdaIndicadorMO
        '
        Me.celdaIndicadorMO.Location = New System.Drawing.Point(306, 195)
        Me.celdaIndicadorMO.Multiline = True
        Me.celdaIndicadorMO.Name = "celdaIndicadorMO"
        Me.celdaIndicadorMO.ReadOnly = True
        Me.celdaIndicadorMO.Size = New System.Drawing.Size(102, 41)
        Me.celdaIndicadorMO.TabIndex = 20
        Me.celdaIndicadorMO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaIndicadorRealMO
        '
        Me.celdaIndicadorRealMO.Location = New System.Drawing.Point(114, 195)
        Me.celdaIndicadorRealMO.Multiline = True
        Me.celdaIndicadorRealMO.Name = "celdaIndicadorRealMO"
        Me.celdaIndicadorRealMO.ReadOnly = True
        Me.celdaIndicadorRealMO.Size = New System.Drawing.Size(95, 41)
        Me.celdaIndicadorRealMO.TabIndex = 19
        Me.celdaIndicadorRealMO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaProyeccionMB
        '
        Me.celdaProyeccionMB.Location = New System.Drawing.Point(306, 116)
        Me.celdaProyeccionMB.Multiline = True
        Me.celdaProyeccionMB.Name = "celdaProyeccionMB"
        Me.celdaProyeccionMB.ReadOnly = True
        Me.celdaProyeccionMB.Size = New System.Drawing.Size(102, 37)
        Me.celdaProyeccionMB.TabIndex = 16
        Me.celdaProyeccionMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaProyeccion
        '
        Me.etiquetaProyeccion.AutoSize = True
        Me.etiquetaProyeccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaProyeccion.Location = New System.Drawing.Point(284, 62)
        Me.etiquetaProyeccion.Name = "etiquetaProyeccion"
        Me.etiquetaProyeccion.Size = New System.Drawing.Size(179, 29)
        Me.etiquetaProyeccion.TabIndex = 18
        Me.etiquetaProyeccion.Text = "PROJECTION"
        '
        'etiquetaIndicadorReal
        '
        Me.etiquetaIndicadorReal.AutoSize = True
        Me.etiquetaIndicadorReal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaIndicadorReal.Location = New System.Drawing.Point(6, 61)
        Me.etiquetaIndicadorReal.Name = "etiquetaIndicadorReal"
        Me.etiquetaIndicadorReal.Size = New System.Drawing.Size(225, 29)
        Me.etiquetaIndicadorReal.TabIndex = 17
        Me.etiquetaIndicadorReal.Text = "REAL INDICATOR"
        '
        'celdaIndicadorRealMB
        '
        Me.celdaIndicadorRealMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaIndicadorRealMB.Location = New System.Drawing.Point(114, 116)
        Me.celdaIndicadorRealMB.Multiline = True
        Me.celdaIndicadorRealMB.Name = "celdaIndicadorRealMB"
        Me.celdaIndicadorRealMB.ReadOnly = True
        Me.celdaIndicadorRealMB.Size = New System.Drawing.Size(95, 37)
        Me.celdaIndicadorRealMB.TabIndex = 15
        Me.celdaIndicadorRealMB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'panelProyeccion
        '
        Me.panelProyeccion.Controls.Add(Me.gbBotones)
        Me.panelProyeccion.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelProyeccion.Location = New System.Drawing.Point(0, 0)
        Me.panelProyeccion.Name = "panelProyeccion"
        Me.panelProyeccion.Size = New System.Drawing.Size(525, 618)
        Me.panelProyeccion.TabIndex = 4
        '
        'gbBotones
        '
        Me.gbBotones.Controls.Add(Me.celdaAnio)
        Me.gbBotones.Controls.Add(Me.etiquetaProyeccionMargenBruto)
        Me.gbBotones.Controls.Add(Me.celdaMargenBrutoProyeccion)
        Me.gbBotones.Controls.Add(Me.etiquetaDatoReal)
        Me.gbBotones.Controls.Add(Me.celdaMargenOpatativoProyeccion)
        Me.gbBotones.Controls.Add(Me.celdaMargenOperativo)
        Me.gbBotones.Controls.Add(Me.Label1)
        Me.gbBotones.Controls.Add(Me.etiquetaMargenBruto)
        Me.gbBotones.Controls.Add(Me.celdaMargenBruto)
        Me.gbBotones.Controls.Add(Me.etiquetaFecha)
        Me.gbBotones.Controls.Add(Me.etiquetaPeriodo)
        Me.gbBotones.Controls.Add(Me.botonPeriodo)
        Me.gbBotones.Controls.Add(Me.celdaPeriodo)
        Me.gbBotones.Controls.Add(Me.dtpFecha)
        Me.gbBotones.Controls.Add(Me.botonDatosInventario)
        Me.gbBotones.Controls.Add(Me.etiquetaProyecccionCostos)
        Me.gbBotones.Controls.Add(Me.etiquetaVentasProyeccion)
        Me.gbBotones.Controls.Add(Me.celdaProyeccionCostos)
        Me.gbBotones.Controls.Add(Me.celdaProyeccionVentas)
        Me.gbBotones.Controls.Add(Me.TextBox6)
        Me.gbBotones.Controls.Add(Me.celdaDescuentos)
        Me.gbBotones.Controls.Add(Me.celdaDevoluciones)
        Me.gbBotones.Controls.Add(Me.celdaCostoVentas)
        Me.gbBotones.Controls.Add(Me.celdacostosOperacion)
        Me.gbBotones.Controls.Add(Me.celdaVentas)
        Me.gbBotones.Controls.Add(Me.etiquetaIntereses)
        Me.gbBotones.Controls.Add(Me.etiquetaCostosOpeativos)
        Me.gbBotones.Controls.Add(Me.etiquetaCostoDeVenta)
        Me.gbBotones.Controls.Add(Me.etiquetaDevoluciones)
        Me.gbBotones.Controls.Add(Me.etiquetaDescuentos)
        Me.gbBotones.Controls.Add(Me.etiquetaVentas)
        Me.gbBotones.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbBotones.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbBotones.Location = New System.Drawing.Point(0, 0)
        Me.gbBotones.Name = "gbBotones"
        Me.gbBotones.Size = New System.Drawing.Size(519, 618)
        Me.gbBotones.TabIndex = 2
        Me.gbBotones.TabStop = False
        Me.gbBotones.Text = "Inventory data"
        '
        'etiquetaProyeccionMargenBruto
        '
        Me.etiquetaProyeccionMargenBruto.AutoSize = True
        Me.etiquetaProyeccionMargenBruto.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaProyeccionMargenBruto.Location = New System.Drawing.Point(321, 442)
        Me.etiquetaProyeccionMargenBruto.Name = "etiquetaProyeccionMargenBruto"
        Me.etiquetaProyeccionMargenBruto.Size = New System.Drawing.Size(106, 17)
        Me.etiquetaProyeccionMargenBruto.TabIndex = 29
        Me.etiquetaProyeccionMargenBruto.Text = "PROJECTION"
        '
        'celdaMargenBrutoProyeccion
        '
        Me.celdaMargenBrutoProyeccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMargenBrutoProyeccion.Location = New System.Drawing.Point(310, 462)
        Me.celdaMargenBrutoProyeccion.Name = "celdaMargenBrutoProyeccion"
        Me.celdaMargenBrutoProyeccion.ReadOnly = True
        Me.celdaMargenBrutoProyeccion.Size = New System.Drawing.Size(118, 23)
        Me.celdaMargenBrutoProyeccion.TabIndex = 28
        Me.celdaMargenBrutoProyeccion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaDatoReal
        '
        Me.etiquetaDatoReal.AutoSize = True
        Me.etiquetaDatoReal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDatoReal.Location = New System.Drawing.Point(171, 442)
        Me.etiquetaDatoReal.Name = "etiquetaDatoReal"
        Me.etiquetaDatoReal.Size = New System.Drawing.Size(94, 17)
        Me.etiquetaDatoReal.TabIndex = 27
        Me.etiquetaDatoReal.Text = "REAL DATA"
        '
        'celdaMargenOpatativoProyeccion
        '
        Me.celdaMargenOpatativoProyeccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMargenOpatativoProyeccion.Location = New System.Drawing.Point(310, 517)
        Me.celdaMargenOpatativoProyeccion.Name = "celdaMargenOpatativoProyeccion"
        Me.celdaMargenOpatativoProyeccion.ReadOnly = True
        Me.celdaMargenOpatativoProyeccion.Size = New System.Drawing.Size(118, 23)
        Me.celdaMargenOpatativoProyeccion.TabIndex = 26
        Me.celdaMargenOpatativoProyeccion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaMargenOperativo
        '
        Me.celdaMargenOperativo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMargenOperativo.Location = New System.Drawing.Point(168, 517)
        Me.celdaMargenOperativo.Name = "celdaMargenOperativo"
        Me.celdaMargenOperativo.ReadOnly = True
        Me.celdaMargenOperativo.Size = New System.Drawing.Size(118, 23)
        Me.celdaMargenOperativo.TabIndex = 25
        Me.celdaMargenOperativo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 520)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(134, 17)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Operating Margin"
        '
        'etiquetaMargenBruto
        '
        Me.etiquetaMargenBruto.AutoSize = True
        Me.etiquetaMargenBruto.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaMargenBruto.Location = New System.Drawing.Point(28, 467)
        Me.etiquetaMargenBruto.Name = "etiquetaMargenBruto"
        Me.etiquetaMargenBruto.Size = New System.Drawing.Size(105, 17)
        Me.etiquetaMargenBruto.TabIndex = 22
        Me.etiquetaMargenBruto.Text = "Gross Margin"
        '
        'celdaMargenBruto
        '
        Me.celdaMargenBruto.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMargenBruto.Location = New System.Drawing.Point(168, 462)
        Me.celdaMargenBruto.Name = "celdaMargenBruto"
        Me.celdaMargenBruto.ReadOnly = True
        Me.celdaMargenBruto.Size = New System.Drawing.Size(118, 23)
        Me.celdaMargenBruto.TabIndex = 23
        Me.celdaMargenBruto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaFecha.Location = New System.Drawing.Point(234, 248)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(77, 17)
        Me.etiquetaFecha.TabIndex = 21
        Me.etiquetaFecha.Text = "DeadLine"
        '
        'etiquetaPeriodo
        '
        Me.etiquetaPeriodo.AutoSize = True
        Me.etiquetaPeriodo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaPeriodo.Location = New System.Drawing.Point(236, 206)
        Me.etiquetaPeriodo.Name = "etiquetaPeriodo"
        Me.etiquetaPeriodo.Size = New System.Drawing.Size(55, 17)
        Me.etiquetaPeriodo.TabIndex = 20
        Me.etiquetaPeriodo.Text = "Period"
        '
        'botonPeriodo
        '
        Me.botonPeriodo.Location = New System.Drawing.Point(390, 203)
        Me.botonPeriodo.Name = "botonPeriodo"
        Me.botonPeriodo.Size = New System.Drawing.Size(47, 22)
        Me.botonPeriodo.TabIndex = 19
        Me.botonPeriodo.Text = "..."
        Me.botonPeriodo.UseVisualStyleBackColor = True
        '
        'celdaPeriodo
        '
        Me.celdaPeriodo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaPeriodo.Location = New System.Drawing.Point(300, 175)
        Me.celdaPeriodo.Name = "celdaPeriodo"
        Me.celdaPeriodo.ReadOnly = True
        Me.celdaPeriodo.Size = New System.Drawing.Size(84, 23)
        Me.celdaPeriodo.TabIndex = 18
        Me.celdaPeriodo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.celdaPeriodo.Visible = False
        '
        'dtpFecha
        '
        Me.dtpFecha.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(317, 243)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(127, 23)
        Me.dtpFecha.TabIndex = 17
        '
        'botonDatosInventario
        '
        Me.botonDatosInventario.Image = Global.KARIMs_SGI.My.Resources.Resources.reload
        Me.botonDatosInventario.Location = New System.Drawing.Point(280, 305)
        Me.botonDatosInventario.Name = "botonDatosInventario"
        Me.botonDatosInventario.Size = New System.Drawing.Size(125, 43)
        Me.botonDatosInventario.TabIndex = 12
        Me.botonDatosInventario.UseVisualStyleBackColor = True
        '
        'etiquetaProyecccionCostos
        '
        Me.etiquetaProyecccionCostos.AutoSize = True
        Me.etiquetaProyecccionCostos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaProyecccionCostos.Location = New System.Drawing.Point(243, 115)
        Me.etiquetaProyecccionCostos.Name = "etiquetaProyecccionCostos"
        Me.etiquetaProyecccionCostos.Size = New System.Drawing.Size(118, 17)
        Me.etiquetaProyecccionCostos.TabIndex = 16
        Me.etiquetaProyecccionCostos.Text = "Projection Cost"
        '
        'etiquetaVentasProyeccion
        '
        Me.etiquetaVentasProyeccion.AutoSize = True
        Me.etiquetaVentasProyeccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaVentasProyeccion.Location = New System.Drawing.Point(236, 48)
        Me.etiquetaVentasProyeccion.Name = "etiquetaVentasProyeccion"
        Me.etiquetaVentasProyeccion.Size = New System.Drawing.Size(126, 17)
        Me.etiquetaVentasProyeccion.TabIndex = 15
        Me.etiquetaVentasProyeccion.Text = "Sales Projection"
        '
        'celdaProyeccionCostos
        '
        Me.celdaProyeccionCostos.BackColor = System.Drawing.Color.RoyalBlue
        Me.celdaProyeccionCostos.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaProyeccionCostos.Location = New System.Drawing.Point(239, 135)
        Me.celdaProyeccionCostos.Multiline = True
        Me.celdaProyeccionCostos.Name = "celdaProyeccionCostos"
        Me.celdaProyeccionCostos.ReadOnly = True
        Me.celdaProyeccionCostos.Size = New System.Drawing.Size(220, 34)
        Me.celdaProyeccionCostos.TabIndex = 14
        Me.celdaProyeccionCostos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaProyeccionVentas
        '
        Me.celdaProyeccionVentas.BackColor = System.Drawing.Color.LightGreen
        Me.celdaProyeccionVentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaProyeccionVentas.Location = New System.Drawing.Point(239, 69)
        Me.celdaProyeccionVentas.Multiline = True
        Me.celdaProyeccionVentas.Name = "celdaProyeccionVentas"
        Me.celdaProyeccionVentas.ReadOnly = True
        Me.celdaProyeccionVentas.Size = New System.Drawing.Size(220, 32)
        Me.celdaProyeccionVentas.TabIndex = 13
        Me.celdaProyeccionVentas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(28, 325)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(153, 23)
        Me.TextBox6.TabIndex = 11
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaDescuentos
        '
        Me.celdaDescuentos.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.celdaDescuentos.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDescuentos.Location = New System.Drawing.Point(28, 393)
        Me.celdaDescuentos.Name = "celdaDescuentos"
        Me.celdaDescuentos.ReadOnly = True
        Me.celdaDescuentos.Size = New System.Drawing.Size(153, 23)
        Me.celdaDescuentos.TabIndex = 10
        Me.celdaDescuentos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaDevoluciones
        '
        Me.celdaDevoluciones.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.celdaDevoluciones.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaDevoluciones.Location = New System.Drawing.Point(28, 195)
        Me.celdaDevoluciones.Name = "celdaDevoluciones"
        Me.celdaDevoluciones.ReadOnly = True
        Me.celdaDevoluciones.Size = New System.Drawing.Size(153, 23)
        Me.celdaDevoluciones.TabIndex = 9
        Me.celdaDevoluciones.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaCostoVentas
        '
        Me.celdaCostoVentas.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.celdaCostoVentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCostoVentas.Location = New System.Drawing.Point(28, 135)
        Me.celdaCostoVentas.Name = "celdaCostoVentas"
        Me.celdaCostoVentas.ReadOnly = True
        Me.celdaCostoVentas.Size = New System.Drawing.Size(153, 23)
        Me.celdaCostoVentas.TabIndex = 8
        Me.celdaCostoVentas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdacostosOperacion
        '
        Me.celdacostosOperacion.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.celdacostosOperacion.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdacostosOperacion.Location = New System.Drawing.Point(28, 263)
        Me.celdacostosOperacion.Name = "celdacostosOperacion"
        Me.celdacostosOperacion.ReadOnly = True
        Me.celdacostosOperacion.Size = New System.Drawing.Size(153, 23)
        Me.celdacostosOperacion.TabIndex = 7
        Me.celdacostosOperacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaVentas
        '
        Me.celdaVentas.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.celdaVentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaVentas.Location = New System.Drawing.Point(28, 68)
        Me.celdaVentas.Name = "celdaVentas"
        Me.celdaVentas.ReadOnly = True
        Me.celdaVentas.Size = New System.Drawing.Size(153, 23)
        Me.celdaVentas.TabIndex = 6
        Me.celdaVentas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaIntereses
        '
        Me.etiquetaIntereses.AutoSize = True
        Me.etiquetaIntereses.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaIntereses.Location = New System.Drawing.Point(30, 305)
        Me.etiquetaIntereses.Name = "etiquetaIntereses"
        Me.etiquetaIntereses.Size = New System.Drawing.Size(71, 17)
        Me.etiquetaIntereses.TabIndex = 5
        Me.etiquetaIntereses.Text = "Interests"
        '
        'etiquetaCostosOpeativos
        '
        Me.etiquetaCostosOpeativos.AutoSize = True
        Me.etiquetaCostosOpeativos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCostosOpeativos.Location = New System.Drawing.Point(30, 243)
        Me.etiquetaCostosOpeativos.Name = "etiquetaCostosOpeativos"
        Me.etiquetaCostosOpeativos.Size = New System.Drawing.Size(117, 17)
        Me.etiquetaCostosOpeativos.TabIndex = 4
        Me.etiquetaCostosOpeativos.Text = "Operating Cost"
        '
        'etiquetaCostoDeVenta
        '
        Me.etiquetaCostoDeVenta.AutoSize = True
        Me.etiquetaCostoDeVenta.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCostoDeVenta.Location = New System.Drawing.Point(30, 115)
        Me.etiquetaCostoDeVenta.Name = "etiquetaCostoDeVenta"
        Me.etiquetaCostoDeVenta.Size = New System.Drawing.Size(85, 17)
        Me.etiquetaCostoDeVenta.TabIndex = 3
        Me.etiquetaCostoDeVenta.Text = "Sales Cost"
        '
        'etiquetaDevoluciones
        '
        Me.etiquetaDevoluciones.AutoSize = True
        Me.etiquetaDevoluciones.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDevoluciones.Location = New System.Drawing.Point(30, 175)
        Me.etiquetaDevoluciones.Name = "etiquetaDevoluciones"
        Me.etiquetaDevoluciones.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaDevoluciones.TabIndex = 2
        Me.etiquetaDevoluciones.Text = "Returns"
        '
        'etiquetaDescuentos
        '
        Me.etiquetaDescuentos.AutoSize = True
        Me.etiquetaDescuentos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDescuentos.Location = New System.Drawing.Point(30, 373)
        Me.etiquetaDescuentos.Name = "etiquetaDescuentos"
        Me.etiquetaDescuentos.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescuentos.TabIndex = 1
        Me.etiquetaDescuentos.Text = "Discounts"
        '
        'etiquetaVentas
        '
        Me.etiquetaVentas.AutoSize = True
        Me.etiquetaVentas.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaVentas.Location = New System.Drawing.Point(30, 48)
        Me.etiquetaVentas.Name = "etiquetaVentas"
        Me.etiquetaVentas.Size = New System.Drawing.Size(48, 17)
        Me.etiquetaVentas.TabIndex = 0
        Me.etiquetaVentas.Text = "Sales"
        '
        'celdaAnio
        '
        Me.celdaAnio.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAnio.Location = New System.Drawing.Point(300, 202)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(84, 22)
        Me.celdaAnio.TabIndex = 30
        Me.celdaAnio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frmMargen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1041, 618)
        Me.Controls.Add(Me.panelPrincipal)
        Me.MaximizeBox = False
        Me.Name = "frmMargen"
        Me.Text = "frmMargen"
        Me.panelPrincipal.ResumeLayout(False)
        Me.panelResultados.ResumeLayout(False)
        Me.gdFacturas.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        CType(Me.dgFactSinPoliza, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbResultados.ResumeLayout(False)
        Me.gbResultados.PerformLayout()
        Me.panelProyeccion.ResumeLayout(False)
        Me.gbBotones.ResumeLayout(False)
        Me.gbBotones.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelPrincipal As System.Windows.Forms.Panel
    Friend WithEvents gbResultados As System.Windows.Forms.GroupBox
    Friend WithEvents gbBotones As System.Windows.Forms.GroupBox
    Friend WithEvents botonDatosInventario As System.Windows.Forms.Button
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescuentos As System.Windows.Forms.TextBox
    Friend WithEvents celdaDevoluciones As System.Windows.Forms.TextBox
    Friend WithEvents celdaCostoVentas As System.Windows.Forms.TextBox
    Friend WithEvents celdacostosOperacion As System.Windows.Forms.TextBox
    Friend WithEvents celdaVentas As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaIntereses As System.Windows.Forms.Label
    Friend WithEvents etiquetaCostosOpeativos As System.Windows.Forms.Label
    Friend WithEvents etiquetaCostoDeVenta As System.Windows.Forms.Label
    Friend WithEvents etiquetaDevoluciones As System.Windows.Forms.Label
    Friend WithEvents etiquetaDescuentos As System.Windows.Forms.Label
    Friend WithEvents etiquetaVentas As System.Windows.Forms.Label
    Friend WithEvents panelResultados As System.Windows.Forms.Panel
    Friend WithEvents panelProyeccion As System.Windows.Forms.Panel
    Friend WithEvents etiquetaProyecccionCostos As System.Windows.Forms.Label
    Friend WithEvents etiquetaVentasProyeccion As System.Windows.Forms.Label
    Friend WithEvents celdaProyeccionCostos As System.Windows.Forms.TextBox
    Friend WithEvents celdaProyeccionVentas As System.Windows.Forms.TextBox
    Friend WithEvents gdFacturas As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaTotalVentas As System.Windows.Forms.Label
    Friend WithEvents celdaTotalVentas As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProyeccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaIndicadorReal As System.Windows.Forms.Label
    Friend WithEvents celdaProyeccionMB As System.Windows.Forms.TextBox
    Friend WithEvents celdaIndicadorRealMB As System.Windows.Forms.TextBox
    Friend WithEvents panelTotales As System.Windows.Forms.Panel
    Friend WithEvents dgFactSinPoliza As System.Windows.Forms.DataGridView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaTotalCostos As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaPeriodo As System.Windows.Forms.Label
    Friend WithEvents botonPeriodo As System.Windows.Forms.Button
    Friend WithEvents celdaPeriodo As System.Windows.Forms.TextBox
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaIndicadorMO As System.Windows.Forms.TextBox
    Friend WithEvents celdaIndicadorRealMO As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaProyeccionMargenBruto As System.Windows.Forms.Label
    Friend WithEvents celdaMargenBrutoProyeccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDatoReal As System.Windows.Forms.Label
    Friend WithEvents celdaMargenOpatativoProyeccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaMargenOperativo As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents etiquetaMargenBruto As System.Windows.Forms.Label
    Friend WithEvents celdaMargenBruto As System.Windows.Forms.TextBox
    Friend WithEvents colFactura As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colVenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents celdaAnio As TextBox
End Class
