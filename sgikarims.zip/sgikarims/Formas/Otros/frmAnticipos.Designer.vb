﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAnticipos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAnticipos))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLIsta = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.ColAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColTitle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ColEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgLiquidacion = New System.Windows.Forms.DataGridView()
        Me.colAnioLiquidacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroLiquidacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaLiquidacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraLiquidacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelProveedor = New System.Windows.Forms.Panel()
        Me.celdaTipoAnticipo = New System.Windows.Forms.TextBox()
        Me.checkContabilidad = New System.Windows.Forms.CheckBox()
        Me.botonPolizaContable = New System.Windows.Forms.Button()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaTitulo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumerof = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCaja = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLIsta.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgLiquidacion, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelProveedor.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLIsta
        '
        Me.panelLIsta.Controls.Add(Me.dgLista)
        Me.panelLIsta.Controls.Add(Me.panelFiltro)
        Me.panelLIsta.Location = New System.Drawing.Point(13, 123)
        Me.panelLIsta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelLIsta.Name = "panelLIsta"
        Me.panelLIsta.Size = New System.Drawing.Size(693, 117)
        Me.panelLIsta.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ColAnio, Me.ColId, Me.ColDate, Me.ColTitle, Me.ColMonto, Me.ColEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 101)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(693, 16)
        Me.dgLista.TabIndex = 1
        '
        'ColAnio
        '
        Me.ColAnio.HeaderText = "Year"
        Me.ColAnio.Name = "ColAnio"
        Me.ColAnio.ReadOnly = True
        Me.ColAnio.Width = 67
        '
        'ColId
        '
        Me.ColId.HeaderText = "ID"
        Me.ColId.Name = "ColId"
        Me.ColId.ReadOnly = True
        Me.ColId.Width = 50
        '
        'ColDate
        '
        Me.ColDate.HeaderText = "Date"
        Me.ColDate.Name = "ColDate"
        Me.ColDate.ReadOnly = True
        Me.ColDate.Width = 67
        '
        'ColTitle
        '
        Me.ColTitle.HeaderText = "Title"
        Me.ColTitle.Name = "ColTitle"
        Me.ColTitle.ReadOnly = True
        Me.ColTitle.Width = 64
        '
        'ColMonto
        '
        Me.ColMonto.HeaderText = "Amount"
        Me.ColMonto.Name = "ColMonto"
        Me.ColMonto.ReadOnly = True
        Me.ColMonto.Width = 85
        '
        'ColEstado
        '
        Me.ColEstado.HeaderText = "Status"
        Me.ColEstado.Name = "ColEstado"
        Me.ColEstado.ReadOnly = True
        Me.ColEstado.Width = 77
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.GroupBox1)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(693, 101)
        Me.panelFiltro.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonFiltrar)
        Me.GroupBox1.Controls.Add(Me.dtpFin)
        Me.GroupBox1.Controls.Add(Me.dtpInicio)
        Me.GroupBox1.Controls.Add(Me.checkFechas)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(693, 101)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filter By:"
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(283, 50)
        Me.botonFiltrar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(100, 28)
        Me.botonFiltrar.TabIndex = 3
        Me.botonFiltrar.Text = "Filtered"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(145, 50)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(128, 22)
        Me.dtpFin.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(8, 50)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(128, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(8, 23)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(106, 21)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Date Range" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel1)
        Me.panelDocumento.Controls.Add(Me.panelProveedor)
        Me.panelDocumento.Location = New System.Drawing.Point(13, 249)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(691, 356)
        Me.panelDocumento.TabIndex = 5
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dgLiquidacion)
        Me.Panel1.Controls.Add(Me.dgDetalle)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 241)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(691, 115)
        Me.Panel1.TabIndex = 2
        '
        'dgLiquidacion
        '
        Me.dgLiquidacion.AllowUserToAddRows = False
        Me.dgLiquidacion.AllowUserToDeleteRows = False
        Me.dgLiquidacion.AllowUserToOrderColumns = True
        Me.dgLiquidacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLiquidacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnioLiquidacion, Me.colNumeroLiquidacion, Me.colLineaLiquidacion, Me.colExtraLiquidacion})
        Me.dgLiquidacion.Location = New System.Drawing.Point(380, 66)
        Me.dgLiquidacion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgLiquidacion.Name = "dgLiquidacion"
        Me.dgLiquidacion.RowTemplate.Height = 24
        Me.dgLiquidacion.Size = New System.Drawing.Size(240, 150)
        Me.dgLiquidacion.TabIndex = 3
        Me.dgLiquidacion.Visible = False
        '
        'colAnioLiquidacion
        '
        Me.colAnioLiquidacion.HeaderText = "Anio"
        Me.colAnioLiquidacion.Name = "colAnioLiquidacion"
        '
        'colNumeroLiquidacion
        '
        Me.colNumeroLiquidacion.HeaderText = "Numero"
        Me.colNumeroLiquidacion.Name = "colNumeroLiquidacion"
        '
        'colLineaLiquidacion
        '
        Me.colLineaLiquidacion.HeaderText = "Linea"
        Me.colLineaLiquidacion.Name = "colLineaLiquidacion"
        '
        'colExtraLiquidacion
        '
        Me.colExtraLiquidacion.HeaderText = "Extra"
        Me.colExtraLiquidacion.Name = "colExtraLiquidacion"
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAno, Me.colNumero, Me.colFecha, Me.colNumerof, Me.colProveedor, Me.colMoneda, Me.colSaldo, Me.colMarca, Me.colCaja, Me.colTipo, Me.colLinea, Me.colCta})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(628, 115)
        Me.dgDetalle.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonQuitar)
        Me.Panel2.Controls.Add(Me.botonAgregar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(628, 0)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(63, 115)
        Me.Panel2.TabIndex = 2
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(13, 47)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(35, 30)
        Me.botonQuitar.TabIndex = 0
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(13, 10)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(35, 30)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelProveedor
        '
        Me.panelProveedor.Controls.Add(Me.celdaTipoAnticipo)
        Me.panelProveedor.Controls.Add(Me.checkContabilidad)
        Me.panelProveedor.Controls.Add(Me.botonPolizaContable)
        Me.panelProveedor.Controls.Add(Me.celdaTotal)
        Me.panelProveedor.Controls.Add(Me.Label9)
        Me.panelProveedor.Controls.Add(Me.botonMoneda)
        Me.panelProveedor.Controls.Add(Me.celdaidMoneda)
        Me.panelProveedor.Controls.Add(Me.celdaMoneda)
        Me.panelProveedor.Controls.Add(Me.celdaTasa)
        Me.panelProveedor.Controls.Add(Me.Label7)
        Me.panelProveedor.Controls.Add(Me.Label6)
        Me.panelProveedor.Controls.Add(Me.celdaDescripcion)
        Me.panelProveedor.Controls.Add(Me.Label5)
        Me.panelProveedor.Controls.Add(Me.checkActivo)
        Me.panelProveedor.Controls.Add(Me.dtpFecha)
        Me.panelProveedor.Controls.Add(Me.Label4)
        Me.panelProveedor.Controls.Add(Me.celdaAño)
        Me.panelProveedor.Controls.Add(Me.Label3)
        Me.panelProveedor.Controls.Add(Me.celdaID)
        Me.panelProveedor.Controls.Add(Me.Label2)
        Me.panelProveedor.Controls.Add(Me.celdaTitulo)
        Me.panelProveedor.Controls.Add(Me.Label1)
        Me.panelProveedor.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelProveedor.Location = New System.Drawing.Point(0, 0)
        Me.panelProveedor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelProveedor.Name = "panelProveedor"
        Me.panelProveedor.Size = New System.Drawing.Size(691, 241)
        Me.panelProveedor.TabIndex = 0
        '
        'celdaTipoAnticipo
        '
        Me.celdaTipoAnticipo.Location = New System.Drawing.Point(445, 214)
        Me.celdaTipoAnticipo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTipoAnticipo.Name = "celdaTipoAnticipo"
        Me.celdaTipoAnticipo.Size = New System.Drawing.Size(59, 22)
        Me.celdaTipoAnticipo.TabIndex = 5
        Me.celdaTipoAnticipo.Visible = False
        '
        'checkContabilidad
        '
        Me.checkContabilidad.AutoSize = True
        Me.checkContabilidad.Checked = True
        Me.checkContabilidad.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkContabilidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkContabilidad.ForeColor = System.Drawing.SystemColors.Highlight
        Me.checkContabilidad.Location = New System.Drawing.Point(265, 27)
        Me.checkContabilidad.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkContabilidad.Name = "checkContabilidad"
        Me.checkContabilidad.Size = New System.Drawing.Size(113, 22)
        Me.checkContabilidad.TabIndex = 31
        Me.checkContabilidad.Text = "Accounting"
        Me.checkContabilidad.UseVisualStyleBackColor = True
        '
        'botonPolizaContable
        '
        Me.botonPolizaContable.Image = CType(resources.GetObject("botonPolizaContable.Image"), System.Drawing.Image)
        Me.botonPolizaContable.Location = New System.Drawing.Point(392, 206)
        Me.botonPolizaContable.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonPolizaContable.Name = "botonPolizaContable"
        Me.botonPolizaContable.Size = New System.Drawing.Size(35, 31)
        Me.botonPolizaContable.TabIndex = 30
        Me.botonPolizaContable.UseVisualStyleBackColor = True
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.Location = New System.Drawing.Point(541, 86)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(132, 26)
        Me.celdaTotal.TabIndex = 29
        '
        'Label9
        '
        Me.Label9.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(595, 65)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 17)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "Total"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(123, 213)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(49, 23)
        Me.botonMoneda.TabIndex = 27
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(29, 215)
        Me.celdaidMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.ReadOnly = True
        Me.celdaidMoneda.Size = New System.Drawing.Size(87, 22)
        Me.celdaidMoneda.TabIndex = 26
        '
        'celdaMoneda
        '
        Me.celdaMoneda.AutoSize = True
        Me.celdaMoneda.Location = New System.Drawing.Point(323, 74)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(21, 17)
        Me.celdaMoneda.TabIndex = 20
        Me.celdaMoneda.Text = "-1"
        Me.celdaMoneda.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(229, 213)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(132, 22)
        Me.celdaTasa.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(261, 193)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 17)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Exchange Rate"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 193)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 17)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Currency"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDescripcion.Location = New System.Drawing.Point(31, 167)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(643, 22)
        Me.celdaDescripcion.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 146)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 17)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Description"
        '
        'checkActivo
        '
        Me.checkActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(598, 16)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(78, 21)
        Me.checkActivo.TabIndex = 10
        Me.checkActivo.Text = "ACTIVE"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(33, 74)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(151, 22)
        Me.dtpFecha.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 55)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 17)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "DATE"
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAño.Location = New System.Drawing.Point(109, 27)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(75, 22)
        Me.celdaAño.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(123, 7)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "YEAR"
        '
        'celdaID
        '
        Me.celdaID.BackColor = System.Drawing.SystemColors.Info
        Me.celdaID.Location = New System.Drawing.Point(33, 27)
        Me.celdaID.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaID.Name = "celdaID"
        Me.celdaID.ReadOnly = True
        Me.celdaID.Size = New System.Drawing.Size(75, 22)
        Me.celdaID.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 7)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 17)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "ID Advances"
        '
        'celdaTitulo
        '
        Me.celdaTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTitulo.Location = New System.Drawing.Point(29, 121)
        Me.celdaTitulo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTitulo.Name = "celdaTitulo"
        Me.celdaTitulo.Size = New System.Drawing.Size(643, 22)
        Me.celdaTitulo.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 102)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Title"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 78)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(716, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(716, 78)
        Me.Encabezado1.TabIndex = 0
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 93
        '
        'colAno
        '
        Me.colAno.HeaderText = "Ano"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        Me.colAno.Width = 62
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Numero"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Visible = False
        Me.colNumero.Width = 87
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colNumerof
        '
        Me.colNumerof.HeaderText = "Number"
        Me.colNumerof.Name = "colNumerof"
        Me.colNumerof.ReadOnly = True
        Me.colNumerof.Width = 87
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Vendor"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        Me.colProveedor.Width = 83
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Currency"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        Me.colMoneda.Width = 94
        '
        'colSaldo
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.Format = "N2"
        DataGridViewCellStyle1.NullValue = Nothing
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Info
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.colSaldo.DefaultCellStyle = DataGridViewCellStyle1
        Me.colSaldo.HeaderText = "Amount"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.Width = 85
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "marca"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Visible = False
        Me.colMarca.Width = 76
        '
        'colCaja
        '
        Me.colCaja.HeaderText = "NumeroCaja"
        Me.colCaja.Name = "colCaja"
        Me.colCaja.Visible = False
        Me.colCaja.Width = 115
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Width = 69
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 72
        '
        'colCta
        '
        Me.colCta.HeaderText = "Account"
        Me.colCta.Name = "colCta"
        Me.colCta.ReadOnly = True
        Me.colCta.Width = 88
        '
        'frmAnticipos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(716, 609)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLIsta)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmAnticipos"
        Me.Text = " "
        Me.panelLIsta.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgLiquidacion, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelProveedor.ResumeLayout(False)
        Me.panelProveedor.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLIsta As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents botonFiltrar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents Panel2 As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelProveedor As Panel
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents celdaMoneda As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaID As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaTitulo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents botonPolizaContable As Button
    Friend WithEvents ColAnio As DataGridViewTextBoxColumn
    Friend WithEvents ColId As DataGridViewTextBoxColumn
    Friend WithEvents ColDate As DataGridViewTextBoxColumn
    Friend WithEvents ColTitle As DataGridViewTextBoxColumn
    Friend WithEvents ColMonto As DataGridViewTextBoxColumn
    Friend WithEvents ColEstado As DataGridViewTextBoxColumn
    Friend WithEvents checkContabilidad As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTipoAnticipo As TextBox
    Friend WithEvents dgLiquidacion As DataGridView
    Friend WithEvents colAnioLiquidacion As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroLiquidacion As DataGridViewTextBoxColumn
    Friend WithEvents colLineaLiquidacion As DataGridViewTextBoxColumn
    Friend WithEvents colExtraLiquidacion As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNumerof As DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colCaja As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colCta As DataGridViewTextBoxColumn
End Class
