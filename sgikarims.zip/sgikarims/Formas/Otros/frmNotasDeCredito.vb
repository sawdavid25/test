﻿Imports System.Xml
Imports System.IO
Imports System.Xml.XmlText
Imports System.Xml.XmlDataDocument
Imports System.Threading
Public Class frmNotasDeCredito

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim intTipo As Integer
    Dim IntCalcularImpuesto As Integer = NO_FILA
    Dim Cat As Integer = vbEmpty
    Dim cfun As New clsFunciones

    'CONSTANTES
    Private Const STR_IVA As String = "IVA"
    Private Const CXC_NAME As String = "Nota de crédito"
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"

    'Tipo de empresa asociada a l documento
    Private Const STR_TABLA As String = "Clientes"
    Private strPaisCliente As String = STR_VACIO
    Private strNitCliente As String = STR_VACIO

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
                botonPrevio.Visible = True
                etiquetaSerie.Visible = False
                etiquetaAutorizacion.Visible = False
            Else
                botonPrevio.Visible = False
            End If
            botonPrevio.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
                botonPrevio.Visible = True
                botonPrevio.Enabled = True
                etiquetaSerie.Visible = False
                etiquetaAutorizacion.Visible = False
            Else
                botonPrevio.Visible = False
            End If
        End If
    End Sub

    'Limpia todos los campos y datagrid's del panel de Fcaturacion
    Private Sub LimpiarFormulario()
        celdaAño.Text = NO_FILA
        celdaNumero.Text = NO_FILA
        celdaTemporal.Text = NO_FILA
        If Sesion.IdEmpresa = 10 Then
            celdaNumero.Visible = True
            celdaTemporal.Visible = False
        End If
        celdaCatalogoCAI.Text = INT_CERO
        celdaEmpresa.Text = NO_FILA
        celdaUsuario.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaIDCliente.Text = NO_FILA
        celdaDireccion.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIDMoneda.Text = NO_FILA
        celdaTasa.Text = NO_FILA
        celdaSubTotal.Text = vbEmpty
        celdaTotal.Text = vbEmpty
        celdaTasaFactura.Text = STR_VACIO
        celdaDeclaracion.Text = STR_VACIO
        celdaCatalogo.Text = NO_FILA
        CeldaTotalEnLetras.Text = STR_VACIO
        celdaNIT.Text = STR_VACIO
        celdaTelefono.Text = STR_VACIO
        celdaCAI.Text = STR_VACIO
        celdaSerie1.Text = STR_VACIO
        celdaNotasObservaciones.Text = STR_VACIO
        dgFacturacion.Rows.Clear()
        dgDetalle.Rows.Clear()
        dgImpuestos.Rows.Clear()
        dgDetalleNC.Rows.Clear()

        celdaSeriFelServi.Clear()
        celdaNumeroFelServi.Clear()

        celdaSerieFel.Text = STR_VACIO
        celdaFechaEmisionDocumento.Text = STR_VACIO
        celdaFechaHoraCertificacion.Text = STR_VACIO
        celdaUUID.Text = STR_VACIO
        etiquetaSerie.Text = STR_VACIO
        etiquetaAutorizacion.Text = STR_VACIO
        checkRevisado.Checked = False
        checkActivar.Checked = True
        checkFacturaFiscal.Checked = False
        celdaImpuesto.Text = INT_CERO
        celdaExepcion.Text = INT_CERO
        celdaSub.Text = INT_CERO
        celdaGiro.Text = STR_VACIO
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo(" Credit Note ")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            queryListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("CREDIT NOTE")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("CREDIT NOTE")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom nombre, h.HDoc_Emp_Per contacto, COALESCE(h.HDoc_DR1_Num,'') referencia, h.HDoc_Doc_Status estado, h.HDoc_DR1_Dbl num, IFNULL(f.Serie,'') Serie, IFNULL(f.NumeroAutorizacion,'') Autorizacion, IF(e.ECta_Ref_Cat=36,o.HDoc_DR1_Dbl,o.HDoc_DR2_Cat) Invoice "
        strsql &= "  FROM Dcmtos_HDR h "
        strsql &= "     LEFT JOIN Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Catalogo = h.HDoc_Doc_Cat AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_Doc_Num  "
        strsql &= "         LEFT JOIN ECtaCte e ON e.ECta_Sis_Emp = h.HDoc_Sis_Emp AND e.ECta_Doc_Cat = h.HDoc_Doc_Cat AND e.ECta_Doc_Ano = h.HDoc_Doc_Ano AND e.ECta_Doc_Num = h.HDoc_Doc_Num "
        strsql &= "             LEFT JOIN Dcmtos_HDR o ON o.HDoc_Sis_Emp = e.ECta_Sis_Emp AND o.HDoc_Doc_Cat = e.ECta_Ref_Cat AND o.HDoc_Doc_Ano = e.ECta_Ref_Ano AND o.HDoc_Doc_Num = e.ECta_Ref_Num "
        strsql &= "   WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=31"


        If checkFecha.Checked = True Then

            strsql &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "   GROUP BY h.HDoc_Doc_Ano, h.HDoc_Doc_Num  ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC "
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Dim e As Integer
        'Dim Lista As DataGridView

        strSQL = SQLlista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()
                If (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 14 And Pais() = 327) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Or Sesion.idGiro = 2 Then
                    dgLista.Columns(2).Visible = False
                    dgLista.Columns(7).Visible = False
                    dgLista.Columns(8).Visible = False
                ElseIf Sesion.IdEmpresa = 10 Then
                    dgLista.Columns(1).Visible = False
                    dgLista.Columns(7).Visible = True
                    dgLista.Columns(8).Visible = True
                Else
                    dgLista.Columns(1).Visible = False
                    dgLista.Columns(7).Visible = True
                    dgLista.Columns(8).Visible = True
                End If


                Do While REA.Read
                    Dim strFila As String = STR_VACIO
                    strFila = REA.GetInt32("anio") & "|"
                    ' If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 14 And Pais() = 327 Then
                    strFila &= REA.GetInt32("num") & "|"
                    '    dgLista.CurrentRow.Cells("colNo").Value.Visible = False
                    ' Else
                    strFila &= REA.GetInt32("numero") & "|"
                    '   dgLista.CurrentRow.Cells("colNumber").Value.Visible = False
                    'End If
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("nombre") & "|"
                    If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                        strFila &= REA.GetString("Invoice") & "|"
                    Else
                        strFila &= REA.GetString("referencia") & "|"
                    End If
                    strFila &= REA.GetInt32("estado") & "|"
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    strFila &= arrayCadena(INT_CERO) & "|"
                    strFila &= REA.GetString("Autorizacion")

                    e = REA.GetInt32("estado")

                    AgregarFila(dgLista, strFila, e)


                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Estado = vbEmpty Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.SkyBlue
                    End If
                End If

                Fila.Cells.Add(Celda)
            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function sqlDetalleNC(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT IFNULL(d.DDoc_RF1_Num,0) Catalogo, IFNULL(d.DDoc_RF2_Num,0) Anio, IFNULL(d.DDoc_RF3_Num,0) Numero, IFNULL(d.DDoc_Prd_Cod,1) LinFact, d.DDoc_Prd_Fob CantidadFact, if(d.DDoc_Prd_UM = 69,'LBS','KGS') UM,IFNULL(d.DDoc_Prd_PNr,'') producto, IFNULL(d.DDoc_RF1_Cod,'') Referencia,IFNULL(d.DDoc_Prd_DSP,0) PrecioFact, IFNULL(d.DDoc_Prd_PUQ,0) totalFact,d.DDoc_Prd_Des descripcion,d.DDoc_Prd_Cif libras,d.DDoc_RF2_Dbl Impuesto,d.DDoc_RF3_Dbl excepcion,d.DDoc_RF1_Dbl total,d.DDoc_Doc_Lin linea
                        FROM Dcmtos_DTL d
                             WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 31 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                        ORDER BY d.DDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL

    End Function

    Private Function sqlDetalle(ByVal anio As Integer, ByVal numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_NET Precio,d.DDoc_RF2_Num impuesto,d.DDoc_RF3_Num retencion,d.DDoc_RF1_Dbl Total"
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 31 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"
        strSQL &= " ORDER BY d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL
    End Function

    Private Function Pais()
        Dim strSQL2 As String
        Dim COM2 As New MySqlCommand
        Dim conec2 As New MySqlConnection
        Dim intPais As Integer = INT_CERO

        strSQL2 = "SELECT e.emp_pais "
        strSQL2 &= "     FROM Empresas e"
        strSQL2 &= "         WHERE e.emp_no = {empresa} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM2 = New MySqlCommand(strSQL2, conec2)
        Using conec2
            intPais = COM2.ExecuteScalar
            COM2.Dispose()
            COM2 = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using

        Return intPais
    End Function
    Private Function SQLHDRNOTADECREDITO(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT IFNULL(HDoc_DR2_Cat,0) HDoc_DR2_Cat, HDoc_Doc_Ano, HDoc_Doc_Num,HDoc_DR1_DBl, HDoc_Doc_Fec,  HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir,HDoc_Emp_Per, HDoc_Emp_Tel, c.cat_clave,  "
        strSQL &= "     HDoc_Emp_NIT, HDoc_RF2_Txt, HDoc_Doc_TC, HDoc_Usuario, HDoc_Doc_Mon, HDoc_RF1_Dbl, HDoc_DR1_Cat, HDoc_RF1_Cod, IFNULL(HDoc_RF2_Cod,'') Rango ,HDoc_RF1_Txt, HDoc_Doc_Status, HDoc_RF2_Txt, HDoc_DR2_Num, IFNULL(cli.cli_clasificacion,0) clasTipoFactura,  IFNULL(cli.cli_nit,'C/F') nitcliente "
        strSQL &= "         FROM Dcmtos_HDR  LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp  AND cli.cli_codigo =HDoc_Emp_Cod"
        strSQL &= "         WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 31 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function

    Private Sub SeleccionarCliente(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim HDR As New clsDcmtos_HDR
        Dim CA As New clsCatalogos
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim intRevisado As Integer
        Dim ArrayRango(10) As String
        Dim strCAI As String = STR_VACIO

        'strCampos = " HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_DR1_DBL, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Per, HDoc_Emp_Tel, HDoc_Emp_NIT, HDoc_RF2_Txt, HDoc_Doc_TC, HDoc_Usuario, HDoc_Doc_Mon, HDoc_RF1_Dbl, HDoc_DR1_Cat, HDoc_RF1_Cod, HDoc_RF1_Txt, HDoc_Doc_Status, HDoc_RF2_Txt, HDoc_DR2_Num"
        'strCondicion = " HDoc_Sis_Emp = {empresa} And HDoc_Doc_Cat = 31 And HDoc_Doc_Ano = {año} And HDoc_Doc_Num = {numero}"
        'strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        'strCondicion = Replace(strCondicion, "{año}", intaño)
        'strCondicion = Replace(strCondicion, "{numero}", intnumero)

        Try
            MyCnn.CONECTAR = strConexion
            strSQL = SQLHDRNOTADECREDITO(intaño, intnumero)
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 14 And Pais() = 327) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Or (Sesion.idGiro = 2) Then
                        celdaTemporal.Text = REA.GetInt32("HDoc_DR1_DBl")
                        celdaNumero.Visible = False
                        celdaNumero.Text = REA.GetInt32("HDoc_Doc_Num")
                    Else

                        celdaNumero.Text = REA.GetInt32("HDoc_Doc_Num")
                        celdaTemporal.Visible = False
                    End If

                    strPaisCliente = REA.GetInt32("clasTipoFactura")
                    strNitCliente = REA.GetString("nitcliente")
                    celdaAño.Text = REA.GetInt32("HDoc_Doc_Ano")
                    dtpFech.Text = REA.GetDateTime("HDoc_Doc_Fec")
                    celdaIDCliente.Text = REA.GetInt32("HDoc_Emp_Cod")
                    celdaCliente.Text = REA.GetString("HDoc_Emp_Nom")
                    celdaDireccion.Text = REA.GetString("HDoc_Emp_Dir")
                    celdaEmpresa.Text = Sesion.IdEmpresa
                    celdaCatalogo.Text = 31
                    celdaUsuario.Text = REA.GetString("HDoc_Usuario")
                    celdaTasa.Text = REA.GetDouble("HDoc_Doc_TC")
                    celdaMoneda.Text = REA.GetString("cat_clave")
                    celdaIDMoneda.Text = REA.GetDouble("HDoc_Doc_Mon")
                    If Sesion.IdEmpresa = 11 Then
                        strCAI = REA.GetString("Rango")
                        'ElseIf Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                        '    celdaCAI.Text = REA.GetString("Rango")
                    ElseIf Sesion.IdEmpresa = 12 And Pais = 310 Or Sesion.IdEmpresa = 16 And Pais = 310 Then
                        celdaGiro.Text = REA.GetString("Rango")
                    End If

                    If Sesion.IdEmpresa = 11 Then
                        ArrayRango = strCAI.Split("|".ToCharArray)
                        If strCAI = "" Then
                        Else
                            celdaCAI.Text = ArrayRango(INT_CERO)
                            celdaRangoFechaAutorizado.Text = ArrayRango(INT_UNO)
                        End If
                    End If
                    celdaCatalogoCAI.Text = REA.GetInt32("HDoc_DR2_Cat")
                    CeldaTotalEnLetras.Text = REA.GetString("HDoc_RF2_Txt")
                    celdaTasaFactura.Text = REA.GetDouble("HDoc_RF1_Dbl")
                    celdaDeclaracion.Text = REA.GetString("HDoc_RF1_Cod")
                    celdaNotasObservaciones.Text = REA.GetString("HDoc_RF1_Txt")
                    celdaNIT.Text = REA.GetString("HDoc_Emp_NIT")
                    celdaTelefono.Text = REA.GetString("HDoc_Emp_Tel")
                    celdaSerie1.Text = REA.GetString("HDoc_DR2_Num")

                    If REA.GetInt32("HDoc_Doc_Status") = 0 Then
                        checkActivar.Checked = False
                    ElseIf REA.GetInt32("HDoc_Doc_Status") = 1 Then
                        checkActivar.Checked = True
                    End If

                    If REA.GetInt32("HDoc_DR1_Cat") = 0 Then
                        rbDifPrecio.Checked = True
                    ElseIf REA.GetInt32("HDoc_DR1_Cat") = 1 Then
                        rbDevoluciones.Checked = True
                    ElseIf REA.GetInt32("HDoc_DR1_Cat") = 2 Then
                        rbOtros.Checked = True
                    End If



                Loop
            End If
            If strCAI = "" Then
                CAI()
                RangoFechaAutorizada()
            End If
            'Verifica estado de la poliza
            strSQL = "Select revisado"
            strSQL &= "  FROM " & cFunciones.ContaEmpresa & " .polizas"
            strSQL &= "          WHERE empresa = {empresa} And ref_tipo = 47 And ref_ciclo = {ciclo} And ref_numero = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ciclo}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            intRevisado = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            checkRevisado.Checked = IIf(intRevisado = vbEmpty, checkRevisado.Checked = False, checkRevisado.Checked = True)

            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                'Carga CAI
                CAI()
            Else
                celdaCAI.Text = INT_CERO
            End If


            '  End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub queryDetalleNC(ByVal anio As Integer, ByVal numero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim e As Integer
        'Dim Lista As DataGridView

        strSQL = sqlDetalleNC(anio, numero)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalleNC.Rows.Clear()
                If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                    dgDetalleNC.Columns(12).Visible = True
                    dgDetalleNC.Columns(13).Visible = True
                Else
                    dgDetalleNC.Columns(12).Visible = False
                    dgDetalleNC.Columns(13).Visible = False
                End If
                dgDetalleNC.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("LinFact") & "|"
                    strFila &= REA.GetDouble("CantidadFact") & "|"
                    strFila &= REA.GetString("UM") & "|"
                    strFila &= REA.GetString("Producto") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetDouble("PrecioFact") & "|"
                    strFila &= REA.GetDouble("totalFact") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("libras") & "|"
                    strFila &= REA.GetDouble("Impuesto") & "|"
                    strFila &= REA.GetDouble("excepcion") & "|"
                    strFila &= REA.GetDouble("total") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= INT_UNO

                    cFunciones.AgregarFila(dgDetalleNC, strFila)

                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryDetalle(ByVal anio As Integer, ByVal numero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim e As Integer
        'Dim Lista As DataGridView

        strSQL = sqlDetalle(anio, numero)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()
                If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                    dgDetalle.Columns(3).Visible = True
                    dgDetalle.Columns(4).Visible = True
                Else
                    dgDetalle.Columns(3).Visible = False
                    dgDetalle.Columns(4).Visible = False
                End If
                dgDetalle.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("cantidad") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("impuesto") & "|"
                    strFila &= REA.GetDouble("retencion") & "|"
                    strFila &= REA.GetDouble("total")

                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function CargarDocsProcesados()
        'Carga el listado de documentos de los cuales ha descargado el actual,
        Dim strSQL As String = STR_VACIO

        strSQL = " Select e.HDoc_Doc_Ano Anio, e.HDoc_Doc_Num Numero, IF(c.ECta_Ref_Cat=36,e.HDoc_DR1_Dbl,e.HDoc_DR2_Cat) Invoice,  e.HDoc_Doc_Fec Fecha, e.HDoc_Usuario Usuario, e.HDoc_DR1_Num Referencia, IFNULL(f.Serie,'') Serie ,IFNULL(f.NumeroAutorizacion,'') AutorizacionF, IFNULL(e.HDoc_DR2_Num,'') SerieGFase,c.ECta_Ref_Cat Cat,e.HDoc_Ant_Com Impuesto, h.HDoc_RF3_Dbl saldo "
        strSQL &= "     FROM ECtaCte c"
        strSQL &= "          INNER JOIN Dcmtos_HDR e On e.HDoc_Sis_Emp = c.ECta_Sis_Emp And e.HDoc_Doc_Cat = c.ECta_Ref_Cat And e.HDoc_Doc_Ano = c.ECta_Ref_Ano And e.HDoc_Doc_Num = c.ECta_Ref_Num"
        strSQL &= "                 LEFT JOIN Fel f ON f.Empresa = e.HDoc_Sis_Emp AND f.Catalogo = e.HDoc_Doc_Cat AND f.Anio = e.HDoc_Doc_Ano AND f.Numero = e.HDoc_Doc_Num "
        strSQL &= "                 LEFT JOIN Dcmtos_HDR h On h.HDoc_Sis_Emp = c.ECta_Sis_Emp AND h.HDoc_Doc_Cat = c.ECta_Doc_Cat AND h.HDoc_Doc_Ano = c.ECta_Doc_Ano AND h.HDoc_Doc_Num = c.ECta_Doc_Num "
        strSQL &= "              WHERE c.ECta_Sis_Emp = {empresa} And c.ECta_Doc_Cat = 31 And c.ECta_Doc_Ano = {anio} And c.ECta_Doc_Num = {numero}"
        strSQL &= "          GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num  ORDER BY e.HDoc_Doc_Fec DESC, e.HDoc_Doc_Num DESC"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryDocProcesados()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim e As Integer
        'Dim Lista As DataGridView

        strSQL = CargarDocsProcesados()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgFacturacion.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Referencia")
                    If Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Or Sesion.IdEmpresa = 10 Then
                        strFila &= "|" & REA.GetString("Invoice")
                    Else
                        strFila &= "|" & ""
                    End If
                    strFila &= "|" & REA.GetString("saldo")

                    cFunciones.AgregarFila(dgFacturacion, strFila)
                    celdaUIDDFact.Text = REA.GetString("Serie")
                    celdaAutFact.Text = REA.GetString("AutorizacionF")
                    celdaSerieGF.Text = REA.GetString("SerieGFase")
                    Cat = REA.GetInt32("Cat")
                    If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                        If REA.GetInt32("Cat") = 296 Then
                            celdaGiro.Visible = True
                            etiquetaGiro.Visible = True
                            celdaImpuesto.Visible = True
                            celdaExepcion.Visible = True
                            celdaSub.Visible = True
                            etiquetaSubTotal.Visible = True
                            etiquetaImpuesto.Visible = True
                            etiquetaExepcion.Visible = True
                            dgDetalle.Columns(3).Visible = True
                            dgDetalle.Columns(4).Visible = True
                            checkFacturaFiscal.Checked = True
                            checkFacturaFiscal.Visible = True
                            IntCalcularImpuesto = REA.GetInt32("Impuesto")
                        Else
                            celdaGiro.Visible = True
                            etiquetaGiro.Visible = True
                            celdaImpuesto.Visible = False
                            celdaExepcion.Visible = False
                            celdaSub.Visible = False
                            etiquetaSubTotal.Visible = False
                            etiquetaImpuesto.Visible = False
                            etiquetaExepcion.Visible = False
                            dgDetalle.Columns(3).Visible = False
                            dgDetalle.Columns(4).Visible = False
                            checkFacturaFiscal.Checked = False
                            checkFacturaFiscal.Visible = False
                        End If
                    Else
                        celdaSub.Visible = False
                        etiquetaSubTotal.Visible = False
                    End If
                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Carga el IVA para el documento
    Private Sub sqlCargarIVA()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try


            'Determinar impuestos aplicables al tipo de documento
            If Me.Tag = "Mod" Then
                strSQL = "   Select MDoc_Doc_Lin Linea, MDoc_Lin_ID ID, MDoc_Lin_Codigo Codigo, MDoc_Lin_Tipo Tipo, MDoc_Lin_Desc Descripcion, MDoc_Lin_Base Base, MDoc_Lin_Cantidad Cantidad, MDoc_Lin_Factor Factor, MDoc_Lin_Monto  Monto, -1 Tag, 1 Origen"
                strSQL &= "      FROM Dcmtos_IMP"
                strSQL &= "              WHERE MDoc_Sis_Emp={empresa} And MDoc_Doc_Cat=31 And MDoc_Doc_Ano={anio} And MDoc_Doc_Num={numero} And MDoc_Lin_Codigo='{IVA}'"
                strSQL &= "        ORDER BY MDoc_Doc_Lin"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{IVA}", STR_IVA)

            ElseIf Me.Tag = "Nuevo" Then

                strSQL = "SELECT d.cat_pid Linea, d.cat_num ID, r.cat_clave Codigo, r.cat_pid Tipo, IF(r.cat_pid=0,r.cat_clave,r.cat_desc) Descripcion, 0 Base, 0 Cantidad, IF(r.cat_sist<0,0,r.cat_sist) Factor, 0 Monto, 0 Tag, 0  Origen"
                strSQL &= "     FROM Catalogos d"
                strSQL &= "         INNER JOIN Catalogos r ON r.cat_sisemp={empresa} AND r.cat_clase='Impuestos' AND r.cat_clave=d.cat_sist"
                strSQL &= "             WHERE d.cat_sisemp={empresa} AND d.cat_clase='DocImpuesto' AND d.cat_clave= 'Doc_CNCredito' AND r.cat_pid=0"
                strSQL &= "                 GROUP BY d.cat_num"
                strSQL &= "              ORDER BY d.cat_pid "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgImpuestos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    If Me.Tag = "Nuevo" Then
                        strFila = 2 & "|"
                    Else
                        strFila = REA.GetInt32("Linea") & "|"
                    End If
                    strFila &= REA.GetInt32("ID") & "|"
                    strFila &= REA.GetString("Codigo") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Base") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetInt32("Factor") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetInt32("Tag") & "|"
                    strFila &= REA.GetInt32("Origen")


                    cFunciones.AgregarFila(dgImpuestos, strFila)

                Loop
                REA.Close()
                REA = Nothing

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer = vbEmpty
        Dim Cantidad As Integer = vbEmpty
        Dim Precio As Double
        Dim Total As Double
        Dim dblTotal As Double = 0
        Dim dblTax As Double = 0
        Dim dblSales As Double = 0

        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
            celdaImpuesto.Text = INT_CERO
            celdaExepcion.Text = INT_CERO
            celdaSub.Text = INT_CERO
            dgDetalle.CurrentRow.Cells("colImpuesto").Value = INT_CERO
            dgDetalle.CurrentRow.Cells("colExepcion").Value = INT_CERO

            celdaSubTotal.Text = CDbl(dgDetalle.CurrentRow.Cells("colCantidad").Value).ToString(FORMATO_MONEDA)
            celdaTotal.Text = CDbl(dgDetalle.CurrentRow.Cells("colTotal").Value).ToString(FORMATO_MONEDA)
        Else
            For i = 0 To dgDetalleNC.Rows.Count - 1
                If dgDetalleNC.Rows(i).Visible = True Then
                    If Cat = 296 Then
                        If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 And Pais() = 310 Then
                            Cantidad = INT_UNO
                            Precio = dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value
                            Total = (Cantidad * Precio)
                            celdaSub.Text = Total.ToString(FORMATO_MONEDA)
                            celdaImpuesto.Text = CDbl((Total * CalcularIVA13()) / 100).ToString(FORMATO_MONEDA)
                            dgDetalleNC.Rows(i).Cells("colImpuestoDet").Value = CDbl((Total * CalcularIVA13()) / 100).ToString(FORMATO_MONEDA)
                            If IntCalcularImpuesto = 1 Then
                                dgDetalleNC.Rows(i).Cells("colExcepcionDet").Value = CDbl(Total / 100).ToString(FORMATO_MONEDA)
                                celdaExepcion.Text = CDbl(Total / 100).ToString(FORMATO_MONEDA)
                            End If
                        End If
                    Else

                        celdaImpuesto.Text = INT_CERO
                        celdaExepcion.Text = INT_CERO
                        celdaSub.Text = INT_CERO
                        dgDetalleNC.Rows(i).Cells("colImpuestoDet").Value = INT_CERO
                        dgDetalleNC.Rows(i).Cells("colExcepcionDet").Value = INT_CERO

                    End If
                    If checkFacturaFiscal.Checked = True And Sesion.IdEmpresa = 16 And Pais() = 310 Then
                        dblTax = celdaImpuesto.Text
                        dblSales = celdaExepcion.Text
                        dblTotal = dblTotal + CDbl((dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value) + dblTax - dblSales).ToString(FORMATO_MONEDA)
                    Else
                        dblTotal = dblTotal + CDbl(dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value).ToString(FORMATO_MONEDA)
                    End If
                End If

            Next

            If (dblTotal <= dgFacturacion.Rows(0).Cells("saldo").Value) Then

                celdaSubTotal.Text = INT_UNO
                celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            ElseIf (Sesion.idGiro = 1) Then
                celdaSubTotal.Text = INT_UNO
                celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
                MsgBox("The amount cannot exceed the invoice balance.", vbExclamation)

            End If


        End If


    End Sub

    'Private Function CalcularIVA()
    '    Dim dblBase As Double
    '    Dim dblCantidad As Double
    '    Dim dblFactor As Double
    '    Dim dblMonto As Double

    '    dblBase = CDbl(dgDetalle.CurrentRow.Cells("colTotal").Value * celdaTasa.Text)


    'End Function

    'Para obtener la tasa de cambio de la factura
    Private Function TasaCambioFactura(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim TasaFactura As Double
        Dim Cat As Integer = vbEmpty

        strSQL = "SELECT HDoc_Doc_TC"
        strSQL &= "      FROM Dcmtos_HDR"
        strSQL &= "              WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={cat} AND HDoc_Doc_Ano={anio} AND HDoc_Doc_Num={numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 13 Then
            Cat = 296
        Else
            Cat = 36
        End If
        strSQL = Replace(strSQL, "{cat}", Cat)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        TasaFactura = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return TasaFactura
    End Function

    Private Function sqlDiferenciaDetalle(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT df.DDoc_Doc_Lin Linea, IFNULL(la.art_DCorta,df.DDoc_Prd_Des) Descripcion,IF(df.DDoc_RF3_Dbl=0,df.DDoc_Prd_QTY,df.DDoc_RF3_Dbl) Despacho, df.DDoc_Prd_NET Precio, COALESCE(mf.cat_clave,'') UMF, IFNULL(((IF(df.DDoc_RF3_Dbl=0,df.DDoc_Prd_QTY,df.DDoc_RF3_Dbl) * df.DDoc_Prd_NET)),0) Facturado ,  ROUND(df.DDoc_Prd_QTY,3)"
        strSQL &= "      Equivalencia, IFNULL(dp.DDoc_Prd_NET,0) Unitario, COALESCE(mp.cat_clave,'') UMP, IFNULL((IF(dp.DDoc_Prd_UM = 69, IF(df.DDoc_Prd_UM = 69,df.DDoc_Prd_QTY * dp.DDoc_Prd_NET, IF(dp.DDoc_Prd_Cif = 0, df.DDoc_Prd_QTY * ROUND((dp.DDoc_Prd_NET *2.2046)+ 0.0000000001,2),df.DDoc_Prd_QTY * dp.DDoc_Prd_Cif)), IF(df.DDoc_Prd_UM = 70, df.DDoc_Prd_QTY * dp.DDoc_Prd_NET, df.DDoc_Prd_QTY * ROUND((dp.DDoc_Prd_NET *2.2046)+ 0.0000000001,2)))),0) Cotizado,
                            IFNULL(ROUND((IF(df.DDoc_RF3_Dbl=0,df.DDoc_Prd_QTY,df.DDoc_RF3_Dbl) * df.DDoc_Prd_NET) - (df.DDoc_Prd_QTY * IF(df.DDoc_Prd_UM = 70, IF(dp.DDoc_Prd_Cif = 0,ROUND((dp.DDoc_Prd_NET*2.2046)+ 0.0000000001,2),dp.DDoc_Prd_Cif),dp.DDoc_Prd_NET))+ 0.0000000001,2),0) Diferencia, IFNULL(rp.PDoc_Par_Num,0) Pedido, df.DDoc_RF1_Txt Referencia"
        strSQL &= "          FROM Dcmtos_HDR h"
        strSQL &= "             LEFT JOIN Dcmtos_DTL df ON df.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND df.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND df.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND df.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro ri ON ri.PDoc_Sis_Emp = df.DDoc_Sis_Emp AND ri.PDoc_Chi_Cat = df.DDoc_Doc_Cat AND ri.PDoc_Chi_Ano = df.DDoc_Doc_Ano AND ri.PDoc_Chi_Num = df.DDoc_Doc_Num AND ri.PDoc_Chi_Lin = df.DDoc_Doc_Lin"
        strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro rp ON rp.PDoc_Sis_Emp = ri.PDoc_Sis_Emp AND rp.PDoc_Chi_Cat = ri.PDoc_Par_Cat AND rp.PDoc_Chi_Ano = ri.PDoc_Par_Ano AND rp.PDoc_Chi_Num = ri.PDoc_Par_Num AND rp.PDoc_Chi_Lin = ri.PDoc_Par_Lin AND rp.PDoc_Par_Cat = {pedido}"
        strSQL &= "                           LEFT JOIN Dcmtos_DTL dp ON dp.DDoc_Sis_Emp = rp.PDoc_Sis_Emp AND dp.DDoc_Doc_Cat = rp.PDoc_Par_Cat AND dp.DDoc_Doc_Ano = rp.PDoc_Par_Ano AND dp.DDoc_Doc_Num = rp.PDoc_Par_Num AND dp.DDoc_Doc_Lin = rp.PDoc_Par_Lin"
        strSQL &= "                LEFT JOIN Inventarios li ON li.inv_sisemp = df.DDoc_Sis_Emp AND li.inv_numero = df.DDoc_Prd_Cod"
        strSQL &= "            LEFT JOIN Articulos la ON la.art_sisemp = li.inv_sisemp AND la.art_codigo = li.inv_artcodigo"
        strSQL &= "        LEFT JOIN Catalogos mf ON mf.cat_clase = 'Medidas' AND mf.cat_num = COALESCE(df.DDoc_RF3_Num,df.DDoc_Prd_UM)"
        strSQL &= "      LEFT JOIN Catalogos mp ON mp.cat_clase = 'Medidas' AND mp.cat_num = dp.DDoc_Prd_UM"
        strSQL &= "   WHERE h.HDoc_Sis_Emp  = {empresa} AND h.HDoc_Doc_Cat  = {factura} AND h.HDoc_Doc_Ano  = {anio} AND h.HDoc_Doc_Num  = {numero} -- AND NOT ISNULL(dp.DDoc_Sis_Emp) AND NOT((COALESCE(df.DDoc_RF3_Num,df.DDoc_Prd_UM) = dp.DDoc_Prd_UM) AND (df.DDoc_Prd_NET = dp.DDoc_Prd_NET))"
        strSQL &= " ORDER BY df.DDoc_Doc_Lin"

        'Reemplaza los parametros en el query
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{pedido}", 75)
        If checkFacturaFiscal.Visible = True And checkFacturaFiscal.Checked = True Then
            strSQL = Replace(strSQL, "{factura}", 296)
        Else
            strSQL = Replace(strSQL, "{factura}", 36)
        End If
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)

        Return strSQL
    End Function

    'Devuelve la inst. de sel. para obtener el total de las notas aplicadas a la fact.
    Private Function sqlTotalNotas(ByVal Anio As Integer, ByVal Numero As Integer, Optional intLine As Integer = 1) As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim ValorNotas As Double


        strSQL = "SELECT IFNULL(SUM(c.ECta_Abno_Ext),0) total"
        strSQL &= "     FROM ECtaCte c"
        strSQL &= "          LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.ECta_Sis_Emp AND e.HDoc_Doc_Cat = c.ECta_Doc_Cat AND e.HDoc_Doc_Ano = c.ECta_Doc_Ano AND e.HDoc_Doc_Num = c.ECta_Doc_Num"
        strSQL &= "      WHERE c.ECta_Sis_Emp = {empresa} AND c.ECta_Ref_Cat = {catalogo} AND c.ECta_Ref_Ano = {anio} AND c.ECta_Ref_Num = {referencia} AND c.ECta_Doc_Lin = {line} AND e.HDoc_DR1_Cat = {clase} AND ((c.ECta_Doc_Cat = {credito} OR c.ECta_Doc_Cat = {abono}) AND NOT(c.ECta_Doc_Cat = {tipo} AND c.ECta_Doc_Ano = {Año} AND c.ECta_Doc_Num = {Number}))"

        'Reemplaza parametros en el query
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 36)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{referencia}", Numero)
        strSQL = Replace(strSQL, "{credito}", 31)
        strSQL = Replace(strSQL, "{clase}", vbEmpty)
        strSQL = Replace(strSQL, "{abono}", 46)
        strSQL = Replace(strSQL, "{line}", intLine)

        strSQL = Replace(strSQL, "{tipo}", celdaCatalogo.Text)
        strSQL = Replace(strSQL, "{Año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{Number}", celdaNumero.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        ValorNotas = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Return ValorNotas
    End Function

    'Carga al detalle la diferencia de precios
    Private Sub CargarDiferencia(Optional ByVal Fila As Integer = NO_FILA, Optional ByVal Cat As Integer = INT_CERO)
        Dim strSQL As String = STR_VACIO
        Dim dblDato As Double
        Dim dblNotas As Double
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intDiferencial As Double = INT_CERO
        Dim strfila As String = STR_VACIO
        Dim intContar As Integer = 0

        If Not (Fila = NO_FILA) Then
            'Recupera las dif. del detalle
            strSQL = sqlDiferenciaDetalle(dgFacturacion.CurrentRow.Cells(0).Value, dgFacturacion.CurrentRow.Cells(1).Value)
            dblDato = vbEmpty
            If Cat = 296 Then
                If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 And Pais() = 310 Then
                    dgDetalleNC.Columns(12).Visible = True
                    dgDetalleNC.Columns(13).Visible = True
                    celdaImpuesto.Visible = True
                    etiquetaImpuesto.Visible = True
                    celdaExepcion.Visible = True
                    etiquetaExepcion.Visible = True
                    celdaSub.Visible = True
                    etiquetaSubTotal.Visible = True
                Else
                    dgDetalle.Columns(3).Visible = False
                    dgDetalle.Columns(4).Visible = False
                    celdaImpuesto.Visible = False
                    etiquetaImpuesto.Visible = False
                    celdaExepcion.Visible = False
                    etiquetaExepcion.Visible = False
                    celdaSub.Visible = False
                    etiquetaSubTotal.Visible = False
                    dgDetalle.CurrentRow.Cells(3).Value = 0.00
                    dgDetalle.CurrentRow.Cells(4).Value = 0.00
                End If
            Else
                If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                    dgDetalle.Columns(3).Visible = False
                    dgDetalle.Columns(4).Visible = False
                    celdaImpuesto.Visible = False
                    etiquetaImpuesto.Visible = False
                    celdaExepcion.Visible = False
                    etiquetaExepcion.Visible = False
                    celdaSub.Visible = False
                    etiquetaSubTotal.Visible = False
                    dgDetalle.CurrentRow.Cells(3).Value = 0.00
                    dgDetalle.CurrentRow.Cells(4).Value = 0.00
                Else
                    dgDetalleNC.Columns(12).Visible = False
                    dgDetalleNC.Columns(13).Visible = False
                    celdaImpuesto.Visible = False
                    etiquetaImpuesto.Visible = False
                    celdaExepcion.Visible = False
                    etiquetaExepcion.Visible = False
                    celdaSub.Visible = False
                    etiquetaSubTotal.Visible = False
                End If
            End If

            Try

                MyCnn.CONECTAR = strConexion

                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        intDiferencial = REA.GetDouble("Diferencia")
                        'If intDiferencial > vbEmpty Then
                        '    dblDato = (dblDato + intDiferencial)
                        'End If

                        If intDiferencial >= vbEmpty Then
                            dblDato = (intDiferencial)
                        End If


                        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                            If dblDato > vbEmpty Then
                                dblDato = (dblDato - sqlTotalNotas(dgFacturacion.CurrentRow.Cells(0).Value, dgFacturacion.CurrentRow.Cells(1).Value))
                            End If
                        Else
                            If dblDato > vbEmpty Then
                                dblDato = (dblDato - sqlTotalNotas(dgFacturacion.CurrentRow.Cells(0).Value, dgFacturacion.CurrentRow.Cells(1).Value, REA.GetInt32("Linea")))
                            End If

                            strfila = Cat & "|" 'Catalogo
                            strfila &= dgFacturacion.CurrentRow.Cells(0).Value & "|" 'Anio
                            strfila &= dgFacturacion.CurrentRow.Cells(1).Value & "|" 'Numero
                            strfila &= REA.GetInt32("Linea") & "|" 'linea
                            strfila &= REA.GetDouble("despacho") & "|" ' Cantidad facturada
                            strfila &= REA.GetString("UMF") & "|" 'Unidad de medida de la factura
                            strfila &= REA.GetString("Descripcion") & "|" ' titulo del Hilo
                            strfila &= REA.GetString("Referencia") & "|" 'Referencia
                            strfila &= REA.GetDouble("Precio") & "|" 'Precio
                            strfila &= REA.GetDouble("Facturado").ToString(FORMATO_MONEDA) & "|" 'Total facturado
                            If rbDifPrecio.Checked = True Then
                                strfila &= "DESCUENTO SOBRE VENTAS" & "|" ' Descripción de la NC
                            ElseIf rbDevoluciones.Checked = True Then
                                strfila &= "DEVOLUCION DE MERCADERIA" & "|" ' Descripción de la NC
                            ElseIf rbOtros.Checked = True Then
                                strfila &= "" & "|" ' Descripción de la NC
                            End If

                            strfila &= "0.00" & "|" ' Libras de devolucion
                                strfila &= "0.00" & "|" ' Impuestos
                                strfila &= "0.00" & "|" ' ventas exentas
                                strfila &= dblDato.ToString(FORMATO_MONEDA) & "|" ' total NC
                                strfila &= INT_CERO & "|" ' Linea
                                strfila &= INT_CERO  ' Extra

                            If rbDifPrecio.Checked = True And dblDato <= 0 Then
                            Else
                                cfun.AgregarFila(dgDetalleNC, strfila)
                            End If

                        End If
                    Loop
                End If
                REA.Close()
                REA = Nothing


                'Actualiza el detalle
                If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                    dgDetalle.CurrentRow.Cells(0).Value = 1.0
                    dgDetalle.CurrentRow.Cells(2).Value = dblDato.ToString(FORMATO_MONEDA)
                    dgDetalle.CurrentRow.Cells(5).Value = dblDato.ToString(FORMATO_MONEDA)
                    'CeldaTotalEnLetras.Text = cFunciones.ALetras(dgDetalle.CurrentRow.Cells(5).Value).ToUpper

                Else
                    '***************************
                    '*****************************
                    ' esto lo he pensado trabajar con for, hay que colocar el dg correcto y las columnas correctas
                    If Cat = 296 Then
                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                            If (Sesion.IdEmpresa = 12 And Pais() = 310) Or Sesion.IdEmpresa = 16 Then
                                dgDetalleNC.Rows(i).Cells("colImpuestoDet").Value = CDbl(((dblDato) * CalcularIVA13() / 100)).ToString(FORMATO_MONEDA)
                                If IntCalcularImpuesto = 1 Then
                                    dgDetalleNC.Rows(i).Cells("colExcepcionDet").Value = CDbl(((dblDato) / 100)).ToString(FORMATO_MONEDA)
                                End If
                            End If
                        Next
                    End If

                    'CeldaTotalEnLetras.Text = cFunciones.ALetras(dgDetalle.CurrentRow.Cells(14).Value).ToUpper
                End If
                CalcularTotales()
                CeldaTotalEnLetras.Text = cFunciones.ALetras(celdaTotal.Text).ToUpper

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        End If

    End Sub

    Private Function ComprobarFilasDetalle() As Boolean
        ComprobarFilasDetalle = True
        Dim i As Integer
        Dim Comprobacion As Boolean = True

        For i = 0 To dgDetalle.Rows.Count - 1

            If dgDetalle.Rows(i).Cells("colCantidad").Value = vbEmpty Then
                Comprobacion = False
                MsgBox("Invalid Amount", vbExclamation, "Notice")
            End If

            If dgDetalle.Rows(i).Cells("colUnitario").Value = vbEmpty Then
                Comprobacion = False
                MsgBox("Invalid Price", vbExclamation, "Notice")
            End If

            If dgDetalle.Rows(i).Cells("colTotal").Value = vbEmpty Then
                Comprobacion = False
                MsgBox("Invalid Total", vbExclamation, "Notice")
            End If

            If dgDetalle.Rows(i).Cells("colDescription").Value = vbNullString Then
                Comprobacion = False
                MsgBox("No Description Entered", vbExclamation, "Notice")
            End If

        Next
        Return Comprobacion
    End Function

    Private Function ComprobarIngreso() As Boolean
        Dim logContinuar As Boolean
        Dim logVacio As Boolean
        Dim intDocs As Integer
        Dim strRef As String = STR_VACIO


        If Me.Tag = "Nuevo" And checkActivar.Checked = False Then
            logVacio = True
        Else
            logVacio = False
        End If
        'Revisar que los datos de la cabecera sean válidos
        If (celdaEmpresa.Text = vbEmpty) Or (celdaCatalogo.Text = vbEmpty) Or (celdaUsuario.Text = vbNullString) Then
            MsgBox("Incomplete Data", vbExclamation, "Notice")
        ElseIf celdaAño.Text = vbEmpty Or
            celdaIDCliente.Text = vbEmpty Or
            celdaCliente.Text = vbNullString Or
            celdaIDMoneda.Text = vbEmpty Or
            celdaTasa.Text = vbEmpty Then

            MsgBox("You must enter at least the minimum data", vbExclamation, "Notice")
        ElseIf celdaTasaFactura.Text = vbEmpty And Not logVacio Then
            MsgBox("Enter the reference exchange rate", vbExclamation, "Notice")
        ElseIf dgFacturacion.Rows.Count = vbEmpty And Not logVacio Then
            MsgBox("No document in Reference", vbExclamation, "Notice")
        Else
            If Not Year(dtpFech.Value) = celdaAño.Text Then
                MsgBox("Document Year And Date do Not match", vbExclamation, "Notice")
                logContinuar = False

            Else
                logContinuar = True
            End If

            If Not logVacio Then
                If ExisteReferencia() Then
                    If MsgBox("There Is another note that refers to the invoice entered" & vbCr & vbCr & "Do you wish to continue?", vbExclamation + vbYesNo + vbDefaultButton2, "Confirm") = vbNo Then
                        logContinuar = False
                    End If
                End If
            End If
            If logContinuar And Not logVacio Then
                If CDate(dgFacturacion.Rows(vbEmpty).Cells("colFecha").Value) > dtpFech.Value Then
                    MsgBox("Date Less than the date of the invoice", vbExclamation, "Aviso")
                    logContinuar = False
                Else
                    'Verifica el plazo de dos meses para notas de crédito
                    If DateDiff("m", dgFacturacion.CurrentRow.Cells("colFecha").Value, dtpFech.Value) > 2 Then
                        If MsgBox("The date difference Is great than two months" & vbCrLf & vbCrLf & "Wishes to continue despite this deadline?", vbExclamation + vbYesNo + vbDefaultButton2, "Confirm") = vbNo Then
                            logContinuar = False
                        End If
                    End If
                End If
            End If

            If logContinuar And Not logVacio Then
                'Comprueba cada línea del detalle
                For i = vbEmpty To dgDetalle.Rows.Count - 1
                    If Not ComprobarFilasDetalle() Then
                        logContinuar = False
                        Exit For
                    End If
                Next
            End If

            If logContinuar Then
                If dgFacturacion.Rows.Count > 1 Then
                    MsgBox("No more than one reference document.", vbExclamation)
                    logContinuar = False
                Else
                    CalcularTotales()

                End If
            End If
        End If
        Return logContinuar
    End Function

    'Comprueba si la ref. ingresada ya existe
    Private Function ExisteReferencia() As Boolean
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim Cat As Integer

        Dim intRef As Integer = vbEmpty
        Dim logEx As Boolean

        If dgFacturacion.Rows.Count > vbEmpty Then
            For i = vbEmpty To dgFacturacion.Rows.Count - 1
                strSQL = "SELECT COUNT(*)"
                strSQL &= "      FROM ECtaCte"
                strSQL &= "              WHERE ECta_Sis_Emp={empresa} And ECta_Doc_Cat=31 And ECta_Ref_Cat={catalogo} And ECta_Ref_Ano={ciclo} And ECta_Ref_Num={referencia} And Not(ECta_Doc_Ano={año} And ECta_Doc_Num={numero})"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{año}", celdaAño.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

                If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                    Cat = 296
                Else
                    Cat = 36
                End If
                strSQL = Replace(strSQL, "{catalogo}", Cat)
                strSQL = Replace(strSQL, "{ciclo}", dgFacturacion.Rows(i).Cells("colAño").Value)
                strSQL = Replace(strSQL, "{referencia}", dgFacturacion.Rows(i).Cells("colNumero").Value)


                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                intRef = COM.ExecuteScalar
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()

                If Not logEx Then
                    logEx = IIf(intRef > vbEmpty, True, False)

                    If logEx = True Then
                        Exit For
                    End If
                End If
            Next
        End If

        ExisteReferencia = logEx
    End Function
    Private Sub BorrarEncabezadoNC(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 31
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarDocumento() As Boolean
        Dim strSQL As String
        Dim intNumero As Integer
        Dim logResultado As Boolean = True
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = " Select ifnull(MAX(HDoc_DR1_Dbl),0)+1"
        strSQL &= "     FROM Dcmtos_HDR"
        strSQL &= "         WHERE HDoc_Sis_Emp ={empresa} And HDoc_Doc_Cat = 31 And HDoc_DR2_Num ='{serie}'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{serie}", celdaSerie1.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intNumero = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaCatalogo.Text
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDOC_USUARIO = celdaUsuario.Text


            'Serrie del Documento
            chdr.HDOC_DR2_NUM = celdaSerie1.Text

            'Fecha y Estado
            chdr.HDoc_Doc_Fec_NET = dtpFech.Value.ToString(FORMATO_MYSQL)
            chdr.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)

            'Empresa
            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNIT.Text
            chdr.HDOC_EMP_TEL = celdaTelefono.Text

            'guarda catalogo de CAI
            chdr.HDOC_DR2_CAT = celdaCatalogoCAI.Text

            'Moneda y Tasa de Cambio
            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            If Sesion.IdEmpresa = 12 Then
                chdr.HDOC_DOC_TC = celdaTasa.Text
            Else
                chdr.HDOC_DOC_TC = celdaTasaFactura.Text
            End If

            'Clase (diferencia/devolución) y referencia (factura)
            If rbDifPrecio.Checked = True Then
                chdr.HDOC_DR1_CAT = vbEmpty
            ElseIf rbDevoluciones.Checked = True Then
                chdr.HDOC_DR1_CAT = INT_UNO
            ElseIf rbOtros.Checked = True Then
                chdr.HDOC_DR1_CAT = 2
            End If
            chdr.HDOC_DR1_NUM = dgFacturacion.CurrentRow.Cells("colNumero").Value

            'Declaración de reexportación, observaciones (notas) y total en letras
            chdr.HDOC_RF1_COD = celdaDeclaracion.Text
            chdr.HDOC_RF1_TXT = celdaNotasObservaciones.Text
            chdr.HDOC_RF2_TXT = CeldaTotalEnLetras.Text
            chdr.HDOC_RF1_DBL = celdaTasaFactura.Text

            'Guardar el CAI
            If Sesion.IdEmpresa = 11 Then
                chdr.HDOC_RF2_COD = celdaCAI.Text & "| " & celdaRangoFechaAutorizado.Text
            ElseIf Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                chdr.HDOC_RF2_COD = celdaCAI.Text
            ElseIf Sesion.IdEmpresa = 12 And Pais = 310 Or Sesion.IdEmpresa = 16 And Pais = 310 Then
                chdr.HDOC_RF2_COD = celdaGiro.Text
            End If
            If checkFacturaFiscal.Checked = True Then
                chdr.HDOC_ANT_COM = INT_UNO
            Else
                chdr.HDOC_ANT_COM = INT_CERO
            End If
            chdr.HDOC_RF3_DBL = dgFacturacion.Rows(0).Cells("saldo").Value


            If Me.Tag = "Mod" Then
                chdr.HDOC_DR1_DBL = celdaTemporal.Text
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If celdaTemporal.Text <> NO_FILA Then
                    chdr.HDOC_DR1_DBL = celdaTemporal.Text
                Else
                    chdr.HDOC_DR1_DBL = intNumero
                End If

                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Sub BorrarDetalleNC(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = 31 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                Dtl.DDOC_DOC_NUM = celdaNumero.Text

                Dtl.DDOC_DOC_LIN = i + 1

                Dtl.DDOC_PRD_QTY = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value).ToString(FORMATO_MONEDA)
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescription").Value
                Dtl.DDOC_PRD_NET = CDbl(dgDetalle.Rows(i).Cells("colUnitario").Value).ToString(FORMATO_MONEDA)
                Dtl.DDOC_RF1_DBL = CDbl(dgDetalle.Rows(i).Cells("colTotal").Value).ToString(FORMATO_MONEDA)
                Dtl.DDOC_RF2_DBL = CDbl(dgDetalle.Rows(i).Cells("colImpuesto").Value).ToString(FORMATO_MONEDA)
                Dtl.DDOC_RF3_DBL = CDbl(dgDetalle.Rows(i).Cells("colExepcion").Value).ToString(FORMATO_MONEDA)
                Dtl.DDOC_RF3_DBL = CDbl(dgDetalle.Rows(i).Cells("colExepcion").Value).ToString(FORMATO_MONEDA)
                If Me.Tag = "Mod" Then
                    If Dtl.Actualizar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf Me.Tag = "Nuevo" Then
                    If Dtl.Guardar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDetalleNC()
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion

        Try
            For i As Integer = 0 To dgDetalleNC.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                Dtl.DDOC_DOC_NUM = celdaNumero.Text
                If dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 0 Then
                    If dgDetalleNC.Rows(i).Visible = True Then
                        dgDetalleNC.Rows(i).Cells("colLinea").Value = i + 1
                        Dtl.DDOC_DOC_LIN = dgDetalleNC.Rows(i).Cells("colLinea").Value
                    End If
                Else
                    Dtl.DDOC_DOC_LIN = dgDetalleNC.Rows(i).Cells("colLinea").Value
                End If

                Dtl.DDOC_PRD_QTY = INT_UNO
                Dtl.DDOC_RF1_NUM = dgDetalleNC.Rows(i).Cells("colCatalogoDet").Value ' Catalogo de Factura
                Dtl.DDOC_RF2_NUM = dgDetalleNC.Rows(i).Cells("colAnioDet").Value ' Año de factura
                Dtl.DDOC_RF3_NUM = dgDetalleNC.Rows(i).Cells("colNumeroDet").Value 'Numero de la factura
                Dtl.DDOC_PRD_COD = dgDetalleNC.Rows(i).Cells("colLineaDet").Value 'Linea de la Factura
                Dtl.DDOC_PRD_FOB = dgDetalleNC.Rows(i).Cells("colCantidadDet").Value ' Cantidad de linea de factura
                Dtl.DDOC_PRD_UM = If(dgDetalleNC.Rows(i).Cells("colUMedidaDet").Value = "LBS", 69, 70) ' Unidad de medida de la factura
                Dtl.DDOC_PRD_PNR = dgDetalleNC.Rows(i).Cells("colDescripcionDet").Value ' Descripción del producto
                Dtl.DDOC_RF1_COD = dgDetalleNC.Rows(i).Cells("colReferenciaDet").Value ' Referencia de la factura
                Dtl.DDOC_PRD_DSP = dgDetalleNC.Rows(i).Cells("colPrecioDet").Value 'Precio del producto (de factura)
                Dtl.DDOC_PRD_PUQ = dgDetalleNC.Rows(i).Cells("colTotalDet").Value 'Total de la linea de la Factura
                Dtl.DDOC_PRD_DES = dgDetalleNC.Rows(i).Cells("colDescripcionNCDet").Value ' Descripcion de la NC
                Dtl.DDOC_PRD_CIF = dgDetalleNC.Rows(i).Cells("colLibrasDet").Value 'Libras devueltas en caso de ser devolución
                Dtl.DDOC_PRD_NET = CDbl(dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value).ToString(FORMATO_MONEDA) 'Valor de la linea de NC
                Dtl.DDOC_RF1_DBL = CDbl(dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value).ToString(FORMATO_MONEDA) ' Valor de la linea de NC
                Dtl.DDOC_RF2_DBL = CDbl(dgDetalleNC.Rows(i).Cells("colImpuestoDet").Value).ToString(FORMATO_MONEDA) 'Impuesto (para Amtex)
                Dtl.DDOC_RF3_DBL = CDbl(dgDetalleNC.Rows(i).Cells("colExcepcionDet").Value).ToString(FORMATO_MONEDA) ' Excepcion (para Amtex)
                If dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 1 Then
                    If Dtl.Actualizar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 0 Then
                    If Dtl.Guardar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 2 Then
                    If Dtl.Borrar = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub BorrarEctateNC(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 31 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarLineaEctateNC(ByVal num As Integer, ByVal anio As Integer, ByVal Lin As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 31 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} AND ECta_Doc_Lin = {lin} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            strSQL = Replace(strSQL, "{lin}", Lin)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarOperacionNC() As Boolean
        Dim logResultado As Boolean = True
        Dim EC As New Tablas.TECTACTE
        EC.CONEXION = strConexion
        Dim i As Integer = vbEmpty
        Dim dblCredito As Double
        Dim dblDebito As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO
        Dim dblTaxes As Double = INT_CERO
        Dim dblSales As Double = INT_CERO

        Try
            dblTasa = celdaTasaFactura.Text

            For i = 0 To dgDetalleNC.Rows.Count - 1
                dblCredito = vbEmpty
                dblDebito = vbEmpty

                If (checkActivar.Checked) = True And (dgFacturacion.Rows.Count > vbEmpty) Then
                    dblCredito = CDbl(dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value)
                End If
                If checkFacturaFiscal.Checked = True And Sesion.IdEmpresa = 16 Then
                    dblTaxes = CDbl(dgDetalleNC.Rows(i).Cells("colImpuestoDet").Value)
                    dblSales = CDbl(dgDetalleNC.Rows(i).Cells("colExcepcionDet").Value)
                End If

                'Datos de la Nota
                EC.ECTA_SIS_EMP = celdaEmpresa.Text
                EC.ECTA_DOC_CAT = celdaCatalogo.Text
                EC.ECTA_DOC_ANO = celdaAño.Text
                EC.ECTA_DOC_NUM = celdaNumero.Text

                EC.ECTA_DOC_LIN = dgDetalleNC.Rows(i).Cells("colLineaDet").Value

                strDato = CXC_NAME & "No." & CDbl(celdaNumero.Text)

                'Documento de referencia (factura)
                If dgFacturacion.Rows.Count = vbEmpty Then
                    EC.ECTA_REF_CAT = vbEmpty
                    EC.ECTA_REF_ANO = vbEmpty
                    EC.ECTA_REF_NUM = vbEmpty
                Else
                    If checkFacturaFiscal.Checked = True Then
                        EC.ECTA_REF_CAT = 296
                    Else
                        EC.ECTA_REF_CAT = 36
                    End If

                    EC.ECTA_REF_ANO = dgDetalleNC.Rows(i).Cells("colAnioDet").Value
                    EC.ECTA_REF_NUM = dgDetalleNC.Rows(i).Cells("colNumeroDet").Value
                    strDato = strDato & " / " & "Ref.Factura No." & dgDetalleNC.Rows(i).Cells("colNumeroDet").Value
                End If

                'Empresa 
                EC.ECTA_TIPOEMP = STR_TABLA
                EC.ECTA_CODEMP = celdaIDCliente.Text

                'Transacción: cargo/abono local y en moneda del doc.
                EC.ECTA_SINI_LOC = vbEmpty
                EC.ECTA_CRGO_LOC = (dblDebito * dblTasa)
                If checkFacturaFiscal.Checked = True And Sesion.IdEmpresa = 16 Then
                    EC.ECTA_ABNO_LOC = ((dblCredito * dblTasa) + dblTaxes - dblSales).ToString(FORMATO_MONEDA)
                Else
                    EC.ECTA_ABNO_LOC = (dblCredito * dblTasa).ToString(FORMATO_MONEDA)
                End If
                EC.ECTA_SINI_EXT = vbEmpty
                EC.ECTA_CRGO_EXT = dblDebito.ToString(FORMATO_MONEDA)
                If checkFacturaFiscal.Checked = True And Sesion.IdEmpresa = 16 Then
                    EC.ECTA_ABNO_EXT = (dblCredito + dblTaxes - dblSales).ToString(FORMATO_MONEDA)
                Else
                    EC.ECTA_ABNO_EXT = dblCredito.ToString(FORMATO_MONEDA)
                End If
                EC.ECTA_CONCEPTO = strDato
                EC.ECta_FecDcmt_NET = dtpFech.Value
                EC.ECta_FecVenc_NET = dtpFech.Value
                EC.ECTA_MONEDA = celdaIDMoneda.Text
                EC.ECTA_TC = celdaTasaFactura.Text
                EC.ECTA_TRANSID = INT_CERO
                If dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 1 Then
                    ActualizarReferencia()
                    'If EC.PUPDATE() = False Then
                    '    MsgBox(EC.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    'End If
                ElseIf dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 0 Then
                    If EC.PINSERT() = False Then
                        MsgBox(EC.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalleNC.Rows(i).Cells("colExtraDet").Value = 2 Then
                    BorrarLineaEctateNC(celdaNumero.Text, celdaAño.Text, dgDetalleNC.Rows(i).Cells("colLinea").Value)
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarOperacion() As Boolean
        Dim logResultado As Boolean = True
        Dim EC As New Tablas.TECTACTE
        EC.CONEXION = strConexion
        Dim i As Integer = vbEmpty
        Dim dblCredito As Double
        Dim dblDebito As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO

        Try
            dblTasa = celdaTasaFactura.Text

            For i = 0 To dgFacturacion.Rows.Count - 1
                dblCredito = vbEmpty
                dblDebito = vbEmpty

                If (checkActivar.Checked) = True And (dgFacturacion.Rows.Count > vbEmpty) Then
                    dblCredito = CDbl(dgDetalle.Rows(i).Cells("colTotal").Value)
                End If


                'Datos de la Nota
                EC.ECTA_SIS_EMP = celdaEmpresa.Text
                EC.ECTA_DOC_CAT = celdaCatalogo.Text
                EC.ECTA_DOC_ANO = celdaAño.Text
                EC.ECTA_DOC_NUM = celdaNumero.Text

                EC.ECTA_DOC_LIN = i + 1

                strDato = CXC_NAME & "No." & CDbl(celdaNumero.Text)

                'Documento de referencia (factura)
                If dgFacturacion.Rows.Count = vbEmpty Then
                    EC.ECTA_REF_CAT = vbEmpty
                    EC.ECTA_REF_ANO = vbEmpty
                    EC.ECTA_REF_NUM = vbEmpty
                Else
                    If Sesion.IdEmpresa = 10 Then
                        EC.ECTA_REF_CAT = 296
                    Else
                        If checkFacturaFiscal.Checked = True Then
                            EC.ECTA_REF_CAT = 296
                        Else
                            EC.ECTA_REF_CAT = 36
                        End If
                    End If
                    EC.ECTA_REF_ANO = dgFacturacion.Rows(i).Cells("colAño").Value
                    EC.ECTA_REF_NUM = dgFacturacion.Rows(i).Cells("colNumero").Value
                    strDato = strDato & " / " & "Ref.Factura No." & dgFacturacion.Rows(i).Cells("colNumero").Value
                End If

                'Empresa 
                EC.ECTA_TIPOEMP = STR_TABLA
                EC.ECTA_CODEMP = celdaIDCliente.Text

                'Transacción: cargo/abono local y en moneda del doc.
                EC.ECTA_SINI_LOC = vbEmpty
                EC.ECTA_CRGO_LOC = (dblDebito * dblTasa)
                EC.ECTA_ABNO_LOC = (dblCredito * dblTasa).ToString(FORMATO_MONEDA)
                EC.ECTA_SINI_EXT = vbEmpty
                EC.ECTA_CRGO_EXT = dblDebito.ToString(FORMATO_MONEDA)
                EC.ECTA_ABNO_EXT = dblCredito.ToString(FORMATO_MONEDA)
                EC.ECTA_CONCEPTO = strDato
                EC.ECta_FecDcmt_NET = dtpFech.Value
                EC.ECta_FecVenc_NET = dtpFech.Value
                EC.ECTA_MONEDA = celdaIDMoneda.Text
                EC.ECTA_TC = celdaTasaFactura.Text

                If Me.Tag = "Mod" Then
                    ActualizarReferencia()
                    'If EC.PUPDATE() = False Then
                    '    MsgBox(EC.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    'End If
                ElseIf Me.Tag = "Nuevo" Then
                    If EC.PINSERT() = False Then
                        MsgBox(EC.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub BorrarImpNC(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "MDoc_Sis_Emp = {empresa} AND MDoc_Doc_Cat = 31 AND MDoc_Doc_Ano = {anio} AND MDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim imp As New Tablas.TDCMTOS_IMP
            imp.CONEXION = strConexion
            imp.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarIVA() As Boolean
        Dim logResultado As Boolean = True
        Dim IMP As New Tablas.TDCMTOS_IMP
        Dim i As Integer = vbEmpty
        IMP.CONEXION = strConexion

        Try
            For i = 0 To dgImpuestos.Rows.Count - 1
                IMP.MDOC_SIS_EMP = Sesion.IdEmpresa
                IMP.MDOC_DOC_CAT = celdaCatalogo.Text
                IMP.MDOC_DOC_ANO = celdaAño.Text
                IMP.MDOC_DOC_NUM = celdaNumero.Text


                IMP.MDOC_DOC_LIN = dgImpuestos.Rows(i).Cells("colLin").Value
                IMP.MDOC_LIN_ID = dgImpuestos.Rows(i).Cells("colID").Value
                IMP.MDOC_LIN_CODIGO = dgImpuestos.Rows(i).Cells("colCode").Value
                IMP.MDOC_LIN_TIPO = dgImpuestos.Rows(i).Cells("colTipo").Value
                IMP.MDOC_LIN_DESC = dgImpuestos.Rows(i).Cells("colDescripcion").Value
                IMP.MDOC_LIN_BASE = dgImpuestos.Rows(i).Cells("colBase").Value
                IMP.MDOC_LIN_CANTIDAD = dgImpuestos.Rows(i).Cells("colCanti").Value
                IMP.MDOC_LIN_FACTOR = dgImpuestos.Rows(i).Cells("colFactor").Value
                IMP.MDOC_LIN_MONTO = dgImpuestos.Rows(i).Cells("colMonto").Value

                If Me.Tag = "Mod" Then
                    If IMP.PUPDATE() = False Then
                        MsgBox(IMP.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf Me.Tag = "Nuevo" Then
                    If IMP.PINSERT() = False Then
                        MsgBox(IMP.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Sub RangoFechaAutorizada()
        Dim strSQL As String = STR_VACIO
        Dim j As Integer = NO_FILA
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim REA As MySqlDataReader
        Dim ArrayRangoFechaAutorizada(10) As String

        strSQL = "   SELECT c.cat_desc  "
        strSQL &= "     FROM Catalogos c "
        strSQL &= "         WHERE c.cat_clase = 'RangoFecha' AND c.cat_clave = 'RAFNC' AND c.cat_sisemp = {empresa} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read

                ArrayRangoFechaAutorizada(0) = REA.GetString("cat_desc")
            Loop
        End If
        REA.Close()
        REA = Nothing
        COM = Nothing

        celdaRangoFechaAutorizado.Text = ArrayRangoFechaAutorizada(0)




    End Sub
    Private Sub CAI()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim REA As MySqlDataReader
        Dim strCAI As String = STR_VACIO

        'strSQL = "Select IFNULL(c.cat_desc,'') dato"
        'strSQL &= "      FROM Catalogos c"
        'strSQL &= "              WHERE c.cat_clase = 'Defaults' and c.cat_clave = 'CAINC'"


        strSQL = "SELECT IFNULL(g.regimen,'') dato
                    FROM Catalogos c
                    LEFT JOIN Gface g ON g.serie = c.cat_num
                    WHERE c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_CNCredito' AND c.cat_sist = '{serie}' and cat_pid=0"

        strSQL = strSQL.Replace("{serie}", celdaSerie1.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()

            celdaCAI.Text = REA.GetString("dato")
        End If


    End Sub
    Public Sub ActualizarReferencia()
        Dim COM As MySqlCommand
        Dim strSQL As String
        Dim dblAbonoExt As Double = 0
        Dim dblAbonoLoc As Double = 0
        Dim dblTotal As Double
        Dim dblTax As Double = INT_CERO
        Dim dblSales As Double = INT_CERO
        Dim dblCredito As Double
        Dim dblDebito As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO
        Dim cat As Integer = NO_FILA
        Dim anioRef As Integer = NO_FILA
        Dim numref As Integer = NO_FILA
        Dim numLinea As Integer = NO_FILA

        Try

            dblTasa = celdaTasaFactura.Text

            For i = 0 To dgDetalleNC.Rows.Count - 1
                dblCredito = vbEmpty
                dblDebito = vbEmpty
                dblTotal = vbEmpty
                numLinea = vbEmpty

                strDato = CXC_NAME & "No." & CDbl(celdaNumero.Text)

                numLinea = dgDetalleNC.Rows(i).Cells("colLineaDet").Value

                'Documento de referencia (factura)
                If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                    If Sesion.IdEmpresa = 9 Then
                        cat = 36
                    Else
                        cat = 296
                    End If

                    If (checkActivar.Checked) = True And (dgFacturacion.Rows.Count > vbEmpty) Then
                        dblTotal = CDbl(dgDetalle.Rows(i).Cells("colTotal").Value)
                    End If
                Else

                    If (checkActivar.Checked) = True And (dgFacturacion.Rows.Count > vbEmpty) Then
                        dblTotal = CDbl(dgDetalleNC.Rows(i).Cells("colTotalNCDet").Value)
                    End If
                    If checkFacturaFiscal.Checked = True Then
                        cat = 296
                    Else
                        cat = 36
                    End If
                End If
                If checkFacturaFiscal.Checked = True And Sesion.IdEmpresa = 16 Then
                    dblTax = CDbl(dgDetalleNC.Rows(i).Cells("colImpuestoDet").Value)
                    dblSales = CDbl(dgDetalleNC.Rows(i).Cells("colExcepcionDet").Value)
                End If

                If (dgFacturacion.Rows.Count > 0) Then
                    anioRef = dgFacturacion.Rows(0).Cells("colAño").Value
                    numref = dgFacturacion.Rows(0).Cells("colNumero").Value
                    strDato = strDato & " / " & "Ref.Factura No." & dgFacturacion.Rows(0).Cells("colNumero").Value
                End If
                'Transacción: cargo/abono local y en moneda del doc.
                If checkFacturaFiscal.Checked = True And Sesion.IdEmpresa = 16 Then
                    dblCredito = ((dblTotal * dblTasa) + dblTax - dblSales).ToString(FORMATO_MONEDA)
                    dblTotal = (dblTotal + dblTax - dblSales)
                Else
                    dblCredito = (dblTotal * dblTasa).ToString(FORMATO_MONEDA)
                End If

                strSQL = " UPDATE  ECtaCte  e  SET e.ECta_codemp = {cliente},e.ECta_Abno_Loc = {total}, e.ECta_Abno_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fecha}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
                strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 31  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} and e.ECta_Doc_Lin = {numLinea} "

                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "; UPDATE PDM.ECtaCte  e  SET e.ECta_codemp = {cliente},e.ECta_Abno_Loc = {total}, e.ECta_Abno_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fecha}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
                    strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 31  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} and e.ECta_Doc_Lin = {numLinea} "
                End If

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{numLinea}", numLinea)
                strSQL = Replace(strSQL, "{total}", dblCredito)
                strSQL = Replace(strSQL, "{totalext}", dblTotal)
                strSQL = Replace(strSQL, "{dato}", strDato)
                strSQL = Replace(strSQL, "{cliente}", celdaIDCliente.Text)
                strSQL = Replace(strSQL, "{fecha}", dtpFech.Value.ToString(FORMATO_MYSQL))
                strSQL = Replace(strSQL, "{moneda}", celdaIDMoneda.Text)
                strSQL = Replace(strSQL, "{tasa}", celdaTasaFactura.Text)
                strSQL = Replace(strSQL, "{catref}", cat)
                strSQL = Replace(strSQL, "{anioref}", anioRef)
                strSQL = Replace(strSQL, "{numref}", numref)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
                COM.Dispose()
                System.GC.Collect()

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function CalcularIVA13() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim dblImpuestos As Double
        strSQL = STR_VACIO
        strSQL = " select c.cat_sist  from Catalogos c "
        strSQL &= " where c.cat_clase = 'Impuestos' and c.cat_clave = 'IVA' and c.cat_sisemp =  " & Sesion.IdEmpresa
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dblImpuestos = CDbl(COM.ExecuteScalar)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblImpuestos
    End Function

#End Region

#Region "Eventos"


    Private Sub frmNotasDeCredito_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpInicio.Value = Today.AddDays(-15)
        dtpFin.Value = Today

        Accessos()
        MostrarLista()
        If Sesion.IdEmpresa = 9 Then
            gbFelServi.Visible = True
        Else
            gbFelServi.Visible = False
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            Me.Tag = "Nuevo"
            Dim opt As New frmOption
            Dim i As Integer = vbEmpty
            Dim strFila As String = STR_VACIO
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim conec As MySqlConnection
            Dim Serie As String = STR_VACIO

            LimpiarFormulario()
            MostrarLista(False)
            If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                dgDetalle.Visible = True
                dgDetalleNC.Visible = False
                dgDetalle.Dock = DockStyle.Fill
                dgDetalleNC.Dock = DockStyle.None
            Else
                dgDetalle.Visible = False
                dgDetalleNC.Visible = True
                dgDetalle.Dock = DockStyle.None
                dgDetalleNC.Dock = DockStyle.Fill
            End If

            opt.Titulo = "Option"
            opt.Mensaje = "Select an option"
            opt.Opciones = "Descuento Sobre Ventas" & "|" & "Devoluciones" & "|" & "Otros"

            If opt.ShowDialog = DialogResult.OK Then

                Select Case opt.Seleccion

                    Case 0
                        intTipo = 0
                        Me.Tag = "Nuevo"
                    Case 1
                        intTipo = 1
                        Me.Tag = "Nuevo"
                    Case 2
                        intTipo = 2
                        Me.Tag = "Nuevo"
                End Select
            Else
                Exit Sub
            End If

            If intTipo = 0 Then
                rbDifPrecio.Checked = True
            ElseIf intTipo = 1 Then
                rbDevoluciones.Checked = True
            ElseIf intTipo = 2 Then
                rbOtros.Checked = True

            End If

            If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then

                For i = 0 To dgDetalle.Rows.Count
                    If intTipo = 0 Then
                        strFila = "1.0" & "|"
                        strFila &= "DESCUENTO SOBRE VENTAS" & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA)

                        cFunciones.AgregarFila(dgDetalle, strFila)
                    ElseIf intTipo = 1 Then
                        strFila = "1.0" & "|"
                        strFila &= "DEVOLUCION DE MERCADERIA" & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA)

                        cFunciones.AgregarFila(dgDetalle, strFila)
                    ElseIf intTipo = 2 Then
                        strFila = "1.0" & "|"
                        strFila &= "" & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                        strFila &= 0.ToString(FORMATO_MONEDA)

                        cFunciones.AgregarFila(dgDetalle, strFila)
                    End If
                Next
            Else
                If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                    dgDetalleNC.Columns(12).Visible = True
                    dgDetalleNC.Columns(13).Visible = True
                Else
                    dgDetalleNC.Columns(12).Visible = False
                    dgDetalleNC.Columns(13).Visible = False
                End If
            End If

            'Query que carga el IVA para las empresas que si pagan
            sqlCargarIVA()

            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaCatalogo.Text = 31
            celdaUsuario.Text = Sesion.Usuario
            celdaAño.Text = cFunciones.AñoMySQL
            dtpFech.Value = cFunciones.HoyMySQL
            If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Then
                celdaMoneda.Text = "Q/"
                celdaIDMoneda.Text = 177
                celdaTasa.Text = INT_UNO
            Else
                celdaMoneda.Text = "US$"
                celdaIDMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            End If
            celdaTasaFactura.Enabled = True
            celdaDeclaracion.Enabled = True


            'Trae el dato de la serie parfa el docuemnto
            strSQL = "SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase='Serie' AND cat_clave='Doc_CNCredito' AND cat_pid = 0"

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Serie = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            celdaSerie1.Text = Serie

            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                'Cargar CAI
                celdaCAI.Visible = True
                etiquetaCAI.Visible = True
                CAI()
                RangoFechaAutorizada()
            Else
                celdaCAI.Text = INT_CERO
            End If
            etiquetaSerie.Visible = False
            etiquetaAutorizacion.Visible = False
            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or Sesion.IdEmpresa = 10 Then
                ActivarFel()
            End If
            rbDevoluciones.Enabled = False
            rbOtros.Enabled = False
            rbDifPrecio.Enabled = False
            If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                etiquetaGiro.Visible = True
                celdaGiro.Visible = True
                checkFacturaFiscal.Visible = True
                checkFacturaFiscal.Checked = False
                dgDetalle.Columns(3).Visible = False
                dgDetalle.Columns(4).Visible = False
                celdaImpuesto.Visible = False
                celdaSub.Visible = False
                celdaExepcion.Visible = False
                celdaImpuesto.Text = INT_CERO
                celdaExepcion.Text = INT_CERO
                celdaSub.Text = INT_CERO
                etiquetaImpuesto.Visible = False
                etiquetaExepcion.Visible = False
                etiquetaSubTotal.Visible = False
            End If
        Else
            MsgBox("You do not have permissions for this action", vbCritical, "Notice")
        End If

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim clsConta As New clsContabilidad
        Dim cls As New clsFunciones
        Dim logVacio As Boolean
        Dim dtpFechaConta As Date

        If (CDbl(celdaTotal.Text) <= dgFacturacion.Rows(0).Cells("saldo").Value) Then

        ElseIf (Sesion.idGiro = 1) Then
            MsgBox("The amount cannot exceed the invoice balance.", vbExclamation)
            Exit Sub
        End If

        If Me.Tag = "Nuevo" Then
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                celdaCatalogoCAI.Text = cFunciones.Traer_Cat_Num_Ret("Doc_CNCredito")
            Else
                celdaCatalogoCAI.Text = 0
            End If
            logVacio = Me.Tag = "Nuevo" And checkActivar.Checked = False
            ProcesoGuardarDocumento()

            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
                MostrarLista()
            Else
                If Not logVacio Then
                    If MsgBox("The data has been saved" & vbCr & vbCr & "Print the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Imprimir") = vbYes Then
                        ImprimirNC()
                    Else
                        MostrarLista()
                    End If
                End If
            End If

        ElseIf Me.Tag = "Mod" Then

            'Como es una modificación verifica la fecha de la poliza si es que el documento tiene, si no captura la fecha del documento
            dtpFechaConta = cfun.SQLValidarFechaContable(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text)

            If cfun.SQLVerificarCierre(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text) = 0 Then
                ProcesoGuardarDocumento()
                clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, dtpFechaConta.ToString(FORMATO_MYSQL))

                If Not logVacio Then
                    If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                        MostrarLista()
                    Else
                        If MsgBox("The data has been saved" & vbCr & vbCr & "Print the document?", vbYesNo + vbQuestion, "Imprimir") = vbYes Then
                            ImprimirNC()
                        Else
                            MostrarLista()
                        End If

                    End If
                End If
            Else 'Si hay cierra solicita autorización
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cfun.AutorizarCambios = True Then
                    'registra quien autoriza
                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, celdaIDCliente.Text, 31, celdaAño.Text, celdaNumero.Text)
                    ProcesoGuardarDocumento()
                    clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, dtpFechaConta.ToString(FORMATO_MYSQL))
                    If Not logVacio Then
                        If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
                            MostrarLista()
                        Else
                            If MsgBox("The data has been saved" & vbCr & vbCr & "Print the document?", vbYesNo + vbQuestion, "Imprimir") = vbYes Then
                                ImprimirNC()
                            Else
                                MostrarLista()
                            End If

                        End If
                    End If
                End If
            End If
        End If
    End Sub
    Private Function NuevaCredito() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}   "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 31)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub ProcesoGuardarDocumento()
        Dim logNuevo As Boolean
        Dim logVacio As Boolean
        Dim clsConta As New clsContabilidad
        Dim cls As New clsFunciones
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        Try
            logNuevo = Me.Tag = "Nuevo"

            logVacio = logNuevo And checkActivar.Checked = False
            If logVacio Then
                If (dgFacturacion.Rows.Count > vbEmpty) Then
                    MsgBox("For the entry of voided notes you should not have referenced invoices", vbExclamation, "Notice")
                    Exit Sub
                ElseIf MsgBox("Enter null note?", vbQuestion + vbYesNo + vbDefaultButton2, "Confirm") = vbNo Then
                    Exit Sub
                End If
            End If

            If ComprobarIngreso() Then
                If logNuevo Then
                    If celdaNumero.Text = NO_FILA Then
                        celdaNumero.Text = NuevaCredito()
                    End If

                    If celdaNumero.Text > vbEmpty Then

                        If logVacio Then
                            dgDetalle.Rows(vbEmpty).Cells("colDescription").Value = "- A N U L A D A -"
                        End If
                        GuardarDocumento()
                        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                            GuardarDetalle()
                        Else
                            GuardarDetalleNC()
                        End If

                        GuardarIVA()
                        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                            GuardarOperacion()
                            If Sesion.IdEmpresa = 9 Then
                                GuardarFelServiImport()
                            End If
                        Else
                            GuardarOperacionNC()
                        End If

                        'Registra transaccion
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 31, celdaAño.Text, celdaNumero.Text)

                        'Integración Contable
                        ' verifica si hay cierre, si no hay guarda la fecha del documento
                        If cfun.SQLVerificarCierre(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text) = 0 Then
                            clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, dtpFech.Value.ToString(FORMATO_MYSQL))
                        Else
                            ' si hay cierre guarda la poliza con fecha de hoy
                            clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, cfun.HoyMySQL.ToString(FORMATO_MYSQL))
                        End If

                    End If
                ElseIf Me.Tag = "Mod" Then
                    If celdaNumero.Text > vbEmpty Then

                        If logVacio Then
                            dgDetalle.Rows(vbEmpty).Cells("colDescription").Value = "- A N U L A D A -"
                        End If

                        If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
                            If celdaUUID.Text <> STR_VACIO Then
                                If checkActivar.Checked = False Then
                                    ArrayServer = strConexion.Split(";".ToCharArray)
                                    strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                                    ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                                    strCadena = ArrayServer(INT_CERO)
                                    ArrayValidacion = strCadena.Split(".".ToCharArray)
                                    strCadena = ArrayValidacion(INT_CERO)
                                    arrayIP = strCadena.Split("=".ToCharArray)
                                    If arrayIP(INT_UNO) = "192" Then
                                        If Sesion.IdEmpresa = 10 Then
                                            If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                                            Else
                                                Exit Sub
                                            End If
                                        Else
                                            If VerificarAccesoLocal(IP, strUsuario, strContrasena, strRuta) = True Then
                                            Else
                                                Exit Sub
                                            End If
                                        End If
                                    Else
                                        If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                    If Sesion.IdEmpresa = 10 Then
                                        If PermisoAnular() = True Then
                                            If (DateDiff("d", dtpFech.Value, Now) > 5) And (dtpFech.Value <= cfun.UltimoDiaSiguienteMes(dtpFech.Value)) Then
                                                If PedirAutorizacionAnularFel("Anulacion Fel") = True Then
                                                    If AnularFelCMC(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                                        MsgBox("You don't have access to cancel this document")
                                                        Exit Sub
                                                    End If
                                                Else
                                                    MsgBox("You don't have access to cancel this document")
                                                    Exit Sub
                                                End If
                                            ElseIf (DateDiff("d", dtpFech.Value, Now) <= 5) Then
                                                If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                                    Exit Sub
                                                Else
                                                    MsgBox("You don't have access to cancel this document")
                                                    Exit Sub
                                                End If
                                            Else
                                                MsgBox("You don't have access to cancel this document")
                                                Exit Sub
                                            End If
                                        Else
                                            MsgBox("You don't have access to cancel this document")
                                            Exit Sub
                                        End If

                                    Else
                                        If PermisoAnular() = True Then
                                            If (DateDiff("d", dtpFech.Value, Now) > 5) And (dtpFech.Value <= cfun.UltimoDiaSiguienteMes(dtpFech.Value)) Then
                                                If PedirAutorizacionAnularFel("Anulacion Fel") = True Then
                                                    If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                                        MsgBox("You don't have access to cancel this document")
                                                        Exit Sub
                                                    End If
                                                Else
                                                    MsgBox("You don't have access to cancel this document")
                                                    Exit Sub
                                                End If
                                            ElseIf (DateDiff("d", dtpFech.Value, Now) <= 5) Then
                                                If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                                    MsgBox("You don't have access to cancel this document")
                                                    Exit Sub
                                                End If
                                            Else
                                                MsgBox("You don't have access to cancel this document")
                                                Exit Sub
                                            End If
                                        Else
                                            MsgBox("You don't have access to cancel this document")
                                            Exit Sub
                                        End If

                                    End If
                                End If
                            Else
                                If checkActivar.Checked = False Then
                                    MsgBox("You cannot cancel a document that is not transmitted" & vbNewLine & "please contact the Financial department.")
                                    Exit Sub
                                End If
                            End If
                        End If
                        GuardarDocumento()
                        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                            GuardarDetalle()
                        Else
                            GuardarDetalleNC()
                        End If
                        GuardarIVA()
                        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                            GuardarOperacion()
                            If Sesion.IdEmpresa = 9 Then
                                GuardarFelServiImport()
                            End If
                        Else
                            GuardarOperacionNC()
                        End If

                        'Registra transaccion
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 31, celdaAño.Text, celdaNumero.Text)

                    End If
                Else
                    MsgBox("It was not possible  to classify the operation to save", vbExclamation, "Notice")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            'strOrigen = PrepararListado

            'Procedimiento para cargar panel dgLista
            queryListaPrincipal()
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer = vbEmpty
        Dim numero As Integer = vbEmpty

        Try
            Me.Tag = "Mod"
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(2).Value
            LimpiarFormulario()
            MostrarLista(0)
            If Sesion.IdEmpresa = 11 Then
                celdaCAI.Visible = True
                etiquetaCAI.Visible = True
            Else
            End If
            SeleccionarCliente(año, numero)
            If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                dgDetalle.Visible = True
                dgDetalleNC.Visible = False
                dgDetalle.Dock = DockStyle.Fill
                dgDetalleNC.Dock = DockStyle.None
                queryDetalle(año, numero)
            Else
                dgDetalle.Visible = False
                dgDetalleNC.Visible = True
                dgDetalle.Dock = DockStyle.None
                dgDetalleNC.Dock = DockStyle.Fill
                queryDetalleNC(año, numero)
            End If

            queryDocProcesados()
            sqlCargarIVA()
            CalcularTotales()
            CeldaTotalEnLetras.Text = cFunciones.ALetras(celdaTotal.Text).ToUpper
            celdaTasaFactura.Enabled = True
            celdaDeclaracion.Enabled = True
            If Sesion.IdEmpresa = 9 Then
                CargarDatosFelServiImport(año, numero)
            End If
            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
                CargarDatosFel()
                If celdaSerieFel.Text <> STR_VACIO Then
                    BloquearFel()
                Else
                    ActivarFel()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonAgregarFactura_Click(sender As Object, e As EventArgs) Handles botonAgregarFactura.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cliente As String = STR_VACIO
        Dim opt As New frmOption

        If celdaIDCliente.Text > NO_FILA Then

            strSQL = "SELECT c.cli_cliente cliente"
            strSQL &= "      FROM Clientes c"
            strSQL &= "          WHERE c.cli_sisemp = {empresa} AND c.cli_codigo = {IDCliente}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{IDCliente}", celdaIDCliente.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Cliente = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            Me.Tag = "Nuevo"
            Dim frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String

            strCondicion = "HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = {Catalogo}) AND (HDoc_Emp_Cod = {CodEmpresa}) AND HDoc_Doc_Status = 1"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{CodEmpresa}", celdaIDCliente.Text)
            If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 13 Then
                Cat = 296
            Else
                If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 Then
                    If checkFacturaFiscal.Checked = True Then
                        Cat = 296
                    Else
                        Cat = 36
                    End If
                Else
                    Cat = 36
                End If
            End If
            strCondicion = Replace(strCondicion, "{Catalogo}", Cat)
            Try
                frm.Titulo = "INVOICE"
                'Se agrego una nuevo funcion al selecionar, por que generaba errores al separar por comas
                frm.MultipleNV = True
                frm.Tabla = " Dcmtos_HDR a LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num
                            LEFT JOIN (
                            SELECT 
                            e.ECta_Sis_Emp,
                            e.ECta_Ref_Cat,
                            e.ECta_Ref_Ano,
                            e.ECta_Ref_Num,
                             GROUP_CONCAT( CONCAT ( CASE e.ECta_Doc_Cat
										    WHEN 31 THEN 'ND'
										    WHEN 32 THEN 'NC'
										    WHEN 54 THEN 'CH'
										  END,
										  ': ',d.HDoc_Doc_Num) SEPARATOR ' / ')  AS notasCredito,
                            ROUND(SUM(IF(ECta_moneda = emp.emp_moneda,IFNULL(ECta_Abno_Loc,0),IFNULL(ECta_Abno_Ext,0))),2) 
					 		- ROUND(SUM(IF(ECta_moneda = emp.emp_moneda,IFNULL(ECta_Crgo_Loc,0),IFNULL(ECta_Crgo_Ext,0))),2) TotalNotas
                            FROM ECtaCte e
                            LEFT JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = e.ECta_Sis_Emp
                            AND d.HDoc_Doc_Cat = e.ECta_Doc_Cat
                            AND d.HDoc_Doc_Ano = e.ECta_Doc_Ano
                            AND d.HDoc_Doc_Num = e.ECta_Doc_Num
                            LEFT JOIN Catalogos t ON t.cat_num = e.ECta_moneda
                            AND t.cat_clase = 'Monedas'
                            LEFT JOIN Catalogos l ON l.cat_num = e.ECta_Doc_Cat
                            AND l.cat_clase ='Documentos'
                            LEFT JOIN Empresas emp ON emp.emp_no = e.ECta_Sis_Emp
                            WHERE e.ECta_Ref_Cat = 36 AND NOT e.ECta_Doc_Cat = 36 AND (e.ECta_Ref_Ano = " & Year(Now) & " OR  e.ECta_Ref_Ano = " & Year(Now) - 1 & ") 
                            GROUP BY
                            e.ECta_Sis_Emp, e.ECta_Ref_Cat, e.ECta_Ref_Ano, e.ECta_Ref_Num
                            ) AS NOTA ON NOTA.ECta_Sis_Emp = a.HDoc_Sis_Emp
                            AND NOTA.ECta_Ref_Ano = a.HDoc_Doc_Ano
                            AND NOTA.ECta_Ref_Num = a.HDoc_Doc_Num "
                frm.FiltroText = " Enter the Invoice to filter"
                If Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    frm.Filtro = "  HDoc_DR1_Dbl"
                    frm.Campos = "  HDoc_Doc_Ano Year, HDoc_Doc_Num Correlative, IF(HDoc_Doc_Cat= 36,HDoc_DR1_Dbl,HDoc_DR2_Cat) Invoice, CAST(HDoc_Doc_Fec AS CHAR) Date, HDoc_Usuario User, COALESCE(HDoc_DR1_Num,'') Reference, a.HDoc_Ant_Com Impuesto,
                                   IFNULL(NOTA.notasCredito,'') ReferenceNotas,
                                    ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ,1) * IFNULL(b.DDoc_Prd_QTY,1)),2) TotalFactura,
                                    IFNULL(NOTA.TotalNotas,0) TotalNotas,
                                    (ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ,1) * IFNULL(b.DDoc_Prd_QTY,1)),2) - IFNULL(SUM(NOTA.TotalNotas),0)) Saldo"
                ElseIf Sesion.IdEmpresa = 10 Then
                    frm.Filtro = "  HDoc_Doc_Num"
                    frm.Campos = " HDoc_Doc_Ano Year, HDoc_Doc_Num Correlative, IF(HDoc_Doc_Cat= 36,HDoc_DR1_Dbl,HDoc_DR2_Cat) Invoice, CAST(HDoc_Doc_Fec AS CHAR) Date, HDoc_Usuario User, COALESCE(HDoc_Doc_Num,'') Reference, a.HDoc_Ant_Com Impuesto,
                                    IFNULL(NOTA.notasCredito,'') ReferenceNotas,
                                    ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ,1) * IFNULL(b.DDoc_Prd_QTY,1)),2) TotalFactura,
                                    IFNULL(NOTA.TotalNotas,0) TotalNotas,
                                    (ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ,1) * IFNULL(b.DDoc_Prd_QTY,1)),2) - IFNULL(SUM(NOTA.TotalNotas),0)) Saldo"

                Else
                    frm.Campos = " HDoc_Doc_Ano Year, HDoc_Doc_Num Number, CAST(HDoc_Doc_Fec AS CHAR) Date, HDoc_Usuario User, COALESCE(HDoc_DR1_Num,'') Reference,
                                    IFNULL(NOTA.notasCredito,'') ReferenceNotas,
                                    ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ,1) * IFNULL(b.DDoc_Prd_QTY,1)),2) TotalFactura,
                                    IFNULL(NOTA.TotalNotas,0) TotalNotas,
                                    (ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ,1) * IFNULL(b.DDoc_Prd_QTY,1)),2) - IFNULL(SUM(NOTA.TotalNotas),0)) Saldo"
                    frm.Filtro = "  HDoc_Doc_Num"
                End If

                frm.Limite = 30
                frm.Ordenamiento = " HDoc_Doc_Ano DESC, HDoc_Doc_Num "
                frm.TipoOrdenamiento = "DESC"
                frm.Condicion = strCondicion
                frm.Agrupar = " a.HDoc_Doc_Ano,
                                a.HDoc_Doc_Num, 
                                a.HDoc_Doc_Fec, 
                                a.HDoc_Usuario,                                                                                  
                                COALESCE(a.HDoc_DR1_Num, '') "
                frm.Condicion2 = " (ROUND(SUM(IFNULL(b.DDoc_Prd_PUQ, 1) * IFNULL(b.DDoc_Prd_QTY, 1)), 2) - IFNULL(SUM(NOTA.TotalNotas), 0)) > 0 "

                If dgFacturacion.Rows.Count = 1 Then
                    MsgBox("If you enter multiple invoices may be incorrect", vbExclamation, "Notice")
                    Exit Sub
                End If

                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    'Informa sobre agregar mas de una factura y no esta permitido

                    strFila = frm.ListaClientes.SelectedCells(0).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"

                    If (Sesion.IdEmpresa = 14) Or (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Or (Sesion.IdEmpresa = 10) Or Sesion.idGiro = 2 Then
                        strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                        strFila &= frm.ListaClientes.SelectedCells(4).Value & "|"
                        strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                        strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                        'strFila &= frm.ListaClientes.SelectedCells(8).Value
                        strFila &= frm.ListaClientes.SelectedRows(0).Cells("col_Saldo").Value.ToString()

                        'strFila &= frm.ListaClientes.SelectedRows(0)

                        'strFila &= dgFacturacion.CurrentRow.Cells("colFecha").Value

                        dgFacturacion.Columns(5).Visible = True
                        IntCalcularImpuesto = frm.ListaClientes.SelectedCells(6).Value
                    Else
                        strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                        strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                        strFila &= frm.ListaClientes.SelectedCells(4).Value & "|"
                        strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                        strFila &= frm.ListaClientes.SelectedRows(0).Cells("col_Saldo").Value.ToString()
                        dgFacturacion.Columns(5).Visible = False
                    End If

                    cFunciones.AgregarFila(dgFacturacion, strFila)
                    If checkFacturaFiscal.Checked = True Then
                        celdaTasaFactura.Text = INT_UNO
                    Else
                        celdaTasaFactura.Text = TasaCambioFactura(frm.LLave, frm.Dato)
                    End If

                    CargarDiferencia(vbEmpty, Cat)
                End If



            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try


        End If
    End Sub

    Private Sub botonClientes_Click(sender As Object, e As EventArgs) Handles botonClientes.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_nit, c.cli_telefono,IFNULL(c.cli_Giro,'') Giro "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaNIT.Text = frm.Dato3
                celdaTelefono.Text = frm.Dato4
                celdaGiro.Text = frm.ListaClientes.SelectedCells(5).Value

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim Cantidad As Integer = vbEmpty
        Dim Precio As Double
        Dim Total As Double

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 0
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    Cantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                    Precio = dgDetalle.Rows(i).Cells("colUnitario").Value
                    Total = (Cantidad * Precio)

                    dgDetalle.Rows(i).Cells("colTotal").Value = Total.ToString(FORMATO_MONEDA)

                    celdaSubTotal.Text = Cantidad.ToString(FORMATO_MONEDA)
                    celdaTotal.Text = Total.ToString(FORMATO_MONEDA)
                    CeldaTotalEnLetras.Text = cFunciones.ALetras(dgDetalle.CurrentRow.Cells(3).Value).ToUpper
                Next
            Case 2

                For i As Integer = 0 To dgDetalle.Rows.Count - 1

                    Cantidad = dgDetalle.Rows(i).Cells("colCantidad").Value
                    Precio = dgDetalle.Rows(i).Cells("colUnitario").Value
                    Total = (Cantidad * Precio)
                    If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 16 And Pais() = 310 Then
                        If Cat = 296 Then
                            celdaImpuesto.Text = INT_CERO
                            celdaExepcion.Text = INT_CERO
                            celdaSub.Text = INT_CERO
                            dgDetalle.Rows(i).Cells("colImpuesto").Value = INT_CERO
                            dgDetalle.Rows(i).Cells("colExepcion").Value = INT_CERO
                            celdaSub.Text = Total.ToString(FORMATO_MONEDA)
                            celdaImpuesto.Text = CDbl(Total * CalcularIVA13() / 100).ToString(FORMATO_MONEDA)
                            dgDetalle.Rows(i).Cells("colImpuesto").Value = CDbl(Total * CalcularIVA13() / 100).ToString(FORMATO_MONEDA)
                            If IntCalcularImpuesto = 1 Then
                                dgDetalle.Rows(i).Cells("colExepcion").Value = CDbl(Total / 100).ToString(FORMATO_MONEDA)
                                celdaExepcion.Text = CDbl(Total / 100).ToString(FORMATO_MONEDA)
                            End If
                        Else
                            celdaImpuesto.Text = INT_CERO
                            celdaExepcion.Text = INT_CERO
                            celdaSub.Text = INT_CERO
                            dgDetalle.Rows(i).Cells("colImpuesto").Value = INT_CERO
                            dgDetalle.Rows(i).Cells("colExepcion").Value = INT_CERO
                        End If
                    Else
                        celdaImpuesto.Text = INT_CERO
                        celdaExepcion.Text = INT_CERO
                        celdaSub.Text = INT_CERO
                        dgDetalle.CurrentRow.Cells("colImpuesto").Value = INT_CERO
                        dgDetalle.CurrentRow.Cells("colExepcion").Value = INT_CERO

                    End If

                    dgDetalle.Rows(i).Cells("colTotal").Value = CDbl((Total + dgDetalle.Rows(i).Cells("colImpuesto").Value - dgDetalle.Rows(i).Cells("colExepcion").Value)).ToString(FORMATO_MONEDA)

                    celdaSubTotal.Text = Cantidad.ToString(FORMATO_MONEDA)
                    celdaTotal.Text = CDbl((Total + dgDetalle.Rows(i).Cells("colImpuesto").Value - dgDetalle.Rows(i).Cells("colExepcion").Value))
                    CeldaTotalEnLetras.Text = cFunciones.ALetras(dgDetalle.CurrentRow.Cells(5).Value).ToUpper

                    For j As Integer = 0 To dgImpuestos.Rows.Count - 1
                        dgImpuestos.Rows(i).Cells("colBase").Value = CDbl(Total / 1.12).ToString(FORMATO_MONEDA)
                        dgImpuestos.Rows(i).Cells("colMonto").Value = CDbl((Total / 1.12) * 0.12).ToString(FORMATO_MONEDA)
                    Next
                Next

        End Select

    End Sub

    'Muestra la póliza contable del documento indicado
    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim NP As New clsPolizaContable

        'Verificar si posee poliza
        strSQL = "SELECT poliza"
        strSQL &= "  FROM {conta}.polizas"
        strSQL &= "          WHERE empresa = {empresa} AND ref_tipo = 31 AND ref_ciclo = {ciclo} AND ref_numero = {numero} "

        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ciclo}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                NP.intModo = 13
                NP.intTipo = 31
                NP.intCiclo = celdaAño.Text
                NP.intNumero = celdaNumero.Text
                NP.MostrarPolizaContable()
            Else
                MsgBox("No tiene poliza contable", vbExclamation, "Notice")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency, cat_sist TC"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFech.Text)
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Procedimientos Fel
    Private Function GenerarUUID() As String
        Dim UUID As String
        UUID = System.Guid.NewGuid.ToString.ToUpper
        ' MsgBox(UUID)
        Return UUID
    End Function
    Public Sub ActivarFel()
        celdaAño.Enabled = True
        celdaNumero.Enabled = True
        celdaDireccion.Enabled = True
        celdaTelefono.Enabled = True
        celdaNIT.Enabled = True
        celdaMoneda.Enabled = True
        botonMoneda.Enabled = True
        celdaTasa.Enabled = True
        celdaTasaFactura.Enabled = True
        celdaDeclaracion.Enabled = True
        celdaNotasObservaciones.Enabled = True
        dgFacturacion.Enabled = True
        dgDetalle.Enabled = True
        dgImpuestos.Enabled = True
        CeldaTotalEnLetras.Enabled = True
        celdaSubTotal.Enabled = True
        celdaTotal.Enabled = True
        dtpFech.Enabled = True
        botonSerie.Enabled = True
        botonClientes.Enabled = True
        botonMoneda.Enabled = True
        botonAgregarFactura.Enabled = True
        Button1.Enabled = True
        Encabezado1.botonGuardar.Enabled = True
        Encabezado1.botonBorrar.Enabled = True
        checkRevisado.Enabled = True
        botonPrevio.Enabled = True
    End Sub
    Public Sub BloquearFel()
        celdaAño.Enabled = False
        celdaNumero.Enabled = False
        celdaDireccion.Enabled = False
        celdaTelefono.Enabled = False
        celdaNIT.Enabled = False
        celdaMoneda.Enabled = False
        botonMoneda.Enabled = False
        celdaTasa.Enabled = False
        celdaTasaFactura.Enabled = False
        celdaDeclaracion.Enabled = False
        celdaNotasObservaciones.Enabled = False
        dgFacturacion.Enabled = False
        dgDetalle.Enabled = False
        dgImpuestos.Enabled = False
        CeldaTotalEnLetras.Enabled = False
        celdaSubTotal.Enabled = False
        celdaTotal.Enabled = False
        botonMoneda.Enabled = False
        rbDevoluciones.Enabled = False
        rbOtros.Enabled = False
        rbDifPrecio.Enabled = False
        dtpFech.Enabled = False
        botonSerie.Enabled = False
        botonClientes.Enabled = False
        botonAgregarFactura.Enabled = False
        Button1.Enabled = False
        checkRevisado.Enabled = False
        botonBuscar.Enabled = False

        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = False
    End Sub
    Private Function PermisoAnular() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_codigo Permiso"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_usuario = '{usuario}' AND p.pms_modulo = 88 AND p.pms_codigo  ='ANULAR'"
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetString("Permiso") = "ANULAR" Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    Private Function PedirAutorizacionAnularFel(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AnularFEL"
        Dim frm As frmAutorización
        PedirAutorizacionAnularFel = False

        frm = New frmAutorización
        frm.Iniciar(31, STR_MARGEN, 0, "Autorizar Anula Fel")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionAnularFel = True
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, celdaIDCliente.Text, celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text, "Autoriza anulacion FEL " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
    Public Sub ImprimirPDFGenerado(ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String)
        Dim Proceso As New Process
        Dim openSave As New SaveFileDialog
        Dim OpenFile As New OpenFileDialog
        Dim strGuardar As String = STR_VACIO
        Dim strArchivo As String = STR_VACIO
        Try
            strGuardar = ".pdf"
            openSave.InitialDirectory = "c:\"
            openSave.Filter = "All Files|*.*"
            openSave.RestoreDirectory = True
            openSave.AddExtension = False
            openSave.FileName = "FENCFel" & celdaNumero.Text & strGuardar & strGuardar
            If openSave.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                strArchivo = openSave.FileName
                If checkActivar.Checked = True Then
                    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "FENCFel" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                Else
                    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                End If
            End If
            'Proceso.StartInfo.FileName = "\\192.168.4.142\Archivos_Fel" & "\Fel" & celdaNumero.Text & ".pdf"
            'Proceso.StartInfo.Arguments = ""
            'Proceso.Start()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDatosFel()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Try
            strSQL = "SELECT f.FechaEmisionDocumento,f.FechaHoraCertificacion,f.Serie, f.NumeroAutorizacion ,f.UUID,f.INCOTERM Resolucion "
            strSQL &= "  FROM Fel f  "
            strSQL &= "     WHERE f.Empresa = {empresa} AND f.catalogo = {catalogo} AND f.Anio = {anio} AND f.Numero = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", 31)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaFechaEmisionDocumento.Text = REA.GetString("FechaEmisionDocumento")
                    celdaFechaHoraCertificacion.Text = REA.GetString("FechaHoraCertificacion")
                    celdaSerieFel.Text = REA.GetString("Serie")
                    celdaUUID.Text = REA.GetString("UUID")
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    etiquetaSerie.Text = arrayCadena(INT_CERO)
                    etiquetaAutorizacion.Text = REA.GetString("NumeroAutorizacion")
                    etiquetaSerie.Visible = True
                    etiquetaAutorizacion.Visible = True
                    celdaResolucion.Text = REA.GetString("Resolucion")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function EnvioProyecto(ByVal strError As String) As Boolean
        Dim logEnvio As Boolean = False
        Dim mail As New clsCorreo
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim correo As New Tablas.TCORREO
        Dim j As Integer
        Dim K As Integer
        Dim conec As New MySqlConnection
        Dim COM1 As MySqlCommand
        Dim strInsert As String = STR_VACIO
        Dim strUsuario As String
        Dim strSQL1 As String
        Dim strConexion2 As String
        Dim strTemporal As String = STR_VACIO
        Dim strTexto As String = STR_VACIO
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Try

            ArrayServer = strConexion.Split(";".ToCharArray)
            strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

            If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
                strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
            Else
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
                strConexion2 = Replace(strConexion2, "{puerto}", "3308")
            End If

            strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
            strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
            strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

            strSQL1 = " Select   CONCAT(per_nombre1 ,'  ' ,per_apellido1) Puesto  FRom Personal  WHERE per_codigo={usuario} "
            strSQL1 = Replace(strSQL1, "{usuario}", Sesion.idUsuario)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL1, conec)
            strUsuario = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strTexto &= " <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color:  #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;text-align: Left'>  USUARIO: </td> <td colspan='3' style='border-right: solid black 1px; border-bottom: solid black 1px;padding: 2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;'>" & strUsuario & "</td> </tr>"
            strTexto &= " <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color:  #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;text-align: Left'>  FECHA INGRESO : </td> <td colspan='3' style='border-right: solid black 1px; border-bottom: solid black 1px;padding: 2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;'> " & Now() & "</td> </tr>"
            strTexto &= "   <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  CONTRATO DE : </td> <td colspan='3' style='border-right: solid black 1px; border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;'> " & celdaNumero.Text & " </td> </tr>"
            strTexto = Replace(strTexto, vbCrLf, "<br>")
            strTexto = Replace(strTexto, "'", Chr(34))

            strTemporal &= " <html> <BODY> <table cellspacing=0 > <tr> <td colspan='4'; style=' border:solid White 0px; background-color: #FFFFFF; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 10pt;width: 3.5cm;text-align: center;border-bottom:solid black 1px; border-right: solid black 1px;border-left: solid black 1px;border-top:solid black 1px;font-weight:bold;'> " & strError & "</td> </tr> "
            strTemporal = Replace(strTemporal, "'", Chr(34))
            '  strSQL = SQLCorreo()
            ' MyCnn.CONECTAR = strConexion
            'COM = New MySqlCommand(strSQL, CON)
            ' REA = COM.ExecuteReader()
            'If REA.HasRows Then
            'Do While REA.Read
            strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "tisoportegt@grupokarims.com" & "',' Alerta de Seguridad ' ,'" & strTemporal & vbCrLf & strTexto & " </table> </body> </html>',0); ")
            '    Loop
            'COM = Nothing
            ' End If
            MyCnn.CONECTAR = strConexion2
            COM = New MySqlCommand(strInsert, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
            logEnvio = True




        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logEnvio
    End Function
    Public Function AnularFel(ByVal strSerieUUID As String, ByVal strFechaEmsionDocumento As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim logResultado As Boolean = True
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\AnulacionFactNC.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFANC" & celdaNumero.Text & ".xml"
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLAnulacion As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strNit As String = STR_VACIO
        Dim strValidarAnulacion As String = STR_VACIO
        Dim strFechaAnulacion As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim strToken As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Try
            If cFunciones.ExisteArchivo(strpath) Then
                'Solicita Token en el Web Service 
                strSolicitarToken = t.SolicitarToken1(strpath)
                If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                    ' Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' cierra el archivo 
                    sw.Close()
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                Else
                    'Crea Archivo TokenD.xml
                    fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    fs.Close()
                    'Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                    sw.Close()
                End If
            End If
            strNit = celdaNIT.Text
            strNit = Replace(strNit, " ", "")
            strNit = Replace(strNit, "-", "")

            strNitCliente = Replace(strNitCliente, " ", "")
            strNitCliente = Replace(strNitCliente, "-", "")

            strFechaAnulacion = Now().ToString("yyyy-MM-ddTHH:mm:ss") & "-06:00"
            ' XML Firma Electronica 
            strXMLAnulacion &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLAnulacion &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
            strXMLAnulacion &= "<xml_dte>" & vbCrLf
            strXMLAnulacion &= "<![CDATA[ " & vbCrLf
            ' XML ANULACION
            strXMLAnulacion &= " <ns:GTAnulacionDocumento Version='0.1' xmlns:ns='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#'>" & vbCrLf
            strXMLAnulacion &= "<ns:SAT>" & vbCrLf
            strXMLAnulacion &= "<ns:AnulacionDTE ID='DatosCertificados'>" & vbCrLf
            strXMLAnulacion &= "<ns:DatosGenerales ID='DatosAnulacion'" & vbCrLf
            strXMLAnulacion &= "NumeroDocumentoAAnular='" & celdaSerieFel.Text & "'" & vbCrLf
            'If strPaisCliente <> 0 Then
            '    strXMLAnulacion &= "NITEmisor='90028481' IDReceptor='CF'" & vbCrLf
            'Else
            strXMLAnulacion &= "NITEmisor='90028481' IDReceptor='" & strNitCliente & "'" & vbCrLf
            'End If
            ' strXMLAnulacion &= "NITEmisor='90028481' IDReceptor='CF'" & vbCrLf
            strXMLAnulacion &= "FechaEmisionDocumentoAnular='" & celdaFechaEmisionDocumento.Text & "'" & vbCrLf
            strXMLAnulacion &= "FechaHoraAnulacion='" & strFechaAnulacion & "' MotivoAnulacion='Cancelacion'/>" & vbCrLf
            strXMLAnulacion &= "</ns:AnulacionDTE>" & vbCrLf
            strXMLAnulacion &= "</ns:SAT>" & vbCrLf
            strXMLAnulacion &= "</ns:GTAnulacionDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXMLAnulacion &= "]]>" & vbCrLf
            strXMLAnulacion &= "</xml_dte>" & vbCrLf
            strXMLAnulacion &= "</FirmaDocumentoRequest>" & vbCrLf

            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
            sw.Write(strXMLAnulacion)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<AnulaDocumentoXMLRequest id='" & celdaSerieFel.Text & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</AnulaDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFactNC.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFactNC.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml")
            ' Registra la factura ya firmado
            strXMLFinal = t.AnulaDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el Anula documento de Fel ")
                strError &= "Fallo en el Anula documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/AnulaDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strValidarAnulacion = nodo.ChildNodes.Item(1).InnerText
            Next
            '   If strValidarAnulacion = INT_UNO Then
            '  MsgBox("La factura registrada se encuentra anulado")
            ' logResultado = False
            'Else
            'MsgBox("La factura  se ha anulado correctamente ")
            logResultado = True
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelNC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelNC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelNC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            'End If




            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & celdaSerieFel.Text & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFNC" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFANC" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinalANC" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinalANC" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinalANC" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try
            botonImprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Function AnularFelCMC(ByVal strSerieUUID As String, ByVal strFechaEmsionDocumento As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim logResultado As Boolean = True
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\AnulacionFactNC.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFANC" & celdaNumero.Text & ".xml"
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLAnulacion As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strValidarAnulacion As String = STR_VACIO
        Dim strFechaAnulacion As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim strToken As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim strNitCliente As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Try
            If cFunciones.ExisteArchivo(strpath) Then
                'Solicita Token en el Web Service 
                strSolicitarToken = t.SolicitarToken1(strpath)
                If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                    ' Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' cierra el archivo 
                    sw.Close()
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                Else
                    'Crea Archivo TokenD.xml
                    fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    fs.Close()
                    'Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                    sw.Close()
                End If
            End If
            strFechaAnulacion = Now().ToString("yyyy-MM-ddTHH:mm:ss") & "-06:00"
            strNitCliente = celdaNIT.Text
            strNitCliente = Replace(strNitCliente, "-", "")
            ' XML Firma Electronica 
            strXMLAnulacion &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLAnulacion &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
            strXMLAnulacion &= "<xml_dte>" & vbCrLf
            strXMLAnulacion &= "<![CDATA[ " & vbCrLf
            ' XML ANULACION
            strXMLAnulacion &= " <ns:GTAnulacionDocumento Version='0.1' xmlns:ns='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#'>" & vbCrLf
            strXMLAnulacion &= "<ns:SAT>" & vbCrLf
            strXMLAnulacion &= "<ns:AnulacionDTE ID='DatosCertificados'>" & vbCrLf
            strXMLAnulacion &= "<ns:DatosGenerales ID='DatosAnulacion'" & vbCrLf
            strXMLAnulacion &= "NumeroDocumentoAAnular='" & celdaSerieFel.Text & "'" & vbCrLf
            'strXMLAnulacion &= "NITEmisor='76882551' IDReceptor='" & strNitCliente & "'" & vbCrLf
            strXMLAnulacion &= "NITEmisor='120375265' IDReceptor='" & strNitCliente & "'" & vbCrLf
            strXMLAnulacion &= "FechaEmisionDocumentoAnular='" & celdaFechaEmisionDocumento.Text & "'" & vbCrLf
            strXMLAnulacion &= "FechaHoraAnulacion='" & strFechaAnulacion & "' MotivoAnulacion='Cancelacion'/>" & vbCrLf
            strXMLAnulacion &= "</ns:AnulacionDTE>" & vbCrLf
            strXMLAnulacion &= "</ns:SAT>" & vbCrLf
            strXMLAnulacion &= "</ns:GTAnulacionDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXMLAnulacion &= "]]>" & vbCrLf
            strXMLAnulacion &= "</xml_dte>" & vbCrLf
            strXMLAnulacion &= "</FirmaDocumentoRequest>" & vbCrLf
            'Iniciamos el ciclo de lectura
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
            sw.Write(strXMLAnulacion)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<AnulaDocumentoXMLRequest id='" & celdaSerieFel.Text & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</AnulaDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFactNC.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFactNC.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml")
            ' Registra la factura ya firmado
            strXMLFinal = t.AnulaDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el Anula documento de Fel ")
                strError &= "Fallo en el Anula documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/AnulaDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strValidarAnulacion = nodo.ChildNodes.Item(1).InnerText
            Next
            '   If strValidarAnulacion = INT_UNO Then
            '  MsgBox("La factura registrada se encuentra anulado")
            ' logResultado = False
            'Else
            'MsgBox("La factura  se ha anulado correctamente ")
            logResultado = True
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelNC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelNC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelNC" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelNC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try
            'End If


            '''' espera para que el envio del xml se genere en megaprint y devuelva el dato correcto
            Thread.Sleep(5000)



            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & celdaSerieFel.Text & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFNC" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFANC" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinalANC" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinalANC" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinalANC" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelAnulacionNC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            botonImprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelAnulacionNC" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Sub GuardarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 31
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PINSERT() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActualizarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 31
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PUPDATE() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function VerificarAcceso(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felNC' AND c.cat_clave = 'NotaCredito' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Private Function VerificarDocumentoXML(ByRef strToken As String, ByRef strUUID As String) As Integer
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strVerifica As String = System.Windows.Forms.Application.StartupPath & "\Verifica.xml"
        Dim strSolicitarToken As String = STR_VACIO
        Dim logResultado As Integer
        Dim strResultado As String = STR_VACIO
        Dim strXMLVerificaDocumento As String = STR_VACIO
        Dim t As New Fel
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim fs As FileStream
        If cFunciones.ExisteArchivo(strpath) Then
            'Solicita Token en el Web Service 
            strSolicitarToken = t.SolicitarToken1(strpath)
            If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                ' Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' cierra el archivo 
                sw.Close()
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
            Else
                'Crea Archivo TokenD.xml
                fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                fs.Close()
                'Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
                sw.Close()
            End If
        End If
        If celdaUUID.Text <> STR_VACIO Then
            strUUID = celdaUUID.Text
        Else
            strUUID = GenerarUUID()
        End If
        'strUUID = "4DFFD5BC-AC7E-4779-8D4C-8C3903322993"
        strXMLVerificaDocumento &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
        strXMLVerificaDocumento &= "<VerificaDocumentoRequest id='" & strUUID & "'/>" & vbCrLf

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        sw.Write(strXMLVerificaDocumento)
        sw.Close()

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        sw.Write(t.VerificaDocumento(strVerifica, strToken))
        sw.Close()
        xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        nodos_lista = xml_Documento.SelectNodes("/VerificaDocumentoResponse")
        ''Iniciamos el ciclo de lectura
        For Each nodo In nodos_lista
            '    ' Asigna el Codigo 64 Bits
            strResultado = nodo.ChildNodes.Item(0).InnerText
            If strResultado = "0" Then
                logResultado = INT_CERO
                GuardarFel(STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, strUUID)
            Else
                logResultado = INT_UNO
            End If
        Next


        Return logResultado
    End Function

    Private Function VerificarAccesoLocal(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felNCL' AND c.cat_clave = 'NotaCredito' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Public Function ImprimirFel(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal strToken As String, ByVal strUUID As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logEncabezado As Boolean = False
        Dim strMotivoAjuste As String = STR_VACIO
        Dim logResultado As Boolean = True
        Dim CMC As Boolean = True
        Dim Horario As String
        Dim strNit As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim strNitCertificador As String = STR_VACIO
        Dim strSerieDocumento As String = STR_VACIO
        Dim strFechaHoraCertificacion As String = STR_VACIO
        Dim strNumeroAutorizacion As String = STR_VACIO
        Dim strXML As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLDTL As String = STR_VACIO
        Dim strXMLFel As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\NCRegistraDocumento.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\FENCPDF" & celdaNumero.Text & ".xml"
        Dim dblGranTotal As Double
        Dim strAdendaTasa As String = STR_VACIO
        Dim strAdendaQuetzales As String = STR_VACIO
        Dim strNombreCliente As String = STR_VACIO
        Dim strFecha As DateTime
        Dim strNumeroFact As String = STR_VACIO

        Dim strNumeroFactFel As String = STR_VACIO
        Dim strSerieFactFel As String = STR_VACIO

        'Exportacion
        Dim strNombreC As String = STR_VACIO
        Dim strDireccionC As String = STR_VACIO
        Dim strCodigoC As String = STR_VACIO
        Dim strNitCliente As String = STR_VACIO
        Dim strDireccionCliente As String = STR_VACIO
        Dim strCodigoCliente As String = STR_VACIO
        Dim strNombreExportador As String = STR_VACIO
        Dim strIcoterm As String = STR_VACIO
        Dim strPaisCliente As Integer = INT_CERO
        ' Especifica el criterio
        Dim vlcCriterio As String = "dte:NumeroAutorizacion"
        Dim strCadenaEncontrada As String = STR_VACIO
        Dim arrayCadena() As String
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim vlcResultado As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            botonImprimir.Enabled = False
            If rbDifPrecio.Checked = True Then
                strMotivoAjuste = "DESCUENTO"
            ElseIf rbDevoluciones.Checked = True Then
                strMotivoAjuste = "DEVOLUCION"
            ElseIf rbOtros.Checked = True Then
                strMotivoAjuste = "OTROS"
            End If
            Horario = Now().ToString("yyyy-MM-ddTHH:mm:ss")
            strSQL = "      SELECT cli2.cli_cliente Cliente, cli2.cli_direccion DireccionCliente,cli2.cli_codigo CodigoCliente,cp2.cat_desc Pais, fe.INCOTERM CIF,ifnull(cxp.cli_cliente,cli2.cli_cliente) NombreC,ifnull(cxp.cli_direccion, cli2.cli_direccion) DireccionC, ifnull(cxp.cli_codigo, cli2.cli_codigo) CodigoC,um.cat_clave Medida,e.HDoc_Doc_Fec Fecha,SUM(d.DDoc_Prd_Net) PrecioUnitario,ROUND(SUM(d.DDoc_Prd_Net * d.DDoc_Prd_QTY)+0.001,2) Precio,d.DDoc_Prd_QTY Cantidad,d.DDoc_Doc_Lin Linea,cp.cat_clave PaisReceptor,emp.emp_razon NombreComercial,emp.emp_direccion DireccionEmisor,e.HDoc_Doc_Num Numero, e.HDoc_Emp_Nom Nombre, replace( e.HDoc_Emp_NIT,'-','') NIT, e.HDoc_Emp_Dir Direccion, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, "
            strSQL &= "         CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, d.DDoc_Prd_Des Descripcion,me.cat_num CodigoMoneda , COALESCE(me.cat_clave,'') Moneda, SUM(d.DDoc_RF1_Dbl) Total "

            strSQL &= "         , CONCAT('FACTURA N° ', CAST(f.HDoc_Doc_Num AS CHAR), IF(COALESCE(f.HDoc_DR2_Num,'')='','', CONCAT(' SERIE ',f.HDoc_DR2_Num)),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) Referencia "
            strSQL &= "                         ,CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, e.HDoc_Doc_TC Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) Conversion, ROUND(SUM(e.HDoc_Doc_TC) * e.HDoc_RF1_Dbl,2) LOCAL,ROUND((SUM(d.DDoc_Prd_Net * d.DDoc_Prd_QTY) * e.HDoc_Doc_TC),2) Quet  "

            If CMC = True Then
                strSQL &= "                         , CONCAT('FACTURA N° ', CAST(f.HDoc_Doc_Num AS CHAR), IF(COALESCE(f.HDoc_DR2_Num,'')='','', CONCAT(' SERIE ',f.HDoc_DR2_Num)),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) Referencia "
            End If
            strSQL &= "                    , IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, "
            strSQL &= "                            CONCAT('- ',e.HDoc_RF2_Txt, '-') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, ifnull(cxp.cli_clasificacion,cli2.cli_clasificacion) clasTipoFactura, if(cli.cli_exterior='Local',0,1) cli_exterior "
            strSQL &= "                                 ,SUBSTRING_INDEX(fe.Serie, '-', 1) as serieFelFactura,
                                                    fe.NumeroAutorizacion as numeroFelFactura
                                                    FROM Dcmtos_HDR e "
            strSQL &= "                                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
            strSQL &= "                                             LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = d.DDoc_Sis_Emp AND c.ECta_Doc_Cat = d.DDoc_Doc_Cat AND c.ECta_Doc_Ano = d.DDoc_Doc_Ano AND c.ECta_Doc_Num = d.DDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Prd_Cod "
            strSQL &= "                                           LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
            strSQL &= "                                         LEFT JOIN Dcmtos_DTL d36 ON d36.DDoc_Sis_Emp = f.HDoc_Sis_Emp AND d36.DDoc_Doc_Cat = f.HDoc_Doc_Cat AND d36.DDoc_Doc_Ano = f.HDoc_Doc_Ano AND d36.DDoc_Doc_Num = f.HDoc_Doc_Num AND d36.DDoc_Doc_Lin = d.DDoc_Prd_Cod "
            strSQL &= "                            LEFT JOIN Dcmtos_DTL_Pro d48 ON d48.PDoc_Sis_Emp = d36.DDoc_Sis_Emp AND d48.PDoc_Chi_Cat = d36.DDoc_Doc_Cat AND d48.PDoc_Chi_Ano = d36.DDoc_Doc_Ano AND d48.PDoc_Chi_Num = d36.DDoc_Doc_Num AND d48.PDoc_Chi_Lin = d36.DDoc_Doc_Lin AND d48.PDoc_Par_Cat = 48
                                                LEFT JOIN Dcmtos_DTL_Pro i75 ON i75.PDoc_Sis_Emp = d48.PDoc_Sis_Emp AND i75.PDoc_Chi_Cat = d48.PDoc_Par_Cat AND i75.PDoc_Chi_Ano = d48.PDoc_Par_Ano AND i75.PDoc_Chi_Num = d48.PDoc_Par_Num AND i75.PDoc_Chi_Lin = d48.PDoc_Par_Lin AND i75.PDoc_Par_Cat = 75
                                            LEFT JOIN Dcmtos_HDR h75 ON h75.HDoc_Sis_Emp = i75.PDoc_Sis_Emp AND h75.HDoc_Doc_Cat = i75.PDoc_Par_Cat AND h75.HDoc_Doc_Ano = i75.PDoc_Par_Ano AND h75.HDoc_Doc_Num = i75.PDoc_Par_Num
                                        LEFT JOIN Clientes cxp ON cxp.cli_sisemp = h75.HDoc_Sis_Emp AND cxp.cli_codigo = h75.HDoc_DR1_Emp
                                    LEFT JOIN Fel fe ON fe.Empresa = f.HDoc_Sis_Emp AND fe.Catalogo = f.HDoc_Doc_Cat  AND fe.Anio = f.HDoc_Doc_Ano AND fe.Numero = f.HDoc_Doc_Num  "
            strSQL &= "                                      LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon"
            strSQL &= "                                    LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
            strSQL &= "                                 LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
            strSQL &= "                              LEFT JOIN Empresas emp ON emp.emp_no = e.HDoc_Sis_Emp"
            strSQL &= "                           LEFT JOIN Clientes cli ON cli.cli_sisemp = e.HDoc_Sis_Emp AND cli.cli_codigo = e.HDoc_Emp_Cod"
            strSQL &= "                       LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais  "
            strSQL &= "                   LEFT JOIN Catalogos um ON um.cat_clase = 'Medidas' AND um.cat_num = d36.DDoc_Prd_UM"
            strSQL &= "                LEFT JOIN Clientes cli2 ON cli2.cli_sisemp = f.HDoc_Sis_Emp AND cli2.cli_codigo = f.HDoc_Emp_Cod "
            strSQL &= "             LEFT JOIN Catalogos cp2 ON cp2.cat_num = cli2.cli_pais "
            strSQL &= "         WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
            strSQL &= "      GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    'strNombreC = REA.GetString("NombreC")
                    strNombreC = cfun.convertirXML(REA.GetString("NombreC"))
                    strNombreC = Replace(strNombreC, "&", "&#38;")
                    strNombreC = Replace(strNombreC, "-", "&#45;")
                    strDireccionC = REA.GetString("Pais")
                    strCodigoC = REA.GetString("CodigoC")
                    strNitCliente = REA.GetString("NIT")
                    'strDireccionCliente = REA.GetString("DireccionCliente")
                    strDireccionCliente = cfun.convertirXML(REA.GetString("DireccionCliente"))
                    strCodigoCliente = REA.GetString("CodigoCliente")
                    strNombreExportador = REA.GetString("NombreComercial")
                    strIcoterm = REA.GetString("CIF")
                    strPaisCliente = REA.GetString("clasTipoFactura")

                    strNumeroFact = dgFacturacion.CurrentRow.Cells("colNumero").Value
                    strFecha = dgFacturacion.CurrentRow.Cells("colFecha").Value
                    strAdendaTasa = REA.GetString("Cambio") & " " & REA.GetDouble("Tasa")
                    strAdendaQuetzales = REA.GetString("Conversion") & " " & REA.GetDouble("Quet")
                    strNombreCliente = REA.GetString("Nombre")
                    strNombreCliente = Replace(strNombreCliente, "&", "&#38;")
                    strNombreCliente = Replace(strNombreCliente, "-", "&#45;")
                    strNombreCliente = cfun.convertirXML(strNombreCliente)

                    strSerieFactFel = REA.GetString("serieFelFactura")
                    strNumeroFactFel = REA.GetString("numeroFelFactura")

                    strNit = REA.GetString("NIT")
                    strNit = Replace(strNit, "-", "")
                    If REA.GetInt32("CodigoMoneda") = 177 Then
                        strMoneda = "GTQ"
                    ElseIf REA.GetInt32("CodigoMoneda") = 178 Then
                        strMoneda = "USD"
                    End If
                    If File.Exists(System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml") Then
                        If logEncabezado = False Then
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            'Encabezado de la nota de Credito 
                            '   strXML &= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:ds='http://www.w3.org/2000/09/xmldsig#' xmlns:n1='http://www.altova.com/samplexml/other-namespace' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' Version='0.4'>" & vbCrLf
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= "<dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            '
                            If strNumeroFact < 11165 Then
                                strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' Exp='SI' FechaHoraEmision='" & Horario & "-06:00" & "'  Tipo='NCRE'/>" & vbCrLf
                            Else
                                strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "'  Tipo='NCRE'/>" & vbCrLf
                            End If
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@hilosyalgodon.com' NITEmisor='90028481' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='Hilos y Algodon Sociedad Anonima'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionEmisor")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>Guatemala</dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            If strNumeroFact < 11165 Then
                                strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            Else


                                If REA.GetInt32("cli_exterior") = 0 Then   '' 0 es local
                                    If REA.GetString("NIT") = "CF" Then
                                        'factura consumidor final
                                        strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                    ElseIf strNitCliente.Length = 13 Then
                                        'factura CUI Valido
                                        strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                    Else
                                        'factura nit valido
                                        strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                    End If
                                    ' strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                                Else
                                    'factura exterior
                                    strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                End If



                                'If strPaisCliente <> 0 Then
                                '    strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                                'Else
                                '    strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                                'End If
                            End If
                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("Direccion")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            'If strNumeroFact < 11165 Then
                            '    strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='4'/>" & vbCrLf
                            'Else
                            strXML &= "<dte:Frase CodigoEscenario='22' TipoFrase ='4'/>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            'End If
                            strXML &= "</dte:Frases>" & vbCrLf
                            'Linea de FActura
                            strXML &= "<dte:Items>" & vbCrLf
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & "</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Precio")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='1'>" & vbCrLf
                            strXMLDTL &= "<Valor1></Valor1>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Total>" & REA.GetDouble("Precio") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                            logEncabezado = True
                        Else
                            'Linea de FActura
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & "</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Precio")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='1'>" & vbCrLf
                            strXMLDTL &= "<Valor1></Valor1>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Total>" & REA.GetDouble("Precio") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                    Else
                        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml")
                        fs.Close()
                        If logEncabezado = False Then
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            'Encabezado de la nota de Credito 
                            '  strXML &= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:ds='http://www.w3.org/2000/09/xmldsig#' xmlns:n1='http://www.altova.com/samplexml/other-namespace' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' Version='0.4'>" & vbCrLf
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= "<dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            'strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' Exp='SI' FechaHoraEmision='" & Horario & "-06:00" & "'  Tipo='NCRE'/>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "'  Tipo='NCRE'/>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' NITEmisor='90028481' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionEmisor")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>Guatemala</dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            If strPaisCliente <> 0 Then
                                strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            Else
                                strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            End If
                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("Direccion") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            'If strNumeroFact < 11165 Then
                            '    strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='4'/>" & vbCrLf
                            'Else
                            strXML &= "<dte:Frase CodigoEscenario='22' TipoFrase ='4'/>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            'End If
                            strXML &= "</dte:Frases>" & vbCrLf
                            'Linea de FActura
                            strXML &= "<dte:Items>" & vbCrLf
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & "</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Precio")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='1'>" & vbCrLf
                            strXMLDTL &= "<Valor1></Valor1>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Total>" & REA.GetDouble("Precio") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                            logEncabezado = True
                        Else
                            'Linea de FActura
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & "</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Precio")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='1'>" & vbCrLf
                            strXMLDTL &= "<Valor1></Valor1>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Total>" & REA.GetDouble("Precio") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                        'Fin del If
                    End If
                Loop
            End If
            strXML &= "</dte:Items>" & vbCrLf
            strXML &= "<dte:Totales>" & vbCrLf
            strXML &= "<dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:TotalImpuesto NombreCorto='IVA' TotalMontoImpuesto='0'/>"
            strXML &= "</dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:GranTotal>" & dblGranTotal & "</dte:GranTotal>" & vbCrLf
            strXML &= "</dte:Totales>" & vbCrLf
            ' Complemento Regimen Fel 
            If celdaAutFact.Text <> STR_VACIO Then
                strXML &= "<dte:Complementos>" & vbCrLf
                strXML &= "<dte:Complemento IDComplemento='1' NombreComplemento='NOTA CREDITO' URIComplemento='http://www.sat.gob.gt/face2/ComplementoReferenciaNota/0.1.0'>" & vbCrLf
                strXML &= "<cno:ReferenciasNota xmlns:cno='http://www.sat.gob.gt/face2/ComplementoReferenciaNota/0.1.0' FechaEmisionDocumentoOrigen='" & strFecha.ToString(FORMATO_MYSQL) & "' MotivoAjuste='" & strMotivoAjuste & "' NumeroAutorizacionDocumentoOrigen='" & celdaUIDDFact.Text & "' NumeroDocumentoOrigen='" & strNumeroFactFel & "' SerieDocumentoOrigen='" & strSerieFactFel & "'  Version='1'/>" & vbCrLf
                strXML &= "</dte:Complemento>" & vbCrLf

                If strNumeroFact < 11165 Then
                    strXML &= "<dte:Complemento IDComplemento='EXP' NombreComplemento='EXPORTACION' URIComplemento='http://www.sat.gob.gt/face2/ComplementoExportaciones/0.1.0'>" & vbCrLf
                    strXML &= "<cex:Exportacion  xmlns:cex='http://www.sat.gob.gt/face2/ComplementoExportaciones/0.1.0' Version='1'>" & vbCrLf
                    strXML &= "<cex:NombreConsignatarioODestinatario>" & strNombreC & " </cex:NombreConsignatarioODestinatario>" & vbCrLf
                    strXML &= "<cex:DireccionConsignatarioODestinatario>" & strDireccionC & "</cex:DireccionConsignatarioODestinatario>" & vbCrLf
                    strXML &= "<cex:CodigoConsignatarioODestinatario>" & strCodigoC & "</cex:CodigoConsignatarioODestinatario>" & vbCrLf
                    strXML &= "<cex:NombreComprador>" & strNombreCliente & "</cex:NombreComprador> " & vbCrLf
                    strXML &= "<cex:DireccionComprador>" & strDireccionCliente & "</cex:DireccionComprador> " & vbCrLf
                    strXML &= "<cex:CodigoComprador>" & strCodigoCliente & " </cex:CodigoComprador> " & vbCrLf
                    strXML &= "<cex:INCOTERM>" & strIcoterm & "</cex:INCOTERM> " & vbCrLf
                    strXML &= "<cex:NombreExportador>" & strNombreExportador & " </cex:NombreExportador> " & vbCrLf
                    strXML &= "<cex:CodigoExportador>H25746</cex:CodigoExportador> " & vbCrLf
                    strXML &= "</cex:Exportacion> " & vbCrLf
                    strXML &= "</dte:Complemento>"
                End If

                strXML &= "</dte:Complementos>" & vbCrLf
            Else
                ' Complemento de Regimen GFase a Fel 
                strXML &= " <dte:Complementos>" & vbCrLf
                strXML &= " <dte:Complemento IDComplemento='NCE38' NombreComplemento='ComplementoNCE' URIComplemento=''>" & vbCrLf
                strXML &= "  <cno:ReferenciasNota xmlns:cno='http://www.sat.gob.gt/face2/ComplementoReferenciaNota/0.1.0' FechaEmisionDocumentoOrigen='" & strFecha.ToString(FORMATO_MYSQL) & "' MotivoAjuste='" & strMotivoAjuste & "' NumeroAutorizacionDocumentoOrigen='" & celdaResolucion.Text & "' NumeroDocumentoOrigen='" & strNumeroFact & "' RegimenAntiguo='Antiguo' SerieDocumentoOrigen='" & celdaSerieGF.Text & "' Version='0'/>" & vbCrLf
                strXML &= " </dte:Complemento>" & vbCrLf
                strXML &= " </dte:Complementos>" & vbCrLf
            End If
            strXML &= "</dte:DatosEmision>" & vbCrLf
            strXML &= "</dte:DTE>" & vbCrLf
            strXML &= "<dte:Adenda>" & vbCrLf
            strXML &= "<dte:AdendaDetail id='AdendaSummary'> " & vbCrLf
            strXML &= "<dte:AdendaSummary>" & vbCrLf
            strXML &= "<dte:Valor1>" & strAdendaTasa & "</dte:Valor1>" & vbCrLf
            strXML &= "<dte:Valor2>" & strAdendaQuetzales & "</dte:Valor2>" & vbCrLf
            If strNumeroFact < 11165 Then
                strXML &= "<dte:Valor4>CUI: " & strNit & "</dte:Valor4>" & vbCrLf
            Else
                strXML &= "<dte:Valor4></dte:Valor4>" & vbCrLf
            End If

            strXML &= "<dte:Valor5>" & celdaAutFact.Text & "</dte:Valor5>" & vbCrLf
            strXML &= "<dte:Valor6>" & strNumeroFact & "</dte:Valor6>" & vbCrLf
            strXML &= "<dte:Valor7>" & celdaNumero.Text & "</dte:Valor7>" & vbCrLf
            strXML &= "</dte:AdendaSummary>" & vbCrLf
            strXML &= "<AdendaItems>" & vbCrLf
            strXML &= strXMLDTL
            strXML &= "</AdendaItems>" & vbCrLf
            strXML &= "</dte:AdendaDetail>" & vbCrLf
            strXML &= "</dte:Adenda>" & vbCrLf
            strXML &= "</dte:SAT>" & vbCrLf
            strXML &= "</dte:GTDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXML &= "]]>" & vbCrLf
            strXML &= "</xml_dte>" & vbCrLf
            strXML &= "</FirmaDocumentoRequest>" & vbCrLf
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml")
            sw.Write(strXML)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCfirma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCfirma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                strError &= " Fallo en la Firma Electronica "
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\NCfirma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCRegistraDocumento.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCRegistraDocumento.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml")
            'Registra la factura ya firmado
            strXMLFinal = t.RegistrarDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el registra documento de Fel ")
                strError &= "Fallo en el registra documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' '' '' ''PRUEBAS
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "file://C:\Archivos_Fel\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RegistraDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strXMLFel = nodo.ChildNodes.Item(0).InnerText
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml")
            sw.Write(strXMLFel)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' '' '' ''PRUEBAS
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "file://C:\Archivos_Fel\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.GetElementsByTagName("dte:Certificacion")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strNitCertificador = nodo.ChildNodes.Item(0).InnerText  ' Nit MegaPrint
                '  strFechaHoraCertificacion = nodo.ChildNodes.Item(1).InnerText ' Nombre MegaPrint
                strSerieDocumento = nodo.ChildNodes.Item(2).InnerText ' Serie 
                strFechaHoraCertificacion = nodo.ChildNodes.Item(3).InnerText ' FechaCertificacion 
            Next
            ' Nombre del archivo a utilizar
            Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml"
            ' Si el archivo existe
            Dim vloFile As New StreamReader(vlcFileName)
            ' Ciclo de iteración entre líneas
            While True
                ' Cargar la línea
                Dim vlcLinea = vloFile.ReadLine()
                ' Si la línea es nula, sale del ciclo
                If vlcLinea Is Nothing Then Exit While
                ' Si la línea contiene el criterio
                If vlcLinea.Contains(vlcCriterio) Then
                    ' Obtener la línea como resultado,
                    ' Concatenando un retorno de carro si ya hay ocurrencias
                    vlcResultado += IIf(vlcResultado <> "", vbCrLf, "") & vlcLinea
                    ' Salir del ciclo
                    Exit While
                    ' Lo omites si quieres todas las ocurrencias
                End If
            End While
            'Realiza busqueda de la cadena para obtener el numero de Autorizacion
            strCadenaEncontrada = vlcResultado.Substring(vlcResultado.LastIndexOf("Numero=") + 1)
            'En un array parte la cadena despues que encuentre un igual 
            arrayCadena = strCadenaEncontrada.Split("=".ToCharArray)
            'carga el numero de autorizacion de cada documento
            strNumeroAutorizacion = arrayCadena(INT_UNO)
            'sustituye serie por cadena vacio para limpiar la cadena y solo obtenga el numero
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, "Serie", STR_VACIO)
            'sustituye "" por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, """", STR_VACIO)
            'sustituye espacios por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, " ", STR_VACIO)


            ActualizarFel(Horario & "-06:00", strFechaHoraCertificacion, strSerieDocumento, strNumeroAutorizacion, STR_VACIO, strUUID)
            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 31, celdaAño.Text, celdaNumero.Text, Sesion.Usuario & " " & Horario)
            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & strSerieDocumento & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FENCPDF" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FENCPDF" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FENCPDFFinal" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FENCPDFFinal" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FENCPDFFinal" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' '' '' ''PRUEBAS
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "file://C:\Archivos_Fel\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            botonImprimir.Enabled = True

            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Function ImprimirFelCMC(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal strToken As String, ByVal strUUID As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logEncabezado As Boolean = False
        Dim strMotivoAjuste As String = STR_VACIO
        Dim logResultado As Boolean = True
        Dim CMC As Boolean = True
        Dim Horario As String
        Dim strNit As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim strNitCertificador As String = STR_VACIO
        Dim strSerieDocumento As String = STR_VACIO
        Dim strFechaHoraCertificacion As String = STR_VACIO
        Dim strNumeroAutorizacion As String = STR_VACIO
        Dim strXML As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLDTL As String = STR_VACIO
        Dim strXMLFel As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\NCRegistraDocumento.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\FENCPDF" & celdaNumero.Text & ".xml"
        Dim dblGranTotal As Double
        Dim strAdendaTasa As String = STR_VACIO
        Dim strAdendaQuetzales As String = STR_VACIO
        Dim strNombreCliente As String = STR_VACIO
        Dim strFecha As DateTime
        Dim strNumeroFact As String = STR_VACIO
        Dim dblIvaImpuesto As Double = INT_CERO
        Dim dblIva As Double = INT_CERO
        Dim dblGranTotalIva As Double = INT_CERO
        Dim strNumeroFactFel As String = STR_VACIO
        Dim strSerieFactFel As String = STR_VACIO

        ' Especifica el criterio
        Dim vlcCriterio As String = "dte:NumeroAutorizacion"
        Dim strCadenaEncontrada As String = STR_VACIO
        Dim arrayCadena() As String
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim vlcResultado As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            botonImprimir.Enabled = False
            If rbDifPrecio.Checked = True Then
                strMotivoAjuste = "DESCUENTO"
            ElseIf rbDevoluciones.Checked = True Then
                strMotivoAjuste = "DEVOLUCION"
            ElseIf rbOtros.Checked = True Then
                strMotivoAjuste = "OTROS"
            End If
            Horario = Now().ToString("yyyy-MM-ddTHH:mm:ss")
            strSQL = " SELECT d.DDoc_Prd_QTY Cantidad,me.cat_num CodigoMoneda,d.DDoc_Doc_Lin Linea,cp.cat_clave PaisReceptor,emp.emp_razon NombreComercial,emp.emp_direccion DireccionEmisor,e.HDoc_Doc_Num Numero, e.HDoc_Emp_Nom Nombre, "
            strSQL &= "     e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, "
            strSQL &= "         d.DDoc_Prd_Des Descripcion, COALESCE(me.cat_clave,'') Moneda, SUM(d.DDoc_RF1_Dbl) Total, CONCAT('FACTURA N° ', CAST(f.HDoc_Doc_Num AS CHAR), IF(COALESCE(f.HDoc_DR2_Num,'')='','', CONCAT(' SERIE ',f.HDoc_DR2_Num)),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) Referencia, "
            strSQL &= "             IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, CONCAT('- ',e.HDoc_RF2_Txt, '-') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario "
            strSQL &= "     , SUBSTRING_INDEX(fe.Serie, '-', 1) as serieFelFactura, fe.NumeroAutorizacion numeroFelFactura, c.ECta_Ref_Num
                            FROM Dcmtos_HDR e "
            strSQL &= "     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
            strSQL &= "     LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin "
            strSQL &= "     LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
            strSQL &= "     LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon "
            strSQL &= "     LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
            strSQL &= "     LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
            strSQL &= "     LEFT JOIN Fel fe ON fe.Empresa = c.ECta_Sis_Emp AND fe.Catalogo = c.ECta_Ref_Cat AND fe.Numero = c.ECta_Ref_Num "
            strSQL &= "     LEFT JOIN Empresas emp ON emp.emp_no = e.HDoc_Sis_Emp "
            strSQL &= "     LEFT JOIN Clientes cli ON cli.cli_sisemp = e.HDoc_Sis_Emp AND cli.cli_codigo = e.HDoc_Emp_Cod "
            strSQL &= "     LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais "
            strSQL &= "     WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
            strSQL &= "     GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strSerieFactFel = REA.GetString("serieFelFactura")
                    strNumeroFactFel = REA.GetString("numeroFelFactura")
                    strNumeroFact = dgFacturacion.CurrentRow.Cells("colNumero").Value
                    strFecha = dgFacturacion.CurrentRow.Cells("colFecha").Value
                    strNombreCliente = REA.GetString("Nombre")
                    strNit = REA.GetString("NIT")
                    strNit = Replace(strNit, "-", "")
                    If REA.GetInt32("CodigoMoneda") = 177 Then
                        strMoneda = "GTQ"
                    ElseIf REA.GetInt32("CodigoMoneda") = 178 Then
                        strMoneda = "USD"
                    End If
                    If File.Exists(System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml") Then
                        If logEncabezado = False Then
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            'Encabezado de la nota de Credito 
                            '   strXML &= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:ds='http://www.w3.org/2000/09/xmldsig#' xmlns:n1='http://www.altova.com/samplexml/other-namespace' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' Version='0.4'>" & vbCrLf
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= "<dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "'  FechaHoraEmision='" & Horario & "-06:00" & "'  Tipo='NCRE'/>" & vbCrLf
                            'strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@cmcguatemala.com' NITEmisor='76882551' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@logisticservicesgt.com' NITEmisor='120375265' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionEmisor") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>Guatemala</dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            'strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com' IDReceptor='" & strNit & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            strXML &= "<dte:Receptor CorreoReceptor='contabilidad@logisticservicesgt.com' IDReceptor='" & strNit & "' NombreReceptor='" & cfun.convertirXML(strNombreCliente) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("Direccion")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "</dte:Frases>" & vbCrLf
                            'Linea de FActura
                            strXML &= "<dte:Items>" & vbCrLf
                            strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Total") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Total")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            dblIva = (REA.GetDouble("Total") / 1.12)
                            dblIvaImpuesto = (dblIva * 0.12)
                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                            strXML &= "<dte:Total>" & REA.GetDouble("Total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                            logEncabezado = True
                        Else
                            'Linea de FActura
                            strXML &= "<dte:Items>" & vbCrLf
                            strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Total") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Total")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            dblIva = (REA.GetDouble("Total") / 1.12)
                            dblIvaImpuesto = (dblIva * 0.12)
                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                            strXML &= "<dte:Total>" & REA.GetDouble("Total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                    Else
                        If logEncabezado = False Then
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            'Encabezado de la nota de Credito 
                            '   strXML &= "<?xml version='1.0' encoding='UTF-8' standalone='no'?><dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:ds='http://www.w3.org/2000/09/xmldsig#' xmlns:n1='http://www.altova.com/samplexml/other-namespace' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' Version='0.4'>" & vbCrLf
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= "<dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "'  FechaHoraEmision='" & Horario & "-06:00" & "'  Tipo='NCRE'/>" & vbCrLf
                            'strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@cmcguatemala.com' NITEmisor='76882551' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@logisticservicesgt.com' NITEmisor='120375265' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionEmisor") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>Guatemala</dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            'strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com' IDReceptor='" & strNit & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            strXML &= "<dte:Receptor CorreoReceptor='contabilidad@logisticservicesgt.com' IDReceptor='" & strNit & "' NombreReceptor='" & cfun.convertirXML(strNombreCliente) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("Direccion")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "</dte:Frases>" & vbCrLf
                            'Linea de FActura
                            strXML &= "<dte:Items>" & vbCrLf
                            strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Total") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Total")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            dblIva = (REA.GetDouble("Total") / 1.12)
                            dblIvaImpuesto = (dblIva * 0.12)
                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                            strXML &= "<dte:Total>" & REA.GetDouble("Total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                            logEncabezado = True
                        Else
                            'Linea de FActura
                            strXML &= "<dte:Items>" & vbCrLf
                            strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion>" & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total") & "</dte:PrecioUnitario>"
                            strXML &= "<dte:Precio>" & REA.GetDouble("Total") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = dblGranTotal + REA.GetDouble("Total")
                            strXML &= "<dte:Descuento>0</dte:Descuento>" & vbCrLf

                            dblIva = (REA.GetDouble("Total") / 1.12)
                            dblIvaImpuesto = (dblIva * 0.12)
                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf
                            dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                            strXML &= "<dte:Total>" & REA.GetDouble("Total") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                    End If
                Loop
            End If
            strXML &= "</dte:Items>" & vbCrLf
            strXML &= "<dte:Totales>" & vbCrLf
            strXML &= "<dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:TotalImpuesto NombreCorto='IVA' TotalMontoImpuesto='" & dblGranTotalIva & "'/>"
            strXML &= "</dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:GranTotal>" & dblGranTotal & "</dte:GranTotal>" & vbCrLf
            strXML &= "</dte:Totales>" & vbCrLf
            strXML &= "<dte:Complementos>" & vbCrLf
            strXML &= "<dte:Complemento IDComplemento='1' NombreComplemento='NOTA CREDITO' URIComplemento='http://www.sat.gob.gt/face2/ComplementoReferenciaNota/0.1.0'>" & vbCrLf
            strXML &= "<cno:ReferenciasNota xmlns:cno='http://www.sat.gob.gt/face2/ComplementoReferenciaNota/0.1.0' FechaEmisionDocumentoOrigen='" & strFecha.ToString(FORMATO_MYSQL) & "' MotivoAjuste='" & strMotivoAjuste & "' NumeroAutorizacionDocumentoOrigen='" & celdaUIDDFact.Text & "' NumeroDocumentoOrigen='" & strNumeroFactFel & "' SerieDocumentoOrigen='" & strSerieFactFel & "'  Version='1'/>" & vbCrLf
            strXML &= "</dte:Complemento>" & vbCrLf
            strXML &= "</dte:Complementos>" & vbCrLf
            strXML &= "</dte:DatosEmision> " & vbCrLf
            strXML &= "</dte:DTE> " & vbCrLf
            strXML &= "<dte:Adenda>" & vbCrLf
            strXML &= "<dte:AdendaDetail id='AdendaSummary'> " & vbCrLf
            strXML &= "<dte:AdendaSummary>" & vbCrLf
            strXML &= "<dte:Valor1>" & strNumeroFact & "</dte:Valor1>" & vbCrLf
            strXML &= "<dte:Valor2>" & celdaNumero.Text & "</dte:Valor2>" & vbCrLf
            strXML &= "</dte:AdendaSummary>" & vbCrLf
            strXML &= "</dte:AdendaDetail>" & vbCrLf
            strXML &= "</dte:Adenda>" & vbCrLf
            strXML &= "</dte:SAT> " & vbCrLf
            strXML &= "</dte:GTDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXML &= "]]>" & vbCrLf
            strXML &= "</xml_dte>" & vbCrLf
            strXML &= "</FirmaDocumentoRequest>" & vbCrLf
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCcontenido.xml")
            sw.Write(strXML)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCfirma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCfirma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                strError &= " Fallo en la Firma Electronica "
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\NCfirma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCRegistraDocumento.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCRegistraDocumento.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml")
            'Registra la factura ya firmado
            strXMLFinal = t.RegistrarDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el registra documento de Fel ")
                strError &= "Fallo en el registra documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\NCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\NCFel" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RegistraDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strXMLFel = nodo.ChildNodes.Item(0).InnerText
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml")
            sw.Write(strXMLFel)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\NCREFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception

            End Try
            Try
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml")
            Catch ex3 As Exception
                MessageBox.Show("Error: " & ex3.Message)
            End Try
            nodos_lista = xml_Documento.GetElementsByTagName("dte:Certificacion")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strNitCertificador = nodo.ChildNodes.Item(0).InnerText  ' Nit MegaPrint
                '  strFechaHoraCertificacion = nodo.ChildNodes.Item(1).InnerText ' Nombre MegaPrint
                strSerieDocumento = nodo.ChildNodes.Item(2).InnerText ' Serie 
                strFechaHoraCertificacion = nodo.ChildNodes.Item(3).InnerText ' FechaCertificacion 
            Next
            ' Nombre del archivo a utilizar
            Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\NCREFel" & celdaNumero.Text & ".xml"
            ' Si el archivo existe
            Dim vloFile As New StreamReader(vlcFileName)
            ' Ciclo de iteración entre líneas
            While True
                ' Cargar la línea
                Dim vlcLinea = vloFile.ReadLine()
                ' Si la línea es nula, sale del ciclo
                If vlcLinea Is Nothing Then Exit While
                ' Si la línea contiene el criterio
                If vlcLinea.Contains(vlcCriterio) Then
                    ' Obtener la línea como resultado,
                    ' Concatenando un retorno de carro si ya hay ocurrencias
                    vlcResultado += IIf(vlcResultado <> "", vbCrLf, "") & vlcLinea
                    ' Salir del ciclo
                    Exit While
                    ' Lo omites si quieres todas las ocurrencias
                End If
            End While
            'Realiza busqueda de la cadena para obtener el numero de Autorizacion
            strCadenaEncontrada = vlcResultado.Substring(vlcResultado.LastIndexOf("Numero=") + 1)
            'En un array parte la cadena despues que encuentre un igual 
            arrayCadena = strCadenaEncontrada.Split("=".ToCharArray)
            'carga el numero de autorizacion de cada documento
            strNumeroAutorizacion = arrayCadena(INT_UNO)
            'sustituye serie por cadena vacio para limpiar la cadena y solo obtenga el numero
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, "Serie", STR_VACIO)
            'sustituye "" por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, """", STR_VACIO)
            'sustituye espacios por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, " ", STR_VACIO)

            ActualizarFel(Horario & "-06:00", strFechaHoraCertificacion, strSerieDocumento, strNumeroAutorizacion, STR_VACIO, strUUID)
            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 31, celdaAño.Text, celdaNumero.Text, Sesion.Usuario & " " & Horario)
            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & strSerieDocumento & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FENCPDF" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FENCPDF" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FENCPDFFinal" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FENCPDFFinal" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FENCPDFFinal" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FENCFel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            botonImprimir.Enabled = True

            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FENCFel" & celdaNumero.Text & ".pdf")
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Sub ImprimirNC()
        Dim strSQL As String = STR_VACIO
        Dim strUUID As String = STR_VACIO
        Dim strToken As String = STR_VACIO
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim intPais As Integer = NO_FILA
        Dim LogBandera As Boolean = False
        Dim LogCMC As Boolean = True
        Dim rpt As New clsReportes
        Dim clsConta As New clsContabilidad
        Dim strSQL2 As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        Dim COM2 As MySqlCommand
        Try
            strSQL = " SELECT e.emp_pais Pais FROM Empresas e  WHERE e.emp_no = " & Sesion.IdEmpresa & " "

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intPais = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            botonImprimir.Enabled = False

            If Sesion.IdEmpresa = 14 Then
                ReporteNotaCreditoRD()
                Exit Sub
            End If
            If Sesion.IdEmpresa = 11 Then
                ReporteNotaCreditoPY()
                Exit Sub
            End If
            If Sesion.IdEmpresa = 15 Then
                ReporteNotaCreditoHSM()
                Exit Sub
            End If
            If Sesion.IdEmpresa = 20 Then
                ReporteNotaCreditoNS()
                Exit Sub
            End If
            If intPais = 310 Or (Sesion.IdEmpresa = 16) Then
                If Cat = 36 Then
                    rpt.rpt_NotasDeCreditoAmtex(celdaAño.Text, celdaNumero.Text)
                Else
                    ReporteNotaCreditoSV()
                End If
                Exit Sub
            End If
            If MsgBox("Print the Details of the invoice?" & vbCrLf & " - Factura,Serie y fecha " & vbCrLf & " - Tipo de Cambio " & vbCrLf & " - Total en moneda local ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                LogBandera = True
            End If
            If Sesion.IdEmpresa = 12 And intPais = 0 Then
                If celdaSerieFel.Text = STR_VACIO Then
                    If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                        If MsgBox("Esta a punto de transmitir esta factura a SAT " & vbNewLine & "Esta seguro que desea continuar? El proceso sera irreversible ", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                            If VerificarDocumentoXML(strToken, strUUID) = INT_CERO Then
                                If ImprimirFel(celdaAño.Text, celdaNumero.Text, strToken, strUUID, IP, strUsuario, strContrasena, strRuta) = True Then
                                    strSQL2 = STR_VACIO
                                    strSQL2 = "UPDATE Dcmtos_HDR h"
                                    strSQL2 &= " SET h.HDoc_Doc_Fec = CURDATE()"
                                    strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 31 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

                                    strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                                    strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
                                    strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                                    'Ejecuta la instrucción
                                    MyCnn.CONECTAR = strConexion
                                    COM2 = New MySqlCommand(strSQL2, CON)
                                    COM2.ExecuteNonQuery()
                                End If
                            Else
                                MsgBox("El documento ya ha sido transmitido")
                            End If
                        Else
                            Exit Sub
                        End If
                        ' ReporteNotaCreditoHilos(LogBandera)
                    Else
                        Exit Sub
                    End If
                Else
                    ArrayServer = strConexion.Split(";".ToCharArray)
                    strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                    ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                    strCadena = ArrayServer(INT_CERO)
                    ArrayValidacion = strCadena.Split(".".ToCharArray)
                    strCadena = ArrayValidacion(INT_CERO)
                    arrayIP = strCadena.Split("=".ToCharArray)
                    If arrayIP(INT_UNO) = "192" Then
                        If VerificarAccesoLocal(IP, strUsuario, strContrasena, strRuta) = True Then
                            ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                        Else
                            Exit Sub
                        End If
                    Else
                        If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                            ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                        Else
                            Exit Sub
                        End If
                    End If
                End If
            ElseIf Sesion.IdEmpresa = 10 Then
                If celdaSerieFel.Text = STR_VACIO Then
                    If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                        If MsgBox("Esta a punto de transmitir esta factura a SAT " & vbNewLine & "Esta seguro que desea continuar? El proceso sera irreversible ", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                            If VerificarDocumentoXML(strToken, strUUID) = INT_CERO Then
                                If ImprimirFelCMC(celdaAño.Text, celdaNumero.Text, strToken, strUUID, IP, strUsuario, strContrasena, strRuta) = True Then
                                    strSQL2 = STR_VACIO
                                    strSQL2 = "UPDATE Dcmtos_HDR h"
                                    strSQL2 &= " SET h.HDoc_Doc_Fec = CURDATE()"
                                    strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 31 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

                                    strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                                    strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
                                    strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                                    'Ejecuta la instrucción
                                    MyCnn.CONECTAR = strConexion
                                    COM2 = New MySqlCommand(strSQL2, CON)
                                    COM2.ExecuteNonQuery()
                                End If
                            Else
                                MsgBox("El documento ya ha sido transmitido")
                            End If
                        Else
                            Exit Sub
                        End If
                        ' ReporteNotaCreditoHilos(LogBandera)
                    Else
                        Exit Sub
                    End If

                Else
                    ArrayServer = strConexion.Split(";".ToCharArray)
                    strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                    ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                    strCadena = ArrayServer(INT_CERO)
                    ArrayValidacion = strCadena.Split(".".ToCharArray)
                    strCadena = ArrayValidacion(INT_CERO)
                    arrayIP = strCadena.Split("=".ToCharArray)
                    If arrayIP(INT_UNO) = "192" Then
                        If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                            ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                        Else
                            Exit Sub
                        End If
                    Else
                        If VerificarAccesoLocal(IP, strUsuario, strContrasena, strRuta) = True Then
                            ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                        Else
                            Exit Sub
                        End If
                    End If
                End If
            Else
                LogCMC = True
                LogBandera = False
                ReporteNotaCreditoHilos(LogBandera, LogCMC)
            End If

            botonImprimir.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        ImprimirNC()
    End Sub

    Private Function BuscarRegistrosDcmtos_HDR_NCHilos(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRNCHilos.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Sub ReporteNotaCreditoHilos(ByVal logBandera As Boolean, Optional CMC As Boolean = True)
        Dim strSQL As String = STR_VACIO
        Dim repCR As New ReporteNCreditosHilos

        strSQL = "      SELECT e.HDoc_Doc_Num Numero, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, "
        strSQL &= "         CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, d.DDoc_Prd_Des Descripcion, COALESCE(me.cat_clave,'') Moneda, SUM(d.DDoc_RF1_Dbl) Total "
        If logBandera = True Then
            strSQL &= "         , CONCAT('FACTURA N° ', CAST(f.HDoc_Doc_Num AS CHAR), IF(COALESCE(f.HDoc_DR2_Num,'')='','', CONCAT(' SERIE ',f.HDoc_DR2_Num)),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) Referencia "
            strSQL &= "                         ,CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) Conversion, ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL  "
        End If
        If CMC = True Then
            strSQL &= "                         , CONCAT('FACTURA N° ', CAST(f.HDoc_Doc_Num AS CHAR), IF(COALESCE(f.HDoc_DR2_Num,'')='','', CONCAT(' SERIE ',f.HDoc_DR2_Num)),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) Referencia "
        End If
        strSQL &= "                    , IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, "
        strSQL &= "                            CONCAT('- ',e.HDoc_RF2_Txt, '-') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario"
        strSQL &= "                                 FROM Dcmtos_HDR e "
        strSQL &= "                                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
        strSQL &= "                                             LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Prd_Cod "
        strSQL &= "                                           LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
        strSQL &= "                                         LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon"
        strSQL &= "                                     LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
        strSQL &= "                                   LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
        strSQL &= "                                 WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        strSQL &= "                             GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NCHilos(strSQL) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRNCHilos.xml")
        Dim frm3 As New frmReporteNotasCreditoHilos
        frm3.Reporte_A_Ver_NCHilos = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRNCHilos.xml")

    End Sub
    Private Function BuscarRegistrosDcmtos_HDR_NCRD(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("NCRD")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRNCRD.xml", XmlWriteMode.WriteSchema)
        End If

    End Function

    Private Function BuscarRegistrosDcmtos_DTL_NCRD(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("NCRD2")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosDTLNCRD.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarRegistrosDcmtos_HDR_NCPY(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas3")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRNCPY.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarRegistrosDcmtos_HDR_NCHSM(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas3")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRNCHSM.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarRegistrosDcmtos_HDR_NCNS(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas3")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRNCNS.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarRegistrosDcmtos_HDR_NCAmtex(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRNCAmtex.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Sub ReporteNotaCreditoPY()
        Dim strSQL As String = STR_VACIO
        Dim repCR As New NotaCreditoPY

        strSQL = "      SELECT CONCAT(e.HDoc_DR2_Num, CAST(LPAD(e.HDoc_Doc_Num,8,0) AS CHAR)) Numero, CONCAT(e.HDoc_DR2_Num, CAST(LPAD(e.HDoc_DR1_Dbl,8,0) AS CHAR)) Nume, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, e.HDoc_Doc_Fec fecha, "
        strSQL &= "         CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, d.DDoc_Prd_Des Descripcion, "
        strSQL &= "                 COALESCE(me.cat_clave,'') Moneda, ROUND(SUM(d.DDoc_RF1_Dbl),2) Total, ROUND((d.DDoc_Prd_DSP),2) precio, IF(d.DDoc_Prd_Cif =0,1, (d.DDoc_Prd_Cif)) cantidad, CONCAT('FACTURA N° ',f.HDoc_DR2_Num, CAST((LPAD(f.HDoc_DR1_Dbl,8,0)) AS CHAR),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) referencia, "
        strSQL &= "                     CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) ConversiON, "
        strSQL &= "                         ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion,"
        strSQL &= "                             CONCAT('- ',e.HDoc_RF2_Txt, '-', ' DOLARES US') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF1_Txt notas,e.HDoc_RF2_Cod CAI,cc.cat_sist Serie, LPAD(g.rango_inicial,8,0) RangoInicial, LPAD(g.rango_final,8,0) RangoFinal, g.autorizacion "
        strSQL &= "                                 FROM Dcmtos_HDR e"
        strSQL &= "                                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
        strSQL &= "                                    LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                                 LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
        strSQL &= "                             LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon "
        strSQL &= "                           LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
        strSQL &= "                       LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
        strSQL &= "                   Left Join Catalogos se ON se.cat_clase = 'Serie' AND se.cat_clave = 'Doc_CNCredito' AND se.cat_pid = 0 "
        strSQL &= "              LEFT JOIN Gface g ON g.empresa = d.DDoc_Sis_Emp AND se.cat_num=g.serie AND e.HDoc_DR1_Dbl >= g.rango_inicial AND e.HDoc_DR1_Dbl  <= g.rango_final "
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num  = g.serie   AND cc.cat_clave = 'Doc_CNCredito' AND cc.cat_clase = 'Serie' "
        strSQL &= "          WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        strSQL &= "    GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NCPY(strSQL) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRNCPY.xml")
        Dim frm3 As New FrmReporteNotaCreditoPY
        frm3.Reporte_A_Ver_NCPY = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRNCPY.xml")
    End Sub
    Private Sub ReporteNotaCreditoHSM()
        Dim strSQL As String = STR_VACIO
        Dim repCR As New NotaCreditoHSM

        'strSQL = "      SELECT CONCAT(e.HDoc_DR2_Num,'-', CAST(LPAD(e.HDoc_Doc_Num,8,0) AS CHAR)) Numero, CONCAT(e.HDoc_DR2_Num,'-', CAST(LPAD(e.HDoc_DR1_Dbl,8,0) AS CHAR)) Nume, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, e.HDoc_Doc_Fec fecha, "
        'strSQL &= "         CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, d.DDoc_Prd_Des Descripcion, "
        'strSQL &= "                 COALESCE(me.cat_clave,'') Moneda, ROUND(SUM(d.DDoc_RF1_Dbl),2) Total, ROUND((d.DDoc_Prd_DSP),2) precio, IF(d.DDoc_Prd_Cif =0,1, (d.DDoc_Prd_Cif)) cantidad, CONCAT('FACTURA N° ',f.HDoc_DR2_Num, CAST((LPAD(f.HDoc_DR1_Dbl,8,0)) AS CHAR),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) referencia, "
        'strSQL &= "                     CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) ConversiON, "
        'strSQL &= "                         ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion,"
        'strSQL &= "                             CONCAT('- ',e.HDoc_RF2_Txt, '-', ' DOLARES US') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF1_Txt notas,

        '                -- e.HDoc_RF2_Cod CAI,cc.cat_sist Serie, LPAD(g.rango_inicial,8,0) RangoInicial, LPAD(g.rango_final,8,0) RangoFinal, g.autorizacion 
        '             ifnull(e.HDoc_RF2_Cod,'|') CAI, ifnull(cc.cat_sist,'') Serie, ifnull(LPAD(g.rango_inicial,8,0),'') RangoInicial, ifnull(LPAD(g.rango_final,8,0),'') RangoFinal, ifnull(g.autorizacion,'') autorizacion"
        'strSQL &= " FROM Dcmtos_HDR e
        '                LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num
        '                LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin
        '                LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num
        '                LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon
        '                LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1
        '                LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación'
        '                LEFT JOIN Catalogos se ON se.cat_clase = 'Serie' AND se.cat_clave = 'Doc_CNCredito' and se.cat_pid=0
        '                LEFT JOIN Gface g ON g.empresa = d.DDoc_Sis_Emp AND g.serie=se.cat_num  AND e.HDoc_DR1_Dbl >= g.rango_inicial AND e.HDoc_DR1_Dbl <= g.rango_final"
        'strSQL &= "          WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        'strSQL &= "    GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "

        strSQL = "  SELECT CONCAT(e.HDoc_DR2_Num,'-', CAST(LPAD(e.HDoc_Doc_Num,8,0) AS CHAR)) Numero, CONCAT(e.HDoc_DR2_Num,'-', CAST(LPAD(e.HDoc_DR1_Dbl,8,0) AS CHAR)) Nume, e.HDoc_Emp_Nom Nombre, 
                        e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, e.HDoc_Doc_Fec fecha, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, 
                        CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, d.DDoc_Prd_Des Descripcion, COALESCE(me.cat_clave,'') Moneda, ROUND(SUM(d.DDoc_RF1_Dbl),2) Total, ROUND((d.DDoc_Prd_DSP),2) precio,
                        IF(d.DDoc_Prd_Cif =0,1, (d.DDoc_Prd_Cif)) cantidad, 
                        CONCAT('FACTURA N° ',f.HDoc_DR2_Num, CAST((LPAD(f.HDoc_DR1_Dbl,8,0)) AS CHAR),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) referencia, 
                        CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) ConversiON, 
                        ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, 
                        IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, 
                        CONCAT('- ',e.HDoc_RF2_Txt, '-', ' DOLARES US') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF1_Txt notas,

                        IFNULL(e.HDoc_RF2_Cod,'|') CAI,  IFNULL(LPAD(g.rango_inicial,8,0),'') RangoInicial, IFNULL(LPAD(g.rango_final,8,0),'') RangoFinal, IFNULL(g.autorizacion,'') autorizacion
                  --      ,e.HDoc_RF2_Cod

                    FROM Dcmtos_HDR e
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num
                    LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin
                    LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num
                    LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon
                    LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1
                    LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación'

                    LEFT JOIN Gface g ON g.empresa = d.DDoc_Sis_Emp AND  e.HDoc_DR1_Dbl >= g.rango_inicial AND e.HDoc_DR1_Dbl <= g.rango_final AND g.serie = e.HDoc_DR2_Cat
                        AND SUBSTRING_INDEX(e.HDoc_RF2_Cod,'|',1) = g.regimen 
                    WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} 
                    GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NCHSM(strSQL) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRNCHSM.xml")
        Dim frm3 As New FrmReporteNotaCreditoHSM
        frm3.Reporte_A_Ver_NCHSM = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRNCHSM.xml")
    End Sub
    Private Sub ReporteNotaCreditoNS()
        Dim strSQL As String = STR_VACIO
        Dim repCR As New NotaCreditoNS

        strSQL = "      SELECT CONCAT(e.HDoc_DR2_Num, CAST(LPAD(e.HDoc_Doc_Num,8,0) AS CHAR)) Numero, CONCAT(e.HDoc_DR2_Num, CAST(LPAD(e.HDoc_DR1_Dbl,8,0) AS CHAR)) Nume, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, e.HDoc_Doc_Fec fecha, "
        strSQL &= "         CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, d.DDoc_Prd_Des Descripcion, "
        strSQL &= "                 COALESCE(me.cat_clave,'') Moneda, ROUND(SUM(d.DDoc_RF1_Dbl),2) Total, ROUND((d.DDoc_Prd_DSP),2) precio, IF(d.DDoc_Prd_Cif =0,1, (d.DDoc_Prd_Cif)) cantidad, CONCAT('FACTURA N° ',f.HDoc_DR2_Num, CAST((LPAD(f.HDoc_DR1_Dbl,8,0)) AS CHAR),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) referencia, "
        strSQL &= "                     CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) ConversiON, "
        strSQL &= "                         ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion,"
        strSQL &= "                             CONCAT('- ',e.HDoc_RF2_Txt, '-', ' DOLARES US') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF1_Txt notas,e.HDoc_RF2_Cod CAI,cc.cat_sist Serie, LPAD(g.rango_inicial,8,0) RangoInicial, LPAD(g.rango_final,8,0) RangoFinal, g.autorizacion "
        strSQL &= "                                 FROM Dcmtos_HDR e"
        strSQL &= "                                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
        strSQL &= "                                    LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                                 LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
        strSQL &= "                             LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon "
        strSQL &= "                           LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
        strSQL &= "                       LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
        strSQL &= "                   Left Join Catalogos se ON se.cat_clase = 'Serie' AND se.cat_clave = 'Doc_CNCredito' AND se.cat_pid = 0 "
        strSQL &= "              LEFT JOIN Gface g ON g.empresa = d.DDoc_Sis_Emp AND  e.HDoc_DR1_Dbl >= g.rango_inicial AND e.HDoc_DR1_Dbl <= g.rango_final AND g.serie = e.HDoc_DR2_Cat AND SUBSTRING_INDEX(e.HDoc_RF2_Cod,'|',1) = g.regimen "
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num  = g.serie   AND cc.cat_clave = 'Doc_CNCredito' AND cc.cat_clase = 'Serie' "
        strSQL &= "          WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        strSQL &= "    GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NCNS(strSQL) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRNCNS.xml")
        Dim frm3 As New FrmReporteNotaCreditoNS
        frm3.Reporte_A_Ver_NCNS = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRNCNS.xml")
    End Sub
    Private Sub ReporteNotaCreditoRD()
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim repCR As New NotaCreditoRD
        strSQL = "  SELECT CONCAT(e.HDoc_DR2_Num, CAST(LPAD(e.HDoc_DR1_Dbl,8,0) AS CHAR)) Numero, e.HDoc_Emp_Nom Cliente, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, "
        strSQL &= "     e.HDoc_Doc_Fec fecha, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, "
        strSQL &= "         d.DDoc_Prd_Des Descripcion, COALESCE(me.cat_clave,'') Moneda, ROUND(SUM(d.DDoc_RF1_Dbl),2) Total, "
        If rbDevoluciones.Checked Then
            strSQL &= "         ROUND((d.DDoc_Prd_DSP),2) precio, SUM(d.DDoc_Prd_Cif) cantidad, "
        Else
            strSQL &= "         ROUND(SUM(d.DDoc_Prd_NET),2) precio,SUM(d.DDoc_Prd_QTY) cantidad,"
        End If
        strSQL &= "             e.HDoc_Doc_Fec Despachado, CAST(IF(t.cli_plazoCR<=0,e.HDoc_Doc_Fec, DATE_ADD(e.HDoc_Doc_Fec, INTERVAL t.cli_plazoCR DAY)) AS DATE) Vencimiento, IF(t.cli_plazoCR<=0,'C0D', CONCAT('Net ', CAST(t.cli_plazoCR AS CHAR))) Credito, "
        strSQL &= "                 CONCAT('FACTURA N° ',f.HDoc_DR2_Num, CAST((LPAD(f.HDoc_DR1_Dbl,7,0)) AS CHAR),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) referencia, CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, "
        strSQL &= "                     e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) ConversiON, ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), "
        strSQL &= "                         CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, CONCAT('- ',e.HDoc_RF2_Txt, '-', ' DOLARES US') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF1_Txt notas "
        strSQL &= "                             FROM Dcmtos_HDR e "
        strSQL &= "                                 INNER JOIN Clientes t ON t.cli_sisemp = e.HDoc_Sis_Emp AND t.cli_codigo = e.HDoc_Emp_Cod "
        strSQL &= "                                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
        strSQL &= "                                         LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                                             LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
        strSQL &= "                                         LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon "
        strSQL &= "                                     LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
        strSQL &= "                                 LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
        strSQL &= "                             WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        strSQL &= "                         GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num"
        If rbDevoluciones.Checked Then
            strSQL &= ", d.DDoc_Prd_DSP "
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NCRD(strSQL) = True Then

        End If

        strSQL2 = "  SELECT CONCAT(e.HDoc_DR2_Num, CAST(LPAD(e.HDoc_DR1_Dbl,8,0) AS CHAR)) Numero, e.HDoc_Emp_Nom Cliente, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, "
        strSQL2 &= "     e.HDoc_Doc_Fec fecha, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, "
        strSQL2 &= "         d.DDoc_Prd_Des DescripcionDTL, COALESCE(me.cat_clave,'') Moneda, ROUND(SUM(d.DDoc_RF1_Dbl),2) TotalDTL, "
        If rbDevoluciones.Checked Then
            strSQL2 &= "         ROUND((d.DDoc_Prd_DSP),2) precioDTL, SUM(d.DDoc_Prd_Cif) cantidadDTL, "
        Else
            strSQL2 &= "         ROUND(SUM(d.DDoc_Prd_NET),2) precioDTL,SUM(d.DDoc_Prd_QTY) cantidadDTL,"
        End If
        strSQL2 &= "             e.HDoc_Doc_Fec Despachado, CAST(IF(t.cli_plazoCR<=0,e.HDoc_Doc_Fec, DATE_ADD(e.HDoc_Doc_Fec, INTERVAL t.cli_plazoCR DAY)) AS DATE) Vencimiento, IF(t.cli_plazoCR<=0,'C0D', CONCAT('Net ', CAST(t.cli_plazoCR AS CHAR))) Credito, "
        strSQL2 &= "                 CONCAT('FACTURA N° ',f.HDoc_DR2_Num, CAST((LPAD(f.HDoc_DR1_Dbl,7,0)) AS CHAR),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) referenciaDTL, CONCAT('A TIPO DE CAMBIO ', COALESCE(ml.cat_clave,'')) Cambio, "
        strSQL2 &= "                     e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) ConversiON, ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), "
        strSQL2 &= "                         CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, CONCAT('- ',e.HDoc_RF2_Txt, '-', ' DOLARES US') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF1_Txt notas "
        strSQL2 &= "                             FROM Dcmtos_HDR e "
        strSQL2 &= "                                 INNER JOIN Clientes t ON t.cli_sisemp = e.HDoc_Sis_Emp AND t.cli_codigo = e.HDoc_Emp_Cod "
        strSQL2 &= "                                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
        strSQL2 &= "                                         LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL2 &= "                                             LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
        strSQL2 &= "                                         LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon "
        strSQL2 &= "                                     LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
        strSQL2 &= "                                 LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
        strSQL2 &= "                             WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        strSQL2 &= "                         GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num"
        If rbDevoluciones.Checked Then
            strSQL2 &= ", d.DDoc_Prd_DSP "
        End If
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_DTL_NCRD(strSQL2) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRNCRD.xml")
        repCR.Load("C:\XML\DcmtosDTLNCRD.xml")
        Dim frm3 As New FrmReporteNotaCreditoPY
        frm3.Reporte_A_Ver_NCPY = repCR
        frm3.Text = "FrmReporteNotaCreditoRD"
        frm3.CrystalReportViewer1.ReportSource = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRNCRD.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosDTLNCRD.xml")
        strSQL = STR_VACIO

    End Sub
    Private Sub ReporteNotaCreditoSV()
        Dim strSQL As String = STR_VACIO
        Dim repCR As New NotaCreditoSV
        strSQL = " SELECT e.HDoc_Doc_Num Numero,e.HDoc_Doc_Fec Fecha,e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_NIT NIT, e.HDoc_Emp_Dir Direccion, "
        strSQL &= "     CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%d') AS CHAR) Dia, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%m') AS CHAR) Mes, CAST(DATE_FORMAT(e.HDoc_Doc_Fec,'%Y') AS CHAR) Año, "
        strSQL &= "         d.DDoc_Prd_Des Descripcion, COALESCE(me.cat_clave,'') Moneda, SUM(d.DDoc_RF1_Dbl) Total, SUM(d.DDoc_Prd_NET) Precio, "
        strSQL &= "             CONCAT('FACTURA N° ', CAST(f.HDoc_DR1_Dbl AS CHAR), IF(COALESCE(f.HDoc_DR2_Num,'')='','', CONCAT(' SERIE ',f.HDoc_DR2_Num)),' DEL ', CAST(DATE_FORMAT(f.HDoc_Doc_Fec,'%d/%m/%Y') AS CHAR)) Referencia, /* CONCAT('A TIPO DE CAMBIO ',  COALESCE(ml.cat_clave,'')) Cambio, "
        strSQL &= "                 e.HDoc_RF1_Dbl Tasa, CONCAT('TOTAL EN ', UCASE(COALESCE(ml.cat_desc,'')),' ', COALESCE(ml.cat_clave,'')) Conversion, */ ROUND(SUM(d.DDoc_RF1_Dbl) * e.HDoc_RF1_Dbl,2) LOCAL, IF(e.HDoc_DR1_Cat = 1 AND NOT(e.HDoc_DR1_Num = ''), CONCAT('NÚMERO DE DECLARACIÓN',' ', COALESCE(re.cat_sist,''),' ',e.HDoc_RF1_Cod),'') Declaracion, "
        strSQL &= "                     CONCAT('- ',e.HDoc_RF2_Txt, '-') Letras, e.HDoc_RF1_Txt Notas, e.HDoc_Usuario Usuario, e.HDoc_RF2_Cod Giro, "
        strSQL &= "                         IF(c.ECta_Ref_Cat=36,f.HDoc_DR1_Dbl,f.HDoc_DR2_Cat) Factura,d.DDoc_Prd_QTY Cantidad , IFNULL(cl.cli_RegistroNo,'') NRC, "
        strSQL &= "                             d.DDoc_RF2_Dbl Impuesto, d.DDoc_RF3_Dbl Retencion1,c.ECta_Ref_Cat Catalogo,IF(f.HDoc_RF2_Num=0,cl.cli_plazoCR,f.HDoc_RF2_Num) Dias "
        strSQL &= "                                 FROM Dcmtos_HDR e "
        strSQL &= "                                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num "
        strSQL &= "                                         LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = e.HDoc_Sis_Emp AND c.ECta_Doc_Cat = e.HDoc_Doc_Cat AND c.ECta_Doc_Ano = e.HDoc_Doc_Ano AND c.ECta_Doc_Num = e.HDoc_Doc_Num AND c.ECta_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                                             LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp = c.ECta_Sis_Emp AND f.HDoc_Doc_Cat = c.ECta_Ref_Cat AND f.Hdoc_Doc_Ano = c.ECta_Ref_Ano AND f.HDoc_Doc_Num = c.ECta_Ref_Num "
        strSQL &= "                                                 LEFT JOIN Catalogos me ON me.cat_clase = 'Monedas' AND me.cat_num = e.HDoc_Doc_Mon "
        'strSQL &= "                                                     LEFT JOIN Catalogos ml ON ml.cat_clase = 'Monedas' AND ml.cat_sist = 1 "
        strSQL &= "                                                         LEFT JOIN Catalogos re ON re.cat_clase = 'Regimenes' AND re.cat_clave = 'Reexportación' "
        strSQL &= "                                                             LEFT JOIN Clientes cl ON cl.cli_sisemp = e.HDoc_Sis_Emp AND cl.cli_codigo = e.HDoc_Emp_Cod "
        strSQL &= "                                                                     WHERE e.HDoc_Sis_Emp = {empresa} AND e.HDoc_Doc_Cat = 31 AND e.HDoc_Doc_Ano = {anio} AND e.HDoc_Doc_Num = {numero} "
        strSQL &= "                                                                     GROUP BY e.HDoc_Doc_Ano, e.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        If BuscarRegistrosDcmtos_HDR_NCAmtex(strSQL) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRNCAmtex.xml")
        Dim frm3 As New FrmReporteNotaCreditoPY
        frm3.Reporte_A_Ver_NCPY = repCR
        frm3.Text = "FrmReporteNotaCreditoSV"
        frm3.CrystalReportViewer1.ReportSource = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRNCAmtex.xml")
    End Sub
    Private Sub botonSerie_Click(sender As Object, e As EventArgs) Handles botonSerie.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Campos = " cat_sist "
            frm.Tabla = " Catalogos "
            frm.Condicion = " cat_clase='Serie' AND cat_clave= 'Doc_NotaC'  and cat_sisemp = " & Sesion.IdEmpresa
            frm.Filtro = " cat_sist"
            frm.FiltroText = " Enter the serial number to filter. "
            frm.Titulo = " Series "
            frm.ShowDialog(Fprincipal)
            If frm.DialogResult = DialogResult.OK Then
                celdaSerie1.Text = frm.LLave
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(31, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(0).Value, 31)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Try
            cfun.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarEncabezadoNC(celdaNumero.Text, celdaAño.Text)
                BorrarDetalleNC(celdaNumero.Text, celdaAño.Text)
                BorrarEctateNC(celdaNumero.Text, celdaAño.Text)
                BorrarImpNC(celdaNumero.Text, celdaAño.Text)
                cFunciones.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAño.Text, 31)
                cFunciones.BorrarDetallePoliza(celdaNumero.Text, celdaAño.Text, 31)
                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 31, celdaAño.Text, celdaNumero.Text)
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub checkActivar_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivar.CheckedChanged
        If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 10) Then
            If checkActivar.Checked = True Then
                Encabezado1.botonGuardar.Enabled = False
            Else
                Encabezado1.botonGuardar.Enabled = True
            End If
        End If
    End Sub

    Private Sub botonPrevio_Click(sender As Object, e As EventArgs) Handles botonPrevio.Click
        Dim LogBandera As Boolean = False
        Dim LogCMC As Boolean = False
        If MsgBox("Print the Details of the invoice?" & vbCrLf & " - Factura,Serie y fecha " & vbCrLf & " - Tipo de Cambio " & vbCrLf & " - Total en moneda local ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
            LogBandera = True
        End If
        If Sesion.IdEmpresa = 10 Then
            LogCMC = True
            LogBandera = False
            ReporteNotaCreditoHilos(LogBandera, LogCMC)
        Else
            ReporteNotaCreditoHilos(LogBandera)
        End If


    End Sub

    Private Sub frmNotasDeCredito_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If dgDetalleNC.SelectedRows.Count = 0 Then Exit Sub
        If MsgBox("You want to delete the selected line?", vbYesNo, "Question") = vbYes Then
            dgDetalleNC.CurrentRow.Cells(16).Value = 2
            dgDetalleNC.CurrentRow.Visible = False
            CalcularTotales()
        End If

    End Sub

    Private Sub dgDetalleNC_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalleNC.CellEndEdit
        CalcularTotales()
        CeldaTotalEnLetras.Text = cFunciones.ALetras(celdaTotal.Text).ToUpper
    End Sub

    Private Sub GuardarFelServiImport()
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 31
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = dtpFech.Value.ToString(FORMATO_MYSQL)
            cFel.FECHAHORACERTIFICACION = dtpFech.Value.ToString(FORMATO_MYSQL)
            cFel.SERIE = celdaSeriFelServi.Text
            cFel.NUMEROAUTORIZACION = celdaNumeroFelServi.Text
            cFel.INCOTERM = ""
            cFel.UUID = ""
            If Me.Tag = "Nuevo" Then
                If cFel.PINSERT() = False Then
                    MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            Else
                If cFel.PUPDATE() = False Then
                    MsgBox(cFel.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarDatosFelServiImport(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = " SELECT Serie, NumeroAutorizacion
                        FROM Fel
                        WHERE Empresa = {emp} AND Catalogo = 31 AND Anio = {anio} AND Numero = {num}"
            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", anio)
            strSQL = strSQL.Replace("{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaSeriFelServi.Text = REA.GetString("Serie")
                    celdaNumeroFelServi.Text = REA.GetString("NumeroAutorizacion")
                Loop

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dtpFech_ValueChanged(sender As Object, e As EventArgs) Handles dtpFech.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFech.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub botonImprimir_ControlRemoved(sender As Object, e As ControlEventArgs) Handles botonImprimir.ControlRemoved

    End Sub

    Private Sub dgLista_DataMemberChanged(sender As Object, e As EventArgs) Handles dgLista.DataMemberChanged

    End Sub



#End Region

End Class