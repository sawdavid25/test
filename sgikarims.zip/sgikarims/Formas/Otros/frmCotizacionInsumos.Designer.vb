﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCotizacionInsumos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRequisicion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado_ = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.PanelTotal = New System.Windows.Forms.Panel()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.panelBotonesDetalle = New System.Windows.Forms.Panel()
        Me.botonAgrega = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoUM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMontoDescuento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescuento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCalculo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaDescuento = New System.Windows.Forms.TextBox()
        Me.checkDescuento = New System.Windows.Forms.CheckBox()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.BotonMoneda = New System.Windows.Forms.Button()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.gbRequisa = New System.Windows.Forms.GroupBox()
        Me.dgRequisa = New System.Windows.Forms.DataGridView()
        Me.col_Tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonAgregarRequisicion = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        Me.PanelTotal.SuspendLayout()
        Me.panelBotonesDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelEncabezado.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbRequisa.SuspendLayout()
        CType(Me.dgRequisa, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Location = New System.Drawing.Point(11, 108)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(542, 53)
        Me.PanelLista.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colFecha, Me.colName, Me.colRequisicion, Me.colEstado_})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 38)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(542, 15)
        Me.dgLista.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Width = 67
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 87
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colName
        '
        Me.colName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colName.HeaderText = "Name"
        Me.colName.Name = "colName"
        Me.colName.ReadOnly = True
        Me.colName.Width = 60
        '
        'colRequisicion
        '
        Me.colRequisicion.HeaderText = "Requisitions"
        Me.colRequisicion.Name = "colRequisicion"
        Me.colRequisicion.ReadOnly = True
        '
        'colEstado_
        '
        Me.colEstado_.HeaderText = "Status"
        Me.colEstado_.Name = "colEstado_"
        Me.colEstado_.ReadOnly = True
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(542, 38)
        Me.panelFiltro.TabIndex = 3
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(457, 6)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.PanelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(11, 165)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(895, 567)
        Me.panelDocumento.TabIndex = 4
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.PanelTotal)
        Me.PanelDetalle.Controls.Add(Me.panelBotonesDetalle)
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 309)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(895, 258)
        Me.PanelDetalle.TabIndex = 5
        '
        'PanelTotal
        '
        Me.PanelTotal.Controls.Add(Me.celdaTotal)
        Me.PanelTotal.Controls.Add(Me.celdaCantidad)
        Me.PanelTotal.Controls.Add(Me.Label18)
        Me.PanelTotal.Controls.Add(Me.Label17)
        Me.PanelTotal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelTotal.Location = New System.Drawing.Point(0, 174)
        Me.PanelTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelTotal.Name = "PanelTotal"
        Me.PanelTotal.Size = New System.Drawing.Size(856, 84)
        Me.PanelTotal.TabIndex = 4
        '
        'celdaTotal
        '
        Me.celdaTotal.AllowDrop = True
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Enabled = False
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTotal.Location = New System.Drawing.Point(719, 53)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(121, 20)
        Me.celdaTotal.TabIndex = 26
        '
        'celdaCantidad
        '
        Me.celdaCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCantidad.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCantidad.Enabled = False
        Me.celdaCantidad.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaCantidad.Location = New System.Drawing.Point(595, 53)
        Me.celdaCantidad.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(110, 20)
        Me.celdaCantidad.TabIndex = 25
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(593, 37)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(46, 13)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Quantity"
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(716, 37)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(31, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Total"
        '
        'panelBotonesDetalle
        '
        Me.panelBotonesDetalle.Controls.Add(Me.botonAgrega)
        Me.panelBotonesDetalle.Controls.Add(Me.botonQuitar)
        Me.panelBotonesDetalle.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotonesDetalle.Location = New System.Drawing.Point(856, 0)
        Me.panelBotonesDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBotonesDetalle.Name = "panelBotonesDetalle"
        Me.panelBotonesDetalle.Size = New System.Drawing.Size(39, 258)
        Me.panelBotonesDetalle.TabIndex = 9
        '
        'botonAgrega
        '
        Me.botonAgrega.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgrega.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgrega.Location = New System.Drawing.Point(3, 13)
        Me.botonAgrega.Name = "botonAgrega"
        Me.botonAgrega.Size = New System.Drawing.Size(33, 23)
        Me.botonAgrega.TabIndex = 7
        Me.botonAgrega.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(3, 53)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(34, 24)
        Me.botonQuitar.TabIndex = 8
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcionArticulo, Me.colCodigoUM, Me.colUM, Me.colCantidad, Me.colPrecio, Me.colTotal, Me.colMontoDescuento, Me.colDescuento, Me.colImpuesto, Me.colEstado, Me.colLinea, Me.colCatalogoPro, Me.colAnioPro, Me.colNumeroPro, Me.colLineaPro, Me.colExtra, Me.colCalculo})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(895, 258)
        Me.dgDetalle.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 57
        '
        'colDescripcionArticulo
        '
        Me.colDescripcionArticulo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcionArticulo.HeaderText = "Description"
        Me.colDescripcionArticulo.Name = "colDescripcionArticulo"
        Me.colDescripcionArticulo.ReadOnly = True
        Me.colDescripcionArticulo.Width = 85
        '
        'colCodigoUM
        '
        Me.colCodigoUM.HeaderText = "CodigoUM"
        Me.colCodigoUM.Name = "colCodigoUM"
        Me.colCodigoUM.Visible = False
        Me.colCodigoUM.Width = 82
        '
        'colUM
        '
        Me.colUM.HeaderText = "UM"
        Me.colUM.Name = "colUM"
        Me.colUM.Width = 49
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colMontoDescuento
        '
        Me.colMontoDescuento.HeaderText = "Discount Amount"
        Me.colMontoDescuento.Name = "colMontoDescuento"
        Me.colMontoDescuento.Width = 104
        '
        'colDescuento
        '
        Me.colDescuento.HeaderText = "% Discount"
        Me.colDescuento.Name = "colDescuento"
        Me.colDescuento.Width = 79
        '
        'colImpuesto
        '
        Me.colImpuesto.HeaderText = "% Tax"
        Me.colImpuesto.Name = "colImpuesto"
        Me.colImpuesto.Width = 57
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Width = 62
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 58
        '
        'colCatalogoPro
        '
        Me.colCatalogoPro.HeaderText = "Catalogo"
        Me.colCatalogoPro.Name = "colCatalogoPro"
        Me.colCatalogoPro.ReadOnly = True
        Me.colCatalogoPro.Visible = False
        Me.colCatalogoPro.Width = 74
        '
        'colAnioPro
        '
        Me.colAnioPro.HeaderText = "Anio"
        Me.colAnioPro.Name = "colAnioPro"
        Me.colAnioPro.ReadOnly = True
        Me.colAnioPro.Visible = False
        Me.colAnioPro.Width = 53
        '
        'colNumeroPro
        '
        Me.colNumeroPro.HeaderText = "Numero"
        Me.colNumeroPro.Name = "colNumeroPro"
        Me.colNumeroPro.ReadOnly = True
        Me.colNumeroPro.Visible = False
        Me.colNumeroPro.Width = 69
        '
        'colLineaPro
        '
        Me.colLineaPro.HeaderText = "LineaPro"
        Me.colLineaPro.Name = "colLineaPro"
        Me.colLineaPro.ReadOnly = True
        Me.colLineaPro.Visible = False
        Me.colLineaPro.Width = 74
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        Me.colExtra.Width = 56
        '
        'colCalculo
        '
        Me.colCalculo.HeaderText = "Calculation"
        Me.colCalculo.Name = "colCalculo"
        Me.colCalculo.ReadOnly = True
        Me.colCalculo.Width = 84
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.GroupBox1)
        Me.PanelEncabezado.Controls.Add(Me.gbRequisa)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(895, 309)
        Me.PanelEncabezado.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaDescuento)
        Me.GroupBox1.Controls.Add(Me.checkDescuento)
        Me.GroupBox1.Controls.Add(Me.checkActive)
        Me.GroupBox1.Controls.Add(Me.celdaNumero)
        Me.GroupBox1.Controls.Add(Me.celdaTasa)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.botonProveedor)
        Me.GroupBox1.Controls.Add(Me.celdaidProveedor)
        Me.GroupBox1.Controls.Add(Me.celdaIdMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaMoneda)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.celdaNit)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.celdaDireccion)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.BotonMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaNombre)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(399, 303)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document Data"
        '
        'celdaDescuento
        '
        Me.celdaDescuento.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDescuento.Location = New System.Drawing.Point(9, 277)
        Me.celdaDescuento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDescuento.Name = "celdaDescuento"
        Me.celdaDescuento.Size = New System.Drawing.Size(95, 20)
        Me.celdaDescuento.TabIndex = 28
        '
        'checkDescuento
        '
        Me.checkDescuento.AutoSize = True
        Me.checkDescuento.Location = New System.Drawing.Point(9, 256)
        Me.checkDescuento.Margin = New System.Windows.Forms.Padding(2)
        Me.checkDescuento.Name = "checkDescuento"
        Me.checkDescuento.Size = New System.Drawing.Size(108, 17)
        Me.checkDescuento.TabIndex = 27
        Me.checkDescuento.Text = "General Discount"
        Me.checkDescuento.UseVisualStyleBackColor = True
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(257, 17)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 2
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumero.Location = New System.Drawing.Point(54, 54)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(80, 19)
        Me.celdaNumero.TabIndex = 25
        Me.celdaNumero.Text = "-1"
        '
        'celdaTasa
        '
        Me.celdaTasa.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTasa.Location = New System.Drawing.Point(243, 222)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(95, 20)
        Me.celdaTasa.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(208, 223)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(30, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Rate"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(352, 91)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(32, 19)
        Me.botonProveedor.TabIndex = 22
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaidProveedor.Location = New System.Drawing.Point(370, 63)
        Me.celdaidProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(14, 20)
        Me.celdaidProveedor.TabIndex = 21
        Me.celdaidProveedor.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdMoneda.Location = New System.Drawing.Point(196, 224)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(8, 20)
        Me.celdaIdMoneda.TabIndex = 20
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaMoneda.Location = New System.Drawing.Point(55, 223)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(102, 20)
        Me.celdaMoneda.TabIndex = 19
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 225)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Currency"
        '
        'celdaNit
        '
        Me.celdaNit.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNit.Location = New System.Drawing.Point(52, 180)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(296, 20)
        Me.celdaNit.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 183)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "N.I.T"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDireccion.Location = New System.Drawing.Point(52, 123)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(332, 45)
        Me.celdaDireccion.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 123)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Address"
        '
        'BotonMoneda
        '
        Me.BotonMoneda.Location = New System.Drawing.Point(160, 222)
        Me.BotonMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.BotonMoneda.Name = "BotonMoneda"
        Me.BotonMoneda.Size = New System.Drawing.Size(32, 19)
        Me.BotonMoneda.TabIndex = 9
        Me.BotonMoneda.Text = "..."
        Me.BotonMoneda.UseVisualStyleBackColor = True
        '
        'celdaNombre
        '
        Me.celdaNombre.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNombre.Location = New System.Drawing.Point(52, 92)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.ReadOnly = True
        Me.celdaNombre.Size = New System.Drawing.Size(296, 20)
        Me.celdaNombre.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 94)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Name"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(196, 60)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(117, 20)
        Me.dtpFecha.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(159, 63)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 58)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Number"
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaAño.Location = New System.Drawing.Point(55, 28)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(80, 20)
        Me.celdaAño.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Year"
        '
        'gbRequisa
        '
        Me.gbRequisa.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbRequisa.Controls.Add(Me.dgRequisa)
        Me.gbRequisa.Controls.Add(Me.PanelBotones)
        Me.gbRequisa.Location = New System.Drawing.Point(406, 2)
        Me.gbRequisa.Margin = New System.Windows.Forms.Padding(2)
        Me.gbRequisa.Name = "gbRequisa"
        Me.gbRequisa.Padding = New System.Windows.Forms.Padding(2)
        Me.gbRequisa.Size = New System.Drawing.Size(482, 105)
        Me.gbRequisa.TabIndex = 1
        Me.gbRequisa.TabStop = False
        Me.gbRequisa.Text = "Requisitions"
        '
        'dgRequisa
        '
        Me.dgRequisa.AllowUserToAddRows = False
        Me.dgRequisa.AllowUserToDeleteRows = False
        Me.dgRequisa.AllowUserToOrderColumns = True
        Me.dgRequisa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgRequisa.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgRequisa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgRequisa.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_Tipo, Me.col_anio, Me.col_Numero, Me.col_fecha, Me.colProveedor, Me.col_referencia, Me.colSaldo, Me.colStatus})
        Me.dgRequisa.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgRequisa.Location = New System.Drawing.Point(2, 15)
        Me.dgRequisa.Margin = New System.Windows.Forms.Padding(2)
        Me.dgRequisa.MultiSelect = False
        Me.dgRequisa.Name = "dgRequisa"
        Me.dgRequisa.ReadOnly = True
        Me.dgRequisa.RowTemplate.Height = 24
        Me.dgRequisa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgRequisa.Size = New System.Drawing.Size(436, 88)
        Me.dgRequisa.TabIndex = 2
        '
        'col_Tipo
        '
        Me.col_Tipo.HeaderText = "Type"
        Me.col_Tipo.Name = "col_Tipo"
        Me.col_Tipo.ReadOnly = True
        Me.col_Tipo.Visible = False
        Me.col_Tipo.Width = 56
        '
        'col_anio
        '
        Me.col_anio.HeaderText = "Year"
        Me.col_anio.Name = "col_anio"
        Me.col_anio.ReadOnly = True
        Me.col_anio.Width = 54
        '
        'col_Numero
        '
        Me.col_Numero.HeaderText = "Number"
        Me.col_Numero.Name = "col_Numero"
        Me.col_Numero.ReadOnly = True
        Me.col_Numero.Width = 69
        '
        'col_fecha
        '
        Me.col_fecha.HeaderText = "Date"
        Me.col_fecha.Name = "col_fecha"
        Me.col_fecha.ReadOnly = True
        Me.col_fecha.Width = 55
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Requester"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        Me.colProveedor.Width = 81
        '
        'col_referencia
        '
        Me.col_referencia.HeaderText = "Reference"
        Me.col_referencia.Name = "col_referencia"
        Me.col_referencia.ReadOnly = True
        Me.col_referencia.Visible = False
        Me.col_referencia.Width = 82
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance KG"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Visible = False
        Me.colSaldo.Width = 89
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Estado"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Visible = False
        Me.colStatus.Width = 65
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.Button1)
        Me.PanelBotones.Controls.Add(Me.botonAgregarRequisicion)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(438, 15)
        Me.PanelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(42, 88)
        Me.PanelBotones.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button1.Location = New System.Drawing.Point(5, 44)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(31, 28)
        Me.Button1.TabIndex = 12
        Me.Button1.UseVisualStyleBackColor = False
        '
        'botonAgregarRequisicion
        '
        Me.botonAgregarRequisicion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregarRequisicion.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregarRequisicion.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarRequisicion.Location = New System.Drawing.Point(4, 8)
        Me.botonAgregarRequisicion.Name = "botonAgregarRequisicion"
        Me.botonAgregarRequisicion.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregarRequisicion.TabIndex = 11
        Me.botonAgregarRequisicion.UseVisualStyleBackColor = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(918, 30)
        Me.BarraTitulo1.TabIndex = 2
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(918, 72)
        Me.Encabezado1.TabIndex = 1
        '
        'frmCotizacionInsumos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(918, 734)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCotizacionInsumos"
        Me.Text = "frmCotizacionInsumos"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        Me.PanelTotal.ResumeLayout(False)
        Me.PanelTotal.PerformLayout()
        Me.panelBotonesDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelEncabezado.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbRequisa.ResumeLayout(False)
        CType(Me.dgRequisa, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelBotonesDetalle As Panel
    Friend WithEvents botonAgrega As Button
    Friend WithEvents botonQuitar As Button
    Friend WithEvents PanelTotal As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaCantidad As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents PanelEncabezado As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents BotonMoneda As Button
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents gbRequisa As GroupBox
    Friend WithEvents dgRequisa As DataGridView
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents botonAgregarRequisicion As Button
    Friend WithEvents col_Tipo As DataGridViewTextBoxColumn
    Friend WithEvents col_anio As DataGridViewTextBoxColumn
    Friend WithEvents col_Numero As DataGridViewTextBoxColumn
    Friend WithEvents col_fecha As DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As DataGridViewTextBoxColumn
    Friend WithEvents col_referencia As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents checkDescuento As System.Windows.Forms.CheckBox
    Friend WithEvents celdaDescuento As TextBox
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colName As DataGridViewTextBoxColumn
    Friend WithEvents colRequisicion As DataGridViewTextBoxColumn
    Friend WithEvents colEstado_ As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionArticulo As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoUM As DataGridViewTextBoxColumn
    Friend WithEvents colUM As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colMontoDescuento As DataGridViewTextBoxColumn
    Friend WithEvents colDescuento As DataGridViewTextBoxColumn
    Friend WithEvents colImpuesto As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoPro As DataGridViewTextBoxColumn
    Friend WithEvents colAnioPro As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroPro As DataGridViewTextBoxColumn
    Friend WithEvents colLineaPro As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents colCalculo As DataGridViewTextBoxColumn
End Class
