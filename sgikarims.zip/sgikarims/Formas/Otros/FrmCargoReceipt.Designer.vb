﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmCargoReceipt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmCargoReceipt))
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContacto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.col_codigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDevolucion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Referencia1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Contrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_credito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_envio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_presentado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_documento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_pago = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_FSD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ref_Canio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ref_CNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ref_CLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Extra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelTotal = New System.Windows.Forms.Panel()
        Me.lblInformacion = New System.Windows.Forms.Label()
        Me.lblLinea = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.celdaObservacion = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.CeldaInfo = New System.Windows.Forms.TextBox()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonContacto = New System.Windows.Forms.Button()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaidCliente = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaContacto = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.BotonMoneda = New System.Windows.Forms.Button()
        Me.celdaNombreCliente = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.celdaFirmante = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.celdaIdAplicante = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaDireccion2 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.botonAplicante = New System.Windows.Forms.Button()
        Me.celdaAplicante = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.celdaPoliza = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaDocumento = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.gbFactura = New System.Windows.Forms.GroupBox()
        Me.dgFactura = New System.Windows.Forms.DataGridView()
        Me.col_Tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.botonAgregarFactura = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.number = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTotal.SuspendLayout()
        Me.PanelEncabezado.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gbFactura.SuspendLayout()
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Location = New System.Drawing.Point(21, 115)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(628, 53)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colFecha, Me.colNombre, Me.colContacto, Me.colReferencia})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.GridColor = System.Drawing.SystemColors.ControlDarkDark
        Me.dgLista.Location = New System.Drawing.Point(0, 38)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(628, 15)
        Me.dgLista.TabIndex = 4
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Width = 54
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 69
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 60
        '
        'colContacto
        '
        Me.colContacto.HeaderText = "Contact"
        Me.colContacto.Name = "colContacto"
        Me.colContacto.ReadOnly = True
        Me.colContacto.Width = 69
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 82
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(628, 38)
        Me.panelFiltro.TabIndex = 3
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(474, 9)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(110, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.PanelTotal)
        Me.panelDocumento.Controls.Add(Me.PanelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(21, 173)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(895, 464)
        Me.panelDocumento.TabIndex = 3
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 287)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(895, 104)
        Me.PanelDetalle.TabIndex = 5
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_codigo, Me.col_descripcion, Me.colidMedida, Me.colBase, Me.colMedida, Me.colPrecio, Me.colCantidad, Me.colDevolucion, Me.colTotal, Me.col_linea, Me.col_Referencia1, Me.col_Contrato, Me.col_credito, Me.col_envio, Me.col_presentado, Me.col_documento, Me.col_pago, Me.col_FSD, Me.colRefAnio, Me.colRefNum, Me.colRefLine, Me.ref_Canio, Me.ref_CNum, Me.ref_CLin, Me.col_Extra})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(895, 104)
        Me.dgDetalle.TabIndex = 0
        '
        'col_codigo
        '
        Me.col_codigo.HeaderText = "Code"
        Me.col_codigo.Name = "col_codigo"
        Me.col_codigo.ReadOnly = True
        Me.col_codigo.Width = 57
        '
        'col_descripcion
        '
        Me.col_descripcion.HeaderText = "Description"
        Me.col_descripcion.Name = "col_descripcion"
        Me.col_descripcion.Width = 85
        '
        'colidMedida
        '
        Me.colidMedida.HeaderText = "idMedida"
        Me.colidMedida.Name = "colidMedida"
        Me.colidMedida.ReadOnly = True
        Me.colidMedida.Visible = False
        Me.colidMedida.Width = 94
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.Name = "colBase"
        Me.colBase.ReadOnly = True
        Me.colBase.Visible = False
        Me.colBase.Width = 69
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colDevolucion
        '
        Me.colDevolucion.HeaderText = "Devolution"
        Me.colDevolucion.Name = "colDevolucion"
        Me.colDevolucion.Width = 83
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'col_linea
        '
        Me.col_linea.HeaderText = "Line"
        Me.col_linea.Name = "col_linea"
        Me.col_linea.ReadOnly = True
        Me.col_linea.Width = 52
        '
        'col_Referencia1
        '
        Me.col_Referencia1.HeaderText = "Reference"
        Me.col_Referencia1.Name = "col_Referencia1"
        Me.col_Referencia1.ReadOnly = True
        Me.col_Referencia1.Width = 82
        '
        'col_Contrato
        '
        Me.col_Contrato.HeaderText = "Contract"
        Me.col_Contrato.Name = "col_Contrato"
        Me.col_Contrato.Width = 72
        '
        'col_credito
        '
        Me.col_credito.HeaderText = "L/C N°"
        Me.col_credito.Name = "col_credito"
        Me.col_credito.Width = 65
        '
        'col_envio
        '
        Me.col_envio.HeaderText = "Shipping"
        Me.col_envio.Name = "col_envio"
        Me.col_envio.ReadOnly = True
        Me.col_envio.Width = 73
        '
        'col_presentado
        '
        Me.col_presentado.HeaderText = "Presented"
        Me.col_presentado.Name = "col_presentado"
        Me.col_presentado.ReadOnly = True
        Me.col_presentado.Width = 80
        '
        'col_documento
        '
        Me.col_documento.HeaderText = "Document"
        Me.col_documento.Name = "col_documento"
        Me.col_documento.ReadOnly = True
        Me.col_documento.Width = 81
        '
        'col_pago
        '
        Me.col_pago.HeaderText = "Payment"
        Me.col_pago.Name = "col_pago"
        Me.col_pago.ReadOnly = True
        Me.col_pago.Width = 73
        '
        'col_FSD
        '
        Me.col_FSD.HeaderText = "FSD & LSD"
        Me.col_FSD.Name = "col_FSD"
        Me.col_FSD.ReadOnly = True
        Me.col_FSD.Width = 86
        '
        'colRefAnio
        '
        Me.colRefAnio.HeaderText = "refAnio"
        Me.colRefAnio.Name = "colRefAnio"
        Me.colRefAnio.ReadOnly = True
        Me.colRefAnio.Visible = False
        Me.colRefAnio.Width = 82
        '
        'colRefNum
        '
        Me.colRefNum.HeaderText = "RefNum"
        Me.colRefNum.Name = "colRefNum"
        Me.colRefNum.ReadOnly = True
        Me.colRefNum.Visible = False
        Me.colRefNum.Width = 88
        '
        'colRefLine
        '
        Me.colRefLine.HeaderText = "RefLinea"
        Me.colRefLine.Name = "colRefLine"
        Me.colRefLine.ReadOnly = True
        Me.colRefLine.Visible = False
        Me.colRefLine.Width = 94
        '
        'ref_Canio
        '
        Me.ref_Canio.HeaderText = "CartaAnio"
        Me.ref_Canio.Name = "ref_Canio"
        Me.ref_Canio.ReadOnly = True
        Me.ref_Canio.Visible = False
        Me.ref_Canio.Width = 99
        '
        'ref_CNum
        '
        Me.ref_CNum.HeaderText = "CartaNum"
        Me.ref_CNum.Name = "ref_CNum"
        Me.ref_CNum.ReadOnly = True
        Me.ref_CNum.Visible = False
        '
        'ref_CLin
        '
        Me.ref_CLin.HeaderText = "CartaLinea"
        Me.ref_CLin.Name = "ref_CLin"
        Me.ref_CLin.ReadOnly = True
        Me.ref_CLin.Visible = False
        Me.ref_CLin.Width = 106
        '
        'col_Extra
        '
        Me.col_Extra.HeaderText = "Extra"
        Me.col_Extra.Name = "col_Extra"
        Me.col_Extra.ReadOnly = True
        Me.col_Extra.Visible = False
        Me.col_Extra.Width = 69
        '
        'PanelTotal
        '
        Me.PanelTotal.Controls.Add(Me.lblInformacion)
        Me.PanelTotal.Controls.Add(Me.lblLinea)
        Me.PanelTotal.Controls.Add(Me.celdaTotal)
        Me.PanelTotal.Controls.Add(Me.celdaCantidad)
        Me.PanelTotal.Controls.Add(Me.Label18)
        Me.PanelTotal.Controls.Add(Me.Label17)
        Me.PanelTotal.Controls.Add(Me.celdaObservacion)
        Me.PanelTotal.Controls.Add(Me.Label16)
        Me.PanelTotal.Controls.Add(Me.CeldaInfo)
        Me.PanelTotal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelTotal.Location = New System.Drawing.Point(0, 391)
        Me.PanelTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelTotal.Name = "PanelTotal"
        Me.PanelTotal.Size = New System.Drawing.Size(895, 73)
        Me.PanelTotal.TabIndex = 4
        '
        'lblInformacion
        '
        Me.lblInformacion.AutoSize = True
        Me.lblInformacion.Location = New System.Drawing.Point(60, 5)
        Me.lblInformacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblInformacion.Name = "lblInformacion"
        Me.lblInformacion.Size = New System.Drawing.Size(86, 13)
        Me.lblInformacion.TabIndex = 28
        Me.lblInformacion.Text = "(add Information)"
        '
        'lblLinea
        '
        Me.lblLinea.AutoSize = True
        Me.lblLinea.Location = New System.Drawing.Point(8, 5)
        Me.lblLinea.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLinea.Name = "lblLinea"
        Me.lblLinea.Size = New System.Drawing.Size(48, 13)
        Me.lblLinea.TabIndex = 27
        Me.lblLinea.Text = "Linea 00"
        '
        'celdaTotal
        '
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTotal.Location = New System.Drawing.Point(764, 50)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(124, 20)
        Me.celdaTotal.TabIndex = 26
        '
        'celdaCantidad
        '
        Me.celdaCantidad.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCantidad.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaCantidad.Location = New System.Drawing.Point(620, 50)
        Me.celdaCantidad.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(134, 20)
        Me.celdaCantidad.TabIndex = 25
        '
        'Label18
        '
        Me.Label18.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(660, 33)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(46, 13)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Quantity"
        '
        'Label17
        '
        Me.Label17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(813, 33)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(31, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Total"
        '
        'celdaObservacion
        '
        Me.celdaObservacion.Location = New System.Drawing.Point(86, 40)
        Me.celdaObservacion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaObservacion.Multiline = True
        Me.celdaObservacion.Name = "celdaObservacion"
        Me.celdaObservacion.Size = New System.Drawing.Size(530, 28)
        Me.celdaObservacion.TabIndex = 2
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(10, 40)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(64, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Observation"
        '
        'CeldaInfo
        '
        Me.CeldaInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaInfo.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaInfo.Location = New System.Drawing.Point(2, 2)
        Me.CeldaInfo.Margin = New System.Windows.Forms.Padding(2)
        Me.CeldaInfo.Multiline = True
        Me.CeldaInfo.Name = "CeldaInfo"
        Me.CeldaInfo.Size = New System.Drawing.Size(891, 29)
        Me.CeldaInfo.TabIndex = 0
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.GroupBox1)
        Me.PanelEncabezado.Controls.Add(Me.GroupBox2)
        Me.PanelEncabezado.Controls.Add(Me.gbFactura)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(895, 287)
        Me.PanelEncabezado.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonContacto)
        Me.GroupBox1.Controls.Add(Me.celdaTasa)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.botonCliente)
        Me.GroupBox1.Controls.Add(Me.celdaidCliente)
        Me.GroupBox1.Controls.Add(Me.celdaIdMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaMoneda)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.celdaNit)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.celdaTelefono)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.celdaContacto)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.celdaDireccion)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.BotonMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaNombreCliente)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.celdaNumero)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.checkActive)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(399, 284)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document Data"
        '
        'botonContacto
        '
        Me.botonContacto.Location = New System.Drawing.Point(352, 157)
        Me.botonContacto.Margin = New System.Windows.Forms.Padding(2)
        Me.botonContacto.Name = "botonContacto"
        Me.botonContacto.Size = New System.Drawing.Size(32, 19)
        Me.botonContacto.TabIndex = 25
        Me.botonContacto.Text = "..."
        Me.botonContacto.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTasa.Location = New System.Drawing.Point(243, 226)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(95, 20)
        Me.celdaTasa.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(208, 227)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Tasa"
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(352, 80)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(32, 19)
        Me.botonCliente.TabIndex = 22
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaidCliente
        '
        Me.celdaidCliente.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaidCliente.Location = New System.Drawing.Point(269, 25)
        Me.celdaidCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidCliente.Name = "celdaidCliente"
        Me.celdaidCliente.Size = New System.Drawing.Size(14, 20)
        Me.celdaidCliente.TabIndex = 21
        Me.celdaidCliente.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdMoneda.Location = New System.Drawing.Point(196, 228)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(8, 20)
        Me.celdaIdMoneda.TabIndex = 20
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaMoneda.Location = New System.Drawing.Point(55, 227)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(102, 20)
        Me.celdaMoneda.TabIndex = 19
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 231)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Moneda"
        '
        'celdaNit
        '
        Me.celdaNit.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNit.Location = New System.Drawing.Point(52, 204)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(296, 20)
        Me.celdaNit.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 206)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "N.I.T"
        '
        'celdaTelefono
        '
        Me.celdaTelefono.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTelefono.Location = New System.Drawing.Point(52, 181)
        Me.celdaTelefono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(296, 20)
        Me.celdaTelefono.TabIndex = 15
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(4, 180)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Phone "
        '
        'celdaContacto
        '
        Me.celdaContacto.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaContacto.Location = New System.Drawing.Point(52, 158)
        Me.celdaContacto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaContacto.Name = "celdaContacto"
        Me.celdaContacto.ReadOnly = True
        Me.celdaContacto.Size = New System.Drawing.Size(296, 20)
        Me.celdaContacto.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 158)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Contact"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDireccion.Location = New System.Drawing.Point(52, 109)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(332, 45)
        Me.celdaDireccion.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 109)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Direction"
        '
        'BotonMoneda
        '
        Me.BotonMoneda.Location = New System.Drawing.Point(160, 226)
        Me.BotonMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.BotonMoneda.Name = "BotonMoneda"
        Me.BotonMoneda.Size = New System.Drawing.Size(32, 19)
        Me.BotonMoneda.TabIndex = 9
        Me.BotonMoneda.Text = "..."
        Me.BotonMoneda.UseVisualStyleBackColor = True
        '
        'celdaNombreCliente
        '
        Me.celdaNombreCliente.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNombreCliente.Location = New System.Drawing.Point(52, 80)
        Me.celdaNombreCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNombreCliente.Name = "celdaNombreCliente"
        Me.celdaNombreCliente.ReadOnly = True
        Me.celdaNombreCliente.Size = New System.Drawing.Size(296, 20)
        Me.celdaNombreCliente.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 83)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Name"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(202, 54)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(146, 20)
        Me.dtpFecha.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(156, 54)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNumero.Location = New System.Drawing.Point(52, 52)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(82, 20)
        Me.celdaNumero.TabIndex = 4
        Me.celdaNumero.Text = "-1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 52)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Number"
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(202, 26)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 2
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaAño.Location = New System.Drawing.Point(55, 24)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(80, 20)
        Me.celdaAño.TabIndex = 1
        Me.celdaAño.Text = "2018"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 23)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Year"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.celdaFirmante)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.celdaIdAplicante)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.celdaDireccion2)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.botonAplicante)
        Me.GroupBox2.Controls.Add(Me.celdaAplicante)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.celdaPoliza)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.celdaDocumento)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Location = New System.Drawing.Point(406, 117)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(482, 169)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'celdaFirmante
        '
        Me.celdaFirmante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFirmante.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaFirmante.Location = New System.Drawing.Point(106, 112)
        Me.celdaFirmante.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaFirmante.Multiline = True
        Me.celdaFirmante.Name = "celdaFirmante"
        Me.celdaFirmante.Size = New System.Drawing.Size(366, 40)
        Me.celdaFirmante.TabIndex = 29
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(20, 118)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(82, 13)
        Me.Label19.TabIndex = 28
        Me.Label19.Text = "Signatory Name"
        '
        'celdaIdAplicante
        '
        Me.celdaIdAplicante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdAplicante.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdAplicante.Location = New System.Drawing.Point(373, 38)
        Me.celdaIdAplicante.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdAplicante.Name = "celdaIdAplicante"
        Me.celdaIdAplicante.Size = New System.Drawing.Size(14, 20)
        Me.celdaIdAplicante.TabIndex = 27
        Me.celdaIdAplicante.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(114, 154)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(223, 13)
        Me.Label15.TabIndex = 26
        Me.Label15.Text = "** Leave blank to print from de letter of crédit  "
        '
        'celdaDireccion2
        '
        Me.celdaDireccion2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDireccion2.Location = New System.Drawing.Point(106, 61)
        Me.celdaDireccion2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion2.Multiline = True
        Me.celdaDireccion2.Name = "celdaDireccion2"
        Me.celdaDireccion2.Size = New System.Drawing.Size(366, 45)
        Me.celdaDireccion2.TabIndex = 25
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(46, 67)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 13)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "Direction"
        '
        'botonAplicante
        '
        Me.botonAplicante.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAplicante.Location = New System.Drawing.Point(342, 37)
        Me.botonAplicante.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAplicante.Name = "botonAplicante"
        Me.botonAplicante.Size = New System.Drawing.Size(26, 19)
        Me.botonAplicante.TabIndex = 23
        Me.botonAplicante.Text = "..."
        Me.botonAplicante.UseVisualStyleBackColor = True
        '
        'celdaAplicante
        '
        Me.celdaAplicante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAplicante.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaAplicante.Location = New System.Drawing.Point(106, 38)
        Me.celdaAplicante.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAplicante.Name = "celdaAplicante"
        Me.celdaAplicante.ReadOnly = True
        Me.celdaAplicante.Size = New System.Drawing.Size(233, 20)
        Me.celdaAplicante.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(44, 38)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(51, 13)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Applicant"
        '
        'celdaPoliza
        '
        Me.celdaPoliza.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPoliza.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaPoliza.Location = New System.Drawing.Point(332, 12)
        Me.celdaPoliza.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaPoliza.Name = "celdaPoliza"
        Me.celdaPoliza.Size = New System.Drawing.Size(145, 20)
        Me.celdaPoliza.TabIndex = 7
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(293, 15)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "Policy"
        '
        'celdaDocumento
        '
        Me.celdaDocumento.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDocumento.Location = New System.Drawing.Point(106, 15)
        Me.celdaDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDocumento.Name = "celdaDocumento"
        Me.celdaDocumento.Size = New System.Drawing.Size(184, 20)
        Me.celdaDocumento.TabIndex = 5
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(44, 15)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(56, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Document"
        '
        'gbFactura
        '
        Me.gbFactura.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFactura.Controls.Add(Me.dgFactura)
        Me.gbFactura.Controls.Add(Me.PanelBotones)
        Me.gbFactura.Location = New System.Drawing.Point(406, 2)
        Me.gbFactura.Margin = New System.Windows.Forms.Padding(2)
        Me.gbFactura.Name = "gbFactura"
        Me.gbFactura.Padding = New System.Windows.Forms.Padding(2)
        Me.gbFactura.Size = New System.Drawing.Size(482, 105)
        Me.gbFactura.TabIndex = 1
        Me.gbFactura.TabStop = False
        Me.gbFactura.Text = "Bill"
        '
        'dgFactura
        '
        Me.dgFactura.AllowUserToAddRows = False
        Me.dgFactura.AllowUserToDeleteRows = False
        Me.dgFactura.AllowUserToOrderColumns = True
        Me.dgFactura.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgFactura.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_Tipo, Me.col_anio, Me.col_Numero, Me.col_fecha, Me.colUsuario, Me.col_referencia, Me.colStatus, Me.number})
        Me.dgFactura.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgFactura.Location = New System.Drawing.Point(2, 15)
        Me.dgFactura.Margin = New System.Windows.Forms.Padding(2)
        Me.dgFactura.MultiSelect = False
        Me.dgFactura.Name = "dgFactura"
        Me.dgFactura.ReadOnly = True
        Me.dgFactura.RowTemplate.Height = 24
        Me.dgFactura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFactura.Size = New System.Drawing.Size(436, 88)
        Me.dgFactura.TabIndex = 2
        '
        'col_Tipo
        '
        Me.col_Tipo.HeaderText = "Type"
        Me.col_Tipo.Name = "col_Tipo"
        Me.col_Tipo.ReadOnly = True
        Me.col_Tipo.Visible = False
        Me.col_Tipo.Width = 69
        '
        'col_anio
        '
        Me.col_anio.HeaderText = "Anio"
        Me.col_anio.Name = "col_anio"
        Me.col_anio.ReadOnly = True
        Me.col_anio.Width = 53
        '
        'col_Numero
        '
        Me.col_Numero.HeaderText = "Number"
        Me.col_Numero.Name = "col_Numero"
        Me.col_Numero.ReadOnly = True
        Me.col_Numero.Width = 69
        '
        'col_fecha
        '
        Me.col_fecha.HeaderText = "Date"
        Me.col_fecha.Name = "col_fecha"
        Me.col_fecha.ReadOnly = True
        Me.col_fecha.Width = 55
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        Me.colUsuario.Width = 54
        '
        'col_referencia
        '
        Me.col_referencia.HeaderText = "Reference"
        Me.col_referencia.Name = "col_referencia"
        Me.col_referencia.ReadOnly = True
        Me.col_referencia.Width = 82
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Estado"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Width = 65
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.botonAgregarFactura)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(438, 15)
        Me.PanelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(42, 88)
        Me.PanelBotones.TabIndex = 3
        '
        'botonAgregarFactura
        '
        Me.botonAgregarFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregarFactura.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregarFactura.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarFactura.Location = New System.Drawing.Point(4, 24)
        Me.botonAgregarFactura.Name = "botonAgregarFactura"
        Me.botonAgregarFactura.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregarFactura.TabIndex = 11
        Me.botonAgregarFactura.UseVisualStyleBackColor = False
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(220, 10)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(2)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(54, 45)
        Me.botonImprimir.TabIndex = 5
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = CType(resources.GetObject("botonBuscar.Image"), System.Drawing.Image)
        Me.botonBuscar.Location = New System.Drawing.Point(290, 10)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(59, 43)
        Me.botonBuscar.TabIndex = 24
        Me.botonBuscar.Text = "Look"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseMnemonic = False
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(925, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(925, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'number
        '
        Me.number.HeaderText = "number"
        Me.number.Name = "number"
        Me.number.ReadOnly = True
        Me.number.Visible = False
        Me.number.Width = 67
        '
        'FrmCargoReceipt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(925, 676)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FrmCargoReceipt"
        Me.Text = "FrmCargoReceipt"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTotal.ResumeLayout(False)
        Me.PanelTotal.PerformLayout()
        Me.PanelEncabezado.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.gbFactura.ResumeLayout(False)
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents BotonMoneda As Button
    Friend WithEvents celdaNombreCliente As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents gbFactura As GroupBox
    Friend WithEvents dgFactura As DataGridView
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaidCliente As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaTelefono As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents celdaContacto As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents celdaDireccion2 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents botonAplicante As Button
    Friend WithEvents celdaAplicante As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents celdaPoliza As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents celdaDocumento As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents PanelTotal As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaCantidad As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents celdaObservacion As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents CeldaInfo As TextBox
    Friend WithEvents PanelEncabezado As Panel
    Friend WithEvents Label15 As Label
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colContacto As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents botonContacto As Button
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents botonAgregarFactura As Button
    Friend WithEvents col_Tipo As DataGridViewTextBoxColumn
    Friend WithEvents col_anio As DataGridViewTextBoxColumn
    Friend WithEvents col_Numero As DataGridViewTextBoxColumn
    Friend WithEvents col_fecha As DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As DataGridViewTextBoxColumn
    Friend WithEvents col_referencia As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents celdaIdAplicante As TextBox
    Friend WithEvents celdaFirmante As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents lblInformacion As Label
    Friend WithEvents lblLinea As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents botonImprimir As Button
    Friend WithEvents col_codigo As DataGridViewTextBoxColumn
    Friend WithEvents col_descripcion As DataGridViewTextBoxColumn
    Friend WithEvents colidMedida As DataGridViewTextBoxColumn
    Friend WithEvents colBase As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colDevolucion As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents col_linea As DataGridViewTextBoxColumn
    Friend WithEvents col_Referencia1 As DataGridViewTextBoxColumn
    Friend WithEvents col_Contrato As DataGridViewTextBoxColumn
    Friend WithEvents col_credito As DataGridViewTextBoxColumn
    Friend WithEvents col_envio As DataGridViewTextBoxColumn
    Friend WithEvents col_presentado As DataGridViewTextBoxColumn
    Friend WithEvents col_documento As DataGridViewTextBoxColumn
    Friend WithEvents col_pago As DataGridViewTextBoxColumn
    Friend WithEvents col_FSD As DataGridViewTextBoxColumn
    Friend WithEvents colRefAnio As DataGridViewTextBoxColumn
    Friend WithEvents colRefNum As DataGridViewTextBoxColumn
    Friend WithEvents colRefLine As DataGridViewTextBoxColumn
    Friend WithEvents ref_Canio As DataGridViewTextBoxColumn
    Friend WithEvents ref_CNum As DataGridViewTextBoxColumn
    Friend WithEvents ref_CLin As DataGridViewTextBoxColumn
    Friend WithEvents col_Extra As DataGridViewTextBoxColumn
    Friend WithEvents botonBuscar As Button
    Friend WithEvents number As DataGridViewTextBoxColumn
End Class
