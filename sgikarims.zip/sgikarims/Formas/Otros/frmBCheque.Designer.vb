﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBCheque
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBCheque))
        Me.Visor = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.SuspendLayout()
        '
        'Visor
        '
        Me.Visor.ActiveViewIndex = -1
        Me.Visor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Visor.Cursor = System.Windows.Forms.Cursors.Default
        Me.Visor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Visor.Location = New System.Drawing.Point(0, 0)
        Me.Visor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Visor.Name = "Visor"
        Me.Visor.ShowCloseButton = False
        Me.Visor.ShowGotoPageButton = False
        Me.Visor.ShowGroupTreeButton = False
        Me.Visor.ShowLogo = False
        Me.Visor.ShowPageNavigateButtons = False
        Me.Visor.ShowParameterPanelButton = False
        Me.Visor.Size = New System.Drawing.Size(1045, 690)
        Me.Visor.TabIndex = 0
        Me.Visor.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None
        '
        'frmBCheque
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1045, 690)
        Me.Controls.Add(Me.Visor)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(1061, 728)
        Me.Name = "frmBCheque"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Check Printing"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Visor As CrystalDecisions.Windows.Forms.CrystalReportViewer
End Class
