﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmYarnMovementV
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle20 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle17 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle18 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle19 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumVerdadero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocument = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizacionF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.checkCliente = New System.Windows.Forms.CheckBox()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.botonFiltar = New System.Windows.Forms.Button()
        Me.celdaClienteFiltro = New System.Windows.Forms.TextBox()
        Me.dtpFechaFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.panelDetalle2 = New System.Windows.Forms.Panel()
        Me.panelPie = New System.Windows.Forms.Panel()
        Me.penelDetalle3 = New System.Windows.Forms.Panel()
        Me.celdaObservacion = New System.Windows.Forms.TextBox()
        Me.etiquetaObservacion = New System.Windows.Forms.Label()
        Me.panelInfo = New System.Windows.Forms.Panel()
        Me.etiquetaInfo1 = New System.Windows.Forms.Label()
        Me.etiquetaInfo0 = New System.Windows.Forms.Label()
        Me.celdaInfo = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.gbInfoAdi = New System.Windows.Forms.GroupBox()
        Me.celdaidClase = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonClase = New System.Windows.Forms.Button()
        Me.celdaClase = New System.Windows.Forms.TextBox()
        Me.etiquetaRevision = New System.Windows.Forms.Label()
        Me.celdaRevision = New System.Windows.Forms.TextBox()
        Me.etiquetaCreditoDay = New System.Windows.Forms.Label()
        Me.celdaCreidtDay = New System.Windows.Forms.TextBox()
        Me.celdaIDCliente2 = New System.Windows.Forms.TextBox()
        Me.botonCliente2 = New System.Windows.Forms.Button()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.celdaCliente2 = New System.Windows.Forms.TextBox()
        Me.etiquetaReferencia = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.gbDocumentos = New System.Windows.Forms.GroupBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgDocs = New System.Windows.Forms.DataGridView()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumReal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAdicional = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbDocDatos = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaNum = New System.Windows.Forms.TextBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaTasaCambio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasaCambio = New System.Windows.Forms.Label()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.etiquetaCatalogo = New System.Windows.Forms.Label()
        Me.celdaIDEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.etiquetaEmpresa = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNIt = New System.Windows.Forms.TextBox()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.etiquetaAutorizacion = New System.Windows.Forms.Label()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.colEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDevolucion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaYarn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPago = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colCredito = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContenedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNotas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRevision = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservaciones = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDetalle2.SuspendLayout()
        Me.penelDetalle3.SuspendLayout()
        Me.panelInfo.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        Me.gbInfoAdi.SuspendLayout()
        Me.gbDocumentos.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgDocs, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDocDatos.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.SuspendLayout()
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonInprimir.Location = New System.Drawing.Point(204, 10)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 45)
        Me.botonInprimir.TabIndex = 20
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelLista.Location = New System.Drawing.Point(0, 102)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(796, 141)
        Me.PanelLista.TabIndex = 21
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colYear, Me.colID, Me.colNumVerdadero, Me.colDate, Me.colCliente, Me.colReference, Me.colDocument, Me.colSerieF, Me.colAutorizacionF, Me.colClasificacion})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 81)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(796, 60)
        Me.dgLista.TabIndex = 2
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        '
        'colID
        '
        Me.colID.HeaderText = "Number"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        '
        'colNumVerdadero
        '
        Me.colNumVerdadero.HeaderText = "NumVerdadero"
        Me.colNumVerdadero.Name = "colNumVerdadero"
        Me.colNumVerdadero.ReadOnly = True
        Me.colNumVerdadero.Visible = False
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Customer"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 76
        '
        'colReference
        '
        Me.colReference.HeaderText = "Reference"
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        '
        'colDocument
        '
        Me.colDocument.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDocument.HeaderText = "Document"
        Me.colDocument.Name = "colDocument"
        Me.colDocument.ReadOnly = True
        '
        'colSerieF
        '
        Me.colSerieF.HeaderText = "Serie Fel"
        Me.colSerieF.Name = "colSerieF"
        Me.colSerieF.ReadOnly = True
        '
        'colAutorizacionF
        '
        Me.colAutorizacionF.HeaderText = "Autorizacion Fel"
        Me.colAutorizacionF.Name = "colAutorizacionF"
        Me.colAutorizacionF.ReadOnly = True
        '
        'colClasificacion
        '
        Me.colClasificacion.HeaderText = "Class"
        Me.colClasificacion.Name = "colClasificacion"
        Me.colClasificacion.ReadOnly = True
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.Label24)
        Me.panelFiltro.Controls.Add(Me.checkCliente)
        Me.panelFiltro.Controls.Add(Me.checkFecha)
        Me.panelFiltro.Controls.Add(Me.botonFiltar)
        Me.panelFiltro.Controls.Add(Me.celdaClienteFiltro)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFin)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicio)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(796, 81)
        Me.panelFiltro.TabIndex = 1
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(17, 7)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(56, 13)
        Me.Label24.TabIndex = 6
        Me.Label24.Text = "Refine By;"
        '
        'checkCliente
        '
        Me.checkCliente.AutoSize = True
        Me.checkCliente.Location = New System.Drawing.Point(18, 51)
        Me.checkCliente.Name = "checkCliente"
        Me.checkCliente.Size = New System.Drawing.Size(70, 17)
        Me.checkCliente.TabIndex = 3
        Me.checkCliente.Text = "Customer"
        Me.checkCliente.UseVisualStyleBackColor = True
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(18, 25)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(84, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "Date Range"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'botonFiltar
        '
        Me.botonFiltar.Location = New System.Drawing.Point(314, 25)
        Me.botonFiltar.Name = "botonFiltar"
        Me.botonFiltar.Size = New System.Drawing.Size(71, 29)
        Me.botonFiltar.TabIndex = 5
        Me.botonFiltar.Text = "&Filter"
        Me.botonFiltar.UseVisualStyleBackColor = True
        '
        'celdaClienteFiltro
        '
        Me.celdaClienteFiltro.Location = New System.Drawing.Point(135, 48)
        Me.celdaClienteFiltro.Name = "celdaClienteFiltro"
        Me.celdaClienteFiltro.Size = New System.Drawing.Size(173, 20)
        Me.celdaClienteFiltro.TabIndex = 4
        '
        'dtpFechaFin
        '
        Me.dtpFechaFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFin.Location = New System.Drawing.Point(221, 25)
        Me.dtpFechaFin.Name = "dtpFechaFin"
        Me.dtpFechaFin.Size = New System.Drawing.Size(87, 20)
        Me.dtpFechaFin.TabIndex = 2
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(135, 25)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(80, 20)
        Me.dtpFechaInicio.TabIndex = 1
        '
        'panelDetalle2
        '
        Me.panelDetalle2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle2.Controls.Add(Me.panelPie)
        Me.panelDetalle2.Controls.Add(Me.penelDetalle3)
        Me.panelDetalle2.Location = New System.Drawing.Point(2, 262)
        Me.panelDetalle2.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDetalle2.Name = "panelDetalle2"
        Me.panelDetalle2.Size = New System.Drawing.Size(791, 278)
        Me.panelDetalle2.TabIndex = 23
        '
        'panelPie
        '
        Me.panelPie.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPie.Location = New System.Drawing.Point(0, 264)
        Me.panelPie.Margin = New System.Windows.Forms.Padding(2)
        Me.panelPie.Name = "panelPie"
        Me.panelPie.Size = New System.Drawing.Size(791, 14)
        Me.panelPie.TabIndex = 1
        '
        'penelDetalle3
        '
        Me.penelDetalle3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.penelDetalle3.Controls.Add(Me.celdaObservacion)
        Me.penelDetalle3.Controls.Add(Me.etiquetaObservacion)
        Me.penelDetalle3.Controls.Add(Me.panelInfo)
        Me.penelDetalle3.Controls.Add(Me.etiquetaTotal)
        Me.penelDetalle3.Controls.Add(Me.dgDetalle)
        Me.penelDetalle3.Controls.Add(Me.etiquetaCantidad)
        Me.penelDetalle3.Controls.Add(Me.celdaCantidad)
        Me.penelDetalle3.Controls.Add(Me.celdaTotal)
        Me.penelDetalle3.Location = New System.Drawing.Point(0, 2)
        Me.penelDetalle3.Margin = New System.Windows.Forms.Padding(2)
        Me.penelDetalle3.Name = "penelDetalle3"
        Me.penelDetalle3.Size = New System.Drawing.Size(791, 336)
        Me.penelDetalle3.TabIndex = 0
        '
        'celdaObservacion
        '
        Me.celdaObservacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservacion.Location = New System.Drawing.Point(80, 233)
        Me.celdaObservacion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaObservacion.Name = "celdaObservacion"
        Me.celdaObservacion.Size = New System.Drawing.Size(697, 20)
        Me.celdaObservacion.TabIndex = 31
        '
        'etiquetaObservacion
        '
        Me.etiquetaObservacion.AutoSize = True
        Me.etiquetaObservacion.Location = New System.Drawing.Point(14, 233)
        Me.etiquetaObservacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaObservacion.Name = "etiquetaObservacion"
        Me.etiquetaObservacion.Size = New System.Drawing.Size(64, 13)
        Me.etiquetaObservacion.TabIndex = 30
        Me.etiquetaObservacion.Text = "Observation"
        '
        'panelInfo
        '
        Me.panelInfo.BackColor = System.Drawing.SystemColors.Control
        Me.panelInfo.Controls.Add(Me.etiquetaInfo1)
        Me.panelInfo.Controls.Add(Me.etiquetaInfo0)
        Me.panelInfo.Controls.Add(Me.celdaInfo)
        Me.panelInfo.Location = New System.Drawing.Point(0, 148)
        Me.panelInfo.Margin = New System.Windows.Forms.Padding(2)
        Me.panelInfo.Name = "panelInfo"
        Me.panelInfo.Size = New System.Drawing.Size(568, 70)
        Me.panelInfo.TabIndex = 2
        '
        'etiquetaInfo1
        '
        Me.etiquetaInfo1.AutoSize = True
        Me.etiquetaInfo1.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaInfo1.Location = New System.Drawing.Point(68, 10)
        Me.etiquetaInfo1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaInfo1.Name = "etiquetaInfo1"
        Me.etiquetaInfo1.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaInfo1.TabIndex = 2
        Me.etiquetaInfo1.Text = "Label1"
        '
        'etiquetaInfo0
        '
        Me.etiquetaInfo0.AutoSize = True
        Me.etiquetaInfo0.BackColor = System.Drawing.SystemColors.Info
        Me.etiquetaInfo0.Location = New System.Drawing.Point(6, 10)
        Me.etiquetaInfo0.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaInfo0.Name = "etiquetaInfo0"
        Me.etiquetaInfo0.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaInfo0.TabIndex = 1
        Me.etiquetaInfo0.Text = "Label1"
        '
        'celdaInfo
        '
        Me.celdaInfo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.celdaInfo.Location = New System.Drawing.Point(0, 0)
        Me.celdaInfo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaInfo.Multiline = True
        Me.celdaInfo.Name = "celdaInfo"
        Me.celdaInfo.Size = New System.Drawing.Size(568, 70)
        Me.celdaInfo.TabIndex = 0
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(704, 150)
        Me.etiquetaTotal.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaTotal.TabIndex = 29
        Me.etiquetaTotal.Text = "Total"
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEmpresa, Me.colTipo, Me.colAnio, Me.colNum, Me.colCodigo, Me.colDescripcion, Me.colMedida, Me.colUnidad, Me.colPrecio, Me.colCantidad, Me.colDevolucion, Me.colTotal, Me.colLinea, Me.colLineaYarn, Me.colRef, Me.colPago, Me.colCredito, Me.colPedido, Me.colContenedor, Me.colNotas, Me.colContrato, Me.colRevision, Me.colObservaciones})
        Me.dgDetalle.EnableHeadersVisualStyles = False
        Me.dgDetalle.Location = New System.Drawing.Point(-2, -5)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle20.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle20
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.Size = New System.Drawing.Size(791, 148)
        Me.dgDetalle.TabIndex = 1
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.Location = New System.Drawing.Point(620, 150)
        Me.etiquetaCantidad.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(46, 13)
        Me.etiquetaCantidad.TabIndex = 28
        Me.etiquetaCantidad.Text = "Quantity"
        '
        'celdaCantidad
        '
        Me.celdaCantidad.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCantidad.Location = New System.Drawing.Point(619, 167)
        Me.celdaCantidad.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(76, 20)
        Me.celdaCantidad.TabIndex = 26
        '
        'celdaTotal
        '
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Location = New System.Drawing.Point(706, 167)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(76, 20)
        Me.celdaTotal.TabIndex = 27
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.gbInfoAdi)
        Me.panelDetalle.Controls.Add(Me.gbDocumentos)
        Me.panelDetalle.Controls.Add(Me.gbDocDatos)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDetalle.Location = New System.Drawing.Point(0, 0)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(796, 258)
        Me.panelDetalle.TabIndex = 22
        '
        'gbInfoAdi
        '
        Me.gbInfoAdi.Controls.Add(Me.celdaidClase)
        Me.gbInfoAdi.Controls.Add(Me.Label2)
        Me.gbInfoAdi.Controls.Add(Me.botonClase)
        Me.gbInfoAdi.Controls.Add(Me.celdaClase)
        Me.gbInfoAdi.Controls.Add(Me.etiquetaRevision)
        Me.gbInfoAdi.Controls.Add(Me.celdaRevision)
        Me.gbInfoAdi.Controls.Add(Me.etiquetaCreditoDay)
        Me.gbInfoAdi.Controls.Add(Me.celdaCreidtDay)
        Me.gbInfoAdi.Controls.Add(Me.celdaIDCliente2)
        Me.gbInfoAdi.Controls.Add(Me.botonCliente2)
        Me.gbInfoAdi.Controls.Add(Me.etiquetaCliente)
        Me.gbInfoAdi.Controls.Add(Me.celdaCliente2)
        Me.gbInfoAdi.Controls.Add(Me.etiquetaReferencia)
        Me.gbInfoAdi.Controls.Add(Me.celdaReferencia)
        Me.gbInfoAdi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbInfoAdi.Location = New System.Drawing.Point(406, 125)
        Me.gbInfoAdi.Margin = New System.Windows.Forms.Padding(2)
        Me.gbInfoAdi.Name = "gbInfoAdi"
        Me.gbInfoAdi.Padding = New System.Windows.Forms.Padding(2)
        Me.gbInfoAdi.Size = New System.Drawing.Size(390, 133)
        Me.gbInfoAdi.TabIndex = 23
        Me.gbInfoAdi.TabStop = False
        Me.gbInfoAdi.Text = "Additional Information"
        '
        'celdaidClase
        '
        Me.celdaidClase.Location = New System.Drawing.Point(356, 69)
        Me.celdaidClase.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidClase.Name = "celdaidClase"
        Me.celdaidClase.Size = New System.Drawing.Size(23, 20)
        Me.celdaidClase.TabIndex = 39
        Me.celdaidClase.Text = "-1"
        Me.celdaidClase.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 104)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Class"
        '
        'botonClase
        '
        Me.botonClase.Location = New System.Drawing.Point(350, 99)
        Me.botonClase.Margin = New System.Windows.Forms.Padding(2)
        Me.botonClase.Name = "botonClase"
        Me.botonClase.Size = New System.Drawing.Size(22, 20)
        Me.botonClase.TabIndex = 37
        Me.botonClase.Text = "..."
        Me.botonClase.UseVisualStyleBackColor = True
        '
        'celdaClase
        '
        Me.celdaClase.Location = New System.Drawing.Point(78, 102)
        Me.celdaClase.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaClase.Name = "celdaClase"
        Me.celdaClase.ReadOnly = True
        Me.celdaClase.Size = New System.Drawing.Size(266, 20)
        Me.celdaClase.TabIndex = 36
        '
        'etiquetaRevision
        '
        Me.etiquetaRevision.AutoSize = True
        Me.etiquetaRevision.Location = New System.Drawing.Point(196, 77)
        Me.etiquetaRevision.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRevision.Name = "etiquetaRevision"
        Me.etiquetaRevision.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaRevision.TabIndex = 34
        Me.etiquetaRevision.Text = "Review"
        '
        'celdaRevision
        '
        Me.celdaRevision.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRevision.Location = New System.Drawing.Point(240, 75)
        Me.celdaRevision.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRevision.Name = "celdaRevision"
        Me.celdaRevision.Size = New System.Drawing.Size(104, 20)
        Me.celdaRevision.TabIndex = 35
        '
        'etiquetaCreditoDay
        '
        Me.etiquetaCreditoDay.AutoSize = True
        Me.etiquetaCreditoDay.Location = New System.Drawing.Point(4, 77)
        Me.etiquetaCreditoDay.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCreditoDay.Name = "etiquetaCreditoDay"
        Me.etiquetaCreditoDay.Size = New System.Drawing.Size(67, 13)
        Me.etiquetaCreditoDay.TabIndex = 32
        Me.etiquetaCreditoDay.Text = "Credit (Days)"
        '
        'celdaCreidtDay
        '
        Me.celdaCreidtDay.Location = New System.Drawing.Point(83, 75)
        Me.celdaCreidtDay.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCreidtDay.Name = "celdaCreidtDay"
        Me.celdaCreidtDay.Size = New System.Drawing.Size(92, 20)
        Me.celdaCreidtDay.TabIndex = 33
        Me.celdaCreidtDay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaIDCliente2
        '
        Me.celdaIDCliente2.Location = New System.Drawing.Point(356, 22)
        Me.celdaIDCliente2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIDCliente2.Name = "celdaIDCliente2"
        Me.celdaIDCliente2.Size = New System.Drawing.Size(23, 20)
        Me.celdaIDCliente2.TabIndex = 31
        Me.celdaIDCliente2.Text = "-1"
        Me.celdaIDCliente2.Visible = False
        '
        'botonCliente2
        '
        Me.botonCliente2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCliente2.Location = New System.Drawing.Point(350, 46)
        Me.botonCliente2.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCliente2.Name = "botonCliente2"
        Me.botonCliente2.Size = New System.Drawing.Size(23, 19)
        Me.botonCliente2.TabIndex = 30
        Me.botonCliente2.Text = "..."
        Me.botonCliente2.UseVisualStyleBackColor = True
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(4, 48)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 11
        Me.etiquetaCliente.Text = "Client"
        '
        'celdaCliente2
        '
        Me.celdaCliente2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCliente2.Location = New System.Drawing.Point(83, 46)
        Me.celdaCliente2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCliente2.Name = "celdaCliente2"
        Me.celdaCliente2.Size = New System.Drawing.Size(260, 20)
        Me.celdaCliente2.TabIndex = 12
        '
        'etiquetaReferencia
        '
        Me.etiquetaReferencia.AutoSize = True
        Me.etiquetaReferencia.Location = New System.Drawing.Point(4, 27)
        Me.etiquetaReferencia.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaReferencia.Name = "etiquetaReferencia"
        Me.etiquetaReferencia.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaReferencia.TabIndex = 9
        Me.etiquetaReferencia.Text = "Reference"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaReferencia.BackColor = System.Drawing.SystemColors.Info
        Me.celdaReferencia.Location = New System.Drawing.Point(83, 24)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(152, 20)
        Me.celdaReferencia.TabIndex = 10
        '
        'gbDocumentos
        '
        Me.gbDocumentos.Controls.Add(Me.Panel1)
        Me.gbDocumentos.Dock = System.Windows.Forms.DockStyle.Top
        Me.gbDocumentos.Location = New System.Drawing.Point(406, 0)
        Me.gbDocumentos.Margin = New System.Windows.Forms.Padding(2)
        Me.gbDocumentos.Name = "gbDocumentos"
        Me.gbDocumentos.Padding = New System.Windows.Forms.Padding(2)
        Me.gbDocumentos.Size = New System.Drawing.Size(390, 125)
        Me.gbDocumentos.TabIndex = 20
        Me.gbDocumentos.TabStop = False
        Me.gbDocumentos.Text = "Documents"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.dgDocs)
        Me.Panel1.Location = New System.Drawing.Point(2, 15)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(379, 108)
        Me.Panel1.TabIndex = 0
        '
        'dgDocs
        '
        Me.dgDocs.AllowUserToAddRows = False
        Me.dgDocs.AllowUserToDeleteRows = False
        Me.dgDocs.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocs.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colNumero, Me.colNumReal, Me.colFecha, Me.colUsuario, Me.colReferencia, Me.colAdicional})
        Me.dgDocs.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocs.Location = New System.Drawing.Point(0, 0)
        Me.dgDocs.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDocs.Name = "dgDocs"
        Me.dgDocs.RowTemplate.Height = 24
        Me.dgDocs.Size = New System.Drawing.Size(379, 108)
        Me.dgDocs.TabIndex = 0
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        '
        'colNumReal
        '
        Me.colNumReal.HeaderText = "NumReal"
        Me.colNumReal.Name = "colNumReal"
        Me.colNumReal.Visible = False
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        '
        'colAdicional
        '
        Me.colAdicional.HeaderText = "Adicional"
        Me.colAdicional.Name = "colAdicional"
        Me.colAdicional.Visible = False
        '
        'gbDocDatos
        '
        Me.gbDocDatos.Controls.Add(Me.Label1)
        Me.gbDocDatos.Controls.Add(Me.celdaNum)
        Me.gbDocDatos.Controls.Add(Me.celdaIDMoneda)
        Me.gbDocDatos.Controls.Add(Me.botonMoneda)
        Me.gbDocDatos.Controls.Add(Me.celdaIDCliente)
        Me.gbDocDatos.Controls.Add(Me.botonCliente)
        Me.gbDocDatos.Controls.Add(Me.celdaTasaCambio)
        Me.gbDocDatos.Controls.Add(Me.etiquetaTasaCambio)
        Me.gbDocDatos.Controls.Add(Me.celdaUsuario)
        Me.gbDocDatos.Controls.Add(Me.etiquetaUsuario)
        Me.gbDocDatos.Controls.Add(Me.celdaCatalogo)
        Me.gbDocDatos.Controls.Add(Me.etiquetaCatalogo)
        Me.gbDocDatos.Controls.Add(Me.celdaIDEmpresa)
        Me.gbDocDatos.Controls.Add(Me.celdaNombre)
        Me.gbDocDatos.Controls.Add(Me.etiquetaEmpresa)
        Me.gbDocDatos.Controls.Add(Me.etiquetaAño)
        Me.gbDocDatos.Controls.Add(Me.checkActivo)
        Me.gbDocDatos.Controls.Add(Me.etiquetaNumero)
        Me.gbDocDatos.Controls.Add(Me.dtpFecha)
        Me.gbDocDatos.Controls.Add(Me.etiquetaNombre)
        Me.gbDocDatos.Controls.Add(Me.etiquetaFecha)
        Me.gbDocDatos.Controls.Add(Me.etiquetaDireccion)
        Me.gbDocDatos.Controls.Add(Me.celdaMoneda)
        Me.gbDocDatos.Controls.Add(Me.celdaNIt)
        Me.gbDocDatos.Controls.Add(Me.etiquetaNIT)
        Me.gbDocDatos.Controls.Add(Me.etiquetaMoneda)
        Me.gbDocDatos.Controls.Add(Me.celdaDireccion)
        Me.gbDocDatos.Controls.Add(Me.celdaAño)
        Me.gbDocDatos.Controls.Add(Me.celdaNumero)
        Me.gbDocDatos.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbDocDatos.Location = New System.Drawing.Point(0, 0)
        Me.gbDocDatos.Margin = New System.Windows.Forms.Padding(2)
        Me.gbDocDatos.Name = "gbDocDatos"
        Me.gbDocDatos.Padding = New System.Windows.Forms.Padding(2)
        Me.gbDocDatos.Size = New System.Drawing.Size(406, 258)
        Me.gbDocDatos.TabIndex = 19
        Me.gbDocDatos.TabStop = False
        Me.gbDocDatos.Text = "Document Data"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(248, 171)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Num"
        Me.Label1.Visible = False
        '
        'celdaNum
        '
        Me.celdaNum.Location = New System.Drawing.Point(280, 167)
        Me.celdaNum.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNum.Name = "celdaNum"
        Me.celdaNum.Size = New System.Drawing.Size(76, 20)
        Me.celdaNum.TabIndex = 31
        Me.celdaNum.Visible = False
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(190, 210)
        Me.celdaIDMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(23, 20)
        Me.celdaIDMoneda.TabIndex = 29
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(163, 205)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(23, 19)
        Me.botonMoneda.TabIndex = 28
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(323, 95)
        Me.celdaIDCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(23, 20)
        Me.celdaIDCliente.TabIndex = 27
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(296, 90)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(23, 19)
        Me.botonCliente.TabIndex = 26
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaTasaCambio
        '
        Me.celdaTasaCambio.Location = New System.Drawing.Point(316, 205)
        Me.celdaTasaCambio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTasaCambio.Name = "celdaTasaCambio"
        Me.celdaTasaCambio.Size = New System.Drawing.Size(76, 20)
        Me.celdaTasaCambio.TabIndex = 25
        '
        'etiquetaTasaCambio
        '
        Me.etiquetaTasaCambio.AutoSize = True
        Me.etiquetaTasaCambio.Location = New System.Drawing.Point(233, 207)
        Me.etiquetaTasaCambio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTasaCambio.Name = "etiquetaTasaCambio"
        Me.etiquetaTasaCambio.Size = New System.Drawing.Size(81, 13)
        Me.etiquetaTasaCambio.TabIndex = 24
        Me.etiquetaTasaCambio.Text = "Exchange Rate"
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(380, 79)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(23, 20)
        Me.celdaUsuario.TabIndex = 23
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(327, 79)
        Me.etiquetaUsuario.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaUsuario.TabIndex = 22
        Me.etiquetaUsuario.Text = "Usuario"
        Me.etiquetaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(380, 50)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(23, 20)
        Me.celdaCatalogo.TabIndex = 21
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'etiquetaCatalogo
        '
        Me.etiquetaCatalogo.AutoSize = True
        Me.etiquetaCatalogo.Location = New System.Drawing.Point(327, 50)
        Me.etiquetaCatalogo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCatalogo.Name = "etiquetaCatalogo"
        Me.etiquetaCatalogo.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaCatalogo.TabIndex = 20
        Me.etiquetaCatalogo.Text = "Catalogo"
        Me.etiquetaCatalogo.Visible = False
        '
        'celdaIDEmpresa
        '
        Me.celdaIDEmpresa.Location = New System.Drawing.Point(380, 22)
        Me.celdaIDEmpresa.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIDEmpresa.Name = "celdaIDEmpresa"
        Me.celdaIDEmpresa.Size = New System.Drawing.Size(23, 20)
        Me.celdaIDEmpresa.TabIndex = 19
        Me.celdaIDEmpresa.Text = "-1"
        Me.celdaIDEmpresa.Visible = False
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(83, 90)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(209, 20)
        Me.celdaNombre.TabIndex = 10
        '
        'etiquetaEmpresa
        '
        Me.etiquetaEmpresa.AutoSize = True
        Me.etiquetaEmpresa.Location = New System.Drawing.Point(327, 22)
        Me.etiquetaEmpresa.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaEmpresa.Name = "etiquetaEmpresa"
        Me.etiquetaEmpresa.Size = New System.Drawing.Size(48, 13)
        Me.etiquetaEmpresa.TabIndex = 18
        Me.etiquetaEmpresa.Text = "Empresa"
        Me.etiquetaEmpresa.Visible = False
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(15, 35)
        Me.etiquetaAño.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(200, 32)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 17
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(15, 61)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(236, 58)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(85, 20)
        Me.dtpFecha.TabIndex = 16
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(15, 90)
        Me.etiquetaNombre.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaNombre.TabIndex = 2
        Me.etiquetaNombre.Text = "Name"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(197, 61)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaFecha.TabIndex = 15
        Me.etiquetaFecha.Text = "Name"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(15, 123)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(83, 205)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 20)
        Me.celdaMoneda.TabIndex = 14
        '
        'celdaNIt
        '
        Me.celdaNIt.Location = New System.Drawing.Point(83, 168)
        Me.celdaNIt.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNIt.Name = "celdaNIt"
        Me.celdaNIt.Size = New System.Drawing.Size(138, 20)
        Me.celdaNIt.TabIndex = 13
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(15, 171)
        Me.etiquetaNIT.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 6
        Me.etiquetaNIT.Text = "NIT"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(14, 207)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 7
        Me.etiquetaMoneda.Text = "Currency"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(83, 120)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(237, 33)
        Me.celdaDireccion.TabIndex = 11
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(83, 32)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(76, 20)
        Me.celdaAño.TabIndex = 8
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(83, 58)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(76, 20)
        Me.celdaNumero.TabIndex = 9
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelDetalle2)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDocumento.Location = New System.Drawing.Point(0, 243)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(796, 544)
        Me.panelDocumento.TabIndex = 25
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonBuscar.Location = New System.Drawing.Point(280, 12)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.Size = New System.Drawing.Size(65, 42)
        Me.botonBuscar.TabIndex = 27
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(796, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(796, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'etiquetaAutorizacion
        '
        Me.etiquetaAutorizacion.AutoSize = True
        Me.etiquetaAutorizacion.Location = New System.Drawing.Point(316, 76)
        Me.etiquetaAutorizacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizacion.Name = "etiquetaAutorizacion"
        Me.etiquetaAutorizacion.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaAutorizacion.TabIndex = 32
        Me.etiquetaAutorizacion.Text = "Label4"
        Me.etiquetaAutorizacion.Visible = False
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(253, 76)
        Me.etiquetaSerie.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaSerie.TabIndex = 31
        Me.etiquetaSerie.Text = "Label4"
        '
        'colEmpresa
        '
        Me.colEmpresa.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption
        Me.colEmpresa.DefaultCellStyle = DataGridViewCellStyle2
        Me.colEmpresa.HeaderText = "Empresa"
        Me.colEmpresa.Name = "colEmpresa"
        Me.colEmpresa.ReadOnly = True
        Me.colEmpresa.Visible = False
        Me.colEmpresa.Width = 73
        '
        'colTipo
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colTipo.DefaultCellStyle = DataGridViewCellStyle3
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Visible = False
        Me.colTipo.Width = 53
        '
        'colAnio
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.colAnio.DefaultCellStyle = DataGridViewCellStyle4
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 53
        '
        'colNum
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.colNum.DefaultCellStyle = DataGridViewCellStyle5
        Me.colNum.HeaderText = "Numero"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        Me.colNum.Visible = False
        Me.colNum.Width = 69
        '
        'colCodigo
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colCodigo.DefaultCellStyle = DataGridViewCellStyle6
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 57
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colDescripcion.DefaultCellStyle = DataGridViewCellStyle7
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colMedida
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colMedida.DefaultCellStyle = DataGridViewCellStyle8
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unit"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        Me.colUnidad.Visible = False
        Me.colUnidad.Width = 51
        '
        'colPrecio
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colPrecio.DefaultCellStyle = DataGridViewCellStyle9
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colCantidad.DefaultCellStyle = DataGridViewCellStyle10
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.Width = 71
        '
        'colDevolucion
        '
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colDevolucion.DefaultCellStyle = DataGridViewCellStyle11
        Me.colDevolucion.HeaderText = "Return"
        Me.colDevolucion.Name = "colDevolucion"
        Me.colDevolucion.ReadOnly = True
        Me.colDevolucion.Width = 64
        '
        'colTotal
        '
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight
        DataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colTotal.DefaultCellStyle = DataGridViewCellStyle12
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colLinea
        '
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colLinea.DefaultCellStyle = DataGridViewCellStyle13
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 58
        '
        'colLineaYarn
        '
        Me.colLineaYarn.HeaderText = "LineaYarn"
        Me.colLineaYarn.Name = "colLineaYarn"
        Me.colLineaYarn.ReadOnly = True
        Me.colLineaYarn.Visible = False
        Me.colLineaYarn.Width = 80
        '
        'colRef
        '
        Me.colRef.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.colRef.DefaultCellStyle = DataGridViewCellStyle14
        Me.colRef.HeaderText = "Reference"
        Me.colRef.Name = "colRef"
        Me.colRef.ReadOnly = True
        Me.colRef.Width = 82
        '
        'colPago
        '
        Me.colPago.HeaderText = "Way To Pay*"
        Me.colPago.Name = "colPago"
        Me.colPago.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colPago.Width = 76
        '
        'colCredito
        '
        Me.colCredito.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colCredito.DefaultCellStyle = DataGridViewCellStyle15
        Me.colCredito.HeaderText = "Letter Of Credit"
        Me.colCredito.Name = "colCredito"
        Me.colCredito.Width = 95
        '
        'colPedido
        '
        Me.colPedido.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colPedido.DefaultCellStyle = DataGridViewCellStyle16
        Me.colPedido.HeaderText = "Order"
        Me.colPedido.Name = "colPedido"
        Me.colPedido.Width = 58
        '
        'colContenedor
        '
        Me.colContenedor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colContenedor.DefaultCellStyle = DataGridViewCellStyle17
        Me.colContenedor.HeaderText = "Container"
        Me.colContenedor.Name = "colContenedor"
        Me.colContenedor.Width = 77
        '
        'colNotas
        '
        Me.colNotas.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colNotas.DefaultCellStyle = DataGridViewCellStyle18
        Me.colNotas.HeaderText = "Notes and Comments"
        Me.colNotas.Name = "colNotas"
        Me.colNotas.Width = 122
        '
        'colContrato
        '
        Me.colContrato.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter
        Me.colContrato.DefaultCellStyle = DataGridViewCellStyle19
        Me.colContrato.HeaderText = "Contrato"
        Me.colContrato.Name = "colContrato"
        Me.colContrato.ReadOnly = True
        Me.colContrato.Visible = False
        Me.colContrato.Width = 72
        '
        'colRevision
        '
        Me.colRevision.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colRevision.HeaderText = "Revision"
        Me.colRevision.Name = "colRevision"
        Me.colRevision.ReadOnly = True
        Me.colRevision.Visible = False
        Me.colRevision.Width = 73
        '
        'colObservaciones
        '
        Me.colObservaciones.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colObservaciones.HeaderText = "Observations"
        Me.colObservaciones.Name = "colObservaciones"
        Me.colObservaciones.Width = 94
        '
        'frmYarnMovementV
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(796, 704)
        Me.Controls.Add(Me.etiquetaAutorizacion)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.etiquetaSerie)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmYarnMovementV"
        Me.Text = "Yarn Movement Requisition (View)"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDetalle2.ResumeLayout(False)
        Me.penelDetalle3.ResumeLayout(False)
        Me.penelDetalle3.PerformLayout()
        Me.panelInfo.ResumeLayout(False)
        Me.panelInfo.PerformLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        Me.gbInfoAdi.ResumeLayout(False)
        Me.gbInfoAdi.PerformLayout()
        Me.gbDocumentos.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgDocs, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDocDatos.ResumeLayout(False)
        Me.gbDocDatos.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
    Friend WithEvents PanelLista As System.Windows.Forms.Panel
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents checkCliente As System.Windows.Forms.CheckBox
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents botonFiltar As System.Windows.Forms.Button
    Friend WithEvents celdaClienteFiltro As System.Windows.Forms.TextBox
    Friend WithEvents dtpFechaFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpFechaInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelDetalle2 As System.Windows.Forms.Panel
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents etiquetaCantidad As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents celdaCantidad As System.Windows.Forms.TextBox
    Friend WithEvents panelInfo As System.Windows.Forms.Panel
    Friend WithEvents celdaInfo As System.Windows.Forms.TextBox
    Friend WithEvents panelPie As System.Windows.Forms.Panel
    Friend WithEvents penelDetalle3 As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents gbInfoAdi As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaCreditoDay As System.Windows.Forms.Label
    Friend WithEvents celdaCreidtDay As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCliente2 As System.Windows.Forms.TextBox
    Friend WithEvents botonCliente2 As System.Windows.Forms.Button
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents celdaCliente2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaReferencia As System.Windows.Forms.Label
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents gbDocumentos As System.Windows.Forms.GroupBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dgDocs As System.Windows.Forms.DataGridView
    Friend WithEvents gbDocDatos As System.Windows.Forms.GroupBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaIDCliente As System.Windows.Forms.TextBox
    Friend WithEvents botonCliente As System.Windows.Forms.Button
    Friend WithEvents celdaTasaCambio As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasaCambio As System.Windows.Forms.Label
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaUsuario As System.Windows.Forms.Label
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCatalogo As System.Windows.Forms.Label
    Friend WithEvents celdaIDEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents celdaNombre As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaEmpresa As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaNombre As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIt As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents etiquetaInfo1 As System.Windows.Forms.Label
    Friend WithEvents etiquetaInfo0 As System.Windows.Forms.Label
    Friend WithEvents etiquetaRevision As System.Windows.Forms.Label
    Friend WithEvents celdaRevision As System.Windows.Forms.TextBox
    Friend WithEvents celdaObservacion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaObservacion As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaNum As System.Windows.Forms.TextBox
    Friend WithEvents colAño As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumReal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAdicional As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents celdaidClase As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents botonClase As Button
    Friend WithEvents celdaClase As TextBox
    Friend WithEvents etiquetaAutorizacion As Label
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents colYear As DataGridViewTextBoxColumn
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colNumVerdadero As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colReference As DataGridViewTextBoxColumn
    Friend WithEvents colDocument As DataGridViewTextBoxColumn
    Friend WithEvents colSerieF As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizacionF As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacion As DataGridViewTextBoxColumn
    Friend WithEvents colEmpresa As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colDevolucion As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colLineaYarn As DataGridViewTextBoxColumn
    Friend WithEvents colRef As DataGridViewTextBoxColumn
    Friend WithEvents colPago As DataGridViewButtonColumn
    Friend WithEvents colCredito As DataGridViewTextBoxColumn
    Friend WithEvents colPedido As DataGridViewTextBoxColumn
    Friend WithEvents colContenedor As DataGridViewTextBoxColumn
    Friend WithEvents colNotas As DataGridViewTextBoxColumn
    Friend WithEvents colContrato As DataGridViewTextBoxColumn
    Friend WithEvents colRevision As DataGridViewTextBoxColumn
    Friend WithEvents colObservaciones As DataGridViewTextBoxColumn
End Class
