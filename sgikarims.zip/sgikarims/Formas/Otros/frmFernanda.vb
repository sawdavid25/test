﻿Public Class frmFernanda

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLLista() As String
        Dim strsql As String = STR_VACIO
        strsql = "SELECT h.HDoc_Doc_Num Correlativo, h.HDoc_Doc_Ano Ciclo, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom,"
        strsql &= "  IFNULL((  "
        strsql &= "     SELECT SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET)"
        strsql &= "         FROM Dcmtos_DTL d"
        strsql &= "     WHERE d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Num = h.HDoc_Doc_Num),0) Total"
        strsql &= "  FROM Dcmtos_HDR h"
        strsql &= " Where  h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat= {CAT_ORD} "
        If checkFechas.Checked = True Then
            strsql &= " AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}' "
            strsql = Replace(strsql, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fin}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        End If
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{CAT_ORD}", CAT_ORD)

        Return strsql
    End Function

    Private Sub reset()
        celdaNoOrden.Text = NO_FILA
        celdaAño.Text = NO_FILA
        celdaTotal.Text = NO_FILA
        celdaProveedor.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaTasa.Text = NO_FILA
        celdaCentroCosto.Text = NO_FILA
        celdaObservaciones.Text = STR_VACIO
        dgDetalle.Rows.Clear()

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Ordenes de Compra")
            'Cargar Datos
            cfun.CargarLista(dgLista, SQLLista, False)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = ""
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

#End Region

    Private Sub frmFernanda_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmFernanda_load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFinal.Value = Today
        dtpInicio.Value = dtpFinal.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar

        frm.Titulo = "Currency"
        frm.FiltroText = "Enter the Currency Symbol to Filter"
        frm.Campos = " cat_num ID, cat_clave SYmbol"
        frm.Tabla = " Catalogos"
        frm.Condicion = " cat_clase = 'Monedas'"
        frm.Limite = 20
        frm.Ordenamiento = "cat_num "
        frm.Filtro = "cat_clave "
        frm.ShowDialog(Me)

        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            celdaIDMoneda.Text = frm.LLave
            celdaMoneda.Text = frm.Dato
        End If

    End Sub

    Private Sub botonCentroCostos_Click(sender As Object, e As EventArgs) Handles botonCentroCostos.Click

        Dim frm As New frmSeleccionar
        Dim cfun As New clsFunciones
        Try
            frm.Titulo = "Cost Center"
            frm.FiltroText = " Enter the Name of Cost Center to filter"
            frm.Campos = " cost_num ID, cost_nombre Name"
            frm.Tabla = cfun.ContaEmpresa & ".costos "
            frm.Condicion = "cost_num >=0"
            frm.Limite = 20
            frm.Ordenamiento = " cost_nombre"
            frm.Filtro = "cost_nombre"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaNumCentroCostos.Text = frm.LLave
                celdaCentroCosto.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonProveedor_Click_1(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar

        'Datospara mostrar en pantalla
        frm.Titulo = "Providers"
        frm.FiltroText = "Enter the Name to Filter Supplier"

        'Datos de Base para Llenar Grid
        frm.Campos = " pro_codigo Code, pro_proveedor Provider,pro_direccion Direction "
        frm.Tabla = "Proveedores"
        frm.Condicion = "pro_codigo >=0"
        frm.Limite = 20
        frm.Ordenamiento = "pro_codigo"
        frm.Filtro = "pro_proveedor"

        'Mostrar formulario
        frm.ShowDialog(Me)

        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDProveedor.Text = frm.LLave
            celdaProveedor.Text = frm.Dato
            celdaDireccion.Text = frm.Dato2

        End If
    End Sub

    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        MostrarLista()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim CReportes As New clsReportes

        CReportes.CommercialInvoice()
    End Sub
End Class