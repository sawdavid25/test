﻿Public Class frmNPolizasContables

#Region "Miembros"

    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones

    Dim logEx As Boolean

    Public intTipo As String = STR_VACIO
    Public intCiclo As String = STR_VACIO
    Public intNumero As String = STR_VACIO
    Public intModo As String = STR_VACIO
    Public intPoliza As String = STR_VACIO
    Public intEjercicio As String = STR_VACIO

    Private dblDebeTotal As Double
    Private dblHaberTotal As Double
    'Variables
    'Private intEjercicio As Integer
    Private logNuevo As Boolean
    Private Const STR_DEBE As String = "C"
    Private Const STR_HABER As String = "A"

#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property Existe As Boolean
        Get
            Return logEx
        End Get
        Set(value As Boolean)
            logEx = value
        End Set
    End Property

    Public Property Tipo As Integer
        Get
            Return intTipo
        End Get
        Set(value As Integer)
            intTipo = value
        End Set
    End Property

    Public Property Ciclo As Integer
        Get
            Return intCiclo
        End Get
        Set(value As Integer)
            intCiclo = value
        End Set
    End Property

    Public Property Numero As Integer
        Get
            Return intNumero
        End Get
        Set(value As Integer)
            intNumero = value
        End Set
    End Property

    Public Property Modo As Integer
        Get
            Return intModo
        End Get
        Set(value As Integer)
            intModo = value
        End Set
    End Property

    Public Property Poliza As Integer
        Get
            Return intPoliza
        End Get
        Set(value As Integer)
            intPoliza = value
        End Set
    End Property
    Public Property Ejercicio As Integer
        Get
            Return intEjercicio
        End Get
        Set(value As Integer)
            intEjercicio = value
        End Set
    End Property

#End Region

#Region "Procedimientos"

    Private Sub Accessos(ByVal Optional strKey As String = "frmPolizasConta")
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            Encabezado1.botonCerrar.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
            Encabezado1.botonCerrar.Enabled = True
        End If
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Clientes")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlistaPrincipal(), False)
            queryListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                ' Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                'Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    'Query que carga Lista Principal
    Private Function SQLlistaPrincipal() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT p.poliza Numero, t.nombre_corto Tipo, ifnull(p.concepto,'N/A') Concepto, p.fecha Fecha, p.modo Modo, p.revisado Estado, IFNULL(d.HDoc_Doc_Num, 0) Documento"
        strsql &= "  FROM {base}.polizas p"
        strsql &= "   INNER JOIN {base}.tipo_poliza t ON t.tipo_poliza = p.tipo"
        strsql &= "     LEFT JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = {empresa} AND d.HDoc_Doc_Cat = p.ref_tipo AND d.HDoc_Doc_Ano = p.ref_ciclo AND d.HDoc_Doc_Num = p.ref_numero"
        If celdaIDTipo.Text = 0 Then
            strsql &= "          WHERE p.empresa = {empresa} AND p.ejercicio = {Ejercicio}"

            If checkFecha.Checked = True Then

                strsql &= " AND (p.fecha BETWEEN '{fechainicio}' AND '{fechafin}')"

                strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
                strsql = Replace(strsql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

            End If
        Else
            strsql &= "          WHERE p.empresa = {empresa} AND p.ejercicio = {Ejercicio} AND p.tipo = {tipo}"

            If checkFecha.Checked = True Then

                strsql &= " AND (p.fecha BETWEEN '{fechainicio}' AND '{fechafin}')"

                strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
                strsql = Replace(strsql, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

            End If
        End If
        strsql &= "     ORDER BY p.fecha"
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{base}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{Ejercicio}", celdaIDEjercicio.Text)
        strsql = Replace(strsql, "{tipo}", celdaIDTipo.Text)

        Return strsql

    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim e As Integer
        Dim d As Integer

        strSQL = SQLlistaPrincipal()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Numero") & "|" & REA.GetString("Tipo") & "|" & REA.GetString("Concepto") & "|" & REA.GetDateTime("Fecha") & "|" & REA.GetInt32("Modo") & "|" &
                              REA.GetString("Estado") & "|" & REA.GetInt32("Documento")

                    e = REA.GetInt32("Estado")
                    d = REA.GetInt32("Documento")

                    AgregarFila(dgLista, strFila, e, d)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Pocedimiento propio de facturacion para agregar listado principal y colores de acuerdo al esta de cada fila
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer, ByVal Documento As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Not Estado = 1 Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Orange
                    End If
                End If
                If Documento = 0 Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.DarkRed
                        Celda.Style.ForeColor = Color.White
                    Else
                        '   Celda.Style.BackColor = Color.White
                    End If
                End If

                Fila.Cells.Add(Celda)

            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga Lista de Encabezado
    Private Function SQLEncabezado() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT p.empresa, p.ejercicio, p.poliza, p.fecha, ifnull(p.concepto,'N/A') concepto, p.tipo, p.tipo_cambio, ifnull(p.observaciones,'') observaciones, p.operador, p.estado, p.marca, p.grupo, p.modo, p.ref_tipo, p.ref_ciclo, p.ref_numero, p.divisa, p.tasa, p.revisado, IFNULL(p.usuario_rev,0) usuario_rev, p.ult_rev ultFecha_rev, t.tipo_poliza,t.nombre_corto, t.nombre, s.emp_nombre "
        strsql &= "  FROM {base}.polizas p"
        strsql &= "   LEFT JOIN {base}.tipo_poliza t ON t.tipo_poliza = p.modo"
        strsql &= "   LEFT JOIN Empresas s ON s.emp_no = p.empresa "
        strsql &= "     WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND p.poliza = {poliza}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{base}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{ejercicio}", celdaIDEjercicio.Text)
        strsql = Replace(strsql, "{poliza}", dgLista.SelectedCells(0).Value)

        Return strsql

    End Function

    'Query que carga Lista de Detalle
    Private Function SQLlistaDetalle() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT d.poliza, d.item item, d.cuenta id_cuenta, IFNULL(c.nombre, 0) nombre_cuenta, d.operacion operacion, d.importe importe, IFNULL( t.cost_num ,0) id, IFNULL(t.cost_nombre,0)costo, IFNULL(d.partida_presupuestal,0) presupuesto, d.ref_id, d.transaccion "
        strsql &= "  FROM {base}.detalle_polizas d"
        strsql &= "   LEFT JOIN {base}.cuentas c ON c.empresa = d.empresa AND c.id_cuenta = d.cuenta"
        strsql &= "     LEFT JOIN {base}.costos t ON t.cost_num = d.centro_costos"
        strsql &= "       WHERE d.empresa = {empresa} AND d.ejercicio = {ejercicio} AND d.poliza = {poliza}"
        strsql &= "      ORDER BY d.operacion DESC, d.item "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{base}", cFunciones.ContaEmpresa)
        strsql = Replace(strsql, "{ejercicio}", celdaIDEjercicio.Text)
        strsql = Replace(strsql, "{poliza}", dgLista.SelectedCells(0).Value)

        Return strsql

    End Function


    Private Function SQLMostrarEjercicioActivo()
        Dim strSQL = STR_VACIO

        strSQL = " SELECT e.ejercicio ejercicio, j.descripcion descrip "
        strSQL &= "    From {conta}.ejercicio_empresa e "
        strSQL &= "    LEFT JOIN {conta}.ejercicios j ON j.ejercicio = e.ejercicio  "
        strSQL &= "        WHERE e.empresa = {empresa} AND e.estado ='A' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)

        Return strSQL
    End Function
    'Procedimiento para Cargar dgLista Panel Detalle
    Public Sub queryListaDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLlistaDetalle()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("item") & "|" & REA.GetString("id_cuenta") & "|" & REA.GetString("nombre_cuenta")
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                        If REA.GetString("operacion") = "C" Then
                            strFila &= "|" & REA.GetDouble("importe") & "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                        Else
                            strFila &= "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetDouble("importe") & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                        End If
                    Else
                        If REA.GetString("operacion") = "C" Then
                            strFila &= "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                        Else
                            strFila &= "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                        End If
                    End If
                    'If REA.GetString("operacion") = "C" Then
                    '    strFila &= "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                    'Else
                    '    strFila &= "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                    'End If

                    cFunciones.AgregarFila(dgDetalle, strFila)


                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    ' llena los campos del Encabezado interno 
    Public Sub SeleccionarEncabezado()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLEncabezado()
        botonTPoliza.Enabled = False
        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read

                celdaPoliza.Text = REA.GetInt32("poliza")
                celdaEmp.Text = REA.GetString("emp_nombre")
                celdaOperator.Text = REA.GetString("operador")
                celdaConcepto.Text = REA.GetString("concepto")
                celdaTasa.Text = REA.GetDouble("tipo_cambio")
                celdaFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                celdaTPoliza.Text = REA.GetString("nombre_corto")
                celdaIDTPoliza.Text = REA.GetInt32("tipo_poliza")
                celdaObservaciones.Text = REA.GetString("observaciones")
                celdaCampo1.Text = REA.GetInt32("ejercicio")
                celdaCampo3.Text = REA.GetInt32("ref_tipo")
                celdaCampo4.Text = REA.GetInt32("ref_ciclo")
                celdaCampo5.Text = REA.GetInt32("ref_numero")
                celdaCampo6.Text = REA.GetInt32("modo")
                celdaCampo7.Text = REA.GetInt32("poliza")
                If REA.GetInt32("revisado") = 0 Then
                    botonSRevisar.BackColor = Color.Orange
                    botonSRevisar.Text = "Without Reviewed"
                    etiqFecha.Visible = False
                    etiqUser.Visible = False
                Else
                    botonSRevisar.BackColor = Color.PaleGreen
                    botonSRevisar.Text = "Reviewed"
                    etiqFecha.Visible = True
                    etiqUser.Visible = True
                    etiqFecha.Text = REA.GetDateTime("ultFecha_rev")
                    etiqUser.Text = REA.GetString("usuario_rev")
                End If

            Loop

            celdaConcepto.ReadOnly = True
            celdaObservaciones.ReadOnly = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Seleccionar()
        SeleccionarEncabezado()
        'SeleccionarSubdocumentos(año, numero)

    End Sub

    Public Sub CargarDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        'botonSRevisar.Text = "NOT REVIEW"
        'botonSRevisar.BackColor = Color.Orange
        Accessos("frmPolizasConta")
        Me.Tag = "Mod"

        strSQL = vbNullString
        strSQL = " SELECT *"
        strSQL &= "  FROM {base}.polizas p"
        If intTipo = vbEmpty Then
            strSQL &= "   LEFT JOIN {base}.tipo_poliza t ON t.tipo_poliza = p.modo"
            strSQL &= "     WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND p.poliza = {poliza}"

            strSQL = Replace(strSQL, "{ejercicio}", intEjercicio)
            strSQL = Replace(strSQL, "{poliza}", intPoliza)
        Else
            strSQL &= "   LEFT JOIN {base}.tipo_poliza t ON t.tipo_poliza = p.modo"
            strSQL &= "     WHERE p.empresa = {empresa} AND p.ref_tipo = {tipo} AND p.ref_ciclo = {ciclo} AND p.ref_numero= {numero}"
            If Not intModo = STR_VACIO Then
                strSQL &= "   AND p.modo = {modo}"
                strSQL = Replace(strSQL, "{modo}", intModo)
            End If

            strSQL = Replace(strSQL, "{tipo}", intTipo)
            strSQL = Replace(strSQL, "{ciclo}", intCiclo)
            strSQL = Replace(strSQL, "{numero}", intNumero)

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{base}", cFunciones.ContaEmpresa)
        End If
        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read

                celdaPoliza.Text = REA.GetInt32("poliza")
                celdaEmp.Text = Sesion.Empresa
                celdaOperator.Text = REA.GetString("operador")
                celdaConcepto.Text = REA.GetString("concepto")
                celdaTasa.Text = REA.GetDouble("tipo_cambio")
                celdaFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                celdaTPoliza.Text = REA.GetString("nombre_corto")
                celdaIDTPoliza.Text = REA.GetInt32("tipo_poliza")
                celdaObservaciones.Text = REA.GetString("observaciones")
                celdaCampo1.Text = REA.GetInt32("ejercicio")
                celdaCampo3.Text = REA.GetInt32("ref_tipo")
                celdaCampo4.Text = REA.GetInt32("ref_ciclo")
                celdaCampo5.Text = REA.GetInt32("ref_numero")
                celdaCampo6.Text = REA.GetInt32("modo")
                celdaCampo7.Text = REA.GetInt32("poliza")
                If REA.GetInt32("revisado") = 0 Then
                    botonSRevisar.BackColor = Color.Orange
                    botonSRevisar.Text = "Without Reviewed"
                    etiqFecha.Visible = False
                    etiqUser.Visible = False
                Else
                    botonSRevisar.BackColor = Color.PaleGreen
                    botonSRevisar.Text = "Reviewed"
                    etiqFecha.Visible = True
                    etiqUser.Visible = True
                    etiqFecha.Text = REA.GetDateTime("ult_rev")
                    etiqUser.Text = REA.GetString("usuario_rev")
                End If

            Loop

            'Datos del Detalle
            strSQL = vbNullString
            strSQL = " SELECT d.poliza, d.item item, d.cuenta id_cuenta, ifnull(c.nombre, 'Cuenta no valida') nombre_cuenta, d.operacion operacion, d.importe importe, IFNULL( t.cost_num ,0) id, IFNULL(t.cost_nombre,0)costo, IFNULL(d.partida_presupuestal,0) presupuesto, d.ref_id, d.transaccion "
            strSQL &= "  FROM {base}.detalle_polizas d"
            strSQL &= "   LEFT JOIN {base}.cuentas c ON c.empresa = d.empresa AND c.id_cuenta = d.cuenta"
            strSQL &= "     LEFT JOIN {base}.costos t ON t.cost_num = d.centro_costos"
            If intTipo = vbEmpty Then
                strSQL &= "       WHERE d.empresa = {empresa} AND d.ejercicio = {ejercicio} AND d.poliza = {poliza}"
                strSQL &= "      ORDER BY d.operacion DESC, d.item "

                strSQL = Replace(strSQL, "{ejercicio}", celdaIDEjercicio.Text)
                strSQL = Replace(strSQL, "{poliza}", intPoliza)
            Else
                strSQL &= "     WHERE d.empresa = {empresa} AND d.ref_tipo = {tipo} AND d.ref_ciclo = {ciclo} AND d.ref_numero= {numero}"
                If Not intModo = STR_VACIO Then
                    strSQL &= "   AND d.modo = {modo}"
                    strSQL = Replace(strSQL, "{modo}", intModo)
                End If

                strSQL = Replace(strSQL, "{tipo}", intTipo)
                strSQL = Replace(strSQL, "{ciclo}", intCiclo)
                strSQL = Replace(strSQL, "{numero}", intNumero)

                strSQL &= "      ORDER BY d.operacion DESC, d.item "
            End If

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{base}", cFunciones.ContaEmpresa)

            Try
                MyCnn.CONECTAR = strConexion

                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then

                    dgDetalle.Rows.Clear()

                    Do While REA.Read
                        Dim strFila As String = STR_VACIO

                        strFila = REA.GetInt32("item") & "|" & REA.GetString("id_cuenta") & "|" & REA.GetString("nombre_cuenta")
                        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa >= 18 Then
                            If REA.GetString("operacion") = "C" Then
                                strFila &= "|" & REA.GetDouble("importe") & "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                            Else
                                strFila &= "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetDouble("importe") & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                            End If
                        Else
                            If REA.GetString("operacion") = "C" Then
                                strFila &= "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                            Else
                                strFila &= "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                            End If
                        End If
                        'If REA.GetString("operacion") = "C" Then
                        '    strFila &= "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                        'Else
                        '    strFila &= "|" & 0.ToString(FORMATO_MONEDA) & "|" & REA.GetDouble("importe").ToString(FORMATO_MONEDA) & "|" & REA.GetInt32("id") & "|" & REA.GetString("costo") & "|" & REA.GetString("presupuesto") & "|" & 1 & "|" & REA.GetInt32("ref_id") & "|" & REA.GetInt32("transaccion")
                        'End If

                        cFunciones.AgregarFila(dgDetalle, strFila)

                    Loop
                End If
                MostrarLista(False)
                Encabezado1.botonCerrar.Enabled = False
                CalcularTotales()
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que hace actualización en el botón Revisado segun el estado de la Poliza
    Private Function sqlUpdate() As String
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand

        If Not logNuevo Then

            strsql = vbNullString
            strsql &= " UPDATE {base}.polizas SET revisado = {estado}, usuario_rev = '{Usuario}', ult_rev = {fecha}"
            strsql &= "     WHERE empresa = {empresa} AND ejercicio = {ejercicio} AND poliza = {poliza} "
            If Sesion.IdEmpresa = 18 Then
                strsql &= "; UPDATE contapdm.polizas SET revisado = {estado}, usuario_rev = '{Usuario}', ult_rev = {fecha}"
                strsql &= "     WHERE empresa = {empresa} AND ejercicio = {ejercicio} AND poliza = {poliza} "
            End If

            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{base}", cFunciones.ContaEmpresa)
            strsql = Replace(strsql, "{ejercicio}", Val(celdaCampo1.Text))
            strsql = Replace(strsql, "{base}", cFunciones.ContaEmpresa)
            strsql = Replace(strsql, "{Usuario}", Sesion.Usuario)
            strsql = Replace(strsql, "{fecha}", "CURDATE()")
            strsql = Replace(strsql, "{ejercicio}", Val(celdaCampo1.Text))
            If botonSRevisar.BackColor = Color.Orange Then
                strsql = Replace(strsql, "{estado}", 0)
            Else
                strsql = Replace(strsql, "{estado}", 1)
            End If
            strsql = Replace(strsql, "{poliza}", celdaPoliza.Text)
        End If

        MyCnn.CONECTAR = strConexion

        COM = New MySqlCommand(strsql, CON)
        COM.ExecuteNonQuery()

        Return strsql
    End Function

    Public Sub MostrarEjercicioActivo()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLMostrarEjercicioActivo()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    celdaEjercicio.Text = REA.GetString("descrip")
                    celdaIDEjercicio.Text = REA.GetInt32("ejercicio")
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Limpiar()

        celdaPoliza.Text = -1
        celdaEmp.Text = Sesion.Empresa
        celdaOperator.Text = Sesion.Usuario
        celdaConcepto.Text = STR_VACIO
        celdaTasa.Text = INT_UNO
        celdaFecha.Text = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaFecha.Enabled = False
        celdaTPoliza.Text = STR_VACIO
        celdaObservaciones.Text = STR_VACIO
        celdaCampo1.Text = EjercicioEnCurso() 'ejercicio
        celdaCampo3.Text = INT_CERO 'tipo (catalogo)
        celdaCampo4.Text = Year(celdaFecha.Text) ' ciclo (año)
        celdaCampo5.Text = INT_CERO ' numero
        celdaCampo6.Text = INT_UNO  ' modo tipo de Poliza
        celdaCampo7.Text = -1
        etiqFecha.Text = STR_VACIO
        etiqUser.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        celdaDebito.Text = -1
        celdaHaber.Text = -1

    End Sub

    Private Function NuevoIdPoliza()
        Dim longPoliza As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " SELECT ifnull(MAX(p.poliza),1)+1 from {conta}.polizas p "
        strSQL &= " WHERE p.empresa = {empresa} and p.ejercicio = '{ejercicio}' "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ejercicio}", EjercicioEnCurso)
        strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            longPoliza = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return longPoliza
    End Function

    Private Function EjercicioEnCurso()
        Dim strSQL As String = STR_VACIO
        Dim EjercicioAct As Integer = 0
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLMostrarEjercicioActivo()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    EjercicioAct = REA.GetInt32("ejercicio")
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return EjercicioAct
    End Function

    Private Function VerificarFechas()
        Dim strSQL As String = STR_VACIO
        Dim FechaValida As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = " SELECT ejercicio FROM {conta}.ejercicios WHERE (('{fecha}' >= inicio) AND ('{fecha}' <= fin)) "
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
            strSQL = Replace(strSQL, "{fecha}", celdaFecha.Value.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            FechaValida = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return FechaValida
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim DatosValidos As Boolean = True
        Dim cont As New clsContabilidad

        If celdaPoliza.Text = NO_FILA Or celdaEmp.Text = STR_VACIO Or celdaTasa.Text = STR_VACIO Then
            MsgBox("Verify that all header information is complete", vbInformation, "Notice")
            DatosValidos = False

            Return DatosValidos
            Exit Function
        End If

        If Not VerificarFechas() = EjercicioEnCurso() Then
            MsgBox("Verify that the date is within the range of the current year", vbInformation, "Notice")
            DatosValidos = False

            Return DatosValidos
            Exit Function
        End If

        If dgDetalle.Rows.Count > 0 Then

            If celdaDebito.Text = NO_FILA Or celdaHaber.Text = NO_FILA Then
                MsgBox("Check the Policy Detail", vbInformation, "Notice")
                DatosValidos = False
            Else
                If Not celdaHaber.Text = celdaDebito.Text Then
                    MsgBox("Check the Policy Detail", vbInformation, "Notice")
                    DatosValidos = False

                    Return DatosValidos
                    Exit Function
                End If
            End If

        End If

        Return DatosValidos
    End Function

    Private Sub GuardarEncabezado()
        Dim pol As New TPOLIZAS

        Try
            pol.CONEXION = strConexion

            pol.EMPRESA = Sesion.IdEmpresa
            pol.EJERCICIO = EjercicioEnCurso()
            pol.POLIZA = celdaPoliza.Text
            pol.fecha_NET = celdaFecha.Value
            pol.CONCEPTO = celdaConcepto.Text
            pol.TIPO = celdaIDTPoliza.Text
            pol.TIPO_CAMBIO = celdaTasa.Text
            pol.OBSERVACIONES = celdaObservaciones.Text
            pol.OPERADOR = Sesion.Usuario
            pol.ESTADO = "C"
            pol.marca_NET = cfun.HoyMySQL
            pol.MODO = celdaIDTPoliza.Text
            pol.REF_TIPO = celdaCampo3.Text
            pol.REF_CICLO = celdaCampo4.Text
            pol.REF_NUMERO = celdaCampo5.Text
            pol.TASA = celdaTasa.Text

            If Me.Tag = "Nuevo" Then
                If pol.Guardar = False Then
                    MsgBox(pol.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            Else
                If pol.PUPDATE = False Then
                    MsgBox(pol.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub GuardarDetalle()
        Dim det As New Tablas.TDETALLE_POLIZAS
        Dim intEjercicioAct As Integer = 0

        intEjercicioAct = EjercicioEnCurso()
        Try
            det.CONEXION = strConexion

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    det.TRANSACCION1 = dgDetalle.Rows(i).Cells("colTransaccion").Value
                Else
                    det.TRANSACCION1 = 0

                End If
                det.EMPRESA = Sesion.IdEmpresa
                det.EJERCICIO = intEjercicioAct
                det.POLIZA = celdaPoliza.Text

                det.CUENTA = dgDetalle.Rows(i).Cells("colCuenta").Value
                det.PARAMETRO_CUENTA = 1 'dgDetalle.Rows(i).Cells("")
                det.IMPORTE = IIf(dgDetalle.Rows(i).Cells("colDebe").Value = 0, dgDetalle.Rows(i).Cells("colHaber").Value, dgDetalle.Rows(i).Cells("colDebe").Value)
                det.CENTRO_COSTOS = IIf(dgDetalle.Rows(i).Cells("colIDCosto").Value = STR_VACIO, 0, dgDetalle.Rows(i).Cells("colIDCosto").Value)
                det.PARTIDA_PRESUPUESTAL = dgDetalle.Rows(i).Cells("colPresupuestal").Value
                det.OPERACION = IIf(dgDetalle.Rows(i).Cells("colDebe").Value > INT_CERO, 2, 1)
                det.FECHA = celdaFecha.Value.ToString(FORMATO_MYSQL)
                det.MODO = celdaIDTPoliza.Text
                det.REF_TIPO = celdaCampo3.Text
                det.REF_CICLO = celdaCampo4.Text
                det.REF_NUMERO = celdaCampo5.Text
                det.REF_ID = dgDetalle.Rows(i).Cells("colRef_id").Value
                det.ITEM = i + 1
                dgDetalle.Rows(i).Cells("colNum").Value = det.ITEM
                If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If det.PINSERT = False Then
                        MsgBox(det.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    ActualizarDetalle(i)
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If det.PDELETE = False Then
                        MsgBox(det.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub ActualizarDetalle(ByVal i As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim dblImporte As Double = 0

        Try

            strSQL = " UPDATE {conta}.detalle_polizas  "
            strSQL &= " SET  item = {item}, cuenta = '{cuenta}', importe ={importe}, centro_costos ={ccosto}, partida_presupuestal ='{ppres}', operacion = '{operacion}' "
            strSQL &= " WHERE transaccion = {trans} AND empresa = {empresa} AND ejercicio ={ejercicio} AND poliza = {poliza} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE contapdm.detalle_polizas  "
                strSQL &= " SET  item = {item}, cuenta = '{cuenta}', importe ={importe}, centro_costos ={ccosto}, partida_presupuestal ='{ppres}', operacion = '{operacion}' "
                strSQL &= " WHERE transaccion = {trans} AND empresa = {empresa} AND ejercicio ={ejercicio} AND poliza = {poliza} "

            End If
            dblImporte = IIf(dgDetalle.Rows(i).Cells("colDebe").Value = 0, dgDetalle.Rows(i).Cells("colHaber").Value, dgDetalle.Rows(i).Cells("colDebe").Value)

            strSQL = Replace(strSQL, "{item}", dgDetalle.Rows(i).Cells("colNum").Value)
            strSQL = Replace(strSQL, "{cuenta}", dgDetalle.Rows(i).Cells("colCuenta").Value)
            strSQL = Replace(strSQL, "{importe}", dblImporte)
            strSQL = Replace(strSQL, "{ccosto}", IIf(dgDetalle.Rows(i).Cells("colIDCosto").Value = STR_VACIO, 0, dgDetalle.Rows(i).Cells("colIDCosto").Value))
            strSQL = Replace(strSQL, "{ppres}", dgDetalle.Rows(i).Cells("colPresupuestal").Value)
            strSQL = Replace(strSQL, "{operacion}", IIf(dgDetalle.Rows(i).Cells("colDebe").Value > INT_CERO, "C", "A"))
            strSQL = Replace(strSQL, "{ejercicio}", celdaCampo1.Text)
            strSQL = Replace(strSQL, "{poliza}", celdaPoliza.Text)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{trans}", dgDetalle.Rows(i).Cells("colTransaccion").Value)
            strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub BorrarEncabezadoPoliza()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try

            strSQL = " DELETE  FROM {conta}.polizas "
            strSQL &= " WHERE empresa = {empresa} AND ejercicio ={ejercicio} AND poliza = {poliza} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; DELETE  FROM contapdm.polizas "
                strSQL &= " WHERE empresa = {empresa} AND ejercicio ={ejercicio} AND poliza = {poliza} "
            End If

            strSQL = Replace(strSQL, "{ejercicio}", celdaCampo1.Text)
            strSQL = Replace(strSQL, "{poliza}", celdaPoliza.Text)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub BorrarDetallePoliza()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                strSQL = " DELETE  FROM {conta}.detalle_polizas "
                strSQL &= " WHERE empresa = {empresa} AND ejercicio ={ejercicio} AND poliza = {poliza} "
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "; DELETE  FROM contapdm.detalle_polizas "
                    strSQL &= " WHERE empresa = {empresa} AND ejercicio ={ejercicio} AND poliza = {poliza} "
                End If

                strSQL = Replace(strSQL, "{ejercicio}", celdaCampo1.Text)
                strSQL = Replace(strSQL, "{poliza}", celdaPoliza.Text)
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{conta}", Sesion.BaseConta)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

#Region "Eventos"

    Private Sub frmPolizasContables_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now), 1)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now), 31)

        MostrarEjercicioActivo()

        celdaTipo.Text = "Todos"
        celdaIDTipo.Text = 0

        Accessos()
        MostrarLista(True)

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            Me.Tag = "Nuevo"
            Limpiar()
            MostrarLista(False)
            celdaFecha.Enabled = True
            SeleccionarTipoPolizas()
            celdaConcepto.ReadOnly = False
            celdaObservaciones.ReadOnly = False
            botonTPoliza.Enabled = True
            botonSRevisar.BackColor = Color.Orange
            botonSRevisar.Text = "Without Reviewed"
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If

    End Sub


    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        End If

    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click

        Dim CReportes As New clsReportes
        Dim intEjercicio As Integer = celdaCampo1.Text
        Dim intPoliza As Integer = celdaCampo7.Text

        CReportes.AccountingPolicyReport(intEjercicio, intPoliza)

    End Sub

    Private Sub botonEjercicio_Click(sender As Object, e As EventArgs) Handles botonEjercicio.Click

        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "empresa = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Exercice"
            frm.Campos = " b.descripcion, b.ejercicio"
            frm.Tabla = cfun.ContaEmpresa & ".ejercicio_empresa a LEFT JOIN " & cfun.ContaEmpresa & ".ejercicios b ON b.ejercicio=a.ejercicio"
            frm.FiltroText = " Enter the exercice to filter"
            frm.Filtro = "  b.ejercicio"
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaEjercicio.Text = frm.LLave
                celdaIDEjercicio.Text = frm.Dato
                celdaCampo1.Text = frm.Dato

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonTipo_Click(sender As Object, e As EventArgs) Handles botonTipo.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Type"
            frm.Campos = " tipo_poliza ID, nombre Description"
            frm.Tabla = cfun.ContaEmpresa & ".tipo_poliza "
            frm.FiltroText = " Enter the exercice to filter "
            frm.Filtro = " nombre"
            frm.Condicion = "tipo_poliza >= 0 "
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDTipo.Text = frm.LLave
                celdaTipo.Text = frm.Dato


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then
            'Procedimiento para cargar panel dgLista
            queryListaPrincipal()

        End If
    End Sub

    Private Sub botonComprobar_Click(sender As Object, e As EventArgs) Handles botonComprobar.Click

        Dim CReportes As New clsReportes
        Dim fechaInicio As Date
        Dim fechaFin As Date

        fechaInicio = dtpInicio.Value.ToString(FORMATO_MYSQL)
        fechaFin = dtpFin.Value.ToString(FORMATO_MYSQL)


        CReportes.VerificationsPolicyReport(fechaInicio, fechaFin)

    End Sub

#End Region

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            'captura el año,numero del panelprincipal dglista
            'ano = dgLista.SelectedCells(0).Value
            'numero = dgLista.SelectedCells(1).Value
            SeleccionarEncabezado()
            celdaFecha.Enabled = True
            queryListaDetalle()
            MostrarLista(False)
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonSRevisar_Click(sender As Object, e As EventArgs) Handles botonSRevisar.Click

        'Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        botonSRevisar.BackColor = IIf(botonSRevisar.BackColor = Color.Orange, Color.PaleGreen, Color.Orange)
        botonSRevisar.Text = IIf(botonSRevisar.Text = "Without Reviewed", "Reviewed", "Without Reviewed")

        sqlUpdate()

    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick


        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 1
                Dim frm As New frmSeleccionar
                Dim strCondicion As String = STR_VACIO
                Dim strTabla_ As String = STR_VACIO

                strTabla_ = " (
                            SELECT c.id_cuenta, c.nombre, IFNULL(n2.NombreIngles,'') Rubro, IFNULL(n.NombreIngles,'') Cuenta_Afectar
                                FROM {conta}.cuentas c
                                LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = c.empresa AND n.idCuenta = c.id_nomenclatura
                                LEFT JOIN {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa AND n2.idCuenta = n.Pertenencia
                                WHERE Empresa = {empresa}) l1"
                strTabla_ = Replace(strTabla_, "{conta}", cFunciones.ContaEmpresa)
                strTabla_ = Replace(strTabla_, "{empresa}", Sesion.IdEmpresa)
                strCondicion = "empresa = {empresa} "
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                Try
                    frm.Titulo = "Nomenclatura"
                    frm.Campos = " l1.id_cuenta Account_, l1.nombre Name_, l1.Rubro Accounting_Item, l1.Cuenta_Afectar Account_To_Affect "
                    frm.Tabla = strTabla_
                    frm.FiltroText = " Enter an account name to filter"
                    frm.Filtro = " l1.nombre "
                    If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                        frm.Condicion = " CHARACTER_LENGTH(l1.id_cuenta) > 6"
                    Else
                        frm.Condicion = "LENGTH(l1.id_cuenta)>1"
                    End If

                    frm.Ordenamiento = "l1.id_cuenta"
                    frm.TipoOrdenamiento = ""

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.SelectedCells(1).Value = frm.LLave
                        dgDetalle.SelectedCells(2).Value = frm.Dato
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

            Case 2
                Dim frm As New frmSeleccionar
                Dim strCondicion As String = STR_VACIO
                Dim strTabla_ As String = STR_VACIO

                strTabla_ = " (
                            SELECT c.id_cuenta, c.nombre, IFNULL(n2.NombreIngles,'') Rubro, IFNULL(n.NombreIngles,'') Cuenta_Afectar
                                FROM {conta}.cuentas c
                                LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = c.empresa AND n.idCuenta = c.id_nomenclatura
                                LEFT JOIN {conta}.nomenclatura n2 ON n2.idEmpresa = n.idEmpresa AND n2.idCuenta = n.Pertenencia
                                WHERE Empresa = {empresa}) l1"
                strTabla_ = Replace(strTabla_, "{conta}", cFunciones.ContaEmpresa)
                strTabla_ = Replace(strTabla_, "{empresa}", Sesion.IdEmpresa)
                strCondicion = "empresa = {empresa} "
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                Try
                    frm.Titulo = "Nomenclatura"
                    frm.Campos = " l1.id_cuenta Account_, l1.nombre Name_, l1.Rubro Accounting_Item, l1.Cuenta_Afectar Account_To_Affect "
                    frm.Tabla = strTabla_
                    frm.FiltroText = " Enter an account name to filter"
                    frm.Filtro = " l1.nombre "
                    If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                        frm.Condicion = " CHARACTER_LENGTH(l1.id_cuenta) > 6"
                    Else
                        frm.Condicion = "LENGTH(l1.id_cuenta)>1"
                    End If

                    frm.Ordenamiento = "l1.id_cuenta"
                    frm.TipoOrdenamiento = ""

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.SelectedCells(1).Value = frm.LLave
                        dgDetalle.SelectedCells(2).Value = frm.Dato
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try

            Case 6
                Dim frm As New frmSeleccionar
                Try
                    frm.Titulo = "Listado"
                    frm.Campos = " cost_num, cost_nombre "
                    frm.Tabla = cfun.ContaEmpresa & ".costos "
                    frm.FiltroText = " Ingrese un nombre de cuenta para filtrar"
                    frm.Filtro = " cost_nombre "
                    frm.Condicion = "cost_num >= 0"
                    frm.Ordenamiento = "cost_num"
                    frm.TipoOrdenamiento = ""

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.SelectedCells(5).Value = frm.LLave
                        dgDetalle.SelectedCells(6).Value = frm.Dato

                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
        End Select
    End Sub

    Private Sub CalcularTotales()

        Dim dblDebe As Double = 0
        Dim dblHaber As Double = 0


        Try
            dblDebeTotal = 0
            dblHaberTotal = 0

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                Else
                    dblDebe = CDbl(dgDetalle.Rows(i).Cells("colDebe").Value)
                    dblHaber = CDbl(dgDetalle.Rows(i).Cells("colHaber").Value)
                    dblDebeTotal = dblDebeTotal + dblDebe
                    dblHaberTotal = dblHaberTotal + dblHaber
                End If

            Next

            celdaDebito.Text = dblDebeTotal.ToString(FORMATO_MONEDA)
            celdaHaber.Text = dblHaberTotal.ToString(FORMATO_MONEDA)

            If Not dblDebeTotal.ToString(FORMATO_MONEDA) = dblHaberTotal.ToString(FORMATO_MONEDA) Then
                celdaHaber.BackColor = Color.White
                celdaDebito.BackColor = Color.White
                celdaHaber.ForeColor = Color.Red
                celdaDebito.ForeColor = Color.Red
            Else
                celdaHaber.BackColor = Color.WhiteSmoke
                celdaDebito.BackColor = Color.WhiteSmoke
                celdaHaber.ForeColor = Color.Black
                celdaDebito.ForeColor = Color.Black
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub SeleccionarTipoPolizas()
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Type"
            frm.Campos = " tipo_poliza ID,nombre_Corto, nombre Description"
            frm.Tabla = cfun.ContaEmpresa & ".tipo_poliza "
            frm.FiltroText = " Enter the exercice to filter "
            frm.Filtro = " nombre"
            frm.Condicion = "tipo_poliza = 1"
            frm.TipoOrdenamiento = ""

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDTPoliza.Text = frm.LLave
                celdaTPoliza.Text = frm.Dato


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonTPoliza_Click(sender As Object, e As EventArgs) Handles botonTPoliza.Click
        SeleccionarTipoPolizas()

    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.Rows.Count = INT_UNO Then Exit Sub
        dgDetalle.CurrentRow.Cells("colExtra").Value = 2
        dgDetalle.CurrentRow.Visible = False
        CalcularTotales()

    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "empresa = {empresa} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Nomenclatura"
            frm.Campos = " id_cuenta Cuenta, nombre Nombre "
            frm.Tabla = cfun.ContaEmpresa & ".cuentas "
            frm.FiltroText = " Ingrese un nombre de cuenta para filtrar"
            frm.Filtro = " nombre "
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                frm.Condicion = strCondicion & "and CHARACTER_LENGTH(id_cuenta) > 6"
            Else
                frm.Condicion = strCondicion & "and id_cuenta >= 0"
            End If
            frm.Ordenamiento = "id_cuenta"
            frm.TipoOrdenamiento = ""

            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Dim strFila As String = STR_VACIO

                strFila = "|" & frm.LLave & "|" & frm.Dato & "|" & 0 & "|" & 0 & "|" & "" & "|" & "" & "|" & "" & "|" & 0 & "|" & 0

                cFunciones.AgregarFila(dgDetalle, strFila)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intExisteCierre As Integer

        'Verifica si hay cierre
        strSQL = " Select Count(*) From Cierre_Encabezado e Where e.CE_Empresa = {emp} and e.CE_Anio = {anio} and e.CE_Fecha_Final >= '{fec}' "
        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Year(celdaFecha.Value.ToString(FORMATO_MYSQL)))
        strSQL = Replace(strSQL, "{fec}", celdaFecha.Value.ToString(FORMATO_MYSQL))

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        intExisteCierre = COM.ExecuteScalar
        ' 0 --> no existe Cierre
        If intExisteCierre = 0 Then
            GuardarDocumento()
        Else
            'Si hay cierre solicita autorización para modificar
            MsgBox("You need authorization to modify this document", vbInformation, "Notice")
            If cfun.AutorizarCambios = True Then
                GuardarDocumento()
            End If
        End If

    End Sub

    Private Sub GuardarDocumento()
        If Me.Tag = "Nuevo" Or logEditar = True Then

            If celdaPoliza.Text = NO_FILA Then
                celdaPoliza.Text = NuevoIdPoliza()
            End If
            If ComprobarDatos() = True Then
                GuardarEncabezado()
                GuardarDetalle()
                If Me.Tag = "Nuevo" Then
                    MsgBox("Successfully Saved Document")
                Else
                    MsgBox("Successfully Updated Document")
                End If
                MostrarLista()
            End If

        End If
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 3
                dgDetalle.CurrentRow.Cells("colHaber").Value = 0
                CalcularTotales()
            Case 4
                dgDetalle.CurrentRow.Cells("colDebe").Value = 0
                CalcularTotales()
        End Select
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("You want to delete the accounting record.", vbYesNo, "Question") = vbYes Then
                BorrarEncabezadoPoliza()
                BorrarDetallePoliza()
                MsgBox("The record has been successfully deleted", vbInformation, "Notice")
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission to perform this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class