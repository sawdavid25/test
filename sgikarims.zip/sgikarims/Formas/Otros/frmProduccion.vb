﻿Public Class frmProduccion

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim Proceso As Integer
    Dim CodigosMat As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim NotaDev As String
    Dim VerOpcion As Integer


#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property NumProceso As Integer
        Get
            Return Proceso
        End Get
        Set(value As Integer)
            Proceso = value
        End Set
    End Property

    Public Property MaterialesCod As String
        Get
            Return CodigosMat
        End Get
        Set(value As String)
            CodigosMat = value
        End Set
    End Property

#End Region

#Region "Procedimientos"

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select h.HDoc_Sis_Emp Empresa, h.HDoc_Doc_Cat Catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num Referencia, h.HDoc_RF2_Txt Producto, h.HDoc_Doc_Status estatus "
        strSQL &= "     From Dcmtos_HDR h"
        strSQL &= "         Where h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = 952 AND h.HDoc_Pro_DNum = {NumProceso} "

        If checkFecha.Checked = True Then

            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{NumProceso}", NumProceso)

        Return strSQL
    End Function

    Private Function NuevaLineaDTL()

        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{catalogo}", 952)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        End Using


    End Function

    Private Function NuevaLineaDEC()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = " SELECT IFNULL(MAX(d.EDoc_Doc_Lin+1),1) linea "
        strSQL &= "    FROM Dcmtos_DEC d "
        strSQL &= "        WHERE d.EDoc_Sis_Emp = {empresa} AND d.EDoc_Doc_Cat = {catalogo} AND d.EDoc_Doc_Ano={anio} AND d.EDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{catalogo}", 952)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)

        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function

    Private Function NuevaLineaIMP()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = " Select ifnull(Max(i.MDoc_Doc_Lin+1),1) "
        strSQL &= "    From Dcmtos_IMP i "
        strSQL &= "        Where i.MDoc_Sis_Emp = {empresa} and i.MDoc_Doc_Cat = {catalogo} and i.MDoc_Doc_Ano = {anio} and i.MDoc_Doc_Num ={numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{catalogo}", 952)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)

        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function

    Private Function NuevaIDEntrada()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = " Select ifNull (Max(idEntrada+1),1) Numero "
        strSQL &= "     From Entradas "
        strSQL &= "      Where Empresa = {empresa} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)

        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

    End Function

    Private Function SQLCargarEncabezado(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDOc_Sis_Emp Empresa, h.HDoc_Doc_Cat Catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, h.HDoc_DR1_Num Ref, h.HDoc_Doc_Status Estatus, h.HDoc_Doc_Mon Moneda, h.HDoc_Doc_TC Tasa, c.cat_clave clave,  h.HDoc_RF2_Num idProd, h.HDoc_RF2_Txt Producto "
        strSQL &= "     FROM Dcmtos_HDR h "
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas' "
        strSQL &= "            WHERE h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat= 952 AND h.HDoc_Doc_Ano={anio} AND h.HDoc_Doc_Num={numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL
    End Function

    Private Function SQLCargarProducto(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT p.PDoc_Par_Cat Catalogo, p.PDoc_Par_Ano Anio,p.PDoc_Par_Num Numero, p.PDoc_Par_Lin ParLinea, d.DDoc_Doc_Lin ChiLinea, d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_PUQ Costo, d.DDoc_RF1_Txt Clasif, d.DDoc_RF1_Dbl CantNeta, d.DDoc_Prd_UM UMedida, d.DDoc_RF1_Cod Referencia, db.BDoc_Box_QTY Bultos "
        strSQL &= "    From Dcmtos_DTL_Pro p "
        strSQL &= "        Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.DDoc_Doc_Num = p.PDoc_Chi_Num "
        strSQL &= "            LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND db.BDoc_Doc_Num = d.DDoc_Doc_Num AND db.BDoc_Doc_Lin = d.DDoc_Doc_Lin"
        strSQL &= "            Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "        Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "     WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 952 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Chi_Lin =d.DDoc_Doc_Lin  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL

    End Function

    Private Function SQLCargarProducto_DEC(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT p.PDoc_Par_Cat Catalogo, p.PDoc_Par_Ano Anio,p.PDoc_Par_Num Numero, p.PDoc_Par_Lin ParLinea, d.EDoc_Doc_Lin ChiLinea, d.EDoc_Lin_Desc Descripcion, d.EDoc_Lin_Net Cantidad, d.EDoc_Lin_Gross Codigo, d.EDoc_Lin_Cargos Costo, dt.DDoc_RF1_Txt Clasif, dt.DDoc_Prd_Des Mezcla, d.EDoc_Lin_Fob CantNeta, d.EDoc_Lin_DAI UMedida, d.EDoc_Lin_Frac referencia "
        strSQL &= "     From Dcmtos_DTL_Pro p "
        strSQL &= "         Left JOIN Dcmtos_DEC d ON d.EDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.EDoc_Doc_Cat = p.PDoc_Chi_Cat AND d.EDoc_Doc_Ano = p.PDoc_Chi_Ano AND d.EDoc_Doc_Num = p.PDoc_Chi_Num "
        strSQL &= "             LEFT JOIN Dcmtos_DTL dt ON dt.DDoc_Sis_Emp = d.EDoc_Sis_Emp AND dt.DDoc_Doc_Cat = d.EDoc_Doc_Cat AND dt.DDoc_Doc_Ano = d.EDoc_Doc_Ano AND dt.DDoc_Doc_Num = d.EDoc_Doc_Num "
        strSQL &= "        Left JOIN Inventarios i ON i.inv_sisemp = d.EDoc_Sis_Emp AND i.inv_numero = d.EDoc_Lin_Gross "
        strSQL &= "    Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 952 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Chi_Lin =d.EDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{numero}", numero)

        Return strSQL
    End Function

    Private Function SQLCargarCostos(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " Select i.MDoc_Sis_Emp empresa, i.MDoc_Doc_Num Numero, i.MDoc_Doc_Lin Linea, i.MDoc_Lin_ID codigo, c.cat_clave descripcion, i.MDoc_Lin_Monto monto "
        strSQL &= "    From Dcmtos_IMP i "
        strSQL &= "        Left Join Catalogos c ON c.cat_num = i.MDoc_Lin_ID "
        strSQL &= "            where i.MDoc_Sis_Emp = {empresa} and i.MDoc_Doc_Cat = {catalogo} and i.MDoc_Doc_Ano = {anio} and i.MDoc_Doc_Num= {num} "
        strSQL &= "                 order by i.MDoc_Doc_Lin  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 952)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", numero)

        Return strSQL
    End Function


    Private Function SQLHacerDescargo(ByVal Num As Integer, ByVal doc As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " Select l1.*, (l1.Ingreso-l1.Egreso) saldo "
        strSQL &= "    FROM( "
        strSQL &= "      Select d.DDoc_Prd_Cod Codigo, d.DDoc_Doc_Num Numero, d.DDoc_Prd_Des Descripcion, d.DDoc_RF1_Txt Clasificacion, d.DDoc_Prd_NET Costo, d.DDoc_Doc_Lin Linea, d.DDoc_Prd_QTY Ingreso, ( "
        strSQL &= "          Select IFNULL(SUM(dt.DDoc_Prd_QTY),0) "
        strSQL &= "              From Dcmtos_DTL_Pro p "
        strSQL &= "                  Left Join Dcmtos_DTL dt ON dt.DDoc_Sis_Emp= p.PDoc_Sis_Emp And dt.DDoc_Doc_Cat = p.PDoc_Chi_Cat And dt.DDoc_Doc_Ano = p.PDoc_Chi_Ano And dt.DDoc_Doc_Num= p.PDoc_Chi_Num And dt.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strSQL &= "                      WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp And p.PDoc_Par_Cat = d.DDoc_Doc_Cat And p.PDoc_Par_Ano = d.DDoc_Doc_Ano And p.PDoc_Par_Num = d.DDoc_Doc_Num And p.PDoc_Par_Lin = d.DDoc_Doc_Lin) Egreso "
        strSQL &= "                          From Dcmtos_DTL d "
        strSQL &= "                      Left Join Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                  Left Join Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo "
        strSQL &= "              Left Join Catalogos c ON c.cat_num = a.art_clase And cat_clave = 'ClaseArt' "
        strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = {catalogo} And d.DDoc_Prd_Cod= {numero} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {doc} )l1 "
        strSQL &= " ORDER BY l1.Codigo DESC "


        strSQL = Replace(strSQL, "{numero}", Num)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{doc}", doc)

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        If NumProceso = 1 Then
            strSQL = Replace(strSQL, "{catalogo}", 47)
        Else
            strSQL = Replace(strSQL, "{catalogo}", 952)
        End If

        Return strSQL

    End Function

    Private Function SQLEstimarCostos()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select d.DEst_IdGasto codigo, d.DEst_Linea linea, c.cat_clave descripcion, h.Est_IdMoneda moneda, d.DEst_Net estimacion, h.Est_Capacidad capacidad, d.DEst_Fase fase "
        strSQL &= "    From Estimacion_HDR h "
        strSQL &= "        Left Join Estimacion_DTL d on d.DEst_Empresa = h.Est_Empresa and d.DEst_Numero = h.Est_Id and d.DEst_Fase = {fase} "
        strSQL &= "            Left Join Catalogos c on c.cat_num = d.DEst_IdGasto "
        strSQL &= "                Where h.Est_Empresa = {empresa} and h.Estatus = 1 "
        strSQL &= "                    order by d.DEst_Linea "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fase}", NumProceso)

        Return strSQL
    End Function

    Private Function SQLVerificarCantidades()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT a.art_titulo titulo, m.det_num codFibra, m.det_clave nombre, m.det_prcnt porcentaje, m.det_merma Merma, c.cat_clave clave, c.cat_desc descripcion "
        strSQL &= "   FROM Articulos a "
        strSQL &= "        Left JOIN Materiales m ON m.det_sisemp = a.art_sisemp AND m.det_articulo = a.art_codigo "
        strSQL &= "            Left JOIN Catalogos c ON c.cat_num = m.det_num "
        strSQL &= "                WHERE a.art_sisemp = {empresa} AND a.art_codigo = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", celdaIdProducto.Text)

        Return strSQL

    End Function

    Private Function SQLDescargoAutomatico(ByVal i As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT  l1.*, (l1.Ingreso-l1.Egreso) saldo "
        strSQL &= "    FROM( "
        strSQL &= "        Select IFNULL(d.DDoc_Prd_Cod, 0) Codigo,  m.det_num, d.DDoc_Doc_Num Numero, d.DDoc_Prd_Des Descripcion, IFNULL(d.DDoc_RF1_Txt, '') Clasificacion, d.DDoc_Prd_NET Costo, d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Dbl Ingreso, d.DDoc_Prd_UM UMedida, ( "
        strSQL &= "            Select IFNULL(SUM(dt.DDoc_Prd_QTY),0) "
        strSQL &= "                From Dcmtos_DTL_Pro p "
        strSQL &= "                    Left JOIN Dcmtos_DTL dt ON dt.DDoc_Sis_Emp= p.PDoc_Sis_Emp AND dt.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND dt.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND dt.DDoc_Doc_Num= p.PDoc_Chi_Num AND dt.DDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strSQL &= "                        WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin) Egreso "
        strSQL &= "                            From Dcmtos_DTL d "
        strSQL &= "                            Left JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "                        Left JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                    Left JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
        strSQL &= "                Left JOIN Materiales m ON m.det_sisemp = a.art_sisemp AND m.det_articulo = a.art_codigo "
        strSQL &= "           WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = {catalogo} And m.det_num ={numero} )l1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", dgCostoFijo.Rows(i).Cells("colCodigoFijo").Value)
        If NumProceso = 1 Then
            strSQL = Replace(strSQL, "{catalogo}", 47)
        Else
            strSQL = Replace(strSQL, "{catalogo}", 952)
        End If

        Return strSQL

    End Function

    Private Function SQLCargarBultos()
        Dim strsql As String = STR_VACIO

        strsql = " SELECT b.BPDoc_Par_Cat catalogo, b.BPDoc_Par_Ano anio, b.BPDoc_Par_Num numero, b.BPDoc_Par_Lin ParLinea, b.BPDoc_Box_Lin LineaBulto, b.BPDoc_Chi_Lin LineaDoc, d.BDoc_Box_LB Peso, d.BDoc_Box_Cod Marca, d.BDoc_Box_Ctg Categoria, d.BDoc_Box_Hsm correlativo "
        strsql &= "    From Dcmtos_DTL_Box_Pro b "
        strsql &= "      LEFT JOIN Dcmtos_DTL_Box d ON d.BDoc_Sis_Emp = b.BPDoc_Sis_Emp AND d.BDoc_Doc_Cat =b.BPDoc_Par_Cat AND d.BDoc_Doc_Ano = b.BPDoc_Par_Ano AND d.BDoc_Doc_Num = b.BPDoc_Par_Num AND d.BDoc_Doc_Lin = b.BPDoc_Par_Lin AND d.BDoc_Box_Lin = b.BPDoc_Box_Lin "
        strsql &= "         WHERE b.BPDoc_Sis_Emp = {empresa} AND b.BPDoc_Par_Cat = 47 AND b.BPDoc_Chi_Cat = {cat} AND b.BPDoc_Chi_Ano = {anio} AND b.BPDoc_Chi_Num = {num} "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{cat}", celdaCatalogo.Text)
        strsql = Replace(strsql, "{anio}", celdaAnio.Text)
        strsql = Replace(strsql, "{num}", celdaNumero.Text)

        Return strsql
    End Function
    Public Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Producto")

                    If REA.GetInt32("estatus") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If



                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub RealizarEstimacion()

        If celdaCantidad.TextLength > 1 Then
            EstimarCostos()
            VerificarCantidades()
            ' DescargoAutomatico()
            botonProducto.Visible = True
            botonEliminarProd.Visible = True
            etiquetaProduto.Visible = True
            etiquetaEliminar.Visible = True
        End If
    End Sub

    Public Sub CargarBultos()
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As New MySqlCommand
        Dim strFila As String = STR_VACIO

        strSQL = SQLCargarBultos()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgBultos.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("catalogo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("ParLinea") & "|"
                    strFila &= REA.GetInt32("LineaBulto") & "|"
                    strFila &= REA.GetInt32("LineaDoc") & "|"
                    strFila &= 1 & "|"
                    strFila &= REA.GetDouble("Peso") & "|"
                    strFila &= REA.GetString("Marca") & "|"
                    strFila &= REA.GetString("correlativo") & "|"
                    strFila &= REA.GetString("Categoria")

                    cfun.AgregarFila(dgBultos, strFila)

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub CargarEncabezado(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLCargarEncabezado(anio, numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read

                    celdaEmpresa.Text = REA.GetInt32("Empresa")
                    celdaAnio.Text = REA.GetInt32("Anio")
                    celdaCatalogo.Text = REA.GetInt32("Catalogo")
                    celdaNumero.Text = REA.GetInt32("Numero")
                    celdareferencia.Text = REA.GetString("Ref")
                    dtpFecha.Text = REA.GetDateTime("Fecha")
                    celdaFecha.Text = REA.GetString("Fecha")
                    celdaIdMoneda.Text = REA.GetInt32("Moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaMoneda.Text = REA.GetString("clave")
                    celdaHilo.Text = REA.GetString("Producto")
                    celdaIdProducto.Text = REA.GetInt32("idProd")

                    If REA.GetInt32("Estatus") = 0 Then
                        etiquetaInactivo.Visible = True
                        botonAnular.Enabled = False
                        botonStart.Enabled = False
                        botonStop.Enabled = False
                    Else
                        etiquetaInactivo.Visible = False
                        botonAnular.Enabled = True
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub CargarProducto(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try

            strSQL = SQLCargarProducto(anio, numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgProducto.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetInt32("ChiLinea") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Clasif") & "|"
                    strFila &= REA.GetDouble("Costo").ToString(FMT_MSO_DIGITO) & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= INT_UNO & "|"
                    strFila &= REA.GetInt32("ParLinea") & "|"
                    strFila &= 0 & "|"
                    strFila &= (REA.GetDouble("Costo") * REA.GetDouble("Cantidad")).ToString(FMT_MSO_DIGITO) & "|"
                    strFila &= REA.GetInt32("UMedida") & "|"
                    If REA.GetInt32("UMedida") = 69 Then
                        strFila &= "LBS" & "|"
                    ElseIf REA.GetInt32("UMedida") = 70 Then
                        strFila &= "KGS" & "|"
                    End If
                    strFila &= "" & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Bultos")

                    cFunciones.AgregarFila(dgProducto, strFila)
                Loop
                celdaCantidad.Text = REA.GetInt32("CantNeta")
                'celdareferencia.Text = 
                'celdaCantidad.Enabled = False
                If NumProceso = 2 Then
                    celdaHilo.Text = REA.GetString("Descripcion")
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarProducto_DEC(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarProducto_DEC(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgProducto.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetInt32("ChiLinea") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Clasif") & "|"
                    strFila &= REA.GetDouble("Costo").ToString(FMT_MSO_DIGITO) & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= INT_UNO & "|"
                    strFila &= REA.GetInt32("ParLinea") & "|"
                    strFila &= 0 & "|"
                    strFila &= (REA.GetDouble("Costo") * REA.GetDouble("Cantidad")).ToString(FMT_MSO_DIGITO) & "|"
                    strFila &= REA.GetDouble("UMedida") & "|"
                    If REA.GetDouble("UMedida") = 69 Then
                        strFila &= "LBS" & "|"
                    ElseIf REA.GetDouble("UMedida") = 70 Then
                        strFila &= "KGS" & "|"
                    End If
                    strFila &= "" & "|"
                    strFila &= REA.GetString("referencia")

                    cFunciones.AgregarFila(dgProducto, strFila)
                Loop
                celdaCantidad.Text = REA.GetInt32("CantNeta")
                celdaHilo.Text = REA.GetString("Mezcla")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Public Sub CargarCostos(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try

            strSQL = SQLCargarCostos(anio, numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgCostos.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("monto").ToString(FMT_MSO_DIGITO)

                    cFunciones.AgregarFila(dgCostos, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Public Sub CargarCostos(ByVal anio As Integer, ByVal numero As Integer)
    '    Dim strSQL As String = STR_VACIO
    '    Dim COM As MySqlCommand
    '    Dim REA As MySqlDataReader
    '    Dim strFila As String = STR_VACIO

    '    Try

    '        strSQL = SQLCargarCostos(anio, numero)

    '        MyCnn.CONECTAR = strConexion
    '        COM = New MySqlCommand(strSQL, CON)
    '        REA = COM.ExecuteReader
    '        dgCostoTiempo.Rows.Clear()
    '        dgCostoFijo.Rows.Clear()
    '        If REA.HasRows Then
    '            Do While REA.Read
    '                If REA.GetInt32("tiempo") = INT_UNO Then
    '                    strFila = REA.GetInt32("Anio") & "|" 'anio
    '                    strFila &= REA.GetInt32("Catalogo") & "|" 'catalogo
    '                    strFila &= REA.GetInt32("codigo") & "|" 'codigo
    '                    strFila &= REA.GetString("descripcion") & "|" 'descripcion
    '                    strFila &= REA.GetString("nombre") & "|" 'clasificacion
    '                    strFila &= REA.GetDouble("Costo") & "|" 'costo
    '                    strFila &= REA.GetDouble("Cantidad") & "|" 'cantidad
    '                    strFila &= INT_UNO & "|" 'Linea Extra
    '                    strFila &= REA.GetInt32("Linea") 'Linea

    '                    cFunciones.AgregarFila(dgCostoTiempo, strFila)

    '                ElseIf REA.GetInt32("tiempo") = INT_CERO Then
    '                    strFila = REA.GetInt32("Anio") & "|" 'anio
    '                    strFila &= REA.GetInt32("Catalogo") & "|" 'catalogo
    '                    strFila &= REA.GetInt32("codigo") & "|" 'codigo
    '                    strFila &= REA.GetString("descripcion") & "|" 'descripcion
    '                    strFila &= REA.GetString("nombre") & "|" 'clasificacion
    '                    strFila &= REA.GetDouble("Costo") & "|" 'costo
    '                    strFila &= REA.GetDouble("Cantidad") & "|" 'cantidad
    '                    strFila &= INT_UNO & "|" 'Linea Extra
    '                    strFila &= REA.GetInt32("Linea")  'Linea

    '                    cFunciones.AgregarFila(dgCostoFijo, strFila)
    '                End If
    '            Loop
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try

    'End Sub

    'Public Sub CargarIDProyectoTarea()
    '    Dim strSQL As String = STR_VACIO
    '    Dim COM As New MySqlCommand
    '    Dim REA As MySqlDataReader
    '    Dim conec As New MySqlConnection

    '    Try
    '        strSQL = " Select t.idProyecto NumProyecto, t.idTareas Tarea, t.`Status` estado "
    '        strSQL &= "    From Tareas t "
    '        strSQL &= "        Where t.Empresa = {empresa} and t.catalogo = {catalogo} and t.ano = {anio} and t.numero = {numero} "

    '        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
    '        strSQL = Replace(strSQL, "{catalogo}", dgLista.SelectedCells(0).Value)
    '        strSQL = Replace(strSQL, "{anio}", dgLista.SelectedCells(1).Value)
    '        strSQL = Replace(strSQL, "{numero}", dgLista.SelectedCells(2).Value)

    '        conec = New MySqlConnection(strConexion)
    '        conec.Open()
    '        COM = New MySqlCommand(strSQL, conec)
    '        REA = COM.ExecuteReader

    '        ' se Captura el id del Proyecto y de la tarea para poder actualizar los campos que permiten hacer la relacion con el documento y el estatus
    '        If REA.HasRows Then
    '            REA.Read()
    '            celdaIdProyecto.Text = REA.GetInt32("NumProyecto")
    '            celdaIDTarea.Text = REA.GetInt32("Tarea")
    '            If REA.GetString("estado") = "Finalizado" Then
    '                botonStart.Enabled = False
    '                botonStop.Enabled = False
    '            End If
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    Private Function VerBotonesEntrada(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = " Select h.HDoc_Doc_Status  "
        strSQL &= "     From Dcmtos_HDR h "
        strSQL &= "      WHERE h.HDoc_Sis_Emp  = {empresa} AND h.HDoc_Doc_Cat  = {catalogo} AND h.HDoc_Doc_Ano  = {anio} AND h.HDoc_Doc_Num  = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", cat)
        strSQL = Replace(strSQL, "{numero}", num)
        strSQL = Replace(strSQL, "{anio}", anio)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar()
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function

    Private Function RevisarFecha(ByVal cat As Integer, ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = " Select Count(*) "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        Left Join Entradas e ON e.Empresa = h.HDoc_Sis_Emp  and e.idTarea = h.HDoc_Doc_Ano   and e.idProyecto = h.HDoc_Doc_Num  "
        strSQL &= "    Where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = {catalogo} and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero} and e.Fin is null "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", cat)
        strSQL = Replace(strSQL, "{numero}", num)
        strSQL = Replace(strSQL, "{anio}", anio)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)

        Using conec
            Return COM.ExecuteScalar()
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function

    Private Function CalcularHoras()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = " SELECT SUM((TIMESTAMPDIFF(MINUTE, e.Inicio,e.Fin)/60)) horas "
        strSQL &= "    From Entradas e "
        strSQL &= "        WHERE e.idProyecto = {num} AND e.idTarea = {anio} "

        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

    End Function

    Private Function CompararSaldo(ByVal i As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM1 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection
        Dim ComprobarSaldo As Double

        strSQL = SQLHacerDescargo(CInt(dgProducto.Rows(i).Cells("col_CodigoProd").Value), CInt(dgProducto.Rows(i).Cells("col_NumeroProd").Value), CInt(dgProducto.Rows(i).Cells("col_AnioProd").Value))

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM1 = New MySqlCommand(strSQL, conec)

        REA = COM1.ExecuteReader

        If REA.HasRows Then
            REA.Read()
            If Me.Tag = "Nuevo" Then
                ComprobarSaldo = REA.GetDouble("saldo")
            ElseIf Me.Tag = "Mod" Then
                ComprobarSaldo = (REA.GetDouble("saldo") + dgProducto.Rows(i).Cells("col_CantidadProd").Value)
            End If

        End If

        Using conec
            Return ComprobarSaldo
            COM1.Dispose()
            COM1 = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function


    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub ColocaMoneda()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection

        strSQL = "SELECT c.cat_clave Moneda, c.cat_num ID, c.cat_sist FROM Catalogos c WHERE cat_clase='Monedas' and c.cat_num = 178"

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            REA = COM.ExecuteReader
            If REA.HasRows Then
                REA.Read()
                celdaMoneda.Text = REA.GetString("Moneda")
                celdaIdMoneda.Text = REA.GetInt32("ID")
                celdaTasa.Text = REA.GetDouble("cat_sist")
            End If

            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

    End Sub

    Private Sub EstimarCostos()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim Calculo As Double

        strSQL = SQLEstimarCostos()
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgCostos.Rows.Clear()
                Do While REA.Read
                    Calculo = 0
                    Calculo = (((REA.GetDouble("estimacion")) / (REA.GetDouble("capacidad"))) * celdaCantidad.Text)

                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= Calculo.ToString(FMT_MSO_DIGITO)

                    cFunciones.AgregarFila(dgCostos, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub VerificarCantidades()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim Calculo As Double
        Dim TPorcentaje As Integer

        strSQL = SQLVerificarCantidades()
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgCostoFijo.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("codFibra") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    If REA.GetInt32("porcentaje") = 0 Then
                        TPorcentaje = 100
                    Else
                        TPorcentaje = REA.GetInt32("porcentaje")
                    End If
                    strFila &= TPorcentaje & "|"
                    strFila &= REA.GetInt32("Merma") & "|"
                    Calculo = (((celdaCantidad.Text * TPorcentaje) / 100) + ((celdaCantidad.Text * REA.GetInt32("Merma")) / 100))
                    strFila &= Calculo

                    cfun.AgregarFila(dgCostoFijo, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub HacerDescargo()

        Dim frmD As New frmDescargarProducto
        Dim Aceptado As Boolean
        Dim strFila As String = STR_VACIO
        Dim i As Integer = 0
        Dim acumalaCod As String = STR_VACIO

        Try
            For i = 0 To dgCostoFijo.Rows.Count - 1
                If i = 0 Then
                    acumalaCod = dgCostoFijo.Rows(i).Cells("colCodigoFijo").Value
                Else
                    acumalaCod = acumalaCod & ", " & dgCostoFijo.Rows(i).Cells("colCodigoFijo").Value
                End If
            Next
            frmD.CodigoMat = acumalaCod

            frmD.Proceso = Proceso
            frmD.ShowDialog(Me) 'Muestra frmDescargarProducto
            Aceptado = frmD.Aceptar

            If Aceptado = True Then

                strFila = celdaAnio.Text & "|" 'año

                If NumProceso = 1 Then
                    strFila &= 47 & "|" 'catalogo 47 si el proceso es BlowrRoom, de lo contrario será 952 
                Else
                    strFila &= 952 & "|" 'catalogo
                End If

                strFila &= frmD.Number & "|" 'Numero(Par_Cat)
                strFila &= frmD.Code & "|" 'codigo
                strFila &= 0 & "|" 'Line
                strFila &= frmD.Description & "|" 'descripcion
                strFila &= frmD.classification & "|" 'clasificacion
                strFila &= frmD.Cost & "|" 'costo
                strFila &= frmD.Quantity & "|" 'cantidad
                strFila &= 0 & "|" 'LineaExtra
                strFila &= frmD.Line & "|" ' Linea Para Pro
                strFila &= 0 & "|" ' Porcentaje, ya no lo uso
                strFila &= (frmD.Cost * frmD.Quantity) & "|" ' Total
                strFila &= frmD.Medida & "|"
                If frmD.Medida = 69 Then
                    strFila &= "LBS" & "|"
                ElseIf frmD.Medida = 70 Then
                    strFila &= "KGS" & "|"
                End If
                strFila &= "" & "|"
                strFila &= frmD.Referencia

                cFunciones.AgregarFila(dgProducto, strFila) 'Cargo al datagrid Producto los valores del frmDescargarProducto
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub MostrarBultosADescargar()
        Dim frm As New frmSeleccionar
        Dim logVerificar As Boolean = True
        Dim condicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strFilaAux As String = STR_VACIO
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim k As Integer = 0
        Dim NumDoc As String = STR_VACIO
        Dim verificaInsert As Integer = 0
        Dim LinDoc As Integer = 0
        Dim AnioDoc As Integer = 0
        Dim sumaCant As Double = 0
        Dim SumaCant2 As Double = 0
        Dim SumaPaquetes As Integer = 0

        condicion = " d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Num = db.BDoc_Doc_Num AND h.HDoc_Ant_Com =0 AND bp.BPDoc_Par_Num IS NULL "
        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
        'condicion = Replace(condicion, "{num}", dgCostoFijo.Rows(i).Cells("colCodigoFijo").Value)

        Try
            frm.Titulo = " Select the packages to use "
            frm.Campos = " db.BDoc_Box_Hsm Correlative,db.BDoc_Box_Cod Mark, h.HDoc_DR1_Num Reference, d.DDoc_Prd_Des Description, db.BDoc_Box_LB PesoBulto, d.DDoc_Prd_NET Price, c.cat_clave Measure, d.DDoc_Doc_Num Number, d.DDoc_Doc_Ano YEAR, d.DDoc_Doc_Lin Line, db.BDoc_Box_Lin LineaBulto, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_UM Umedida, db.BDoc_Box_Ctg Categoria  "
            frm.Tabla = " Dcmtos_DTL d " &
                         " LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND db.BDoc_Doc_Num = d.DDoc_Doc_Num AND db.BDoc_Doc_Lin = d.DDoc_Doc_Lin " &
                         " LEFT JOIN Dcmtos_DTL_Box_Pro bp ON bp.BPDoc_Sis_Emp = db.BDoc_Sis_Emp AND bp.BPDoc_Par_Num = db.BDoc_Doc_Num AND bp.BPDoc_Par_Cat = db.BDoc_Doc_Cat AND bp.BPDoc_Par_Ano = db.BDoc_Doc_Ano AND bp.BPDoc_Par_Lin = db.BDoc_Doc_Lin AND bp.BPDoc_Box_Lin = db.BDoc_Box_Lin AND bp.BPDoc_Chi_Cat= 952 " &
                         " LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND cat_clase = 'Medidas' " &
                         "  LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = db.BDoc_Sis_Emp AND h.HDoc_Doc_Cat = db.BDoc_Doc_Cat AND h.HDoc_Doc_Ano = db.BDoc_Doc_Ano AND h.HDoc_Doc_Num = db.BDoc_Doc_Num " &
                         " LEFT JOIN Inventarios i ON i.inv_sisemp = h.HDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod " &
                          " LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo" &
                          " LEFT JOIN Materiales m ON m.det_sisemp = a.art_sisemp AND m.det_articulo = a.art_codigo "
            frm.FiltroText = " Enter description "
            frm.Filtro = " db.BDoc_Box_Hsm "
            frm.Condicion = condicion
            frm.Multiple = True

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'dgBultos.Rows.Clear()

                For i = 0 To frm.DataGrid.Rows.Count - 1
                    If frm.ListaClientes.Rows(i).Cells("colCheck").Value = True Then
                        logVerificar = True
                        If dgBultos.Rows.Count > 0 Then
                            For k = 0 To dgBultos.Rows.Count - 1
                                '7 es 11, 5 es 10, 4 es 8, 3 es 9
                                If frm.ListaClientes.Rows(i).Cells(9).Value = dgBultos.Rows(k).Cells("colAnioB").Value And frm.ListaClientes.Rows(i).Cells(8).Value = dgBultos.Rows(k).Cells("colNumeroB").Value And frm.ListaClientes.Rows(i).Cells(10).Value = dgBultos.Rows(k).Cells("colLineaB").Value And frm.ListaClientes.Rows(i).Cells(11).Value = dgBultos.Rows(k).Cells("colBultoB").Value Then

                                    MsgBox("The package " & frm.ListaClientes.Rows(i).Cells(11).Value & " has already been selected, select another", vbInformation, "Notice")
                                    logVerificar = False
                                End If
                            Next
                        End If
                        If logVerificar = True Then
                            strFilaAux = 47 & "|" 'catalogo
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Año
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" 'Par_Linea
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(11).Value & "|" 'Linea Bulto
                            strFilaAux &= 0 & "|" 'Linea Documento
                            strFilaAux &= 0 & "|" 'Extra
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(5).Value & "|" 'Peso del Bulto
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(2).Value & "|" 'Marca
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(1).Value & "|" ' Correlativo HSM
                            strFilaAux &= frm.ListaClientes.Rows(i).Cells(14).Value ' Categoria

                            cFunciones.AgregarFila(dgBultos, strFilaAux)

                            If frm.ListaClientes.Rows(i).Cells(9).Value = AnioDoc And frm.ListaClientes.Rows(i).Cells(8).Value = NumDoc And frm.ListaClientes.Rows(i).Cells(10).Value = LinDoc Then
                                If dgProducto.Rows.Count > 0 Then
                                    NumDoc = frm.ListaClientes.Rows(i).Cells(8).Value
                                    LinDoc = frm.ListaClientes.Rows(i).Cells(10).Value
                                    AnioDoc = frm.ListaClientes.Rows(i).Cells(9).Value

                                    For j = 0 To dgProducto.Rows.Count - 1
                                        If dgProducto.Rows(j).Cells("col_AnioProd").Value = AnioDoc And dgProducto.Rows(j).Cells("col_NumeroProd").Value = NumDoc And dgProducto.Rows(j).Cells("col_ParLineaProd").Value = LinDoc And dgProducto.Rows(j).Cells("col_ExtraProd").Value < 2 Then
                                            SumaPaquetes = 0
                                            sumaCant = frm.ListaClientes.Rows(i).Cells(5).Value
                                            SumaCant2 = dgProducto.Rows(j).Cells("col_CantidadProd").Value + sumaCant
                                            dgProducto.Rows(j).Cells("col_CantidadProd").Value = SumaCant2
                                            verificaInsert = 1
                                            SumaPaquetes = CInt(dgProducto.Rows(j).Cells("col_BultosProd").Value) + 1
                                            dgProducto.Rows(j).Cells("col_BultosProd").Value = SumaPaquetes
                                        Else

                                        End If

                                    Next
                                    If verificaInsert = 0 Then
                                        'SumaPaquetes = 0
                                        strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                        strFila &= 47 & "|" 'Catalogo
                                        strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                        strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                        strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                        strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                        strFila &= "" & "|" 'Clasificacion
                                        strFila &= frm.ListaClientes.Rows(i).Cells(6).Value & "|" ' Costo
                                        sumaCant = sumaCant + frm.ListaClientes.Rows(i).Cells(5).Value
                                        strFila &= sumaCant.ToString(FMT_MSO_DIGITO) & "|" 'Cantidad
                                        strFila &= INT_CERO & "|" 'Extra
                                        strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" ' Par_linea
                                        strFila &= "" & "|" 'Porcentaje
                                        strFila &= ((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant)) & "|" ' Total
                                        strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                        strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                        strFila &= "" & "|" ' Verificador
                                        strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                        SumaPaquetes = SumaPaquetes + 1
                                        strFila &= SumaPaquetes  ' Paquetes

                                        AnioDoc = frm.ListaClientes.Rows(i).Cells(9).Value
                                        NumDoc = frm.ListaClientes.Rows(i).Cells(8).Value
                                        LinDoc = frm.ListaClientes.Rows(i).Cells(10).Value
                                    End If
                                Else
                                    strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                    strFila &= 47 & "|" 'Catalogo
                                    strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                    strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                    strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                    strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                    strFila &= "" & "|" 'Clasificacion
                                    strFila &= frm.ListaClientes.Rows(i).Cells(6).Value & "|" ' Costo
                                    sumaCant = sumaCant + frm.ListaClientes.Rows(i).Cells(5).Value
                                    strFila &= sumaCant.ToString(FMT_MSO_DIGITO) & "|" 'Cantidad
                                    strFila &= INT_CERO & "|" 'Extra
                                    strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" ' Par_linea
                                    strFila &= "" & "|" 'Porcentaje
                                    strFila &= ((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant)) & "|" ' Total
                                    strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                    strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                    strFila &= "" & "|" ' Verificador
                                    strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                    SumaPaquetes = SumaPaquetes + 1
                                    strFila &= SumaPaquetes  'Paquetes

                                    AnioDoc = frm.ListaClientes.Rows(i).Cells(9).Value
                                    NumDoc = frm.ListaClientes.Rows(i).Cells(8).Value
                                    LinDoc = frm.ListaClientes.Rows(i).Cells(10).Value
                                End If

                            Else
                                If i = 0 Then
                                ElseIf i > 0 And strFila <> STR_VACIO Then
                                    cFunciones.AgregarFila(dgProducto, strFila)
                                    strFila = STR_VACIO
                                    sumaCant = INT_CERO
                                    SumaPaquetes = 0
                                End If

                                If dgProducto.Rows.Count > 0 Then

                                    AnioDoc = frm.ListaClientes.Rows(i).Cells(9).Value
                                    NumDoc = frm.ListaClientes.Rows(i).Cells(8).Value
                                    LinDoc = frm.ListaClientes.Rows(i).Cells(10).Value

                                    For j = 0 To dgProducto.Rows.Count - 1
                                        If dgProducto.Rows(j).Cells("col_AnioProd").Value = AnioDoc And dgProducto.Rows(j).Cells("col_NumeroProd").Value = NumDoc And dgProducto.Rows(j).Cells("col_ParLineaProd").Value = LinDoc And dgProducto.Rows(j).Cells("col_ExtraProd").Value < 2 Then
                                            SumaPaquetes = 0
                                            sumaCant = frm.ListaClientes.Rows(i).Cells(5).Value
                                            SumaCant2 = dgProducto.Rows(j).Cells("col_CantidadProd").Value + sumaCant
                                            dgProducto.Rows(j).Cells("col_CantidadProd").Value = SumaCant2
                                            verificaInsert = 1
                                            SumaPaquetes = CInt(dgProducto.Rows(j).Cells("col_BultosProd").Value) + 1
                                            dgProducto.Rows(j).Cells("col_BultosProd").Value = SumaPaquetes
                                        Else

                                        End If

                                    Next
                                    If verificaInsert = 0 Then
                                        SumaPaquetes = 0
                                        strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                        strFila &= 47 & "|" 'Catalogo
                                        strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                        strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                        strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                        strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                        strFila &= "" & "|" 'Clasificacion
                                        strFila &= frm.ListaClientes.Rows(i).Cells(6).Value & "|" ' Costo
                                        sumaCant = sumaCant + frm.ListaClientes.Rows(i).Cells(5).Value
                                        strFila &= sumaCant.ToString(FMT_MSO_DIGITO) & "|" 'Cantidad
                                        strFila &= INT_CERO & "|" 'Extra
                                        strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" ' Par_linea
                                        strFila &= "" & "|" 'Porcentaje
                                        strFila &= ((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant)) & "|" ' Total
                                        strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                        strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                        strFila &= "" & "|" ' Verificador
                                        strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                        SumaPaquetes = SumaPaquetes + 1
                                        strFila &= SumaPaquetes  'Paquetes

                                        AnioDoc = frm.ListaClientes.Rows(i).Cells(9).Value
                                        NumDoc = frm.ListaClientes.Rows(i).Cells(8).Value
                                        LinDoc = frm.ListaClientes.Rows(i).Cells(10).Value
                                    End If
                                Else
                                    strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                    strFila &= 47 & "|" 'Catalogo
                                    strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                    strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                    strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                    strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                    strFila &= "" & "|" 'Clasificacion
                                    strFila &= frm.ListaClientes.Rows(i).Cells(6).Value & "|" ' Costo
                                    sumaCant = sumaCant + frm.ListaClientes.Rows(i).Cells(5).Value
                                    strFila &= sumaCant.ToString(FMT_MSO_DIGITO) & "|" 'Cantidad
                                    strFila &= INT_CERO & "|" 'Extra
                                    strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" ' Par_linea
                                    strFila &= "" & "|" 'Porcentaje
                                    strFila &= ((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant)) & "|" ' Total
                                    strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                    strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                    strFila &= "" & "|" ' Verificador
                                    strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                    SumaPaquetes = SumaPaquetes + 1
                                    strFila &= SumaPaquetes  'Paquetes

                                    AnioDoc = frm.ListaClientes.Rows(i).Cells(9).Value
                                    NumDoc = frm.ListaClientes.Rows(i).Cells(8).Value
                                    LinDoc = frm.ListaClientes.Rows(i).Cells(10).Value
                                End If
                            End If

                        End If
                    End If
                Next
                If strFila <> STR_VACIO Then
                    cFunciones.AgregarFila(dgProducto, strFila)
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub DescargoAutomatico()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim i As Integer
        Dim Verificador As Double = 0
        Dim Quantity As Integer

        Try
            For i = 0 To dgCostoFijo.Rows.Count - 1
                strSQL = SQLDescargoAutomatico(i)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                dgProducto.Rows.Clear()
                If REA.HasRows Then
                    Verificador = dgCostoFijo.Rows(i).Cells("colCantidadFijo").Value
                    Do While REA.Read
                        strFila = celdaAnio.Text & "|"
                        If NumProceso = 1 Then
                            strFila &= 47 & "|" 'catalogo 47 si el proceso es BlowrRoom, de lo contrario será 952 
                        Else
                            strFila &= 952 & "|" 'catalogo
                        End If
                        strFila &= REA.GetInt32("Numero") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        strFila &= 0 & "|"
                        strFila &= REA.GetString("Descripcion") & "|"
                        strFila &= REA.GetString("Clasificacion") & "|"
                        strFila &= REA.GetDouble("Costo").ToString(FORMATO_MONEDA) & "|"

                        If Verificador <= REA.GetDouble("saldo") And Verificador = 0 Then
                            Quantity = dgCostoFijo.Rows(i).Cells("colCantidadFijo").Value
                            strFila &= Quantity & "|"
                            Verificador = Verificador - dgCostoFijo.Rows(i).Cells("colCantidadFijo").Value

                            'Exit Do
                        ElseIf Verificador > REA.GetDouble("saldo") Then
                            Quantity = REA.GetDouble("saldo")
                            strFila &= Quantity & "|"
                            Verificador = Verificador - REA.GetDouble("saldo")
                        ElseIf Verificador <= REA.GetDouble("saldo") Then
                            Quantity = Verificador
                            strFila &= Quantity & "|"
                            Verificador = Verificador - Quantity

                            'Exit Do
                            'If Verificador > 0 Then
                            '    strFila &= REA.GetDouble("saldo") & "|"
                            '    Verificador = Verificador - REA.GetDouble("saldo")
                            'Else

                            'End If

                        End If
                        strFila &= 0 & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= 0 & "|" 'ya no lo uso
                        strFila &= (REA.GetDouble("Costo") * Quantity).ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetInt32("UMedida") & "|"
                        If REA.GetInt32("UMedida") = 69 Then
                            strFila &= "LBS"
                        ElseIf REA.GetInt32("UMedida") = 70 Then
                            strFila &= "KGS"
                        End If

                        cFunciones.AgregarFila(dgProducto, strFila)
                        If Verificador = 0 Then
                            Exit Do
                        End If
                    Loop
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub LimpiarCampos()
        dtpFecha.Text = cfun.HoyMySQL
        celdaFecha.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        celdaNumero.Text = NO_FILA
        celdareferencia.Clear()
        celdaCatalogo.Text = 952
        celdaAnio.Text = cfun.AñoMySQL
        celdaEmpresa.Text = Sesion.IdEmpresa
        etiquetaInactivo.Visible = False

        dgProducto.Rows.Clear()
        dgCostos.Rows.Clear()
        dgCostoFijo.Rows.Clear()
        dgBultos.Rows.Clear()

        celdaIdProyecto.Clear()
        celdaIDTarea.Clear()
        celdaOrden.Clear()
        celdaEntrada.Clear()
        celdaHilo.Clear()
        celdaCantidad.Text = INT_CERO
        celdaIdProducto.Clear()
        celdaTotalBultos.Clear()
        celdaTotalLibras.Clear()

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            panelDetalle.Visible = False
            panelDetalle.Dock = DockStyle.None
            If NumProceso = 1 Then
                BarraTitulo1.CambiarTitulo("Production Phase 1")
            Else
                BarraTitulo1.CambiarTitulo("Production Phase 2")
            End If
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

            dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
            dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            ListaPrincipal()

            Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDetalle.Visible = True
            panelDetalle.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                LimpiarCampos()
                'CargarCostos()
                ColocaMoneda()
            End If

        End If

    End Sub


    'Private Sub VerProyectosYTareas()
    '    Dim frm As New frmSeleccionar 'frmSeleccionar que me muestra los proyectos disponibles
    '    Dim strFila As String = STR_VACIO
    '    Dim condicion As String = STR_VACIO
    '    Dim idFlujo As Integer

    '    Try

    '        condicion = " Empresa = 15 "
    '        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)

    '        frm.Titulo = "Select a Project"
    '        frm.Campos = " idProyecto, idFlujo, Nombre, Descripcion "
    '        frm.Tabla = " Proyecto "
    '        frm.Condicion = condicion
    '        frm.FiltroText = " Enter the desired project name "
    '        frm.Filtro = " Nombre "
    '        frm.Ordenamiento = " idProyecto "

    '        frm.ShowDialog(Me)

    '        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
    '            idFlujo = frm.Dato 'captura el idFlujo que sirve para el siguiente frmSeleccionar
    '        End If

    '        Dim frmF As New frmSeleccionar ' frmSeleccionar que me muestra el Detalle de Flujo del Flujo Selecciodo

    '        condicion = STR_VACIO 'Vacia el valor que trae la variable

    '        condicion = " t.Empresa = {empresa} and t.idProyecto = {id} and t.idFlujoDet = fd.idFlujoDet  "
    '        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
    '        condicion = Replace(condicion, "{id}", idFlujo)

    '        frmF.Titulo = " Select the task you want to perform "
    '        frmF.Campos = " t.idProyecto, t.idTareas , t.responsable, fd.Comentario, t.`Status`,fd.Orden  "
    '        frmF.Tabla = "Tareas t Left Join Proyecto p ON p.Empresa = t.Empresa and p.idProyecto = t.IdProyecto Left Join Flujos f ON f.Empresa = p.Empresa and f.idFlujo = p.idFlujo Left Join Flujo_Detalle fd ON fd.Empresa = f.Empresa and fd.idFlujo = f.idFlujo  "
    '        frmF.Condicion = condicion
    '        frmF.FiltroText = " Enter the name of the job "
    '        frmF.Filtro = " Comentario "
    '        frmF.Ordenamiento = " Orden "

    '        frmF.ShowDialog(Me)

    '        If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
    '            celdaIdProyecto.Text = frmF.ListaClientes.SelectedCells(0).Value
    '            celdaIDTarea.Text = frmF.ListaClientes.SelectedCells(1).Value
    '            celdaOrden.Text = frmF.ListaClientes.SelectedCells(5).Value
    '        End If

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try
    'End Sub

    Private Sub frmProduccion_Load(sender As Object, e As EventArgs) Handles Me.Load
        MostrarLista()
        etiquetaTitulos.Visible = False
        If NumProceso = 2 Then
            'etiquetaTitulos.Visible = True
            'etiquetaTitulos.Text = "Ingrese el Titulo del Hilo"
            'celdaHilo.Visible = True
            PanelCostoFijo.Visible = False
            dgBultos.Visible = False
            etiquetaCantidad.Visible = False
            celdaCantidad.Visible = False
            'celdaCantidad.Visible = True
            'celdaHilo.BackColor = Color.WhiteSmoke
            'botonConvertir.Visible = True
            'botonModificar.Visible = True

            'ElseIf NumProceso > 4 Then
            '    etiquetaTitulos.Visible = True
            '    If NumProceso = 5 Then
            '        etiquetaTitulos.Text = "Ingrese el Titulo del Hilo"
            '    End If
            '    If NumProceso = 6 Then
            '        etiquetaTitulos.Text = ""
            '    End If
            '    If NumProceso = 7 Then
            '        etiquetaTitulos.Visible = False
            '        celdaHilo.Visible = False
            '        etiquetaCantidad.Visible = True
            '        celdaCantidad.Visible = True
            '    End If
            '    If NumProceso = 8 Then
            '        etiquetaTitulos.Visible = False
            '        celdaHilo.Visible = False
            '    End If
            '    celdaHilo.Text = Visible
            '    botonConvertir.Visible = False
            '    botonModificar.Visible = False
            'Else
            'celdaHilo.Visible = False
            '    botonConvertir.Visible = False
            '    botonModificar.Visible = False
        End If
    End Sub


    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0

        Try

            If celdaHilo.Text = vbNullString Then
                Comprobar = False
                Exit Function
            End If


            If celdaCantidad.Text.Length = 0 Then
                Comprobar = False
                Exit Function
            End If



            If dgProducto.RowCount > 0 Then 'comprueba que el datagrid de Productos tengo al menos 1 Linea

                For i = 0 To dgProducto.Rows.Count - 1
                    If dgProducto.Rows(i).Cells("col_ExtraProd").Value < 2 Then
                        If dgProducto.Rows(i).Cells("col_CantidadProd").Value > 0 Then 'La cantidad debe ser ingresada de lo contrario no se permitirá guardar
                        Else
                            Comprobar = False
                            Exit Function
                        End If
                    End If

                    If CDbl(dgProducto.Rows(i).Cells("col_CantidadProd").Value) > CDbl(CompararSaldo(i)) Then
                        MsgBox("You can not enter an amount greater than the Balance", vbCritical, "Notice")
                        Comprobar = False
                        Exit Function

                    End If
                Next

            Else
                Comprobar = False
                Exit Function
            End If

            'If dgCostos.RowCount > 0 Then ' Comprueba que el datagrid de costos que dependen del tiempo tenga al menos 1 linea
            '    For i = 0 To dgCostos.Rows.Count - 1
            '        If dgCostos.Rows(i).Cells("col_ExtraCosto").Value < 2 Then
            '            If dgCostos.Rows(i).Cells("col_CantidadCosto").Value > 0 Then ' la cantidad debe ser mayor a 0
            '            Else
            '                Comprobar = False
            '                Exit Function
            '            End If
            '        End If

            '    Next
            'Else
            '    Comprobar = False
            '    Exit Function
            'End If

            'If dgCostoFijo.RowCount > 0 Then ' Comprueba que el datagrid de costos fijos tenga al menos 1 linea
            '    For i = 0 To dgCostoFijo.Rows.Count - 1
            '        If dgCostoFijo.Rows(i).Cells("col_ExtraCostoFijo").Value < 2 Then
            '            If dgCostoFijo.Rows(i).Cells("col_CantidadCostoFijo").Value > 0 Then ' la cantidad debe ser mayor a 0

            '            Else
            '                Comprobar = False
            '                Exit Function
            '            End If
            '        End If

            '    Next
            'Else
            '    Comprobar = False
            '    Exit Function
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Comprobar

    End Function

    Private Function GuardarEncabezado() As Boolean
        Dim LogResultado As Boolean = True
        Dim hdr As New clsDcmtos_HDR

        Try
            hdr.CONEXION = strConexion

            hdr.HDOC_SIS_EMP = celdaEmpresa.Text
            hdr.HDOC_DOC_CAT = celdaCatalogo.Text ' Catalogo 952
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.HDoc_Doc_Fec_NET = celdaFecha.Text
            hdr.HDOC_DR1_NUM = celdareferencia.Text
            hdr.HDOC_PRO_DNUM = NumProceso
            hdr.HDOC_DOC_MON = celdaIdMoneda.Text
            hdr.HDOC_DOC_TC = celdaTasa.Text
            hdr.HDOC_RF2_NUM = celdaIdProducto.Text
            hdr.HDOC_RF2_TXT = celdaHilo.Text
            hdr.HDOC_USUARIO = Sesion.Usuario
            If Me.Tag = "Nuevo" Then
                hdr.HDOC_DOC_STATUS = INT_UNO 'Guarda HDR como 1 (no Iniciado)
                etiquetaInactivo.Visible = False
            Else
                hdr.HDOC_DOC_STATUS = VerBotonesEntrada(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)
            End If

            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If hdr.Guardar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado
    End Function

    Private Function GuardarProducto() As Boolean
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim j As Integer
        Dim CantTotal As Double = 0
        Dim UnidadMedida As Integer = 0

        Dim dtl As New clsDcmtos_DTL

        Try
            'If NumProceso = 2 Then 'Drawing
            '    Dim dec As New Tablas.TDCMTOS_DEC

            '    For i = 0 To dgProducto.Rows.Count - 1

            '        If CDbl(dgProducto.Rows(i).Cells("col_CantidadProd").Value) > CDbl(CompararSaldo(i)) Then
            '            MsgBox("You can not enter an amount greater than the Balance", vbCritical, "Notice")
            '            LogResultado = False
            '            Exit Function

            '        End If

            '        UnidadMedida = dgProducto.Rows(i).Cells("col_IdMedidaProd").Value
            '        'Guarda el descargo de Fibra Cardada y Peinada
            '        dec.EDOC_SIS_EMP = Sesion.IdEmpresa
            '        dec.EDOC_DOC_CAT = celdaCatalogo.Text
            '        dec.EDOC_DOC_ANO = celdaAnio.Text
            '        dec.EDOC_DOC_NUM = celdaNumero.Text
            '        dec.EDOC_LIN_GROSS = dgProducto.Rows(i).Cells("col_CodigoProd").Value
            '        dec.EDOC_LIN_DESC = dgProducto.Rows(i).Cells("col_DescripcionProd").Value
            '        dec.EDOC_LIN_REF = dgProducto.Rows(i).Cells("col_ClasificacionProd").Value
            '        dec.EDOC_LIN_CARGOS = dgProducto.Rows(i).Cells("col_CostoProd").Value
            '        dec.EDOC_LIN_NET = dgProducto.Rows(i).Cells("col_CantidadProd").Value
            '        dec.EDOC_LIN_DAI = UnidadMedida
            '        dec.EDOC_LIN_FRAC = dgProducto.Rows(i).Cells("col_ReferenciaProd").Value
            '        CantTotal = CantTotal + dgProducto.Rows(i).Cells("col_CantidadProd").Value

            '        If celdaCantidad.Visible = False Then
            '            dec.EDOC_LIN_FOB = CantTotal
            '        Else
            '            dec.EDOC_LIN_FOB = celdaCantidad.Text
            '        End If


            '        If dgProducto.Rows(i).Cells("col_ExtraProd").Value = 0 Then '0 es Nuevo, 1 es modificación
            '            dgProducto.Rows(i).Cells("col_LineaProd").Value = NuevaLineaDEC()
            '            dec.EDOC_DOC_LIN = dgProducto.Rows(i).Cells("col_LineaProd").Value
            '        Else
            '            dec.EDOC_DOC_LIN = dgProducto.Rows(i).Cells("col_LineaProd").Value
            '        End If

            '        dec.CONEXION = strConexion
            '        If dgProducto.Rows(i).Cells("col_ExtraProd").Value = 1 Then
            '            'If dec.PUPDATE() = False Then
            '            '    MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            '            'End If
            '        ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 0 Then
            '            If dec.PINSERT() = False Then
            '                MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            '            End If
            '        ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 2 Then
            '            If dec.PDELETE() = False Then
            '                MsgBox(dtl.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
            '            End If
            '        End If

            '    Next

            '    'Guarda la Mezcla en DTL
            '    dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
            '    dtl.DDOC_DOC_CAT = celdaCatalogo.Text
            '    dtl.DDOC_DOC_ANO = celdaAnio.Text
            '    dtl.DDOC_DOC_NUM = celdaNumero.Text
            '    dtl.DDOC_PRD_COD = INT_CERO
            '    dtl.DDOC_PRD_DES = celdaHilo.Text
            '    'dtl.DDOC_RF1_TXT = "MEZCLA"
            '    dtl.DDOC_PRD_PUQ = INT_CERO
            '    dtl.DDOC_PRD_QTY = CantTotal
            '    dtl.DDOC_DOC_LIN = INT_UNO
            '    dtl.DDOC_PRD_UM = UnidadMedida

            '    If celdaCantidad.Visible = False Then
            '        dtl.DDOC_RF1_DBL = CantTotal
            '    Else
            '        dtl.DDOC_RF1_DBL = celdaCantidad.Text
            '    End If

            '    dtl.DDOC_PRD_NET = CalcularTotales()

            '    If Me.Tag = "Nuevo" Then
            '        If dtl.Guardar() = False Then
            '            MsgBox(dtl.MERROR.ToString)
            '        End If
            '    Else
            '        If dtl.Actualizar = False Then
            '            MsgBox(dtl.MERROR.ToString)
            '        End If

            '    End If


            'Else

            For i = 0 To dgProducto.Rows.Count - 1


                dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                    dtl.DDOC_DOC_CAT = celdaCatalogo.Text
                    dtl.DDOC_DOC_ANO = celdaAnio.Text
                    dtl.DDOC_DOC_NUM = celdaNumero.Text
                    dtl.DDOC_PRD_COD = dgProducto.Rows(i).Cells("col_CodigoProd").Value
                    dtl.DDOC_PRD_UM = dgProducto.Rows(i).Cells("col_IdMedidaProd").Value
                    dtl.DDOC_RF1_COD = dgProducto.Rows(i).Cells("col_ReferenciaProd").Value

                If NumProceso = 1 Then
                    If celdaIdProducto.Text = 5 Then
                        dtl.DDOC_RF1_NUM = 13
                    ElseIf celdaIdProducto.Text = 6 Then
                        dtl.DDOC_RF1_NUM = 14
                    ElseIf celdaIdProducto.Text = 7 Then
                        dtl.DDOC_RF1_NUM = 162
                    ElseIf celdaIdProducto.Text = 8 Then
                        dtl.DDOC_RF1_NUM = 414
                    ElseIf celdaIdProducto.Text = 9 Then
                        dtl.DDOC_RF1_NUM = 241

                    End If


                    'ElseIf celdaIdProducto.Text = 5 Then
                    '    dtl.DDOC_RF1_NUM = 14
                End If

                    If NumProceso = 1 Then
                        dtl.DDOC_PRD_DES = dgProducto.Rows(i).Cells("col_DescripcionProd").Value

                    ElseIf NumProceso = 2 Then

                        dtl.DDOC_PRD_DES = celdaHilo.Text

                    End If

                    dtl.DDOC_RF1_TXT = dgProducto.Rows(i).Cells("col_ClasificacionProd").Value
                    dtl.DDOC_PRD_PUQ = dgProducto.Rows(i).Cells("col_CostoProd").Value
                    dtl.DDOC_PRD_QTY = dgProducto.Rows(i).Cells("col_CantidadProd").Value

                    If celdaCantidad.Visible = False Then
                        dtl.DDOC_RF1_DBL = dgProducto.Rows(i).Cells("col_CantidadProd").Value
                    Else
                        dtl.DDOC_RF1_DBL = celdaCantidad.Text
                    End If

                dtl.DDOC_PRD_NET = 0 'CalcularTotales()


                If dgProducto.Rows(i).Cells("col_ExtraProd").Value = 0 Then '0 es Nuevo, 1 es modificación
                        dgProducto.Rows(i).Cells("col_LineaProd").Value = NuevaLineaDTL()
                        dtl.DDOC_DOC_LIN = dgProducto.Rows(i).Cells("col_LineaProd").Value

                        'Recorre el dgBultos (oculto) verifica la llave y coloca el numero de Linea que corresponde a cada llave
                        For j = 0 To dgBultos.Rows.Count - 1
                            If dgProducto.Rows(i).Cells("col_AnioProd").Value = dgBultos.Rows(j).Cells("colAnioB").Value And dgProducto.Rows(i).Cells("col_NumeroProd").Value = dgBultos.Rows(j).Cells("colNumeroB").Value And dgProducto.Rows(i).Cells("col_ParLineaProd").Value = dgBultos.Rows(j).Cells("colLineaB").Value Then
                                dgBultos.Rows(j).Cells("colLineaDocumentoB").Value = dgProducto.Rows(i).Cells("col_LineaProd").Value
                            End If
                        Next
                    Else
                        dtl.DDOC_DOC_LIN = dgProducto.Rows(i).Cells("col_LineaProd").Value
                        For j = 0 To dgBultos.Rows.Count - 1
                            If dgProducto.Rows(i).Cells("col_AnioProd").Value = dgBultos.Rows(j).Cells("colAnioB").Value And dgProducto.Rows(i).Cells("col_NumeroProd").Value = dgBultos.Rows(j).Cells("colNumeroB").Value And dgProducto.Rows(i).Cells("col_ParLineaProd").Value = dgBultos.Rows(j).Cells("colLineaB").Value Then
                                dgBultos.Rows(j).Cells("colLineaDocumentoB").Value = dgProducto.Rows(i).Cells("col_LineaProd").Value
                            End If
                        Next
                    End If

                    If dgProducto.Rows(i).Cells("col_ExtraProd").Value = 1 Then
                        If dtl.Actualizar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 0 Then
                        If dtl.Guardar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 2 Then
                        If dtl.Borrar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could Not delete the document", MsgBoxStyle.Critical)
                        End If
                    End If

                Next
            'End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado

    End Function


    Private Function GuardarDescargos() As Boolean
        Dim logResultado As Boolean = True
        Dim i As Integer
        Dim pro As New clsDcmtos_DTL_Pro

        Try
            For i = 0 To dgProducto.Rows.Count - 1
                pro.PDOC_SIS_EMP = celdaEmpresa.Text
                pro.PDOC_PAR_CAT = dgProducto.Rows(i).Cells("col_CatalogoProd").Value
                pro.PDOC_PAR_ANO = dgProducto.Rows(i).Cells("col_AnioProd").Value
                pro.PDOC_PAR_NUM = dgProducto.Rows(i).Cells("col_NumeroProd").Value
                pro.PDOC_PAR_LIN = dgProducto.Rows(i).Cells("col_ParLineaProd").Value  ' Que linea debe guardar aqui????????????????????
                pro.PDOC_CHI_CAT = celdaCatalogo.Text
                pro.PDOC_CHI_ANO = celdaAnio.Text
                pro.PDOC_CHI_NUM = celdaNumero.Text
                pro.PDOC_CHI_LIN = dgProducto.Rows(i).Cells("col_LineaProd").Value
                pro.PDOC_QTY_PRO = dgProducto.Rows(i).Cells("col_CantidadProd").Value

                If dgProducto.Rows(i).Cells("col_ExtraProd").Value = 1 Then
                    If pro.Actualizar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 0 Then
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 2 Then
                    If pro.Borrar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function GuardarCostos() As Boolean
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim imp As New Tablas.TDCMTOS_IMP
        Try
            For i = 0 To dgCostos.Rows.Count - 1
                imp.MDOC_SIS_EMP = celdaEmpresa.Text
                imp.MDOC_DOC_CAT = celdaCatalogo.Text
                imp.MDOC_DOC_ANO = celdaAnio.Text
                imp.MDOC_DOC_NUM = celdaNumero.Text
                imp.MDOC_DOC_LIN = dgCostos.Rows(i).Cells("colLinea").Value
                imp.MDOC_LIN_ID = dgCostos.Rows(i).Cells("colCodigo").Value
                imp.MDOC_LIN_MONTO = dgCostos.Rows(i).Cells("colCosto").Value

                imp.CONEXION = strConexion

                If Me.Tag = "Nuevo" Then
                    If imp.PINSERT = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                Else
                    If imp.PUPDATE = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado
    End Function

    Private Function GuardarBultos() As Boolean
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim box As New Tablas.TDCMTOS_DTL_BOX

        Try
            For i = 0 To dgProducto.Rows.Count - 1
                box.BDOC_SIS_EMP = Sesion.IdEmpresa
                box.BDOC_DOC_CAT = celdaCatalogo.Text
                box.BDOC_DOC_ANO = celdaAnio.Text
                box.BDOC_DOC_NUM = celdaNumero.Text
                box.BDOC_DOC_LIN = dgProducto.Rows(i).Cells("col_LineaProd").Value
                box.BDOC_BOX_COD = celdareferencia.Text
                box.BDOC_BOX_QTY = dgProducto.Rows(i).Cells("col_BultosProd").Value
                box.BDOC_BOX_LB = dgProducto.Rows(i).Cells("col_CantidadProd").Value

                box.CONEXION = strConexion
                If dgProducto.Rows(i).Cells("col_ExtraProd").Value = 1 Then
                    If box.PUPDATE() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 0 Then
                    If box.PINSERT() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgProducto.Rows(i).Cells("col_ExtraProd").Value = 2 Then
                    If box.PDELETE() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado
    End Function

    Private Function GuardarDetalleBultos()
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim DetBox As New Tablas.TDCMTOS_DTL_BOX_PRO

        Try
            For i = 0 To dgBultos.Rows.Count - 1
                DetBox.BPDOC_SIS_EMP = Sesion.IdEmpresa
                DetBox.BPDOC_PAR_CAT = dgBultos.Rows(i).Cells("colCatalogoB").Value
                DetBox.BPDOC_PAR_ANO = dgBultos.Rows(i).Cells("colAnioB").Value
                DetBox.BPDOC_PAR_NUM = dgBultos.Rows(i).Cells("colNumeroB").Value
                DetBox.BPDOC_PAR_LIN = dgBultos.Rows(i).Cells("colLineaB").Value
                DetBox.BPDOC_BOX_LIN = dgBultos.Rows(i).Cells("colBultoB").Value
                DetBox.BPDOC_CHI_CAT = celdaCatalogo.Text
                DetBox.BPDOC_CHI_ANO = celdaAnio.Text
                DetBox.BPDOC_CHI_NUM = celdaNumero.Text
                DetBox.BPDOC_CHI_LIN = dgBultos.Rows(i).Cells("colLineaDocumentoB").Value

                DetBox.CONEXION = strConexion

                If dgBultos.Rows(i).Cells("colExtraB").Value = 0 Then
                    If DetBox.PINSERT = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgBultos.Rows(i).Cells("colExtraB").Value = 1 Then
                    '    If DetBox.PUPDATE = False Then
                    '        MsgBox(DetBox.MERROR.ToString & "Could Not Update the document", MsgBoxStyle.Critical)
                    '    End If
                ElseIf dgBultos.Rows(i).Cells("colExtraB").Value = 2 Then
                    If DetBox.PDELETE = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not Delete the document", MsgBoxStyle.Critical)
                    End If

                ElseIf dgBultos.Rows(i).Cells("colExtraB").Value = 3 Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Par_Cat = {catP} AND BPDoc_Par_Ano = {anioP} AND BPDoc_Par_Num ={numP} AND BPDoc_Par_Lin = {LinP} AND BPDoc_Chi_Cat = {catC} AND BPDoc_Chi_Ano = {anioC} AND BPDoc_Chi_Num = {numC} AND BPDoc_Chi_Lin ={LinC} "

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{catP}", dgBultos.Rows(i).Cells("colCatalogoB").Value)
                    strSQL = Replace(strSQL, "{anioP}", dgBultos.Rows(i).Cells("colAnioB").Value)
                    strSQL = Replace(strSQL, "{numP}", dgBultos.Rows(i).Cells("colNumeroB").Value)
                    strSQL = Replace(strSQL, "{LinP}", dgBultos.Rows(i).Cells("colLineaB").Value)
                    strSQL = Replace(strSQL, "{catC}", celdaCatalogo.Text)
                    strSQL = Replace(strSQL, "{anioC}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numC}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{LinC}", dgBultos.Rows(i).Cells("colLineaDocumentoB").Value)

                    Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                    box.CONEXION = strConexion
                    box.PDELETE(strSQL)

                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function

    Private Function GuardarCostosTiempo() As Boolean
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim imp As New Tablas.TDCMTOS_IMP
        Try
            For i = 0 To dgCostos.Rows.Count - 1
                imp.MDOC_SIS_EMP = celdaEmpresa.Text
                imp.MDOC_DOC_CAT = celdaCatalogo.Text
                imp.MDOC_DOC_ANO = celdaAnio.Text
                imp.MDOC_DOC_NUM = celdaNumero.Text
                'imp.MDOC_DOC_LIN = dgCostoTiempo.Rows(i).Cells("col_LineaCosto").Value
                imp.MDOC_LIN_CODIGO = dgCostos.Rows(i).Cells("col_CodigoCosto").Value
                imp.MDOC_LIN_CANTIDAD = dgCostos.Rows(i).Cells("col_CantidadCosto").Value
                imp.MDOC_LIN_MONTO = dgCostos.Rows(i).Cells("col_CostoCosto").Value

                If dgCostos.Rows(i).Cells("col_LineaCosto").Value = 0 Then '0 = Nueva(Inserta), 1= Actualizar, 2 = Elimina
                    dgCostos.Rows(i).Cells("col_LineaCosto").Value = NuevaLineaIMP()
                    imp.MDOC_DOC_LIN = dgCostos.Rows(i).Cells("col_LineaCosto").Value
                Else
                    imp.MDOC_DOC_LIN = dgCostos.Rows(i).Cells("col_LineaCosto").Value
                End If

                imp.CONEXION = strConexion

                If dgCostos.Rows(i).Cells("col_ExtraCosto").Value = 0 Then
                    If imp.PINSERT = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If

                ElseIf dgCostos.Rows(i).Cells("col_ExtraCosto").Value = 1 Then
                    If imp.PUPDATE = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If

                ElseIf dgCostos.Rows(i).Cells("col_ExtraCosto").Value = 2 Then
                    If imp.PDELETE = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function


    Private Function GuardarCostosFijos() As Boolean
        Dim logResultado As Boolean = True
        Dim i As Integer
        Dim imp As New Tablas.TDCMTOS_IMP

        Try
            For i = 0 To dgCostoFijo.Rows.Count - 1
                imp.MDOC_SIS_EMP = celdaEmpresa.Text
                imp.MDOC_DOC_CAT = celdaCatalogo.Text
                imp.MDOC_DOC_ANO = celdaAnio.Text
                imp.MDOC_DOC_NUM = celdaNumero.Text
                'imp.MDOC_DOC_LIN = dgCostoFijo.Rows(i).Cells("col_LineaCostoFijo").Value
                imp.MDOC_LIN_CODIGO = dgCostoFijo.Rows(i).Cells("col_CodigoCostoFijo").Value
                imp.MDOC_LIN_CANTIDAD = dgCostoFijo.Rows(i).Cells("col_CantidadCostoFijo").Value
                imp.MDOC_LIN_MONTO = dgCostoFijo.Rows(i).Cells("col_CostoCostoFijo").Value

                If dgCostoFijo.Rows(i).Cells("col_LineaCostoFijo").Value = 0 Then '0 = Nueva(Inserta), 1= Actualizar, 2 = Elimina
                    dgCostoFijo.Rows(i).Cells("col_LineaCostoFijo").Value = NuevaLineaIMP()
                    imp.MDOC_DOC_LIN = dgCostoFijo.Rows(i).Cells("col_LineaCostoFijo").Value
                Else
                    imp.MDOC_DOC_LIN = dgCostoFijo.Rows(i).Cells("col_LineaCostoFijo").Value
                End If

                imp.CONEXION = strConexion
                If dgCostoFijo.Rows(i).Cells("col_ExtraCostoFijo").Value = 0 Then
                    If imp.PINSERT = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If

                ElseIf dgCostoFijo.Rows(i).Cells("col_ExtraCostoFijo").Value = 1 Then
                    If imp.PUPDATE = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If

                ElseIf dgCostoFijo.Rows(i).Cells("col_ExtraCostoFijo").Value = 2 Then
                    If imp.PDELETE = False Then
                        MsgBox(imp.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function


    Private Function GuardarEntradas() As Boolean
        Dim logResultado As Boolean = True
        Dim ent As New Tablas.TENTRADAS

        Try
            ent.EMPRESA = CInt(celdaEmpresa.Text)
            ent.IDENTRADA = NuevaIDEntrada()
            ent.IDTAREA = CInt(celdaAnio.Text) ' Campo IdTarea va a almacenar el año (solo en el modulo de Produccion)
            ent.IDPROYECTO = CInt(celdaNumero.Text) ' Campo idProyecto va a almacenar el numero (solo en el modulo de Produccion)
            ent.USUARIO = Sesion.Usuario
            ent.Inicio_NET = cFunciones.HoyMySQL
            ent.FIN = Nothing

            ent.CONEXION = strConexion
            If ent.PINSERT() = False Then
                MsgBox(ent.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Private Function ActualizarTareas(Optional ByVal Finalizar As Boolean = False)

    '    Dim strSQL As String = STR_VACIO
    '    Dim COM As New MySqlCommand
    '    Dim conec As New MySqlConnection

    '    Try

    '        If Finalizar = False Then
    '            strSQL = " UPDATE Tareas SET catalogo = {catalogo} , ano = {anio}, numero = {numero}, Status = 'En proceso' WHERE Empresa = {empresa} AND idProyecto = {proyecto} AND idTareas = {tarea} "

    '            ' Remplaza los valores que se van a actualizar
    '            strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
    '            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
    '            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

    '        ElseIf Finalizar = True Then
    '            strSQL = " UPDATE Tareas SET Status = 'Finalizado' WHERE Empresa = {empresa} AND idProyecto = {proyecto} AND idTareas = {tarea} "

    '        End If

    '        ' Remplaza el where
    '        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
    '        strSQL = Replace(strSQL, "{proyecto}", celdaIdProyecto.Text)
    '        strSQL = Replace(strSQL, "{tarea}", celdaIDTarea.Text)

    '        conec = New MySqlConnection(strConexion)
    '        conec.Open()
    '        COM = New MySqlCommand(strSQL, conec)

    '    Catch ex As Exception
    '        MsgBox(ex.ToString)
    '    End Try

    '    Return COM.ExecuteNonQuery()

    'End Function

    Private Function ActualizarEntradas()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try

            strSQL = " UPDATE Entradas e SET e.Fin = {fin}  WHERE Empresa = {empresa} AND idProyecto = {proyecto} AND idTarea = {tarea} AND e.Fin is null "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= strSQL = "; UPDATE PDM.Entradas e SET e.Fin = {fin}  WHERE Empresa = {empresa} AND idProyecto = {proyecto} AND idTarea = {tarea} AND e.Fin is null "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{proyecto}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{tarea}", celdaAnio.Text)

            strSQL = Replace(strSQL, "{fin}", MYSQL_HOY)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Using conec
            Return COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

    End Function

    Private Function ActualizarHDR(ByVal intSatus As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try
            strSQL = " Update Dcmtos_HDR h SET h.HDoc_Doc_Status = {status} Where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 952 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; Update PDM.Dcmtos_HDR h SET h.HDoc_Doc_Status = {status} Where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 952 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero} "
            End If
            strSQL = Replace(strSQL, "{status}", intSatus)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Using conec
            Return COM.ExecuteNonQuery
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function

    Private Sub DeleteBoxPro()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "BPDoc_Chi_Cat = 952 AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {numero}"

            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
            box.CONEXION = strConexion
            box.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ActualizarDTL(ByVal fin As Double)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try
            strSQL = " UPDATE Dcmtos_DTL d SET d.DDoc_Prd_NET ={fin} WHERE d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 952 and d.DDoc_Doc_Ano = {anio} and d.DDoc_Doc_Num = {num} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Dcmtos_DTL d SET d.DDoc_Prd_NET ={fin} WHERE d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 952 and d.DDoc_Doc_Ano = {anio} and d.DDoc_Doc_Num = {num} "
            End If
            strSQL = Replace(strSQL, "{fin}", fin)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{num}", celdaNumero.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Using conec
            Return COM.ExecuteNonQuery
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function

    Private Function ConvertirFibraAHilo()
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim SumaTotal As Double = 0
        Dim NombreHilo As String = STR_VACIO
        Dim TituloHilo As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand
        Dim TotalPorcentajes As Double = INT_CERO
        Dim SumaPorcentajes As Double = INT_CERO

        Try

            For i = 0 To dgProducto.Rows.Count - 1
                SumaTotal = dgProducto.Rows(i).Cells("col_CantidadProd").Value + SumaTotal ' Suma las cantidades de cada Fibra
            Next

            For i = 0 To dgProducto.Rows.Count - 1


                dgProducto.Rows(i).Cells("col_PorcentajeProd").Value = ((CDbl(dgProducto.Rows(i).Cells("col_CantidadProd").Value) / SumaTotal) * 100).ToString(FORMATO_MONEDA) 'Calcula el porcentaje de cada fibra y las escribe en la columna Porcentaje del datagrid (columna que solo se usa de bandera)
                'NombreHilo = NombreHilo & dgProducto.Rows(i).Cells("col_PorcentajeProd").Value & "% " & TituloHilo
            Next

            For i = 0 To dgProducto.Rows.Count - 1
                TotalPorcentajes = 0
                strSQL = " SELECT a.art_titulo FROM Articulos a WHERE a.art_sisemp = {empresa} AND a.art_codigo = {num} "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{num}", dgProducto.Rows(i).Cells("col_CodigoProd").Value)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)

                TituloHilo = COM.ExecuteScalar 'Trae el Nombre de la fibra

                    For j = 0 To dgProducto.Rows.Count - 1
                    If dgProducto.Rows(i).Cells("col_CodigoProd").Value = dgProducto.Rows(j).Cells("col_CodigoProd").Value Then
                        If dgProducto.Rows(j).Cells("col_VerificadorProd").Value = 1 Then

                        Else
                            TotalPorcentajes = TotalPorcentajes + dgProducto.Rows(j).Cells("col_PorcentajeProd").Value
                            dgProducto.Rows(j).Cells("col_VerificadorProd").Value = 1

                        End If
                    End If
                Next
                If TotalPorcentajes = 0 Then
                Else
                    NombreHilo = NombreHilo & TotalPorcentajes & "% " & TituloHilo & " "
                End If

            Next

            For i = 0 To dgProducto.Rows.Count - 1
                dgProducto.Rows(i).Cells("col_VerificadorProd").Value = 0
            Next

            celdaHilo.Text = NombreHilo
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return NombreHilo
        conec.Close()
        conec.Dispose()
        conec = Nothing

    End Function


    Private Function CalcularTotales() 'Calcula totales de cada Datagrid
        Dim TotalProducto As Double = INT_CERO
        Dim TotalCosto As Double = INT_CERO

        ' Dim TotalHoras As Double = INT_CERO
        Dim TotalFinal As Double = INT_CERO
        'Dim CantidadFinal As Double = INT_CERO

        Dim i As Integer
        Try

            For i = 0 To dgProducto.Rows.Count - 1
                'Calcula el total de Producto (Cantidad * Costo) de cada Linea
                'dgProducto.Rows(i).Cells("col_TotalProd").Value = CDbl((dgProducto.Rows(i).Cells("col_CostoProd").Value) * (dgProducto.Rows(i).Cells("col_CantidadProd").Value))
                TotalProducto = TotalProducto + (dgProducto.Rows(i).Cells("col_TotalProd").Value) ' Hace la suma de todas las lineas
                'CantidadFinal = CantidadFinal + CDbl(dgProducto.Rows(i).Cells("col_CantidadProd").Value)
            Next



            'TotalHoras = CalcularHoras()

            For i = 0 To dgCostos.Rows.Count - 1

                TotalCosto = TotalCosto + (dgCostos.Rows(i).Cells("colCosto").Value)
            Next

            TotalFinal = ((TotalProducto + TotalCosto) / celdaCantidad.Text) 'Precio Final del Producto en el proceso actual, que será el precio Inicial del siguiente proceso


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return TotalFinal
    End Function


#End Region


#Region "Eventos"

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"

        MostrarLista(False)
        'VerProyectosYTareas()
        celdaAnio.Text = cfun.AñoMySQL
        celdaEmpresa.Text = Sesion.IdEmpresa
        'botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\16\db next.ico ")
        botonStart.Text = "Start"
        botonStart.Enabled = False
        botonStop.Enabled = False
        botonAnular.Enabled = False

        botonProducto.Visible = True
        botonEliminarProd.Visible = False
        etiquetaProduto.Visible = True
        etiquetaEliminar.Visible = False
        If NumProceso = 2 Then
            dgProducto.Columns(17).Visible = False
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf panelDetalle.Visible = True Then
            MostrarLista()
        End If
    End Sub

    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click

        If NumProceso = 1 Then
            MostrarBultosADescargar()
            SumarYContarBultos()
        ElseIf NumProceso = 2 Then
            HacerDescargo()
        End If

    End Sub

    Public Sub SumarYContarBultos()
        Dim i As Integer = 0
        Dim SumBultos As Integer = 0
        Dim SumLibras As Double = 0
        For i = 0 To dgProducto.Rows.Count - 1
            SumLibras = SumLibras + dgProducto.Rows(i).Cells("col_CantidadProd").Value
            SumBultos = SumBultos + dgProducto.Rows(i).Cells("col_BultosProd").Value

        Next
        celdaTotalLibras.Text = SumLibras.ToString(FORMATO_MONEDA)
        celdaTotalBultos.Text = SumBultos.ToString(FORMATO_MONEDA)

    End Sub




    'Muestra Gastos que dependen del Tiempo
    Private Sub botonCostoTiempo_Click(sender As Object, e As EventArgs) Handles botonCostoTiempo.Click
        Dim Frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        Frm.Titulo = "Expenses"
        Frm.Campos = " idGastos, Empresa, Nombre, Descripcion, Tipo, IFNULL(costo,0) costo "
        Frm.Tabla = " Gastos LEFT JOIN Catalogos ON cat_clase = 'Gastos' AND cat_num = Tipo "
        Frm.FiltroText = "Enter the Name Of the Expense To Filter"
        Frm.Filtro = " idGasto "
        Frm.Condicion = " Tiempo=1 " 'Si el Costo depende del tiempo es 1
        Frm.Ordenamiento = "idGastos"

        Frm.ShowDialog(Me)

        Try

            If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strFila = celdaAnio.Text & "|" 'año
                strFila &= celdaCatalogo.Text & "|" ' catalogo
                strFila &= Frm.ListaClientes.SelectedCells(0).Value & "|" ' codigo
                strFila &= Frm.ListaClientes.SelectedCells(3).Value & "|" ' Descripcion
                strFila &= Frm.ListaClientes.SelectedCells(2).Value & "|" ' Clasificacion
                strFila &= Frm.ListaClientes.SelectedCells(5).Value & "|" ' Costo
                strFila &= INT_CERO & "|" ' Cantidad
                strFila &= INT_CERO & "|" 'Extra
                strFila &= INT_CERO 'Linea

                cFunciones.AgregarFila(dgCostos, strFila) 'agrega los valores del frmSeleccionar al dg del frmProdución
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    ' Muestra Gastos Fijos
    Private Sub botonCostoFijo_Click(sender As Object, e As EventArgs) Handles botonCostoFijo.Click
        Dim Frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        Frm.Titulo = "Expenses"
        Frm.Campos = " idGastos, Empresa, Nombre, Descripcion, Tipo, IFNULL(costo,0) costo "
        Frm.Tabla = " Gastos LEFT JOIN Catalogos ON cat_clase = 'Gastos' AND cat_num = Tipo "
        Frm.FiltroText = "Enter the Name Of the Expense To Filter"
        Frm.Filtro = " idGasto "
        Frm.Condicion = " Tiempo=0 " ' Si el costo no depende del tiempo es 0
        Frm.Ordenamiento = "idGastos"

        Frm.ShowDialog(Me)

        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            strFila = celdaAnio.Text & "|" 'año
            strFila &= celdaCatalogo.Text & "|" 'catalogo
            strFila &= Frm.ListaClientes.SelectedCells(0).Value & "|" 'idGasto
            strFila &= Frm.ListaClientes.SelectedCells(3).Value & "|" 'Descripcion
            strFila &= Frm.ListaClientes.SelectedCells(2).Value & "|" 'Clasificacion
            strFila &= Frm.ListaClientes.SelectedCells(5).Value & "|" 'Costo
            strFila &= INT_CERO & "|" 'Cantidad
            strFila &= INT_CERO & "|" 'extra
            strFila &= INT_CERO 'linea

            cFunciones.AgregarFila(dgCostoFijo, strFila)
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim NumLong As Long
        Dim i As Integer
        Dim clsConta As New clsContabilidad

        If Me.Tag = "Nuevo" Then
            NumLong = celdaNumero.Text
            celdaNumero.Text = cfun.Verificacion_Nuevo_Registro(NumLong, "Dcmtos", 952, celdaAnio.Text)
        End If

        If celdaNumero.Text > 0 Then
            If ComprobarCampos() = True Then
                GuardarEncabezado()
                GuardarProducto()
                GuardarDescargos()
                ' GuardarCostos() ya no se usará
                GuardarBultos()
                If NumProceso = 1 Then
                    GuardarDetalleBultos()
                End If

                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
                ElseIf Me.Tag = "Mod" Then
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
                End If
                'GuardarCostosTiempo()
                'GuardarCostosFijos()
                'ActualizarTareas()

                If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                    MostrarLista(True)
                Else
                    Me.Tag = "Mod"
                    'If VerBotonesEntrada(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 1 Then

                    '    'botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\16\db next.ico ")
                    '    botonStart.Text = "Start"
                    '    botonStop.Enabled = False
                    'Else
                    '    ' botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\db last.ico ")
                    '    botonStart.Text = "Pause"
                    '    botonStop.Enabled = True
                    'End If
                    'botonStart.Enabled = True
                    'botonAnular.Enabled = True

                    'For i = 0 To dgProducto.Rows.Count - 1
                    '    dgProducto.Rows(i).Cells("col_ExtraProd").Value = INT_UNO
                    '    If celdaCantidad.Visible = False Then
                    '        celdaCantidad.Text = celdaCantidad.Text + dgProducto.Rows(i).Cells("col_CantidadProd").Value
                    '    End If
                    'Next

                    'For i = 0 To dgCostos.Rows.Count - 1
                    '    dgCostos.Rows(i).Cells("col_ExtraCosto").Value = INT_UNO
                    'Next

                    'For i = 0 To dgCostoFijo.Rows.Count - 1
                    '    dgCostoFijo.Rows(i).Cells("col_ExtraCostoFijo").Value = INT_UNO
                    'Next

                    'Exit Sub

                End If

                If Sesion.IdEmpresa = 15 Then
                    clsConta.GenerarPoliza(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)
                End If

            Else
                MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                Exit Sub
            End If
        End If


    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        celdaFecha.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        LimpiarCampos()
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intCat As Integer

        Try
            If dgLista.Rows.Count = 0 Then Exit Sub
            Me.Tag = "Mod"

            intAnio = dgLista.SelectedCells(1).Value
            intNumero = dgLista.SelectedCells(2).Value
            intCat = dgLista.SelectedCells(0).Value

            CargarEncabezado(intAnio, intNumero)

            botonProducto.Visible = True
            botonEliminarProd.Visible = True
            etiquetaProduto.Visible = True
            etiquetaEliminar.Visible = True


            'If NumProceso = 2 Then
            '    CargarProducto_DEC(intAnio, intNumero)
            'Else
            CargarProducto(intAnio, intNumero)
            SumarYContarBultos()
            'End If

            ' CargarCostos(intAnio, intNumero)
            'RealizarEstimacion()
            CargarBultos()


            '////////////////////////////////////////////////////////////////////////////////////////////////////

            '  CODIGO QUE YA NO VOY A UTILIZAR :(

            '///////////////////////////////////////////////////////////////////////////////////////////////////

            'intEstados = VerBotonesEntrada(intCat, intAnio, intNumero)

            'If intEstados = 1 Then ' Inserta Entrada

            '    'botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\16\db next.ico ")
            '    botonStart.Text = "Start"
            '    botonStop.Enabled = False
            '    botonStart.Enabled = True
            'ElseIf intEstados = 2 Then 'Modifica Entrada
            '    If RevisarFecha(intCat, intAnio, intNumero) = 0 Then
            '        celdaEntrada.Text = 0
            '        'botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\16\db next.ico ")
            '        botonStart.Text = "Start"
            '    Else
            '        ' botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\db last.ico ")
            '        botonStart.Text = "Pause"

            '    End If
            '    botonStop.Enabled = True
            '    botonStart.Enabled = True

            'ElseIf intEstados = 3 Then
            '    'botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\16\db next.ico ")
            '    botonStart.Text = "Start"
            '    botonStart.Enabled = False
            '    botonStop.Enabled = False
            'End If

            'botonAnular.Enabled = True
            'CargarIDProyectoTarea()

            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonEliminarProd_Click(sender As Object, e As EventArgs) Handles botonEliminarProd.Click
        Dim strfila As String = STR_VACIO
        Dim i As Integer

        If NumProceso = 1 Then
            strfila = dgProducto.CurrentRow.Cells("col_CatalogoProd").Value & "|"
            strfila &= dgProducto.CurrentRow.Cells("col_AnioProd").Value & "|"
            strfila &= dgProducto.CurrentRow.Cells("col_NumeroProd").Value & "|"
            strfila &= dgProducto.CurrentRow.Cells("col_ParLineaProd").Value & "|"
            strfila &= 0 & "|"
            strfila &= dgProducto.CurrentRow.Cells("col_LineaProd").Value & "|"
            strfila &= 3 'Linea Extra

            cFunciones.AgregarFila(dgBultos, strfila)

            For i = 0 To dgBultos.Rows.Count - 1
                If dgBultos.Rows(i).Cells("colExtraB").Value = 3 Then
                    dgBultos.Rows(i).Visible = False
                End If
            Next
        End If

        dgProducto.CurrentRow.Cells("col_ExtraProd").Value = 2
        dgProducto.CurrentRow.Visible = False 'Oculta la fila y le coloca 2 a la columna Extra para cuando se guarde la elimine

    End Sub



    Private Sub dgProducto_DoubleClick(sender As Object, e As EventArgs) Handles dgProducto.DoubleClick
        If NumProceso = 2 Then
            If dgProducto.Rows.Count = 0 Then Exit Sub

            Dim frmD As New frmDescargarProducto
            Dim ModAceptado As Boolean
            Try
                Select Case dgProducto.CurrentCell.ColumnIndex
                    Case 8

                        frmD.Proceso = NumProceso

                        frmD.Code = CInt(dgProducto.CurrentRow.Cells("col_CodigoProd").Value)
                        frmD.Number = CInt(dgProducto.CurrentRow.Cells("col_NumeroProd").Value)
                        frmD.Anio = CInt(dgProducto.CurrentRow.Cells("col_AnioProd").Value)
                        frmD.Quantity = CDbl(dgProducto.CurrentRow.Cells("col_CantidadProd").Value)
                        'frmD.Medida = CInt(dgProducto.CurrentRow.Cells("col_IdMedidaProd").Value)

                        frmD.Aceptar = True

                        Me.DialogResult = System.Windows.Forms.DialogResult.OK
                        frmD.ShowDialog(Me)

                        ModAceptado = frmD.Aceptar

                        If ModAceptado = True Then
                            dgProducto.SelectedCells(8).Value = frmD.Quantity
                            dgProducto.SelectedCells(7).Value = frmD.Cost
                            dgProducto.SelectedCells(13).Value = frmD.Medida
                            If frmD.Medida = 69 Then
                                dgProducto.SelectedCells(14).Value = "LBS"
                            ElseIf frmD.Medida = 70 Then
                                dgProducto.SelectedCells(14).Value = "KGS"
                            End If
                        End If


                End Select

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If


    End Sub

    Private Sub botonEliminarCosto_Click(sender As Object, e As EventArgs) Handles botonEliminarCosto.Click
        dgCostos.CurrentRow.Cells(7).Value = 2
        'dgProducto.CurrentRow.Visible = False 'Oculta la fila y le coloca 2 a la columna Extra para cuando se guarde la elimine

    End Sub

    Private Sub botonEliminarCostoFijo_Click(sender As Object, e As EventArgs) Handles botonEliminarCostoFijo.Click
        Dim i As Integer
        Dim NuevaCantidad As Double = 0
        Dim CantidadBultos As Integer = 0

        Try

            For i = 0 To dgProducto.Rows.Count - 1
                If dgProducto.Rows(i).Cells("col_AnioProd").Value = dgBultos.CurrentRow.Cells("colAnioB").Value Then
                    If dgProducto.Rows(i).Cells("col_CatalogoProd").Value = dgBultos.CurrentRow.Cells("colCatalogoB").Value Then
                        If dgProducto.Rows(i).Cells("col_NumeroProd").Value = dgBultos.CurrentRow.Cells("colNumeroB").Value Then
                            If dgProducto.Rows(i).Cells("col_ParLineaProd").Value = dgBultos.CurrentRow.Cells("colLineaB").Value Then
                                If dgProducto.Rows(i).Cells("col_LineaProd").Value = dgBultos.CurrentRow.Cells("colLineaDocumentoB").Value Then
                                    If dgProducto.Rows(i).Cells("col_CantidadProd").Value > dgBultos.CurrentRow.Cells("colPesoB").Value Or CInt(dgProducto.Rows(i).Cells("col_BultosProd").Value > 1) Then

                                        NuevaCantidad = CDbl(dgProducto.Rows(i).Cells("col_CantidadProd").Value) - CDbl(dgBultos.CurrentRow.Cells("colPesoB").Value)
                                        CantidadBultos = CInt(dgProducto.Rows(i).Cells("col_BultosProd").Value) - 1

                                        dgBultos.CurrentRow.Cells("colExtraB").Value = 2 ' columna numero 6
                                        dgBultos.CurrentRow.Visible = False 'Oculta la fila y le coloca 2 a la columna Extra para cuando se guarde la elimine

                                        dgProducto.Rows(i).Cells("col_CantidadProd").Value = NuevaCantidad
                                        dgProducto.Rows(i).Cells("col_BultosProd").Value = CantidadBultos

                                    Else
                                        MsgBox("This bulge can not be eliminated, since it is the only bulge of the detail line, erase directly from the detail to continue", vbCritical)
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonStart_Click(sender As Object, e As EventArgs) Handles botonStart.Click
        ''''''ACTUALIZAR EL HDR CUANDO SE INICIA
        ' 0 = inactivo
        ' 1 = No iniciado
        ' 2 = En Proceso
        ' 3 = Finalizado
        If VerBotonesEntrada(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 1 Then ' 1 Insertar
            GuardarEntradas()
            ActualizarHDR(2) ' Actualiza a status 2 (En Proceso)
            ' botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\db last.ico ")
            botonStart.Text = "Pause"
            botonStop.Enabled = True
        ElseIf VerBotonesEntrada(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 2 Then ' 2 Modificar
            If RevisarFecha(celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text) = 0 Then
                GuardarEntradas()
                ' botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\db last.ico ")
                botonStart.Text = "Pause"
            Else
                ActualizarEntradas()
                ' botonStart.Image = System.Drawing.Image.FromFile(" C:\Users\Misrraim\Documents\Fer Sistema\KARIMs SGI\Resources\16\db next.ico ")
                botonStart.Text = "Start"
                celdaEntrada.Text = 0
            End If


        End If


    End Sub

    Private Sub botonStop_Click(sender As Object, e As EventArgs) Handles botonStop.Click
        Dim CalcularTotal As Double = INT_CERO
        ActualizarEntradas()
        ActualizarHDR(3) ' Actualiza a status 3 (finalizado)
        'ActualizarTareas(True)
        CalcularTotal = CalcularTotales()
        ActualizarDTL(CalcularTotal)
        botonStart.Enabled = False
        botonStop.Enabled = False
    End Sub

    Private Function VerificarStatusDescargo()
        Dim COM As New MySqlCommand
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT COUNT(*) Descargos "
            strSql &= "    From Dcmtos_DTL_Pro dp "
            strSql &= "        Left JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = dp.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = dp.PDoc_Chi_Cat AND h.HDoc_Doc_Ano = dp.PDoc_Chi_Ano AND h.HDoc_Doc_Num = dp.PDoc_Chi_Num "
            strSql &= "            WHERE dp.PDoc_Sis_Emp = {empresa} AND dp.PDoc_Par_Cat = 952 AND dp.PDoc_Par_Ano = {anio} AND dp.PDoc_Par_Num = {num} AND h.HDoc_Doc_Status= 0 "

            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{anio}", celdaAnio.Text)
            strSql = Replace(strSql, "{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            Return COM.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function
    Private Sub botonAnular_Click(sender As Object, e As EventArgs) Handles botonAnular.Click

        If NumProceso = 1 Then
            If VerificarStatusDescargo() > 0 Then
                ActualizarHDR(0) 'actualiza a status 0 (anulado)
                etiquetaInactivo.Visible = True
                DeleteBoxPro()
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
            Else
                MsgBox("The document can not be deleted, it already has releases", vbInformation, "Notice")
            End If
        ElseIf NumProceso = 2 Then
            ActualizarHDR(0) 'actualiza a status 0 (anulado)
            etiquetaInactivo.Visible = True
            cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
        End If


    End Sub

    Private Sub botonConvertir_Click(sender As Object, e As EventArgs) Handles botonConvertir.Click
        ConvertirFibraAHilo()
    End Sub

    Private Sub botonModificar_Click(sender As Object, e As EventArgs) Handles botonEstimar.Click

        'PROCESO QUE SE UTILIZABA PARA EDITAR EL NOMBRE DEL HILO (YA NO SE UTILIZARÁ
        'Dim frm As New frmAutorización
        'frm.Iniciar(514, "ALL", 0, "Authorize Hilo name")
        'frm.ShowDialog(Me)

        'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
        '    celdaHilo.Enabled = True
        'End If

        RealizarEstimacion()

    End Sub

    Private Sub panelTiempo_Paint(sender As Object, e As PaintEventArgs) Handles panelTiempo.Paint

    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



    Private Sub botonCalcular_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub dgCostos_DoubleClick(sender As Object, e As EventArgs) Handles dgCostos.DoubleClick

    End Sub

    Private Sub botonSeleccion_Click(sender As Object, e As EventArgs) Handles botonSeleccion.Click
        Dim frm As New frmSeleccionar
        Dim condicion As String = STR_VACIO

        Try

            If NumProceso = 1 Then
                condicion = "  a.art_sisemp = {empresa} AND a.art_clase =2307 "
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
            ElseIf NumProceso = 2 Then
                condicion = "  a.art_sisemp = 15 AND a.art_clase NOT IN(2307,2306,331) "
                condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
            End If

            frm.Titulo = "Fiber"
            frm.Campos = " a.art_codigo codigo, a.art_DLarga Description "
            frm.Tabla = " Articulos a LEFT JOIN Catalogos c ON c.cat_num = a.art_clase AND c.cat_clase = 'ClaseArt' "
                frm.FiltroText = " Enter the name of the fiber "
                frm.Filtro = " a.art_codigo "
            frm.Limite = 0
            frm.Ordenamiento = " a.art_codigo "
            frm.TipoOrdenamiento = ""
                frm.Condicion = condicion
            'ElseIf NumProceso = 2 Then
            'condicion = "  a.art_sisemp = {empresa} AND a.art_clase !=2209 "
            '    condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)

            '    frm.Titulo = "Fiber"
            '    frm.Campos = " a.art_codigo codigo, a.art_titulo titulo, a.art_DCorta DCorta, a.art_DLarga DLarga "
            '    frm.Tabla = " Articulos a "
            '    frm.FiltroText = " Enter the name of the fiber "
            '    frm.Filtro = " a.art_codigo "
            '    frm.Limite = 5
            '    frm.Ordenamiento = " a.art_codigo "
            '    frm.TipoOrdenamiento = ""
            '    frm.Condicion = condicion
            'End If

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaHilo.Text = frm.Dato
                celdaIdProducto.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(952, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value, 952)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            'Procedimiento para cargar panel dgLista
            ListaPrincipal()

        End If
    End Sub

    Private Sub panelProducto_Paint(sender As Object, e As PaintEventArgs) Handles panelProducto.Paint

    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

    Private Sub celdaNumero_TextChanged(sender As Object, e As EventArgs) Handles celdaNumero.TextChanged

    End Sub



#End Region

    Private Sub dgProducto_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgProducto.CellContentClick

    End Sub
End Class