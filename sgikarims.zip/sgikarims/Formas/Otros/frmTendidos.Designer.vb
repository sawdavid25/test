﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTendidos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaAnd = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgBultos = New System.Windows.Forms.DataGridView()
        Me.colAnoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaBultoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoNetoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTaraB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoBrutoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPreciob = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoriaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLaveB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaBB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLave2B = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colAnoD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaTendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPacasD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLLaveD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaDD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelPie = New System.Windows.Forms.Panel()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaBultos = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaPesoNeto = New System.Windows.Forms.TextBox()
        Me.celdaTara = New System.Windows.Forms.TextBox()
        Me.celdaPesoBruto = New System.Windows.Forms.TextBox()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.radioBultos = New System.Windows.Forms.RadioButton()
        Me.radioReferencia = New System.Windows.Forms.RadioButton()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaPrecioPromedio = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgBultos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPie.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFiltro)
        Me.panelLista.Location = New System.Drawing.Point(27, 125)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(798, 97)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAnio, Me.colNumber, Me.colDate, Me.colReferencia, Me.colProducto, Me.colTipo})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 61)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(798, 36)
        Me.dgLista.TabIndex = 1
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 89
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 61
        '
        'colNumber
        '
        Me.colNumber.HeaderText = "ID"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 46
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 63
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 99
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Producto"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        Me.colProducto.Visible = False
        Me.colProducto.Width = 90
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Visible = False
        Me.colTipo.Width = 61
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.etiquetaAnd)
        Me.panelFiltro.Controls.Add(Me.dtpFin)
        Me.panelFiltro.Controls.Add(Me.dtpInicio)
        Me.panelFiltro.Controls.Add(Me.checkFecha)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(798, 61)
        Me.panelFiltro.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(647, 16)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 9
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaAnd
        '
        Me.etiquetaAnd.AutoSize = True
        Me.etiquetaAnd.Location = New System.Drawing.Point(436, 23)
        Me.etiquetaAnd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAnd.Name = "etiquetaAnd"
        Me.etiquetaAnd.Size = New System.Drawing.Size(33, 17)
        Me.etiquetaAnd.TabIndex = 8
        Me.etiquetaAnd.Text = "And"
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(484, 20)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(128, 22)
        Me.dtpFin.TabIndex = 7
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(300, 21)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(128, 22)
        Me.dtpInicio.TabIndex = 6
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(51, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(155, 21)
        Me.checkFecha.TabIndex = 5
        Me.checkFecha.Text = "Show Date between"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelPie)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(42, 238)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(758, 281)
        Me.panelDocumento.TabIndex = 3
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgBultos)
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 160)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(758, 46)
        Me.panelDetalle.TabIndex = 2
        '
        'dgBultos
        '
        Me.dgBultos.AllowUserToAddRows = False
        Me.dgBultos.AllowUserToDeleteRows = False
        Me.dgBultos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgBultos.BackgroundColor = System.Drawing.Color.Honeydew
        Me.dgBultos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgBultos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnoB, Me.colNumeroB, Me.colLineaB, Me.colLineaBultoB, Me.colCorrelativoB, Me.colMarcaB, Me.colReferenciaB, Me.colDescripcionB, Me.colPesoNetoB, Me.colTaraB, Me.colPesoBrutoB, Me.colPreciob, Me.colMedidaB, Me.colCategoriaB, Me.colLLaveB, Me.colMarcaBB, Me.colLLave2B})
        Me.dgBultos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgBultos.Location = New System.Drawing.Point(692, 0)
        Me.dgBultos.MultiSelect = False
        Me.dgBultos.Name = "dgBultos"
        Me.dgBultos.ReadOnly = True
        Me.dgBultos.RowTemplate.Height = 24
        Me.dgBultos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgBultos.Size = New System.Drawing.Size(66, 46)
        Me.dgBultos.TabIndex = 1
        '
        'colAnoB
        '
        Me.colAnoB.HeaderText = "Año"
        Me.colAnoB.Name = "colAnoB"
        Me.colAnoB.ReadOnly = True
        Me.colAnoB.Visible = False
        Me.colAnoB.Width = 58
        '
        'colNumeroB
        '
        Me.colNumeroB.HeaderText = "Numero"
        Me.colNumeroB.Name = "colNumeroB"
        Me.colNumeroB.ReadOnly = True
        Me.colNumeroB.Visible = False
        Me.colNumeroB.Width = 83
        '
        'colLineaB
        '
        Me.colLineaB.HeaderText = "Linea"
        Me.colLineaB.Name = "colLineaB"
        Me.colLineaB.ReadOnly = True
        Me.colLineaB.Visible = False
        Me.colLineaB.Width = 68
        '
        'colLineaBultoB
        '
        Me.colLineaBultoB.HeaderText = "Bulto"
        Me.colLineaBultoB.Name = "colLineaBultoB"
        Me.colLineaBultoB.ReadOnly = True
        Me.colLineaBultoB.Visible = False
        Me.colLineaBultoB.Width = 65
        '
        'colCorrelativoB
        '
        Me.colCorrelativoB.HeaderText = "Correlative"
        Me.colCorrelativoB.Name = "colCorrelativoB"
        Me.colCorrelativoB.ReadOnly = True
        Me.colCorrelativoB.Width = 101
        '
        'colMarcaB
        '
        Me.colMarcaB.HeaderText = "Mark"
        Me.colMarcaB.Name = "colMarcaB"
        Me.colMarcaB.ReadOnly = True
        Me.colMarcaB.Width = 64
        '
        'colReferenciaB
        '
        Me.colReferenciaB.HeaderText = "Reference"
        Me.colReferenciaB.Name = "colReferenciaB"
        Me.colReferenciaB.ReadOnly = True
        Me.colReferenciaB.Width = 99
        '
        'colDescripcionB
        '
        Me.colDescripcionB.HeaderText = "Description"
        Me.colDescripcionB.Name = "colDescripcionB"
        Me.colDescripcionB.ReadOnly = True
        Me.colDescripcionB.Width = 104
        '
        'colPesoNetoB
        '
        Me.colPesoNetoB.HeaderText = "Net Weight"
        Me.colPesoNetoB.Name = "colPesoNetoB"
        Me.colPesoNetoB.ReadOnly = True
        Me.colPesoNetoB.Width = 103
        '
        'colTaraB
        '
        Me.colTaraB.HeaderText = "Tare"
        Me.colTaraB.Name = "colTaraB"
        Me.colTaraB.ReadOnly = True
        Me.colTaraB.Width = 63
        '
        'colPesoBrutoB
        '
        Me.colPesoBrutoB.HeaderText = "Gross Weight"
        Me.colPesoBrutoB.Name = "colPesoBrutoB"
        Me.colPesoBrutoB.ReadOnly = True
        Me.colPesoBrutoB.Width = 119
        '
        'colPreciob
        '
        Me.colPreciob.HeaderText = "Price"
        Me.colPreciob.Name = "colPreciob"
        Me.colPreciob.ReadOnly = True
        Me.colPreciob.Width = 65
        '
        'colMedidaB
        '
        Me.colMedidaB.HeaderText = "Measure"
        Me.colMedidaB.Name = "colMedidaB"
        Me.colMedidaB.ReadOnly = True
        Me.colMedidaB.Width = 88
        '
        'colCategoriaB
        '
        Me.colCategoriaB.HeaderText = "Category"
        Me.colCategoriaB.Name = "colCategoriaB"
        Me.colCategoriaB.ReadOnly = True
        Me.colCategoriaB.Width = 90
        '
        'colLLaveB
        '
        Me.colLLaveB.HeaderText = "Key"
        Me.colLLaveB.Name = "colLLaveB"
        Me.colLLaveB.ReadOnly = True
        Me.colLLaveB.Visible = False
        Me.colLLaveB.Width = 57
        '
        'colMarcaBB
        '
        Me.colMarcaBB.HeaderText = "Marca"
        Me.colMarcaBB.Name = "colMarcaBB"
        Me.colMarcaBB.ReadOnly = True
        Me.colMarcaBB.Visible = False
        Me.colMarcaBB.Width = 72
        '
        'colLLave2B
        '
        Me.colLLave2B.HeaderText = "key2"
        Me.colLLave2B.Name = "colLLave2B"
        Me.colLLave2B.ReadOnly = True
        Me.colLLave2B.Visible = False
        Me.colLLave2B.Width = 63
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Info
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnoD, Me.colNumeroD, Me.colLineaD, Me.colLineaTendido, Me.colDescripcionD, Me.colPrecioD, Me.colCantidadD, Me.colMedidaD, Me.colTotalD, Me.colReferenciaD, Me.colPacasD, Me.colLLaveD, Me.colMarcaDD})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(692, 46)
        Me.dgDetalle.TabIndex = 0
        '
        'colAnoD
        '
        Me.colAnoD.HeaderText = "Ano"
        Me.colAnoD.Name = "colAnoD"
        Me.colAnoD.ReadOnly = True
        Me.colAnoD.Visible = False
        Me.colAnoD.Width = 58
        '
        'colNumeroD
        '
        Me.colNumeroD.HeaderText = "Numero"
        Me.colNumeroD.Name = "colNumeroD"
        Me.colNumeroD.ReadOnly = True
        Me.colNumeroD.Visible = False
        Me.colNumeroD.Width = 83
        '
        'colLineaD
        '
        Me.colLineaD.HeaderText = "Linea"
        Me.colLineaD.Name = "colLineaD"
        Me.colLineaD.ReadOnly = True
        Me.colLineaD.Visible = False
        Me.colLineaD.Width = 68
        '
        'colLineaTendido
        '
        Me.colLineaTendido.HeaderText = "Line"
        Me.colLineaTendido.Name = "colLineaTendido"
        Me.colLineaTendido.ReadOnly = True
        Me.colLineaTendido.Width = 60
        '
        'colDescripcionD
        '
        Me.colDescripcionD.HeaderText = "Descripcion"
        Me.colDescripcionD.Name = "colDescripcionD"
        Me.colDescripcionD.ReadOnly = True
        Me.colDescripcionD.Width = 107
        '
        'colPrecioD
        '
        Me.colPrecioD.HeaderText = "Price"
        Me.colPrecioD.Name = "colPrecioD"
        Me.colPrecioD.ReadOnly = True
        Me.colPrecioD.Width = 65
        '
        'colCantidadD
        '
        Me.colCantidadD.HeaderText = "Quantity"
        Me.colCantidadD.Name = "colCantidadD"
        Me.colCantidadD.ReadOnly = True
        Me.colCantidadD.Width = 86
        '
        'colMedidaD
        '
        Me.colMedidaD.HeaderText = "Meassure"
        Me.colMedidaD.Name = "colMedidaD"
        Me.colMedidaD.ReadOnly = True
        Me.colMedidaD.Width = 95
        '
        'colTotalD
        '
        Me.colTotalD.HeaderText = "Amount"
        Me.colTotalD.Name = "colTotalD"
        Me.colTotalD.ReadOnly = True
        Me.colTotalD.Width = 81
        '
        'colReferenciaD
        '
        Me.colReferenciaD.HeaderText = "Reference"
        Me.colReferenciaD.Name = "colReferenciaD"
        Me.colReferenciaD.ReadOnly = True
        Me.colReferenciaD.Width = 99
        '
        'colPacasD
        '
        Me.colPacasD.HeaderText = "Package"
        Me.colPacasD.Name = "colPacasD"
        Me.colPacasD.ReadOnly = True
        Me.colPacasD.Width = 88
        '
        'colLLaveD
        '
        Me.colLLaveD.HeaderText = "Key"
        Me.colLLaveD.Name = "colLLaveD"
        Me.colLLaveD.ReadOnly = True
        Me.colLLaveD.Visible = False
        Me.colLLaveD.Width = 57
        '
        'colMarcaDD
        '
        Me.colMarcaDD.HeaderText = "Marca"
        Me.colMarcaDD.Name = "colMarcaDD"
        Me.colMarcaDD.ReadOnly = True
        Me.colMarcaDD.Visible = False
        Me.colMarcaDD.Width = 72
        '
        'panelPie
        '
        Me.panelPie.Controls.Add(Me.Label7)
        Me.panelPie.Controls.Add(Me.celdaBultos)
        Me.panelPie.Controls.Add(Me.Label6)
        Me.panelPie.Controls.Add(Me.celdaTotal)
        Me.panelPie.Controls.Add(Me.Label5)
        Me.panelPie.Controls.Add(Me.Label4)
        Me.panelPie.Controls.Add(Me.Label3)
        Me.panelPie.Controls.Add(Me.celdaPesoNeto)
        Me.panelPie.Controls.Add(Me.celdaTara)
        Me.panelPie.Controls.Add(Me.celdaPesoBruto)
        Me.panelPie.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPie.Location = New System.Drawing.Point(0, 206)
        Me.panelPie.Name = "panelPie"
        Me.panelPie.Size = New System.Drawing.Size(758, 75)
        Me.panelPie.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(522, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 17)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Packages"
        '
        'celdaBultos
        '
        Me.celdaBultos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaBultos.Location = New System.Drawing.Point(512, 27)
        Me.celdaBultos.Name = "celdaBultos"
        Me.celdaBultos.ReadOnly = True
        Me.celdaBultos.Size = New System.Drawing.Size(85, 22)
        Me.celdaBultos.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(611, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 17)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Amount"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(597, 27)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(133, 22)
        Me.celdaTotal.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(244, 7)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 17)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Tare"
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(371, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Gross weight."
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(90, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 17)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Net weight."
        '
        'celdaPesoNeto
        '
        Me.celdaPesoNeto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPesoNeto.Location = New System.Drawing.Point(79, 27)
        Me.celdaPesoNeto.Name = "celdaPesoNeto"
        Me.celdaPesoNeto.ReadOnly = True
        Me.celdaPesoNeto.Size = New System.Drawing.Size(133, 22)
        Me.celdaPesoNeto.TabIndex = 2
        '
        'celdaTara
        '
        Me.celdaTara.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTara.Location = New System.Drawing.Point(218, 27)
        Me.celdaTara.Name = "celdaTara"
        Me.celdaTara.ReadOnly = True
        Me.celdaTara.Size = New System.Drawing.Size(133, 22)
        Me.celdaTara.TabIndex = 1
        '
        'celdaPesoBruto
        '
        Me.celdaPesoBruto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPesoBruto.Location = New System.Drawing.Point(357, 27)
        Me.celdaPesoBruto.Name = "celdaPesoBruto"
        Me.celdaPesoBruto.ReadOnly = True
        Me.celdaPesoBruto.Size = New System.Drawing.Size(133, 22)
        Me.celdaPesoBruto.TabIndex = 0
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.radioBultos)
        Me.panelEncabezado.Controls.Add(Me.radioReferencia)
        Me.panelEncabezado.Controls.Add(Me.botonQuitar)
        Me.panelEncabezado.Controls.Add(Me.botonAgregar)
        Me.panelEncabezado.Controls.Add(Me.Label8)
        Me.panelEncabezado.Controls.Add(Me.celdaPrecioPromedio)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaTasa)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.panelEncabezado.Controls.Add(Me.celdaReferencia)
        Me.panelEncabezado.Controls.Add(Me.Label2)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.Label1)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Controls.Add(Me.botonProducto)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(758, 160)
        Me.panelEncabezado.TabIndex = 0
        '
        'radioBultos
        '
        Me.radioBultos.AutoSize = True
        Me.radioBultos.Checked = True
        Me.radioBultos.Location = New System.Drawing.Point(464, 35)
        Me.radioBultos.Name = "radioBultos"
        Me.radioBultos.Size = New System.Drawing.Size(104, 21)
        Me.radioBultos.TabIndex = 54
        Me.radioBultos.TabStop = True
        Me.radioBultos.Text = "By Package"
        Me.radioBultos.UseVisualStyleBackColor = True
        '
        'radioReferencia
        '
        Me.radioReferencia.AutoSize = True
        Me.radioReferencia.Location = New System.Drawing.Point(464, 8)
        Me.radioReferencia.Name = "radioReferencia"
        Me.radioReferencia.Size = New System.Drawing.Size(115, 21)
        Me.radioReferencia.TabIndex = 53
        Me.radioReferencia.Text = "By Reference"
        Me.radioReferencia.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.minus
        Me.botonQuitar.Location = New System.Drawing.Point(584, 113)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(54, 41)
        Me.botonQuitar.TabIndex = 52
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(524, 113)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(54, 41)
        Me.botonAgregar.TabIndex = 51
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(475, 65)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(97, 17)
        Me.Label8.TabIndex = 50
        Me.Label8.Text = "Average Price"
        '
        'celdaPrecioPromedio
        '
        Me.celdaPrecioPromedio.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPrecioPromedio.Location = New System.Drawing.Point(464, 85)
        Me.celdaPrecioPromedio.Name = "celdaPrecioPromedio"
        Me.celdaPrecioPromedio.ReadOnly = True
        Me.celdaPrecioPromedio.Size = New System.Drawing.Size(133, 22)
        Me.celdaPrecioPromedio.TabIndex = 49
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(172, 129)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(33, 23)
        Me.botonMoneda.TabIndex = 48
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(284, 17)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.ReadOnly = True
        Me.celdaIdMoneda.Size = New System.Drawing.Size(31, 22)
        Me.celdaIdMoneda.TabIndex = 47
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(81, 128)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 22)
        Me.celdaMoneda.TabIndex = 46
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(15, 136)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 45
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(275, 127)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 22)
        Me.celdaTasa.TabIndex = 32
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(231, 132)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 31
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(81, 100)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(294, 22)
        Me.celdaReferencia.TabIndex = 24
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 17)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Number"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(81, 69)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(124, 22)
        Me.celdaNumero.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 17)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "ID"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(13, 43)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 19
        Me.etiquetaAnio.Text = "Year"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(81, 38)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(124, 22)
        Me.celdaAnio.TabIndex = 20
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(81, 10)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(124, 22)
        Me.dtpFecha.TabIndex = 18
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(13, 17)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 17
        Me.etiquetaFecha.Text = "Date"
        '
        'botonProducto
        '
        Me.botonProducto.Image = Global.KARIMs_SGI.My.Resources.Resources.box_open
        Me.botonProducto.Location = New System.Drawing.Point(464, 113)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(54, 41)
        Me.botonProducto.TabIndex = 2
        Me.botonProducto.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 81)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(859, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(859, 81)
        Me.Encabezado1.TabIndex = 0
        '
        'frmTendidos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(859, 531)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmTendidos"
        Me.Text = "Tendidos"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgBultos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPie.ResumeLayout(False)
        Me.panelPie.PerformLayout()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgBultos As System.Windows.Forms.DataGridView
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents panelPie As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents botonProducto As System.Windows.Forms.Button
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents etiquetaAnio As System.Windows.Forms.Label
    Friend WithEvents celdaAnio As System.Windows.Forms.TextBox
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaIdMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaPesoNeto As System.Windows.Forms.TextBox
    Friend WithEvents celdaTara As System.Windows.Forms.TextBox
    Friend WithEvents celdaPesoBruto As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents celdaBultos As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents celdaPrecioPromedio As System.Windows.Forms.TextBox
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents etiquetaAnd As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents colAnoB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaBultoB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativoB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarcaB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPesoNetoB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTaraB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPesoBrutoB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPreciob As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedidaB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCategoriaB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLaveB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarcaBB As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLave2B As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnoD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaTendido As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecioD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidadD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedidaD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotalD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPacasD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLLaveD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMarcaDD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents radioBultos As System.Windows.Forms.RadioButton
    Friend WithEvents radioReferencia As System.Windows.Forms.RadioButton
    Friend WithEvents colCatalogo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumber As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProducto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipo As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
