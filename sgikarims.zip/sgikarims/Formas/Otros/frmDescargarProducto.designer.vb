﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDescargarProducto
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.PanelDescargo = New System.Windows.Forms.Panel()
        Me.dgDescargos = New System.Windows.Forms.DataGridView()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEgreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_UMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Medida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelDescargo.SuspendLayout()
        CType(Me.dgDescargos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1122, 37)
        Me.BarraTitulo1.TabIndex = 0
        '
        'PanelDescargo
        '
        Me.PanelDescargo.Controls.Add(Me.dgDescargos)
        Me.PanelDescargo.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelDescargo.Location = New System.Drawing.Point(0, 37)
        Me.PanelDescargo.Name = "PanelDescargo"
        Me.PanelDescargo.Size = New System.Drawing.Size(1122, 316)
        Me.PanelDescargo.TabIndex = 1
        '
        'dgDescargos
        '
        Me.dgDescargos.AllowUserToAddRows = False
        Me.dgDescargos.AllowUserToDeleteRows = False
        Me.dgDescargos.AllowUserToOrderColumns = True
        Me.dgDescargos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDescargos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDescargos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colNumero, Me.colDescripcion, Me.colClasificacion, Me.colCosto, Me.colLinea, Me.colIngreso, Me.colEgreso, Me.colSaldo, Me.colCantidad, Me.col_UMedida, Me.col_Medida, Me.col_Referencia})
        Me.dgDescargos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDescargos.Location = New System.Drawing.Point(0, 0)
        Me.dgDescargos.MultiSelect = False
        Me.dgDescargos.Name = "dgDescargos"
        Me.dgDescargos.RowTemplate.Height = 24
        Me.dgDescargos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDescargos.Size = New System.Drawing.Size(1122, 316)
        Me.dgDescargos.TabIndex = 0
        '
        'botonCancelar
        '
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCancelar.Location = New System.Drawing.Point(853, 367)
        Me.botonCancelar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(77, 65)
        Me.botonCancelar.TabIndex = 11
        Me.botonCancelar.Text = "Close"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Image = Global.KARIMs_SGI.My.Resources.Resources.Aceptado
        Me.botonAceptar.Location = New System.Drawing.Point(699, 367)
        Me.botonAceptar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(77, 65)
        Me.botonAceptar.TabIndex = 10
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Visible = False
        Me.colCodigo.Width = 70
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 70
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        '
        'colClasificacion
        '
        Me.colClasificacion.HeaderText = "Clasification"
        Me.colClasificacion.Name = "colClasificacion"
        Me.colClasificacion.ReadOnly = True
        Me.colClasificacion.Visible = False
        '
        'colCosto
        '
        Me.colCosto.HeaderText = "Cost"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 70
        '
        'colIngreso
        '
        Me.colIngreso.HeaderText = "Entry"
        Me.colIngreso.Name = "colIngreso"
        Me.colIngreso.ReadOnly = True
        Me.colIngreso.Visible = False
        '
        'colEgreso
        '
        Me.colEgreso.HeaderText = "Discharge"
        Me.colEgreso.Name = "colEgreso"
        Me.colEgreso.ReadOnly = True
        Me.colEgreso.Visible = False
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        '
        'col_UMedida
        '
        Me.col_UMedida.HeaderText = "UMedida"
        Me.col_UMedida.Name = "col_UMedida"
        Me.col_UMedida.Visible = False
        Me.col_UMedida.Width = 70
        '
        'col_Medida
        '
        Me.col_Medida.HeaderText = "Medida"
        Me.col_Medida.Name = "col_Medida"
        Me.col_Medida.Width = 70
        '
        'col_Referencia
        '
        Me.col_Referencia.HeaderText = "Reference"
        Me.col_Referencia.Name = "col_Referencia"
        '
        'frmDescargarProducto
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1122, 447)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Controls.Add(Me.PanelDescargo)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Name = "frmDescargarProducto"
        Me.Text = "frmDescargarProducto"
        Me.PanelDescargo.ResumeLayout(False)
        CType(Me.dgDescargos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelDescargo As Panel
    Friend WithEvents dgDescargos As DataGridView
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacion As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colIngreso As DataGridViewTextBoxColumn
    Friend WithEvents colEgreso As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents col_UMedida As DataGridViewTextBoxColumn
    Friend WithEvents col_Medida As DataGridViewTextBoxColumn
    Friend WithEvents col_Referencia As DataGridViewTextBoxColumn
End Class
