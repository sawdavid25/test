﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDevoluciones
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSelectivoLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezadoLista = New System.Windows.Forms.Panel()
        Me.botonClienteE = New System.Windows.Forms.Button()
        Me.celdaClienteE = New System.Windows.Forms.TextBox()
        Me.etiquetaClienteE = New System.Windows.Forms.Label()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.DgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProductoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFacturaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLoteDetDev = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadKG = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioKg = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultosDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTejedoraDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.etiquetaComentarios = New System.Windows.Forms.Label()
        Me.celdaComentarios = New System.Windows.Forms.TextBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTotalCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.panelDgTotales = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.botonCCosto = New System.Windows.Forms.Button()
        Me.celdaCCosto = New System.Windows.Forms.TextBox()
        Me.etiquetaCCosto = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbCliente = New System.Windows.Forms.RadioButton()
        Me.rbHilos = New System.Windows.Forms.RadioButton()
        Me.botonAutorizado = New System.Windows.Forms.Button()
        Me.celdaAutorizado = New System.Windows.Forms.TextBox()
        Me.etiquetaAutorizado = New System.Windows.Forms.Label()
        Me.celdaSolicitante = New System.Windows.Forms.TextBox()
        Me.etiquetaSolicitante = New System.Windows.Forms.Label()
        Me.gbRelacion = New System.Windows.Forms.GroupBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.dgFactura = New System.Windows.Forms.DataGridView()
        Me.colNumeroF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbCliente = New System.Windows.Forms.GroupBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.celdaDate = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezadoLista.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.DgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.panelDgTotales.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDatos.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbRelacion.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbCliente.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelEncabezadoLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 126)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1370, 142)
        Me.panelLista.TabIndex = 8
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFecha, Me.colCliente, Me.colReferencia, Me.colAnio, Me.colEstado, Me.colSelectivoLista})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 85)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1370, 57)
        Me.dgLista.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'colSelectivoLista
        '
        Me.colSelectivoLista.HeaderText = "Selective"
        Me.colSelectivoLista.Name = "colSelectivoLista"
        Me.colSelectivoLista.ReadOnly = True
        '
        'panelEncabezadoLista
        '
        Me.panelEncabezadoLista.Controls.Add(Me.botonClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaFechas)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpInicial)
        Me.panelEncabezadoLista.Controls.Add(Me.checkFechas)
        Me.panelEncabezadoLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoLista.Name = "panelEncabezadoLista"
        Me.panelEncabezadoLista.Size = New System.Drawing.Size(1370, 85)
        Me.panelEncabezadoLista.TabIndex = 0
        '
        'botonClienteE
        '
        Me.botonClienteE.Location = New System.Drawing.Point(568, 54)
        Me.botonClienteE.Name = "botonClienteE"
        Me.botonClienteE.Size = New System.Drawing.Size(43, 28)
        Me.botonClienteE.TabIndex = 7
        Me.botonClienteE.Text = "..."
        Me.botonClienteE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonClienteE.UseVisualStyleBackColor = True
        '
        'celdaClienteE
        '
        Me.celdaClienteE.Location = New System.Drawing.Point(131, 56)
        Me.celdaClienteE.Name = "celdaClienteE"
        Me.celdaClienteE.Size = New System.Drawing.Size(432, 22)
        Me.celdaClienteE.TabIndex = 6
        '
        'etiquetaClienteE
        '
        Me.etiquetaClienteE.AutoSize = True
        Me.etiquetaClienteE.Location = New System.Drawing.Point(46, 59)
        Me.etiquetaClienteE.Name = "etiquetaClienteE"
        Me.etiquetaClienteE.Size = New System.Drawing.Size(51, 17)
        Me.etiquetaClienteE.TabIndex = 5
        Me.etiquetaClienteE.Text = "Cliente"
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(742, 10)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 26)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(485, 13)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaFechas.TabIndex = 3
        Me.etiquetaFechas.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(568, 11)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(122, 22)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(349, 11)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(121, 22)
        Me.dtpInicial.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(49, 15)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(231, 21)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Show Documents Between Date"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Controls.Add(Me.DgDetalle)
        Me.panelDetalle.Controls.Add(Me.panelTotales)
        Me.panelDetalle.Controls.Add(Me.panelDatos)
        Me.panelDetalle.Location = New System.Drawing.Point(0, 274)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1358, 586)
        Me.panelDetalle.TabIndex = 9
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonQuitar)
        Me.Panel1.Controls.Add(Me.botonAgregar)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(1297, 317)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(61, 121)
        Me.Panel1.TabIndex = 5
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(15, 56)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(34, 31)
        Me.botonQuitar.TabIndex = 45
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(15, 12)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(34, 31)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'DgDetalle
        '
        Me.DgDetalle.AllowUserToAddRows = False
        Me.DgDetalle.AllowUserToDeleteRows = False
        Me.DgDetalle.AllowUserToOrderColumns = True
        Me.DgDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigoDet, Me.colProductoDet, Me.colFacturaDet, Me.colUMedida, Me.colLoteDet, Me.colLoteDetDev, Me.colCantidadDet, Me.colPrecioDet, Me.colCantidadKG, Me.colPrecioKg, Me.colBultosDet, Me.colReferenciaDet, Me.colTejedoraDet})
        Me.DgDetalle.Location = New System.Drawing.Point(0, 317)
        Me.DgDetalle.MultiSelect = False
        Me.DgDetalle.Name = "DgDetalle"
        Me.DgDetalle.RowTemplate.Height = 24
        Me.DgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgDetalle.Size = New System.Drawing.Size(1296, 121)
        Me.DgDetalle.TabIndex = 4
        '
        'colCodigoDet
        '
        Me.colCodigoDet.HeaderText = "Code"
        Me.colCodigoDet.Name = "colCodigoDet"
        Me.colCodigoDet.ReadOnly = True
        '
        'colProductoDet
        '
        Me.colProductoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colProductoDet.HeaderText = "Product"
        Me.colProductoDet.Name = "colProductoDet"
        Me.colProductoDet.ReadOnly = True
        '
        'colFacturaDet
        '
        Me.colFacturaDet.HeaderText = "Bill No."
        Me.colFacturaDet.Name = "colFacturaDet"
        Me.colFacturaDet.ReadOnly = True
        '
        'colUMedida
        '
        Me.colUMedida.HeaderText = "Measure"
        Me.colUMedida.Name = "colUMedida"
        Me.colUMedida.ReadOnly = True
        '
        'colLoteDet
        '
        Me.colLoteDet.HeaderText = "Invoice lot"
        Me.colLoteDet.Name = "colLoteDet"
        Me.colLoteDet.ReadOnly = True
        '
        'colLoteDetDev
        '
        Me.colLoteDetDev.HeaderText = "Return Lot "
        Me.colLoteDetDev.Name = "colLoteDetDev"
        '
        'colCantidadDet
        '
        Me.colCantidadDet.HeaderText = "Quantity Pound"
        Me.colCantidadDet.Name = "colCantidadDet"
        Me.colCantidadDet.ReadOnly = True
        '
        'colPrecioDet
        '
        Me.colPrecioDet.HeaderText = "Price Pounds"
        Me.colPrecioDet.Name = "colPrecioDet"
        Me.colPrecioDet.ReadOnly = True
        '
        'colCantidadKG
        '
        Me.colCantidadKG.HeaderText = "Quantity Kg"
        Me.colCantidadKG.Name = "colCantidadKG"
        Me.colCantidadKG.ReadOnly = True
        '
        'colPrecioKg
        '
        Me.colPrecioKg.HeaderText = "Price Kg"
        Me.colPrecioKg.Name = "colPrecioKg"
        Me.colPrecioKg.ReadOnly = True
        '
        'colBultosDet
        '
        Me.colBultosDet.HeaderText = "Packages"
        Me.colBultosDet.Name = "colBultosDet"
        '
        'colReferenciaDet
        '
        Me.colReferenciaDet.HeaderText = "Reference"
        Me.colReferenciaDet.Name = "colReferenciaDet"
        Me.colReferenciaDet.ReadOnly = True
        '
        'colTejedoraDet
        '
        Me.colTejedoraDet.HeaderText = "Weaver"
        Me.colTejedoraDet.Name = "colTejedoraDet"
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.etiquetaComentarios)
        Me.panelTotales.Controls.Add(Me.celdaComentarios)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotalCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotales)
        Me.panelTotales.Controls.Add(Me.panelDgTotales)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 438)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1358, 148)
        Me.panelTotales.TabIndex = 3
        '
        'etiquetaComentarios
        '
        Me.etiquetaComentarios.AutoSize = True
        Me.etiquetaComentarios.Location = New System.Drawing.Point(478, 13)
        Me.etiquetaComentarios.Name = "etiquetaComentarios"
        Me.etiquetaComentarios.Size = New System.Drawing.Size(74, 17)
        Me.etiquetaComentarios.TabIndex = 22
        Me.etiquetaComentarios.Text = "Comments"
        '
        'celdaComentarios
        '
        Me.celdaComentarios.Location = New System.Drawing.Point(481, 38)
        Me.celdaComentarios.Multiline = True
        Me.celdaComentarios.Name = "celdaComentarios"
        Me.celdaComentarios.Size = New System.Drawing.Size(415, 107)
        Me.celdaComentarios.TabIndex = 21
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(1198, 49)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(114, 22)
        Me.celdaTotal.TabIndex = 20
        '
        'celdaTotalCantidad
        '
        Me.celdaTotalCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalCantidad.Location = New System.Drawing.Point(1052, 49)
        Me.celdaTotalCantidad.Name = "celdaTotalCantidad"
        Me.celdaTotalCantidad.ReadOnly = True
        Me.celdaTotalCantidad.Size = New System.Drawing.Size(114, 22)
        Me.celdaTotalCantidad.TabIndex = 19
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(1048, 21)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(55, 17)
        Me.etiquetaTotales.TabIndex = 1
        Me.etiquetaTotales.Text = "Totales"
        '
        'panelDgTotales
        '
        Me.panelDgTotales.Controls.Add(Me.dgDocumentos)
        Me.panelDgTotales.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDgTotales.Location = New System.Drawing.Point(0, 0)
        Me.panelDgTotales.Name = "panelDgTotales"
        Me.panelDgTotales.Size = New System.Drawing.Size(437, 148)
        Me.panelDgTotales.TabIndex = 0
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.AllowUserToOrderColumns = True
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumento, Me.colDatos})
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumentos.MultiSelect = False
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.RowTemplate.Height = 24
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(437, 148)
        Me.dgDocumentos.TabIndex = 1
        '
        'colClave
        '
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colDatos
        '
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.botonCCosto)
        Me.panelDatos.Controls.Add(Me.celdaCCosto)
        Me.panelDatos.Controls.Add(Me.etiquetaCCosto)
        Me.panelDatos.Controls.Add(Me.GroupBox1)
        Me.panelDatos.Controls.Add(Me.botonAutorizado)
        Me.panelDatos.Controls.Add(Me.celdaAutorizado)
        Me.panelDatos.Controls.Add(Me.etiquetaAutorizado)
        Me.panelDatos.Controls.Add(Me.celdaSolicitante)
        Me.panelDatos.Controls.Add(Me.etiquetaSolicitante)
        Me.panelDatos.Controls.Add(Me.gbRelacion)
        Me.panelDatos.Controls.Add(Me.gbCliente)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1358, 317)
        Me.panelDatos.TabIndex = 0
        '
        'botonCCosto
        '
        Me.botonCCosto.Location = New System.Drawing.Point(955, 234)
        Me.botonCCosto.Name = "botonCCosto"
        Me.botonCCosto.Size = New System.Drawing.Size(38, 25)
        Me.botonCCosto.TabIndex = 29
        Me.botonCCosto.Text = "..."
        Me.botonCCosto.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCCosto.UseVisualStyleBackColor = True
        '
        'celdaCCosto
        '
        Me.celdaCCosto.Location = New System.Drawing.Point(699, 237)
        Me.celdaCCosto.Name = "celdaCCosto"
        Me.celdaCCosto.Size = New System.Drawing.Size(242, 22)
        Me.celdaCCosto.TabIndex = 31
        '
        'etiquetaCCosto
        '
        Me.etiquetaCCosto.AutoSize = True
        Me.etiquetaCCosto.Location = New System.Drawing.Point(584, 242)
        Me.etiquetaCCosto.Name = "etiquetaCCosto"
        Me.etiquetaCCosto.Size = New System.Drawing.Size(86, 17)
        Me.etiquetaCCosto.TabIndex = 30
        Me.etiquetaCCosto.Text = "Cost Center "
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbCliente)
        Me.GroupBox1.Controls.Add(Me.rbHilos)
        Me.GroupBox1.Location = New System.Drawing.Point(1067, 146)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(274, 100)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Devolution costs"
        '
        'rbCliente
        '
        Me.rbCliente.AutoSize = True
        Me.rbCliente.Location = New System.Drawing.Point(6, 55)
        Me.rbCliente.Name = "rbCliente"
        Me.rbCliente.Size = New System.Drawing.Size(72, 21)
        Me.rbCliente.TabIndex = 24
        Me.rbCliente.TabStop = True
        Me.rbCliente.Text = "Cliente"
        Me.rbCliente.UseVisualStyleBackColor = True
        '
        'rbHilos
        '
        Me.rbHilos.AutoSize = True
        Me.rbHilos.Location = New System.Drawing.Point(6, 23)
        Me.rbHilos.Name = "rbHilos"
        Me.rbHilos.Size = New System.Drawing.Size(157, 21)
        Me.rbHilos.TabIndex = 23
        Me.rbHilos.TabStop = True
        Me.rbHilos.Text = "HILOS Y ALGODON"
        Me.rbHilos.UseVisualStyleBackColor = True
        '
        'botonAutorizado
        '
        Me.botonAutorizado.Location = New System.Drawing.Point(955, 271)
        Me.botonAutorizado.Name = "botonAutorizado"
        Me.botonAutorizado.Size = New System.Drawing.Size(38, 25)
        Me.botonAutorizado.TabIndex = 23
        Me.botonAutorizado.Text = "..."
        Me.botonAutorizado.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAutorizado.UseVisualStyleBackColor = True
        '
        'celdaAutorizado
        '
        Me.celdaAutorizado.Location = New System.Drawing.Point(699, 274)
        Me.celdaAutorizado.Name = "celdaAutorizado"
        Me.celdaAutorizado.Size = New System.Drawing.Size(242, 22)
        Me.celdaAutorizado.TabIndex = 27
        '
        'etiquetaAutorizado
        '
        Me.etiquetaAutorizado.AutoSize = True
        Me.etiquetaAutorizado.Location = New System.Drawing.Point(584, 279)
        Me.etiquetaAutorizado.Name = "etiquetaAutorizado"
        Me.etiquetaAutorizado.Size = New System.Drawing.Size(88, 17)
        Me.etiquetaAutorizado.TabIndex = 26
        Me.etiquetaAutorizado.Text = "Approved by"
        '
        'celdaSolicitante
        '
        Me.celdaSolicitante.Location = New System.Drawing.Point(699, 164)
        Me.celdaSolicitante.Name = "celdaSolicitante"
        Me.celdaSolicitante.Size = New System.Drawing.Size(242, 22)
        Me.celdaSolicitante.TabIndex = 25
        '
        'etiquetaSolicitante
        '
        Me.etiquetaSolicitante.AutoSize = True
        Me.etiquetaSolicitante.Location = New System.Drawing.Point(584, 169)
        Me.etiquetaSolicitante.Name = "etiquetaSolicitante"
        Me.etiquetaSolicitante.Size = New System.Drawing.Size(96, 17)
        Me.etiquetaSolicitante.TabIndex = 24
        Me.etiquetaSolicitante.Text = "Requested by"
        '
        'gbRelacion
        '
        Me.gbRelacion.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbRelacion.Controls.Add(Me.panelBotones)
        Me.gbRelacion.Controls.Add(Me.dgFactura)
        Me.gbRelacion.Location = New System.Drawing.Point(587, 3)
        Me.gbRelacion.Name = "gbRelacion"
        Me.gbRelacion.Size = New System.Drawing.Size(713, 142)
        Me.gbRelacion.TabIndex = 10
        Me.gbRelacion.TabStop = False
        Me.gbRelacion.Text = "Return Information"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonMenos)
        Me.panelBotones.Controls.Add(Me.botonMas)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(649, 18)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(61, 121)
        Me.panelBotones.TabIndex = 1
        '
        'botonMenos
        '
        Me.botonMenos.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonMenos.Location = New System.Drawing.Point(15, 56)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(34, 31)
        Me.botonMenos.TabIndex = 45
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(15, 12)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(34, 31)
        Me.botonMas.TabIndex = 4
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'dgFactura
        '
        Me.dgFactura.AllowUserToAddRows = False
        Me.dgFactura.AllowUserToDeleteRows = False
        Me.dgFactura.AllowUserToOrderColumns = True
        Me.dgFactura.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFactura.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumeroF, Me.colFechaF, Me.colReferenciaF, Me.colAnioF, Me.colCatalogoF})
        Me.dgFactura.Location = New System.Drawing.Point(3, 18)
        Me.dgFactura.MultiSelect = False
        Me.dgFactura.Name = "dgFactura"
        Me.dgFactura.ReadOnly = True
        Me.dgFactura.RowTemplate.Height = 24
        Me.dgFactura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFactura.Size = New System.Drawing.Size(640, 121)
        Me.dgFactura.TabIndex = 0
        '
        'colNumeroF
        '
        Me.colNumeroF.HeaderText = "Number"
        Me.colNumeroF.Name = "colNumeroF"
        Me.colNumeroF.ReadOnly = True
        '
        'colFechaF
        '
        Me.colFechaF.HeaderText = "Date"
        Me.colFechaF.Name = "colFechaF"
        Me.colFechaF.ReadOnly = True
        '
        'colReferenciaF
        '
        Me.colReferenciaF.HeaderText = "Reference"
        Me.colReferenciaF.Name = "colReferenciaF"
        Me.colReferenciaF.ReadOnly = True
        '
        'colAnioF
        '
        Me.colAnioF.HeaderText = "Anio"
        Me.colAnioF.Name = "colAnioF"
        Me.colAnioF.ReadOnly = True
        '
        'colCatalogoF
        '
        Me.colCatalogoF.HeaderText = "Catalogo"
        Me.colCatalogoF.Name = "colCatalogoF"
        Me.colCatalogoF.ReadOnly = True
        '
        'gbCliente
        '
        Me.gbCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gbCliente.Controls.Add(Me.celdaUsuario)
        Me.gbCliente.Controls.Add(Me.botonMoneda)
        Me.gbCliente.Controls.Add(Me.dtpFecha)
        Me.gbCliente.Controls.Add(Me.celdaNIT)
        Me.gbCliente.Controls.Add(Me.celdaIdMoneda)
        Me.gbCliente.Controls.Add(Me.celdaIdCliente)
        Me.gbCliente.Controls.Add(Me.celdaDate)
        Me.gbCliente.Controls.Add(Me.checkActivo)
        Me.gbCliente.Controls.Add(Me.celdaTasa)
        Me.gbCliente.Controls.Add(Me.celdaMoneda)
        Me.gbCliente.Controls.Add(Me.celdaDireccion)
        Me.gbCliente.Controls.Add(Me.botonCliente)
        Me.gbCliente.Controls.Add(Me.celdaCliente)
        Me.gbCliente.Controls.Add(Me.celdaNumero)
        Me.gbCliente.Controls.Add(Me.celdaCatalogo)
        Me.gbCliente.Controls.Add(Me.celdaAnio)
        Me.gbCliente.Controls.Add(Me.etiquetaTasa)
        Me.gbCliente.Controls.Add(Me.etiquetaMoneda)
        Me.gbCliente.Controls.Add(Me.etiquetaDireccion)
        Me.gbCliente.Controls.Add(Me.etiquetaCliente)
        Me.gbCliente.Controls.Add(Me.etiquetaFecha)
        Me.gbCliente.Controls.Add(Me.etiquetaNumero)
        Me.gbCliente.Controls.Add(Me.etiquetaAnio)
        Me.gbCliente.Location = New System.Drawing.Point(3, 3)
        Me.gbCliente.Name = "gbCliente"
        Me.gbCliente.Size = New System.Drawing.Size(560, 311)
        Me.gbCliente.TabIndex = 1
        Me.gbCliente.TabStop = False
        Me.gbCliente.Text = "Return"
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(415, 283)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(100, 22)
        Me.celdaUsuario.TabIndex = 21
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(227, 235)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(38, 25)
        Me.botonMoneda.TabIndex = 22
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(106, 108)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(114, 22)
        Me.dtpFecha.TabIndex = 20
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(435, 117)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(100, 22)
        Me.celdaNIT.TabIndex = 19
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(274, 276)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(81, 22)
        Me.celdaIdMoneda.TabIndex = 18
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(328, 105)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(81, 22)
        Me.celdaIdCliente.TabIndex = 18
        '
        'celdaDate
        '
        Me.celdaDate.Location = New System.Drawing.Point(224, 110)
        Me.celdaDate.Name = "celdaDate"
        Me.celdaDate.Size = New System.Drawing.Size(81, 22)
        Me.celdaDate.TabIndex = 17
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(398, 41)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 16
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(106, 276)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(114, 22)
        Me.celdaTasa.TabIndex = 15
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(106, 237)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(114, 22)
        Me.celdaMoneda.TabIndex = 14
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(106, 178)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(360, 48)
        Me.celdaDireccion.TabIndex = 13
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(396, 143)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(38, 29)
        Me.botonCliente.TabIndex = 8
        Me.botonCliente.Text = "..."
        Me.botonCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(106, 146)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(284, 22)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(106, 74)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(114, 22)
        Me.celdaNumero.TabIndex = 10
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(193, 16)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(81, 22)
        Me.celdaCatalogo.TabIndex = 8
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(106, 39)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(114, 22)
        Me.celdaAnio.TabIndex = 7
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(18, 276)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 6
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(18, 237)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 5
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(16, 178)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(53, 17)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Addres"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(16, 146)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(43, 17)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(16, 110)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(16, 74)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(16, 39)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1370, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1370, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmDevoluciones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 872)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmDevoluciones"
        Me.Text = "Devoluciones"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezadoLista.ResumeLayout(False)
        Me.panelEncabezadoLista.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.DgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelDgTotales.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDatos.ResumeLayout(False)
        Me.panelDatos.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbRelacion.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbCliente.ResumeLayout(False)
        Me.gbCliente.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelEncabezadoLista As Panel
    Friend WithEvents botonClienteE As Button
    Friend WithEvents celdaClienteE As TextBox
    Friend WithEvents etiquetaClienteE As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFechas As CheckBox
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colSelectivoLista As DataGridViewTextBoxColumn
    Friend WithEvents panelDatos As Panel
    Friend WithEvents gbCliente As GroupBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaNIT As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents celdaDate As TextBox
    Friend WithEvents checkActivo As CheckBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents DgDetalle As DataGridView
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaTotalCantidad As TextBox
    Friend WithEvents etiquetaTotales As Label
    Friend WithEvents panelDgTotales As Panel
    Friend WithEvents dgDocumentos As DataGridView
    Friend WithEvents colClave As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colDatos As DataGridViewTextBoxColumn
    Friend WithEvents gbRelacion As GroupBox
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents dgFactura As DataGridView
    Friend WithEvents botonAutorizado As Button
    Friend WithEvents celdaAutorizado As TextBox
    Friend WithEvents etiquetaAutorizado As Label
    Friend WithEvents celdaSolicitante As TextBox
    Friend WithEvents etiquetaSolicitante As Label
    Friend WithEvents colNumeroF As DataGridViewTextBoxColumn
    Friend WithEvents colFechaF As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaF As DataGridViewTextBoxColumn
    Friend WithEvents colAnioF As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoF As DataGridViewTextBoxColumn
    Friend WithEvents rbCliente As RadioButton
    Friend WithEvents rbHilos As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents botonCCosto As Button
    Friend WithEvents celdaCCosto As TextBox
    Friend WithEvents etiquetaCCosto As Label
    Friend WithEvents etiquetaComentarios As Label
    Friend WithEvents celdaComentarios As TextBox
    Friend WithEvents colCodigoDet As DataGridViewTextBoxColumn
    Friend WithEvents colProductoDet As DataGridViewTextBoxColumn
    Friend WithEvents colFacturaDet As DataGridViewTextBoxColumn
    Friend WithEvents colUMedida As DataGridViewTextBoxColumn
    Friend WithEvents colLoteDet As DataGridViewTextBoxColumn
    Friend WithEvents colLoteDetDev As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadDet As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioDet As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadKG As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioKg As DataGridViewTextBoxColumn
    Friend WithEvents colBultosDet As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaDet As DataGridViewTextBoxColumn
    Friend WithEvents colTejedoraDet As DataGridViewTextBoxColumn
End Class
