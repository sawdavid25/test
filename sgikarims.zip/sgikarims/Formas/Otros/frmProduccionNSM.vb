﻿Imports System.Threading

Public Class frmProduccionNSM
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim Proceso As Integer
    Dim CodigosMat As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim NotaDev As String
    Dim VerOpcion As Integer
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select h.HDoc_Sis_Emp Empresa, h.HDoc_Doc_Cat Catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num Referencia, IFNULL(h980.HDoc_DR1_Num,'') PO, h.HDoc_Doc_Status estatus "
        strSQL &= "     From Dcmtos_HDR h"
        strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND dp.PDoc_Par_Cat = h.HDoc_Doc_Cat AND dp.PDoc_Par_Ano = h.HDoc_Doc_Ano AND dp.PDoc_Par_Num = h.HDoc_Doc_Num AND dp.PDoc_Chi_Cat = 980 "
        strSQL &= "             LEFT JOIN Dcmtos_HDR h980 ON h980.HDoc_Sis_Emp = dp.PDoc_Sis_Emp AND h980.HDoc_Doc_Cat = dp.PDoc_Chi_Cat AND h980.HDoc_Doc_Ano = dp.PDoc_Chi_Ano AND h980.HDoc_Doc_Num = dp.PDoc_Chi_Num "
        strSQL &= "         Where h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = 952 "

        If checkFecha.Checked = True Then

            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If
        strSQL &= "             GROUP BY h.HDoc_Sis_Emp , h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        ' strSQL = Replace(strSQL, "{NumProceso}", NumProceso)

        Return strSQL
    End Function
    Private Function NuevaLineaDTL()

        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        ' strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        '  strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{catalogo}", 952)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function
    Public Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("PO")

                    If REA.GetInt32("estatus") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaLinea() As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select ifnull(max(d.DDoc_Doc_Lin ),0)+1 from Dcmtos_DTL d "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 952 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            panelDocumento.Visible = False
            panelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Production Phase 1")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

            ListaPrincipal()

        Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDocumento.Visible = True
            panelDocumento.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '      LimpiarCampos()
                'CargarCostos()
                '        ColocaMoneda()
            End If

        End If

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarBultosADescargar()
        Dim frm As New frmSeleccionar
        Dim logVerificar As Boolean = True
        Dim condicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strFilaAux As String = STR_VACIO
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim k As Integer = 0
        Dim NumDoc As String = STR_VACIO
        Dim verificaInsert As Integer = 0
        Dim LinDoc As Integer = 0
        Dim AnioDoc As Integer = 0
        Dim sumaCant As Double = 0
        Dim SumaCant2 As Double = 0
        Dim SumaPaquetes As Integer = 0
        Dim strComplemento As String = STR_VACIO
        Dim dblSaldo As Double
        celdaSaldo.Text = SaldoPO().ToString(FORMATO_MONEDA)
        condicion = " WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Num = db.BDoc_Doc_Num  AND h.HDoc_DR1_Cat IN (0,4) {tfibra} AND bp.BPDoc_Par_Num IS NULL ) l1 WHERE (l1.TipoProducto = 'Fibra' OR l1.TipoProducto = 'Waste')  AND NOT l1.TipoProducto = 'Terminado' ) l2"
        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
        'If Sesion.IdEmpresa = 15 Then
        '    If rbCotton.Checked = True Then
        '        condicion = Replace(condicion, "{tfibra}", " AND cc.cat_pid =1 ")
        '    ElseIf rbPoly.Checked = True Then
        '        condicion = Replace(condicion, "{tfibra}", " AND cc.cat_pid =2 ")
        '    Else
        '        condicion = Replace(condicion, "{tfibra}", STR_VACIO)
        '    End If

        'Else
        condicion = Replace(condicion, "{tfibra}", STR_VACIO)
        'End If
        'condicion = Replace(condicion, "{num}", dgCostoFijo.Rows(i).Cells("colCodigoFijo").Value)

        Try
            strComplemento = " l2.Price > 0 "
            frm.Titulo = " Select the packages to use "
            frm.Campos = "   l2.Correlative Correlative , l2.Mark Mark, l2.Reference Reference,l2.Description Description, l2.PesoBulto PesoBulto, l2.Price Price , l2.Measure Measure, l2.Number NUMBER, l2.YEAR YEAR, l2.Line Line , l2.LineaBulto LineaBulto , l2.Codigo Codigo, l2.Umedida Umedida , l2.Categoria Categoria, l2.PrecioEstimado  Estimated, l2.Marca Mark, l2.TipoCambio TipoCambio  "
            frm.Tabla = " ( SELECT l1.TipoProducto,l1.Correlative Correlative, l1.Mark Mark, l1.Reference Reference,l1.Description Description,(l1.PesoBulto - l1.Tara) PesoBulto ,l1.Price Price,l1.Measure Measure,l1.Number Number,l1.YEAR YEAR,l1.Line Line,l1.LineaBulto LineaBulto,l1.Codigo Codigo,l1.Umedida Umedida,l1.Categoria Categoria,(l1.Price + l1.MO + l1.GF) PrecioEstimado,l1.Marca, l1.TipoCambio FROM ( " &
                        "   SELECT cc.cat_ext TipoProducto,db.BDoc_Box_Hsm Correlative,db.BDoc_Box_Cod Mark, h.HDoc_DR1_Num Reference, d.DDoc_Prd_Des Description, db.BDoc_Box_LB PesoBulto, d.DDoc_Prd_NET Price, c.cat_clave Measure, d.DDoc_Doc_Num Number, d.DDoc_Doc_Ano YEAR, d.DDoc_Doc_Lin Line, db.BDoc_Box_Lin LineaBulto, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_UM Umedida, db.BDoc_Box_Ctg Categoria,db.BDoc_Box_Cod Marca,db.BDoc_Box_Ord Tara, IFNULL((  " &
                        "   SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total " &
                        "   FROM Gastos_Produccion g " &
                        "    LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda And c.cat_clase = 'Monedas' " &
                        "      LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' " &
                        "           WHERE g.idEmpresa = " & Sesion.IdEmpresa & " AND gp.cat_desc = 'Mano de Obra' " &
                        "               ORDER BY g.idGastoProduccion DESC " &
                        "                   LIMIT 1), 0) MO, IFNULL(( " &
                        "               SELECT ROUND((g.Promedio + g.Total1 + g.Total2),2) Total " &
                        "                   FROM Gastos_Produccion g " &
                        "                       LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' " &
                        "                           LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' " &
                        "                               WHERE g.idEmpresa = " & Sesion.IdEmpresa & " AND gp.cat_desc = 'Gastos de fabricación' " &
                        "                                   ORDER BY g.idGastoProduccion DESC " &
                        "                                       LIMIT 1), 0) GF, h.HDoc_Doc_TC TipoCambio " &
                        "                                           FROM Dcmtos_DTL d" &
                         " LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND db.BDoc_Doc_Num = d.DDoc_Doc_Num AND db.BDoc_Doc_Lin = d.DDoc_Doc_Lin " &
                         " LEFT JOIN Dcmtos_DTL_Box_Pro bp ON bp.BPDoc_Sis_Emp = db.BDoc_Sis_Emp AND bp.BPDoc_Par_Num = db.BDoc_Doc_Num AND bp.BPDoc_Par_Cat = db.BDoc_Doc_Cat AND bp.BPDoc_Par_Ano = db.BDoc_Doc_Ano AND bp.BPDoc_Par_Lin = db.BDoc_Doc_Lin AND bp.BPDoc_Box_Lin = db.BDoc_Box_Lin AND bp.BPDoc_Chi_Cat= 952 " &
                         " LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND cat_clase = 'Medidas' " &
                         "  LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = db.BDoc_Sis_Emp AND h.HDoc_Doc_Cat = db.BDoc_Doc_Cat AND h.HDoc_Doc_Ano = db.BDoc_Doc_Ano AND h.HDoc_Doc_Num = db.BDoc_Doc_Num " &
                         " LEFT JOIN Inventarios i ON i.inv_sisemp = h.HDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod " &
                          " LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo" &
                          " LEFT JOIN Catalogos cc ON cc.cat_clase = 'ClaseArt' AND cc.cat_num = a.art_clase " &
                          " LEFT JOIN Materiales m ON m.det_sisemp = a.art_sisemp AND m.det_articulo = a.art_codigo " & condicion
            frm.FiltroText = " Enter description "
            frm.Filtro = " l2.Mark "
            frm.Condicion = " l2.Price > 0 "
            frm.Ordenamiento = " l2.Mark "
            frm.TipoOrdenamiento = " ASC"
            frm.Multiple = True
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then

                For i = 0 To frm.DataGrid.Rows.Count - 1
                    If frm.ListaClientes.Rows(i).Cells("colCheck").Value = True Then
                        sumaCant = INT_CERO
                        logVerificar = True
                        If dgDetalle.Rows.Count > 0 Then
                            For k = 0 To dgDetalle.Rows.Count - 1
                                '7 es 11, 5 es 10, 4 es 8, 3 es 9
                                If frm.ListaClientes.Rows(i).Cells(9).Value = dgDetalle.Rows(k).Cells("colRefAnio").Value And frm.ListaClientes.Rows(i).Cells(8).Value = dgDetalle.Rows(k).Cells("colRefNum").Value And frm.ListaClientes.Rows(i).Cells(10).Value = dgDetalle.Rows(k).Cells("colRefLin").Value And frm.ListaClientes.Rows(i).Cells(11).Value = dgDetalle.Rows(k).Cells("colBultoB").Value Then
                                    MsgBox("The package " & frm.ListaClientes.Rows(i).Cells(11).Value & " has already been selected, select another", vbInformation, "Notice")
                                    logVerificar = False
                                Else
                                    logVerificar = True
                                End If
                            Next
                        End If
                        If logVerificar = True Then
                            sumaCant = sumaCant + frm.ListaClientes.Rows(i).Cells(5).Value
                            dblSaldo = celdaSaldo.Text
                            ' valida si tiene saldo para adjuntar mas bultos 
                            ' valida empresa HSM

                            If sumaCant <= celdaSaldo.Text Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                                strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                strFila &= 47 & "|" 'Catalogo
                                strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                strFila &= frm.ListaClientes.Rows(i).Cells(16).Value & "|" ' Marca 
                                strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                '    strFila &= "" & "|" 'Clasificacion
                                strFila &= CDbl(frm.ListaClientes.Rows(i).Cells(6).Value) & "|" ' Costo
                                strFila &= sumaCant.ToString(FORMATO_MONEDA) & "|" 'Cantidad
                                '  strFila &= "" & "|" 'Porcentaje
                                strFila &= frm.ListaClientes.Rows(i).Cells(15).Value & "|" '  Precio Medido
                                strFila &= CDbl(((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant))).ToString(FORMATO_MONEDA) & "|" ' Total
                                strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                '   strFila &= "" & "|" ' Verificador
                                strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" '  Linea
                                strFila &= frm.ListaClientes.Rows(i).Cells(11).Value & "|" '  Linea Bulto
                                strFila &= INT_CERO & "|"  'Extra
                                strFila &= INT_CERO & "|" ' Status PO
                                strFila &= INT_CERO & "|" ' Linea PO
                                strFila &= frm.ListaClientes.Rows(i).Cells(1).Value & "|" ' Correlativo
                                strFila &= frm.ListaClientes.Rows(i).Cells(17).Value    ' tasaCambio
                                cFunciones.AgregarFila(dgDetalle, strFila)
                                celdaSaldo.Text = (dblSaldo - sumaCant).ToString(FORMATO_MONEDA)
                            ElseIf sumaCant <= (celdaSaldo.Text / (PorcentajeEstimado() / 100)) Then
                                strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                strFila &= 47 & "|" 'Catalogo
                                strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                strFila &= frm.ListaClientes.Rows(i).Cells(16).Value & "|" ' Marca 
                                strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                '    strFila &= "" & "|" 'Clasificacion
                                strFila &= CDbl(frm.ListaClientes.Rows(i).Cells(6).Value) & "|" ' Costo
                                strFila &= sumaCant.ToString(FORMATO_MONEDA) & "|" 'Cantidad
                                '  strFila &= "" & "|" 'Porcentaje
                                strFila &= frm.ListaClientes.Rows(i).Cells(15).Value & "|" '  Precio Medido
                                strFila &= CDbl(((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant))).ToString(FORMATO_MONEDA) & "|" ' Total
                                strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                '   strFila &= "" & "|" ' Verificador
                                strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" '  Linea
                                strFila &= frm.ListaClientes.Rows(i).Cells(11).Value & "|" '  Linea Bulto
                                strFila &= INT_CERO & "|"  'Extra
                                strFila &= INT_CERO & "|" ' Status PO 
                                strFila &= INT_CERO & "|" ' Linea PO
                                strFila &= frm.ListaClientes.Rows(i).Cells(1).Value & "|"  ' Correlativo
                                strFila &= frm.ListaClientes.Rows(i).Cells(17).Value    ' tasaCambio
                                cFunciones.AgregarFila(dgDetalle, strFila)
                                celdaSaldo.Text = (dblSaldo - sumaCant).ToString(FORMATO_MONEDA)
                            Else
                                If checkDespacharFibra.Checked = True Then
                                    strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                    strFila &= 47 & "|" 'Catalogo
                                    strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                    strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                    strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                    strFila &= frm.ListaClientes.Rows(i).Cells(16).Value & "|" ' Marca 
                                    strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                    '    strFila &= "" & "|" 'Clasificacion
                                    strFila &= CDbl(frm.ListaClientes.Rows(i).Cells(6).Value) & "|" ' Costo
                                    strFila &= sumaCant.ToString(FORMATO_MONEDA) & "|" 'Cantidad
                                    '  strFila &= "" & "|" 'Porcentaje
                                    strFila &= frm.ListaClientes.Rows(i).Cells(15).Value & "|" '  Precio Medido
                                    strFila &= CDbl(((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant))).ToString(FORMATO_MONEDA) & "|" ' Total
                                    strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                    strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                    '   strFila &= "" & "|" ' Verificador
                                    strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                    strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" '  Linea
                                    strFila &= frm.ListaClientes.Rows(i).Cells(11).Value & "|" '  Linea Bulto
                                    strFila &= INT_CERO & "|"  'Extra
                                    strFila &= INT_CERO & "|" ' Status PO
                                    strFila &= INT_CERO & "|" ' Linea PO
                                    strFila &= frm.ListaClientes.Rows(i).Cells(1).Value & "|"   ' Correlativo
                                    strFila &= frm.ListaClientes.Rows(i).Cells(17).Value    ' tasaCambio
                                    cFunciones.AgregarFila(dgDetalle, strFila)
                                    celdaSaldo.Text = (dblSaldo - sumaCant).ToString(FORMATO_MONEDA)
                                Else
                                    If PedirAutorizacionPO("PO") = True Then
                                        strFila = frm.ListaClientes.Rows(i).Cells(9).Value & "|" 'Anio
                                        strFila &= 47 & "|" 'Catalogo
                                        strFila &= frm.ListaClientes.Rows(i).Cells(8).Value & "|" 'Numero
                                        strFila &= frm.ListaClientes.Rows(i).Cells(12).Value & "|" 'Codigo
                                        strFila &= INT_CERO & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                                        strFila &= frm.ListaClientes.Rows(i).Cells(16).Value & "|" ' Marca 
                                        strFila &= frm.ListaClientes.Rows(i).Cells(4).Value & "|" ' Descripcion
                                        '    strFila &= "" & "|" 'Clasificacion
                                        strFila &= CDbl(frm.ListaClientes.Rows(i).Cells(6).Value) & "|" ' Costo
                                        strFila &= sumaCant.ToString(FORMATO_MONEDA) & "|" 'Cantidad
                                        '  strFila &= "" & "|" 'Porcentaje
                                        strFila &= frm.ListaClientes.Rows(i).Cells(15).Value & "|" '  Precio Medido
                                        strFila &= CDbl(((frm.ListaClientes.Rows(i).Cells(6).Value) * (sumaCant))).ToString(FORMATO_MONEDA) & "|" ' Total
                                        strFila &= frm.ListaClientes.Rows(i).Cells(13).Value & "|" 'Id Medida
                                        strFila &= frm.ListaClientes.Rows(i).Cells(7).Value & "|" 'Medida
                                        '   strFila &= "" & "|" ' Verificador
                                        strFila &= frm.ListaClientes.Rows(i).Cells(3).Value & "|" ' Referencia
                                        strFila &= frm.ListaClientes.Rows(i).Cells(10).Value & "|" '  Linea
                                        strFila &= frm.ListaClientes.Rows(i).Cells(11).Value & "|" '  Linea Bulto
                                        strFila &= INT_CERO & "|"  'Extra
                                        strFila &= INT_CERO & "|" ' Status PO
                                        strFila &= INT_CERO & "|" ' Linea PO
                                        strFila &= frm.ListaClientes.Rows(i).Cells(1).Value & "|"   ' Correlativo
                                        strFila &= frm.ListaClientes.Rows(i).Cells(17).Value    ' tasaCambio
                                        cFunciones.AgregarFila(dgDetalle, strFila)
                                        celdaSaldo.Text = (dblSaldo - sumaCant).ToString(FORMATO_MONEDA)
                                    End If
                                End If
                            End If
                        End If
                    End If
                Next
            End If
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0
        Try
            If celdaReferencia.Text = vbNullString Then
                MsgBox("Blank reference", vbCritical)
                Comprobar = False
                Exit Function
            End If
            If checkDespacharFibra.Checked = False Then
                If celdaPO.Text = vbNullString Then
                    MsgBox("Blank PO Production", vbCritical)
                    Comprobar = False
                    Exit Function
                End If
            End If

            If rbMezcla.Checked = True Then
                Comprobar = True
            ElseIf rbCotton.Checked = True Then
                Comprobar = True
            ElseIf rbPoly.Checked = True Then
                Comprobar = True
            ElseIf rbRayon.Checked = True Then
                Comprobar = True
            ElseIf rbSpandex.Checked = True Then
                Comprobar = True
            Else
                MsgBox("Incomplete data please check one option", vbCritical)
                Comprobar = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Comprobar
    End Function
    Private Function ComprobarDetalles() As Boolean
        Dim Comprobar As Boolean = True
        If dgDetalle.RowCount > 0 Then 'comprueba que el datagrid de Productos tengo al menos 1 Linea
        Else
            Comprobar = False
            Exit Function
        End If
        Return Comprobar
    End Function
    Private Function GuardarEncabezado(ByVal intCodigo As Integer, Optional logMezcla As Boolean = False) As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim logResultado As Boolean = True
        Try

            CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            CHDR.HDOC_DOC_CAT = 952
            CHDR.HDOC_DOC_ANO = celdaAnio.Text
            CHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            CHDR.HDOC_DOC_MON = celdaIdMoneda.Text
            CHDR.HDOC_DOC_TC = celdaTasa.Text
            CHDR.HDOC_DR1_NUM = celdaReferencia.Text
            CHDR.HDOC_RF1_DBL = celdaPrecio.Text
            CHDR.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)
            CHDR.HDOC_EMP_COD = IIf(checkDespacharFibra.Checked = True, 1, vbEmpty)
            'If logMezcla = True Then
            '    CHDR.HDOC_DR1_CAT = INT_CERO
            'Else
            '    CHDR.HDOC_DR1_CAT = intCodigo
            'End If
            If rbMezcla.Checked = True Then
                CHDR.HDOC_DR1_CAT = INT_CERO
            ElseIf rbCotton.Checked = True Then
                CHDR.HDOC_DR1_CAT = INT_UNO
            ElseIf rbPoly.Checked = True Then
                CHDR.HDOC_DR1_CAT = 2
            ElseIf rbRayon.Checked = True Then
                CHDR.HDOC_DR1_CAT = 3
            ElseIf rbSpandex.Checked = True Then
                CHDR.HDOC_DR1_CAT = 4
            End If
            CHDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                celdaNumero.Text = cFunciones.NuevoId(952)
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Guardar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            Else
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Actualizar = False Then
                    logResultado = False
                    MsgBox(CHDR.MERROR.ToString)
                Else
                    logResultado = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Sub GuardarDetalle()
        Dim cDTL As New clsDcmtos_DTL
        Try
            For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
                cDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.DDOC_DOC_CAT = 952
                cDTL.DDOC_DOC_ANO = celdaAnio.Text
                cDTL.DDOC_DOC_NUM = celdaNumero.Text


                'TODO CODIGO DE PRODUCTO
                cDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                cDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                cDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value
                cDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                If checkDespacharFibra.Checked = True Then
                    cDTL.DDOC_PRD_QTY = 0 'dgDetalle.Rows(i).Cells("colCantidad").Value
                Else
                    cDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                End If

                cDTL.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colMarca").Value
                cDTL.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colTipoCambio").Value
                'TODO ID MEDIDA
                cDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colReferencia1").Value
                cDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colPrecioMedida").Value
                If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then             ' INSERTAR
                    dgDetalle.Rows(i).Cells("colLinea").Value = NuevaLinea()
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Guardar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then ' ACTUALIZAR
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Actualizar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then ' Borrar
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Borrar = False Then                                      ' BORRAR
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarDescargos() As Boolean
        Dim logResultado As Boolean = True
        Dim i As Integer
        Dim pro As New clsDcmtos_DTL_Pro

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = dgDetalle.Rows(i).Cells("colRefCatalogo").Value
                pro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colRefAnio").Value
                pro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colRefNum").Value
                pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colRefLin").Value  ' Que linea debe guardar aqui????????????????????
                pro.PDOC_CHI_CAT = 952
                pro.PDOC_CHI_ANO = celdaAnio.Text
                pro.PDOC_CHI_NUM = celdaNumero.Text
                pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                If checkActivar.Checked = True Then
                    If checkDespacharFibra.Checked = True Then
                        pro.PDOC_QTY_PRO = INT_CERO
                    Else
                        pro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value
                    End If

                Else
                    pro.PDOC_QTY_PRO = INT_CERO
                End If
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If pro.Actualizar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If pro.Borrar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function
    Private Function GuardarBultos() As Boolean
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim box As New Tablas.TDCMTOS_DTL_BOX

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                box.BDOC_SIS_EMP = Sesion.IdEmpresa
                box.BDOC_DOC_CAT = 952
                box.BDOC_DOC_ANO = celdaAnio.Text
                box.BDOC_DOC_NUM = celdaNumero.Text
                box.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                box.BDOC_BOX_COD = celdaReferencia.Text
                box.BDOC_BOX_QTY = INT_CERO
                If checkActivar.Checked = True Then
                    If checkDespacharFibra.Checked = True Then
                        box.BDOC_BOX_LB = INT_CERO
                    Else
                        box.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value
                    End If

                Else
                    box.BDOC_BOX_LB = INT_CERO
                End If
                box.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If box.PUPDATE() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If box.PINSERT() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If box.PDELETE() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado
    End Function
    Private Function GuardarDetalleBultos()
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim DetBox As New Tablas.TDCMTOS_DTL_BOX_PRO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                DetBox.BPDOC_SIS_EMP = Sesion.IdEmpresa
                If checkActivar.Checked = True Then
                    DetBox.BPDOC_PAR_CAT = dgDetalle.Rows(i).Cells("colRefCatalogo").Value
                    DetBox.BPDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colRefAnio").Value
                    DetBox.BPDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colRefNum").Value
                    DetBox.BPDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colRefLin").Value
                    DetBox.BPDOC_BOX_LIN = dgDetalle.Rows(i).Cells("colBultoB").Value
                Else
                    DetBox.BPDOC_PAR_CAT = INT_CERO
                    DetBox.BPDOC_PAR_ANO = INT_CERO
                    DetBox.BPDOC_PAR_NUM = INT_CERO
                    DetBox.BPDOC_PAR_LIN = INT_CERO
                    DetBox.BPDOC_BOX_LIN = INT_CERO
                End If
                DetBox.BPDOC_CHI_CAT = 952
                DetBox.BPDOC_CHI_ANO = celdaAnio.Text
                DetBox.BPDOC_CHI_NUM = celdaNumero.Text
                DetBox.BPDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                DetBox.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If DetBox.PINSERT = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                    'ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    ' If DetBox.PUPDATE = False Then
                    '  MsgBox(DetBox.MERROR.ToString & "Could Not Update the document", MsgBoxStyle.Critical)
                    'End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If DetBox.PDELETE = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not Delete the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 3 Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Par_Cat = {catP} AND BPDoc_Par_Ano = {anioP} AND BPDoc_Par_Num ={numP} AND BPDoc_Par_Lin = {LinP} AND BPDoc_Chi_Cat = {catC} AND BPDoc_Chi_Ano = {anioC} AND BPDoc_Chi_Num = {numC} AND BPDoc_Chi_Lin ={LinC} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{catP}", dgDetalle.Rows(i).Cells("colRefCatalogo").Value)
                    strSQL = Replace(strSQL, "{anioP}", dgDetalle.Rows(i).Cells("colRefAnio").Value)
                    strSQL = Replace(strSQL, "{numP}", dgDetalle.Rows(i).Cells("colRefNum").Value)
                    strSQL = Replace(strSQL, "{LinP}", dgDetalle.Rows(i).Cells("colRefLin").Value)
                    strSQL = Replace(strSQL, "{catC}", 952)
                    strSQL = Replace(strSQL, "{anioC}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numC}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{LinC}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                    box.CONEXION = strConexion
                    box.PDELETE(strSQL)
                End If
                If checkActivar.Checked = False Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = {cat} AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {num} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 952)
                    strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
                    Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                    box.CONEXION = strConexion
                    box.PDELETE(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function

    Private Sub GuardarKardex(ByVal intTipoKardex As Integer) ' 0 --> suma los montos, 1 --> resta los montos
        Try
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
            Dim strsql As String = STR_VACIO
            ' Variables que capturan los datos actuales de la PO
            Dim Cantidad_K As Double = INT_CERO
            Dim Total_K As Double = INT_CERO
            Dim kar As New Tablas.TKARDEX

            strsql = cfun.Kardex_PProceso(980, celdaidAñoPO.Text, celdaidPONumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader()
            If REA.HasRows Then
                Do While REA.Read
                    Cantidad_K = ConvertirSinNotacionCientifica(REA.GetDouble("Cantidad"), 8)
                    Total_K = ConvertirSinNotacionCientifica(REA.GetDouble("Total"), 8)
                Loop
            End If
            COM = Nothing
            REA.Close()

            kar.KAR_SIS_EMP = Sesion.IdEmpresa
            kar.KAR_DOC_CAT = 952
            kar.KAR_DOC_ANO = celdaAnio.Text
            kar.KAR_DOC_NUM = celdaNumero.Text
            kar.KAR_ONHAND = celdaPeso.Text 'Cantidad ingresada en el tendido
            kar.KAR_COST_LOC = celdaPrecio.Text ' Precio promedio del tendido
            kar.KAR_ONTRANSIT = celdaTotal.Text ' Total $ del tendido
            If intTipoKardex = 0 Then
                kar.KAR_COMMITTED = Math.Round((Cantidad_K + celdaPeso.Text), 8)  'Saldo de libras, sumando lo que se está ingresando con la linea anterior
                kar.KAR_PHY_INC = Math.Round((Total_K + celdaTotal.Text), 8) 'Saldo en $, sumando el total que está ingresando con la linea anterior
                kar.KAR_COST_EXT = Math.Round(((Total_K + celdaTotal.Text) / (Cantidad_K + celdaPeso.Text)), 8) 'Costo Promedio para la PO
            Else
                kar.KAR_COMMITTED = Math.Round((Cantidad_K - celdaPeso.Text), 8)  'Saldo de libras, restando lo que se está ingresando con la linea anterior
                kar.KAR_PHY_INC = Math.Round((Total_K - celdaTotal.Text), 8) 'Saldo en $, restando el total que está ingresando con la linea anterior
                If kar.KAR_COMMITTED = 0 Then
                    kar.KAR_COST_EXT = 0
                Else
                    kar.KAR_COST_EXT = Math.Round(((Total_K - celdaTotal.Text) / (Cantidad_K - celdaPeso.Text)), 8) 'Costo Promedio para la PO
                End If

            End If
            kar.KAR_DOC_MON = celdaIdMoneda.Text
            kar.KAR_DOC_TC = celdaTasa.Text
            kar.Kar_Opr_Fec_NET = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
            kar.Kar_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            ' llave de PO
            kar.KAR_PO_CAT = 980
            kar.KAR_PO_ANO = celdaidAñoPO.Text
            kar.KAR_PO_NUM = celdaidPONumero.Text

            kar.CONEXION = strConexion

            If kar.PINSERT = False Then
                MsgBox(kar.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Function ConvertirSinNotacionCientifica(valorTexto As String, decimales As Integer) As Double
        If String.IsNullOrWhiteSpace(valorTexto) Then
            Throw New ArgumentException("El valor proporcionado está vacío o es nulo.")
        End If

        ' Eliminar notación científica si existe
        Dim indexE As Integer = valorTexto.ToLower().IndexOf("e")
        If indexE >= 0 Then
            valorTexto = valorTexto.Substring(0, indexE)
        End If

        ' Convertir y redondear
        Dim valor As Double = Double.Parse(valorTexto, System.Globalization.CultureInfo.InvariantCulture)
        Return Math.Round(valor, decimales, MidpointRounding.AwayFromZero)
    End Function

    Private Sub Reset()
        celdaTasa.Text = cFunciones.QueryTasa()
        dtpFecha.Value = Today
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = NO_FILA
        celdaReferencia.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        celdaIdMoneda.Text = 178 'dolares
        celdaMoneda.Text = "USD $"
        rbMezcla.Checked = False
        rbCotton.Checked = False
        rbPoly.Checked = False
        rbRayon.Checked = False
        rbSpandex.Checked = False
        celdaTotal.Text = INT_CERO
        celdaPrecio.Text = INT_CERO
        celdaPeso.Text = INT_CERO
        celdaidAñoPO.Text = NO_FILA
        celdaidPONumero.Text = NO_FILA
        celdaPO.Text = STR_VACIO
        checkActivar.Checked = True
        checkDespacharFibra.Checked = False
    End Sub
    Private Function SQLDetalle(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT d.DDoc_Doc_Lin Linea,d.DDoc_Prd_Cod Codigo,	d.DDoc_Prd_Des Descripcion ,d.DDoc_Prd_UM idMedida , c.cat_clave Medida ,d.DDoc_Prd_NET Precio, d.DDoc_Prd_QTY Cantidad , d.DDoc_RF1_Cod Referencia, "
            strSQL &= "     dp.PDoc_Par_Cat Catalogo , dp.PDoc_Par_Ano Anio, dp.PDoc_Par_Num Num, dp.PDoc_Par_Lin LineaRef, "
            strSQL &= "         IFNULL(dbp.BPDoc_Box_Lin,0) LineaBultos,d.DDoc_RF1_Dbl PrecioEstimado,d.DDoc_Prd_PNr Marca,IFNULL(d980.DDoc_Doc_Lin,-1) LineaPO,IFNULL(db47.BDoc_Box_Hsm,'') Correlativo,d.DDoc_RF2_Dbl TasaCambio "
            strSQL &= "             FROM Dcmtos_DTL d LEFT JOIN Dcmtos_HDR h ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp and d.DDoc_Doc_Cat=h.HDoc_Doc_Cat and d.DDoc_Doc_Ano=h.HDoc_Doc_Ano and d.DDoc_Doc_Num=h.HDoc_Doc_Num "
            strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND dp.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND dp.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND dp.PDoc_Chi_Num = d.DDoc_Doc_Num AND dp.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND db.BDoc_Doc_Num = d.DDoc_Doc_Num AND db.BDoc_Doc_Lin = d.DDoc_Doc_Lin "
            strSQL &= "                         LEFT JOIN Dcmtos_DTL_Box_Pro dbp ON dbp.BPDoc_Sis_Emp = d.DDoc_Sis_Emp AND dbp.BPDoc_Chi_Cat = d.DDoc_Doc_Cat AND dbp.BPDoc_Chi_Ano = d.DDoc_Doc_Ano AND dbp.BPDoc_Chi_Num = d.DDoc_Doc_Num AND dbp.BPDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strSQL &= "                       LEFT JOIN Dcmtos_DTL_Box_Pro dp952 ON dp952.BPDoc_Sis_Emp AND dp952.BPDoc_Par_Cat = d.DDoc_Doc_Cat AND dp952.BPDoc_Par_Ano = d.DDoc_Doc_Ano AND dp952.BPDoc_Par_Num = d.DDoc_Doc_Num   "
            strSQL &= "                    LEFT JOIN Dcmtos_DTL_Box db47 ON db47.BDoc_Sis_Emp = dbp.BPDoc_Sis_Emp AND db47.BDoc_Doc_Cat = dbp.BPDoc_Par_Cat AND db47.BDoc_Doc_Ano = dbp.BPDoc_Par_Ano AND db47.BDoc_Doc_Num = dbp.BPDoc_Par_Num AND db47.BDoc_Box_Lin = dbp.BPDoc_Box_Lin AND db47.BDoc_Box_Cod = d.DDoc_Prd_PNr "
            strSQL &= "                 LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase = 'Medidas' "
            strSQL &= "              LEFT JOIN Dcmtos_DTL_Box_Pro dp980 ON dp980.BPDoc_Sis_Emp = d.DDoc_Sis_Emp AND dp980.BPDoc_Par_Cat = d.DDoc_Doc_Cat AND dp980.BPDoc_Par_Ano = d.DDoc_Doc_Ano AND dp980.BPDoc_Par_Num = d.DDoc_Doc_Num AND 	 dp980.BPDoc_Par_Lin = d.DDoc_Doc_Lin AND dp980.BPDoc_Chi_Cat = 980 "
            strSQL &= "          LEFT JOIN Dcmtos_DTL d980 ON d980.DDoc_Sis_Emp = dp980.BPDoc_Sis_Emp AND d980.DDoc_Doc_Cat = dp980.BPDoc_Chi_Cat AND d980.DDoc_Doc_Ano = dp980.BPDoc_Chi_Ano AND d980.DDoc_Doc_Num = dp980.BPDoc_Chi_Num AND d980.DDoc_Doc_Lin = dp980.BPDoc_Chi_Lin "
            strSQL &= "       WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 952 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "
            strSQL &= "     GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano,d.DDoc_Doc_Num,d.DDoc_Doc_Lin"
            strSQL &= "   ORDER BY d.DDoc_Sis_Emp,d.DDoc_Doc_Cat,d.DDoc_Doc_Num,d.DDoc_Doc_Lin"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim sumaCant As Double = 0
        Try
            strSQL = SQLDetalle(Anio, Num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    sumaCant = INT_CERO
                    strFila = REA.GetInt32("Anio") & "|" 'Anio
                    strFila &= REA.GetInt32("Catalogo") & "|" 'Catalogo
                    strFila &= REA.GetInt32("Num") & "|" 'Numero
                    strFila &= REA.GetInt32("Codigo") & "|" 'Codigo
                    strFila &= REA.GetInt32("Linea") & "|" 'frm.ListaClientes.Rows(i).Cells(6).Value & "|" 'Linea
                    strFila &= REA.GetString("Marca") & "|" ' Marca
                    strFila &= REA.GetString("Descripcion") & "|" ' Descripcion
                    '    strFila &= "" & "|" 'Clasificacion
                    strFila &= REA.GetDouble("Precio") & "|" ' Costo
                    sumaCant = sumaCant + REA.GetDouble("Cantidad")
                    strFila &= sumaCant.ToString(FORMATO_MONEDA) & "|" 'Cantidad
                    '  strFila &= "" & "|" 'Porcentaje
                    strFila &= REA.GetDouble("PrecioEstimado") & "|" ' Precio Estimado
                    strFila &= ((REA.GetDouble("Precio")) * (sumaCant)).ToString(FORMATO_MONEDA) & "|" ' Total
                    strFila &= REA.GetInt32("idMedida") & "|" 'Id Medida
                    strFila &= REA.GetString("Medida") & "|" 'Medida
                    '   strFila &= "" & "|" ' Verificador
                    strFila &= REA.GetString("Referencia") & "|" ' Referencia
                    strFila &= REA.GetInt32("LineaRef") & "|" '  Linea
                    strFila &= REA.GetInt32("LineaBultos") & "|" '  Linea Bulto
                    strFila &= INT_UNO & "|"  'Extra
                    If celdaPO.Text = STR_VACIO Then
                        strFila &= INT_CERO & "|" ' Status PO
                    Else
                        strFila &= INT_UNO & "|" ' Status PO
                    End If
                    strFila &= REA.GetInt32("LineaPO") & "|" ' Linea PO
                    strFila &= REA.GetString("Correlativo") & "|" ' Linea PO 
                    strFila &= REA.GetDouble("TasaCambio")  ' Tipo Cambio

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLEncabezado(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT h.HDoc_Emp_Cod fibra, h.HDoc_Doc_Ano Anio , h.HDoc_Doc_Num Numero , h.HDoc_Doc_Fec Fecha , h.HDoc_DR1_Num Referencia , h.HDoc_Doc_TC Tasa , h.HDoc_Doc_Mon idMoneda , c.cat_clave Moneda,h.HDoc_DR1_Cat opciones,h.HDoc_Doc_Status Estado,IFNULL(h980.HDoc_Doc_Ano,-1) anioPO, IFNULL(h980.HDoc_Doc_Num,-1) numeroPO, IFNULL(h980.HDoc_DR1_Num,'') ReferenciaPO "
            strSQL &= "     FROM Dcmtos_HDR h  "
            strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase='Monedas' "
            strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Par_Cat = h.HDoc_Doc_Cat AND p.PDoc_Par_Ano = h.HDoc_Doc_Ano AND p.PDoc_Par_Num = h.HDoc_Doc_Num AND p.PDoc_Chi_Cat = 980 "
            strSQL &= "                 LEFT JOIN Dcmtos_HDR h980 ON h980.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h980.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND h980.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND h980.HDoc_Doc_Num = p.PDoc_Chi_Num"
            strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 952 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
            strSQL &= "         GROUP BY h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano, h.HDoc_Doc_Num "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = SQLEncabezado(Anio, Num)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAnio.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("Numero")
                celdaReferencia.Text = REA.GetString("Referencia")
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                celdaTasa.Text = REA.GetDouble("Tasa")
                celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                celdaMoneda.Text = REA.GetString("Moneda")
                If REA.GetInt32("opciones") = INT_CERO Then
                    rbMezcla.Checked = True
                ElseIf REA.GetInt32("opciones") = INT_UNO Then
                    rbCotton.Checked = True
                ElseIf REA.GetInt32("opciones") = 2 Then
                    rbPoly.Checked = True
                ElseIf REA.GetInt32("opciones") = 3 Then
                    rbRayon.Checked = True
                ElseIf REA.GetInt32("opciones") = 4 Then
                    rbSpandex.Checked = True
                End If
                celdaidAñoPO.Text = REA.GetInt32("anioPO")
                celdaidPONumero.Text = REA.GetInt32("numeroPO")
                celdaPO.Text = REA.GetString("ReferenciaPO")

                If REA.GetInt32("fibra") = INT_CERO Then
                    checkDespacharFibra.Checked = False
                    botonPO.Enabled = True
                Else
                    checkDespacharFibra.Checked = True
                    botonPO.Enabled = False
                End If
                If REA.GetInt32("Estado") = INT_CERO Then
                    checkActivar.Checked = False
                    bloquear()
                Else
                    checkActivar.Checked = True
                    Activar()
                End If
                If REA.GetInt32("numeroPO") <> NO_FILA Then
                    botonPO.Enabled = False
                Else
                    botonPO.Enabled = True
                End If
            Loop
        End If

    End Sub

    'Borrar Kardex
    Public Sub BorrarKardex()
        Dim strsql As String = STR_VACIO
        Try

            strsql = "Kar_Sis_Emp = {emp} AND Kar_Doc_Cat = 952 AND Kar_Doc_Ano = {anio} AND Kar_Doc_Num = {num} "

            strsql = Replace(strsql, "{emp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAnio.Text)
            strsql = Replace(strsql, "{num}", celdaNumero.Text)

            Dim kardex As New Tablas.TKARDEX
            kardex.CONEXION = strConexion
            kardex.PDELETE(strsql)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Borrar Encabezado Ingreso
    Public Function BorrarEncabezado() As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 952
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Detalle Ingreso
    Private Function BorrarDetalle() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO

        Try
            If LogBorrar = True Then
                MyCnn.CONECTAR = strConexion
                strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 952 AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero} ;"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                Dim dtl As New clsDcmtos_DTL
                dtl.CONEXION = strConexion
                dtl.Borrar(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Descargo 
    Private Function BorrarDescargos() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '   For i = 0 To dgDetalle.Rows.Count - 1
                strSQl &= "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 952 AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero}  ;"
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                '    Next
                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultos() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '   For i = 0 To dgDetalle.Rows.Count - 1
                strSQl = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = 952 AND BDoc_Doc_Ano  = {anio} AND BDoc_Doc_Num = {numero}  ;"
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                '    Next
                Dim box As New Tablas.TDCMTOS_DTL_BOX
                box.CONEXION = strConexion
                box.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultosPro() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '   For i = 0 To dgDetalle.Rows.Count - 1
                strSQL &= "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = 952 AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {numero};"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                '    Next
                Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                box.CONEXION = strConexion
                box.PDELETE(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Sub CalcularTotales()
        Dim dblTotal As Double = INT_CERO
        Dim dblPeso As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim intlinea As Integer = INT_CERO
        Dim vTCPromedio As Double = INT_CERO
        Dim TotalCordobas As Double = INT_CERO
        Dim intContarLineas As Integer = 0
        Dim i As Integer = 0
        For i = 0 To dgDetalle.Rows.Count - 1
            If Not dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                intlinea = intlinea + 1
                dgDetalle.Rows(i).Cells("colTotal").Value = (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)).ToString(FORMATO_MONEDA)
                dblTotal = dblTotal + (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value))
                dblPeso = dblPeso + (dgDetalle.Rows(i).Cells("colCantidad").Value)
                dblPrecio = dblPrecio + (dgDetalle.Rows(i).Cells("colPrecio").Value)
                TotalCordobas = TotalCordobas + (CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value) * CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)) * CDbl(dgDetalle.Rows(i).Cells("colTipoCambio").Value)
                'vTCPromedio = TotalCordobas / dblTotal
                intContarLineas += 1
            End If

        Next

        celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
        celdaPeso.Text = dblPeso.ToString(FORMATO_MONEDA)
        celdaPrecio.Text = (dblTotal / dblPeso) ' (dblPrecio / intlinea) '.ToString(FORMATO_MONEDA) se quitó el redondeo en el precio promedio ML(21-06-2023)
        vTCPromedio = TotalCordobas / dblTotal
        celdaTasa.Text = vTCPromedio '(vTCPromedio / intlinea).ToString("#,##0.0000")
        celdaLineas.Text = intContarLineas
    End Sub
    Public Sub bloquear()
        celdaReferencia.ReadOnly = True
        celdaTasa.ReadOnly = True
        botonAgregar.Enabled = False
        botonQuitar.Enabled = False
        checkActivar.Enabled = False
        checkDespacharFibra.Enabled = False
        rbMezcla.Enabled = False
        rbCotton.Enabled = False
        rbPoly.Enabled = False
        rbRayon.Enabled = False
        rbSpandex.Enabled = False
        botonPO.Enabled = False
    End Sub
    Public Sub Activar()
        celdaReferencia.ReadOnly = False
        celdaTasa.ReadOnly = False
        botonAgregar.Enabled = True
        botonQuitar.Enabled = True
        checkActivar.Enabled = True
        checkDespacharFibra.Enabled = True
        rbMezcla.Enabled = True
        rbCotton.Enabled = True
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            rbPoly.Enabled = False
            rbRayon.Enabled = False
            rbSpandex.Enabled = False
        Else
            rbPoly.Enabled = True
            rbRayon.Enabled = True
            rbSpandex.Enabled = True
        End If
        botonPO.Enabled = True
    End Sub
    ' Procedimientos para Guardar en Pedido Produccion de hilo 
    Public Sub MostrarPO()
        Dim frm As New frmSeleccionar
        Dim fechaInicio As Date
        Dim sCondicion As String
        Dim strTabla As String
        Try
            fechaInicio = DateTime.Now.AddMonths(-14)
            frm.Titulo = "PO "
            frm.Campos = "  l2.* FROM ( SELECT l1.Reference Reference, l1.ID ID, l1.YEAR YEAR, round(l1.Saldo,2) Saldo "
            strTabla = "   ( SELECT h.HDoc_DR1_Num Reference, h.HDoc_Doc_Num ID, h.HDoc_Doc_Ano YEAR,ROUND((h.HDoc_RF1_Dbl / c.cat_sist),2)  - COALESCE  " &
                                "   (( SELECT SUM(b.BDoc_Box_LB)" &
                                        "   FROM Dcmtos_DTL_Box b  WHERE b.BDoc_Sis_Emp = h.HDoc_Sis_Emp AND b.BDoc_Doc_Cat = h.HDoc_Doc_Cat AND b.BDoc_Doc_Ano = h.HDoc_Doc_Ano AND b.BDoc_Doc_Num = h.HDoc_Doc_Num),0) Saldo " &
                                            "   FROM  Dcmtos_HDR h " &
                                            "       LEFT JOIN Catalogos c ON c.cat_clase = 'Pop' AND c.cat_sisemp = " & Sesion.IdEmpresa
            frm.FiltroText = " Enter the number of the PO to Filter"
            'frm.Filtro = " cat_clave "

            sCondicion = "h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " And h.HDoc_Doc_Cat = 980 And HDoc_Doc_Status = 1 {fechas_}) l1 ) l2 "
            '{POlibre}"

            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                'sCondicion = Replace(sCondicion, "{POlibre}", " ")
                sCondicion = Replace(sCondicion, "{fechas_}", STR_VACIO)
            Else
                frm.Condicion2 = " (l2.Saldo > - 0.1) "
                'sCondicion = Replace(sCondicion, "{POlibre}", "HAVING (l2.Saldo > - 0.1) ")
                sCondicion = Replace(sCondicion, "{fechas_}", " And h.HDoc_Doc_Fec BETWEEN '" & fechaInicio.ToString(FORMATO_MYSQL) & "' AND '" & Now().ToString(FORMATO_MYSQL) & "'" & " ")
            End If
            frm.Tabla = strTabla & " WHERE " & sCondicion
            frm.Condicion = " l2.ID >0 "
            frm.Filtro = " l2.Reference "

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaPO.Text = frm.LLave
                celdaidPONumero.Text = frm.Dato
                celdaidAñoPO.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarEncabezadoPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            '   For i = 0 To dgDetalle.Rows.Count - 1
            strSQL = " UPDATE Dcmtos_HDR SET HDoc_Doc_TC=(
                        SELECT  SUM(DDoc_Prd_NET*DDoc_Prd_QTY*DDoc_RF2_Dbl)/SUM(DDoc_Prd_NET*DDoc_Prd_QTY)  tc_Promedio FROM Dcmtos_DTL 
                        WHERE DDoc_Doc_Cat = 980 and DDoc_Sis_Emp={empresa} and DDoc_Doc_Ano={anio} and DDoc_Doc_Num={numero} 
                        ) WHERE HDoc_Sis_Emp= {empresa} AND HDoc_Doc_Cat=980 AND HDoc_Doc_Ano={anio} AND HDoc_Doc_Num={numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Dcmtos_HDR SET HDoc_Doc_TC=(
                        SELECT  SUM(DDoc_Prd_NET*DDoc_Prd_QTY*DDoc_RF2_Dbl)/SUM(DDoc_Prd_NET*DDoc_Prd_QTY)  tc_Promedio FROM Dcmtos_DTL 
                        WHERE DDoc_Doc_Cat = 980 and DDoc_Sis_Emp={empresa} and DDoc_Doc_Ano={anio} and DDoc_Doc_Num={numero} 
                        ) WHERE HDoc_Sis_Emp= {empresa} AND HDoc_Doc_Cat=980 AND HDoc_Doc_Ano={anio} AND HDoc_Doc_Num={numero} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
            strSQL = Replace(strSQL, "{numero}", celdaidPONumero.Text)
            '    Next
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Sub GuardarDetallePO()
        Dim cDTL As New clsDcmtos_DTL
        Dim strSQL As String = STR_VACIO
        Try
            For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
                cDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.DDOC_DOC_CAT = 980
                cDTL.DDOC_DOC_ANO = celdaidAñoPO.Text
                cDTL.DDOC_DOC_NUM = celdaidPONumero.Text


                'TODO CODIGO DE PRODUCTO
                cDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                cDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                cDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value
                cDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                cDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                cDTL.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colMarca").Value
                cDTL.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colTipoCambio").Value
                'TODO ID MEDIDA
                cDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colReferencia1").Value
                cDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colPrecioMedida").Value
                If dgDetalle.Rows(i).Cells("colExtraPO").Value = 0 Then             ' INSERTAR
                    dgDetalle.Rows(i).Cells("colLineaPO").Value = NuevaLineaPO()
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaPO").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Guardar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 1 Then ' ACTUALIZAR
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaPO").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Actualizar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 2 Then ' Borrar
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaPO").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Borrar = False Then                                      ' BORRAR
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                End If
                If checkActivar.Checked = False Then
                    strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {cat} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num} AND DDoc_Doc_Lin = {linea} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 980)
                    strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
                    strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim dtl As New clsDcmtos_DTL
                    dtl.CONEXION = strConexion
                    dtl.Borrar(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaLineaPO() As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select ifnull(max(d.DDoc_Doc_Lin ),0)+1 from Dcmtos_DTL d "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 980 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", celdaidAñoPO.Text)
            strSQL = Replace(strSQL, "{numero}", celdaidPONumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Function GuardarBultosPO() As Boolean
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim box As New Tablas.TDCMTOS_DTL_BOX
        Dim strSQL As String = STR_VACIO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                box.BDOC_SIS_EMP = Sesion.IdEmpresa
                box.BDOC_DOC_CAT = 980
                box.BDOC_DOC_ANO = celdaidAñoPO.Text
                box.BDOC_DOC_NUM = celdaidPONumero.Text
                box.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaPO").Value
                box.BDOC_BOX_COD = celdaReferencia.Text
                box.BDOC_BOX_QTY = INT_CERO
                If checkActivar.Checked = True Then
                    If checkDespacharFibra.Checked = True Then
                        box.BDOC_BOX_LB = INT_CERO
                    Else
                        box.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value
                    End If

                Else
                    box.BDOC_BOX_LB = INT_CERO
                End If
                box.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtraPO").Value = 1 Then
                    If box.PUPDATE() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 0 Then
                    If box.PINSERT() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 2 Then
                    If box.PDELETE() = False Then
                        MsgBox(box.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
                If checkActivar.Checked = False Then
                    strSQL = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = {cat} AND BDoc_Doc_Ano = {anio} AND BDoc_Doc_Num = {num} AND BDoc_Doc_Lin = {linea}"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 980)
                    strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
                    strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim dbox As New Tablas.TDCMTOS_DTL_BOX
                    dbox.CONEXION = strConexion
                    dbox.PDELETE(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return LogResultado
    End Function
    Private Function GuardarDetalleBultosPO()
        Dim LogResultado As Boolean = True
        Dim i As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim DetBox As New Tablas.TDCMTOS_DTL_BOX_PRO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                DetBox.BPDOC_SIS_EMP = Sesion.IdEmpresa
                If checkActivar.Checked = True Then
                    DetBox.BPDOC_PAR_CAT = 952
                    DetBox.BPDOC_PAR_ANO = celdaAnio.Text
                    DetBox.BPDOC_PAR_NUM = celdaNumero.Text
                    DetBox.BPDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                    DetBox.BPDOC_BOX_LIN = dgDetalle.Rows(i).Cells("colBultoB").Value
                Else
                    DetBox.BPDOC_PAR_CAT = INT_CERO
                    DetBox.BPDOC_PAR_ANO = INT_CERO
                    DetBox.BPDOC_PAR_NUM = INT_CERO
                    DetBox.BPDOC_PAR_LIN = INT_CERO
                    DetBox.BPDOC_BOX_LIN = INT_CERO
                End If
                DetBox.BPDOC_CHI_CAT = 980
                DetBox.BPDOC_CHI_ANO = celdaidAñoPO.Text
                DetBox.BPDOC_CHI_NUM = celdaidPONumero.Text
                DetBox.BPDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaPO").Value
                DetBox.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtraPO").Value = 0 Then
                    If DetBox.PINSERT = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                    'ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    ' If DetBox.PUPDATE = False Then
                    '  MsgBox(DetBox.MERROR.ToString & "Could Not Update the document", MsgBoxStyle.Critical)
                    'End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 2 Then
                    If DetBox.PDELETE = False Then
                        MsgBox(DetBox.MERROR.ToString & "Could Not Delete the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 3 Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Par_Cat = {catP} AND BPDoc_Par_Ano = {anioP} AND BPDoc_Par_Num ={numP} AND BPDoc_Par_Lin = {LinP} AND BPDoc_Chi_Cat = {catC} AND BPDoc_Chi_Ano = {anioC} AND BPDoc_Chi_Num = {numC} AND BPDoc_Chi_Lin ={LinC} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{catP}", dgDetalle.Rows(i).Cells("colRefCatalogo").Value)
                    strSQL = Replace(strSQL, "{anioP}", dgDetalle.Rows(i).Cells("colRefAnio").Value)
                    strSQL = Replace(strSQL, "{numP}", dgDetalle.Rows(i).Cells("colRefNum").Value)
                    strSQL = Replace(strSQL, "{LinP}", dgDetalle.Rows(i).Cells("colRefLin").Value)
                    strSQL = Replace(strSQL, "{catC}", 952)
                    strSQL = Replace(strSQL, "{anioC}", celdaAnio.Text)
                    strSQL = Replace(strSQL, "{numC}", celdaNumero.Text)
                    strSQL = Replace(strSQL, "{LinC}", dgDetalle.Rows(i).Cells("colLinea").Value)
                    Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                    box.CONEXION = strConexion
                    box.PDELETE(strSQL)
                End If
                If checkActivar.Checked = False Then
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = {cat} AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {num} AND BPDoc_Chi_Lin= {linea} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 980)
                    strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
                    strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim box As New Tablas.TDCMTOS_DTL_BOX_PRO
                    box.CONEXION = strConexion
                    box.PDELETE(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogResultado
    End Function
    Private Function GuardarDescargosPO() As Boolean
        Dim logResultado As Boolean = True
        Dim i As Integer
        Dim pro As New clsDcmtos_DTL_Pro
        Dim strSQL As String = STR_VACIO
        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = 952
                pro.PDOC_PAR_ANO = celdaAnio.Text
                pro.PDOC_PAR_NUM = celdaNumero.Text
                pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value   ' Que linea debe guardar aqui????????????????????
                pro.PDOC_CHI_CAT = 980
                pro.PDOC_CHI_ANO = celdaidAñoPO.Text
                pro.PDOC_CHI_NUM = celdaidPONumero.Text
                pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaPO").Value
                If checkActivar.Checked = True Then
                    If checkDespacharFibra.Checked = True Then
                        pro.PDOC_QTY_PRO = INT_CERO
                    Else
                        pro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value
                    End If

                Else
                    pro.PDOC_QTY_PRO = INT_CERO
                End If
                If dgDetalle.Rows(i).Cells("colExtraPO").Value = 1 Then
                    If pro.Actualizar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 0 Then
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtraPO").Value = 2 Then
                    If pro.Borrar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                    End If
                End If
                If checkActivar.Checked = False Then
                    strSQL = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {cat}  AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num= {num} AND PDoc_Chi_Lin= {linea} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{cat}", 980)
                    strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
                    strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim dpro As New clsDcmtos_DTL_Pro
                    dpro.CONEXION = strConexion
                    dpro.Borrar(strSQL)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function
    ' Procedimiento para Borrar en Pedido Produccion de Hilo 
    Private Function BorrarDetallePO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO

        Try
            If LogBorrar = True Then
                MyCnn.CONECTAR = strConexion
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = 980 AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero} AND DDoc_Doc_Lin = {linea} ;"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaidPONumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim dtl As New clsDcmtos_DTL
                    dtl.CONEXION = strConexion
                    dtl.Borrar(strSQL)
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDescargosPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 980 AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea} ;"
                    strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                    strSQl = Replace(strSQl, "{anio}", celdaidAñoPO.Text)
                    strSQl = Replace(strSQl, "{numero}", celdaidPONumero.Text)
                    strSQl = Replace(strSQl, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim pro As New clsDcmtos_DTL_Pro
                    pro.CONEXION = strConexion
                    pro.Borrar(strSQl)
                Next
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQl, CON)
                COM.ExecuteNonQuery()
                COM = Nothing
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultosPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQl = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = 980 AND BDoc_Doc_Ano  = {anio} AND BDoc_Doc_Num = {numero} AND BDoc_Doc_Lin = {linea}  ;"
                    strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                    strSQl = Replace(strSQl, "{anio}", celdaidAñoPO.Text)
                    strSQl = Replace(strSQl, "{numero}", celdaidPONumero.Text)
                    strSQl = Replace(strSQl, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim dbox As New Tablas.TDCMTOS_DTL_BOX
                    dbox.CONEXION = strConexion
                    dbox.PDELETE(strSQl)
                Next
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarBultosProPO() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    strSQL = "BPDoc_Sis_Emp = {empresa} AND BPDoc_Chi_Cat = 980 AND BPDoc_Chi_Ano = {anio} AND BPDoc_Chi_Num = {numero} AND  BPDoc_Chi_Lin = {linea};"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaidPONumero.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaPO").Value)
                    Dim dbox As New Tablas.TDCMTOS_DTL_BOX_PRO
                    dbox.CONEXION = strConexion
                    dbox.PDELETE(strSQL)
                Next

                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function SaldoPO() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim dblSaldo As Double
        Try
            strSQL = " SELECT (l1.SaldoLibras - l1.Saldo) Saldo "
            strSQL &= "     FROM ( "
            strSQL &= "         SELECT ROUND((h.HDoc_RF1_Dbl / c.cat_sist),2) SaldoLibras, IFNULL(( "
            strSQL &= "             SELECT SUM(b.BDoc_Box_LB) "
            strSQL &= "                 FROM Dcmtos_DTL_Box b "
            strSQL &= "                     WHERE b.BDoc_Sis_Emp = h.HDoc_Sis_Emp AND b.BDoc_Doc_Cat = h.HDoc_Doc_Cat AND b.BDoc_Doc_Ano = h.HDoc_Doc_Ano AND b.BDoc_Doc_Num = h.HDoc_Doc_Num),0) Saldo "
            strSQL &= "                 FROM Dcmtos_HDR h "
            strSQL &= "             LEFT JOIN Catalogos c ON c.cat_clase = 'Pop' AND c.cat_sisemp = {empresa} "
            strSQL &= "          WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 980 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} )l1 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
            strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            dblSaldo = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return dblSaldo
    End Function
    Private Function PorcentajeEstimado() As Double
        Dim strSQL As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim dblSaldo As Double

        strSQL = " SELECT c.cat_sist Porcentaje "
        strSQL &= "     FROM Catalogos c  "
        strSQL &= "         WHERE c.cat_clase = 'porcentajeE' "
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        dblSaldo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

    End Function
    Private Function PedirAutorizacionPO(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AutorizarPO"
        Dim frm As frmAutorización
        PedirAutorizacionPO = False

        frm = New frmAutorización
        frm.Iniciar(952, STR_MARGEN, 0, "Autorizar PO")
        frm.etiquetaInfo.Text = "The amount of selected Pounds, exceeds the balance of the PO"
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionPO = True
                cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acConfirm, 0, 952, celdaAnio.Text, celdaNumero.Text, "Autorizó Saldo PO " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
    Public Sub PrecioEstimadoPO()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim intLinea As Integer = INT_CERO
        Dim dblPrecio As Double = INT_CERO

        strSQL = " SELECT d.DDoc_Prd_Net PrecioEstimado "
        strSQL &= "     FROM Dcmtos_DTL d "
        strSQL &= "         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 980 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
        strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                intLinea = intLinea + 1
                dblPrecio = dblPrecio + REA.GetDouble("PrecioEstimado")
            Loop
        End If
        REA.Close()
        COM = Nothing
        strSQL = STR_VACIO
        strSQL = " UPDATE  Dcmtos_HDR   SET HDoc_RF2_Dbl = {precio} WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 980 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE  PDM.Dcmtos_HDR   SET HDoc_RF2_Dbl = {precio} WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 980 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaidAñoPO.Text)
        strSQL = Replace(strSQL, "{num}", celdaidPONumero.Text)
        strSQL = Replace(strSQL, "{precio}", (dblPrecio / intLinea).ToString(FORMATO_MONEDA))
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        COM = Nothing
    End Sub
    Private Function ValidarTipoFibra(ByRef intCodigo As Integer, ByRef logMezcla As Boolean) As Boolean
        Dim logValidar As Boolean = True
        Dim logPrimera As Boolean = False
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If logPrimera = False Then
                    intCodigo = TipoFibra(dgDetalle.Rows(i).Cells("colCodigo").Value)
                    logMezcla = False
                    logPrimera = True
                Else
                    If intCodigo = TipoFibra(dgDetalle.Rows(i).Cells("colCodigo").Value) Then
                        intCodigo = TipoFibra(dgDetalle.Rows(i).Cells("colCodigo").Value)
                        logMezcla = False
                    Else
                        logMezcla = True
                        Exit For
                    End If
                End If
            Next
            If logMezcla = False Then
                If intCodigo = INT_CERO Then
                    MsgBox("Please verify the type of product you selected")
                    logValidar = False
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
    Private Function TipoFibra(ByVal intCodigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intTipo As Integer
        Try
            strSQL = " SELECT IFNULL(c.cat_pid ,0) Tipo "
            strSQL &= "     FROM Inventarios i "
            strSQL &= "         LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "             LEFT JOIN Catalogos c ON c.cat_num = a.art_clase AND c.cat_ext = 'Fibra' "
            strSQL &= "                  WHERE i.inv_sisemp = {empresa} AND i.inv_numero = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intCodigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader()
            If REA.HasRows Then
                Do While REA.Read
                    intTipo = REA.GetInt32("Tipo")
                Loop
            End If
            COM = Nothing
            REA.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intTipo
    End Function
#End Region
#Region "Eventos"
    Private Sub frmProduccionNSM_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CheckForIllegalCrossThreadCalls = False
        Accesos()
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)
        MostrarLista()
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        MostrarLista(False)
        celdaAnio.Text = cfun.AñoMySQL
        Reset()
        Activar()
        If Sesion.IdEmpresa = 22 Then
            panelTipo.Visible = False
            rbCotton.Checked = True
        Else
            panelTipo.Visible = True
        End If
    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        If Sesion.IdEmpresa = 22 Then
            Dim frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strTabla As String = STR_VACIO
            strCondicion = "inv_sisemp = {empresa} AND inv_status = 'activo' AND inv_generico=0"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strTabla = " Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMcmpra LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab LEFT JOIN Proveedores pro ON pro_sisemp = inv_sisemp AND pro_codigo = inv_provcod"

            Try
                frm.Titulo = "List of Products"
                frm.FiltroText = "Enter the Product Name to filter"
                frm.Campos = "inv_numero Inventory, TRIM(CONCAT(art_DLarga, ' ', IFNULL(p.cat_clave,''))) Description, m.cat_num CodeUnit, m.cat_clave Unit,inv_costo Cost, inv_prodlote Lot,  inv_artcodigo Product, IFNULL(pro.pro_proveedor,'')Manufacturer, IFNULL(p.cat_clave,'')Origin, inv_partnum Part, inv_prodano Year, inv_prodsem Week"
                frm.Tabla = strTabla
                frm.Condicion = strCondicion
                If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                    frm.Filtro = " inv_prodlote "
                Else
                    frm.Filtro = " inv_numero "
                End If
                frm.Ordenamiento = " inv_numero"
                frm.TipoOrdenamiento = ""
                frm.Limite = 150

                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then

                    Dim strFila As String = STR_VACIO
                    Dim linea As Integer = 0
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        linea = dgDetalle.Rows(i).Cells("colLinea").Value
                    Next
                    ' strFila = CeldaAño.Text & "|" & frm.LLave & "|" & linea + 1 & "|" & frm.LLave & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & frm.Dato4 & "|" & 1 & "|" & frm.Dato4 * 1 & "|" & 0 & "|" & frm.LLave & "|" & "" & "|" & linea + 1 & "|" & "|" & "|" & "|" & INT_CERO & "|" & "|" & 1 & "|" & 0
                    strFila = 0 & "|" 'Ref Año - ingreso
                    strFila &= 0 & "|" 'Ref Catalogo - ingreso
                    strFila &= 0 & "|" 'Ref número - ingreso
                    strFila &= frm.LLave & "|" 'código de inventario
                    strFila &= linea & "|" 'linea del documento actual
                    strFila &= 0 & "|" 'lote
                    strFila &= frm.Dato & "|" ' descripción
                    strFila &= frm.Dato4 & "|" ' precio
                    strFila &= 0 & "|" ' cantidad
                    strFila &= 0 & "|" 'frm.ListaClientes.SelectedCells(8).Value & "|" ' Origen
                    strFila &= 0 & "|" ' total
                    strFila &= frm.Dato2 & "|" ' idmedida
                    strFila &= frm.Dato3 & "|" ' medida
                    strFila &= 0 & "|" ' referencia1
                    strFila &= 0 & "|" ' Linea de ingreso  - ingreso
                    strFila &= 0 & "|" ' col bulto
                    strFila &= 0 & "|" ' col extra
                    strFila &= 0 & "|" ' col extraPO
                    strFila &= 0 & "|" ' col linea PO
                    strFila &= 0 & "|" ' col correlativo
                    strFila &= 0  ' col tipo de cambio

                    cFunciones.AgregarFila(dgDetalle, strFila)

                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            If checkDespacharFibra.Checked = False Then
                If celdaPO.Text <> STR_VACIO Then
                    MostrarBultosADescargar()
                Else
                    MsgBox("Please Select the PO")
                End If
            Else
                MostrarBultosADescargar()
            End If
        End If

    End Sub
    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Try
            Dim Count As Integer
            If dgDetalle.SelectedRows Is Nothing Then Exit Sub
            If Not Me.Tag = "Nuevo" Then
                If PedirAutorizacionPO("PO") = True Then
                    If dgDetalle.Rows.Count > 1 Then
                        Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                        For i As Integer = 0 To Count - 1
                            If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                        CInt(dgDetalle.SelectedCells(0).Value) & ", " &
                   CStr(dgDetalle.SelectedCells(1).Value) & " " &
                    CStr(dgDetalle.SelectedCells(2).Value) & " " &
                       CStr(dgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                        vbYes Then
                                If dgDetalle.SelectedCells(16).Value = 0 Or dgDetalle.SelectedCells(16).Value = 1 Then
                                    dgDetalle.SelectedCells(16).Value = 2
                                    dgDetalle.CurrentRow.Visible = False
                                    CalcularTotales()
                                ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                                    '  dgDetalle.SelectedCells(6).Value = 3
                                    ' dgDetalle.CurrentRow.Visible = False
                                    dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                                End If
                                If dgDetalle.SelectedCells(17).Value = 0 Or dgDetalle.SelectedCells(17).Value = 1 Then
                                    dgDetalle.SelectedCells(17).Value = 2
                                    CalcularTotales()
                                ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                                    dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                                End If
                            End If
                        Next
                    Else
                        MsgBox("you can not delete the last row")
                        Exit Sub
                    End If
                End If
            Else
                If dgDetalle.Rows.Count > 1 Then
                    Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                    For i As Integer = 0 To Count - 1
                        If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgDetalle.SelectedCells(0).Value) & ", " &
               CStr(dgDetalle.SelectedCells(1).Value) & " " &
                CStr(dgDetalle.SelectedCells(2).Value) & " " &
                   CStr(dgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                            If dgDetalle.SelectedCells(16).Value = 0 Or dgDetalle.SelectedCells(16).Value = 1 Then
                                dgDetalle.SelectedCells(16).Value = 2
                                dgDetalle.CurrentRow.Visible = False
                                CalcularTotales()
                            ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                                '  dgDetalle.SelectedCells(6).Value = 3
                                ' dgDetalle.CurrentRow.Visible = False
                                dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                            End If
                            If dgDetalle.SelectedCells(17).Value = 0 Or dgDetalle.SelectedCells(17).Value = 1 Then
                                dgDetalle.SelectedCells(17).Value = 2
                                CalcularTotales()
                            ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                                dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                            End If
                        End If
                    Next
                Else
                    MsgBox("you can not delete the last row")
                    Exit Sub
                End If
            End If

            'dgDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub frmProduccionNSM_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        End If
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim NumLong As Long
        Dim i As Integer
        Dim clsConta As New clsContabilidad
        Dim intCodigo As Integer
        Dim logMezcla As Boolean


        Try

            'celdaSaldo.Text = SaldoPO().ToString(FORMATO_MONEDA)
            If Me.Tag = "Nuevo" Then

                NumLong = celdaNumero.Text
                celdaNumero.Text = cfun.Verificacion_Nuevo_Registro(NumLong, "Dcmtos", 952, celdaAnio.Text)
                If celdaNumero.Text > 0 Then
                    If ComprobarCampos() = True Then
                        'If ValidarTipoFibra(intCodigo, logMezcla) = False Then
                        '    Exit Sub
                        'End If
                        GuardarEncabezado(intCodigo, logMezcla)
                        GuardarDetalle()
                        GuardarDescargos()
                        GuardarDetalleBultos()
                        ' GuardarCostos() ya no se usará
                        GuardarBultos()
                        ' Guardar Kardex
                        GuardarKardex(INT_CERO) ' 0 --> suma los montos, 1 --> resta los montos
                        cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
                        'GuardarCostosTiempo()
                        'GuardarCostosFijos()
                        'ActualizarTareas()

                        ' Metodo para guardar PO
                        If checkDespacharFibra.Checked = False Then
                            GuardarDetallePO()
                            GuardarDescargosPO()
                            GuardarDetalleBultosPO()
                            GuardarBultosPO()
                            PrecioEstimadoPO()
                            GuardarEncabezadoPO()
                        End If

                        cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 980, celdaAnio.Text, celdaNumero.Text)
                        If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        Else
                            Me.Tag = "Mod"
                        End If
                        If Sesion.idGiro = 2 Then
                            If checkDespacharFibra.Checked = False Then
                                clsConta.GenerarPoliza(952, celdaAnio.Text, celdaNumero.Text)
                            End If

                        End If
                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If
                End If
            ElseIf Me.Tag = "Mod" Then
                'If ValidarTipoFibra(intCodigo, logMezcla) = False Then
                '    Exit Sub
                'End If

                ' Hay que eliminar la linea de Kardex
                ' BorrarKardex()

                GuardarEncabezado(intCodigo, logMezcla)
                GuardarDetalle()
                GuardarDescargos()
                GuardarDetalleBultos()
                ' GuardarCostos() ya no se usará
                GuardarBultos()
                ' Guardar Kardex
                GuardarKardex(INT_UNO) ' 0 --> suma los montos, 1 --> resta los montos

                GuardarKardex(INT_CERO) ' 0 --> suma los montos, 1 --> resta los montos
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
                ' Metodo para Guardar PO
                If checkDespacharFibra.Checked = False Then
                    GuardarDetallePO()
                    GuardarDescargosPO()
                    GuardarDetalleBultosPO()
                    GuardarBultosPO()
                    PrecioEstimadoPO()
                    GuardarEncabezadoPO()
                End If

                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 980, celdaAnio.Text, celdaNumero.Text)
                If Sesion.idGiro = 2 Then
                    If checkDespacharFibra.Checked = False Then
                        clsConta.GenerarPoliza(952, celdaAnio.Text, celdaNumero.Text)
                    End If
                End If
                If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                    MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency, cat_sist Rate"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Reset()
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intCat As Integer
        Try
            If dgLista.Rows.Count = 0 Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(1).Value
            intNumero = dgLista.SelectedCells(2).Value
            intCat = dgLista.SelectedCells(0).Value
            CargarEncabezado(intAnio, intNumero)
            CargarDetalle(intAnio, intNumero)
            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(952, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value, 952)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Cantidad_Kardex As Double = 0
        Dim Total_Kardex As Double = 0
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                'BorrarKardex()

                strsql = cfun.Kardex_PProceso(980, celdaidAñoPO.Text, celdaidPONumero.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql, CON)
                REA = COM.ExecuteReader()
                If REA.HasRows Then
                    Do While REA.Read
                        Cantidad_Kardex = REA.GetDouble("Cantidad")
                        Total_Kardex = REA.GetDouble("Total")
                    Loop
                End If
                COM = Nothing
                REA.Close()

                GuardarKardex(INT_UNO) ' 0 --> suma los montos, 1 --> resta los montos
                BorrarEncabezado()
                BorrarDetalle()
                BorrarDescargos()
                BorrarBultos()
                BorrarBultosPro()
                BorrarDetallePO()
                BorrarDescargosPO()
                BorrarBultosPO()
                BorrarBultosProPO()
                cFunciones.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAnio.Text, 952)
                cFunciones.BorrarDetallePoliza(celdaNumero.Text, celdaAnio.Text, 952)
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 952, celdaAnio.Text, celdaNumero.Text)
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub
    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click
        Dim frm As New frmOption
        Dim NP As New clsPolizaContable
        Dim NPC As New frmNPolizasContables
        Try
            NP.intModo = 29
            NP.intTipo = 952
            NP.intCiclo = celdaAnio.Text
            NP.intNumero = celdaNumero.Text
            NP.MostrarPolizaContable()
        Catch ex As Exception
            MsgBox("It has no Accounting Policy")
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub
    Private Sub botonPO_Click(sender As Object, e As EventArgs) Handles botonPO.Click
        MostrarPO()
    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

    Private Sub checkDespacharFibra_CheckedChanged(sender As Object, e As EventArgs) Handles checkDespacharFibra.CheckedChanged
        If checkDespacharFibra.Checked = True Then
            botonPO.Enabled = False
        Else
            botonPO.Enabled = True
        End If
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        ' proceso para mostrar los ingresos a bodega ;(
        ' Dim logGenerico As Boolean
        Dim strCodigo As Integer = INT_CERO
        Dim strSQL1 As String = STR_VACIO
        Dim COM As MySqlCommand
        ' Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim strArticulo As String = STR_VACIO

        If dgDetalle.Rows.Count = vbEmpty Then Exit Sub

        strCodigo = dgDetalle.SelectedCells(3).Value
        Select Case dgDetalle.CurrentCell.ColumnIndex

            Case 8
                'If Not logComentario Then
                'CargarNota()
                'End If
                'logGenerico = sqlEsGenerico(strCodigo)


                'For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
                '    If dgDetalle.Rows(i).Selected Then
                '        If dgDetalle.Rows(i).Visible = True Then
                '            contador = contador + 1
                '            dgDetalle.Rows(i).Cells("colIDD").Value = contador
                '        End If     
                '    End If
                'Next

                strSQL1 = "SELECT inv_artcodigo"
                strSQL1 &= "      FROM Inventarios"
                strSQL1 &= "          WHERE inv_sisemp={empresa} And inv_numero = {codigo}"

                strSQL1 = Replace(strSQL1, "{empresa}", Sesion.IdEmpresa)
                strSQL1 = Replace(strSQL1, "{codigo}", dgDetalle.SelectedCells(18).Value)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL1, conec)
                strArticulo = COM.ExecuteScalar
                conec.Close()

                MostrarReferencias(strCodigo, strArticulo)
        End Select
    End Sub

    Private Sub MostrarReferencias(ByVal strcodigo As Integer, ByVal strArticulo As String)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim frmLista As New frmFacturasRef_Aux_
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        'Genera el listado de referencias con saldo
        strSQL = SqlReferencias(strcodigo, strArticulo)

        'Inicializa la ventana
        frmLista.Unidad = dgDetalle.SelectedCells(11).Value
        frmLista.dgLista.Rows.Clear()
        frmLista.Informacion = ""

        'Obtiene los datos de la base de datos
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            Do While REA.Read
                strFila = REA.GetInt32("Anio") & "|"
                strFila &= REA.GetInt32("Numero") & "|"
                strFila &= REA.GetDateTime("Fecha") & "|"
                strFila &= "" & "|" 'PolizaDeIngreso(REA.GetInt32("Anio"), REA.GetInt32("Numero")) & "|"
                strFila &= REA.GetString("Referencia") & "|"
                strFila &= REA.GetInt32("Linea") & "|"
                strFila &= REA.GetInt32("Codigo") & "|"
                ' strFila &= (CDbl(dgDetalle.CurrentRow.Cells("colSaldoActual").Value) + CDbl(dgDetalle.CurrentRow.Cells("colCantDescargo").Value)) & "|"
                strFila &= REA.GetDouble("Saldo").ToString(FORMATO_MONEDA) & "|"
                strFila &= REA.GetString("Medida") & "|"
                strFila &= REA.GetString("Unidad") & "|"
                strFila &= INT_CERO & "|" ' Cantidad a descargar
                strFila &= REA.GetString("Nota1") & "|"
                strFila &= REA.GetString("Nota2") & "|"
                strFila &= REA.GetDouble("Reservado") & "|"
                strFila &= vbEmpty & "|"
                strFila &= vbEmpty & "|"
                strFila &= 1

                cfun.AgregarFila(frmLista.dgLista, strFila)
            Loop
        End If
        frmLista.Iniciar()

        frmLista.ShowDialog(Me)
        frmLista.Hide()

        If frmLista.Aceptado Then
            With frmLista.dgLista
                For k As Integer = 0 To frmLista.dgLista.Rows.Count - 1
                    If Val(frmLista.dgLista.Rows(k).Cells("colDescargo").Value) > vbEmpty Then
                        dgDetalle.CurrentRow.Cells("colRefAnio").Value = frmLista.dgLista.Rows(k).Cells("colAño").Value ' año ingreso
                        dgDetalle.CurrentRow.Cells("colRefCatalogo").Value = 47 ' catalogo ingreso
                        dgDetalle.CurrentRow.Cells("colRefNum").Value = frmLista.dgLista.Rows(k).Cells("colNumero").Value ' numero ingreso
                        dgDetalle.CurrentRow.Cells("colCodigo").Value = frmLista.dgLista.Rows(k).Cells("colCodigo").Value ' codigo inventario
                        dgDetalle.CurrentRow.Cells("colLinea").Value = INT_CERO ' linea del documento
                        'dgDetalle.CurrentRow.Cells("colMarca").Value = "" ' guarda el lote, pero se le asigna al jalar el código de inventario antes del descargo
                        'dgDetalle.CurrentRow.Cells("colDescripcion").Value = "" ' Descripcion del hilo, no cambia
                        'dgDetalle.CurrentRow.Cells("colPrecio").Value = frmLista.dgLista.Rows(k).Cells("colAño").Value
                        dgDetalle.CurrentRow.Cells("colCantidad").Value = frmLista.dgLista.Rows(k).Cells("colDescargo").Value ' cantidad a descargar
                        'dgDetalle.CurrentRow.Cells("colRefAnio").Value = frmLista.dgLista.Rows(k).Cells("colAño").Value
                        'dgDetalle.CurrentRow.Cells("colRefAnio").Value = frmLista.dgLista.Rows(k).Cells("colAño").Value
                        dgDetalle.CurrentRow.Cells("colidMedida").Value = frmLista.dgLista.Rows(k).Cells("colUnidad").Value
                        dgDetalle.CurrentRow.Cells("colMedida").Value = frmLista.dgLista.Rows(k).Cells("colMedida").Value
                        dgDetalle.CurrentRow.Cells("colRefLin").Value = frmLista.dgLista.Rows(k).Cells("colLinea").Value


                        REA.Close()
                        COM = Nothing
                        Dim strSQL6 As String
                        strSQL6 = " SELECT d.DDoc_Prd_NET Precio, h.HDoc_Doc_TC TC "
                        strSQL6 &= "    FROM Dcmtos_DTL d  
                                        LEFT JOIN Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num"
                        strSQL6 &= "                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 47 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea} "
                        strSQL6 = Replace(strSQL6, "{empresa}", Sesion.IdEmpresa)
                        strSQL6 = Replace(strSQL6, "{anio}", dgDetalle.CurrentRow.Cells("colRefAnio").Value)
                        strSQL6 = Replace(strSQL6, "{numero}", dgDetalle.CurrentRow.Cells("colRefNum").Value)
                        strSQL6 = Replace(strSQL6, "{linea}", dgDetalle.CurrentRow.Cells("colRefLin").Value)

                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL6, CON)
                        REA = COM.ExecuteReader
                        If REA.HasRows Then
                            Do While REA.Read
                                dgDetalle.CurrentRow.Cells("colPrecio").Value = REA.GetDouble("Precio")
                                dgDetalle.CurrentRow.Cells("colTipoCambio").Value = REA.GetDouble("TC")

                            Loop
                        End If
                    End If
                Next
            End With
        End If
        dgDetalle.Columns("colPrecio").ReadOnly = False
        CalcularTotales()
        dgDetalle.Columns("colPrecio").ReadOnly = False
    End Sub
    Private Function SqlReferencias(ByVal strcodigo As Integer, ByVal strArticulo As String)
        Dim strSQL As String
        'Dim COM As MySqlCommand
        'Dim conec As MySqlConnection
        'Dim REA As MySqlDataReader

        'Dim strQuery As String


        'NOTA: intCurRef = ingreso a bodega
        strSQL = "SELECT a.HDoc_Doc_Cat Tipo, a.HDoc_Doc_Ano Anio, a.HDoc_Doc_Num Numero, b.DDoc_Doc_Lin Linea, a.HDoc_Doc_Fec Fecha, a.HDoc_DR1_Num Referencia, p.cat_desc pais,  b.DDoc_Prd_Cod Codigo, m.cat_clave Medida, m.cat_num Unidad, SUM(b.DDoc_Prd_QTY) - COALESCE(("
        strSQL &= "  SELECT SUM(c.PDoc_QTY_Pro)"
        strSQL &= "      FROM Dcmtos_DTL_Pro c"
        strSQL &= "          WHERE c.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND c.PDoc_Par_Cat = a.HDoc_Doc_Cat AND c.PDoc_Par_Ano = a.HDoc_Doc_Ano AND c.PDoc_Par_Num = a.HDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin), 0) Saldo, IFNULL(("
        strSQL &= "              SELECT n.ADoc_Dta_Txt"
        strSQL &= "                  FROM Dcmtos_ACC n"
        strSQL &= "                     WHERE n.ADoc_Sis_Emp=a.HDoc_Sis_Emp AND n.ADoc_Doc_Cat=a.HDoc_Doc_Cat AND n.ADoc_Doc_Ano=a.HDoc_Doc_Ano AND n.ADoc_Doc_Num=a.HDoc_Doc_Num AND n.ADoc_Doc_Sub='Doc_DIngreso' AND n.ADoc_Doc_Lin='04'"
        strSQL &= "                              LIMIT 1),'') nota1, IFNULL(b.DDoc_RF1_Txt,'') nota2, IFNULL(("
        strSQL &= "                          SELECT SUM(v.cantidad) Cantidad"
        strSQL &= "                      FROM Reserva v"
        strSQL &= "                  WHERE v.id_empresa=b.DDoc_Sis_Emp AND v.doc_tipo=b.DDoc_Doc_Cat AND v.doc_ciclo=b.DDoc_Doc_Ano AND v.doc_num=b.DDoc_Doc_Num AND v.doc_lin=b.DDoc_Doc_Lin AND NOT(v.estado=2)),0) Reservado"
        strSQL &= "              FROM Dcmtos_HDR a"
        strSQL &= "           INNER JOIN Dcmtos_DTL b ON b.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND b.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND b.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND b.DDoc_Doc_Num = a.HDoc_Doc_Num"
        strSQL &= "              LEFT JOIN Inventarios d ON d.inv_numero = b.DDoc_Prd_Cod AND d.inv_sisemp = b.DDoc_Sis_Emp"
        strSQL &= "         LEFT JOIN Catalogos  p on p.cat_num = d.inv_lugarfab"
        strSQL &= "       LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = b.DDoc_Prd_UM"
        strSQL &= "     WHERE a.HDoc_Sis_Emp = {empresa} AND a.HDoc_Doc_Cat = 47 AND a.HDoc_Doc_Fec <='{fec}' AND b.DDoc_Prd_Cod = {cod} GROUP BY a.HDoc_Doc_Ano, a.HDoc_Doc_Num, b.DDoc_Doc_Lin"
        strSQL &= "     HAVING  Saldo > 0.05"
        strSQL &= "         ORDER BY  a.HDoc_DR1_Num, a.HDoc_Doc_Ano,  a.HDoc_Doc_Num, b.DDoc_Doc_Lin"


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", dgDetalle.SelectedCells(5).Value)
        strSQL = Replace(strSQL, "{año}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{lugar}", dgDetalle.SelectedCells(16).Value)
        strSQL = Replace(strSQL, "{linea}", dgDetalle.SelectedCells(3).Value)
        strSQL = Replace(strSQL, "{fec}", Format(CDate(dtpFecha.Text), "yyyy-MM-dd"))
        strSQL = Replace(strSQL, "{cod}", strcodigo)

        ''Agrega a la cláusula WHERE las características del genérico
        'strQuery = "Select COALESCE(inv_provcod,-1)  provcod,COALESCE(inv_lugarfab,-1) lugarfab, COALESCE(inv_prodlote,'') prodlote"
        'strQuery &= "   FROM Inventarios"
        'strQuery &= "       WHERE inv_sisemp= {empresa} AND inv_numero= " & strcodigo & ""

        'strQuery = Replace(strQuery, "{empresa}", Sesion.IdEmpresa)

        'MyCnn.CONECTAR = strConexion
        'COM = New MySqlCommand(strQuery, CON)
        'REA = COM.ExecuteReader
        'REA.Read()

        ''Lugar de fabricación
        'Dim Lugfab As String
        'Dim strSQL3 As String = STR_VACIO
        'If (REA.GetInt32("lugarfab") >= vbEmpty) Then
        '    strSQL3 = "SELECT cat_desc"
        '    strSQL3 &= "   FROM Catalogos"
        '    strSQL3 &= "      WHERE cat_num=" & REA.GetString("lugarfab") & ""
        '    strSQL3 &= "  LIMIT 1"

        '    conec = New MySqlConnection(strConexion)
        '    conec.Open()
        '    COM = New MySqlCommand(strSQL3, conec)
        '    Lugfab = COM.ExecuteScalar
        '    conec.Close()

        '    strSQL = strSQL & " AND inv_lugarfab=" & REA.GetString("lugarfab")
        'End If
        'Devuelve la consulta
        SqlReferencias = strSQL
    End Function

#End Region
End Class