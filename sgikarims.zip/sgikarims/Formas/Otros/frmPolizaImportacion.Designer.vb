﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPolizaImportacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPolizaImportacion))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSelectivoLista = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRegimen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSoporte = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoG = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSelectivo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelColores = New System.Windows.Forms.Panel()
        Me.etiquetaTiposRegimen = New System.Windows.Forms.Label()
        Me.etiquetaRegimen = New System.Windows.Forms.Label()
        Me.etiquetaBlanco = New System.Windows.Forms.Label()
        Me.etiquetaRojo = New System.Windows.Forms.Label()
        Me.etiquetaVerde = New System.Windows.Forms.Label()
        Me.etiquetaSeleccion = New System.Windows.Forms.Label()
        Me.etiquetaColor = New System.Windows.Forms.Label()
        Me.celdaBlanco = New System.Windows.Forms.TextBox()
        Me.CeldaRojo = New System.Windows.Forms.TextBox()
        Me.celdaVerde = New System.Windows.Forms.TextBox()
        Me.celdaColor = New System.Windows.Forms.TextBox()
        Me.panelEncabezadoLista = New System.Windows.Forms.Panel()
        Me.botonProveedorE = New System.Windows.Forms.Button()
        Me.celdaProveedorE = New System.Windows.Forms.TextBox()
        Me.etiquetaProveedorE = New System.Windows.Forms.Label()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescuentoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMontoDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colParteDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoUMDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colInciso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKgBrutos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKgNetos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFOB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFlete = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSeguro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtros = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtrosG = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCIF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colValorAduanal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDAI = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIVA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGranTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinDPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaTexto = New System.Windows.Forms.TextBox()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.panelDatosOcultos = New System.Windows.Forms.Panel()
        Me.dgDatosOcultos = New System.Windows.Forms.DataGridView()
        Me.colDescripcionLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKGBrutos2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colKGNetos2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFOB2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFlete2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSeguro2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDAI2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIVA2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOtros2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.etiquetaDocumentos = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTotalCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.panelDgTotales = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.gbReferencia = New System.Windows.Forms.GroupBox()
        Me.botonGuardarCetificado = New System.Windows.Forms.Button()
        Me.celdaCertificado = New System.Windows.Forms.TextBox()
        Me.lblCertificado = New System.Windows.Forms.Label()
        Me.celdaCodigoGeneracion = New System.Windows.Forms.TextBox()
        Me.etiquetacodigo = New System.Windows.Forms.Label()
        Me.botonCosteo = New System.Windows.Forms.Button()
        Me.celdaCosteo = New System.Windows.Forms.TextBox()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.celdaFlete = New System.Windows.Forms.TextBox()
        Me.celdaRef2 = New System.Windows.Forms.TextBox()
        Me.celdaRef1 = New System.Windows.Forms.TextBox()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaSeguro = New System.Windows.Forms.Label()
        Me.etiquetaFlete = New System.Windows.Forms.Label()
        Me.etiquetaCosteo = New System.Windows.Forms.Label()
        Me.etiquetaRef2 = New System.Windows.Forms.Label()
        Me.etiquetaRef1 = New System.Windows.Forms.Label()
        Me.etiquetaFactura = New System.Windows.Forms.Label()
        Me.gbDatosPoliza = New System.Windows.Forms.GroupBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.dgPolizaImportacion = New System.Windows.Forms.DataGridView()
        Me.colNumeroP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperadorP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbPoliza = New System.Windows.Forms.GroupBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdProveedor = New System.Windows.Forms.TextBox()
        Me.celdaDate = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonCorregir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.checkTendido = New System.Windows.Forms.CheckBox()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelColores.SuspendLayout()
        Me.panelEncabezadoLista.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.panelDatosOcultos.SuspendLayout()
        CType(Me.dgDatosOcultos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDgTotales.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDatos.SuspendLayout()
        Me.gbReferencia.SuspendLayout()
        Me.gbDatosPoliza.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgPolizaImportacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbPoliza.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelColores)
        Me.panelLista.Controls.Add(Me.panelEncabezadoLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 112)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1349, 300)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFecha, Me.colProveedor, Me.colPoliza, Me.colReferencia, Me.colAnio, Me.colEstado, Me.colSelectivoLista, Me.colRegimen, Me.colSoporte, Me.colCodigoG, Me.colSelectivo})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 85)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1349, 98)
        Me.dgLista.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 87
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colProveedor
        '
        Me.colProveedor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colProveedor.HeaderText = "Provider"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        Me.colProveedor.Width = 90
        '
        'colPoliza
        '
        Me.colPoliza.HeaderText = "Policy / Class"
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        Me.colPoliza.Width = 80
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 103
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 62
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        Me.colEstado.Width = 77
        '
        'colSelectivoLista
        '
        Me.colSelectivoLista.HeaderText = "Selective"
        Me.colSelectivoLista.Name = "colSelectivoLista"
        Me.colSelectivoLista.ReadOnly = True
        Me.colSelectivoLista.Visible = False
        Me.colSelectivoLista.Width = 94
        '
        'colRegimen
        '
        Me.colRegimen.HeaderText = "Regimen"
        Me.colRegimen.Name = "colRegimen"
        Me.colRegimen.ReadOnly = True
        Me.colRegimen.Visible = False
        Me.colRegimen.Width = 93
        '
        'colSoporte
        '
        Me.colSoporte.HeaderText = "Support"
        Me.colSoporte.Name = "colSoporte"
        Me.colSoporte.ReadOnly = True
        Me.colSoporte.Visible = False
        Me.colSoporte.Width = 87
        '
        'colCodigoG
        '
        Me.colCodigoG.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigoG.HeaderText = "Generation Code"
        Me.colCodigoG.Name = "colCodigoG"
        Me.colCodigoG.ReadOnly = True
        Me.colCodigoG.Width = 133
        '
        'colSelectivo
        '
        Me.colSelectivo.HeaderText = "..."
        Me.colSelectivo.Name = "colSelectivo"
        Me.colSelectivo.ReadOnly = True
        Me.colSelectivo.Width = 49
        '
        'panelColores
        '
        Me.panelColores.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.panelColores.Controls.Add(Me.etiquetaTiposRegimen)
        Me.panelColores.Controls.Add(Me.etiquetaRegimen)
        Me.panelColores.Controls.Add(Me.etiquetaBlanco)
        Me.panelColores.Controls.Add(Me.etiquetaRojo)
        Me.panelColores.Controls.Add(Me.etiquetaVerde)
        Me.panelColores.Controls.Add(Me.etiquetaSeleccion)
        Me.panelColores.Controls.Add(Me.etiquetaColor)
        Me.panelColores.Controls.Add(Me.celdaBlanco)
        Me.panelColores.Controls.Add(Me.CeldaRojo)
        Me.panelColores.Controls.Add(Me.celdaVerde)
        Me.panelColores.Controls.Add(Me.celdaColor)
        Me.panelColores.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelColores.Location = New System.Drawing.Point(0, 183)
        Me.panelColores.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelColores.Name = "panelColores"
        Me.panelColores.Size = New System.Drawing.Size(1349, 117)
        Me.panelColores.TabIndex = 2
        '
        'etiquetaTiposRegimen
        '
        Me.etiquetaTiposRegimen.AutoSize = True
        Me.etiquetaTiposRegimen.Location = New System.Drawing.Point(823, 44)
        Me.etiquetaTiposRegimen.Name = "etiquetaTiposRegimen"
        Me.etiquetaTiposRegimen.Size = New System.Drawing.Size(20, 17)
        Me.etiquetaTiposRegimen.TabIndex = 10
        Me.etiquetaTiposRegimen.Text = "ZI"
        '
        'etiquetaRegimen
        '
        Me.etiquetaRegimen.AutoSize = True
        Me.etiquetaRegimen.Location = New System.Drawing.Point(823, 21)
        Me.etiquetaRegimen.Name = "etiquetaRegimen"
        Me.etiquetaRegimen.Size = New System.Drawing.Size(63, 17)
        Me.etiquetaRegimen.TabIndex = 9
        Me.etiquetaRegimen.Text = "Regimes"
        '
        'etiquetaBlanco
        '
        Me.etiquetaBlanco.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaBlanco.AutoSize = True
        Me.etiquetaBlanco.Location = New System.Drawing.Point(1299, 80)
        Me.etiquetaBlanco.Name = "etiquetaBlanco"
        Me.etiquetaBlanco.Size = New System.Drawing.Size(31, 17)
        Me.etiquetaBlanco.TabIndex = 8
        Me.etiquetaBlanco.Text = "N/A"
        '
        'etiquetaRojo
        '
        Me.etiquetaRojo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaRojo.AutoSize = True
        Me.etiquetaRojo.Location = New System.Drawing.Point(1159, 80)
        Me.etiquetaRojo.Name = "etiquetaRojo"
        Me.etiquetaRojo.Size = New System.Drawing.Size(34, 17)
        Me.etiquetaRojo.TabIndex = 7
        Me.etiquetaRojo.Text = "Red"
        '
        'etiquetaVerde
        '
        Me.etiquetaVerde.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaVerde.AutoSize = True
        Me.etiquetaVerde.Location = New System.Drawing.Point(1000, 75)
        Me.etiquetaVerde.Name = "etiquetaVerde"
        Me.etiquetaVerde.Size = New System.Drawing.Size(48, 17)
        Me.etiquetaVerde.TabIndex = 6
        Me.etiquetaVerde.Text = "Green"
        '
        'etiquetaSeleccion
        '
        Me.etiquetaSeleccion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaSeleccion.AutoSize = True
        Me.etiquetaSeleccion.Location = New System.Drawing.Point(963, 41)
        Me.etiquetaSeleccion.Name = "etiquetaSeleccion"
        Me.etiquetaSeleccion.Size = New System.Drawing.Size(122, 17)
        Me.etiquetaSeleccion.TabIndex = 5
        Me.etiquetaSeleccion.Text = "Random Selective"
        '
        'etiquetaColor
        '
        Me.etiquetaColor.AutoSize = True
        Me.etiquetaColor.Location = New System.Drawing.Point(45, 80)
        Me.etiquetaColor.Name = "etiquetaColor"
        Me.etiquetaColor.Size = New System.Drawing.Size(113, 17)
        Me.etiquetaColor.TabIndex = 4
        Me.etiquetaColor.Text = " Not in Shopping"
        '
        'celdaBlanco
        '
        Me.celdaBlanco.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaBlanco.BackColor = System.Drawing.Color.White
        Me.celdaBlanco.Location = New System.Drawing.Point(1267, 71)
        Me.celdaBlanco.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaBlanco.Name = "celdaBlanco"
        Me.celdaBlanco.Size = New System.Drawing.Size(25, 22)
        Me.celdaBlanco.TabIndex = 3
        '
        'CeldaRojo
        '
        Me.CeldaRojo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaRojo.BackColor = System.Drawing.Color.Red
        Me.CeldaRojo.Location = New System.Drawing.Point(1125, 69)
        Me.CeldaRojo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.CeldaRojo.Name = "CeldaRojo"
        Me.CeldaRojo.Size = New System.Drawing.Size(28, 22)
        Me.CeldaRojo.TabIndex = 2
        '
        'celdaVerde
        '
        Me.celdaVerde.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaVerde.BackColor = System.Drawing.Color.YellowGreen
        Me.celdaVerde.Location = New System.Drawing.Point(965, 69)
        Me.celdaVerde.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaVerde.Name = "celdaVerde"
        Me.celdaVerde.Size = New System.Drawing.Size(28, 22)
        Me.celdaVerde.TabIndex = 1
        '
        'celdaColor
        '
        Me.celdaColor.BackColor = System.Drawing.Color.Orange
        Me.celdaColor.Location = New System.Drawing.Point(8, 76)
        Me.celdaColor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaColor.Name = "celdaColor"
        Me.celdaColor.Size = New System.Drawing.Size(31, 22)
        Me.celdaColor.TabIndex = 0
        '
        'panelEncabezadoLista
        '
        Me.panelEncabezadoLista.Controls.Add(Me.botonProveedorE)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaProveedorE)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaProveedorE)
        Me.panelEncabezadoLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaFechas)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpInicial)
        Me.panelEncabezadoLista.Controls.Add(Me.checkFechas)
        Me.panelEncabezadoLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelEncabezadoLista.Name = "panelEncabezadoLista"
        Me.panelEncabezadoLista.Size = New System.Drawing.Size(1349, 85)
        Me.panelEncabezadoLista.TabIndex = 0
        '
        'botonProveedorE
        '
        Me.botonProveedorE.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonProveedorE.Location = New System.Drawing.Point(569, 57)
        Me.botonProveedorE.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonProveedorE.Name = "botonProveedorE"
        Me.botonProveedorE.Size = New System.Drawing.Size(37, 26)
        Me.botonProveedorE.TabIndex = 7
        Me.botonProveedorE.Text = "..."
        Me.botonProveedorE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonProveedorE.UseVisualStyleBackColor = True
        '
        'celdaProveedorE
        '
        Me.celdaProveedorE.Location = New System.Drawing.Point(131, 57)
        Me.celdaProveedorE.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaProveedorE.Name = "celdaProveedorE"
        Me.celdaProveedorE.Size = New System.Drawing.Size(432, 22)
        Me.celdaProveedorE.TabIndex = 6
        '
        'etiquetaProveedorE
        '
        Me.etiquetaProveedorE.AutoSize = True
        Me.etiquetaProveedorE.Location = New System.Drawing.Point(45, 59)
        Me.etiquetaProveedorE.Name = "etiquetaProveedorE"
        Me.etiquetaProveedorE.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaProveedorE.TabIndex = 5
        Me.etiquetaProveedorE.Text = "Provider"
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(741, 10)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 26)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(485, 14)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaFechas.TabIndex = 3
        Me.etiquetaFechas.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(568, 11)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(121, 22)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(349, 11)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(121, 22)
        Me.dtpInicial.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(49, 15)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(231, 21)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Show Documents Between Date"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.dgDetalle)
        Me.panelDocumento.Controls.Add(Me.celdaTexto)
        Me.panelDocumento.Controls.Add(Me.panelTotales)
        Me.panelDocumento.Controls.Add(Me.panelDatos)
        Me.panelDocumento.Location = New System.Drawing.Point(12, 418)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1356, 615)
        Me.panelDocumento.TabIndex = 3
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigoDet, Me.colDescripcionDet, Me.colMedidaDet, Me.colPrecioDet, Me.colDescuentoDet, Me.colMontoDet, Me.colBultos, Me.colCantidadDet, Me.colTotalDet, Me.colParteDet, Me.colCodigoUMDet, Me.colInciso, Me.colDescripDet, Me.colKgBrutos, Me.colKgNetos, Me.colFOB, Me.colFlete, Me.colSeguro, Me.colOtros, Me.colOtrosG, Me.colCIF, Me.colValorAduanal, Me.colDAI, Me.colIVA, Me.colCosto, Me.colGranTotal, Me.colCat, Me.colNum, Me.colAño, Me.colLinDPoliza, Me.colLote})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 376)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(1356, 113)
        Me.dgDetalle.TabIndex = 1
        '
        'colCodigoDet
        '
        Me.colCodigoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigoDet.HeaderText = "Code"
        Me.colCodigoDet.Name = "colCodigoDet"
        Me.colCodigoDet.ReadOnly = True
        Me.colCodigoDet.Width = 70
        '
        'colDescripcionDet
        '
        Me.colDescripcionDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripcionDet.HeaderText = "Description"
        Me.colDescripcionDet.Name = "colDescripcionDet"
        Me.colDescripcionDet.ReadOnly = True
        Me.colDescripcionDet.Width = 108
        '
        'colMedidaDet
        '
        Me.colMedidaDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedidaDet.HeaderText = "Measure"
        Me.colMedidaDet.Name = "colMedidaDet"
        Me.colMedidaDet.ReadOnly = True
        Me.colMedidaDet.Width = 92
        '
        'colPrecioDet
        '
        Me.colPrecioDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecioDet.HeaderText = "Price"
        Me.colPrecioDet.Name = "colPrecioDet"
        Me.colPrecioDet.ReadOnly = True
        Me.colPrecioDet.Width = 69
        '
        'colDescuentoDet
        '
        Me.colDescuentoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescuentoDet.HeaderText = "Discount %"
        Me.colDescuentoDet.Name = "colDescuentoDet"
        Me.colDescuentoDet.ReadOnly = True
        '
        'colMontoDet
        '
        Me.colMontoDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMontoDet.HeaderText = "Discount $"
        Me.colMontoDet.Name = "colMontoDet"
        Me.colMontoDet.ReadOnly = True
        Me.colMontoDet.Width = 96
        '
        'colBultos
        '
        Me.colBultos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBultos.HeaderText = "Packages"
        Me.colBultos.Name = "colBultos"
        Me.colBultos.Width = 99
        '
        'colCantidadDet
        '
        Me.colCantidadDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidadDet.HeaderText = "Quantity"
        Me.colCantidadDet.Name = "colCantidadDet"
        Me.colCantidadDet.ReadOnly = True
        Me.colCantidadDet.Width = 90
        '
        'colTotalDet
        '
        Me.colTotalDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotalDet.HeaderText = "Total"
        Me.colTotalDet.Name = "colTotalDet"
        Me.colTotalDet.ReadOnly = True
        Me.colTotalDet.Width = 69
        '
        'colParteDet
        '
        Me.colParteDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colParteDet.HeaderText = "Part"
        Me.colParteDet.Name = "colParteDet"
        Me.colParteDet.ReadOnly = True
        Me.colParteDet.Visible = False
        '
        'colCodigoUMDet
        '
        Me.colCodigoUMDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigoUMDet.HeaderText = "Unit Code"
        Me.colCodigoUMDet.Name = "colCodigoUMDet"
        Me.colCodigoUMDet.ReadOnly = True
        Me.colCodigoUMDet.Visible = False
        '
        'colInciso
        '
        Me.colInciso.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colInciso.HeaderText = "Item"
        Me.colInciso.Name = "colInciso"
        Me.colInciso.Width = 63
        '
        'colDescripDet
        '
        Me.colDescripDet.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescripDet.HeaderText = "Description"
        Me.colDescripDet.Name = "colDescripDet"
        Me.colDescripDet.Width = 108
        '
        'colKgBrutos
        '
        Me.colKgBrutos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKgBrutos.HeaderText = "Gross"
        Me.colKgBrutos.Name = "colKgBrutos"
        Me.colKgBrutos.Width = 75
        '
        'colKgNetos
        '
        Me.colKgNetos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colKgNetos.HeaderText = "Net"
        Me.colKgNetos.Name = "colKgNetos"
        Me.colKgNetos.Width = 59
        '
        'colFOB
        '
        Me.colFOB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFOB.HeaderText = "FOB ($)"
        Me.colFOB.Name = "colFOB"
        Me.colFOB.Width = 81
        '
        'colFlete
        '
        Me.colFlete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFlete.HeaderText = "Freight ($)"
        Me.colFlete.Name = "colFlete"
        Me.colFlete.Width = 95
        '
        'colSeguro
        '
        Me.colSeguro.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colSeguro.HeaderText = "Insurance ($)"
        Me.colSeguro.Name = "colSeguro"
        Me.colSeguro.Width = 111
        '
        'colOtros
        '
        Me.colOtros.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colOtros.HeaderText = "Others Expenses"
        Me.colOtros.Name = "colOtros"
        Me.colOtros.Width = 133
        '
        'colOtrosG
        '
        Me.colOtrosG.HeaderText = "Others ($)"
        Me.colOtrosG.Name = "colOtrosG"
        '
        'colCIF
        '
        Me.colCIF.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCIF.HeaderText = "CIF ($)"
        Me.colCIF.Name = "colCIF"
        Me.colCIF.Width = 57
        '
        'colValorAduanal
        '
        Me.colValorAduanal.HeaderText = "Valor Aduanal"
        Me.colValorAduanal.Name = "colValorAduanal"
        Me.colValorAduanal.ReadOnly = True
        '
        'colDAI
        '
        Me.colDAI.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDAI.HeaderText = "DAI (Q)"
        Me.colDAI.Name = "colDAI"
        Me.colDAI.Width = 59
        '
        'colIVA
        '
        Me.colIVA.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIVA.HeaderText = "IVA (Q)"
        Me.colIVA.Name = "colIVA"
        Me.colIVA.Width = 58
        '
        'colCosto
        '
        Me.colCosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCosto.HeaderText = "CostoU"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.Visible = False
        '
        'colGranTotal
        '
        Me.colGranTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGranTotal.HeaderText = "GranTotal"
        Me.colGranTotal.Name = "colGranTotal"
        Me.colGranTotal.Visible = False
        '
        'colCat
        '
        Me.colCat.HeaderText = "Catalogo"
        Me.colCat.Name = "colCat"
        Me.colCat.Visible = False
        '
        'colNum
        '
        Me.colNum.HeaderText = "Numero"
        Me.colNum.Name = "colNum"
        Me.colNum.Visible = False
        '
        'colAño
        '
        Me.colAño.HeaderText = "Año"
        Me.colAño.Name = "colAño"
        Me.colAño.Visible = False
        '
        'colLinDPoliza
        '
        Me.colLinDPoliza.HeaderText = "LinDaPoliza"
        Me.colLinDPoliza.Name = "colLinDPoliza"
        Me.colLinDPoliza.Visible = False
        '
        'colLote
        '
        Me.colLote.HeaderText = "Lot"
        Me.colLote.Name = "colLote"
        '
        'celdaTexto
        '
        Me.celdaTexto.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.celdaTexto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.celdaTexto.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaTexto.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTexto.ForeColor = System.Drawing.Color.DodgerBlue
        Me.celdaTexto.Location = New System.Drawing.Point(0, 324)
        Me.celdaTexto.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTexto.Multiline = True
        Me.celdaTexto.Name = "celdaTexto"
        Me.celdaTexto.ReadOnly = True
        Me.celdaTexto.Size = New System.Drawing.Size(1356, 52)
        Me.celdaTexto.TabIndex = 0
        Me.celdaTexto.Text = resources.GetString("celdaTexto.Text")
        Me.celdaTexto.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.panelDatosOcultos)
        Me.panelTotales.Controls.Add(Me.celdaUsuario)
        Me.panelTotales.Controls.Add(Me.etiquetaDocumentos)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotalCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotales)
        Me.panelTotales.Controls.Add(Me.panelDgTotales)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 489)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1356, 126)
        Me.panelTotales.TabIndex = 2
        '
        'panelDatosOcultos
        '
        Me.panelDatosOcultos.Controls.Add(Me.dgDatosOcultos)
        Me.panelDatosOcultos.Location = New System.Drawing.Point(517, 7)
        Me.panelDatosOcultos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatosOcultos.Name = "panelDatosOcultos"
        Me.panelDatosOcultos.Size = New System.Drawing.Size(475, 119)
        Me.panelDatosOcultos.TabIndex = 22
        Me.panelDatosOcultos.Visible = False
        '
        'dgDatosOcultos
        '
        Me.dgDatosOcultos.AllowUserToAddRows = False
        Me.dgDatosOcultos.AllowUserToDeleteRows = False
        Me.dgDatosOcultos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDatosOcultos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDatosOcultos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colDescripcionLinea, Me.colKGBrutos2, Me.colKGNetos2, Me.colFOB2, Me.colFlete2, Me.colSeguro2, Me.colDAI2, Me.colIVA2, Me.colOtros2})
        Me.dgDatosOcultos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDatosOcultos.Location = New System.Drawing.Point(0, 0)
        Me.dgDatosOcultos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDatosOcultos.Name = "dgDatosOcultos"
        Me.dgDatosOcultos.RowTemplate.Height = 24
        Me.dgDatosOcultos.Size = New System.Drawing.Size(475, 119)
        Me.dgDatosOcultos.TabIndex = 0
        '
        'colDescripcionLinea
        '
        Me.colDescripcionLinea.HeaderText = "DescripcionLinea2"
        Me.colDescripcionLinea.Name = "colDescripcionLinea"
        '
        'colKGBrutos2
        '
        Me.colKGBrutos2.HeaderText = "KGBrutos2"
        Me.colKGBrutos2.Name = "colKGBrutos2"
        '
        'colKGNetos2
        '
        Me.colKGNetos2.HeaderText = "KGNetos2"
        Me.colKGNetos2.Name = "colKGNetos2"
        '
        'colFOB2
        '
        Me.colFOB2.HeaderText = "FOB2"
        Me.colFOB2.Name = "colFOB2"
        '
        'colFlete2
        '
        Me.colFlete2.HeaderText = "Flete2"
        Me.colFlete2.Name = "colFlete2"
        '
        'colSeguro2
        '
        Me.colSeguro2.HeaderText = "Seguro2"
        Me.colSeguro2.Name = "colSeguro2"
        '
        'colDAI2
        '
        Me.colDAI2.HeaderText = "DAI2"
        Me.colDAI2.Name = "colDAI2"
        '
        'colIVA2
        '
        Me.colIVA2.HeaderText = "IVA2"
        Me.colIVA2.Name = "colIVA2"
        '
        'colOtros2
        '
        Me.colOtros2.HeaderText = "Otros2"
        Me.colOtros2.Name = "colOtros2"
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(875, 94)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(100, 22)
        Me.celdaUsuario.TabIndex = 21
        Me.celdaUsuario.Visible = False
        '
        'etiquetaDocumentos
        '
        Me.etiquetaDocumentos.AutoSize = True
        Me.etiquetaDocumentos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.etiquetaDocumentos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDocumentos.ForeColor = System.Drawing.Color.Maroon
        Me.etiquetaDocumentos.Location = New System.Drawing.Point(1013, 98)
        Me.etiquetaDocumentos.Name = "etiquetaDocumentos"
        Me.etiquetaDocumentos.Size = New System.Drawing.Size(212, 18)
        Me.etiquetaDocumentos.TabIndex = 2
        Me.etiquetaDocumentos.Text = "Documentos Relacionados"
        Me.etiquetaDocumentos.Visible = False
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(1172, 22)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(113, 22)
        Me.celdaTotal.TabIndex = 20
        '
        'celdaTotalCantidad
        '
        Me.celdaTotalCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalCantidad.Location = New System.Drawing.Point(1005, 22)
        Me.celdaTotalCantidad.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotalCantidad.Name = "celdaTotalCantidad"
        Me.celdaTotalCantidad.ReadOnly = True
        Me.celdaTotalCantidad.Size = New System.Drawing.Size(113, 22)
        Me.celdaTotalCantidad.TabIndex = 19
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(881, 27)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(55, 17)
        Me.etiquetaTotales.TabIndex = 1
        Me.etiquetaTotales.Text = "Totales"
        '
        'panelDgTotales
        '
        Me.panelDgTotales.Controls.Add(Me.dgDocumentos)
        Me.panelDgTotales.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDgTotales.Location = New System.Drawing.Point(0, 0)
        Me.panelDgTotales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDgTotales.Name = "panelDgTotales"
        Me.panelDgTotales.Size = New System.Drawing.Size(500, 126)
        Me.panelDgTotales.TabIndex = 0
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.AllowUserToOrderColumns = True
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumento, Me.colDatos})
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumentos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgDocumentos.MultiSelect = False
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.RowTemplate.Height = 24
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(500, 126)
        Me.dgDocumentos.TabIndex = 1
        '
        'colClave
        '
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        Me.colClave.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        '
        'colDatos
        '
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.gbReferencia)
        Me.panelDatos.Controls.Add(Me.gbDatosPoliza)
        Me.panelDatos.Controls.Add(Me.gbPoliza)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1356, 324)
        Me.panelDatos.TabIndex = 0
        '
        'gbReferencia
        '
        Me.gbReferencia.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbReferencia.Controls.Add(Me.botonGuardarCetificado)
        Me.gbReferencia.Controls.Add(Me.celdaCertificado)
        Me.gbReferencia.Controls.Add(Me.lblCertificado)
        Me.gbReferencia.Controls.Add(Me.celdaCodigoGeneracion)
        Me.gbReferencia.Controls.Add(Me.etiquetacodigo)
        Me.gbReferencia.Controls.Add(Me.botonCosteo)
        Me.gbReferencia.Controls.Add(Me.celdaCosteo)
        Me.gbReferencia.Controls.Add(Me.celdaSeguro)
        Me.gbReferencia.Controls.Add(Me.celdaFlete)
        Me.gbReferencia.Controls.Add(Me.celdaRef2)
        Me.gbReferencia.Controls.Add(Me.celdaRef1)
        Me.gbReferencia.Controls.Add(Me.celdaFactura)
        Me.gbReferencia.Controls.Add(Me.etiquetaSeguro)
        Me.gbReferencia.Controls.Add(Me.etiquetaFlete)
        Me.gbReferencia.Controls.Add(Me.etiquetaCosteo)
        Me.gbReferencia.Controls.Add(Me.etiquetaRef2)
        Me.gbReferencia.Controls.Add(Me.etiquetaRef1)
        Me.gbReferencia.Controls.Add(Me.etiquetaFactura)
        Me.gbReferencia.Location = New System.Drawing.Point(624, 151)
        Me.gbReferencia.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbReferencia.Name = "gbReferencia"
        Me.gbReferencia.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbReferencia.Size = New System.Drawing.Size(701, 167)
        Me.gbReferencia.TabIndex = 2
        Me.gbReferencia.TabStop = False
        Me.gbReferencia.Text = "Reference and Expenses"
        '
        'botonGuardarCetificado
        '
        Me.botonGuardarCetificado.BackColor = System.Drawing.SystemColors.Control
        Me.botonGuardarCetificado.Image = Global.KARIMs_SGI.My.Resources.Resources.save
        Me.botonGuardarCetificado.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.botonGuardarCetificado.Location = New System.Drawing.Point(591, 137)
        Me.botonGuardarCetificado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonGuardarCetificado.Name = "botonGuardarCetificado"
        Me.botonGuardarCetificado.Size = New System.Drawing.Size(80, 31)
        Me.botonGuardarCetificado.TabIndex = 71
        Me.botonGuardarCetificado.Text = "Save"
        Me.botonGuardarCetificado.TextAlign = System.Drawing.ContentAlignment.TopLeft
        Me.botonGuardarCetificado.UseVisualStyleBackColor = True
        Me.botonGuardarCetificado.Visible = False
        '
        'celdaCertificado
        '
        Me.celdaCertificado.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCertificado.Location = New System.Drawing.Point(339, 138)
        Me.celdaCertificado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCertificado.Name = "celdaCertificado"
        Me.celdaCertificado.Size = New System.Drawing.Size(245, 22)
        Me.celdaCertificado.TabIndex = 33
        Me.celdaCertificado.Visible = False
        '
        'lblCertificado
        '
        Me.lblCertificado.AutoSize = True
        Me.lblCertificado.Location = New System.Drawing.Point(247, 142)
        Me.lblCertificado.Name = "lblCertificado"
        Me.lblCertificado.Size = New System.Drawing.Size(71, 17)
        Me.lblCertificado.TabIndex = 32
        Me.lblCertificado.Text = "Certificate"
        Me.lblCertificado.Visible = False
        '
        'celdaCodigoGeneracion
        '
        Me.celdaCodigoGeneracion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCodigoGeneracion.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigoGeneracion.Location = New System.Drawing.Point(625, 101)
        Me.celdaCodigoGeneracion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCodigoGeneracion.Name = "celdaCodigoGeneracion"
        Me.celdaCodigoGeneracion.Size = New System.Drawing.Size(65, 22)
        Me.celdaCodigoGeneracion.TabIndex = 31
        '
        'etiquetacodigo
        '
        Me.etiquetacodigo.AutoSize = True
        Me.etiquetacodigo.Location = New System.Drawing.Point(507, 103)
        Me.etiquetacodigo.Name = "etiquetacodigo"
        Me.etiquetacodigo.Size = New System.Drawing.Size(114, 17)
        Me.etiquetacodigo.TabIndex = 30
        Me.etiquetacodigo.Text = "Generation code"
        '
        'botonCosteo
        '
        Me.botonCosteo.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonCosteo.Location = New System.Drawing.Point(496, 28)
        Me.botonCosteo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCosteo.Name = "botonCosteo"
        Me.botonCosteo.Size = New System.Drawing.Size(37, 23)
        Me.botonCosteo.TabIndex = 19
        Me.botonCosteo.Text = "..."
        Me.botonCosteo.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCosteo.UseVisualStyleBackColor = True
        '
        'celdaCosteo
        '
        Me.celdaCosteo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCosteo.Location = New System.Drawing.Point(339, 27)
        Me.celdaCosteo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCosteo.Name = "celdaCosteo"
        Me.celdaCosteo.ReadOnly = True
        Me.celdaCosteo.Size = New System.Drawing.Size(151, 22)
        Me.celdaCosteo.TabIndex = 29
        '
        'celdaSeguro
        '
        Me.celdaSeguro.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSeguro.Location = New System.Drawing.Point(339, 102)
        Me.celdaSeguro.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.ReadOnly = True
        Me.celdaSeguro.Size = New System.Drawing.Size(151, 22)
        Me.celdaSeguro.TabIndex = 28
        '
        'celdaFlete
        '
        Me.celdaFlete.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFlete.Location = New System.Drawing.Point(339, 66)
        Me.celdaFlete.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaFlete.Name = "celdaFlete"
        Me.celdaFlete.ReadOnly = True
        Me.celdaFlete.Size = New System.Drawing.Size(151, 22)
        Me.celdaFlete.TabIndex = 27
        '
        'celdaRef2
        '
        Me.celdaRef2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRef2.Location = New System.Drawing.Point(75, 101)
        Me.celdaRef2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaRef2.Name = "celdaRef2"
        Me.celdaRef2.ReadOnly = True
        Me.celdaRef2.Size = New System.Drawing.Size(151, 22)
        Me.celdaRef2.TabIndex = 26
        '
        'celdaRef1
        '
        Me.celdaRef1.BackColor = System.Drawing.SystemColors.Info
        Me.celdaRef1.Location = New System.Drawing.Point(75, 64)
        Me.celdaRef1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaRef1.Name = "celdaRef1"
        Me.celdaRef1.ReadOnly = True
        Me.celdaRef1.Size = New System.Drawing.Size(151, 22)
        Me.celdaRef1.TabIndex = 25
        '
        'celdaFactura
        '
        Me.celdaFactura.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFactura.Location = New System.Drawing.Point(75, 27)
        Me.celdaFactura.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.ReadOnly = True
        Me.celdaFactura.Size = New System.Drawing.Size(151, 22)
        Me.celdaFactura.TabIndex = 19
        '
        'etiquetaSeguro
        '
        Me.etiquetaSeguro.AutoSize = True
        Me.etiquetaSeguro.Location = New System.Drawing.Point(255, 105)
        Me.etiquetaSeguro.Name = "etiquetaSeguro"
        Me.etiquetaSeguro.Size = New System.Drawing.Size(70, 17)
        Me.etiquetaSeguro.TabIndex = 24
        Me.etiquetaSeguro.Text = "Insurance"
        '
        'etiquetaFlete
        '
        Me.etiquetaFlete.AutoSize = True
        Me.etiquetaFlete.Location = New System.Drawing.Point(255, 69)
        Me.etiquetaFlete.Name = "etiquetaFlete"
        Me.etiquetaFlete.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaFlete.TabIndex = 23
        Me.etiquetaFlete.Text = "Freight"
        '
        'etiquetaCosteo
        '
        Me.etiquetaCosteo.AutoSize = True
        Me.etiquetaCosteo.Location = New System.Drawing.Point(255, 32)
        Me.etiquetaCosteo.Name = "etiquetaCosteo"
        Me.etiquetaCosteo.Size = New System.Drawing.Size(55, 17)
        Me.etiquetaCosteo.TabIndex = 22
        Me.etiquetaCosteo.Text = "Costing"
        '
        'etiquetaRef2
        '
        Me.etiquetaRef2.AutoSize = True
        Me.etiquetaRef2.Location = New System.Drawing.Point(5, 105)
        Me.etiquetaRef2.Name = "etiquetaRef2"
        Me.etiquetaRef2.Size = New System.Drawing.Size(46, 17)
        Me.etiquetaRef2.TabIndex = 21
        Me.etiquetaRef2.Text = "Ref. 2"
        '
        'etiquetaRef1
        '
        Me.etiquetaRef1.AutoSize = True
        Me.etiquetaRef1.Location = New System.Drawing.Point(5, 69)
        Me.etiquetaRef1.Name = "etiquetaRef1"
        Me.etiquetaRef1.Size = New System.Drawing.Size(46, 17)
        Me.etiquetaRef1.TabIndex = 20
        Me.etiquetaRef1.Text = "Ref. 1"
        '
        'etiquetaFactura
        '
        Me.etiquetaFactura.AutoSize = True
        Me.etiquetaFactura.Location = New System.Drawing.Point(5, 32)
        Me.etiquetaFactura.Name = "etiquetaFactura"
        Me.etiquetaFactura.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaFactura.TabIndex = 19
        Me.etiquetaFactura.Text = "Invoice"
        '
        'gbDatosPoliza
        '
        Me.gbDatosPoliza.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbDatosPoliza.Controls.Add(Me.panelBotones)
        Me.gbDatosPoliza.Controls.Add(Me.dgPolizaImportacion)
        Me.gbDatosPoliza.Location = New System.Drawing.Point(635, 5)
        Me.gbDatosPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbDatosPoliza.Name = "gbDatosPoliza"
        Me.gbDatosPoliza.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbDatosPoliza.Size = New System.Drawing.Size(705, 142)
        Me.gbDatosPoliza.TabIndex = 1
        Me.gbDatosPoliza.TabStop = False
        Me.gbDatosPoliza.Text = "Data for import policy"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonMenos)
        Me.panelBotones.Controls.Add(Me.botonMas)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(641, 17)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(61, 123)
        Me.panelBotones.TabIndex = 1
        '
        'botonMenos
        '
        Me.botonMenos.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonMenos.Location = New System.Drawing.Point(15, 57)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(35, 31)
        Me.botonMenos.TabIndex = 45
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(15, 12)
        Me.botonMas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(35, 31)
        Me.botonMas.TabIndex = 4
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'dgPolizaImportacion
        '
        Me.dgPolizaImportacion.AllowUserToAddRows = False
        Me.dgPolizaImportacion.AllowUserToDeleteRows = False
        Me.dgPolizaImportacion.AllowUserToOrderColumns = True
        Me.dgPolizaImportacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgPolizaImportacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPolizaImportacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPolizaImportacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumeroP, Me.colFechaP, Me.colOperadorP, Me.colReferenciaP, Me.colAnioP, Me.colCatalogoP, Me.colExtra})
        Me.dgPolizaImportacion.Location = New System.Drawing.Point(3, 18)
        Me.dgPolizaImportacion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgPolizaImportacion.MultiSelect = False
        Me.dgPolizaImportacion.Name = "dgPolizaImportacion"
        Me.dgPolizaImportacion.ReadOnly = True
        Me.dgPolizaImportacion.RowTemplate.Height = 24
        Me.dgPolizaImportacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPolizaImportacion.Size = New System.Drawing.Size(632, 121)
        Me.dgPolizaImportacion.TabIndex = 0
        '
        'colNumeroP
        '
        Me.colNumeroP.HeaderText = "Number"
        Me.colNumeroP.Name = "colNumeroP"
        Me.colNumeroP.ReadOnly = True
        '
        'colFechaP
        '
        Me.colFechaP.HeaderText = "Date"
        Me.colFechaP.Name = "colFechaP"
        Me.colFechaP.ReadOnly = True
        '
        'colOperadorP
        '
        Me.colOperadorP.HeaderText = "Operator"
        Me.colOperadorP.Name = "colOperadorP"
        Me.colOperadorP.ReadOnly = True
        '
        'colReferenciaP
        '
        Me.colReferenciaP.HeaderText = "Reference"
        Me.colReferenciaP.Name = "colReferenciaP"
        Me.colReferenciaP.ReadOnly = True
        '
        'colAnioP
        '
        Me.colAnioP.HeaderText = "Anio"
        Me.colAnioP.Name = "colAnioP"
        Me.colAnioP.ReadOnly = True
        Me.colAnioP.Visible = False
        '
        'colCatalogoP
        '
        Me.colCatalogoP.HeaderText = "Catalogo"
        Me.colCatalogoP.Name = "colCatalogoP"
        Me.colCatalogoP.ReadOnly = True
        Me.colCatalogoP.Visible = False
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'gbPoliza
        '
        Me.gbPoliza.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.gbPoliza.Controls.Add(Me.checkTendido)
        Me.gbPoliza.Controls.Add(Me.botonMoneda)
        Me.gbPoliza.Controls.Add(Me.dtpFecha)
        Me.gbPoliza.Controls.Add(Me.celdaNIT)
        Me.gbPoliza.Controls.Add(Me.celdaIdMoneda)
        Me.gbPoliza.Controls.Add(Me.celdaIdProveedor)
        Me.gbPoliza.Controls.Add(Me.celdaDate)
        Me.gbPoliza.Controls.Add(Me.checkActivo)
        Me.gbPoliza.Controls.Add(Me.celdaTasa)
        Me.gbPoliza.Controls.Add(Me.celdaMoneda)
        Me.gbPoliza.Controls.Add(Me.celdaDireccion)
        Me.gbPoliza.Controls.Add(Me.botonProveedor)
        Me.gbPoliza.Controls.Add(Me.celdaProveedor)
        Me.gbPoliza.Controls.Add(Me.celdaNumero)
        Me.gbPoliza.Controls.Add(Me.celdaEmpresa)
        Me.gbPoliza.Controls.Add(Me.celdaCatalogo)
        Me.gbPoliza.Controls.Add(Me.celdaAnio)
        Me.gbPoliza.Controls.Add(Me.etiquetaTasa)
        Me.gbPoliza.Controls.Add(Me.etiquetaMoneda)
        Me.gbPoliza.Controls.Add(Me.etiquetaDireccion)
        Me.gbPoliza.Controls.Add(Me.etiquetaProveedor)
        Me.gbPoliza.Controls.Add(Me.etiquetaFecha)
        Me.gbPoliza.Controls.Add(Me.etiquetaNumero)
        Me.gbPoliza.Controls.Add(Me.etiquetaAnio)
        Me.gbPoliza.Location = New System.Drawing.Point(3, 5)
        Me.gbPoliza.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbPoliza.Name = "gbPoliza"
        Me.gbPoliza.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbPoliza.Size = New System.Drawing.Size(609, 316)
        Me.gbPoliza.TabIndex = 0
        Me.gbPoliza.TabStop = False
        Me.gbPoliza.Text = "Import policy"
        '
        'botonMoneda
        '
        Me.botonMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonMoneda.Location = New System.Drawing.Point(227, 238)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(37, 25)
        Me.botonMoneda.TabIndex = 22
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(107, 108)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(113, 22)
        Me.dtpFecha.TabIndex = 20
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(448, 155)
        Me.celdaNIT.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(100, 22)
        Me.celdaNIT.TabIndex = 19
        Me.celdaNIT.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(299, 238)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(81, 22)
        Me.celdaIdMoneda.TabIndex = 18
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdProveedor
        '
        Me.celdaIdProveedor.Location = New System.Drawing.Point(385, 119)
        Me.celdaIdProveedor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdProveedor.Name = "celdaIdProveedor"
        Me.celdaIdProveedor.Size = New System.Drawing.Size(81, 22)
        Me.celdaIdProveedor.TabIndex = 18
        Me.celdaIdProveedor.Visible = False
        '
        'celdaDate
        '
        Me.celdaDate.Location = New System.Drawing.Point(224, 110)
        Me.celdaDate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaDate.Name = "celdaDate"
        Me.celdaDate.Size = New System.Drawing.Size(81, 22)
        Me.celdaDate.TabIndex = 17
        Me.celdaDate.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(397, 41)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 16
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(107, 276)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(113, 22)
        Me.celdaTasa.TabIndex = 15
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(107, 238)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(113, 22)
        Me.celdaMoneda.TabIndex = 14
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(107, 178)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(360, 48)
        Me.celdaDireccion.TabIndex = 13
        '
        'botonProveedor
        '
        Me.botonProveedor.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.botonProveedor.Location = New System.Drawing.Point(397, 146)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(37, 26)
        Me.botonProveedor.TabIndex = 8
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(107, 146)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(284, 22)
        Me.celdaProveedor.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(107, 74)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(113, 22)
        Me.celdaNumero.TabIndex = 10
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(280, 15)
        Me.celdaEmpresa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(81, 22)
        Me.celdaEmpresa.TabIndex = 9
        Me.celdaEmpresa.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(193, 16)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(81, 22)
        Me.celdaCatalogo.TabIndex = 8
        Me.celdaCatalogo.Visible = False
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(107, 39)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(113, 22)
        Me.celdaAnio.TabIndex = 7
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(19, 276)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 6
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(19, 238)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 5
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(16, 178)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(53, 17)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Addres"
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(16, 146)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaProveedor.TabIndex = 3
        Me.etiquetaProveedor.Text = "Provider"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(16, 110)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(16, 74)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(16, 39)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(283, 12)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(72, 57)
        Me.botonImprimir.TabIndex = 4
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonCorregir
        '
        Me.botonCorregir.Enabled = False
        Me.botonCorregir.Image = Global.KARIMs_SGI.My.Resources.Resources.edit_2
        Me.botonCorregir.Location = New System.Drawing.Point(377, 12)
        Me.botonCorregir.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCorregir.Name = "botonCorregir"
        Me.botonCorregir.Size = New System.Drawing.Size(95, 57)
        Me.botonCorregir.TabIndex = 5
        Me.botonCorregir.Text = "To correct"
        Me.botonCorregir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCorregir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 75)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1349, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1349, 75)
        Me.Encabezado1.TabIndex = 0
        '
        'checkTendido
        '
        Me.checkTendido.AutoSize = True
        Me.checkTendido.Location = New System.Drawing.Point(397, 70)
        Me.checkTendido.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkTendido.Name = "checkTendido"
        Me.checkTendido.Size = New System.Drawing.Size(84, 21)
        Me.checkTendido.TabIndex = 23
        Me.checkTendido.Text = "Laid Out"
        Me.checkTendido.UseVisualStyleBackColor = True
        '
        'frmPolizaImportacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1349, 844)
        Me.Controls.Add(Me.botonCorregir)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmPolizaImportacion"
        Me.Text = " "
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelColores.ResumeLayout(False)
        Me.panelColores.PerformLayout()
        Me.panelEncabezadoLista.ResumeLayout(False)
        Me.panelEncabezadoLista.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelDatosOcultos.ResumeLayout(False)
        CType(Me.dgDatosOcultos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDgTotales.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDatos.ResumeLayout(False)
        Me.gbReferencia.ResumeLayout(False)
        Me.gbReferencia.PerformLayout()
        Me.gbDatosPoliza.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        CType(Me.dgPolizaImportacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbPoliza.ResumeLayout(False)
        Me.gbPoliza.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents panelEncabezadoLista As Panel
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents panelColores As Panel
    Friend WithEvents celdaBlanco As TextBox
    Friend WithEvents CeldaRojo As TextBox
    Friend WithEvents celdaVerde As TextBox
    Friend WithEvents celdaColor As TextBox
    Friend WithEvents etiquetaColor As Label

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles CeldaRojo.TextChanged

    End Sub

    Friend WithEvents etiquetaTiposRegimen As Label
    Friend WithEvents etiquetaRegimen As Label
    Friend WithEvents etiquetaBlanco As Label
    Friend WithEvents etiquetaRojo As Label
    Friend WithEvents etiquetaVerde As Label
    Friend WithEvents etiquetaSeleccion As Label
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents celdaProveedorE As TextBox
    Friend WithEvents etiquetaProveedorE As Label
    Friend WithEvents botonProveedorE As Button
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelDatos As Panel
    Friend WithEvents gbPoliza As GroupBox
    Friend WithEvents gbReferencia As GroupBox
    Friend WithEvents gbDatosPoliza As GroupBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaRef2 As Label
    Friend WithEvents etiquetaRef1 As Label
    Friend WithEvents etiquetaFactura As Label
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdProveedor As TextBox
    Friend WithEvents celdaDate As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaEmpresa As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaCosteo As TextBox
    Friend WithEvents celdaSeguro As TextBox
    Friend WithEvents celdaFlete As TextBox
    Friend WithEvents celdaRef2 As TextBox
    Friend WithEvents celdaRef1 As TextBox
    Friend WithEvents celdaFactura As TextBox
    Friend WithEvents etiquetaSeguro As Label
    Friend WithEvents etiquetaFlete As Label
    Friend WithEvents etiquetaCosteo As Label
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents botonCosteo As Button
    Friend WithEvents dgPolizaImportacion As DataGridView
    Friend WithEvents panelTotales As Panel
    Friend WithEvents etiquetaDocumentos As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaTotalCantidad As TextBox
    Friend WithEvents etiquetaTotales As Label
    Friend WithEvents panelDgTotales As Panel
    Friend WithEvents dgDocumentos As DataGridView
    Friend WithEvents celdaTexto As TextBox
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaNIT As TextBox
    Friend WithEvents botonImprimir As Button
    Friend WithEvents botonCorregir As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonMas As Button
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMoneda As Button
    Friend WithEvents panelDatosOcultos As System.Windows.Forms.Panel
    Friend WithEvents dgDatosOcultos As System.Windows.Forms.DataGridView
    Friend WithEvents colDescripcionLinea As DataGridViewTextBoxColumn
    Friend WithEvents colKGBrutos2 As DataGridViewTextBoxColumn
    Friend WithEvents colKGNetos2 As DataGridViewTextBoxColumn
    Friend WithEvents colFOB2 As DataGridViewTextBoxColumn
    Friend WithEvents colFlete2 As DataGridViewTextBoxColumn
    Friend WithEvents colSeguro2 As DataGridViewTextBoxColumn
    Friend WithEvents colDAI2 As DataGridViewTextBoxColumn
    Friend WithEvents colIVA2 As DataGridViewTextBoxColumn
    Friend WithEvents colOtros2 As DataGridViewTextBoxColumn
    Friend WithEvents colClave As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colDatos As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroP As DataGridViewTextBoxColumn
    Friend WithEvents colFechaP As DataGridViewTextBoxColumn
    Friend WithEvents colOperadorP As DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaP As DataGridViewTextBoxColumn
    Friend WithEvents colAnioP As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoP As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionDet As DataGridViewTextBoxColumn
    Friend WithEvents colMedidaDet As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioDet As DataGridViewTextBoxColumn
    Friend WithEvents colDescuentoDet As DataGridViewTextBoxColumn
    Friend WithEvents colMontoDet As DataGridViewTextBoxColumn
    Friend WithEvents colBultos As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadDet As DataGridViewTextBoxColumn
    Friend WithEvents colTotalDet As DataGridViewTextBoxColumn
    Friend WithEvents colParteDet As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoUMDet As DataGridViewTextBoxColumn
    Friend WithEvents colInciso As DataGridViewTextBoxColumn
    Friend WithEvents colDescripDet As DataGridViewTextBoxColumn
    Friend WithEvents colKgBrutos As DataGridViewTextBoxColumn
    Friend WithEvents colKgNetos As DataGridViewTextBoxColumn
    Friend WithEvents colFOB As DataGridViewTextBoxColumn
    Friend WithEvents colFlete As DataGridViewTextBoxColumn
    Friend WithEvents colSeguro As DataGridViewTextBoxColumn
    Friend WithEvents colOtros As DataGridViewTextBoxColumn
    Friend WithEvents colOtrosG As DataGridViewTextBoxColumn
    Friend WithEvents colCIF As DataGridViewTextBoxColumn
    Friend WithEvents colValorAduanal As DataGridViewTextBoxColumn
    Friend WithEvents colDAI As DataGridViewTextBoxColumn
    Friend WithEvents colIVA As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colGranTotal As DataGridViewTextBoxColumn
    Friend WithEvents colCat As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colLinDPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colLote As DataGridViewTextBoxColumn
    Friend WithEvents celdaCodigoGeneracion As TextBox
    Friend WithEvents etiquetacodigo As Label
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colSelectivoLista As DataGridViewTextBoxColumn
    Friend WithEvents colRegimen As DataGridViewTextBoxColumn
    Friend WithEvents colSoporte As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoG As DataGridViewTextBoxColumn
    Friend WithEvents colSelectivo As DataGridViewTextBoxColumn
    Friend WithEvents celdaCertificado As TextBox
    Friend WithEvents lblCertificado As Label
    Friend WithEvents botonGuardarCetificado As Button
    Friend WithEvents checkTendido As System.Windows.Forms.CheckBox
End Class
