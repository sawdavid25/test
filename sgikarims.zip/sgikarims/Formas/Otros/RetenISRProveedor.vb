﻿Public Class frmRetenISRProveedor

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Num Numero, h.HDoc_Doc_Ano Anio, h.HDoc_DR1_Num Documento, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Nombre, h.HDoc_RF1_Dbl Monto, IFNULL(CONCAT(d.HDoc_DR1_Num, ' ', d.HDoc_DR2_Num),'') Factura, IFNULL(d.HDoc_RF1_Dbl,0) Total, h.HDoc_Doc_Cat catalogo, h.HDoc_Doc_Status Estado "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        Left JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND d.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND d.HDoc_Doc_Num = h.HDoc_Pro_DNum "
        strSQL &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 220 AND (h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{final}') AND h.HDoc_Ant_Com =0 "
        strSQL &= "                ORDER BY h.HDoc_Doc_Fec DESC, h.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{inicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{final}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function

    Private Function SQLCargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_RF3_Dbl control, h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat cat, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, 
                    h.HDoc_Emp_Cod cod, h.HDoc_Emp_Nom proveedor, h.HDoc_Doc_Mon moneda, h.HDoc_Doc_TC TC, h.HDoc_RF1_Dbl total,h.HDoc_RF2_Dbl Porcentaje, 
                    IF(h.HDoc_Pro_DCat = 0,d.DDoc_RF1_Num,h.HDoc_Pro_DCat) catF, IF(h.HDoc_Pro_DAno= 0,d.DDoc_RF2_Num,h.HDoc_Pro_DAno) anioF, IF(h.HDoc_Pro_DNum = 0,d.DDoc_RF3_Num,h.HDoc_Pro_DNum) numF, 
                    h.HDoc_DR1_Num retencion, HDoc_DR1_Cat tipoFac, h.HDoc_Doc_Status, h.HDoc_Doc_Mon idMoneda, h.HDoc_Doc_TC TC, h.HDoc_DR2_Cat CAIRetencion, if(h.HDoc_DR2_Fec IS NULL, h.HDoc_Doc_Fec,HDoc_DR2_Fec) fechaC, p.pro_anticipos recibos, h.HDoc_RF2_Txt TipoRetencion"
        strSQL &= "    FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQL &= " LEFT JOIN Proveedores p ON p.pro_sisemp = h.Hdoc_Sis_Emp and p.pro_codigo = h.HDoc_Emp_Cod "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 220 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strSQL &= "            LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        Return strSQL
    End Function

    Private Function SQLCargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0, Optional cat_fact As Integer = 0) ''se agregan recibos
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT r.HDoc_Doc_Ano anio,r.HDoc_Doc_Fec fecha, r.HDoc_Doc_Num numero, r.HDoc_Usuario, r.HDoc_DR1_Num NumFac, r.HDoc_DR2_Num Serie, r.HDoc_RF1_Dbl Monto, r.HDoc_Doc_TC TC, c.cat_clave Moneda,r. HDoc_Doc_Mon idMoneda, r.HDoc_Doc_Cat catalogo "
        strSQL &= "    From Dcmtos_HDR r "
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon and c.cat_clase = 'Monedas' "
        'strSQL &= "        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = r.HDoc_Sis_Emp and h.HDoc_Pro_DNum = r.HDoc_Doc_Num and h.HDoc_Pro_DAno = r.HDoc_Doc_Ano and h.HDoc_Pro_DCat = r.HDoc_Doc_Cat and h.HDoc_Doc_Num = {cod} "
        strSQL &= "            WHERE r.HDoc_Sis_Emp = {empresa} AND r.HDoc_Doc_Cat in ({cat}) AND r.HDoc_Doc_Ano = {anio} AND r.HDoc_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        strSQL = Replace(strSQL, "{cod}", codigo)
        strSQL = Replace(strSQL, "{cat}", cat_fact)

        Return strSQL
    End Function

    Private Function SQLCargarPagos(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSLQ As String = STR_VACIO

        strSLQ = " SELECT HDoc_DR1_Num cheque, HDoc_Doc_Fec fecha,cat_clave moneda ,HDoc_Doc_TC tasa, CONCAT(Bcta_Des_Cue,' ',BCta_Num_Cue) cuenta ,DDoc_RF1_Dbl total "
        strSLQ &= "    From Dcmtos_HDR "
        strSLQ &= "        Left JOIN Dcmtos_DTL ON DDoc_Sis_Emp = HDoc_Sis_Emp AND DDoc_Doc_Cat = HDoc_Doc_Cat AND DDoc_Doc_Ano = HDoc_Doc_Ano AND DDoc_Doc_Num = HDoc_Doc_Num "
        strSLQ &= "            Left JOIN Catalogos ON cat_num = HDoc_Doc_Mon "
        strSLQ &= "                Left JOIN CtasBcos ON BCta_Num = HDoc_RF1_Num "
        strSLQ &= "                    WHERE DDoc_Sis_Emp = {empresa} AND DDoc_RF1_Num = 220 AND DDoc_RF2_Num = {anio} and DDoc_RF3_Num= {num} "

        strSLQ = Replace(strSLQ, "{empresa}", Sesion.IdEmpresa)
        strSLQ = Replace(strSLQ, "{anio}", intAnio)
        strSLQ = Replace(strSLQ, "{num}", intNum)

        Return strSLQ

    End Function

    Private Function SQLMostrarFacturas() ''se agregan recibos
        Dim strSQL As String = STR_VACIO

        'strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, h.HDoc_DR2_Num Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp "
        'strSQL &= "    From Dcmtos_HDR h "
        'strSQL &= "        Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 0) AND NOT  r.HDoc_Doc_Status = 2 " ' HDoc_Ant_Com = 1 Retencion de IVA, 0 Retencion de ISR "
        'strSQL &= "           LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas' "
        'strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat in (44,209) AND h.HDoc_Emp_Cod ={cod} AND h.HDoc_Doc_Fec > '{fecha}' AND h.HDoc_Doc_Status = 1 AND r.HDoc_Sis_Emp IS NULL {monto} Order By h.HDoc_Doc_Fec DESC "

        strSQL = "  SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, 
                        h.HDoc_DR2_Num Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp, h.HDoc_Doc_Cat catalogo
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat 
                        AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 0) AND NOT r.HDoc_Doc_Status = 2
                    LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat IN (44) AND h.HDoc_Emp_Cod ={cod} 
                        AND h.HDoc_Doc_Fec > '{fecha}' AND h.HDoc_Doc_Status = 1 {relacion} {monto}
                    UNION
                    SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, 
                        h.HDoc_DR2_Num Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp, h.HDoc_Doc_Cat catalogo
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat 
                        AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 0) AND NOT r.HDoc_Doc_Status = 2
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_RF1_Num = h.HDoc_Doc_Cat AND d.DDoc_RF2_Num = h.HDoc_Doc_Ano AND d.DDoc_RF3_Num = h.HDoc_Doc_Num
                    LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat IN (209) AND h.HDoc_Emp_Cod ={cod} 
                        AND h.HDoc_Doc_Fec > '{fecha}' AND h.HDoc_Doc_Status = 1 {relacion} AND d.DDoc_RF3_Num IS NULL
                    ORDER BY fecha DESC"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cod}", celdaIdProveedor.Text)
        If Sesion.idGiro = 2 Then
            strSQL = Replace(strSQL, "{fecha}", DateSerial(Year(Date.Now) - 1, Month(Date.Now), 30).ToString(FORMATO_MYSQL)) 'dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
        Else
            strSQL = Replace(strSQL, "{fecha}", DateSerial(Year(Date.Now), Month(Date.Now) - 4, 30).ToString(FORMATO_MYSQL)) 'dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
        End If
        If Sesion.IdEmpresa = 12 Then
            strSQL = Replace(strSQL, "{monto}", "AND IF(h.HDoc_Doc_Mon = 178,h.HDoc_RF1_Dbl>0,IF( h.HDoc_Ant_Com =0,h.HDoc_RF1_Dbl>=2500,h.HDoc_RF1_Dbl>0))")
        Else
            strSQL = Replace(strSQL, "{monto}", "")
        End If
        If checkFacturas.Checked = True Then
            strSQL = Replace(strSQL, "{relacion}", STR_VACIO)
        Else
            strSQL = Replace(strSQL, "{relacion}", " AND r.HDoc_Sis_Emp IS NULL ")
        End If
        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Documento") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetInt32("catalogo") & "|"
                    strFila &= REA.GetInt32("Estado")

                    If REA.GetInt32("Estado") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.LightBlue)
                    ElseIf REA.GetInt32("Estado") = 1 Then
                        cFunciones.AgregarFila(dgLista, strFila)
                    ElseIf REA.GetInt32("Estado") = 2 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    End If

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            BarraTitulo1.CambiarTitulo("ISR Withholding Provider")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            botonImprimir.Enabled = False
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Sub CargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        celdaTipoRetencion.Text = ""
        Try
            strSQL = SQLCargarEncabezado(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                REA.Read()

                celdaAnio.Text = REA.GetInt32("anio")
                dtpFechaDoc.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                dtpFechaPolizaC.Value = REA.GetDateTime("fechaC").ToString(FORMATO_MYSQL)
                celdaNumero.Text = REA.GetString("retencion")
                celdaProveedor.Text = REA.GetString("proveedor")
                celdaIdProveedor.Text = REA.GetInt32("cod")
                celdaMonto.Text = REA.GetDouble("total").ToString(FORMATO_MONEDA)
                celdaCatalogo.Text = REA.GetInt32("cat")
                celdaAnio.Text = REA.GetInt32("anio")
                celdaNumeroHDR.Text = REA.GetInt32("numero")
                celdaCatF.Text = REA.GetInt32("catF")
                celdaAnioF.Text = REA.GetInt32("anioF")
                celdaNumF.Text = REA.GetInt32("numF")

                celdaIDMoneda.Text = REA.GetInt32("idMoneda")
                celdaTipoCambio.Text = REA.GetDouble("TC")
                celdaCAIRetencion.Text = REA.GetInt32("CAIRetencion")
                If REA.GetInt32("HDoc_Doc_Status") = 2 Then
                    checkActivo.Checked = False
                    checkActivo.Enabled = False
                Else
                    checkActivo.Checked = True
                    checkActivo.Enabled = True
                End If

                If REA.GetInt32("tipoFac") = 1 Then
                    checkFacturaEspecial.Checked = True
                Else
                    checkFacturaEspecial.Checked = False
                End If
                etiquetaPorcentaje.Text = REA.GetDouble("Porcentaje")
                celdaControl.Text = REA.GetDouble("control")

                If REA.GetString("recibos") = "1" Then
                    botonAgregar.Visible = True
                    botonQuitar.Visible = True
                ElseIf REA.GetString("recibos") = " " Then
                    botonAgregar.Visible = False
                    botonQuitar.Visible = False
                End If

                celdaTipoRetencion.Text = REA.GetString("TipoRetencion")

            End If
            celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarFactura(celdaAnioF.Text, celdaNumF.Text, intNum, celdaCatF.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("HDoc_Usuario") & "|"
                    strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    If checkFacturaEspecial.Checked = True Then
                        strFila &= 1 & "|"
                    Else
                        strFila &= 0 & "|"
                    End If
                    strFila &= 1 & "|" ' 1 actualizar, 0 insertar
                    'strFila &= REA.GetDouble("calculo") & "|"
                    strFila &= REA.GetDouble("catalogo")

                    cFunciones.AgregarFila(dgFactura, strFila)
                    'celdaIDMoneda.Text = cFunciones.DivisaLocal
                    'celdaTipoCambio.Text = 1
                    celdaCatF.Text = 44
                    celdaAnioF.Text = REA.GetInt32("anio")
                    celdaNumF.Text = REA.GetInt32("numero")
                    celdaTCFactura.Text = REA.GetDouble("TC")
                    celdaMontoF.Text = REA.GetDouble("Monto")

                Loop
                'celdaTipoCambio.Text = 1

            End If

            dgFactura.Columns("colCalISR").Visible = False

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarPago(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarPagos(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cheque") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    strFila &= REA.GetString("moneda") & "|"
                    strFila &= REA.GetDouble("tasa") & "|"
                    strFila &= REA.GetString("cuenta") & "|"
                    strFila &= REA.GetDouble("total")

                    cFunciones.AgregarFila(dgDatos, strFila)
                Loop
                celdaTotal.Text = CDbl(celdaMonto.Text) - CDbl(dgDatos.CurrentRow.Cells("colTota1").Value)
            Else
                celdaTotal.Text = CDbl(celdaMonto.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub MostrarFacturas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLMostrarFacturas()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("HDoc_Usuario") & "|"
                    strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    strFila &= REA.GetInt32("FactEsp") & "|"

                    strFila &= 0 & "|" ' 1 actualizar, 0 insertar
                    strFila &= REA.GetInt32("catalogo") & "|"
                    strFila &= 0 & "|"
                    strFila &= 0

                    If celdaRecibos.Text = 0 And REA.GetInt32("catalogo") = 209 Then
                    ElseIf celdaRecibos.Text = 0 And REA.GetInt32("catalogo") = 44 Then
                        cFunciones.AgregarFila(dgFactura, strFila)
                    ElseIf celdaRecibos.Text = 1 And REA.GetInt32("catalogo") = 209 Then
                        cFunciones.AgregarFila(dgFactura, strFila)
                    End If
                Loop

            End If

            If celdaRecibos.Text = 1 Then
                dgFactura.Columns("colCalISR").Visible = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function FactorISR() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim factor As Double = 0

        strSQL = " SELECT ROUND(a.cat_sist /100,2) factorISR "
        strSQL &= "    From Catalogos a "
        strSQL &= "        WHERE a.cat_clase='Impuestos' AND a.cat_sisemp = 0 AND a.cat_clave = 'ISR_RG' "

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        factor = COM.ExecuteScalar

        Return factor
    End Function

    Public Function VerificarIVA() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim IVA As Double = 0

        strSQL = " SELECT IFNULL(SUM(MDoc_Lin_Monto),0) "
        strSQL &= "    From Dcmtos_IMP "
        strSQL &= "        WHERE MDoc_Sis_Emp={empresa} AND MDoc_Doc_Cat in (44,209) AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={num} AND MDoc_Lin_Tipo= 0 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnioF.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumF.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        IVA = COM.ExecuteScalar

        Return IVA
    End Function

    Public Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaAnioOc.Clear()
        celdaCatalogo.Text = 220
        celdaMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaNumero.Clear()
        celdaNumeroHDR.Text = -1
        celdaProveedor.Clear()
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaMoneda.Clear()
        celdaIDMoneda.Clear()
        celdaTipoCambio.Clear()
        celdaControl.Text = NO_FILA
        If Sesion.idGiro = 2 Then
            celdaIDMoneda.Text = cFunciones.DivisaExtranjera
            celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)
            celdaTipoCambio.Text = cFunciones.TasaSegunFecha(dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
        Else
            celdaIDMoneda.Text = cFunciones.DivisaLocal
            celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)
            celdaTipoCambio.Text = 1
        End If
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            celdaNumero.Text = cFunciones.TraerNumero(celdaAnio.Text)
        Else
            celdaNumero.Text = STR_VACIO
        End If
        dtpFechaDoc.Text = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        dtpFechaPolizaC.Text = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaTCFactura.Clear()
        checkFacturaEspecial.Checked = False
        checkActivo.Checked = True
        checkActivo.Enabled = True
        checkFacturas.Checked = False
        etiquetaPorcentaje.Text = INT_CERO
        dgFactura.Rows.Clear()
        dgDatos.Rows.Clear()

        botonAgregar.Visible = False
        botonQuitar.Visible -= False
        celdaRecibos.Text = "0"
        dgFactura.Columns("colCalISR").Visible = False
        celdaMonto.ReadOnly = False
        celdaTipoRetencion.Clear()

    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        Dim i As Integer = INT_CERO

        If celdaNumero.Text = vbNullString Then
            If MsgBox("You must enter the Withholding Number", vbOKOnly, "Notice") = vbOK Then
                celdaNumero.Focus()
                comprobar = False
            ElseIf celdaProveedor.Text = vbNullString Then
                If MsgBox("You must select a provider", vbOKOnly, "Notice") = vbOK Then
                    botonProveedor.Focus()
                    comprobar = False
                End If
            ElseIf dgFactura.Rows.Count > 1 Then
                If MsgBox("Select an invoice please", vbOKOnly, "Notice") = vbOK Then
                    comprobar = False
                End If
            End If
        End If

        If celdaMonto.Text = "0.00" Then
            If MsgBox("Please do the ISR calculation for document", vbOKOnly, "Notice") = vbOK Then
                comprobar = False
            End If
        End If
        If Sesion.idGiro = 1 Then
            For i = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Visible = True Then
                    If i > 0 Then
                        If dgFactura.Rows(i).Cells("colCalISR").Value = Nothing Then
                            If MsgBox("Please do the ISR calculation for document", vbOKOnly, "Notice") = vbOK Then
                                comprobar = False
                            End If
                        End If
                    End If

                End If
            Next
        End If


        Return comprobar
    End Function
    Private Sub BorrarEncabezadoISRProveedor(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 220
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarRetencionHDR()
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 220
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_NUM = celdaNumeroHDR.Text
        hdr.HDoc_Doc_Fec_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        hdr.HDoc_DR2_Fec_NET = dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL)  ''fecha para la poliza contable
        hdr.HDOC_EMP_COD = celdaIdProveedor.Text
        hdr.HDOC_EMP_NOM = celdaProveedor.Text
        hdr.HDOC_RF1_DBL = celdaMonto.Text
        If celdaRecibos.Text = 0 Then
            hdr.HDOC_PRO_DCAT = celdaCatF.Text
            hdr.HDOC_PRO_DNUM = celdaNumF.Text
            hdr.HDOC_PRO_DANO = celdaAnioF.Text
        End If

        hdr.HDOC_DR1_NUM = celdaNumero.Text
        hdr.HDOC_DR1_CAT = IIf(checkFacturaEspecial.Checked = True, INT_UNO, INT_CERO)
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 11 Then
            hdr.HDOC_DR2_CAT = celdaCAIRetencion.Text
        Else
            hdr.HDOC_DR2_CAT = 0
        End If
        hdr.HDOC_RF2_DBL = etiquetaPorcentaje.Text
        hdr.HDOC_RF2_TXT = celdaTipoRetencion.Text
        hdr.HDOC_RF3_DBL = celdaControl.Text
        hdr.HDOC_DOC_MON = celdaIDMoneda.Text
        hdr.HDOC_DOC_TC = celdaTipoCambio.Text
        hdr.HDOC_USUARIO = Sesion.Usuario
        If checkActivo.Checked = True Then
            hdr.HDOC_DOC_STATUS = INT_CERO ' 0 porque aun no está pagada la retención, al momento de jalarla para pagar debe actualizar a 1 en este campo
        Else
            hdr.HDOC_DOC_STATUS = 2
        End If

        hdr.HDOC_ANT_COM = INT_CERO  ' Retencion de IVA 1, retencion de ISR 0

        If dgFactura.Rows.Count = 1 Then
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colExtraFact").Value = 0 Or dgFactura.Rows(i).Cells("colExtraFact").Value = 1 Then
                    hdr.HDOC_DR2_NUM = dgFactura.Rows(i).Cells("colREferenciaFac").Value
                    hdr.HDOC_RF1_TXT = dgFactura.Rows(i).Cells("colMonedaFac").Value & " " & dgFactura.Rows(i).Cells("colTotalFac").Value & "/T.C: " & dgFactura.Rows(i).Cells("colTCFac").Value
                End If
            Next
        End If

        hdr.CONEXION = strConexion
        If Me.Tag = "Nuevo" Then

            If hdr.Guardar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Else
            If hdr.Actualizar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

        If celdaRecibos.Text = 1 Then
            GuardarDetalle(celdaNumeroHDR.Text, celdaAnio.Text)
        End If
    End Sub
    Private Sub BorrarEctateRetenISR(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 220 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarCuentaXPagar()
        Dim ect As New Tablas.TECTACTE

        ect.ECTA_SIS_EMP = Sesion.IdEmpresa
        ect.ECTA_DOC_CAT = 220
        ect.ECTA_DOC_ANO = celdaAnio.Text
        ect.ECTA_DOC_NUM = celdaNumeroHDR.Text
        ect.ECTA_DOC_LIN = INT_UNO
        ect.ECTA_TIPOEMP = "Proveedores"
        ect.ECTA_CODEMP = celdaIdProveedor.Text
        ect.ECTA_SINI_LOC = INT_CERO
        ect.ECTA_CRGO_LOC = INT_CERO
        ect.ECTA_SINI_EXT = INT_CERO
        ect.ECTA_CRGO_EXT = INT_CERO
        If checkActivo.Checked = True Then
            ect.ECTA_ABNO_LOC = celdaMonto.Text
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colMonedaFac").Value = "US$" Or dgFactura.Rows(i).Cells("colMonedaFac").Value = "USD" Then
                    'ect.ECTA_ABNO_EXT = (celdaMonto.Text) / celdaTipoCambio.Text 'dgFactura.Rows(i).Cells("colTCFac").Value
                    'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                    '' ect.ECTA_ABNO_EXT = (celdaMonto.Text) / cFunciones.TasaSegunFecha(dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
                    ect.ECTA_ABNO_EXT = (celdaMonto.Text) / celdaTCFactura.Text
                    'Else
                    '    ect.ECTA_ABNO_EXT = (celdaMonto.Text) / dgFactura.Rows(i).Cells("colTCFac").Value
                    'End If
                Else
                    ect.ECTA_ABNO_EXT = celdaMonto.Text
                End If
                ect.ECTA_CONCEPTO = "Retencion IVA / " & dgFactura.Rows(i).Cells("colREferenciaFac").Value
            Next
        Else
            ect.ECTA_ABNO_LOC = INT_CERO
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colMonedaFac").Value = "US$" Or dgFactura.Rows(i).Cells("colMonedaFac").Value = "USD" Then
                    'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                    ect.ECTA_ABNO_EXT = INT_CERO
                    'Else
                    '    ect.ECTA_ABNO_EXT = (celdaMonto.Text) / dgFactura.Rows(i).Cells("colTCFac").Value
                    'End If

                Else
                    ect.ECTA_ABNO_EXT = INT_CERO
                End If
                ect.ECTA_CONCEPTO = "Retencion IVA / " & dgFactura.Rows(i).Cells("colREferenciaFac").Value
            Next
        End If
        ect.ECta_FecDcmt_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECta_FecVenc_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECTA_MONEDA = cFunciones.DivisaLocal 'celdaIDMoneda.Text
        ect.ECTA_TC = INT_UNO  'celdaTipoCambio.Text
        ect.ECTA_REF_CAT = celdaCatF.Text
        ect.ECTA_REF_ANO = celdaAnioF.Text
        ect.ECTA_REF_NUM = celdaNumF.Text

        ect.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then
            If ect.PINSERT = False Then
                MsgBox(ect.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Else
            ActualizarCtaCorriente()
        End If

    End Sub

    Public Sub ActualizarCtaCorriente()
        Dim conec As MySqlConnection
        Dim intTransID As Integer
        Dim strsql As String
        Dim COMAND As MySqlCommand

        Try

            strsql = " SELECT e.ECta_TransId FROM ECtaCte e WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = {cat} AND e.ECta_Doc_Ano = {anio} AND e.ECta_Doc_Num = {num}"
            strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAnio.Text)
            strsql = Replace(strsql, "{num}", celdaNumeroHDR.Text)
            strsql = Replace(strsql, "{cat}", 220)

            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            COMAND = New MySqlCommand(strsql, conec)
            intTransID = COMAND.ExecuteScalar

            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strsql = STR_VACIO

            strsql = " Update ECtaCte  Set ECta_codemp = {emp}, ECta_Crgo_Loc = {cloc}, ECta_Abno_Loc= {aloc}, ECta_Crgo_Ext = {cext}, ECta_Abno_Ext = {aext},  ECta_FecVenc = '{venc}', ECta_FecDcmt = '{fec}', ECta_moneda = {mon}, ECta_TC = {tc}"
            strsql &= " Where ECta_TransId = {trans} and ECta_Sis_Emp = {idemp} and ECta_Doc_Cat ={cat}  and ECta_Doc_Ano = {anio} and ECta_Doc_Num = {num} "
            If Sesion.IdEmpresa = 18 Then
                strsql &= "; Update ECtaCte  Set ECta_codemp = {emp}, ECta_Crgo_Loc = {cloc}, ECta_Abno_Loc= {aloc}, ECta_Crgo_Ext = {cext}, ECta_Abno_Ext = {aext},  ECta_FecVenc = '{venc}', ECta_FecDcmt = '{fec}', ECta_moneda = {mon}, ECta_TC = {tc}"
                strsql &= " Where ECta_TransId = {trans} and ECta_Sis_Emp = {idemp} and ECta_Doc_Cat ={cat}  and ECta_Doc_Ano = {anio} and ECta_Doc_Num = {num} "
            End If
            strsql = Replace(strsql, "{idemp}", Sesion.IdEmpresa)
            strsql = Replace(strsql, "{anio}", celdaAnio.Text)
            strsql = Replace(strsql, "{num}", celdaNumeroHDR.Text)
            strsql = Replace(strsql, "{cat}", 220)
            strsql = Replace(strsql, "{trans}", intTransID)

            strsql = Replace(strsql, "{emp}", celdaIdProveedor.Text)
            strsql = Replace(strsql, "{cloc}", INT_CERO)
            strsql = Replace(strsql, "{aloc}", Replace(celdaMonto.Text, ",", ""))
            strsql = Replace(strsql, "{cext}", INT_CERO)
            strsql = Replace(strsql, "{aext}", Replace(celdaMonto.Text, ",", "") / cFunciones.TasaSegunFecha(dtpFechaDoc.Value.ToString(FORMATO_MYSQL)))
            'strsql = Replace(strsql, "{conc}", "Retencion IVA / " & dgFactura.SelectedCells("colREferenciaFac").Value)
            strsql = Replace(strsql, "{venc}", dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fec}", dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{mon}", cFunciones.DivisaLocal)
            strsql = Replace(strsql, "{tc}", INT_UNO)

            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            COMAND = New MySqlCommand(strsql, conec)
            COMAND.ExecuteNonQuery()

            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidarRetencionIvaProveedor(ByVal num As Integer, ByVal anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim logValidar As Integer = INT_CERO

        Try
            strSQL = " SELECT COUNT(*) "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 220 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND h.HDoc_Doc_Status = 1 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            logValidar = COM.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
#End Region

#Region "Eventos"
    Private Sub frmRetenISRProveedor_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFechaInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFechaFinal.Value = Today  'DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        MostrarLista()
        Accessos()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        If CDate(dtpFechaInicial.Value) > CDate(dtpFechaFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
        Else
            ListaPrincipal()
        End If

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intAnio As Integer = 0
        Dim intNum As Integer = 0

        LimpiarCampos()
        BloquearBotones()
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(0).Value
            intNum = dgLista.SelectedCells(1).Value
            CargarEncabezado(intAnio, intNum)
            MostrarSiEsProveedorRecibos(celdaIdProveedor.Text)
            If celdaRecibos.Text = 0 Then

                CargarFactura(intAnio, intNum)
            ElseIf celdaRecibos.Text = 1 Then
                CargarRecibos(intAnio, intNum)
            End If

            CargarPago(intAnio, intNum)
            MostrarLista(False)
            etiquetaPorcentaje.Visible = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Suppliers"
            frm.Campos = " p.pro_codigo codigo, p.pro_proveedor proveedor "
            frm.Tabla = " Proveedores p "
            frm.FiltroText = " Enter the Supplier to filter "
            frm.Filtro = " p.pro_proveedor "
            frm.Ordenamiento = " p.pro_proveedor "
            frm.TipoOrdenamiento = " ASC "
            frm.Condicion = " p.pro_sisemp = " & Sesion.IdEmpresa
            frm.Limite = 15

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato

                If Sesion.idGiro = 1 Then
                    MostrarSiEsProveedorRecibos(celdaIdProveedor.Text)
                End If

                MostrarFacturas()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarCampos()
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If

    End Sub

    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim strDato As String = 0
        Dim dblMonto1 As Double = 0
        Dim TC_dbl As Double = 0
        Dim i As Integer = 0
        Dim FISR As Double = 0
        Dim VIVA As Double = 0
        Dim dblMontoSum As Double = 0
        Dim dblMonto As Double = INT_CERO
        Dim frmO As New frmOption
        Dim intControl As Integer = INT_CERO
        Dim j As Integer = INT_CERO


        dgFactura.CurrentRow.Cells("colExtraFact").Value = 3 ' 3 es solo un pivote para que no se oculte la fila seleccionada
        For i = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 3 Then
                celdaAnioF.Text = dgFactura.Rows(i).Cells("colAnioFac").Value
                celdaNumF.Text = dgFactura.Rows(i).Cells("colNumeroFac").Value
                celdaCatF.Text = dgFactura.Rows(i).Cells("colCat").Value
                celdaMontoF.Text = dgFactura.Rows(i).Cells("colTotalFac").Value
                'dgFactura.Rows(i).Cells("colMonedaFac").Value
                'celdaTipoCambio.Text = INT_UNO.ToString(FORMATO_MONEDA) 'dgFactura.Rows(i).Cells("colTCFac").Value
                celdaTCFactura.Text = dgFactura.Rows(i).Cells("colTCFac").Value
                If Me.Tag = "Nuevo" Then
                    dgFactura.Rows(i).Cells("colExtraFact").Value = 0
                End If
                FISR = FactorISR() ' Consulta cual es el porcentaje de ISR dependiendo del pais
                VIVA = VerificarIVA()

                'Procedimiento para Calcular el ISR
                If Sesion.idGiro = 2 Then ' (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Then
                    If celdaTCFactura.Text = 1 Then
                        celdaIDMoneda.Text = 182 ' id de moneda Nicaragua (Córdobas) --> tambien Lempiras (HN)
                        celdaMoneda.Text = dgFactura.Rows(i).Cells("colMonedaFac").Value
                        celdaTipoCambio.Text = celdaTCFactura.Text
                        TC_dbl = 1
                    Else
                        TC_dbl = celdaTCFactura.Text
                        ' VIVA = VIVA / celdaTCFactura.Text
                    End If
                    If (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Then
                        TC_dbl = celdaTipoCambio.Text
                    End If
                    frmO.Titulo = "percentage"
                    frmO.Mensaje = "Enter the percentage to use in withholding"
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then 'HSM
                        frmO.Opciones = "1% Bienes y servicios" & "|" _
                                      & "12.5% servicios profesionales o técnicos" & "|" _
                                      & "10% Retenc. a No Residentes (Art.No.5, Num.8)" & "|" _
                                      & "25% Retenc. A No Residentes (Art.No.5,Num.3)" & "|" _
                                      & "15% Impuesto sobre Ventas (Acuerdo 215-2010)"
                    ElseIf Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 21 Then 'PDM
                        frmO.Opciones = "2% Bienes y servicios" & "|" _
                                      & "10% servicios profesionales o técnicos" & "|" _
                                      & "3% transportes marítimos,aéreo y carga" & "|" _
                                      & "15% arrendamientos y subarrendamientos,inmuebles" & "|" _
                                      & "15% intereses pagados" & "|" _
                                      & "20% Actividades Economicas a No Residentes"
                    ElseIf Sesion.IdEmpresa = 22 Then
                        frmO.Opciones = " 1% Retención Anticipo ISR/Bienes" & "|" _
                                     & "12.5% Prestación de honorarios profesionales y servicios" & "|" _
                                     & "25% A empresas extranjeras por servicios prestados en Honduras" & "|" _
                                     & "10% Retención por servicios"
                    Else
                        frmO.Opciones = "2% Bienes y servicios" & "|" _
                                      & "10% servicios profesionales o técnicos" & "|" _
                                      & "3% transportes marítimos,aéreo y carga" & "|" _
                                      & "15% arrendamientos y subarrendamientos,inmuebles" & "|" _
                                      & "15% intereses pagados" & "|" _
                                      & "20% Actividades Economicas a No Residentes"
                    End If

                    If frmO.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                            Select Case frmO.Seleccion
                                Case 0
                                    strDato = 1
                                    celdaTipoRetencion.Text = "Bienes y servicios"
                                Case 1
                                    strDato = 12.5
                                    celdaTipoRetencion.Text = "Servicios profesionales o técnicos"
                                Case 2
                                    strDato = 10
                                    celdaTipoRetencion.Text = "Retenc. A No Residentes"
                                Case 3
                                    strDato = 25 ' Retención no domiciliados Art. 5 Num 3
                                    celdaTipoRetencion.Text = "Retenc. A No Residentes"
                                Case 4
                                    strDato = 15 ' Impuesto sobre ventas (Acuerdo 215-20210)
                                    celdaTipoRetencion.Text = "Retención de ISV"

                            End Select
                        ElseIf Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then

                            Select Case frmO.Seleccion
                                Case 0
                                    strDato = 2
                                Case 1
                                    strDato = 10
                                Case 2
                                    strDato = 3
                                Case 3
                                    strDato = 15
                                    intControl = INT_UNO
                                Case 4
                                    strDato = 15 'intereses pagados - este no debe llevar el caso especial de la opcion de arriba
                                Case 5
                                    strDato = 20
                            End Select
                        ElseIf Sesion.IdEmpresa = 22 Then
                            Select Case frmO.Seleccion
                                Case 0
                                    strDato = 1
                                Case 1
                                    strDato = 12.5
                                Case 2
                                    strDato = 25
                                Case 3
                                    strDato = 10
                            End Select
                        Else
                            Select Case frmO.Seleccion
                                Case 0
                                    strDato = 2
                                Case 1
                                    strDato = 10
                                Case 2
                                    strDato = 3
                                Case 3
                                    strDato = 15
                                    intControl = INT_UNO
                                Case 4
                                    strDato = 15 ' intereses pagados - este no debe llevar el caso especial de la opcion de arriba
                                Case 5
                                    strDato = 20
                            End Select
                        End If

                    Else
                        Exit Sub
                    End If
                    If strDato = 15 And intControl = INT_UNO Then
                        dblMonto1 = Math.Round(((CDbl(celdaMontoF.Text) * CDbl(TC_dbl)) - VIVA), 2)
                        'dblMonto1 = Math.Round(((CDbl(celdaMontoF.Text - VIVA) * CDbl(TC_dbl)) * (strDato / 100)), 2)
                        celdaMonto.Text = Math.Round((dblMonto1 * (80 / 100)) * (strDato / 100), 2)
                        celdaTotal.Text = celdaMonto.Text
                        etiquetaPorcentaje.Text = strDato
                    ElseIf strDato = 1 Then
                        celdaMonto.Text = Math.Round((((CDbl(celdaMontoF.Text) * CDbl(TC_dbl)) - VIVA) * (strDato / 100)), 2)
                        celdaTotal.Text = celdaMonto.Text
                        etiquetaPorcentaje.Text = strDato
                    Else
                        'celdaMonto.Text = Math.Round(((CDbl(celdaMontoF.Text) * CDbl(TC_dbl)) - VIVA) * strDato / 100, 2)
                        celdaMonto.Text = Math.Round((((CDbl(celdaMontoF.Text) * CDbl(TC_dbl)) - VIVA) * (strDato / 100)), 2)
                        celdaTotal.Text = celdaMonto.Text
                        etiquetaPorcentaje.Text = strDato
                    End If

                Else
                    dblMontoSum = Math.Round(((CDbl(celdaMontoF.Text) * CDbl(celdaTCFactura.Text)) - VIVA) * FISR, 2)
                    dgFactura.Rows(i).Cells("colCalISR").Value = dblMontoSum
                    'dgFactura.Rows(i).Cells("colExtraFact").Value = 1


                    For j = 0 To dgFactura.Rows.Count - 1
                        If dgFactura.Rows(j).Visible = True Then
                            dblMonto = dblMonto + dgFactura.Rows(j).Cells("colCalISR").Value
                        End If
                    Next

                    celdaMonto.Text = Math.Round(CDbl(dblMonto), 2)
                    celdaTotal.Text = celdaMonto.Text

                    'If dgFactura.Rows.Count > 1 Then
                    'dgFactura.Rows(i).Cells("colExtraFact").Value = 1
                    'End If

                End If
                If dgFactura.Rows(i).Cells("colEspecialFac").Value = 1 Then
                    checkFacturaEspecial.Checked = True
                Else
                    checkFacturaEspecial.Checked = False
                End If
            Else
                If celdaRecibos.Text = 1 Then
                    If dgFactura.Rows.Count = 1 Then
                        If dgFactura.Rows(i).Cells("colExtraFact").Value <> 1 Then
                            dgFactura.Rows(i).Cells("colExtraFact").Value = 2 ' 2 elimina la fila (no guarda)
                        End If
                    End If
                Else
                    dgFactura.Rows(i).Cells("colExtraFact").Value = 2 ' 2 elimina la fila (no guarda)
                    dgFactura.Rows(i).Visible = False
                End If




            End If
        Next
        celdaControl.Text = intControl
    End Sub

    Private Sub celdaMonto_TextChanged(sender As Object, e As EventArgs) Handles celdaMonto.TextChanged
        If celdaMonto.Text.LongCount = 0 Then
            celdaTotal.Text = 0.00
        Else
            celdaTotal.Text = celdaMonto.Text
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim dtFechaConta As Date
        Dim conta As New clsContabilidad
        Dim cFunciones As New clsFunciones
        Dim strSQL As String '= STR_VACIO
        Dim COM As MySqlCommand
        Dim StatusRet As Integer

        If Me.Tag = "Nuevo" Then
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 11 Then
                celdaCAIRetencion.Text = cFunciones.Traer_Cat_Num_Ret("Doc_RetenISR")
            Else
                celdaCAIRetencion.Text = 0
            End If
            'Verifica si hay cierre o no
            If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                GuardarDatosDeDocumento()
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to create this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaProveedor.Text, 220, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                End If

            End If

        Else
                strSQL = " SELECT h.HDoc_Doc_Status
                            FROM Dcmtos_HDR h
                            WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 220 AND h.HDoc_Doc_Ano = " & celdaAnio.Text & " AND h.HDoc_Doc_Num = " & celdaNumeroHDR.Text

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteScalar()
            StatusRet = COM.ExecuteScalar

            If StatusRet = 1 Then
                MsgBox("Withholding is already paid, cannot be canceled", vbInformation, "Notice")
                Exit Sub
            End If
            'Captura la Fecha de la póliza o del documento, si este no tiene poliza
            dtFechaConta = cFunciones.SQLValidarFechaContable(220, celdaAnio.Text, celdaNumeroHDR.Text)
            'Verifica si hay cierre o no
            If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value) = 0 Then
                GuardarDatosDeDocumento()
                If (checkActivo.Checked = False) Or (StatusRet = 2) Then
                    cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                    cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                Else
                    conta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                End If
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaIdProveedor.Text, 220, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                    GuardarDatosDeDocumento()
                    If (checkActivo.Checked = False) Or (StatusRet = 2) Then
                        cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                        cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                    Else
                        conta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub GuardarDatosDeDocumento()
        If logEditar = True Or Me.Tag = "Nuevo" Then
            Dim clsConta As New clsContabilidad
            If ComprobarCampos() = True Then
                If celdaNumeroHDR.Text = -1 Then
                    celdaNumeroHDR.Text = cFunciones.NuevoId(220)
                End If

                GuardarRetencionHDR()
                GuardarCuentaXPagar()
                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 220, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("The Document has been successfully saved", vbInformation, "Notice")
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 220, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("The document has been successfully updated", vbInformation, "Notice")
                End If
                If Me.Tag = "Nuevo" Then
                    If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                        clsConta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                    Else
                        clsConta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                    End If
                End If
                MostrarLista(True)
            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub

    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click
        Dim PC As New clsPolizaContable
        PC.intTipo = 220
        PC.intCiclo = celdaAnio.Text
        PC.intNumero = celdaNumeroHDR.Text
        PC.intModo = 24
        PC.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 220,)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            'Dim COM As MySqlCommand
            If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value) = 0 Then
                Borrar_con_Click()
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to delete this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaProveedor.Text, 220, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                    Borrar_con_Click()
                End If
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub
    Private Function Borrar_con_Click()
        If ValidarRetencionIvaProveedor(celdaNumeroHDR.Text, celdaAnio.Text) = INT_CERO Then
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarEncabezadoISRProveedor(celdaNumeroHDR.Text, celdaAnio.Text)
                BorrarDetalleISRProveedor(celdaNumeroHDR.Text, celdaAnio.Text)
                BorrarEctateRetenISR(celdaNumeroHDR.Text, celdaAnio.Text)
                cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 220, celdaAnio.Text, celdaNumeroHDR.Text)
                MsgBox("Eliminated Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You can not delete a document in the process", vbInformation, "Notice")
        End If
    End Function

    Private Sub dtpFechaDoc_ValueChanged(sender As Object, e As EventArgs) Handles dtpFechaDoc.ValueChanged
        If celdaTipoCambio.Text > 1 Then
            celdaTipoCambio.Text = cFunciones.TasaSegunFecha(dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim rpt As New clsReportes
        rpt.GenerarReporteRetencionISRProveedores(celdaAnio.Text, celdaNumeroHDR.Text, etiquetaPorcentaje.Text)
    End Sub

    Private Function GuardarDetalle(ByVal intNumero As Integer, ByVal Año As Integer) As Boolean
        Dim cDTL As New clsDcmtos_DTL
        Dim logDetalle As Boolean = False
        Dim j As Integer = 0
        Try
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                cDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.DDOC_DOC_CAT = 220
                cDTL.DDOC_DOC_ANO = celdaAnio.Text
                cDTL.DDOC_DOC_NUM = celdaNumeroHDR.Text
                cDTL.DDOC_RF2_COD = celdaNumero.Text
                'cDTL.DDOC_PRD_COD = dgFactura.Rows(i).Cells("colNumeroFac").Value
                cDTL.DDOC_PRD_DES = dgFactura.Rows(i).Cells("colREferenciaFac").Value
                cDTL.DDOC_PRD_QTY = CDbl(dgFactura.Rows(i).Cells("colTotalFac").Value)
                cDTL.DDoc_RF1_Fec_NET = dgFactura.Rows(i).Cells("colFechaFac").Value
                cDTL.DDOC_RF1_TXT = dgFactura.Rows(i).Cells("colUsuarioFac").Value
                cDTL.DDOC_PRD_PNR = dgFactura.Rows(i).Cells("colMonedaFac").Value
                cDTL.DDOC_RF1_COD = dgFactura.Rows(i).Cells("colTCFac").Value
                cDTL.DDOC_PRD_NET = dgFactura.Rows(i).Cells("colCalISR").Value
                cDTL.DDOC_RF1_NUM = 209
                cDTL.DDOC_RF2_NUM = celdaAnioF.Text
                cDTL.DDOC_RF3_NUM = celdaNumF.Text

                If Me.Tag = "Nuevo" Then
                    If dgFactura.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    cDTL.DDOC_DOC_LIN = j
                Else
                    cDTL.DDOC_DOC_LIN = dgFactura.Rows(i).Cells("colLinea").Value
                End If

                If dgFactura.Rows(i).Cells("colExtraFact").Value = 1 And Me.Tag = "Mod" Then
                    If cDTL.Actualizar() = False Then
                        MsgBox(cDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgFactura.Rows(i).Cells("colExtraFact").Value = 0 And Me.Tag = "Nuevo" Then
                    If cDTL.Guardar() = False Then
                        MsgBox(cDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim fecha As DateTime
        Dim año As Integer = INT_CERO
        Dim i As Integer = INT_CERO

        Try
            frm.Titulo = "Receipts"
            frm.Campos = " h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, concat_ws(' ',h.HDoc_DR1_Num,h.HDoc_DR2_Num) Serie,
                           h.HDoc_RF1_Dbl Monto, c.cat_clave Moneda, h.HDoc_Doc_TC TC, h.HDoc_Ant_Com FactEsp, h.HDoc_Doc_Cat catalogo "
            'frm.Tabla = " Dcmtos_HDR h 
            'LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 0) AND NOT r.HDoc_Doc_Status = 2
            'LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_RF3_Num= h.HDoc_Doc_Num AND d.DDoc_RF1_Num = h.HDoc_Doc_Cat AND d.DDoc_RF2_Num = h.HDoc_Doc_Ano 
            'LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
            frm.Tabla = " Dcmtos_HDR h
            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_RF3_Num= h.HDoc_Doc_Num AND d.DDoc_RF1_Num = h.HDoc_Doc_Cat AND d.DDoc_RF2_Num = h.HDoc_Doc_Ano 
            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
            frm.FiltroText = " Enter the receipt to filter "
            'frm.Filtro = " p.pro_proveedor "
            frm.Ordenamiento = " fecha "
            frm.TipoOrdenamiento = " DESC "
            'frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat IN (209) AND h.HDoc_Emp_Cod =" & celdaIdProveedor.Text & " AND h.HDoc_Doc_Fec > '2022-08-30' AND h.HDoc_Doc_Status = 1 AND r.HDoc_Sis_Emp IS NULL AND d.DDoc_RF3_Num IS NULL"
            frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat IN (209) AND h.HDoc_Emp_Cod =" & celdaIdProveedor.Text & " AND h.HDoc_Doc_Fec > '2022-08-30' AND h.HDoc_Doc_Status = 1 AND d.DDoc_RF3_Num IS NULL"
            frm.Limite = 15

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                For i = 0 To dgFactura.Rows.Count - 1
                    If dgFactura.Rows(i).Cells("colNumeroFac").Value = frm.Dato And dgFactura.Rows(i).Visible = True Then
                        If MsgBox("This document is already uploaded please upload a different one", vbOKOnly, "Notice") = vbOK Then
                            Exit Sub
                        End If
                    End If
                Next


                fecha = frm.LLave
                año = fecha.Year

                strFila = año & "|"
                strFila &= frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= frm.Dato2 & "|"
                strFila &= frm.Dato3 & "|"
                strFila &= frm.Dato4 & "|"
                strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(6).Value & "|"
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= 0

                cFunciones.AgregarFila(dgFactura, strFila)

            End If

            If celdaRecibos.Text = 1 Then
                dgFactura.Columns("colCalISR").Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgFactura.SelectedRows.Count = INT_CERO Then Exit Sub
        dgFactura.CurrentRow.Cells("colExtraFact").Value = 2
        dgFactura.CurrentRow.Visible = False
        dgFactura.Focus()
    End Sub

    Public Sub MostrarSiEsProveedorRecibos(ByVal IdProveedor As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strFila As String = STR_VACIO
        Dim recibos As Integer = INT_CERO
        Dim REA As MySqlDataReader

        Try
            recibos = ProveedorCSRecibos(IdProveedor)

            celdaRecibos.Text = recibos

            If celdaRecibos.Text = "1" Then
                botonAgregar.Visible = True
                botonQuitar.Visible = True
                celdaMonto.ReadOnly = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function ProveedorCSRecibos(ByVal idProveedor As Integer) As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Recibos As Integer = 0
        Dim conec As MySqlConnection

        strSQL = " Select IF(p.pro_anticipos = '',0,p.pro_anticipos) recibos "
        strSQL &= "    From Proveedores p "
        strSQL &= "        WHERE p.pro_sisemp = {empresa} and p.pro_codigo = {idProveedor}"
        strSQL &= "           ORDER BY p.pro_proveedor ASC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{idProveedor}", idProveedor)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Recibos = COM.ExecuteScalar
        conec.Close()

        Return Recibos
    End Function

    Private Sub CargarRecibos(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarRecibos(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    strFila &= 0 & "|" 'indica que son recibos
                    'strFila &= 0 & "|"  'categoria
                    strFila &= 1 & "|" 'extra 1 = actaulizar, 0= insertar
                    strFila &= REA.GetDouble("catalogo") & "|"
                    strFila &= REA.GetDouble("CalISR") & "|"
                    strFila &= REA.GetInt32("linea")


                    cFunciones.AgregarFila(dgFactura, strFila)
                    'celdaIDMoneda.Text = cFunciones.DivisaLocal
                    'celdaTipoCambio.Text = 1
                    celdaCatF.Text = 44
                    celdaAnioF.Text = REA.GetInt32("anio")
                    celdaNumF.Text = REA.GetInt32("numero")
                    celdaTCFactura.Text = REA.GetDouble("TC")
                    celdaMontoF.Text = REA.GetDouble("Monto")

                Loop
                'celdaTipoCambio.Text = 1

            End If

            If celdaRecibos.Text = 1 Then
                dgFactura.Columns("colCalISR").Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLCargarRecibos(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0) ''se agregan recibos
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.DDoc_Doc_Ano anio,d.DDoc_RF1_Fec fecha, d.DDoc_RF3_Num numero, d.DDoc_RF1_Txt Usuario, d.DDoc_PRD_Cod NumFac,d.DDoc_PRD_Des Serie, d.DDoc_Prd_Qty Monto, "
        strSQL &= "  h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Doc_Mon idMoneda, d.DDoc_RF1_Num catalogo, d.DDoc_Prd_Net CalISR, d.DDoc_Doc_Lin linea"
        strSQL &= "    FROM Dcmtos_HDR h "
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
        strSQL &= "        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "            WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 220 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        'strSQL = Replace(strSQL, "{cod}", codigo)

        Return strSQL
    End Function


    Private Sub BorrarDetalleISRProveedor(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = 220 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFactura_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgFactura.CellEndEdit
        Dim dblMonto As Double = 0

        Select Case dgFactura.CurrentCell.ColumnIndex
            Case 11
                If dgFactura.Rows.Count = 1 Then
                    celdaMonto.Text = Math.Round(CDbl(dgFactura.CurrentRow.Cells("colCalISR").Value), 2)
                    celdaTotal.Text = celdaMonto.Text
                Else
                    For i = 0 To dgFactura.Rows.Count - 1
                        dblMonto = Math.Round(CDbl(dblMonto) + CDbl(dgFactura.Rows(i).Cells("colCalISR").Value), 2)
                    Next
                    celdaMonto.Text = dblMonto
                    celdaTotal.Text = celdaMonto.Text
                End If
        End Select

        'dgFactura.CurrentRow.Cells("colExtraFact").Value = 1

    End Sub


#End Region
End Class