﻿Public Class frmRetenIVAProveedor

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Num Numero, h.HDoc_Doc_Ano Anio, h.HDoc_DR1_Num Documento, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Nombre, h.HDoc_RF1_Dbl Monto, CONCAT(IFNULL(d.HDoc_DR1_Num,''), ' ', IFNULL(d.HDoc_DR2_Num,'')) Factura, IFNULL(d.HDoc_RF1_Dbl,0) Total, h.HDoc_Doc_Status Estado "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        Left JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND d.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND d.HDoc_Doc_Num = h.HDoc_Pro_DNum "
        strSQL &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 220 AND (h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{final}') AND h.HDoc_Ant_Com = 1 "
        strSQL &= "                ORDER BY h.HDoc_Doc_Fec DESC, h.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{inicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{final}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function

    Private Function SQLCargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat cat, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod cod, h.HDoc_Emp_Nom proveedor, h.HDoc_Doc_Mon moneda, h.HDoc_Doc_TC TC, h.HDoc_RF1_Dbl total, h.HDoc_Pro_DCat catF, h.HDoc_Pro_DAno anioF, h.HDoc_Pro_DNum numF, h.HDoc_DR1_Num retencion, h.HDoc_DR1_Cat tipoFac, h.HDoc_Doc_Status,  if(h.HDoc_DR2_Fec IS NULL, h.HDoc_Doc_Fec,HDoc_DR2_Fec) fechaC "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 220 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strSQL &= "            LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        Return strSQL
    End Function

    Private Function SQLCargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0) ''se agregan recibos
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT r.HDoc_Doc_Ano anio,r.HDoc_Doc_Fec fecha, r.HDoc_Doc_Num numero, r.HDoc_Usuario, r.HDoc_DR1_Num NumFac,r.HDoc_DR2_Num Serie, r.HDoc_RF1_Dbl Monto, r.HDoc_Doc_TC TC, c.cat_clave Moneda, r.HDoc_Doc_Mon idMoneda "
        strSQL &= "    From Dcmtos_HDR r"
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon and c.cat_clase = 'Monedas' "
        strSQL &= "            WHERE r.HDoc_Sis_Emp = {empresa} AND r.HDoc_Doc_Cat  in (44,209) AND r.HDoc_Doc_Ano = {anio} AND r.HDoc_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        'strSQL = Replace(strSQL, "{cod}", codigo)

        Return strSQL
    End Function

    Private Function SQLCargarPagos(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSLQ As String = STR_VACIO

        strSLQ = " SELECT HDoc_DR1_Num cheque, HDoc_Doc_Fec fecha,cat_clave moneda ,HDoc_Doc_TC tasa, CONCAT(Bcta_Des_Cue,' ',BCta_Num_Cue) cuenta ,DDoc_RF1_Dbl total "
        strSLQ &= "    From Dcmtos_HDR "
        strSLQ &= "        Left JOIN Dcmtos_DTL ON DDoc_Sis_Emp = HDoc_Sis_Emp AND DDoc_Doc_Cat = HDoc_Doc_Cat AND DDoc_Doc_Ano = HDoc_Doc_Ano AND DDoc_Doc_Num = HDoc_Doc_Num "
        strSLQ &= "            Left JOIN Catalogos ON cat_num = HDoc_Doc_Mon "
        strSLQ &= "                Left JOIN CtasBcos ON BCta_Num = HDoc_RF1_Num "
        strSLQ &= "                    WHERE DDoc_Sis_Emp = {empresa} AND DDoc_RF1_Num = 220 AND DDoc_RF2_Num = {anio} and DDoc_RF3_Num= {num} "

        strSLQ = Replace(strSLQ, "{empresa}", Sesion.IdEmpresa)
        strSLQ = Replace(strSLQ, "{anio}", intAnio)
        strSLQ = Replace(strSLQ, "{num}", intNum)

        Return strSLQ

    End Function

    Private Function SQLMostrarFacturas() ''se agregan recibos
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, 
	                h.HDoc_DR2_Num Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Doc_Cat catalogo, h.HDoc_Ant_Com FactEsp 
                    From Dcmtos_HDR h
                    Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat 
	                    AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 1) 
	                    AND NOT  r.HDoc_Doc_Status = 2 
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_RF1_Num = h.HDoc_Doc_Cat AND d.DDoc_RF2_Num = h.HDoc_Doc_Ano AND d.DDoc_RF3_Num = h.HDoc_Doc_Num
                    LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas' 
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat  in (209) AND h.HDoc_Emp_Cod ={cod} AND h.HDoc_Doc_Fec > '{fecha}' AND r.HDoc_Sis_Emp IS NULL AND d.DDoc_RF3_Num IS NULL
                    UNION
                    SELECT
	                    h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, 
	                    h.HDoc_DR2_Num Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Doc_Cat catalogo, h.HDoc_Ant_Com FactEsp 
                    From Dcmtos_HDR h
                    Left JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat 
	                    AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 1) 
	                    AND NOT  r.HDoc_Doc_Status = 2 
                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Prd_Cod = h.HDoc_Doc_Num AND d.DDoc_Doc_Cat = 220 AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano 
                    LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas' 
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat  in (44) AND h.HDoc_Emp_Cod ={cod} AND h.HDoc_Doc_Fec > '{fecha}' 
	                    AND h.HDoc_Doc_Status = 1 AND r.HDoc_Sis_Emp IS NULL {monto} AND d.DDoc_Prd_Cod IS NULL
                    ORDER BY fecha desc"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cod}", celdaIdProveedor.Text)
        strSQL = Replace(strSQL, "{fecha}", DateSerial(Year(Date.Now), Month(Date.Now) - 4, 30).ToString(FORMATO_MYSQL))
        If Sesion.IdEmpresa = 12 Then
            strSQL = Replace(strSQL, "{monto}", "AND IF(h.HDoc_Doc_Mon = 178,h.HDoc_RF1_Dbl>0,IF( h.HDoc_Ant_Com =0,h.HDoc_RF1_Dbl>=2500,h.HDoc_RF1_Dbl>0))")
        Else
            strSQL = Replace(strSQL, "{monto}", "")
        End If
        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Documento") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetInt32("Estado")

                    If REA.GetInt32("Estado") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.LightBlue)
                    ElseIf REA.GetInt32("Estado") = 1 Then
                        cFunciones.AgregarFila(dgLista, strFila)
                    ElseIf REA.GetInt32("Estado") = 2 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            BarraTitulo1.CambiarTitulo("IVA Withholding Provider")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Sub CargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLCargarEncabezado(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                REA.Read()

                celdaAnio.Text = REA.GetInt32("anio")
                dtpFechaDoc.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                dtpFechaPolizaC.Value = REA.GetDateTime("fechaC").ToString(FORMATO_MYSQL)
                celdaNumero.Text = REA.GetString("retencion")
                celdaProveedor.Text = REA.GetString("proveedor")
                celdaIdProveedor.Text = REA.GetInt32("cod")
                celdaMonto.Text = REA.GetDouble("total").ToString(FORMATO_MONEDA)
                celdaCatalogo.Text = REA.GetInt32("cat")
                celdaAnio.Text = REA.GetInt32("anio")
                celdaNumeroHDR.Text = REA.GetInt32("numero")
                celdaCatF.Text = REA.GetInt32("catF")
                celdaAnioF.Text = REA.GetInt32("anioF")
                celdaNumF.Text = REA.GetInt32("numF")
                If REA.GetInt32("HDoc_Doc_Status") = 2 Then
                    checkActivo.Checked = False
                    checkActivo.Enabled = False
                Else
                    checkActivo.Checked = True
                    checkActivo.Enabled = True
                End If

                If REA.GetInt32("tipoFac") = 1 Then
                    checkFacturaEspecial.Checked = True
                Else
                    checkFacturaEspecial.Checked = False
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarFactura(celdaAnioF.Text, celdaNumF.Text, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("HDoc_Usuario") & "|"
                    strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    If checkFacturaEspecial.Checked = True Then
                        strFila &= 1 & "|"
                    Else
                        strFila &= 0 & "|"
                    End If
                    strFila &= 1 ' 1 actualizar, 0 insertar

                    cFunciones.AgregarFila(dgFactura, strFila)
                    celdaIDMoneda.Text = cFunciones.DivisaLocal
                    celdaTipoCambio.Text = 1
                    celdaCatF.Text = 44
                    celdaAnioF.Text = REA.GetInt32("anio")
                    celdaNumF.Text = REA.GetInt32("numero")
                    celdaTCFactura.Text = REA.GetDouble("TC")
                    celdaMontoF.Text = REA.GetDouble("Monto")
                Loop
                celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)


            End If

            dgFactura.Columns("colIva").Visible = False

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarPago(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarPagos(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cheque") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("moneda") & "|"
                    strFila &= REA.GetDouble("tasa") & "|"
                    strFila &= REA.GetString("cuenta") & "|"
                    strFila &= REA.GetDouble("total")

                    cFunciones.AgregarFila(dgDatos, strFila)
                Loop
                celdaTotal.Text = CDbl(celdaMonto.Text) - CDbl(dgDatos.CurrentRow.Cells("colTota1").Value)
            Else
                celdaTotal.Text = CDbl(celdaMonto.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub MostrarFacturas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLMostrarFacturas()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("HDoc_Usuario") & "|"
                    strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    strFila &= REA.GetInt32("FactEsp") & "|"
                    strFila &= REA.GetInt32("catalogo") & "|"
                    strFila &= 0 ' 1 actualizar, 0 insertar

                    If celdaRecibos.Text = 0 And REA.GetInt32("catalogo") = 209 Then
                    ElseIf celdaRecibos.Text = 0 And REA.GetInt32("catalogo") = 44 Then
                        cFunciones.AgregarFila(dgFactura, strFila)
                    ElseIf celdaRecibos.Text = 1 And REA.GetInt32("catalogo") = 209 Then
                        cFunciones.AgregarFila(dgFactura, strFila)
                    End If

                Loop

            End If


            If celdaRecibos.Text = 1 Then
                dgFactura.Columns("colIva").Visible = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function FactorIVA(Optional clave As String = "IVA_RG") As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim factor As Double = 0

        strSQL = " SELECT ROUND(a.cat_sist /100,2) factorIVA "
        strSQL &= "    From Catalogos a "
        strSQL &= "        WHERE a.cat_clase='Impuestos' AND a.cat_sisemp = 0 AND a.cat_clave = '{clave}' "

        strSQL = Replace(strSQL, "{clave}", clave)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        factor = COM.ExecuteScalar

        Return factor
    End Function

    Public Function VerificarIVA() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim IVA As Double = 0

        strSQL = " SELECT IFNULL(SUM(MDoc_Lin_Monto),0) "
        strSQL &= "    From Dcmtos_IMP "
        strSQL &= "        WHERE MDoc_Sis_Emp={empresa} AND MDoc_Doc_Cat in (44,209) AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={num} AND MDoc_Lin_Tipo= 0 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnioF.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumF.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        IVA = COM.ExecuteScalar

        Return IVA
    End Function

    Public Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaAnioOc.Clear()
        celdaCatalogo.Text = 220
        celdaMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaNumero.Clear()
        celdaNumeroHDR.Text = -1
        celdaProveedor.Clear()
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFechaDoc.Text = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        dtpFechaPolizaC.Text = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaMoneda.Clear()
        celdaIDMoneda.Clear()
        celdaTipoCambio.Clear()
        celdaTCFactura.Clear()
        checkFacturaEspecial.Checked = False
        checkActivo.Checked = True
        checkActivo.Enabled = True
        celdaIDMoneda.Text = cFunciones.DivisaLocal
        celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)
        celdaTipoCambio.Text = 1

        dgFactura.Rows.Clear()
        dgDatos.Rows.Clear()

        botonAgregar.Visible = False
        botonQuitar.Visible -= False
        celdaRecibos.Text = "0"
        dgFactura.Columns("colIva").Visible = False
        celdaMonto.ReadOnly = False

    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        If celdaNumero.Text = vbNullString Then
            If MsgBox("You must enter the Withholding Number", vbOKOnly, vbInformation) = vbOK Then
                celdaNumero.Focus()
                comprobar = False
            ElseIf celdaProveedor.Text = vbNullString Then
                If MsgBox("You must select a provider", vbOKOnly, vbInformation) = vbOK Then
                    botonProveedor.Focus()
                    comprobar = False
                End If
            ElseIf dgFactura.Rows.Count > 1 Then
                If MsgBox("Select an invoice please", vbOKOnly, vbInformation) = vbOK Then
                    comprobar = False
                End If
            End If
        End If

        'If celdaMonto.Text = "0.00" Then
        '    If MsgBox("Please do the IVA calculation for document", vbOKOnly, vbInformation) = vbOK Then
        '        comprobar = False
        '    End If
        'End If

        For i = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Visible = True Then
                If dgFactura.Rows(i).Cells("colIva").Value = Nothing And celdaMonto.Text = "0.00" Then
                    If MsgBox("Please do the IVA calculation for document", vbOKOnly, "Notice") = vbOK Then
                        comprobar = False
                    End If
                End If
            End If
        Next

        Return comprobar
    End Function
    Private Sub BorrarEncabezadoIvaProveedor(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 220
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarRetencionHDR()
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 220
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_NUM = celdaNumeroHDR.Text
        hdr.HDoc_Doc_Fec_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        hdr.HDoc_DR2_Fec_NET = dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL)
        hdr.HDOC_EMP_COD = celdaIdProveedor.Text
        hdr.HDOC_EMP_NOM = celdaProveedor.Text
        hdr.HDOC_RF1_DBL = celdaMonto.Text
        If celdaRecibos.Text = 0 Then
            hdr.HDOC_PRO_DCAT = celdaCatF.Text
            hdr.HDOC_PRO_DNUM = celdaNumF.Text
            hdr.HDOC_PRO_DANO = celdaAnioF.Text
        End If

        hdr.HDOC_DR1_NUM = celdaNumero.Text
        hdr.HDOC_DR1_CAT = IIf(checkFacturaEspecial.Checked = True, INT_UNO, INT_CERO)
        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 0 Or dgFactura.Rows(i).Cells("colExtraFact").Value = 1 Then
                hdr.HDOC_DR2_NUM = dgFactura.Rows(i).Cells("colREferenciaFac").Value
                hdr.HDOC_RF1_TXT = dgFactura.Rows(i).Cells("colMonedaFac").Value & " " & dgFactura.Rows(i).Cells("colTotalFac").Value & "/T.C: " & dgFactura.Rows(i).Cells("colTCFac").Value
            Else
            End If
        Next
        hdr.HDOC_DOC_MON = celdaIDMoneda.Text
        hdr.HDOC_DOC_TC = celdaTipoCambio.Text
        hdr.HDOC_USUARIO = Sesion.Usuario
        If checkActivo.Checked = True Then
            hdr.HDOC_DOC_STATUS = INT_CERO ' 0 porque aun no está pagada la retención, al momento de jalarla para pagar debe actualizar a 1 en este campo
        Else
            hdr.HDOC_DOC_STATUS = 2
        End If
        hdr.HDOC_ANT_COM = INT_UNO ' Retencion de IVA 1, retencion de ISR 0

        hdr.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then

            If hdr.Guardar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If

        Else
            If hdr.Actualizar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

        If celdaRecibos.Text = 1 Then
            GuardarDetalle(celdaNumeroHDR.Text, celdaAnio.Text)
        End If

    End Sub
    Private Sub BorrarEctateRetenIva(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 220 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActualizarReferencia()
        Dim COM As MySqlCommand
        Dim strSQL As String
        Dim dblAbonoExt As Double = 0
        Dim dblAbonoLoc As Double = 0
        Dim dblTotal As Double
        Dim dblCredito As Double
        Dim dblDebito As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO
        Dim cat As Integer = NO_FILA
        Dim anioRef As Integer = NO_FILA
        Dim numref As Integer = NO_FILA
        Try
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                dblCredito = vbEmpty
                dblDebito = vbEmpty
                dblTotal = vbEmpty
                If dgFactura.Rows(i).Cells("colMonedaFac").Value = "US$" Then
                    dblTotal = (celdaMonto.Text) / dgFactura.Rows(i).Cells("colTCFac").Value
                Else
                    dblTotal = INT_CERO
                End If
                strDato = "Retencion IVA / " & dgFactura.Rows(i).Cells("colREferenciaFac").Value
                'Transacción: cargo/abono local y en moneda del doc.
                dblCredito = celdaMonto.Text
            Next
            strSQL = " UPDATE  ECtaCte  e  SET e.ECta_codemp = {proveedor},e.ECta_Abno_Loc = {total}, e.ECta_Abno_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fecha}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
            strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 220  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE  PDM.ECtaCte  e  SET e.ECta_codemp = {proveedor},e.ECta_Abno_Loc = {total}, e.ECta_Abno_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fecha}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
                strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 220  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumeroHDR.Text)
            strSQL = Replace(strSQL, "{total}", dblCredito.ToString(FORMATO_MONEDA))
            strSQL = Replace(strSQL, "{totalext}", dblTotal.ToString(FORMATO_MONEDA))
            strSQL = Replace(strSQL, "{dato}", strDato)
            strSQL = Replace(strSQL, "{proveedor}", celdaIdProveedor.Text)
            strSQL = Replace(strSQL, "{fecha}", dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{moneda}", celdaIDMoneda.Text)
            strSQL = Replace(strSQL, "{tasa}", celdaTipoCambio.Text)
            strSQL = Replace(strSQL, "{catref}", celdaCatF.Text)
            strSQL = Replace(strSQL, "{anioref}", celdaAnioF.Text)
            strSQL = Replace(strSQL, "{numref}", celdaNumF.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarCuentaXPagar()
        Dim ect As New Tablas.TECTACTE
        ect.ECTA_SIS_EMP = Sesion.IdEmpresa
        ect.ECTA_DOC_CAT = 220
        ect.ECTA_DOC_ANO = celdaAnio.Text
        ect.ECTA_DOC_NUM = celdaNumeroHDR.Text
        ect.ECTA_DOC_LIN = INT_UNO
        ect.ECTA_TIPOEMP = "Proveedores"
        ect.ECTA_CODEMP = celdaIdProveedor.Text
        ect.ECTA_SINI_LOC = INT_CERO
        ect.ECTA_CRGO_LOC = INT_CERO
        ect.ECTA_SINI_EXT = INT_CERO
        ect.ECTA_CRGO_EXT = INT_CERO
        If checkActivo.Checked = True Then
            ect.ECTA_ABNO_LOC = celdaMonto.Text
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colMonedaFac").Value = "US$" Or dgFactura.Rows(i).Cells("colMonedaFac").Value = "USD" Then
                    ect.ECTA_ABNO_EXT = (celdaMonto.Text) / dgFactura.Rows(i).Cells("colTCFac").Value
                Else
                    ect.ECTA_ABNO_EXT = celdaMonto.Text
                End If
                ect.ECTA_CONCEPTO = "Retencion IVA / " & dgFactura.Rows(i).Cells("colREferenciaFac").Value
            Next
        Else
            ect.ECTA_ABNO_LOC = INT_CERO
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Cells("colMonedaFac").Value = "US$" Or dgFactura.Rows(i).Cells("colMonedaFac").Value = "USD" Then
                    ect.ECTA_ABNO_EXT = INT_CERO '  (celdaMonto.Text) / dgFactura.Rows(i).Cells("colTCFac").Value
                Else
                    ect.ECTA_ABNO_EXT = INT_CERO 'celdaMonto.Text
                End If
                ect.ECTA_CONCEPTO = "Retencion IVA ANULADA / " & dgFactura.Rows(i).Cells("colREferenciaFac").Value
            Next
        End If

        ect.ECta_FecDcmt_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECta_FecVenc_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECTA_MONEDA = celdaIDMoneda.Text
        ect.ECTA_TC = celdaTipoCambio.Text
        ect.ECTA_REF_CAT = celdaCatF.Text
        ect.ECTA_REF_ANO = celdaAnioF.Text
        ect.ECTA_REF_NUM = celdaNumF.Text

        ect.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then
            If ect.PINSERT = False Then
                MsgBox(ect.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Else
            'ActualizarReferencia()
            If ect.PUPDATE = False Then
                MsgBox(ect.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        End If
    End Sub
    Private Function ValidarRetencionIvaProveedor(ByVal num As Integer, ByVal anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim logValidar As Integer = INT_CERO

        Try
            strSQL = " SELECT COUNT(*) "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 220 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND h.HDoc_Doc_Status = 1 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            logValidar = COM.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
#End Region

#Region "Eventos"
    Private Sub frmRetenIVAProveedor_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFechaInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFechaFinal.Value = Today  'DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        MostrarLista()
        Accessos()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        If CDate(dtpFechaInicial.Value) > CDate(dtpFechaFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
        Else
            ListaPrincipal()
        End If

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intAnio As Integer = 0
        Dim intNum As Integer = 0
        Dim intNumFac As Integer = 0

        LimpiarCampos()
        BloquearBotones()
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(0).Value
            intNum = dgLista.SelectedCells(1).Value
            CargarEncabezado(intAnio, intNum)
            MostrarSiEsProveedorRecibos(celdaIdProveedor.Text)
            intNumFac = celdaNumF.Text
            If celdaRecibos.Text = 0 Then
                CargarFactura(intAnio, intNum)
            ElseIf celdaRecibos.Text = 1 Then
                CargarRecibos(intAnio, intNum, intNumFac)
            End If

            CargarPago(intAnio, intNum)

            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Suppliers"
            frm.Campos = " p.pro_codigo codigo, p.pro_proveedor proveedor "
            frm.Tabla = " Proveedores p "
            frm.FiltroText = " Enter the Supplier to filter "
            frm.Filtro = " p.pro_proveedor "
            frm.Ordenamiento = " p.pro_proveedor "
            frm.TipoOrdenamiento = " ASC "
            frm.Condicion = " p.pro_sisemp = " & Sesion.IdEmpresa
            frm.Limite = 15

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato

                If Sesion.idGiro = 1 Then
                    MostrarSiEsProveedorRecibos(celdaIdProveedor.Text)
                End If

                MostrarFacturas()

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarCampos()
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If

    End Sub

    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim i As Integer = 0
        Dim Factor As Double = 0
        Dim Verificar As Double = 0
        Dim dblMontoSum As Double = 0
        Dim dblMonto As Double = INT_CERO
        Dim j As Integer = INT_CERO

        dgFactura.CurrentRow.Cells("colExtraFact").Value = 3 ' 3 es solo un pivote para que no se oculte la fila seleccionada
        For i = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 3 Then
                celdaAnioF.Text = dgFactura.Rows(i).Cells("colAnioFac").Value
                celdaNumF.Text = dgFactura.Rows(i).Cells("colNumeroFac").Value
                celdaCatF.Text = 44
                celdaMontoF.Text = dgFactura.Rows(i).Cells("colTotalFac").Value
                celdaIDMoneda.Text = cFunciones.DivisaLocal
                celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)  'dgFactura.Rows(i).Cells("colMonedaFac").Value
                celdaTipoCambio.Text = INT_UNO.ToString(FORMATO_MONEDA) 'dgFactura.Rows(i).Cells("colTCFac").Value
                celdaTCFactura.Text = dgFactura.Rows(i).Cells("colTCFac").Value
                dgFactura.Rows(i).Cells("colExtraFact").Value = 0
                Verificar = VerificarIVA()
                If dgFactura.Rows(i).Cells("colEspecialFac").Value = 1 Then
                    checkFacturaEspecial.Checked = True
                    celdaMonto.Text = Verificar
                Else
                    checkFacturaEspecial.Checked = False
                    If Verificar = 0 Then
                        Factor = FactorIVA("IVA_PC") ' IVA pequeño contribuyente es 5% sobre el total de la factura en GT
                        dblMontoSum = Math.Round((CDbl(celdaMontoF.Text) * CDbl(celdaTCFactura.Text) * Factor), 2)
                        dgFactura.Rows(i).Cells("colIva").Value = dblMontoSum
                        dgFactura.Rows(i).Cells("colExtraFact").Value = 1
                        For j = 0 To dgFactura.Rows.Count - 1
                            If dgFactura.Rows(j).Visible = True Then
                                dblMonto = dblMonto + dgFactura.Rows(j).Cells("colIva").Value
                            End If
                        Next
                        celdaMonto.Text = Math.Round(CDbl(dblMonto), 2)
                        celdaTotal.Text = celdaMonto.Text

                        dgFactura.Rows(i).Cells("colExtraFact").Value = 1
                    Else
                        Factor = FactorIVA() ' Consulta cual es el porcentaje de IVA dependiendo del pais
                        celdaMonto.Text = Math.Round(Verificar * Factor, 2)
                        dgFactura.Rows(i).Cells("colIva").Value = celdaMonto.Text
                        dgFactura.Rows(i).Cells("colExtraFact").Value = 1
                        For j = 0 To dgFactura.Rows.Count - 1
                            If dgFactura.Rows(j).Visible = True Then
                                dblMonto = dblMonto + dgFactura.Rows(j).Cells("colIva").Value
                            End If
                        Next
                        celdaMonto.Text = Math.Round(CDbl(dblMonto), 2)
                        celdaTotal.Text = celdaMonto.Text

                        dgFactura.Rows(i).Cells("colExtraFact").Value = 1
                    End If
                End If

                'Procedimiento para Calcular el ISR
                'celdaMonto.Text = Math.Round(((CDbl(celdaMontoF.Text) * CDbl(celdaTCFactura.Text)) - VerificarIVA()) * FactorIVA(), 2)
                celdaTotal.Text = celdaMonto.Text

            Else
                If celdaRecibos.Text = 1 Then
                    If dgFactura.Rows.Count = 1 Then
                        If dgFactura.Rows(i).Cells("colExtraFact").Value <> 1 Then
                            dgFactura.Rows(i).Cells("colExtraFact").Value = 2 ' 2 elimina la fila (no guarda)
                        End If
                    End If
                Else
                    dgFactura.Rows(i).Cells("colExtraFact").Value = 2 ' 2 elimina la fila (no guarda)
                    dgFactura.Rows(i).Visible = False
                End If
            End If
        Next
    End Sub

    Private Sub celdaMonto_TextChanged(sender As Object, e As EventArgs) Handles celdaMonto.TextChanged
        If celdaMonto.Text.LongCount = 0 Then
            celdaTotal.Text = 0.00
        Else
            celdaTotal.Text = celdaMonto.Text
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim dtFechaConta As Date
        Dim conta As New clsContabilidad
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim StatusRet As Integer


        If Me.Tag = "Nuevo" Then
            GuardarDatosDeDocumento()
        Else
            strSQL = " SELECT h.HDoc_Doc_Status
                            FROM Dcmtos_HDR h
                            WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 220 AND h.HDoc_Doc_Ano = " & celdaAnio.Text & " AND h.HDoc_Doc_Num = " & celdaNumeroHDR.Text

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteScalar()
            StatusRet = COM.ExecuteScalar

            If StatusRet = 1 Then
                MsgBox("Withholding is already paid, cannot be canceled", vbInformation, "Notice")
                Exit Sub
            End If

            'Captura la Fecha de la póliza o del documento, si este no tiene poliza
            dtFechaConta = cFunciones.SQLValidarFechaContable(220, celdaAnio.Text, celdaNumeroHDR.Text)
            'Verifica si hay cierre o no
            If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                GuardarDatosDeDocumento()
                If (checkActivo.Checked = False) Or (StatusRet = 2) Then
                    cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                    cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                Else
                    conta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                End If
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaProveedor.Text, 220, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                    GuardarDatosDeDocumento()
                    If (checkActivo.Checked = False) Or (StatusRet = 2) Then
                        cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                        cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                    Else
                        conta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub GuardarDatosDeDocumento()
        If logEditar = True Or Me.Tag = "Nuevo" Then
            Dim clsConta As New clsContabilidad
            If ComprobarCampos() = True Then
                If celdaNumeroHDR.Text = -1 Then
                    celdaNumeroHDR.Text = cFunciones.NuevoId(220)
                End If
                GuardarRetencionHDR()
                GuardarCuentaXPagar()
                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 220, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("The Document has been successfully saved", vbInformation, "Notice")
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 220, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("The document has been successfully updated", vbInformation, "Notice")
                End If

                If Me.Tag = "Nuevo" Then
                    If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                        clsConta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                    Else
                        clsConta.GenerarPoliza(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value.ToString(FORMATO_MYSQL))
                    End If
                End If
                MostrarLista(True)
            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub
    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click
        Dim PC As New clsPolizaContable
        PC.intTipo = 220
        PC.intCiclo = celdaAnio.Text
        PC.intNumero = celdaNumeroHDR.Text
        PC.intModo = 25
        PC.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 220,)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFactura_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgFactura.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If cFunciones.SQLVerificarCierre(220, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaPolizaC.Value) = 0 Then
                Borrar_con_Click()
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to delete this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaProveedor.Text, 220, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                    Borrar_con_Click()
                End If
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub
    Private Function Borrar_con_Click()
        Dim strSQL As String = STR_VACIO
        If ValidarRetencionIvaProveedor(celdaNumeroHDR.Text, celdaAnio.Text) = INT_CERO Then
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarEncabezadoIvaProveedor(celdaNumeroHDR.Text, celdaAnio.Text)
                BorrarDetalleIVAProveedor(celdaNumeroHDR.Text, celdaAnio.Text)
                BorrarEctateRetenIva(celdaNumeroHDR.Text, celdaAnio.Text)
                cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 220)
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 220, celdaAnio.Text, celdaNumeroHDR.Text)
                MsgBox("Eliminated Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You can not delete a document in the process", vbInformation, "Notice")
        End If
    End Function

    Public Sub MostrarSiEsProveedorRecibos(ByVal IdProveedor As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strFila As String = STR_VACIO
        Dim recibos As Integer = INT_CERO
        Dim REA As MySqlDataReader

        Try
            recibos = ProveedorCSRecibos(IdProveedor)

            celdaRecibos.Text = recibos

            If celdaRecibos.Text = "1" Then
                botonAgregar.Visible = True
                botonQuitar.Visible = True
                celdaMonto.ReadOnly = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function ProveedorCSRecibos(ByVal idProveedor As Integer) As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Recibos As Integer = 0
        Dim conec As MySqlConnection

        strSQL = " Select IF(p.pro_anticipos = '',0,p.pro_anticipos) recibos "
        strSQL &= "    From Proveedores p "
        strSQL &= "        WHERE p.pro_sisemp = {empresa} and p.pro_codigo = {idProveedor}"
        strSQL &= "           ORDER BY p.pro_proveedor ASC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{idProveedor}", idProveedor)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Recibos = COM.ExecuteScalar
        conec.Close()

        Return Recibos
    End Function

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim fecha As DateTime
        Dim año As Integer = INT_CERO
        Dim i As Integer = INT_CERO

        Try
            frm.Titulo = "Receipts"
            frm.Campos = " h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, concat_ws(' ',h.HDoc_DR1_Num,h.HDoc_DR2_Num) Serie,
                           h.HDoc_RF1_Dbl Monto, c.cat_clave Moneda, h.HDoc_Doc_TC TC, h.HDoc_Ant_Com FactEsp, h.HDoc_Doc_Cat catalogo "
            'frm.Tabla = " Dcmtos_HDR h 
            'LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num AND (r.HDoc_Ant_Com = 0) AND NOT r.HDoc_Doc_Status = 2
            'LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_RF3_Num= h.HDoc_Doc_Num AND d.DDoc_RF1_Num = h.HDoc_Doc_Cat AND d.DDoc_RF2_Num = h.HDoc_Doc_Ano 
            'LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
            frm.Tabla = " Dcmtos_HDR h
            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_RF3_Num= h.HDoc_Doc_Num AND d.DDoc_RF1_Num = h.HDoc_Doc_Cat AND d.DDoc_RF2_Num = h.HDoc_Doc_Ano 
            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
            frm.FiltroText = " Enter the receipt to filter "
            'frm.Filtro = " p.pro_proveedor "
            frm.Ordenamiento = " fecha "
            frm.TipoOrdenamiento = " DESC "
            'frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat IN (209) AND h.HDoc_Emp_Cod =" & celdaIdProveedor.Text & " AND h.HDoc_Doc_Fec > '2022-08-30' AND h.HDoc_Doc_Status = 1 AND r.HDoc_Sis_Emp IS NULL AND d.DDoc_RF3_Num IS NULL"
            frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat IN (209) AND h.HDoc_Emp_Cod =" & celdaIdProveedor.Text & " AND h.HDoc_Doc_Fec > '2022-08-30' AND h.HDoc_Doc_Status = 1 AND d.DDoc_RF3_Num IS NULL"
            frm.Limite = 15

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                For i = 0 To dgFactura.Rows.Count - 1
                    If dgFactura.Rows(i).Cells("colNumeroFac").Value = frm.Dato And dgFactura.Rows(i).Visible = True Then
                        If MsgBox("This document is already uploaded please upload a different one", vbOKOnly, "Notice") = vbOK Then
                            Exit Sub
                        End If
                    End If
                Next


                fecha = frm.LLave
                año = fecha.Year

                strFila = año & "|"
                strFila &= frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= frm.Dato2 & "|"
                strFila &= frm.Dato3 & "|"
                strFila &= frm.Dato4 & "|"
                strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(6).Value & "|"
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= 0

                cFunciones.AgregarFila(dgFactura, strFila)

            End If

            If celdaRecibos.Text = 1 Then
                dgFactura.Columns("colIva").Visible = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgFactura.SelectedRows.Count = INT_CERO Then Exit Sub
        dgFactura.CurrentRow.Cells("colExtraFact").Value = 2
        dgFactura.CurrentRow.Visible = False
        dgFactura.Focus()
    End Sub

    Private Sub CargarRecibos(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional intNumFac As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarRecibos(intAnio, intNum, intNumFac)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    strFila &= 0 & "|" 'indica que son recibos
                    strFila &= 0 & "|" 'extra
                    strFila &= REA.GetDouble("catalogo") & "|"
                    strFila &= REA.GetDouble("CalISR") & "|"
                    strFila &= REA.GetInt32("linea")


                    cFunciones.AgregarFila(dgFactura, strFila)
                    'celdaIDMoneda.Text = cFunciones.DivisaLocal
                    'celdaTipoCambio.Text = 1
                    celdaCatF.Text = 44
                    celdaAnioF.Text = REA.GetInt32("anio")
                    celdaNumF.Text = REA.GetInt32("numero")
                    celdaTCFactura.Text = REA.GetDouble("TC")
                    celdaMontoF.Text = REA.GetDouble("Monto")

                Loop
                'celdaTipoCambio.Text = 1

            End If


            If celdaRecibos.Text = 1 Then
                dgFactura.Columns("colIva").Visible = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLCargarRecibos(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional intNumFac As Integer = 0) ''se agregan recibos
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.DDoc_Doc_Ano anio,d.DDoc_RF1_Fec fecha, d.DDoc_Doc_Num numero, d.DDoc_RF1_Txt Usuario, d.DDoc_PRD_Cod NumFac,d.DDoc_PRD_Des Serie, d.DDoc_Prd_Qty Monto, "
        strSQL &= "  h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Doc_Mon idMoneda, d.DDoc_Doc_Cat catalogo, d.DDoc_Prd_Net CalISR, d.DDoc_Doc_Lin linea"
        strSQL &= "    FROM Dcmtos_HDR h "
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
        strSQL &= "        LEFT JOIN Dcmtos_Dtl d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "            WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 220 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        'strSQL = Replace(strSQL, "{cod}", codigo)

        Return strSQL
    End Function

    Private Sub dgFactura_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgFactura.CellEndEdit
        Dim dblMonto As Double = 0



        If dgFactura.Rows.Count = 1 Then
            dblMonto = Math.Round(CDbl(dgFactura.CurrentRow.Cells("colIva").Value), 2)
            celdaTotal.Text = celdaMonto.Text
        Else
            For i = 0 To dgFactura.Rows.Count - 1
                dblMonto = Math.Round(CDbl(dblMonto) + CDbl(dgFactura.Rows(i).Cells("colIva").Value), 2)
            Next
            celdaMonto.Text = dblMonto
            celdaTotal.Text = celdaMonto.Text
        End If

        dgFactura.CurrentRow.Cells("colExtraFact").Value = 1

    End Sub

    Private Sub BorrarDetalleIVAProveedor(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = 220 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarDetalle(ByVal intNumero As Integer, ByVal Año As Integer) As Boolean
        Dim cDTL As New clsDcmtos_DTL
        Dim logDetalle As Boolean = False
        Dim j As Integer = 0
        Try
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                cDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.DDOC_DOC_CAT = 220
                cDTL.DDOC_DOC_ANO = celdaAnio.Text
                cDTL.DDOC_DOC_NUM = celdaNumeroHDR.Text
                cDTL.DDOC_RF2_COD = celdaNumero.Text
                'cDTL.DDOC_PRD_COD = dgFactura.Rows(i).Cells("colNumeroFac").Value
                cDTL.DDOC_PRD_DES = dgFactura.Rows(i).Cells("colREferenciaFac").Value
                cDTL.DDOC_PRD_QTY = CDbl(dgFactura.Rows(i).Cells("colTotalFac").Value)
                cDTL.DDoc_RF1_Fec_NET = dgFactura.Rows(i).Cells("colFechaFac").Value
                cDTL.DDOC_RF1_TXT = dgFactura.Rows(i).Cells("colUsuarioFac").Value
                cDTL.DDOC_PRD_PNR = dgFactura.Rows(i).Cells("colMonedaFac").Value
                cDTL.DDOC_RF1_COD = dgFactura.Rows(i).Cells("colTCFac").Value
                cDTL.DDOC_PRD_NET = If(dgFactura.Rows(i).Cells("colIva").Value = 0, celdaMonto.Text, dgFactura.Rows(i).Cells("colIva").Value)
                cDTL.DDOC_RF1_NUM = 209
                cDTL.DDOC_RF2_NUM = dgFactura.Rows(i).Cells("colAnioFac").Value
                cDTL.DDOC_RF3_NUM = dgFactura.Rows(i).Cells("colNumeroFac").Value

                If Me.Tag = "Nuevo" Then
                    If dgFactura.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    cDTL.DDOC_DOC_LIN = j
                Else
                    cDTL.DDOC_DOC_LIN = dgFactura.Rows(i).Cells("colLinea2").Value
                End If

                If dgFactura.Rows(i).Cells("colExtraFact").Value = 0 And Me.Tag = "Mod" Then
                    If cDTL.Actualizar() = False Then
                        MsgBox(cDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgFactura.Rows(i).Cells("colExtraFact").Value = 1 And Me.Tag = "Nuevo" Then
                    If cDTL.Guardar() = False Then
                        MsgBox(cDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function

#End Region
End Class