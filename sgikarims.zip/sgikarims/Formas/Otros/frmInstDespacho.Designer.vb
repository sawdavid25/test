﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInstDespacho
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservaciones = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colControl = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRelacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCarga = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDireccion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTelefono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonPendientes = New System.Windows.Forms.Button()
        Me.botonBanderaAzul = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelInferior = New System.Windows.Forms.Panel()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.celdaColorRojo = New System.Windows.Forms.TextBox()
        Me.etiquetaNoCargado = New System.Windows.Forms.Label()
        Me.etiquetaModificado = New System.Windows.Forms.Label()
        Me.etiquetaNoFacturado = New System.Windows.Forms.Label()
        Me.etiquetaAnulado = New System.Windows.Forms.Label()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgBultosInicio = New System.Windows.Forms.DataGridView()
        Me.dgbultos1 = New System.Windows.Forms.DataGridView()
        Me.dgReferencias = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFech2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPoliza = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExist = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMed = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExiste = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantDescargada = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAlmacenado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonAgreDetalle = New System.Windows.Forms.Button()
        Me.botonQuitDetalle = New System.Windows.Forms.Button()
        Me.PanelGastos = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbFleteOtro = New System.Windows.Forms.RadioButton()
        Me.rbFleteCliente = New System.Windows.Forms.RadioButton()
        Me.rbFleteEmpresa = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.etiquetaComentarios = New System.Windows.Forms.Label()
        Me.celdaComentario = New System.Windows.Forms.TextBox()
        Me.rbGastosOtros = New System.Windows.Forms.RadioButton()
        Me.rbGastosCliente = New System.Windows.Forms.RadioButton()
        Me.rbGastosEmpresa = New System.Windows.Forms.RadioButton()
        Me.Panelbotom = New System.Windows.Forms.Panel()
        Me.celdaSubTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.gbPedidoClientes = New System.Windows.Forms.GroupBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.dgPedidos = New System.Windows.Forms.DataGridView()
        Me.colPF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperador = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPOCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.gbInformación = New System.Windows.Forms.GroupBox()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.checkTraslado = New System.Windows.Forms.CheckBox()
        Me.checkFibra = New System.Windows.Forms.CheckBox()
        Me.checkTarifa = New System.Windows.Forms.CheckBox()
        Me.celdaIdCosteo = New System.Windows.Forms.TextBox()
        Me.botonCosteo = New System.Windows.Forms.Button()
        Me.celdaCosteo = New System.Windows.Forms.TextBox()
        Me.etiquetaCosteo = New System.Windows.Forms.Label()
        Me.rbOpcionPagoNO = New System.Windows.Forms.RadioButton()
        Me.rbOpcionPagoSI = New System.Windows.Forms.RadioButton()
        Me.etiquetaImpuestos = New System.Windows.Forms.Label()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.etiquetaObservaciones = New System.Windows.Forms.Label()
        Me.celdaDetalle = New System.Windows.Forms.TextBox()
        Me.etiquetaDetalle = New System.Windows.Forms.Label()
        Me.gbInstDespacho = New System.Windows.Forms.GroupBox()
        Me.checkPago = New System.Windows.Forms.CheckBox()
        Me.checkConsignacion = New System.Windows.Forms.CheckBox()
        Me.CeldaCarga = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.botonClientes = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.celdaFecha = New System.Windows.Forms.TextBox()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonBuscar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.dgcatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgBulkNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumBulto2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.productoCod2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgMark = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgCategoria = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgPeso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgLineaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultoNo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NumBulto1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.productoCod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoria = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPeso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDet = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNPedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFech = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExistencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrden = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colADespachar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLibrasAdicionales = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPendiente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLugar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodDestino = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodOriginal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatosOriginales = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumParte = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOriginal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNPedidoDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPolizaDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea2Desc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidadDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisponibleDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldoActual = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota1Desc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNota2Desc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelInferior.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgBultosInicio, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgbultos1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgReferencias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.PanelGastos.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panelbotom.SuspendLayout()
        Me.PanelEncabezado.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.gbPedidoClientes.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.dgPedidos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.gbInformación.SuspendLayout()
        Me.gbInstDespacho.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFecha)
        Me.panelLista.Controls.Add(Me.panelInferior)
        Me.panelLista.Location = New System.Drawing.Point(0, 98)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1010, 147)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumber, Me.colDate, Me.colCode, Me.colCliente, Me.colReferencia, Me.colObservaciones, Me.colEstado, Me.colAño, Me.colControl, Me.colRelacion, Me.colCarga, Me.colDireccion, Me.colTelefono, Me.colNit, Me.colTasa})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 49)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1010, 58)
        Me.dgLista.TabIndex = 0
        '
        'colNumber
        '
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        '
        'colCode
        '
        Me.colCode.HeaderText = "Code"
        Me.colCode.Name = "colCode"
        Me.colCode.ReadOnly = True
        Me.colCode.Visible = False
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 58
        '
        'colReferencia
        '
        Me.colReferencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 82
        '
        'colObservaciones
        '
        Me.colObservaciones.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colObservaciones.HeaderText = "Observations"
        Me.colObservaciones.Name = "colObservaciones"
        Me.colObservaciones.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "State"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        '
        'colControl
        '
        Me.colControl.HeaderText = "Control"
        Me.colControl.Name = "colControl"
        Me.colControl.ReadOnly = True
        Me.colControl.Visible = False
        '
        'colRelacion
        '
        Me.colRelacion.HeaderText = "Relation"
        Me.colRelacion.Name = "colRelacion"
        Me.colRelacion.ReadOnly = True
        Me.colRelacion.Visible = False
        '
        'colCarga
        '
        Me.colCarga.HeaderText = "Charge"
        Me.colCarga.Name = "colCarga"
        Me.colCarga.ReadOnly = True
        Me.colCarga.Visible = False
        '
        'colDireccion
        '
        Me.colDireccion.HeaderText = "Direction"
        Me.colDireccion.Name = "colDireccion"
        Me.colDireccion.ReadOnly = True
        Me.colDireccion.Visible = False
        '
        'colTelefono
        '
        Me.colTelefono.HeaderText = "Phone"
        Me.colTelefono.Name = "colTelefono"
        Me.colTelefono.ReadOnly = True
        Me.colTelefono.Visible = False
        '
        'colNit
        '
        Me.colNit.HeaderText = "Nit"
        Me.colNit.Name = "colNit"
        Me.colNit.ReadOnly = True
        Me.colNit.Visible = False
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonPendientes)
        Me.panelFecha.Controls.Add(Me.botonBanderaAzul)
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(1010, 49)
        Me.panelFecha.TabIndex = 1
        '
        'botonPendientes
        '
        Me.botonPendientes.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPendientes.Image = Global.KARIMs_SGI.My.Resources.Resources.lock_new
        Me.botonPendientes.Location = New System.Drawing.Point(956, 11)
        Me.botonPendientes.Name = "botonPendientes"
        Me.botonPendientes.Size = New System.Drawing.Size(27, 28)
        Me.botonPendientes.TabIndex = 7
        Me.botonPendientes.UseVisualStyleBackColor = True
        '
        'botonBanderaAzul
        '
        Me.botonBanderaAzul.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonBanderaAzul.Image = Global.KARIMs_SGI.My.Resources.Resources.flag_blue
        Me.botonBanderaAzul.Location = New System.Drawing.Point(924, 11)
        Me.botonBanderaAzul.Name = "botonBanderaAzul"
        Me.botonBanderaAzul.Size = New System.Drawing.Size(26, 28)
        Me.botonBanderaAzul.TabIndex = 6
        Me.botonBanderaAzul.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(432, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(328, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(182, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelInferior
        '
        Me.panelInferior.Controls.Add(Me.TextBox3)
        Me.panelInferior.Controls.Add(Me.TextBox2)
        Me.panelInferior.Controls.Add(Me.TextBox1)
        Me.panelInferior.Controls.Add(Me.celdaColorRojo)
        Me.panelInferior.Controls.Add(Me.etiquetaNoCargado)
        Me.panelInferior.Controls.Add(Me.etiquetaModificado)
        Me.panelInferior.Controls.Add(Me.etiquetaNoFacturado)
        Me.panelInferior.Controls.Add(Me.etiquetaAnulado)
        Me.panelInferior.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInferior.Location = New System.Drawing.Point(0, 107)
        Me.panelInferior.Name = "panelInferior"
        Me.panelInferior.Size = New System.Drawing.Size(1010, 40)
        Me.panelInferior.TabIndex = 2
        '
        'TextBox3
        '
        Me.TextBox3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox3.BackColor = System.Drawing.Color.Aqua
        Me.TextBox3.Location = New System.Drawing.Point(631, 11)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(19, 20)
        Me.TextBox3.TabIndex = 32
        '
        'TextBox2
        '
        Me.TextBox2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox2.BackColor = System.Drawing.Color.Yellow
        Me.TextBox2.Location = New System.Drawing.Point(536, 12)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(19, 20)
        Me.TextBox2.TabIndex = 31
        '
        'TextBox1
        '
        Me.TextBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox1.Location = New System.Drawing.Point(411, 15)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(19, 20)
        Me.TextBox1.TabIndex = 30
        '
        'celdaColorRojo
        '
        Me.celdaColorRojo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaColorRojo.BackColor = System.Drawing.Color.Red
        Me.celdaColorRojo.Location = New System.Drawing.Point(319, 13)
        Me.celdaColorRojo.Name = "celdaColorRojo"
        Me.celdaColorRojo.ReadOnly = True
        Me.celdaColorRojo.Size = New System.Drawing.Size(19, 20)
        Me.celdaColorRojo.TabIndex = 29
        '
        'etiquetaNoCargado
        '
        Me.etiquetaNoCargado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaNoCargado.AutoSize = True
        Me.etiquetaNoCargado.Location = New System.Drawing.Point(648, 13)
        Me.etiquetaNoCargado.Name = "etiquetaNoCargado"
        Me.etiquetaNoCargado.Size = New System.Drawing.Size(109, 13)
        Me.etiquetaNoCargado.TabIndex = 7
        Me.etiquetaNoCargado.Text = "PENDING  TO LOAD"
        '
        'etiquetaModificado
        '
        Me.etiquetaModificado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaModificado.AutoSize = True
        Me.etiquetaModificado.Location = New System.Drawing.Point(558, 14)
        Me.etiquetaModificado.Name = "etiquetaModificado"
        Me.etiquetaModificado.Size = New System.Drawing.Size(59, 13)
        Me.etiquetaModificado.TabIndex = 6
        Me.etiquetaModificado.Text = "MODIFIED"
        '
        'etiquetaNoFacturado
        '
        Me.etiquetaNoFacturado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaNoFacturado.AutoSize = True
        Me.etiquetaNoFacturado.Location = New System.Drawing.Point(428, 15)
        Me.etiquetaNoFacturado.Name = "etiquetaNoFacturado"
        Me.etiquetaNoFacturado.Size = New System.Drawing.Size(99, 13)
        Me.etiquetaNoFacturado.TabIndex = 5
        Me.etiquetaNoFacturado.Text = "PENDING TO BILL"
        '
        'etiquetaAnulado
        '
        Me.etiquetaAnulado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaAnulado.AutoSize = True
        Me.etiquetaAnulado.Location = New System.Drawing.Point(336, 15)
        Me.etiquetaAnulado.Name = "etiquetaAnulado"
        Me.etiquetaAnulado.Size = New System.Drawing.Size(71, 13)
        Me.etiquetaAnulado.TabIndex = 4
        Me.etiquetaAnulado.Text = "-ANNULLED-"
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel4)
        Me.panelDocumento.Controls.Add(Me.PanelGastos)
        Me.panelDocumento.Controls.Add(Me.Panelbotom)
        Me.panelDocumento.Controls.Add(Me.PanelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(0, 188)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(1013, 586)
        Me.panelDocumento.TabIndex = 3
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.panelDetalle)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 340)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1013, 192)
        Me.Panel4.TabIndex = 31
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgBultosInicio)
        Me.panelDetalle.Controls.Add(Me.dgbultos1)
        Me.panelDetalle.Controls.Add(Me.dgReferencias)
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.Panel2)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 0)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1013, 192)
        Me.panelDetalle.TabIndex = 7
        '
        'dgBultosInicio
        '
        Me.dgBultosInicio.AllowUserToAddRows = False
        Me.dgBultosInicio.AllowUserToDeleteRows = False
        Me.dgBultosInicio.AllowUserToOrderColumns = True
        Me.dgBultosInicio.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgBultosInicio.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgBultosInicio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgBultosInicio.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dgcatalogo, Me.dgAnio, Me.dgNumber, Me.dgLinea, Me.dgBulkNumber, Me.NumBulto2, Me.productoCod2, Me.dgMark, Me.dgCategoria, Me.dgPeso, Me.dgLineaDet, Me.dgExtra})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgBultosInicio.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgBultosInicio.Location = New System.Drawing.Point(85, 89)
        Me.dgBultosInicio.Margin = New System.Windows.Forms.Padding(2)
        Me.dgBultosInicio.MultiSelect = False
        Me.dgBultosInicio.Name = "dgBultosInicio"
        Me.dgBultosInicio.ReadOnly = True
        Me.dgBultosInicio.RowTemplate.Height = 24
        Me.dgBultosInicio.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgBultosInicio.Size = New System.Drawing.Size(796, 170)
        Me.dgBultosInicio.TabIndex = 10
        Me.dgBultosInicio.Visible = False
        '
        'dgbultos1
        '
        Me.dgbultos1.AllowUserToAddRows = False
        Me.dgbultos1.AllowUserToDeleteRows = False
        Me.dgbultos1.AllowUserToOrderColumns = True
        Me.dgbultos1.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgbultos1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgbultos1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgbultos1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo1, Me.colAnio1, Me.colNumero1, Me.colLinea1, Me.colBultoNo, Me.NumBulto1, Me.productoCod, Me.colMarca, Me.colCategoria, Me.colPeso, Me.colLineaDet, Me.colExtra1})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgbultos1.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgbultos1.Location = New System.Drawing.Point(28, 59)
        Me.dgbultos1.Margin = New System.Windows.Forms.Padding(2)
        Me.dgbultos1.MultiSelect = False
        Me.dgbultos1.Name = "dgbultos1"
        Me.dgbultos1.ReadOnly = True
        Me.dgbultos1.RowTemplate.Height = 24
        Me.dgbultos1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgbultos1.Size = New System.Drawing.Size(796, 170)
        Me.dgbultos1.TabIndex = 9
        Me.dgbultos1.Visible = False
        '
        'dgReferencias
        '
        Me.dgReferencias.AllowUserToAddRows = False
        Me.dgReferencias.AllowUserToDeleteRows = False
        Me.dgReferencias.AllowUserToOrderColumns = True
        Me.dgReferencias.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgReferencias.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgReferencias.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgReferencias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgReferencias.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colNumero, Me.colLine, Me.colAnio, Me.colNum, Me.colFech2, Me.colRef, Me.colPoliza, Me.colLinea2, Me.colCod, Me.colExist, Me.colMed, Me.colUnidad, Me.colDescargo, Me.colExiste, Me.colSaldo, Me.colCantDescargada, Me.colAlmacenado, Me.colNota1, Me.colNota2, Me.colPrice})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgReferencias.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgReferencias.Location = New System.Drawing.Point(413, 129)
        Me.dgReferencias.MultiSelect = False
        Me.dgReferencias.Name = "dgReferencias"
        Me.dgReferencias.ReadOnly = True
        Me.dgReferencias.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgReferencias.Size = New System.Drawing.Size(517, 114)
        Me.dgReferencias.TabIndex = 9
        Me.dgReferencias.Visible = False
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "N/Pedido"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colLine
        '
        Me.colLine.HeaderText = "Line"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colNum
        '
        Me.colNum.HeaderText = "Number"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        '
        'colFech2
        '
        Me.colFech2.HeaderText = "Date"
        Me.colFech2.Name = "colFech2"
        Me.colFech2.ReadOnly = True
        '
        'colRef
        '
        Me.colRef.HeaderText = "Reference"
        Me.colRef.Name = "colRef"
        Me.colRef.ReadOnly = True
        '
        'colPoliza
        '
        Me.colPoliza.HeaderText = "Policy"
        Me.colPoliza.Name = "colPoliza"
        Me.colPoliza.ReadOnly = True
        '
        'colLinea2
        '
        Me.colLinea2.HeaderText = "Line"
        Me.colLinea2.Name = "colLinea2"
        Me.colLinea2.ReadOnly = True
        '
        'colCod
        '
        Me.colCod.HeaderText = "Code"
        Me.colCod.Name = "colCod"
        Me.colCod.ReadOnly = True
        '
        'colExist
        '
        Me.colExist.HeaderText = "Existence"
        Me.colExist.Name = "colExist"
        Me.colExist.ReadOnly = True
        '
        'colMed
        '
        Me.colMed.HeaderText = "Measure"
        Me.colMed.Name = "colMed"
        Me.colMed.ReadOnly = True
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unity"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        '
        'colDescargo
        '
        Me.colDescargo.HeaderText = "Discharge"
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.ReadOnly = True
        '
        'colExiste
        '
        Me.colExiste.HeaderText = "Existe"
        Me.colExiste.Name = "colExiste"
        Me.colExiste.ReadOnly = True
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "SaldoActual"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        '
        'colCantDescargada
        '
        Me.colCantDescargada.HeaderText = "Cant.Descargada"
        Me.colCantDescargada.Name = "colCantDescargada"
        Me.colCantDescargada.ReadOnly = True
        '
        'colAlmacenado
        '
        Me.colAlmacenado.HeaderText = "Almacenado 1/0"
        Me.colAlmacenado.Name = "colAlmacenado"
        Me.colAlmacenado.ReadOnly = True
        '
        'colNota1
        '
        Me.colNota1.HeaderText = "Note/Referencia"
        Me.colNota1.Name = "colNota1"
        Me.colNota1.ReadOnly = True
        '
        'colNota2
        '
        Me.colNota2.HeaderText = "Note/Linea"
        Me.colNota2.Name = "colNota2"
        Me.colNota2.ReadOnly = True
        '
        'colPrice
        '
        Me.colPrice.HeaderText = "Precio"
        Me.colPrice.Name = "colPrice"
        Me.colPrice.ReadOnly = True
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAno, Me.colCatalogo, Me.colNPedido, Me.colLinea, Me.colFech, Me.colCodigo, Me.colArticulo, Me.colMedida, Me.colPrecio, Me.colExistencia, Me.colOrden, Me.colADespachar, Me.colLibrasAdicionales, Me.colBulto, Me.colPendiente, Me.colReference, Me.colLugar, Me.colCodDestino, Me.colCodOriginal, Me.colDatosOriginales, Me.colNumParte, Me.colIDD, Me.colUnit, Me.colBase, Me.colCantidad, Me.colPedido, Me.colOriginal, Me.colXtra, Me.colObservation, Me.colIDDesc, Me.colAnioDesc, Me.colCatDesc, Me.colNumDesc, Me.colLineaDesc, Me.colCantDescargo, Me.colCodDesc, Me.colNPedidoDesc, Me.colFecha2, Me.colPolizaDesc, Me.colRefDesc, Me.colLinea2Desc, Me.colMedDesc, Me.colUnidadDesc, Me.colDisponibleDesc, Me.colSaldoActual, Me.colNota1Desc, Me.colNota2Desc})
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle10
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(973, 192)
        Me.dgDetalle.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonAgreDetalle)
        Me.Panel2.Controls.Add(Me.botonQuitDetalle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(973, 0)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(40, 192)
        Me.Panel2.TabIndex = 0
        '
        'botonAgreDetalle
        '
        Me.botonAgreDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgreDetalle.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgreDetalle.Enabled = False
        Me.botonAgreDetalle.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgreDetalle.Location = New System.Drawing.Point(5, 68)
        Me.botonAgreDetalle.Name = "botonAgreDetalle"
        Me.botonAgreDetalle.Size = New System.Drawing.Size(31, 28)
        Me.botonAgreDetalle.TabIndex = 8
        Me.botonAgreDetalle.UseVisualStyleBackColor = False
        '
        'botonQuitDetalle
        '
        Me.botonQuitDetalle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitDetalle.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitDetalle.Location = New System.Drawing.Point(5, 111)
        Me.botonQuitDetalle.Name = "botonQuitDetalle"
        Me.botonQuitDetalle.Size = New System.Drawing.Size(31, 29)
        Me.botonQuitDetalle.TabIndex = 9
        Me.botonQuitDetalle.UseVisualStyleBackColor = True
        '
        'PanelGastos
        '
        Me.PanelGastos.Controls.Add(Me.GroupBox2)
        Me.PanelGastos.Controls.Add(Me.GroupBox1)
        Me.PanelGastos.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelGastos.Location = New System.Drawing.Point(0, 273)
        Me.PanelGastos.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelGastos.Name = "PanelGastos"
        Me.PanelGastos.Size = New System.Drawing.Size(1013, 67)
        Me.PanelGastos.TabIndex = 30
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbFleteOtro)
        Me.GroupBox2.Controls.Add(Me.rbFleteCliente)
        Me.GroupBox2.Controls.Add(Me.rbFleteEmpresa)
        Me.GroupBox2.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(407, 65)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Freight Charges"
        '
        'rbFleteOtro
        '
        Me.rbFleteOtro.AutoSize = True
        Me.rbFleteOtro.Location = New System.Drawing.Point(281, 33)
        Me.rbFleteOtro.Margin = New System.Windows.Forms.Padding(2)
        Me.rbFleteOtro.Name = "rbFleteOtro"
        Me.rbFleteOtro.Size = New System.Drawing.Size(90, 17)
        Me.rbFleteOtro.TabIndex = 8
        Me.rbFleteOtro.Text = "RadioButton3"
        Me.rbFleteOtro.UseVisualStyleBackColor = True
        '
        'rbFleteCliente
        '
        Me.rbFleteCliente.AutoSize = True
        Me.rbFleteCliente.Checked = True
        Me.rbFleteCliente.Location = New System.Drawing.Point(147, 33)
        Me.rbFleteCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.rbFleteCliente.Name = "rbFleteCliente"
        Me.rbFleteCliente.Size = New System.Drawing.Size(90, 17)
        Me.rbFleteCliente.TabIndex = 7
        Me.rbFleteCliente.TabStop = True
        Me.rbFleteCliente.Text = "RadioButton2"
        Me.rbFleteCliente.UseVisualStyleBackColor = True
        '
        'rbFleteEmpresa
        '
        Me.rbFleteEmpresa.AutoSize = True
        Me.rbFleteEmpresa.Location = New System.Drawing.Point(17, 33)
        Me.rbFleteEmpresa.Margin = New System.Windows.Forms.Padding(2)
        Me.rbFleteEmpresa.Name = "rbFleteEmpresa"
        Me.rbFleteEmpresa.Size = New System.Drawing.Size(90, 17)
        Me.rbFleteEmpresa.TabIndex = 6
        Me.rbFleteEmpresa.Text = "RadioButton1"
        Me.rbFleteEmpresa.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.etiquetaComentarios)
        Me.GroupBox1.Controls.Add(Me.celdaComentario)
        Me.GroupBox1.Controls.Add(Me.rbGastosOtros)
        Me.GroupBox1.Controls.Add(Me.rbGastosCliente)
        Me.GroupBox1.Controls.Add(Me.rbGastosEmpresa)
        Me.GroupBox1.Location = New System.Drawing.Point(410, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(603, 63)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customs Expenses."
        '
        'etiquetaComentarios
        '
        Me.etiquetaComentarios.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaComentarios.AutoSize = True
        Me.etiquetaComentarios.Location = New System.Drawing.Point(407, 15)
        Me.etiquetaComentarios.Name = "etiquetaComentarios"
        Me.etiquetaComentarios.Size = New System.Drawing.Size(56, 13)
        Me.etiquetaComentarios.TabIndex = 25
        Me.etiquetaComentarios.Text = "Comments"
        '
        'celdaComentario
        '
        Me.celdaComentario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaComentario.Location = New System.Drawing.Point(410, 31)
        Me.celdaComentario.Multiline = True
        Me.celdaComentario.Name = "celdaComentario"
        Me.celdaComentario.Size = New System.Drawing.Size(147, 28)
        Me.celdaComentario.TabIndex = 24
        '
        'rbGastosOtros
        '
        Me.rbGastosOtros.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbGastosOtros.AutoSize = True
        Me.rbGastosOtros.Location = New System.Drawing.Point(285, 31)
        Me.rbGastosOtros.Margin = New System.Windows.Forms.Padding(2)
        Me.rbGastosOtros.Name = "rbGastosOtros"
        Me.rbGastosOtros.Size = New System.Drawing.Size(90, 17)
        Me.rbGastosOtros.TabIndex = 8
        Me.rbGastosOtros.Text = "RadioButton4"
        Me.rbGastosOtros.UseVisualStyleBackColor = True
        '
        'rbGastosCliente
        '
        Me.rbGastosCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbGastosCliente.AutoSize = True
        Me.rbGastosCliente.Checked = True
        Me.rbGastosCliente.Location = New System.Drawing.Point(151, 31)
        Me.rbGastosCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.rbGastosCliente.Name = "rbGastosCliente"
        Me.rbGastosCliente.Size = New System.Drawing.Size(90, 17)
        Me.rbGastosCliente.TabIndex = 7
        Me.rbGastosCliente.TabStop = True
        Me.rbGastosCliente.Text = "RadioButton5"
        Me.rbGastosCliente.UseVisualStyleBackColor = True
        '
        'rbGastosEmpresa
        '
        Me.rbGastosEmpresa.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbGastosEmpresa.AutoSize = True
        Me.rbGastosEmpresa.Location = New System.Drawing.Point(21, 31)
        Me.rbGastosEmpresa.Margin = New System.Windows.Forms.Padding(2)
        Me.rbGastosEmpresa.Name = "rbGastosEmpresa"
        Me.rbGastosEmpresa.Size = New System.Drawing.Size(90, 17)
        Me.rbGastosEmpresa.TabIndex = 6
        Me.rbGastosEmpresa.Text = "RadioButton6"
        Me.rbGastosEmpresa.UseVisualStyleBackColor = True
        '
        'Panelbotom
        '
        Me.Panelbotom.Controls.Add(Me.celdaSubTotal)
        Me.Panelbotom.Controls.Add(Me.etiquetaTotal)
        Me.Panelbotom.Controls.Add(Me.celdaTotal)
        Me.Panelbotom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panelbotom.Location = New System.Drawing.Point(0, 532)
        Me.Panelbotom.Margin = New System.Windows.Forms.Padding(2)
        Me.Panelbotom.Name = "Panelbotom"
        Me.Panelbotom.Size = New System.Drawing.Size(1013, 54)
        Me.Panelbotom.TabIndex = 11
        '
        'celdaSubTotal
        '
        Me.celdaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSubTotal.Location = New System.Drawing.Point(770, 20)
        Me.celdaSubTotal.Name = "celdaSubTotal"
        Me.celdaSubTotal.Size = New System.Drawing.Size(100, 20)
        Me.celdaSubTotal.TabIndex = 5
        Me.celdaSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(706, 24)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaTotal.TabIndex = 4
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(886, 19)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(97, 20)
        Me.celdaTotal.TabIndex = 6
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.Panel1)
        Me.PanelEncabezado.Controls.Add(Me.gbInstDespacho)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(1013, 273)
        Me.PanelEncabezado.TabIndex = 10
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.gbPedidoClientes)
        Me.Panel1.Controls.Add(Me.gbInformación)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(410, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(603, 273)
        Me.Panel1.TabIndex = 1
        '
        'gbPedidoClientes
        '
        Me.gbPedidoClientes.Controls.Add(Me.Panel5)
        Me.gbPedidoClientes.Controls.Add(Me.Panel3)
        Me.gbPedidoClientes.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbPedidoClientes.Location = New System.Drawing.Point(0, 0)
        Me.gbPedidoClientes.Name = "gbPedidoClientes"
        Me.gbPedidoClientes.Size = New System.Drawing.Size(603, 114)
        Me.gbPedidoClientes.TabIndex = 1
        Me.gbPedidoClientes.TabStop = False
        Me.gbPedidoClientes.Text = "Customer orders ( ordered by document)"
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.dgPedidos)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(3, 16)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(560, 95)
        Me.Panel5.TabIndex = 1
        '
        'dgPedidos
        '
        Me.dgPedidos.AllowUserToAddRows = False
        Me.dgPedidos.AllowUserToDeleteRows = False
        Me.dgPedidos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPedidos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPedidos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.dgPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPedidos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colPF, Me.colFecha, Me.colOperador, Me.colPOCliente, Me.colYear, Me.colImpuesto, Me.colExtra})
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgPedidos.DefaultCellStyle = DataGridViewCellStyle12
        Me.dgPedidos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgPedidos.Location = New System.Drawing.Point(0, 0)
        Me.dgPedidos.Name = "dgPedidos"
        Me.dgPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPedidos.Size = New System.Drawing.Size(560, 95)
        Me.dgPedidos.TabIndex = 0
        '
        'colPF
        '
        Me.colPF.HeaderText = "PF"
        Me.colPF.Name = "colPF"
        Me.colPF.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colOperador
        '
        Me.colOperador.HeaderText = "Operator"
        Me.colOperador.Name = "colOperador"
        Me.colOperador.ReadOnly = True
        '
        'colPOCliente
        '
        Me.colPOCliente.HeaderText = "Client P.O"
        Me.colPOCliente.Name = "colPOCliente"
        Me.colPOCliente.ReadOnly = True
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        Me.colYear.Visible = False
        '
        'colImpuesto
        '
        Me.colImpuesto.HeaderText = "Tax"
        Me.colImpuesto.Name = "colImpuesto"
        Me.colImpuesto.ReadOnly = True
        Me.colImpuesto.Visible = False
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.botonEliminar)
        Me.Panel3.Controls.Add(Me.botonMas)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(563, 16)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(37, 95)
        Me.Panel3.TabIndex = 0
        '
        'botonEliminar
        '
        Me.botonEliminar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(3, 32)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(31, 19)
        Me.botonEliminar.TabIndex = 2
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonMas.BackColor = System.Drawing.SystemColors.Control
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonMas.Location = New System.Drawing.Point(3, 7)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(31, 22)
        Me.botonMas.TabIndex = 1
        Me.botonMas.UseVisualStyleBackColor = False
        '
        'gbInformación
        '
        Me.gbInformación.Controls.Add(Me.botonPolizaC)
        Me.gbInformación.Controls.Add(Me.checkTraslado)
        Me.gbInformación.Controls.Add(Me.checkFibra)
        Me.gbInformación.Controls.Add(Me.checkTarifa)
        Me.gbInformación.Controls.Add(Me.celdaIdCosteo)
        Me.gbInformación.Controls.Add(Me.botonCosteo)
        Me.gbInformación.Controls.Add(Me.celdaCosteo)
        Me.gbInformación.Controls.Add(Me.etiquetaCosteo)
        Me.gbInformación.Controls.Add(Me.rbOpcionPagoNO)
        Me.gbInformación.Controls.Add(Me.rbOpcionPagoSI)
        Me.gbInformación.Controls.Add(Me.etiquetaImpuestos)
        Me.gbInformación.Controls.Add(Me.celdaObservaciones)
        Me.gbInformación.Controls.Add(Me.etiquetaObservaciones)
        Me.gbInformación.Controls.Add(Me.celdaDetalle)
        Me.gbInformación.Controls.Add(Me.etiquetaDetalle)
        Me.gbInformación.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.gbInformación.Location = New System.Drawing.Point(0, 114)
        Me.gbInformación.Name = "gbInformación"
        Me.gbInformación.Size = New System.Drawing.Size(603, 159)
        Me.gbInformación.TabIndex = 2
        Me.gbInformación.TabStop = False
        Me.gbInformación.Text = "Additional Information"
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(546, 72)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(29, 23)
        Me.botonPolizaC.TabIndex = 34
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'checkTraslado
        '
        Me.checkTraslado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkTraslado.AutoSize = True
        Me.checkTraslado.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.checkTraslado.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkTraslado.ForeColor = System.Drawing.Color.DarkGreen
        Me.checkTraslado.Location = New System.Drawing.Point(428, 110)
        Me.checkTraslado.Name = "checkTraslado"
        Me.checkTraslado.Size = New System.Drawing.Size(125, 17)
        Me.checkTraslado.TabIndex = 33
        Me.checkTraslado.Text = "Transfer of laying"
        Me.checkTraslado.UseVisualStyleBackColor = False
        '
        'checkFibra
        '
        Me.checkFibra.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkFibra.AutoSize = True
        Me.checkFibra.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.checkFibra.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkFibra.ForeColor = System.Drawing.Color.DarkGreen
        Me.checkFibra.Location = New System.Drawing.Point(429, 133)
        Me.checkFibra.Name = "checkFibra"
        Me.checkFibra.Size = New System.Drawing.Size(75, 17)
        Me.checkFibra.TabIndex = 32
        Me.checkFibra.Text = "Fiber Bill"
        Me.checkFibra.UseVisualStyleBackColor = False
        '
        'checkTarifa
        '
        Me.checkTarifa.AutoSize = True
        Me.checkTarifa.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.checkTarifa.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkTarifa.Location = New System.Drawing.Point(16, 131)
        Me.checkTarifa.Margin = New System.Windows.Forms.Padding(2)
        Me.checkTarifa.Name = "checkTarifa"
        Me.checkTarifa.Size = New System.Drawing.Size(92, 17)
        Me.checkTarifa.TabIndex = 32
        Me.checkTarifa.Text = "Sample Fee"
        Me.checkTarifa.UseVisualStyleBackColor = False
        '
        'celdaIdCosteo
        '
        Me.celdaIdCosteo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdCosteo.Location = New System.Drawing.Point(419, 56)
        Me.celdaIdCosteo.Name = "celdaIdCosteo"
        Me.celdaIdCosteo.Size = New System.Drawing.Size(30, 20)
        Me.celdaIdCosteo.TabIndex = 31
        Me.celdaIdCosteo.Visible = False
        '
        'botonCosteo
        '
        Me.botonCosteo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCosteo.Location = New System.Drawing.Point(510, 75)
        Me.botonCosteo.Name = "botonCosteo"
        Me.botonCosteo.Size = New System.Drawing.Size(26, 20)
        Me.botonCosteo.TabIndex = 30
        Me.botonCosteo.Text = "..."
        Me.botonCosteo.UseVisualStyleBackColor = True
        '
        'celdaCosteo
        '
        Me.celdaCosteo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCosteo.Location = New System.Drawing.Point(374, 76)
        Me.celdaCosteo.Name = "celdaCosteo"
        Me.celdaCosteo.ReadOnly = True
        Me.celdaCosteo.Size = New System.Drawing.Size(131, 20)
        Me.celdaCosteo.TabIndex = 26
        '
        'etiquetaCosteo
        '
        Me.etiquetaCosteo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaCosteo.AutoSize = True
        Me.etiquetaCosteo.Location = New System.Drawing.Point(372, 58)
        Me.etiquetaCosteo.Name = "etiquetaCosteo"
        Me.etiquetaCosteo.Size = New System.Drawing.Size(42, 13)
        Me.etiquetaCosteo.TabIndex = 7
        Me.etiquetaCosteo.Text = "Costing"
        '
        'rbOpcionPagoNO
        '
        Me.rbOpcionPagoNO.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbOpcionPagoNO.AutoSize = True
        Me.rbOpcionPagoNO.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbOpcionPagoNO.Location = New System.Drawing.Point(235, 131)
        Me.rbOpcionPagoNO.Margin = New System.Windows.Forms.Padding(2)
        Me.rbOpcionPagoNO.Name = "rbOpcionPagoNO"
        Me.rbOpcionPagoNO.Size = New System.Drawing.Size(41, 17)
        Me.rbOpcionPagoNO.TabIndex = 6
        Me.rbOpcionPagoNO.TabStop = True
        Me.rbOpcionPagoNO.Text = "No"
        Me.rbOpcionPagoNO.UseVisualStyleBackColor = True
        '
        'rbOpcionPagoSI
        '
        Me.rbOpcionPagoSI.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbOpcionPagoSI.AutoSize = True
        Me.rbOpcionPagoSI.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red
        Me.rbOpcionPagoSI.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbOpcionPagoSI.ForeColor = System.Drawing.Color.Black
        Me.rbOpcionPagoSI.Location = New System.Drawing.Point(307, 131)
        Me.rbOpcionPagoSI.Margin = New System.Windows.Forms.Padding(2)
        Me.rbOpcionPagoSI.Name = "rbOpcionPagoSI"
        Me.rbOpcionPagoSI.Size = New System.Drawing.Size(46, 17)
        Me.rbOpcionPagoSI.TabIndex = 5
        Me.rbOpcionPagoSI.TabStop = True
        Me.rbOpcionPagoSI.Text = "Yes"
        Me.rbOpcionPagoSI.UseVisualStyleBackColor = False
        '
        'etiquetaImpuestos
        '
        Me.etiquetaImpuestos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaImpuestos.AutoSize = True
        Me.etiquetaImpuestos.Location = New System.Drawing.Point(155, 134)
        Me.etiquetaImpuestos.Name = "etiquetaImpuestos"
        Me.etiquetaImpuestos.Size = New System.Drawing.Size(69, 13)
        Me.etiquetaImpuestos.TabIndex = 4
        Me.etiquetaImpuestos.Text = "Tax Payment"
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaObservaciones.BackColor = System.Drawing.SystemColors.Info
        Me.celdaObservaciones.Location = New System.Drawing.Point(6, 76)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(348, 49)
        Me.celdaObservaciones.TabIndex = 3
        '
        'etiquetaObservaciones
        '
        Me.etiquetaObservaciones.AutoSize = True
        Me.etiquetaObservaciones.Location = New System.Drawing.Point(14, 58)
        Me.etiquetaObservaciones.Name = "etiquetaObservaciones"
        Me.etiquetaObservaciones.Size = New System.Drawing.Size(69, 13)
        Me.etiquetaObservaciones.TabIndex = 2
        Me.etiquetaObservaciones.Text = "Observations"
        '
        'celdaDetalle
        '
        Me.celdaDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDetalle.Location = New System.Drawing.Point(6, 37)
        Me.celdaDetalle.Name = "celdaDetalle"
        Me.celdaDetalle.Size = New System.Drawing.Size(556, 20)
        Me.celdaDetalle.TabIndex = 1
        '
        'etiquetaDetalle
        '
        Me.etiquetaDetalle.AutoSize = True
        Me.etiquetaDetalle.Location = New System.Drawing.Point(14, 20)
        Me.etiquetaDetalle.Name = "etiquetaDetalle"
        Me.etiquetaDetalle.Size = New System.Drawing.Size(34, 13)
        Me.etiquetaDetalle.TabIndex = 0
        Me.etiquetaDetalle.Text = "Detail"
        '
        'gbInstDespacho
        '
        Me.gbInstDespacho.Controls.Add(Me.checkPago)
        Me.gbInstDespacho.Controls.Add(Me.checkConsignacion)
        Me.gbInstDespacho.Controls.Add(Me.CeldaCarga)
        Me.gbInstDespacho.Controls.Add(Me.celdaUsuario)
        Me.gbInstDespacho.Controls.Add(Me.celdaCatalogo)
        Me.gbInstDespacho.Controls.Add(Me.celdaEmpresa)
        Me.gbInstDespacho.Controls.Add(Me.celdaIDMoneda)
        Me.gbInstDespacho.Controls.Add(Me.celdaIDCliente)
        Me.gbInstDespacho.Controls.Add(Me.celdaTasa)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaTasa)
        Me.gbInstDespacho.Controls.Add(Me.botonMoneda)
        Me.gbInstDespacho.Controls.Add(Me.celdaMoneda)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaMoneda)
        Me.gbInstDespacho.Controls.Add(Me.celdaNIT)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaNIT)
        Me.gbInstDespacho.Controls.Add(Me.celdaTelefono)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaTelefono)
        Me.gbInstDespacho.Controls.Add(Me.celdaDireccion)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaDireccion)
        Me.gbInstDespacho.Controls.Add(Me.botonClientes)
        Me.gbInstDespacho.Controls.Add(Me.celdaCliente)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaCliente)
        Me.gbInstDespacho.Controls.Add(Me.celdaFecha)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaFecha)
        Me.gbInstDespacho.Controls.Add(Me.checkActivar)
        Me.gbInstDespacho.Controls.Add(Me.celdaNumero)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaNumero)
        Me.gbInstDespacho.Controls.Add(Me.celdaAño)
        Me.gbInstDespacho.Controls.Add(Me.etiquetaAño)
        Me.gbInstDespacho.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbInstDespacho.Location = New System.Drawing.Point(0, 0)
        Me.gbInstDespacho.Name = "gbInstDespacho"
        Me.gbInstDespacho.Size = New System.Drawing.Size(410, 273)
        Me.gbInstDespacho.TabIndex = 0
        Me.gbInstDespacho.TabStop = False
        Me.gbInstDespacho.Text = "Instructions office"
        '
        'checkPago
        '
        Me.checkPago.AutoSize = True
        Me.checkPago.BackColor = System.Drawing.Color.Transparent
        Me.checkPago.Location = New System.Drawing.Point(207, 84)
        Me.checkPago.Name = "checkPago"
        Me.checkPago.Size = New System.Drawing.Size(47, 17)
        Me.checkPago.TabIndex = 31
        Me.checkPago.Text = "Paid"
        Me.checkPago.UseVisualStyleBackColor = False
        Me.checkPago.Visible = False
        '
        'checkConsignacion
        '
        Me.checkConsignacion.AutoSize = True
        Me.checkConsignacion.BackColor = System.Drawing.Color.Transparent
        Me.checkConsignacion.Location = New System.Drawing.Point(207, 61)
        Me.checkConsignacion.Name = "checkConsignacion"
        Me.checkConsignacion.Size = New System.Drawing.Size(87, 17)
        Me.checkConsignacion.TabIndex = 30
        Me.checkConsignacion.Text = "Consignment"
        Me.checkConsignacion.UseVisualStyleBackColor = False
        '
        'CeldaCarga
        '
        Me.CeldaCarga.Location = New System.Drawing.Point(381, 153)
        Me.CeldaCarga.Name = "CeldaCarga"
        Me.CeldaCarga.Size = New System.Drawing.Size(20, 20)
        Me.CeldaCarga.TabIndex = 29
        Me.CeldaCarga.Text = "-1"
        Me.CeldaCarga.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(372, 14)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(20, 20)
        Me.celdaUsuario.TabIndex = 28
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(383, 213)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(20, 20)
        Me.celdaCatalogo.TabIndex = 27
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(383, 178)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(20, 20)
        Me.celdaEmpresa.TabIndex = 26
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(344, 62)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(319, 63)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDCliente.TabIndex = 24
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(240, 232)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(130, 20)
        Me.celdaTasa.TabIndex = 23
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(198, 234)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 22
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(158, 231)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(26, 20)
        Me.botonMoneda.TabIndex = 21
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(74, 231)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(74, 20)
        Me.celdaMoneda.TabIndex = 20
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(31, 237)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 19
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaNIT
        '
        Me.celdaNIT.Enabled = False
        Me.celdaNIT.Location = New System.Drawing.Point(70, 196)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(111, 20)
        Me.celdaNIT.TabIndex = 18
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(26, 200)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 17
        Me.etiquetaNIT.Text = "NIT"
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Enabled = False
        Me.celdaTelefono.Location = New System.Drawing.Point(240, 196)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(130, 20)
        Me.celdaTelefono.TabIndex = 16
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(198, 197)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(38, 13)
        Me.etiquetaTelefono.TabIndex = 15
        Me.etiquetaTelefono.Text = "Phone"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(69, 143)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(302, 38)
        Me.celdaDireccion.TabIndex = 11
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(10, 163)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 10
        Me.etiquetaDireccion.Text = "Address"
        '
        'botonClientes
        '
        Me.botonClientes.Location = New System.Drawing.Point(372, 111)
        Me.botonClientes.Name = "botonClientes"
        Me.botonClientes.Size = New System.Drawing.Size(26, 20)
        Me.botonClientes.TabIndex = 9
        Me.botonClientes.Text = "..."
        Me.botonClientes.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(69, 111)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(302, 20)
        Me.celdaCliente.TabIndex = 8
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(4, 114)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 7
        Me.etiquetaCliente.Text = "Customer"
        '
        'celdaFecha
        '
        Me.celdaFecha.Location = New System.Drawing.Point(70, 76)
        Me.celdaFecha.Name = "celdaFecha"
        Me.celdaFecha.Size = New System.Drawing.Size(90, 20)
        Me.celdaFecha.TabIndex = 6
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(26, 76)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 5
        Me.etiquetaFecha.Text = "Date"
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(340, 36)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 4
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(216, 36)
        Me.celdaNumero.Multiline = True
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(78, 19)
        Me.celdaNumero.TabIndex = 3
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(167, 39)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaAño
        '
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaAño.Location = New System.Drawing.Point(70, 36)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(90, 19)
        Me.celdaAño.TabIndex = 1
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(27, 40)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(272, 10)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(57, 43)
        Me.botonImprimir.TabIndex = 8
        Me.botonImprimir.Text = "Imprimir"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonBuscar
        '
        Me.botonBuscar.Image = Global.KARIMs_SGI.My.Resources.Resources.book_blue_view
        Me.botonBuscar.Location = New System.Drawing.Point(205, 10)
        Me.botonBuscar.Name = "botonBuscar"
        Me.botonBuscar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.botonBuscar.Size = New System.Drawing.Size(57, 43)
        Me.botonBuscar.TabIndex = 7
        Me.botonBuscar.Text = "Search"
        Me.botonBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBuscar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 67)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1032, 24)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1032, 67)
        Me.Encabezado1.TabIndex = 0
        '
        'dgcatalogo
        '
        Me.dgcatalogo.HeaderText = "Catalogo"
        Me.dgcatalogo.Name = "dgcatalogo"
        Me.dgcatalogo.ReadOnly = True
        '
        'dgAnio
        '
        Me.dgAnio.HeaderText = "Anio"
        Me.dgAnio.Name = "dgAnio"
        Me.dgAnio.ReadOnly = True
        '
        'dgNumber
        '
        Me.dgNumber.HeaderText = "Number"
        Me.dgNumber.Name = "dgNumber"
        Me.dgNumber.ReadOnly = True
        '
        'dgLinea
        '
        Me.dgLinea.HeaderText = "Line"
        Me.dgLinea.Name = "dgLinea"
        Me.dgLinea.ReadOnly = True
        '
        'dgBulkNumber
        '
        Me.dgBulkNumber.HeaderText = "Bulk number"
        Me.dgBulkNumber.Name = "dgBulkNumber"
        Me.dgBulkNumber.ReadOnly = True
        '
        'NumBulto2
        '
        Me.NumBulto2.HeaderText = "NumBulto2"
        Me.NumBulto2.Name = "NumBulto2"
        Me.NumBulto2.ReadOnly = True
        '
        'productoCod2
        '
        Me.productoCod2.HeaderText = "productoCod2"
        Me.productoCod2.Name = "productoCod2"
        Me.productoCod2.ReadOnly = True
        '
        'dgMark
        '
        Me.dgMark.HeaderText = "Mark"
        Me.dgMark.Name = "dgMark"
        Me.dgMark.ReadOnly = True
        '
        'dgCategoria
        '
        Me.dgCategoria.HeaderText = "Category"
        Me.dgCategoria.Name = "dgCategoria"
        Me.dgCategoria.ReadOnly = True
        '
        'dgPeso
        '
        Me.dgPeso.HeaderText = "Peso"
        Me.dgPeso.Name = "dgPeso"
        Me.dgPeso.ReadOnly = True
        '
        'dgLineaDet
        '
        Me.dgLineaDet.HeaderText = "LineaDetalle"
        Me.dgLineaDet.Name = "dgLineaDet"
        Me.dgLineaDet.ReadOnly = True
        '
        'dgExtra
        '
        Me.dgExtra.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.dgExtra.HeaderText = "Extra"
        Me.dgExtra.Name = "dgExtra"
        Me.dgExtra.ReadOnly = True
        '
        'colCatalogo1
        '
        Me.colCatalogo1.HeaderText = "Catalogo"
        Me.colCatalogo1.Name = "colCatalogo1"
        Me.colCatalogo1.ReadOnly = True
        '
        'colAnio1
        '
        Me.colAnio1.HeaderText = "Anio"
        Me.colAnio1.Name = "colAnio1"
        Me.colAnio1.ReadOnly = True
        '
        'colNumero1
        '
        Me.colNumero1.HeaderText = "Number"
        Me.colNumero1.Name = "colNumero1"
        Me.colNumero1.ReadOnly = True
        '
        'colLinea1
        '
        Me.colLinea1.HeaderText = "Line"
        Me.colLinea1.Name = "colLinea1"
        Me.colLinea1.ReadOnly = True
        '
        'colBultoNo
        '
        Me.colBultoNo.HeaderText = "Bulk number"
        Me.colBultoNo.Name = "colBultoNo"
        Me.colBultoNo.ReadOnly = True
        '
        'NumBulto1
        '
        Me.NumBulto1.HeaderText = "NumBulto1"
        Me.NumBulto1.Name = "NumBulto1"
        Me.NumBulto1.ReadOnly = True
        '
        'productoCod
        '
        Me.productoCod.HeaderText = "productoCod"
        Me.productoCod.Name = "productoCod"
        Me.productoCod.ReadOnly = True
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Mark"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        '
        'colCategoria
        '
        Me.colCategoria.HeaderText = "Category"
        Me.colCategoria.Name = "colCategoria"
        Me.colCategoria.ReadOnly = True
        '
        'colPeso
        '
        Me.colPeso.HeaderText = "Peso"
        Me.colPeso.Name = "colPeso"
        Me.colPeso.ReadOnly = True
        '
        'colLineaDet
        '
        Me.colLineaDet.HeaderText = "LineaDetalle"
        Me.colLineaDet.Name = "colLineaDet"
        Me.colLineaDet.ReadOnly = True
        '
        'colExtra1
        '
        Me.colExtra1.HeaderText = "Extra"
        Me.colExtra1.Name = "colExtra1"
        Me.colExtra1.ReadOnly = True
        '
        'colAno
        '
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        '
        'colNPedido
        '
        Me.colNPedido.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNPedido.HeaderText = "No. Pedido"
        Me.colNPedido.Name = "colNPedido"
        Me.colNPedido.ReadOnly = True
        Me.colNPedido.Width = 85
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 52
        '
        'colFech
        '
        Me.colFech.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFech.HeaderText = "Date"
        Me.colFech.Name = "colFech"
        Me.colFech.ReadOnly = True
        Me.colFech.Width = 55
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code*"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 61
        '
        'colArticulo
        '
        Me.colArticulo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colArticulo.HeaderText = "Article*"
        Me.colArticulo.Name = "colArticulo"
        Me.colArticulo.ReadOnly = True
        Me.colArticulo.Width = 65
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price $"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.Width = 65
        '
        'colExistencia
        '
        Me.colExistencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colExistencia.HeaderText = "Available"
        Me.colExistencia.Name = "colExistencia"
        Me.colExistencia.ReadOnly = True
        Me.colExistencia.Width = 75
        '
        'colOrden
        '
        Me.colOrden.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colOrden.HeaderText = "Order"
        Me.colOrden.Name = "colOrden"
        Me.colOrden.ReadOnly = True
        Me.colOrden.Width = 58
        '
        'colADespachar
        '
        Me.colADespachar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colADespachar.HeaderText = "To Dispatch*"
        Me.colADespachar.Name = "colADespachar"
        Me.colADespachar.ReadOnly = True
        Me.colADespachar.Width = 94
        '
        'colLibrasAdicionales
        '
        Me.colLibrasAdicionales.HeaderText = "Add Pounds"
        Me.colLibrasAdicionales.Name = "colLibrasAdicionales"
        '
        'colBulto
        '
        Me.colBulto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBulto.HeaderText = "Package"
        Me.colBulto.Name = "colBulto"
        Me.colBulto.Width = 75
        '
        'colPendiente
        '
        Me.colPendiente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPendiente.HeaderText = "Pending"
        Me.colPendiente.Name = "colPendiente"
        Me.colPendiente.ReadOnly = True
        Me.colPendiente.Width = 71
        '
        'colReference
        '
        Me.colReference.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReference.HeaderText = "Reference"
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        Me.colReference.Width = 82
        '
        'colLugar
        '
        Me.colLugar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLugar.HeaderText = "Place Destination"
        Me.colLugar.Name = "colLugar"
        Me.colLugar.ReadOnly = True
        Me.colLugar.Width = 105
        '
        'colCodDestino
        '
        Me.colCodDestino.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodDestino.HeaderText = "Destination Code"
        Me.colCodDestino.Name = "colCodDestino"
        Me.colCodDestino.ReadOnly = True
        Me.colCodDestino.Visible = False
        Me.colCodDestino.Width = 104
        '
        'colCodOriginal
        '
        Me.colCodOriginal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodOriginal.HeaderText = "Original Code"
        Me.colCodOriginal.Name = "colCodOriginal"
        Me.colCodOriginal.ReadOnly = True
        Me.colCodOriginal.Visible = False
        Me.colCodOriginal.Width = 87
        '
        'colDatosOriginales
        '
        Me.colDatosOriginales.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDatosOriginales.HeaderText = "Original Data"
        Me.colDatosOriginales.Name = "colDatosOriginales"
        Me.colDatosOriginales.ReadOnly = True
        Me.colDatosOriginales.Visible = False
        Me.colDatosOriginales.Width = 86
        '
        'colNumParte
        '
        Me.colNumParte.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumParte.HeaderText = "Part Number"
        Me.colNumParte.Name = "colNumParte"
        Me.colNumParte.ReadOnly = True
        Me.colNumParte.Visible = False
        Me.colNumParte.Width = 84
        '
        'colIDD
        '
        Me.colIDD.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIDD.HeaderText = "ID"
        Me.colIDD.Name = "colIDD"
        Me.colIDD.ReadOnly = True
        Me.colIDD.Width = 43
        '
        'colUnit
        '
        Me.colUnit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colUnit.HeaderText = "Unidad"
        Me.colUnit.Name = "colUnit"
        Me.colUnit.ReadOnly = True
        Me.colUnit.Visible = False
        Me.colUnit.Width = 66
        '
        'colBase
        '
        Me.colBase.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBase.HeaderText = "Base"
        Me.colBase.Name = "colBase"
        Me.colBase.ReadOnly = True
        Me.colBase.Visible = False
        Me.colBase.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.Width = 71
        '
        'colPedido
        '
        Me.colPedido.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPedido.HeaderText = "Pedido"
        Me.colPedido.Name = "colPedido"
        Me.colPedido.ReadOnly = True
        Me.colPedido.Visible = False
        Me.colPedido.Width = 65
        '
        'colOriginal
        '
        Me.colOriginal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colOriginal.HeaderText = "Original"
        Me.colOriginal.Name = "colOriginal"
        Me.colOriginal.ReadOnly = True
        Me.colOriginal.Visible = False
        Me.colOriginal.Width = 67
        '
        'colXtra
        '
        Me.colXtra.HeaderText = "Extra"
        Me.colXtra.Name = "colXtra"
        Me.colXtra.ReadOnly = True
        '
        'colObservation
        '
        Me.colObservation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colObservation.HeaderText = "Observations"
        Me.colObservation.Name = "colObservation"
        Me.colObservation.Width = 94
        '
        'colIDDesc
        '
        Me.colIDDesc.HeaderText = "IDDesc"
        Me.colIDDesc.Name = "colIDDesc"
        Me.colIDDesc.Visible = False
        '
        'colAnioDesc
        '
        Me.colAnioDesc.HeaderText = "AnioDescargo"
        Me.colAnioDesc.Name = "colAnioDesc"
        Me.colAnioDesc.Visible = False
        '
        'colCatDesc
        '
        Me.colCatDesc.HeaderText = "CatDescargo"
        Me.colCatDesc.Name = "colCatDesc"
        Me.colCatDesc.Visible = False
        '
        'colNumDesc
        '
        Me.colNumDesc.HeaderText = "NumDescargo"
        Me.colNumDesc.Name = "colNumDesc"
        Me.colNumDesc.Visible = False
        '
        'colLineaDesc
        '
        Me.colLineaDesc.HeaderText = "LineaDescargo"
        Me.colLineaDesc.Name = "colLineaDesc"
        Me.colLineaDesc.Visible = False
        '
        'colCantDescargo
        '
        Me.colCantDescargo.HeaderText = "CantidadDescargo"
        Me.colCantDescargo.Name = "colCantDescargo"
        Me.colCantDescargo.Visible = False
        '
        'colCodDesc
        '
        Me.colCodDesc.HeaderText = "CodigoDescargo"
        Me.colCodDesc.Name = "colCodDesc"
        Me.colCodDesc.Visible = False
        '
        'colNPedidoDesc
        '
        Me.colNPedidoDesc.HeaderText = "NPedidoDescargo"
        Me.colNPedidoDesc.Name = "colNPedidoDesc"
        Me.colNPedidoDesc.Visible = False
        '
        'colFecha2
        '
        Me.colFecha2.HeaderText = "Fecha2"
        Me.colFecha2.Name = "colFecha2"
        Me.colFecha2.Visible = False
        '
        'colPolizaDesc
        '
        Me.colPolizaDesc.HeaderText = "PolizaDescargo"
        Me.colPolizaDesc.Name = "colPolizaDesc"
        Me.colPolizaDesc.Visible = False
        '
        'colRefDesc
        '
        Me.colRefDesc.HeaderText = "RefDesc"
        Me.colRefDesc.Name = "colRefDesc"
        Me.colRefDesc.Visible = False
        '
        'colLinea2Desc
        '
        Me.colLinea2Desc.HeaderText = "Linea2Desc"
        Me.colLinea2Desc.Name = "colLinea2Desc"
        Me.colLinea2Desc.Visible = False
        '
        'colMedDesc
        '
        Me.colMedDesc.HeaderText = "MedidaDesc"
        Me.colMedDesc.Name = "colMedDesc"
        Me.colMedDesc.Visible = False
        '
        'colUnidadDesc
        '
        Me.colUnidadDesc.HeaderText = "UnidadDesc"
        Me.colUnidadDesc.Name = "colUnidadDesc"
        Me.colUnidadDesc.Visible = False
        '
        'colDisponibleDesc
        '
        Me.colDisponibleDesc.HeaderText = "DisponibleDesc"
        Me.colDisponibleDesc.Name = "colDisponibleDesc"
        Me.colDisponibleDesc.Visible = False
        '
        'colSaldoActual
        '
        Me.colSaldoActual.HeaderText = "SaldoActual"
        Me.colSaldoActual.Name = "colSaldoActual"
        Me.colSaldoActual.Visible = False
        '
        'colNota1Desc
        '
        Me.colNota1Desc.HeaderText = "Nota1Desc"
        Me.colNota1Desc.Name = "colNota1Desc"
        Me.colNota1Desc.Visible = False
        '
        'colNota2Desc
        '
        Me.colNota2Desc.HeaderText = "Nota2Desc"
        Me.colNota2Desc.Name = "colNota2Desc"
        Me.colNota2Desc.Visible = False
        '
        'frmInstDespacho
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1032, 709)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.botonBuscar)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmInstDespacho"
        Me.Text = "frmInstDespacho"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelInferior.ResumeLayout(False)
        Me.panelInferior.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgBultosInicio, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgbultos1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgReferencias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.PanelGastos.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panelbotom.ResumeLayout(False)
        Me.Panelbotom.PerformLayout()
        Me.PanelEncabezado.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.gbPedidoClientes.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        CType(Me.dgPedidos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.gbInformación.ResumeLayout(False)
        Me.gbInformación.PerformLayout()
        Me.gbInstDespacho.ResumeLayout(False)
        Me.gbInstDespacho.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents gbInstDespacho As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaTelefono As System.Windows.Forms.Label
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents botonClientes As System.Windows.Forms.Button
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents celdaFecha As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents gbInformación As System.Windows.Forms.GroupBox
    Friend WithEvents etiquetaImpuestos As System.Windows.Forms.Label
    Friend WithEvents celdaObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaObservaciones As System.Windows.Forms.Label
    Friend WithEvents celdaDetalle As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDetalle As System.Windows.Forms.Label
    Friend WithEvents gbPedidoClientes As System.Windows.Forms.GroupBox
    Friend WithEvents botonEliminar As System.Windows.Forms.Button
    Friend WithEvents botonMas As System.Windows.Forms.Button
    Friend WithEvents dgPedidos As System.Windows.Forms.DataGridView
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents celdaSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents panelFecha As System.Windows.Forms.Panel
    Friend WithEvents etiquetaFin As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents botonPendientes As System.Windows.Forms.Button
    Friend WithEvents botonBanderaAzul As System.Windows.Forms.Button
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents botonBuscar As System.Windows.Forms.Button
    Friend WithEvents botonImprimir As System.Windows.Forms.Button
    Friend WithEvents etiquetaModificado As System.Windows.Forms.Label
    Friend WithEvents panelInferior As System.Windows.Forms.Panel
    Friend WithEvents etiquetaNoFacturado As System.Windows.Forms.Label
    Friend WithEvents etiquetaAnulado As System.Windows.Forms.Label
    Friend WithEvents etiquetaNoCargado As System.Windows.Forms.Label
    Friend WithEvents celdaIDCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents rbOpcionPagoNO As System.Windows.Forms.RadioButton
    Friend WithEvents rbOpcionPagoSI As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaColorRojo As System.Windows.Forms.TextBox
    Friend WithEvents dgReferencias As System.Windows.Forms.DataGridView
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents botonQuitDetalle As System.Windows.Forms.Button
    Friend WithEvents botonAgreDetalle As System.Windows.Forms.Button
    Friend WithEvents CeldaCarga As System.Windows.Forms.TextBox
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents colPF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOperador As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPOCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colYear As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colImpuesto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExtra As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNum As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFech2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colRef As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPoliza As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLinea2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExist As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMed As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExiste As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantDescargada As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAlmacenado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNota1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNota2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PanelGastos As System.Windows.Forms.Panel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents rbFleteOtro As System.Windows.Forms.RadioButton
    Friend WithEvents rbFleteCliente As System.Windows.Forms.RadioButton
    Friend WithEvents rbFleteEmpresa As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents rbGastosOtros As System.Windows.Forms.RadioButton
    Friend WithEvents rbGastosCliente As System.Windows.Forms.RadioButton
    Friend WithEvents rbGastosEmpresa As System.Windows.Forms.RadioButton
    Friend WithEvents PanelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panelbotom As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents etiquetaComentarios As System.Windows.Forms.Label
    Friend WithEvents celdaComentario As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents dgbultos1 As DataGridView
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colCode As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colObservaciones As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colControl As DataGridViewTextBoxColumn
    Friend WithEvents colRelacion As DataGridViewTextBoxColumn
    Friend WithEvents colCarga As DataGridViewTextBoxColumn
    Friend WithEvents colDireccion As DataGridViewTextBoxColumn
    Friend WithEvents colTelefono As DataGridViewTextBoxColumn
    Friend WithEvents colNit As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
    Friend WithEvents celdaCosteo As TextBox
    Friend WithEvents etiquetaCosteo As Label
    Friend WithEvents botonCosteo As Button
    Friend WithEvents celdaIdCosteo As TextBox
    Friend WithEvents checkConsignacion As System.Windows.Forms.CheckBox
    Friend WithEvents checkPago As System.Windows.Forms.CheckBox
    Friend WithEvents checkTarifa As System.Windows.Forms.CheckBox
    Friend WithEvents checkFibra As System.Windows.Forms.CheckBox
    Friend WithEvents checkTraslado As System.Windows.Forms.CheckBox
    Friend WithEvents botonPolizaC As Button
    Friend WithEvents dgBultosInicio As DataGridView
    Friend WithEvents dgcatalogo As DataGridViewTextBoxColumn
    Friend WithEvents dgAnio As DataGridViewTextBoxColumn
    Friend WithEvents dgNumber As DataGridViewTextBoxColumn
    Friend WithEvents dgLinea As DataGridViewTextBoxColumn
    Friend WithEvents dgBulkNumber As DataGridViewTextBoxColumn
    Friend WithEvents NumBulto2 As DataGridViewTextBoxColumn
    Friend WithEvents productoCod2 As DataGridViewTextBoxColumn
    Friend WithEvents dgMark As DataGridViewTextBoxColumn
    Friend WithEvents dgCategoria As DataGridViewTextBoxColumn
    Friend WithEvents dgPeso As DataGridViewTextBoxColumn
    Friend WithEvents dgLineaDet As DataGridViewTextBoxColumn
    Friend WithEvents dgExtra As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo1 As DataGridViewTextBoxColumn
    Friend WithEvents colAnio1 As DataGridViewTextBoxColumn
    Friend WithEvents colNumero1 As DataGridViewTextBoxColumn
    Friend WithEvents colLinea1 As DataGridViewTextBoxColumn
    Friend WithEvents colBultoNo As DataGridViewTextBoxColumn
    Friend WithEvents NumBulto1 As DataGridViewTextBoxColumn
    Friend WithEvents productoCod As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colCategoria As DataGridViewTextBoxColumn
    Friend WithEvents colPeso As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDet As DataGridViewTextBoxColumn
    Friend WithEvents colExtra1 As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colNPedido As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colFech As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colArticulo As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colExistencia As DataGridViewTextBoxColumn
    Friend WithEvents colOrden As DataGridViewTextBoxColumn
    Friend WithEvents colADespachar As DataGridViewTextBoxColumn
    Friend WithEvents colLibrasAdicionales As DataGridViewTextBoxColumn
    Friend WithEvents colBulto As DataGridViewTextBoxColumn
    Friend WithEvents colPendiente As DataGridViewTextBoxColumn
    Friend WithEvents colReference As DataGridViewTextBoxColumn
    Friend WithEvents colLugar As DataGridViewTextBoxColumn
    Friend WithEvents colCodDestino As DataGridViewTextBoxColumn
    Friend WithEvents colCodOriginal As DataGridViewTextBoxColumn
    Friend WithEvents colDatosOriginales As DataGridViewTextBoxColumn
    Friend WithEvents colNumParte As DataGridViewTextBoxColumn
    Friend WithEvents colIDD As DataGridViewTextBoxColumn
    Friend WithEvents colUnit As DataGridViewTextBoxColumn
    Friend WithEvents colBase As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPedido As DataGridViewTextBoxColumn
    Friend WithEvents colOriginal As DataGridViewTextBoxColumn
    Friend WithEvents colXtra As DataGridViewTextBoxColumn
    Friend WithEvents colObservation As DataGridViewTextBoxColumn
    Friend WithEvents colIDDesc As DataGridViewTextBoxColumn
    Friend WithEvents colAnioDesc As DataGridViewTextBoxColumn
    Friend WithEvents colCatDesc As DataGridViewTextBoxColumn
    Friend WithEvents colNumDesc As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDesc As DataGridViewTextBoxColumn
    Friend WithEvents colCantDescargo As DataGridViewTextBoxColumn
    Friend WithEvents colCodDesc As DataGridViewTextBoxColumn
    Friend WithEvents colNPedidoDesc As DataGridViewTextBoxColumn
    Friend WithEvents colFecha2 As DataGridViewTextBoxColumn
    Friend WithEvents colPolizaDesc As DataGridViewTextBoxColumn
    Friend WithEvents colRefDesc As DataGridViewTextBoxColumn
    Friend WithEvents colLinea2Desc As DataGridViewTextBoxColumn
    Friend WithEvents colMedDesc As DataGridViewTextBoxColumn
    Friend WithEvents colUnidadDesc As DataGridViewTextBoxColumn
    Friend WithEvents colDisponibleDesc As DataGridViewTextBoxColumn
    Friend WithEvents colSaldoActual As DataGridViewTextBoxColumn
    Friend WithEvents colNota1Desc As DataGridViewTextBoxColumn
    Friend WithEvents colNota2Desc As DataGridViewTextBoxColumn
End Class
