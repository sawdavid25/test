﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProduccion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProduccion))
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.gbProducto = New System.Windows.Forms.GroupBox()
        Me.dgProducto = New System.Windows.Forms.DataGridView()
        Me.col_AnioProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_CatalogoProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_NumeroProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_CodigoProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_LineaProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_DescripcionProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_ClasificacionProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_CostoProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_CantidadProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_ExtraProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_ParLineaProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_PorcentajeProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_TotalProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_IdMedidaProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_MedidaProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_VerificadorProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_ReferenciaProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_BultosProd = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelProducto = New System.Windows.Forms.Panel()
        Me.botonEliminarProd = New System.Windows.Forms.Button()
        Me.etiquetaEliminar = New System.Windows.Forms.Label()
        Me.botonProducto = New System.Windows.Forms.Button()
        Me.etiquetaProduto = New System.Windows.Forms.Label()
        Me.gbCostosTiempo = New System.Windows.Forms.GroupBox()
        Me.dgCostos = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelCostoTiempo = New System.Windows.Forms.Panel()
        Me.celdaIdProducto = New System.Windows.Forms.TextBox()
        Me.botonConvertir = New System.Windows.Forms.Button()
        Me.botonSeleccion = New System.Windows.Forms.Button()
        Me.etiquetaTitulos = New System.Windows.Forms.Label()
        Me.celdaHilo = New System.Windows.Forms.TextBox()
        Me.botonEliminarCosto = New System.Windows.Forms.Button()
        Me.botonCostoTiempo = New System.Windows.Forms.Button()
        Me.etiquetaEliminarCosto = New System.Windows.Forms.Label()
        Me.etiquetaCostoTiemo = New System.Windows.Forms.Label()
        Me.gbCostosFijos = New System.Windows.Forms.GroupBox()
        Me.dgBultos = New System.Windows.Forms.DataGridView()
        Me.colCatalogoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBultoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDocumentoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarcaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativoB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCategoriaB = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgCostoFijo = New System.Windows.Forms.DataGridView()
        Me.colCodigoFijo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionFijo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPorcentajeFijo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMermaFijo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidadFijo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelCostoFijo = New System.Windows.Forms.Panel()
        Me.botonEliminarCostoFijo = New System.Windows.Forms.Button()
        Me.etiquetaEliminarCostoFijo = New System.Windows.Forms.Label()
        Me.botonCostoFijo = New System.Windows.Forms.Button()
        Me.etiquetaCostoFijo = New System.Windows.Forms.Label()
        Me.panelTiempo = New System.Windows.Forms.Panel()
        Me.etiquetaTotalBultos = New System.Windows.Forms.Label()
        Me.etiquetaTotalLibras = New System.Windows.Forms.Label()
        Me.celdaTotalBultos = New System.Windows.Forms.TextBox()
        Me.celdaTotalLibras = New System.Windows.Forms.TextBox()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.botonAnular = New System.Windows.Forms.Button()
        Me.etiquetaInactivo = New System.Windows.Forms.Label()
        Me.celdaEntrada = New System.Windows.Forms.TextBox()
        Me.celdaOrden = New System.Windows.Forms.TextBox()
        Me.celdaIDTarea = New System.Windows.Forms.TextBox()
        Me.celdaIdProyecto = New System.Windows.Forms.TextBox()
        Me.celdaFecha = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdareferencia = New System.Windows.Forms.TextBox()
        Me.etiquetaReferencia = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.botonStop = New System.Windows.Forms.Button()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.botonStart = New System.Windows.Forms.Button()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.botonEstimar = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.gbProducto.SuspendLayout()
        CType(Me.dgProducto, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelProducto.SuspendLayout()
        Me.gbCostosTiempo.SuspendLayout()
        CType(Me.dgCostos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelCostoTiempo.SuspendLayout()
        Me.gbCostosFijos.SuspendLayout()
        CType(Me.dgBultos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgCostoFijo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelCostoFijo.SuspendLayout()
        Me.panelTiempo.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 108)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(1087, 90)
        Me.panelListaPrincipal.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogo, Me.colAnio, Me.colNumber, Me.colDate, Me.colReferencia, Me.colProducto})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 54)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1087, 36)
        Me.dgLista.TabIndex = 3
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 83
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 63
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Product"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(1087, 54)
        Me.panelFecha.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(582, 15)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(435, 17)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(361, 21)
        Me.etiquetaFin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(243, 16)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(224, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.gbProducto)
        Me.panelDetalle.Controls.Add(Me.gbCostosTiempo)
        Me.panelDetalle.Controls.Add(Me.gbCostosFijos)
        Me.panelDetalle.Controls.Add(Me.panelTiempo)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDetalle.Location = New System.Drawing.Point(0, 198)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1087, 689)
        Me.panelDetalle.TabIndex = 4
        '
        'gbProducto
        '
        Me.gbProducto.Controls.Add(Me.dgProducto)
        Me.gbProducto.Controls.Add(Me.panelProducto)
        Me.gbProducto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbProducto.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbProducto.Location = New System.Drawing.Point(0, 139)
        Me.gbProducto.Name = "gbProducto"
        Me.gbProducto.Size = New System.Drawing.Size(352, 257)
        Me.gbProducto.TabIndex = 19
        Me.gbProducto.TabStop = False
        Me.gbProducto.Text = "Product"
        '
        'dgProducto
        '
        Me.dgProducto.AllowUserToAddRows = False
        Me.dgProducto.AllowUserToDeleteRows = False
        Me.dgProducto.AllowUserToOrderColumns = True
        Me.dgProducto.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgProducto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgProducto.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_AnioProd, Me.col_CatalogoProd, Me.col_NumeroProd, Me.col_CodigoProd, Me.col_LineaProd, Me.col_DescripcionProd, Me.col_ClasificacionProd, Me.col_CostoProd, Me.col_CantidadProd, Me.col_ExtraProd, Me.col_ParLineaProd, Me.col_PorcentajeProd, Me.col_TotalProd, Me.col_IdMedidaProd, Me.col_MedidaProd, Me.col_VerificadorProd, Me.col_ReferenciaProd, Me.col_BultosProd})
        Me.dgProducto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgProducto.Location = New System.Drawing.Point(3, 92)
        Me.dgProducto.MultiSelect = False
        Me.dgProducto.Name = "dgProducto"
        Me.dgProducto.RowTemplate.Height = 24
        Me.dgProducto.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgProducto.Size = New System.Drawing.Size(346, 162)
        Me.dgProducto.TabIndex = 3
        '
        'col_AnioProd
        '
        Me.col_AnioProd.HeaderText = "Year"
        Me.col_AnioProd.Name = "col_AnioProd"
        Me.col_AnioProd.ReadOnly = True
        Me.col_AnioProd.Visible = False
        '
        'col_CatalogoProd
        '
        Me.col_CatalogoProd.HeaderText = "Catalogo"
        Me.col_CatalogoProd.Name = "col_CatalogoProd"
        Me.col_CatalogoProd.ReadOnly = True
        Me.col_CatalogoProd.Visible = False
        '
        'col_NumeroProd
        '
        Me.col_NumeroProd.HeaderText = "Number"
        Me.col_NumeroProd.Name = "col_NumeroProd"
        Me.col_NumeroProd.ReadOnly = True
        Me.col_NumeroProd.Visible = False
        '
        'col_CodigoProd
        '
        Me.col_CodigoProd.HeaderText = "Code"
        Me.col_CodigoProd.Name = "col_CodigoProd"
        Me.col_CodigoProd.ReadOnly = True
        Me.col_CodigoProd.Visible = False
        '
        'col_LineaProd
        '
        Me.col_LineaProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_LineaProd.HeaderText = "Line"
        Me.col_LineaProd.Name = "col_LineaProd"
        Me.col_LineaProd.ReadOnly = True
        Me.col_LineaProd.Width = 60
        '
        'col_DescripcionProd
        '
        Me.col_DescripcionProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_DescripcionProd.HeaderText = "Description"
        Me.col_DescripcionProd.Name = "col_DescripcionProd"
        Me.col_DescripcionProd.ReadOnly = True
        Me.col_DescripcionProd.Width = 104
        '
        'col_ClasificacionProd
        '
        Me.col_ClasificacionProd.HeaderText = "classification"
        Me.col_ClasificacionProd.Name = "col_ClasificacionProd"
        Me.col_ClasificacionProd.ReadOnly = True
        Me.col_ClasificacionProd.Visible = False
        '
        'col_CostoProd
        '
        Me.col_CostoProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_CostoProd.HeaderText = "Cost"
        Me.col_CostoProd.Name = "col_CostoProd"
        Me.col_CostoProd.ReadOnly = True
        Me.col_CostoProd.Width = 61
        '
        'col_CantidadProd
        '
        Me.col_CantidadProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_CantidadProd.HeaderText = "Quantity"
        Me.col_CantidadProd.Name = "col_CantidadProd"
        Me.col_CantidadProd.ReadOnly = True
        Me.col_CantidadProd.Width = 86
        '
        'col_ExtraProd
        '
        Me.col_ExtraProd.HeaderText = "Extra"
        Me.col_ExtraProd.Name = "col_ExtraProd"
        Me.col_ExtraProd.ReadOnly = True
        Me.col_ExtraProd.Visible = False
        '
        'col_ParLineaProd
        '
        Me.col_ParLineaProd.HeaderText = "Par_Linea"
        Me.col_ParLineaProd.Name = "col_ParLineaProd"
        Me.col_ParLineaProd.ReadOnly = True
        Me.col_ParLineaProd.Visible = False
        '
        'col_PorcentajeProd
        '
        Me.col_PorcentajeProd.HeaderText = "Percentage"
        Me.col_PorcentajeProd.Name = "col_PorcentajeProd"
        Me.col_PorcentajeProd.ReadOnly = True
        Me.col_PorcentajeProd.Visible = False
        '
        'col_TotalProd
        '
        Me.col_TotalProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_TotalProd.HeaderText = "Total"
        Me.col_TotalProd.Name = "col_TotalProd"
        Me.col_TotalProd.ReadOnly = True
        Me.col_TotalProd.Width = 65
        '
        'col_IdMedidaProd
        '
        Me.col_IdMedidaProd.HeaderText = "IdMedida"
        Me.col_IdMedidaProd.Name = "col_IdMedidaProd"
        Me.col_IdMedidaProd.ReadOnly = True
        Me.col_IdMedidaProd.Visible = False
        '
        'col_MedidaProd
        '
        Me.col_MedidaProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_MedidaProd.HeaderText = "Measure"
        Me.col_MedidaProd.Name = "col_MedidaProd"
        Me.col_MedidaProd.ReadOnly = True
        Me.col_MedidaProd.Width = 88
        '
        'col_VerificadorProd
        '
        Me.col_VerificadorProd.HeaderText = "Verificador"
        Me.col_VerificadorProd.Name = "col_VerificadorProd"
        Me.col_VerificadorProd.ReadOnly = True
        Me.col_VerificadorProd.Visible = False
        '
        'col_ReferenciaProd
        '
        Me.col_ReferenciaProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_ReferenciaProd.HeaderText = "Reference"
        Me.col_ReferenciaProd.Name = "col_ReferenciaProd"
        Me.col_ReferenciaProd.ReadOnly = True
        Me.col_ReferenciaProd.Width = 99
        '
        'col_BultosProd
        '
        Me.col_BultosProd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_BultosProd.HeaderText = "Package"
        Me.col_BultosProd.Name = "col_BultosProd"
        Me.col_BultosProd.Width = 88
        '
        'panelProducto
        '
        Me.panelProducto.Controls.Add(Me.botonEliminarProd)
        Me.panelProducto.Controls.Add(Me.etiquetaEliminar)
        Me.panelProducto.Controls.Add(Me.botonProducto)
        Me.panelProducto.Controls.Add(Me.etiquetaProduto)
        Me.panelProducto.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelProducto.Location = New System.Drawing.Point(3, 18)
        Me.panelProducto.Name = "panelProducto"
        Me.panelProducto.Size = New System.Drawing.Size(346, 74)
        Me.panelProducto.TabIndex = 2
        '
        'botonEliminarProd
        '
        Me.botonEliminarProd.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonEliminarProd.Location = New System.Drawing.Point(313, 17)
        Me.botonEliminarProd.Name = "botonEliminarProd"
        Me.botonEliminarProd.Size = New System.Drawing.Size(38, 25)
        Me.botonEliminarProd.TabIndex = 3
        Me.botonEliminarProd.UseVisualStyleBackColor = True
        Me.botonEliminarProd.Visible = False
        '
        'etiquetaEliminar
        '
        Me.etiquetaEliminar.AutoSize = True
        Me.etiquetaEliminar.Location = New System.Drawing.Point(193, 21)
        Me.etiquetaEliminar.Name = "etiquetaEliminar"
        Me.etiquetaEliminar.Size = New System.Drawing.Size(102, 17)
        Me.etiquetaEliminar.TabIndex = 2
        Me.etiquetaEliminar.Text = "Delete Product"
        Me.etiquetaEliminar.Visible = False
        '
        'botonProducto
        '
        Me.botonProducto.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonProducto.Location = New System.Drawing.Point(120, 17)
        Me.botonProducto.Name = "botonProducto"
        Me.botonProducto.Size = New System.Drawing.Size(38, 25)
        Me.botonProducto.TabIndex = 1
        Me.botonProducto.UseVisualStyleBackColor = True
        Me.botonProducto.Visible = False
        '
        'etiquetaProduto
        '
        Me.etiquetaProduto.AutoSize = True
        Me.etiquetaProduto.Location = New System.Drawing.Point(5, 21)
        Me.etiquetaProduto.Name = "etiquetaProduto"
        Me.etiquetaProduto.Size = New System.Drawing.Size(100, 17)
        Me.etiquetaProduto.TabIndex = 0
        Me.etiquetaProduto.Text = "Select Product"
        Me.etiquetaProduto.Visible = False
        '
        'gbCostosTiempo
        '
        Me.gbCostosTiempo.Controls.Add(Me.dgCostos)
        Me.gbCostosTiempo.Controls.Add(Me.panelCostoTiempo)
        Me.gbCostosTiempo.Dock = System.Windows.Forms.DockStyle.Right
        Me.gbCostosTiempo.Location = New System.Drawing.Point(352, 139)
        Me.gbCostosTiempo.Name = "gbCostosTiempo"
        Me.gbCostosTiempo.Size = New System.Drawing.Size(735, 257)
        Me.gbCostosTiempo.TabIndex = 20
        Me.gbCostosTiempo.TabStop = False
        Me.gbCostosTiempo.Text = "Cost"
        '
        'dgCostos
        '
        Me.dgCostos.AllowUserToAddRows = False
        Me.dgCostos.AllowUserToDeleteRows = False
        Me.dgCostos.AllowUserToOrderColumns = True
        Me.dgCostos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgCostos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCostos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colLinea, Me.colClasificacion, Me.colCosto})
        Me.dgCostos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCostos.Location = New System.Drawing.Point(3, 92)
        Me.dgCostos.MultiSelect = False
        Me.dgCostos.Name = "dgCostos"
        Me.dgCostos.RowTemplate.Height = 24
        Me.dgCostos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCostos.Size = New System.Drawing.Size(729, 162)
        Me.dgCostos.TabIndex = 4
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Visible = False
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 60
        '
        'colClasificacion
        '
        Me.colClasificacion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClasificacion.HeaderText = "Classification"
        Me.colClasificacion.Name = "colClasificacion"
        Me.colClasificacion.ReadOnly = True
        Me.colClasificacion.Width = 115
        '
        'colCosto
        '
        Me.colCosto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCosto.HeaderText = "Cost"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.Width = 61
        '
        'panelCostoTiempo
        '
        Me.panelCostoTiempo.Controls.Add(Me.celdaIdProducto)
        Me.panelCostoTiempo.Controls.Add(Me.botonConvertir)
        Me.panelCostoTiempo.Controls.Add(Me.botonSeleccion)
        Me.panelCostoTiempo.Controls.Add(Me.etiquetaTitulos)
        Me.panelCostoTiempo.Controls.Add(Me.celdaHilo)
        Me.panelCostoTiempo.Controls.Add(Me.botonEliminarCosto)
        Me.panelCostoTiempo.Controls.Add(Me.botonCostoTiempo)
        Me.panelCostoTiempo.Controls.Add(Me.etiquetaEliminarCosto)
        Me.panelCostoTiempo.Controls.Add(Me.etiquetaCostoTiemo)
        Me.panelCostoTiempo.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelCostoTiempo.Location = New System.Drawing.Point(3, 18)
        Me.panelCostoTiempo.Name = "panelCostoTiempo"
        Me.panelCostoTiempo.Size = New System.Drawing.Size(729, 74)
        Me.panelCostoTiempo.TabIndex = 3
        '
        'celdaIdProducto
        '
        Me.celdaIdProducto.Location = New System.Drawing.Point(518, 25)
        Me.celdaIdProducto.Name = "celdaIdProducto"
        Me.celdaIdProducto.Size = New System.Drawing.Size(100, 22)
        Me.celdaIdProducto.TabIndex = 9
        Me.celdaIdProducto.Visible = False
        '
        'botonConvertir
        '
        Me.botonConvertir.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonConvertir.AutoSize = True
        Me.botonConvertir.Location = New System.Drawing.Point(613, 23)
        Me.botonConvertir.Name = "botonConvertir"
        Me.botonConvertir.Size = New System.Drawing.Size(75, 41)
        Me.botonConvertir.TabIndex = 4
        Me.botonConvertir.Text = "Convert"
        Me.botonConvertir.UseVisualStyleBackColor = True
        Me.botonConvertir.Visible = False
        '
        'botonSeleccion
        '
        Me.botonSeleccion.AutoSize = True
        Me.botonSeleccion.Location = New System.Drawing.Point(370, 23)
        Me.botonSeleccion.Name = "botonSeleccion"
        Me.botonSeleccion.Size = New System.Drawing.Size(110, 41)
        Me.botonSeleccion.TabIndex = 5
        Me.botonSeleccion.Text = "Select Product"
        Me.botonSeleccion.UseVisualStyleBackColor = True
        '
        'etiquetaTitulos
        '
        Me.etiquetaTitulos.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTitulos.AutoSize = True
        Me.etiquetaTitulos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTitulos.Location = New System.Drawing.Point(-45, 1)
        Me.etiquetaTitulos.Name = "etiquetaTitulos"
        Me.etiquetaTitulos.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaTitulos.TabIndex = 8
        Me.etiquetaTitulos.Text = "Label1"
        '
        'celdaHilo
        '
        Me.celdaHilo.Location = New System.Drawing.Point(16, 21)
        Me.celdaHilo.Multiline = True
        Me.celdaHilo.Name = "celdaHilo"
        Me.celdaHilo.Size = New System.Drawing.Size(348, 43)
        Me.celdaHilo.TabIndex = 7
        '
        'botonEliminarCosto
        '
        Me.botonEliminarCosto.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonEliminarCosto.Location = New System.Drawing.Point(321, 17)
        Me.botonEliminarCosto.Name = "botonEliminarCosto"
        Me.botonEliminarCosto.Size = New System.Drawing.Size(38, 25)
        Me.botonEliminarCosto.TabIndex = 5
        Me.botonEliminarCosto.UseVisualStyleBackColor = True
        Me.botonEliminarCosto.Visible = False
        '
        'botonCostoTiempo
        '
        Me.botonCostoTiempo.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonCostoTiempo.Location = New System.Drawing.Point(133, 17)
        Me.botonCostoTiempo.Name = "botonCostoTiempo"
        Me.botonCostoTiempo.Size = New System.Drawing.Size(37, 25)
        Me.botonCostoTiempo.TabIndex = 1
        Me.botonCostoTiempo.UseVisualStyleBackColor = True
        Me.botonCostoTiempo.Visible = False
        '
        'etiquetaEliminarCosto
        '
        Me.etiquetaEliminarCosto.AutoSize = True
        Me.etiquetaEliminarCosto.Location = New System.Drawing.Point(201, 21)
        Me.etiquetaEliminarCosto.Name = "etiquetaEliminarCosto"
        Me.etiquetaEliminarCosto.Size = New System.Drawing.Size(81, 17)
        Me.etiquetaEliminarCosto.TabIndex = 4
        Me.etiquetaEliminarCosto.Text = "Delete Cost"
        Me.etiquetaEliminarCosto.Visible = False
        '
        'etiquetaCostoTiemo
        '
        Me.etiquetaCostoTiemo.AutoSize = True
        Me.etiquetaCostoTiemo.Location = New System.Drawing.Point(6, 21)
        Me.etiquetaCostoTiemo.Name = "etiquetaCostoTiemo"
        Me.etiquetaCostoTiemo.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaCostoTiemo.TabIndex = 0
        Me.etiquetaCostoTiemo.Text = "Select Cost"
        Me.etiquetaCostoTiemo.Visible = False
        '
        'gbCostosFijos
        '
        Me.gbCostosFijos.Controls.Add(Me.dgBultos)
        Me.gbCostosFijos.Controls.Add(Me.dgCostoFijo)
        Me.gbCostosFijos.Controls.Add(Me.PanelCostoFijo)
        Me.gbCostosFijos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.gbCostosFijos.Location = New System.Drawing.Point(0, 396)
        Me.gbCostosFijos.Name = "gbCostosFijos"
        Me.gbCostosFijos.Size = New System.Drawing.Size(1087, 293)
        Me.gbCostosFijos.TabIndex = 18
        Me.gbCostosFijos.TabStop = False
        Me.gbCostosFijos.Text = "Fixed costs"
        '
        'dgBultos
        '
        Me.dgBultos.AllowUserToAddRows = False
        Me.dgBultos.AllowUserToDeleteRows = False
        Me.dgBultos.AllowUserToOrderColumns = True
        Me.dgBultos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgBultos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgBultos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCatalogoB, Me.colAnioB, Me.colNumeroB, Me.colLineaB, Me.colBultoB, Me.colLineaDocumentoB, Me.colExtraB, Me.colPesoB, Me.colMarcaB, Me.colCorrelativoB, Me.colCategoriaB})
        Me.dgBultos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgBultos.Location = New System.Drawing.Point(771, 76)
        Me.dgBultos.MultiSelect = False
        Me.dgBultos.Name = "dgBultos"
        Me.dgBultos.RowTemplate.Height = 24
        Me.dgBultos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgBultos.Size = New System.Drawing.Size(313, 214)
        Me.dgBultos.TabIndex = 5
        '
        'colCatalogoB
        '
        Me.colCatalogoB.HeaderText = "Catalogo"
        Me.colCatalogoB.Name = "colCatalogoB"
        Me.colCatalogoB.Visible = False
        '
        'colAnioB
        '
        Me.colAnioB.HeaderText = "Year"
        Me.colAnioB.Name = "colAnioB"
        Me.colAnioB.Visible = False
        '
        'colNumeroB
        '
        Me.colNumeroB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumeroB.HeaderText = "Number"
        Me.colNumeroB.Name = "colNumeroB"
        Me.colNumeroB.Width = 83
        '
        'colLineaB
        '
        Me.colLineaB.HeaderText = "ParLinea"
        Me.colLineaB.Name = "colLineaB"
        Me.colLineaB.Visible = False
        '
        'colBultoB
        '
        Me.colBultoB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colBultoB.HeaderText = "Package line"
        Me.colBultoB.Name = "colBultoB"
        Me.colBultoB.Width = 105
        '
        'colLineaDocumentoB
        '
        Me.colLineaDocumentoB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLineaDocumentoB.HeaderText = "Line Document"
        Me.colLineaDocumentoB.Name = "colLineaDocumentoB"
        Me.colLineaDocumentoB.Width = 117
        '
        'colExtraB
        '
        Me.colExtraB.HeaderText = "Extra"
        Me.colExtraB.Name = "colExtraB"
        Me.colExtraB.Visible = False
        '
        'colPesoB
        '
        Me.colPesoB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPesoB.HeaderText = "Weight"
        Me.colPesoB.Name = "colPesoB"
        Me.colPesoB.Width = 77
        '
        'colMarcaB
        '
        Me.colMarcaB.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMarcaB.HeaderText = "Mark"
        Me.colMarcaB.Name = "colMarcaB"
        Me.colMarcaB.Width = 64
        '
        'colCorrelativoB
        '
        Me.colCorrelativoB.HeaderText = "Correlative HSM"
        Me.colCorrelativoB.Name = "colCorrelativoB"
        '
        'colCategoriaB
        '
        Me.colCategoriaB.HeaderText = "Category"
        Me.colCategoriaB.Name = "colCategoriaB"
        '
        'dgCostoFijo
        '
        Me.dgCostoFijo.AllowUserToAddRows = False
        Me.dgCostoFijo.AllowUserToDeleteRows = False
        Me.dgCostoFijo.AllowUserToOrderColumns = True
        Me.dgCostoFijo.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgCostoFijo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCostoFijo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigoFijo, Me.colDescripcionFijo, Me.colPorcentajeFijo, Me.colMermaFijo, Me.colCantidadFijo})
        Me.dgCostoFijo.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgCostoFijo.Location = New System.Drawing.Point(3, 76)
        Me.dgCostoFijo.Name = "dgCostoFijo"
        Me.dgCostoFijo.RowTemplate.Height = 24
        Me.dgCostoFijo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCostoFijo.Size = New System.Drawing.Size(768, 214)
        Me.dgCostoFijo.TabIndex = 4
        '
        'colCodigoFijo
        '
        Me.colCodigoFijo.HeaderText = "Code"
        Me.colCodigoFijo.Name = "colCodigoFijo"
        Me.colCodigoFijo.ReadOnly = True
        Me.colCodigoFijo.Visible = False
        '
        'colDescripcionFijo
        '
        Me.colDescripcionFijo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcionFijo.HeaderText = "Description"
        Me.colDescripcionFijo.Name = "colDescripcionFijo"
        Me.colDescripcionFijo.ReadOnly = True
        '
        'colPorcentajeFijo
        '
        Me.colPorcentajeFijo.HeaderText = "Porcentage"
        Me.colPorcentajeFijo.Name = "colPorcentajeFijo"
        '
        'colMermaFijo
        '
        Me.colMermaFijo.HeaderText = "Decrease"
        Me.colMermaFijo.Name = "colMermaFijo"
        '
        'colCantidadFijo
        '
        Me.colCantidadFijo.HeaderText = "Quantity"
        Me.colCantidadFijo.Name = "colCantidadFijo"
        '
        'PanelCostoFijo
        '
        Me.PanelCostoFijo.Controls.Add(Me.botonEliminarCostoFijo)
        Me.PanelCostoFijo.Controls.Add(Me.etiquetaEliminarCostoFijo)
        Me.PanelCostoFijo.Controls.Add(Me.botonCostoFijo)
        Me.PanelCostoFijo.Controls.Add(Me.etiquetaCostoFijo)
        Me.PanelCostoFijo.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelCostoFijo.Location = New System.Drawing.Point(3, 18)
        Me.PanelCostoFijo.Name = "PanelCostoFijo"
        Me.PanelCostoFijo.Size = New System.Drawing.Size(1081, 58)
        Me.PanelCostoFijo.TabIndex = 3
        '
        'botonEliminarCostoFijo
        '
        Me.botonEliminarCostoFijo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEliminarCostoFijo.Image = Global.KARIMs_SGI.My.Resources.Resources.delete31
        Me.botonEliminarCostoFijo.Location = New System.Drawing.Point(1025, 20)
        Me.botonEliminarCostoFijo.Name = "botonEliminarCostoFijo"
        Me.botonEliminarCostoFijo.Size = New System.Drawing.Size(38, 25)
        Me.botonEliminarCostoFijo.TabIndex = 5
        Me.botonEliminarCostoFijo.UseVisualStyleBackColor = True
        '
        'etiquetaEliminarCostoFijo
        '
        Me.etiquetaEliminarCostoFijo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaEliminarCostoFijo.AutoSize = True
        Me.etiquetaEliminarCostoFijo.Location = New System.Drawing.Point(888, 24)
        Me.etiquetaEliminarCostoFijo.Name = "etiquetaEliminarCostoFijo"
        Me.etiquetaEliminarCostoFijo.Size = New System.Drawing.Size(119, 17)
        Me.etiquetaEliminarCostoFijo.TabIndex = 4
        Me.etiquetaEliminarCostoFijo.Text = "Remove Package"
        '
        'botonCostoFijo
        '
        Me.botonCostoFijo.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonCostoFijo.Location = New System.Drawing.Point(142, 17)
        Me.botonCostoFijo.Name = "botonCostoFijo"
        Me.botonCostoFijo.Size = New System.Drawing.Size(35, 25)
        Me.botonCostoFijo.TabIndex = 1
        Me.botonCostoFijo.UseVisualStyleBackColor = True
        Me.botonCostoFijo.Visible = False
        '
        'etiquetaCostoFijo
        '
        Me.etiquetaCostoFijo.AutoSize = True
        Me.etiquetaCostoFijo.Location = New System.Drawing.Point(6, 21)
        Me.etiquetaCostoFijo.Name = "etiquetaCostoFijo"
        Me.etiquetaCostoFijo.Size = New System.Drawing.Size(110, 17)
        Me.etiquetaCostoFijo.TabIndex = 0
        Me.etiquetaCostoFijo.Text = "Select fixed cost"
        Me.etiquetaCostoFijo.Visible = False
        '
        'panelTiempo
        '
        Me.panelTiempo.Controls.Add(Me.etiquetaTotalBultos)
        Me.panelTiempo.Controls.Add(Me.etiquetaTotalLibras)
        Me.panelTiempo.Controls.Add(Me.celdaTotalBultos)
        Me.panelTiempo.Controls.Add(Me.celdaTotalLibras)
        Me.panelTiempo.Controls.Add(Me.celdaCantidad)
        Me.panelTiempo.Controls.Add(Me.etiquetaCantidad)
        Me.panelTiempo.Controls.Add(Me.etiquetaTasa)
        Me.panelTiempo.Controls.Add(Me.celdaTasa)
        Me.panelTiempo.Controls.Add(Me.botonMoneda)
        Me.panelTiempo.Controls.Add(Me.celdaIdMoneda)
        Me.panelTiempo.Controls.Add(Me.celdaMoneda)
        Me.panelTiempo.Controls.Add(Me.etiquetaMoneda)
        Me.panelTiempo.Controls.Add(Me.botonAnular)
        Me.panelTiempo.Controls.Add(Me.etiquetaInactivo)
        Me.panelTiempo.Controls.Add(Me.celdaEntrada)
        Me.panelTiempo.Controls.Add(Me.celdaOrden)
        Me.panelTiempo.Controls.Add(Me.celdaIDTarea)
        Me.panelTiempo.Controls.Add(Me.celdaIdProyecto)
        Me.panelTiempo.Controls.Add(Me.celdaFecha)
        Me.panelTiempo.Controls.Add(Me.celdaEmpresa)
        Me.panelTiempo.Controls.Add(Me.celdareferencia)
        Me.panelTiempo.Controls.Add(Me.etiquetaReferencia)
        Me.panelTiempo.Controls.Add(Me.dtpFecha)
        Me.panelTiempo.Controls.Add(Me.etiquetaAnio)
        Me.panelTiempo.Controls.Add(Me.etiquetaFecha)
        Me.panelTiempo.Controls.Add(Me.celdaAnio)
        Me.panelTiempo.Controls.Add(Me.botonStop)
        Me.panelTiempo.Controls.Add(Me.etiquetaNumero)
        Me.panelTiempo.Controls.Add(Me.botonStart)
        Me.panelTiempo.Controls.Add(Me.celdaNumero)
        Me.panelTiempo.Controls.Add(Me.celdaCatalogo)
        Me.panelTiempo.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelTiempo.Location = New System.Drawing.Point(0, 0)
        Me.panelTiempo.Name = "panelTiempo"
        Me.panelTiempo.Size = New System.Drawing.Size(1087, 139)
        Me.panelTiempo.TabIndex = 17
        '
        'etiquetaTotalBultos
        '
        Me.etiquetaTotalBultos.AutoSize = True
        Me.etiquetaTotalBultos.Location = New System.Drawing.Point(683, 86)
        Me.etiquetaTotalBultos.Name = "etiquetaTotalBultos"
        Me.etiquetaTotalBultos.Size = New System.Drawing.Size(106, 17)
        Me.etiquetaTotalBultos.TabIndex = 38
        Me.etiquetaTotalBultos.Text = "Total Packages"
        '
        'etiquetaTotalLibras
        '
        Me.etiquetaTotalLibras.AutoSize = True
        Me.etiquetaTotalLibras.Location = New System.Drawing.Point(567, 86)
        Me.etiquetaTotalLibras.Name = "etiquetaTotalLibras"
        Me.etiquetaTotalLibras.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaTotalLibras.TabIndex = 37
        Me.etiquetaTotalLibras.Text = "Total Pounds"
        '
        'celdaTotalBultos
        '
        Me.celdaTotalBultos.Location = New System.Drawing.Point(686, 108)
        Me.celdaTotalBultos.Name = "celdaTotalBultos"
        Me.celdaTotalBultos.Size = New System.Drawing.Size(100, 22)
        Me.celdaTotalBultos.TabIndex = 36
        '
        'celdaTotalLibras
        '
        Me.celdaTotalLibras.Location = New System.Drawing.Point(570, 108)
        Me.celdaTotalLibras.Name = "celdaTotalLibras"
        Me.celdaTotalLibras.Size = New System.Drawing.Size(100, 22)
        Me.celdaTotalLibras.TabIndex = 35
        '
        'celdaCantidad
        '
        Me.celdaCantidad.Location = New System.Drawing.Point(786, 0)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(132, 22)
        Me.celdaCantidad.TabIndex = 34
        Me.celdaCantidad.Text = "0"
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.BackColor = System.Drawing.SystemColors.Control
        Me.etiquetaCantidad.Location = New System.Drawing.Point(650, 3)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(134, 17)
        Me.etiquetaCantidad.TabIndex = 33
        Me.etiquetaCantidad.Text = "Quantity to Produce"
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(245, 61)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(98, 17)
        Me.etiquetaTasa.TabIndex = 32
        Me.etiquetaTasa.Text = "exchange rate"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(367, 58)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 22)
        Me.celdaTasa.TabIndex = 31
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(171, 102)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(38, 25)
        Me.botonMoneda.TabIndex = 6
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(146, 81)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(63, 22)
        Me.celdaIdMoneda.TabIndex = 30
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(85, 103)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(61, 22)
        Me.celdaMoneda.TabIndex = 29
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(11, 106)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 28
        Me.etiquetaMoneda.Text = "Coin"
        '
        'botonAnular
        '
        Me.botonAnular.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAnular.Image = CType(resources.GetObject("botonAnular.Image"), System.Drawing.Image)
        Me.botonAnular.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAnular.Location = New System.Drawing.Point(965, 41)
        Me.botonAnular.Name = "botonAnular"
        Me.botonAnular.Size = New System.Drawing.Size(78, 46)
        Me.botonAnular.TabIndex = 27
        Me.botonAnular.Text = "Anular"
        Me.botonAnular.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAnular.UseVisualStyleBackColor = True
        '
        'etiquetaInactivo
        '
        Me.etiquetaInactivo.AutoSize = True
        Me.etiquetaInactivo.BackColor = System.Drawing.Color.Red
        Me.etiquetaInactivo.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaInactivo.ForeColor = System.Drawing.Color.White
        Me.etiquetaInactivo.Location = New System.Drawing.Point(960, 41)
        Me.etiquetaInactivo.Name = "etiquetaInactivo"
        Me.etiquetaInactivo.Size = New System.Drawing.Size(128, 32)
        Me.etiquetaInactivo.TabIndex = 26
        Me.etiquetaInactivo.Text = "Anulada"
        Me.etiquetaInactivo.Visible = False
        '
        'celdaEntrada
        '
        Me.celdaEntrada.Location = New System.Drawing.Point(505, 1)
        Me.celdaEntrada.Name = "celdaEntrada"
        Me.celdaEntrada.Size = New System.Drawing.Size(56, 22)
        Me.celdaEntrada.TabIndex = 24
        Me.celdaEntrada.Visible = False
        '
        'celdaOrden
        '
        Me.celdaOrden.Location = New System.Drawing.Point(578, 65)
        Me.celdaOrden.Name = "celdaOrden"
        Me.celdaOrden.Size = New System.Drawing.Size(56, 22)
        Me.celdaOrden.TabIndex = 23
        Me.celdaOrden.Visible = False
        '
        'celdaIDTarea
        '
        Me.celdaIDTarea.Location = New System.Drawing.Point(578, 32)
        Me.celdaIDTarea.Name = "celdaIDTarea"
        Me.celdaIDTarea.Size = New System.Drawing.Size(56, 22)
        Me.celdaIDTarea.TabIndex = 22
        Me.celdaIDTarea.Visible = False
        '
        'celdaIdProyecto
        '
        Me.celdaIdProyecto.Location = New System.Drawing.Point(578, 0)
        Me.celdaIdProyecto.Name = "celdaIdProyecto"
        Me.celdaIdProyecto.Size = New System.Drawing.Size(56, 22)
        Me.celdaIdProyecto.TabIndex = 21
        Me.celdaIdProyecto.Visible = False
        '
        'celdaFecha
        '
        Me.celdaFecha.Location = New System.Drawing.Point(145, 30)
        Me.celdaFecha.Name = "celdaFecha"
        Me.celdaFecha.Size = New System.Drawing.Size(64, 22)
        Me.celdaFecha.TabIndex = 20
        Me.celdaFecha.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(505, 65)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(56, 22)
        Me.celdaEmpresa.TabIndex = 19
        Me.celdaEmpresa.Visible = False
        '
        'celdareferencia
        '
        Me.celdareferencia.Location = New System.Drawing.Point(367, 108)
        Me.celdareferencia.Name = "celdareferencia"
        Me.celdareferencia.Size = New System.Drawing.Size(100, 22)
        Me.celdareferencia.TabIndex = 18
        '
        'etiquetaReferencia
        '
        Me.etiquetaReferencia.AutoSize = True
        Me.etiquetaReferencia.Location = New System.Drawing.Point(245, 108)
        Me.etiquetaReferencia.Name = "etiquetaReferencia"
        Me.etiquetaReferencia.Size = New System.Drawing.Size(74, 17)
        Me.etiquetaReferencia.TabIndex = 17
        Me.etiquetaReferencia.Text = "Reference"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(85, 3)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(124, 22)
        Me.dtpFecha.TabIndex = 16
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(245, 8)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 8
        Me.etiquetaAnio.Text = "Year"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(41, 8)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 15
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(367, 5)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.Size = New System.Drawing.Size(100, 22)
        Me.celdaAnio.TabIndex = 9
        '
        'botonStop
        '
        Me.botonStop.Image = CType(resources.GetObject("botonStop.Image"), System.Drawing.Image)
        Me.botonStop.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonStop.Location = New System.Drawing.Point(965, 3)
        Me.botonStop.Name = "botonStop"
        Me.botonStop.Size = New System.Drawing.Size(78, 46)
        Me.botonStop.TabIndex = 14
        Me.botonStop.Text = "Stop"
        Me.botonStop.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonStop.UseVisualStyleBackColor = True
        Me.botonStop.Visible = False
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(11, 61)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 10
        Me.etiquetaNumero.Text = "Number"
        '
        'botonStart
        '
        Me.botonStart.Image = CType(resources.GetObject("botonStart.Image"), System.Drawing.Image)
        Me.botonStart.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonStart.Location = New System.Drawing.Point(965, 81)
        Me.botonStart.Name = "botonStart"
        Me.botonStart.Size = New System.Drawing.Size(78, 46)
        Me.botonStart.TabIndex = 13
        Me.botonStart.Text = "Start"
        Me.botonStart.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonStart.UseVisualStyleBackColor = True
        Me.botonStart.Visible = False
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(85, 58)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(124, 22)
        Me.celdaNumero.TabIndex = 11
        Me.celdaNumero.Text = "-1"
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(505, 32)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(56, 22)
        Me.celdaCatalogo.TabIndex = 12
        Me.celdaCatalogo.Text = "952"
        Me.celdaCatalogo.Visible = False
        '
        'botonEstimar
        '
        Me.botonEstimar.Image = Global.KARIMs_SGI.My.Resources.Resources.edit
        Me.botonEstimar.Location = New System.Drawing.Point(272, 12)
        Me.botonEstimar.Name = "botonEstimar"
        Me.botonEstimar.Size = New System.Drawing.Size(79, 53)
        Me.botonEstimar.TabIndex = 5
        Me.botonEstimar.Text = "Estimate"
        Me.botonEstimar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonEstimar.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 71)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1087, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1087, 71)
        Me.Encabezado1.TabIndex = 0
        '
        'frmProduccion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1087, 754)
        Me.Controls.Add(Me.botonEstimar)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmProduccion"
        Me.Text = "production"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.gbProducto.ResumeLayout(False)
        CType(Me.dgProducto, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelProducto.ResumeLayout(False)
        Me.panelProducto.PerformLayout()
        Me.gbCostosTiempo.ResumeLayout(False)
        CType(Me.dgCostos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelCostoTiempo.ResumeLayout(False)
        Me.panelCostoTiempo.PerformLayout()
        Me.gbCostosFijos.ResumeLayout(False)
        CType(Me.dgBultos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgCostoFijo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelCostoFijo.ResumeLayout(False)
        Me.PanelCostoFijo.PerformLayout()
        Me.panelTiempo.ResumeLayout(False)
        Me.panelTiempo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents botonStop As Button
    Friend WithEvents botonStart As Button
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents gbCostosTiempo As GroupBox
    Friend WithEvents dgCostos As DataGridView
    Friend WithEvents panelCostoTiempo As Panel
    Friend WithEvents botonCostoTiempo As Button
    Friend WithEvents etiquetaCostoTiemo As Label
    Friend WithEvents gbProducto As GroupBox
    Friend WithEvents dgProducto As DataGridView
    Friend WithEvents panelProducto As Panel
    Friend WithEvents botonProducto As Button
    Friend WithEvents etiquetaProduto As Label
    Friend WithEvents panelTiempo As Panel
    Friend WithEvents celdaEmpresa As TextBox
    Friend WithEvents celdareferencia As TextBox
    Friend WithEvents etiquetaReferencia As Label
    Friend WithEvents celdaFecha As TextBox
    Friend WithEvents etiquetaEliminar As Label
    Friend WithEvents botonEliminarProd As Button
    Friend WithEvents botonEliminarCosto As Button
    Friend WithEvents etiquetaEliminarCosto As Label
    Friend WithEvents celdaOrden As TextBox
    Friend WithEvents celdaIDTarea As TextBox
    Friend WithEvents celdaIdProyecto As TextBox
    Friend WithEvents celdaEntrada As TextBox
    Friend WithEvents etiquetaInactivo As Label
    Friend WithEvents botonAnular As Button
    Friend WithEvents botonConvertir As Button
    Friend WithEvents botonEstimar As Button
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaCantidad As Label
    Friend WithEvents celdaCantidad As TextBox
    Friend WithEvents gbCostosFijos As GroupBox
    Friend WithEvents dgCostoFijo As DataGridView
    Friend WithEvents PanelCostoFijo As Panel
    Friend WithEvents etiquetaCostoFijo As Label
    Friend WithEvents botonCostoFijo As Button
    Friend WithEvents etiquetaEliminarCostoFijo As Label
    Friend WithEvents botonEliminarCostoFijo As Button
    Friend WithEvents etiquetaTitulos As Label
    Friend WithEvents celdaHilo As TextBox
    Friend WithEvents botonSeleccion As Button
    Friend WithEvents celdaIdProducto As TextBox
    Friend WithEvents dgBultos As DataGridView
    Friend WithEvents colCodigoFijo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionFijo As DataGridViewTextBoxColumn
    Friend WithEvents colPorcentajeFijo As DataGridViewTextBoxColumn
    Friend WithEvents colMermaFijo As DataGridViewTextBoxColumn
    Friend WithEvents colCantidadFijo As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacion As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents col_AnioProd As DataGridViewTextBoxColumn
    Friend WithEvents col_CatalogoProd As DataGridViewTextBoxColumn
    Friend WithEvents col_NumeroProd As DataGridViewTextBoxColumn
    Friend WithEvents col_CodigoProd As DataGridViewTextBoxColumn
    Friend WithEvents col_LineaProd As DataGridViewTextBoxColumn
    Friend WithEvents col_DescripcionProd As DataGridViewTextBoxColumn
    Friend WithEvents col_ClasificacionProd As DataGridViewTextBoxColumn
    Friend WithEvents col_CostoProd As DataGridViewTextBoxColumn
    Friend WithEvents col_CantidadProd As DataGridViewTextBoxColumn
    Friend WithEvents col_ExtraProd As DataGridViewTextBoxColumn
    Friend WithEvents col_ParLineaProd As DataGridViewTextBoxColumn
    Friend WithEvents col_PorcentajeProd As DataGridViewTextBoxColumn
    Friend WithEvents col_TotalProd As DataGridViewTextBoxColumn
    Friend WithEvents col_IdMedidaProd As DataGridViewTextBoxColumn
    Friend WithEvents col_MedidaProd As DataGridViewTextBoxColumn
    Friend WithEvents col_VerificadorProd As DataGridViewTextBoxColumn
    Friend WithEvents col_ReferenciaProd As DataGridViewTextBoxColumn
    Friend WithEvents col_BultosProd As DataGridViewTextBoxColumn
    Friend WithEvents etiquetaTotalBultos As Label
    Friend WithEvents etiquetaTotalLibras As Label
    Friend WithEvents celdaTotalBultos As TextBox
    Friend WithEvents celdaTotalLibras As TextBox
    Friend WithEvents colCatalogoB As DataGridViewTextBoxColumn
    Friend WithEvents colAnioB As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroB As DataGridViewTextBoxColumn
    Friend WithEvents colLineaB As DataGridViewTextBoxColumn
    Friend WithEvents colBultoB As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDocumentoB As DataGridViewTextBoxColumn
    Friend WithEvents colExtraB As DataGridViewTextBoxColumn
    Friend WithEvents colPesoB As DataGridViewTextBoxColumn
    Friend WithEvents colMarcaB As DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativoB As DataGridViewTextBoxColumn
    Friend WithEvents colCategoriaB As DataGridViewTextBoxColumn
End Class
