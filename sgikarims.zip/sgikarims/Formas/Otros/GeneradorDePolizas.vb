﻿Public Class GeneradorDePolizas

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones

    Dim intEjercicioPoliza() As Integer
    Dim intNumeroPoliza() As Long


#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub LimpiarCampos()
        celdaDocumento.Clear()
        celdaCatalogo.Clear()
        dgDocumentos.Rows.Clear()
    End Sub

    Private Function VerificarPais()
        Dim intPais As Integer
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand

        strSql = " SELECT e.emp_pais FROM Empresas e WHERE e.emp_no = {empresa} "
        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        intPais = COM.ExecuteScalar

        Return intPais
    End Function

#End Region

#Region "Eventos"
    Private Sub GeneradorDePolizas_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        BarraTitulo1.CambiarTitulo("Generador de Polizas Contables")
        dtpInicio.Value = Today.AddMonths(-3)
        dtpFin.Value = Today
        If LogBorrar = True Then
            checkGenerar.Enabled = True
            checkGenerar.Checked = False
        Else
            checkGenerar.Enabled = False
            checkGenerar.Checked = False
        End If

    End Sub

    Private Sub botonDocumento_Click(sender As Object, e As EventArgs) Handles botonDocumento.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        LimpiarCampos()

        Try
            strTabla = " {conta}.polizas p LEFT JOIN Catalogos c ON c.cat_num = p.ref_tipo"
            strTabla = Replace(strTabla, "{conta}", cFunciones.ContaEmpresa)

            strCondicion = " p.empresa = {empresa} AND p.ref_tipo >0 "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

            frm.Titulo = "Tipo de Documento"
            frm.Campos = " DISTINCT(p.ref_tipo), c.cat_desc "
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            frm.FiltroText = " Ingrese el nombre del Documento"
            frm.Filtro = " c.cat_desc"
            frm.Ordenamiento = " p.ref_tipo"
            frm.TipoOrdenamiento = "ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaCatalogo.Text = frm.LLave
                celdaDocumento.Text = frm.Dato
            End If

        Catch ex As Exception
            ex.ToString()
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strCampos As String = STR_VACIO
        Dim strNumeroDoc As String = STR_VACIO
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim intPais As Integer
        Dim strFiltro As String
        Dim strFila As String = STR_VACIO
        Dim strOC_Serv As String = STR_VACIO

        If celdaCatalogo.Text = STR_VACIO Then
            MsgBox("Debe Seleccionar el tipo de Documento", vbInformation, "Aviso")
            botonDocumento.Focus()
            Exit Sub
        End If
        intPais = VerificarPais()

        Try
            If (Sesion.IdEmpresa = 12 And intPais = 0) Or (Sesion.IdEmpresa = 3 And intPais = 0) Or (Sesion.IdEmpresa = 9 And intPais = 0) Or (Sesion.IdEmpresa = 10 And intPais = 0) Then 'Hilos
                If celdaCatalogo.Text = 31 Or celdaCatalogo.Text = 32 Or celdaCatalogo.Text = 36 Or celdaCatalogo.Text = 39 Or celdaCatalogo.Text = 47 Or celdaCatalogo.Text = 950 Or celdaCatalogo.Text = 689 Then
                    strNumeroDoc = "h.HDoc_Doc_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 51 Or celdaCatalogo.Text = 52 Or celdaCatalogo.Text = 53 Or celdaCatalogo.Text = 54 Or celdaCatalogo.Text = 220 Or celdaCatalogo.Text = 326 Then
                    strNumeroDoc = "h.HDoc_DR1_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 44 Or celdaCatalogo.Text = 209 Then
                    strNumeroDoc = "CONCAT(h.HDoc_DR1_Num,' ',h.HDoc_DR2_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                ElseIf celdaCatalogo.Text = 246 Then
                    strNumeroDoc = "CONCAT('Caja # ', h.HDoc_DR1_Cat,' - Liquidacion # ',h.HDoc_DR1_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                End If
            ElseIf Sesion.IdEmpresa = 11 Then 'Pride yarn
                If celdaCatalogo.Text = 31 Or celdaCatalogo.Text = 32 Or celdaCatalogo.Text = 51 Or celdaCatalogo.Text = 52 Or celdaCatalogo.Text = 53 Or celdaCatalogo.Text = 54 Or celdaCatalogo.Text = 220 Or celdaCatalogo.Text = 326 Then
                    strNumeroDoc = "h.HDoc_DR1_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 39 Or celdaCatalogo.Text = 47 Or celdaCatalogo.Text = 950 Or celdaCatalogo.Text = 689 Then
                    strNumeroDoc = "h.HDoc_Doc_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 36 Then
                    strNumeroDoc = "h.HDoc_DR1_Dbl"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 44 Or celdaCatalogo.Text = 209 Then
                    strNumeroDoc = "CONCAT(h.HDoc_DR1_Num,' ',h.HDoc_DR2_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                ElseIf celdaCatalogo.Text = 246 Then
                    strNumeroDoc = "CONCAT('Caja # ', h.HDoc_DR1_Cat,' - Liquidacion # ',h.HDoc_DR1_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                End If
            ElseIf (Sesion.IdEmpresa = 12 And intPais = 310) Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Then
                If celdaCatalogo.Text = 31 Or celdaCatalogo.Text = 32 Or celdaCatalogo.Text = 39 Or celdaCatalogo.Text = 47 Or celdaCatalogo.Text = 296 Or celdaCatalogo.Text = 950 Or celdaCatalogo.Text = 689 Then
                    strNumeroDoc = "h.HDoc_Doc_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 36 Or celdaCatalogo.Text = 51 Or celdaCatalogo.Text = 52 Or celdaCatalogo.Text = 53 Or celdaCatalogo.Text = 54 Or celdaCatalogo.Text = 220 Or celdaCatalogo.Text = 326 Then
                    strNumeroDoc = "h.HDoc_DR1_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 44 Or celdaCatalogo.Text = 209 Then
                    strNumeroDoc = "CONCAT(h.HDoc_DR1_Num,' ',h.HDoc_DR2_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                ElseIf celdaCatalogo.Text = 246 Then
                    strNumeroDoc = "CONCAT('Caja # ', h.HDoc_DR1_Cat,' - Liquidacion # ',h.HDoc_DR1_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                End If
            ElseIf Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                If celdaCatalogo.Text = 31 Or celdaCatalogo.Text = 32 Or celdaCatalogo.Text = 39 Or celdaCatalogo.Text = 47 Or celdaCatalogo.Text = 950 Or celdaCatalogo.Text = 689 Or celdaCatalogo.Text = 952 Or celdaCatalogo.Text = 48 Then
                    strNumeroDoc = "h.HDoc_Doc_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 51 Or celdaCatalogo.Text = 52 Or celdaCatalogo.Text = 53 Or celdaCatalogo.Text = 54 Or celdaCatalogo.Text = 220 Or celdaCatalogo.Text = 326 Then
                    strNumeroDoc = "h.HDoc_DR1_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 44 Or celdaCatalogo.Text = 209 Then
                    strNumeroDoc = "CONCAT(h.HDoc_DR1_Num,' ',h.HDoc_DR2_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                ElseIf celdaCatalogo.Text = 246 Or celdaCatalogo.Text = 36 Then
                    strNumeroDoc = "CONCAT('Caja # ', h.HDoc_DR1_Cat,' - Liquidacion # ',h.HDoc_DR1_Num)"
                ElseIf celdaCatalogo.Text = 691 Then
                    strNumeroDoc = "h.HDoc_DR1_Dbl"
                    strFiltro = strNumeroDoc
                    strFiltro = "h.HDoc_DR1_Num"
                End If
            ElseIf Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                If celdaCatalogo.Text = 31 Or celdaCatalogo.Text = 32 Or celdaCatalogo.Text = 39 Or celdaCatalogo.Text = 47 Or celdaCatalogo.Text = 950 Or celdaCatalogo.Text = 689 Or celdaCatalogo.Text = 952 Or celdaCatalogo.Text = 48 Then
                    strNumeroDoc = "h.HDoc_Doc_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 51 Or celdaCatalogo.Text = 52 Or celdaCatalogo.Text = 53 Or celdaCatalogo.Text = 54 Or celdaCatalogo.Text = 220 Or celdaCatalogo.Text = 326 Then
                    strNumeroDoc = "h.HDoc_DR1_Num"
                    strFiltro = strNumeroDoc
                ElseIf celdaCatalogo.Text = 44 Or celdaCatalogo.Text = 209 Then
                    strNumeroDoc = "CONCAT(h.HDoc_DR1_Num,' ',h.HDoc_DR2_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                ElseIf celdaCatalogo.Text = 246 Then
                    strNumeroDoc = "CONCAT('Caja # ', h.HDoc_DR1_Cat,' - Liquidacion # ',h.HDoc_DR1_Num)"
                    strFiltro = "h.HDoc_DR1_Num"
                ElseIf celdaCatalogo.Text = 691 Or celdaCatalogo.Text = 36 Then
                    strNumeroDoc = "h.HDoc_DR1_Dbl"
                    strFiltro = strNumeroDoc
                End If

            End If

            strCampos = " s1.fecha fecha, s1.numero numero, s1.Descripcion Descripcion, s1.anio anio, s1.HDoc_Doc_Num HDoc_Doc_Num "

            strTabla = " ( Select h.HDoc_Doc_Fec fecha, {NumDoc} numero, IFNULL(h.HDoc_Emp_Nom,'') Descripcion, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num "
            strTabla &= " From Dcmtos_HDR h "
            strTabla &= " Where h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Fec BETWEEN '{Finicio}' AND '{Ffin}')s1 "
            strTabla = Replace(strTabla, "{empresa}", Sesion.IdEmpresa)
            If celdaCatalogo.Text = 44 Then
                strTabla = Replace(strTabla, "{cat}", celdaCatalogo.Text & " AND NOT (HDoc_RF1_Cod=1 AND HDoc_DR1_Emp=3) ")
            Else
                strTabla = Replace(strTabla, "{cat}", celdaCatalogo.Text)
            End If

            strTabla = Replace(strTabla, "{Finicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strTabla = Replace(strTabla, "{Ffin}", dtpFin.Value.ToString(FORMATO_MYSQL))
            strTabla = Replace(strTabla, "{NumDoc}", strNumeroDoc)

            frm.Titulo = "Documentos"
            frm.Multiple = True
            frm.Campos = strCampos
            frm.Tabla = strTabla
            frm.Condicion = "s1.HDoc_Doc_Num >= 1"
            frm.FiltroText = " Ingrese el numero de Documento"
            frm.Filtro = "s1.numero"
            frm.Limite = 50

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                For i As Integer = 0 To frm.DataGrid.Rows.Count - 1
                    If frm.DataGrid.Rows(i).Cells("colCheck").Value = True Then
                        strFila = frm.ListaClientes.Rows(i).Cells(4).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(5).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(1).Value & "|"
                        strFila &= frm.ListaClientes.Rows(i).Cells(2).Value

                        cFunciones.AgregarFila(dgDocumentos, strFila)
                    End If
                Next
            End If

        Catch ex As Exception
            ex.ToString()
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        dgDocumentos.Rows.Remove(dgDocumentos.CurrentRow)
    End Sub

    Private Sub botonGenerador_Click(sender As Object, e As EventArgs) Handles botonGenerador.Click
        If checkGenerar.Checked = False Then
            If dgDocumentos.Rows.Count = 0 Then
                MsgBox("Debe Seleccionar Documentos Primero", vbInformation, "Aviso")
                botonAgregar.Focus()
                Exit Sub
            End If

            If MsgBox("¿Está seguro que desea generar las polizas contables de estos documentos?", vbQuestion + vbYesNo, "Consulta") = vbYes Then
                Dim Contabilidad As New clsContabilidad
                Dim PolizasBancos As New clsBPoliza
                Dim rpt As New clsReportes
                Dim strSQL As String = STR_VACIO

                Dim frmMsj As New frmMensaje
                frmMsj.Mensaje = "Generando Polizas"
                frmMsj.Show()
                System.Windows.Forms.Application.DoEvents()
                Dim dtFechaConta As Date
                Dim boolValidaCierre As Boolean = False

                For i As Integer = 0 To dgDocumentos.Rows.Count - 1
                    ' Captura la fecha
                    dtFechaConta = cfun.SQLValidarFechaContable(celdaCatalogo.Text, dgDocumentos.Rows(i).Cells("colAnio").Value, dgDocumentos.Rows(i).Cells("colHDoc_Doc_Num").Value)
                    'Verifica si existe cierre (0 --> no hay cierre)
                    If boolValidaCierre = True Then
                        GenerarPolizas(i, dtFechaConta.ToString(FORMATO_MYSQL))
                    ElseIf cfun.SQLVerificarCierre(celdaCatalogo.Text, dgDocumentos.Rows(i).Cells("colAnio").Value, dgDocumentos.Rows(i).Cells("colHDoc_Doc_Num").Value) = 0 Then
                        GenerarPolizas(i, dtFechaConta.ToString(FORMATO_MYSQL))
                    Else
                        'Si hay cierre solicita autorización
                        MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                        If cFunciones.AutorizarCambios = True Then
                            boolValidaCierre = True
                            GenerarPolizas(i, dtFechaConta.ToString(FORMATO_MYSQL))
                        End If

                    End If

                Next
                rpt.ImprimirPolizasCierre(intEjercicioPoliza, intNumeroPoliza)
                dgDocumentos.Rows.Clear()
                frmMsj.Close()
            End If
        Else
            If celdaCatalogo.Text = STR_VACIO Then
                MsgBox("Debe Seleccionar el tipo de Documento", vbInformation, "Aviso")
                botonDocumento.Focus()
                Exit Sub
            End If
            If MsgBox("¿Está seguro que desea generar las polizas contables de estos documentos?", vbQuestion + vbYesNo, "Consulta") = vbYes Then
                GenerarPolizas()
                MsgBox("Polizas Generadas correctamente", vbInformation)
            End If

        End If

    End Sub

    Private Sub GenerarPolizas(Optional j As Integer = 0, Optional fec As Date = Nothing)
        Dim Contabilidad As New clsContabilidad
        Dim PolizasBancos As New clsBPoliza
        Dim rpt As New clsReportes
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        'Verifica si las polizas a generar son documentos de Bancos o no
        If celdaCatalogo.Text = 51 Or celdaCatalogo.Text = 52 Or celdaCatalogo.Text = 53 Or celdaCatalogo.Text = 54 Then ' Documentos generados de Bancos
            MyCnn.CONECTAR = strConexion
            ' Regeneración Masiva
            If checkGenerar.Checked = True Then
                PolizasBancos.ProcesarDocumento(celdaCatalogo.Text, 0, 0, fec.ToString(FORMATO_MYSQL), dtpInicio.Value, dtpFin.Value)
            Else
                PolizasBancos.ProcesarDocumento(celdaCatalogo.Text, dgDocumentos.Rows(j).Cells("colAnio").Value, dgDocumentos.Rows(j).Cells("colHDoc_Doc_Num").Value, fec.ToString(FORMATO_MYSQL))
            End If

        Else
            If checkGenerar.Checked = True Then
                Contabilidad.GenerarPoliza(celdaCatalogo.Text, 0, 0, fec.ToString(FORMATO_MYSQL), dtpInicio.Value, dtpFin.Value)
            Else
                Contabilidad.GenerarPoliza(celdaCatalogo.Text, dgDocumentos.Rows(j).Cells("colAnio").Value, dgDocumentos.Rows(j).Cells("colHDoc_Doc_Num").Value, fec.ToString(FORMATO_MYSQL))
            End If

        End If

        If checkGenerar.Checked = False Then
            strSQL = STR_VACIO
            ReDim Preserve intEjercicioPoliza(j)
            ReDim Preserve intNumeroPoliza(j)
            ' VERIFICA EL NUMERO DE POLIZA QUE GENERA PARA LOS DOCUMENTOS SELECCIONADOS
            strSQL = " SELECT p.ejercicio,p.poliza "
            strSQL &= "    From {conta}.polizas p "
            strSQL &= "    Where p.empresa = {emp} And p.ref_tipo = {cat} And p.ref_ciclo = {anio} And p.ref_numero = {num} "

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            strSQL = Replace(strSQL, "{cat}", celdaCatalogo.Text)
            strSQL = Replace(strSQL, "{anio}", dgDocumentos.Rows(j).Cells("colAnio").Value)
            strSQL = Replace(strSQL, "{num}", dgDocumentos.Rows(j).Cells("colHDoc_Doc_Num").Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read()
                    intEjercicioPoliza(j) = REA.GetInt32("ejercicio")
                    intNumeroPoliza(j) = REA.GetInt32("poliza")
                Loop

            End If
        End If

    End Sub

    Private Sub botonCerrar_Click(sender As Object, e As EventArgs) Handles botonCerrar.Click
        Me.Close()
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

#End Region

End Class