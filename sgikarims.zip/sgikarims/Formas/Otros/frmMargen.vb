﻿Public Class frmMargen

#Region "Miembros"
    Dim strKey As String = STR_VACIO
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub Reset()
        celdaVentas.Text = 0
        celdacostosOperacion.Text = INT_CERO
        celdaCostoVentas.Text = INT_CERO
        celdaDescuentos.Text = INT_CERO
        celdaDevoluciones.Text = INT_CERO
        TextBox6.Text = INT_CERO
        celdaProyeccionCostos.Text = 0
        celdaProyeccionMB.Text = 0
        celdaProyeccionVentas.Text = 0
        celdaMargenOperativo.Text = 0
        celdaMargenOpatativoProyeccion.Text = 0
        celdaMargenBruto.Text = 0
        celdaMargenBrutoProyeccion.Text = 0
        celdaIndicadorMO.Text = 0
        celdaIndicadorRealMB.Text = 0
        celdaIndicadorRealMO.Text = 0


    End Sub

    Private Function sqlProyeccionNoImpresas(ByVal intPeriodo As Integer, ByVal fecha As Date) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num fact, (ROUND(SUM(d.DDoc_Prd_QTY * d.DDoc_Prd_NET),2)) venta, (ROUND(SUM(d.DDoc_Prd_QTY * n.DDoc_Prd_NET),2)) costo"
        strSQL &= "  FROM Dcmtos_HDR h"
        strSQL &= "      LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQL &= "          LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strSQL &= "              LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat = p.PDoc_Par_Cat AND i.PDoc_Chi_Ano = p.PDoc_Par_Ano AND i.PDoc_Chi_Num = p.PDoc_Par_Num AND i.PDoc_Chi_Lin = p.PDoc_Par_Lin AND i.PDoc_Par_Cat = 47"
        strSQL &= "                  LEFT JOIN Dcmtos_DTL n ON n.DDoc_Sis_Emp = i.PDoc_Sis_Emp AND n.DDoc_Doc_Cat = i.PDoc_Par_Cat AND n.DDoc_Doc_Ano = i.PDoc_Par_Ano AND n.DDoc_Doc_Num = i.PDoc_Par_Num AND n.DDoc_Doc_Lin = i.PDoc_Par_Lin"
        strSQL &= "                      WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Status = 1  AND h.HDoc_Doc_Fec <= '{fecha}' AND"
        strSQL &= "                  ("
        strSQL &= "              SELECT COUNT(*)"
        strSQL &= "          FROM contahilos.polizas p"
        strSQL &= "      WHERE p.empresa = h.HDoc_Sis_Emp AND p.ref_tipo = h.HDoc_Doc_Cat AND p.ref_ciclo = h.HDoc_Doc_Ano AND p.ref_numero = h.HDoc_Doc_Num ) =0"
        strSQL &= "   GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", cFunciones.AñoMySQL)
        strSQL = Replace(strSQL, "{cat}", 36)
        strSQL = Replace(strSQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function

    Private Function sqlDatosCalculos(ByVal intPeriodo As Integer, ByVal fecha As Date) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT cc.nombre, ROUND(ABS(IFNULL((SUM(IF(d.operacion = 'C', d.importe, 0))) - (SUM(IF(d.operacion = 'A', d.importe, 0))),0)),2) ventas"
        strSQL &= "     FROM contahilos.polizas p"
        strSQL &= "         LEFT JOIN contahilos.detalle_polizas d ON d.empresa = p.empresa AND d.ejercicio = p.ejercicio AND p.poliza = d.poliza"
        strSQL &= "             INNER JOIN contahilos.cuentas c ON c.id_cuenta = d.cuenta AND c.empresa = d.empresa AND c.pid IN ('0402001', '0402002','0401', '0501', '0502', '0503001')"
        strSQL &= "         LEFT JOIN contahilos.cuentas cc ON cc.id_cuenta = c.pid AND cc.empresa = c.empresa"
        strSQL &= "     WHERE p.empresa = {empresa} AND p.ejercicio = {ejercicio} AND p.fecha <= '{fecha}' AND d.cuenta NOT IN('0502046', '0502021')"
        strSQL &= "GROUP BY c.pid"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ejercicio}", intPeriodo)
        strSQL = Replace(strSQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))

        Return strSQL
    End Function

    Private Sub CargarDatos(ByVal intPeriodo As Integer, ByVal fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = sqlDatosCalculos(intPeriodo, fecha)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            Do While REA.Read()

                If REA.GetString("nombre") = "VENTAS" Then
                    celdaVentas.Text = REA.GetDouble("ventas").ToString(FORMATO_MONEDA)
                ElseIf REA.GetString("nombre") = "Descuentos" Then
                    celdaDescuentos.Text = REA.GetDouble("ventas").ToString(FORMATO_MONEDA)
                ElseIf REA.GetString("nombre") = "Devoluciones" Then
                    celdaDevoluciones.Text = REA.GetDouble("ventas").ToString(FORMATO_MONEDA)
                ElseIf REA.GetString("nombre") = "COSTO DE VENTAS" Then
                    celdaCostoVentas.Text = REA.GetDouble("ventas").ToString(FORMATO_MONEDA)
                ElseIf REA.GetString("nombre") = "GASTOS DE OPERACIÓN" Then
                    celdacostosOperacion.Text = REA.GetDouble("ventas").ToString(FORMATO_MONEDA)
                End If
            Loop
        End If

    End Sub

    Private Function CargarFactSinPoliza(ByVal intPeriodo As Integer, ByVal fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = sqlProyeccionNoImpresas(intPeriodo, fecha)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            Do While REA.Read
                strFila = REA.GetString("fact") & "|"
                strFila &= REA.GetDateTime("fecha") & "|"
                strFila &= REA.GetDouble("venta") & "|"
                strFila &= REA.GetDouble("costo")

                cFunciones.AgregarFila(dgFactSinPoliza, strFila)
            Loop
        End If

    End Function

    Private Sub ValidarEjercicio()
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        Try
            strSQL = " SELECT IFNULL(ej.ejercicio,'X') estado, YEAR(e.inicio) anio
                            FROM contahilos.ejercicios e
                            LEFT JOIN contahilos.ejercicio_empresa ej ON ej.ejercicio = e.ejercicio AND ej.empresa = {emp}
                            WHERE '{fecha}' BETWEEN e.inicio AND e.fin "
            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{fecha}", Today.ToString(FORMATO_MYSQL))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    celdaAnio.Text = REA.GetInt32("anio")
                    celdaPeriodo.Text = REA.GetString("estado")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Eventos"

    Private Sub frmMargen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reset()
        ValidarEjercicio()
        dtpFecha.Value = Today.ToString(FORMATO_MYSQL)
        CargarDatos(celdaPeriodo.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
        CargarFactSinPoliza(celdaPeriodo.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
        CalculoProyeccionTotales()
        CalculoProyeccion()
    End Sub

    Private Sub botonDatosInventario_Click(sender As Object, e As EventArgs) Handles botonDatosInventario.Click
        Reset()
        dgFactSinPoliza.Rows.Clear()
        CargarDatos(celdaPeriodo.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
        CargarFactSinPoliza(celdaPeriodo.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
        CalculoProyeccionTotales()
        CalculoProyeccion()
    End Sub

    Private Sub CalculoProyeccionTotales()
        Dim i As Integer = INT_CERO
        Dim j As Integer = INT_CERO
        Dim dblVentas As Double
        Dim dblTotalVentas As Double
        Dim dblCostos As Double
        Dim dblTotalCostos As Double

        For i = 0 To dgFactSinPoliza.Rows.Count - 1
            dblVentas = dgFactSinPoliza.Rows(i).Cells("colVenta").Value
            dblTotalVentas = dblTotalVentas + dblVentas
        Next


        For i = 0 To dgFactSinPoliza.Rows.Count - 1
            dblCostos = dgFactSinPoliza.Rows(i).Cells("colCosto").Value
            dblTotalCostos = dblTotalCostos + dblCostos
        Next

        'Carga el dato de Proyeccion de Ventas
        celdaProyeccionVentas.Text = dblTotalVentas
        celdaTotalVentas.Text = dblTotalVentas

        'Carga el dato de Proyeccion de Costos
        celdaProyeccionCostos.Text = dblTotalCostos
        celdaTotalCostos.Text = dblTotalCostos

    End Sub

    Private Sub CalculoProyeccion()
        Dim dblMargenBruto As Double
        Dim dblRestaMargenBruto As Double
        Dim dblProyeccionMargenBruto As Double
        Dim dblProyeccionRestaMargenBruto As Double
        Dim dblMargenOperativo As Double
        Dim dblProyeccionMargenOperativo As Double
        Dim dblIndicadorMB As Double
        Dim dblRestaIndicadorMB As Double
        Dim dblIndicadorMBP As Double
        Dim dblRestaIndicadorMBP As Double
        Dim dblIndicadorMO As Double
        Dim dblRestaIndicadorMO As Double
        Dim dblIndicadorMOP As Double
        Dim dblRestaIndicadorMOP As Double

        'Proceso de Margen Bruto
        dblRestaMargenBruto = (CDbl(celdaDescuentos.Text) + CDbl(celdaDevoluciones.Text) + CDbl(celdaCostoVentas.Text))
        dblMargenBruto = CDbl(celdaVentas.Text).ToString(FORMATO_MONEDA) - dblRestaMargenBruto.ToString(FORMATO_MONEDA)
        celdaMargenBruto.Text = CDbl(dblMargenBruto).ToString(FORMATO_MONEDA)


        'Proceso de  Proyeccion Margen Bruto
        dblProyeccionRestaMargenBruto = (CDbl(celdaDescuentos.Text) + CDbl(celdaDevoluciones.Text) + CDbl(celdaCostoVentas.Text) + CDbl(celdaProyeccionCostos.Text))
        dblProyeccionMargenBruto = (CDbl(celdaVentas.Text).ToString(FORMATO_MONEDA) + CDbl(celdaProyeccionVentas.Text)) - dblProyeccionRestaMargenBruto.ToString(FORMATO_MONEDA)
        celdaMargenBrutoProyeccion.Text = CDbl(dblProyeccionMargenBruto).ToString(FORMATO_MONEDA)


        'Proceso de Margen Operativo
        dblMargenOperativo = ((celdaMargenBruto.Text) - CDbl(celdacostosOperacion.Text))
        celdaMargenOperativo.Text = CDbl(dblMargenOperativo).ToString(FORMATO_MONEDA)


        'Proceso de Margen Operativo
        dblProyeccionMargenOperativo = ((celdaMargenBrutoProyeccion.Text) - CDbl(celdacostosOperacion.Text))
        celdaMargenOpatativoProyeccion.Text = CDbl(dblProyeccionMargenOperativo).ToString(FORMATO_MONEDA)

        'Calculo Indicador Margen Bruto Real
        dblRestaIndicadorMB = (CDbl(celdaVentas.Text) - CDbl(celdaDevoluciones.Text) - CDbl(celdaDescuentos.Text))
        dblIndicadorMB = (CDbl(celdaMargenBruto.Text) / dblRestaIndicadorMB)
        celdaIndicadorRealMB.Text = CDbl(dblIndicadorMB * 100).ToString(FORMATO_MONEDA)

        If CDbl(dblIndicadorMB * 100) < 3.5 Then
            celdaIndicadorRealMB.BackColor = Color.Red
            celdaIndicadorRealMB.ForeColor = Color.Black
        ElseIf CDbl(dblIndicadorMB * 100).ToString(FORMATO_MONEDA) > 3.75 Then
            celdaIndicadorRealMB.BackColor = Color.Red
            celdaIndicadorRealMB.ForeColor = Color.Black
        Else
            celdaIndicadorRealMB.BackColor = Color.Green
            celdaIndicadorRealMB.ForeColor = Color.Black
        End If

        'Calculo Indicador Margen Bruto Proyeccion
        dblRestaIndicadorMBP = (CDbl(celdaVentas.Text) - CDbl(celdaDevoluciones.Text) - CDbl(celdaDescuentos.Text))
        dblIndicadorMBP = (CDbl(celdaMargenBrutoProyeccion.Text) + CDbl(celdaProyeccionVentas.Text))
        dblIndicadorMBP = CDbl(dblIndicadorMBP.ToString(FORMATO_MONEDA) / dblRestaIndicadorMBP.ToString(FORMATO_MONEDA))
        celdaProyeccionMB.Text = CDbl(dblIndicadorMBP * 100).ToString(FORMATO_MONEDA)

        If CDbl(dblIndicadorMBP * 100) < 3.5 Then
            celdaProyeccionMB.BackColor = Color.Red
            celdaProyeccionMB.ForeColor = Color.Black
        ElseIf CDbl(dblIndicadorMBP * 100) > 3.75 Then
            celdaProyeccionMB.BackColor = Color.Red
            celdaProyeccionMB.ForeColor = Color.Black
        Else
            celdaProyeccionMB.BackColor = Color.Green
            celdaProyeccionMB.ForeColor = Color.Black
        End If


        'Calculo Indicador Margen Operativo Real
        dblRestaIndicadorMO = (CDbl(celdaVentas.Text) - CDbl(celdaDevoluciones.Text) - CDbl(celdaDescuentos.Text))
        dblIndicadorMO = (CDbl(dblProyeccionMargenOperativo) / CDbl(dblRestaIndicadorMO))
        celdaIndicadorRealMO.Text = CDbl(dblIndicadorMO * 100).ToString(FORMATO_MONEDA)

        If CDbl(dblIndicadorMO * 100) < 3.5 Then
            celdaIndicadorRealMO.BackColor = Color.Red
            celdaIndicadorRealMO.ForeColor = Color.Black
        ElseIf CDbl(dblIndicadorMO * 100) > 3.75 Then
            celdaIndicadorRealMO.BackColor = Color.Red
            celdaIndicadorRealMO.ForeColor = Color.Black
        Else
            celdaIndicadorRealMO.BackColor = Color.Green
            celdaIndicadorRealMO.ForeColor = Color.Black
        End If


        'Calculo Indicador Margen Operativo Proyeccion
        dblRestaIndicadorMOP = ((CDbl(celdaVentas.Text) + CDbl(celdaProyeccionVentas.Text)) - CDbl(celdaDevoluciones.Text) - CDbl(celdaDescuentos.Text))
        dblIndicadorMOP = (CDbl(dblProyeccionMargenOperativo) / CDbl(dblRestaIndicadorMOP))
        celdaIndicadorMO.Text = CDbl(dblIndicadorMOP * 100).ToString(FORMATO_MONEDA)

        If CDbl(dblIndicadorMOP * 100) < 3.5 Then
            celdaIndicadorMO.BackColor = Color.Red
            celdaIndicadorMO.ForeColor = Color.Black
        ElseIf CDbl(dblIndicadorMOP * 100) > 3.75 Then
            celdaIndicadorMO.BackColor = Color.Red
            celdaIndicadorMO.ForeColor = Color.Black
        Else
            celdaIndicadorMO.BackColor = Color.Green
            celdaIndicadorMO.ForeColor = Color.Black
        End If
    End Sub


    Private Sub botonPeriodo_Click(sender As Object, e As EventArgs) Handles botonPeriodo.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " YEAR(e.inicio) Year_, e.descripcion fiscal_year,e.ejercicio Id"
            frm.Tabla = cFunciones.ContaEmpresa & ".ejercicios e"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Condicion = " e.ejercicio <> 0"
            frm.Filtro = "e.ejercicio"
            frm.Ordenamiento = "e.ejercicio"
            frm.TipoOrdenamiento = "DESC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaAnio.Text = frm.LLave
                celdaPeriodo.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

#End Region

End Class