﻿Public Class frmEstimacion
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim tbl_Documento As String = "Dcmtos_HDR"

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Function SQLCargarDetalle()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select cat_num Tipo, cat_clave Descripcion "
        strSQL &= "    From Catalogos c "
        strSQL &= "            Where c.cat_clase = 'Gastos' "

        Return strSQL
    End Function

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select h.Est_Id id, h.Est_Fecha fecha, h.Est_Observacion Observacion, h.Est_Usuario usuario, h.Estatus, h.Est_Anio Anio "
        strSQL &= "    From Estimacion_HDR h "
        strSQL &= "        Where h.Est_Empresa = {empresa} "
        If checkFecha.Checked = True Then

            strSQL &= " AND (h.Est_Fecha BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function


    Private Function SQLEncabezado(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " Select h.Est_Id id, h.Est_Anio anio, h.Est_Fecha fecha, h.Estatus estado, h.Est_IdMoneda moneda, h.Est_TCMoneda TC, h.Est_Observacion observacion, c.cat_clave signo, h.Est_Capacidad Cap "
        strSQL &= "    From Estimacion_HDR h "
        strSQL &= "        Left Join Catalogos c on c.cat_num = h.Est_IdMoneda "
        strSQL &= "            Where "
        strSQL &= "                h.Est_Empresa = {empresa} and h.Est_Id = {num} and h.Est_Anio = {anio} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{anio}", anio)

        Return strSQL
    End Function

    Private Function SQLCargarDatos(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " Select d.DEst_Anio anio, d.DEst_Numero num, d.DEst_Linea linea, d.DEst_Fase fase, d.DEst_IdGasto CGasto, d.DEst_Net Estimacion, c.cat_clave descripcion "
        strSQL &= "    From Estimacion_DTL d "
        strSQL &= "        Left Join Catalogos c On c.cat_num = d.DEst_IdGasto "
        strSQL &= "            Where d.DEst_Empresa = {empresa} and d.DEst_Numero = {num} and d.DEst_Anio = {anio} "
        strSQL &= "                Order By d.DEst_Fase "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{num}", num)
        strSQL = Replace(strSQL, "{anio}", anio)

        Return strSQL
    End Function

    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub

    Public Sub ColocaMoneda()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection

        strSQL = "SELECT c.cat_clave Moneda, c.cat_num ID, c.cat_sist FROM Catalogos c WHERE cat_clase='Monedas' and c.cat_num = 178"

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            REA.Read()
            celdaMoneda.Text = REA.GetString("Moneda")
            celdaIdMoneda.Text = REA.GetInt32("ID")
            celdaTasa.Text = REA.GetDouble("cat_sist")
        End If
        conec.Close()
    End Sub

    Private Sub LimpiarCampos()
        celdaNumero.Text = -1
        celdaMoneda.Clear()
        celdaIdMoneda.Clear()
        celdaTasa.Clear()
        dtpFecha.Text = cfun.HoyMySQL
        celdaFecha.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        celdaAnio.Text = cfun.AñoMySQL
        celdaObservacion.Clear()
        celdaCapacidad.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaEstado.Clear()

    End Sub

    Private Function ActualizarStatus()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try
            strSQL = " UPDATE Estimacion_HDR h SET h.Estatus = 0 "
            strSQL &= "    WHERE h.Est_Empresa = {empresa} AND h.Estatus = 1 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Using conec
            Return COM.ExecuteNonQuery()
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            panelDetalle.Visible = False
            panelDetalle.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Estimate")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False


            dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
            dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            ListaPrincipal()

        Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDetalle.Visible = True
            panelDetalle.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Estimate")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Estimate")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                LimpiarCampos()
                CargarDetalleF1()
                CargarDetalleF2()
                ColocaMoneda()
            End If

        End If

    End Sub

    Private Sub CargarDetalleF1()
        Dim strsql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim i As Integer = 0

        strsql = SQLCargarDetalle()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgEstimacionF1.Rows.Clear()
                Do While REA.Read
                    i = i + 1
                    strFila = REA.GetInt32("Tipo") & "|"
                    strFila &= i & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= INT_CERO.ToString(FORMATO_MONEDA)

                    cFunciones.AgregarFila(dgEstimacionF1, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalleF2()
        Dim strsql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim i As Integer = 0

        strsql = SQLCargarDetalle()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgEstimacionF2.Rows.Clear()
                Do While REA.Read
                    i = i + 1
                    strFila = REA.GetInt32("Tipo") & "|"
                    strFila &= i & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= INT_CERO.ToString(FORMATO_MONEDA)

                    cFunciones.AgregarFila(dgEstimacionF2, strFila)
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub CargarEncabezado(ByVal Numero As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLEncabezado(Numero, anio)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                celdaNumero.Text = REA.GetInt32("id")
                dtpFecha.Text = REA.GetDateTime("fecha")
                celdaFecha.Text = REA.GetDateTime("fecha")
                celdaMoneda.Text = REA.GetString("signo")
                celdaIdMoneda.Text = REA.GetString("moneda")
                celdaTasa.Text = REA.GetDouble("TC")
                celdaAnio.Text = REA.GetInt32("anio")
                celdaObservacion.Text = REA.GetString("observacion")
                celdaCapacidad.Text = REA.GetDouble("Cap")
                celdaEstado.Text = REA.GetInt32("Estado")
                If REA.GetInt32("Estado") = 1 Then
                    etiquetaEstado.Visible = True
                Else
                    etiquetaEstado.Visible = False
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub CargarDatos(ByVal num As Integer, ByVal year As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLCargarDatos(num, year)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgEstimacionF1.Rows.Clear()
                dgEstimacionF2.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("CGasto") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetDouble("Estimacion")

                    If REA.GetInt32("fase") = 1 Then ' Agrega la fila en el primer datagrid
                        cFunciones.AgregarFila(dgEstimacionF1, strFila)
                    ElseIf REA.GetInt32("fase") = 2 Then ' Agrega la fila en el segundo datagrid
                        cFunciones.AgregarFila(dgEstimacionF2, strFila)
                    End If
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub ListaPrincipal()
        Dim strsql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strsql = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("id") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Observacion") & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetInt32("Anio")

                    If REA.GetInt32("Estatus") = 1 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.YellowGreen)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function GuardarEncabezado() As Boolean
        Dim logResultado As Boolean = True
        Dim hdr As New Tablas.TESTIMACION_HDR

        Try
            hdr.CONEXION = strConexion

            hdr.EST_EMPRESA = Sesion.IdEmpresa
            hdr.EST_ID = celdaNumero.Text
            hdr.EST_ANIO = celdaAnio.Text
            hdr.Est_Fecha_NET = celdaFecha.Text
            hdr.EST_USUARIO = Sesion.Usuario
            If Me.Tag = "Nuevo" Then
                hdr.ESTATUS = 1
            Else
                hdr.ESTATUS = celdaEstado.Text
            End If

            hdr.EST_IDMONEDA = celdaIdMoneda.Text
            hdr.EST_TCMONEDA = celdaTasa.Text
            hdr.EST_OBSERVACION = celdaObservacion.Text
            hdr.EST_CAPACIDAD = celdaCapacidad.Text

            If Me.Tag = "Mod" Then
                If hdr.PUPDATE = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If hdr.PINSERT = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function

    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim dtl As New Tablas.TESTIMACION_DTL
        Dim i As Integer

        Try
            dtl.CONEXION = strConexion

            For i = 0 To dgEstimacionF1.Rows.Count - 1 ' GUARDA EN EL PRIMER DATAGRID FASE = 1

                dtl.DEST_EMPRESA = Sesion.IdEmpresa
                dtl.DEST_ANIO = celdaAnio.Text
                dtl.DEST_NUMERO = celdaNumero.Text
                dtl.DEST_LINEA = dgEstimacionF1.Rows(i).Cells("colLineaF1").Value
                dtl.DEST_IDGASTO = dgEstimacionF1.Rows(i).Cells("colCodigoF1").Value
                dtl.DEST_NET = dgEstimacionF1.Rows(i).Cells("colEstimacionF1").Value
                dtl.DEST_FASE = 1 ' Fase 1 (si es 1 es del primer datagrid)

                If Me.Tag = "Mod" Then
                    If dtl.PUPDATE = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                Else
                    If dtl.PINSERT = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

            For i = 0 To dgEstimacionF2.Rows.Count - 1 ' GUARDA EN SEGUNDO DATAGRID FASE = 2
                dtl.DEST_EMPRESA = Sesion.IdEmpresa
                dtl.DEST_ANIO = celdaAnio.Text
                dtl.DEST_NUMERO = celdaNumero.Text
                dtl.DEST_LINEA = dgEstimacionF2.Rows(i).Cells("colLineaF2").Value
                dtl.DEST_IDGASTO = dgEstimacionF2.Rows(i).Cells("colCodigoF2").Value
                dtl.DEST_NET = dgEstimacionF2.Rows(i).Cells("colEstimacionF2").Value
                dtl.DEST_FASE = 2 'Fase 2 (si es 2 es del segundo datagrid)

                If Me.Tag = "Mod" Then
                    If dtl.PUPDATE = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                Else
                    If dtl.PINSERT = False Then
                        MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function


#End Region

#Region "Eventos"
    Private Sub frmEstimacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' ListaPrincipal()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        etiquetaEstado.Visible = False
        MostrarLista(False)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            If Me.Tag = "Nuevo" Then
                strSQL = " Select ifnull(Max(e.Est_Id+1),1) id From Estimacion_HDR e "

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader

                REA.Read()
                celdaNumero.Text = REA.GetInt32("id")
            End If

            If celdaNumero.Text > 0 Then
                If Me.Tag = "Nuevo" Then
                    ActualizarStatus()
                End If
                GuardarEncabezado()
                GuardarDetalle()

                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro(tbl_Documento, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 0, celdaAnio.Text, celdaNumero.Text)
                ElseIf Me.Tag = "Mod" Then
                    cFunciones.EscribirRegistro(tbl_Documento, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 0, celdaAnio.Text, celdaNumero.Text)
                End If

                If MsgBox("Information saved successfully", vbOK) = MsgBoxResult.Ok Then
                    MostrarLista()
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf panelDetalle.Visible = True Then
            MostrarLista()
        End If
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Me.Tag = "Mod"
        Dim num As Integer = 0
        Dim year As Integer = 0

        LimpiarCampos()
        MostrarLista(False, False)
        num = dgLista.SelectedCells(0).Value
        year = dgLista.SelectedCells(4).Value

        CargarEncabezado(num, year)
        CargarDatos(num, year)

    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(4).Value, 0)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFin.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            'Procedimiento para cargar panel dgLista
            ListaPrincipal()

        End If
    End Sub

#End Region

End Class