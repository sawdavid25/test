﻿Public Class frmTraslado
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strMensaje As String = STR_VACIO
    Dim intPais As Integer = 0
    Dim cfun As New clsFunciones
    Public Const catalogoFactura = 36
    Dim intTipoTraslado As Integer = NO_FILA

    Public Const catalogos = 677
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function verificarPais()
        Dim strsql As String = STR_VACIO
        Dim com As MySqlCommand

        strsql = " Select e.emp_pais From Empresas e Where e.emp_no =  " & Sesion.IdEmpresa
        MyCnn.CONECTAR = strConexion
        com = New MySqlCommand(strsql, CON)

        Return com.ExecuteScalar()

    End Function
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = cFunciones.AñoMySQL
        celdaNumero.Text = -1
        celdaTasa.Text = cFunciones.QueryTasa
        dtpFecha.Text = Now.ToString(FORMATO_MYSQL)
        celdaDireccion.Text = STR_VACIO
        celdaNombreCliente.Text = STR_VACIO
        celdaidCliente.Text = NO_FILA
        celdaNit.Text = STR_VACIO
        celdaIdMoneda.Text = cFunciones.DivisaExtranjera
        celdaMoneda.Text = cFunciones.TraerMoneda(celdaIdMoneda.Text)
        celdaDocumento.Text = STR_VACIO
        celdaIdAplicante.Clear()
        celdaAplicante.Text = STR_VACIO
        celdaDireccion2.Clear()
        celdaTotal.Clear()
        celdaCantidad.Clear()
        celdaNumeroAutorizado.Text = NO_FILA
        celdaCAI.Clear()
        celdaIdTransporte.Clear()
        celdaTransporte.Clear()
        celdaSerie.Clear()
        dgDetalle.Rows.Clear()
        dgFactura.Rows.Clear()
        dgFacturaRel.Rows.Clear()
        celdaIdRazon.Clear()
        celdaRazon.Clear()
        celdaDestino.Clear()
        celdaidDestino.Clear()
        checkTranseferencia.Checked = False
        celdaIdSerie.Clear()
    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            botonImprimir.Enabled = False

        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True

        End If

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones

        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Transfer")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()

        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                '     botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                SeleccionarSubdocumentos(celdaAño.Text, celdaNumero.Text)
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub
    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_DR1_Dbl numero2, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom proveedor, IFNULL(a.ADoc_Dta_Chr,'') doc, h.HDoc_Doc_Status Estado "
        strSQL &= "   FROM Dcmtos_HDR h "
        strSQL &= "         LEFT JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp = h.HDoc_Sis_Emp and a.ADoc_Doc_Cat = h.HDoc_Doc_Cat and a.ADoc_Doc_Ano = h.HDoc_Doc_Ano and a.ADoc_Doc_Num = h.HDoc_Doc_Num and a.ADoc_Doc_Sub= 'Prvs_Guia' and a.ADoc_Doc_Lin = '01' "
        strSQL &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "     AND (h.HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}')"
        End If
        strSQL &= "             ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC; "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        intTipoTraslado = NO_FILA
        strSQL = sqlLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strFila = REA.GetInt32("anio") & "|"
                strFila &= REA.GetInt32("numero") & "|"
                strFila &= REA.GetInt32("numero2") & "|"
                strFila &= REA.GetDateTime("fecha") & "|"
                strFila &= REA.GetString("proveedor") & "|"
                strFila &= REA.GetString("doc")
                If REA.GetInt32("Estado") = 0 Then
                    cfun.AgregarFila(dgLista, strFila, Color.Coral)
                Else
                    cfun.AgregarFila(dgLista, strFila)
                End If

            Loop
        End If

    End Sub
    Private Function SQLEncabezado(ByVal codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT h.HDoc_Ant_Com intTipoTraslado, h.HDoc_RF1_Dbl idCAI, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod codigo, h.HDoc_Emp_Nom proveedor, h.HDoc_Emp_Dir direccion, h.HDoc_Emp_NIT NIT, h.HDoc_Doc_Mon idmoneda, h.HDoc_DR1_Num referencia, IFNULL(h.HDoc_DR1_Cat,0) idrazon, IFNULL(cc.cat_desc,'') razon, "
        strSQL &= " c.cat_clave Moneda, h.HDoc_Doc_TC tasa, h.HDoc_Doc_Status Estado, h.HDoc_DR1_Emp idDireccion, IFNULL(r.cen_direccion,'') Salida, IFNULL(h.HDoc_DR1_Dbl,0) NumeroAut, IFNULL(h.HDoc_DR2_Num,'') serie, IFNULL(h.HDoc_RF2_Txt,'') CAI, h.HDoc_RF2_Num idTransporte, IFNULL(p.pro_proveedor,'') Transporte, "
        strSQL &= " h.HDoc_DR2_Cat tipoTraslado, IF(h.HDoc_DR2_Cat =1, h.HDoc_RF1_Num , h.HDoc_DR2_Emp) idDestino, IF(h.HDoc_DR2_Cat = 1, IFNULL(r1.cen_direccion,''), IFNULL(cl.cli_cliente,'')) destino,h.HDoc_RF1_Cod Direccion2, h.HDoc_RF1_Txt Transporte2 , h.HDoc_RF2_Cod Razon2 "
        strSQL &= "     FROM Dcmtos_HDR h "
        strSQL &= "         LEFT JOIN Centros r ON r.cen_empresa = h.HDoc_Sis_Emp and r.cen_codigo = h.HDoc_DR1_Emp  "
        strSQL &= "             LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_DR1_Cat AND cc.cat_clase = 'Razon_Traslado' "
        strSQL &= "                 LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp and p.pro_codigo = h.HDoc_RF2_Num "
        strSQL &= "                 LEFT JOIN Clientes cl ON cl.cli_sisemp = h.HDoc_Sis_Emp AND cl.cli_codigo = h.HDoc_DR2_Emp "
        strSQL &= "                 LEFT JOIN Centros r1 ON r1.cen_empresa = h.HDoc_Sis_Emp and r1.cen_codigo = h.HDoc_RF1_Num "
        strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 677 AND h.HDoc_Doc_Ano= {anio} AND h.HDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", codigo)
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLEncabezado(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaAño.Text = REA.GetInt32("anio")
                    celdaNumero.Text = REA.GetInt32("numero")
                    If REA.GetInt32("Estado") = 1 Then
                        checkActive.Checked = True
                        checkActive.Enabled = True
                    Else
                        checkActive.Checked = False
                        checkActive.Enabled = False
                    End If
                    If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                        celdaCAI.ReadOnly = True
                        botonAplicante.Enabled = True
                        botonTransporte.Enabled = True
                        botonRazon.Enabled = True
                        celdaIdAplicante.Text = REA.GetInt32("idDireccion")
                        celdaDireccion2.Text = REA.GetString("Salida")
                        celdaIdTransporte.Text = REA.GetInt32("idTransporte")
                        celdaTransporte.Text = REA.GetString("Transporte")
                        celdaIdRazon.Text = REA.GetInt32("idrazon")
                        celdaRazon.Text = REA.GetString("razon")
                    Else
                        celdaCAI.ReadOnly = False
                        botonAplicante.Enabled = False
                        botonTransporte.Enabled = False
                        botonRazon.Enabled = False
                        celdaDireccion2.Text = REA.GetString("Direccion2")
                        celdaTransporte.Text = REA.GetString("Transporte2")
                        celdaRazon.Text = REA.GetString("Razon2")
                    End If
                    intTipoTraslado = REA.GetInt32("intTipoTraslado")
                    celdaIdSerie.Text = REA.GetInt32("idCAI")
                    dtpFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    celdaidCliente.Text = REA.GetInt32("codigo")
                    celdaNombreCliente.Text = REA.GetString("proveedor")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaNit.Text = REA.GetString("NIT")
                    celdaIdMoneda.Text = REA.GetInt32("idmoneda")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaTasa.Text = REA.GetDouble("tasa")
                    'celdaDocumento.Text = REA.GetString("Documento")
                    'celdaAplicante.Text = REA.GetString("Cliente")
                    celdaCAI.Text = REA.GetString("CAI")
                    celdaSerie.Text = REA.GetString("serie")
                    celdaNumeroAutorizado.Text = REA.GetDouble("NumeroAut")
                    celdaidDestino.Text = REA.GetInt32("idDestino")
                    celdaDestino.Text = REA.GetString("destino")
                    If REA.GetInt32("tipoTraslado") = 1 Then
                        checkTranseferencia.Checked = True
                    Else
                        checkTranseferencia.Checked = False
                    End If
                Loop
                REA.Close()
                COM = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "      SELECT d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des articulo, d.DDoc_Prd_UM idMedida, d.DDoc_Doc_Lin linea, 'KGS' Medida, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidad, d.DDoc_RF1_Txt referencia, "
        strSQL &= "         d.DDoc_RF2_Num paquetes, (d.DDoc_Prd_NET * d.DDoc_Prd_QTY) total, IFNULL(p.PDoc_Par_Cat,0) ParCat, IFNULL(p.PDoc_Par_Ano,0) ParAnio, IFNULL(p.PDoc_Par_Num,0) ParNum, IFNULL(p.PDoc_Par_Lin,0) ParLin "
        strSQL &= "             FROM Dcmtos_HDR h "
        strSQL &= "                LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 677 AND h.HDoc_Doc_Ano= {anio} AND h.HDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Codigo)

        Return strSQL
    End Function
    Private Function SQLFacturasRel(ByVal Codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT 
	                   h.HDoc_Doc_Ano Anio,
	                    h.HDoc_Doc_Fec fecha, 
	                    h.HDoc_Doc_Num numero, 
	                    h.HDoc_Usuario usuario, 
	                    concat_ws(' ',h.HDoc_DR1_Num,h.HDoc_DR2_Num) Referencia,
	                    h.HDoc_RF1_Dbl Monto,  
	                    c.cat_desc Moneda,
	                    h.HDoc_Doc_TC TC, 
	                    h.HDoc_Ant_Com FactEsp, 
	                    1 extra ,
	                    h.HDoc_Doc_Cat catalogo,
	                    0 calISR,
	                    i.IDoc_Doc_Lin linea,
                        h.HDoc_DR1_Dbl FacturaNumero
                    FROM Dcmtos_DTL_Itm i
                    LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp=i.IDoc_Sis_Emp 
	                    AND h.HDoc_Doc_Cat=i.IDoc_RF1_Num
	                    AND h.HDoc_Doc_Ano=i.IDoc_RF1_Cod
	                    AND h.HDoc_Doc_Num=i.IDoc_RF1_Dbl
                    LEFT JOIN Catalogos c ON c.cat_num=h.HDoc_Doc_Mon AND c.cat_clase='Monedas'
                    WHERE i.IDoc_Sis_Emp={empresa} AND i.IDoc_Doc_Cat={catalogo} AND i.IDoc_Doc_Ano={anio} AND i.IDoc_Doc_Num={numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Codigo)

        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblcantidad As Double = 0
        Dim dblTotal As Double = 0
        Dim dblTotalLinea As Double = 0
        Try
            strSQL = SQLDetalle(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read

                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("articulo") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetInt32("idMedida") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("paquetes") & "|"
                    dblTotalLinea = REA.GetDouble("precio") * REA.GetDouble("cantidad")
                    strFila &= dblTotalLinea.ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("ParCat") & "|"
                    strFila &= REA.GetInt32("ParAnio") & "|"
                    strFila &= REA.GetInt32("ParNum") & "|"
                    strFila &= REA.GetInt32("ParLin") & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgDetalle, strFila)

                    dblcantidad = dblcantidad + REA.GetDouble("cantidad")
                    dblTotal = dblTotal + dblTotalLinea

                Loop
                celdaCantidad.Text = dblcantidad.ToString(FORMATO_MONEDA)
                celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarFacturasRel(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblcantidad As Double = 0
        Dim dblTotal As Double = 0
        Dim dblTotalLinea As Double = 0
        Try
            strSQL = SQLFacturasRel(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFacturaRel.Rows.Clear()
                Do While REA.Read

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetString("fecha") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("tc").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("FactEsp") & "|1|"
                    strFila &= REA.GetInt32("catalogo") & "|0|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("FacturaNumero")

                    cFunciones.AgregarFila(dgFacturaRel, strFila)

                Loop
                celdaCantidad.Text = dblcantidad.ToString(FORMATO_MONEDA)
                celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLReferenciaDocumento(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT b.HDoc_Doc_Cat tipo, b.HDoc_Doc_Ano anio, b.HDoc_Doc_Num numero, b.HDoc_Doc_Fec fecha, b.HDoc_Emp_Nom proveedor, b.HDoc_DR1_Num referencia "
        strSQL &= "     FROM Dcmtos_DTL_Pro a "
        strSQL &= "         INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num AND a.PDoc_Par_Cat = 47 "
        strSQL &= "             WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = {catalogo} AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {numero} "
        strSQL &= "                 GROUP BY b.HDoc_Doc_Num ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Return strSQL
    End Function
    Public Sub CargarReferencia(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Try


            strSQL = SQLReferenciaDocumento(Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"

                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("proveedor") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= INT_UNO
                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Function SQLDetalleDocumentosProceso() As String
        Dim strSQL As String = STR_VACIO
        Dim AnioIngreso As String = 0
        Dim NumIngreso As String = 0
        Dim j = 0
        Try
            strSQL = "  SELECT d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, "
            strSQL &= "     d.DDoc_Prd_Des articulo, d.DDoc_Prd_UM UMedida, d.DDoc_Prd_NET precio, h.HDoc_DR1_Num referencia, c.cat_clave "
            strSQL &= "         FROM Dcmtos_HDR h "
            strSQL &= "             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                                    LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM"
            strSQL &= "                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Doc_Ano IN({anio}) AND h.HDoc_Doc_Num IN({numero}) "

            AnioIngreso = STR_VACIO
            NumIngreso = STR_VACIO
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If dgFactura.Rows(i).Visible = True Then
                    If j = 0 Then
                        AnioIngreso = AnioIngreso & dgFactura.Rows(i).Cells("col_anio").Value
                        NumIngreso = NumIngreso & dgFactura.Rows(i).Cells("col_Numero").Value
                        j = j + 1
                    Else
                        AnioIngreso = AnioIngreso & "," & dgFactura.Rows(i).Cells("col_anio").Value
                        NumIngreso = NumIngreso & "," & dgFactura.Rows(i).Cells("col_Numero").Value
                    End If

                End If
            Next

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", AnioIngreso)
            strSQL = Replace(strSQL, "{numero}", NumIngreso)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function SQLDocumentosEnProceso() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Proveedor, h.HDoc_DR1_Num referencia, ROUND(d.DDoc_Prd_QTY - (
                        SELECT IFNULL(SUM(IF(o.PDoc_Chi_Cat = 48, o.PDoc_QTY_Pro, dgr.DDoc_Prd_QTY)),0) Dato
                        FROM Dcmtos_DTL_Pro o
                        LEFT JOIN Dcmtos_DTL dgr ON dgr.DDoc_Sis_Emp = o.PDoc_Sis_Emp AND dgr.DDoc_Doc_Cat = o.PDoc_Chi_Cat AND dgr.DDoc_Doc_Ano = o.PDoc_Chi_Ano AND dgr.DDoc_Doc_Num = o.PDoc_Chi_Num AND dgr.DDoc_Doc_Lin = o.PDoc_Chi_Lin 
                        WHERE o.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND o.PDoc_Par_Cat = d.DDoc_Doc_Cat AND o.PDoc_Par_Ano = d.DDoc_Doc_Ano AND o.PDoc_Par_Num = d.DDoc_Doc_Num AND (o.PDoc_Par_Lin = d.DDoc_Doc_Lin OR o.PDoc_Par_Lin IS NULL) AND (o.PDoc_Chi_Cat IN(48,677) OR o.PDoc_Chi_Cat IS NULL))) AS Saldo "
            strSQL &= "         FROM Dcmtos_HDR h "
            strSQL &= "             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat =d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 677 "
            strSQL &= "                     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Emp_Cod = {codigo} AND (p.PDoc_Chi_Cat IS NULL OR p.PDoc_Chi_Cat = 677) {plantas} "
            strSQL &= "                         GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
            strSQL &= "                             HAVING Saldo > 0 "
            strSQL &= "                                 ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogoFac}", catalogoFactura)
            strSQL = Replace(strSQL, "{codigo}", celdaidCliente.Text)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)
            If Sesion.idGiro = 2 Then
                strSQL = Replace(strSQL, "{plantas}", "AND h.HDoc_DR1_Cat IN(3,6)")
            Else
                strSQL = Replace(strSQL, "{plantas}", STR_VACIO)
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDatosCliente(ByVal codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT cli_codigo codigo , cli_cliente Cliente , cli_direccion Direccion  "
            strSQL &= "     FROM Clientes "
            strSQL &= "        LEFT JOIN Catalogos ON cat_num=cli_moneda "
            strSQL &= "             WHERE cli_sisemp={empresa} AND cli_codigo={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaIdAplicante.Text = REA.GetInt32("codigo")
                    celdaAplicante.Text = REA.GetString("Cliente")
                    celdaDireccion2.Text = REA.GetString("Direccion")
                    celdaDocumento.Text = dgFactura.CurrentRow.Cells("col_Numero").Value
                Loop
            End If

        Catch ex As Exception

        End Try
    End Sub
    Public Sub CargarPolizaExportacion()
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            strSQL = " SELECT DISTINCT ip.ADoc_Dta_Chr  Exportacion"
            strSQL &= "     FROM Dcmtos_DTL_Pro rp "
            strSQL &= "         INNER JOIN Dcmtos_HDR ep ON ep.HDoc_Sis_Emp = rp.PDoc_Sis_Emp AND ep.HDoc_Doc_Cat = rp.PDoc_Chi_Cat AND ep.HDoc_Doc_Ano = rp.PDoc_Chi_Ano AND ep.HDoc_Doc_Num = rp.PDoc_Chi_Num "
            strSQL &= "             LEFT JOIN Dcmtos_ACC ip ON ip.ADoc_Sis_Emp = ep.HDoc_Sis_Emp AND ip.ADoc_Doc_Cat = ep.HDoc_Doc_Cat AND ip.ADoc_Doc_Ano = ep.HDoc_Doc_Ano AND ip.ADoc_Doc_Num = ep.HDoc_Doc_Num AND ip.ADoc_Doc_Sub = 'Doc_PolExp' AND ip.Adoc_Doc_Lin = '01' "
            strSQL &= "                      WHERE rp.PDoc_Sis_Emp = {empresa} AND rp.PDoc_Par_Cat = {catalogo} AND rp.PDoc_Par_Ano = {anio} AND rp.PDoc_Par_Num = {numero} AND rp.PDoc_Chi_Cat = 56 AND NOT(COALESCE(ip.ADoc_Dta_Chr,'') = '') LIMIT 1"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
            strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
            strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function CalcularKilos()
        Dim strSLQ As String = STR_VACIO
        Dim AnioIngreso As String = STR_VACIO
        Dim NumIngreso As String = STR_VACIO
        Dim j As Integer = 0

        strSLQ = " SELECT d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Num, d.DDoc_Doc_Lin Linea, IF(p.PDoc_Chi_Cat = 48, ROUND(IF(d.DDoc_Prd_UM = 70, (((d.DDoc_Prd_QTY) - (IFNULL(SUM(p.PDoc_QTY_Pro),0))) *2.2046), (((d.DDoc_Prd_QTY) - (IFNULL(SUM(p.PDoc_QTY_Pro),0))))),2), ROUND(IF(d.DDoc_Prd_UM = 70, (((d.DDoc_Prd_QTY) - (IFNULL(SUM(dgr.DDoc_Prd_QTY),0))) *2.2046), (((d.DDoc_Prd_QTY) - (IFNULL(SUM(dgr.DDoc_Prd_QTY),0))))),2)) kilos"
        strSLQ &= "    From Dcmtos_DTL d "
        strSLQ &= "         Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp =d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin 
                            LEFT JOIN Dcmtos_DTL dgr ON dgr.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND dgr.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND dgr.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND dgr.DDoc_Doc_Num = p.PDoc_Chi_Num AND dgr.DDoc_Doc_Lin = p.PDoc_Chi_Lin"
        strSLQ &= "            Left JOIN Dcmtos_DTL_Box c ON c.BDoc_Sis_Emp = p.PDoc_Sis_Emp AND c.BDoc_Doc_Cat = p.PDoc_Chi_Cat AND c.BDoc_Doc_Ano = p.PDoc_Chi_Ano AND c.BDoc_Doc_Num = p.PDoc_Chi_Num AND c.BDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strSLQ &= "                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat =47 AND d.DDoc_Doc_Ano IN({anio}) AND d.DDoc_Doc_Num IN({numero}) "
        strSLQ &= "                     GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "

        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Visible = True Then
                If j = 0 Then
                    AnioIngreso = AnioIngreso & dgFactura.Rows(i).Cells("col_anio").Value
                    NumIngreso = NumIngreso & dgFactura.Rows(i).Cells("col_Numero").Value
                    j = j + 1
                Else
                    AnioIngreso = AnioIngreso & "," & dgFactura.Rows(i).Cells("col_anio").Value
                    NumIngreso = NumIngreso & "," & dgFactura.Rows(i).Cells("col_Numero").Value
                End If
            End If

        Next

        strSLQ = Replace(strSLQ, "{empresa}", Sesion.IdEmpresa)
        strSLQ = Replace(strSLQ, "{anio}", AnioIngreso)
        strSLQ = Replace(strSLQ, "{numero}", NumIngreso)

        Return strSLQ
    End Function

    Private Function CalcularBultos()
        Dim strSQL As String = STR_VACIO
        Dim AnioIngreso As String = STR_VACIO
        Dim NumIngreso As String = STR_VACIO
        Dim j As Integer = 0

        strSQL = " SELECT b.BDoc_Doc_Ano Anio, b.BDoc_Doc_Num Num, b.BDoc_Doc_Lin Linea, IFNULL((b.BDoc_Box_QTY) - IFNULL((
                    SELECT SUM(IF(p.PDoc_Chi_Cat = 48, c.BDoc_Box_QTY,dgr.DDoc_Prd_QTY)) "
        strSQL &= "        From Dcmtos_DTL_Pro p "
        strSQL &= "            INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND h.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND h.HDoc_Doc_Num = p.PDoc_Chi_Num AND h.HDoc_Doc_Status = 1 
                                LEFT JOIN Dcmtos_DTL dgr ON dgr.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND dgr.DDoc_Doc_Cat = p.PDoc_Chi_Cat AND dgr.DDoc_Doc_Ano = p.PDoc_Chi_Ano AND dgr.DDoc_Doc_Num = p.PDoc_Chi_Num AND dgr.DDoc_Doc_Lin = p.PDoc_Chi_Lin"
        strSQL &= "                Left JOIN Dcmtos_DTL_Box c ON c.BDoc_Sis_Emp = p.PDoc_Sis_Emp AND c.BDoc_Doc_Cat = p.PDoc_Chi_Cat AND c.BDoc_Doc_Ano = p.PDoc_Chi_Ano AND c.BDoc_Doc_Num = p.PDoc_Chi_Num AND c.BDoc_Doc_Lin = p.PDoc_Chi_Lin "
        strSQL &= "                    WHERE p.PDoc_Sis_Emp = b.BDoc_Sis_Emp AND p.PDoc_Par_Cat = b.BDoc_Doc_Cat AND p.PDoc_Par_Ano = b.BDoc_Doc_Ano AND p.PDoc_Par_Num = b.BDoc_Doc_Num AND p.PDoc_Chi_Cat IN(48,677)),0),0) bultos "
        strSQL &= "                From Dcmtos_DTL_Box b "
        strSQL &= "            WHERE b.BDoc_Sis_Emp = {empresa} AND b.BDoc_Doc_Cat =47 AND b.BDoc_Doc_Ano IN({anio}) AND b.BDoc_Doc_Num IN({numero}) "
        strSQL &= "        ORDER BY b.BDoc_Doc_Ano, b.BDoc_Doc_Num, b.BDoc_Doc_lin"

        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Visible = True Then
                If j = 0 Then
                    AnioIngreso = AnioIngreso & dgFactura.Rows(i).Cells("col_anio").Value
                    NumIngreso = NumIngreso & dgFactura.Rows(i).Cells("col_Numero").Value
                    j = j + 1
                Else
                    AnioIngreso = AnioIngreso & "," & dgFactura.Rows(i).Cells("col_anio").Value
                    NumIngreso = NumIngreso & "," & dgFactura.Rows(i).Cells("col_Numero").Value
                End If
            End If
        Next

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", AnioIngreso)
        strSQL = Replace(strSQL, "{numero}", NumIngreso)

        Return strSQL
    End Function

    Private Function SqlListarSubDatos() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT cat_clave, cat_desc, IF(("
        strSQL &= "      SELECT COUNT(*)"
        strSQL &= "              FROM Dcmtos_ACC"
        strSQL &= "                   WHERE ADoc_Sis_Emp = {empresa}  AND ADoc_Doc_Cat = 677 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) >0,'SI','NO') AS cantidad"
        strSQL &= "              FROM Catalogos"
        strSQL &= "        WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_B/Ing' AND (cat_sisemp IN (12))"
        strSQL &= "    ORDER BY cat_clave; "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function

    'procedimiento que cargar SubDocumentos
    Public Sub SeleccionarSubdocumentos(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlListarSubDatos()

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgSubdocumentos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO


                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    strFila &= REA.GetString("Cantidad")

                    cFunciones.AgregarFila(dgSubdocumentos, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Public Sub CargarSerieDoc()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim strSerie As String = STR_VACIO

        strSQL &= "SELECT c.cat_sist "
        strSQL &= "   FROM Catalogos c"
        strSQL &= "      WHERE cat_clase='Serie' AND cat_clave= 'Doc_GRemision' and cat_pid = 0 and cat_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        strSerie = COM.ExecuteScalar

        celdaSerie.Text = strSerie
    End Sub

    Private Sub CargarCAIDoc()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim REA As MySqlDataReader
        Dim strCAI As String = STR_VACIO

        strSQL = "SELECT g.regimen CAI
                    FROM Gface g
                    WHERE g.empresa = {emp} AND g.serie = {cod} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{cod}", celdaIdSerie.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()

            celdaCAI.Text = REA.GetString("CAI")
        End If


    End Sub
    Public Sub CargarDocumentosProcesados()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLDocumentosEnProceso()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dgFactura.Rows.Clear()
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = 47 & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Proveedor") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetString("Saldo") & "|"
                    strFila &= INT_CERO
                    cfun.AgregarFila(dgFactura, strFila)
                Loop
            End If
            'celdaDocumento.Text = STR_VACIO
            'celdaDireccion2.Text = STR_VACIO
            'celdaAplicante.Text = STR_VACIO
            'celdaIdAplicante.Text = STR_VACIO


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDocumentosDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim dblTotalLin As Double = 0

        Try
            strSQL = SQLDetalleDocumentosProceso()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("articulo") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetInt32("UMedida") & "|"
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetString("cat_clave") & "|"
                    If REA.GetInt32("UMedida") = 70 Then
                        strFila &= ((REA.GetDouble("precio")) / 2.2046) & "|"
                    Else
                        strFila &= REA.GetDouble("precio") & "|"

                    End If

                    strFila &= INT_CERO & "|" ' Cantidad
                    strFila &= INT_CERO & "|" ' Paquetes
                    'dblTotalLin = (REA.GetDouble("precio") * REA.GetDouble("saldo"))
                    strFila &= INT_CERO & "|"
                    strFila &= REA.GetInt32("DDoc_Doc_Cat") & "|"
                    strFila &= REA.GetInt32("DDoc_Doc_Ano") & "|"
                    strFila &= REA.GetInt32("DDoc_Doc_Num") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= INT_CERO
                    cfun.AgregarFila(dgDetalle, strFila)

                Loop

                CalcularKilosIngeso()
                CalcularBultosIngreso()

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CalcularKilosIngeso() ' Se había programado para que mostrara kilos, pero despues cambiaron e opinion y se cambió a libras, por eso los nombres quedaron como kilos
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblTotalLinea As Double = 0
        strSQL = CalcularKilos()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    If REA.GetInt32("Linea") = dgDetalle.Rows(i).Cells("colLineaPro").Value And REA.GetInt32("Anio") = dgDetalle.Rows(i).Cells("colAnioPro").Value And REA.GetInt32("Num") = dgDetalle.Rows(i).Cells("colNumeroPro").Value Then
                        dgDetalle.Rows(i).Cells("colCantidad").Value = REA.GetDouble("kilos")
                        dblTotalLinea = ((dgDetalle.Rows(i).Cells("colPrecio").Value) * (dgDetalle.Rows(i).Cells("colCantidad").Value))
                        dgDetalle.Rows(i).Cells("colTotal").Value = dblTotalLinea.ToString(FORMATO_MONEDA)
                        If REA.GetDouble("kilos") <= 0 Then
                            dgDetalle.Rows(i).Cells("colExtra").Value = 2
                            dgDetalle.Rows(i).Visible = False
                        End If
                    End If
                Next
            Loop
        End If

    End Sub

    Public Sub CalcularBultosIngreso()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblSumCantidad As Double = 0
        Dim dblSumTotal As Double = 0
        strSQL = CalcularBultos()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    If REA.GetInt32("Linea") = dgDetalle.Rows(i).Cells("colLineaPro").Value And REA.GetInt32("Anio") = dgDetalle.Rows(i).Cells("colAnioPro").Value And REA.GetInt32("Num") = dgDetalle.Rows(i).Cells("colNumeroPro").Value Then
                        dgDetalle.Rows(i).Cells("colPaquetes").Value = REA.GetDouble("bultos")
                        If Not dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                            dblSumCantidad = dblSumCantidad + (dgDetalle.Rows(i).Cells("colCantidad").Value)
                            dblSumTotal = dblSumTotal + (dgDetalle.Rows(i).Cells("colTotal").Value)
                        End If
                    End If
                Next
            Loop
            celdaCantidad.Text = dblSumCantidad.ToString(FORMATO_MONEDA)
            celdaTotal.Text = dblSumTotal.ToString(FORMATO_MONEDA)
        End If
    End Sub
    Public Sub Pedido()
        Dim strSQL As String
        Dim strSQL1 As String
        Dim strSQl2 As String
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim frmNote As New frmAviso
        Dim dblTotal As Double
        Dim dblPrecio As Double
        Dim strUnidad As String
        Dim strBase As String
        Dim strPedido As String
        Dim intUnidad As Integer
        Dim intBase As Integer
        Dim dblCantidad As Double = 0
        Dim dblTotalDoc As Double = 0
        Try
            strMensaje = STR_VACIO
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                strSQL = "  Select r.HDoc_Doc_Cat tipo, r.HDoc_Doc_Ano año, r.HDoc_Doc_Num numero, e.DDoc_Doc_Lin linea, If(d.DDoc_Prd_UM = 70, COALESCE(e.DDoc_Prd_Net,0) * 2.2046, COALESCE(e.DDoc_Prd_Net,0)) precio, COALESCE(e.DDoc_Prd_UM,0) unidad, f.HDoc_Doc_Fec fecha, e.DDoc_Prd_Ref estilo, COALESCE(r.HDoc_DR1_Num,'') pedido, DATE_ADD(f.HDoc_Doc_Fec, INTERVAL c.cli_plazoCR DAY) vencimiento "
                strSQL &= "     FROM Dcmtos_DTL d "
                strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND i.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND i.PDoc_Chi_Num=d.DDoc_Doc_Num AND i.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
                strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=i.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=i.PDoc_Par_Cat AND p.PDoc_Par_Cat=75 AND p.PDoc_Chi_Ano=i.PDoc_Par_Ano AND p.PDoc_Chi_Num=i.PDoc_Par_Num AND p.PDoc_Chi_Lin=i.PDoc_Par_Lin "
                strSQL &= "                 LEFT JOIN Dcmtos_DTL e ON e.DDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.DDoc_Doc_Cat=p.PDoc_Par_Cat AND e.DDoc_Doc_Ano=p.PDoc_Par_Ano AND e.DDoc_Doc_Num=p.PDoc_Par_Num AND e.DDoc_Doc_Lin=p.PDoc_Par_Lin "
                strSQL &= "                     LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND r.HDoc_Doc_Cat=e.DDoc_Doc_Cat AND r.HDoc_Doc_Ano=e.DDoc_Doc_Ano AND r.HDoc_Doc_Num=e.DDoc_Doc_Num "
                strSQL &= "                          LEFT JOIN Clientes c ON c.cli_sisemp=r.HDoc_Sis_Emp AND c.cli_codigo=r.HDoc_Emp_Cod "
                strSQL &= "                              LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp={empresa} AND f.HDoc_Doc_Cat={catalogo} AND f.HDoc_Doc_Ano={anio} AND f.HDoc_Doc_Num={numero}"
                strSQL &= "                                  WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={catalogo} AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num={numero} AND d.DDoc_Doc_Lin={linea} AND NOT ISNULL(r.HDoc_Sis_Emp) LIMIT 1"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{catalogo}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
                strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
                strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
                strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("col_linea").Value)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        If Me.Tag = "Nuevo" Then
                            intUnidad = dgDetalle.Rows(i).Cells("colidMedida").Value
                            'intBase = dgDetalle.Rows(i).Cells("colBase").Value
                            strPedido = REA.GetString("pedido")
                            If REA.GetDouble("precio") > vbEmpty Then
                                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value

                                If Not (dblPrecio = REA.GetDouble("precio")) Then

                                    strSQL1 = " SELECT cat_clave FROM Catalogos WHERE cat_clase='Medidas' AND cat_num = " & intUnidad
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM2 = New MySqlCommand(strSQL1, conec)
                                    Using conec
                                        strUnidad = COM2.ExecuteScalar
                                        COM2.Dispose()
                                        COM2 = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    strSQl2 = " SELECT cat_clave FROM Catalogos WHERE cat_clase='Medidas' AND cat_num = " & intBase
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM2 = New MySqlCommand(strSQL1, conec)
                                    Using conec
                                        strBase = COM2.ExecuteScalar
                                        COM2.Dispose()
                                        COM2 = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    dgDetalle.Rows(i).Cells("colPrecio").Value = REA.GetDouble("precio")
                                    dblTotal = REA.GetDouble("precio") * CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                                    dgDetalle.Rows(i).Cells("colTotal").Value = dblTotal.ToString(FORMATO_MONEDA)

                                    strMensaje &= "Línea #" & (i + 1) & ": el precio del pedido difiere del facturado" & vbCrLf & vbCrLf & "Pedido: " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & " x " & strUnidad & vbCrLf & "Factura: " & dblPrecio.ToString(FORMATO_MONEDA) & " x " & strBase & vbCrLf & vbCrLf & vbNullString
                                Else
                                    dblTotal = REA.GetDouble("precio") * CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                                End If
                            End If
                            dgDetalle.Rows(i).Cells("col_presentado").Value = REA.GetDateTime("vencimiento").ToString(FORMATO_MYSQL)
                            dgDetalle.Rows(i).Cells("col_Contrato").Value = strPedido
                            dblCantidad = dblCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value
                            dblTotalDoc = dblTotalDoc + dblTotal
                        Else

                        End If
                    Loop
                    celdaCantidad.Text = dblCantidad.ToString(FORMATO_MONEDA)
                    celdaTotal.Text = dblTotalDoc.ToString(FORMATO_MONEDA)
                    ' Contrato(dgFactura.CurrentRow.Cells("col_anio").Value, dgFactura.CurrentRow.Cells("col_Numero").Value, dgDetalle.Rows(i).Cells("col_linea").Value)
                    COM = Nothing
                    REA.Close()
                End If
            Next
            If Not (strMensaje = vbNullString) Then
                frmNote.Texto = strMensaje
                frmNote.ShowDialog(Me)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Contrato(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim k As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strContrato As String = STR_VACIO
        Dim strFecha As String = STR_VACIO

        strSQL = " SELECT g.Año Anio, g.Numero, g.Linea, g.Contrato, CONCAT(IF(g.Fecha1!='' AND g.Fecha2='','FSD ',''),g.Fecha1, IF(g.Fecha1='' OR g.Fecha2='','',' / '), IF(g.Fecha1='' AND g.Fecha2!='','LSD ',''),g.Fecha2) Fechas "
        strSQL &= "     FROM ( "
        strSQL &= "         SELECT rc.PDoc_Par_Ano Año, rc.PDoc_Par_Num Numero, rc.PDoc_Par_Lin Linea, IFNULL(ec.HDoc_DR1_Num,'') Contrato, CAST(IFNULL(dc.DDoc_RF1_Fec,'') AS CHAR) Fecha1, CAST(IFNULL(dc.DDoc_RF2_Fec,'') AS CHAR) Fecha2 "
        strSQL &= "             FROM Dcmtos_DTL_Pro rc "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL dc ON dc.DDoc_Sis_Emp=rc.PDoc_Sis_Emp AND dc.DDoc_Doc_Cat=rc.PDoc_Par_Cat AND dc.DDoc_Doc_Ano=rc.PDoc_Par_Ano AND dc.DDoc_Doc_Num=rc.PDoc_Par_Num AND dc.DDoc_Doc_Lin=rc.PDoc_Par_Lin "
        strSQL &= "                     LEFT JOIN Dcmtos_HDR ec ON ec.HDoc_Sis_Emp = dc.DDoc_Sis_Emp AND ec.HDoc_Doc_Cat=dc.DDoc_Doc_Cat AND ec.HDoc_Doc_Ano=dc.DDoc_Doc_Ano AND ec.HDoc_Doc_Num=dc.DDoc_Doc_Num "
        strSQL &= "                         WHERE rc.PDoc_Sis_Emp = {empresa} AND rc.PDoc_Chi_Cat = 75 AND rc.PDoc_Chi_Ano = {anio} AND rc.PDoc_Chi_Num = {numero} AND rc.PDoc_Chi_Lin = {linea} AND rc.PDoc_Par_Cat = 389 "
        strSQL &= "                             GROUP BY rc.PDoc_Sis_Emp, rc.PDoc_Par_Cat, rc.PDoc_Par_Ano, rc.PDoc_Par_Num, rc.PDoc_Par_Lin) g "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{linea}", Linea)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If Not (REA.GetString("contrato") = "") Then
                    If k = vbEmpty Then
                        dgDetalle.CurrentRow.Cells("colRefAnio").Value = REA.GetInt32("Anio")
                        dgDetalle.CurrentRow.Cells("colRefNum").Value = REA.GetInt32("Numero")
                        dgDetalle.CurrentRow.Cells("colRefLine").Value = REA.GetInt32("Linea")
                    End If
                    If InStr(1, strContrato, REA.GetString("contrato")) = vbEmpty Then
                        strContrato &= REA.GetString("contrato") & "/"
                    End If
                    If strFecha = vbNullString Then
                        If Not REA.GetString("Fechas") = "" Then
                            strFecha = REA.GetString("Fechas")
                        End If
                    End If

                End If
                k = k + 1
            Loop
        End If
        If k > 1 Then
            'Agrega a la lista de mensajes
            strMensaje &= "Línea #" & (dgDetalle.CurrentRow.Cells("col_linea").Value) & ": se encontró más de un contrato para dicho pedido" & vbCrLf & vbCrLf & vbNullString
        End If
        dgDetalle.CurrentRow.Cells("col_Contrato").Value = strContrato
        dgDetalle.CurrentRow.Cells("colFechaContrato").Value = strFecha

    End Sub
    Private Function GuardarDocumento(ByVal codigo As Integer, ByVal intAnio As Integer) As Boolean
        Dim clsHDR As New clsDcmtos_HDR
        Dim logGuardar As Boolean = True
        Try
            clsHDR.CONEXION = strConexion
            clsHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            clsHDR.HDOC_DOC_CAT = catalogos
            clsHDR.HDOC_DOC_ANO = intAnio
            clsHDR.HDOC_DOC_NUM = codigo
            clsHDR.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            clsHDR.HDOC_EMP_COD = celdaidCliente.Text
            clsHDR.HDOC_EMP_NOM = celdaNombreCliente.Text
            clsHDR.HDOC_EMP_DIR = celdaDireccion.Text
            clsHDR.HDOC_EMP_NIT = celdaNit.Text
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                clsHDR.HDOC_DR1_EMP = celdaIdAplicante.Text ' el id de la direccion de donde sale
                clsHDR.HDOC_RF2_NUM = celdaIdTransporte.Text
                clsHDR.HDOC_DR1_CAT = celdaIdRazon.Text
            Else
                clsHDR.HDOC_RF1_COD = celdaDireccion2.Text ' el id de la direccion de donde sale
                clsHDR.HDOC_RF1_TXT = celdaTransporte.Text
                clsHDR.HDOC_RF2_COD = celdaRazon.Text
            End If
            clsHDR.HDOC_DR1_DBL = celdaNumeroAutorizado.Text
            clsHDR.HDOC_DR2_NUM = celdaSerie.Text
            clsHDR.HDOC_RF2_TXT = celdaCAI.Text
            clsHDR.HDOC_USUARIO = Sesion.Usuario
            clsHDR.HDOC_DOC_TC = celdaTasa.Text
            clsHDR.HDOC_DOC_MON = celdaIdMoneda.Text
            clsHDR.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, vbEmpty)
            clsHDR.HDOC_DR2_CAT = IIf(checkTranseferencia.Checked = True, 1, INT_CERO)
            clsHDR.HDOC_ANT_COM = intTipoTraslado
            clsHDR.HDOC_RF1_DBL = celdaIdSerie.Text
            If checkTranseferencia.Checked = False Then
                clsHDR.HDOC_DR2_EMP = celdaidDestino.Text ' el id del destino final, cuando es a un cliente
            Else
                clsHDR.HDOC_RF1_NUM = celdaidDestino.Text ' id de destino cuando es traslado interno
            End If

            If Me.Tag = "Mod" Then
                If clsHDR.Actualizar() = False Then
                    logGuardar = False
                    MsgBox(clsHDR.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                Else
                    logGuardar = True
                End If
            Else
                If clsHDR.Guardar() = False Then
                    logGuardar = False
                    MsgBox(clsHDR.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                Else
                    logGuardar = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer, ByVal IntAnio As Integer) As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim logGuardar As Boolean
        Try
            clsDTL.CONEXION = strConexion
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = catalogos
                clsDTL.DDOC_DOC_ANO = IntAnio
                clsDTL.DDOC_DOC_NUM = Codigo
                If dgDetalle.Rows(i).Cells("colLinea").Value = 0 Then
                    dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
                    clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                Else
                    clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                End If

                clsDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                clsDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colProducto").Value
                clsDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value
                clsDTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTL.DDOC_PRD_DSP = INT_CERO
                clsDTL.DDOC_PRD_DSQ = INT_CERO
                clsDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                clsDTL.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colRefIngreso").Value

                clsDTL.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colPaquetes").Value

                ' clsDTL.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("").Value ' Documento 
                'clsDTL.DDOC_RF3_FEC = dgDetalle.Rows(i).Cells("").Value  ' Pago 
                'clsDTL.DDOC_RF2_COD = Codigo

                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If clsDTL.Actualizar() = False Then
                        logGuardar = False
                        MsgBox(clsDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    Else
                        logGuardar = True
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If clsDTL.Guardar() = False Then
                        logGuardar = False
                        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    Else
                        logGuardar = True
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If clsDTL.Borrar() = False Then
                        logGuardar = False
                        MsgBox(clsDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    Else
                        logGuardar = True
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Sub GuardarRelacion(ByVal numero As Integer, ByVal IntAnio As Integer)
        Dim pro As New clsDcmtos_DTL_Pro

        Try
            pro.CONEXION = strConexion

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = dgDetalle.Rows(i).Cells("colCatalogoPro").Value
                pro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioPro").Value
                pro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumeroPro").Value
                pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaPro").Value
                pro.PDOC_CHI_CAT = catalogos
                pro.PDOC_CHI_ANO = celdaAño.Text
                pro.PDOC_CHI_NUM = celdaNumero.Text
                pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                pro.PDOC_CLTE_COD = celdaidCliente.Text
                pro.PDOC_PROV_COD = INT_CERO
                'pro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("col_codigo").Value
                pro.PDOC_PRD_PNR = INT_CERO
                pro.PDOC_DR1_NUM = INT_CERO
                pro.PDOC_DR2_NUM = INT_CERO
                'pro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").dValue
                'pro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                'pro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value

                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If pro.Actualizar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If pro.Borrar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

                If checkActive.Checked = False Then
                    checkActive.Enabled = False
                    If pro.Borrar = False Then
                        MsgBox(pro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub MostrarInfo(ByVal Codigo As Integer, ByVal Linea As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "      SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor "
            strSQL &= "         FROM Inventarios i "
            strSQL &= "             INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                 LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
            strSQL &= "                     LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
            strSQL &= "                         WHERE i.inv_sisemp=12 AND i.inv_numero=10646 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", Codigo)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarHilo(ByVal intHilo As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim conec As New MySqlConnection

        conec.ConnectionString = strConexion
        conec.Open()
        Try

            strSQL = " SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor, m.cat_clave Medida "
            strSQL &= " FROM Inventarios i "
            strSQL &= " INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= " LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa "
            strSQL &= " LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
            strSQL &= " LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
            strSQL &= " WHERE i.inv_sisemp={empresa} AND i.inv_numero={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intHilo)

            COM2 = New MySqlCommand(strSQL, conec)
            REA2 = COM2.ExecuteReader
            If REA2.HasRows Then
                Do While REA2.Read
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1

                        If REA2.GetString("proveedor") = vbNullString Then
                            lblInformacion.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais")
                        Else
                            lblInformacion.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais") & " / " & REA2.GetString("proveedor")
                        End If
                        ' Contador = Contador + 1

                    Next
                    lblLinea.Text = Linea
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            conec.Close()
        End Try
        'REA.Close()
        'REA = Nothing
        'COM = Nothing
    End Sub

    Private Sub VerInformacionDeHilo()
        Dim intHilo As Integer
        Try

            If dgDetalle.Rows.Count > 0 Then
                intHilo = dgDetalle.CurrentRow.Cells("col_Codigo").Value
                If Me.Tag = "Mod" Then
                    CargarHilo(intHilo, dgDetalle.CurrentRow.Cells("col_Extra").Value)
                Else
                    CargarHilo(intHilo, dgDetalle.CurrentRow.Index + 1)
                End If
            End If
            'End If

        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function VerificarDatos() As Boolean
        Dim verificacion As Boolean = False
        Dim Intconteo As Integer = 0
        If intTipoTraslado <> 1 Then
            For i As Integer = 0 To dgFactura.Rows.Count - 1
                If Not dgFactura.Rows(i).Cells("colStatus").Value = 2 Then
                    Intconteo = Intconteo + 1
                End If
            Next
        Else
            Intconteo = 1
        End If

        If Intconteo >= 1 Then
            If dgDetalle.Rows.Count >= 1 Then
                verificacion = True
            End If
        End If
        If celdaIdSerie.Text = vbNullString Or celdaIdSerie.Text = STR_VACIO Then
            MsgBox("seleccione serie")
            celdaSerie.Focus()
            verificacion = False
        Else
            verificacion = True
            If ComprobarNoFacturaDisponible() Then
                verificacion = False
            End If
        End If

        If celdaidDestino.Text = "" Then
            MsgBox("seleccione destino")
            botonDestino.Focus()
            verificacion = False
        End If
        Return verificacion
    End Function
    Private Function ComprobarNoFacturaDisponible() As Boolean
        Dim intNumAutorizado As Integer = 0
        Dim numDoc As Integer = 0
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim cai As String = "0"
        Dim rangoInicial As Integer = 0
        Dim rangoFinal As Integer = 0
        Dim autorizacion As String = Now().ToString(FORMATO_MYSQL)

        If celdaNumero.Text = NO_FILA Then
            numDoc = cFunciones.NuevoId(catalogos)
            celdaNumero.Text = numDoc
        End If
        If celdaNumeroAutorizado.Text = NO_FILA Then
            strSQL = " SELECT ifnull(MAX(HDoc_DR1_Dbl),0)+1"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "         WHERE HDoc_Sis_Emp ={empresa} and HDoc_Doc_Cat = 677 and HDoc_DR2_Num = '" & celdaSerie.Text & "'"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intNumAutorizado = COM.ExecuteScalar
            celdaNumeroAutorizado.Text = intNumAutorizado
        End If
        If Me.Tag = "Nuevo" And Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            intNumAutorizado = celdaNumeroAutorizado.Text
            strSQL = "Select IFNULL(regimen,'') cai, rango_inicial rangoInicial, rango_final rangoFinal, autorizacion FROM Gface"
            strSQL &= " WHERE empresa = {empresa}"
            strSQL &= " And serie=("
            strSQL &= " Select cat_num FROM Catalogos"
            strSQL &= " where cat_clase ='Serie'"
            strSQL &= " And cat_clave ='Doc_GRemision'"
            strSQL &= " And cat_sisemp = {empresa} And cat_pid = 0 "
            If Sesion.IdEmpresa = 11 Then
                strSQL &= " And cat_sist='" & celdaSerie.Text & "' "
            End If

            strSQL &= " )"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                cai = REA.GetString("cai")
                rangoInicial = REA.GetString("rangoInicial")
                rangoFinal = REA.GetString("rangoFinal")
                autorizacion = REA.GetString("autorizacion")
            End If
            REA.Close()
            COM.Dispose()
            REA = Nothing
            COM = Nothing

            If Date.Compare(Now().ToString(FORMATO_MYSQL), CDate(autorizacion).ToString(FORMATO_MYSQL)) <= 0 And (rangoInicial <= intNumAutorizado And intNumAutorizado <= rangoFinal) Then
                Return False
            Else
                MsgBox("No. Invoice not available." & vbLf & "CAI: " & cai & vbLf & "Initial Range: " & rangoInicial & vbLf & "Final Range: " & rangoFinal, vbExclamation, "Notice")
                Return True
            End If
        End If

        Return False
    End Function
    Private Function BuscarRegistrosDcmtos_ACC(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("Traslado")
        adaptador.Fill(Tablas, "Dcmtos_ACC")
        If Tablas.Tables("Dcmtos_ACC").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\Dcmtos_ACCTHN.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarRegistrosDcmtos_DTL(ByVal strConsulta) As String
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("Traslado2")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\Dcmtos_DTLTHN.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Public Sub ImpresionTraslado(ByVal anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim repCR As Object = Nothing

        If Sesion.IdEmpresa = 20 Then
            repCR = New GuiaRemisionNS
        ElseIf Sesion.IdEmpresa = 15 Then
            repCR = New GuiaRemisionHSM
        Else
            repCR = New GuiaRemision
        End If


        ' strSQL = "  SELECT h.HDoc_Doc_Fec Fecha, CAST(CONCAT(h.HDoc_DR2_Num, LPAD(h.HDoc_DR1_Dbl,8,0)) AS CHAR)Numero,r.cat_desc Razon, h.HDoc_RF2_Txt CAI, CAST(CONCAT(h.HDoc_DR2_Num, LPAD(g.rango_inicial,8,0)) AS CHAR)Rango_Inicial, CAST(CONCAT(h.HDoc_DR2_Num, LPAD(g.rango_final,8,0)) AS CHAR)Rango_Final, g.autorizacion, t.cen_direccion salida, p.pro_proveedor Transporte, p.pro_nit RTN,h.HDoc_Doc_TC Tasa, IF(h.HDoc_DR2_Cat = 1, IFNULL(r1.cen_descripcion,''), IFNULL(cl.cli_cliente,'')) destino, IF(h.HDoc_DR2_Cat = 1, IFNULL(r1.cen_direccion,''), IFNULL(cli_direccion,'')) direccion_Destino, IF(h.HDoc_DR2_Cat = 1, IFNULL(em.emp_nit,''), IFNULL(cli_nit,'')) RTN_Destino,SUM(d.DDoc_Prd_QTY) CLBS, IFNULL((  "
        strSQL = "  SELECT h.HDoc_Doc_Fec Fecha,CAST(CONCAT(h.HDoc_DR2_Num,'-', LPAD(h.HDoc_DR1_Dbl,8,0)) AS CHAR)Numero,r.cat_desc Razon, h.HDoc_RF2_Txt CAI, CAST(CONCAT(h.HDoc_DR2_Num,'-', LPAD(g.rango_inicial,8,0)) AS CHAR)Rango_Inicial, CAST(CONCAT(h.HDoc_DR2_Num,'-', LPAD(g.rango_final,8,0)) AS CHAR)Rango_Final, g.autorizacion, t.cen_descripcion nsalida, t.cen_direccion salida, p.pro_proveedor Transporte, p.pro_nit RTN,h.HDoc_Doc_TC Tasa, IF(h.HDoc_DR2_Cat = 1, IFNULL(r1.cen_descripcion,''), IFNULL(cl.cli_cliente,'')) destino, IF(h.HDoc_DR2_Cat = 1, IFNULL(r1.cen_direccion,''), IFNULL(cli_direccion,'')) direccion_Destino, IF(h.HDoc_DR2_Cat = 1, IFNULL(em.emp_nit,''), IFNULL(cli_nit,'')) RTN_Destino,SUM(d.DDoc_Prd_QTY) CLBS, IFNULL((  "
        strSQL &= "     SELECT ac.ADoc_Dta_Chr "
        strSQL &= "         FROM Dcmtos_ACC ac "
        strSQL &= "             WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '06'),'') conductor, IFNULL(( "
        strSQL &= "                SELECT ac.ADoc_Dta_Chr "
        strSQL &= "                     FROM Dcmtos_ACC ac "
        strSQL &= "                         WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '13'),'') licencia, IFNULL((  "
        strSQL &= "                             SELECT ac.ADoc_Dta_Chr   "
        strSQL &= "                                 FROM Dcmtos_ACC ac  "
        strSQL &= "                                     WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '14'),'') vehiculo, IFNULL(( "
        strSQL &= "                                          SELECT ac.ADoc_Dta_Chr "
        strSQL &= "                                              FROM Dcmtos_ACC ac "
        strSQL &= "                                                     WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '07'),'') placa, IFNULL(( "
        strSQL &= "                                                         SELECT ac.ADoc_Dta_Chr "
        strSQL &= "                                                             FROM Dcmtos_ACC ac "
        strSQL &= "                                                                 WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '08'),'') placa_contenedor, IFNULL(( "
        strSQL &= "                                                                     SELECT ac.ADoc_Dta_Chr "
        strSQL &= "                                                                         FROM Dcmtos_ACC ac "
        strSQL &= "                                                                              WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '12'),'') DUA, IFNULL(( "
        strSQL &= "                                                                                     SELECT CAST(ac.ADoc_Dta_Fec AS CHAR)  "
        strSQL &= "                                                                                         FROM Dcmtos_ACC ac"
        strSQL &= "                                                                                     WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '02'),'') fechaDUA, IFNULL((  "
        strSQL &= "                                                                                  SELECT CAST(ac.ADoc_Dta_Fec AS CHAR) "
        strSQL &= "                                                                             FROM Dcmtos_ACC ac"
        strSQL &= "                                                                          WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '15'),'') fechainicio, IFNULL((  "
        strSQL &= "                                                                     SELECT CAST(ac.ADoc_Dta_Fec AS CHAR)"
        strSQL &= "                                                                FROM Dcmtos_ACC ac "
        strSQL &= "                                                         WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '16'),'') fechaFin,  "
        strSQL &= "                                                         IFNULL(("
        strSQL &= "                                                         SELECT CAST(ac.ADoc_Dta_Wht AS CHAR)"
        strSQL &= "                                                          FROM Dcmtos_ACC ac"
        strSQL &= "                                                         WHERE ac.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = h.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Prvs_Guia' AND ac.ADoc_Doc_Lin = '22'),'') Peso"
        strSQL &= "                                                         ,SUM(
                                                                                case 
	                                                                                when d.DDoc_Prd_Des LIKE '%Rampla%' then 
		                                                                                round(IFNULL((SELECT cat_sist FROM Catalogos WHERE cat_clase='Empaque' AND cat_clave='Rampla'),0)*d.DDoc_Prd_QTY/2.2046,2)
	                                                                                when d.DDoc_Prd_Des LIKE '%lamina%' then 
		                                                                                round(IFNULL((SELECT cat_sist FROM Catalogos WHERE cat_clase='Empaque' AND cat_clave='Separador'),0)*d.DDoc_Prd_QTY/2.2046,2)
                                                                                end) Pesos "
        strSQL &= "                                                     FROM Dcmtos_HDR h "
        strSQL &= "                                                 /* LEFT JOIN Catalogos c ON c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_GRemision' AND c.cat_sisemp = h.HDoc_Sis_Emp AND c.cat_pid =0 */"
        strSQL &= "                                             LEFT JOIN Catalogos r ON r.cat_num = h.HDoc_DR1_Cat AND  r.cat_clase = 'Razon_Traslado'  "
        strSQL &= "                                         LEFT JOIN Gface g ON g.empresa = h.HDoc_Sis_Emp AND g.serie = h.HDoc_RF1_Dbl  /* AND g.tipo_documento = h.HDoc_Doc_Cat AND g.tipo_activo = 1*/ "
        strSQL &= "                                     LEFT JOIN Centros t ON t.cen_empresa = h.HDoc_Sis_Emp AND t.cen_codigo = h.HDoc_DR1_Emp "
        strSQL &= "                             LEFT JOIN Proveedores p ON p.pro_sisemp = h.HDoc_Sis_Emp AND p.pro_codigo = h.HDoc_RF2_Num "
        strSQL &= "                         LEFT JOIN Clientes cl ON cl.cli_sisemp = h.HDoc_Sis_Emp AND cl.cli_codigo = h.HDoc_DR2_Emp "
        strSQL &= "                     LEFT JOIN Centros r1 ON r1.cen_empresa = h.HDoc_Sis_Emp AND r1.cen_codigo = h.HDoc_RF1_Num "
        strSQL &= "                 LEFT JOIN Empresas em ON em.emp_no = h.HDoc_Sis_Emp "
        strSQL &= "             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 677 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strSQL &= "    GROUP By h.HDoc_Sis_Emp , h.HDoc_Doc_Cat, h.HDoc_Doc_Ano  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{num}", Num)
        BuscarRegistrosDcmtos_ACC(strSQL)

        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
            strSQL2 = " SELECT
	                        IFNULL(d.DDoc_RF1_Txt,'') referencia, d.DDoc_Prd_Des descripcion, d.DDoc_Prd_QTY cantidad,
	                        d.DDoc_Prd_QTY peso, 
	                        d.DDoc_Prd_Net precio, 
	                        (d.DDoc_Prd_QTY * d.DDoc_Prd_Net)monto, 
	                        h.HDoc_Doc_TC tasa, 
	                        IFNULL(p.pro_proveedor,'N/A') fabricante, 
	                        IFNULL(i.inv_prodlote,'N/A') lote, d.DDoc_RF2_Num bultos
	                        ,IFNULL((SELECT cat_sist FROM Catalogos WHERE cat_clase='Empaque' AND cat_clave='Rampla'),0) pesoRampla
	                        ,IFNULL((SELECT cat_sist FROM Catalogos WHERE cat_clase='Empaque' AND cat_clave='Separador'),0) pesoSeparador 
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                        LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo= i.inv_provcod"
        Else
            strSQL2 = " SELECT IFNULL(d.DDoc_RF1_Txt,'') referencia, d.DDoc_Prd_Des descripcion, d.DDoc_Prd_QTY cantidad, d.DDoc_Prd_Net precio, (d.DDoc_Prd_QTY * d.DDoc_Prd_Net)monto, h.HDoc_Doc_TC tasa, p.pro_proveedor fabricante, i.inv_prodlote lote, d.DDoc_RF2_Num bultos "
            strSQL2 &= "    FROM Dcmtos_HDR h "
            strSQL2 &= "        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL2 &= "            LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL2 &= "                LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo= i.inv_provcod "
        End If
        strSQL2 &= "                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 677 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} -- AND h.HDoc_Doc_Status = 1 "
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", anio)
        strSQL2 = Replace(strSQL2, "{numero}", Num)
        BuscarRegistrosDcmtos_DTL(strSQL2)


        repCR.Load("C:\XML\Dcmtos_ACCTHN.xml")
        repCR.Load("C:\XML\Dcmtos_DTLTHN.xml")

        Dim frm3 As New FrmFacturaHN


        If Sesion.IdEmpresa = 20 Then
            frm3.Reporte_A_VerNS = repCR
        ElseIf Sesion.IdEmpresa = 15 Then
            frm3.Reporte_A_VerHSM = repCR
        Else
            frm3.Reporte_A_VerHN = repCR
        End If

        frm3.CrystalReportViewer1.ReportSource = repCR
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\Dcmtos_ACCTHN.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\Dcmtos_DTLTHN.xml")
    End Sub
    Private Sub BorrarEncabezadoTraslado(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 677
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDetalleTraslado(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "IDoc_Sis_Emp = {empresa}  AND IDoc_Doc_Cat = 677 AND IDoc_Doc_Ano = {anio} AND IDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim itm As New Tablas.TDCMTOS_DTL_ITM
            itm.CONEXION = strConexion
            itm.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDtl_ProTraslado(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = 677 AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Eventos"
    Private Sub frmTraslado_Load(sender As Object, e As EventArgs) Handles Me.Load
        intPais = verificarPais()
        dtpFechaFinal.Value = Today.ToString(FORMATO_MYSQL)
        dtpFechaInicial.Value = dtpFechaInicial.Value.AddMonths(NO_FILA).ToString(FORMATO_MYSQL)
        Accessos()
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                Dim opt As New frmOption
                opt.Titulo = "Type"
                opt.Opciones = "Transfers" & "|" & "Work in process"
                'opt.ShowDialog(Me)
                If opt.ShowDialog = DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case 0
                            intTipoTraslado = 0 ' Proceso Normal
                        Case 1
                            intTipoTraslado = 1 ' proceso específico para HSM-NS
                    End Select
                Else
                    Exit Sub
                End If
            End If
            LimpiarPanelOrden()
            MostrarLista(False, True)
            Encabezado1.botonBorrar.Enabled = False
            'CargarSerieDoc()
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                'CargarCAIDoc()
                celdaCAI.ReadOnly = True
                botonAplicante.Enabled = True
                botonTransporte.Enabled = True
                botonRazon.Enabled = True
            Else
                celdaCAI.Text = STR_VACIO
                celdaCAI.ReadOnly = False
                botonAplicante.Enabled = False
                botonTransporte.Enabled = False
                botonRazon.Enabled = False
            End If
            botonAgregarFactura.Enabled = True
            Button1.Enabled = True
        Else
            MsgBox("No Posee permisos para esta acción", vbInformation)
        End If
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = " p.pro_sisemp = {empresa} and p.pro_status = 'Activo'  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Providers"
            frm.Campos = " p.pro_proveedor proveedor, p.pro_direccion direccion, p.pro_nit nit, p.pro_codigo codigo "
            frm.Tabla = " Proveedores p"
            frm.FiltroText = " Enter the provider to filter"
            frm.Filtro = "  p.pro_proveedor "
            frm.Limite = 30
            frm.Ordenamiento = " p.pro_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaidCliente.Text = frm.Dato3
                celdaNombreCliente.Text = frm.LLave
                celdaDireccion.Text = frm.Dato
                celdaNit.Text = frm.Dato2
                celdaMoneda.Text = "US$"
                celdaIdMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
                If intTipoTraslado <> 1 Then
                    CargarDocumentosProcesados()
                    If MsgBox("Do you want the detail of the income to be displayed to Warehouse?", vbYesNo + vbQuestion, "Question") = vbYes Then
                        CargarDocumentosDetalle()
                    End If
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonContacto_Click(sender As Object, e As EventArgs)
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cnt_sisemp = {empresa} AND  c.cnt_codemp  = {cliente} AND c.cnt_status = 'Activo'  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{cliente}", celdaidCliente.Text)
        Try
            frm.Titulo = "Contact"
            frm.Campos = " CONCAT(c.cnt_nombre ,' | ',c.cnt_celular) Contacto "
            frm.Tabla = " Contactos c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cnt_nombre"
            frm.Limite = 30
            frm.Ordenamiento = " c.cnt_codemp "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                'celdaContacto.Text = frm.LLave

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim strFila As String = STR_VACIO
        If dgFactura.Rows.Count >= 1 Then
            dgFactura.CurrentRow.Cells(7).Value = 3
            For i As Integer = 0 To dgFactura.Rows.Count - 1

                If dgFactura.Rows(i).Cells("colStatus").Value = 3 Then
                    dgFactura.Rows(i).Cells("colStatus").Value = 0
                    celdaCatIngreso.Text = 47
                    celdaAnioIngreso.Text = dgFactura.Rows(i).Cells("col_anio").Value
                    celdaNumIngreso.Text = dgFactura.Rows(i).Cells("col_Numero").Value
                Else
                    dgFactura.Rows(i).Cells("colStatus").Value = 2
                    dgFactura.Rows(i).Visible = False
                End If


            Next

            dgDetalle.Rows.Clear()
            'CargarDatosCliente(celdaidCliente.Text)
            'CargarPolizaExportacion()
            CargarDocumentosDetalle()
            'Pedido()
        End If
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        End If
    End Sub

    Private Sub BotonMoneda_Click(sender As Object, e As EventArgs) Handles BotonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdMoneda.Text = frm.Dato
                celdaMoneda.Text = frm.LLave
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim Re As New frmRequisiciones
        Dim dblSaldo As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 7
                    If intTipoTraslado = 1 Then
                        Re.Codigo = 6
                        Re.Unico = True
                        Re.Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value
                        'Re.intnumero = dgDetalle.CurrentRow.Cells("colNumPoliza").Value
                        'Re.intaño = dgDetalle.CurrentRow.Cells("colAnioPoliza").Value
                        Re.dtFecha = dtpFecha.Value
                        Re.Proceso = True
                        Re.ShowDialog(Me)
                        Re.Hide()

                        If Re.Aceptado Then
                            For i As Integer = 0 To Re.dgLista.Rows.Count - 1
                                dblSaldo = Re.dgLista.Rows(i).Cells("colDescargo").Value
                                dblPrecio = CDbl(Re.dgLista.Rows(i).Cells("colPrecio").Value) + CDbl(Re.dgLista.Rows(i).Cells("colGFMO").Value)
                                If dblSaldo > vbEmpty Then
                                    dgDetalle.CurrentRow.Cells("colCantidad").Value = dblSaldo.ToString(FORMATO_MONEDA)
                                    dgDetalle.CurrentRow.Cells("colPrecio").Value = dblPrecio
                                End If
                            Next

                        End If
                    End If

                    '            Dim frmF As New frmDateTimePicker
                    '            frmF.ShowDialog(Me)
                    '            If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    '                dgDetalle.CurrentRow.Cells("col_envio").Value = frmF.LLave
                    '            End If
                    '        Case 13
                    '            Dim frmF As New frmDateTimePicker
                    '            frmF.ShowDialog(Me)
                    '            If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    '                dgDetalle.CurrentRow.Cells("col_presentado").Value = frmF.LLave
                    '            End If
                    '        Case 17
                    '            Dim frmF As New frmDateTimePicker
                    '            frmF.ShowDialog(Me)
                    '            If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    '                dgDetalle.CurrentRow.Cells("col_pago").Value = frmF.LLave
                    '            End If
            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer
        Dim numero As Integer
        Me.Tag = "Mod"
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        'captura el año,numero del panelprincipal dglista
        MostrarLista(0)
        año = dgLista.SelectedCells(0).Value
        numero = dgLista.SelectedCells(1).Value
        LimpiarPanelOrden()
        CargarEncabezado(numero, año)
        CargarReferencia(año, numero)
        CargarDetalle(numero, año)
        CargarFacturasRel(numero, año)
        SeleccionarSubdocumentos(año, numero)
        botonAgregarFactura.Enabled = False
        Button1.Enabled = False
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub

    Private Sub dgDetalle_SelectionChanged(sender As Object, e As EventArgs) Handles dgDetalle.SelectionChanged
        ' VerInformacionDeHilo()
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If logEditar = True Or Me.Tag = "Nuevo" Then
            If VerificarDatos() = True Then
                If GuardarDocumento(celdaNumero.Text, celdaAño.Text) = True Then
                    GuardarDetalle(celdaNumero.Text, celdaAño.Text)
                    GuardarRelacion(celdaNumero.Text, celdaAño.Text)
                    GuardarFacturasRel()
                    If Me.Tag = "Nuevo" Then
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 677, celdaAño.Text, celdaNumero.Text)
                        MsgBox("Successfully Saved Document", vbInformation, "Notice")
                    Else
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 677, celdaAño.Text, celdaNumero.Text)
                        MsgBox("Successfully Updated Document", vbInformation, "Notice")
                    End If

                    If MsgBox("Do you want to close the document?", vbQuestion + vbYesNo, "Notice") = vbYes Then
                        MostrarLista()
                    End If
                    Me.Tag = "Mod"
                End If
            Else
                MsgBox("Enter the minimum data to be able to Save", vbInformation)

            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub


    Private Sub botonAgregarFactura_Click(sender As Object, e As EventArgs) Handles botonAgregarFactura.Click
        If celdaidCliente.Text > 0 Then
            Dim frm As New frmSeleccionar
            Dim strTabla As String = STR_VACIO
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim strCampos As String = STR_VACIO
            Dim strAgrupar As String = STR_VACIO

            strTabla = " Dcmtos_HDR h "
            strTabla &= "  Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strTabla &= "      Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat =d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat = 677 "
            strCondicion = " h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 47 AND h.HDoc_Emp_Cod = {cod} AND (p.PDoc_Chi_Cat IS NULL OR p.PDoc_Chi_Cat = 677) "

            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{cod}", celdaidCliente.Text)

            strCampos = " h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Proveedor, h.HDoc_DR1_Num referencia, ROUND(d.DDoc_Prd_QTY - ( "
            strCampos &= "     Select IFNULL(SUM(o.PDoc_QTY_Pro),0) Dato "
            strCampos &= "         From Dcmtos_DTL_Pro o "
            strCampos &= "             WHERE o.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND o.PDoc_Par_Cat = d.DDoc_Doc_Cat AND o.PDoc_Par_Ano = d.DDoc_Doc_Ano AND o.PDoc_Par_Num = d.DDoc_Doc_Num AND (o.PDoc_Par_Lin = d.DDoc_Doc_Lin OR o.PDoc_Par_Lin IS NULL) AND (o.PDoc_Chi_Cat = 48 OR o.PDoc_Chi_Cat IS NULL))) AS Saldo"

            strAgrupar = " d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin HAVING Saldo > 1 "

            Try
                frm.Titulo = "Entry to Warehouse"
                frm.Campos = strCampos
                frm.Tabla = strTabla
                frm.Condicion = strCondicion
                frm.FiltroText = " Select a Warehouse Entry"
                frm.Filtro = " h.HDoc_DR1_Num "
                frm.Agrupar = strAgrupar

                frm.Ordenamiento = " h.HDoc_Doc_Ano DESC,"
                frm.TipoOrdenamiento = " h.HDoc_Doc_Num DESC"

                frm.ShowDialog(Me)

                If frm.DialogResult = DialogResult.OK Then
                    strFila = 47 & "|"
                    strFila &= frm.ListaClientes.SelectedCells(0).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(4).Value & "|"
                    strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                    strFila &= INT_CERO

                    cFunciones.AgregarFila(dgFactura, strFila)
                    If Me.Tag = "Nuevo" Then
                        CargarDocumentosDetalle()
                    End If
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        dgFactura.CurrentRow.Cells(7).Value = 2
        dgFactura.CurrentRow.Visible = False
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, catalogos,)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Try
            If logConsultar = True Then
                ImpresionTraslado(celdaAño.Text, celdaNumero.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgSubdocumentos_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgSubdocumentos.CellContentClick

    End Sub

    Private Sub dgSubdocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgSubdocumentos.DoubleClick
        If Me.Tag = "Mod" Then
            Dim SDoc As New frmSubDocumentos

            Select Case dgSubdocumentos.CurrentCell.ColumnIndex
                Case 2

                    SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                    SDoc.Año = celdaAño.Text
                    SDoc.Numero = celdaNumero.Text
                    SDoc.Doc = dgSubdocumentos.SelectedCells(0).Value
                    SDoc.Catalogo = catalogos
                    SDoc.btnImprimir.Enabled = False

                    'SubDocumentos desde facturacion, parametros
                    Dim anios As New List(Of String)
                    Dim numFactura As New List(Of String)

                    For Each row As DataGridViewRow In dgFacturaRel.Rows
                        If Not row.IsNewRow Then ' Evita la fila vacía al final
                            Dim valorAnio As Object = row.Cells("colAnioFac").Value
                            If valorAnio IsNot Nothing Then
                                anios.Add(valorAnio.ToString())
                            End If

                            Dim valorFact As Object = row.Cells("colNumeroFac").Value
                            If valorFact IsNot Nothing Then
                                numFactura.Add(valorFact.ToString())
                            End If
                        End If
                    Next

                    SDoc.anioFact = String.Join(", ", anios)
                    SDoc.numFactura = String.Join(", ", numFactura)

                    'SDoc.anioFact = dgFacturaRel.CurrentRow.Cells("colAnioP").Value
                    'SDoc.numFactura = dgFacturaRel.CurrentRow.Cells("colNumeroP").Value

                    SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea").Value
                    SDoc.ShowDialog(Me)
            End Select
        Else
            MsgBox("Save the Document first", vbInformation, "Notice")
        End If
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim dblTotalLine As Double = 0
        Dim dblTotalDoc As Double = 0
        Dim dblTotalCantidad As Double = 0
        dblTotalLine = (dgDetalle.CurrentRow.Cells("colPrecio").Value) * (dgDetalle.CurrentRow.Cells("colCantidad").Value)
        dgDetalle.CurrentRow.Cells("colTotal").Value = dblTotalLine.ToString(FORMATO_MONEDA)

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If Not dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                dblTotalDoc = dblTotalDoc + dgDetalle.CurrentRow.Cells("colTotal").Value
                dblTotalCantidad = dblTotalCantidad + dgDetalle.CurrentRow.Cells("colCantidad").Value
            End If
        Next
        celdaCantidad.Text = dblTotalCantidad.ToString(FORMATO_MONEDA)
        celdaTotal.Text = dblTotalDoc.ToString(FORMATO_MONEDA)
    End Sub

    Private Sub dgFactura_KeyDown(sender As Object, e As KeyEventArgs) Handles dgFactura.KeyDown
        If e.KeyCode = Keys.F3 Then
            cFunciones.BuscarenLista(dgFactura)
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub botonAplicante_Click(sender As Object, e As EventArgs) Handles botonAplicante.Click

        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = " c.cen_empresa = {empresa} AND c.cen_codigo > 1  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Addresses"
            frm.Campos = " c.cen_codigo codigo,c.cen_direccion direccion,c.cen_descripcion descripcion "
            frm.Tabla = " Centros c "
            frm.FiltroText = " Enter the address to filter "
            frm.Filtro = "  c.cen_direccion "
            frm.Limite = 30
            frm.Ordenamiento = " c.cen_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdAplicante.Text = frm.LLave
                celdaDireccion2.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonTransporte_Click(sender As Object, e As EventArgs) Handles botonTransporte.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "  p.pro_sisemp = {empresa} AND pro_fabricante = 'No'  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Transport"
            frm.Campos = " p.pro_codigo codigo, p.pro_proveedor proveedor "
            frm.Tabla = " Proveedores p "
            frm.FiltroText = " Enter the provider to filter "
            frm.Filtro = "  p.pro_proveedor "
            frm.Limite = 20
            frm.Ordenamiento = " p.pro_proveedor "
            frm.TipoOrdenamiento = "ASC"
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdTransporte.Text = frm.LLave
                celdaTransporte.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonRazon_Click(sender As Object, e As EventArgs) Handles botonRazon.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Transfer reason"
            frm.Campos = " c.cat_clave inciso, c.cat_desc Razon, c.cat_num numero  "
            frm.Tabla = " Catalogos c "
            frm.Condicion = " c.cat_clase = 'Razon_Traslado' "
            frm.FiltroText = "Enter the reason to filter"
            frm.Filtro = " c.cat_desc "
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = "ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaRazon.Text = frm.Dato
                celdaIdRazon.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonDestino_Click(sender As Object, e As EventArgs) Handles botonDestino.Click
        Dim frm As New frmSeleccionar
        If checkTranseferencia.Checked = True Then
            Dim strCondicion As String = STR_VACIO
            strCondicion = " c.cen_empresa = {empresa} AND c.cen_codigo > 1  "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            Try
                frm.Titulo = "Addresses"
                frm.Campos = " c.cen_codigo codigo,c.cen_direccion direccion,c.cen_descripcion descripcion "
                frm.Tabla = " Centros c "
                frm.FiltroText = " Enter the address to filter "
                frm.Filtro = "  c.cen_direccion "
                frm.Limite = 30
                frm.Ordenamiento = " c.cen_codigo "
                frm.TipoOrdenamiento = ""
                frm.Condicion = strCondicion

                'frm.ShowDialog(Me)
                'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                '    celdaIdAplicante.Text = frm.LLave
                '    celdaDireccion2.Text = frm.Dato
                'End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            'Me.Tag = "Nuevo"

            Dim strCondicion As String = STR_VACIO
            strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            Try
                frm.Titulo = "Client"
                frm.Campos = " c.cli_codigo , c.cli_cliente "
                frm.Tabla = " Clientes c"
                frm.FiltroText = " Enter the client to filter"
                frm.Filtro = "  c.cli_cliente"
                frm.Limite = 30
                frm.Ordenamiento = " c.cli_codigo "
                frm.TipoOrdenamiento = ""
                frm.Condicion = strCondicion
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
        frm.ShowDialog(Me)
        If frm.DialogResult = DialogResult.OK Then
            celdaidDestino.Text = frm.LLave
            celdaDestino.Text = frm.Dato
        End If

    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Try
            If LogBorrar = True Then
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarEncabezadoTraslado(celdaNumero.Text, celdaAño.Text)
                    BorrarDetalleTraslado(celdaNumero.Text, celdaAño.Text)
                    BorrarDtl_ProTraslado(celdaNumero.Text, celdaAño.Text)
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 677, celdaAño.Text, celdaNumero.Text)
                    MostrarLista()
                End If
            Else
                MsgBox("You do not have permission for this action", vbInformation, "Notice")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub botonSerie_Click(sender As Object, e As EventArgs) Handles botonSerie.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Series"
            frm.Campos = " cat_num ID, cat_sist Serie, cat_ext Lugar "
            frm.Tabla = " Catalogos "
            frm.FiltroText = " Enter the Serie to filter"
            frm.Filtro = "  cat_sist "
            frm.Limite = 30
            frm.Ordenamiento = " cat_num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = " cat_clase = 'Serie' AND cat_clave = 'Doc_GRemision' AND cat_pid = 0"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdSerie.Text = frm.LLave
                celdaSerie.Text = frm.Dato
                CargarCAIDoc()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgrega_Click(sender As Object, e As EventArgs) Handles botonAgrega.Click
        Dim strFilaAdd As String = STR_VACIO
        strFilaAdd = 0 & "|" 'codigo
        strFilaAdd &= vbNullString & "|" ' artículo
        strFilaAdd &= vbNullString & "|" ' Referencia
        strFilaAdd &= 69 & "|" ' idMedida
        strFilaAdd &= 0 & "|" 'linea
        strFilaAdd &= "LBS" & "|" 'Medida
        strFilaAdd &= 0.00 & "|" ' precio
        strFilaAdd &= 0.00 & "|" ' cantidad
        strFilaAdd &= 1 & "|" 'paquetes
        strFilaAdd &= 0.00 & "|" ' total
        strFilaAdd &= 0 & "|" 'catálogo
        strFilaAdd &= 0 & "|" 'año
        strFilaAdd &= 0 & "|" 'número
        strFilaAdd &= 0 & "|" 'linea
        strFilaAdd &= 0  'extra
        cfun.AgregarFila(dgDetalle, strFilaAdd)

        dgDetalle.CurrentRow.Cells("colProducto").ReadOnly = False
        dgDetalle.CurrentRow.Cells("colRefIngreso").ReadOnly = False
        dgDetalle.CurrentRow.Cells("colPrecio").ReadOnly = False
        dgDetalle.CurrentRow.Cells("colCantidad").ReadOnly = False
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        dgDetalle.CurrentRow.Cells("colExtra").Value = 2
        dgDetalle.CurrentRow.Visible = False
    End Sub

    Private Sub botonAgregarFact_Click(sender As Object, e As EventArgs) Handles botonAgregarFact.Click
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim fecha As DateTime
        Dim año As Integer = INT_CERO
        Dim i As Integer = INT_CERO

        Try
            'ReferenciaCortar nombre de columna para que frmSeleccionar recorte y renombra a Referencia
            frm.Titulo = "Invoices"
            frm.Campos = "h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, concat_ws(' ',h.HDoc_DR1_Num,h.HDoc_DR2_Num) ReferenciaCortar,
                        h.HDoc_RF1_Dbl Monto,c.cat_desc Moneda,  h.HDoc_Doc_TC TC, h.HDoc_Ant_Com FactEsp, h.HDoc_Doc_Cat catalogo, h.HDoc_DR1_Dbl FacturaNumero "

            'h.HDoc_Doc_Ano Anio,
            '	h.HDoc_Doc_Fec fecha, 
            '	h.HDoc_Doc_Num numero, 
            '	h.HDoc_Usuario usuario, 
            '	concat_ws(' ',h.HDoc_DR1_Num,h.HDoc_DR2_Num) Referencia,
            '	h.HDoc_RF1_Dbl Monto,  
            '	c.cat_desc Moneda,
            '	h.HDoc_Doc_TC TC, 
            '	h.HDoc_Ant_Com FactEsp, 
            '	1 extra ,
            '	h.HDoc_Doc_Cat catalogo,
            '	0 calISR,
            '	i.IDoc_Doc_Lin linea

            frm.Tabla = "Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano AND d.DDoc_Doc_Num=h.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp=h.HDoc_Sis_Emp 
                            -- datos Traslado
	                            AND a.ADoc_Doc_Cat=677 
                            -- AND a.ADoc_Doc_Ano=" & celdaAño.Text & " AND a.ADoc_Doc_Num=" & celdaNumero.Text & "
                            -- datos factura
	                            AND a.ADoc_Doc_Sub='FactRel' 
	                            AND a.ADoc_Dta_Mny=h.HDoc_Doc_Cat
	                            AND a.ADoc_Dta_Wht=h.HDoc_Doc_Ano
	                            AND a.ADoc_Dta_Num=h.HDoc_Doc_Num
                            LEFT JOIN Catalogos c ON c.cat_num=h.HDoc_Doc_Mon AND c.cat_clase='Monedas'
                            LEFT JOIN Dcmtos_DTL_Itm i ON i.IDoc_Sis_Emp = h.HDoc_Sis_Emp
	                            AND i.IDoc_RF1_Num=h.HDoc_Doc_Cat
	                            AND i.IDoc_RF1_Cod=h.HDoc_Doc_Ano
	                            AND i.IDoc_RF1_Dbl=h.HDoc_Doc_Num
	                            AND i.IDoc_Sis_Emp IS NULL "
            frm.Condicion = "h.HDoc_Sis_Emp =  " & Sesion.IdEmpresa & " 
	                        AND h.HDoc_Doc_Cat=36
	                        -- AND h.HDoc_Emp_Cod = " & celdaidCliente.Text & "
	                        AND h.HDoc_Doc_Fec > '2025-01-01'
	                        AND h.HDoc_Doc_Status = 1
	                        AND a.ADoc_Sis_Emp IS NULL "
            frm.FiltroText = " Enter the receipt to filter "
            frm.Ordenamiento = " h.HDoc_DR1_Dbl  "
            frm.Agrupar = "h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num"
            frm.TipoOrdenamiento = " DESC "
            frm.Filtro = "  CONCAT(h.HDoc_DR1_DBL, h.HDoc_Emp_Nom) "
            frm.Limite = 15


            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                For i = 0 To dgFacturaRel.Rows.Count - 1
                    If dgFacturaRel.Rows(i).Cells("colNumeroFac").Value = frm.Dato And dgFacturaRel.Rows(i).Visible = True Then
                        If MsgBox("This document is already uploaded please upload a different one", vbOKOnly, "Notice") = vbOK Then
                            Exit Sub
                        End If
                    End If
                Next


                fecha = frm.LLave
                año = fecha.Year

                strFila = año & "|"
                strFila &= frm.LLave & "|"
                strFila &= frm.Dato & "|"
                strFila &= frm.Dato2 & "|"
                strFila &= frm.Dato3 & "|"
                strFila &= frm.Dato4 & "|" '#5
                strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(6).Value & "|"
                strFila &= 0 & "|" '#8
                strFila &= 0 & "|" '#9
                strFila &= 0 & "|"
                strFila &= 0 & "|"
                strFila &= i & "|" '#12
                strFila &= frm.ListaClientes.SelectedCells(9).Value '#13

                cFunciones.AgregarFila(dgFacturaRel, strFila)

            End If

            'If celdaRecibos.Text = 1 Then
            '    dgFactura.Columns("colCalISR").Visible = True
            'End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarFacturasRel() As Boolean
        Dim cDTL As New Tablas.TDCMTOS_DTL_ITM
        Dim logDetalle As Boolean = False
        Dim j As Integer = 0
        Try
            For i As Integer = 0 To dgFacturaRel.Rows.Count - 1
                cDTL.CONEXION = strConexion
                cDTL.IDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.IDOC_DOC_CAT = 677
                cDTL.IDOC_DOC_ANO = celdaAño.Text
                cDTL.IDOC_DOC_NUM = celdaNumero.Text
                cDTL.IDOC_RF1_NUM = 36
                cDTL.IDOC_RF1_COD = dgFacturaRel.Rows(i).Cells("colAnioFac").Value
                cDTL.IDOC_RF1_DBL = dgFacturaRel.Rows(i).Cells("colNumeroFac").Value

                If Me.Tag = "Nuevo" Then
                    If dgFacturaRel.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    cDTL.IDOC_DOC_LIN = j
                Else
                    cDTL.IDOC_DOC_LIN = dgFacturaRel.Rows(i).Cells("DataGridViewTextBoxColumn1").Value
                End If

                If dgFacturaRel.Rows(i).Cells("colExtraFact").Value = 1 And Me.Tag = "Mod" Then
                    If cDTL.PUPDATE() = False Then
                        MsgBox(cDTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgFacturaRel.Rows(i).Cells("colExtraFact").Value = 0 And (Me.Tag = "Nuevo" Or Me.Tag = "Mod") Then
                    If cDTL.PINSERT() = False Then
                        MsgBox(cDTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function
    Private Sub botonQuitarFact_Click(sender As Object, e As EventArgs) Handles botonQuitarFact.Click
        If dgFactura.SelectedRows.Count = INT_CERO Then Exit Sub
        dgFactura.CurrentRow.Cells("colExtraFact").Value = 2
        dgFactura.CurrentRow.Visible = False
        dgFactura.Focus()
    End Sub
#End Region

End Class