﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGastoProduccion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidGasto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGasto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPromedio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.PanelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFecha)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 126)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(763, 90)
        Me.panelListaPrincipal.TabIndex = 5
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumber, Me.colDate})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 54)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowHeadersWidth = 51
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(763, 36)
        Me.dgLista.TabIndex = 3
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.MinimumWidth = 6
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 125
        '
        'colNumber
        '
        Me.colNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.MinimumWidth = 6
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        Me.colNumber.Width = 87
        '
        'colDate
        '
        Me.colDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDate.HeaderText = "Date"
        Me.colDate.MinimumWidth = 6
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        Me.colDate.Width = 67
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(763, 54)
        Me.panelFecha.TabIndex = 2
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(581, 15)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(435, 17)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(361, 21)
        Me.etiquetaFin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(243, 16)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 21)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(224, 21)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.PanelDetalle)
        Me.PanelDocumento.Controls.Add(Me.PanelEncabezado)
        Me.PanelDocumento.Location = New System.Drawing.Point(16, 223)
        Me.PanelDocumento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(731, 316)
        Me.PanelDocumento.TabIndex = 6
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 127)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(731, 189)
        Me.PanelDetalle.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colidGasto, Me.colGasto, Me.colPromedio, Me.colTotal1, Me.colTotal2, Me.colTotal})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowHeadersWidth = 51
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(731, 189)
        Me.dgDetalle.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.MinimumWidth = 6
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 125
        '
        'colidGasto
        '
        Me.colidGasto.HeaderText = "idGasto"
        Me.colidGasto.MinimumWidth = 6
        Me.colidGasto.Name = "colidGasto"
        Me.colidGasto.ReadOnly = True
        Me.colidGasto.Width = 125
        '
        'colGasto
        '
        Me.colGasto.HeaderText = "Expense"
        Me.colGasto.MinimumWidth = 6
        Me.colGasto.Name = "colGasto"
        Me.colGasto.ReadOnly = True
        Me.colGasto.Width = 125
        '
        'colPromedio
        '
        Me.colPromedio.HeaderText = "Average"
        Me.colPromedio.MinimumWidth = 6
        Me.colPromedio.Name = "colPromedio"
        Me.colPromedio.Width = 125
        '
        'colTotal1
        '
        Me.colTotal1.HeaderText = ""
        Me.colTotal1.MinimumWidth = 6
        Me.colTotal1.Name = "colTotal1"
        Me.colTotal1.Width = 125
        '
        'colTotal2
        '
        Me.colTotal2.HeaderText = ""
        Me.colTotal2.MinimumWidth = 6
        Me.colTotal2.Name = "colTotal2"
        Me.colTotal2.Width = 125
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.MinimumWidth = 6
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 125
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.celdaEstado)
        Me.PanelEncabezado.Controls.Add(Me.botonMoneda)
        Me.PanelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.PanelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.PanelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.PanelEncabezado.Controls.Add(Me.celdaTasa)
        Me.PanelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.PanelEncabezado.Controls.Add(Me.celdaNumero)
        Me.PanelEncabezado.Controls.Add(Me.Label1)
        Me.PanelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.PanelEncabezado.Controls.Add(Me.celdaAnio)
        Me.PanelEncabezado.Controls.Add(Me.dtpFecha)
        Me.PanelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(731, 127)
        Me.PanelEncabezado.TabIndex = 0
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(175, 95)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(33, 23)
        Me.botonMoneda.TabIndex = 62
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(285, 11)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.ReadOnly = True
        Me.celdaIdMoneda.Size = New System.Drawing.Size(31, 22)
        Me.celdaIdMoneda.TabIndex = 61
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(83, 95)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(76, 22)
        Me.celdaMoneda.TabIndex = 60
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(17, 95)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 59
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(268, 94)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 22)
        Me.celdaTasa.TabIndex = 58
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(223, 95)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 57
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(83, 63)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(124, 22)
        Me.celdaNumero.TabIndex = 54
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(21, 17)
        Me.Label1.TabIndex = 53
        Me.Label1.Text = "ID"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(15, 37)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 51
        Me.etiquetaAnio.Text = "Year"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(83, 32)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(124, 22)
        Me.celdaAnio.TabIndex = 52
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(83, 4)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(124, 22)
        Me.dtpFecha.TabIndex = 50
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(15, 11)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 49
        Me.etiquetaFecha.Text = "Date"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(763, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(763, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'celdaEstado
        '
        Me.celdaEstado.Location = New System.Drawing.Point(285, 34)
        Me.celdaEstado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.ReadOnly = True
        Me.celdaEstado.Size = New System.Drawing.Size(31, 22)
        Me.celdaEstado.TabIndex = 63
        Me.celdaEstado.Visible = False
        '
        'frmGastoProduccion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(763, 554)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmGastoProduccion"
        Me.Text = "frmGastoProduccion"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.PanelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelEncabezado.ResumeLayout(False)
        Me.PanelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents PanelEncabezado As Panel
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colidGasto As DataGridViewTextBoxColumn
    Friend WithEvents colGasto As DataGridViewTextBoxColumn
    Friend WithEvents colPromedio As DataGridViewTextBoxColumn
    Friend WithEvents colTotal1 As DataGridViewTextBoxColumn
    Friend WithEvents colTotal2 As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents celdaEstado As TextBox
End Class
