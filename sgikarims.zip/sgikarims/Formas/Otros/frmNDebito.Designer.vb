﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmNDebito
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmNDebito))
        Me.panelNotasDebito = New System.Windows.Forms.Panel()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelImpuestos = New System.Windows.Forms.Panel()
        Me.dgImpuestos = New System.Windows.Forms.DataGridView()
        Me.colLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCanti = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTag = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaTotalLetras = New System.Windows.Forms.TextBox()
        Me.celdaSubTotal = New System.Windows.Forms.TextBox()
        Me.CeldaTotalEnLetras = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescription = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnitario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbInformación = New System.Windows.Forms.GroupBox()
        Me.rbOtros = New System.Windows.Forms.RadioButton()
        Me.rbDifPrecio = New System.Windows.Forms.RadioButton()
        Me.celdaNotasObservaciones = New System.Windows.Forms.TextBox()
        Me.etiquetraNotasObservaciones = New System.Windows.Forms.Label()
        Me.celdaDeclaracion = New System.Windows.Forms.TextBox()
        Me.EtiquetaDeclaracion = New System.Windows.Forms.Label()
        Me.celdaTasaFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaTasaFactura = New System.Windows.Forms.Label()
        Me.gbFacturas = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonAgregarFactura = New System.Windows.Forms.Button()
        Me.dgFacturacion = New System.Windows.Forms.DataGridView()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReference = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroFisico = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbDatosDocumento = New System.Windows.Forms.GroupBox()
        Me.celdaUIDDFact = New System.Windows.Forms.TextBox()
        Me.celdaSerieFel = New System.Windows.Forms.TextBox()
        Me.celdaFechaHoraCertificacion = New System.Windows.Forms.TextBox()
        Me.celdaFechaEmisionDocumento = New System.Windows.Forms.TextBox()
        Me.celdaUUID = New System.Windows.Forms.TextBox()
        Me.celdaRangoFechaAutorizado = New System.Windows.Forms.TextBox()
        Me.celdaTemporal = New System.Windows.Forms.TextBox()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.celdaSerie1 = New System.Windows.Forms.TextBox()
        Me.celdaCAI = New System.Windows.Forms.TextBox()
        Me.etiquetaCAI = New System.Windows.Forms.Label()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.checkRevisado = New System.Windows.Forms.CheckBox()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.dtpFech = New System.Windows.Forms.DateTimePicker()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.botonClientes = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAutorizacionF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.botonPrevio = New System.Windows.Forms.Button()
        Me.etiquetaAutorizacion = New System.Windows.Forms.Label()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelNotasDebito.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.panelImpuestos.SuspendLayout()
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelTotales.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbInformación.SuspendLayout()
        Me.gbFacturas.SuspendLayout()
        CType(Me.dgFacturacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDatosDocumento.SuspendLayout()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelNotasDebito
        '
        Me.panelNotasDebito.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelNotasDebito.Controls.Add(Me.panelDocumento)
        Me.panelNotasDebito.Location = New System.Drawing.Point(14, 98)
        Me.panelNotasDebito.Name = "panelNotasDebito"
        Me.panelNotasDebito.Size = New System.Drawing.Size(865, 835)
        Me.panelNotasDebito.TabIndex = 4
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.panelImpuestos)
        Me.panelDocumento.Controls.Add(Me.panelTotales)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.gbInformación)
        Me.panelDocumento.Controls.Add(Me.gbFacturas)
        Me.panelDocumento.Controls.Add(Me.gbDatosDocumento)
        Me.panelDocumento.Location = New System.Drawing.Point(3, 3)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(818, 603)
        Me.panelDocumento.TabIndex = 5
        '
        'panelImpuestos
        '
        Me.panelImpuestos.Controls.Add(Me.dgImpuestos)
        Me.panelImpuestos.Location = New System.Drawing.Point(16, 529)
        Me.panelImpuestos.Name = "panelImpuestos"
        Me.panelImpuestos.Size = New System.Drawing.Size(718, 100)
        Me.panelImpuestos.TabIndex = 1
        '
        'dgImpuestos
        '
        Me.dgImpuestos.AllowUserToAddRows = False
        Me.dgImpuestos.AllowUserToDeleteRows = False
        Me.dgImpuestos.AllowUserToOrderColumns = True
        Me.dgImpuestos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgImpuestos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgImpuestos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgImpuestos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLin, Me.colID, Me.colCode, Me.colTipo, Me.colDescripcion, Me.colBase, Me.colCanti, Me.colFactor, Me.colMonto, Me.colTag, Me.colOrigen})
        Me.dgImpuestos.Location = New System.Drawing.Point(11, 12)
        Me.dgImpuestos.Name = "dgImpuestos"
        Me.dgImpuestos.Size = New System.Drawing.Size(704, 84)
        Me.dgImpuestos.TabIndex = 0
        Me.dgImpuestos.Visible = False
        '
        'colLin
        '
        Me.colLin.HeaderText = "Line"
        Me.colLin.Name = "colLin"
        '
        'colID
        '
        Me.colID.HeaderText = "ID"
        Me.colID.Name = "colID"
        '
        'colCode
        '
        Me.colCode.HeaderText = "Codigo"
        Me.colCode.Name = "colCode"
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Descripcion"
        Me.colDescripcion.Name = "colDescripcion"
        '
        'colBase
        '
        Me.colBase.HeaderText = "Base"
        Me.colBase.Name = "colBase"
        '
        'colCanti
        '
        Me.colCanti.HeaderText = "Cantidad"
        Me.colCanti.Name = "colCanti"
        '
        'colFactor
        '
        Me.colFactor.HeaderText = "Factor"
        Me.colFactor.Name = "colFactor"
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Monto"
        Me.colMonto.Name = "colMonto"
        '
        'colTag
        '
        Me.colTag.HeaderText = "Tag"
        Me.colTag.Name = "colTag"
        '
        'colOrigen
        '
        Me.colOrigen.HeaderText = "Origen"
        Me.colOrigen.Name = "colOrigen"
        '
        'panelTotales
        '
        Me.panelTotales.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelTotales.Controls.Add(Me.celdaTotalLetras)
        Me.panelTotales.Controls.Add(Me.celdaSubTotal)
        Me.panelTotales.Controls.Add(Me.CeldaTotalEnLetras)
        Me.panelTotales.Controls.Add(Me.etiquetaTotal)
        Me.panelTotales.Controls.Add(Me.celdaTotal)
        Me.panelTotales.Location = New System.Drawing.Point(4, 445)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(808, 78)
        Me.panelTotales.TabIndex = 12
        '
        'celdaTotalLetras
        '
        Me.celdaTotalLetras.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotalLetras.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.celdaTotalLetras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotalLetras.Location = New System.Drawing.Point(9, 3)
        Me.celdaTotalLetras.Name = "celdaTotalLetras"
        Me.celdaTotalLetras.Size = New System.Drawing.Size(112, 13)
        Me.celdaTotalLetras.TabIndex = 13
        Me.celdaTotalLetras.Text = "ToTal En Letras:"
        Me.celdaTotalLetras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaSubTotal
        '
        Me.celdaSubTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSubTotal.Location = New System.Drawing.Point(592, 9)
        Me.celdaSubTotal.Name = "celdaSubTotal"
        Me.celdaSubTotal.Size = New System.Drawing.Size(100, 20)
        Me.celdaSubTotal.TabIndex = 5
        Me.celdaSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CeldaTotalEnLetras
        '
        Me.CeldaTotalEnLetras.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaTotalEnLetras.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaTotalEnLetras.Location = New System.Drawing.Point(9, 16)
        Me.CeldaTotalEnLetras.Multiline = True
        Me.CeldaTotalEnLetras.Name = "CeldaTotalEnLetras"
        Me.CeldaTotalEnLetras.Size = New System.Drawing.Size(560, 46)
        Me.CeldaTotalEnLetras.TabIndex = 12
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(548, 12)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaTotal.TabIndex = 4
        Me.etiquetaTotal.Text = "Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Location = New System.Drawing.Point(706, 8)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(97, 20)
        Me.celdaTotal.TabIndex = 6
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel2)
        Me.panelDetalle.Location = New System.Drawing.Point(7, 327)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(806, 114)
        Me.panelDetalle.TabIndex = 8
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.dgDetalle)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(806, 114)
        Me.Panel2.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCantidad, Me.colDescription, Me.colUnitario, Me.colTotal})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(806, 114)
        Me.dgDetalle.TabIndex = 0
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCantidad.HeaderText = "Amount"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 68
        '
        'colDescription
        '
        Me.colDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDescription.HeaderText = "Description"
        Me.colDescription.Name = "colDescription"
        Me.colDescription.Width = 85
        '
        'colUnitario
        '
        Me.colUnitario.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colUnitario.HeaderText = "Unitary$"
        Me.colUnitario.Name = "colUnitario"
        Me.colUnitario.Width = 71
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTotal.HeaderText = "Total$"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 62
        '
        'gbInformación
        '
        Me.gbInformación.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbInformación.Controls.Add(Me.rbOtros)
        Me.gbInformación.Controls.Add(Me.rbDifPrecio)
        Me.gbInformación.Controls.Add(Me.celdaNotasObservaciones)
        Me.gbInformación.Controls.Add(Me.etiquetraNotasObservaciones)
        Me.gbInformación.Controls.Add(Me.celdaDeclaracion)
        Me.gbInformación.Controls.Add(Me.EtiquetaDeclaracion)
        Me.gbInformación.Controls.Add(Me.celdaTasaFactura)
        Me.gbInformación.Controls.Add(Me.etiquetaTasaFactura)
        Me.gbInformación.Location = New System.Drawing.Point(433, 128)
        Me.gbInformación.Name = "gbInformación"
        Me.gbInformación.Size = New System.Drawing.Size(379, 192)
        Me.gbInformación.TabIndex = 3
        Me.gbInformación.TabStop = False
        Me.gbInformación.Text = "Additional Information"
        '
        'rbOtros
        '
        Me.rbOtros.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbOtros.AutoSize = True
        Me.rbOtros.Location = New System.Drawing.Point(248, 64)
        Me.rbOtros.Name = "rbOtros"
        Me.rbOtros.Size = New System.Drawing.Size(56, 17)
        Me.rbOtros.TabIndex = 16
        Me.rbOtros.TabStop = True
        Me.rbOtros.Text = "Others"
        Me.rbOtros.UseVisualStyleBackColor = True
        '
        'rbDifPrecio
        '
        Me.rbDifPrecio.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbDifPrecio.AutoSize = True
        Me.rbDifPrecio.Location = New System.Drawing.Point(248, 28)
        Me.rbDifPrecio.Name = "rbDifPrecio"
        Me.rbDifPrecio.Size = New System.Drawing.Size(101, 17)
        Me.rbDifPrecio.TabIndex = 14
        Me.rbDifPrecio.TabStop = True
        Me.rbDifPrecio.Text = "Price Difference"
        Me.rbDifPrecio.UseVisualStyleBackColor = True
        '
        'celdaNotasObservaciones
        '
        Me.celdaNotasObservaciones.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNotasObservaciones.Location = New System.Drawing.Point(5, 126)
        Me.celdaNotasObservaciones.Multiline = True
        Me.celdaNotasObservaciones.Name = "celdaNotasObservaciones"
        Me.celdaNotasObservaciones.Size = New System.Drawing.Size(370, 60)
        Me.celdaNotasObservaciones.TabIndex = 13
        '
        'etiquetraNotasObservaciones
        '
        Me.etiquetraNotasObservaciones.AutoSize = True
        Me.etiquetraNotasObservaciones.Location = New System.Drawing.Point(7, 109)
        Me.etiquetraNotasObservaciones.Name = "etiquetraNotasObservaciones"
        Me.etiquetraNotasObservaciones.Size = New System.Drawing.Size(124, 13)
        Me.etiquetraNotasObservaciones.TabIndex = 12
        Me.etiquetraNotasObservaciones.Text = "Notes  and Observations"
        '
        'celdaDeclaracion
        '
        Me.celdaDeclaracion.BackColor = System.Drawing.SystemColors.Window
        Me.celdaDeclaracion.Enabled = False
        Me.celdaDeclaracion.Location = New System.Drawing.Point(121, 50)
        Me.celdaDeclaracion.Name = "celdaDeclaracion"
        Me.celdaDeclaracion.Size = New System.Drawing.Size(97, 20)
        Me.celdaDeclaracion.TabIndex = 3
        Me.celdaDeclaracion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'EtiquetaDeclaracion
        '
        Me.EtiquetaDeclaracion.AutoSize = True
        Me.EtiquetaDeclaracion.Location = New System.Drawing.Point(5, 54)
        Me.EtiquetaDeclaracion.Name = "EtiquetaDeclaracion"
        Me.EtiquetaDeclaracion.Size = New System.Drawing.Size(61, 13)
        Me.EtiquetaDeclaracion.TabIndex = 2
        Me.EtiquetaDeclaracion.Text = "Declaration"
        '
        'celdaTasaFactura
        '
        Me.celdaTasaFactura.BackColor = System.Drawing.SystemColors.Window
        Me.celdaTasaFactura.Enabled = False
        Me.celdaTasaFactura.Location = New System.Drawing.Point(121, 21)
        Me.celdaTasaFactura.Name = "celdaTasaFactura"
        Me.celdaTasaFactura.Size = New System.Drawing.Size(97, 20)
        Me.celdaTasaFactura.TabIndex = 1
        Me.celdaTasaFactura.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaTasaFactura
        '
        Me.etiquetaTasaFactura.AutoSize = True
        Me.etiquetaTasaFactura.Location = New System.Drawing.Point(6, 24)
        Me.etiquetaTasaFactura.Name = "etiquetaTasaFactura"
        Me.etiquetaTasaFactura.Size = New System.Drawing.Size(71, 13)
        Me.etiquetaTasaFactura.TabIndex = 0
        Me.etiquetaTasaFactura.Text = "Rate(Invoice)"
        '
        'gbFacturas
        '
        Me.gbFacturas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFacturas.Controls.Add(Me.Button1)
        Me.gbFacturas.Controls.Add(Me.botonAgregarFactura)
        Me.gbFacturas.Controls.Add(Me.dgFacturacion)
        Me.gbFacturas.Location = New System.Drawing.Point(436, 8)
        Me.gbFacturas.Name = "gbFacturas"
        Me.gbFacturas.Size = New System.Drawing.Size(376, 119)
        Me.gbFacturas.TabIndex = 2
        Me.gbFacturas.TabStop = False
        Me.gbFacturas.Text = "Invoice"
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.row_delete
        Me.Button1.Location = New System.Drawing.Point(340, 73)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(31, 29)
        Me.Button1.TabIndex = 11
        Me.Button1.UseVisualStyleBackColor = True
        '
        'botonAgregarFactura
        '
        Me.botonAgregarFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregarFactura.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregarFactura.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarFactura.Location = New System.Drawing.Point(340, 41)
        Me.botonAgregarFactura.Name = "botonAgregarFactura"
        Me.botonAgregarFactura.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregarFactura.TabIndex = 10
        Me.botonAgregarFactura.UseVisualStyleBackColor = False
        '
        'dgFacturacion
        '
        Me.dgFacturacion.AllowUserToAddRows = False
        Me.dgFacturacion.AllowUserToDeleteRows = False
        Me.dgFacturacion.AllowUserToOrderColumns = True
        Me.dgFacturacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFacturacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFacturacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFacturacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colNumero, Me.colFecha, Me.colUsuario, Me.colReference, Me.colNumeroFisico})
        Me.dgFacturacion.Location = New System.Drawing.Point(6, 25)
        Me.dgFacturacion.MultiSelect = False
        Me.dgFacturacion.Name = "dgFacturacion"
        Me.dgFacturacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFacturacion.Size = New System.Drawing.Size(328, 88)
        Me.dgFacturacion.TabIndex = 0
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Id"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        '
        'colReference
        '
        Me.colReference.HeaderText = "Reference"
        Me.colReference.Name = "colReference"
        Me.colReference.ReadOnly = True
        '
        'colNumeroFisico
        '
        Me.colNumeroFisico.HeaderText = "No_Invoice"
        Me.colNumeroFisico.Name = "colNumeroFisico"
        '
        'gbDatosDocumento
        '
        Me.gbDatosDocumento.Controls.Add(Me.celdaUIDDFact)
        Me.gbDatosDocumento.Controls.Add(Me.celdaSerieFel)
        Me.gbDatosDocumento.Controls.Add(Me.celdaFechaHoraCertificacion)
        Me.gbDatosDocumento.Controls.Add(Me.celdaFechaEmisionDocumento)
        Me.gbDatosDocumento.Controls.Add(Me.celdaUUID)
        Me.gbDatosDocumento.Controls.Add(Me.celdaRangoFechaAutorizado)
        Me.gbDatosDocumento.Controls.Add(Me.celdaTemporal)
        Me.gbDatosDocumento.Controls.Add(Me.botonSerie)
        Me.gbDatosDocumento.Controls.Add(Me.celdaSerie1)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCAI)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaCAI)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaNIT)
        Me.gbDatosDocumento.Controls.Add(Me.celdaNIT)
        Me.gbDatosDocumento.Controls.Add(Me.checkActivar)
        Me.gbDatosDocumento.Controls.Add(Me.Label1)
        Me.gbDatosDocumento.Controls.Add(Me.celdaTelefono)
        Me.gbDatosDocumento.Controls.Add(Me.checkRevisado)
        Me.gbDatosDocumento.Controls.Add(Me.botonPolizaC)
        Me.gbDatosDocumento.Controls.Add(Me.celdaEmpresa)
        Me.gbDatosDocumento.Controls.Add(Me.dtpFech)
        Me.gbDatosDocumento.Controls.Add(Me.celdaUsuario)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCatalogo)
        Me.gbDatosDocumento.Controls.Add(Me.celdaIDMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaIDCliente)
        Me.gbDatosDocumento.Controls.Add(Me.celdaTasa)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaTasa)
        Me.gbDatosDocumento.Controls.Add(Me.botonMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaMoneda)
        Me.gbDatosDocumento.Controls.Add(Me.celdaDireccion)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaDireccion)
        Me.gbDatosDocumento.Controls.Add(Me.botonClientes)
        Me.gbDatosDocumento.Controls.Add(Me.celdaCliente)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaCliente)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaFecha)
        Me.gbDatosDocumento.Controls.Add(Me.celdaNumero)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaNumero)
        Me.gbDatosDocumento.Controls.Add(Me.celdaAño)
        Me.gbDatosDocumento.Controls.Add(Me.etiquetaAño)
        Me.gbDatosDocumento.Location = New System.Drawing.Point(3, 3)
        Me.gbDatosDocumento.Name = "gbDatosDocumento"
        Me.gbDatosDocumento.Size = New System.Drawing.Size(424, 317)
        Me.gbDatosDocumento.TabIndex = 1
        Me.gbDatosDocumento.TabStop = False
        Me.gbDatosDocumento.Text = "Document Data"
        '
        'celdaUIDDFact
        '
        Me.celdaUIDDFact.Location = New System.Drawing.Point(197, 11)
        Me.celdaUIDDFact.Name = "celdaUIDDFact"
        Me.celdaUIDDFact.Size = New System.Drawing.Size(32, 20)
        Me.celdaUIDDFact.TabIndex = 71
        Me.celdaUIDDFact.Visible = False
        '
        'celdaSerieFel
        '
        Me.celdaSerieFel.Location = New System.Drawing.Point(134, 11)
        Me.celdaSerieFel.Name = "celdaSerieFel"
        Me.celdaSerieFel.Size = New System.Drawing.Size(11, 20)
        Me.celdaSerieFel.TabIndex = 68
        Me.celdaSerieFel.Visible = False
        '
        'celdaFechaHoraCertificacion
        '
        Me.celdaFechaHoraCertificacion.Location = New System.Drawing.Point(118, 11)
        Me.celdaFechaHoraCertificacion.Name = "celdaFechaHoraCertificacion"
        Me.celdaFechaHoraCertificacion.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaHoraCertificacion.TabIndex = 67
        Me.celdaFechaHoraCertificacion.Visible = False
        '
        'celdaFechaEmisionDocumento
        '
        Me.celdaFechaEmisionDocumento.Location = New System.Drawing.Point(105, 11)
        Me.celdaFechaEmisionDocumento.Name = "celdaFechaEmisionDocumento"
        Me.celdaFechaEmisionDocumento.Size = New System.Drawing.Size(11, 20)
        Me.celdaFechaEmisionDocumento.TabIndex = 66
        Me.celdaFechaEmisionDocumento.Visible = False
        '
        'celdaUUID
        '
        Me.celdaUUID.Location = New System.Drawing.Point(160, 11)
        Me.celdaUUID.Name = "celdaUUID"
        Me.celdaUUID.Size = New System.Drawing.Size(17, 20)
        Me.celdaUUID.TabIndex = 49
        Me.celdaUUID.Visible = False
        '
        'celdaRangoFechaAutorizado
        '
        Me.celdaRangoFechaAutorizado.Location = New System.Drawing.Point(303, 223)
        Me.celdaRangoFechaAutorizado.Name = "celdaRangoFechaAutorizado"
        Me.celdaRangoFechaAutorizado.Size = New System.Drawing.Size(78, 20)
        Me.celdaRangoFechaAutorizado.TabIndex = 48
        Me.celdaRangoFechaAutorizado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaRangoFechaAutorizado.Visible = False
        '
        'celdaTemporal
        '
        Me.celdaTemporal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTemporal.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaTemporal.Location = New System.Drawing.Point(70, 63)
        Me.celdaTemporal.Multiline = True
        Me.celdaTemporal.Name = "celdaTemporal"
        Me.celdaTemporal.Size = New System.Drawing.Size(89, 19)
        Me.celdaTemporal.TabIndex = 47
        Me.celdaTemporal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonSerie
        '
        Me.botonSerie.Location = New System.Drawing.Point(350, 38)
        Me.botonSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(30, 19)
        Me.botonSerie.TabIndex = 46
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        '
        'celdaSerie1
        '
        Me.celdaSerie1.Location = New System.Drawing.Point(190, 38)
        Me.celdaSerie1.Name = "celdaSerie1"
        Me.celdaSerie1.ReadOnly = True
        Me.celdaSerie1.Size = New System.Drawing.Size(139, 20)
        Me.celdaSerie1.TabIndex = 45
        Me.celdaSerie1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCAI
        '
        Me.celdaCAI.Enabled = False
        Me.celdaCAI.Location = New System.Drawing.Point(59, 289)
        Me.celdaCAI.Name = "celdaCAI"
        Me.celdaCAI.Size = New System.Drawing.Size(247, 20)
        Me.celdaCAI.TabIndex = 44
        Me.celdaCAI.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaCAI.Visible = False
        '
        'etiquetaCAI
        '
        Me.etiquetaCAI.AutoSize = True
        Me.etiquetaCAI.Location = New System.Drawing.Point(23, 292)
        Me.etiquetaCAI.Name = "etiquetaCAI"
        Me.etiquetaCAI.Size = New System.Drawing.Size(24, 13)
        Me.etiquetaCAI.TabIndex = 43
        Me.etiquetaCAI.Text = "CAI"
        Me.etiquetaCAI.Visible = False
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(18, 226)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 42
        Me.etiquetaNIT.Text = "NIT"
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(70, 226)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(142, 20)
        Me.celdaNIT.TabIndex = 41
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Location = New System.Drawing.Point(190, 63)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(56, 17)
        Me.checkActivar.TabIndex = 39
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 202)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Phone"
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Location = New System.Drawing.Point(70, 202)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(142, 20)
        Me.celdaTelefono.TabIndex = 33
        '
        'checkRevisado
        '
        Me.checkRevisado.AutoSize = True
        Me.checkRevisado.Location = New System.Drawing.Point(286, 205)
        Me.checkRevisado.Name = "checkRevisado"
        Me.checkRevisado.Size = New System.Drawing.Size(74, 17)
        Me.checkRevisado.TabIndex = 32
        Me.checkRevisado.Text = "Reviewed"
        Me.checkRevisado.UseVisualStyleBackColor = True
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(250, 201)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(29, 23)
        Me.botonPolizaC.TabIndex = 31
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(338, 78)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(17, 20)
        Me.celdaEmpresa.TabIndex = 30
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'dtpFech
        '
        Me.dtpFech.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFech.Location = New System.Drawing.Point(70, 93)
        Me.dtpFech.Name = "dtpFech"
        Me.dtpFech.Size = New System.Drawing.Size(141, 20)
        Me.dtpFech.TabIndex = 29
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(361, 78)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(20, 20)
        Me.celdaUsuario.TabIndex = 28
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(286, 78)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(44, 20)
        Me.celdaCatalogo.TabIndex = 27
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(223, 251)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(392, 78)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDCliente.TabIndex = 24
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(306, 246)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(101, 20)
        Me.celdaTasa.TabIndex = 23
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(262, 249)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 22
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(184, 257)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(26, 20)
        Me.botonMoneda.TabIndex = 21
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(65, 258)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(97, 20)
        Me.celdaMoneda.TabIndex = 20
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(23, 261)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 19
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Location = New System.Drawing.Point(70, 153)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(310, 35)
        Me.celdaDireccion.TabIndex = 11
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(12, 156)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 10
        Me.etiquetaDireccion.Text = "Address"
        '
        'botonClientes
        '
        Me.botonClientes.Location = New System.Drawing.Point(387, 121)
        Me.botonClientes.Name = "botonClientes"
        Me.botonClientes.Size = New System.Drawing.Size(26, 20)
        Me.botonClientes.TabIndex = 9
        Me.botonClientes.Text = "..."
        Me.botonClientes.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(70, 122)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(310, 20)
        Me.celdaCliente.TabIndex = 8
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 125)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 7
        Me.etiquetaCliente.Text = "Customer"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(18, 93)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 5
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaNumero.Location = New System.Drawing.Point(71, 63)
        Me.celdaNumero.Multiline = True
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(89, 19)
        Me.celdaNumero.TabIndex = 3
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(11, 66)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'celdaAño
        '
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.celdaAño.Location = New System.Drawing.Point(70, 36)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(90, 19)
        Me.celdaAño.TabIndex = 1
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(26, 36)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFechas)
        Me.panelListaPrincipal.Location = New System.Drawing.Point(879, 224)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(143, 68)
        Me.panelListaPrincipal.TabIndex = 5
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNum, Me.colNum2, Me.colDate, Me.colNombre, Me.colReferencia, Me.colEstado, Me.colSerieF, Me.colAutorizacionF})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 45)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(143, 23)
        Me.dgLista.TabIndex = 1
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colNum
        '
        Me.colNum.HeaderText = "Number"
        Me.colNum.Name = "colNum"
        Me.colNum.ReadOnly = True
        '
        'colNum2
        '
        Me.colNum2.HeaderText = "Number"
        Me.colNum2.Name = "colNum2"
        Me.colNum2.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'colSerieF
        '
        Me.colSerieF.HeaderText = "Serie Fel"
        Me.colSerieF.Name = "colSerieF"
        Me.colSerieF.ReadOnly = True
        '
        'colAutorizacionF
        '
        Me.colAutorizacionF.HeaderText = "Autorizacion Fel"
        Me.colAutorizacionF.Name = "colAutorizacionF"
        Me.colAutorizacionF.ReadOnly = True
        '
        'panelFechas
        '
        Me.panelFechas.Controls.Add(Me.botonActualizar)
        Me.panelFechas.Controls.Add(Me.dtpFin)
        Me.panelFechas.Controls.Add(Me.etiquetaFin)
        Me.panelFechas.Controls.Add(Me.dtpInicio)
        Me.panelFechas.Controls.Add(Me.checkFecha)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(143, 45)
        Me.panelFechas.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(435, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 10
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(331, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 9
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(274, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 8
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(185, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 7
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(10, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 6
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = CType(resources.GetObject("botonImprimir.Image"), System.Drawing.Image)
        Me.botonImprimir.Location = New System.Drawing.Point(211, 11)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(59, 43)
        Me.botonImprimir.TabIndex = 49
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'botonPrevio
        '
        Me.botonPrevio.Image = Global.KARIMs_SGI.My.Resources.Resources.search1
        Me.botonPrevio.Location = New System.Drawing.Point(276, 11)
        Me.botonPrevio.Name = "botonPrevio"
        Me.botonPrevio.Size = New System.Drawing.Size(65, 42)
        Me.botonPrevio.TabIndex = 50
        Me.botonPrevio.Text = "Preview"
        Me.botonPrevio.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonPrevio.UseVisualStyleBackColor = True
        '
        'etiquetaAutorizacion
        '
        Me.etiquetaAutorizacion.AutoSize = True
        Me.etiquetaAutorizacion.Location = New System.Drawing.Point(442, 77)
        Me.etiquetaAutorizacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAutorizacion.Name = "etiquetaAutorizacion"
        Me.etiquetaAutorizacion.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaAutorizacion.TabIndex = 52
        Me.etiquetaAutorizacion.Text = "Label4"
        Me.etiquetaAutorizacion.Visible = False
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(379, 77)
        Me.etiquetaSerie.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaSerie.TabIndex = 51
        Me.etiquetaSerie.Text = "Label4"
        Me.etiquetaSerie.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 61)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1028, 30)
        Me.BarraTitulo1.TabIndex = 3
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1028, 61)
        Me.Encabezado1.TabIndex = 1
        '
        'frmNDebito
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 609)
        Me.Controls.Add(Me.etiquetaAutorizacion)
        Me.Controls.Add(Me.etiquetaSerie)
        Me.Controls.Add(Me.botonPrevio)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.panelNotasDebito)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmNDebito"
        Me.Text = "frmNDebito"
        Me.panelNotasDebito.ResumeLayout(False)
        Me.panelDocumento.ResumeLayout(False)
        Me.panelImpuestos.ResumeLayout(False)
        CType(Me.dgImpuestos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbInformación.ResumeLayout(False)
        Me.gbInformación.PerformLayout()
        Me.gbFacturas.ResumeLayout(False)
        CType(Me.dgFacturacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDatosDocumento.ResumeLayout(False)
        Me.gbDatosDocumento.PerformLayout()
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelNotasDebito As System.Windows.Forms.Panel
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelImpuestos As System.Windows.Forms.Panel
    Friend WithEvents dgImpuestos As System.Windows.Forms.DataGridView
    Friend WithEvents colLin As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCanti As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFactor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMonto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTag As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOrigen As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelTotales As System.Windows.Forms.Panel
    Friend WithEvents celdaTotalLetras As System.Windows.Forms.TextBox
    Friend WithEvents celdaSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents CeldaTotalEnLetras As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotal As System.Windows.Forms.Label
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescription As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUnitario As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gbInformación As System.Windows.Forms.GroupBox
    Friend WithEvents rbOtros As System.Windows.Forms.RadioButton
    Friend WithEvents rbDifPrecio As System.Windows.Forms.RadioButton
    Friend WithEvents celdaNotasObservaciones As System.Windows.Forms.TextBox
    Friend WithEvents etiquetraNotasObservaciones As System.Windows.Forms.Label
    Friend WithEvents celdaDeclaracion As System.Windows.Forms.TextBox
    Friend WithEvents EtiquetaDeclaracion As System.Windows.Forms.Label
    Friend WithEvents celdaTasaFactura As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasaFactura As System.Windows.Forms.Label
    Friend WithEvents gbFacturas As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents botonAgregarFactura As System.Windows.Forms.Button
    Friend WithEvents dgFacturacion As System.Windows.Forms.DataGridView
    Friend WithEvents gbDatosDocumento As System.Windows.Forms.GroupBox
    Friend WithEvents celdaRangoFechaAutorizado As System.Windows.Forms.TextBox
    Friend WithEvents celdaTemporal As System.Windows.Forms.TextBox
    Friend WithEvents botonSerie As System.Windows.Forms.Button
    Friend WithEvents celdaSerie1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaCAI As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCAI As System.Windows.Forms.Label
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaTelefono As System.Windows.Forms.TextBox
    Friend WithEvents checkRevisado As System.Windows.Forms.CheckBox
    Friend WithEvents botonPolizaC As System.Windows.Forms.Button
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents dtpFech As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDCliente As System.Windows.Forms.TextBox
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents celdaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents botonClientes As System.Windows.Forms.Button
    Friend WithEvents celdaCliente As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents panelListaPrincipal As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFechas As System.Windows.Forms.Panel
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents etiquetaFin As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents botonImprimir As Button
    Friend WithEvents celdaUUID As TextBox
    Friend WithEvents celdaSerieFel As TextBox
    Friend WithEvents celdaFechaHoraCertificacion As TextBox
    Friend WithEvents celdaFechaEmisionDocumento As TextBox
    Friend WithEvents botonPrevio As Button
    Friend WithEvents celdaUIDDFact As TextBox
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colNum2 As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colSerieF As DataGridViewTextBoxColumn
    Friend WithEvents colAutorizacionF As DataGridViewTextBoxColumn
    Friend WithEvents etiquetaAutorizacion As Label
    Friend WithEvents etiquetaSerie As Label
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As DataGridViewTextBoxColumn
    Friend WithEvents colReference As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroFisico As DataGridViewTextBoxColumn
End Class
