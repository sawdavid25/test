﻿Public Class frmInsumos
    Dim cfun As New clsFunciones
#Region "Procedimientos"

    Private Function VerifacarDatos() As Boolean
        Dim logVerificar As Boolean = False
        If cfun.ValidarCampoNumerico(celdaPrecio) Then
            logVerificar = True
        Else
            Return logVerificar
            Exit Function
        End If
        If cfun.ValidarCampoTexto(celdaDescripcion) Then
            logVerificar = True
        Else
            Return logVerificar
            Exit Function
        End If
        Return logVerificar
    End Function

    Private Sub Guardar()
        Dim cCat As New clsCatalogos

        Try
            cCat.CONEXION = strConexion
            cCat.CAT_CLASE = "Insumos"
            cCat.CAT_DESC = celdaDescripcion.Text
            cCat.CAT_DATO = celdaPrecio.Text
            cCat.CAT_NUM = cfun.NuevoIdCatalogo
            If cCat.Guardar = True Then
                Me.Close()
            Else
                MsgBox(cCat.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString & cCat.MERROR.ToString)
        End Try
    End Sub

    Private Sub Reset()
        celdaCodigo.Text = NO_FILA
        celdaDescripcion.Text = STR_VACIO
        celdaPrecio.Text = "00.00"
    End Sub

#End Region


    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        Me.Close()

    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If VerifacarDatos() Then
            Guardar()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Reset()
    End Sub

    Private Sub frmInsumos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Reset()
        Encabezado1.botonBorrar.Enabled = False
    End Sub

    Private Sub BarraTitulo1_Load(sender As Object, e As EventArgs) Handles BarraTitulo1.Load

    End Sub
End Class
