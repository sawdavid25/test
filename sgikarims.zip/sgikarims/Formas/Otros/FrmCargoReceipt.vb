﻿Public Class FrmCargoReceipt
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strMensaje As String = STR_VACIO
    Dim cfun As New clsFunciones
    Public Const catalogoFactura = 36
    Public Const catalogos = 397
    Public numerofactura As Integer
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones"
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = cFunciones.AñoMySQL
        celdaTasa.Text = INT_UNO
        celdaNumero.Text = -1
        dtpFecha.Text = Now
        celdaDireccion.Text = STR_VACIO
        celdaNombreCliente.Text = STR_VACIO
        celdaidCliente.Text = NO_FILA
        celdaTelefono.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIdMoneda.Text = NO_FILA
        celdaDocumento.Text = STR_VACIO
        celdaAplicante.Text = STR_VACIO
        celdaPoliza.Text = STR_VACIO
        celdaDireccion2.Text = STR_VACIO
        botonCliente.Enabled = True
        botonAgregarFactura.Enabled = True
        lblLinea.Text = STR_VACIO
        celdaObservacion.Text = STR_VACIO
        celdaCantidad.Text = STR_VACIO
        celdaTotal.Text = STR_VACIO
        lblInformacion.Text = STR_VACIO
        CeldaInfo.Text = STR_VACIO
        celdaFirmante.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        dgFactura.Rows.Clear()
    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
            '  botonInprimir.Enabled = False
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            '  botonImprimir.Enabled = True
        End If

    End Sub

    Private Function verificarPais()
        Dim strsql As String = STR_VACIO
        Dim com As MySqlCommand

        strsql = " Select e.emp_pais From Empresas e Where e.emp_no =  " & Sesion.IdEmpresa
        MyCnn.CONECTAR = strConexion
        com = New MySqlCommand(strsql, CON)

        Return com.ExecuteScalar()

    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Cargo Receipt")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                '     botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '  botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaidCliente.Text = vbNullString Then
            MsgBox("BLANK NAME ")
            Comprobar = False
            Exit Function
        End If
        If Not (celdaAño.Text = dgFactura.CurrentRow.Cells("col_anio").Value) Then
            If MsgBox("The year of the document and the date do not match", vbQuestion + vbYesNo, "Verificacion") = vbNo Then
                Comprobar = False
                Exit Function
            End If
        End If
        If Me.Tag = "Nuevo" Then

            If ExisteReferencia() = 1 Then
                If MsgBox("the reference already exist  " & vbCr & vbCr & "¿Confirm that you want to confirm? ", vbQuestion + vbYesNo, "Aviso") = vbNo Then
                    Comprobar = False
                    Exit Function
                End If
            End If
        End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If

        For i As Integer = 0 To dgDetalle.RowCount - 1
            If dgDetalle.Rows(i).Visible = True Then
                If dgDetalle.Rows(i).Cells("colTotal").Value = NO_FILA Then
                    LogVerdadero = False
                    MsgBox("The total must be greater than 0")
                End If
                If dgDetalle.Rows(i).Cells("col_Contrato").Value = vbNullString Then
                    MsgBox("Blank Contract")
                    LogVerdadero = False
                End If
                If dgDetalle.Rows(i).Cells("col_credito").Value = vbNullString Then
                    MsgBox("Blank Credit")
                    LogVerdadero = False
                End If

                If dgDetalle.Rows(i).Cells("colCantidad").Value = INT_CERO Then
                    MsgBox("Amount invalid please add another number")
                    LogVerdadero = False
                End If
            End If
        Next
        Return LogVerdadero
    End Function
    Private Function ExisteReferencia() As Integer
        Dim strSQL As String = STR_VACIO
        Dim intValidacion As Integer
        'Conexiones 
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "  Select COUNT(*)  "
        strSQL &= "     FROM Dcmtos_HDR "
        strSQL &= "         WHERE HDoc_Sis_Emp={empresa} And HDoc_Doc_Cat={catalogo}  AND HDoc_Doc_Ano={anio} AND HDoc_Doc_Num={numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{referencia}", celdaDocumento.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            intValidacion = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using



        Return intValidacion
    End Function
    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT HDoc_Doc_Ano anio, HDoc_Doc_Num numero, HDoc_DR1_Dbl numero2, HDoc_Doc_Fec fecha, HDoc_Emp_Nom nombre, IFNULL(HDoc_Emp_Per,'') contacto, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Doc_Status Estado "
        strSQL &= "     FROM Dcmtos_HDR "
        strSQL &= "         WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat={catalogo} "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "     AND (HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}')"
        End If
        strSQL &= "             ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC; "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intPais As Integer = 0

        'intPais = verificarPais()

        strSQL = sqlLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strFila = REA.GetInt32("anio") & "|"
                strFila &= REA.GetInt32("numero") & "|"
                strFila &= REA.GetDateTime("fecha") & "|"
                strFila &= REA.GetString("nombre") & "|"
                strFila &= REA.GetString("contacto") & "|"
                strFila &= REA.GetString("referencia")
                If REA.GetInt32("Estado") = 0 Then
                    cfun.AgregarFila(dgLista, strFila, Color.Coral)
                Else
                    cfun.AgregarFila(dgLista, strFila)
                End If

            Loop
        End If

    End Sub
    Private Function SQLEncabezado(ByVal codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT e.HDoc_Doc_Cat Catalogo, e.HDoc_Doc_Ano Anio , e.HDoc_Doc_Status Estado,e.HDoc_Doc_Num Numero,e.HDoc_Doc_Fec Fecha, e.HDoc_Emp_Cod Codigo, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_Dir Direccion , IFNULL(e.HDoc_Emp_Per,'') Contacto , e.HDoc_Emp_Tel Telefono , e.HDoc_Emp_NIT Nit ,e.HDoc_Doc_Mon idMoneda,cc.cat_clave Moneda,e.HDoc_Doc_TC Tasa, e.HDoc_DR1_Num  Documento , e.HDoc_RF2_Cod Poliza,e.HDoc_DR1_Emp Aplicante , c.cli_cliente Cliente,e.HDoc_RF1_Txt Direccion2,e.HDoc_RF1_Cod Firmante "
        strSQL &= "     FROM Dcmtos_HDR e "
        strSQL &= "         LEFT JOIN Clientes c ON c.cli_sisemp = e.HDoc_Sis_Emp AND c.cli_codigo = e.HDoc_DR1_Emp "
        strSQL &= "             LEFT JOIN Catalogos cc ON cc.cat_num = e.HDoc_Doc_Mon AND cc.cat_clase = 'Monedas' "
        strSQL &= "                 WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat={catalogo} AND e.HDoc_Doc_Ano={anio} AND e.HDoc_Doc_Num={numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", codigo)
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLEncabezado(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaAño.Text = REA.GetInt32("Anio")
                    celdaNumero.Text = REA.GetInt32("Numero")
                    If REA.GetInt32("Estado") = 1 Then
                        checkActive.Checked = True
                    Else
                        checkActive.Checked = False
                        checkActive.Enabled = False
                    End If
                    dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaidCliente.Text = REA.GetInt32("Codigo")
                    celdaNombreCliente.Text = REA.GetString("Nombre")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaContacto.Text = REA.GetString("Contacto")
                    celdaTelefono.Text = REA.GetString("Telefono")
                    celdaNit.Text = REA.GetString("Nit")
                    celdaIdMoneda.Text = REA.GetInt32("idMoneda")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaDocumento.Text = REA.GetString("Documento")
                    celdaPoliza.Text = REA.GetString("Poliza")
                    celdaIdAplicante.Text = REA.GetInt32("Aplicante")
                    celdaAplicante.Text = REA.GetString("Cliente")
                    celdaDireccion2.Text = REA.GetString("Direccion2")
                    celdaFirmante.Text = REA.GetString("Firmante")
                Loop
                REA.Close()
                COM = Nothing
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "      SELECT d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des descripcion, COALESCE(c.cat_clave,'') medida, d.DDoc_Prd_UM unidad, d.DDoc_Prd_Net precio, "
        strSQL &= "         d.DDoc_Prd_Qty cantidad, d.DDoc_RF2_Dbl revision, (d.DDoc_Prd_NET * d.DDoc_Prd_Qty) total, COALESCE(d.DDoc_RF3_Num, d.DDoc_Prd_UM) base, 0 saldo, COALESCE(p.PDoc_Par_Ano,0) anio, "
        strSQL &= "             COALESCE(p.PDoc_Par_Num,0) numero, COALESCE(p.PDoc_Par_Lin,0) linea, COALESCE(d.DDoc_RF1_Txt,'') referencia, COALESCE(d.DDoc_RF1_Cod,'') contrato, COALESCE(d.DDoc_Prd_Ref,'') credito, d.DDoc_RF2_Dbl restar, IFNULL(d.DDoc_RF1_Fec,'') Envio, "
        strSQL &= "                IFNULL(d.DDoc_RF2_Fec,'') Presentacion, IFNULL(d.DDoc_RF3_Fec,'') Pago, IFNULL(d.DDoc_RF2_Txt,'') Documento "
        strSQL &= "                     FROM Dcmtos_DTL d"
        strSQL &= "                         LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = 36 AND p.PDoc_Chi_Cat = 397 AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                             LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM "
        strSQL &= "                                     LEFT JOIN Inventarios i ON i.inv_sisemp = 12 AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                                         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL &= "                                             GROUP BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
        strSQL &= "                                                 ORDER BY d.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Codigo)

        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Codigo As Integer, ByVal Anio As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLDetalle(Codigo, Anio)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read

                    strFila = REA.GetInt32("codigo") & "|"  ' Codigo
                    strFila &= REA.GetString("descripcion") & "|"  ' Descripcion
                    strFila &= REA.GetInt32("unidad") & "|" ' id Medida
                    strFila &= REA.GetInt32("base") & "|"  ' Base
                    strFila &= REA.GetString("medida") & "|"  ' Medida
                    strFila &= REA.GetDouble("precio").ToString(FORMATO_MONEDA) & "|"  ' Precio
                    strFila &= REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|"   ' Cantidad
                    strFila &= REA.GetDouble("restar") & "|" ' Devolucion
                    strFila &= REA.GetDouble("total").ToString("###0.00") & "|"   ' Total
                    strFila &= REA.GetInt32("linea") & "|"  ' Linea
                    strFila &= REA.GetString("referencia") & "|"  ' Referencia
                    strFila &= REA.GetString("contrato") & "|"  ' Contrato
                    strFila &= REA.GetString("credito") & "|"  ' Credito    
                    strFila &= REA.GetString("Envio") & "|" ' Envio 
                    strFila &= REA.GetString("Presentacion") & "|"  ' ¨Presentado
                    strFila &= REA.GetString("Documento") & "|"  'Documento
                    strFila &= REA.GetString("Pago") & "|"   'Pago
                    strFila &= "" & "|"  'FSD
                    strFila &= "" & "|" ' Anio
                    strFila &= "" & "|" ' Numero
                    strFila &= "" & "|" 'Linea
                    strFila &= "" & "|" ' Anio Carta Credito
                    strFila &= "" & "|" ' Numero Carta Credito
                    strFila &= "" & "|" 'Linea Carta de Credito 
                    strFila &= "1"
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
                CalcularTotales()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLReferencia(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT COALESCE(rc.PDoc_Par_Ano,0) cAnio, COALESCE(rc.PDoc_Par_Num,0) cNumero, COALESCE(rc.PDoc_Par_Lin,0) cLinea, COALESCE(rl.PDoc_Par_Ano,0) lAnio, COALESCE(rl.PDoc_Par_Num,0) lNumero, COALESCE(rl.PDoc_Par_Lin,0) lLinea "
        strSQL &= "     FROM Dcmtos_DTL dr "
        strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro rc ON rc.PDoc_Sis_Emp = dr.DDoc_Sis_Emp AND rc.PDoc_Par_Cat = 389 AND rc.PDoc_Chi_Cat = dr.DDoc_Doc_Cat AND rc.PDoc_Chi_Ano = dr.DDoc_Doc_Ano AND rc.PDoc_Chi_Num = dr.DDoc_Doc_Num AND rc.PDoc_Chi_Lin = dr.DDoc_Doc_Lin "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro rl ON rl.PDoc_Sis_Emp = dr.DDoc_Sis_Emp AND rl.PDoc_Par_Cat = 387 AND rl.PDoc_Chi_Cat = dr.DDoc_Doc_Cat AND rl.PDoc_Chi_Ano = dr.DDoc_Doc_Ano AND rl.PDoc_Chi_Num = dr.DDoc_Doc_Num AND rl.PDoc_Chi_Lin = dr.DDoc_Doc_Lin "
        strSQL &= "                 WHERE dr.DDoc_Sis_Emp = {empresa} AND dr.DDoc_Doc_Cat = {catalogo} AND dr.DDoc_Doc_Ano = {anio} AND dr.DDoc_Doc_Num = {numero}   AND dr.DDoc_Doc_Lin = {linea} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{linea}", Linea)
        Return strSQL
    End Function
    Private Function SQLReferenciaDocumento(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT DISTINCT HDoc_Doc_Cat tipo, HDoc_Doc_Ano anio, HDoc_Doc_Num numero, HDoc_DR1_Dbl numero2, HDoc_Doc_Fec fecha, HDoc_Usuario usuario, HDoc_DR1_Num referencia "
        strSQL &= "     FROM Dcmtos_DTL_Pro a "
        strSQL &= "         INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num AND a.PDoc_Par_Cat = 36 "
        strSQL &= "             WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = {catalogo} AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {numero} "
        strSQL &= "                 ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Return strSQL
    End Function
    Public Sub CargarReferencia(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String
        Dim intPais As Integer
        Try
            intPais = verificarPais()

            strSQL = SQLReferenciaDocumento(Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    If (intPais = 310 And Sesion.IdEmpresa = 12) Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Then
                        strFila &= REA.GetInt32("numero2") & "|"
                    Else
                        strFila &= REA.GetInt32("numero") & "|"
                    End If

                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= "1|"
                    strFila &= REA.GetString("numero")
                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalleDocumentosProceso() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT e.HDoc_Sis_Emp empresa, e.HDoc_Doc_Cat tipo, e.HDoc_Doc_Ano año, e.HDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, a.art_DCorta descripcion, "
            strSQL &= "     COALESCE(c.cat_clave,'') medida, d.DDoc_Prd_UM unidad, d.DDoc_Prd_NET precio, d.DDoc_RF1_Txt referencia, '' contrato, '' credito, 0 restar, COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM) base, (d.DDoc_Prd_QTY - COALESCE(( "
            strSQL &= "         SELECT SUM(p.PDoc_QTY_Pro) "
            strSQL &= "             FROM Dcmtos_DTL_Pro p "
            strSQL &= "                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Chi_Cat ={catalogo}),0)) cantidad "
            strSQL &= "                     FROM Dcmtos_DTL d "
            strSQL &= "                         LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND  e.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "                             LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "                                 LEFT JOIN Articulos a ON a.art_sisemp = d.DDoc_Sis_Emp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM "
            strSQL &= "                                         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogofact} AND HDoc_Doc_Ano = {anio} AND {distincionPY} = {numero}  "
            strSQL &= "                                             GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin "
            strSQL &= "                                                 HAVING (cantidad > 0) "
            strSQL &= "                                                     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)
            strSQL = Replace(strSQL, "{catalogofact}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
            strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
            strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
            If Sesion.IdEmpresa = 11 Then
                strSQL = Replace(strSQL, "{distincionPY}", "HDoc_DR1_Dbl")
            Else
                strSQL = Replace(strSQL, "{distincionPY}", "HDoc_Doc_Num")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function SQLDocumentosEnProceso() As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT DISTINCT HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano anio, HDoc_Doc_Num numero, HDoc_DR1_Dbl numero2, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total "
            strSQL &= "     FROM Dcmtos_HDR a "
            strSQL &= "         LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num "
            strSQL &= "             WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = {catalogoFac}) AND (HDoc_Emp_Cod = {codigo}) AND HDoc_Doc_Status = 1 AND (COALESCE(( "
            strSQL &= "                 SELECT SUM(c.PDoc_QTY_Pro) "
            strSQL &= "                     FROM Dcmtos_DTL_Pro c "
            strSQL &= "                         WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = {catalogo}), 0) < b.DDoc_Prd_QTY) "
            strSQL &= "                             ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogoFac}", catalogoFactura)
            strSQL = Replace(strSQL, "{codigo}", celdaidCliente.Text)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDatosCliente(ByVal codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intCodigo As Integer

        Try

            strSQL = " SELECT COALESCE(e.HDoc_DR1_Emp,0) id, COALESCE(e.HDoc_RF1_Cod,'N/A') persona, f.HDoc_Doc_Fec fecha "
            strSQL &= "    FROM Dcmtos_DTL d "
            strSQL &= "        LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND i.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND i.PDoc_Chi_Num=d.DDoc_Doc_Num AND i.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
            strSQL &= "            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=i.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=i.PDoc_Par_Cat AND p.PDoc_Par_Cat=75 AND p.PDoc_Chi_Ano=i.PDoc_Par_Ano AND p.PDoc_Chi_Num=i.PDoc_Par_Num AND p.PDoc_Chi_Lin=i.PDoc_Par_Lin "
            strSQL &= "                LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=p.PDoc_Par_Cat AND e.HDoc_Doc_Ano=p.PDoc_Par_Ano AND e.HDoc_Doc_Num=p.PDoc_Par_Num "
            strSQL &= "                    LEFT JOIN Dcmtos_HDR f ON f.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND f.HDoc_Doc_Cat=d.DDoc_Doc_Cat AND f.HDoc_Doc_Ano=d.DDoc_Doc_Ano AND f.HDoc_Doc_Num=d.DDoc_Doc_Num "
            strSQL &= "                        WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=36 AND d.DDoc_Doc_Ano={anio} AND f.{distincionPY}={numero} LIMIT 1 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", CInt(dgFactura.CurrentRow.Cells("col_anio").Value))
            strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)

            If Sesion.IdEmpresa = 11 Then
                strSQL = Replace(strSQL, "{distincionPY}", "HDoc_DR1_Dbl")
            Else
                strSQL = Replace(strSQL, "{distincionPY}", "HDoc_Doc_Num")
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    intCodigo = REA.GetInt32("id")
                Loop
            End If
            COM = Nothing
            REA.Close()



            strSQL2 = " Select cli_codigo codigo , cli_cliente Cliente , cli_direccion Direccion  "
            strSQL2 &= "     FROM Clientes "
            strSQL2 &= "        LEFT JOIN Catalogos ON cat_num=cli_moneda "
            strSQL2 &= "             WHERE cli_sisemp={empresa} And cli_codigo={codigo} "
            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{codigo}", intCodigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaIdAplicante.Text = REA.GetInt32("codigo")
                    celdaAplicante.Text = REA.GetString("Cliente")
                    celdaDireccion2.Text = REA.GetString("Direccion")
                    celdaDocumento.Text = dgFactura.CurrentRow.Cells("col_Numero").Value
                    celdaNumero.Text = dgFactura.CurrentRow.Cells("col_Numero").Value
                    dtpFecha.Value = CDate(dgFactura.CurrentRow.Cells("col_fecha").Value)
                    celdaAño.Text = CInt(dgFactura.CurrentRow.Cells("col_anio").Value)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarPolizaExportacion()
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try

            strSQL = " SELECT DISTINCT ip.ADoc_Dta_Chr  Exportacion"
            strSQL &= "     FROM Dcmtos_DTL_Pro rp "
            strSQL &= "         INNER JOIN Dcmtos_HDR ep ON ep.HDoc_Sis_Emp = rp.PDoc_Sis_Emp And ep.HDoc_Doc_Cat = rp.PDoc_Chi_Cat And ep.HDoc_Doc_Ano = rp.PDoc_Chi_Ano And ep.HDoc_Doc_Num = rp.PDoc_Chi_Num "
            strSQL &= "             LEFT JOIN Dcmtos_ACC ip ON ip.ADoc_Sis_Emp = ep.HDoc_Sis_Emp And ip.ADoc_Doc_Cat = ep.HDoc_Doc_Cat And ip.ADoc_Doc_Ano = ep.HDoc_Doc_Ano And ip.ADoc_Doc_Num = ep.HDoc_Doc_Num And ip.ADoc_Doc_Sub = 'Doc_PolExp' AND ip.Adoc_Doc_Lin = '01' "
            strSQL &= " INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = rp.PDoc_Sis_Emp AND h.HDoc_Doc_Cat = rp.PDoc_Par_Cat AND h.HDoc_Doc_Ano = rp.PDoc_Par_Ano AND h.HDoc_Doc_Num = rp.PDoc_Par_Num "
            strSQL &= "                      WHERE rp.PDoc_Sis_Emp = {empresa} AND rp.PDoc_Par_Cat = {catalogo} AND rp.PDoc_Par_Ano = {anio} AND {distincionPY} = {numero} AND rp.PDoc_Chi_Cat = 56 AND NOT(COALESCE(ip.ADoc_Dta_Chr,'') = '') LIMIT 1"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
            strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
            strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)

            If Sesion.IdEmpresa = 11 Then
                strSQL = Replace(strSQL, "{distincionPY}", "h.HDoc_DR1_Dbl")
            Else
                strSQL = Replace(strSQL, "{distincionPY}", "h.HDoc_Doc_Num")
            End If

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaPoliza.Text = REA.GetString("Exportacion")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDocumentosProcesados()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim intPais As Integer = 0
        Try
            intPais = verificarPais()

            strSQL = SQLDocumentosEnProceso()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dgFactura.Rows.Clear()
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("tipo") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    If (intPais = 310 And Sesion.IdEmpresa = 12) Or Sesion.IdEmpresa = 14 And Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Then
                        strFila &= REA.GetInt32("numero2") & "|"
                    Else
                        strFila &= REA.GetInt32("numero") & "|"
                    End If

                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= "0|"
                    strFila &= REA.GetInt32("numero") 'number
                    cfun.AgregarFila(dgFactura, strFila)
                Loop
            End If
            celdaDocumento.Text = STR_VACIO
            celdaPoliza.Text = STR_VACIO
            celdaDireccion2.Text = STR_VACIO
            celdaFirmante.Text = STR_VACIO
            celdaAplicante.Text = STR_VACIO
            celdaIdAplicante.Text = STR_VACIO


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDocumentosDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLDetalleDocumentosProceso()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetInt32("unidad") & "|"
                    strFila &= REA.GetInt32("base") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("restar").ToString(FORMATO_MONEDA) & "|"
                    strFila &= (REA.GetDouble("precio") * REA.GetDouble("cantidad")).ToString("###0.00") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= "|"  ' Contrato
                    strFila &= "|" ' Credito
                    strFila &= "|" ' Envio
                    strFila &= "|" 'Presentado'
                    strFila &= "|" ' Documento
                    strFila &= "|" 'Pago
                    strFila &= "|" 'FSD & LSD
                    strFila &= "0" & "|" 'RefAnio 
                    strFila &= "0" & "|" 'RefNum
                    strFila &= "0" & "|" 'RefLine
                    strFila &= "0" & "|" 'RefCAnio 
                    strFila &= "0" & "|" 'RefCNum
                    strFila &= "0" & "|" 'RefCLine
                    strFila &= "0"
                    cfun.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Pedido()
        Dim strSQL As String
        Dim strSQL1 As String
        Dim strSQl2 As String
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim frmNote As New frmAviso
        Dim dblTotal As Double
        Dim dblPrecioKGS As Double
        Dim dblPrecio As Double
        Dim strUnidad As String
        Dim strBase As String
        Dim strPedido As String
        Dim intUnidad As Integer
        Dim intBase As Integer
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intLinea As Integer
        Try
            strMensaje = STR_VACIO
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                strSQL = "  SELECT r.HDoc_Doc_Cat tipo, r.HDoc_Doc_Ano anio, r.HDoc_Doc_Num numero, e.DDoc_Doc_Lin linea, COALESCE(e.DDoc_Prd_NET,0) precio, COALESCE(e.DDoc_Prd_UM,0) unidad, COALESCE(r.HDoc_DR1_Num,'') contrato "
                strSQL &= "     FROM Dcmtos_DTL d INNER JOIN Dcmtos_HDR h ON d.DDoc_Sis_Emp=h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano AND d.DDoc_Doc_Num=h.HDoc_Doc_Num"
                strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND i.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND i.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND i.PDoc_Chi_Num=d.DDoc_Doc_Num AND i.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
                strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=i.PDoc_Sis_Emp AND p.PDoc_Chi_Cat=i.PDoc_Par_Cat AND p.PDoc_Par_Cat=75 AND p.PDoc_Chi_Ano=i.PDoc_Par_Ano AND p.PDoc_Chi_Num=i.PDoc_Par_Num AND p.PDoc_Chi_Lin=i.PDoc_Par_Lin "
                strSQL &= "                 LEFT JOIN Dcmtos_DTL e ON e.DDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.DDoc_Doc_Cat=p.PDoc_Par_Cat AND e.DDoc_Doc_Ano=p.PDoc_Par_Ano AND e.DDoc_Doc_Num=p.PDoc_Par_Num AND e.DDoc_Doc_Lin=p.PDoc_Par_Lin "
                strSQL &= "                     LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND r.HDoc_Doc_Cat=e.DDoc_Doc_Cat AND r.HDoc_Doc_Ano=e.DDoc_Doc_Ano AND r.HDoc_Doc_Num=e.DDoc_Doc_Num "
                strSQL &= "                         WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={catalogo} AND d.DDoc_Doc_Ano={anio} AND {distincionPY}={numero} AND d.DDoc_Doc_Lin={linea} AND NOT ISNULL(r.HDoc_Sis_Emp) LIMIT 1"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{catalogo}", dgFactura.CurrentRow.Cells("col_Tipo").Value)
                strSQL = Replace(strSQL, "{anio}", dgFactura.CurrentRow.Cells("col_anio").Value)
                strSQL = Replace(strSQL, "{numero}", dgFactura.CurrentRow.Cells("col_Numero").Value)
                strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("col_linea").Value)
                If Sesion.IdEmpresa = 11 Then
                    strSQL = Replace(strSQL, "{distincionPY}", "h.HDoc_DR1_Dbl")
                Else
                    strSQL = Replace(strSQL, "{distincionPY}", "h.HDoc_Doc_Num")
                End If
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        intAnio = REA.GetInt32("anio")
                        intNumero = REA.GetInt32("numero")
                        intLinea = REA.GetInt32("linea")
                        If Me.Tag = "Nuevo" Then
                            intUnidad = dgDetalle.Rows(i).Cells("colidMedida").Value
                            intBase = dgDetalle.Rows(i).Cells("colBase").Value
                            strPedido = REA.GetString("contrato")
                            If REA.GetDouble("precio") > vbEmpty Then
                                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value

                                If Not (dblPrecio = REA.GetDouble("precio") And intUnidad = intBase) Then

                                    strSQL1 = " SELECT cat_clave FROM Catalogos WHERE cat_clase='Medidas' AND cat_num = " & intUnidad
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM2 = New MySqlCommand(strSQL1, conec)
                                    Using conec
                                        strUnidad = COM2.ExecuteScalar
                                        COM2.Dispose()
                                        COM2 = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    strSQl2 = " SELECT cat_clave FROM Catalogos WHERE cat_clase='Medidas' AND cat_num = " & intBase
                                    conec = New MySqlConnection(strConexion)
                                    conec.Open()
                                    COM2 = New MySqlCommand(strSQL1, conec)
                                    Using conec
                                        strBase = COM2.ExecuteScalar
                                        COM2.Dispose()
                                        COM2 = Nothing
                                        conec.Close()
                                        conec.Dispose()
                                        conec = Nothing
                                        System.GC.Collect()
                                    End Using
                                    If REA.GetInt32("unidad") = intUnidad Then
                                        dgDetalle.Rows(i).Cells("colPrecio").Value = REA.GetDouble("precio")
                                        dblTotal = REA.GetDouble("precio") * CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                                        dgDetalle.Rows(i).Cells("colTotal").Value = dblTotal.ToString(FORMATO_MONEDA)
                                    Else
                                        dblPrecioKGS = (REA.GetDouble("precio") * 2.2046)
                                        dgDetalle.Rows(i).Cells("colPrecio").Value = dblPrecioKGS.ToString(FORMATO_MONEDA)
                                        dblTotal = dblPrecioKGS * CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                                        dgDetalle.Rows(i).Cells("colTotal").Value = dblTotal.ToString(FORMATO_MONEDA)
                                    End If
                                    strMensaje &= "Línea #" & (i + 1) & ": el precio del pedido difiere del facturado" & vbCrLf & vbCrLf & "Pedido: " & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & " x " & strUnidad & vbCrLf & "Factura: " & dblPrecio.ToString(FORMATO_MONEDA) & " x " & strBase & vbCrLf & vbCrLf & vbNullString
                                End If
                            End If
                        Else

                        End If

                    Loop
                    Contrato(intAnio, intNumero, intLinea)
                    CartaCredito(dgDetalle.Rows(i).Cells("colRefAnio").Value, dgDetalle.Rows(i).Cells("colRefNum").Value, dgDetalle.Rows(i).Cells("col_linea").Value)
                    intAnio = INT_CERO
                    intNumero = INT_CERO
                    intLinea = INT_CERO
                    COM = Nothing
                    REA.Close()
                End If
            Next
            If Not (strMensaje = vbNullString) Then
                frmNote.Texto = strMensaje
                frmNote.ShowDialog(Me)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub Contrato(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim k As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strContrato As String = STR_VACIO
        Dim strFecha As String = STR_VACIO

        strSQL = " SELECT g.Año Anio, g.Numero, g.Linea, g.Contrato, CONCAT(IF(g.Fecha1!='' AND g.Fecha2='','FSD ',''),g.Fecha1, IF(g.Fecha1='' OR g.Fecha2='','',' / '), IF(g.Fecha1='' AND g.Fecha2!='','LSD ',''),g.Fecha2) Fechas "
        strSQL &= "     FROM ( "
        strSQL &= "         SELECT rc.PDoc_Par_Ano Año, rc.PDoc_Par_Num Numero, rc.PDoc_Par_Lin Linea, IFNULL(ec.HDoc_DR1_Num,'') Contrato, CAST(IFNULL(dc.DDoc_RF1_Fec,'') AS CHAR) Fecha1, CAST(IFNULL(dc.DDoc_RF2_Fec,'') AS CHAR) Fecha2 "
        strSQL &= "             FROM Dcmtos_DTL_Pro rc "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL dc ON dc.DDoc_Sis_Emp=rc.PDoc_Sis_Emp AND dc.DDoc_Doc_Cat=rc.PDoc_Par_Cat AND dc.DDoc_Doc_Ano=rc.PDoc_Par_Ano AND dc.DDoc_Doc_Num=rc.PDoc_Par_Num AND dc.DDoc_Doc_Lin=rc.PDoc_Par_Lin "
        strSQL &= "                     LEFT JOIN Dcmtos_HDR ec ON ec.HDoc_Sis_Emp = dc.DDoc_Sis_Emp AND ec.HDoc_Doc_Cat=dc.DDoc_Doc_Cat AND ec.HDoc_Doc_Ano=dc.DDoc_Doc_Ano AND ec.HDoc_Doc_Num=dc.DDoc_Doc_Num "
        strSQL &= "                         WHERE rc.PDoc_Sis_Emp = {empresa} AND rc.PDoc_Chi_Cat = 75 AND rc.PDoc_Chi_Ano = {anio} AND rc.PDoc_Chi_Num = {numero} AND rc.PDoc_Chi_Lin = {linea} AND rc.PDoc_Par_Cat = 389 "
        strSQL &= "                             GROUP BY rc.PDoc_Sis_Emp, rc.PDoc_Par_Cat, rc.PDoc_Par_Ano, rc.PDoc_Par_Num, rc.PDoc_Par_Lin) g "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{linea}", Linea)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If Not (REA.GetString("contrato") = "") Then
                    If k = vbEmpty Then
                        dgDetalle.CurrentRow.Cells("colRefAnio").Value = REA.GetInt32("Anio")
                        dgDetalle.CurrentRow.Cells("colRefNum").Value = REA.GetInt32("Numero")
                        dgDetalle.CurrentRow.Cells("colRefLine").Value = REA.GetInt32("Linea")
                    End If
                    If InStr(1, strContrato, REA.GetString("contrato")) = vbEmpty Then
                        strContrato &= REA.GetString("contrato") & "/"
                    End If
                    If strFecha = vbNullString Then
                        If Not REA.GetString("Fechas") = "" Then
                            strFecha = REA.GetString("Fechas")
                        End If
                    End If

                End If
                k = k + 1
            Loop
        End If
        If k = 0 Then
            If Me.Tag = "Mod" Then
                MsgBox("No Contract was found for the disparched order ", vbExclamation, "Warning")
            End If
        End If

        If k > 1 Then
            'Agrega a la lista de mensajes
            strMensaje &= "Línea #" & (dgDetalle.CurrentRow.Cells("col_linea").Value) & ": se encontró más de un contrato para dicho pedido" & vbCrLf & vbCrLf & vbNullString
        End If
        dgDetalle.CurrentRow.Cells("col_Contrato").Value = strContrato
        dgDetalle.CurrentRow.Cells("col_FSD").Value = strFecha

    End Sub
    Public Sub CartaCredito(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim dblSaldo As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Dim intPos As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "  SELECT el.HDoc_Doc_Ano anio, el.HDoc_Doc_Num Numero, dl.DDoc_Doc_Lin Linea, el.HDoc_DR1_Num Referencia, dl.DDoc_Prd_Des Descripcion, (dl.DDoc_Prd_QTY - SUM(COALESCE(rc.PDoc_QTY_Pro,0))) Saldo  "
        strSQL &= "     FROM Dcmtos_DTL dc "
        strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro rl ON rl.PDoc_Sis_Emp = dc.DDoc_Sis_Emp AND rl.PDoc_Chi_Cat = 387 AND rl.PDoc_Par_Cat = dc.DDoc_Doc_Cat AND rl.PDoc_Par_Ano = dc.DDoc_Doc_Ano AND rl.PDoc_Par_Num = dc.DDoc_Doc_Num AND rl.PDoc_Par_Lin = dc.DDoc_Doc_Lin "
        strSQL &= "             LEFT JOIN Dcmtos_DTL dl ON dl.DDoc_Sis_Emp = rl.PDoc_Sis_Emp AND dl.DDoc_Doc_Cat = rl.PDoc_Chi_Cat AND dl.DDoc_Doc_Ano = rl.PDoc_Chi_Ano AND dl.DDoc_Doc_Num = rl.PDoc_Chi_Num AND dl.DDoc_Doc_Lin = rl.PDoc_Chi_Lin "
        strSQL &= "                 LEFT JOIN Dcmtos_HDR el ON el.HDoc_Sis_Emp = dl.DDoc_Sis_Emp AND el.HDoc_Doc_Cat = dl.DDoc_Doc_Cat AND el.HDoc_Doc_Ano = dl.DDoc_Doc_Ano AND el.HDoc_Doc_Num = dl.DDoc_Doc_Num "
        strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro rc ON rc.PDoc_Sis_Emp = dl.DDoc_Sis_Emp AND rc.PDoc_Chi_Cat = 397 AND  rc.PDoc_Par_Cat = dl.DDoc_Doc_Cat AND rc.PDoc_Par_Ano = dl.DDoc_Doc_Ano AND rc.PDoc_Par_Num = dl.DDoc_Doc_Num AND rc.PDoc_Par_Lin = dl.DDoc_Doc_Lin AND NOT(rc.PDoc_Chi_Ano = {aniof} AND rc.PDoc_Chi_Num = {numf} AND rc.PDoc_Chi_Lin = {linea}) "
        strSQL &= "                         WHERE dc.DDoc_Sis_Emp = {empresa} AND dc.DDoc_Doc_Cat = 389 AND dc.DDoc_Doc_Ano = {anio} AND dc.DDoc_Doc_Num = {numero} AND dc.DDoc_Doc_Lin = {linea} AND NOT ISNULL(dl.DDoc_Sis_Emp) "
        strSQL &= "                             GROUP BY dl.DDoc_Doc_Ano, dl.DDoc_Doc_Num, dl.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{aniof}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numf}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{linea}", Linea)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If Not (Trim(dgDetalle.CurrentRow.Cells("col_credito").Value) = "") Then
                    If Not (Trim(dgDetalle.CurrentRow.Cells("col_credito").Value = Trim(REA.GetString("Referencia")))) Then

                        If MsgBox("Change Credit" & vbCr & vbCr & "Previous: " & dgDetalle.CurrentRow.Cells("col_credito").Value & " New: " & vbTab & REA.GetString("Referencia") & "", vbQuestion + vbYesNo, "Aviso") = vbNo Then
                            intPos = NO_FILA
                        End If
                    End If
                End If
                If Not (intPos = NO_FILA) Then
                    dblSaldo = REA.GetDouble("Saldo")
                    dblCantidad = (dgDetalle.CurrentRow.Cells("colCantidad").Value - dgDetalle.CurrentRow.Cells("colDevolucion").Value)
                    If dblCantidad > dblSaldo Then

                        strMensaje &= "Línea #" & Linea & dblCantidad & "is Greater than the balance " & vbCrLf & dblSaldo & " of the letter Credit  "

                        If MsgBox(" " & strMensaje, vbExclamation + vbOKCancel + vbDefaultButton2, "Insufficient Balance ") = vbCancel Then
                            intPos = NO_FILA
                        End If

                    End If
                End If
                dgDetalle.CurrentRow.Cells("ref_Canio").Value = REA.GetInt32("anio")
                dgDetalle.CurrentRow.Cells("ref_CNum").Value = REA.GetInt32("Numero")
                dgDetalle.CurrentRow.Cells("ref_CLin").Value = REA.GetInt32("Linea")
                dgDetalle.CurrentRow.Cells("col_credito").Value = REA.GetString("Referencia")



            Loop
        Else
            If Me.Tag = "Mod" Then
                MsgBox("No Letter of credit was found for the contract", vbExclamation, "Warning")
            End If
        End If


    End Sub
    Private Function GuardarDocumento(ByVal codigo As Integer, ByVal intAnio As Integer) As Boolean
        Dim clsHDR As New clsDcmtos_HDR
        Dim logGuardar As Boolean = True
        Try
            clsHDR.CONEXION = strConexion
            clsHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            clsHDR.HDOC_DOC_CAT = catalogos
            clsHDR.HDOC_DOC_ANO = intAnio
            clsHDR.HDOC_DOC_NUM = codigo
            clsHDR.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            clsHDR.HDOC_EMP_COD = celdaidCliente.Text
            clsHDR.HDOC_EMP_NOM = celdaNombreCliente.Text
            clsHDR.HDOC_EMP_DIR = celdaDireccion.Text
            clsHDR.HDOC_EMP_NIT = celdaNit.Text
            clsHDR.HDOC_DR1_EMP = celdaIdAplicante.Text
            clsHDR.HDOC_DR1_NUM = celdaDocumento.Text
            clsHDR.HDOC_RF1_COD = celdaFirmante.Text
            clsHDR.HDOC_RF1_TXT = celdaDireccion2.Text
            clsHDR.HDOC_RF2_COD = celdaPoliza.Text
            clsHDR.HDOC_RF2_TXT = celdaObservacion.Text
            clsHDR.HDOC_USUARIO = Sesion.Usuario
            clsHDR.HDOC_DOC_TC = celdaTasa.Text
            clsHDR.HDOC_DOC_MON = celdaIdMoneda.Text
            clsHDR.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, vbEmpty)
            If logEditar = True Then
                If Me.Tag = "Mod" Then
                    If clsHDR.Actualizar() = False Then
                        logGuardar = False
                        MsgBox(clsHDR.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    Else
                        cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, catalogos, celdaAño.Text, celdaNumero.Text)
                        logGuardar = True

                        If GuardarDetalle(codigo, intAnio) Then
                            logGuardar = True
                        Else
                            logGuardar = False
                        End If

                        If GuardarDcmtosPro(codigo, intAnio) Then
                            logGuardar = True
                        Else
                            logGuardar = False

                        End If

                    End If
                End If
            Else
                MsgBox("Does Not Have Permissions")
            End If
            If logInsertar = True Then
                If Me.Tag = "Nuevo" Then
                    If clsHDR.Guardar() = False Then
                        logGuardar = False
                        MsgBox(clsHDR.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    Else
                        cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, catalogos, celdaAño.Text, celdaNumero.Text)
                        logGuardar = True

                        If GuardarDetalle(codigo, intAnio) Then
                            logGuardar = True
                        Else
                            logGuardar = False
                        End If

                        If GuardarDcmtosPro(codigo, intAnio) Then
                            logGuardar = True
                        Else
                            logGuardar = False
                        End If
                    End If
                End If
            Else
                MsgBox("Does Not Have Permissions")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer, ByVal IntAnio As Integer) As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Dim logGuardar As Boolean
        Try
            clsDTL.CONEXION = strConexion
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = catalogos
                clsDTL.DDOC_DOC_ANO = IntAnio
                clsDTL.DDOC_DOC_NUM = Codigo
                clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("col_linea").Value

                clsDTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("col_codigo").Value
                clsDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("col_descripcion").Value
                clsDTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value
                clsDTL.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("col_FSD").Value
                clsDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value

                clsDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("col_Contrato").Value
                clsDTL.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("col_Referencia1").Value

                If dgDetalle.Rows(i).Cells("col_envio").Value = "" Then
                    clsDTL.DDOC_RF1_FEC = Nothing
                Else
                    clsDTL.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("col_envio").Value  ' Envio 
                End If
                clsDTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value
                clsDTL.DDOC_RF2_COD = celdaDocumento.Text
                clsDTL.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colDevolucion").Value

                clsDTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colTotal").Value ' Total
                clsDTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colTotal").Value ' Total 
                clsDTL.DDOC_PRD_REF = dgDetalle.Rows(i).Cells("col_credito").Value ' Carta de Credito 

                clsDTL.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("col_documento").Value ' Documento

                If dgDetalle.Rows(i).Cells("col_presentado").Value = "" Then
                    clsDTL.DDOC_RF2_FEC = Nothing
                Else
                    clsDTL.DDoc_RF2_Fec_NET = dgDetalle.Rows(i).Cells("col_presentado").Value  ' Presentado 
                End If

                If dgDetalle.Rows(i).Cells("col_pago").Value = "" Then
                    clsDTL.DDOC_RF3_FEC = Nothing
                Else
                    clsDTL.DDoc_RF3_Fec_NET = dgDetalle.Rows(i).Cells("col_pago").Value  ' Pago 
                End If
                clsDTL.DDOC_RF2_COD = Codigo

                If logInsertar = True Then
                    If dgDetalle.Rows(i).Cells("col_Extra").Value = 0 Then
                        If clsDTL.Guardar = False Then
                            MsgBox(clsDTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If
                If logEditar = True Then
                    If dgDetalle.Rows(i).Cells("col_Extra").Value = 1 Then
                        If clsDTL.Actualizar = False Then
                            MsgBox(clsDTL.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function GuardarDcmtosPro(ByVal Codigo As Integer, ByVal Anio As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                'Catalogo 36
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = catalogoFactura
                clsDTLPro.PDOC_PAR_ANO = dgFactura.CurrentRow.Cells("col_anio").Value
                clsDTLPro.PDOC_PAR_NUM = dgFactura.CurrentRow.Cells("number").Value 'Codigo
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("col_linea").Value
                'Catalogo 397
                clsDTLPro.PDOC_CHI_CAT = catalogos
                clsDTLPro.PDOC_CHI_ANO = Anio
                clsDTLPro.PDOC_CHI_NUM = Codigo
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("col_linea").Value

                If logInsertar = True Then
                    If dgDetalle.Rows(i).Cells("col_Extra").Value = 0 Then
                        If clsDTLPro.Guardar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If

                If logEditar = True Then
                    If dgDetalle.Rows(i).Cells("col_Extra").Value = 1 Then
                        If clsDTLPro.Actualizar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If

                If checkActive.Checked = False Then
                    checkActive.Enabled = False
                    If clsDTLPro.Borrar = False Then
                        MsgBox(clsDTLPro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                        Return False
                        logGuardar = False
                        Exit Function
                    End If
                End If

            Next


            ' Contrato
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 389
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(j).Cells("colRefAnio").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(j).Cells("colRefNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(j).Cells("col_linea").Value
                ' Catalalogo 397
                clsDTLPro.PDOC_CHI_CAT = catalogos
                clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(j).Cells("col_linea").Value


                If logInsertar = True Then
                    If dgDetalle.Rows(j).Cells("col_Extra").Value = 0 Then
                        If dgDetalle.Rows(j).Cells("colRefNum").Value > 0 Then
                            If clsDTLPro.Guardar = False Then
                                MsgBox(clsDTLPro.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                                Return False
                                logGuardar = False
                                Exit Function
                            Else
                                logGuardar = True
                            End If
                        Else

                        End If
                    End If

                End If

                If logEditar = True Then
                    If dgDetalle.Rows(j).Cells("col_Extra").Value = 1 Then
                        If dgDetalle.Rows(j).Cells("colRefNum").Value > 0 Then
                            If clsDTLPro.Actualizar = False Then
                                MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                                Return False
                                logGuardar = False
                                Exit Function
                            Else
                                logGuardar = True
                            End If
                        Else

                        End If
                    End If
                    End If

            Next
            'Credito 
            For k As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 387
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(k).Cells("ref_Canio").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(k).Cells("ref_CNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(k).Cells("ref_CLin").Value
                ' Catalalogo 397
                clsDTLPro.PDOC_CHI_CAT = catalogos
                clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(k).Cells("col_linea").Value


                If logInsertar = True Then
                    If dgDetalle.Rows(k).Cells("col_Extra").Value = 0 Then
                        If dgDetalle.Rows(k).Cells("ref_CNum").Value > 0 Then

                            If clsDTLPro.Guardar = False Then
                                MsgBox(clsDTLPro.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                                Return False
                                logGuardar = False
                                Exit Function
                            Else
                                logGuardar = True
                            End If
                        Else

                        End If
                    End If
                End If

                If logEditar = True Then
                    If dgDetalle.Rows(k).Cells("col_Extra").Value = 1 Then
                        If dgDetalle.Rows(k).Cells("colRefNum").Value > 0 Then

                            If clsDTLPro.Actualizar = False Then
                                MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                                Return False
                                logGuardar = False
                                Exit Function
                            Else
                                logGuardar = True
                            End If
                        Else

                        End If
                    End If
                End If
            Next
        Catch ex As Exception

        End Try
        Return logGuardar
    End Function
    Public Sub CargarHilo(ByVal intHilo As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim conec As New MySqlConnection

        conec.ConnectionString = strConexion
        conec.Open()
        Try

            strSQL = " SELECT a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') proveedor, m.cat_clave Medida "
            strSQL &= " FROM Inventarios i "
            strSQL &= " INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL &= " LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa "
            strSQL &= " LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab "
            strSQL &= " LEFT JOIN Proveedores v ON v.pro_sisemp = i.inv_sisemp AND v.pro_codigo = i.inv_provcod "
            strSQL &= " WHERE i.inv_sisemp={empresa} AND i.inv_numero={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intHilo)

            COM2 = New MySqlCommand(strSQL, conec)
            REA2 = COM2.ExecuteReader
            If REA2.HasRows Then
                Do While REA2.Read
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1

                        If REA2.GetString("proveedor") = vbNullString Then
                            lblInformacion.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais")
                        Else
                            lblInformacion.Text = REA2.GetString("descripcion") & "  " & REA2.GetString("pais") & "/" & REA2.GetString("proveedor")
                        End If
                        ' Contador = Contador + 1

                    Next
                    lblLinea.Text = Linea
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            conec.Close()
        End Try
        'REA.Close()
        'REA = Nothing
        'COM = Nothing
    End Sub
    Private Sub VerInformacionDeHilo()
        Dim intHilo As Integer
        Try

            If dgDetalle.Rows.Count > 0 Then
                intHilo = dgDetalle.CurrentRow.Cells("col_Codigo").Value
                If Me.Tag = "Mod" Then
                    CargarHilo(intHilo, dgDetalle.CurrentRow.Cells("col_Extra").Value)
                Else
                    CargarHilo(intHilo, dgDetalle.CurrentRow.Index + 1)
                End If
            End If
            'End If

        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarReferenciaDTLPRO(ByVal anio As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1


                strSQL = SQLReferencia(anio, numero, dgDetalle.Rows(i).Cells("col_linea").Value)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        dgDetalle.Rows(i).Cells("colRefAnio").Value = REA.GetInt32("cAnio")
                        dgDetalle.Rows(i).Cells("colRefNum").Value = REA.GetInt32("cNumero")
                        dgDetalle.Rows(i).Cells("colRefLine").Value = REA.GetInt32("cLinea")
                        dgDetalle.Rows(i).Cells("ref_Canio").Value = REA.GetInt32("lAnio")
                        dgDetalle.Rows(i).Cells("ref_CNum").Value = REA.GetInt32("lNumero")
                        dgDetalle.Rows(i).Cells("ref_CLin").Value = REA.GetInt32("lLinea")
                    Loop
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CalcularTotales()
        Dim dblCantidad As Double
        Dim dblTotal As Double
        Dim dblGranTotal As Double
        Dim dblDevolucion As Double
        Dim dblPrecio As Double
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                dblCantidad = dblCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value
                dblDevolucion = (dgDetalle.Rows(i).Cells("colCantidad").Value - dgDetalle.Rows(i).Cells("colDevolucion").Value)
                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                dgDetalle.Rows(i).Cells("colTotal").Value = Math.Round((dblDevolucion.ToString(FORMATO_MONEDA) * dblPrecio), 2)
                dblTotal = dgDetalle.Rows(i).Cells("colTotal").Value
                dblGranTotal = dblGranTotal + dblTotal.ToString("###0.00")
                dblDevolucion = INT_CERO
                dblPrecio = INT_CERO
            Next

            celdaCantidad.Text = dblCantidad.ToString(FORMATO_MONEDA)
            celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function DinstintoHilo() As String
        Dim strSQL As String
        Try
            strSQL = "  SELECT DISTINCT d.DDoc_RF1_Cod contrato, d.DDoc_Prd_Des descripcion "
            strSQL &= "     FROM Dcmtos_DTL d "
            strSQL &= "         WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", catalogos)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Function BorrarEncabezado(ByVal Codigo As Integer, ByVal intAnio As Integer) As Boolean
        Dim LogGuardar As Boolean
        Dim clsHDR As New clsDcmtos_HDR
        Try
            clsHDR.CONEXION = strConexion
            If LogBorrar = True Then
                clsHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
                clsHDR.HDOC_DOC_CAT = catalogos
                clsHDR.HDOC_DOC_ANO = intAnio
                clsHDR.HDOC_DOC_NUM = Codigo
                If clsHDR.Borrar = False Then
                    LogGuardar = False
                    MsgBox(clsHDR.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                Else
                    cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, catalogos, celdaAño.Text, celdaNumero.Text)
                    LogGuardar = True
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function
    Private Function BorrarDetalle(ByVal Codigo As Integer, ByVal intAnio As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim clsDTL As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTL.DDOC_DOC_CAT = catalogos
                clsDTL.DDOC_DOC_ANO = intAnio
                clsDTL.DDOC_DOC_NUM = Codigo
                clsDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("col_linea").Value
                If clsDTL.Borrar = False Then
                    logGuardar = False
                    MsgBox(clsDTL.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                Else
                    cfun.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, 0, catalogos, celdaAño.Text, celdaNumero.Text)
                    logGuardar = True
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function BorrarDTLPro(ByVal Codigo As Integer, ByVal intAnio As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                'Catalogo 36
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = catalogoFactura
                clsDTLPro.PDOC_PAR_ANO = intAnio
                clsDTLPro.PDOC_PAR_NUM = dgFactura.CurrentRow.Cells("number").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("col_linea").Value
                'Catalogo 397
                clsDTLPro.PDOC_CHI_CAT = catalogos
                clsDTLPro.PDOC_CHI_ANO = intAnio
                clsDTLPro.PDOC_CHI_NUM = Codigo
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("col_linea").Value
                If LogBorrar = True Then
                    If clsDTLPro.Borrar = False Then
                        MsgBox(clsDTLPro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                        Return False
                        logGuardar = False
                        Exit Function
                    Else
                        logGuardar = True
                    End If
                End If
            Next
            ' Contrato 

            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 389
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(j).Cells("colRefAnio").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(j).Cells("colRefNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(j).Cells("col_linea").Value
                ' Catalalogo 397
                clsDTLPro.PDOC_CHI_CAT = catalogos
                clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(j).Cells("col_linea").Value
                If LogBorrar = True Then
                    If clsDTLPro.Borrar = False Then
                        MsgBox(clsDTLPro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                        Return False
                        logGuardar = False
                        Exit Function
                    Else
                        logGuardar = True
                    End If
                End If
            Next
            'Credito 
            For k As Integer = 0 To dgDetalle.Rows.Count - 1
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 387
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(k).Cells("ref_Canio").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(k).Cells("ref_CNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(k).Cells("ref_CLin").Value
                ' Catalalogo 397
                clsDTLPro.PDOC_CHI_CAT = catalogos
                clsDTLPro.PDOC_CHI_ANO = celdaAño.Text
                clsDTLPro.PDOC_CHI_NUM = celdaNumero.Text
                clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(k).Cells("col_linea").Value
                If LogBorrar = True Then
                    If dgDetalle.Rows(k).Cells("ref_CNum").Value > 0 Then
                        If clsDTLPro.Borrar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If
            Next



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function
#End Region
#Region "Eventos"
    Private Sub FrmCargoReceipt_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFechaInicial.Value = dtpFechaInicial.Value.AddMonths(NO_FILA)
        dtpFechaFinal.Value = Today
        Me.Tag = "Nuevo"
        Accessos()
        MostrarLista()

    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarPanelOrden()
            lblInformacion.Text = STR_VACIO
            MostrarLista(False, True)
        Else
            MsgBox("No Posee permisos para esta acción", vbInformation)
        End If
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_nit, c.cli_telefono "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidCliente.Text = frm.LLave
                celdaNombreCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaNIT.Text = frm.Dato3
                celdaTelefono.Text = frm.Dato4
                celdaMoneda.Text = "US$"
                celdaIdMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")


            End If
            CargarDocumentosProcesados()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonContacto_Click(sender As Object, e As EventArgs) Handles botonContacto.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cnt_sisemp = {empresa} AND  c.cnt_codemp  = {cliente} AND c.cnt_status = 'Activo'  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{cliente}", celdaidCliente.Text)
        Try
            frm.Titulo = "Contact"
            frm.Campos = " CONCAT(c.cnt_nombre ,' | ',c.cnt_celular) Contacto "
            frm.Tabla = " Contactos c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cnt_nombre"
            frm.Limite = 30
            frm.Ordenamiento = " c.cnt_codemp "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaContacto.Text = frm.LLave

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim strFila As String = STR_VACIO
        dgFactura.CurrentRow.Cells(6).Value = 2
        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows.Count = 1 Then
                strFila = dgFactura.Rows(i).Cells("col_Tipo").Value & "|" & dgFactura.Rows(i).Cells("col_anio").Value & "|" & dgFactura.Rows(i).Cells("col_Numero").Value & "|" & dgFactura.Rows(i).Cells("col_fecha").Value & "|" & dgFactura.Rows(i).Cells("colUsuario").Value & "|" & dgFactura.Rows(i).Cells("col_referencia").Value & "|" & dgFactura.Rows(i).Cells("colStatus").Value & "|" & dgFactura.Rows(i).Cells("number").Value
            ElseIf dgFactura.Rows(i).Cells("colStatus").Value = 2 Then
                dgFactura.CurrentRow.Cells(6).Value = 1
                strFila = dgFactura.Rows(i).Cells("col_Tipo").Value & "|" & dgFactura.Rows(i).Cells("col_anio").Value & "|" & dgFactura.Rows(i).Cells("col_Numero").Value & "|" & dgFactura.Rows(i).Cells("col_fecha").Value & "|" & dgFactura.Rows(i).Cells("colUsuario").Value & "|" & dgFactura.Rows(i).Cells("col_referencia").Value & "|" & dgFactura.Rows(i).Cells("colStatus").Value & "|" & dgFactura.Rows(i).Cells("number").Value
            End If
        Next
        dgFactura.Rows.Clear()
        cFunciones.AgregarFila(dgFactura, strFila)


        dgDetalle.Rows.Clear()
        CargarDatosCliente(celdaidCliente.Text)
        CargarPolizaExportacion()
        CargarDocumentosDetalle()
        Pedido()
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
    End Sub
    Private Sub BotonMoneda_Click(sender As Object, e As EventArgs) Handles BotonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 11
                    Pedido()
                Case 12
                    CartaCredito(dgDetalle.CurrentRow.Cells("colRefAnio").Value, dgDetalle.CurrentRow.Cells("colRefNum").Value, dgDetalle.CurrentRow.Cells("col_linea").Value)
                Case 13
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_envio").Value = frmF.LLave
                    End If
                Case 14
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_presentado").Value = frmF.LLave
                    End If
                Case 18
                    Dim frmF As New frmDateTimePicker
                    frmF.ShowDialog(Me)
                    If frmF.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells("col_pago").Value = frmF.LLave
                    End If
            End Select


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer
        Dim numero As Integer
        Me.Tag = "Mod"
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        'captura el año,numero del panelprincipal dglista
        MostrarLista(0)
        año = dgLista.SelectedCells(0).Value
        numero = dgLista.SelectedCells(1).Value
        LimpiarPanelOrden()
        botonCliente.Enabled = False
        botonAgregarFactura.Enabled = False
        CargarEncabezado(numero, año)
        CargarReferencia(año, numero)
        CargarDetalle(numero, año)
        CargarReferenciaDTLPRO(año, numero)
    End Sub
    Private Sub dgDetalle_SelectionChanged(sender As Object, e As EventArgs) Handles dgDetalle.SelectionChanged
        VerInformacionDeHilo()
    End Sub
    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotales()
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If logEditar = True Or Me.Tag = "Nuevo" Then
            If ComprobarDatos() = True Then
                If ComprobarFila() = True Then
                    If GuardarDocumento(celdaNumero.Text, celdaAño.Text) = True Then
                        If MsgBox("the document has been saved  " & vbCr & vbCr & "¿You want to close the document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                            MostrarLista(True)
                        Else
                            MostrarLista(0)
                            Me.Tag = "mod"
                        End If
                    End If
                    End If
            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(catalogos, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, catalogos)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim strSQL As String
        Dim strContrato(100) As String
        Dim ArrayValidacion() As String
        Dim strValidacion As String = STR_VACIO
        Dim strValidacion2 As String = STR_VACIO
        Dim strDescripcion(100) As String
        Dim z As Integer = INT_CERO
        Dim strGrupo As String = STR_VACIO
        Dim frm As New frmOption
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim cls As New clsReportes
        Dim intLinea As Integer = 0
        strSQL = DinstintoHilo()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                z = z + 1
                ReDim Preserve strContrato(z)
                ReDim Preserve strDescripcion(z)

                strContrato(z) = REA.GetString("contrato")
                strDescripcion(z) = REA.GetString("descripcion")

                strGrupo = strGrupo & IIf(intLinea = 0, vbNullString, "|") & strContrato(z) & "- " & strDescripcion(z)
                intLinea = intLinea + 1
            Loop
        End If
        If intLinea > 1 Then
            frm.Titulo = "Printing Options"
            frm.Mensaje = "Select what you want to print"
            frm.Opciones = strGrupo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strValidacion = frm.FilaBase
                ArrayValidacion = strValidacion.Split("-".ToCharArray)
                strValidacion2 = ArrayValidacion(INT_UNO)
                For j As Integer = 0 To dgDetalle.Rows.Count - 1
                    If strValidacion2.Contains(dgDetalle.Rows(j).Cells("col_descripcion").Value) Then
                        cls.ImpresionCargoReceipt(catalogos, celdaAño.Text, celdaNumero.Text, dgDetalle.Rows(j).Cells("col_Contrato").Value, dgDetalle.Rows(j).Cells("col_descripcion").Value)
                        Exit Sub
                    End If
                Next
            End If
        Else
            cls.ImpresionCargoReceipt(catalogos, celdaAño.Text, celdaNumero.Text, dgDetalle.CurrentRow.Cells("col_Contrato").Value, dgDetalle.CurrentRow.Cells("col_descripcion").Value)
        End If
    End Sub

    Private Sub botonAgregarFactura_Click(sender As Object, e As EventArgs) Handles botonAgregarFactura.Click

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarEncabezado(celdaNumero.Text, celdaAño.Text)
                BorrarDetalle(celdaNumero.Text, celdaAño.Text)
                BorrarDTLPro(celdaNumero.Text, celdaAño.Text)
                MsgBox("Delete Complete")
                MostrarLista(True)
            End If

        End If
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Try
            cfun.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAplicante_Click(sender As Object, e As EventArgs) Handles botonAplicante.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_nit, c.cli_telefono "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdAplicante.Text = frm.LLave
                celdaAplicante.Text = frm.Dato
                celdaDireccion2.Text = frm.Dato2
                celdaNit.Text = frm.Dato3
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub
#End Region

End Class