﻿Public Class frmLibroComprasOtros
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Private Sub botonBorrar_Click(sender As Object, e As EventArgs) Handles botonBorrar.Click
        Me.Close()
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Function SqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = " select h.HDoc_Doc_Ano Ano,  h.HDoc_Doc_Num Numero ,   month(h.HDoc_Doc_Fec ) Mes, if(h.HDoc_Doc_Status=1,'CLOSED', 'OPEN') Estado  "
        strSQL &= " from Dcmtos_HDR h "
        strSQL &= " where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 900 "
        strSQL &= " order by  h.HDoc_Sis_Emp desc,  h.HDoc_Doc_Cat desc,  h.HDoc_Doc_Ano desc,  h.HDoc_Doc_Num desc "
        'strSQL &= " limit 40 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function
    Private Sub CargarLista()
        Dim strSql As String = STR_VACIO
        Dim strFila As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        dgLista.Rows.Clear()
        Try
            strSql = SqlLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= cFunciones.MesALetras(REA.GetInt32("Mes")) & "|"
                    strFila &= REA.GetString("Estado")

                    If REA.GetString("Estado") = "OPEN" Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.LightYellow)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila, Color.LightBlue)
                    End If

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ModificarLibro(ByVal id As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " UPDATE Dcmtos_HDR h SET h.HDoc_Doc_Status = {id} "
        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 900 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", dgLista.CurrentRow.Cells("colIdAno").Value)
        strSQL = Replace(strSQL, "{numero}", dgLista.CurrentRow.Cells("colIdNumero").Value)
        strSQL = Replace(strSQL, "{id}", id)

        MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
    End Sub



    Private Sub botonBloquear_Click(sender As Object, e As EventArgs) Handles botonBloquear.Click
        If MsgBox("Do you want to proceed to Close the book?", vbYesNo, "Question") = vbYes Then
            ModificarLibro(1)
            MsgBox("The Purchase book has been closed", vbInformation, "Notice")
            CargarLista()
        End If
    End Sub

    Private Sub botonLiberar_Click(sender As Object, e As EventArgs) Handles botonLiberar.Click
        If MsgBox("You want to open the book for Modifications", vbYesNo, "Question") = vbYes Then
            ModificarLibro(0)
            MsgBox("the shopping book has been enabled", vbInformation, "Notice ")
            CargarLista()
        End If
    End Sub
    Private Function SQLOtrosDocumentos(ByVal intAno As Integer, ByVal intNumero As Integer, ByVal Finicio As Date, ByVal Ffin As Date) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  insert into Dcmtos_DTL "
            strSQL &= " (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_UM, DDoc_RF1_Num, DDoc_RF2_Num, DDoc_RF3_Num, DDoc_RF1_Fec, DDoc_RF1_Cod, DDoc_Prd_Des, DDoc_Prd_PNr, DDoc_Prd_Fob, DDoc_RF1_Txt, DDoc_RF2_Txt, DDoc_Prd_PUQ, DDoc_RF1_Dbl, DDoc_RF2_Dbl,DDoc_Prd_Cif, DDoc_RF3_Dbl,  DDoc_RF2_Cod) "
            strSQL &= "     SELECT {empresa} emp,900 cat,{ano} anio,{numero} num,@rownum:=@rownum+1 as linea,0, d.DDoc_Doc_Cat ref_tipo, d.DDoc_Doc_Ano ref_ano, d.DDoc_Doc_Num ref_numero,  h.HDoc_Doc_Fec fecha, CAST(CONCAT(d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num) AS CHAR) id ,COALESCE(lp.pro_proveedor,h.HDoc_Emp_Per) proveedor,'Otro Documento' tipo, "
            strSQL &= "     IFNULL(( SELECT COUNT(*) "
            strSQL &= "               FROM Dcmtos_DTL e"
            strSQL &= "                 LEFT JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND c.HDoc_Doc_Cat=e.DDoc_RF1_Num AND c.HDoc_Doc_Ano=e.DDoc_RF2_Num AND c.HDoc_Doc_Num=e.DDoc_RF3_Num  "
            strSQL &= "              WHERE e.DDoc_Sis_Emp=d.DDoc_Sis_Emp AND e.DDoc_Doc_Cat= 900 AND e.DDoc_RF1_Num=d.DDoc_Doc_Cat AND e.DDoc_RF2_Num=d.DDoc_Doc_Ano AND e.DDoc_RF3_Num=d.DDoc_Doc_Num AND c.HDoc_Doc_Status=1),0) existe,   "
            strSQL &= "     concat(CONCAT(h.HDoc_DR2_Num,' ',h.HDoc_DR1_Num) , '|FA|', COALESCE(lp.pro_nit,'N/A')  ) documento, "
            strSQL &= "     CONCAT( (SELECT IFNULL(GROUP_CONCAT(DISTINCT b.HDoc_DR1_Num SEPARATOR ', '),'-') "
            strSQL &= "                 FROM Dcmtos_DTL a "
            strSQL &= "                 left JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = a.DDoc_Sis_Emp AND b.HDoc_Doc_Cat = a.DDoc_Doc_Cat AND b.HDoc_Doc_Ano = a.DDoc_Doc_Ano AND b.HDoc_Doc_Num = a.DDoc_Doc_Num "
            strSQL &= "     WHERE a.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND a.DDoc_Doc_Cat = 51 AND a.DDoc_RF1_Num = d.DDoc_Doc_Cat AND a.DDoc_RF2_Num = d.DDoc_Doc_Ano AND a.DDoc_RF3_Num = d.DDoc_Doc_Num) ,'|-|',GROUP_CONCAT(DISTINCT IFNULL(d.DDoc_RF1_Cod,'N/A') SEPARATOR ',') ) cuenta, -1 uno , "
            strSQL &= "     IFNULL(IF(h.HDoc_Doc_Status = 1, ii.MDoc_Lin_Base,0),ROUND((SUM(IFNULL(IF(h.HDoc_Doc_Status = 1,d.DDoc_RF1_Dbl * h.HDoc_Doc_TC,0),0))),2)) base, IFNULL(IF(h.HDoc_Doc_Status = 1,ii.MDoc_Lin_Monto,0),0) iva, ROUND((SUM(IFNULL(IF(h.HDoc_Doc_Status = 1,d.DDoc_RF1_Dbl * h.HDoc_Doc_TC,0),0))),2) total, IFNULL(ic.MDoc_Lin_Monto,0) directo, "
            strSQL &= "     IF(IFNULL(ic.MDoc_Lin_Monto,0)>0,'C', ELT((d.DDoc_RF1_Num + 1),'B','S')) TTipo "
            strSQL &= "     FROM (SELECT @rownum:=0)r,Dcmtos_DTL d "
            strSQL &= "         INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL &= "         LEFT JOIN Proveedores lp ON lp.pro_sisemp = d.DDoc_Sis_Emp AND lp.pro_codigo = h.HDoc_Emp_Cod "
            strSQL &= "         LEFT JOIN Dcmtos_IMP ii ON ii.MDoc_Sis_Emp=d.DDoc_Sis_Emp AND ii.MDoc_Doc_Cat=d.DDoc_Doc_Cat AND ii.MDoc_Doc_Ano=d.DDoc_Doc_Ano AND ii.MDoc_Doc_Num=d.DDoc_Doc_Num AND ii.MDoc_Lin_Codigo='IVA'  "
            strSQL &= "         LEFT JOIN Dcmtos_IMP ic ON ic.MDoc_Sis_Emp=d.DDoc_Sis_Emp AND ic.MDoc_Doc_Cat=d.DDoc_Doc_Cat AND ic.MDoc_Doc_Ano=d.DDoc_Doc_Ano AND ic.MDoc_Doc_Num=d.DDoc_Doc_Num AND ic.MDoc_Lin_Codigo='IMP_DC' "
            strSQL &= "     WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 209 AND h.HDoc_RF1_Num = 0 AND HDoc_DR1_Emp>=0 AND IFNULL(h.HDoc_DR2_Cat,0)=0 AND (h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}') AND (d.DDoc_RF1_Dbl > 0) and h.HDoc_Doc_Num >=1 "
            strSQL &= "     GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, d.DDoc_RF1_Num "
            strSQL &= "     HAVING existe=0 "
            strSQL &= "     ORDER BY h.HDoc_Doc_Fec, h.HDoc_Emp_Cod, h.HDoc_Doc_Num, d.DDoc_Doc_Lin "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", intAno)
            strSQL = Replace(strSQL, "{numero}", intNumero)
            strSQL = Replace(strSQL, "{inicio}", Finicio.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", Ffin.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Private Sub GenerarLibro(ByVal Finicio As Date, Ffin As Date)
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strSQLine As String = STR_VACIO
        Dim IntAno As Integer = NO_FILA
        Dim IntNumero As Integer = NO_FILA
        Dim chdr As New clsDcmtos_HDR
        Dim conec1 As MySqlConnection

        Try
            IntAno = Ffin.Year
            IntNumero = cFunciones.NuevoId(900, IntAno)

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 900
            chdr.HDOC_DOC_ANO = IntAno
            chdr.HDOC_DOC_NUM = IntNumero
            chdr.HDoc_Doc_Fec_NET = Ffin
            chdr.HDOC_EMP_NOM = Sesion.Empresa
            chdr.HDOC_EMP_DIR = STR_VACIO
            chdr.HDOC_EMP_NIT = "N/A"
            chdr.HDOC_DR1_NUM = "DEL MES DE  " & cFunciones.MesALetras(Month(Ffin))
            chdr.HDoc_DR1_Fec_NET = Today
            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_RF1_DBL = INT_CERO
            chdr.HDOC_DOC_STATUS = INT_CERO

            chdr.CONEXION = strConexion
            If chdr.Guardar = True Then
                'Otros Documentos
                strSQL = SQLOtrosDocumentos(IntAno, IntNumero, Finicio, Ffin)
                MyCnn.CONECTAR = strConexion & ";Allow User Variables=True"
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()

            Else
                MsgBox(chdr.MERROR.ToString)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarLibro(ByVal Fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intAno As Integer = NO_FILA
        Dim intNum As Integer = NO_FILA
        Dim chdr As New clsDcmtos_HDR
        Dim strCondicion As String = STR_VACIO
        Dim dtl As New clsDcmtos_DTL
        Try
            strSQL = " select h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano ano  , h.HDoc_Doc_Num num from Dcmtos_HDR h "
            strSQL &= "  where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 900 and h.HDoc_Doc_Ano = {ano} and month(h.HDoc_Doc_Fec ) = {mes} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", Year(Fecha))
            strSQL = Replace(strSQL, "{mes}", Month(Fecha))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    intAno = REA.GetInt32("ano")
                    intNum = REA.GetInt32("num")
                Loop
            End If
            'borrar HDR
            strCondicion = " HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 900 and HDoc_Doc_Ano = {ano} and HDoc_Doc_Num = {num} "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{ano}", intAno)
            strCondicion = Replace(strCondicion, "{num}", intNum)


            chdr.CONEXION = strConexion
            If chdr.Borrar(strCondicion) = False Then
                MsgBox(" The book couldn't be deleted  " & chdr.MERROR.ToString)
            End If

            'Borrar DTL 
            strCondicion = " DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = 900 and DDoc_Doc_Ano = {ano} and DDoc_Doc_Num = {num} "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{ano}", intAno)
            strCondicion = Replace(strCondicion, "{num}", intNum)
            dtl.CONEXION = strConexion
            If dtl.Borrar(strCondicion) = False Then
                MsgBox(" The book detail couldn't be deleted " & dtl.MERROR.ToString)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ExisteLibro(ByVal Fecha As Date) As Boolean
        Dim logResultado As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " select count(*) from Dcmtos_HDR h "
            strSQL &= "  where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 900 and h.HDoc_Doc_Ano = {ano} and month(h.HDoc_Doc_Fec ) = {mes} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", Year(Fecha))
            strSQL = Replace(strSQL, "{mes}", Month(Fecha))

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            If COM.ExecuteScalar = INT_CERO Then
                logResultado = False
            Else
                logResultado = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Sub botonNuevo_Click(sender As Object, e As EventArgs) Handles botonNuevo.Click
        Dim frm As New frmDateTimePicker
        Dim Fecha_Inicio As Date
        Dim Fecha_Fin As Date
        Try
            frm.ShowDialog(Me)
            If frm.DialogResult = Windows.Forms.DialogResult.OK Then
                If MsgBox("Do you want to include no process documents of last 2 month?", MsgBoxStyle.YesNo) = vbYes Then
                    Fecha_Inicio = DateAdd(DateInterval.Month, -2, cFunciones.PrimerdiaDelMes(frm.DateTimePicker1.Value))
                Else
                    Fecha_Inicio = cFunciones.PrimerdiaDelMes(frm.DateTimePicker1.Value)
                End If
                Fecha_Fin = cFunciones.UltimodiaDelMes(frm.DateTimePicker1.Value)
                If ExisteLibro(Fecha_Fin) Then
                    If MsgBox(" This book already exist." & vbNewLine & "Do you want to rewrite this book ?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                        BorrarLibro(Fecha_Fin)
                        GenerarLibro(Fecha_Inicio, Fecha_Fin)
                    Else
                        Exit Sub
                    End If
                Else
                    GenerarLibro(Fecha_Inicio, Fecha_Fin)
                End If
                CargarLista()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BotonSalir_Click(sender As Object, e As EventArgs) Handles BotonSalir.Click

    End Sub
    Private Sub ImprimirLibroCompras()
        Dim rpt As New clsReportes
        Dim IntAnio As Integer = 0
        Dim IntNumero As Integer = 0
        Dim strMes As String = STR_VACIO

        IntAnio = dgLista.CurrentRow.Cells("colIdAno").Value
        IntNumero = dgLista.CurrentRow.Cells("colIdNumero").Value
        strMes = dgLista.CurrentRow.Cells("colMes").Value

        rpt.LibroComprasOtrosDocumentos(IntAnio, IntNumero, strMes)
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ImprimirLibroCompras()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        ImprimirLibroCompras()
    End Sub

    Private Sub frmLibroComprasOtros_Load(sender As Object, e As EventArgs) Handles Me.Load
        CargarLista()
    End Sub
#End Region
End Class