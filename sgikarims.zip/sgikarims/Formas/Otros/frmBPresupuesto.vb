﻿Public Class frmBPresupuesto
    Public Property Monto As Double = 0.0
    Public Property fechaDocumento As Date = Now()
    Private strBuscar As String = String.Empty

    'Suma el detalle de presupuesto
    Public Sub Sumar()
        Dim dblSuma As Double = 0.0
        Dim row As DataGridViewRow

        For Each row In Lista.Rows
            dblSuma += CDbl(row.Cells(lista_monto.Index).Value)
            row.Cells(lista_monto.Index).Selected = True
        Next
        CeldaTotal.Text = dblSuma.ToString("f")
    End Sub

    'Muestra las cuentas de presupuesto para seleccionar
    Private Sub SeleccionarCuentas()
        Const INT_DETALLE As Integer = 3
        Dim gr As DataGridViewRow
        Dim row As DataGridViewRow

        Using frm As New frmSeleccionMultiple
            frm.strTipoVenta = 0
            ConfigurarDetalle(frm.Lista)
            CargarCuentas(frm.Lista)
            'frm.AgregarColumnaSeleccion()
            frm.Text = "Select Account To Allocate"
            frm.Multiple = False
            If frm.ShowDialog = DialogResult.OK Then
                row = frm.Lista.CurrentRow

                'Solo si es una cuenta de detalle
                If CInt(row.Cells(frm.Lista.Columns.Item("lista_tipo").Index).Value) = INT_DETALLE Then
                    Lista.SuspendLayout()
                    Lista.AllowUserToAddRows = True

                    'Agregar fila
                    gr = Lista.Rows(Lista.NewRowIndex).Clone
                    gr.Cells(lista_cuenta.Index).Value = row.Cells(frm.Lista.Columns.Item("lista_cuenta").Index).Value
                    gr.Cells(lista_nombre.Index).Value = row.Cells(frm.Lista.Columns.Item("lista_nombre").Index).Value
                    gr.Cells(lista_name.Index).Value = row.Cells(frm.Lista.Columns.Item("lista_name").Index).Value
                    gr.Cells(lista_monto.Index).Value = INT_CERO.ToString("f")

                    Lista.Rows.Add(gr)
                    gr.Selected = True
                    gr.Cells(lista_monto.Index).Selected = True

                    Lista.AllowUserToAddRows = False
                    Lista.ResumeLayout()

                    'Editar monto
                    Lista.BeginEdit(True)
                Else
                    Lista.Focus()
                End If
            End If
        End Using
    End Sub

    'Carga los documentos de venta con saldo pendiente de pago (ref. cliente)
    Private Sub CargarCuentas(ByRef Lista As DataGridView)
        Dim intTipo As Integer
        Dim strSQL As String = " SELECT id_cuenta ID, nombre_loc Nombre, nombre_ext name, CAST(tipo AS SIGNED) Tipo " &
                               " FROM {conta}.cuentas_presupuesto " &
                               " WHERE empresa = {empresa} AND tipo IN(1,3) {reporte2024}" &
                               " ORDER BY id_cuenta"
        strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{conta}", Sesion.BaseConta)
        If fechaDocumento.Year < 2024 Then
            strSQL = strSQL.Replace("{reporte2024}", " AND idNomenclatura IS NULL ")
        Else
            strSQL = strSQL.Replace("{reporte2024}", " AND idNomenclatura =1 ")
        End If
        MyCnn.CONECTAR = strConexion
            Dim cmd As New MySqlCommand(strSQL, CON)
            Dim da As New MySqlDataAdapter(cmd)
            Dim dt As New System.Data.DataTable
            Dim dr As DataRow
            Dim row As DataGridViewRow
            da.Fill(dt)

            'Cargar filas en cuadricula para seleccion
            Lista.SuspendLayout()
            Lista.AllowUserToAddRows = True
            For Each dr In dt.Rows
                intTipo = CInt(dr("tipo"))

            row = Lista.Rows(Lista.NewRowIndex).Clone
            row.Cells(Lista.Columns.Item("lista_tipo").Index).Value = intTipo.ToString
            row.Cells(Lista.Columns.Item("lista_cuenta").Index).Value = dr("id").ToString
            row.Cells(Lista.Columns.Item("lista_nombre").Index).Value = dr("nombre").ToString
            row.Cells(Lista.Columns.Item("lista_name").Index).Value = dr("name").ToString

            If intTipo.Equals(INT_UNO) Then
                row.Cells(Lista.Columns.Item("lista_cuenta").Index).Style.BackColor = Color.DarkSeaGreen
                row.Cells(Lista.Columns.Item("lista_cuenta").Index).Style.ForeColor = Color.White
                row.Cells(Lista.Columns.Item("lista_nombre").Index).Style.BackColor = Color.DarkSeaGreen
                row.Cells(Lista.Columns.Item("lista_nombre").Index).Style.ForeColor = Color.White
                row.Cells(Lista.Columns.Item("lista_name").Index).Style.BackColor = Color.DarkSeaGreen
                row.Cells(Lista.Columns.Item("lista_name").Index).Style.ForeColor = Color.White
            End If

            Lista.Rows.Add(row)
            Next
            Lista.AllowUserToAddRows = False
            Lista.ResumeLayout()
    End Sub

    'Para crear una columna de texto en una cuadricula
    Private Function CrearColumnaTexto(ByVal Nombre As String, Optional Texto As String = STR_VACIO, Optional EsVisible As Boolean = False, Optional Bloqueado As Boolean = True, Optional Ancho As Integer = 50) As DataGridViewTextBoxColumn
        Dim col As New DataGridViewTextBoxColumn
        col.Name = Nombre
        col.HeaderText = Texto
        col.Visible = EsVisible
        col.ReadOnly = Bloqueado
        col.Width = Ancho
        col.SortMode = DataGridViewColumnSortMode.NotSortable
        If Bloqueado Then
            col.DefaultCellStyle.BackColor = Color.LightYellow
        End If
        Return col
    End Function

    'Configura las columnas para la cuadricula de cuentas de presupuesto
    Private Sub ConfigurarDetalle(ByRef Lista As DataGridView)
        Dim col As DataGridViewTextBoxColumn

        col = CrearColumnaTexto("lista_tipo")
        Lista.Columns.Add(col)

        'Columnas visibles
        col = CrearColumnaTexto("lista_cuenta", "Account", True, True, 100)
        col.DefaultCellStyle.BackColor = SystemColors.Info
        col.DefaultCellStyle.ForeColor = SystemColors.InfoText
        Lista.Columns.Add(col)

        'Columnas visibles
        col = CrearColumnaTexto("lista_nombre", "Description", True, True, 250)
        col.DefaultCellStyle.BackColor = SystemColors.Info
        col.DefaultCellStyle.ForeColor = SystemColors.InfoText
        Lista.Columns.Add(col)

        col = CrearColumnaTexto("lista_name", "Name", True, True, 250)
        col.DefaultCellStyle.BackColor = SystemColors.Info
        col.DefaultCellStyle.ForeColor = SystemColors.InfoText
        Lista.Columns.Add(col)
    End Sub

    'Eliminar la fila actual
    Private Sub BotonQuitar_Click(sender As Object, e As EventArgs) Handles BotonQuitar.Click
        If Lista.CurrentRow IsNot Nothing Then
            Lista.Rows().Remove(Lista.CurrentRow)
            If Lista.Rows.Count > INT_CERO Then
                Lista.Rows(Lista.Rows.Count - 1).Selected = True
            End If
            Lista.Focus()
            Sumar()
        End If
    End Sub

    'Cerrar esta ventana
    Private Sub BotonCerrar_Click(sender As Object, e As EventArgs) Handles BotonCerrar.Click
        DialogResult = DialogResult.Cancel
    End Sub

    'Cerrar ventana para guardar cambios
    Private Sub BotonGuardar_Click(sender As Object, e As EventArgs) Handles BotonGuardar.Click
        Dim logErr As Boolean = False
        Sumar()

        If CDbl(CeldaTotal.Text) > Monto Then
            MessageBox.Show("Allocated budget is greater than document amount", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Lista.Focus()
        Else
            For Each row As DataGridViewRow In Lista.Rows
                If row.Cells(lista_monto.Index).Value <= INT_CERO Then
                    logErr = True
                End If
            Next

            If logErr Then
                MessageBox.Show("Allocated amount must be a valid number", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Lista.Focus()
            Else
                DialogResult = DialogResult.OK
            End If
        End If
    End Sub

    Private Sub frmBPresupuesto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Lista.Columns(lista_nombre.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Lista.Columns(lista_name.Index).DefaultCellStyle.BackColor = Color.LightYellow
        Lista.Columns(lista_monto.Index).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
    End Sub

    'Evento: se ha modificado el monto
    Private Sub Lista_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles Lista.CellValueChanged
        If e.ColumnIndex.Equals(lista_monto.Index) Then
            Sumar()
        End If
    End Sub

    'Evento: validar el monto
    Private Sub Lista_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles Lista.CellValidating
        Dim s As String = String.Empty
        If e.ColumnIndex.Equals(lista_monto.Index) Then
            If Not IsNumeric(e.FormattedValue) Then
                MessageBox.Show("Please enter a valid number", "Amount", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
                e.Cancel = True
            End If
        End If
    End Sub

    'Evento: formato de celda
    Private Sub Lista_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles Lista.CellFormatting
        If Not String.IsNullOrEmpty(e.Value) Then
            If e.ColumnIndex.Equals(lista_monto.Index) Then
                e.Value = CDbl(e.Value).ToString("f")
            End If
        End If
    End Sub

    'Evento: boton agregar
    Private Sub BotonAgregar_Click(sender As Object, e As EventArgs) Handles BotonAgregar.Click
        SeleccionarCuentas()
    End Sub

    Private Sub Lista_KeyDown(sender As Object, e As KeyEventArgs) Handles Lista.KeyDown
        If e.KeyCode = Keys.F3 Then
            e.SuppressKeyPress = True
            If Lista.Rows.Count > INT_CERO Then
                'Mostrar ventana de busqueda
                BuscarTexto()
            End If
        End If
    End Sub

    Private Sub BuscarTexto()
        Dim strTemp As String = String.Empty
        Dim strDato As String = String.Empty

        Dim intDesde As Integer = INT_CERO
        Dim intFilas As Integer = (Lista.Rows.Count - 1)
        Dim intCols As Integer = (Lista.Columns.Count - 1)

        Dim logEx As Boolean = False

        strTemp = InputBox(String.Empty, "Search", strBuscar).Trim.ToUpper
        If strTemp.Equals(String.Empty) Then
            strBuscar = String.Empty
        Else
            'Si el texto es diferente buscar desde el inicio
            If strTemp.Equals(strBuscar) Then
                intDesde = (Lista.CurrentRow.Index + 1)
            End If
            strBuscar = strTemp

            'Recorrer las filas
            For i As Integer = intDesde To intFilas
                'Recorrer las columnas
                For j As Integer = INT_CERO To intCols
                    If Lista.Columns(j).Visible Then
                        strDato = If(Lista.Rows(i).Cells(j).Value, String.Empty).ToString().ToUpper.Trim
                        If strDato.Contains(strTemp) Then
                            'Seleccionar fila encontrada
                            Lista.ClearSelection()
                            Lista.CurrentCell = Lista.Rows(i).Cells(j)
                            logEx = True
                            Exit For
                        End If
                    End If
                Next
                If logEx Then Exit For
            Next

            If Not logEx Then
                MessageBox.Show("No search results for this text", "Search", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            Lista.Focus()
        End If
    End Sub
End Class