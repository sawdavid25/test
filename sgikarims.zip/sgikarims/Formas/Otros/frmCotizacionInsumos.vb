﻿Imports System.Reflection
Imports KARIMs_SGI.Tablas.TCATALOGOS
Imports Microsoft.Office.Interop.Word

Public Class frmCotizacionInsumos
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim intTipoIngreso As Integer = NO_FILA
    Dim cfun As New clsFunciones

    Dim intTipo As Integer

    Dim intMultiple As Integer
    Dim dblDocCantidad As Double
    Dim dblDocTotal As Double
    Dim CodProv As Integer = vbEmpty
    Dim logProduction As Boolean
    Dim anioRequisa As Integer
    Dim numRequisa As Integer

    'Constantes
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Public Const catalogos = 736
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"

    Private Function sqlLista() As String
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Num, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Nombre,  GROUP_CONCAT(A.HDoc_Doc_Num SEPARATOR ',') Requisa, h.HDoc_Doc_Status Estado
                    FROM Dcmtos_HDR h
                    LEFT JOIN
                    (
                    SELECT pro.PDoc_Sis_Emp, pro.PDoc_Chi_Cat, pro.PDoc_Chi_Ano, pro.PDoc_Chi_Num, hh.HDoc_Doc_Num
                    FROM Dcmtos_DTL_Pro pro
                    LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = pro.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat = pro.PDoc_Par_Cat AND hh.HDoc_Doc_Ano = pro.PDoc_Par_Ano AND hh.HDoc_Doc_Num = pro.PDoc_Par_Num
                    WHERE hh.HDoc_Sis_Emp = {empresa} AND hh.HDoc_Doc_Cat = 734
                    GROUP BY pro.PDoc_Chi_Num, hh.HDoc_Doc_Num
                    ) A ON A.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND A.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND A.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND A.PDoc_Chi_Num = h.HDoc_Doc_Num

                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {catalogo} "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "     AND (h.HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}')"
        End If
        strSQL &= "   GROUP BY h.HDoc_Doc_Ano, h.HDoc_Doc_Num          
                      ORDER BY h.HDoc_Doc_Ano DESC, h.HDoc_Doc_Num DESC; "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function

    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader



        strSQL = sqlLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strFila = REA.GetInt32("Anio") & "|"
                strFila &= REA.GetInt32("Num") & "|"
                strFila &= REA.GetDateTime("Fecha") & "|"
                strFila &= REA.GetString("Nombre") & "|"
                strFila &= REA.GetString("Requisa") & "|"
                If REA.GetInt32("Estado") = 1 Then
                    strFila &= "Activo"
                Else
                    strFila &= "Inactivo"
                End If
                If REA.GetInt32("Estado") = 1 Then
                    cfun.AgregarFila(dgLista, strFila)
                Else
                    cfun.AgregarFila(dgLista, strFila, Color.Red)
                End If



            Loop
        End If

    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("List Processing ")
            'Cargar Datos
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()

        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                'Reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub LimpiarPanelOrden()
        celdaAño.Text = cFunciones.AñoMySQL
        celdaNumero.Text = -1
        celdaTasa.Text = cFunciones.QueryTasa
        dtpFecha.Text = Now.ToString(FORMATO_MYSQL)
        celdaDireccion.Text = STR_VACIO
        celdaNombre.Text = STR_VACIO
        celdaidProveedor.Text = NO_FILA
        celdaNit.Text = STR_VACIO
        celdaIdMoneda.Text = cFunciones.DivisaExtranjera
        celdaMoneda.Text = cFunciones.TraerMoneda(celdaIdMoneda.Text)
        celdaTotal.Clear()
        celdaCantidad.Clear()
        celdaNumero.Text = NO_FILA
        dgDetalle.Rows.Clear()
        dgRequisa.Rows.Clear()
        checkActive.Checked = True
        checkDescuento.Checked = False
        celdaDescuento.Clear()


    End Sub

    Private Sub BorrarEncabezado(ByVal num As Integer, ByVal anio As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = catalogos
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDetalle(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = {cata} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", catalogos)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDTL_Pro(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = {cata} AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", catalogos)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT d.DDoc_Prd_Cod cod, d.DDoc_Prd_Des producto, ca.cat_num CodigoUM, IF(ca.cat_num = 0,'',ca.cat_clave) UM, d.DDoc_Doc_Lin Line, d.DDoc_Prd_PUQ Precio,d.DDoc_Prd_QTY Cantidad, 
                    d.DDoc_RF1_Num Estado, p.PDoc_Par_Cat Catalogo, p.PDoc_Par_Ano Anio, p.PDoc_Par_Num Num, p.PDoc_Par_Lin Linea, d.DDoc_RF1_Dbl Descuento, d.DDoc_RF2_Dbl Impuesto, d.DDoc_RF3_Dbl Calculo, d.DDoc_RF4_Dbl MontoDescuento
                    FROM Dcmtos_DTL d
						  LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano
						  and p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin         
                            LEFT JOIN Catalogos ca ON ca.cat_num = d.DDoc_Prd_UM
                            WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 736 AND d.DDoc_Doc_Ano = {anio} AND 
									 d.DDoc_Doc_Num = {num}"

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)


        Return strSQL
    End Function
    Private Function sqlDetalleNuevo(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Prd_Cod cod,d.DDoc_Prd_Des producto, d.DDoc_Doc_Lin linea, d.DDoc_Prd_QTY Cantidad
                    FROM Dcmtos_DTL d                    
                            WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} AND d.DDoc_RF3_Num = 1 "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)


        Return strSQL
    End Function
    Private Function sqlRequisas(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = "  SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Num, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Nombre
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL_Pro P ON P.PDoc_Par_Cat = h.HDoc_Doc_Cat AND P.PDoc_Par_Ano = h.HDoc_Doc_Ano AND P.PDoc_Par_Num = h.HDoc_Doc_Num
                    WHERE P.PDoc_Sis_Emp = {emp} AND P.PDoc_Chi_Cat = 736 AND P.PDoc_Chi_Ano = {anio} AND P.PDoc_Chi_Num = {num} 
                    GROUP BY Anio, Num"

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)


        Return strSQL
    End Function
    Private Function VerificarDatos() As Boolean
        Dim verificar As Boolean = True
        Dim intLineas As Integer = 0
        Try

            If celdaNombre.Text.Length < 5 Then
                verificar = False
                MsgBox("Please, select a provider", vbInformation, "Notice")
                celdaDireccion.Focus()
                Exit Function
            End If
            If celdaDireccion.Text.Length < 5 Then
                verificar = False
                MsgBox("Direction is Invalid", vbInformation, "Notice")
                celdaDireccion.Focus()
                Exit Function
            End If

            If checkDescuento.Checked = True Then
                If celdaDescuento.Text = STR_VACIO Then
                    verificar = False
                    MsgBox("Discount Amount invalid", vbInformation, "Notice")
                    Exit Function
                ElseIf celdaDescuento.Text <= 0 Then
                    verificar = False
                    MsgBox("Discount Amount invalid", vbInformation, "Notice")
                    Exit Function
                End If
            End If


            If dgDetalle.Rows.Count > 0 Then
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    If dgDetalle.Rows(i).Cells("colExtra").Value <> 2 Then
                        If dgDetalle.Rows(i).Cells("colCodigo").Value = 0 Then

                            verificar = False
                            MsgBox("Article code invalid", vbInformation, "Notice")
                            Exit Function

                        End If

                        If dgDetalle.Rows(i).Cells("colDescripcionArticulo").Value = STR_VACIO Then
                            verificar = False
                            MsgBox("Article is invalid", vbInformation, "Notice")
                            Exit Function
                        End If

                        If dgDetalle.Rows(i).Cells("colPrecio").Value <= 0 Then
                            verificar = False
                            MsgBox("Price is invalid", vbInformation, "Notice")
                            Exit Function
                        End If

                        If dgDetalle.Rows(i).Cells("colCantidad").Value <= 0 Then
                            verificar = False
                            MsgBox("Quantity is invalid", vbInformation, "Notice")
                            Exit Function
                        End If
                    End If

                Next
            Else
                MsgBox("invalid detail", vbInformation, "Notice")
                verificar = False
                Exit Function
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return verificar
    End Function
    Private Function GuardarEncabezado() As Boolean
        Dim hdr As New clsDcmtos_HDR
        Dim Correcto As Boolean = False
        Try
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 736
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_EMP_COD = celdaidProveedor.Text
            hdr.HDOC_EMP_NOM = celdaNombre.Text
            hdr.HDOC_EMP_DIR = celdaDireccion.Text
            hdr.HDOC_EMP_NIT = celdaNit.Text
            hdr.HDOC_DOC_TC = celdaTasa.Text
            hdr.HDOC_DOC_MON = celdaIdMoneda.Text
            hdr.HDOC_DR1_NUM = celdaCantidad.Text
            hdr.HDOC_DR1_DBL = celdaTotal.Text
            If celdaDescuento.Text <> STR_VACIO Then
                hdr.HDOC_RF1_DBL = celdaDescuento.Text
            End If

            If checkDescuento.Checked = True Then
                hdr.HDOC_RF2_DBL = 1
            Else
                hdr.HDOC_RF2_DBL = 0
            End If


            hdr.HDOC_DOC_STATUS = IIf(checkActive.Checked = True, 1, 0)

            hdr.CONEXION = strConexion
            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    Correcto = False
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 736, celdaAño.Text, celdaNumero.Text)
                    Correcto = True
                End If
            Else
                If hdr.Guardar() = False Then
                    Correcto = False
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 736, celdaAño.Text, celdaNumero.Text)
                    Correcto = True
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Correcto
    End Function

    Private Sub GuardarDetalle()
        Dim dtl As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                dtl.DDOC_DOC_ANO = celdaAño.Text
                dtl.DDOC_DOC_CAT = 736
                dtl.DDOC_DOC_NUM = celdaNumero.Text
                If dgDetalle.Rows(i).Cells("colLinea").Value = 0 Then
                    dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
                    dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                Else
                    dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                End If
                dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcionArticulo").Value
                dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colCodigoUM").Value
                If dgDetalle.Rows(i).Cells("colEstado").Value = "Approved" Then
                    dtl.DDOC_RF1_NUM = 1

                Else
                    dtl.DDOC_RF1_NUM = 0
                End If

                dtl.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colDescuento").Value
                dtl.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colImpuesto").Value
                dtl.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("colCalculo").Value
                dtl.DDOC_RF4_DBL = dgDetalle.Rows(i).Cells("colMontoDescuento").Value

                dtl.CONEXION = strConexion

                If Me.Tag = "Mod" Then
                    If dgDetalle.Rows(i).Cells("colExtra").Value = "0" Then
                        If dtl.Guardar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = "1" Then

                        If dtl.Actualizar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)

                        End If

                    ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = "2" Then
                        If dtl.Borrar = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not delete the detail", MsgBoxStyle.Critical)

                        End If
                    End If

                Else
                    If dgDetalle.Rows(i).Cells("colExtra").Value = "0" Then
                        If dtl.Guardar() = False Then
                            MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If

                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub GuardarRelacion()
        Dim pro As New clsDcmtos_DTL_Pro

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1


                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = dgDetalle.Rows(i).Cells("colCatalogoPro").Value
                pro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnioPro").Value
                pro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumeroPro").Value
                pro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaPro").Value
                pro.PDOC_CHI_CAT = catalogos
                pro.PDOC_CHI_ANO = celdaAño.Text
                pro.PDOC_CHI_NUM = celdaNumero.Text
                pro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                pro.PDOC_CLTE_COD = INT_CERO
                pro.PDOC_PROV_COD = celdaidProveedor.Text
                pro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                pro.PDOC_PRD_PNR = INT_CERO
                pro.PDOC_DR1_NUM = INT_CERO
                pro.PDOC_DR2_NUM = INT_CERO

                pro.CONEXION = strConexion
                If Me.Tag = "Mod" Then


                    If dgDetalle.Rows(i).Cells("colExtra").Value = "0" Then
                        If pro.Guardar() = False Then
                            MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        If pro.Actualizar() = False Then
                            MsgBox(pro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)

                        End If

                    End If
                Else
                    If pro.Guardar() = False Then
                        MsgBox(pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function LimpiarCampos()
        celdaNombre.ReadOnly = False
        celdaNumero.Text = NO_FILA
        celdaAño.Text = cFunciones.AñoMySQL
        dtpFecha.Text = Now.ToString(FORMATO_MYSQL)
        celdaNombre.Clear()
        dgDetalle.Rows.Clear()
        dgRequisa.Rows.Clear()
        checkActive.Checked = True
    End Function

    Private Function sqlEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Nom nombre, h.HDoc_Doc_Status status, 
                    h.HDoc_Emp_Cod Cod, h.HDoc_Emp_Dir Direccion, h.HDoc_Emp_Nit Nit, h.HDoc_Doc_Mon IdMoneda, h.HDoc_Doc_TC Tasa,  h.HDoc_DR1_Num Cantidad, h.HDoc_DR1_DBL Total,
                    c.cat_clave Moneda, h.HDoc_RF1_Dbl MontoDescuento, h.HDoc_RF2_Dbl Descuento
                    FROM Dcmtos_HDR h
                        LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon
                        WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 736 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{anio}", anio)
        strSQL = strSQL.Replace("{num}", num)


        Return strSQL
    End Function
    Private Sub CargarEncabezado(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlEncabezado(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaNumero.Text = REA.GetInt32("Numero")

                    celdaAño.Text = REA.GetInt32("anio")
                    dtpFecha.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    celdaNombre.Text = REA.GetString("nombre")
                    celdaidProveedor.Text = REA.GetInt32("Cod")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaNit.Text = REA.GetString("Nit")
                    celdaCantidad.Text = REA.GetDouble("Cantidad")
                    celdaTotal.Text = REA.GetDouble("Total")
                    celdaIdMoneda.Text = REA.GetInt32("IdMoneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaDescuento.Text = REA.GetDouble("MontoDescuento")
                    If REA.GetInt32("Descuento") = 1 Then
                        checkDescuento.Checked = True
                    Else
                        checkDescuento.Checked = False
                    End If
                    If REA.GetInt32("status") = 1 Then
                        checkActive.Checked = True
                    Else
                        checkActive.Checked = False
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalle(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim dblTotal As Double
        Dim Cantidad As Integer
        Dim Precio As Double

        Try


            strSQL = sqlDetalle(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                Do While REA.Read

                    strFila = REA.GetInt32("cod") & "|"
                    strFila &= REA.GetString("producto") & "|"
                    strFila &= REA.GetInt32("CodigoUM") & "|"
                    strFila &= REA.GetString("UM") & "|"
                    Cantidad = REA.GetInt32("Cantidad")
                    strFila &= Cantidad & "|"
                    Precio = REA.GetDouble("Precio")
                    strFila &= Precio.ToString(FORMATO_MONEDA) & "|"
                    dblTotal = Cantidad * Precio
                    strFila &= dblTotal.ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("MontoDescuento") & "|"
                    strFila &= REA.GetDouble("Descuento") & "|"
                    strFila &= REA.GetDouble("Impuesto") & "|"
                    If REA.GetInt32("Estado") = 1 Then
                        strFila &= "Approved" & "|"
                    Else
                        strFila &= "" & "|"
                    End If
                    strFila &= REA.GetInt32("Line") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Num") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= "1" & "|"
                    strFila &= REA.GetDouble("Calculo").ToString(FORMATO_MONEDA)
                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ContarCotizaciones(ByRef Numero As Integer, ByRef Anio As Integer) As Integer

        Try
            Dim strSQL As String = STR_VACIO
            Dim conec As New MySqlConnection
            Dim COM As MySqlCommand
            Dim Cantidad As Integer

            strSQL = " SELECT COUNT(*)
                    FROM Dcmtos_DTL d
                    INNER JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat
                    AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num 
						  AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin
                    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {Anio} AND d.DDoc_Doc_Num = {Numero} AND d.DDoc_RF3_Num = 1"
            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{Anio}", Anio)
            strSQL = strSQL.Replace("{Numero}", Numero)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Cantidad = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()



            Return Cantidad
        Catch ex As Exception

            MsgBox(ex.ToString)
            Return 0
        End Try


    End Function
    Private Function ContarArticulos(ByRef Numero As Integer, ByRef Anio As Integer) As Integer

        Try
            Dim strSQL As String = STR_VACIO
            Dim conec As New MySqlConnection
            Dim COM As MySqlCommand
            Dim Cantidad As Integer

            strSQL = " SELECT COUNT(*)
                    FROM Dcmtos_DTL d
                    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {Anio} AND d.DDoc_Doc_Num = {Numero} AND d.DDoc_RF3_Num = 1"
            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{Anio}", Anio)
            strSQL = strSQL.Replace("{Numero}", Numero)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Cantidad = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()



            Return Cantidad
        Catch ex As Exception

            MsgBox(ex.ToString)
            Return 0
        End Try


    End Function
    Private Sub CargarRequisas(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader



        Try


            strSQL = sqlRequisas(anio, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                Do While REA.Read
                    strFila = 734 & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Num") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Nombre")
                    ' If ContarCotizaciones(num, anio) <= ContarArticulos(num, anio) Then
                    cFunciones.AgregarFila(dgRequisa, strFila)
                    'End If


                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidarDependencias() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim Codigo As Integer

        strSQL = "  SELECT COUNT(p.PDoc_Chi_Num)  "
        strSQL &= " FROM Dcmtos_HDR h  "
        strSQL &= "     Left Join Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp And p.PDoc_Par_Cat = h.HDoc_Doc_Cat And p.PDoc_Par_Ano = h.HDoc_Doc_Ano And p.PDoc_Par_Num = h.HDoc_Doc_Num "
        strSQL &= "  WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {catalogo} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} And h.HDoc_Doc_Status = 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", catalogos)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        Codigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        'celdaID.Text = Codigo
        Return Codigo
    End Function

#End Region
#Region "Eventos"
    Private Sub frmCotizacionInsumos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFechaFinal.Value = Today.ToString(FORMATO_MYSQL)
        dtpFechaInicial.Value = dtpFechaInicial.Value.AddMonths(NO_FILA).ToString(FORMATO_MYSQL)
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then

            LimpiarPanelOrden()
            MostrarLista(False, True)
            Encabezado1.botonBorrar.Enabled = False

            botonAgregarRequisicion.Enabled = True
            Button1.Enabled = True
        Else
            MsgBox("No Posee permisos para esta acción", vbInformation)
        End If

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Try
            If LogBorrar = True Then
                If ValidarDependencias() > INT_CERO Then
                    MsgBox("You can not delete a document in the process", vbInformation, "Notice")
                Else
                    If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                        BorrarEncabezado(celdaNumero.Text, celdaAño.Text)
                        BorrarDetalle(celdaNumero.Text, celdaAño.Text)
                        BorrarDTL_Pro(celdaNumero.Text, celdaAño.Text)
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 736, celdaAño.Text, celdaNumero.Text)
                        MostrarLista()
                    End If
                End If

            Else
                    MsgBox("You do not have permission for this action", vbInformation, "Notice")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        End If
    End Sub

    Private Sub botonAgregarRequisicion_Click(sender As Object, e As EventArgs) Handles botonAgregarRequisicion.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strAgrupar As String = STR_VACIO


        strTabla = " Dcmtos_HDR h
                       LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"

        strCondicion = " h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 734 AND h.HDoc_Doc_Status = 1 AND d.DDoc_RF3_Num = 1"

        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        strCampos = " h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Requester"
        strAgrupar = "h.HDoc_Doc_Ano, h.HDoc_Doc_Num"

        Try
            frm.Titulo = "Requisitions"
            frm.Campos = strCampos
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            frm.FiltroText = " Select a Requisitions"
            frm.Filtro = " h.HDoc_Emp_Nom "
            frm.Agrupar = strAgrupar

            frm.ShowDialog(Me)

            If frm.DialogResult = DialogResult.OK Then
                strFila = 734 & "|"
                strFila &= frm.ListaClientes.SelectedCells(0).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"


                cFunciones.AgregarFila(dgRequisa, strFila)
                If Me.Tag = "Nuevo" Then
                    ' CargarDocumentosDetalle()
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If MsgBox("Are you sure to delete this items?", vbYesNo + vbQuestion) = vbNo Then
            Exit Sub
        End If
        Dim intRow As Integer =
               dgRequisa.CurrentCell.RowIndex


        If logEditar = True Then
            dgRequisa.Rows.RemoveAt(intRow)
        End If
    End Sub

    Private Sub dgRequisa_DoubleClick(sender As Object, e As EventArgs) Handles dgRequisa.DoubleClick
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strAgrupar As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        If dgRequisa.Rows.Count > 0 Then
            anioRequisa = dgRequisa.SelectedCells(1).Value
            numRequisa = dgRequisa.SelectedCells(2).Value
        End If




        Try


            strSQL = "SELECT d.DDoc_Prd_Cod cod,d.DDoc_Prd_Des producto, ca.cat_num CodigoUM, IF(ca.cat_num =0,'',ca.cat_clave) UM, d.DDoc_Doc_Lin linea, d.DDoc_Prd_QTY Cantidad, d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Num 
                       FROM Dcmtos_DTL d 
                        LEFT JOIN Catalogos ca ON ca.cat_num = d.DDoc_Prd_UM
                        WHERE  d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {anio}  
                      AND d.DDoc_Doc_Num = {num}  AND d.DDoc_RF3_Num = 1  "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anioRequisa)
            strSQL = Replace(strSQL, "{num}", numRequisa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                Do While REA.Read

                    strFila = REA.GetInt32("cod") & "|"
                    strFila &= REA.GetString("producto") & "|"
                    strFila &= REA.GetInt32("CodigoUM") & "|"
                    strFila &= REA.GetString("UM") & "|"
                    strFila &= REA.GetInt32("Cantidad") & "|"
                    strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                    strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                    strFila &= "0" & "|"
                    strFila &= "0" & "|"
                    strFila &= "15" & "|"
                    strFila &= "" & "|"
                    strFila &= "0" & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Num") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= "0"& "|"
                    strFila &= 0.ToString(FORMATO_MONEDA)

                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = " p.pro_sisemp = {empresa} and p.pro_status = 'Activo'  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Providers"
            frm.Campos = " p.pro_proveedor proveedor, p.pro_direccion direccion, p.pro_nit nit, p.pro_codigo codigo "
            frm.Tabla = " Proveedores p"
            frm.FiltroText = " Enter the provider to filter"
            frm.Filtro = "  p.pro_proveedor "
            frm.Limite = 30
            frm.Ordenamiento = " p.pro_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaidProveedor.Text = frm.Dato3
                celdaNombre.Text = frm.LLave
                celdaDireccion.Text = frm.Dato
                celdaNit.Text = frm.Dato2
                celdaMoneda.Text = "USD"
                celdaIdMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If MsgBox("Are you sure to delete this items?", vbYesNo + vbQuestion) = vbNo Then
            Exit Sub
        End If
        If dgDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        dgDetalle.CurrentRow.Cells("colExtra").Value = 2
        dgDetalle.CurrentRow.Visible = False
        calcularTotales()
    End Sub

    Private Sub botonAgrega_Click(sender As Object, e As EventArgs) Handles botonAgrega.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strAgrupar As String = STR_VACIO

        If dgRequisa.Rows.Count > 0 Then
            anioRequisa = dgRequisa.CurrentRow.Cells(1).Value
            numRequisa = dgRequisa.CurrentRow.Cells(2).Value
        End If




        strCampos = "d.DDoc_Prd_Cod cod,d.DDoc_Prd_Des producto, d.DDoc_Doc_Lin linea, d.DDoc_Prd_QTY Cantidad, d.DDoc_Doc_Cat Catalogo, d.DDoc_Doc_Ano Anio, d.DDoc_Doc_Num Num, ca.cat_num CodigoUM, IF(ca.cat_num = 0 ,'',ca.cat_clave) UM"

        strTabla = "Dcmtos_DTL d LEFT JOIN Catalogos ca ON ca.cat_num = d.DDoc_Prd_UM"

        strCondicion = " d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 734 AND d.DDoc_Doc_Ano = {anio}  
                      AND d.DDoc_Doc_Num = {num}  AND d.DDoc_RF3_Num = 1 "


        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{anio}", anioRequisa)
        strCondicion = Replace(strCondicion, "{num}", numRequisa)



        Try
            frm.Titulo = "Requisitions"
            frm.Campos = strCampos
            frm.Tabla = strTabla
            frm.Condicion = strCondicion
            frm.FiltroText = " Select a Requisitions"
            frm.Filtro = " d.DDoc_Prd_Des "

            frm.ShowDialog(Me)

            If frm.DialogResult = DialogResult.OK Then

                strFila &= frm.ListaClientes.SelectedCells(0).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(7).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(8).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                strFila &= 0.ToString(FORMATO_MONEDA) & "|"
                strFila &= "0" & "|"
                strFila &= "0" & "|"
                strFila &= "15" & "|"
                strFila &= "" & "|"
                strFila &= "0" & "|"
                strFila &= frm.ListaClientes.SelectedCells(4).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(5).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(6).Value & "|"
                strFila &= frm.ListaClientes.SelectedCells(2).Value & "|"
                strFila &= "0" & "|"
                strFila &= 0.ToString(FORMATO_MONEDA)


                cFunciones.AgregarFila(dgDetalle, strFila)

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub calcularTotales()
        Dim dblTotalLine As Double = 0
        Dim dblTotalDoc As Double = 0
        Dim dblTotalCantidad As Double = 0
        Dim dblCalculo As Double = 0
        Dim dblResta As Double = 0
        Dim dblImpuesto As Double = 0
        Dim dblDescuento As Double = 0
        Dim dblPorcentaje As Double = 0
        Dim dblPrecio As Double = 0


        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colExtra").Value <> 2 Then

                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                dblTotalLine = (dgDetalle.Rows(i).Cells("colPrecio").Value) * (dgDetalle.Rows(i).Cells("colCantidad").Value)
                If dblPrecio = 0 Then
                    dblPorcentaje = 0
                Else
                    dblPorcentaje = (dgDetalle.Rows(i).Cells("colMontoDescuento").Value / dblPrecio) * 100
                End If

                dblDescuento = (dblPrecio * dgDetalle.Rows(i).Cells("colDescuento").Value) / 100
                dblResta = dblPrecio - dblDescuento
                dblImpuesto = (dblResta * dgDetalle.Rows(i).Cells("colImpuesto").Value) / 100
                dblCalculo = dblResta + dblImpuesto
                dgDetalle.Rows(i).Cells("colTotal").Value = dblTotalLine.ToString(FORMATO_MONEDA)
                dgDetalle.Rows(i).Cells("colCalculo").Value = dblCalculo.ToString(FORMATO_MONEDA)

                dgDetalle.Rows(i).Cells("colDescuento").Value = dblPorcentaje
                dgDetalle.Rows(i).Cells("colMontoDescuento").Value = dblDescuento


                dblTotalDoc = dblTotalDoc + dgDetalle.Rows(i).Cells("colTotal").Value
                dblTotalCantidad = dblTotalCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value

            End If


        Next
        celdaCantidad.Text = dblTotalCantidad.ToString(FORMATO_MONEDA)
        celdaTotal.Text = dblTotalDoc.ToString(FORMATO_MONEDA)
    End Sub
    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit


        Dim dblTotalLine As Double = 0
        Dim dblTotalDoc As Double = 0
        Dim dblTotalCantidad As Double = 0
        Dim dblCalculo As Double = 0
        Dim dblResta As Double = 0
        Dim dblImpuesto As Double = 0
        Dim dblDescuento As Double = 0
        Dim dblPorcentaje As Double = 0
        Dim dblPrecio As Double = 0

        dblPrecio = dgDetalle.CurrentRow.Cells("colPrecio").Value
        dblTotalLine = dblPrecio * (dgDetalle.CurrentRow.Cells("colCantidad").Value)
        If dblPrecio = 0 Then
            dblPorcentaje = 0
        Else
            dblPorcentaje = (dgDetalle.CurrentRow.Cells("colMontoDescuento").Value / dblPrecio) * 100
        End If


        dblDescuento = (dblPrecio * dgDetalle.CurrentRow.Cells("colDescuento").Value) / 100
        dblResta = dblPrecio - dblDescuento
        dblImpuesto = (dblResta * dgDetalle.CurrentRow.Cells("colImpuesto").Value) / 100
        dblCalculo = dblResta + dblImpuesto
        dgDetalle.CurrentRow.Cells("colTotal").Value = dblTotalLine.ToString(FORMATO_MONEDA)
        dgDetalle.CurrentRow.Cells("colCalculo").Value = dblCalculo.ToString(FORMATO_MONEDA)


        If dgDetalle.CurrentCell.ColumnIndex = 7 Then
            dgDetalle.CurrentRow.Cells("colDescuento").Value = dblPorcentaje
        End If

        If dgDetalle.CurrentCell.ColumnIndex = 8 Then
            dgDetalle.CurrentRow.Cells("colMontoDescuento").Value = dblDescuento

        End If

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colExtra").Value <> 2 Then
                dblTotalDoc = dblTotalDoc + dgDetalle.Rows(i).Cells("colTotal").Value
                dblTotalCantidad = dblTotalCantidad + dgDetalle.Rows(i).Cells("colCantidad").Value
            End If


        Next
        celdaCantidad.Text = dblTotalCantidad.ToString(FORMATO_MONEDA)
        celdaTotal.Text = dblTotalDoc.ToString(FORMATO_MONEDA)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        If VerificarDatos() = True Then
            If celdaNumero.Text = NO_FILA Then
                celdaNumero.Text = cFunciones.NuevoId(catalogos)

            End If

            If GuardarEncabezado() = True Then
                GuardarDetalle()
                GuardarRelacion()
                MsgBox("Successfully Saved Document", vbInformation, "Notice")
                MostrarLista()


            End If
        End If
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim opt As New frmOption
        Dim intopt As Integer
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try

            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 10
                    If Me.Tag = "Mod" Then
                        If dgDetalle.CurrentRow.Cells("colEstado").Value = "Approved" Then
                            dgDetalle.CurrentRow.Cells("colEstado").Value = STR_VACIO
                        ElseIf dgDetalle.CurrentRow.Cells("colEstado").Value = STR_VACIO Then
                            dgDetalle.CurrentRow.Cells("colEstado").Value = "Approved"

                        Else
                            dgDetalle.CurrentRow.Cells("colEstado").Value = STR_VACIO
                        End If
                    End If

            End Select

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim año As Integer
        Dim numero As Integer
        Me.Tag = "Mod"
        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        MostrarLista(False)
        año = dgLista.SelectedCells(0).Value
        numero = dgLista.SelectedCells(1).Value
        LimpiarCampos()
        CargarEncabezado(año, numero)
        CargarDetalle(año, numero)
        CargarRequisas(año, numero)
        'botonAgregar.Enabled = False
        ' botonEliminar.Enabled = False
        celdaNombre.ReadOnly = True

        If checkDescuento.Checked = False Then
            celdaDescuento.Clear()
            celdaDescuento.Enabled = False
            For i As Integer = 0 To dgDetalle.Rows.Count - 1


                dgDetalle.Rows(i).Cells("colMontoDescuento").ReadOnly = False
                dgDetalle.Rows(i).Cells("colDescuento").ReadOnly = False


            Next
        Else
            celdaDescuento.Enabled = True
            'celdaDescuento.Text = "0"
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                dgDetalle.Rows(i).Cells("colMontoDescuento").Value = "0"
                dgDetalle.Rows(i).Cells("colDescuento").Value = "0"
                dgDetalle.Rows(i).Cells("colMontoDescuento").ReadOnly = True
                dgDetalle.Rows(i).Cells("colDescuento").ReadOnly = True


            Next

        End If


    End Sub

    Private Sub BotonMoneda_Click(sender As Object, e As EventArgs) Handles BotonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdMoneda.Text = frm.Dato
                celdaMoneda.Text = frm.LLave
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

    Private Sub checkDescuento_CheckedChanged(sender As Object, e As EventArgs) Handles checkDescuento.CheckedChanged
        If checkDescuento.Checked = False Then
            celdaDescuento.Clear()
            celdaDescuento.Enabled = False
            For i As Integer = 0 To dgDetalle.Rows.Count - 1


                dgDetalle.Rows(i).Cells("colMontoDescuento").ReadOnly = False
                dgDetalle.Rows(i).Cells("colDescuento").ReadOnly = False


            Next
        Else
            celdaDescuento.Enabled = True
            celdaDescuento.Text = "0"
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                dgDetalle.Rows(i).Cells("colMontoDescuento").Value = "0"
                dgDetalle.Rows(i).Cells("colDescuento").Value = "0"
                dgDetalle.Rows(i).Cells("colMontoDescuento").ReadOnly = True
                dgDetalle.Rows(i).Cells("colDescuento").ReadOnly = True


            Next

        End If
    End Sub

#End Region

End Class