﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLibroComprasgt
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonBorrar = New System.Windows.Forms.Button()
        Me.botonLiberar = New System.Windows.Forms.Button()
        Me.botonBloquear = New System.Windows.Forms.Button()
        Me.PanelAbajo = New System.Windows.Forms.Panel()
        Me.botonNuevo = New System.Windows.Forms.Button()
        Me.BotonSalir = New System.Windows.Forms.Button()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colIdAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelEncabezado.SuspendLayout()
        Me.PanelAbajo.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.Button1)
        Me.PanelEncabezado.Controls.Add(Me.botonBorrar)
        Me.PanelEncabezado.Controls.Add(Me.botonLiberar)
        Me.PanelEncabezado.Controls.Add(Me.botonBloquear)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(522, 73)
        Me.PanelEncabezado.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.Button1.Location = New System.Drawing.Point(196, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 61)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Print"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = True
        '
        'botonBorrar
        '
        Me.botonBorrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonBorrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonBorrar.Location = New System.Drawing.Point(435, 6)
        Me.botonBorrar.Name = "botonBorrar"
        Me.botonBorrar.Size = New System.Drawing.Size(75, 61)
        Me.botonBorrar.TabIndex = 2
        Me.botonBorrar.Text = "Close"
        Me.botonBorrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBorrar.UseVisualStyleBackColor = True
        '
        'botonLiberar
        '
        Me.botonLiberar.Image = Global.KARIMs_SGI.My.Resources.Resources.lock_open
        Me.botonLiberar.Location = New System.Drawing.Point(101, 6)
        Me.botonLiberar.Name = "botonLiberar"
        Me.botonLiberar.Size = New System.Drawing.Size(75, 61)
        Me.botonLiberar.TabIndex = 1
        Me.botonLiberar.Text = "Unlock"
        Me.botonLiberar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonLiberar.UseVisualStyleBackColor = True
        '
        'botonBloquear
        '
        Me.botonBloquear.Image = Global.KARIMs_SGI.My.Resources.Resources.lock_new
        Me.botonBloquear.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonBloquear.Location = New System.Drawing.Point(12, 6)
        Me.botonBloquear.Name = "botonBloquear"
        Me.botonBloquear.Size = New System.Drawing.Size(75, 61)
        Me.botonBloquear.TabIndex = 0
        Me.botonBloquear.Text = "Lock"
        Me.botonBloquear.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonBloquear.UseVisualStyleBackColor = True
        '
        'PanelAbajo
        '
        Me.PanelAbajo.Controls.Add(Me.botonNuevo)
        Me.PanelAbajo.Controls.Add(Me.BotonSalir)
        Me.PanelAbajo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelAbajo.Location = New System.Drawing.Point(0, 259)
        Me.PanelAbajo.Name = "PanelAbajo"
        Me.PanelAbajo.Size = New System.Drawing.Size(522, 58)
        Me.PanelAbajo.TabIndex = 1
        '
        'botonNuevo
        '
        Me.botonNuevo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonNuevo.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonNuevo.Location = New System.Drawing.Point(321, 6)
        Me.botonNuevo.Name = "botonNuevo"
        Me.botonNuevo.Size = New System.Drawing.Size(75, 49)
        Me.botonNuevo.TabIndex = 1
        Me.botonNuevo.Text = "New"
        Me.botonNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonNuevo.UseVisualStyleBackColor = True
        '
        'BotonSalir
        '
        Me.BotonSalir.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.BotonSalir.Image = Global.KARIMs_SGI.My.Resources.Resources.cancel
        Me.BotonSalir.Location = New System.Drawing.Point(424, 6)
        Me.BotonSalir.Name = "BotonSalir"
        Me.BotonSalir.Size = New System.Drawing.Size(75, 49)
        Me.BotonSalir.TabIndex = 0
        Me.BotonSalir.Text = "Cancel"
        Me.BotonSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonSalir.UseVisualStyleBackColor = True
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdAno, Me.colIdNumero, Me.colMes, Me.colEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 73)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(522, 186)
        Me.dgLista.TabIndex = 2
        '
        'colIdAno
        '
        Me.colIdAno.HeaderText = "Year"
        Me.colIdAno.Name = "colIdAno"
        Me.colIdAno.ReadOnly = True
        '
        'colIdNumero
        '
        Me.colIdNumero.HeaderText = "Numero"
        Me.colIdNumero.Name = "colIdNumero"
        Me.colIdNumero.ReadOnly = True
        '
        'colMes
        '
        Me.colMes.HeaderText = "Month"
        Me.colMes.Name = "colMes"
        Me.colMes.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        '
        'frmLibroComprasgt
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 317)
        Me.Controls.Add(Me.dgLista)
        Me.Controls.Add(Me.PanelEncabezado)
        Me.Controls.Add(Me.PanelAbajo)
        Me.Name = "frmLibroComprasgt"
        Me.Text = "frmLibroComprasgt"
        Me.PanelEncabezado.ResumeLayout(False)
        Me.PanelAbajo.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents botonBorrar As System.Windows.Forms.Button
    Friend WithEvents botonLiberar As System.Windows.Forms.Button
    Friend WithEvents botonBloquear As System.Windows.Forms.Button
    Friend WithEvents PanelAbajo As System.Windows.Forms.Panel
    Friend WithEvents botonNuevo As System.Windows.Forms.Button
    Friend WithEvents BotonSalir As System.Windows.Forms.Button
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents colIdAno As DataGridViewTextBoxColumn
    Friend WithEvents colIdNumero As DataGridViewTextBoxColumn
    Friend WithEvents colMes As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
End Class
