﻿Imports System.IO.Ports
Imports System.Threading
Imports KARIMs_SGI.Tablas

Public Class frmCajasPT


#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim logConsultar As Boolean = False
    Const cat_num As Integer = 776
    Dim cfun As New clsFunciones
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim varNumeroIngreso As Integer = INT_CERO
    Dim varIngresoModificable As Integer = INT_CERO

    Dim clienteDatos(5) As String
    Dim ProveedorDatos(5) As String

    Dim vIngresoAno, vIngresoNumero, vPolizaAno, vPolizaNumero As String

    Dim hora_actual, hora_inicio, hora_Inicio_P, hora_fin As DateTime



    ' Dim frmP As Form = frmSPrincipal

    'Dim NotaDev As String
    'Dim VerOpcion As Integer

    Private serialReader As clsFunciones.SerialPortReader
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Function Puerto_Numero()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = "SELECT cat_desc"
        strSQL &= "      FROM Catalogos c"
        strSQL &= "          WHERE cat_clase='clasePesa' and cat_clave='puerto' and cat_sisemp={empresa} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function
    Private Function Puerto_Velocidad()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = "SELECT cat_desc"
        strSQL &= "      FROM Catalogos c"
        strSQL &= "          WHERE cat_clase='clasePesa' and cat_clave='velocidad' and cat_sisemp={empresa} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function
    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT
	                    h.HDoc_Sis_Emp Empresa, 
                        h.HDoc_Doc_Cat Catalogo, 
                        h.HDoc_Doc_Ano Anio, 
	                    h.HDoc_Doc_Num Numero, 
                        h.HDoc_Doc_Fec fecha, 
                        h.HDoc_DR1_Num Referencia, 
	                    (SELECT hh.HDoc_DR1_Num Reference
                            FROM  Dcmtos_HDR hh 
                            WHERE hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) po,
	                    h.HDoc_Doc_Status estatus, 
                        IFNULL(p.PDoc_Par_Num,0) LoteId
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL_Pro p
	                    ON p.PDoc_Sis_Emp=h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat=h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano=h.HDoc_Doc_Ano AND p.PDoc_Chi_Num=h.HDoc_Doc_Num
                    LEFT JOIN Dcmtos_HDR	hh 
	                    ON hh.HDoc_Sis_Emp=p.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat=p.PDoc_Par_Cat AND hh.HDoc_Doc_Ano=p.PDoc_Par_Ano AND hh.HDoc_Doc_Num=p.PDoc_Par_Num 
                    WHERE h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = 776 "

        If checkFecha.Checked = True Then

            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If
        strSQL &= "             GROUP BY h.HDoc_Sis_Emp , h.HDoc_Doc_Cat, h.HDoc_Doc_Ano , h.HDoc_Doc_Num  "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        ' strSQL = Replace(strSQL, "{NumProceso}", NumProceso)

        Return strSQL
    End Function
    Private Function NuevoCorrelativo()
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = "SELECT IFNULL(MAX(CAST(d.DDoc_RF1_Cod AS SIGNED)), 0)+1 Linea"
        strSQL &= "      FROM Dcmtos_DTL d"
        strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} and d.DDoc_Doc_Num={numlote}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 737)
        strSQL = Replace(strSQL, "{anio}", celdaAnoLote.Text)
        strSQL = Replace(strSQL, "{numlote}", celdaIdLote.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function
    Public Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("PO") & "|"
                    strFila &= REA.GetInt16("loteId")

                    If REA.GetInt32("estatus") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Function primeraLineaPO(ano As Integer, numero As Integer) As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT IFNULL(MIN(d.DDoc_Doc_Lin ),0) FROM Dcmtos_DTL d "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = 980 And d.DDoc_Doc_Ano = {ano} And d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        If intLInea = 0 Then
            Return False
        Else
            Return intLInea
        End If

    End Function
    Private Function primeraLinea47(ByVal año As Integer, ByVal numero As Integer) As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " Select IFNULL(MAX(d.DDoc_Doc_Lin ),1) FROM Dcmtos_DTL d "
            strSQL &= " WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = 47 And d.DDoc_Doc_Ano = {ano} And d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        If intLInea = 0 Then
            Return False
        Else
            Return intLInea
        End If

    End Function
    Private Function IngresoModificable(ano As Integer, numero As Integer, lote As Integer, loteaño As Integer, fecha As Date)
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        strSQL = "Select IFNULL(MAX(chi_ing.PDoc_Chi_Num),0)
                    FROM Dcmtos_DTL_Pro chi_caja 
                    LEFT JOIN Dcmtos_DTL_Pro chi_ing ON chi_ing.PDoc_Sis_Emp=chi_caja.PDoc_Sis_Emp AND chi_ing.PDoc_Par_Cat=chi_caja.PDoc_Chi_Cat AND chi_ing.PDoc_Par_Ano=chi_caja.PDoc_Chi_Ano 
                        AND chi_ing.PDoc_Par_Num=chi_caja.PDoc_Chi_Num AND chi_ing.PDoc_Par_Lin=chi_caja.PDoc_Chi_Lin
                    LEFT JOIN Dcmtos_HDR h_ing ON h_ing.HDoc_Sis_Emp=chi_ing.PDoc_Sis_Emp AND h_ing.HDoc_Doc_Cat=chi_ing.PDoc_Chi_Cat AND h_ing.HDoc_Doc_Ano=chi_ing.PDoc_Chi_Ano AND h_ing.HDoc_Doc_Num=chi_ing.PDoc_Chi_Num
                    WHERE chi_caja.PDoc_Sis_Emp={empresa} AND chi_caja.PDoc_Chi_Cat=776 AND chi_caja.PDoc_Chi_Ano={ano} AND chi_caja.PDoc_Chi_Num={numero} AND HDoc_Doc_Fec='{fecha}' 
                        AND chi_caja.PDoc_Par_Cat=737 AND chi_caja.PDoc_Par_Ano={loteaño} and  chi_caja.PDoc_Par_Num={lote}  AND h_ing.HDOC_RF2_DBL=1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ano}", ano)
        strSQL = Replace(strSQL, "{numero}", numero)
        strSQL = Replace(strSQL, "{lote}", lote)
        strSQL = Replace(strSQL, "{loteaño}", loteaño)
        strSQL = Replace(strSQL, "{fecha}", fecha.ToString(FORMATO_MYSQL))

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            Return COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
    End Function
    Private Function NuevaLinea() As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select ifnull(max(d.DDoc_Doc_Lin ),0)+1 DDoc_Doc_Lin from Dcmtos_DTL d "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 737 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", celdaAnoLote.Text)
            strSQL = Replace(strSQL, "{numero}", celdaIdLote.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Function NuevaLineaIngreso(ano As Integer, numero As Integer) As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select ifnull(max(d.DDoc_Doc_Lin),0)+1 DDoc_Doc_Lin from Dcmtos_DTL d "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 47 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Function NuevaLineaIngresoCaja(ano As Integer, numero As Integer) As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "SELECT IFNULL(MAX(BDoc_Box_Lin),0)+1 lineaBox FROM Dcmtos_DTL_Box d "
            strSQL &= " WHERE d.BDoc_Sis_Emp =  {empresa} AND d.BDoc_Doc_Cat = 47 AND d.BDoc_Doc_Ano =  {ano} AND d.BDoc_Doc_Num = {numero}  AND d.BDoc_Doc_Lin = 1"
            'strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 47 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Function pesoIngreso(ano As Integer, numero As Integer) As Double
        Dim intLInea As Double = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select ROUND(IFNULL(DDoc_RF4_Dbl,0),2) from Dcmtos_DTL d "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 47 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            panelDocumento.Visible = False
            panelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Cajas Producto Terminado")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

            ListaPrincipal()

        Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            panelDocumento.Visible = True
            panelDocumento.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '      LimpiarCampos()
                'CargarCostos()
                '        ColocaMoneda()
            End If

        End If

    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub datosCliente()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim int_InvNum As Integer = 0

        Try
            strSQL = "SELECT cli_codigo codigo, cli_cliente nombre, cli_direccion direccion, cli_nit nit, cli_telefono telefono, e.emp_moneda moneda
                    FROM Clientes cli
                    LEFT JOIN Catalogos c ON cli.cli_codigo=c.cat_pid AND c.cat_clase='empresa' AND c.cat_clave='cliente' 
                    LEFT JOIN Empresas e ON e.emp_no=cli.cli_sisemp
                    WHERE c.cat_sisemp=" & Sesion.IdEmpresa & ";"
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read
                clienteDatos(0) = REA.GetInt32("codigo").ToString
                clienteDatos(1) = REA.GetString("nombre").ToString
                clienteDatos(2) = REA.GetString("direccion").ToString
                clienteDatos(3) = REA.GetString("nit").ToString
                clienteDatos(4) = REA.GetString("telefono").ToString
                clienteDatos(5) = REA.GetInt32("moneda").ToString
            Loop

            strSQL = STR_VACIO
            COM.Dispose()
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub datosProveedor()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim int_InvNum As Integer = 0

        Try
            strSQL = "SELECT pro.pro_codigo codigo, pro.pro_proveedor nombre, pro.pro_direccion direccion, pro.pro_nit nit, pro.pro_telefono telefono, pro.pro_moneda moneda
                  FROM Proveedores pro
                  LEFT JOIN Catalogos c ON pro.pro_codigo=c.cat_pid AND c.cat_clase='empresa' AND c.cat_clave='Proveedor' 
                  WHERE c.cat_sisemp=" & Sesion.IdEmpresa & ";"
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read
                ProveedorDatos(0) = REA.GetInt32("codigo").ToString
                ProveedorDatos(1) = REA.GetString("nombre").ToString
                ProveedorDatos(2) = REA.GetString("direccion").ToString
                ProveedorDatos(3) = REA.GetString("nit").ToString
                ProveedorDatos(4) = REA.GetString("telefono").ToString
                ProveedorDatos(5) = REA.GetInt32("moneda").ToString
            Loop

            strSQL = STR_VACIO
            COM.Dispose()
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarEncabezado() As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim logResultado As Boolean = True
        Try


            '' encabezado de ingreso a bodega int_tipo=2

            Dim frmingreso As New frmIngresoBodega
            Dim fechaIngreso As Date

            'If My.Computer.Clock.ToString < hora_inicio Then

            If (hora_actual.ToLongTimeString < hora_Inicio_P.ToLongTimeString) Then
                varIngresoModificable = IngresoModificable(celdaAnio.Text, celdaNumero.Text, celdaIdLote.Text, celdaAnoLote.Text, DateAdd(DateInterval.Day, -1, Now()))
                fechaIngreso = DateAdd(DateInterval.Day, -1, Now())
            Else
                varIngresoModificable = IngresoModificable(celdaAnio.Text, celdaNumero.Text, celdaIdLote.Text, celdaAnoLote.Text, Now().ToString(FORMATO_MYSQL))
                fechaIngreso = Now()
            End If

            If varIngresoModificable = 0 Or frmingreso.pressPOWE(varIngresoModificable, celdaAnio.Text) = 0 Then
                varNumeroIngreso = frmingreso.NuevoIngreso(celdaAnio.Text)
            Else
                varNumeroIngreso = varIngresoModificable
            End If

            CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            CHDR.HDOC_DOC_CAT = 47
            CHDR.HDOC_DOC_ANO = celdaAnio.Text
            CHDR.HDOC_DOC_NUM = varNumeroIngreso
            CHDR.HDOC_DOC_TC = cfun.TasaSegunFecha(fechaIngreso.ToString(FORMATO_MYSQL))
            'datosCliente() ''
            datosProveedor() ''
            '' segun el cliente en catalogos cat_clase='empresa' and cat_clave='cliente' and cat_sisemp= sesion.idempresa

            CHDR.HDOC_EMP_COD = ProveedorDatos(0)
            CHDR.HDOC_EMP_NOM = ProveedorDatos(1)
            CHDR.HDOC_EMP_DIR = ProveedorDatos(2)
            CHDR.HDOC_EMP_NIT = ProveedorDatos(3)
            CHDR.HDOC_EMP_TEL = ProveedorDatos(4)
            CHDR.HDOC_DOC_MON = cfun.DivisaExtranjera()
            CHDR.HDOC_DR1_NUM = celdaNumeroLote.Text

            CHDR.HDOC_PRO_DCAT = 0      ' celda revisado
            CHDR.HDOC_DR2_CAT = 0       ' check ingreso
            CHDR.HDOC_DR1_CAT = 2       ' int_tipo
            CHDR.HDOC_RF1_DBL = 0       ' check tendido
            CHDR.HDOC_RF2_TXT = celdaColorCono.Text ' "Ingreso cajas producto terminado: " & varNumeroIngreso
            CHDR.HDOC_USUARIO = Sesion.Usuario
            CHDR.HDOC_ANT_COM = 0
            CHDR.HDOC_RF3_DBL = 0       ' check muestra
            CHDR.HDOC_RF2_DBL = 1       ' press POWE

            If varIngresoModificable > 0 Then
                If logEditar = True Then
                    'If CHDR.Actualizar() = False Then
                    '    MsgBox(CHDR.MERROR.ToString & "could not update the document", MsgBoxStyle.Critical)
                    'End If
                Else
                    MsgBox("you do not have access to save a new revenue from goods to warehouse", vbInformation)
                End If
            Else
                If logInsertar = True Then
                    'Se manda fecha para ingreso.
                    CHDR.HDoc_Doc_Fec_NET = fechaIngreso.ToString(FORMATO_MYSQL)
                    If CHDR.Guardar() = False Then
                        MsgBox(CHDR.MERROR.ToString & "could not save the document", MsgBoxStyle.Critical)
                    Else
                        cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text) ''cajas
                    End If
                Else
                    MsgBox("you do not have access to save a new revenue from goods to warehouse", vbInformation)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function GuardarEncabezadoCaja() As Boolean
        Dim CHDR As New clsDcmtos_HDR
        Dim logResultado As Boolean = True

        '' encabezado de cajas
        CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
        CHDR.HDOC_DOC_CAT = 776     '' cajas 776
        CHDR.HDOC_DOC_ANO = celdaAnio.Text
        CHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
        CHDR.HDOC_DR1_CAT = celdaIdColorCono.Text
        CHDR.HDOC_DR1_DBL = celdaTara.Text
        CHDR.HDOC_DR1_EMP = celdaIdColorEtiqueta.Text
        CHDR.HDOC_DR2_CAT = celdaIdFrame.Text
        CHDR.HDOC_RF2_DBL = celdaRollosCaja.Text
        CHDR.HDOC_RF2_NUM = celdaCorrelativo.Text
        CHDR.HDOC_DR2_EMP = celdaIdEmpacador.Text
        CHDR.HDOC_RF1_NUM = celdaIdTipoLote.Text
        CHDR.HDOC_EMP_COD = celdaIdProducto.Text
        CHDR.HDOC_RF1_TXT = celdaIdTurno.Text
        CHDR.HDOC_DR2_NUM = celdaIdEmbalaje.Text    'ID TIPO EMBAJALE - TABLA: CATALOGO_LOTES, clave Embajale

        ''lote 737
        CHDR.HDOC_RF2_COD = celdaAnoLote.Text
        CHDR.HDOC_DR1_NUM = celdaNumeroLote.Text
        CHDR.HDOC_RF2_TXT = celdaIdLote.Text

        ''PO 980
        CHDR.HDOC_RF1_DBL = celdaIdPO.Text
        CHDR.HDOC_RF3_DBL = celdaidAnoPO.Text


        CHDR.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)
        CHDR.CONEXION = strConexion
        If Me.Tag = "Nuevo" Then
            'celdaNumero.Text = cFunciones.NuevoId(cat_num)
            'CHDR.HDOC_DOC_NUM = celdaNumero.Text
            'If CHDR.Guardar = False Then
            '    logResultado = False
            '    MsgBox(CHDR.MERROR.ToString)
            'Else
            '    logResultado = True
            '    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text) ''cajas
            'End If
        Else
            CHDR.HDOC_DOC_NUM = celdaNumero.Text
            If CHDR.Actualizar = False Then
                logResultado = False
                MsgBox(CHDR.MERROR.ToString)
            Else
                logResultado = True
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text) ''cajas
            End If
        End If
    End Function
    Private Sub GuardarDetallePorLinea()
        Dim clDTL As New clsDcmtos_DTL  ' lotes
        Dim ciDTL As New clsDcmtos_DTL  ' ingreso
        Dim ccDTL As New clsDcmtos_DTL  ' cajas
        Dim cdBox As New TDCMTOS_DTL_BOX  ' cajas
        Dim varIngreso As Integer = 0
        Dim pro As New clsDcmtos_DTL_Pro
        Dim clsConta As New clsContabilidad
        Dim intLinea As Integer
        Try
            intLinea = dgDetalle.RowCount - 1
            'detalle de cajas 
            ccDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            ccDTL.DDOC_DOC_CAT = cat_num '776 cajas
            ccDTL.DDOC_DOC_ANO = celdaAnio.Text
            ccDTL.DDOC_DOC_NUM = celdaNumero.Text
            ccDTL.DDOC_RF1_TXT = dgDetalle.Rows(intLinea).Cells("col_numLote").Value
            ccDTL.DDoc_RF1_Fec_NET = Now().ToString(FORMATO_MYSQL) 'dgDetalle.Rows(intLinea).Cells("col_fecha").Value -- FECHA ACTUAL
            ccDTL.DDOC_RF1_COD = dgDetalle.Rows(intLinea).Cells("col_correlativo").Value
            ccDTL.DDOC_PRD_QTY = dgDetalle.Rows(intLinea).Cells("col_PesoNeto").Value
            ccDTL.DDOC_PRD_DSP = dgDetalle.Rows(intLinea).Cells("col_tara").Value
            ' ccDTL.DDOC_PRD_COD = dgDetalle.Rows(intLinea).Cells("col_PesoBruto").Value
            ccDTL.DDOC_RF4_COD = celdaIdTurno.Text
            ccDTL.DDOC_RF4_DBL = celdaIdColorCono.Text
            ccDTL.DDOC_RF2_TXT = hora_actual            '' hora de guardado de la caja
            ccDTL.DDOC_RF2_NUM = celdaIdEmpacador.Text            '' empacador que guarda la caja
            ccDTL.DDOC_RF2_DBL = celdaRollosCaja.Text
            ccDTL.DDOC_RF3_TXT = celdaIdFrame.Text
            ccDTL.DDOC_RF2_COD = celdaIdEmbalaje.Text

            '=================================== FECHA PRODUCCION =============
            Dim fechaActual As DateTime = Now()
            Dim horaCorte As Integer = hora_Inicio_P.Hour
            ' La hora de corte para iniciar el día de producción (06:00 hrs)
            Dim fechaProduccion As DateTime

            ' Verificamos si la hora actual es antes de las 06:00, si es así, la fecha de producción es el día anterior.
            If fechaActual.Hour < horaCorte Then
                ' Si la hora actual es antes de las 06:00, usamos la fecha del día anterior a las 06:00
                fechaProduccion = New DateTime(fechaActual.Year, fechaActual.Month, fechaActual.Day, horaCorte, 0, 0).AddDays(-1)
            Else
                ' Si la hora actual es después de las 06:00, usamos la fecha de hoy a las 06:00
                fechaProduccion = New DateTime(fechaActual.Year, fechaActual.Month, fechaActual.Day, horaCorte, 0, 0)
            End If

            ' Guardamos la fecha de producción (solo la parte de la fecha sin la hora)
            ccDTL.DDOC_RF4_TXT = fechaProduccion.ToString("yyyy-MM-dd")
            '================================================


            If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then             ' INSERTAR
                'dgDetalle.CurrentRow.Cells("colLinea").Value = NuevaLinea()
                ccDTL.DDOC_DOC_LIN = dgDetalle.Rows(intLinea).Cells("col_linea").Value
                ccDTL.CONEXION = strConexion
                If ccDTL.Guardar = False Then
                    MsgBox(ccDTL.MERROR.ToString)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 1 Then ' ACTUALIZAR
                ccDTL.DDOC_DOC_LIN = dgDetalle.Rows(intLinea).Cells("col_linea").Value
                ccDTL.CONEXION = strConexion
                If ccDTL.Actualizar = False Then
                    MsgBox(ccDTL.MERROR.ToString)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then ' Borrar
                ccDTL.DDOC_DOC_LIN = dgDetalle.Rows(intLinea).Cells("col_linea").Value
                ccDTL.CONEXION = strConexion
                If ccDTL.Borrar = False Then                                      ' BORRAR
                    MsgBox(ccDTL.MERROR.ToString)
                End If
            End If


            ' detalle de lotes
            clDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            clDTL.DDOC_DOC_CAT = 737                 'lotes
            clDTL.DDOC_DOC_ANO = celdaAnoLote.Text
            clDTL.DDOC_DOC_NUM = celdaIdLote.Text
            clDTL.DDOC_RF1_TXT = dgDetalle.Rows(intLinea).Cells("col_numLote").Value
            clDTL.DDoc_RF1_Fec_NET = Now().ToString(FORMATO_MYSQL) 'dgDetalle.Rows(intLinea).Cells("col_fecha").Value
            clDTL.DDOC_RF1_COD = dgDetalle.Rows(intLinea).Cells("col_correlativo").Value
            clDTL.DDOC_PRD_QTY = dgDetalle.Rows(intLinea).Cells("col_PesoNeto").Value
            clDTL.DDOC_PRD_DSP = dgDetalle.Rows(intLinea).Cells("col_tara").Value
            clDTL.DDOC_PRD_COD = dgDetalle.Rows(intLinea).Cells("col_PesoBruto").Value

            'TODO ID MEDIDA
            If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then             ' INSERTAR
                'clDTL.DDOC_DOC_LIN = NuevaLinea()
                clDTL.DDOC_DOC_LIN = dgDetalle.Rows(intLinea).Cells("col_linea").Value
                clDTL.CONEXION = strConexion
                If clDTL.Guardar = False Then
                    MsgBox(clDTL.MERROR.ToString)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then ' Borrar
                clDTL.DDOC_DOC_LIN = dgDetalle.Rows(intLinea).Cells("col_lineaLote").Value
                clDTL.CONEXION = strConexion
                If clDTL.Borrar = False Then                                      ' BORRAR
                    MsgBox(clDTL.MERROR.ToString)
                End If
            End If

            If dgDetalle.Rows(intLinea).Cells("col_numingreso").Value = 0 Then
                dgDetalle.Rows(intLinea).Cells("col_numingreso").Value = varNumeroIngreso
            End If



            'detalle Ingreso Box
            cdBox.BDOC_SIS_EMP = Sesion.IdEmpresa
            cdBox.BDOC_DOC_CAT = 47                 'ingreso
            cdBox.BDOC_DOC_ANO = celdaAnio.Text
            cdBox.BDOC_DOC_NUM = dgDetalle.Rows(intLinea).Cells("col_numIngreso").Value
            cdBox.BDOC_DOC_LIN = 1
            cdBox.BDOC_BOX_HSM = dgDetalle.Rows(intLinea).Cells("col_correlativo").Value 'Correlativo HSM
            cdBox.BDOC_BOX_CTG = "" ' categoria
            cdBox.BDOC_BOX_COD = "" 'Marca
            cdBox.BDOC_BOX_ORD = dgDetalle.Rows(intLinea).Cells("col_tara").Value ' tara
            cdBox.BDOC_BOX_QTY = 1
            cdBox.BDOC_BOX_LB = dgDetalle.Rows(intLinea).Cells("col_PesoNeto").Value 'peso de packing
            cdBox.BDOC_BOX_LBEXT = dgDetalle.Rows(intLinea).Cells("col_PesoBruto").Value ' Peso HSM 
            cdBox.BDOC_BOX_GIN = "" ' Gin
            cdBox.BDOC_BOX_GBAC = "" ' Gin Bac
            cdBox.BDOC_BOX_CRP = "" ' Crp
            cdBox.BDOC_BOX_REF = "" ' Referencia
            cdBox.BDOC_BOX_REF1 = "" ' Referencia
            cdBox.BDOC_BOX_REF2 = "" ' Referencia
            'cdBox.BDOC_DOC_LIN = 1 ' ciDTL.DDOC_DOC_LIN     '' se guarda como 1 ya que el ingreso unicamente tiene una linea
            'ciDTL.DDOC_DOC_LIN

            'TODO ID MEDIDA
            If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then             ' INSERTAR
                'cdBox.BDOC_BOX_LIN = NuevaLineaIngresoCaja(cdBox.BDOC_DOC_ANO, cdBox.BDOC_DOC_NUM)
                cdBox.BDOC_BOX_LIN = dgDetalle.Rows(intLinea).Cells("col_linea").Value
                cdBox.CONEXION = strConexion
                If cdBox.PINSERT = False Then
                    MsgBox(cdBox.MERROR.ToString)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 1 Then ' ACTUALIZAR
                cdBox.BDOC_BOX_LIN = dgDetalle.Rows(intLinea).Cells("col_lineabox").Value
                cdBox.CONEXION = strConexion
                If cdBox.PUPDATE = False Then
                    MsgBox(ciDTL.MERROR.ToString)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then ' Borrar
                cdBox.BDOC_BOX_LIN = dgDetalle.Rows(intLinea).Cells("col_lineabox").Value
                cdBox.CONEXION = strConexion

                If cdBox.PDELETE = False Then                                      ' BORRAR
                    MsgBox(ciDTL.MERROR.ToString)
                End If
            End If





            '''''' relaciones PRO
            ' PO -> Lotes
            pro.PDOC_SIS_EMP = Sesion.IdEmpresa
            pro.PDOC_PAR_CAT = 980                  '980 PO
            pro.PDOC_PAR_ANO = celdaidAnoPO.Text
            pro.PDOC_PAR_NUM = celdaIdPO.Text
            pro.PDOC_PAR_LIN = primeraLineaPO(celdaidAnoPO.Text, celdaIdPO.Text)
            pro.PDOC_CHI_CAT = 737                  '737 lotes
            pro.PDOC_CHI_ANO = celdaAnio.Text
            pro.PDOC_CHI_NUM = celdaNumero.Text
            pro.PDOC_CHI_LIN = clDTL.DDOC_DOC_LIN
            'pro.PDOC_QTY_PRO = dgDetalle.CurrentRow.Cells("col_PesoNeto").Value
            'pro.PDOC_PRD_NET = dgDetalle.CurrentRow.Cells("col_tara").Value

            If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 1 Then
                If pro.Actualizar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then
                If pro.Guardar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then
                If pro.Borrar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                End If
            End If


            ' Lotes -> Cajas
            pro.PDOC_SIS_EMP = Sesion.IdEmpresa
            pro.PDOC_PAR_CAT = 737              '737 lotes
            pro.PDOC_PAR_ANO = celdaAnoLote.Text
            pro.PDOC_PAR_NUM = celdaIdLote.Text
            pro.PDOC_PAR_LIN = clDTL.DDOC_DOC_LIN 'dgDetalle.CurrentRow.Cells("col_linea").Value
            pro.PDOC_CHI_CAT = 776          '776 cajas
            pro.PDOC_CHI_ANO = celdaAnio.Text
            pro.PDOC_CHI_NUM = celdaNumero.Text
            pro.PDOC_CHI_LIN = ccDTL.DDOC_DOC_LIN 'dgDetalle.CurrentRow.Cells("col_linea").Value
            pro.PDOC_QTY_PRO = dgDetalle.Rows(intLinea).Cells("col_PesoNeto").Value
            pro.PDOC_PRD_NET = dgDetalle.Rows(intLinea).Cells("col_tara").Value

            If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 1 Then
                If pro.Actualizar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then
                If pro.Guardar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then
                If pro.Borrar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                End If
            End If

            ' Cajas -> Ingresos
            pro.PDOC_SIS_EMP = Sesion.IdEmpresa
            pro.PDOC_PAR_CAT = 776              '776 cajas
            pro.PDOC_PAR_ANO = celdaAnio.Text
            pro.PDOC_PAR_NUM = celdaNumero.Text
            pro.PDOC_PAR_LIN = dgDetalle.Rows(intLinea).Cells("col_linea").Value
            pro.PDOC_CHI_CAT = 47                   '47 Ingreso
            pro.PDOC_CHI_ANO = celdaAnio.Text
            pro.PDOC_CHI_NUM = dgDetalle.Rows(intLinea).Cells("col_numIngreso").Value


            pro.PDOC_CHI_LIN = 1   'dgDetalle.CurrentRow.Cells("col_lineaIngreso").Value       '' se guarda como 1 ya que el ingreso unicamente tiene una linea
            pro.PDOC_QTY_PRO = dgDetalle.Rows(intLinea).Cells("col_PesoNeto").Value
            pro.PDOC_PRD_NET = dgDetalle.Rows(intLinea).Cells("col_tara").Value

            If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 1 Then
                If pro.Actualizar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then
                If pro.Guardar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then
                If pro.Borrar() = False Then
                    MsgBox(pro.MERROR.ToString & "Could Not update the document", MsgBoxStyle.Critical)
                End If
            End If









            'detalle ingreso
            ciDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            ciDTL.DDOC_DOC_CAT = 47                 'ingreso
            ciDTL.DDOC_DOC_ANO = cFunciones.AñoMySQL
            ciDTL.DDOC_DOC_NUM = varNumeroIngreso
            ciDTL.DDOC_DOC_LIN = 1

            ciDTL.DDOC_RF2_NUM = 3089
            ciDTL.DDOC_PRD_COD = celdaIdProducto.Text

            ciDTL.DDOC_PRD_DES = celdaProducto.Text ' productoDatos(0) 'descripcionarticulo 
            ciDTL.DDOC_PRD_UM = 69    'idmedida     69=libras
            ciDTL.DDOC_PRD_PUQ = 0 'precio
            ciDTL.DDOC_PRD_DSP = INT_CERO  'descuento
            ciDTL.DDOC_PRD_DSQ = INT_CERO  'descuento dolares
            ciDTL.DDOC_PRD_NET = 0  'precio
            ciDTL.DDOC_PRD_QTY = 0 'cantidad

            Dim pesoAcumulado As Double = 0.00
            pesoAcumulado = pesoIngreso(celdaAnio.Text, varNumeroIngreso) + dgDetalle.Rows(intLinea).Cells("col_PesoNeto").Value
            ciDTL.DDOC_RF4_DBL = pesoAcumulado

            If varIngresoModificable = 0 And dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then       ' guardar
                If varIngreso = 0 Then
                    varIngreso = 1
                    ciDTL.CONEXION = strConexion
                    If ciDTL.Guardar = False Then
                        MsgBox(ciDTL.MERROR.ToString)
                    End If
                End If
            ElseIf dgDetalle.Rows(intLinea).Cells("col_estado").Value = 1 Or dgDetalle.Rows(intLinea).Cells("col_estado").Value = 0 Then
                ciDTL.CONEXION = strConexion
                If ciDTL.Actualizar = False Then
                    MsgBox(ciDTL.MERROR.ToString)
                End If
            Else
                If dgDetalle.Rows(intLinea).Cells("col_estado").Value = 2 Then    ' borrar
                    ciDTL.CONEXION = strConexion
                    If ciDTL.Borrar = False Then
                        MsgBox(ciDTL.MERROR.ToString)
                    End If
                End If
            End If

            dgDetalle.Rows(intLinea).Cells("col_lineaBox").Value = cdBox.BDOC_BOX_LIN
            dgDetalle.Rows(intLinea).Cells("col_lineaLote").Value = clDTL.DDOC_DOC_LIN
            dgDetalle.Rows(intLinea).Cells("col_anoIngreso").Value = cFunciones.AñoMySQL
            dgDetalle.Rows(intLinea).Cells("col_lineaIngreso").Value = 1

            Dim notaRegistro As String = STR_VACIO
            notaRegistro = CrearLog(intLinea)

            cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 737, celdaAnio.Text, celdaNumero.Text, notaRegistro) ''Lote
            cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text, notaRegistro) ''cajas
            cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 47, celdaAnio.Text, celdaNumero.Text, notaRegistro & pesoAcumulado.ToString()) ''ingreso

            'Dim nota As String = "EmpresaId: " & empresaId & ", LoteAno: " & LoteAno & ", LoteNum: " & LoteNum & ", LoteLin: " & LoteLin & ", IngAno: " & ingAno & ", IngNum: " & ingNum & ", IngLin: " & ingLin & ", CajaAno: " & CajaAno & ", CajaNum: " & CajaNum & ", CajaLin: " & CajaLin & ", CajaBoxLin: " & cajaBoxLin

            'cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 737, LoteAno, LoteLin, nota) ''Lote

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Reset()
        botonNumeroLote.Enabled = True
        dtpFecha.Value = cfun.HoyMySQL()
        checkActivar.Checked = True
        celdaNumero.Text = NO_FILA
        celdaAnoLote.Text = NO_FILA
        celdaIdLote.Text = NO_FILA
        celdaNumeroLote.Text = STR_VACIO
        celdaIdTipoLote.Text = NO_FILA
        celdaTipoLote.Text = STR_VACIO
        celdaTara.Text = INT_CERO
        celdaIdColorCono.Text = NO_FILA
        celdaColorCono.Text = STR_VACIO
        celdaIdEmpacador.Text = NO_FILA
        celdaEmpacador.Text = STR_VACIO
        celdaIdColorEtiqueta.Text = NO_FILA
        celdaEtiquetaColor.Text = STR_VACIO
        celdaIdFrame.Text = NO_FILA
        celdaFrame.Text = STR_VACIO
        celdaIdEmbalaje.Text = STR_VACIO
        celdaEmbalaje.Text = STR_VACIO
        celdaIdPO.Text = NO_FILA
        celdaidAnoPO.Text = NO_FILA
        celdaPO.Text = STR_VACIO
        celdaRollosCaja.Text = STR_VACIO
        celdaCorrelativo.Text = INT_UNO
        celdaPesoManual.Text = INT_CERO
        celdaPesoBoton.Text = INT_CERO
        celdaIdProducto.Text = NO_FILA
        celdaProducto.Text = STR_VACIO
        celdaIdTurno.Text = NO_FILA
        celdaTurno.Text = STR_VACIO
        dgDetalle.Rows.Clear()

        celdaPuerto.Text = Puerto_Numero()
        celdaVelocidad.Text = Puerto_Velocidad()
        varIngresoModificable = 0
        varNumeroIngreso = 0
    End Sub
    Private Function ComprobarCampos() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0
        hora_actual = TimeOfDay
        Try
            If celdaIdLote.Text = NO_FILA Then
                MsgBox("Seleccione Lote", vbCritical)
                Comprobar = False
                Return Comprobar
                Exit Function
            End If
            If celdaIdTurno.Text = NO_FILA Then
                MsgBox("Seleccione Turno", vbCritical)
                Comprobar = False
                Return Comprobar
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Comprobar
    End Function
    Private Function ComprobarCampos_peso() As Boolean
        Dim Comprobar As Boolean = True
        Dim i As Integer = 0
        Try
            If Val(celdaPesoManual.Text) = 0 And Val(celdaPesoBoton.Text) = 0 Then
                MsgBox("Ingrese Peso", vbCritical)
                Comprobar = False
                Return Comprobar
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Comprobar
    End Function

    Private Function ComprobarFilas() As Boolean
        Dim i As Integer = vbEmpty
        Dim Comprobacion As Boolean = True

        For i = 0 To dgDetalle.Rows.Count - 1

            If dgDetalle.Rows(i).Cells("col_estado").Value = 1 Then

                If dgDetalle.Rows(i).Cells("").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Article code invalid")
                End If
                If dgDetalle.Rows(i).Cells("colArticulo").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Item Descripcion is Invalid")
                End If
                If dgDetalle.Rows(i).Cells("colPrecio").Value = NO_FILA Then
                    Comprobacion = False
                    MsgBox("Item Price is invalid")
                End If
                If dgDetalle.Rows(i).Cells("colCantidad").Value = NO_FILA Then
                    Comprobacion = False
                    MsgBox("Item Quantity is invalid")
                End If
                If dgDetalle.Rows(i).Cells("colBultos").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Packages Quantity is Invalid")
                End If
            End If

        Next
        Return Comprobacion
    End Function
    Private Function Dependecias() As Integer
        Dim intValidacion As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "  SELECT COUNT(*) "
            strSQL &= "    	FROM Dcmtos_DTL_Pro p "
            strSQL &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 776 AND p.PDoc_Par_Ano = {anio} AND p.PDoc_Par_Num = {numero}   "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intValidacion = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intValidacion
    End Function
    Private Function SQLDetalle(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "SELECT 
                        DDoc_Doc_Cat col_catalogo,
                        DDoc_Doc_Ano col_ano, 
                        DDoc_Doc_Num col_numero, 
                        DDoc_Doc_Lin col_linea, 
                        DDoc_RF1_Txt col_numLote, 
                        DDoc_RF1_Fec col_fecha, 
                        CAST(DDoc_RF1_COD AS SIGNED) col_correlativo, 
                        DDoc_Prd_DSP col_tara,
                        DDoc_Prd_QTY col_PesoNeto, 
                        DDoc_Prd_COD col_PesoBruto, 
                        1 col_estado,
                        IFNULL(pp.PDoc_Chi_Num,0)   col_numIngreso,
                        IFNULL(pp.PDoc_Chi_Ano,0)   col_anoIngreso,	                    
	                    IFNULL(pp.PDoc_Chi_Lin,0)   col_lineaIngreso,
                        IFNULL(p.PDoc_Par_Lin,0)    col_lineaLote,
	                    IFNULL(b.BDoc_Box_Lin,0)	col_lineaBox
                  FROM Dcmtos_DTL d		-- 776 cajas -- 737 lotes
                    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND p.PDoc_Chi_Num=d.DDoc_Doc_Num AND p.PDoc_Chi_Lin=d.DDoc_Doc_Lin
                    LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND pp.PDoc_Par_Cat=d.DDoc_Doc_Cat AND pp.PDoc_Par_Ano=d.DDoc_Doc_Ano AND pp.PDoc_Par_Num=d.DDoc_Doc_Num AND pp.PDoc_Par_Lin=d.DDoc_Doc_Lin
                  LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp=pp.PDoc_Sis_Emp AND b.BDoc_Doc_Cat=pp.PDoc_Chi_Cat AND b.BDoc_Doc_Ano=pp.PDoc_Chi_Ano AND b.BDoc_Doc_Num=pp.PDoc_Chi_Num AND b.BDoc_Doc_Lin = pp.PDoc_Chi_Lin AND b.BDoc_Box_Lin = d.DDoc_Doc_Lin 

                    WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat= " & cat_num & " AND DDoc_Doc_Ano= {anio} AND DDoc_Doc_Num= {num} AND DDoc_RF1_Fec BETWEEN '{fechaInicio}' AND '{fechaFin}';"
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
            strSQL = Replace(strSQL, "{fechainicio}", dtpPalletInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpPalletFin.Value.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarDetalle(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim sumaCant As Double = 0
        dgOrdenado.Rows.Clear()
        dgDetalle.Rows.Clear()
        Try
            strSQL = SQLDetalle(Anio, Num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    sumaCant = INT_CERO
                    strFila = REA.GetInt32("col_catalogo") & "|"
                    strFila &= REA.GetInt32("col_ano") & "|"
                    strFila &= REA.GetInt32("col_numero") & "|"
                    strFila &= REA.GetInt32("col_linea") & "|"
                    strFila &= REA.GetString("col_numLote") & "|"
                    strFila &= REA.GetString("col_fecha") & "|"
                    strFila &= REA.GetString("col_correlativo") & "|"
                    strFila &= REA.GetString("col_tara") & "|"
                    strFila &= REA.GetDouble("col_PesoNeto") & "|"
                    strFila &= REA.GetString("col_tara") + REA.GetDouble("col_PesoNeto") & "|" 'strFila &= REA.GetDouble("col_PesoBruto") & "|"
                    strFila &= INT_UNO & "|" 'Estado   marca si la linea se nueva | consulta | eliminar
                    strFila &= REA.GetInt32("col_numIngreso") & "|"
                    strFila &= REA.GetInt32("col_anoIngreso") & "|"
                    strFila &= REA.GetInt32("col_lineaIngreso") & "|"
                    strFila &= REA.GetInt32("col_lineaLote") & "|"
                    strFila &= REA.GetInt32("col_lineabox")
                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop
            End If
            'CalcularTotales()
            CopiarYOrdenarDatos()
            If dgOrdenado.RowCount >= 1 Then
                dgOrdenado.Rows(0).Selected = True
                Dim indiceFilaSeleccionada As Integer = dgOrdenado.SelectedRows(0).Index
                dgOrdenado.CurrentCell = dgOrdenado.Rows(indiceFilaSeleccionada).Cells(6)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLEncabezado(ByVal Anio As Integer, ByVal Num As Integer, ByVal opcion As Integer) As String
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "SELECT 
	                    h.HDoc_Sis_Emp
	                    , h.HDoc_Doc_Cat
	                    , h.HDoc_Doc_Ano Anio
	                    , h.HDoc_Doc_Num numero
	                    , h.HDoc_Doc_Fec fecha
	                    , h.HDoc_RF2_Cod anoLote
	                    , h.HDoc_RF2_Txt idLote
                        , h.HDoc_DR1_Num Lote
                        ,(SELECT hh.HDoc_DR1_Num
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp And hh.HDoc_Doc_Cat = 737 AND hh.HDoc_Doc_Ano=h.HDoc_RF2_Cod AND hh.HDoc_Doc_Num=h.HDoc_RF2_Txt) NumeroLote
	                    , h.HDoc_RF1_Dbl poID
	                    , (SELECT hh.HDoc_Doc_Ano YEAR
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) poIdAno
	                    , (SELECT hh.HDoc_DR1_Num Reference
		                    FROM  Dcmtos_HDR hh 
		                    WHERE hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp And hh.HDoc_Doc_Cat = 980 AND hh.HDoc_Doc_Ano=h.HDoc_RF3_Dbl AND hh.HDoc_Doc_Num=h.HDoc_RF1_Dbl) po
	                    , h.HDoc_DR1_Cat colorConoID
                        , cc.cat_desc colorCono
                        , h.HDoc_DR1_Dbl tara
	                    , h.HDoc_DR1_Emp colorEtiquetaID
	                    , ce.cat_desc colorEtiqueta
	                    , h.HDoc_DR2_Cat FrameID
	                    , f.cat_desc Frame
	                    , h.HDoc_RF2_Dbl RollosCaja
	                    , h.HDoc_RF2_Num correlativo
	                    , h.HDoc_DR2_Emp empacadorId
	                    , e.cat_desc empacador
	                    , h.HDoc_RF1_Num tipoLoteId
	                    , tl.cat_desc tipoLote
                        ,IFNULL(h.HDoc_DR2_Num,'')  tipoEmbalajeId
	                    ,IFNULL(em.cat_desc,'') tipoEmbalaje
	                    , h.HDoc_Emp_Cod ProductoId
	                    , (SELECT a.art_DCorta Descripcion FROM Articulos a left join Inventarios i on a.art_sisemp=i.inv_sisemp and a.art_codigo=i.inv_artcodigo WHERE i.inv_numero=h.HDoc_Emp_Cod ) producto
                        , IFNULL(chi_ing.PDoc_Chi_Ano,'') ingresoAno
	                    , IFNULL(chi_ing.PDoc_Chi_Num,'') ingresoNumero
	                    , IFNULL(p_ing.ejercicio,'') polEjercicio
                        , IFNULL(p_ing.poliza,'') polNumero
                    FROM Dcmtos_HDR h
                    LEFT JOIN Dcmtos_DTL d ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND d.DDoc_Doc_Cat=h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano=h.HDoc_Doc_Ano AND d.DDoc_Doc_Num=h.HDoc_Doc_Num
                    LEFT JOIN Catalogos_lotes cc ON cc.cat_num = h.HDoc_DR1_Cat AND cc.cat_clase='ColorCono'
                    LEFT JOIN Catalogos_lotes ce ON ce.cat_num = h.HDoc_DR1_Emp AND ce.cat_clase='ColorEtiqueta'
                    LEFT JOIN Catalogos_lotes f ON f.cat_num = h.HDoc_DR2_Cat AND f.cat_clase='Frame'
                    LEFT JOIN Catalogos_lotes e ON e.cat_num = h.HDoc_DR2_Emp AND e.cat_clase='Empacador'
                    LEFT JOIN Catalogos_lotes tl ON tl.cat_num = h.HDoc_RF1_Num AND tl.cat_clase='TipoLote'
                    LEFT JOIN Catalogos_lotes em ON em.cat_num = h.HDoc_DR2_Num AND em.cat_clase='Embalaje'
                    LEFT JOIN Dcmtos_DTL_Pro chi_caja ON chi_caja.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND chi_caja.PDoc_Par_Cat=d.DDoc_Doc_Cat AND chi_caja.PDoc_Par_Ano=d.DDoc_Doc_Ano AND chi_caja.PDoc_Par_Num=d.DDoc_Doc_Num AND chi_caja.PDoc_Par_Lin=d.DDoc_Doc_Lin
                    LEFT JOIN Dcmtos_DTL_Pro chi_ing ON chi_ing.PDoc_Sis_Emp=chi_caja.PDoc_Sis_Emp AND chi_ing.PDoc_Par_Cat=chi_caja.PDoc_Chi_Cat AND chi_ing.PDoc_Par_Ano=chi_caja.PDoc_Chi_Ano AND chi_ing.PDoc_Par_Num=chi_caja.PDoc_Chi_Num AND chi_ing.PDoc_Par_Lin=chi_caja.PDoc_Chi_Lin
                    LEFT JOIN " & Sesion.BaseConta & ".polizas p_ing ON p_ing.empresa=chi_ing.PDoc_Sis_Emp AND p_ing.ref_tipo=chi_ing.PDoc_Chi_Cat AND p_ing.ref_ciclo=chi_ing.PDoc_Chi_Ano AND p_ing.ref_numero=chi_ing.PDoc_Chi_Num

                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} LIMIT 1 ; "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            If opcion = 0 Then
                strSQL = Replace(strSQL, "{cat}", 737)
            Else
                strSQL = Replace(strSQL, "{cat}", cat_num)
            End If

            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{num}", Num)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = SQLEncabezado(Anio, Num, 1)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAnio.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("Numero")
                celdaAnoLote.Text = REA.GetInt32("anoLote")
                celdaIdLote.Text = REA.GetInt32("idLote")
                celdaNumeroLote.Text = REA.GetString("numeroLote")
                celdaIdPO.Text = REA.GetInt32("poId")
                celdaidAnoPO.Text = REA.GetInt32("poIdAno")
                celdaPO.Text = REA.GetString("po")
                celdaIdColorCono.Text = REA.GetInt32("colorConoID")
                celdaColorCono.Text = REA.GetString("colorCono")
                celdaTara.Text = REA.GetDouble("Tara")
                celdaIdColorEtiqueta.Text = REA.GetInt32("colorEtiquetaID")
                celdaEtiquetaColor.Text = REA.GetString("colorEtiqueta")
                celdaIdFrame.Text = REA.GetInt32("FrameID")
                celdaFrame.Text = REA.GetString("Frame")
                celdaIdEmbalaje.Text = REA.GetString("tipoEmbalajeId")
                celdaEmbalaje.Text = REA.GetString("tipoEmbalaje")
                celdaRollosCaja.Text = REA.GetInt32("RollosCaja")
                celdaIdEmpacador.Text = REA.GetInt32("empacadorId")
                celdaEmpacador.Text = REA.GetString("empacador")
                celdaIdTipoLote.Text = REA.GetInt32("tipoLoteId")
                celdaTipoLote.Text = REA.GetString("tipoLote")
                celdaIdProducto.Text = REA.GetInt32("ProductoId")
                celdaProducto.Text = REA.GetString("Producto")
                vIngresoAno = REA.GetString("ingresoAno")
                vIngresoNumero = REA.GetString("ingresoNumero")
                vPolizaAno = REA.GetString("polEjercicio")
                vPolizaNumero = REA.GetString("polNumero")
            Loop
        End If

    End Sub
    Public Sub CargarEncabezadoLote(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        strSQL = SQLEncabezado(Anio, Num, 0)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAnoLote.Text = REA.GetInt32("Anio")
                celdaIdLote.Text = REA.GetInt32("Numero")
                dtpFecha.Value = REA.GetDateTime("Fecha")
                celdaIdPO.Text = REA.GetInt32("poId")
                celdaidAnoPO.Text = REA.GetInt32("poIdAno")
                celdaPO.Text = REA.GetString("po")
                celdaIdColorCono.Text = REA.GetInt32("colorConoID")
                celdaColorCono.Text = REA.GetString("colorCono")
                celdaTara.Text = REA.GetDouble("Tara")
                celdaIdColorEtiqueta.Text = REA.GetInt32("colorEtiquetaID")
                celdaEtiquetaColor.Text = REA.GetString("colorEtiqueta")
                celdaIdFrame.Text = REA.GetInt32("FrameID")
                celdaFrame.Text = REA.GetString("Frame")
                celdaRollosCaja.Text = REA.GetInt32("RollosCaja")
                celdaIdEmpacador.Text = REA.GetInt32("empacadorId")
                celdaEmpacador.Text = REA.GetString("empacador")
                celdaIdTipoLote.Text = REA.GetInt32("tipoLoteId")
                celdaTipoLote.Text = REA.GetString("tipoLote")
                celdaIdEmbalaje.Text = REA.GetString("tipoEmbalajeId")
                celdaEmbalaje.Text = REA.GetString("tipoEmbalaje")
                celdaIdProducto.Text = REA.GetInt32("ProductoId")
                celdaProducto.Text = REA.GetString("Producto")
            Loop
        End If
        TurnoActual()

    End Sub
    'Borrar Encabezado Ingreso
    Public Function BorrarEncabezado() As Boolean
        Dim logGuardar As Boolean
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 776
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Detalle Ingreso
    Private Function BorrarDetalle(ByVal empresaId As Integer, ByVal LoteNum As Integer, ByVal LoteAno As Integer, ByVal LoteLin As Integer,
                                ByVal ingAno As Integer, ByVal ingNum As Integer, ByVal ingLin As Integer,
                                ByVal CajaNum As Integer, ByVal CajaAno As Integer, ByVal CajaLin As Integer, ByVal cajaBoxLin As Integer,
                                ByVal PONum As Integer, ByVal POAno As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim Dtl As New clsDcmtos_DTL
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand


        Try
            Using conn As New MySqlConnection(strConexion)
                conn.Open()
                Using cmd As New MySqlCommand("ManageDocuments", conn)
                    cmd.CommandType = CommandType.StoredProcedure

                    ' Parámetros de entrada
                    cmd.Parameters.AddWithValue("@empresaId", empresaId)
                    cmd.Parameters.AddWithValue("@LoteNum", LoteNum)
                    cmd.Parameters.AddWithValue("@LoteAno", LoteAno)
                    cmd.Parameters.AddWithValue("@LoteLin", LoteLin)
                    cmd.Parameters.AddWithValue("@ingAno", ingAno)
                    cmd.Parameters.AddWithValue("@ingNum", ingNum)
                    cmd.Parameters.AddWithValue("@ingLin", ingLin)
                    cmd.Parameters.AddWithValue("@CajaNum", CajaNum)
                    cmd.Parameters.AddWithValue("@CajaAno", CajaAno)
                    cmd.Parameters.AddWithValue("@CajaLin", CajaLin)
                    cmd.Parameters.AddWithValue("@cajaBoxLin", cajaBoxLin)
                    cmd.Parameters.AddWithValue("@PONum", PONum)
                    cmd.Parameters.AddWithValue("@POAno", POAno)

                    ' Ejecutar el procedimiento almacenado
                    cmd.ExecuteNonQuery()
                End Using
            End Using

            Return True ' Éxito
        Catch ex As Exception
            MessageBox.Show("Error al ejecutar ManageDocuments: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False ' Falla
        End Try
        Return logGuardar
    End Function

#End Region
#Region "Eventos"
    Private Sub frmProduccionNSM_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CheckForIllegalCrossThreadCalls = False
        Accesos()
        Reset()
        dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 2, 30)
        dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)
        MostrarLista()
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        MostrarLista(False)
        celdaAnio.Text = cfun.AñoMySQL
        Reset()
        '  botonTurno.PerformClick()
        TurnoActual()
        If comprobarPuerto() Then
            botonCapturaPeso.Enabled = True
            botonCapturaPeso.Visible = True
            botonNoCapturaPeso.Visible = False
            botonNoCapturaPeso.Enabled = False
        Else
            botonCapturaPeso.Enabled = False
            botonCapturaPeso.Visible = False
            botonNoCapturaPeso.Visible = True
            botonNoCapturaPeso.Enabled = True
        End If

    End Sub
    Private Sub botonQuitDetalle_Click(sender As Object, e As EventArgs) Handles botonQuitDetalle.Click
        Try
            ' Muestra el nombre de la columna y el tipo de datos
            'Debug.WriteLine("Columna: " & col.Name & " | Tipo de Datos: " & col.ValueType.ToString())
            botonQuitDetalle.Enabled = False
            If MsgBox("Esta seguro que desea borrar Pallet: No. Correlativo: " & CStr(dgOrdenado.SelectedCells(6).Value) & ", Fecha: " & CStr(dgOrdenado.SelectedCells(5).Value) & ", Peso Neto: " & CStr(dgOrdenado.SelectedCells(8).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then

                Dim Count As Integer
                If dgOrdenado.SelectedRows Is Nothing Then Exit Sub

                If CDate(dgOrdenado.SelectedCells(5).Value).ToString(FORMATO_MYSQL) = Now().ToString(FORMATO_MYSQL) Then
                    'If dgDetalle.Rows.Count > 1 Then
                    Count = dgOrdenado.Rows.GetRowCount(DataGridViewElementStates.Selected)

                    If PedirAutorizacionEliminarCaja() = True Then
                        'If Dependecias() > INT_CERO Then
                        '    MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                        '    cfun.MostrarDependencias(776, celdaAnio.Text, celdaNumero.Text)
                        'Else
                        If (dgOrdenado.SelectedCells(10).Value = 0 Or dgOrdenado.SelectedCells(10).Value = 1) Then

                            '/*PARAMETROS LOTE*/
                            'SET @LoteAno = 2025;	-- encabezado
                            'SET @LoteNum = 11;		-- encabezado
                            'SET @LoteLin = 29;		-- dgdetalle
                            '/* PARAMETROS DE INGRESOS */
                            'SET @ingAno  = 2025;	-- dgdetalle
                            'SET @ingNum  = 18566;	-- dgdetalle
                            'SET @ingLin = 1;		-- siempre es 1
                            '/* PARAMETROS DE CAJA */
                            'SET @CajaAno=2025;	-- encabezado
                            'SET @CajaNum=11;		-- encabezado
                            'SET @CajaLin=29;		-- dgdetalle
                            'SET @cajaBoxLin=29;	-- dgdetalle
                            ' Itera a través de las columnas del DataGridView y muestra su nombre y tipo de datos

                            ' Parámetros que vamos a pasar al procedimiento almacenado
                            Dim empresaId As Integer = Sesion.IdEmpresa
                            Dim LoteAno As Integer = celdaAnoLote.Text
                            Dim LoteNum As String = celdaIdLote.Text
                            Dim LoteLin As Integer = dgOrdenado.CurrentRow.Cells("col_lineaLote_o").Value 'Linea lote
                            Dim ingNum As Integer = dgOrdenado.CurrentRow.Cells("col_numIngreso_o").Value 'numIngreso
                            Dim ingAno As Integer = dgOrdenado.CurrentRow.Cells("col_anoIngreso_o").Value  'AnioIngreso
                            Dim ingLin As Integer = 1       'Siempre 1
                            Dim CajaAno As Integer = celdaAnio.Text   'col_ano INVISIBLE
                            Dim CajaNum As Integer = celdaNumero.Text     'Linea
                            Dim CajaLin As Integer = dgOrdenado.CurrentRow.Cells("col_linea_o").Value 'Linea
                            Dim cajaBoxLin As Integer = dgOrdenado.CurrentRow.Cells("col_lineabox_o").Value 'Linea box
                            '=====================================================

                            ' Crear la conexión MySQL
                            Dim CON As New MySqlConnection(strConexion)
                            Dim COM As MySqlCommand
                            Dim REA As MySqlDataReader
                            Dim database As String


                            'Try
                            '    

                            '    Dim fullProcedureName As String = database & ".`EliminarLineaCajaDetalle`"

                            '    ' Abrir la conexión
                            '    CON.Open()

                            '    ' Crear el comando para ejecutar el procedimiento almacenado
                            '    COM = New MySqlCommand(fullProcedureName, CON)

                            '    COM.CommandType = CommandType.StoredProcedure

                            '    ' Añadir los parámetros al comando (asegurándote que el nombre de los parámetros coincida)
                            '    COM.Parameters.AddWithValue("@p_empresaId", empresaId)
                            '    COM.Parameters.AddWithValue("@p_LoteAno", LoteAno)
                            '    COM.Parameters.AddWithValue("@p_LoteNum", LoteNum)
                            '    COM.Parameters.AddWithValue("@p_LoteLin", LoteLin)
                            '    COM.Parameters.AddWithValue("@p_ingAno", ingAno)
                            '    COM.Parameters.AddWithValue("@p_ingNum", ingNum)
                            '    COM.Parameters.AddWithValue("@p_ingLin", ingLin)
                            '    COM.Parameters.AddWithValue("@p_CajaAno", CajaAno)
                            '    COM.Parameters.AddWithValue("@p_CajaNum", CajaNum)
                            '    COM.Parameters.AddWithValue("@p_CajaLin", CajaLin)
                            '    COM.Parameters.AddWithValue("@p_cajaBoxLin", cajaBoxLin)

                            '    REA = COM.ExecuteReader()

                            '    MessageBox.Show("Proceso ejecutado con éxito.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)

                            '    'Eliminiar fila del datagrid
                            '    'dgDetalle.Rows.RemoveAt(dgDetalle.SelectedRows(0).Index)
                            '    dgOrdenado.Rows.Clear()
                            '    CargarDetalle(CajaAno, CajaNum)

                            '    '=============================================================================
                            '    Dim nota As String = "EmpresaId: " & empresaId & ", LoteAno: " & LoteAno & ", LoteNum: " & LoteNum & ", LoteLin: " & LoteLin & ", IngAno: " & ingAno & ", IngNum: " & ingNum & ", IngLin: " & ingLin & ", CajaAno: " & CajaAno & ", CajaNum: " & CajaNum & ", CajaLin: " & CajaLin & ", CajaBoxLin: " & cajaBoxLin

                            '    cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 737, celdaIdLote.Text, CajaNum, nota) ''Lote
                            '    cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 776, celdaNumero.Text, CajaNum, nota) ''cajas
                            '    cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 47, ingNum, CajaNum, nota) ''ingreso

                            'Catch ex As MySqlException
                            '    MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            'Finally
                            '    If CON.State = ConnectionState.Open Then
                            '        CON.Close()
                            '    End If
                            'End Try
                            '=====================================================
                            'End If



                            Try
                                database = cFunciones.nameBase()
                                Dim fullProcedureName As String = database & ".`EliminarLineaCajaDetalle`"

                                ' Abrir la conexión
                                CON.Open()

                                ' Crear el comando para ejecutar el procedimiento almacenado
                                COM = New MySqlCommand(fullProcedureName, CON)
                                COM.CommandType = CommandType.StoredProcedure

                                ' Agregar parámetros
                                COM.Parameters.AddWithValue("p_empresaId", empresaId)
                                COM.Parameters.AddWithValue("p_LoteAno", LoteAno)
                                COM.Parameters.AddWithValue("p_LoteNum", LoteNum)
                                COM.Parameters.AddWithValue("p_LoteLin", LoteLin)
                                COM.Parameters.AddWithValue("p_ingAno", ingAno)
                                COM.Parameters.AddWithValue("p_ingNum", ingNum)
                                COM.Parameters.AddWithValue("p_ingLin", ingLin)
                                COM.Parameters.AddWithValue("p_CajaAno", CajaAno)
                                COM.Parameters.AddWithValue("p_CajaNum", CajaNum)
                                COM.Parameters.AddWithValue("p_CajaLin", CajaLin)
                                COM.Parameters.AddWithValue("p_cajaBoxLin", cajaBoxLin)

                                ' Ejecutar el procedimiento y capturar el mensaje de salida
                                Dim mensaje As Object = COM.ExecuteScalar()

                                ' Verificar si el procedimiento devolvió un mensaje
                                If mensaje IsNot Nothing Then
                                    MessageBox.Show(mensaje.ToString(), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                Else
                                    MessageBox.Show("Eliminación completada correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                End If
                                ' Eliminiar fila del datagrid
                                dgOrdenado.Rows.Clear()
                                CargarDetalle(CajaAno, CajaNum)
                                '=============================================================================
                                Dim nota As String = "EmpresaId: " & empresaId & ", LoteAno: " & LoteAno & ", LoteNum: " & LoteNum & ", LoteLin: " & LoteLin & ", IngAno: " & ingAno & ", IngNum: " & ingNum & ", IngLin: " & ingLin & ", CajaAno: " & CajaAno & ", CajaNum: " & CajaNum & ", CajaLin: " & CajaLin & ", CajaBoxLin: " & cajaBoxLin

                                cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 737, LoteAno, LoteLin, nota) ''Lote
                                cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 776, CajaAno, CajaLin, nota) ''cajas
                                cFunciones.EscribirRegistro("Dcmtos_DTL", clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 47, ingAno, ingNum, nota) ''ingreso

                            Catch ex As MySqlException
                                MessageBox.Show("Error: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            Finally
                                ' Cerrar la conexión
                                If CON.State = ConnectionState.Open Then
                                    CON.Close()
                                End If
                            End Try


                        End If
                    Else
                        MsgBox("You don't have access to cancel this document")
                        botonQuitDetalle.Enabled = True
                        Exit Sub
                    End If
                Else
                    MsgBox("No puede eliminar una caja con fecha diferente a hoy")
                End If

            Else
                MsgBox("Operation Cancelled")
                botonQuitDetalle.Enabled = True
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        botonQuitDetalle.Enabled = True
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        End If
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar

        Dim i As Integer
        Dim clsConta As New clsContabilidad
        Dim intCodigo As Integer
        Dim logMezcla As Boolean
        Try
            'celdaSaldo.Text = SaldoPO().ToString(FORMATO_MONEDA)
            If Me.Tag = "Nuevo" Then

                MsgBox("Este registro se crea desde el módulo de Lotes")
            ElseIf Me.Tag = "Mod" Then
                GuardarEncabezadoCaja()
                '   GuardarDetalle()

                'cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 737, celdaAnio.Text, celdaNumero.Text)    '' Lote
                'cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text) '' cajas

                'GuardarPolizaIngreso()
                ' clsConta.GenerarPoliza(cat_num, celdaAnio.Text, celdaNumero.Text)

                If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                    '  MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Reset()
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim intCat As Integer
        Dim intLote As Integer
        Try
            If dgLista.Rows.Count = 0 Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(1).Value
            intNumero = dgLista.SelectedCells(2).Value
            intCat = dgLista.SelectedCells(0).Value
            intLote = dgLista.SelectedCells(6).Value
            CargarEncabezado(intAnio, intNumero)
            'varIngresoModificable = IngresoModificable(intAnio, intNumero, intLote)
            ' Establecer la fecha de inicio a 5 días antes de la fecha actual
            dtpPalletInicio.Value = DateTime.Now.AddDays(-2)
            ' Establecer la fecha de fin al día actual
            dtpPalletFin.Value = DateTime.Now.AddDays(1)

            CargarDetalle(intAnio, intNumero)
            MostrarLista(False, False)
            ' botonTurno.PerformClick()
            TurnoActual()
            celdaPesoManual.Focus()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(776, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value, 776)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Cantidad_Kardex As Double = 0
        Dim Total_Kardex As Double = 0
        If LogBorrar = True Then
            If Dependecias() > INT_CERO Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
                cfun.MostrarDependencias(776, celdaAnio.Text, celdaNumero.Text)
            Else

                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then

                    For i As Integer = 0 To dgDetalle.RowCount - 1
                        dgDetalle.Rows(i).Cells("col_estado").Value = 2
                        GuardarDetallePorLinea()
                    Next

                    BorrarEncabezado()
                    cFunciones.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAnio.Text, 776)
                    cFunciones.BorrarDetallePoliza(celdaNumero.Text, celdaAnio.Text, 776)
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub
    Private Sub botonCapturaPeso_Click(sender As Object, e As EventArgs) Handles botonCapturaPeso.Click
        ' Deshabilitar el botón para evitar clics múltiples
        botonCapturaPeso.Enabled = False

        ' Inicializar el lector del puerto serial
        Try
            ' Si el puerto está abierto, lo cerramos antes de abrirlo nuevamente
            If SerialPort.IsOpen() Then
                SerialPort.Close()
            End If

            ' Abrir el puerto serial
            SerialPort.Open()

            ' Llamar a la función que lee el peso (asegúrate de que esta función no sea bloqueante o esté manejada correctamente)
            LeerPesoMT_SICS()

            ' Llamar a la acción del otro botón, si es necesario
            botonAgreDetalle.PerformClick()

        Catch ex As Exception
            ' En caso de error, muestra el mensaje de error
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Asegurarse de que el botón se habilite siempre después de la operación
            botonCapturaPeso.Enabled = True
        End Try

    End Sub
    Private Sub botonNumeroLote_Click(sender As Object, e As EventArgs) Handles botonNumeroLote.Click
        Dim frm As New frmSeleccionar
        Dim fechaInicio As Date
        Try
            fechaInicio = DateTime.Now.AddMonths(-14)
            frm.Titulo = "PO "
            frm.Campos = " h.HDoc_Doc_Ano YEAR, h.HDoc_Doc_Num ID, h.HDoc_DR1_Num NumeroLote"
            frm.Tabla = "   Dcmtos_HDR h "
            frm.FiltroText = " Ingrese el numero de lote a buscar:"
            frm.Filtro = " NumeroLote "
            frm.Condicion = "h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " And h.HDoc_Doc_Cat = 737"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaAnoLote.Text = frm.LLave
                celdaNumeroLote.Text = frm.Dato2
                celdaIdLote.Text = frm.Dato
            End If
            celdaPesoManual.Clear()
            celdaPesoManual.Focus()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub celdaIdLote_TextChanged(sender As Object, e As EventArgs) Handles celdaIdLote.TextChanged
        If Me.Tag = "Nuevo" Then
            CargarEncabezadoLote(celdaAnoLote.Text, celdaIdLote.Text)
        End If
        celdaCorrelativo.Text = NuevoCorrelativo()
    End Sub
    Private Sub BotonAgreDetalle_Click(sender As Object, e As EventArgs) Handles botonAgreDetalle.Click
        Dim strFila As String = STR_VACIO
        Dim linea As Integer = 0
        Dim pesoBruto As Double = 0.00
        Dim pesoNeto As Double = 0.00
        Dim tara As Double = 0.00

        Dim filaEncontrada As Integer
        If ComprobarCampos() Then
            If ComprobarCampos_peso() And validaCorrelativo(celdaCorrelativo.Text) Then
                'TOMA EL MAXIMO DE LINEAS DE CAJAS... 
                linea = obtenerIdLinea()

                'If dgDetalle.Rows.Count > 0 Then
                '    'For i As Integer = 1 To dgDetalle.Rows.Count - 1
                '    linea = dgDetalle.Rows(dgDetalle.Rows.Count - 1).Cells("col_linea").Value + 1
                '    'Next
                'End If

                If linea <= 0 Then
                    Exit Sub ' Salir si no es un número válido.
                End If

                '============================= BEGIN - VALIDAR PESO =================================
                ' Primero, intenta leer el peso de la báscula o el valor manual.
                If Double.TryParse(celdaPesoBoton.Text.Trim(), pesoBruto) Then
                    ' Si no tiene valor, usa el peso manual.
                    If pesoBruto = 0 Then
                        If Not Double.TryParse(celdaPesoManual.Text.Trim(), pesoBruto) Then
                            MsgBox("Error: Peso no es un numero válido.", MsgBoxStyle.Critical, "Datos Incorrectos")
                            Exit Sub ' Salir si no es un número válido.
                        End If
                    End If
                    ' Intentamos leer el valor de tara.
                    If Not Double.TryParse(celdaTara.Text.Trim(), tara) Then
                        MsgBox("Error: La tara no es un número válido.", MsgBoxStyle.Critical, "Datos Incorrectos")
                        Exit Sub ' Salir si no es un número válido.
                    End If
                    ' Calcular el peso neto.
                    pesoNeto = pesoBruto - tara

                    ' Validar si el tara es mayor que cero.
                    If tara < 0 Then
                        MsgBox("La tara es menor o igual a cero. Verifica los datos ingresados.", MsgBoxStyle.Critical, "Error")
                        Exit Sub ' Salir si no es un número válido.
                    End If

                    ' Validar si el peso neto es mayor que cero.
                    If pesoNeto <= 0 Then
                        MsgBox("El peso neto es menor o igual a cero. Verifica los datos ingresados.", MsgBoxStyle.Critical, "Error")
                        Exit Sub ' Salir si no es un número válido.
                    End If

                Else
                    MsgBox("Error: El peso bruto no es un número válido.", MsgBoxStyle.Critical, "Datos Incorrectos")
                    Exit Sub ' Salir si no es un número válido.
                End If
                '============================= END - VALIDAR PESO =================================


                strFila = cat_num & "|"       'Catalogo
                strFila &= celdaAnio.Text & "|"       'Año
                strFila &= celdaNumero.Text & "|"      'Numero
                strFila &= linea & "|"      'Linea
                strFila &= celdaNumeroLote.Text & "|"      'Numero lote
                strFila &= Now().ToString(FORMATO_MYSQL) & "|"       'Fecha
                strFila &= celdaCorrelativo.Text & "|"      'Correlativo
                'strFila &= Val(celdaTara.Text) & "|"      'tara
                'strFila &= CDbl((celdaPesoManual.Text) - CDbl((celdaTara.Text))) & "|"      'pero Net
                'strFila &= CDbl((celdaPesoManual.Text)) & "|"      'Peso Bruto
                strFila &= tara & "|"      'tara
                strFila &= pesoNeto & "|"      'pero Net
                strFila &= pesoBruto & "|"      'Peso Bruto
                strFila &= "0|"         'Estado      0> nuevo 1>consulta 2> borrar
                strFila &= "0|0|0|0|0"        ' año, numero, linea -> ingreso    linea -> lote, lineabox

                cFunciones.AgregarFila(dgDetalle, strFila)

                cFunciones.EscribirRegistro("dgDetalle", clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text, strFila) ''Lote

                celdaPesoManual.Clear()
                celdaPesoManual.Focus()
                botonNumeroLote.Enabled = False
                turnoInicial(1)     ''turno A

                GuardarEncabezado()

                GuardarDetallePorLinea()
                'CopiarYOrdenarDatos()
                CargarDetalle(celdaAnio.Text, celdaNumero.Text)

                dgDetalle.Rows(dgDetalle.RowCount - 1).Selected = True
                dgOrdenado.Rows(0).Selected = True
                BuscarCorrelativoObtenerLinea(celdaCorrelativo.Text)

                celdaCorrelativo.Text += 1

                impresionEtiqueta("0")
            End If
        End If
    End Sub
    Private Sub CopiarYOrdenarDatos()
        ' Limpiar SOLO las filas, no las columnas
        dgOrdenado.Rows.Clear()

        ' Copiar las filas dinámicamente
        For Each fila As DataGridViewRow In dgDetalle.Rows
            If Not fila.IsNewRow Then ' Evita la última fila vacía
                Dim nuevaFila As DataGridViewRow = dgOrdenado.Rows(dgOrdenado.Rows.Add())

                ' Copiar los valores de las celdas
                For i As Integer = 0 To fila.Cells.Count - 1
                    nuevaFila.Cells(i).Value = fila.Cells(i).Value
                Next
            End If
        Next

        ' Ordenar por "col_correlativo" si existe y convertir a número antes de comparar
        If dgOrdenado.Columns.Contains("col_correlativo_o") Then
            Dim colIndex As Integer = dgOrdenado.Columns("col_correlativo_o").Index
            dgOrdenado.Sort(New NumericComparer(colIndex, System.ComponentModel.ListSortDirection.Descending))
        End If
    End Sub

    ' Crear un Comparador Personalizado para Ordenar como Números
    Private Class NumericComparer
        Implements IComparer

        Private columnIndex As Integer
        Private sortOrder As System.ComponentModel.ListSortDirection

        Public Sub New(colIndex As Integer, order As System.ComponentModel.ListSortDirection)
            columnIndex = colIndex
            sortOrder = order
        End Sub

        Public Function Compare(x As Object, y As Object) As Integer Implements IComparer.Compare
            Dim rowX As DataGridViewRow = DirectCast(x, DataGridViewRow)
            Dim rowY As DataGridViewRow = DirectCast(y, DataGridViewRow)

            ' Obtener valores de la columna como números
            Dim valX As Integer = 0
            Dim valY As Integer = 0

            Integer.TryParse(If(rowX.Cells(columnIndex).Value?.ToString(), "0"), valX)
            Integer.TryParse(If(rowY.Cells(columnIndex).Value?.ToString(), "0"), valY)

            ' Comparar valores numéricos
            If sortOrder = System.ComponentModel.ListSortDirection.Ascending Then
                Return valX.CompareTo(valY)
            Else
                Return valY.CompareTo(valX)
            End If
        End Function
    End Class
    Private Sub celdaPesoManual_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaPesoManual.KeyDown
        If e.KeyCode = Keys.Enter Then
            botonAgreDetalle.PerformClick()
            e.SuppressKeyPress = True ' Evita el sonido de la tecla Enter            
        End If
    End Sub
    Private Sub botonTurno_Click(sender As Object, e As EventArgs) Handles botonTurno.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Turno"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion, cat_ext hora_Inicio, cat_dato hora_fin"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese Turno"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'Turno'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdTurno.Text = frm.LLave
                celdaTurno.Text = frm.Dato
                hora_inicio = frm.Dato2
                hora_fin = frm.Dato3
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub TurnoActual()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = ""
        hora_actual = TimeOfDay
        Try
            strSQL = "SELECT cat_num Codigo, cat_desc Descripcion, cat_ext hora_Inicio, cat_dato hora_fin FROM "
            strSQL &= " Catalogos_lotes WHERE cat_clase = 'Turno' and  CAST('" & hora_actual & "' AS TIME) BETWEEN CAST(cat_ext AS TIME) AND CAST(cat_dato AS TIME)"
            strSQL = "SELECT cat_num Codigo, cat_desc Descripcion, cat_ext hora_Inicio, cat_dato hora_fin 
                        FROM  Catalogos_lotes 
                        WHERE cat_clase = 'Turno' and  time('" & hora_actual & "') BETWEEN time(cat_ext) AND time(cat_dato)
                        union
                        SELECT cat_num Codigo, cat_desc Descripcion, cat_ext hora_Inicio, cat_dato hora_fin 
                        FROM  Catalogos_lotes turno
                        WHERE (TIME('" & hora_actual & "') >= TIME(turno.cat_ext) OR TIME('" & hora_actual & "') < TIME(turno.cat_dato)) 
                                     AND TIME(turno.cat_ext) > TIME(turno.cat_dato)
                        ;"

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaIdTurno.Text = REA.GetInt32("Codigo")
                    celdaTurno.Text = REA.GetString("Descripcion")
                    hora_inicio = REA.GetString("hora_Inicio")
                    hora_fin = REA.GetString("hora_fin")
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub turnoInicial(numero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = ""
        hora_actual = TimeOfDay
        Try
            strSQL = "SELECT cat_ext hora_Inicio FROM "
            strSQL &= " Catalogos_lotes WHERE cat_clase = 'Turno'
                        and Cat_num=" & numero

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    hora_Inicio_P = REA.GetString("hora_Inicio")
                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub impresionEtiqueta(Optional ByVal tipoReporte As String = "")
        'REPORTE 

        Dim opt As New frmOption
        Dim strRespuesta As String = STR_VACIO
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO

        If dgOrdenado.SelectedRows.Count > 0 Then

            ' Verificar si tipoReporte está vacío
            If String.IsNullOrEmpty(tipoReporte) Then
                ' Si tipoReporte está vacío, mostrar el menú
                opt.Titulo = "INCOTERM"
                opt.Mensaje = "Select an option"
                opt.Opciones = "Print Etiqueta Caja" & "|" & "Print Etiqueta Traspaso" ' & "|" & "Print Etiqueta Info Empacador" & "|" & "Print Etiqueta Cono"

                ' Mostrar el cuadro de diálogo para la selección
                If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    ' Procesar la opción seleccionada
                    Select Case opt.Seleccion
                        Case 0
                            strRespuesta = "0"
                        Case 1
                            strRespuesta = "1"
                        Case 2
                            strRespuesta = "2"
                        Case 3
                            strRespuesta = "3"
                    End Select
                Else
                    ' Si se cancela el diálogo, salir del Sub
                    Exit Sub
                End If
            Else
                ' Si tipoReporte no está vacío, asignar "0" a strRespuesta
                strRespuesta = tipoReporte
            End If

        Else
            MessageBox.Show("No hay ninguna fila seleccionada.")
        End If

        ' Instanciar la clase clsEtiquetas
        Dim rptEtiqueta As New clsEtiquetas()
        Dim rutaArchivo As String = String.Empty ' Asegúrate de inicializar la variable

        'ENVIANDO DATOS NECESARIOS PARA QUERY DE REPORTERIA
        rptEtiqueta.Anio = Convert.ToInt32(celdaAnio.Text)
        rptEtiqueta.Number = Convert.ToInt32(celdaNumero.Text)
        rptEtiqueta.Linea = Convert.ToInt32(dgOrdenado.SelectedRows(0).Cells("col_linea_o").Value)

        Select Case strRespuesta
            Case "0"
                rutaArchivo = rptEtiqueta.imprimirEtiquetaPeso()
            Case "1"
                ' Declaramos las variables
                Dim correlativoInicio As String = String.Empty
                Dim correlativoFin As String = String.Empty
                Dim cantidadCajas As String = String.Empty
                Dim respuesta As DialogResult

                Try
                    ' Preguntamos al usuario si desea ingresar los tres datos
                    respuesta = MessageBox.Show("¿Desea ingresar los datos de correlativo ( inicio - fin )?",
                                                           "Ingreso de Datos", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)

                    ' Si el usuario responde "No", no pedimos los datos de los rangos
                    If respuesta = DialogResult.No Then
                        ' MessageBox.Show("No se ingresarán los datos de correlativo y cantidad de cajas. Continuando con el proceso.")
                        ' Continuamos con el proceso sin pedir los datos de correlativo o cantidad
                        rutaArchivo = rptEtiqueta.imprimirFichaTraspasoBodegaPT(dgOrdenado.SelectedRows(0).Cells("col_correlativo_o").Value, dgOrdenado.SelectedRows(0).Cells("col_correlativo_o").Value, 1)
                    Else

                        ' Llamar a la función para obtener el rango
                        Dim resultado As Tuple(Of Integer, Integer) = ObtenerRango()

                        ' Verificar si se obtuvo un rango válido
                        If resultado IsNot Nothing Then
                            correlativoInicio = resultado.Item1
                            correlativoFin = resultado.Item2

                            ' Puedes ahora usar numero1 y numero2 en otros cálculos o lógica
                            cantidadCajas = correlativoFin - correlativoInicio + 1

                            ' Ahora que tenemos los datos, podemos continuar con la generación del reporte
                            MessageBox.Show("Correlativo Inicio: " & correlativoInicio & vbCrLf &
                                 "Correlativo Fin: " & correlativoFin & vbCrLf &
                                 "Cantidad de Cajas: " & cantidadCajas)

                            'Busca el correlativo y selecciona el correlativo.
                            If BuscarCorrelativoObtenerLinea(correlativoInicio) Then
                                rptEtiqueta.Linea = Convert.ToInt32(dgOrdenado.SelectedRows(0).Cells("col_linea_o").Value)
                                rutaArchivo = rptEtiqueta.imprimirFichaTraspasoBodegaPT(correlativoInicio, correlativoFin, cantidadCajas)
                            End If

                        Else
                            MessageBox.Show("No se pudo obtener un rango válido.")
                        End If


                    End If

                    '//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                Catch ex As Exception
                    MsgBox(ex.ToString())
                End Try
            Case "2"
                rutaArchivo = rptEtiqueta.imprimirEtiquetaInfoEmpacador(celdaAnio.Text, celdaNumero.Text)
            Case "3"
                rutaArchivo = rptEtiqueta.imprimirEtiquetaCono(celdaAnio.Text, celdaNumero.Text)
            Case Else
                ' Si la respuesta no es "FOB" ni "CIF", asignar un valor por defecto o manejar el error
                MessageBox.Show("Tipo de respuesta no válido.")
                Exit Sub ' Salir del método si no se asignó ruta
        End Select

        ' Verificar si rutaArchivo tiene un valor antes de navegar
        If Not String.IsNullOrEmpty(rutaArchivo) Then
            ' Cargar el archivo HTML generado en el WebBrowser
            'wbVistaPrevia.Navigate(rutaArchivo) 'Se elimina vista porque se agrega vista de frmReportes

            Dim frm As New frmReporte
            frm.ArchivoTemporal = rutaArchivo
            frm.Show()
            'If IsNothing(frmP) Then
            '    frm.Show()
            'Else
            '        'If blParent = True Then
            '        'frm.MdiParent = Fprincipal
            '        'End If
            '        frm.Show()
            'End If
            rutaArchivo = STR_VACIO



        Else
            MessageBox.Show("No se generó el archivo, por favor verifique el proceso.")
        End If

    End Sub
    Private Sub impresionEtiquetaConoEmpacador(Optional ByVal tipoReporte As String = "")
        'REPORTE 

        Dim opt As New frmOption
        Dim strRespuesta As String = STR_VACIO
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO

        ' Verificar si tipoReporte está vacío
        If String.IsNullOrEmpty(tipoReporte) Then
            ' Si tipoReporte está vacío, mostrar el menú
            opt.Titulo = "INCOTERM"
            opt.Mensaje = "Select an option"
            opt.Opciones = "Print Etiqueta Info Empacador" & "|" & "Print Etiqueta Cono"

            ' Mostrar el cuadro de diálogo para la selección
            If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                ' Procesar la opción seleccionada
                Select Case opt.Seleccion
                    Case 0
                        strRespuesta = "0"
                    Case 1
                        strRespuesta = "1"
                End Select
            Else
                ' Si se cancela el diálogo, salir del Sub
                Exit Sub
            End If
        Else
            ' Si tipoReporte no está vacío, asignar "0" a strRespuesta
            strRespuesta = tipoReporte
        End If


        ' Instanciar la clase clsEtiquetas
        Dim rptEtiqueta As New clsEtiquetas()
        Dim rutaArchivo As String = String.Empty ' Asegúrate de inicializar la variable

        Select Case strRespuesta
            Case "0"
                rutaArchivo = rptEtiqueta.imprimirEtiquetaInfoEmpacador(celdaAnio.Text, celdaNumero.Text)
            Case "1"
                rutaArchivo = rptEtiqueta.imprimirEtiquetaCono(celdaAnio.Text, celdaNumero.Text)
            Case Else
                ' Si la respuesta no es "FOB" ni "CIF", asignar un valor por defecto o manejar el error
                MessageBox.Show("Tipo de respuesta no válido.")
                Exit Sub ' Salir del método si no se asignó ruta
        End Select
        If Not String.IsNullOrEmpty(rutaArchivo) Then
            ' Cargar el archivo HTML generado en el WebBrowser

            Dim frm As New frmReporte
            frm.ArchivoTemporal = rutaArchivo
            frm.Show()

            rutaArchivo = STR_VACIO

        Else
            MessageBox.Show("No se generó el archivo, por favor verifique el proceso.")
        End If
    End Sub

    Private Sub celdaVelocidad_TextChanged(sender As Object, e As EventArgs) Handles celdaVelocidad.DoubleClick

    End Sub

    Private Sub btnImprimirEtiquetas_Click(sender As Object, e As EventArgs) Handles btnImprimirEtiquetas.Click
        impresionEtiqueta()
    End Sub
    Private Sub botonImprimirConoEmpacador_Click(sender As Object, e As EventArgs) Handles botonImprimirConoEmpacador.Click
        impresionEtiquetaConoEmpacador()
    End Sub
    Public Function comprobarPuerto1() As Boolean
        Dim estado As Boolean = False

        'Dim WithEvents Serial As New SerialPort("COM5", 9600, Parity.None, 8, StopBits.One)
        Using Serial As New SerialPort("COM5", 9600, Parity.None, 8, StopBits.One)
            Serial.Dispose()

            Dim portName As String = celdaPuerto.Text ' Reemplaza "COM1" con el nombre del puerto que deseas verificar
            Console.WriteLine($"comprobarPuerto()  {portName} ")
            Try
                If Serial.IsOpen Then Serial.Close()
                Serial.PortName = celdaPuerto.Text      '"COM5"
                Serial.BaudRate = celdaVelocidad.Text   '9600
                Serial.Open()
                MessageBox.Show("Puerto " & celdaPuerto.Text & " abierto")
                Console.WriteLine($"Puerto {portName} abierto.")
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
                Console.WriteLine($"Error en puerto {portName}.")
            End Try

            Console.WriteLine($"validacion si esta conectado en {portName} ")
            'Dim isConnected As Boolean = clsFunciones.SerialPortValidator.IsDeviceConnected(portName, celdaVelocidad.Text)

            ' Configurar los parámetros del puerto serial
            Serial.ReadTimeout = 5000
            Serial.WriteTimeout = 5000

            ' Abrir el puerto serial
            If Serial.IsOpen Then Serial.Close()
            Serial.Open()

            ' Enviar un comando para verificar la conexión (por ejemplo, un simple ping)
            Dim command As String = "PING" & vbCrLf
            Serial.Write(command)

            ' Esperar una respuesta
            Dim response As String = Serial.ReadLine()

            ' Si recibimos una respuesta, asumimos que el dispositivo está conectado
            If Not String.IsNullOrEmpty(response) Then
                estado = True
            End If


            If estado = True Then
                MsgBox("El dispositivo está conectado en " & portName & ".")
                Console.WriteLine($"El dispositivo está conectado en {portName}.")
            Else
                MsgBox("No se encontró ningún dispositivo en " & portName & ".")
                Console.WriteLine($"No se encontró ningún dispositivo en {portName}.")
            End If


            Return estado
        End Using
    End Function
    Public Function comprobarPuerto()
        Dim estado As Boolean = False
        Dim portName As String = celdaPuerto.Text ' COM5
        Dim baudRate As Integer = Integer.Parse(celdaVelocidad.Text) ' 9600

        Try
            Using Serial As New SerialPort(portName, baudRate, Parity.None, 8, StopBits.One)
                ' Configurar los tiempos de espera antes de abrir el puerto
                Serial.ReadTimeout = 2000  ' 2 segundos
                Serial.WriteTimeout = 2000

                If Serial.IsOpen Then Serial.Close()
                Serial.Open()
                MessageBox.Show("Puerto " & portName & " abierto correctamente.")
                Console.WriteLine($"Puerto {portName} abierto correctamente.")
                botonNoCapturaPeso.Visible = False
                botonCapturaPeso.Visible = True
                botonCapturaPeso.Enabled = True
                ' Enviar un comando de prueba
                'Dim command As String = "PING" & vbCrLf
                'Serial.Write(command)
                'Threading.Thread.Sleep(500) ' Espera 500ms para recibir respuesta

                '' Intentar leer la respuesta
                'Dim response As String = Serial.ReadLine()
                'If Not String.IsNullOrEmpty(response) Then
                '    estado = True
                'End If

                ' Cerrar puerto antes de salir
                Serial.Close()
            End Using

            'Catch ex As TimeoutException
            '    MessageBox.Show("Error: No hubo respuesta del dispositivo en el puerto " & portName & ".")
            'Catch ex As UnauthorizedAccessException
            '    MessageBox.Show("Error: El puerto " & portName & " está en uso o requiere permisos.")
            'Catch ex As IO.IOException
            '    MessageBox.Show("Error: El puerto " & portName & " no está disponible.")
        Catch ex As Exception
            MessageBox.Show("Error inesperado: " & ex.Message)
        End Try

        '' Mostrar mensaje final
        'If estado = True Then
        '    MsgBox("El dispositivo está conectado en " & portName & ".")
        '    Console.WriteLine($"El dispositivo está conectado en {portName}.")
        'Else
        '    MsgBox("No se encontró ningún dispositivo en " & portName & ".")
        '    Console.WriteLine($"No se encontró ningún dispositivo en {portName}.")
        'End If
    End Function

    Public Sub AvailablePorts()
        Dim ports As String() = SerialPort.GetPortNames()
        Console.WriteLine("Puertos disponibles:")
        For Each port As String In ports
            Console.WriteLine(port)
            MsgBox(port)
        Next
        Console.ReadLine()
    End Sub


    Private Sub botonNoCapturaPeso_Click(sender As Object, e As EventArgs) Handles botonNoCapturaPeso.Click
        celdaPuerto.Text = Puerto_Numero()
        celdaVelocidad.Text = Puerto_Velocidad()
        'AvailablePorts()
        comprobarPuerto()
    End Sub

    Private Sub lblPesoManual_Click(sender As Object, e As EventArgs) Handles lblPesoManual.Click
        If TextBox1.Visible = True Then
            TextBox1.Visible = False
        Else
            TextBox1.Visible = True
        End If

    End Sub

    Private Sub botonEmpacador_Click(sender As Object, e As EventArgs) Handles botonEmpacador.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Empacador"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion, cat_clave Nombre"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese Empacador"
            frm.Filtro = " CONCAT(cat_desc, ' ', cat_clave) "
            frm.Condicion = "cat_clase = 'Empacador' AND cat_pid = 1"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdEmpacador.Text = frm.LLave
                celdaEmpacador.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonColorCono_Click(sender As Object, e As EventArgs) Handles botonColorCono.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Color Cono"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese el color de cono"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'ColorCono'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdColorCono.Text = frm.LLave
                celdaColorCono.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFrame_Click(sender As Object, e As EventArgs) Handles botonFrame.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Frame"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese Frame"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'Frame'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdFrame.Text = frm.LLave
                celdaFrame.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub etiquetaFecha_Click(sender As Object, e As EventArgs) Handles etiquetaFecha.Click
        MsgBox("ingreso No." & vIngresoAno & "|" & vIngresoNumero & ", poliza No." & vPolizaAno & "|" & vPolizaNumero)
    End Sub
    Private Function PedirAutorizacionEliminarCaja() As Boolean
        Dim LogResult As Boolean = True
        Dim frm As frmAutorización
        PedirAutorizacionEliminarCaja = False

        frm = New frmAutorización
        frm.Iniciar(776, "EliminaCaja", 0, "Autorizar Eliminar caja")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionEliminarCaja = True
                Dim notaDelete As String = STR_VACIO

                notaDelete = "Lote:" & dgOrdenado.CurrentRow.Cells("col_lineaLote_o").Value ' Linea Lote
                notaDelete &= ", Caja:" & celdaNumero.Text
                notaDelete &= ", AnioCaja:" & celdaAnio.Text
                notaDelete &= ", LineaCaja:" & dgOrdenado.CurrentRow.Cells("col_linea_o").Value 'Linea Caja
                notaDelete &= ", AnioIngreso:" & dgOrdenado.CurrentRow.Cells("col_anoIngreso_o").Value  'AnioIngreso
                notaDelete &= ", Ingreso:" & dgOrdenado.CurrentRow.Cells("col_numIngreso_o").Value 'numIngreso
                notaDelete &= ", LineaBox:" & dgOrdenado.CurrentRow.Cells("col_lineabox_o").Value 'Linea box

                cfun.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acConfirm, Sesion.idUsuario, 776, celdaAnio.Text, celdaNumero.Text, "Autorizar Eliminar caja " & "( " & frm.Usuario & " ) " & notaDelete)
            Else
                MsgBox("No cuenta con el nivel de autorizacion requerido para eliminar", vbExclamation, "Notice")
            End If
        Else
            MsgBox("No cuenta con el nivel de autorizacion requerido para eliminar", vbExclamation, "Notice")
        End If
        LogResult = True
    End Function

    Private Function CrearLog(ByVal intLinea As Integer) As String
        Dim log As New Text.StringBuilder()

        If intLinea >= 0 AndAlso intLinea < dgDetalle.Rows.Count Then
            Dim fila As DataGridViewRow = dgDetalle.Rows(intLinea)

            For Each cell As DataGridViewCell In fila.Cells
                Dim nombreColumna As String = dgDetalle.Columns(cell.ColumnIndex).HeaderText

                ' Concatenamos el nombre de la columna y el valor de la celda
                log.Append(nombreColumna & ": " & If(cell.Value IsNot Nothing, cell.Value.ToString(), "null"))
                log.Append(";") ' Usamos tabulador como separador
            Next

        Else
            log.AppendLine("Índice de fila no válido.")
        End If

        ' Devolvemos el log como un string
        Return log.ToString()
    End Function


#End Region
#Region "pruebas"


    'Private WithEvents SerialPort As New SerialPort("COM7", 9600, Parity.None, 8, StopBits.One)
    Private WithEvents SerialPort As New SerialPort(Puerto_Numero, Puerto_Velocidad, Parity.None, 8, StopBits.One)
    'Private SerialPort As SerialPort
    Private Sub TextBox1_DoubleClick(sender As Object, e As EventArgs) Handles TextBox1.DoubleClick
        'Dim puertoEncontrado As String = DetectarPuertoBascula()

        'If puertoEncontrado <> "" Then
        '    SerialPort = New SerialPort(puertoEncontrado, 9600, Parity.None, 8, StopBits.One)
        '    Try
        '        SerialPort.NewLine = vbCrLf
        '        SerialPort.Open()
        '        MessageBox.Show("Báscula detectada en: " & puertoEncontrado)
        '        celdaPuerto.Text = puertoEncontrado
        '    Catch ex As Exception
        '        MessageBox.Show("Error al abrir el puerto: " & ex.Message)
        '    End Try
        'Else
        '    MessageBox.Show("No se encontró la báscula.")
        'End If
        Try
            SerialPort.NewLine = vbCrLf ' Configura el fin de línea para MT-SICS
            If SerialPort.IsOpen Then SerialPort.Close()
            SerialPort.Open()
            LeerPesoMT_SICS() ' Llama a la función de lectura al hacer doble clic en el TextBox
            If SerialPort IsNot Nothing AndAlso SerialPort.IsOpen Then
                SerialPort.Close() ' Cierra el puerto al cerrar el formulario
            End If
        Catch
            MsgBox("sin puerto serial")
        End Try
    End Sub

    Private Sub btnSeleccionFecha_Click(sender As Object, e As EventArgs) Handles btnSeleccionFecha.Click
        CargarDetalle(celdaAnio.Text, celdaNumero.Text)
    End Sub

    Private Sub LeerPesoMT_SICS()
        Try
            If SerialPort.IsOpen Then
                SerialPort.DiscardInBuffer() ' Limpia el buffer de entrada
                ''SerialPort.WriteLine("S") ' Enviar comando "S"
                Threading.Thread.Sleep(100) ' Esperar que la báscula responda

                SerialPort.ReadTimeout = 100 ' Establece un tiempo límite de espera
                Dim respuesta As String = SerialPort.ReadExisting().Trim()

                If respuesta = "" Then
                    MessageBox.Show("No se recibió respuesta de la báscula.")
                Else
                    MsgBox(respuesta)
                    TextBox1.Text = ParsearPeso(respuesta)
                    celdaPesoBoton.Text = ParsearPeso(respuesta)
                End If
            Else
                MessageBox.Show("El puerto " & SerialPort.PortName & " no está abierto.")
            End If
        Catch ex As TimeoutException
            MessageBox.Show("Tiempo de espera agotado. No se recibió respuesta de la báscula.")
        Catch ex As Exception
            MessageBox.Show("Error en la lectura del puerto: " & ex.Message)
        End Try
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub botonEmbalaje_Click(sender As Object, e As EventArgs) Handles botonEmbalaje.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Embalaje"
            frm.Campos = " cat_num Codigo, cat_desc Descripcion"
            frm.Tabla = " Catalogos_lotes"
            frm.FiltroText = " Ingrese el embalaje"
            frm.Filtro = " cat_desc "
            frm.Condicion = "cat_clase = 'Embalaje'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdEmbalaje.Text = frm.LLave
                celdaEmbalaje.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ParsearPeso(respuesta As String) As String
        ' Mettler Toledo responde con formato como: "S S      12.34 kg"
        Dim partes() As String = respuesta.Split(" "c)
        For Each parte In partes
            If IsNumeric(parte) Then
                Return parte / 10  ' Devuelve solo el valor numérico
            End If
        Next
        Return "0"
    End Function
    Private Function DetectarPuertoBascula() As String
        Dim puertosDisponibles() As String = SerialPort.GetPortNames()

        For Each puerto In puertosDisponibles
            If puerto.Contains("COM") Then ' Filtrar puertos disponibles
                Try
                    Using sp As New SerialPort(puerto, 9600, Parity.None, 8, StopBits.One)
                        sp.Open()
                        Threading.Thread.Sleep(100) ' Espera breve
                        ' sp.WriteLine("S") ' Enviar comando de prueba
                        Threading.Thread.Sleep(100)
                        Dim respuesta As String = sp.ReadExisting().Trim()
                        sp.Close()

                        ' Si la respuesta tiene números, asumimos que es la báscula
                        If respuesta <> "" AndAlso respuesta.Any(Function(c) Char.IsDigit(c)) Then
                            Return puerto ' Se encontró el puerto correcto
                        End If
                    End Using
                Catch ex As Exception
                    ' Ignorar errores de puertos ocupados o inaccesibles
                End Try
            End If
        Next

        Return "" ' No se encontró la báscula
    End Function
    Public Function BuscarCorrelativoObtenerLinea(ByVal valor As String) As Boolean
        Dim valorBuscado As String = valor
        Dim indiceFila As Integer = -1  ' Inicializamos el índice como -1 (sin encontrar)

        ' Recorrer todas las filas del DataGridView
        For Each row As DataGridViewRow In dgOrdenado.Rows
            ' Asegurarnos de que no estamos en la fila nueva (la fila de entrada)
            If Not row.IsNewRow Then
                ' Comparar el valor de la celda en la columna "Nombre" (suponiendo que el índice de columna es 1)
                If row.Cells("col_correlativo_o").Value.ToString() = valorBuscado Then
                    ' Si encontramos el valor, almacenamos el índice de la fila
                    indiceFila = row.Index

                    ' Ahora obtenemos el valor de otra columna, por ejemplo, "ID" (supongamos que la columna "ID" está en el índice 0)
                    Dim id As Integer = Convert.ToInt32(row.Cells("col_linea_o").Value)

                    Exit For
                End If
            End If
        Next
        ' Si no se encontró el valor
        If indiceFila = -1 Then
            MessageBox.Show("El valor no fue encontrado.")
            Return False
        Else

            dgOrdenado.Rows(indiceFila).Selected = True
            Return True

        End If


    End Function
    Public Function validaCorrelativo(ByVal valor As String) As Boolean

        Dim validaExistencia As Integer
        Dim fechaExiste As Date

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = ""

        Dim empresaId As Integer = Sesion.IdEmpresa
        Dim CajaAno As Integer = celdaAnio.Text   'col_ano INVISIBLE
        Dim CajaNum As Integer = celdaNumero.Text     'Linea

        Try
            strSQL = " SELECT DDoc_Doc_Num, DDoc_RF1_Fec fecha, COUNT(DDoc_Doc_Num) existe FROM Dcmtos_DTL  "
            strSQL &= " WHERE DDoc_Sis_Emp = " & empresaId & " AND DDoc_Doc_Cat = 776 AND DDoc_Doc_Ano = " & CajaAno & " AND DDoc_Doc_Num= " & CajaNum & " AND DDoc_RF1_Cod = '" & valor & "' GROUP BY DDoc_Doc_Num "

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    validaExistencia = REA.GetInt32("existe")
                    fechaExiste = REA.GetString("fecha")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        ' Si no se encontró el valor
        If validaExistencia > 0 Then
            MessageBox.Show("El correlativo ya existe, en fecha: " & fechaExiste)
            Return False
        Else
            Return True
        End If


    End Function

    Public Function obtenerIdLinea() As Integer

        Dim IdNum As Integer

        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = ""

        Dim empresaId As Integer = Sesion.IdEmpresa
        Dim CajaAno As Integer = celdaAnio.Text   'col_ano INVISIBLE
        Dim CajaNum As Integer = celdaNumero.Text 'Linea

        Try
            strSQL = " SELECT IFNULL(MAX(DDoc_Doc_Lin),0) + 1 ID FROM Dcmtos_DTL  "
            strSQL &= " WHERE DDoc_Sis_Emp = " & empresaId & " AND DDoc_Doc_Cat = 776 AND DDoc_Doc_Ano = " & CajaAno & " AND DDoc_Doc_Num = " & CajaNum

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IdNum = REA.GetInt32("ID")
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        ' Si no se encontró el valor
        If IdNum <= 0 Then
            MessageBox.Show("Error al guardar pallets")
            Return 0
        Else
            Return IdNum
        End If


    End Function

    Function ObtenerRango() As Tuple(Of Integer, Integer)
        ' Solicitar al usuario que ingrese un rango de números
        Dim rango As String = InputBox("Introduce el rango de números (por ejemplo, 25-49):", "Entrada de Datos", "")

        ' Verificar que el rango contiene un guion "-" para separar las dos cantidades
        If rango.Contains("-") Then
            ' Separar las dos cantidades usando el guion como delimitador
            Dim partes() As String = rango.Split("-"c)

            ' Verificar que se hayan ingresado exactamente dos números
            If partes.Length = 2 Then
                Dim numero1 As Integer
                Dim numero2 As Integer

                ' Intentar convertir las partes a números enteros
                If Integer.TryParse(partes(0), numero1) AndAlso Integer.TryParse(partes(1), numero2) Then
                    ' Verificar que el primer número sea menor o igual al segundo
                    If numero1 <= numero2 Then
                        ' Devolver los dos números como una tupla
                        Return Tuple.Create(numero1, numero2)
                    Else
                        MessageBox.Show("El primer número debe ser menor o igual que el segundo.")
                        Return Nothing ' Retorna Nothing si el rango no es válido
                    End If
                Else
                    MessageBox.Show("Por favor ingresa dos números válidos.")
                    Return Nothing ' Retorna Nothing si no se pueden convertir las partes a números
                End If
            Else
                MessageBox.Show("Por favor ingresa un rango válido con dos números separados por un guion.")
                Return Nothing ' Retorna Nothing si no se ingresan dos números
            End If
        Else
            MessageBox.Show("Por favor ingresa un rango en el formato 'numero1-numero2'.")
            Return Nothing ' Retorna Nothing si el formato no es correcto
        End If
    End Function


#End Region
End Class