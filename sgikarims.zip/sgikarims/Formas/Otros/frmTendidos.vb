﻿Public Class frmTendidos

#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Funciones y Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Reset()
        dtpFecha.Value = Today
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = NO_FILA
        celdaReferencia.Text = STR_VACIO
        celdaPrecioPromedio.Text = INT_CERO
        dgDetalle.Rows.Clear()
        dgBultos.Rows.Clear()
        celdaBultos.Text = INT_CERO
        celdaPesoBruto.Text = INT_CERO
        celdaPesoNeto.Text = INT_CERO
        celdaTotal.Text = INT_CERO
        celdaTara.Text = INT_CERO
        celdaIdMoneda.Text = 178 'dolares
        celdaMoneda.Text = "USD $"
        celdaTasa.Text = cFunciones.QueryTasa()
        radioBultos.Checked = True
        radioBultos.Enabled = True
        radioReferencia.Enabled = True

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        Try
            If logMostrar = True Then

                'ocultar panel de documento
                panelDocumento.Dock = DockStyle.None
                panelDocumento.Visible = False
                'actualizar Titulo
                BarraTitulo1.CambiarTitulo(" List ")
                'Cargar Datos
                CargarLista()
                'Mostrar Panel FiltroL
                panelLista.Visible = True
                panelLista.Dock = DockStyle.Fill
                BloquearBotones()
                Me.Tag = ""
            Else
                'Verifica si se va a crear un nuevo documento o se va modifica
                If logInsert = False Then
                    BarraTitulo1.CambiarTitulo("Update")
                    Me.Tag = "mod"
                    BloquearBotones(False)
                    ' botonInprimir.Enabled = True
                    'Ocultar Panel Filtro
                    panelLista.Visible = False
                    panelLista.Dock = DockStyle.None
                    'Mostrar panel de documento
                    panelDocumento.Dock = DockStyle.Fill
                    panelDocumento.Visible = True
                Else
                    ' If ConfigurarForma() = True Then
                    BarraTitulo1.CambiarTitulo("New ")
                    Me.Tag = "Nuevo"
                    BloquearBotones(False)
                    '   botonInprimir.Enabled = False
                    Reset()
                    'Ocultar Panel Filtro
                    panelLista.Visible = False
                    panelLista.Dock = DockStyle.None
                    'Mostrar panel de documento
                    panelDocumento.Dock = DockStyle.Fill
                    panelDocumento.Visible = True
                    ' End If

                    dgLista.DataSource = Nothing
                End If


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " Select h.HDoc_Sis_Emp Empresa, h.HDoc_Doc_Cat Catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num Referencia, h.HDoc_RF2_Txt Producto, h.HDoc_Doc_Status estatus, h.HDoc_Ant_Com tipo "
        strSQL &= "     From Dcmtos_HDR h"
        strSQL &= "         Where h.HDoc_Sis_Emp= {empresa} AND h.HDoc_Doc_Cat = 952 "

        If checkFecha.Checked = True Then

            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        End If
        strSQL &= " order by Anio desc,Numero desc ,fecha desc"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


        Return strSQL
    End Function

    Private Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Producto") & "|"
                    strFila &= REA.GetInt32("tipo")


                    If REA.GetInt32("estatus") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        If REA.GetInt32("tipo") = 0 Then
                            cFunciones.AgregarFila(dgLista, strFila)
                        Else
                            cFunciones.AgregarFila(dgLista, strFila, Color.LightSkyBlue)
                        End If

                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MarcarParaBorrar()
        Try
            For i As Integer = 0 To dgBultos.Rows.Count - 1
                dgBultos.Rows(i).Cells("colMarcaBB").Value = 2
                dgBultos.Rows(i).Visible = False
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ExisteDetalle(ByVal i As Integer) As Boolean
        Dim logExiste As Boolean = False
        Try
        For j As Integer = INT_CERO To dgDetalle.Rows.Count - 1
            logExiste = False
            If dgDetalle.Rows(j).Cells("colLLaveD").Value = dgBultos.Rows(i).Cells("colLLave2B").Value Then
                'Acumular Cantidadd
                dgDetalle.Rows(j).Cells("colCantidadD").Value = CDbl(dgDetalle.Rows(j).Cells("colCantidadD").Value) + CDbl(dgBultos.Rows(i).Cells("colPesoNetoB").Value)
                'Acumular Total
                dgDetalle.Rows(j).Cells("colTotalD").Value = dgDetalle.Rows(j).Cells("colTotalD").Value + (dgBultos.Rows(i).Cells("colPesoNetoB").Value * dgBultos.Rows(i).Cells("colPrecioB").Value)
                'Contar Bultos
                dgDetalle.Rows(j).Cells("colPacasD").Value = dgDetalle.Rows(j).Cells("colPacasD").Value + INT_UNO
                dgDetalle.Rows(j).Visible = True

                dgDetalle.Rows(j).Cells("colMedidaD").Value = dgBultos.Rows(i).Cells("colMedidaB").Value
                    If dgDetalle.Rows(j).Cells("colLineaTendido").Value = INT_CERO Then
                        dgDetalle.Rows(j).Cells("colMarcaDD").Value = "0"
                    Else
                        dgDetalle.Rows(j).Cells("colMarcaDD").Value = "1"
                    End If

                logExiste = True
                Exit For
            End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logExiste
    End Function

    Private Sub LLenarDetalle()

        Dim strFila As String = STR_VACIO
        Dim LogExiste As Boolean = False
        Try
            ResetDetalle()

            For i As Integer = INT_CERO To dgBultos.Rows.Count - 1
                If dgBultos.Rows(i).Cells("colMarcaBB").Value < 2 Then ' solo lineas visibles
                    If ExisteDetalle(i) = False Then

                        'Agregar Linea
                        strFila = dgBultos.Rows(i).Cells("colAnoB").Value & "|"
                        strFila &= dgBultos.Rows(i).Cells("colNumeroB").Value & "|"
                        strFila &= dgBultos.Rows(i).Cells("colLineaB").Value & "|"
                        strFila &= " 0|"
                        strFila &= dgBultos.Rows(i).Cells("colDescripcionB").Value & "|"
                        strFila &= dgBultos.Rows(i).Cells("colPrecioB").Value & "|"
                        strFila &= dgBultos.Rows(i).Cells("colPesoNetoB").Value & "|"
                        strFila &= dgBultos.Rows(i).Cells("colMedidaB").Value & "|"
                        strFila &= (dgBultos.Rows(i).Cells("colPrecioB").Value * dgBultos.Rows(i).Cells("colPesoNetoB").Value) & "|"
                        strFila &= dgBultos.Rows(i).Cells("colReferenciaB").Value & "|"
                        strFila &= "1|"
                        strFila &= dgBultos.Rows(i).Cells("colLLave2B").Value & "|"
                        strFila &= "0"

                        cFunciones.AgregarFila(dgDetalle, strFila)

                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ResetDetalle()
        For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
            dgDetalle.Rows(i).Cells("colCantidadD").Value = 0
            dgDetalle.Rows(i).Cells("colPacasD").Value = 0
            dgDetalle.Rows(i).Cells("colTotalD").Value = 0
            dgDetalle.Rows(i).Cells("colMarcaDD").Value = 2
            dgDetalle.Rows(i).Visible = False
        Next
    End Sub

    Private Sub CalcularTotalesPorBulto()
        Dim dblNeto As Double = 0
        Dim dblBruto As Double = 0
        Dim dblTara As Double = 0
        Dim dblTotal As Double = 0
        Dim intBultos As Integer = 0

        Try
            For i As Integer = INT_CERO To dgBultos.Rows.Count - 1
                If CInt(dgBultos.Rows(i).Cells("colMarcaBB").Value) < 2 Then

                    dblNeto = dblNeto + dgBultos.Rows(i).Cells("colPesoNetoB").Value
                    dblBruto = dblBruto + dgBultos.Rows(i).Cells("colPesoBrutoB").Value
                    dblTara = dblTara + dgBultos.Rows(i).Cells("colTaraB").Value
                    dblTotal = dblTotal + (dgBultos.Rows(i).Cells("colPesoNetoB").Value * dgBultos.Rows(i).Cells("colPrecioB").Value)
                    intBultos = intBultos + 1

                End If
            Next

            celdaPesoNeto.Text = dblNeto.ToString(FORMATO_MONEDA)
            celdaPesoBruto.Text = dblBruto.ToString(FORMATO_MONEDA)
            celdaTara.Text = dblTara.ToString(FORMATO_MONEDA)
            celdaBultos.Text = intBultos
            celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            celdaPrecioPromedio.Text = Math.Round((dblTotal / dblNeto), 4)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularTotalesPorDetalle()
        Dim dblNeto As Double = 0
        Dim dblBruto As Double = 0
        Dim dblTara As Double = 0
        Dim dblTotal As Double = 0
        Dim intBultos As Integer = 0

        Try
            For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
                If CInt(dgDetalle.Rows(i).Cells("colMarcaDD").Value) < 2 Then

                    dblNeto = dblNeto + dgDetalle.Rows(i).Cells("colCantidadD").Value
                    dblBruto = dblBruto + dgDetalle.Rows(i).Cells("colCantidadD").Value
                    dblTara = 0
                    dblTotal = dblTotal + (dgDetalle.Rows(i).Cells("colCantidadD").Value * dgDetalle.Rows(i).Cells("colPrecioD").Value)
                    intBultos = intBultos + dgDetalle.Rows(i).Cells("colPacasD").Value

                End If
            Next

            celdaPesoNeto.Text = dblNeto.ToString(FORMATO_MONEDA)
            celdaPesoBruto.Text = dblBruto.ToString(FORMATO_MONEDA)
            celdaTara.Text = dblTara.ToString(FORMATO_MONEDA)
            celdaBultos.Text = intBultos
            celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            celdaPrecioPromedio.Text = Math.Round((dblTotal / dblNeto), 4)


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logResultado As Boolean = True
        Try
            If cFunciones.ValidarCampoTexto(celdaReferencia) = False Then
                logResultado = False
            End If
            If cFunciones.ValidarCampoNumerico(celdaPrecioPromedio) = False Then
                logResultado = False
            End If
            If dgDetalle.Rows.Count = INT_CERO Then
                logResultado = False
            End If
            If radioBultos.Checked = True Then
                If dgBultos.Rows.Count = INT_CERO Then
                    logResultado = False
                End If
            End If
            
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub GuardaEncabezado()
        Dim CHDR As New clsDcmtos_HDR
        Try

            CHDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            CHDR.HDOC_DOC_CAT = 952
            CHDR.HDOC_DOC_ANO = celdaAnio.Text
            CHDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            CHDR.HDOC_DOC_MON = celdaIdMoneda.Text
            CHDR.HDOC_DOC_TC = celdaTasa.Text
            CHDR.HDOC_DR1_NUM = celdaReferencia.Text
            CHDR.HDOC_DOC_STATUS = INT_UNO
            If radioBultos.Checked = True Then
                CHDR.HDOC_ANT_COM = INT_CERO
            Else
                CHDR.HDOC_ANT_COM = INT_UNO
            End If
            CHDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                celdaNumero.Text = cFunciones.NuevoId(952)
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Guardar = False Then
                    MsgBox(CHDR.MERROR.ToString)
                End If
            Else
                CHDR.HDOC_DOC_NUM = celdaNumero.Text
                If CHDR.Actualizar = False Then
                    MsgBox(CHDR.MERROR.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function NuevaLinea() As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select ifnull(max(d.DDoc_Doc_Lin ),0)+1 from Dcmtos_DTL d "
            strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 952 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function

    Private Sub GuardarDetalle()
        Dim cDTL As New clsDcmtos_DTL
        Try
            For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
                cDTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                cDTL.DDOC_DOC_CAT = 952
                cDTL.DDOC_DOC_ANO = celdaAnio.Text
                cDTL.DDOC_DOC_NUM = celdaNumero.Text

                cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaTendido").Value
                'TODO CODIGO DE PRODUCTO
                cDTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcionD").Value
                cDTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecioD").Value
                cDTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidadD").Value
                'TODO ID MEDIDA
                cDTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colReferenciaD").Value


                If dgDetalle.Rows(i).Cells("colMarcaDD").Value = 0 Then             ' INSERTAR
                    dgDetalle.Rows(i).Cells("colLineaTendido").Value = NuevaLinea()
                    cDTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaTendido").Value
                    cDTL.CONEXION = strConexion
                    If cDTL.Guardar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colMarcaDD").Value = 1 Then ' ACTUALIZAR
                    cDTL.CONEXION = strConexion
                    If cDTL.Actualizar = False Then
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                Else
                    cDTL.CONEXION = strConexion
                    If cDTL.Borrar = False Then                                      ' BORRAR
                        MsgBox(cDTL.MERROR.ToString)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarPro()
        Dim cPro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = INT_CERO To dgDetalle.Rows.Count - 1
                cPro.PDOC_SIS_EMP = Sesion.IdEmpresa

                cPro.PDOC_PAR_CAT = 47
                cPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnoD").Value
                cPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNumeroD").Value
                cPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLineaD").Value

                cPro.PDOC_CHI_CAT = 952
                cPro.PDOC_CHI_ANO = celdaAnio.Text
                cPro.PDOC_CHI_NUM = celdaNumero.Text
                cPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLineaTendido").Value
                cPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidadD").Value

                cPro.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colMarcaDD").Value = 0 Then             ' INSERTAR
                    If cPro.Guardar = False Then
                        MsgBox(cPro.MERROR.ToString)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colMarcaDD").Value = 1 Then          ' ACTUALIZAR
                    If cPro.Actualizar = False Then
                        MsgBox(cPro.MERROR.ToString)
                    End If
                Else
                    If cPro.Borrar = False Then                                      ' BORRAR
                        MsgBox(cPro.MERROR.ToString)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub GuardarProBultos()
        Dim cBoxP As New Tablas.TDCMTOS_DTL_BOX_PRO
        Try
            For i As Integer = INT_CERO To dgBultos.Rows.Count - 1

                cBoxP.BPDOC_SIS_EMP = Sesion.IdEmpresa
                cBoxP.BPDOC_PAR_CAT = 47
                cBoxP.BPDOC_PAR_ANO = dgBultos.Rows(i).Cells("colAnoB").Value
                cBoxP.BPDOC_PAR_NUM = dgBultos.Rows(i).Cells("colNumeroB").Value
                cBoxP.BPDOC_PAR_LIN = dgBultos.Rows(i).Cells("colLineaB").Value
                cBoxP.BPDOC_BOX_LIN = dgBultos.Rows(i).Cells("colLineaBultoB").Value
                cBoxP.BPDOC_CHI_CAT = 952
                cBoxP.BPDOC_CHI_ANO = celdaAnio.Text
                cBoxP.BPDOC_CHI_NUM = celdaNumero.Text
                cBoxP.BPDOC_CHI_LIN = INT_UNO

                cBoxP.CONEXION = strConexion
                If dgBultos.Rows(i).Cells("colMarcaBB").Value = INT_CERO Then
                    If cBoxP.PINSERT = False Then
                        MsgBox(cBoxP.MERROR.ToString)
                    End If
                ElseIf dgBultos.Rows(i).Cells("colMarcaBB").Value = 2 Then
                    If cBoxP.PDELETE = False Then
                        MsgBox(cBoxP.MERROR.ToString)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SqlDetalle(ByVal ano As Integer, ByVal num As Integer) As String
        Dim strSQl As String = STR_VACIO
        Try
            strSQl = " select p.PDoc_Par_Ano Ano, p.PDoc_Par_Num Numero, p.PDoc_Par_Lin Linea, d.DDoc_Doc_Lin LineaBulto, d.DDoc_Prd_Des Descripcion,d.DDoc_Prd_NET Precio,  d.DDoc_Prd_QTY Cantidad, (d.DDoc_Prd_NET *  d.DDoc_Prd_QTY) Total, d.DDoc_RF1_Cod Referencia, concat(p.PDoc_Par_Ano , p.PDoc_Par_Num , p.PDoc_Par_Lin ) LLave "
            strSQl &= "  from Dcmtos_DTL d "
            strSQl &= "   left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp = d.DDoc_Sis_Emp and p.PDoc_Chi_Cat = d.DDoc_Doc_Cat and p.PDoc_Chi_Ano = d.DDoc_Doc_Ano and p.PDoc_Chi_Num = d.DDoc_Doc_Num and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strSQl &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 952 and d.DDoc_Doc_Ano ={ano} and d.DDoc_Doc_Num = {numero} "

            strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{ano}", ano)
            strSQl = Replace(strSQl, "{numero}", num)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQl
    End Function

    Private Sub CargarDetalle(ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SqlDetalle(ano, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgDetalle.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("Ano").ToString & "|"
                    strFila &= REA.GetInt32("Numero").ToString & "|"
                    strFila &= REA.GetInt32("Linea").ToString & "|"
                    strFila &= REA.GetInt32("LineaBulto").ToString & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= "medida|"

                    strFila &= (REA.GetDouble("Precio") * REA.GetDouble("Cantidad")) & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= "1|"
                    strFila &= REA.GetString("LLave") & "|"
                    strFila &= "1"

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SqlBultos(ByVal ano As Integer, ByVal num As Integer) As String
        Dim strSQl As String = STR_VACIO
        Try
            strSQl = " select b.BDoc_Doc_Ano Ano, b.BDoc_Doc_Num Numero, b.BDoc_Doc_Lin Linea, b.BDoc_Box_Lin LineaBulto , b.BDoc_Box_Hsm Correlativo, b.BDoc_Box_Cod Marca , h.HDoc_DR1_Num Referencia, d.DDoc_Prd_Des  Descripcion,  b.BDoc_Box_LB PesoNeto , (b.BDoc_Box_LBExt - b.BDoc_Box_LB ) Tara, b.BDoc_Box_LBExt PesoBruto , d.DDoc_Prd_NET Precio , c.cat_clave  Medida, b.BDoc_Box_Ctg Categoria , concat(b.BDoc_Doc_Ano , b.BDoc_Doc_Num , b.BDoc_Doc_Lin , b.BDoc_Box_Lin)LLave ,  concat(b.BDoc_Doc_Ano , b.BDoc_Doc_Num , b.BDoc_Doc_Lin )  LLave2  "
            strSQl &= "  from Dcmtos_DTL_Box_Pro p  "
            strSQl &= "  left join Dcmtos_DTL_Box b on b.BDoc_Sis_Emp = p.BPDoc_Sis_Emp and b.BDoc_Doc_Cat = p.BPDoc_Par_Cat and b.BDoc_Doc_Ano = p.BPDoc_Par_Ano and b.BDoc_Doc_Num = p.BPDoc_Par_Num and b.BDoc_Doc_Lin = p.BPDoc_Par_Lin and b.BDoc_Box_Lin = p.BPDoc_Box_Lin  "
            strSQl &= "  left join Dcmtos_DTL d on d.DDoc_Sis_Emp = b.BDoc_Sis_Emp and d.DDoc_Doc_Cat = b.BDoc_Doc_Cat and d.DDoc_Doc_Ano = b.BDoc_Doc_Ano and d.DDoc_Doc_Num = b.BDoc_Doc_Num and  d.DDoc_Doc_Lin = b.BDoc_Doc_Lin  "
            strSQl &= "  left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQl &= "  left join Catalogos c on c.cat_num = d.DDoc_Prd_UM "
            strSQl &= " where p.BPDoc_Sis_Emp = {empresa} and p.BPDoc_Chi_Cat = 952 and p.BPDoc_Chi_Ano = {ano} and p.BPDoc_Chi_Num = {numero} "

            strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{ano}", ano)
            strSQl = Replace(strSQl, "{numero}", num)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSQl
    End Function

    Private Sub CargarBultos(ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SqlBultos(ano, num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgBultos.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("Ano").ToString & "|"
                    strFila &= REA.GetInt32("Numero").ToString & "|"
                    strFila &= REA.GetInt32("Linea").ToString & "|"
                    strFila &= REA.GetInt32("LineaBulto").ToString & "|"
                    strFila &= REA.GetString("Correlativo").ToString & "|"
                    strFila &= REA.GetString("Marca") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("PesoNeto") & "|"
                    strFila &= REA.GetDouble("Tara") & "|"
                    strFila &= REA.GetDouble("PesoBruto") & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetString("Categoria") & "|"
                    strFila &= REA.GetString("LLave") & "|"
                    strFila &= "1|"
                    strFila &= REA.GetString("LLave2")

                    cFunciones.AgregarFila(dgBultos, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarEncabezado(ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = " select h.HDoc_Doc_Ano Anio , h.HDoc_Doc_Num Numero , h.HDoc_Doc_Fec Fecha , h.HDoc_Doc_Mon idMoneda, h.HDoc_Doc_TC Tasa, h.HDoc_DR1_Num Referencia, c.cat_clave Moneda, h.HDoc_Ant_Com tipo  "
            strSQL &= "   from Dcmtos_HDR h  left join Catalogos c on c.cat_num = h.HDoc_Doc_Mon "
            strSQL &= "  where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 952 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read
                celdaAnio.Text = REA.GetInt32("Anio").ToString
                celdaNumero.Text = REA.GetInt32("Numero").ToString
                celdaIdMoneda.Text = REA.GetInt32("idMoneda").ToString
                celdaMoneda.Text = REA.GetString("Moneda").ToString
                celdaTasa.Text = REA.GetDouble("Tasa").ToString
                celdaReferencia.Text = REA.GetString("Referencia").ToString
                dtpFecha.Value = REA.GetMySqlDateTime("Fecha")
                If REA.GetInt32("tipo") = 0 Then
                    radioBultos.Checked = True
                Else
                    radioBultos.Checked = False
                End If

                radioBultos.Enabled = False
                radioReferencia.Enabled = False
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Seleccionar(ByVal ano As Integer, ByVal num As Integer, ByVal tipo As Integer)
        Reset()
        CargarEncabezado(ano, num)
        CargarDetalle(ano, num)
        If tipo = INT_CERO Then ' por pacas
            CargarBultos(ano, num)
            LLenarDetalle()
            CalcularTotalesPorBulto()
        Else
            CalcularTotalesPorDetalle()
        End If

    End Sub
#End Region

    Private Sub frmTendidos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmTendidos_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFin.Value = Today
        dtpInicio.Value = dtpFin.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarDatos() Then
            GuardaEncabezado()
            GuardarDetalle()
            GuardarPro()
            If radioBultos.Checked = True Then
                GuardarProBultos()
            End If
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
    End Sub

    Private Sub botonProducto_Click(sender As Object, e As EventArgs) Handles botonProducto.Click
        Dim frm As New frmTendidosBultos
        Dim strFila As String = STR_VACIO
        Dim logExiste As Boolean = False
        Try
            For i As Integer = INT_CERO To dgBultos.Rows.Count - 1
                If dgBultos.Rows(i).Cells("colMarcaBB").Value < 2 Then
                    strFila = dgBultos.Rows(i).Cells("colAnoB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colNumeroB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colLineaB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colLineaBultoB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colCorrelativoB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colMarcaB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colReferenciaB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colDescripcionB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colPesoNetoB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colTaraB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colPesoBrutoB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colPreciob").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colMedidaB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colCategoriaB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colLLaveB").Value & "|"
                    strFila &= dgBultos.Rows(i).Cells("colLLave2B").Value

                    cFunciones.AgregarFila(frm.dgPacasSeleccionadas, strFila)
                End If
            Next

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                MarcarParaBorrar()
                Try
                    For i As Integer = INT_CERO To frm.dgPacasSeleccionadas.Rows.Count - 1
                        logExiste = False
                        For j As Integer = INT_CERO To dgBultos.Rows.Count - 1
                            If frm.dgPacasSeleccionadas.Rows(i).Cells("colLlaveS").Value = dgBultos.Rows(j).Cells("colLLaveB").Value Then
                                dgBultos.Rows(j).Cells("colMarcaBB").Value = 1
                                dgBultos.Rows(j).Visible = True
                                logExiste = True
                                Exit For
                            End If
                        Next
                        If logExiste = False Then
                            strFila = frm.dgPacasSeleccionadas.Rows(i).Cells("colAnoS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colNumeroS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colLineaS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colLienaBultoS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colCorrelativoS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colMarcaS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colReferenciaS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colDescripcionS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colPesoNetoS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colTaraS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colPesoBrutoS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colPrecioS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colMedida").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colCategoriaS").Value & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colLlaveS").Value & "|"
                            strFila &= "0" & "|"
                            strFila &= frm.dgPacasSeleccionadas.Rows(i).Cells("colLlave2S").Value
                            cFunciones.AgregarFila(dgBultos, strFila)
                        End If
                    Next

                    LLenarDetalle()

                    CalcularTotalesPorBulto()
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        If dgLista.Rows.Count > 0 Then
            Seleccionar(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value, dgLista.SelectedCells(6).Value)
            MostrarLista(False, False)
        End If
    End Sub

    Private Sub radioBultos_CheckedChanged(sender As Object, e As EventArgs) Handles radioBultos.CheckedChanged
        If radioBultos.Checked = True Then
            radioBultos.BackColor = Color.Blue
            radioBultos.ForeColor = Color.White

            radioReferencia.BackColor = Nothing
            radioReferencia.ForeColor = Color.Black

            botonProducto.Visible = True
            botonAgregar.Visible = False
            botonQuitar.Visible = False
        Else
            radioReferencia.BackColor = Color.Green
            radioReferencia.ForeColor = Color.White

            radioBultos.BackColor = Nothing
            radioBultos.ForeColor = Color.Black

            botonProducto.Visible = False
            botonAgregar.Visible = True
            botonQuitar.Visible = True
        End If
        ' Reset()
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmInventarioTendido
        Dim logExiste As Boolean = False
        Dim strFila As String = STR_VACIO
        Try
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                For i As Integer = 0 To frm.dgLista.Rows.Count - 1
                    logExiste = False
                    If CDbl(frm.dgLista.Rows(i).Cells("colDescargoI").Value) > 0 Then
                        For j As Integer = 0 To dgDetalle.Rows.Count - 1
                            If dgDetalle.Rows(j).Cells("colLLaveD").Value = frm.dgLista.Rows(i).Cells("colLlaveI").Value Then
                                logExiste = True
                                dgDetalle.Rows(j).Cells("colCantidad").Value = frm.dgLista.Rows(i).Cells("colDescargoI").Value
                                dgDetalle.Rows(j).Cells("colPacasD").Value = frm.dgLista.Rows(i).Cells("colBultosDI").Value
                                dgDetalle.Rows(j).Cells("colTotalD").Value = (frm.dgLista.Rows(i).Cells("colPrecioI").Value * frm.dgLista.Rows(i).Cells("colDescargoI").Value)
                                Exit For
                            End If
                        Next
                        If logExiste = False Then
                            strFila = frm.dgLista.Rows(i).Cells("colAnoI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colNumeroI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colLineaI").Value & "|"
                            strFila &= " 0|"
                            strFila &= frm.dgLista.Rows(i).Cells("colDescripcionI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colPrecioI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colDescargoI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colMedidaI").Value & "|"
                            strFila &= (frm.dgLista.Rows(i).Cells("colPrecioI").Value * frm.dgLista.Rows(i).Cells("colDescargoI").Value) & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colReferenciaI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colBultosDI").Value & "|"
                            strFila &= frm.dgLista.Rows(i).Cells("colLLaveI").Value & "|"
                            strFila &= "0"

                            cFunciones.AgregarFila(dgDetalle, strFila)
                        End If
                    End If
                Next
                CalcularTotalesPorDetalle()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        Try
            If MsgBox("Are you sure, do you want to delete this row?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                dgDetalle.CurrentRow.Cells("colMarcaDD").Value = 2
                dgDetalle.CurrentRow.Visible = False
            End If
           
        Catch ex As Exception
            ' MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub
End Class