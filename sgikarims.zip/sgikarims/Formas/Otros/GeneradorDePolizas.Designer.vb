﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GeneradorDePolizas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.checkGenerar = New System.Windows.Forms.CheckBox()
        Me.botonCerrar = New System.Windows.Forms.Button()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.botonGenerador = New System.Windows.Forms.Button()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechaFin = New System.Windows.Forms.Label()
        Me.etiquetaFechaInicio = New System.Windows.Forms.Label()
        Me.botonDocumento = New System.Windows.Forms.Button()
        Me.etiquetaDocumento = New System.Windows.Forms.Label()
        Me.celdaDocumento = New System.Windows.Forms.TextBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelDocumentos = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colHDoc_Doc_Num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.panelEncabezado.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.panelDocumentos.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.checkGenerar)
        Me.panelEncabezado.Controls.Add(Me.botonCerrar)
        Me.panelEncabezado.Controls.Add(Me.celdaCatalogo)
        Me.panelEncabezado.Controls.Add(Me.botonGenerador)
        Me.panelEncabezado.Controls.Add(Me.dtpInicio)
        Me.panelEncabezado.Controls.Add(Me.dtpFin)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFechaFin)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFechaInicio)
        Me.panelEncabezado.Controls.Add(Me.botonDocumento)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDocumento)
        Me.panelEncabezado.Controls.Add(Me.celdaDocumento)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 55)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(856, 149)
        Me.panelEncabezado.TabIndex = 1
        '
        'checkGenerar
        '
        Me.checkGenerar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkGenerar.AutoSize = True
        Me.checkGenerar.Checked = True
        Me.checkGenerar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkGenerar.Location = New System.Drawing.Point(688, 117)
        Me.checkGenerar.Name = "checkGenerar"
        Me.checkGenerar.Size = New System.Drawing.Size(152, 21)
        Me.checkGenerar.TabIndex = 8
        Me.checkGenerar.Text = "Generación Masiva"
        Me.checkGenerar.UseVisualStyleBackColor = True
        '
        'botonCerrar
        '
        Me.botonCerrar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.botonCerrar.Location = New System.Drawing.Point(762, 7)
        Me.botonCerrar.Name = "botonCerrar"
        Me.botonCerrar.Size = New System.Drawing.Size(78, 52)
        Me.botonCerrar.TabIndex = 11
        Me.botonCerrar.Text = "Close"
        Me.botonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCerrar.UseVisualStyleBackColor = True
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(550, 49)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(61, 22)
        Me.celdaCatalogo.TabIndex = 8
        Me.celdaCatalogo.Visible = False
        '
        'botonGenerador
        '
        Me.botonGenerador.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open
        Me.botonGenerador.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonGenerador.Location = New System.Drawing.Point(617, 83)
        Me.botonGenerador.Name = "botonGenerador"
        Me.botonGenerador.Size = New System.Drawing.Size(96, 55)
        Me.botonGenerador.TabIndex = 7
        Me.botonGenerador.Text = "Generar Polizas"
        Me.botonGenerador.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGenerador.UseVisualStyleBackColor = True
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(209, 92)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(134, 22)
        Me.dtpInicio.TabIndex = 5
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(401, 92)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(123, 22)
        Me.dtpFin.TabIndex = 6
        '
        'etiquetaFechaFin
        '
        Me.etiquetaFechaFin.AutoSize = True
        Me.etiquetaFechaFin.Location = New System.Drawing.Point(350, 97)
        Me.etiquetaFechaFin.Name = "etiquetaFechaFin"
        Me.etiquetaFechaFin.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaFechaFin.TabIndex = 4
        Me.etiquetaFechaFin.Text = "Hasta"
        '
        'etiquetaFechaInicio
        '
        Me.etiquetaFechaInicio.AutoSize = True
        Me.etiquetaFechaInicio.Location = New System.Drawing.Point(21, 97)
        Me.etiquetaFechaInicio.Name = "etiquetaFechaInicio"
        Me.etiquetaFechaInicio.Size = New System.Drawing.Size(182, 17)
        Me.etiquetaFechaInicio.TabIndex = 3
        Me.etiquetaFechaInicio.Text = "Mostrar Documentos desde"
        '
        'botonDocumento
        '
        Me.botonDocumento.Image = Global.KARIMs_SGI.My.Resources.Resources.search
        Me.botonDocumento.Location = New System.Drawing.Point(659, 19)
        Me.botonDocumento.Name = "botonDocumento"
        Me.botonDocumento.Size = New System.Drawing.Size(54, 23)
        Me.botonDocumento.TabIndex = 4
        Me.botonDocumento.UseVisualStyleBackColor = True
        '
        'etiquetaDocumento
        '
        Me.etiquetaDocumento.AutoSize = True
        Me.etiquetaDocumento.Location = New System.Drawing.Point(21, 22)
        Me.etiquetaDocumento.Name = "etiquetaDocumento"
        Me.etiquetaDocumento.Size = New System.Drawing.Size(132, 17)
        Me.etiquetaDocumento.TabIndex = 1
        Me.etiquetaDocumento.Text = "Tipo de Documento"
        '
        'celdaDocumento
        '
        Me.celdaDocumento.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDocumento.Location = New System.Drawing.Point(175, 19)
        Me.celdaDocumento.Name = "celdaDocumento"
        Me.celdaDocumento.ReadOnly = True
        Me.celdaDocumento.Size = New System.Drawing.Size(478, 22)
        Me.celdaDocumento.TabIndex = 0
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonQuitar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(774, 204)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(82, 302)
        Me.panelBotones.TabIndex = 2
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(18, 85)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(51, 39)
        Me.botonQuitar.TabIndex = 10
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(18, 17)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(51, 39)
        Me.botonAgregar.TabIndex = 9
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelDocumentos
        '
        Me.panelDocumentos.Controls.Add(Me.dgDocumentos)
        Me.panelDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumentos.Location = New System.Drawing.Point(0, 204)
        Me.panelDocumentos.Name = "panelDocumentos"
        Me.panelDocumentos.Size = New System.Drawing.Size(774, 302)
        Me.panelDocumentos.TabIndex = 3
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.AllowUserToOrderColumns = True
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colHDoc_Doc_Num, Me.colFecha, Me.colNumero})
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumentos.MultiSelect = False
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.RowTemplate.Height = 24
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(774, 302)
        Me.dgDocumentos.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Año"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colHDoc_Doc_Num
        '
        Me.colHDoc_Doc_Num.HeaderText = "HDoc_Doc_Num"
        Me.colHDoc_Doc_Num.Name = "colHDoc_Doc_Num"
        Me.colHDoc_Doc_Num.ReadOnly = True
        Me.colHDoc_Doc_Num.Visible = False
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Fecha"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Numero"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 0)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(856, 55)
        Me.BarraTitulo1.TabIndex = 0
        '
        'GeneradorDePolizas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(856, 506)
        Me.Controls.Add(Me.panelDocumentos)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.panelEncabezado)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Name = "GeneradorDePolizas"
        Me.Text = "GeneradorDePolizas"
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        Me.panelDocumentos.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFechaFin As Label
    Friend WithEvents etiquetaFechaInicio As Label
    Friend WithEvents botonDocumento As Button
    Friend WithEvents etiquetaDocumento As Label
    Friend WithEvents celdaDocumento As TextBox
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelDocumentos As Panel
    Friend WithEvents dgDocumentos As DataGridView
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents botonGenerador As Button
    Friend WithEvents botonCerrar As Button
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colHDoc_Doc_Num As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents checkGenerar As System.Windows.Forms.CheckBox
End Class
