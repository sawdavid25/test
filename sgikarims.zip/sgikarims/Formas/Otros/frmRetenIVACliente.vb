﻿Public Class frmRetenIVACliente

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, HDoc_Emp_Nom Nombre, IFNULL(HDoc_DR1_Num,'') Documento, IFNULL(HDoc_RF1_Cod,'') Referencia, HDoc_Doc_Status Estado, ifnull(f.NumeroAutorizacion,0) Autorizacion  "
        strSQL &= "    FROM Dcmtos_HDR "
        strSQL &= "    LEFT JOIN Fel f ON f.Empresa = HDoc_Sis_Emp AND f.Anio = HDoc_Doc_Ano AND f.Numero = HDoc_RF1_Cod AND f.Catalogo = 296 "
        strSQL &= "        WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=326   "
        If checkFecha.Checked = True Then
            strSQL &= " AND (HDoc_Doc_Fec BETWEEN '{inicio}' AND '{final}') "
            strSQL = Replace(strSQL, "{inicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{final}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strSQL &= "            ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function

    Private Function SQLCargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat cat, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod cod, h.HDoc_Emp_Nom proveedor, h.HDoc_Doc_Mon moneda, h.HDoc_Doc_TC TC, h.HDoc_RF1_Dbl total, h.HDoc_Pro_DCat catF, h.HDoc_Pro_DAno anioF, h.HDoc_Pro_DNum numF, h.HDoc_DR1_Num retencion, h.HDoc_RF1_Txt notas " ', HDoc_DR1_Cat tipoFac "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 326 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strSQL &= "            LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        Return strSQL
    End Function

    Private Function SQLCargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO

        If Sesion.IdEmpresa = 10 Then
            strSQL = " SELECT e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num Numero, e.HDoc_Doc_Fec Fecha, e.HDoc_Usuario Usuario, e.HDoc_DR1_Num Referencia, e.HDoc_RF1_Dbl Monto, e.HDoc_Doc_Mon moneda, e.HDoc_Doc_TC TC, f.NumeroAutorizacion Autorizacion "
            strSQL &= "    FROM ECtaCte c "
            strSQL &= "    INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.ECta_Sis_Emp AND e.HDoc_Doc_Cat = c.ECta_Ref_Cat AND e.HDoc_Doc_Ano = c.ECta_Ref_Ano AND e.HDoc_Doc_Num = c.ECta_Ref_Num "
            strSQL &= "    INNER JOIN Fel f ON f.Empresa = e.HDoc_Sis_Emp AND f.Anio = e.HDoc_Doc_Ano AND f.Numero = e.HDoc_Doc_Num AND f.Catalogo = 296 "
        Else
            strSQL = " SELECT e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num Numero, e.HDoc_Doc_Fec Fecha, e.HDoc_Usuario Usuario, h.HDoc_RF1_Cod, (d.DDoc_Prd_NET * d.DDoc_Prd_QTY * e.HDoc_Doc_TC) Monto, e.HDoc_Doc_Mon moneda, e.HDoc_Doc_TC TC, 0 Autorizacion
                            FROM ECtaCte c
                            INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.ECta_Sis_Emp AND e.HDoc_Doc_Cat = c.ECta_Ref_Cat AND e.HDoc_Doc_Ano = c.ECta_Ref_Ano AND e.HDoc_Doc_Num = c.ECta_Ref_Num
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = c.ECta_Sis_Emp AND h.HDoc_Doc_Cat = c.ECta_Doc_Cat AND h.HDoc_Doc_Ano = c.ECta_Doc_Ano AND h.HDoc_Doc_Num = c.ECta_Doc_Num"
        End If

        strSQL &= "        WHERE c.ECta_Sis_Emp = {empresa} AND c.ECta_Doc_Cat = 326 AND c.ECta_Doc_Ano = {anio} AND c.ECta_Doc_Num = {num} "
        strSQL &= "        ORDER BY e.HDoc_Doc_Fec DESC, e.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        'strSQL = Replace(strSQL, "{cod}", codigo)

        Return strSQL
    End Function

    Private Function SQLCargarPagos(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSLQ As String = STR_VACIO

        strSLQ = " SELECT d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_PNr Referencia, d.DDoc_Prd_PUQ Fraccion, d.DDoc_Prd_DSP Factor, d.DDoc_Prd_DSQ Base, d.DDoc_Prd_NET Total, d.DDoc_RF1_Dbl Monto, d.DDoc_RF1_Num Tipo, d.DDoc_RF2_Num Año, d.DDoc_RF3_Num Numero "
        strSLQ &= "    FROM Dcmtos_DTL d "
        strSLQ &= "        WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 326 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "
        strSLQ &= "            ORDER BY d.DDoc_Doc_Lin "

        strSLQ = Replace(strSLQ, "{empresa}", Sesion.IdEmpresa)
        strSLQ = Replace(strSLQ, "{anio}", intAnio)
        strSLQ = Replace(strSLQ, "{num}", intNum)

        Return strSLQ

    End Function

    Private Function SQLMostrarFacturas()
        Dim strSQL As String = STR_VACIO

        If Sesion.IdEmpresa = 10 Then
            strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, IFNULL(h.HDoc_DR2_Num,'') Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp, f.NumeroAutorizacion Autorizacion "
            strSQL &= "    From Dcmtos_HDR h "
            strSQL &= "        LEFT JOIN Dcmtos_DTL r ON r.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.DDoc_Doc_Cat = 326 AND r.DDoc_RF1_Num = h.HDoc_Doc_Cat AND r.DDoc_RF2_Num = h.HDoc_Doc_Ano AND r.DDoc_RF3_Num = h.HDoc_Doc_Num  "
            strSQL &= "           LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas' "
            strSQL &= "    INNER JOIN Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_Doc_Num AND f.Catalogo = 296 "
        Else
            strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, f.NumeroAutorizacion NumFac, IFNULL(f.Serie,'') Serie, (d.DDoc_Prd_Net * d.DDoc_Prd_QTY * h.HDoc_Doc_TC) Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp, 0 Autorizacion
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_DTL r ON r.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.DDoc_Doc_Cat = 326 AND r.DDoc_RF1_Num = h.HDoc_Doc_Cat AND r.DDoc_RF2_Num = h.HDoc_Doc_Ano AND r.DDoc_RF3_Num = h.HDoc_Doc_Num
                            LEFT JOIN Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Catalogo = h.HDoc_Doc_Cat AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_Doc_Num
                            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
        End If

        strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Emp_Cod ={cod} AND h.HDoc_Doc_Status = 1 AND h.HDoc_Doc_Fec > '{fecha}' AND r.DDoc_Sis_Emp IS NULL Order By h.HDoc_Doc_Fec DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cod}", celdaIdProveedor.Text)
        strSQL = Replace(strSQL, "{fecha}", DateSerial(Year(Date.Now), Month(Date.Now) - 4, 1).ToString(FORMATO_MYSQL))

        If Sesion.IdEmpresa = 10 Then
            strSQL = Replace(strSQL, "{cat}", 296)
        Else
            strSQL = Replace(strSQL, "{cat}", 36)
        End If

        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Documento") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetInt32("Estado") & "|"
                    strFila &= REA.GetString("Autorizacion")

                    If REA.GetInt32("Estado") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.LightBlue)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila)
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            BarraTitulo1.CambiarTitulo("IVA Withholding Customer")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Sub CargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLCargarEncabezado(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                REA.Read()

                celdaAnio.Text = REA.GetInt32("anio")
                dtpFechaDoc.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                celdaNumero.Text = REA.GetString("retencion")
                celdaProveedor.Text = REA.GetString("proveedor")
                celdaIdProveedor.Text = REA.GetInt32("cod")
                celdaMonto.Text = REA.GetDouble("total").ToString(FORMATO_MONEDA)
                celdaCatalogo.Text = REA.GetInt32("cat")
                celdaAnio.Text = REA.GetInt32("anio")
                celdaNumeroHDR.Text = REA.GetInt32("numero")
                celdaCatF.Text = REA.GetInt32("catF")
                celdaAnioF.Text = REA.GetInt32("anioF")
                celdaNumF.Text = REA.GetInt32("numF")
                celdaNotas.Text = REA.GetString("notas")
                'If REA.GetInt32("tipoFac") = 1 Then
                '    checkFacturaEspecial.Checked = True
                'Else
                '    checkFacturaEspecial.Checked = False
                'End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarFactura(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    If Sesion.IdEmpresa = 10 Then
                        strFila &= REA.GetString("Numero") & "|"
                    Else
                        strFila &= REA.GetString("HDoc_RF1_Cod") & "|"
                    End If
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= "Q/" & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    'If checkFacturaEspecial.Checked = True Then
                    '    strFila &= 1 & "|"
                    'Else
                    strFila &= 0 & "|"
                    'End If
                    strFila &= 1 & "|"
                    strFila &= REA.GetInt64("Autorizacion")

                    cFunciones.AgregarFila(dgFactura, strFila)
                    celdaIDMoneda.Text = cFunciones.DivisaLocal
                    celdaTipoCambio.Text = 1
                    If Sesion.IdEmpresa = 10 Then
                        celdaCatF.Text = 296
                    Else
                        celdaCatF.Text = 36
                    End If

                    celdaAnioF.Text = REA.GetInt32("anio")
                    celdaNumF.Text = REA.GetInt32("Numero")
                    celdaTCFactura.Text = REA.GetDouble("TC")
                    celdaMontoF.Text = REA.GetDouble("Monto")
                Loop
                celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarPago(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarPagos(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("Fraccion") & "|"
                    strFila &= REA.GetInt32("Factor") & "|"
                    strFila &= REA.GetDouble("Monto")

                    cFunciones.AgregarFila(dgDatos, strFila)
                Loop
                'celdaTotal.Text = CDbl(celdaMonto.Text) - CDbl(dgDatos.CurrentRow.Cells("colTota1").Value)
                'Else
                '    celdaTotal.Text = CDbl(celdaMonto.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub MostrarFacturas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLMostrarFacturas()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("HDoc_Usuario") & "|"
                    If Sesion.IdEmpresa = 10 Then
                        strFila &= REA.GetString("numero") & " " & REA.GetString("Serie") & "|"
                    Else
                        strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    End If
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    'strFila &= REA.GetInt32("FactEsp") & "|"
                    strFila &= 0 & "|" ' 1 actualizar, 0 insertar
                    strFila &= 1 & "|"
                    strFila &= REA.GetInt64("Autorizacion")

                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function FactorIVA(Optional clave As String = "IVA_Clt") As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim factor As Double = 0

        strSQL = " SELECT ROUND(a.cat_sist /100,2) factorIVA "
        strSQL &= "    From Catalogos a "
        strSQL &= "        WHERE a.cat_clase='Impuestos' AND a.cat_sisemp = 10 AND a.cat_clave = '{clave}' "

        strSQL = Replace(strSQL, "{clave}", clave)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        factor = COM.ExecuteScalar

        Return factor
    End Function

    Public Function VerificarIVA() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim IVA As Double = 0

        If Sesion.IdEmpresa = 10 Then
            strSQL = " SELECT IFNULL(SUM(MDoc_Lin_Monto),0) "
            strSQL &= "    From Dcmtos_IMP "
            strSQL &= "        WHERE MDoc_Sis_Emp={empresa} AND MDoc_Doc_Cat={cat} AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={num} AND MDoc_Lin_Tipo= 0 "

            strSQL = Replace(strSQL, "{cat}", 296)
        Else
            strSQL = " SELECT ROUND((d.DDoc_Prd_NET * d.DDoc_Prd_QTY * h.HDoc_Doc_TC ) - ((d.DDoc_Prd_NET * d.DDoc_Prd_QTY * h.HDoc_Doc_TC) / ((c.cat_sist /100)+1)),2) IVA
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Catalogos c ON c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa}
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL = Replace(strSQL, "{cat}", 36)
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnioF.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumF.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        IVA = COM.ExecuteScalar

        Return IVA
    End Function

    Public Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaAnioOc.Clear()
        celdaCatalogo.Text = 326
        celdaMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaNumero.Clear()
        celdaNumeroHDR.Text = -1
        celdaProveedor.Clear()
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFechaDoc.Text = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaMoneda.Clear()
        celdaIDMoneda.Clear()
        celdaTipoCambio.Clear()
        celdaTCFactura.Clear()
        celdaNotas.Clear()
        'checkFacturaEspecial.Checked = False
        If Sesion.IdEmpresa = 10 Then
            dgFactura.Columns("colAutorizacionFel").Visible = True
        Else
            dgFactura.Columns("colAutorizacionFel").Visible = False
        End If


        dgFactura.Rows.Clear()
        dgDatos.Rows.Clear()

    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        If celdaNumero.Text = vbNullString Then
            If MsgBox("You must enter the Withholding Number", vbOK, vbInformation) = vbOK Then
                celdaNumero.Focus()
                comprobar = False
            ElseIf celdaProveedor.Text = vbNullString Then
                If MsgBox("You must select a Customer", vbOK, vbInformation) = vbOK Then
                    botonProveedor.Focus()
                    comprobar = False
                End If
            ElseIf dgFactura.Rows.Count > 1 Then
                If MsgBox("Select an invoice please", vbOK, vbInformation) = vbOK Then
                    comprobar = False
                End If
            End If
        End If
        Return comprobar
    End Function
    Private Sub BorrarEncabezadoIVAProveedor(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 326
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDetalleRetenIva(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = 326 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarRetencionHDR()
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 326
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_NUM = celdaNumeroHDR.Text
        hdr.HDoc_Doc_Fec_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        hdr.HDOC_EMP_COD = celdaIdProveedor.Text
        hdr.HDOC_EMP_NOM = celdaProveedor.Text
        hdr.HDOC_DR1_NUM = celdaNumero.Text
        hdr.HDOC_DR1_DBL = celdaTipoCambio.Text
        hdr.HDOC_RF1_TXT = UCase(celdaNotas.Text)
        hdr.HDOC_RF1_DBL = celdaMonto.Text
        hdr.HDOC_PRO_DCAT = 0
        hdr.HDOC_PRO_DNUM = 0
        hdr.HDOC_PRO_DANO = 0
        hdr.HDOC_RF2_TXT = cFunciones.ALetras(celdaMonto.Text)

        'hdr.HDOC_DR1_CAT = IIf(checkFacturaEspecial.Checked = True, INT_UNO, INT_CERO)
        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 0 Or dgFactura.Rows(i).Cells("colExtraFact").Value = 1 Then
                hdr.HDOC_RF1_COD = dgFactura.Rows(i).Cells("colREferenciaFac").Value
            Else
            End If
        Next
        hdr.HDOC_RF2_DBL = 0
        hdr.HDOC_RF3_DBL = 0
        hdr.HDOC_DOC_MON = celdaIDMoneda.Text
        hdr.HDOC_DOC_TC = celdaTipoCambio.Text
        hdr.HDOC_USUARIO = Sesion.Usuario
        hdr.HDOC_DOC_STATUS = INT_UNO
        hdr.HDOC_ANT_COM = INT_CERO

        hdr.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then

            If hdr.Guardar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If

        Else
            If hdr.Actualizar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If
    End Sub

    Public Sub GuardarRetencionDTL()
        Dim dtl As New clsDcmtos_DTL

        dtl.DDOC_SIS_EMP = Sesion.IdEmpresa
        dtl.DDOC_DOC_CAT = 326
        dtl.DDOC_DOC_ANO = celdaAnio.Text
        dtl.DDOC_DOC_NUM = celdaNumeroHDR.Text
        dtl.DDOC_DOC_LIN = INT_UNO
        dtl.DDOC_PRD_DES = dgDatos.CurrentRow.Cells("colCheque").Value
        dtl.DDOC_PRD_UM = INT_CERO
        dtl.DDOC_PRD_PUQ = dgDatos.CurrentRow.Cells("colMoneda").Value
        dtl.DDOC_PRD_DSP = dgDatos.CurrentRow.Cells("colTasa").Value
        dtl.DDOC_PRD_DSQ = INT_CERO
        dtl.DDOC_PRD_NET = dgDatos.CurrentRow.Cells("colFechaDoc").Value
        If Sesion.IdEmpresa = 10 Then
            dtl.DDOC_RF1_NUM = 296
        Else
            dtl.DDOC_RF1_NUM = 36
        End If
        dtl.DDOC_RF1_DBL = dgDatos.CurrentRow.Cells("colBanco").Value
        dtl.DDOC_RF2_NUM = dgFactura.CurrentRow.Cells("colAnioFac").Value
        dtl.DDOC_RF2_DBL = INT_CERO
        dtl.DDOC_RF3_NUM = dgFactura.CurrentRow.Cells("colNumeroFac").Value
        dtl.DDOC_RF3_DBL = INT_CERO
        dtl.DDOC_PRD_FOB = INT_CERO
        dtl.DDOC_PRD_CIF = INT_CERO

        If Me.Tag = "Nuevo" Then

            If dtl.Guardar() = False Then
                MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If

        Else
            If dtl.Actualizar() = False Then
                MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub
    Private Sub BorrarEctateRetenIVA(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 326 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarCuentaXPagar()
        Dim ect As New Tablas.TECTACTE

        ect.ECTA_SIS_EMP = Sesion.IdEmpresa
        ect.ECTA_DOC_CAT = 326
        ect.ECTA_DOC_ANO = celdaAnio.Text
        ect.ECTA_DOC_NUM = celdaNumeroHDR.Text
        ect.ECTA_DOC_LIN = INT_UNO
        ect.ECTA_TIPOEMP = "Clientes"
        ect.ECTA_CODEMP = celdaIdProveedor.Text
        ect.ECTA_SINI_LOC = INT_CERO
        ect.ECTA_CRGO_LOC = INT_CERO
        ect.ECTA_ABNO_LOC = celdaMonto.Text
        ect.ECTA_SINI_EXT = INT_CERO
        ect.ECTA_CRGO_EXT = INT_CERO
        For i As Integer = 0 To dgFactura.Rows.Count - 1
            ect.ECTA_ABNO_EXT = ((celdaMonto.Text) / CDbl(dgFactura.Rows(i).Cells("colTCFac").Value))
            ect.ECTA_CONCEPTO = "IVA Retenido / Cliente - Factura No. " & dgFactura.Rows(i).Cells("colREferenciaFac").Value & " del " & dgFactura.Rows(i).Cells("colFechaFac").Value
        Next

        ect.ECta_FecDcmt_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECta_FecVenc_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECTA_MONEDA = celdaIDMoneda.Text
        ect.ECTA_TC = celdaTipoCambio.Text
        ect.ECTA_REF_CAT = celdaCatF.Text
        ect.ECTA_REF_ANO = celdaAnioF.Text
        ect.ECTA_REF_NUM = celdaNumF.Text

        ect.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then
            If ect.PINSERT = False Then
                MsgBox(ect.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Else
            If ect.PUPDATE = False Then
                MsgBox(ect.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub
    Private Function ValidarRetencionIVAProveedor(ByVal num As Integer, ByVal anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim logValidar As Integer = INT_CERO

        Try
            strSQL = " SELECT COUNT(*) "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 326 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND h.HDoc_Doc_Status = 1 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            logValidar = COM.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
#End Region

#Region "Eventos"
    Private Sub frmRetenIVACliente_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFechaInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFechaFinal.Value = Today  'DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        If Sesion.IdEmpresa = 10 Then
            dgLista.Columns("colAutorizacion").Visible = True
        Else
            dgLista.Columns("colAutorizacion").Visible = False
        End If

        MostrarLista()
        Accessos()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        If CDate(dtpFechaInicial.Value) > CDate(dtpFechaFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
        Else
            ListaPrincipal()
        End If

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intAnio As Integer = 0
        Dim intNum As Integer = 0

        LimpiarCampos()
        BloquearBotones()
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(0).Value
            intNum = dgLista.SelectedCells(1).Value
            CargarEncabezado(intAnio, intNum)
            CargarFactura(intAnio, intNum)
            CargarPago(intAnio, intNum)

            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Customer"
            frm.Campos = " c.cli_codigo codigo, c.cli_cliente cliente "
            frm.Tabla = " Clientes c "
            frm.FiltroText = " Enter the Customer to filter "
            frm.Filtro = " c.cli_cliente "
            frm.Ordenamiento = " c.cli_cliente "
            frm.TipoOrdenamiento = " ASC "
            frm.Condicion = " c.cli_sisemp = " & Sesion.IdEmpresa & " AND c.cli_status = 'Activo'"
            frm.Limite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato

                MostrarFacturas()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarCampos()
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If

    End Sub

    Public Sub LlenarDetalle()
        Dim strDesc As String = STR_VACIO
        Dim fila As String = STR_VACIO
        Dim dblFactorIVA As Double = 0
        Dim dblFactorRet As Double = 0

        Try
            dblFactorIVA = FactorIVA("IVA")
            dblFactorRet = FactorIVA()
            strDesc = "Factura No. " & dgFactura.CurrentRow.Cells(2).Value & "  fel. " & dgFactura.CurrentRow.Cells(10).Value & "   del " & dgFactura.CurrentRow.Cells(1).Value

            fila = strDesc & "|"
            fila &= dgFactura.CurrentRow.Cells(5).Value & "|"
            fila &= (dblFactorRet * 100) & "|"
            fila &= (dblFactorIVA * 100) & "|"
            fila &= celdaMonto.Text

            cFunciones.AgregarFila(dgDatos, fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim i As Integer = 0
        Dim Factor As Double = 0
        Dim Verificar As Double = 0
        dgFactura.CurrentRow.Cells("colExtraFact").Value = 3 ' 3 es solo un pivote para que no se oculte la fila seleccionada
        For i = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 3 Then
                celdaAnioF.Text = dgFactura.Rows(i).Cells("colAnioFac").Value
                celdaNumF.Text = dgFactura.Rows(i).Cells("colNumeroFac").Value
                If Sesion.IdEmpresa = 10 Then
                    celdaCatF.Text = 296
                Else
                    celdaCatF.Text = 36
                End If
                celdaMontoF.Text = dgFactura.Rows(i).Cells("colTotalFac").Value
                celdaIDMoneda.Text = cFunciones.DivisaLocal
                celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)  'dgFactura.Rows(i).Cells("colMonedaFac").Value
                celdaTipoCambio.Text = INT_UNO.ToString(FORMATO_MONEDA) 'dgFactura.Rows(i).Cells("colTCFac").Value
                celdaTCFactura.Text = dgFactura.Rows(i).Cells("colTCFac").Value
                dgFactura.Rows(i).Cells("colExtraFact").Value = 0
                Verificar = VerificarIVA()
                'If dgFactura.Rows(i).Cells("colEspecialFac").Value = 1 Then
                '    checkFacturaEspecial.Checked = True
                '    celdaMonto.Text = Verificar
                'Else
                'checkFacturaEspecial.Checked = False
                If Verificar = 0 Then
                    Factor = FactorIVA("IVA_Clt") ' IVA pequeño contribuyente es 5% sobre el total de la factura en GT
                    celdaMonto.Text = Math.Round((CDbl(celdaMontoF.Text) * CDbl(celdaTCFactura.Text) * Factor), 2)
                Else
                    Factor = FactorIVA() ' Consulta cual es el porcentaje de IVA dependiendo del pais
                    celdaMonto.Text = Math.Round(Verificar * Factor, 2)
                End If
                'End If

                'Procedimiento para Calcular el ISR
                'celdaMonto.Text = Math.Round(((CDbl(celdaMontoF.Text) * CDbl(celdaTCFactura.Text)) - VerificarIVA()) * FactorIVA(), 2)
                celdaTotal.Text = celdaMonto.Text
                LlenarDetalle()

            Else
                dgFactura.Rows(i).Cells("colExtraFact").Value = 2 ' 2 elimina la fila (no guarda)
                dgFactura.Rows(i).Visible = False
            End If
        Next
    End Sub

    Private Sub celdaMonto_TextChanged(sender As Object, e As EventArgs) Handles celdaMonto.TextChanged
        If celdaMonto.Text.LongCount = 0 Then
            celdaTotal.Text = 0.00

        Else
            celdaTotal.Text = celdaMonto.Text
            ' dgDatos.CurrentRow.Cells("colBanco").Value = celdaMonto.Text
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim dtFechaConta As Date
        Dim conta As New clsContabilidad
        If Me.Tag = "Nuevo" Then
            GuardarDatosDeDocumento()
        Else
            'Captura la Fecha de la póliza o del documento, si este no tiene poliza
            dtFechaConta = cFunciones.SQLValidarFechaContable(326, celdaAnio.Text, celdaNumeroHDR.Text)
            'Verifica si hay cierre o no
            If cFunciones.SQLVerificarCierre(326, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                GuardarDatosDeDocumento()
                conta.GenerarPoliza(326, celdaAnio.Text, celdaNumeroHDR.Text, dtFechaConta.ToString(FORMATO_MYSQL))
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaProveedor.Text, 326, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                    GuardarDatosDeDocumento()
                    conta.GenerarPoliza(326, celdaAnio.Text, celdaNumeroHDR.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                End If
            End If
        End If
    End Sub

    Private Sub GuardarDatosDeDocumento()
        If logEditar = True Or Me.Tag = "Nuevo" Then
            Dim clsConta As New clsContabilidad
            If ComprobarCampos() = True Then
                If celdaNumeroHDR.Text = -1 Then
                    celdaNumeroHDR.Text = cFunciones.NuevoId(326)
                End If
                GuardarRetencionHDR()
                GuardarRetencionDTL()
                GuardarCuentaXPagar()
                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 326, celdaAnio.Text, celdaNumeroHDR.Text)

                    If cFunciones.SQLVerificarCierre(326, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                        clsConta.GenerarPoliza(326, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
                    Else
                        clsConta.GenerarPoliza(326, celdaAnio.Text, celdaNumeroHDR.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                    End If

                        MsgBox("The Document has been successfully saved", vbInformation, "Notice")
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 326, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("The document has been successfully updated", vbInformation, "Notice")
                End If

                MostrarLista(True)

            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub

    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click
        Dim PC As New clsPolizaContable
        PC.intTipo = 326
        PC.intCiclo = celdaAnio.Text
        PC.intNumero = celdaNumeroHDR.Text
        PC.intModo = 27
        PC.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 326,)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFactura_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgFactura.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            ' If ValidarRetencionIVAProveedor(celdaNumeroHDR.Text, celdaAnio.Text) = INT_CERO Then
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                BorrarEncabezadoIVAProveedor(celdaNumeroHDR.Text, celdaAnio.Text)
                BorrarDetalleRetenIva(celdaNumeroHDR.Text, celdaAnio.Text)
                BorrarEctateRetenIVA(celdaNumeroHDR.Text, celdaAnio.Text)
                cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 326)
                cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text,326)
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 326, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("Eliminated Complete")
                    MostrarLista()
                End If
            'Else
            '    MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            'End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub


#End Region
End Class