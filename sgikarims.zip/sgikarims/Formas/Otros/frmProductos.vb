﻿Imports System.ComponentModel

Public Class frmProductos
#Region "About SGI"
    ' Ultimo cambio 07-03-2022
    ' Responsable : WC
    ' SGIVER. V3.3.12.44
    ' Se elimino el case de la linea 519 para que no especifique estaticamente los codigos de clase
    ' si no valide el grupo de clase de productos de [Fibra] en la variable strTipo en la linea 544

#End Region
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim intCurDoc As Integer
    Dim strReferencia As String
    Dim cfun As New clsFunciones
    Dim dblDocTotal As Double
    Dim intSeleccion As Integer
    Dim intTipoPoly As Integer
    Dim strOpcion As String = STR_VACIO ' guarda  el tipo de Producto (fibra, terminado, proceso, etc)
    Dim intTipoProd As Integer = NO_FILA
    Private TotalPorcentaje As Double
    Private dblDocCantidad As Double

    Public Const TBL_DOCUMENTOS As String = "Articulos"



#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
            'botonBuscar.Enabled = True
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
            'botonBuscar.Enabled = False
        End If
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False, Optional cod As Integer = 0)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelFiltro.Visible = True
            panelDetalle.Dock = DockStyle.None
            panelDetalle.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Product Maintenance")
            'Cargar Datos
            queryListaPrincipal(cod)
            'Mostrar Panel Filtro
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            'Cargar Datos
            If celdaType.Text IsNot Nothing Then
                queryListaPrincipal(cod)
                'Mostrar Panel Filtro

                BloquearBotones()
            End If
        Else
                'Ocultar Panel Filtro
                PanelFiltro.Visible = False

            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDetalle.Dock = DockStyle.Fill
            panelDetalle.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonImprimir.Enabled = False

                Reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Public Sub LimpiarPanel()

        etiquetaCodigo.Visible = True
        celdaCodigo.Visible = True
        etiquetaClase.Visible = True
        celdaClase.Visible = True
        botonClase.Visible = True

        checkActivar.Checked = True
        checkProduccion.Checked = True
        celdaCodigo.Text = NO_FILA
        celdaClase.Text = STR_VACIO
        celdaIDClase.Text = NO_FILA
        celdaAcabado.Text = STR_VACIO
        celdaIDAcabado.Text = NO_FILA
        celdaTitulo.Text = STR_VACIO
        celdaIDTexturizado.Text = STR_VACIO
        celdaSpinning.Text = STR_VACIO
        celdaIDSpinning.Text = NO_FILA
        checkReciclado.Checked = False
        checkOrganico.Checked = False
        rbSi.Checked = False
        rbNo.Checked = False
        celdaDescripcion.Text = STR_VACIO
        celdaTotal.Text = NO_FILA
        dgDetalle.Rows.Clear()
        celdaTotal.Text = STR_VACIO
        CeldaDecripcionCorta.Text = STR_VACIO
        celdaDescripcionLarga.Text = STR_VACIO
        celdaDescripcionHilo3.Text = STR_VACIO
        celdaPartidaArancelaria.Text = STR_VACIO
        celdaArancel.Text = NO_FILA
        celdaFilamento.Text = INT_CERO
        celdaIDTexturizado.Text = INT_CERO
        celdaIDDenier.Text = INT_CERO
        celdaIDClasificacion.Text = INT_CERO
        celdaClasificacion.Text = STR_VACIO
        celdaNombreProducto.Text = STR_VACIO
        dgDetalle.Rows.Clear()

        If ((Sesion.IdEmpresa >= 18) And (Sesion.IdEmpresa <= 21)) Or Sesion.idGiro = 2 Then
            gbHeather.Visible = False
            checkExcento.Visible = True
        Else
            checkExcento.Visible = False
        End If

    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT a.art_codigo Codigo, IFNULL(a.art_DCorta,'') Dcorta, IFNULL(a.art_DLarga,'') DLarga, IFNULL(a.art_clase,0) Clase, IFNULL(a.art_titulo,'') Titulo, IFNULL(c.cat_desc,'') descripcion, a.art_status estado "
        strsql &= "  FROM Articulos a"
        strsql &= "     LEFT JOIN Catalogos c ON c.cat_num = a.art_clase AND c.cat_clase = 'ClaseArt'"
        strsql &= "         WHERE art_sisemp = {empresa}
                             AND cat_ext = '{type}' "

        strsql &= "             ORDER BY art_codigo"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{type}", celdaType.Text)


        Return strsql
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal(Optional cod As Integer = 0)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim e As Integer
        Dim c As Integer
        Dim r As Integer
        Dim ch As Integer

        strSQL = SQLlista()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Codigo") & "|" & REA.GetString("DCorta") & "|" & REA.GetString("DLarga") & "|" & REA.GetString("descripcion") & "|" & REA.GetInt32("Clase") & "|" & REA.GetString("Titulo")
                    If REA.GetInt32("estado") = 1 Then
                        cFunciones.AgregarFila(dgLista, strFila)
                    Else
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    End If
                    If Not cod = 0 Then
                        For j As Integer = 0 To dgLista.Rows.Count - 1
                            If cod = dgLista.Rows(j).Cells("colCodigo").Value Then
                                dgLista.Rows(j).Selected = True
                                dgLista.CurrentCell = dgLista.Rows(j).Cells(0)
                                Exit For
                            End If
                        Next
                    End If

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function SeleccionEncabezado(ByVal intCodigo As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT a.art_codigo Codigo, a.art_desc Descripcion, a.art_frac Partida, IFNULL(a.art_acabado, '') IDAcabado, IFNULL(ca.cat_desc,'') Acabado, a.art_duty Arancel, a.art_titulo Titulo, a.art_spinning IDSpinning, IFNULL(c.cat_desc,'') Spinning, a.art_denier IDDenier, IFNULL(ct.cat_desc,'') Denier, a.art_filamento IDfilamento, IFNULL(cta.cat_desc,'') Filamento, IFNULL(a.art_extrainfo,'') Info, a.art_texturizado IDTextura, IFNULL(ctaa.cat_desc, '') Textura, a.art_heather Heather, a.art_DCorta DCorta, a.art_DLarga DLarga, a.art_clase IDClase, caa.cat_desc Clase, art_status Estado, IFNULL(cat.cat_num,0) IDClasificacion, IFNULL(cat.cat_desc,'') Clasificacion, IF(a.art_venta = '1',1, IF(a.art_venta= '2',2,IF(a.art_venta= '3',3,0))) recycle ,a.art_produccion produccion,caa.cat_ext Tipo, a.art_excento "
        strSQL &= " FROM Articulos a"
        strSQL &= "      LEFT JOIN Catalogos ca ON ca.cat_num = a.art_acabado AND ca.cat_clase = 'Acabado'"
        strSQL &= "      LEFT JOIN Catalogos caa ON caa.cat_num = a.art_clase AND caa.cat_clase ='ClaseArt'"
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = a.art_spinning AND c.cat_clase = 'Spinning'"
        strSQL &= "      LEFT JOIN Catalogos ct ON ct.cat_num = a.art_denier AND ct.cat_clase = 'Denier'"
        strSQL &= "      LEFT JOIN Catalogos cta ON cta.cat_num = a.art_filamento "
        strSQL &= "      LEFT JOIN Catalogos ctaa ON ctaa.cat_num = a.art_texturizado AND ctaa.cat_clase = 'Texture'"
        strSQL &= "      LEFT JOIN Catalogos cat ON cat.cat_num = a.art_ref AND cat.cat_clase = 'Clasificacion'"
        strSQL &= "      LEFT JOIN Inventarios i ON i.inv_sisemp = a.art_sisemp AND i.inv_numero = a.art_codigo"
        strSQL &= "         WHERE a.art_sisemp  = {empresa} AND a.art_codigo = {codigo}"


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", intCodigo)

        Return strSQL
    End Function

    Private Sub CargarEncabezado2(ByVal intCodigo As Integer, Optional ByVal intClase As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT a.*, IFNULL(cl.cat_desc,'') class, caa.cat_pid tipo, caa.cat_desc Clase, IFNULL(ca.cat_desc,'') Acabado, art_produccion produccion "
        strSQL &= " FROM Articulos a"
        strSQL &= "     LEFT JOIN Catalogos caa ON caa.cat_num = a.art_clase AND caa.cat_clase ='ClaseArt'"
        strSQL &= "     LEFT JOIN Catalogos cl ON cl.cat_num = a.art_ref AND cl.cat_clase ='Clasificacion' AND cl.cat_pid = 1"
        strSQL &= "        LEFT JOIN Catalogos ca ON ca.cat_num = a.art_acabado AND ca.cat_clase = 'Acabado'"
        strSQL &= "         WHERE a.art_sisemp = {empresa} and a.art_codigo = {codigo}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", intCodigo)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        REA.Read()
        celdaCodigo.Text = REA.GetInt32("art_codigo")
        celdaIDClase.Text = REA.GetInt32("art_clase")
        celdaClase.Text = REA.GetString("Clase")
        CeldaDecripcionCorta.Text = REA.GetString("art_DCorta")
        celdaDescripcionLarga.Text = REA.GetString("art_DLarga")
        celdaDescripcion.Text = REA.GetString("art_extrainfo")
        celdaNombreProducto.Text = REA.GetString("art_desc")
        celdaDescripcionHilo3.Text = REA.GetString("art_desc")

        celdaIDClasificacion.Text = REA.GetInt32("art_ref")
        celdaClasificacion.Text = REA.GetString("class")

        IIf(REA.GetString("art_venta") = "1", checkReciclado.Checked = True, checkReciclado.Checked = False)
        If REA.GetString("art_venta") = 1 Then
            checkReciclado.Checked = True
        ElseIf REA.GetString("art_venta") = 2 Then
            checkOrganico.Checked = True
        ElseIf REA.GetString("art_venta") = 3 Then
            checkReciclado.Checked = True
            checkOrganico.Checked = True
        Else
            checkReciclado.Checked = False
        End If
        If REA.GetInt32("art_heather") = 1 Then
            rbSi.Checked = True
            rbNo.Checked = False
        Else
            rbSi.Checked = False
            rbNo.Checked = True
        End If
        If REA.GetInt16("produccion") = INT_UNO Then
            checkProduccion.Checked = True
        Else
            checkProduccion.Checked = False

        End If

        If intClase = 2307 Then
            etiquetaAcabado.Visible = True
            celdaAcabado.Visible = True
            botonAcabado.Visible = True
            celdaIDAcabado.Visible = False
            celdaAcabado.Text = REA.GetString("Acabado")
            celdaIDAcabado.Text = REA.GetInt32("art_acabado")
        Else
            etiquetaAcabado.Visible = False
            celdaAcabado.Visible = False
            botonAcabado.Visible = False
            celdaIDAcabado.Visible = False
        End If

        etiquetaClase.Visible = True
        celdaClase.Visible = True
        botonClase.Visible = True
        celdaIDClase.Visible = False
        etiquetaTexturizado.Visible = False
        celdaTexturizado.Visible = False
        botonTexturizado.Visible = False
        celdaIDTexturizado.Visible = False
        etiquetaTitulo.Visible = False
        celdaTitulo.Visible = False
        If REA.GetInt32("tipo") = 5 Then
            etiquetaClasificacion.Visible = True
            celdaClasificacion.Visible = True
            botonClasificacion.Visible = True
        Else
            etiquetaClasificacion.Visible = False
            celdaClasificacion.Visible = False
            botonClasificacion.Visible = False
        End If

        celdaIDClasificacion.Visible = False
        etiquetaDenier.Visible = False
        celdaDenier.Visible = False
        botonDenier.Visible = False
        celdaIDDenier.Visible = False
        etiquetaFilamento.Visible = False
        celdaFilamento.Visible = False
        botonFilamento.Visible = False
        celdaIDFilamento.Visible = False
        etiquetaSpinning.Visible = False
        celdaSpinning.Visible = False
        botonSpinning.Visible = False
        celdaIDSpinning.Visible = False

        etiquetaNombreProducto.Visible = True
        celdaNombreProducto.Visible = True
        panelDetalle2.Visible = False
        celdaTotal.Visible = False

    End Sub

    Private Sub CargarEncabezado(ByVal intCodigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim intClase As Integer
        Dim strTipoProducto As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader


        strSQL = SeleccionEncabezado(intCodigo)
        etiquetaNombreProducto.Visible = False
        celdaNombreProducto.Visible = False
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                REA.Read()
                celdaCodigo.Text = REA.GetInt32("Codigo")
                celdaDescripcionHilo3.Text = REA.GetString("Descripcion")

                celdaPartidaArancelaria.Text = REA.GetString("Partida")
                celdaArancel.Text = REA.GetInt32("Arancel")
                celdaDescripcion.Text = REA.GetString("Info")
                CeldaDecripcionCorta.Text = REA.GetString("DCorta")
                celdaDescripcionLarga.Text = REA.GetString("DLarga")
                If REA.GetInt16("produccion") = INT_UNO Then
                    checkProduccion.Checked = True
                Else
                    checkProduccion.Checked = False
                End If
                If REA.GetInt16("art_excento") = INT_UNO Then
                    checkExcento.Checked = True
                Else
                    checkExcento.Checked = False
                End If
                If REA.GetInt32("recycle") = 1 Then
                    checkReciclado.Checked = True
                ElseIf REA.GetInt32("recycle") = 2 Then
                    checkOrganico.Checked = True
                ElseIf REA.GetInt32("recycle") = 3 Then
                    checkOrganico.Checked = True
                    checkReciclado.Checked = True
                Else
                    checkReciclado.Checked = False
                End If

                If REA.GetInt32("Estado") = 1 Then
                    checkActivar.Checked = True
                    checkActivar.Enabled = True
                Else
                    checkActivar.Checked = False
                    checkActivar.Enabled = False
                End If
                etiquetaClasificacion.Visible = True
                celdaClasificacion.Visible = True
                botonClasificacion.Visible = True
                celdaIDClasificacion.Text = REA.GetInt32("IDClasificacion")
                celdaClasificacion.Text = REA.GetString("Clasificacion")

                intClase = REA.GetInt32("IDClase")
                strTipoProducto = REA.GetString("Tipo")

                Select Case intClase
                    Case 10
                        If REA.GetString("IDTextura") > 0 Then
                            intTipoPoly = 1
                            celdaIDClase.Text = REA.GetInt32("IDClase")
                            celdaClase.Text = REA.GetString("Clase")
                            celdaIDDenier.Text = REA.GetInt32("IDDenier")
                            celdaDenier.Text = REA.GetString("Denier")
                            celdaIDTexturizado.Text = REA.GetInt32("IDTextura")
                            celdaTexturizado.Text = REA.GetString("Textura")
                            celdaIDFilamento.Text = REA.GetInt32("IDFilamento")
                            celdaFilamento.Text = REA.GetString("Filamento")
                            etiquetaDenier.Visible = True
                            celdaDenier.Visible = True
                            celdaIDDenier.Visible = False
                            botonDenier.Visible = True
                            etiquetaTexturizado.Visible = True
                            celdaTexturizado.Visible = True
                            botonTexturizado.Visible = True
                            etiquetaFilamento.Visible = True
                            celdaFilamento.Visible = True
                            botonFilamento.Visible = True
                            etiquetaAcabado.Visible = False
                            celdaAcabado.Visible = False
                            botonAcabado.Visible = False
                            etiquetaTitulo.Visible = False
                            celdaTitulo.Visible = False
                            etiquetaSpinning.Visible = False
                            celdaIDSpinning.Visible = False
                            celdaSpinning.Visible = False
                            botonSpinning.Visible = False
                        ElseIf (REA.GetString("IDTextura") = 0) Then
                            intTipoPoly = 0
                            celdaIDClase.Text = REA.GetInt32("IDClase")
                            celdaClase.Text = REA.GetString("Clase")
                            celdaIDAcabado.Text = REA.GetString("IDAcabado")
                            celdaAcabado.Text = REA.GetString("Acabado")
                            celdaTitulo.Text = REA.GetString("Titulo")
                            celdaIDSpinning.Text = REA.GetInt32("IDSpinning")
                            celdaSpinning.Text = REA.GetString("Spinning")
                            If REA.GetInt32("Heather") = 1 Then
                                rbSi.Checked = True
                                rbNo.Checked = False
                            Else
                                rbSi.Checked = False
                                rbNo.Checked = True
                            End If
                            etiquetaDenier.Visible = False
                            celdaDenier.Visible = False
                            celdaIDDenier.Visible = False
                            botonDenier.Visible = False
                            etiquetaTexturizado.Visible = False
                            celdaTexturizado.Visible = False
                            botonTexturizado.Visible = False
                            etiquetaFilamento.Visible = False
                            celdaFilamento.Visible = False
                            botonFilamento.Visible = False
                            etiquetaAcabado.Visible = True
                            celdaAcabado.Visible = True
                            botonAcabado.Visible = True
                            etiquetaTitulo.Visible = True
                            celdaTitulo.Visible = True
                            etiquetaSpinning.Visible = True
                            celdaIDSpinning.Visible = False
                            celdaSpinning.Visible = True
                            botonSpinning.Visible = True
                        End If
                    Case 15
                        celdaIDClase.Text = REA.GetInt32("IDClase")
                        celdaClase.Text = REA.GetString("Clase")
                        celdaIDDenier.Text = REA.GetInt32("IDDenier")
                        celdaDenier.Text = REA.GetString("Denier")

                        etiquetaAcabado.Visible = False
                        celdaAcabado.Visible = False
                        celdaIDAcabado.Visible = False
                        botonAcabado.Visible = False

                        etiquetaDenier.Visible = True
                        celdaDenier.Visible = True
                        celdaIDDenier.Visible = False
                        botonDenier.Visible = True
                        etiquetaClasificacion.Visible = True
                        celdaClasificacion.Visible = True
                        botonClasificacion.Visible = True
                        celdaIDClasificacion.Visible = False

                        etiquetaTitulo.Visible = False
                        celdaTitulo.Visible = False

                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        celdaIDTexturizado.Visible = False
                        botonTexturizado.Visible = False

                        etiquetaSpinning.Visible = False
                        celdaSpinning.Visible = False
                        celdaIDSpinning.Visible = False
                        botonSpinning.Visible = False

                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        celdaIDFilamento.Visible = False
                        botonFilamento.Visible = False

                        'gbHeather.Visible = False
                        rbNo.Visible = True
                        rbSi.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = True
                    Case 2306 'FIBRA
                        MostrarRegistros(intClase, strTipoProducto)
                        celdaIDClase.Text = REA.GetInt32("IDClase")
                        celdaClase.Text = REA.GetString("Clase")

                        celdaIDDenier.Text = REA.GetInt32("IDDenier")
                        celdaDenier.Text = REA.GetString("Denier")

                        celdaIDAcabado.Text = REA.GetString("IDAcabado")
                        celdaAcabado.Text = REA.GetString("Acabado")

                        celdaIdMicronaire.Text = REA.GetInt32("IDFilamento")
                        celdaMicronaire.Text = REA.GetString("Filamento")

                        'Case 388, 896, 2307, 2369, 2370, 2371
                        '    If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                        '        celdaIDClase.Text = REA.GetInt32("IDClase")
                        '        celdaClase.Text = REA.GetString("Clase")
                        '        celdaNombreProducto.Text = REA.GetString("Descripcion")
                        '        panelDetalle2.Visible = False
                        '        etiquetaClasificacion.Visible = True
                        '        celdaClasificacion.Visible = True
                        '        botonClasificacion.Visible = True
                        '        etiquetaNombreProducto.Visible = True
                        '        celdaNombreProducto.Visible = True
                        '        checkProduccion.Visible = True
                        '        gbHeather.Visible = True
                        '        rbNo.Visible = True
                        '        rbSi.Visible = True
                        '        Exit Sub
                        '    End If
                        'TODO
                    Case Else
                        If intTipoProd > 0 Or strTipoProducto = "Fibra" Or strTipoProducto = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Or strTipoProducto = "Material de empaque" Or strTipoProducto = "Inventario en Custodia" Or strTipoProducto = "Consumibles" Or strTipoProducto = "Combustible" Or strTipoProducto = "Repuestos" Or strTipoProducto = "Proyecto" Then
                            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                                celdaIDClase.Text = REA.GetInt32("IDClase")
                                celdaClase.Text = REA.GetString("Clase")
                                celdaNombreProducto.Text = REA.GetString("Descripcion")
                                panelDetalle2.Visible = False
                                etiquetaClasificacion.Visible = True
                                celdaClasificacion.Visible = True
                                botonClasificacion.Visible = True
                                etiquetaNombreProducto.Visible = True
                                celdaNombreProducto.Visible = True
                                checkProduccion.Visible = True
                                gbHeather.Visible = True
                                rbNo.Visible = True
                                rbSi.Visible = True
                                Exit Sub
                            End If
                        End If

                        If strTipoProducto = "Material de empaque" Or strTipoProducto = "Consumibles" Or strTipoProducto = "Repuestos" Then
                            checkExcento.Visible = True
                        Else
                            checkExcento.Visible = False
                        End If

                        celdaIDClase.Text = REA.GetInt32("IDClase")
                        celdaClase.Text = REA.GetString("Clase")
                        celdaIDAcabado.Text = REA.GetString("IDAcabado")
                        celdaAcabado.Text = REA.GetString("Acabado")
                        celdaTitulo.Text = REA.GetString("Titulo")
                        celdaIDSpinning.Text = REA.GetInt32("IDSpinning")
                        celdaSpinning.Text = REA.GetString("Spinning")

                        If REA.GetInt32("Heather") = 1 Then
                            rbSi.Checked = True
                            rbNo.Checked = False
                        Else
                            rbSi.Checked = False
                            rbNo.Checked = True
                        End If

                        etiquetaDenier.Visible = False
                        celdaDenier.Visible = False
                        celdaIDDenier.Visible = False
                        botonDenier.Visible = False
                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        botonTexturizado.Visible = False
                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        botonFilamento.Visible = False
                        etiquetaAcabado.Visible = True
                        celdaAcabado.Visible = True
                        botonAcabado.Visible = True
                        etiquetaTitulo.Visible = True
                        celdaTitulo.Visible = True
                        etiquetaSpinning.Visible = True
                        celdaIDSpinning.Visible = False
                        celdaSpinning.Visible = True
                        botonSpinning.Visible = True
                        gbHeather.Visible = True
                        rbNo.Visible = True
                        rbSi.Visible = True
                End Select



                'Condición para ocultar campos de clasificación cuando se trabaja en HSM ya que ahi no son necesarios
                'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Then
                '    etiquetaClasificacion.Visible = False
                '    celdaIDClasificacion.Visible = False
                '    celdaClasificacion.Visible = False
                '    botonClasificacion.Visible = False
                'End If
            End If

            panelDetalle2.Visible = True
            celdaTotal.Visible = True

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function QueryCargarDetalle()
        Dim strSQL As String = STR_VACIO

        strSQL = "SELECT m.det_sisemp Empresa, m.det_articulo Art, m.det_item Item, m.det_num Numero, m.det_clave Clave, m.det_prcnt Porcentaje, c.cat_num NumCat, c.cat_clase Clase, c.cat_clave Clave, c.cat_desc Descripcion,  IFNULL(m.det_merma,0) Merma"
        strSQL &= "      FROM Materiales m"
        strSQL &= "              INNER JOIN Catalogos c ON c.cat_num = m.det_num AND c.cat_clase = 'Material'"
        strSQL &= "                      WHERE m.det_sisemp = {empresa} AND m.det_articulo = '{codigo}'"
        strSQL &= "               ORDER BY m.det_item"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)

        Return strSQL
    End Function

    Private Sub CargarDetalle()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Porcentaje As String

        strSQL = QueryCargarDetalle()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            Do While REA.Read
                If REA.HasRows Then

                    TotalPorcentaje = REA.GetDouble("Porcentaje")
                    dblDocCantidad = dblDocCantidad + TotalPorcentaje

                    strFila = REA.GetInt32("Empresa") & "|"
                    strFila &= REA.GetString("Art") & "|"
                    strFila &= REA.GetInt32("Item") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Clave") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Porcentaje") & "%" & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetDouble("Merma") & "%"

                    cfun.AgregarFila(dgDetalle, strFila)
                    Porcentaje = REA.GetString("Porcentaje")
                Else
                    panelDetalle2.Visible = False
                End If
            Loop

            ' oculta la columna de merma, ya no se utilizará
            dgDetalle.Columns("colMerma").Visible = False


            'celdaTotal.Text = dblDocCantidad.ToString(FORMATO_MONEDA) & "%"
            CalcularTotalPorcentajes()
            celdaClase.Enabled = False
            botonClase.Enabled = False

            If Porcentaje = "0" Or Porcentaje Is Nothing Then
                panelDetalle2.Visible = False
                dgDetalle.Columns("colPorcentaje").Visible = False
            Else
                panelDetalle2.Visible = True
                dgDetalle.Columns("colPorcentaje").Visible = True
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarRegistros(ByVal intClase As Integer, Optional strOpcion As String = STR_VACIO)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim intAsignar As Integer

        etiquetaNombreProducto.Visible = False
        celdaNombreProducto.Visible = False
        rbNo.Checked = True
        etiquetaMicronaire.Visible = False
        celdaMicronaire.Visible = False
        celdaIdMicronaire.Visible = False
        botonMicronaire.Visible = False
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
            If strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Invisible Waste" Or strOpcion = "Product in process" Then
                etiquetaClase.Visible = True
                celdaClase.Visible = True
                botonClase.Visible = True
                celdaIDClase.Visible = False
                etiquetaTexturizado.Visible = False
                celdaTexturizado.Visible = False
                botonTexturizado.Visible = False
                celdaIDTexturizado.Visible = False
                etiquetaTitulo.Visible = False
                celdaTitulo.Visible = False
                etiquetaClasificacion.Visible = True
                celdaClasificacion.Visible = True
                botonClasificacion.Visible = True
                etiquetaDenier.Visible = False
                celdaDenier.Visible = False
                botonDenier.Visible = False
                celdaIDDenier.Visible = False
                etiquetaNombreProducto.Visible = True
                celdaNombreProducto.Visible = True
                panelDetalle2.Visible = False
                celdaTotal.Visible = False

                gbHeather.Visible = True
                rbNo.Visible = True
                rbSi.Visible = True
                dgDetalle.Columns("colPorcentaje").Visible = False
                If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                Else
                    If intClase = 106 Or intClase = 9 Or intClase = 416 Or intClase = 2899 Or intClase = 2882 Or intClase = 2355 Or intClase = 2356 Then
                        intAsignar = 11
                    ElseIf intClase = 898 Then
                        intAsignar = 899
                    ElseIf intClase = 896 Then
                        intAsignar = 531
                    ElseIf intClase = 549 Then
                        intAsignar = 442
                    ElseIf intClase = 15 Then
                        intAsignar = 13
                    ElseIf intClase = 105 Then
                        intAsignar = 14

                    End If

                    Dim COM As MySqlCommand
                    Dim REA As MySqlDataReader
                    strSQL = "SELECT c.cat_num Numero, c.cat_clave Clave, c.cat_desc Descripcion"
                    strSQL &= "      FROM Catalogos c"
                    strSQL &= "              WHERE c.cat_clase = 'Material' AND c.cat_num = {IDClase}"

                    strSQL = Replace(strSQL, "{IDClase}", intAsignar)

                    Try
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader

                        REA.Read()
                        If REA.HasRows Then
                            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                dgDetalle.Rows(i).Cells("colEmpresa").Value = Sesion.IdEmpresa
                                dgDetalle.Rows(i).Cells("colArt").Value &= 0
                                dgDetalle.Rows(i).Cells("colItem").Value &= 0
                                dgDetalle.Rows(i).Cells("colNumero").Value &= REA.GetInt32("Numero")
                                dgDetalle.Rows(i).Cells("colClave").Value &= REA.GetString("Clave")
                                dgDetalle.Rows(i).Cells("colDesComponente").Value &= REA.GetString("Descripcion")
                                If intClase = 106 Or intClase = 898 Or intClase = 549 Then
                                    dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 0
                                ElseIf intClase = 9 Or intClase = 15 Or intClase = 105 Or intClase = 416 Or intClase = 2899 Or intClase = 2882 Or intClase = 2355 Or intClase = 2356 Then
                                    dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 100 & "%"
                                End If

                            Next
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                End If
            ElseIf intTipoProd > 0 Or strOpcion = "Maquinaria" Or strOpcion = "Otros" Or strOpcion = "Material de empaque" Or strOpcion = "Repuestos" Or strOpcion = "Consumibles" Or strOpcion = "Inventario en Custodia" Or strOpcion = "Proyecto" Or strOpcion = "Combustible" Then
                etiquetaClase.Visible = True
                celdaClase.Visible = True
                botonClase.Visible = True
                celdaIDClase.Visible = False
                etiquetaTexturizado.Visible = False
                celdaTexturizado.Visible = False
                botonTexturizado.Visible = False
                celdaIDTexturizado.Visible = False
                etiquetaTitulo.Visible = False
                celdaTitulo.Visible = False
                etiquetaClasificacion.Visible = False
                'If Sesion.IdEmpresa = 18 Then
                '    celdaClasificacion.Visible = True
                '    botonClasificacion.Visible = True
                'Else
                celdaClasificacion.Visible = False
                botonClasificacion.Visible = False
                'End If

                celdaIDClasificacion.Visible = False
                etiquetaDenier.Visible = False
                celdaDenier.Visible = False
                botonDenier.Visible = False
                celdaIDDenier.Visible = False
                If intClase = 2307 Then
                    etiquetaAcabado.Visible = True
                    celdaAcabado.Visible = True
                    botonAcabado.Visible = True
                    celdaIDAcabado.Visible = False

                Else
                    etiquetaAcabado.Visible = False
                    celdaAcabado.Visible = False
                    botonAcabado.Visible = False
                    celdaIDAcabado.Visible = False
                End If

                etiquetaFilamento.Visible = False
                celdaFilamento.Visible = False
                botonFilamento.Visible = False
                celdaIDFilamento.Visible = False
                etiquetaSpinning.Visible = False
                celdaSpinning.Visible = False
                botonSpinning.Visible = False
                celdaIDSpinning.Visible = False


                If intClase = 2306 Then
                    etiquetaNombreProducto.Text = "Fiber Type"
                    etiquetaNombreProducto.Visible = True
                    celdaNombreProducto.Visible = True
                    panelDetalle2.Visible = True
                    dgDetalle.Columns("colPorcentaje").Visible = False
                    celdaTotal.Visible = False
                ElseIf intClase = 2307 Then
                    etiquetaNombreProducto.Text = "Fiber Type"
                    etiquetaNombreProducto.Visible = True
                    celdaNombreProducto.Visible = True
                    panelDetalle2.Visible = True
                    dgDetalle.Columns("colPorcentaje").Visible = False
                    celdaTotal.Visible = False
                    'ElseIf intClase = 2337 Or intClase = 2338 Then
                    '    etiquetaNombreProducto.Text = "Waste Type"
                    '    etiquetaNombreProducto.Visible = True
                    '    celdaNombreProducto.Visible = True
                    '    panelDetalle2.Visible = True
                    '    dgDetalle.Columns("colPorcentaje").Visible = False
                    '    celdaTotal.Visible = False
                ElseIf intClase = 330 Then
                    etiquetaNombreProducto.Visible = True
                    celdaNombreProducto.Visible = True
                    panelDetalle2.Visible = False
                    celdaTotal.Visible = False

                Else
                    etiquetaNombreProducto.Visible = True
                    celdaNombreProducto.Visible = True
                    panelDetalle2.Visible = False
                    celdaTotal.Visible = False

                End If
            ElseIf (strOpcion = "Terminado" And intClase = 15) Then
                etiquetaAcabado.Visible = False
                celdaAcabado.Visible = False
                celdaIDAcabado.Visible = False
                botonAcabado.Visible = False

                etiquetaDenier.Visible = True
                celdaDenier.Visible = True
                celdaIDDenier.Visible = False
                botonDenier.Visible = True
                etiquetaClasificacion.Visible = True
                celdaClasificacion.Visible = True
                botonClasificacion.Visible = True
                celdaIDClasificacion.Visible = False

                etiquetaTitulo.Visible = False
                celdaTitulo.Visible = False

                etiquetaTexturizado.Visible = False
                celdaTexturizado.Visible = False
                celdaIDTexturizado.Visible = False
                botonTexturizado.Visible = False

                etiquetaSpinning.Visible = False
                celdaSpinning.Visible = False
                celdaIDSpinning.Visible = False
                botonSpinning.Visible = False

                etiquetaFilamento.Visible = False
                celdaFilamento.Visible = False
                celdaIDFilamento.Visible = False
                botonFilamento.Visible = False

                etiquetaNombreProducto.Visible = False
                celdaNombreProducto.Visible = False

                'gbHeather.Visible = False
                rbNo.Visible = True
                rbSi.Visible = True
                panelDetalle2.Visible = True
                dgDetalle.Columns("colPorcentaje").Visible = True
                If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                Else
                    Dim COM As MySqlCommand
                    Dim REA As MySqlDataReader
                    strSQL = "SELECT c.cat_num Numero, c.cat_clave Clave, c.cat_desc Descripcion"
                    strSQL &= "      FROM Catalogos c"
                    strSQL &= "              WHERE c.cat_clase = 'Material' AND c.cat_num = {IDClase}"

                    strSQL = Replace(strSQL, "{IDClase}", 13)

                    Try
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader

                        REA.Read()
                        If REA.HasRows Then
                            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                dgDetalle.Rows(i).Cells("colEmpresa").Value = Sesion.IdEmpresa
                                dgDetalle.Rows(i).Cells("colArt").Value &= 0
                                dgDetalle.Rows(i).Cells("colItem").Value &= 0
                                dgDetalle.Rows(i).Cells("colNumero").Value &= REA.GetInt32("Numero")
                                dgDetalle.Rows(i).Cells("colClave").Value &= REA.GetString("Clave")
                                dgDetalle.Rows(i).Cells("colDesComponente").Value &= REA.GetString("Descripcion")
                                dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 100 & "%"
                            Next
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                End If
            ElseIf strOpcion = "Terminado" Or strOpcion = "Tela" Then
                etiquetaAcabado.Visible = True
                celdaAcabado.Visible = True
                celdaIDAcabado.Visible = False
                botonAcabado.Visible = True
                etiquetaClasificacion.Visible = True
                celdaClasificacion.Visible = True
                botonClasificacion.Visible = True
                celdaIDClasificacion.Visible = False

                etiquetaDenier.Visible = False
                celdaDenier.Visible = False
                celdaIDDenier.Visible = False
                botonDenier.Visible = False

                etiquetaTitulo.Visible = True
                celdaTitulo.Visible = True

                etiquetaTexturizado.Visible = False
                celdaTexturizado.Visible = False
                celdaIDTexturizado.Visible = False
                If Sesion.IdEmpresa = 22 And strOpcion = "Tela" Then
                    botonTexturizado.Visible = True
                Else
                    botonTexturizado.Visible = False
                End If

                etiquetaSpinning.Visible = True
                celdaSpinning.Visible = True
                celdaIDSpinning.Visible = False
                botonSpinning.Visible = True

                etiquetaFilamento.Visible = False
                celdaFilamento.Visible = False
                celdaIDFilamento.Visible = False
                botonFilamento.Visible = False

                etiquetaNombreProducto.Visible = False
                celdaNombreProducto.Visible = False
                gbHeather.Visible = True
                rbNo.Visible = True
                rbSi.Visible = True
                panelDetalle2.Visible = True
                dgDetalle.Columns("colPorcentaje").Visible = True
                If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                Else
                    If intClase = 106 Or intClase = 9 Or intClase = 416 Or intClase = 2899 Or intClase = 2882 Or intClase = 2355 Or intClase = 2356 Then
                        intAsignar = 11
                    ElseIf intClase = 898 Then
                        intAsignar = 899
                    ElseIf intClase = 896 Then
                        intAsignar = 531
                    ElseIf intClase = 549 Then
                        intAsignar = 442
                    ElseIf intClase = 15 Then
                        intAsignar = 13
                    ElseIf intClase = 105 Then
                        intAsignar = 14

                    End If

                    Dim COM As MySqlCommand
                    Dim REA As MySqlDataReader
                    strSQL = "SELECT c.cat_num Numero, c.cat_clave Clave, c.cat_desc Descripcion"
                    strSQL &= "      FROM Catalogos c"
                    strSQL &= "              WHERE c.cat_clase = 'Material' AND c.cat_num = {IDClase}"

                    strSQL = Replace(strSQL, "{IDClase}", intAsignar)

                    Try
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader

                        REA.Read()
                        If REA.HasRows Then
                            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                dgDetalle.Rows(i).Cells("colEmpresa").Value = Sesion.IdEmpresa
                                dgDetalle.Rows(i).Cells("colArt").Value &= 0
                                dgDetalle.Rows(i).Cells("colItem").Value &= 0
                                dgDetalle.Rows(i).Cells("colNumero").Value &= REA.GetInt32("Numero")
                                dgDetalle.Rows(i).Cells("colClave").Value &= REA.GetString("Clave")
                                dgDetalle.Rows(i).Cells("colDesComponente").Value &= REA.GetString("Descripcion")
                                If intClase = 106 Or intClase = 898 Or intClase = 549 Then
                                    dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 0
                                ElseIf intClase = 9 Or intClase = 15 Or intClase = 105 Or intClase = 416 Or intClase = 2899 Or intClase = 2882 Or intClase = 2355 Or intClase = 2356 Then
                                    dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 100 & "%"
                                End If

                            Next
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                End If
            End If
        Else
            If strOpcion.Length > 1 Then
                If intTipoProd > 0 Or strOpcion = "Otros" Or strOpcion = "Material de empaque" Or strOpcion = "Repuestos" Or strOpcion = "Consumibles" Or strOpcion = "Inventario en Custodia" Or strOpcion = "Proyecto" Or strOpcion = "Combustible" Then
                    etiquetaClase.Visible = True
                    celdaClase.Visible = True
                    botonClase.Visible = True
                    celdaIDClase.Visible = False
                    etiquetaTexturizado.Visible = False
                    celdaTexturizado.Visible = False
                    botonTexturizado.Visible = False
                    celdaIDTexturizado.Visible = False
                    etiquetaTitulo.Visible = False
                    celdaTitulo.Visible = False
                    etiquetaClasificacion.Visible = False
                    celdaClasificacion.Visible = False
                    botonClasificacion.Visible = False
                    celdaIDClasificacion.Visible = False
                    etiquetaDenier.Visible = False
                    celdaDenier.Visible = False
                    botonDenier.Visible = False
                    celdaIDDenier.Visible = False
                    If intClase = 2307 Then
                        etiquetaAcabado.Visible = True
                        celdaAcabado.Visible = True
                        botonAcabado.Visible = True
                        celdaIDAcabado.Visible = False

                    Else
                        etiquetaAcabado.Visible = False
                        celdaAcabado.Visible = False
                        botonAcabado.Visible = False
                        celdaIDAcabado.Visible = False
                    End If

                    etiquetaFilamento.Visible = False
                    celdaFilamento.Visible = False
                    botonFilamento.Visible = False
                    celdaIDFilamento.Visible = False
                    etiquetaSpinning.Visible = False
                    celdaSpinning.Visible = False
                    botonSpinning.Visible = False
                    celdaIDSpinning.Visible = False


                    If intClase = 2306 Then
                        etiquetaNombreProducto.Text = "Fiber Type"
                        etiquetaNombreProducto.Visible = True
                        celdaNombreProducto.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = False
                        celdaTotal.Visible = False
                    ElseIf intClase = 2307 Then
                        etiquetaNombreProducto.Text = "Fiber Type"
                        etiquetaNombreProducto.Visible = True
                        celdaNombreProducto.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = False
                        celdaTotal.Visible = False
                        'ElseIf intClase = 2337 Or intClase = 2338 Then
                        '    etiquetaNombreProducto.Text = "Waste Type"
                        '    etiquetaNombreProducto.Visible = True
                        '    celdaNombreProducto.Visible = True
                        '    panelDetalle2.Visible = True
                        '    dgDetalle.Columns("colPorcentaje").Visible = False
                        '    celdaTotal.Visible = False
                    ElseIf intClase = 330 Then
                        etiquetaNombreProducto.Visible = True
                        celdaNombreProducto.Visible = True
                        panelDetalle2.Visible = False
                        celdaTotal.Visible = False

                    Else
                        etiquetaNombreProducto.Visible = True
                        celdaNombreProducto.Visible = True
                        panelDetalle2.Visible = False
                        celdaTotal.Visible = False

                    End If
                End If
            Else
                Select Case intClase
                    Case 388, 107, 526
                        etiquetaClasificacion.Visible = True
                        celdaClasificacion.Visible = True
                        botonClasificacion.Visible = True
                        celdaIDClasificacion.Visible = False
                        etiquetaAcabado.Visible = False
                        celdaAcabado.Visible = False
                        celdaIDAcabado.Visible = False
                        botonAcabado.Visible = False

                        etiquetaDenier.Visible = False
                        celdaDenier.Visible = False
                        celdaIDDenier.Visible = False
                        botonDenier.Visible = False

                        etiquetaTitulo.Visible = False
                        celdaTitulo.Visible = False

                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        celdaIDTexturizado.Visible = False
                        botonTexturizado.Visible = False

                        etiquetaSpinning.Visible = False
                        celdaSpinning.Visible = False
                        celdaIDSpinning.Visible = False
                        botonSpinning.Visible = False

                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        celdaIDFilamento.Visible = False
                        botonFilamento.Visible = False


                        'gbHeather.Visible = True
                        rbNo.Visible = True
                        rbSi.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = True
                    Case 106, 9, 898, 896, 549, 105, 416, 2899, 2882, 2355, 2356

                        etiquetaAcabado.Visible = True
                        celdaAcabado.Visible = True
                        celdaIDAcabado.Visible = False
                        botonAcabado.Visible = True
                        etiquetaClasificacion.Visible = True
                        celdaClasificacion.Visible = True
                        botonClasificacion.Visible = True
                        celdaIDClasificacion.Visible = False

                        etiquetaDenier.Visible = False
                        celdaDenier.Visible = False
                        celdaIDDenier.Visible = False
                        botonDenier.Visible = False

                        etiquetaTitulo.Visible = True
                        celdaTitulo.Visible = True

                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        celdaIDTexturizado.Visible = False
                        botonTexturizado.Visible = False

                        etiquetaSpinning.Visible = True
                        celdaSpinning.Visible = True
                        celdaIDSpinning.Visible = False
                        botonSpinning.Visible = True

                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        celdaIDFilamento.Visible = False
                        botonFilamento.Visible = False

                        gbHeather.Visible = True
                        rbNo.Visible = True
                        rbSi.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = True
                        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                        Else
                            If intClase = 106 Or intClase = 9 Or intClase = 416 Or intClase = 2899 Or intClase = 2882 Or intClase = 2355 Or intClase = 2356 Then
                                intAsignar = 11
                            ElseIf intClase = 898 Then
                                intAsignar = 899
                            ElseIf intClase = 896 Then
                                intAsignar = 531
                            ElseIf intClase = 549 Then
                                intAsignar = 442
                            ElseIf intClase = 15 Then
                                intAsignar = 13
                            ElseIf intClase = 105 Then
                                intAsignar = 14

                            End If

                            Dim COM As MySqlCommand
                            Dim REA As MySqlDataReader
                            strSQL = "SELECT c.cat_num Numero, c.cat_clave Clave, c.cat_desc Descripcion"
                            strSQL &= "      FROM Catalogos c"
                            strSQL &= "              WHERE c.cat_clase = 'Material' AND c.cat_num = {IDClase}"

                            strSQL = Replace(strSQL, "{IDClase}", intAsignar)

                            Try
                                MyCnn.CONECTAR = strConexion
                                COM = New MySqlCommand(strSQL, CON)
                                REA = COM.ExecuteReader

                                REA.Read()
                                If REA.HasRows Then
                                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                        dgDetalle.Rows(i).Cells("colEmpresa").Value = Sesion.IdEmpresa
                                        dgDetalle.Rows(i).Cells("colArt").Value &= 0
                                        dgDetalle.Rows(i).Cells("colItem").Value &= 0
                                        dgDetalle.Rows(i).Cells("colNumero").Value &= REA.GetInt32("Numero")
                                        dgDetalle.Rows(i).Cells("colClave").Value &= REA.GetString("Clave")
                                        dgDetalle.Rows(i).Cells("colDesComponente").Value &= REA.GetString("Descripcion")
                                        If intClase = 106 Or intClase = 898 Or intClase = 549 Then
                                            dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 0
                                        ElseIf intClase = 9 Or intClase = 15 Or intClase = 105 Or intClase = 416 Or intClase = 2899 Or intClase = 2882 Or intClase = 2355 Or intClase = 2356 Then
                                            dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 100 & "%"
                                        End If

                                    Next
                                End If

                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try
                        End If
                    Case 10
                        Dim opt As New frmOption
                        opt.Titulo = "Type"
                        opt.Mensaje = "Select Type"
                        opt.Opciones = "Simple" & "|" & "Textured"

                        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                            Select Case opt.Seleccion

                                Case 0
                                    intTipoPoly = 0
                                Case 1
                                    intTipoPoly = 1
                            End Select
                        Else
                            Exit Sub
                        End If

                        If intTipoPoly = 0 Then
                            etiquetaAcabado.Visible = True
                            celdaAcabado.Visible = True
                            celdaIDAcabado.Visible = False
                            botonAcabado.Visible = True
                            etiquetaClasificacion.Visible = True
                            celdaClasificacion.Visible = True
                            botonClasificacion.Visible = True
                            celdaIDClasificacion.Visible = False

                            etiquetaDenier.Visible = False
                            celdaDenier.Visible = False
                            celdaIDDenier.Visible = False
                            botonDenier.Visible = False

                            etiquetaTitulo.Visible = True
                            celdaTitulo.Visible = True

                            etiquetaTexturizado.Visible = False
                            celdaTexturizado.Visible = False
                            celdaIDTexturizado.Visible = False
                            botonTexturizado.Visible = False

                            etiquetaSpinning.Visible = True
                            celdaSpinning.Visible = True
                            celdaIDSpinning.Visible = False
                            botonSpinning.Visible = True

                            etiquetaFilamento.Visible = False
                            celdaFilamento.Visible = False
                            celdaIDFilamento.Visible = False
                            botonFilamento.Visible = False

                            'gbHeather.Visible = False
                            rbNo.Visible = True
                            rbSi.Visible = True
                            panelDetalle2.Visible = True
                            dgDetalle.Columns("colPorcentaje").Visible = True
                        ElseIf intTipoPoly = 1 Then
                            etiquetaAcabado.Visible = False
                            celdaAcabado.Visible = False
                            celdaIDAcabado.Visible = False
                            botonAcabado.Visible = False
                            etiquetaClasificacion.Visible = True
                            celdaClasificacion.Visible = True
                            botonClasificacion.Visible = True
                            celdaIDClasificacion.Visible = False

                            etiquetaDenier.Visible = True
                            celdaDenier.Visible = True
                            celdaIDDenier.Visible = False
                            botonDenier.Visible = True

                            etiquetaTitulo.Visible = False
                            celdaTitulo.Visible = False

                            etiquetaTexturizado.Visible = True
                            celdaTexturizado.Visible = True
                            celdaIDTexturizado.Visible = False
                            botonTexturizado.Visible = True

                            etiquetaSpinning.Visible = False
                            celdaSpinning.Visible = False
                            celdaIDSpinning.Visible = False
                            botonSpinning.Visible = False

                            etiquetaFilamento.Visible = True
                            celdaFilamento.Visible = True
                            celdaIDFilamento.Visible = False
                            botonFilamento.Visible = True

                            'gbHeather.Visible = False
                            rbNo.Visible = True
                            rbSi.Visible = True
                            panelDetalle2.Visible = True
                            dgDetalle.Columns("colPorcentaje").Visible = True
                            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                            Else
                                Dim COM As MySqlCommand
                                Dim REA As MySqlDataReader
                                strSQL = "SELECT c.cat_num Numero, c.cat_clave Clave, c.cat_desc Descripcion"
                                strSQL &= "      FROM Catalogos c"
                                strSQL &= "              WHERE c.cat_clase = 'Material' AND c.cat_num = {IDClase}"

                                strSQL = Replace(strSQL, "{IDClase}", 12)

                                Try
                                    MyCnn.CONECTAR = strConexion
                                    COM = New MySqlCommand(strSQL, CON)
                                    REA = COM.ExecuteReader

                                    REA.Read()
                                    If REA.HasRows Then
                                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                            dgDetalle.Rows(i).Cells("colEmpresa").Value = Sesion.IdEmpresa
                                            dgDetalle.Rows(i).Cells("colArt").Value &= 0
                                            dgDetalle.Rows(i).Cells("colItem").Value &= 0
                                            dgDetalle.Rows(i).Cells("colNumero").Value &= REA.GetInt32("Numero")
                                            dgDetalle.Rows(i).Cells("colClave").Value &= REA.GetString("Clave")
                                            dgDetalle.Rows(i).Cells("colDesComponente").Value &= REA.GetString("Descripcion")
                                            dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 100 & "%"
                                        Next
                                    End If
                                Catch ex As Exception
                                    MsgBox(ex.ToString)
                                End Try
                            End If
                        End If
                    Case 15
                        etiquetaAcabado.Visible = False
                        celdaAcabado.Visible = False
                        celdaIDAcabado.Visible = False
                        botonAcabado.Visible = False

                        etiquetaDenier.Visible = True
                        celdaDenier.Visible = True
                        celdaIDDenier.Visible = False
                        botonDenier.Visible = True
                        etiquetaClasificacion.Visible = True
                        celdaClasificacion.Visible = True
                        botonClasificacion.Visible = True
                        celdaIDClasificacion.Visible = False

                        etiquetaTitulo.Visible = False
                        celdaTitulo.Visible = False

                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        celdaIDTexturizado.Visible = False
                        botonTexturizado.Visible = False

                        etiquetaSpinning.Visible = False
                        celdaSpinning.Visible = False
                        celdaIDSpinning.Visible = False
                        botonSpinning.Visible = False

                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        celdaIDFilamento.Visible = False
                        botonFilamento.Visible = False

                        'gbHeather.Visible = False
                        rbNo.Visible = True
                        rbSi.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = True
                        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                        Else
                            Dim COM As MySqlCommand
                            Dim REA As MySqlDataReader
                            strSQL = "SELECT c.cat_num Numero, c.cat_clave Clave, c.cat_desc Descripcion"
                            strSQL &= "      FROM Catalogos c"
                            strSQL &= "              WHERE c.cat_clase = 'Material' AND c.cat_num = {IDClase}"

                            strSQL = Replace(strSQL, "{IDClase}", 13)

                            Try
                                MyCnn.CONECTAR = strConexion
                                COM = New MySqlCommand(strSQL, CON)
                                REA = COM.ExecuteReader

                                REA.Read()
                                If REA.HasRows Then
                                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                        dgDetalle.Rows(i).Cells("colEmpresa").Value = Sesion.IdEmpresa
                                        dgDetalle.Rows(i).Cells("colArt").Value &= 0
                                        dgDetalle.Rows(i).Cells("colItem").Value &= 0
                                        dgDetalle.Rows(i).Cells("colNumero").Value &= REA.GetInt32("Numero")
                                        dgDetalle.Rows(i).Cells("colClave").Value &= REA.GetString("Clave")
                                        dgDetalle.Rows(i).Cells("colDesComponente").Value &= REA.GetString("Descripcion")
                                        dgDetalle.Rows(i).Cells("colPorcentaje").Value &= 100 & "%"
                                    Next
                                End If

                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try
                        End If
                    Case 331, 2337, 2338, 330, 2307

                        etiquetaClase.Visible = True
                        celdaClase.Visible = True
                        botonClase.Visible = True
                        celdaIDClase.Visible = False
                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        botonTexturizado.Visible = False
                        celdaIDTexturizado.Visible = False
                        etiquetaTitulo.Visible = False
                        celdaTitulo.Visible = False
                        etiquetaClasificacion.Visible = False
                        celdaClasificacion.Visible = False
                        botonClasificacion.Visible = False
                        celdaIDClasificacion.Visible = False
                        etiquetaDenier.Visible = False
                        celdaDenier.Visible = False
                        botonDenier.Visible = False
                        celdaIDDenier.Visible = False
                        If intClase = 2307 Then
                            etiquetaAcabado.Visible = True
                            celdaAcabado.Visible = True
                            botonAcabado.Visible = True
                            celdaIDAcabado.Visible = False

                        Else
                            etiquetaAcabado.Visible = False
                            celdaAcabado.Visible = False
                            botonAcabado.Visible = False
                            celdaIDAcabado.Visible = False
                        End If

                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        botonFilamento.Visible = False
                        celdaIDFilamento.Visible = False
                        etiquetaSpinning.Visible = False
                        celdaSpinning.Visible = False
                        botonSpinning.Visible = False
                        celdaIDSpinning.Visible = False


                        If intClase = 2306 Then
                            etiquetaNombreProducto.Text = "Fiber Type"
                            etiquetaNombreProducto.Visible = True
                            celdaNombreProducto.Visible = True
                            panelDetalle2.Visible = True
                            dgDetalle.Columns("colPorcentaje").Visible = False
                            celdaTotal.Visible = False
                        ElseIf intClase = 2307 Then
                            etiquetaNombreProducto.Text = "Fiber Type"
                            etiquetaNombreProducto.Visible = True
                            celdaNombreProducto.Visible = True
                            panelDetalle2.Visible = True
                            dgDetalle.Columns("colPorcentaje").Visible = False
                            celdaTotal.Visible = False
                            'ElseIf intClase = 2337 Or intClase = 2338 Then
                            '    etiquetaNombreProducto.Text = "Waste Type"
                            '    etiquetaNombreProducto.Visible = True
                            '    celdaNombreProducto.Visible = True
                            '    panelDetalle2.Visible = True
                            '    dgDetalle.Columns("colPorcentaje").Visible = False
                            '    celdaTotal.Visible = False
                        ElseIf intClase = 330 Then
                            etiquetaNombreProducto.Visible = True
                            celdaNombreProducto.Visible = True
                            panelDetalle2.Visible = False
                            celdaTotal.Visible = False

                        Else
                            etiquetaNombreProducto.Visible = True
                            celdaNombreProducto.Visible = True
                            panelDetalle2.Visible = False
                            celdaTotal.Visible = False

                        End If
                    Case 2306 'FIBRA 2020-02-26
                        'TODO
                        etiquetaAcabado.Visible = True
                        celdaAcabado.Visible = True
                        celdaIDAcabado.Visible = False
                        botonAcabado.Visible = True

                        etiquetaClasificacion.Visible = True
                        celdaClasificacion.Visible = True
                        botonClasificacion.Visible = True
                        celdaIDClasificacion.Visible = False

                        etiquetaDenier.Visible = True
                        celdaDenier.Visible = True
                        celdaIDDenier.Visible = False
                        botonDenier.Visible = True

                        etiquetaTitulo.Visible = False
                        celdaTitulo.Visible = False

                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        celdaIDTexturizado.Visible = False
                        botonTexturizado.Visible = False

                        etiquetaSpinning.Visible = False
                        celdaSpinning.Visible = False
                        celdaIDSpinning.Visible = False
                        botonSpinning.Visible = False

                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        celdaIDFilamento.Visible = False
                        botonFilamento.Visible = False

                        etiquetaMicronaire.Visible = True
                        celdaMicronaire.Visible = True
                        celdaIdMicronaire.Visible = False
                        botonMicronaire.Visible = True

                        'gbHeather.Visible = False
                        rbNo.Visible = True
                        rbSi.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = True




                    Case Else
                        Me.Tag = "Nuevo"
                        Dim COM As MySqlCommand
                        Dim conec As MySqlConnection
                        Dim intNumero As Integer

                        LimpiarPanel()
                        MostrarLista(False)
                        celdaClase.Enabled = True
                        celdaIDClase.Enabled = True
                        botonClase.Enabled = True

                        etiquetaCodigo.Visible = True
                        celdaCodigo.Visible = True
                        etiquetaClase.Visible = True
                        celdaClase.Visible = True
                        botonClase.Visible = True
                        etiquetaAcabado.Visible = False
                        celdaAcabado.Visible = False
                        botonAcabado.Visible = False
                        celdaIDAcabado.Visible = False
                        etiquetaTitulo.Visible = False
                        celdaTitulo.Visible = False
                        etiquetaSpinning.Visible = False
                        celdaSpinning.Visible = False
                        botonSpinning.Visible = False
                        celdaIDSpinning.Visible = False
                        etiquetaDenier.Visible = False
                        celdaDenier.Visible = False
                        botonDenier.Visible = False
                        etiquetaTexturizado.Visible = False
                        celdaTexturizado.Visible = False
                        botonTexturizado.Visible = False
                        etiquetaFilamento.Visible = False
                        celdaFilamento.Visible = False
                        botonFilamento.Visible = False
                        'gbHeather.Visible = False
                        rbSi.Visible = True
                        rbNo.Visible = True
                        panelDetalle2.Visible = True
                        dgDetalle.Columns("colPorcentaje").Visible = True

                        etiquetaNombreProducto.Visible = False
                        celdaNombreProducto.Visible = False


                        strFila = "" & "|"
                        strFila = "" & "|"
                        strFila = "" & "|"
                        strFila = "" & "|"
                        strFila = "" & "|"
                        strFila = "" & "|"
                        strFila = ""

                        cFunciones.AgregarFila(dgDetalle, strFila)
                        dgDetalle.DefaultCellStyle.BackColor = Color.Beige

                        celdaArancel.Text = "0.00"

                        strSQL = "SELECT IFNULL(MAX(a.art_codigo + 1),1)"
                        strSQL &= "   FROM Articulos a"
                        strSQL &= "          WHERE a.art_sisemp = {empresa}"

                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM = New MySqlCommand(strSQL, conec)
                        Using conec
                            intNumero = COM.ExecuteScalar
                            COM.Dispose()
                            COM = Nothing
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End Using

                        celdaCodigo.Text = intNumero

                        Me.Tag = "Nuevo"
                End Select
            End If
        End If
        'Clasificacion no se utiliza en HSM
        'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Then
        '    etiquetaClasificacion.Visible = False
        '    celdaClasificacion.Visible = False
        '    botonClasificacion.Visible = False
        '    celdaIDClasificacion.Visible = False
        'End If

        'Coloca en cero los campos de ID para que al momento de guardar no de ningun error
        celdaIDAcabado.Text = INT_CERO
        celdaIDClase.Text = INT_CERO
        celdaIDClasificacion.Text = INT_CERO
        celdaIDDenier.Text = INT_CERO
        celdaIDFilamento.Text = INT_CERO
        celdaIDSpinning.Text = INT_CERO
        celdaIDTexturizado.Text = INT_CERO
    End Sub

    Private Function EncontrarClave(ByVal intNumero As Integer) As String
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT * "
        strSQL &= "  FROM Catalogos"
        strSQL &= "      WHERE cat_num = {numero}"

        strSQL = Replace(strSQL, "{numero}", intNumero)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            REA.Read()
            If Not REA.HasRows Then
                MsgBox("No se encontro el ITEM en el Catalogo.")
                EncontrarClave = vbNullString
            Else
                EncontrarClave = REA.GetString("cat_clave")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function
    Private Function ConstruccionNombreCorto() As Boolean
        Dim strCot As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim i As Integer = INT_CERO
        Dim j As Integer = INT_CERO
        Dim NCorto As String = STR_VACIO
        Dim logCot As Boolean
        Dim intIDClase As Integer
        Dim intCot As Integer
        Dim logCancel As Boolean
        Dim strTemp As String = STR_VACIO
        Dim strDato As String = STR_VACIO
        Dim strExt As String = STR_VACIO
        Dim intPalabraRepetida As Integer = INT_CERO
        Dim strTexturizado As String = STR_VACIO
        Dim strTela As String = vbNullString

        intCot = 9
        intIDClase = celdaIDClase.Text

        If intTipoProd > 0 Or celdaClase.Text = "Pallets" Or strOpcion = "Maquinaria" Or intIDClase = 331 Or intIDClase = 2337 Or intIDClase = 2338 Or intIDClase = 330 Or celdaClase.Text = "Packing" Or celdaClase.Text = "Parts" Or celdaClase.Text = "Consumables" Or celdaClase.Text = "Inventory in Custody" Or celdaClase.Text = "Proyecto" Or celdaClase.Text = "Fuel" Then
        Else
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                If strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Or intIDClase = 388 Or intIDClase = 896 Or intIDClase = 2307 Or intIDClase = 2369 Or intIDClase = 2370 Or intIDClase = 2371 Or intIDClase = 2376 Then
                Else
                    If dgDetalle.Rows.Count = 0 Then
                        MsgBox("Ingrese Materiales para continuar")
                        Exit Function
                    End If
                End If
            Else
                If dgDetalle.Rows.Count = 0 Then
                    MsgBox("Ingrese Materiales para continuar")
                    Exit Function
                End If
            End If
            strSQL = "SELECT cat_clave"
            strSQL &= "      FROM Catalogos"
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                If dgDetalle.Rows.Count > 1 Then
                    strSQL &= "             WHERE cat_num = " & dgDetalle.Rows(0).Cells("colNumero").Value
                End If
            Else
                strSQL &= "             WHERE cat_num = " & dgDetalle.Rows(0).Cells("colNumero").Value
            End If

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                strCot = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        End If


        logCot = False
        intIDClase = celdaIDClase.Text
        If intTipoProd > 0 Or celdaClase.Text = "Pallets" Or strOpcion = "Maquinaria" Or intIDClase = 331 Or intIDClase = 2337 Or intIDClase = 2338 Or intIDClase = 330 Or celdaClase.Text = "Packing" Or celdaClase.Text = "Parts" Or celdaClase.Text = "Consumables" Or celdaClase.Text = "Inventory in Custody" Or celdaClase.Text = "Proyecto" Or celdaClase.Text = "Fuel" Then
            NCorto = celdaNombreProducto.Text
        ElseIf (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
            If strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Or intIDClase = 388 Or intIDClase = 896 Or intIDClase = 2307 Or intIDClase = 2369 Or intIDClase = 2370 Or intIDClase = 2371 Or intIDClase = 2376 Then
                NCorto = celdaNombreProducto.Text
            Else
                For i = 0 To dgDetalle.Rows.Count - 1
                    If Not (dgDetalle.Rows(i).Cells("colNumero").Value = vbNullString) Then
                        If dgDetalle.Columns("colPorcentaje").Visible = False Then
                            NCorto = NCorto & " " & dgDetalle.Rows(i).Cells("colClave").Value
                        Else
                            NCorto = NCorto & " " & Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString) & "%"
                            NCorto = NCorto & " " & dgDetalle.Rows(i).Cells("colClave").Value
                        End If


                        If (dgDetalle.Rows(i).Cells("colClave").Value = strCot) And (dgDetalle.Rows(i).Cells("colPorcentaje").Value) = "100%" Or (dgDetalle.Rows(i).Cells("colPorcentaje").Value = "100.00") Then
                            logCot = True
                        End If
                    End If
                Next
            End If
        Else
            For i = 0 To dgDetalle.Rows.Count - 1
                If Not (dgDetalle.Rows(i).Cells("colNumero").Value = vbNullString) Then
                    If dgDetalle.Columns("colPorcentaje").Visible = False Then
                        NCorto = NCorto & " " & dgDetalle.Rows(i).Cells("colClave").Value
                    Else
                        NCorto = NCorto & " " & Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString) & "%"
                        NCorto = NCorto & " " & dgDetalle.Rows(i).Cells("colClave").Value
                    End If


                    If (dgDetalle.Rows(i).Cells("colClave").Value = strCot) And (dgDetalle.Rows(i).Cells("colPorcentaje").Value) = "100%" Or (dgDetalle.Rows(i).Cells("colPorcentaje").Value = "100.00") Then
                        logCot = True
                    End If
                End If
            Next
        End If

        If intIDClase = 416 Then
            If Sesion.IdEmpresa = 22 Then
            Else
                strTela = "TELA "
            End If

        End If
        CeldaDecripcionCorta.Text = vbNullString
        celdaDescripcionLarga.Text = vbNullString

        If intTipoProd > 0 Or celdaClase.Text = "Pallets" Or strOpcion = "Maquinaria" Or celdaClase.Text = "Proyecto" Or celdaClase.Text = "Packing" Or celdaClase.Text = "Parts" Or celdaClase.Text = "Consumables" Or celdaClase.Text = "Inventory in Custody" Or celdaClase.Text = "Fuel" Then
            CeldaDecripcionCorta.Text = NCorto
        Else
            Select Case intIDClase
                Case 9, 106, 549, 105, 898, 896, 416, 2899, 2882, 2355, 2356
                    '   
                    'Valida si la clase es "cotton" y que el porcentaje sea 100% en un solo registro
                    '
                    'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                    'Else
                    '    If intIDClase = intCot And Not logCot Then
                    '        MsgBox("Review Product Composition", vbExclamation, "Note")
                    '        logCancel = True
                    '    End If
                    'End If

                    CeldaDecripcionCorta.Text = celdaTitulo.Text & NCorto & " "

                    strTemp = vbNullString
                    If celdaIDAcabado.Text > vbEmpty Then
                        strTemp = EncontrarClave(celdaIDAcabado.Text)
                    End If
                    'Procedimiento que sirve para evitar que se repitan palabras en el nombre de los hilos
                    CeldaDecripcionCorta.Text = Replace(CeldaDecripcionCorta.Text, strTemp, "")
                    CeldaDecripcionCorta.Text = CeldaDecripcionCorta.Text & strTemp

                    strTemp = vbNullString
                    If celdaIDSpinning.Text > vbEmpty Then
                        strTemp = EncontrarClave(celdaIDSpinning.Text)
                    End If
                    CeldaDecripcionCorta.Text = strTela & CeldaDecripcionCorta.Text & " " & strTemp

                Case 10

                    If intTipoPoly = 1 Then
                        strSQL = STR_VACIO
                        strSQL = " SELECT c.cat_clave "
                        strSQL &= " From Catalogos c "
                        strSQL &= " Where cat_clase = 'Texture' AND c.cat_num = " & celdaIDTexturizado.Text

                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM = New MySqlCommand(strSQL, conec)
                        Using conec
                            strTexturizado = COM.ExecuteScalar
                            COM.Dispose()
                            COM = Nothing
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End Using


                        CeldaDecripcionCorta.Text = strTexturizado & " " & celdaDenier.Text & "/" & celdaFilamento.Text & " " & dgDetalle.Rows(0).Cells("colClave").Value '& " " & celdaDescripcion.Text
                    Else

                        CeldaDecripcionCorta.Text = celdaTitulo.Text & NCorto & " "

                        If celdaIDAcabado.Text > vbEmpty Then
                            strTemp = EncontrarClave(celdaIDAcabado.Text)
                        End If
                        'Procedimiento que sirve para evitar que se repitan palabras en el nombre de los hilos
                        CeldaDecripcionCorta.Text = Replace(CeldaDecripcionCorta.Text, strTemp, "")
                        CeldaDecripcionCorta.Text = CeldaDecripcionCorta.Text & strTemp

                        strTemp = vbNullString
                        If celdaIDSpinning.Text > vbEmpty Then
                            strTemp = EncontrarClave(celdaIDSpinning.Text)
                        End If
                        CeldaDecripcionCorta.Text = CeldaDecripcionCorta.Text & " " & strTemp
                    End If


                Case 15
                    CeldaDecripcionCorta.Text = "SPANDEX "
                    CeldaDecripcionCorta.Text = CeldaDecripcionCorta.Text & EncontrarClave(celdaIDDenier.Text) & " DENIER"

            'Case 416
            '    CeldaDecripcionCorta.Text = Trim(UCase(celdaClase.Text) & NCorto)

                Case 331
                    CeldaDecripcionCorta.Text = NCorto
                'celdaDescripcionHilo3.Text = celdaNombreProducto.Text
                Case 2306

                    If dgDetalle.Rows.Count = INT_CERO Then
                        CeldaDecripcionCorta.Text = celdaDenier.Text & "DX" & celdaMicronaire.Text & "MM  " & celdaAcabado.Text
                    Else
                        CeldaDecripcionCorta.Text = celdaDenier.Text & "DX" & celdaMicronaire.Text & "MM  " & dgDetalle.Rows(0).Cells("colDesComponente").Value & "  " & celdaAcabado.Text
                    End If
                Case 2307
                    CeldaDecripcionCorta.Text = NCorto
                    'celdaDescripcionHilo3.Text = celdaNombreProducto.Text

                    strTemp = vbNullString
                    If celdaIDAcabado.Text > vbEmpty Then
                        strTemp = EncontrarClave(celdaIDAcabado.Text)
                    End If
                    'Procedimiento que sirve para evitar que se repitan palabras en el nombre de los hilos
                    CeldaDecripcionCorta.Text = Replace(CeldaDecripcionCorta.Text, strTemp, " ")
                    CeldaDecripcionCorta.Text = CeldaDecripcionCorta.Text & " " & strTemp

                Case 2337
                    CeldaDecripcionCorta.Text = NCorto
                Case 2338
                    CeldaDecripcionCorta.Text = NCorto
                Case 331
                    CeldaDecripcionCorta.Text = NCorto
                Case 330
                    CeldaDecripcionCorta.Text = NCorto
                Case 388, 896, 2307, 2369, 2370, 2371, 2376
                    If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                        CeldaDecripcionCorta.Text = NCorto
                    End If
            End Select
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.idGiro = 2 Then
                If strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Then
                    CeldaDecripcionCorta.Text = NCorto
                End If
            End If
        End If
        strExt = vbNullString
        strDato = Trim(celdaDescripcion.Text)
        If Strings.Left(strDato, 1) = "/" Then
            i = InStr(1, strDato, Space(1))
            If (i > vbEmpty) Then
                strExt = Strings.Left(strDato, i - 1)
                strDato = Strings.Right(strDato, Len(strDato) - i)
            End If
        End If

        CeldaDecripcionCorta.Text = Replace(CeldaDecripcionCorta.Text, "{ext}", strExt)
        CeldaDecripcionCorta.Text = UCase(Trim(CeldaDecripcionCorta.Text & " " & strDato))

        'Devolver resultado
        ConstruccionNombreCorto = Not (logCancel)

    End Function

    Private Function ConstruccionNombreLargo() As Boolean
        Dim strDato As String = STR_VACIO
        Dim strExt As String = STR_VACIO
        Dim NLargo As String = STR_VACIO
        Dim i As Integer = INT_CERO
        Dim strTemp As String = STR_VACIO
        Dim intIDClase As Integer = INT_CERO
        Dim intPalabraRepetida As Integer = INT_CERO
        Dim strPalabra As String = STR_VACIO
        Dim strTela As String = vbNullString

        NLargo = vbNullString
        intIDClase = celdaIDClase.Text

        If intTipoProd > 0 Or celdaClase.Text = "Pallets" Or strOpcion = "Maquinaria" Or intIDClase = 331 Or intIDClase = 330 Or intIDClase = 2337 Or intIDClase = 2338 Or celdaClase.Text = "Packing" Or celdaClase.Text = "Parts" Or celdaClase.Text = "Consumables" Or celdaClase.Text = "Inventory in Custody" Or celdaClase.Text = "Proyecto" Or celdaClase.Text = "Fuel" Then
            NLargo = celdaNombreProducto.Text
        ElseIf (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
            If intTipoProd > 0 Or strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Or intIDClase = 388 Or intIDClase = 896 Or intIDClase = 2307 Or intIDClase = 2369 Or intIDClase = 2370 Or intIDClase = 2371 Or intIDClase = 2376 Then
                NLargo = celdaNombreProducto.Text
            Else
                For i = 0 To dgDetalle.Rows.Count - 1
                    If dgDetalle.Rows(i).Cells("colNumero").Value = vbNullString Then Exit For
                    If dgDetalle.Columns("colPorcentaje").Visible = False Then
                        NLargo = NLargo & " " & Trim(dgDetalle.Rows(i).Cells("colDesComponente").Value)
                    Else
                        NLargo = NLargo & " " & Val(Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString)) & "%"
                        NLargo = NLargo & " " & Trim(dgDetalle.Rows(i).Cells("colDesComponente").Value)
                    End If
                Next
            End If
        Else
            For i = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colNumero").Value = vbNullString Then Exit For
                If dgDetalle.Columns("colPorcentaje").Visible = False Then
                    NLargo = NLargo & " " & Trim(dgDetalle.Rows(i).Cells("colDesComponente").Value)
                Else
                    NLargo = NLargo & " " & Val(Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString)) & "%"
                    NLargo = NLargo & " " & Trim(dgDetalle.Rows(i).Cells("colDesComponente").Value)
                End If
            Next
        End If

        If intIDClase = 416 Then
            If Sesion.IdEmpresa = 22 Then
            Else
                strTela = "TELA "
            End If

        End If

        If intTipoProd > 0 Or celdaClase.Text = "Pallets" Or strOpcion = "Maquinaria" Or celdaClase.Text = "Packing" Or celdaClase.Text = "Parts" Or celdaClase.Text = "Consumables" Or celdaClase.Text = "Inventory in Custody" Or celdaClase.Text = "Proyecto" Or celdaClase.Text = "Fuel" Then
            celdaDescripcionLarga.Text = NLargo
        Else
            Select Case intIDClase
                Case 9, 106, 549, 105, 898, 896, 416, 2899, 2882, 2355, 2356
                    celdaDescripcionLarga.Text = celdaTitulo.Text & NLargo & " "
                    'Procedimiento que sirve para evitar que se repitan palabras en el nombre de los hilos
                    'ACABADO
                    strPalabra = celdaAcabado.Text.ToUpper
                    celdaDescripcionLarga.Text = Replace(celdaDescripcionLarga.Text, strPalabra, "")
                    celdaDescripcionLarga.Text = celdaDescripcionLarga.Text & celdaAcabado.Text

                    'SPINNING
                    celdaDescripcionLarga.Text = strTela & celdaDescripcionLarga.Text & " " & celdaSpinning.Text

                Case 10
                    If intTipoPoly = 1 Then
                        celdaDescripcionLarga.Text = celdaTexturizado.Text & " " & celdaDenier.Text & "/" & celdaFilamento.Text & " " & dgDetalle.Rows(0).Cells("colClave").Value & " "
                    Else

                        celdaDescripcionLarga.Text = celdaTitulo.Text & NLargo & " "

                        'Procedimiento que sirve para evitar que se repitan palabras en el nombre de los hilos
                        'ACABADO
                        strPalabra = STR_VACIO
                        strPalabra = celdaAcabado.Text.ToUpper
                        celdaDescripcionLarga.Text = Replace(celdaDescripcionLarga.Text, strPalabra, "")
                        celdaDescripcionLarga.Text = celdaDescripcionLarga.Text & celdaAcabado.Text

                        'SPINNING
                        celdaDescripcionLarga.Text = celdaDescripcionLarga.Text & " " & celdaSpinning.Text
                    End If


                Case 15
                    celdaDescripcionLarga.Text = "SPANDEX "
                    celdaDescripcionLarga.Text = celdaDescripcionLarga.Text & celdaDenier.Text & " DENIER"

            'Case 416
            '    celdaDescripcionLarga.Text = Trim(UCase(celdaClase.Text) & NLargo)

                Case 331
                    celdaDescripcionLarga.Text = NLargo

                Case 330
                    celdaDescripcionLarga.Text = NLargo

                Case 2306
                    If dgDetalle.Rows.Count = INT_CERO Then
                        celdaDescripcionLarga.Text = celdaDenier.Text & "DX" & celdaMicronaire.Text & "MM  " & celdaAcabado.Text
                    Else
                        celdaDescripcionLarga.Text = celdaDenier.Text & "DX" & celdaMicronaire.Text & "MM  " & dgDetalle.Rows(0).Cells("colDesComponente").Value & "  " & celdaAcabado.Text
                    End If
                Case 2307
                    celdaDescripcionLarga.Text = NLargo
                    'celdaDescripcionHilo3.Text = celdaNombreProducto.Text

                    'Procedimiento que sirve para evitar que se repitan palabras en el nombre de los hilos
                    'ACABADO
                    strPalabra = celdaAcabado.Text.ToUpper
                    celdaDescripcionLarga.Text = Replace(celdaDescripcionLarga.Text, strPalabra, " ")
                    celdaDescripcionLarga.Text = celdaDescripcionLarga.Text & " " & celdaAcabado.Text

                Case 2337
                    celdaDescripcionLarga.Text = NLargo
                Case 2338
                    celdaDescripcionLarga.Text = NLargo
                Case 388, 896, 2307, 2369, 2370, 2371, 2376
                    If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                        celdaDescripcionLarga.Text = NLargo
                    End If
            End Select
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.idGiro = 2 Then
                If strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Then
                    celdaDescripcionLarga.Text = NLargo
                End If
            End If

        End If
        strExt = vbNullString
        strDato = Trim(celdaDescripcion.Text)
        If Strings.Left(strDato, 1) = "/" Then
            i = InStr(1, strDato, Space(1))
            If (i > vbEmpty) Then
                strExt = Strings.Left(strDato, i - 1)
                strDato = Strings.Right(strDato, Len(strDato) - i)
            End If
        End If

        celdaDescripcionLarga.Text = Replace(celdaDescripcionLarga.Text, "{ext}", strExt)
        celdaDescripcionLarga.Text = UCase(Trim(celdaDescripcionLarga.Text & " " & strDato))

    End Function

    Private Sub CalcularTotalPorcentajes()
        Dim i As Integer = INT_CERO
        Dim dblPorcentaje As Double


        Try

            dblDocTotal = 0

            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = True Then
                    dblPorcentaje = CDbl(Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString))
                    dblDocTotal = dblDocTotal + dblPorcentaje
                End If
            Next

            celdaTotal.Text = dblDocTotal.ToString(FORMATO_MONEDA) & "%"

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Actualiza la descripcion en el detalle de los docs.
    Private Sub ActualizarDatos()
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strDCorta As String = STR_VACIO
        Dim strDLarga As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand


        strDCorta = CeldaDecripcionCorta.Text
        strDLarga = celdaDescripcionLarga.Text

        'Actualiza la descripción corta en los docs.: 55/Datos para póliza, 180/póliza e 47/ingreso a bodega
        strSQL = " UPDATE Dcmtos_DTL"
        strSQL &= "      INNER JOIN Inventarios On inv_sisemp = DDoc_Sis_Emp And inv_numero = DDoc_Prd_Cod"
        strSQL &= "              LEFT JOIN Catalogos On cat_clase = 'Paises' AND cat_num = inv_lugarfab SET DDoc_Prd_Des= TRIM(CONCAT(" & "'" & strDCorta & "'" & ",' ', IFNULL(cat_clave,'')))"
        strSQL &= "       WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (55, 180, 47) AND inv_artcodigo={codigo}"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_DTL"
            strSQL &= "      INNER JOIN Inventarios On inv_sisemp = DDoc_Sis_Emp And inv_numero = DDoc_Prd_Cod"
            strSQL &= "              LEFT JOIN Catalogos On cat_clase = 'Paises' AND cat_num = inv_lugarfab SET DDoc_Prd_Des= TRIM(CONCAT(" & "'" & strDCorta & "'" & ",' ', IFNULL(cat_clave,'')))"
            strSQL &= "       WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (55, 180, 47) AND inv_artcodigo={codigo}"
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Val(celdaCodigo.Text))

        'Ejecuta la instrucción
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        'Actualiza la descripción larga en los docs.: 71/Pedido, 127/Confirmación
        strSQL2 = " UPDATE Dcmtos_DTL"
        strSQL2 &= "     INNER JOIN Inventarios ON inv_sisemp = DDoc_Sis_Emp AND inv_numero = DDoc_Prd_Cod"
        strSQL2 &= "             LEFT JOIN Catalogos ON cat_clase = 'Paises' AND cat_num = inv_lugarfab SET DDoc_Prd_Des= TRIM(CONCAT(" & "'" & strDLarga & "'" & ",' ', IFNULL(cat_clave,'')))"
        strSQL2 &= "      WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (75, 127) AND inv_artcodigo={codigo}"

        If Sesion.IdEmpresa = 18 Then
            strSQL2 &= "; UPDATE PDM.Dcmtos_DTL"
            strSQL2 &= "     INNER JOIN Inventarios ON inv_sisemp = DDoc_Sis_Emp AND inv_numero = DDoc_Prd_Cod"
            strSQL2 &= "             LEFT JOIN Catalogos ON cat_clase = 'Paises' AND cat_num = inv_lugarfab SET DDoc_Prd_Des= TRIM(CONCAT(" & "'" & strDLarga & "'" & ",' ', IFNULL(cat_clave,'')))"
            strSQL2 &= "      WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat IN (75, 127) AND inv_artcodigo={codigo}"
        End If

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{codigo}", Val(celdaCodigo.Text))

        'Ejecuta la instrucción
        MyCnn.CONECTAR = strConexion
        COM2 = New MySqlCommand(strSQL2, CON)
        COM2.ExecuteNonQuery()
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        Dim i As Integer = INT_CERO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        If celdaClasificacion.Visible = True Then
            If celdaClasificacion.Text = vbNullString Then
                MsgBox("Please place the classification", vbInformation, "Notice")
                botonClasificacion.Focus()
                comprobar = False
                Exit Function
            End If
        End If
        If celdaNombreProducto.Visible = True Then
            celdaDescripcionHilo3.Text = celdaNombreProducto.Text
        End If

        If (celdaIDClase.Text = vbEmpty) Or celdaDescripcionHilo3.Text = vbNullString Then
            MsgBox("Data is missing in the description cell", vbExclamation, "Notice")
            celdaDescripcionHilo3.Focus()
            comprobar = False
            Exit Function

        End If

        For i = 0 To dgDetalle.Rows.Count - 1
            If Not ComprobarFila(i) Then
                comprobar = False
                Exit Function
            End If
        Next
        If celdaIDClase.Text = 2306 Then
        Else

            If dgDetalle.Visible = True Then
                If dgDetalle.Columns("colPorcentaje").Visible = True Then
                    CalcularTotalPorcentajes()
                    If Not (dblDocTotal = 100) Then
                        If Not celdaIDClase.Text = 330 Then
                            If Not (dblDocTotal = 100) Or dblDocTotal = vbEmpty Then
                                MsgBox("The composition must add 100%", vbCritical)
                                comprobar = False
                                Exit Function

                            End If
                        End If
                    End If
                End If
            End If
        End If
        'Ensambla nombres de artículo
        If ConstruccionNombreCorto() Then
            ConstruccionNombreLargo()

            'Buscar ShortName en DCorta
            strSQL = "  SELECT art_codigo"
            strSQL &= "     FROM Articulos"
            strSQL &= "          WHERE art_sisemp= {empresa} AND art_DCorta = '{ACorta}' AND art_codigo <> {Codigo}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ACorta}", CeldaDecripcionCorta.Text)
            strSQL = Replace(strSQL, "{Codigo}", celdaCodigo.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                If REA.Read Then
                    MsgBox("Product ALREADY EXISTS " & REA.GetString("art_codigo"), vbCritical)
                    comprobar = False
                    Exit Function

                End If
            End If

            'Validar NUEVO registro
            If Trim(CeldaDecripcionCorta.Text) = vbNullString Then
                MsgBox("It was not possible to create the product description", vbExclamation, "Note")
                Exit Function
                comprobar = False
            End If
        End If
        Return comprobar
    End Function

    Private Function ComprobarFila(ByVal i As Integer) As Boolean
        ComprobarFila = True


        If Trim(dgDetalle.Rows(i).Cells("colNumero").Value = vbNullString And i = dgDetalle.Rows.Count - 1) Then
            ComprobarFila = True
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colNumero").Value = vbEmpty Then
            MsgBox("Rows " & i + 1 & ": Invalid Material Code.")
            ComprobarFila = False
            Exit Function
        End If

        If Trim(dgDetalle.Rows(i).Cells("colClave").Value = vbNullString) Then
            MsgBox("Rows" & i + 1 & ": Key of the blank material.")
            ComprobarFila = False
            Exit Function
        End If


        If Trim(dgDetalle.Rows(i).Cells("colDesComponente").Value = vbNullString) Then
            MsgBox("Rows" & i + 1 & ": Key of the blank material.")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Columns("colPorcentaje").Visible = True Then
            If Val(Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString) = vbEmpty) Then
                MsgBox("Rows" & i + 1 & ": Item percentage at zero.")
                ComprobarFila = False
                Exit Function
            End If
        End If
        ComprobarFila = True
    End Function

    'Query para guardar Datos Encabezado
    Private Function GuardarRegistro() As Boolean
        Dim logResultado As Boolean = True
        Dim TArt As New Tablas.TARTICULOS

        Try
            TArt.CONEXION = strConexion
            If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                If intSeleccion = 388 Or intSeleccion = 896 Or intSeleccion = 2307 Or intSeleccion = 2369 Or intSeleccion = 2370 Or intSeleccion = 2371 Or intSeleccion = 2376 Then
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = " "
                    TArt.ART_ACABADO = INT_CERO
                    TArt.ART_SPINNING = INT_CERO
                    TArt.ART_DENIER = INT_CERO
                    TArt.ART_FILAMENTO = INT_CERO
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = INT_CERO
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = celdaIDClasificacion.Text
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)
                    TArt.ART_VENTA = IIf(checkReciclado.Checked = True, "1", "0")
                ElseIf intSeleccion = 331 Or intSeleccion = 2307 Or intSeleccion = 2337 Or intSeleccion = 2338 Then
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = " "
                    If intSeleccion = 2307 Then
                        TArt.ART_ACABADO = celdaIDAcabado.Text
                    Else
                        TArt.ART_ACABADO = INT_CERO
                    End If
                    TArt.ART_SPINNING = INT_CERO
                    TArt.ART_DENIER = INT_CERO
                    TArt.ART_FILAMENTO = INT_CERO
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = INT_CERO
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = INT_CERO
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)
                    TArt.ART_VENTA = IIf(checkReciclado.Checked = True, "1", "0")
                ElseIf intSeleccion = 2306 Then
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = celdaTitulo.Text
                    TArt.ART_ACABADO = celdaIDAcabado.Text
                    TArt.ART_SPINNING = celdaIDSpinning.Text
                    TArt.ART_DENIER = celdaIDDenier.Text
                    TArt.ART_FILAMENTO = If(celdaIdMicronaire.Text = STR_VACIO, 0, celdaIdMicronaire.Text)
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = celdaIDTexturizado.Text
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = celdaIDClasificacion.Text
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)
                    TArt.ART_VENTA = IIf(checkReciclado.Checked = True, "1", "0")
                Else
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = celdaTitulo.Text
                    TArt.ART_ACABADO = celdaIDAcabado.Text
                    TArt.ART_SPINNING = celdaIDSpinning.Text
                    TArt.ART_DENIER = celdaIDDenier.Text
                    TArt.ART_FILAMENTO = If(celdaIDFilamento.Text = STR_VACIO, 0, celdaIDFilamento.Text)
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = celdaIDTexturizado.Text
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = celdaIDClasificacion.Text
                    'TArt.ART_REF = celdaIDClasificacion.Text
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)

                    If checkReciclado.Checked = True And checkOrganico.Checked = True Then
                        TArt.ART_VENTA = 3
                    ElseIf checkReciclado.Checked = True Then
                        TArt.ART_VENTA = INT_UNO
                    ElseIf checkOrganico.Checked = True Then
                        TArt.ART_VENTA = 2
                    Else
                        TArt.ART_VENTA = INT_CERO
                    End If
                End If
            Else
                If intSeleccion = 331 Or intSeleccion = 2307 Or intSeleccion = 2337 Or intSeleccion = 2338 Then
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = " "
                    If intSeleccion = 2307 Then
                        TArt.ART_ACABADO = celdaIDAcabado.Text
                    Else
                        TArt.ART_ACABADO = INT_CERO
                    End If
                    TArt.ART_SPINNING = INT_CERO
                    TArt.ART_DENIER = INT_CERO
                    TArt.ART_FILAMENTO = INT_CERO
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = INT_CERO
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = INT_CERO
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)
                    TArt.ART_VENTA = IIf(checkReciclado.Checked = True, "1", "0")
                ElseIf intSeleccion = 2306 Then
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = celdaTitulo.Text
                    TArt.ART_ACABADO = celdaIDAcabado.Text
                    TArt.ART_SPINNING = celdaIDSpinning.Text
                    TArt.ART_DENIER = celdaIDDenier.Text
                    TArt.ART_FILAMENTO = If(celdaIdMicronaire.Text = STR_VACIO, 0, celdaIdMicronaire.Text)
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = celdaIDTexturizado.Text
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = celdaIDClasificacion.Text
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)
                    TArt.ART_VENTA = IIf(checkReciclado.Checked = True, "1", "0")
                Else
                    TArt.ART_SISEMP = Sesion.IdEmpresa
                    TArt.ART_CODIGO = celdaCodigo.Text
                    TArt.ART_CLASE = celdaIDClase.Text
                    TArt.ART_TITULO = celdaTitulo.Text
                    TArt.ART_ACABADO = celdaIDAcabado.Text
                    TArt.ART_SPINNING = celdaIDSpinning.Text
                    TArt.ART_DENIER = celdaIDDenier.Text
                    TArt.ART_FILAMENTO = If(celdaIDFilamento.Text = STR_VACIO, 0, celdaIDFilamento.Text)
                    TArt.ART_EXTRAINFO = celdaDescripcion.Text
                    TArt.ART_DCORTA = CeldaDecripcionCorta.Text
                    TArt.ART_DLARGA = celdaDescripcionLarga.Text
                    TArt.ART_TEXTURIZADO = celdaIDTexturizado.Text
                    TArt.ART_DESC = celdaDescripcionHilo3.Text
                    TArt.ART_FRAC = celdaPartidaArancelaria.Text
                    TArt.ART_DUTY = celdaArancel.Text
                    TArt.ART_REF = celdaIDClasificacion.Text
                    TArt.ART_HEATHER = IIf(rbSi.Checked = True, 1, vbEmpty)
                    TArt.ART_STATUS = IIf(checkActivar.Checked = True, 1, 0)

                    If checkReciclado.Checked = True And checkOrganico.Checked = True Then
                        TArt.ART_VENTA = 3
                    ElseIf checkReciclado.Checked = True Then
                        TArt.ART_VENTA = INT_UNO
                    ElseIf checkOrganico.Checked = True Then
                        TArt.ART_VENTA = 2
                    Else
                        TArt.ART_VENTA = INT_CERO
                    End If
                    ' Fin IF 
                End If
            End If
            If checkProduccion.Checked = True Then
                TArt.ART_PRODUCCION = INT_UNO
            Else
                TArt.ART_PRODUCCION = INT_CERO

            End If
            If checkExcento.Checked = True Then
                TArt.ART_EXCENTO = INT_UNO
            Else
                TArt.ART_EXCENTO = INT_CERO
            End If

            If Me.Tag = "Mod" Then
                If TArt.PUPDATE = False Then
                    MsgBox(TArt.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If TArt.PINSERT = False Then
                    MsgBox(TArt.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim TMat As New Tablas.TMATERIALES
        Dim i As Integer = INT_CERO

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                If (dgDetalle.Rows(i).Cells("colNumero").Value = vbNullString) And i = dgDetalle.Rows.Count - 1 Then
                    Exit For
                End If

                TMat.CONEXION = strConexion

                TMat.DET_SISEMP = Sesion.IdEmpresa
                TMat.DET_ARTICULO = celdaCodigo.Text
                TMat.DET_ITEM = i + 1
                TMat.DET_NUM = dgDetalle.Rows(i).Cells("colNumero").Value
                TMat.DET_CLAVE = dgDetalle.Rows(i).Cells("colClave").Value
                TMat.DET_PRCNT = CDbl(Replace(dgDetalle.Rows(i).Cells("colPorcentaje").Value, "%", vbNullString))
                TMat.DET_MERMA = CDbl(Replace(dgDetalle.Rows(i).Cells("colMerma").Value, "%", vbNullString))

                If Me.Tag = "Mod" And dgDetalle.Rows(i).Cells("colXtra").Value = 0 Then
                    If TMat.PUPDATE = False Then
                        MsgBox(TMat.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 1 Then
                    If TMat.PINSERT = False Then
                        MsgBox(TMat.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colXtra").Value = 2 Then
                    If TMat.PDELETE = False Then
                        MsgBox(TMat.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Function

    Public Sub CrearUnProductoGenerico(ByVal strCodigoArticulo As String)
        Dim lngID As Integer
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Dim CON2 As MySqlConnection
        Dim REA As MySqlDataReader

        strSQL = "SELECT (IFNULL(MAX(inv_numero),0)+1) ID"
        strSQL &= "      FROM Inventarios"
        strSQL &= "              WHERE inv_sisemp={empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            lngID = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        strSQL2 = "SELECT cat_num, cat_clave, cat_desc"
        strSQL2 &= "     FROM Catalogos"
        strSQL2 &= "             WHERE {desc} = 'GENERIC'"
        If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
            strSQL2 = Replace(strSQL2, "{desc}", "cat_dato")
        Else
            strSQL2 = Replace(strSQL2, "{desc}", "cat_sist")
        End If


        Try
            CON2 = New MySqlConnection(strConexion)
            CON2.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON2)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read

                    If MsgBox("Create Generic Code?" & vbCr & vbCr & REA.GetString("cat_desc"), vbExclamation + vbYesNo + vbDefaultButton2, "Generic: " & REA.GetString("cat_clave")) = vbYes Then
                        '  REA.Close()

                        Dim Inv As New Tablas.TINVENTARIOS
                        Inv.CONEXION = strConexion

                        Inv.INV_SISEMP = Sesion.IdEmpresa
                        Inv.INV_NUMERO = lngID
                        Inv.inv_fecha_NET = cFunciones.HoyMySQL
                        Inv.INV_ARTCODIGO = strCodigoArticulo
                        If (Sesion.IdEmpresa = 15) Then
                            Inv.INV_LUGARFAB = 1
                        ElseIf (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                            Inv.INV_LUGARFAB = 851
                        Else
                            Inv.INV_LUGARFAB = REA.GetInt64("cat_num")
                        End If

                        Inv.INV_UMVENTA = 69
                        Inv.INV_UMCMPRA = 69
                        Inv.INV_UMFAC = 1
                        Inv.INV_COSTO = 0
                        Inv.INV_PRECIOMIN = 0
                        Inv.INV_PRECIOMAX = 0
                        Inv.INV_PRECIOFAC = 1
                        Inv.INV_STATUS = IIf(checkActivar.Checked = True, 1, 2)
                        Inv.INV_GENERICO = 1

                        If Me.Tag = "Mod" Then
                            If Inv.PINSERT() = False Then
                                MsgBox(Inv.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                            End If
                        Else
                            If Inv.PINSERT = False Then
                                MsgBox(Inv.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                            End If
                        End If

                        lngID = lngID + 1
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CrearUnProductoGenericoHSM(ByVal strCodigoArticulo As String)
        Dim lngID As Integer
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Dim CON2 As MySqlConnection
        Dim REA As MySqlDataReader

        strSQL = "SELECT (IFNULL(MAX(inv_numero),0)+1) ID"
        strSQL &= "      FROM Inventarios"
        strSQL &= "              WHERE inv_sisemp={empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            lngID = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        strSQL2 = "SELECT cat_num, cat_clave, cat_desc"
        strSQL2 &= "     FROM Catalogos"
        strSQL2 &= "             WHERE cat_sist = 'DEF_COUNTRY'"


        Try
            CON2 = New MySqlConnection(strConexion)
            CON2.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON2)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read

                    '  If MsgBox("Create Generic Code?" & vbCr & vbCr & REA.GetString("cat_desc"), vbExclamation + vbYesNo + vbDefaultButton2, "Generic: " & REA.GetString("cat_clave")) = vbYes Then
                    '  REA.Close()

                    Dim Inv As New Tablas.TINVENTARIOS
                    Inv.CONEXION = strConexion

                    Inv.INV_SISEMP = Sesion.IdEmpresa
                    Inv.INV_NUMERO = lngID
                    Inv.inv_fecha_NET = cFunciones.HoyMySQL
                    Inv.INV_ARTCODIGO = strCodigoArticulo
                    Inv.INV_LUGARFAB = REA.GetInt64("cat_num")
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                        Inv.INV_UMVENTA = 441 '441 unidad, 419 pieza cat_clase='Medidas'
                        Inv.INV_UMCMPRA = 441
                    Else
                        Inv.INV_UMVENTA = 419 '441 unidad, 419 pieza cat_clase='Medidas'
                        Inv.INV_UMCMPRA = 419
                    End If
                    Inv.INV_UMFAC = 1
                    Inv.INV_COSTO = 0
                    Inv.INV_PRECIOMIN = 0
                    Inv.INV_PRECIOMAX = 0
                    Inv.INV_PRECIOFAC = 1
                    Inv.INV_STATUS = IIf(checkActivar.Checked = True, 1, 2)
                    Inv.INV_GENERICO = 1

                    If Me.Tag = "Mod" Then
                        If Inv.PINSERT() = False Then
                            MsgBox(Inv.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    Else
                        If Inv.PINSERT = False Then
                            MsgBox(Inv.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If

                    lngID = lngID + 1
                    ' End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Muestra los documentos que utilizan este código de producto
    Private Sub MostrarDocumentos(ByVal Codigo As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strTexto As String = STR_VACIO
        Dim strProducto As String = STR_VACIO
        Dim i As Integer

        Try
            strSQL = "SELECT c.cat_desc Documento, CAST(CONCAT(d.DDoc_Doc_Ano,' / ',d.DDoc_Doc_Num) AS CHAR) Numero"
            strSQL &= "  FROM Dcmtos_DTL d"
            strSQL &= "     INNER JOIN Catalogos c ON c.cat_num = d.DDoc_Doc_Cat"
            strSQL &= "          LEFT JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod"
            strSQL &= "             WHERE d.DDoc_Sis_Emp = {empresa} AND i.inv_artcodigo = {codigo}"
            strSQL &= "           GROUP BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num"
            strSQL &= "      ORDER BY d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", Codigo)

            i = vbEmpty
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            i = i + 1
            If REA.HasRows Then
                Do While REA.Read
                    If Not (strTexto = vbNullString) Then
                        strTexto = strTexto & vbCr
                    End If
                    strTexto = strTexto & i & ")" & REA.GetString("Documento") & Space(2) & REA.GetString("Numero")
                Loop
            End If

            strProducto = Codigo
            If (strTexto = vbNullString) Then
                MsgBox("The Product" & Codigo & ", is not being used", vbExclamation, "Notice")
            Else
                strTexto = "Product: " & strProducto & vbCr & "Related Documents: " & vbCr & vbCr & strTexto
                MsgBox(strTexto, vbInformation, "Related Documents")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Validacion y metodos de Borrar 
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*)"
        strSQL &= "     FROM Inventarios i "
        strSQL &= "         WHERE i.inv_sisemp = {empresa} AND i.inv_artcodigo ={num}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{num}", celdaCodigo.Text)
        Return strSQL
    End Function
    Private Sub BorrarProducto(ByVal num As Integer)

        Dim pro As New Tablas.TARTICULOS
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = " art_sisemp = {empresa} AND art_codigo = {numero} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{numero}", num)
        Try
            pro.CONEXION = strConexion
            'pro.PRO_CODIGO = celdaCodigo.Text
            If pro.PDELETE(strCondicion) = True Then
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarMaterialDetalle(ByVal num As Integer)
        Dim pro As New Tablas.TMATERIALES
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = " det_sisemp = {empresa} AND det_articulo = {numero} "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{numero}", num)
        Try
            pro.CONEXION = strConexion
            'pro.PRO_CODIGO = celdaCodigo.Text
            If pro.PDELETE(strCondicion) = True Then
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function AutorizarGuardar() As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "MOD_PROD"
        Dim frm As frmAutorización
        AutorizarGuardar = False

        frm = New frmAutorización
        frm.Iniciar(57, STR_MARGEN, 0, "Authorize Edit")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            AutorizarGuardar = True
        End If
        LogResult = True
    End Function
#End Region

#Region "Eventos"

    Private Sub frmProductos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try

            If Me.Tag = "Nuevo" Then
                If Sesion.idGiro = 2 Then  '(Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or  Then

                    '331: Otros
                    '330: Proceso - Rayon en proceso

                    If intTipoProd > 0 Or strOpcion = "Maquinaria" Or intSeleccion = 331 Or intSeleccion = 330 Or intSeleccion = 2372 Or intSeleccion = 2373 Or intSeleccion = 2379 Or intSeleccion = 2416 Or intSeleccion = 2986 Or intSeleccion = 2503 Then
                        celdaCodigo.Text = cFunciones.Verificacion_Nuevo_Registro(celdaCodigo.Text, "Articulos")
                        If celdaCodigo.Text > 0 Then
                            If ComprobarDatos() = True Then
                                GuardarRegistro()

                                '2373: Repuestos
                                '2372: Material de Empaque
                                '2379: Consumible
                                '2416: Inventario en custodia
                                '2986: Proyecto

                                If intTipoProd > 0 Or intSeleccion = 2372 Or intSeleccion = 2373 Or intSeleccion = 2379 Or intSeleccion = 2416 Or intSeleccion = 2986 Or intSeleccion = 2503 Then ' (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Then
                                    CrearUnProductoGenericoHSM(celdaCodigo.Text)
                                Else
                                    CrearUnProductoGenerico(celdaCodigo.Text)
                                End If

                                'Registra la transaccion
                                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaCodigo.Text)
                                MsgBox("Stored Product Correctly", MsgBoxStyle.Information)
                                MostrarLista(True, False, celdaCodigo.Text)
                            End If
                        End If
                    Else
                        celdaCodigo.Text = cFunciones.Verificacion_Nuevo_Registro(celdaCodigo.Text, "Articulos")
                        If ComprobarDatos() = True Then
                            If celdaCodigo.Text > 0 Then
                                GuardarRegistro()
                                GuardarDetalle()
                                If intSeleccion = 2306 Or intSeleccion = 2307 Then
                                Else
                                    CrearUnProductoGenerico(celdaCodigo.Text)
                                End If
                                MsgBox("Stored Product Correctly", MsgBoxStyle.Information)
                                'Registra la transaccion
                                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaCodigo.Text)

                                MostrarLista(True, False, celdaCodigo.Text)

                            End If
                        End If
                        ' Fin de IF 
                    End If








                Else
                    If intSeleccion = 331 Or intSeleccion = 330 Then
                        celdaCodigo.Text = cFunciones.Verificacion_Nuevo_Registro(celdaCodigo.Text, "Articulos")
                        If celdaCodigo.Text > 0 Then
                            If ComprobarDatos() = True Then
                                GuardarRegistro()

                                If Sesion.idGiro = 2 Then  '(Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
                                    CrearUnProductoGenericoHSM(celdaCodigo.Text)
                                Else
                                    CrearUnProductoGenerico(celdaCodigo.Text)
                                End If

                                'Registra la transaccion
                                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaCodigo.Text)
                                MsgBox("Stored Product Correctly", MsgBoxStyle.Information)
                                MostrarLista(True, False, celdaCodigo.Text)
                            End If
                        End If
                    Else
                        celdaCodigo.Text = cFunciones.Verificacion_Nuevo_Registro(celdaCodigo.Text, "Articulos")
                        If ComprobarDatos() = True Then
                            If celdaCodigo.Text > 0 Then
                                GuardarRegistro()
                                GuardarDetalle()
                                If intSeleccion = 2306 Or intSeleccion = 2307 Then
                                Else
                                    If (Not Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Or (Not Sesion.IdEmpresa = 15) Or Sesion.idGiro = 2 Then
                                        CrearUnProductoGenerico(celdaCodigo.Text)
                                    End If
                                End If

                                MsgBox("Stored Product Correctly", MsgBoxStyle.Information)
                                'Registra la transaccion
                                cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaCodigo.Text)

                                MostrarLista(True, False, celdaCodigo.Text)

                            End If
                        End If
                        ' Fin de IF 
                    End If
                End If
            ElseIf Me.Tag = "Mod" Then
                intSeleccion = celdaIDClase.Text

                If intSeleccion = 331 Or intSeleccion = 330 Then
                    If AutorizarGuardar() = True Then
                        GuardarRegistro()
                        MsgBox("Product Correctly Upgraded", MsgBoxStyle.Information)
                        'Registra la transaccion
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaCodigo.Text)
                    End If

                    MostrarLista(True, False, celdaCodigo.Text)
                Else
                    If ComprobarDatos() = True Then
                        If AutorizarGuardar() = True Then
                            GuardarRegistro()
                            GuardarDetalle()

                            'Actualizar descripcion en inventario y docs.
                            ActualizarDatos()

                            MsgBox("Product Correctly Upgraded", MsgBoxStyle.Information)
                            'Registra la transaccion
                            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaCodigo.Text)

                        End If


                        MostrarLista(True, False, celdaCodigo.Text)
                    End If
                End If

            Else
                MsgBox("It was not possible  to classify the operation  to save", vbExclamation, "Notice")
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intNumero As Integer

        LimpiarPanel()
        MostrarLista(False)
        celdaClase.Enabled = True
        celdaIDClase.Enabled = True
        botonClase.Enabled = True
        Encabezado1.botonBorrar.Enabled = False
        etiquetaCodigo.Visible = True
        celdaCodigo.Visible = True
        etiquetaClase.Visible = True
        celdaClase.Visible = True
        botonClase.Visible = True
        etiquetaAcabado.Visible = False
        celdaAcabado.Visible = False
        botonAcabado.Visible = False
        celdaIDAcabado.Visible = False
        etiquetaTitulo.Visible = False
        celdaTitulo.Visible = False
        etiquetaSpinning.Visible = False
        celdaSpinning.Visible = False
        botonSpinning.Visible = False
        celdaIDSpinning.Visible = False
        etiquetaDenier.Visible = False
        celdaDenier.Visible = False
        botonDenier.Visible = False
        etiquetaTexturizado.Visible = False
        celdaTexturizado.Visible = False
        botonTexturizado.Visible = False
        etiquetaFilamento.Visible = False
        celdaFilamento.Visible = False
        botonFilamento.Visible = False


        rbSi.Visible = True
        rbNo.Visible = True
        rbNo.Checked = True

        etiquetaNombreProducto.Visible = False
        celdaNombreProducto.Visible = False
        ' oculta la columna de merma, ya no se utilizará
        dgDetalle.Columns("colMerma").Visible = False

        strFila = "" & "|"
        strFila = "" & "|"
        strFila = "" & "|"
        strFila = "" & "|"
        strFila = "" & "|"
        strFila = "" & "|"
        strFila = ""

        cFunciones.AgregarFila(dgDetalle, strFila)
        dgDetalle.DefaultCellStyle.BackColor = Color.Beige

        celdaArancel.Text = "0.00"

        strSQL = "SELECT IFNULL(MAX(a.art_codigo + 1),1)"
        strSQL &= "   FROM Articulos a"
        strSQL &= "          WHERE a.art_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            intNumero = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        celdaCodigo.Text = intNumero
        panelDetalle2.Visible = True
        celdaTotal.Visible = True
        dgDetalle.Columns("colPorcentaje").Visible = True

        'If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Then
        '    etiquetaClasificacion.Visible = False
        '    celdaClasificacion.Visible = False
        '    botonClasificacion.Visible = False
        '    celdaIDClasificacion.Visible = False
        'End If

        'Iniciando todos los campos de ID en Cero
        celdaIDClase.Text = INT_CERO
        celdaIDAcabado.Text = INT_CERO
        celdaIDClasificacion.Text = INT_CERO
        celdaIDDenier.Text = INT_CERO
        celdaIDFilamento.Text = INT_CERO
        celdaIDSpinning.Text = INT_CERO
        celdaIDTexturizado.Text = INT_CERO

        Me.Tag = "Nuevo"

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDetalle.Visible = True Then
            MostrarLista(True, False, celdaCodigo.Text)
        Else
            Me.Close()
        End If
    End Sub

    Private Sub dgLista_DoubleClick1(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intCodigo As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        ' clsFunciones.EnableDisable(panelEncabezado, False)

        LimpiarPanel()
        intCodigo = dgLista.SelectedCells(0).Value


        'etiquetaNombreProducto.Visible = False
        'celdaNombreProducto.Visible = False

        Dim strSQL As String = STR_VACIO


        strSQL = "SELECT a.art_clase, c.cat_pid, c.cat_ext, c.cat_sisemp "
        strSQL &= " FROM Articulos a LEFT JOIN Catalogos c ON c.cat_num = a.art_clase "
        strSQL &= "      WHERE a.art_sisemp = {empresa} and a.art_codigo = {codigo}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", intCodigo)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        REA.Read()
        strOpcion = REA.GetString("cat_ext")
        intTipoProd = REA.GetInt32("cat_sisemp")
        If (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 19) Or Sesion.idGiro = 2 Then
            If intTipoProd > 0 Or strOpcion = "Fibra" Or strOpcion = "Waste" Or strOpcion = "Product in process" Or strOpcion = "Invisible Waste" Or REA.GetInt32("art_clase") = 388 Or REA.GetInt32("art_clase") = 896 Or REA.GetInt32("art_clase") = 2307 Or REA.GetInt32("art_clase") = 2369 Or REA.GetInt32("art_clase") = 2370 Or REA.GetInt32("art_clase") = 2371 Then
                CargarEncabezado(intCodigo)
            ElseIf strOpcion = "Maquinaria" Or REA.GetInt32("art_clase") = 331 Or REA.GetInt32("art_clase") = 330 Or REA.GetInt32("art_clase") = 2337 Or REA.GetInt32("art_clase") = 2338 Or REA.GetInt32("cat_pid") = 5 Then ' Or REA.GetString("cat_desc") = "Parts" Or REA.GetString("cat_desc") = "Consumables" Or REA.GetString("cat_desc") = "Inventory in Custody" Then
                CargarEncabezado2(intCodigo)
            ElseIf REA.GetInt32("art_clase") = 2306 Then
                Dim intClase As Integer = INT_CERO
                intClase = REA.GetInt32("art_clase")
                If REA.GetInt32("art_clase") = 2307 Then
                    intClase = 2307
                    CargarEncabezado2(intCodigo, intClase)
                Else
                    CargarEncabezado(intCodigo)
                End If
                CargarDetalle()
            Else
                CargarEncabezado(intCodigo)
                CargarDetalle()
            End If
        Else
            If REA.GetInt32("art_clase") = 331 Or REA.GetInt32("art_clase") = 330 Or REA.GetInt32("art_clase") = 2337 Or REA.GetInt32("art_clase") = 2338 Or REA.GetInt32("cat_pid") = 2 Then ' Or REA.GetString("cat_desc") = "Packing" Or REA.GetString("cat_desc") = "Parts" Or REA.GetString("cat_desc") = "Consumables" Or REA.GetString("cat_desc") = "Inventory in Custody" Then
                CargarEncabezado2(intCodigo)
            ElseIf REA.GetInt32("art_clase") = 2306 Or REA.GetInt32("art_clase") = 2307 Then
                Dim intClase As Integer = INT_CERO
                intClase = REA.GetInt32("art_clase")
                If REA.GetInt32("art_clase") = 2307 Then
                    intClase = 2307
                    CargarEncabezado2(intCodigo, intClase)
                Else
                    CargarEncabezado(intCodigo)
                End If


                CargarDetalle()
            Else
                CargarEncabezado(intCodigo)
                    CargarDetalle()
                End If
            End If
            MostrarLista(False)
    End Sub

    Private Sub botonClase_Click(sender As Object, e As EventArgs) Handles botonClase.Click

        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO

        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim intNumero As Integer
        Dim strFila As String = STR_VACIO


        If Me.Tag = "Nuevo" Then
            LimpiarPanel()

            strSQL = "SELECT IFNULL(MAX(a.art_codigo + 1),1)"
            strSQL &= "   FROM Articulos a"
            strSQL &= "          WHERE a.art_sisemp = {empresa}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intNumero = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            celdaCodigo.Text = intNumero
        End If


        Try
            frm.Titulo = "Class"
            frm.FiltroText = " Enter The Class To Filter"
            frm.Campos = " c.cat_num Numero, c.cat_desc Descripcion,c.cat_ext type, c.cat_sisemp Id"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'ClaseArt'"



            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                intSeleccion = frm.LLave
                celdaIDClase.Text = frm.LLave
                celdaClase.Text = frm.Dato
                strOpcion = frm.Dato2
                intTipoProd = frm.Dato3
            End If

            strFila = "" & "|"
            strFila &= "" & "|"
            strFila &= "" & "|"
            strFila &= "" & "|"
            strFila &= "" & "|"
            strFila &= "" & "|"
            strFila &= "" & "|"
            strFila &= 1

            cFunciones.AgregarFila(dgDetalle, strFila)
            dgDetalle.DefaultCellStyle.BackColor = Color.Beige

            celdaArancel.Text = "0.00"

            MostrarRegistros(celdaIDClase.Text, strOpcion)

            celdaIDClase.Text = intSeleccion

            If (Sesion.IdEmpresa = 15) Or ((Sesion.IdEmpresa >= 18) And (Sesion.IdEmpresa <= 21)) Or Sesion.idGiro = 2 Then
                If intTipoProd > 0 Or (strOpcion = "Maquinaria") Or (strOpcion = "Consumibles") Or (strOpcion = "Material de empaque") Or (strOpcion = "Repuestos") Or (strOpcion = "Waste") Or (strOpcion = "Product in process") Or (strOpcion = "Invisible Waste") Or (strOpcion = "Repuestos") Or strOpcion = "Inventario en Custodia" Or strOpcion = "Proyecto" Or strOpcion = "Combustible" Or intTipoProd > 0 Then
                    gbHeather.Visible = False
                End If
                If (strOpcion = "Consumibles") Or (strOpcion = "Material de empaque") Or (strOpcion = "Repuestos") Then
                    checkExcento.Visible = True
                Else
                    checkExcento.Visible = False
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim frm As New frmSeleccionar

        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 3
                    frm.Titulo = "Class"
                    frm.FiltroText = " Enter The Class To Filter"
                    frm.Campos = " c.cat_clave Clave, c.cat_desc Description, c.cat_sist Sistem, c.cat_num Number"
                    frm.Tabla = " Catalogos c"
                    frm.Filtro = " c.cat_desc "
                    frm.Condicion = "cat_clase = 'Material'"
                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentRow.Cells(3).Value = frm.Dato3
                        dgDetalle.CurrentRow.Cells(4).Value = frm.LLave
                        dgDetalle.CurrentRow.Cells(5).Value = frm.Dato

                    End If
                    dgDetalle.CurrentRow.ReadOnly = False
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAcabado_Click(sender As Object, e As EventArgs) Handles botonAcabado.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim strFila As String = STR_VACIO

        Try
            frm.Titulo = "Class"
            frm.FiltroText = " Enter The Class To Filter"
            frm.Campos = " c.cat_num Number, c.cat_desc Description"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'Acabado'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDAcabado.Text = frm.LLave
                celdaAcabado.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonDenier_Click(sender As Object, e As EventArgs) Handles botonDenier.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            frm.Titulo = "Class"
            frm.FiltroText = " Enter The Class To Filter"
            frm.Campos = " c.cat_num Number, c.cat_desc Description"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'Denier'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDDenier.Text = frm.LLave
                celdaDenier.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonTexturizado_Click(sender As Object, e As EventArgs) Handles botonTexturizado.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim strFila As String = STR_VACIO
        Try
            If Sesion.IdEmpresa = 22 Then
                frm.Titulo = "Class"
                frm.FiltroText = " Enter The Class To Filter"
                frm.Campos = " c.cat_num Number, c.cat_desc Description"
                frm.Tabla = " Catalogos c"
                frm.Filtro = " c.cat_desc "
                frm.Condicion = "cat_clase = 'Prod_Terminado'"
                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    'celdaIDTexturizado.Text = frm.LLave
                    celdaTitulo.Text = frm.Dato
                End If
            Else

                frm.Titulo = "Class"
                frm.FiltroText = " Enter The Class To Filter"
                frm.Campos = " c.cat_num Number, c.cat_desc Description"
                frm.Tabla = " Catalogos c"
                frm.Filtro = " c.cat_desc "
                frm.Condicion = "cat_clase = 'Texture'"

                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    celdaIDTexturizado.Text = frm.LLave
                    celdaTexturizado.Text = frm.Dato
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonSpinning_Click(sender As Object, e As EventArgs) Handles botonSpinning.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim strFila As String = STR_VACIO

        Try
            frm.Titulo = "Class"
            frm.FiltroText = " Enter The Class To Filter"
            frm.Campos = " c.cat_num Number, c.cat_desc Description"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'Spinning'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDSpinning.Text = frm.LLave
                celdaSpinning.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFilamento_Click(sender As Object, e As EventArgs) Handles botonFilamento.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim strFila As String = STR_VACIO

        Try
            frm.Titulo = "Class"
            frm.FiltroText = " Enter The Class To Filter"
            frm.Campos = " c.cat_num Number, c.cat_desc Description"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'Filamento'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDFilamento.Text = frm.LLave
                celdaFilamento.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonVistaPrevia_Click(sender As Object, e As EventArgs) Handles botonVistaPrevia.Click

        If intSeleccion = 331 Or intSeleccion = 2306 Or intSeleccion = 2307 Then
            ConstruccionNombreCorto()
            ConstruccionNombreLargo()
            celdaDescripcionHilo3.Text = celdaNombreProducto.Text
        ElseIf intTipoProd > 0 Or strOpcion = "Maquinaria" Or strOpcion = "Fibra" Or strOpcion = "Product in process" Or strOpcion = "Waste" Or strOpcion = "Invisible Waste" Or Sesion.idGiro = 2 Or (intSeleccion = 388 And Sesion.IdEmpresa = 15) Or (intSeleccion = 896 And Sesion.IdEmpresa = 15) Or (intSeleccion = 2307 And Sesion.IdEmpresa = 15) Or (intSeleccion = 2369 And Sesion.IdEmpresa = 15) Or (intSeleccion = 2370 And Sesion.IdEmpresa = 15) Or (intSeleccion = 2371 And Sesion.IdEmpresa = 15) Or (intSeleccion = 2376 And Sesion.IdEmpresa = 15) Or (intSeleccion = 388 And Sesion.IdEmpresa = 18) Or (intSeleccion = 896 And Sesion.IdEmpresa = 18) Or (intSeleccion = 2307 And Sesion.IdEmpresa = 18) Or (intSeleccion = 2369 And Sesion.IdEmpresa = 18) Or (intSeleccion = 2370 And Sesion.IdEmpresa = 18) Or (intSeleccion = 2371 And Sesion.IdEmpresa = 18) Or (intSeleccion = 2376 And Sesion.IdEmpresa = 18) Or (intSeleccion = 388 And Sesion.IdEmpresa = 19) Or (intSeleccion = 896 And Sesion.IdEmpresa = 19) Or (intSeleccion = 2307 And Sesion.IdEmpresa = 19) Or (intSeleccion = 2369 And Sesion.IdEmpresa = 19) Or (intSeleccion = 2370 And Sesion.IdEmpresa = 19) Or (intSeleccion = 2371 And Sesion.IdEmpresa = 19) Or (intSeleccion = 2376 And Sesion.IdEmpresa = 19) Then
            ConstruccionNombreCorto()
            ConstruccionNombreLargo()
            celdaDescripcionHilo3.Text = celdaNombreProducto.Text
        Else
            CalcularTotalPorcentajes()
            ConstruccionNombreCorto()
            ConstruccionNombreLargo()
        End If


    End Sub

    Private Function BuscarPalabras(ByVal Descripcion As String, ByVal DatoComparar As String)
        Dim intPalabra As Integer = INT_CERO

        intPalabra = InStr(Descripcion, LCase(DatoComparar))

        If intPalabra = 0 Then
            intPalabra = 0
        Else
            intPalabra = 1
        End If

        Return intPalabra
    End Function


    Private Sub botonAdd_Click(sender As Object, e As EventArgs) Handles botonAdd.Click
        Dim strSQL As String = STR_VACIO

        strSQL = "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= "" & "|"
        strSQL &= 1

        dgDetalle.DefaultCellStyle.BackColor = Color.Beige
        cFunciones.AgregarFila(dgDetalle, strSQL)

    End Sub

    Private Sub botonDelete_Click(sender As Object, e As EventArgs) Handles botonDelete.Click
        If dgDetalle.Rows.Count < 1 Then Exit Sub
        Try
            'Dim strFila As String
            If dgDetalle.CurrentRow.Cells(7).Value = 1 Then
                dgDetalle.CurrentRow.Cells(7).Value = 2
                dgDetalle.CurrentRow.Visible = False
            Else
                dgDetalle.CurrentRow.Cells(7).Value = 0
                dgDetalle.CurrentRow.Cells(7).Value = 2
                dgDetalle.CurrentRow.Visible = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                MostrarDocumentos(dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(INT_CERO, INT_CERO, INT_CERO, "Articulos", dgLista.SelectedCells(0).Value)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonClasificacion_Click(sender As Object, e As EventArgs) Handles botonClasificacion.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim strFila As String = STR_VACIO

        Try
            frm.Titulo = "Classification"
            frm.FiltroText = " Enter The Classification To Filter"
            frm.Campos = " c.cat_num Number, c.cat_desc Clasificacion"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            If intTipoProd > 0 Or strOpcion = "Repuestos" Or strOpcion = "Material de empaque" Or strOpcion = "Consumibles" Or strOpcion = "Inventario en Custodia" Or strOpcion = "Proyecto" Or strOpcion = "Combustible" Then
                frm.Condicion = "cat_clase = 'Clasificacion' AND cat_pid = 1"
            Else
                frm.Condicion = "cat_clase = 'Clasificacion' AND cat_pid = 0"
            End If

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDClasificacion.Text = frm.LLave
                celdaClasificacion.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmProductos_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim IntNumDocs As Integer

            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()
            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarProducto(celdaCodigo.Text)
                    BorrarMaterialDetalle(celdaCodigo.Text)
                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaCodigo.Text)
                    MostrarLista()
                End If
            End If
        End If
    End Sub


    Private Sub botonMicronaire_Click(sender As Object, e As EventArgs) Handles botonMicronaire.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            frm.Titulo = "Class"
            frm.FiltroText = " Enter The Class To Filter"
            frm.Campos = " c.cat_num Number, c.cat_desc Description"
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'Micronaire'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMicronaire.Text = frm.LLave
                celdaMicronaire.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub checkReciclado_CheckedChanged(sender As Object, e As EventArgs) Handles checkReciclado.CheckedChanged
        'If checkReciclado.Checked = True Then
        '    checkOrganico.Checked = False
        'End If
    End Sub

    Private Sub checkOrganico_CheckedChanged(sender As Object, e As EventArgs) Handles checkOrganico.CheckedChanged
        'If checkOrganico.Checked = True Then
        '    checkReciclado.Checked = False
        'End If
    End Sub

    Private Sub butonType_Click1(sender As Object, e As EventArgs) Handles butonType.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Dim intNumero As Integer
        Dim strFila As String = STR_VACIO
        Dim strOpcion As String = STR_VACIO




        Try
            frm.Titulo = "Product Type"
            frm.FiltroText = " Enter The Producto Type To Filter"
            frm.Campos = " cat_ext Type "
            frm.Tabla = " Catalogos c"
            frm.Filtro = " c.cat_desc "
            frm.Condicion = "cat_clase = 'ClaseArt' Group by 1"



            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strOpcion = frm.LLave

            End If



            celdaType.Text = strOpcion
            MostrarLista()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BarraTitulo1_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

#End Region
End Class