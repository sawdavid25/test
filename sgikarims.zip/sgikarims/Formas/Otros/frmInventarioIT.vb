﻿Public Class frmInventarioIT
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
#End Region
#Region "Procedimiento"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Funciones y Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            PanelDocumento.Dock = DockStyle.None
            PanelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Inventory IT")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            PanelDocumento.Dock = DockStyle.Fill
            PanelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                Reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            ' SUM((l1.Saldo - l1.Monto)) monto
            strSql = " SELECT it.id_Inventario Code, IF(it.Codigo_Equipo = '','Sin Código',it.Codigo_Equipo) codigo, IFNULL(CONCAT(p.per_nombre1,' ',p.per_apellido1),'No Asignado') responsable, e.cat_clave Description, IF(it.Estado= 0,'CANCELED', 'ACTIVE') Estado
                            FROM InventarioIT it
                            LEFT JOIN Personal p ON p.per_sisemp = it.id_Empresa AND p.per_codigo = it.id_Asignacion
                            LEFT JOIN Catalogos e ON e.cat_num = it.id_Equipo AND e.cat_clase = 'Inventario'
                                WHERE it.id_Empresa = {empresa} "


            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            ' strSql = strSql.Replace("{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            ' strSql = strSql.Replace("{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read

                    strLinea = REA.GetInt32("Code") & "|" 'Codigo
                    strLinea &= REA.GetString("Description") & "|" 'Descripcion 
                    strLinea &= REA.GetString("responsable") & "|"
                    strLinea &= REA.GetString("codigo") & "|"
                    strLinea &= REA.GetString("Estado") ' Estado
                    If REA.GetString("Estado") = "CANCELED" Then
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub reset()
        'Campos Obligatorios 
        celdaNumero.Text = NO_FILA
        celdaInventario.Text = STR_VACIO
        celdaidInventario.Text = NO_FILA
        celdaMarca.Text = STR_VACIO
        celdaSerie.Text = STR_VACIO
        celdaUbicacion.Text = STR_VACIO
        celdaidUbicacion.Text = NO_FILA
        celdaProveedor.Text = STR_VACIO
        celdaidProveedor.Text = NO_FILA
        celdaCosto.Text = INT_CERO
        dtpFecha.Value = Now()
        celdaComentario.Clear()
        'Campos No Obligatorios
        celdaMacEthernet.Clear()
        celdaMacWifi.Clear()
        celdaCodigoEquipo.Text = STR_VACIO
        celdaModelo.Text = STR_VACIO
        celdaServiceTag.Text = STR_VACIO
        celdaProcesador.Text = STR_VACIO
        celdaRam.Text = STR_VACIO
        celdaSistema.Text = STR_VACIO
        celdaSeguro.Text = STR_VACIO
        celdaidSeguro.Text = NO_FILA
        celdaFactura.Text = STR_VACIO
        celdaOFFICE.Text = STR_VACIO
        celdaAsignacion.Text = STR_VACIO
        celdaidAsignacion.Text = NO_FILA
        checkSinAsignar.Checked = False
        celdaDisco.Text = STR_VACIO
        dgCobian.Rows.Clear()
        dtpFechaBaja.Value = Now()
        celdaRazonBaja.Text = STR_VACIO
    End Sub
    Public Sub BloquearNObligatorios()
        PanelNRequerido.Enabled = False
    End Sub
    Public Sub ActivarNObligatorios()
        PanelNRequerido.Enabled = True
    End Sub
    Private Function NuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " SELECT IFNULL(MAX(it.id_Inventario),0)  + 1 Codigo "
        strSQL &= " FROM InventarioIT it "
        strSQL &= "     WHERE it.id_Empresa = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " SELECT IFNULL(MAX(c.id_Linea),0) + 1  Codigo  "
        strSQL &= " FROM Cobian c   "
        strSQL &= " WHERE c.id_Empresa = {empresa} AND c.id_Inventario = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function SQLInventarioIT(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT it.id_Inventario Codigo, it.id_Equipo Inventario, e.cat_clave idInventario, e.cat_sist Requerido ,IFNULL(it.Codigo_Equipo,'') CodigoEquipo,IFNULL(it.Marca,'')Marca, IFNULL(it.Modelo,'') Modelo, "
        strSQL &= "     IFNULL(it.Serie,'') Serie, IFNULL(it.Service_Tag,'') ServiceTag, IFNULL(it.Procesador,'') Procesador, IFNULL(it.Memoria_Ram,'') RAM, "
        strSQL &= "         IFNULL(it.Sistema,'') Sistema, IFNULL(it.Disco,'') Disco, it.Ubicacion, u.cat_clave UbicacionD, IFNULL(it.Seguro,-1) Seguro, IFNULL(s.cat_clave,'') SeguroD, "
        strSQL &= "             it.idProveedor, p.pro_proveedor NombreP, IFNULL(it.Factura,'') Factura,IFNULL(it.Costo,0) Costo,IFNULL(it.Office,'') OFFICE,IFNULL(it.id_Asignacion,-1) idAsignacion, IFNULL(CONCAT(per_nombre1,' ',per_nombre2,' ',per_apellido1,' ',per_apellido2),'No assigned') Asignacion ,it.Fecha,IFNULL(it.FechaBaja,Now()) FechaBaja,IFNULL(it.RazonBaja,'') RazonBaja, it.Estado, "
        strSQL &= "              IFNULL(it.Comentario,'') comentario, ifnull(it.Mac_Wifi,'') wifi, ifnull(it.Mac_Ethernet,'') ethernet "
        strSQL &= "                 FROM InventarioIT it "
        strSQL &= "                     LEFT JOIN Catalogos e ON e.cat_num = it.id_Equipo AND e.cat_clase ='Inventario' "
        strSQL &= "                         LEFT JOIN Catalogos u ON u.cat_num = it.Ubicacion AND u.cat_clase = 'Ubicacion' "
        strSQL &= "                             LEFT JOIN Catalogos s ON s.cat_num = it.Seguro AND s.cat_clase= 'Seguro' "
        strSQL &= "                                 LEFT JOIN Proveedores p ON p.pro_sisemp = it.id_Empresa AND p.pro_codigo = it.idProveedor "
        strSQL &= "                                     LEFT JOIN Personal per ON per.per_sisemp = it.id_Empresa AND per.per_codigo = it.id_Asignacion "
        strSQL &= "                                         WHERE it.id_Empresa = {empresa} AND it.id_Inventario = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Function SQLCobianDetalle(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT c.id_Linea Linea , c.Dia , c.Nombre , c.Hora , c.Estado "
        strSQL &= "      FROM Cobian c "
        strSQL &= "         WHERE c.id_Empresa = {empresa} AND c.id_Inventario = {inventario} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{inventario}", Codigo)
        Return strSQL
    End Function
    Public Sub CargarCobianDetalle(ByVal Codigo As Integer)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLCobianDetalle(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Linea") & "|" 'Linea

                    Select Case REA.GetInt32("Dia")
                        Case 1  'Domingo
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Sunday" & "|" ' Dia 
                        Case 2 ' Lunes
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Monday" & "|" ' Dia 
                        Case 3 ' Martes
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Tuesday" & "|" ' Dia 
                        Case 4 ' Miercoles 
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Wednesday" & "|" ' Dia 
                        Case 5 ' Jueves 
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Thursday" & "|" ' Dia 
                        Case 6 ' Viernes 
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Friday" & "|" ' Dia 
                        Case 7 ' Sabado 
                            strFila &= REA.GetInt32("Dia") & "|" 'id Dia 
                            strFila &= "Saturday" & "|" ' Dia 
                    End Select
                    strFila &= REA.GetString("Nombre") & "|" ' Nombre 
                    strFila &= REA.GetString("Hora") & "|" ' Tiempo
                    If REA.GetInt32("Estado") = INT_UNO Then
                        strFila &= REA.GetInt32("Estado") & "|" ' id Estado
                        strFila &= "ACTIVE" & "|" '  Estado 
                    Else
                        strFila &= REA.GetInt32("Estado") & "|" ' id Estado
                        strFila &= "INACTIVE" & "|" '  Estado 
                    End If
                    strFila &= INT_UNO ' Col Extra 
                    cfun.AgregarFila(dgCobian, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarInventarioIT(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLInventarioIT(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaNumero.Text = REA.GetInt32("Codigo")
                    celdaidInventario.Text = REA.GetInt32("Inventario")
                    celdaInventario.Text = REA.GetString("idInventario")
                    celdaCodigoEquipo.Text = REA.GetString("CodigoEquipo")
                    celdaMarca.Text = REA.GetString("Marca")
                    celdaModelo.Text = REA.GetString("Modelo")
                    celdaSerie.Text = REA.GetString("Serie")
                    celdaServiceTag.Text = REA.GetString("ServiceTag")
                    celdaProcesador.Text = REA.GetString("Procesador")
                    celdaRam.Text = REA.GetString("RAM")
                    celdaSistema.Text = REA.GetString("Sistema")
                    celdaDisco.Text = REA.GetString("Disco")
                    celdaidUbicacion.Text = REA.GetInt32("Ubicacion")
                    celdaUbicacion.Text = REA.GetString("UbicacionD")
                    celdaidSeguro.Text = REA.GetInt32("Seguro")
                    celdaSeguro.Text = REA.GetString("SeguroD")
                    celdaidProveedor.Text = REA.GetInt32("idProveedor")
                    celdaProveedor.Text = REA.GetString("NombreP")
                    celdaFactura.Text = REA.GetString("Factura")
                    celdaCosto.Text = REA.GetDouble("Costo").ToString(FORMATO_MONEDA)
                    celdaOFFICE.Text = REA.GetString("OFFICE")
                    dtpFecha.Value = REA.GetDateTime("Fecha")
                    dtpFechaBaja.Value = REA.GetDateTime("FechaBaja")
                    celdaRazonBaja.Text = REA.GetString("RazonBaja")

                    celdaComentario.Text = REA.GetString("comentario")
                    celdaMacWifi.Text = REA.GetString("wifi")
                    celdaMacEthernet.Text = REA.GetString("ethernet")
                    If REA.GetString("Requerido") = INT_UNO Then
                        ActivarNObligatorios()
                    Else
                        BloquearNObligatorios()
                    End If

                    If REA.GetInt32("Estado") = INT_UNO Then
                        checkActivo.Checked = True
                    Else
                        checkActivo.Checked = False
                    End If
                    celdaAsignacion.Text = REA.GetString("Asignacion")
                    celdaidAsignacion.Text = REA.GetInt32("idAsignacion")
                    If REA.GetInt32("idAsignacion") = NO_FILA Then
                        checkSinAsignar.Checked = True
                    Else
                        checkSinAsignar.Checked = False
                    End If

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaidInventario.Text = NO_FILA Then
            MsgBox("Blank Inventory")
            celdaidInventario.Focus()
            Comprobar = False
        End If
        If celdaMarca.Text = vbNullString Then
            celdaMarca.Focus()
            MsgBox("BLANK Mark")
            Comprobar = False
        End If

        If celdaSerie.Text = vbNullString Then
            MsgBox("Blank Series")
            Comprobar = False
            celdaSerie.Focus()
        End If
        If celdaidUbicacion.Text = NO_FILA Then
            MsgBox("Blank Location")
            Comprobar = False
            celdaidUbicacion.Focus()
        End If
        If celdaidProveedor.Text = NO_FILA Then
            MsgBox("Blank Provider")
            Comprobar = False
        End If
        If cfun.ValidarCampoNumerico(celdaCosto) = False Then
            Comprobar = False
        End If
        If checkActivo.Checked = False Then
            If celdaRazonBaja.Text = STR_VACIO Then
                MsgBox("Blank Low reason")
                Comprobar = False
            End If
        End If
        If celdaCodigoEquipo.Text = vbNullString Then
            MsgBox("Blank Code Equipment")
            celdaCodigoEquipo.Focus()
            Comprobar = False
        End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function GuardarInventario() As Boolean
        Dim logValidar As Boolean = True
        Dim cInventarioIT As New Tablas.TINVENTARIOIT
        Dim intCodigo As Integer = NO_FILA
        Try
            cInventarioIT.CONEXION = strConexion
            cInventarioIT.ID_EMPRESA = Sesion.IdEmpresa
            cInventarioIT.ID_EQUIPO = celdaidInventario.Text
            cInventarioIT.CODIGO_EQUIPO = celdaCodigoEquipo.Text
            cInventarioIT.MARCA = celdaMarca.Text
            cInventarioIT.MODELO = celdaModelo.Text
            cInventarioIT.SERIE = celdaSerie.Text
            cInventarioIT.SERVICE_TAG = celdaServiceTag.Text
            cInventarioIT.PROCESADOR = celdaProcesador.Text
            cInventarioIT.MEMORIA_RAM = celdaRam.Text
            cInventarioIT.SISTEMA = celdaSistema.Text
            cInventarioIT.DISCO = celdaDisco.Text
            cInventarioIT.UBICACION = celdaidUbicacion.Text
            cInventarioIT.SEGURO = celdaidSeguro.Text
            cInventarioIT.IDPROVEEDOR = celdaidProveedor.Text
            cInventarioIT.FACTURA = celdaFactura.Text
            cInventarioIT.COSTO = celdaCosto.Text
            cInventarioIT.OFFICE = celdaOFFICE.Text
            cInventarioIT.ID_ASIGNACION = celdaidAsignacion.Text
            cInventarioIT.Fecha_NET = dtpFecha.Value
            cInventarioIT.ESTADO = IIf(checkActivo.Checked = True, INT_UNO, vbEmpty)
            cInventarioIT.COMENTARIO = celdaComentario.Text
            cInventarioIT.MAC_WIFI = celdaMacWifi.Text
            cInventarioIT.MAC_ETHERNET = celdaMacEthernet.Text
            If checkActivo.Checked = False Then
                cInventarioIT.FechaBaja_NET = dtpFechaBaja.Value
            Else
                cInventarioIT.FECHABAJA = Nothing
            End If
            cInventarioIT.RAZONBAJA = celdaRazonBaja.Text
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    intCodigo = NuevoCodigo()
                    cInventarioIT.ID_INVENTARIO = intCodigo
                    If cInventarioIT.PINSERT = False Then
                        MsgBox(cInventarioIT.MERROR.ToString)
                        Return False
                        Exit Function
                    End If
                    If GuardarCobian(intCodigo) = True Then
                        logValidar = True
                    Else
                        logValidar = False
                    End If
                    cFunciones.EscribirRegistro("InventarioIT", clsFunciones.AccEnum.acAdd, intCodigo, 0, 0, intCodigo, Notas:=celdaInventario.Text)
                    Else
                        MsgBox("You don't have permission to save ")
                    Return False
                    Exit Function
                End If
            Else
                If logEditar = True Then
                    intCodigo = celdaNumero.Text
                    cInventarioIT.ID_INVENTARIO = intCodigo
                    If cInventarioIT.PUPDATE = False Then
                        MsgBox(cInventarioIT.MERROR.ToString)
                        Return False
                        Exit Function
                    End If
                    If GuardarCobian(intCodigo) = True Then
                        logValidar = True
                    Else
                        logValidar = False
                    End If
                    cFunciones.EscribirRegistro("InventarioIT", clsFunciones.AccEnum.acUpdate, intCodigo, 0, 0, intCodigo, Notas:=celdaInventario.Text)
                Else
                    MsgBox("You don't have permission to update ")
                    Return False
                    Exit Function
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
    Private Function GuardarCobian(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cCobian As New Tablas.TCOBIAN
        Try
            For i As Integer = 0 To dgCobian.Rows.Count - 1
                cCobian.ID_EMPRESA = Sesion.IdEmpresa
                cCobian.ID_INVENTARIO = numero
                cCobian.DIA = dgCobian.Rows(i).Cells("colidDia").Value
                cCobian.NOMBRE = dgCobian.Rows(i).Cells("colNombre").Value
                cCobian.HORA = dgCobian.Rows(i).Cells("colHora").Value
                cCobian.ESTADO = dgCobian.Rows(i).Cells("colidEstado").Value
                Select Case dgCobian.Rows(i).Cells("colExtra").Value
                    Case 0 'Guardar nueva Linea
                        dgCobian.Rows(i).Cells("colLinea").Value = NuevaLinea(numero)
                        cCobian.ID_LINEA = dgCobian.Rows(i).Cells("colLinea").Value
                        cCobian.CONEXION = strConexion
                        If cCobian.PINSERT = False Then
                            logResultado = False
                            MsgBox(cCobian.MERROR.ToString)
                        End If
                    Case 1 'Actualizar Linea
                        cCobian.ID_LINEA = dgCobian.Rows(i).Cells("colLinea").Value
                        cCobian.CONEXION = strConexion
                        If cCobian.PUPDATE = False Then
                            logResultado = False
                            MsgBox(cCobian.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        cCobian.ID_LINEA = dgCobian.Rows(i).Cells("colLinea").Value
                        cCobian.CONEXION = strConexion
                        If cCobian.PDELETE = False Then
                            logResultado = False
                            MsgBox(cCobian.MERROR.ToString)
                        End If
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    'Bprrar InventarioIT
    Public Function BorrarInventariIT() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM  InventarioIT  WHERE id_Empresa = {empresa} AND id_Inventario = {codigo}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaNumero.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Cobian 
    Public Function BorrarCobian() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Cobian  WHERE id_Empresa = {empresa} AND id_Inventario ={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaNumero.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function NuevoMantenimiento() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " SELECT IFNULL(MAX(m.Numero),0)  + 1 Codigo "
        strSQL &= " FROM Mantenimiento_HDR m"
        strSQL &= "     WHERE m.idEmpresa = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function GuardarMantenimiento(ByVal intEquipo As Integer) As Boolean
        Dim logValidar As Boolean = True
        Dim cMantenimiento As New Tablas.TMANTENIMIENTO_HDR
        Dim intCodigo As Integer = NO_FILA
        Try
            cMantenimiento.CONEXION = strConexion
            cMantenimiento.IDEMPRESA = Sesion.IdEmpresa
            cMantenimiento.IDEQUIPO = intEquipo
            cMantenimiento.IDTIPO = 81
            cMantenimiento.DESCRIPCION = "ASIGNACION"
            cMantenimiento.Fecha_NET = Now.ToString(FORMATO_MYSQL)
            intCodigo = NuevoMantenimiento()
            cMantenimiento.NUMERO = intCodigo
            If cMantenimiento.PINSERT = False Then
                MsgBox(cMantenimiento.MERROR.ToString)
                Return False
                Exit Function
            End If
            If GuardarDetalle(intCodigo) = True Then
                logValidar = True
            Else
                logValidar = False
            End If
            cFunciones.EscribirRegistro("Mantenimiento_HDR", clsFunciones.AccEnum.acAdd, intCodigo, 0, 0, intCodigo, Notas:=celdaInventario.Text)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
    Private Function GuardarDetalle(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cMantenimientosDTL As New Tablas.TMANTENIMIENTO_DTL
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT d.idFlujoDet id , d.Comentario  "
            strSQL &= "     FROM Flujos f "
            strSQL &= "         LEFT JOIN Flujo_Detalle d ON d.Empresa = f.Empresa AND d.idFlujo = f.idFlujo "
            strSQL &= "             WHERE f.Empresa = {empresa} AND f.idFlujo = 81  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    cMantenimientosDTL.CONEXION = strConexion
                    cMantenimientosDTL.IDEMPRESA = Sesion.IdEmpresa
                    cMantenimientosDTL.NUMERO = numero
                    cMantenimientosDTL.DESCRIPCION = REA.GetString("Comentario")
                    cMantenimientosDTL.COMENTARIO = " REASIGNACION " & celdaAsignacion.Text & " " & Now.ToString(FORMATO_MYSQL) & " "
                    cMantenimientosDTL.IDTAREA = REA.GetInt32("id")
                    cMantenimientosDTL.CONEXION = strConexion
                    If cMantenimientosDTL.PINSERT = False Then
                        logResultado = False
                        MsgBox(cMantenimientosDTL.MERROR.ToString)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Sub sqlActualizacionAsignacion()
        Dim strSQL As String
        Dim COM As MySqlCommand
        Try

            strSQL = "UPDATE  InventarioIT it SET it.id_Asignacion = {numero}  WHERE it.id_Empresa = {empresa} AND it.id_Inventario ={codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{numero}", celdaidAsignacion.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
            MostrarLista(True)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CambioDeAsignacion(ByVal intValidacion As Integer)
        If intValidacion = 1 Then
            If checkSinAsignar.Checked = True Then
                If Me.Tag = "mod" Then
                    If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to assign? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                        celdaAsignacion.Text = "Not assigned"
                        celdaidAsignacion.Text = NO_FILA
                        GuardarMantenimiento(celdaNumero.Text)
                        sqlActualizacionAsignacion()
                    End If
                Else
                    celdaAsignacion.Text = "Not assigned"
                    celdaidAsignacion.Text = NO_FILA
                End If
            Else
                checkSinAsignar.Checked = False
            End If
        End If
    End Sub
#End Region
#Region "Eventos"
    Private Sub frmInventarioIT_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub
    Private Sub frmInventarioIT_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        reset()
        MostrarLista(False, True)
        Encabezado1.botonBorrar.Enabled = False
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If PanelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub
    Private Sub botonInventario_Click(sender As Object, e As EventArgs) Handles botonInventario.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "c.cat_clase = 'Inventario' AND c.cat_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Insurance"
            frm.Campos = "c.cat_num Code , c.cat_clave Description , c.cat_sist Required "
            frm.Tabla = "Catalogos c"
            frm.FiltroText = "Enter the Insurance to filter"
            frm.Filtro = "c.cat_clave"
            frm.Ordenamiento = "c.cat_num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidInventario.Text = frm.LLave
                celdaInventario.Text = frm.Dato
                If frm.Dato2 = INT_UNO Then
                    ActivarNObligatorios()
                Else
                    BloquearNObligatorios()
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "p.pro_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Providers"
            frm.Campos = "p.pro_codigo id, p.pro_proveedor Proveedor"
            frm.Tabla = "Proveedores p"
            frm.FiltroText = "Enter the provider to filter"
            frm.Filtro = "p.pro_proveedor"
            frm.Ordenamiento = "p.pro_proveedor, p.pro_status"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonSeguro_Click(sender As Object, e As EventArgs) Handles botonSeguro.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "c.cat_clase = 'Seguro' AND c.cat_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Insurance"
            frm.Campos = "c.cat_num Code , c.cat_clave Description"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = "Enter the Insurance to filter"
            frm.Filtro = "c.cat_clave"
            frm.Ordenamiento = "c.cat_num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidSeguro.Text = frm.LLave
                celdaSeguro.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAsignacion_Click(sender As Object, e As EventArgs) Handles botonAsignacion.Click
        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO
        strRemplazo = "per_sisemp = {empresa} AND per_estado = 1"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Select a Responsible"
            frm.Campos = " per_codigo Id, CONCAT(per_nombre1,' ',per_nombre2,' ',per_apellido1,' ',per_apellido2) Descripcion"
            frm.Tabla = " Personal  "
            frm.FiltroText = " Enter The Name Of The responsible To Filter "
            frm.Filtro = "per_nombre1  "
            frm.Ordenamiento = "per_nombre1, per_nombre2, per_apellido1"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If Me.Tag = "mod" Then
                    If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to assign? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                        celdaidAsignacion.Text = frm.LLave
                        celdaAsignacion.Text = frm.Dato
                        sqlActualizacionAsignacion()
                        GuardarMantenimiento(celdaNumero.Text)
                    End If
                Else
                    celdaidAsignacion.Text = frm.LLave
                    celdaAsignacion.Text = frm.Dato
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub checkSinAsignar_CheckedChanged(sender As Object, e As EventArgs) Handles checkSinAsignar.CheckedChanged

    End Sub
    Private Sub botonUbicacion_Click(sender As Object, e As EventArgs) Handles botonUbicacion.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "c.cat_clase = 'Ubicacion' AND c.cat_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Insurance"
            frm.Campos = "c.cat_num Code , c.cat_clave Description"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = "Enter the Insurance to filter"
            frm.Filtro = "c.cat_clave"
            frm.Ordenamiento = "c.cat_num "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidUbicacion.Text = frm.LLave
                celdaUbicacion.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If GuardarInventario() = True Then
                    MsgBox("save successful")
                    MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(0, 0, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, 0, 0, "InventarioIT", dgLista.SelectedCells(0).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            reset()
            CargarInventarioIT(dgLista.SelectedCells(0).Value)
            CargarCobianDetalle(dgLista.SelectedCells(0).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAbajo_Click(sender As Object, e As EventArgs) Handles botonAbajo.Click
        Try
            If MsgBox("Are you sure you want to delete this row? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                dgCobian.CurrentRow.Cells("colExtra").Value = 2
                dgCobian.CurrentRow.Visible = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonUp_Click(sender As Object, e As EventArgs) Handles botonUp.Click
        Dim strFila As String = STR_VACIO

        strFila = "" & "|" 'Linea
        strFila &= "" & "|" 'id Dia 
        strFila &= "" & "|" ' Dia 
        strFila &= "" & "|" ' Nombre 
        strFila &= "" & "|" ' Tiempo
        strFila &= "" & "|" ' id Estado
        strFila &= "" & "|" '  Estado 
        strFila &= INT_CERO ' Col Extra 
        cfun.AgregarFila(dgCobian, strFila)

    End Sub
    Private Sub dgCobian_DoubleClick(sender As Object, e As EventArgs) Handles dgCobian.DoubleClick
        Select Case dgCobian.CurrentCell.ColumnIndex
            Case 2
                Dim frm As New frmOption
                frm.Opciones = "Sunday |" & "Monday |" & "Tuesday |" & "Wednesday |" & "Thursday |" & "Friday |" & "Saturday"
                frm.Titulo = " DOCUMENTS NOTES "
                frm.ShowDialog(Me)
                Me.DialogResult = DialogResult.OK
                Select Case frm.Seleccion
                    Case 0  'Domingo
                        dgCobian.SelectedCells(2).Value = "Sunday"
                        dgCobian.SelectedCells(1).Value = INT_UNO
                    Case 1 ' Lunes
                        dgCobian.SelectedCells(2).Value = "Monday"
                        dgCobian.SelectedCells(1).Value = 2
                    Case 2 ' Martes
                        dgCobian.SelectedCells(2).Value = "Tuesday"
                        dgCobian.SelectedCells(1).Value = 3
                    Case 3 ' Miercoles 
                        dgCobian.SelectedCells(2).Value = "Wednesday"
                        dgCobian.SelectedCells(1).Value = 4
                    Case 4 ' Jueves 
                        dgCobian.SelectedCells(2).Value = "Thursday"
                        dgCobian.SelectedCells(1).Value = 5
                    Case 5 ' Viernes 
                        dgCobian.SelectedCells(2).Value = "Friday"
                        dgCobian.SelectedCells(1).Value = 6
                    Case 6 ' Sabado 
                        dgCobian.SelectedCells(2).Value = "Saturday"
                        dgCobian.SelectedCells(1).Value = 7
                End Select
            Case 4
                Try
                    Dim frmFecha As New frmDateTimePicker
                    frmFecha.DateTimePicker1.Format = DateTimePickerFormat.Time
                    frmFecha.Tiempo = True
                    frmFecha.ShowDialog(Me)
                    If frmFecha.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgCobian.CurrentRow.Cells("colHora").Value = frmFecha.LLave
                        dgCobian.CurrentRow.Cells("colHora").Value = Replace(dgCobian.CurrentRow.Cells("colHora").Value, "a. m.", STR_VACIO)
                        dgCobian.CurrentRow.Cells("colHora").Value = Replace(dgCobian.CurrentRow.Cells("colHora").Value, "p. m.", STR_VACIO)
                    End If
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Case 6
                Dim frm As New frmOption
                frm.Opciones = "ACTIVE |" & " INACTIVE "
                frm.Titulo = " STATE "
                frm.ShowDialog(Me)
                Me.DialogResult = DialogResult.OK
                Select Case frm.Seleccion
                    Case 0  ' ACTIVE 
                        dgCobian.CurrentRow.Cells("colEstado1").Value = "ACTIVE"
                        dgCobian.CurrentRow.Cells("colidEstado").Value = INT_UNO
                    Case 1 ' INACTIVE 
                        dgCobian.CurrentRow.Cells("colEstado1").Value = "INACTIVE"
                        dgCobian.CurrentRow.Cells("colEstado1").Value = INT_CERO
                End Select
        End Select
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarInventariIT()
                BorrarCobian()
                cFunciones.EscribirRegistro("InventarioIT", clsFunciones.AccEnum.acDelete, celdaNumero.Text, 0, 0, celdaNumero.Text, Notas:=celdaInventario.Text)
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You don't have permission to delete ")
        End If
    End Sub
    Private Sub checkActivo_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivo.CheckedChanged
        If checkActivo.Checked = True Then
            dtpFechaBaja.Enabled = False
            celdaRazonBaja.Enabled = False
        Else
            dtpFechaBaja.Enabled = True
            celdaRazonBaja.Enabled = True
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Dim clsReporte As New clsReportes
        If checkActivo.Checked = False Then
            clsReporte.ReporteActaBajaEquipo(celdaNumero.Text)
        End If
    End Sub

    Private Sub checkSinAsignar_Click(sender As Object, e As EventArgs) Handles checkSinAsignar.Click
        CambioDeAsignacion(1)
    End Sub
#End Region

End Class