﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDatosPolizaImport
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.volNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaAnd = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkMostrarDoc = New System.Windows.Forms.CheckBox()
        Me.celdaFiltro = New System.Windows.Forms.TextBox()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescuento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescuentoDolar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.celdaFlete = New System.Windows.Forms.TextBox()
        Me.celdaCosteo = New System.Windows.Forms.TextBox()
        Me.celdaRef2 = New System.Windows.Forms.TextBox()
        Me.celdaRef1 = New System.Windows.Forms.TextBox()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaSeguro = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.etiquetaCosteo = New System.Windows.Forms.Label()
        Me.etiquetaRef2 = New System.Windows.Forms.Label()
        Me.etiquetaRef1 = New System.Windows.Forms.Label()
        Me.etiquetaFactura = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaInfo = New System.Windows.Forms.TextBox()
        Me.panelListaDocumen = New System.Windows.Forms.Panel()
        Me.dgListaDocument = New System.Windows.Forms.DataGridView()
        Me.gbDatoPoliza = New System.Windows.Forms.GroupBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDNombre = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.botonNombre = New System.Windows.Forms.Button()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaFech = New System.Windows.Forms.Label()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.panelInfoPie = New System.Windows.Forms.Panel()
        Me.etiquetasTotales2 = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales1 = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.dgDatosArriboPuerto = New System.Windows.Forms.GroupBox()
        Me.checkContenedor = New System.Windows.Forms.CheckBox()
        Me.celdaFecha = New System.Windows.Forms.TextBox()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaNaviera = New System.Windows.Forms.TextBox()
        Me.etiquetaNaviera = New System.Windows.Forms.Label()
        Me.panelSubDocumentos = New System.Windows.Forms.Panel()
        Me.dgSubsDocument = New System.Windows.Forms.DataGridView()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.panelListaDocumen.SuspendLayout()
        CType(Me.dgListaDocument, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDatoPoliza.SuspendLayout()
        Me.panelInfoPie.SuspendLayout()
        Me.dgDatosArriboPuerto.SuspendLayout()
        Me.panelSubDocumentos.SuspendLayout()
        CType(Me.dgSubsDocument, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.botonActualizar)
        Me.panelLista.Controls.Add(Me.etiquetaAnd)
        Me.panelLista.Controls.Add(Me.dtpFinal)
        Me.panelLista.Controls.Add(Me.dtpInicio)
        Me.panelLista.Controls.Add(Me.checkMostrarDoc)
        Me.panelLista.Controls.Add(Me.celdaFiltro)
        Me.panelLista.Location = New System.Drawing.Point(544, 119)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(865, 249)
        Me.panelLista.TabIndex = 0
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.volNumero, Me.colFecha, Me.colProveedor, Me.colClase, Me.colReferencia})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 57)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(865, 192)
        Me.dgLista.TabIndex = 6
        '
        'volNumero
        '
        Me.volNumero.HeaderText = "Nº"
        Me.volNumero.Name = "volNumero"
        Me.volNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Provider"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        '
        'colClase
        '
        Me.colClase.HeaderText = "Class"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(688, 16)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaAnd
        '
        Me.etiquetaAnd.AutoSize = True
        Me.etiquetaAnd.Location = New System.Drawing.Point(439, 22)
        Me.etiquetaAnd.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAnd.Name = "etiquetaAnd"
        Me.etiquetaAnd.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaAnd.TabIndex = 4
        Me.etiquetaAnd.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(528, 17)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(127, 22)
        Me.dtpFinal.TabIndex = 3
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(303, 17)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(127, 22)
        Me.dtpInicio.TabIndex = 2
        '
        'checkMostrarDoc
        '
        Me.checkMostrarDoc.AutoSize = True
        Me.checkMostrarDoc.Location = New System.Drawing.Point(47, 21)
        Me.checkMostrarDoc.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkMostrarDoc.Name = "checkMostrarDoc"
        Me.checkMostrarDoc.Size = New System.Drawing.Size(224, 21)
        Me.checkMostrarDoc.TabIndex = 1
        Me.checkMostrarDoc.Text = "Show Document Between Date"
        Me.checkMostrarDoc.UseVisualStyleBackColor = True
        '
        'celdaFiltro
        '
        Me.celdaFiltro.BackColor = System.Drawing.SystemColors.Info
        Me.celdaFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.celdaFiltro.Location = New System.Drawing.Point(0, 0)
        Me.celdaFiltro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaFiltro.Multiline = True
        Me.celdaFiltro.Name = "celdaFiltro"
        Me.celdaFiltro.ReadOnly = True
        Me.celdaFiltro.Size = New System.Drawing.Size(865, 57)
        Me.celdaFiltro.TabIndex = 0
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(952, 89)
        Me.Encabezado1.TabIndex = 1
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(952, 37)
        Me.BarraTitulo1.TabIndex = 2
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.GroupBox2)
        Me.panelDocumento.Controls.Add(Me.GroupBox1)
        Me.panelDocumento.Controls.Add(Me.gbDatoPoliza)
        Me.panelDocumento.Location = New System.Drawing.Point(16, 177)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(936, 473)
        Me.panelDocumento.TabIndex = 3
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Location = New System.Drawing.Point(4, 325)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(916, 139)
        Me.panelDetalle.TabIndex = 4
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colArticulo, Me.colUMedida, Me.colPrecio, Me.colDescuento, Me.colDescuentoDolar, Me.colCantidad, Me.colTotal})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(916, 139)
        Me.dgDetalle.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code*"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        '
        'colArticulo
        '
        Me.colArticulo.HeaderText = "Article"
        Me.colArticulo.Name = "colArticulo"
        Me.colArticulo.ReadOnly = True
        '
        'colUMedida
        '
        Me.colUMedida.HeaderText = "U/Medida"
        Me.colUMedida.Name = "colUMedida"
        Me.colUMedida.ReadOnly = True
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price $"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        '
        'colDescuento
        '
        Me.colDescuento.HeaderText = "Dscto. %"
        Me.colDescuento.Name = "colDescuento"
        Me.colDescuento.ReadOnly = True
        '
        'colDescuentoDolar
        '
        Me.colDescuentoDolar.HeaderText = "Dscto. $"
        Me.colDescuentoDolar.Name = "colDescuentoDolar"
        Me.colDescuentoDolar.ReadOnly = True
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity*"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total $"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.celdaSeguro)
        Me.GroupBox2.Controls.Add(Me.celdaFlete)
        Me.GroupBox2.Controls.Add(Me.celdaCosteo)
        Me.GroupBox2.Controls.Add(Me.celdaRef2)
        Me.GroupBox2.Controls.Add(Me.celdaRef1)
        Me.GroupBox2.Controls.Add(Me.celdaFactura)
        Me.GroupBox2.Controls.Add(Me.etiquetaSeguro)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.etiquetaCosteo)
        Me.GroupBox2.Controls.Add(Me.etiquetaRef2)
        Me.GroupBox2.Controls.Add(Me.etiquetaRef1)
        Me.GroupBox2.Controls.Add(Me.etiquetaFactura)
        Me.GroupBox2.Location = New System.Drawing.Point(456, 185)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(461, 133)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Reference Document Data"
        '
        'celdaSeguro
        '
        Me.celdaSeguro.Location = New System.Drawing.Point(308, 105)
        Me.celdaSeguro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.Size = New System.Drawing.Size(131, 22)
        Me.celdaSeguro.TabIndex = 21
        '
        'celdaFlete
        '
        Me.celdaFlete.Location = New System.Drawing.Point(292, 64)
        Me.celdaFlete.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaFlete.Name = "celdaFlete"
        Me.celdaFlete.Size = New System.Drawing.Size(147, 22)
        Me.celdaFlete.TabIndex = 20
        '
        'celdaCosteo
        '
        Me.celdaCosteo.Location = New System.Drawing.Point(292, 25)
        Me.celdaCosteo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaCosteo.Name = "celdaCosteo"
        Me.celdaCosteo.Size = New System.Drawing.Size(147, 22)
        Me.celdaCosteo.TabIndex = 19
        '
        'celdaRef2
        '
        Me.celdaRef2.Location = New System.Drawing.Point(72, 96)
        Me.celdaRef2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaRef2.Name = "celdaRef2"
        Me.celdaRef2.Size = New System.Drawing.Size(147, 22)
        Me.celdaRef2.TabIndex = 18
        '
        'celdaRef1
        '
        Me.celdaRef1.Location = New System.Drawing.Point(72, 60)
        Me.celdaRef1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaRef1.Name = "celdaRef1"
        Me.celdaRef1.Size = New System.Drawing.Size(147, 22)
        Me.celdaRef1.TabIndex = 17
        '
        'celdaFactura
        '
        Me.celdaFactura.Location = New System.Drawing.Point(72, 25)
        Me.celdaFactura.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.Size = New System.Drawing.Size(147, 22)
        Me.celdaFactura.TabIndex = 16
        '
        'etiquetaSeguro
        '
        Me.etiquetaSeguro.AutoSize = True
        Me.etiquetaSeguro.Location = New System.Drawing.Point(228, 108)
        Me.etiquetaSeguro.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSeguro.Name = "etiquetaSeguro"
        Me.etiquetaSeguro.Size = New System.Drawing.Size(70, 17)
        Me.etiquetaSeguro.TabIndex = 6
        Me.etiquetaSeguro.Text = "Insurance"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(228, 73)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Freight"
        '
        'etiquetaCosteo
        '
        Me.etiquetaCosteo.AutoSize = True
        Me.etiquetaCosteo.Location = New System.Drawing.Point(228, 37)
        Me.etiquetaCosteo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCosteo.Name = "etiquetaCosteo"
        Me.etiquetaCosteo.Size = New System.Drawing.Size(55, 17)
        Me.etiquetaCosteo.TabIndex = 4
        Me.etiquetaCosteo.Text = "Costing"
        '
        'etiquetaRef2
        '
        Me.etiquetaRef2.AutoSize = True
        Me.etiquetaRef2.Location = New System.Drawing.Point(19, 100)
        Me.etiquetaRef2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRef2.Name = "etiquetaRef2"
        Me.etiquetaRef2.Size = New System.Drawing.Size(42, 17)
        Me.etiquetaRef2.TabIndex = 3
        Me.etiquetaRef2.Text = "Ref.2"
        '
        'etiquetaRef1
        '
        Me.etiquetaRef1.AutoSize = True
        Me.etiquetaRef1.Location = New System.Drawing.Point(19, 64)
        Me.etiquetaRef1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaRef1.Name = "etiquetaRef1"
        Me.etiquetaRef1.Size = New System.Drawing.Size(42, 17)
        Me.etiquetaRef1.TabIndex = 2
        Me.etiquetaRef1.Text = "Ref.1"
        '
        'etiquetaFactura
        '
        Me.etiquetaFactura.AutoSize = True
        Me.etiquetaFactura.Location = New System.Drawing.Point(19, 28)
        Me.etiquetaFactura.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFactura.Name = "etiquetaFactura"
        Me.etiquetaFactura.Size = New System.Drawing.Size(52, 17)
        Me.etiquetaFactura.TabIndex = 1
        Me.etiquetaFactura.Text = "Invoice"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaInfo)
        Me.GroupBox1.Controls.Add(Me.panelListaDocumen)
        Me.GroupBox1.Location = New System.Drawing.Point(456, 12)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(461, 165)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "including shipment confirmation"
        '
        'celdaInfo
        '
        Me.celdaInfo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInfo.Location = New System.Drawing.Point(23, 123)
        Me.celdaInfo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaInfo.Multiline = True
        Me.celdaInfo.Name = "celdaInfo"
        Me.celdaInfo.Size = New System.Drawing.Size(429, 34)
        Me.celdaInfo.TabIndex = 1
        '
        'panelListaDocumen
        '
        Me.panelListaDocumen.Controls.Add(Me.dgListaDocument)
        Me.panelListaDocumen.Location = New System.Drawing.Point(23, 23)
        Me.panelListaDocumen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelListaDocumen.Name = "panelListaDocumen"
        Me.panelListaDocumen.Size = New System.Drawing.Size(431, 92)
        Me.panelListaDocumen.TabIndex = 0
        '
        'dgListaDocument
        '
        Me.dgListaDocument.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaDocument.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaDocument.Location = New System.Drawing.Point(0, 0)
        Me.dgListaDocument.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgListaDocument.MultiSelect = False
        Me.dgListaDocument.Name = "dgListaDocument"
        Me.dgListaDocument.ReadOnly = True
        Me.dgListaDocument.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaDocument.Size = New System.Drawing.Size(431, 92)
        Me.dgListaDocument.TabIndex = 0
        '
        'gbDatoPoliza
        '
        Me.gbDatoPoliza.Controls.Add(Me.celdaIDMoneda)
        Me.gbDatoPoliza.Controls.Add(Me.celdaIDNombre)
        Me.gbDatoPoliza.Controls.Add(Me.botonMoneda)
        Me.gbDatoPoliza.Controls.Add(Me.botonNombre)
        Me.gbDatoPoliza.Controls.Add(Me.celdaTasa)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaTasa)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaFech)
        Me.gbDatoPoliza.Controls.Add(Me.dtpDate)
        Me.gbDatoPoliza.Controls.Add(Me.celdaMoneda)
        Me.gbDatoPoliza.Controls.Add(Me.celdaNIT)
        Me.gbDatoPoliza.Controls.Add(Me.celdaNumero)
        Me.gbDatoPoliza.Controls.Add(Me.celdaNombre)
        Me.gbDatoPoliza.Controls.Add(Me.celdaDescripcion)
        Me.gbDatoPoliza.Controls.Add(Me.checkActivo)
        Me.gbDatoPoliza.Controls.Add(Me.celdaAño)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaMoneda)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaNIT)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaDireccion)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaNombre)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaNumero)
        Me.gbDatoPoliza.Controls.Add(Me.etiquetaAño)
        Me.gbDatoPoliza.Location = New System.Drawing.Point(4, 4)
        Me.gbDatoPoliza.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbDatoPoliza.Name = "gbDatoPoliza"
        Me.gbDatoPoliza.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gbDatoPoliza.Size = New System.Drawing.Size(444, 314)
        Me.gbDatoPoliza.TabIndex = 1
        Me.gbDatoPoliza.TabStop = False
        Me.gbDatoPoliza.Text = "Document Data"
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(189, 245)
        Me.celdaIDMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(27, 22)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDNombre
        '
        Me.celdaIDNombre.Location = New System.Drawing.Point(379, 85)
        Me.celdaIDNombre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIDNombre.Name = "celdaIDNombre"
        Me.celdaIDNombre.Size = New System.Drawing.Size(27, 22)
        Me.celdaIDNombre.TabIndex = 24
        Me.celdaIDNombre.Text = "-1"
        Me.celdaIDNombre.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(168, 209)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(49, 28)
        Me.botonMoneda.TabIndex = 23
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'botonNombre
        '
        Me.botonNombre.Location = New System.Drawing.Point(321, 82)
        Me.botonNombre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonNombre.Name = "botonNombre"
        Me.botonNombre.Size = New System.Drawing.Size(49, 28)
        Me.botonNombre.TabIndex = 21
        Me.botonNombre.Text = "..."
        Me.botonNombre.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(268, 214)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(101, 22)
        Me.celdaTasa.TabIndex = 20
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(225, 218)
        Me.etiquetaTasa.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 19
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaFech
        '
        Me.etiquetaFech.AutoSize = True
        Me.etiquetaFech.Location = New System.Drawing.Point(264, 60)
        Me.etiquetaFech.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFech.Name = "etiquetaFech"
        Me.etiquetaFech.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFech.TabIndex = 18
        Me.etiquetaFech.Text = "Date"
        '
        'dtpDate
        '
        Me.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDate.Location = New System.Drawing.Point(321, 57)
        Me.dtpDate.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(113, 22)
        Me.dtpDate.TabIndex = 17
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(84, 209)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(75, 22)
        Me.celdaMoneda.TabIndex = 16
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(84, 174)
        Me.celdaNIT.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(132, 22)
        Me.celdaNIT.TabIndex = 15
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(84, 57)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(75, 22)
        Me.celdaNumero.TabIndex = 12
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(84, 85)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(228, 22)
        Me.celdaNombre.TabIndex = 11
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(84, 112)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(351, 48)
        Me.celdaDescripcion.TabIndex = 10
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(268, 33)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 9
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(84, 30)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(75, 22)
        Me.celdaAño.TabIndex = 8
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(8, 218)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(65, 17)
        Me.etiquetaMoneda.TabIndex = 7
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(12, 182)
        Me.etiquetaNIT.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(42, 17)
        Me.etiquetaNIT.TabIndex = 5
        Me.etiquetaNIT.Text = "N.I.T."
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(12, 116)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(64, 17)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(12, 89)
        Me.etiquetaNombre.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaNombre.TabIndex = 2
        Me.etiquetaNombre.Text = "Name"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(12, 60)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(12, 33)
        Me.etiquetaAño.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'panelInfoPie
        '
        Me.panelInfoPie.Controls.Add(Me.etiquetasTotales2)
        Me.panelInfoPie.Controls.Add(Me.etiquetaTotales1)
        Me.panelInfoPie.Controls.Add(Me.etiquetaTotales)
        Me.panelInfoPie.Controls.Add(Me.dgDatosArriboPuerto)
        Me.panelInfoPie.Controls.Add(Me.panelSubDocumentos)
        Me.panelInfoPie.Location = New System.Drawing.Point(19, 677)
        Me.panelInfoPie.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelInfoPie.Name = "panelInfoPie"
        Me.panelInfoPie.Size = New System.Drawing.Size(933, 162)
        Me.panelInfoPie.TabIndex = 4
        '
        'etiquetasTotales2
        '
        Me.etiquetasTotales2.Location = New System.Drawing.Point(841, 49)
        Me.etiquetasTotales2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.etiquetasTotales2.Name = "etiquetasTotales2"
        Me.etiquetasTotales2.Size = New System.Drawing.Size(87, 22)
        Me.etiquetasTotales2.TabIndex = 14
        '
        'etiquetaTotales1
        '
        Me.etiquetaTotales1.Location = New System.Drawing.Point(749, 49)
        Me.etiquetaTotales1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.etiquetaTotales1.Name = "etiquetaTotales1"
        Me.etiquetaTotales1.Size = New System.Drawing.Size(87, 22)
        Me.etiquetaTotales1.TabIndex = 13
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(701, 53)
        Me.etiquetaTotales.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaTotales.TabIndex = 2
        Me.etiquetaTotales.Text = "Totals"
        '
        'dgDatosArriboPuerto
        '
        Me.dgDatosArriboPuerto.Controls.Add(Me.checkContenedor)
        Me.dgDatosArriboPuerto.Controls.Add(Me.celdaFecha)
        Me.dgDatosArriboPuerto.Controls.Add(Me.etiquetaFecha)
        Me.dgDatosArriboPuerto.Controls.Add(Me.celdaNaviera)
        Me.dgDatosArriboPuerto.Controls.Add(Me.etiquetaNaviera)
        Me.dgDatosArriboPuerto.Location = New System.Drawing.Point(371, 18)
        Me.dgDatosArriboPuerto.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDatosArriboPuerto.Name = "dgDatosArriboPuerto"
        Me.dgDatosArriboPuerto.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDatosArriboPuerto.Size = New System.Drawing.Size(323, 123)
        Me.dgDatosArriboPuerto.TabIndex = 1
        Me.dgDatosArriboPuerto.TabStop = False
        Me.dgDatosArriboPuerto.Text = "Data Arrival in Port"
        '
        'checkContenedor
        '
        Me.checkContenedor.AutoSize = True
        Me.checkContenedor.Location = New System.Drawing.Point(172, 95)
        Me.checkContenedor.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkContenedor.Name = "checkContenedor"
        Me.checkContenedor.Size = New System.Drawing.Size(127, 21)
        Me.checkContenedor.TabIndex = 13
        Me.checkContenedor.Text = "Total Container"
        Me.checkContenedor.UseVisualStyleBackColor = True
        '
        'celdaFecha
        '
        Me.celdaFecha.Location = New System.Drawing.Point(120, 68)
        Me.celdaFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaFecha.Name = "celdaFecha"
        Me.celdaFecha.Size = New System.Drawing.Size(87, 22)
        Me.celdaFecha.TabIndex = 12
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(8, 71)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 11
        Me.etiquetaFecha.Text = "Date"
        '
        'celdaNaviera
        '
        Me.celdaNaviera.Location = New System.Drawing.Point(120, 31)
        Me.celdaNaviera.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaNaviera.Name = "celdaNaviera"
        Me.celdaNaviera.Size = New System.Drawing.Size(181, 22)
        Me.celdaNaviera.TabIndex = 10
        '
        'etiquetaNaviera
        '
        Me.etiquetaNaviera.AutoSize = True
        Me.etiquetaNaviera.Location = New System.Drawing.Point(8, 34)
        Me.etiquetaNaviera.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNaviera.Name = "etiquetaNaviera"
        Me.etiquetaNaviera.Size = New System.Drawing.Size(103, 17)
        Me.etiquetaNaviera.TabIndex = 9
        Me.etiquetaNaviera.Text = "Shipping Comp"
        '
        'panelSubDocumentos
        '
        Me.panelSubDocumentos.Controls.Add(Me.dgSubsDocument)
        Me.panelSubDocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelSubDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.panelSubDocumentos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelSubDocumentos.Name = "panelSubDocumentos"
        Me.panelSubDocumentos.Size = New System.Drawing.Size(363, 162)
        Me.panelSubDocumentos.TabIndex = 0
        '
        'dgSubsDocument
        '
        Me.dgSubsDocument.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSubsDocument.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgSubsDocument.Location = New System.Drawing.Point(0, 0)
        Me.dgSubsDocument.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgSubsDocument.Name = "dgSubsDocument"
        Me.dgSubsDocument.Size = New System.Drawing.Size(363, 162)
        Me.dgSubsDocument.TabIndex = 1
        '
        'frmDatosPolizaImport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(952, 878)
        Me.Controls.Add(Me.panelInfoPie)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Controls.Add(Me.panelLista)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmDatosPolizaImport"
        Me.Text = "frmDatosPolizaImport"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        Me.panelLista.PerformLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelListaDocumen.ResumeLayout(False)
        CType(Me.dgListaDocument, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDatoPoliza.ResumeLayout(False)
        Me.gbDatoPoliza.PerformLayout()
        Me.panelInfoPie.ResumeLayout(False)
        Me.panelInfoPie.PerformLayout()
        Me.dgDatosArriboPuerto.ResumeLayout(False)
        Me.dgDatosArriboPuerto.PerformLayout()
        Me.panelSubDocumentos.ResumeLayout(False)
        CType(Me.dgSubsDocument, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents volNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colClase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents etiquetaAnd As System.Windows.Forms.Label
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkMostrarDoc As System.Windows.Forms.CheckBox
    Friend WithEvents celdaFiltro As System.Windows.Forms.TextBox
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents gbDatoPoliza As System.Windows.Forms.GroupBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDNombre As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents botonNombre As System.Windows.Forms.Button
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents etiquetaFech As System.Windows.Forms.Label
    Friend WithEvents dtpDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaNombre As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaNombre As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colArticulo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescuento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescuentoDolar As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaSeguro As System.Windows.Forms.TextBox
    Friend WithEvents celdaFlete As System.Windows.Forms.TextBox
    Friend WithEvents celdaCosteo As System.Windows.Forms.TextBox
    Friend WithEvents celdaRef2 As System.Windows.Forms.TextBox
    Friend WithEvents celdaRef1 As System.Windows.Forms.TextBox
    Friend WithEvents celdaFactura As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSeguro As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents etiquetaCosteo As System.Windows.Forms.Label
    Friend WithEvents etiquetaRef2 As System.Windows.Forms.Label
    Friend WithEvents etiquetaRef1 As System.Windows.Forms.Label
    Friend WithEvents etiquetaFactura As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaInfo As System.Windows.Forms.TextBox
    Friend WithEvents panelListaDocumen As System.Windows.Forms.Panel
    Friend WithEvents dgListaDocument As System.Windows.Forms.DataGridView
    Friend WithEvents panelInfoPie As System.Windows.Forms.Panel
    Friend WithEvents etiquetasTotales2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotales1 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTotales As System.Windows.Forms.Label
    Friend WithEvents dgDatosArriboPuerto As System.Windows.Forms.GroupBox
    Friend WithEvents checkContenedor As System.Windows.Forms.CheckBox
    Friend WithEvents celdaFecha As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaFecha As System.Windows.Forms.Label
    Friend WithEvents celdaNaviera As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNaviera As System.Windows.Forms.Label
    Friend WithEvents panelSubDocumentos As System.Windows.Forms.Panel
    Friend WithEvents dgSubsDocument As System.Windows.Forms.DataGridView
End Class
