﻿Public Class frmPedidoFibra
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer
    Dim contratoNum As Integer
    Dim Descargos As Integer
    Private Const DOC_NAME As String = "Doc_CPedido"
    Dim strTextoComentario As String

    Private dblSaldo As Double
    Private intLinea As Integer
    Private dblDocCantidad As Double
    Private dblDocTotal As Double

    'Constantes
    Public Const PRE_PF As String = "PF "
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Private Const STR_NOMBRE As String = "cliente"

    'Si el documento tiene descargos indica la línea mayor
    Private intMaxRef As Integer

    Public logRelacion As Boolean

    Dim dtpDetalle As DateTimePicker
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            'botonImprimir.Enabled = False
            ' botonBuscar.Enabled = True

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonImprimir.Enabled = True
            'botonBuscar.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Proforma Invoice Fiber")
            queryListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                If celdaidProyecto.Text <> NO_FILA Then
                    BarraTitulo1.CambiarTitulo("Modify Registration Project # " & celdaidProyecto.Text & "  " & celdaProyecto.Text & "")
                Else
                    BarraTitulo1.CambiarTitulo("Modify Registration")
                End If
                '   BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
            End If
            'Reset()
            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String

        Dim strFiltrarLista As String
        Dim ErrorLog As String

        On Error GoTo e_error

        strFiltrarLista = " Select HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, HDoc_Emp_Nom cliente, HDoc_DR1_Num referencia, HDoc_RF1_Txt texto, HDoc_Doc_Status estado, HDoc_Doc_Ano anio, HDoc_emp_Dir Direccion,HDoc_Pro_DCat Revisado "
        strFiltrarLista &= "    From Dcmtos_HDR"
        strFiltrarLista &= "    Where HDoc_Sis_Emp = {empresa} And HDoc_Doc_Cat = 941"

        If Checkfecha.Checked = True Then

            strFiltrarLista &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strFiltrarLista = Replace(strFiltrarLista, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strFiltrarLista = Replace(strFiltrarLista, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        End If

        strFiltrarLista &= "   Order By HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"


        strFiltrarLista = Replace(strFiltrarLista, "{empresa}", Sesion.IdEmpresa)

        Return strFiltrarLista


e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        ' ErrorLog "Formulario -> Form.SqlLista()"
        On Error GoTo 0


    End Function
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim r As Integer
        strSQL = SQLLista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("cliente") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetString("Direccion") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("Revisado")

                    r = REA.GetInt32("Revisado")
                    'cFunciones.AgregarFila(dgLista, strFila)
                    cfun.AgregarFila(dgLista, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ComprobarFila(ByVal Index As Integer) As Boolean
        ComprobarFila = True
        Dim Comprobacion As Boolean
        Dim strFecha As Date

        If dgDetalle.Rows(Index).Visible = True Then
            If dgDetalle.Rows(Index).Cells("colCodigo").Value And Index = dgDetalle.Rows.Count - 1 Then
                ComprobarFila = True
            End If
            If Val(dgDetalle.Rows(Index).Cells("colCodigo").Value) = vbEmpty Then
                MsgBox("Row " & Index + 1 & ": Invalid Code Article.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colDescripcion").Value = vbNullString Then
                MsgBox("Row " & Index + 1 & ": Blank Description.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colFecha").Value = vbNullString Then
                MsgBox("Row " & Index + 1 & ": Delivery date blank.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            End If

            If dgDetalle.Columns("colFechaInicio").Visible = True Then
                If dgDetalle.Rows(Index).Cells("colFechaInicio").Value = "-1" Then
                    If MsgBox("Row " & Index + 1 & ": You must enter a start date and an end date", vbExclamation, "Notice") Then
                        ComprobarFila = False
                        Exit Function
                    End If
                Else
                    ComprobarFila = True
                End If
            End If


            If Not Comprobacion Then
                If Val(dgDetalle.Rows(Index).Cells("colCantidad").Value) = vbEmpty Then
                    MsgBox("Fila " & Index + 1 & ": Item number ZERO.", vbExclamation, "Notice")
                    ComprobarFila = True
                End If
            End If
        End If
        'ComprobarFila = Not Comprobacion
        Return ComprobarFila
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        Dim i As Integer
        Dim logErr As Boolean

        If celdaEmpresa.Text = vbNullString Or celdaCatalogo.Text = vbNullString Or celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete Data System.", vbCritical)
        ElseIf celdaIDCliente.Text = vbNullString Or
            celdaCliente.Text = vbNullString Or
            celdaDireccion.Text = vbNullString Or
            celdaNit.Text = vbNullString Then
            MsgBox("You must enter all minimum data.", vbCritical)
            comprobar = False
            'Verifica Datos en el DETALLE.
            'logErr = False
            'ComprobarDatos = False
        Else
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If ComprobarFila(i) = True Then
                    logErr = True
                    Exit For
                Else
                    comprobar = False
                    Exit Function
                End If
            Next

            If Not logErr Then
                'Verifica que total > 0
                If Not celdaTotales.Text > vbEmpty Then
                    MsgBox("An order is not supported with ZERO amount.", vbCritical)
                End If
            End If


        End If
        Return comprobar
    End Function
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = -1
        celdaNumero.Text = -1
        celdaDireccion.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaIDCliente.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaNumeroReq.Text = STR_VACIO
        dtpFecha1.Text = STR_VACIO
        celdaTC.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaTotales.Text = 0
        celdaTotales2.Text = 0
        dgDetalle.Rows.Clear()
        dgDetalle2.Rows.Clear()
        celdaRevisado.Text = NO_FILA
        celdaImpuestos.Text = NO_FILA
        BotonCliente.Enabled = True
        checkActivo.Checked = False
        checkActivo.Enabled = True
        celdaidProveedor.Text = NO_FILA
        celdaProveedor.Text = STR_VACIO
        celdaDireccionProveedor.Text = STR_VACIO
        celdaidFabricante.Text = NO_FILA
        celdaFabricante.Text = STR_VACIO
        celdaDireccionFabricante.Text = STR_VACIO
        ' logInsertar = False
        LogBorrar = True
    End Sub
    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double

        Try
            dblDocCantidad = 0
            dblDocTotal = 0
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                dblCant = dgDetalle.Rows(i).Cells("colCantidad").Value
                dblDocCantidad = dblDocCantidad + dblCant
                dblDocTotal = dblDocTotal + (dblCant * dblPrecio)
            Next
            celdaTotales.Text = dblDocCantidad.ToString(FORMATO_MONEDA)
            celdaTotales2.Text = dblDocTotal.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaFactura() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}   "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 941)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean = True
        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = 941
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha1.Value
            chdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, vbEmpty)

            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_NIT = celdaNit.Text

            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            chdr.HDOC_DOC_TC = celdaTC.Text


            chdr.HDOC_DR1_NUM = celdaNumeroReq.Text
            chdr.HDOC_DR2_NUM = celdaCredit.Text

            chdr.HDOC_USUARIO = celdaUsuario.Text
            'Proveedor 
            chdr.HDOC_DR1_EMP = celdaidProveedor.Text
            chdr.HDOC_DR2_EMP = celdaidFabricante.Text
            '    chdr.HDOC_PRO_DCAT = celdaRevisado.Text

            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Query para Guardar Descargos
    Private Function GuardarDescargos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlPro As New clsDcmtos_DTL_Pro
        DtlPro.CONEXION = strConexion

        Try

            DtlPro.PDOC_SIS_EMP = Sesion.IdEmpresa

            'Documento a ser Descargado


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    'Query para guardar el Detalle
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intLinea As Integer = vbEmpty


        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                strSQL = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
                strSQL &= "      FROM Dcmtos_DTL d"
                strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{catalogo}", 941)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    intLinea = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using


                If dgDetalle.Rows(i).Visible = True Then
                    Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                    Dtl.DDOC_DOC_CAT = 941
                    Dtl.DDOC_DOC_ANO = celdaAño.Text
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    If Me.Tag = "Nuevo" Or dgDetalle.Rows(i).Cells("colAgrega").Value = 0 Then
                        Dtl.DDOC_DOC_LIN = intLinea
                        dgDetalle.Rows(i).Cells("colLineaDet").Value = intLinea
                        'dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                    Else
                        Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaDet").Value

                    End If

                    Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                    Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                    Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colNumMedida").Value

                    Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                    Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colOrigen").Value
                    If dgDetalle.Rows(i).Cells("colFechaInicio").Value = "" Then
                        Dtl.DDOC_RF1_FEC = Nothing
                    Else
                        Dtl.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colFechaInicio").Value
                    End If

                    If dgDetalle.Rows(i).Cells("colFecha").Value = "" Then
                        Dtl.DDOC_RF2_FEC = Nothing
                    Else
                        Dtl.DDoc_RF2_Fec_NET = dgDetalle.Rows(i).Cells("colFecha").Value
                    End If

                    If dgDetalle.Rows(i).Cells("colObservacion").Value = vbNullString Then
                    Else
                        Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colObservacion").Value
                    End If

                    If dgDetalle.Rows(i).Cells("colAgrega").Value = 1 And Me.Tag = "Mod" Then
                        If Dtl.Actualizar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf dgDetalle.Rows(i).Cells("colAgrega").Value = 0 Or Me.Tag = "Nuevo" Then
                        If Dtl.Guardar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function VerificarSiTieneDespacho() As Integer
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*) FROM Dcmtos_HDR d "
        strSQL &= " LEFT JOIN Dcmtos_DTL_Pro s ON s.PDoc_Sis_Emp = d.HDoc_Sis_Emp AND s.PDoc_Par_Cat = d.HDoc_Doc_Cat AND s.PDoc_Par_Ano = d.HDoc_Doc_Ano AND s.PDoc_Par_Num = d.HDoc_Doc_Num and s.PDoc_Chi_Cat = 942 "
        strSQL &= " WHERE d.HDoc_Sis_Emp = {empresa} AND d.HDoc_Doc_Cat = 941 AND d.HDoc_Doc_Ano = {anio} AND d.HDoc_Doc_Num = {num} AND s.PDoc_Sis_Emp IS NULL "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto

    End Function
    Private Function SqlDescargos(ByVal Linea As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "SELECT COUNT(*) "
        strSQL &= "  FROM Dcmtos_DTL_Pro p"
        strSQL &= "          LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp and h.HDoc_Doc_Cat = p.PDoc_Chi_Cat and h.HDoc_Doc_Ano = p.PDoc_Chi_Ano and h.HDoc_Doc_Num = p.PDoc_Chi_Num"
        strSQL &= "      WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat  = 941 AND p.PDoc_Par_Ano = {año} AND p.PDoc_Chi_Cat = 942 AND p.PDoc_Par_Num = {numero} AND p.PDoc_Par_Lin ={linea} AND h.HDoc_Doc_Status = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{linea}", Linea)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Descargos = COM.ExecuteScalar()
        conec.Close()

        Return Descargos
    End Function
    Private Function SqlDescargos()

        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "SELECT COUNT(*) "
        strSQL &= "  FROM Dcmtos_DTL_Pro p"
        strSQL &= "          LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp and h.HDoc_Doc_Cat = p.PDoc_Chi_Cat and h.HDoc_Doc_Ano = p.PDoc_Chi_Ano and h.HDoc_Doc_Num = p.PDoc_Chi_Num"
        strSQL &= "      WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat  = 941 AND p.PDoc_Par_Ano = {año} AND p.PDoc_Chi_Cat = 942 AND p.PDoc_Par_Num = {numero} AND h.HDoc_Doc_Status = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Descargos = COM.ExecuteScalar()
        conec.Close()

        Return Descargos
    End Function
    Private Sub BorrarLineDetalle(ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Visible = False Then
                If SqlDescargos(dgDetalle.Rows(i).Cells("colLineaDet").Value) > 0 Then
                    MsgBox("You can not delete this line because you already have downloads", vbExclamation, "Notice")
                Else
                    strSQL = "   Delete"
                    strSQL &= "      FROM Dcmtos_DTL"
                    strSQL &= "  WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Num ={numero} AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Lin ={linea}"

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{numero}", intNumero)
                    strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
                    strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaDet").Value)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        'strTemp = COM.ExecuteScalar
                        COM.ExecuteNonQuery()
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                End If
            End If
        Next
    End Sub
    Private Function VerificarDependenciaInstruccion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim TieneInstruccion As Integer
        Try

            strSQL = " SELECT COUNT(p.PDoc_Chi_Num)
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Par_Cat = h.HDoc_Doc_Cat AND p.PDoc_Par_Ano = h.HDoc_Doc_Ano AND p.PDoc_Par_Num = h.HDoc_Doc_Num 
                                WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 941 AND h.HDoc_Doc_Ano= {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            TieneInstruccion = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return TieneInstruccion
    End Function
    Private Sub EliminarEncabezado()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_HDR 
                            WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = 941 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_DTL 
                            WHERE DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = 941 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalle(ByVal intNumero As Integer, ByVal intAño As Integer) As String

        Dim strsql As String
        Dim errorLog As String

        On Error GoTo e_error

        strsql = " Select HDoc_Sis_Emp empresa, HDoc_Doc_Cat catalogo, HDoc_Doc_Ano anio, HDoc_Doc_Num numeroDoc, HDoc_Doc_Fec fecha, HDoc_Emp_Cod codEmpresa, HDoc_Emp_Nom nombreEmp, HDoc_Emp_Dir direccion,  HDoc_Emp_Nit NIT, HDoc_DR1_Num docNum,HDoc_DR2_Num Term, HDoc_Doc_TC tasa, HDoc_Doc_Mon moneda, HDoc_Doc_Status estatus, cli_codigo codCliente, cli_cliente cliente, cli_direccion direccionCli, cli_telefono telCliente, cat_clave Moneda,IFNULL(p.pro_codigo,-1) codigoProveedor, IFNULL(p.pro_proveedor,'') NombreProveedor,IFNULL(p.pro_direccion,'') DireccionProveedor,IFNULL(p1.pro_codigo,-1) codigoFabricante,IFNULL(p1.pro_proveedor,'') NombreFabricante, IFNULL(p1.pro_direccion,'') DireccionFabricante "
        strsql &= "    From Dcmtos_HDR"
        strsql &= "        Left Join Clientes ON cli_codigo = HDoc_DR1_Emp And cli_sisemp = HDoc_Sis_Emp"
        strsql &= "     LEFT JOIN Catalogos ON  cat_num = HDoc_Doc_Mon"
        strsql &= "   LEFT JOIN Proveedores p ON p.pro_sisemp = HDoc_Sis_Emp AND p.pro_codigo = HDoc_DR1_Emp AND p.pro_fabricante = 'NO'"
        strsql &= " LEFT JOIN Proveedores p1 ON p1.pro_sisemp = HDoc_Sis_Emp AND p1.pro_codigo = HDoc_DR2_Emp AND p1.pro_fabricante = 'SI' "
        strsql &= "WHERE HDoc_Doc_Cat = 941 And HDoc_Sis_Emp = {empresa} And HDoc_Doc_Num = {numero} And HDoc_Doc_Ano = {anio}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        ' ErrorLog "Formulario -> Form.SqlLista()"
        On Error GoTo 0

    End Function
    Public Sub queryEncabezado(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO


        strSQL = SQLDetalle(intNumero, intAño)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                'dgLista.Rows.Clear()

                Do While REA.Read

                    celdaNumero.Text = REA.GetInt32("numeroDoc")
                    celdaNumero.Enabled = False
                    dtpFecha1.Text = REA.GetDateTime("fecha")
                    celdaCliente.Text = REA.GetString("nombreEmp")
                    celdaIDCliente.Text = REA.GetInt32("codEmpresa")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaNit.Text = REA.GetString("NIT")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaIDMoneda.Text = REA.GetInt32("moneda")
                    celdaAño.Text = REA.GetInt32("anio")
                    celdaAño.Enabled = False
                    celdaTC.Text = REA.GetDouble("tasa")
                    celdaNumeroReq.Text = REA.GetString("docNum")
                    celdaCredit.Text = REA.GetString("Term")
                    celdaEmpresa.Text = Sesion.IdEmpresa
                    celdaCatalogo.Text = 941
                    celdaUsuario.Text = Sesion.Usuario
                    celdaidProveedor.Text = REA.GetInt32("codigoProveedor")
                    celdaProveedor.Text = REA.GetString("NombreProveedor")
                    celdaDireccionProveedor.Text = REA.GetString("DireccionProveedor")
                    celdaidFabricante.Text = REA.GetInt32("codigoFabricante")
                    celdaFabricante.Text = REA.GetString("NombreFabricante")
                    celdaDireccionFabricante.Text = REA.GetString("DireccionFabricante")
                    If REA.GetInt32("estatus") = 1 Then
                        checkActivo.Checked = True
                        etiquetaAnulada.Visible = False
                        checkActivo.Enabled = True
                    Else
                        checkActivo.Checked = False
                        etiquetaAnulada.Visible = True
                        checkActivo.Enabled = False
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalleDown(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strsql As String
        Dim errorLog As String

        On Error GoTo e_error

        strsql = " SELECT DDoc_Sis_Emp, DDoc_Doc_Cat Catalogo, DDoc_Doc_Ano Anio, DDoc_Doc_Num, DDoc_Prd_Cod codigo, IFNULL(DDoc_Prd_Des,'') descripcion, IFNULL(cat_num,0) numMedida, cat_clave medida,DDoc_RF1_Cod Origen, IFNULL(DDoc_Prd_PUQ,0) precio, DDoc_RF1_Fec fecha,DDoc_RF2_Fec ETD,  DDoc_Prd_QTY cantidad, DDoc_Doc_Lin linea, (DDoc_Prd_NET * DDoc_Prd_Qty) total, IFNULL(DDoc_RF2_Txt,'') Observaciones, IFNULL(("
        strsql &= "    SELECT SUM(p.PDoc_QTY_Pro) Cantidad"
        strsql &= "         FROM Dcmtos_DTL_Pro p"
        strsql &= "            WHERE p.PDoc_Sis_Emp=DDoc_Sis_Emp AND p.PDoc_Par_Cat=DDoc_Doc_Cat AND p.PDoc_Par_Ano=DDoc_Doc_Ano AND p.PDoc_Par_Num =DDoc_Doc_Num AND p.PDoc_Par_Lin =DDoc_Doc_Lin),0) Descargo"
        strsql &= "                 From Dcmtos_DTL"
        strsql &= "                 Left JOIN Catalogos ON cat_num = DDoc_Prd_UM AND cat_clase = 'Medidas'"
        strsql &= "            Left JOIN Producto_Fibra pf ON pf.prf_sisemp = DDoc_Sis_Emp AND pf.prf_numero = DDoc_Prd_Cod"
        strsql &= "         Left JOIN Clientes  ON cli_sisemp = DDoc_Sis_Emp AND cli_codigo = DDoc_RF1_Num"
        strsql &= "    WHERE DDoc_Doc_Cat = 941 AND DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}"
        strsql &= " ORDER BY DDoc_Doc_Lin;"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function

e_error:
        On Error GoTo 0

    End Function
    Public Sub queryDetalleDown(ByVal intNumero As Integer, ByVal intAño As Integer)
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim STR_ESTADO As String = "si"
        strSQL = SQLDetalleDown(intNumero, intAño)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgDetalle.Rows.Clear()
                Do While REA.Read
                    Dim strFila As String = STR_VACIO
                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetInt32("numMedida") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetString("Origen") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetDouble("cantidad") & "|"
                    strFila &= REA.GetDecimal("total") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= REA.GetDouble("Descargo") & "|"
                    strFila &= REA.GetDateTime("ETD") & "|"
                    strFila &= 1 & "|"
                    strFila &= REA.GetString("Observaciones")
                    cFunciones.AgregarFila(dgDetalle, strFila)
                    ' For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    'If REA.GetString("NumMedida") = 70 Then
                    'dgDetalle.Rows(i).Cells("colMedida").Style.BackColor = Color.Red
                    'End If
                    'If Descargos > 0 Then
                    '    dgDetalle.Rows(i).Cells("colPrecio").Value = Enabled
                    'End If
                    'Next
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalle2(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strsql As String
        Dim errorLog

        On Error GoTo e_error

        strsql = " SELECT  d.DDoc_Prd_QTY inicial,  PDoc_Par_Lin linea, PDoc_Chi_Cat catalogo, PDoc_Chi_Ano anio, PDoc_Chi_Num NumDespacho, HDoc_Doc_Fec fecha, PDoc_QTY_Pro cantidad"
        strsql &= "    From Dcmtos_DTL_Pro"
        strsql &= "        Left JOIN Dcmtos_HDR ON HDoc_Sis_Emp=PDoc_Sis_Emp AND HDoc_Doc_Cat=PDoc_Chi_Cat AND HDoc_Doc_Ano=PDoc_Chi_Ano AND HDoc_Doc_Num=PDoc_Chi_Num"
        strsql &= "        Left join Dcmtos_DTL d on d.DDoc_Sis_Emp =  PDoc_Sis_Emp and d.DDoc_Doc_Cat =PDoc_Par_Cat and d.DDoc_Doc_Ano = PDoc_Par_Ano and d.DDoc_Doc_Num =PDoc_Par_Num and d.DDoc_Doc_Lin = PDoc_Par_Lin"
        strsql &= "    WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat=941 AND PDoc_Par_Ano={anio} AND PDoc_Par_Num={numero} AND PDoc_Chi_Cat IN (942)"
        strsql &= " ORDER BY PDoc_Par_Lin, HDoc_Doc_Fec, PDoc_Chi_Num, PDoc_Chi_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        On Error GoTo 0

    End Function
    Public Sub queryDetalle2(ByVal intNumero As Integer, ByVal intAño As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLDetalle2(intNumero, intAño)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgDetalle2.Rows.Clear()
                Dim intLinea As Integer = 1
                Dim num As Integer = 0


                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("NumDespacho") & "|"
                    strFila &= REA.GetDecimal("cantidad") & "|"
                    If num = 0 Then
                        dblSaldo = REA.GetDouble("inicial")
                    End If

                    If intLinea = REA.GetInt32("linea") Then
                        dblSaldo = dblSaldo - REA.GetDouble("cantidad")
                        num = 1

                    Else

                        dblSaldo = REA.GetDouble("inicial")
                        dblSaldo = dblSaldo - REA.GetDouble("cantidad")
                        intLinea = REA.GetDouble("linea")
                    End If

                    strFila &= dblSaldo
                    cFunciones.AgregarFila(dgDetalle2, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
#Region "Eventos"
    Private Sub frmPedidoFibra_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpInicio.Value = dtpInicio.Value.AddMonths(NO_FILA)
        dtpFinal.Value = Today
        MostrarLista()
        Accessos()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Encabezado1.botonGuardar.Enabled = True
        Me.Tag = "Nuevo"
        Dim intNumero As Integer
        Dim intAño As Integer

        If logInsertar = True Then
            LimpiarPanelOrden()
            celdaTC.Text = cFunciones.QueryTasa("CURDATE()")
            MostrarLista(False, True)

            celdaAño.Text = cFunciones.AñoMySQL
            celdaNumero.Text = -1
            celdaNumero.Enabled = True
            intNumero = celdaAño.Text
            intAño = celdaAño.Text
            celdaAño.Text = cFunciones.AñoMySQL
            celdaComentario.Text = 0

            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaMoneda.Text = "US$"
            celdaIDMoneda.Text = 178
            celdaCatalogo.Text = 941
            celdaUsuario.Text = Sesion.Usuario

            celdaAño.Enabled = True
            celdaNumero.Enabled = True

            celdaRevisado.Text = 0
            checkActivo.Checked = True
            etiquetaAnulada.Visible = False

        Else
            MsgBox("You do not have access to create a new instruction", vbInformation)
        End If

    End Sub

    Private Sub BotonCliente_Click(sender As Object, e As EventArgs) Handles BotonCliente.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Client"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "cli_codigo code,cli_cliente Client, cli_direccion Direction, cli_telefono Phone, cli_nit NIT"
        frm.Tabla = "Clientes"
        frm.Condicion = strCondicion
        frm.Ordenamiento = "cli_cliente < 0"
        frm.Filtro = "cli_cliente"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
            celdaDireccion.Text = frm.Dato2
            celdaNit.Text = frm.Dato4
        End If
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            Else
                Exit Sub
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            celdaTC.Text = Cambio


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim conec As MySqlConnection
            Dim strSQL As String = STR_VACIO
            Dim Codigo As Integer

            'strVal = dgDetalle.SelectedCells(0).Value
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 13
                    Try
                        Dim Calendar As New frmDateTimePicker
                        Calendar.ShowDialog(Me)
                        If Calendar.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.SelectedCells(13).Value = Calendar.LLave
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
            End Select
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
    Private Sub botonAdd_Click(sender As Object, e As EventArgs) Handles botonAdd.Click
        Dim frm As New frmSeleccionar
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strCondicion As String = STR_VACIO
        Dim fila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim Codigo As Integer
        Dim strFila As String



        strCondicion = " pr.prf_sisemp = {empresa} AND pr.prf_status = 'Activo'"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)


        frm.Titulo = "List of Product"
        frm.FiltroText = "Enter the name Product"
        frm.Campos = " pr.prf_numero Numero,m.cat_num idMedida , m.cat_clave Medida , pr.prf_descripcion Descripcion"
        frm.Tabla = "Producto_Fibra pr LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = pr.prf_UM "
        frm.Condicion = strCondicion
        frm.Ordenamiento = "prf_numero "
        frm.TipoOrdenamiento = "ASC"
        frm.Filtro = " prf_descripcion"

        Try
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strFila = 941 & "|" & cfun.AñoMySQL & "|" & frm.LLave & "|" & frm.Dato3 & "|" & frm.Dato & "|" & frm.Dato2 & "|" & "|" & 0.0 & "|" & cFunciones.HoyMySQL & "|" & 0.0 & "|" & 0.0 & "|" & 0 & "|" & " " & "|" & " " & "|" & 0 & "|" & " "
                cFunciones.AgregarFila(dgDetalle, strFila)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim Cantidad As Double
        Dim Precio As Double
        Dim Total As Double

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 7

                Precio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value

                Total = (dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colCantidad").Value)

                dgDetalle.CurrentRow.Cells("colTotal").Value = Total
                CalcularTotales()
                'celdaTotales2.Text = Total.ToString(FORMATO_MONEDA)
                'celdaTotales.Text = Cantidad.ToString(FORMATO_MONEDA)
            Case 9
                Precio = dgDetalle.CurrentRow.Cells("colprecio").Value
                Cantidad = dgDetalle.CurrentRow.Cells("colcantidad").Value

                Total = (dgDetalle.CurrentRow.Cells("colprecio").Value * dgDetalle.CurrentRow.Cells("colcantidad").Value)

                dgDetalle.CurrentRow.Cells("coltotal").Value = Total
                CalcularTotales()
                'celdaTotales2.Text = Total.ToString(FORMATO_MONEDA)
                'celdaTotales.Text = Cantidad.ToString(FORMATO_MONEDA)
                'Try
                '    If ((dgDetalle.Focused & (dgDetalle.CurrentCell.ColumnIndex = 19))) Then
                '        dgDetalle.CurrentCell.Value = dtpDetalle.Value.Date
                '    End If
                'Catch ex As Exception
                '    MsgBox(ex.ToString)
                'End Try
        End Select
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Encabezado1.botonGuardar.Enabled = False
        Try
            If logInsertar = True Then
                If Me.Tag = "Nuevo" Then
                    If ComprobarDatos() Then
                        celdaNumero.Text = NuevaFactura()
                        GuardarDocumento()
                        GuardarDetalle()
                        cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 941, celdaAño.Text, celdaNumero.Text)
                        MsgBox("The document has been saved.")
                        MostrarLista(True)
                    End If
                Else
                    If logEditar = True Then
                        If checkActivo.Checked = False Then
                            If VerificarSiTieneDespacho() = 0 Then
                                MsgBox(" Proforma Invoice has deliveries already, therefore, we cannot cancel it ")
                                Exit Sub
                            End If
                        End If
                        If ComprobarDatos() Then
                            GuardarDocumento()
                            GuardarDetalle()
                            BorrarLineDetalle(celdaNumero.Text, 941)
                            cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 941, celdaAño.Text, celdaNumero.Text)
                            MsgBox("The document has been saved.")
                            MostrarLista(True)
                        End If
                    Else
                        MsgBox("You do not have permission Reload this Proforma")
                    End If
                End If
            Else
                MsgBox("You do not have permission to create a new proforma")
            End If
            Encabezado1.botonGuardar.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonDelete_Click(sender As Object, e As EventArgs) Handles botonDelete.Click
        If dgDetalle.SelectedRows.Count = 0 Then Exit Sub
        Try
            'Dim strFila As String
            If dgDetalle.CurrentRow.Cells(14).Value = 0 Then
                dgDetalle.SelectedCells(14).Value = 2
                dgDetalle.CurrentRow.Visible = False
            Else
                dgDetalle.SelectedCells(14).Value = 2
                dgDetalle.CurrentRow.Visible = False
            End If
        Catch ex As Exception
            '    MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Try
            If LogBorrar = True Then

                If VerificarDependenciaInstruccion() > 0 Then
                Else
                    If MsgBox("Are you sure you want to remove this document?", vbYesNo, "Question") = vbYes Then
                        EliminarEncabezado()
                        EliminarDetalle()
                        cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIDCliente.Text, 941, celdaAño.Text, celdaNumero.Text)
                        MsgBox("Document successfully deleted", vbInformation)
                        MostrarLista(True)
                    Else
                        Exit Sub
                    End If
                End If
            Else
                MsgBox("You do not have permissions to perform this action", vbInformation)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Encabezado1.botonGuardar.Enabled = True
        Dim intNumero As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Dim strSQL2 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim conec2 As MySqlConnection
        Dim Contrato As Integer

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"

            intNumero = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(5).Value
            LimpiarPanelOrden()
            queryEncabezado(intNumero, intAño)
            queryDetalleDown(intNumero, intAño)
            queryDetalle2(intNumero, intAño)
            'CargarReferencias(intAño, intNumero)

            'botonBuscar.Enabled = False
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            CalcularTotales()
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                If SqlDescargos(dgDetalle.Rows(i).Cells("colLineaDet").Value) > 0 Then

                    dgDetalle.Rows(i).Cells("colPrecio").ReadOnly = True
                    dgDetalle.Rows(i).Cells("colDescripcion").ReadOnly = True
                    dgDetalle.Rows(i).Cells("colPrecio").Style.BackColor = Color.Cyan
                    dgDetalle.Rows(i).Cells("colDescripcion").Style.BackColor = Color.Cyan
                Else
                    dgDetalle.Rows(i).Cells("colPrecio").ReadOnly = False
                    dgDetalle.Rows(i).Cells("colDescripcion").ReadOnly = False
                End If
            Next

            'Verifica si ya hay descargos para bloquear o desbloquear el boton del cliente
            If SqlDescargos() > 0 Then
                'Bloquea campos pues con una linea que tenga descargo ya no se puede modificar nada
                BotonCliente.Enabled = False
                celdaCliente.Enabled = False
                celdaDireccion.Enabled = False
            Else
                'Habilita campos si las lineas no tienen ningun descargo esto a solicitud de Nancy Gonzalez
                BotonCliente.Enabled = True
                celdaCliente.Enabled = True
                celdaDireccion.Enabled = True
            End If
            '    For i As Integer = 0 To dgDetalle.Rows.Count - 1
            '   If dgDetalle.Rows(i).Cells("colNumMedida").Value = 70 Then
            '  dgDetalle.Rows(i).Cells("colMedida").Style.BackColor = Color.Red
            ' Else
            'dgDetalle.Rows(i).Cells("colMedida").Style.BackColor = Color.White
            'End If
            'Next
            'For i As Integer = 0 To dgReferencias.Rows.Count - 1
            '    For j = 0 To dgDetalle.Rows.Count - 1
            '        If dgReferencias.Rows(i).Cells("colDescargo").Value > 0 And
            '            dgDetalle.Rows(j).Cells("colYear").Value = dgReferencias.Rows(i).Cells("colAnio").Value And
            '            dgDetalle.Rows(j).Cells("colLineaDet").Value = dgReferencias.Rows(i).Cells("colLine").Value Then

            '            dgDetalle.Rows(j).Cells("colDescargos").Value = 1
            '        End If
            '    Next
            'Next
            MostrarLista(False)
            'If celdaNumero.Text = "" Then
            '    BotonCliente.Enabled = True
            '    botonSolicitante.Enabled = True
            'Else
            '    BotonCliente.Enabled = False
            '    botonSolicitante.Enabled = False
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
        Else
            MostrarLista()
            LimpiarPanelOrden()
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(941, dgLista.SelectedCells(5).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(5).Value, 941)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub frmPedidoFibra_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        queryListaPrincipal()
    End Sub
    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "pro_sisemp = {empresa} AND pro_fabricante = 'NO'"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Provider"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "pro_codigo code,pro_proveedor Provider, pro_direccion Direction"
        frm.Tabla = "Proveedores"
        frm.Condicion = strCondicion
        frm.Filtro = "pro_proveedor"
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaidProveedor.Text = frm.LLave
            celdaProveedor.Text = frm.Dato
            celdaDireccionProveedor.Text = frm.Dato2
        End If
    End Sub
    Private Sub botonFabricante_Click(sender As Object, e As EventArgs) Handles botonFabricante.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "pro_sisemp = {empresa} AND pro_fabricante = 'SI'"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Provider"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "pro_codigo code,pro_proveedor Provider, pro_direccion Direction"
        frm.Tabla = "Proveedores"
        frm.Condicion = strCondicion
        frm.Filtro = "pro_proveedor"
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaidFabricante.Text = frm.LLave
            celdaFabricante.Text = frm.Dato
            celdaDireccionFabricante.Text = frm.Dato2
        End If
    End Sub
#End Region
End Class