﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmDescargoConsumibles
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDescargoConsumibles))
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.checkOtraPlanta = New System.Windows.Forms.CheckBox()
        Me.celdaArea = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaIDCosto = New System.Windows.Forms.Label()
        Me.botonCCostos = New System.Windows.Forms.Button()
        Me.checkCuenta = New System.Windows.Forms.CheckBox()
        Me.botonPoliza = New System.Windows.Forms.Button()
        Me.celdaNumeroAutorizado = New System.Windows.Forms.TextBox()
        Me.celdaDepartamento = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTCantidad = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodDepartamento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDepartamento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodMaquina = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionMaquina = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colModelo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Saldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Cta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_NombreCta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_TC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidreserva = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCancelado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBotones.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Controls.Add(Me.PanelBotones)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 184)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(513, 163)
        Me.PanelDetalle.TabIndex = 6
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colProducto, Me.colIdMedida, Me.colLinea, Me.colMedida, Me.colCodDepartamento, Me.colDepartamento, Me.colCodMaquina, Me.colDescripcionMaquina, Me.colMarca, Me.colModelo, Me.colSerie, Me.col_Saldo, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colExtra, Me.col_Cta, Me.col_NombreCta, Me.col_TC, Me.colArea, Me.colidreserva, Me.colCancelado})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(471, 163)
        Me.dgDetalle.TabIndex = 0
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.botonEliminar)
        Me.PanelBotones.Controls.Add(Me.botonAgregar)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(471, 0)
        Me.PanelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(42, 163)
        Me.PanelBotones.TabIndex = 4
        '
        'botonEliminar
        '
        Me.botonEliminar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEliminar.BackColor = System.Drawing.SystemColors.Control
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(5, 44)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(31, 28)
        Me.botonEliminar.TabIndex = 12
        Me.botonEliminar.UseVisualStyleBackColor = False
        '
        'botonAgregar
        '
        Me.botonAgregar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregar.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(4, 8)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregar.TabIndex = 11
        Me.botonAgregar.UseVisualStyleBackColor = False
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.GroupBox1)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(513, 184)
        Me.panelEncabezado.TabIndex = 7
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.checkOtraPlanta)
        Me.GroupBox1.Controls.Add(Me.celdaArea)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.celdaIDCosto)
        Me.GroupBox1.Controls.Add(Me.botonCCostos)
        Me.GroupBox1.Controls.Add(Me.checkCuenta)
        Me.GroupBox1.Controls.Add(Me.botonPoliza)
        Me.GroupBox1.Controls.Add(Me.celdaNumeroAutorizado)
        Me.GroupBox1.Controls.Add(Me.celdaDepartamento)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.celdaNombre)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.celdaNumero)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.checkActive)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(542, 184)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document Data"
        '
        'checkOtraPlanta
        '
        Me.checkOtraPlanta.AutoSize = True
        Me.checkOtraPlanta.Location = New System.Drawing.Point(333, 29)
        Me.checkOtraPlanta.Margin = New System.Windows.Forms.Padding(2)
        Me.checkOtraPlanta.Name = "checkOtraPlanta"
        Me.checkOtraPlanta.Size = New System.Drawing.Size(145, 17)
        Me.checkOtraPlanta.TabIndex = 32
        Me.checkOtraPlanta.Text = "Dispatch to another plant"
        Me.checkOtraPlanta.UseVisualStyleBackColor = True
        '
        'celdaArea
        '
        Me.celdaArea.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaArea.Location = New System.Drawing.Point(76, 154)
        Me.celdaArea.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaArea.Name = "celdaArea"
        Me.celdaArea.Size = New System.Drawing.Size(296, 20)
        Me.celdaArea.TabIndex = 31
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 156)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 13)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Area"
        '
        'celdaIDCosto
        '
        Me.celdaIDCosto.AutoSize = True
        Me.celdaIDCosto.Location = New System.Drawing.Point(413, 151)
        Me.celdaIDCosto.Name = "celdaIDCosto"
        Me.celdaIDCosto.Size = New System.Drawing.Size(16, 13)
        Me.celdaIDCosto.TabIndex = 29
        Me.celdaIDCosto.Text = "-1"
        Me.celdaIDCosto.Visible = False
        '
        'botonCCostos
        '
        Me.botonCCostos.Location = New System.Drawing.Point(376, 118)
        Me.botonCCostos.Name = "botonCCostos"
        Me.botonCCostos.Size = New System.Drawing.Size(25, 22)
        Me.botonCCostos.TabIndex = 28
        Me.botonCCostos.Text = "..."
        Me.botonCCostos.UseVisualStyleBackColor = True
        '
        'checkCuenta
        '
        Me.checkCuenta.AutoSize = True
        Me.checkCuenta.Enabled = False
        Me.checkCuenta.Location = New System.Drawing.Point(253, 30)
        Me.checkCuenta.Margin = New System.Windows.Forms.Padding(2)
        Me.checkCuenta.Name = "checkCuenta"
        Me.checkCuenta.Size = New System.Drawing.Size(66, 17)
        Me.checkCuenta.TabIndex = 27
        Me.checkCuenta.Text = "Account"
        Me.checkCuenta.UseVisualStyleBackColor = True
        '
        'botonPoliza
        '
        Me.botonPoliza.Image = CType(resources.GetObject("botonPoliza.Image"), System.Drawing.Image)
        Me.botonPoliza.Location = New System.Drawing.Point(457, 150)
        Me.botonPoliza.Margin = New System.Windows.Forms.Padding(2)
        Me.botonPoliza.Name = "botonPoliza"
        Me.botonPoliza.Size = New System.Drawing.Size(27, 24)
        Me.botonPoliza.TabIndex = 26
        Me.botonPoliza.UseVisualStyleBackColor = True
        '
        'celdaNumeroAutorizado
        '
        Me.celdaNumeroAutorizado.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumeroAutorizado.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumeroAutorizado.Location = New System.Drawing.Point(76, 54)
        Me.celdaNumeroAutorizado.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroAutorizado.Name = "celdaNumeroAutorizado"
        Me.celdaNumeroAutorizado.Size = New System.Drawing.Size(80, 19)
        Me.celdaNumeroAutorizado.TabIndex = 25
        Me.celdaNumeroAutorizado.Text = "-1"
        '
        'celdaDepartamento
        '
        Me.celdaDepartamento.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDepartamento.Location = New System.Drawing.Point(76, 120)
        Me.celdaDepartamento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDepartamento.Name = "celdaDepartamento"
        Me.celdaDepartamento.Size = New System.Drawing.Size(296, 20)
        Me.celdaDepartamento.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 123)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Cost Center"
        '
        'celdaNombre
        '
        Me.celdaNombre.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNombre.Location = New System.Drawing.Point(76, 92)
        Me.celdaNombre.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(296, 20)
        Me.celdaNombre.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 94)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Name"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(253, 60)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(117, 20)
        Me.dtpFecha.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(216, 63)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNumero.Location = New System.Drawing.Point(154, 8)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(82, 20)
        Me.celdaNumero.TabIndex = 4
        Me.celdaNumero.Text = "-1"
        Me.celdaNumero.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 58)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Number"
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(253, 10)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 2
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaAño.Location = New System.Drawing.Point(76, 28)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(80, 20)
        Me.celdaAño.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Year"
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.Panel1)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(9, 155)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(513, 408)
        Me.panelDocumento.TabIndex = 8
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.celdaTotal)
        Me.Panel1.Controls.Add(Me.celdaTCantidad)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 347)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(513, 61)
        Me.Panel1.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(293, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Monetary Total"
        '
        'celdaTotal
        '
        Me.celdaTotal.Enabled = False
        Me.celdaTotal.Location = New System.Drawing.Point(372, 18)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(67, 20)
        Me.celdaTotal.TabIndex = 16
        '
        'celdaTCantidad
        '
        Me.celdaTCantidad.Enabled = False
        Me.celdaTCantidad.Location = New System.Drawing.Point(232, 18)
        Me.celdaTCantidad.Name = "celdaTCantidad"
        Me.celdaTCantidad.Size = New System.Drawing.Size(55, 20)
        Me.celdaTCantidad.TabIndex = 15
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(156, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Total Quantity"
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Location = New System.Drawing.Point(9, 86)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(513, 65)
        Me.PanelLista.TabIndex = 9
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colNumeroSerie, Me.colFecha, Me.colNombre, Me.colReferencia})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 38)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(513, 27)
        Me.dgLista.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Width = 67
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Visible = False
        Me.colNumero.Width = 87
        '
        'colNumeroSerie
        '
        Me.colNumeroSerie.HeaderText = "Number*"
        Me.colNumeroSerie.Name = "colNumeroSerie"
        Me.colNumeroSerie.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 60
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Visible = False
        Me.colReferencia.Width = 103
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(513, 38)
        Me.panelFiltro.TabIndex = 3
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(457, 6)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(206, 9)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(2)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(54, 45)
        Me.botonImprimir.TabIndex = 10
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 57)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(590, 24)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(590, 57)
        Me.Encabezado1.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 57
        '
        'colProducto
        '
        Me.colProducto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colProducto.HeaderText = "Article"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        Me.colProducto.Width = 61
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "IdMedida"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.ReadOnly = True
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 76
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 52
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colCodDepartamento
        '
        Me.colCodDepartamento.HeaderText = "Cod Department"
        Me.colCodDepartamento.Name = "colCodDepartamento"
        Me.colCodDepartamento.ReadOnly = True
        Me.colCodDepartamento.Visible = False
        Me.colCodDepartamento.Width = 109
        '
        'colDepartamento
        '
        Me.colDepartamento.HeaderText = "Department"
        Me.colDepartamento.Name = "colDepartamento"
        Me.colDepartamento.ReadOnly = True
        Me.colDepartamento.Width = 87
        '
        'colCodMaquina
        '
        Me.colCodMaquina.HeaderText = "CodMaquina"
        Me.colCodMaquina.Name = "colCodMaquina"
        Me.colCodMaquina.ReadOnly = True
        Me.colCodMaquina.Visible = False
        Me.colCodMaquina.Width = 92
        '
        'colDescripcionMaquina
        '
        Me.colDescripcionMaquina.HeaderText = "Machine Description"
        Me.colDescripcionMaquina.Name = "colDescripcionMaquina"
        Me.colDescripcionMaquina.ReadOnly = True
        Me.colDescripcionMaquina.Width = 118
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Brand"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Width = 60
        '
        'colModelo
        '
        Me.colModelo.HeaderText = "Model"
        Me.colModelo.Name = "colModelo"
        Me.colModelo.ReadOnly = True
        Me.colModelo.Width = 61
        '
        'colSerie
        '
        Me.colSerie.HeaderText = "Series"
        Me.colSerie.Name = "colSerie"
        Me.colSerie.ReadOnly = True
        Me.colSerie.Width = 61
        '
        'col_Saldo
        '
        Me.col_Saldo.HeaderText = "Balance"
        Me.col_Saldo.Name = "col_Saldo"
        Me.col_Saldo.ReadOnly = True
        Me.col_Saldo.Width = 71
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        Me.colExtra.Width = 56
        '
        'col_Cta
        '
        Me.col_Cta.HeaderText = "Account"
        Me.col_Cta.Name = "col_Cta"
        Me.col_Cta.ReadOnly = True
        Me.col_Cta.Width = 72
        '
        'col_NombreCta
        '
        Me.col_NombreCta.HeaderText = "Account Name"
        Me.col_NombreCta.Name = "col_NombreCta"
        Me.col_NombreCta.ReadOnly = True
        Me.col_NombreCta.Width = 95
        '
        'col_TC
        '
        Me.col_TC.HeaderText = "TC"
        Me.col_TC.Name = "col_TC"
        Me.col_TC.ReadOnly = True
        Me.col_TC.Width = 46
        '
        'colArea
        '
        Me.colArea.HeaderText = "Area"
        Me.colArea.Name = "colArea"
        Me.colArea.Visible = False
        Me.colArea.Width = 54
        '
        'colidreserva
        '
        Me.colidreserva.HeaderText = "colidreserva"
        Me.colidreserva.Name = "colidreserva"
        Me.colidreserva.ReadOnly = True
        Me.colidreserva.Visible = False
        Me.colidreserva.Width = 89
        '
        'colCancelado
        '
        Me.colCancelado.HeaderText = "canceled"
        Me.colCancelado.Name = "colCancelado"
        Me.colCancelado.Width = 76
        '
        'frmDescargoConsumibles
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(590, 582)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmDescargoConsumibles"
        Me.Text = "frmDescargoConsumibles"
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBotones.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaNumeroAutorizado As TextBox
    Friend WithEvents celdaDepartamento As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroSerie As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents botonImprimir As Button
    Friend WithEvents botonPoliza As Button
    Friend WithEvents checkCuenta As System.Windows.Forms.CheckBox
    Friend WithEvents botonCCostos As Button
    Friend WithEvents celdaIDCosto As Label
    Friend WithEvents celdaArea As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaTCantidad As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents checkOtraPlanta As System.Windows.Forms.CheckBox
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colCodDepartamento As DataGridViewTextBoxColumn
    Friend WithEvents colDepartamento As DataGridViewTextBoxColumn
    Friend WithEvents colCodMaquina As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionMaquina As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents colModelo As DataGridViewTextBoxColumn
    Friend WithEvents colSerie As DataGridViewTextBoxColumn
    Friend WithEvents col_Saldo As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents col_Cta As DataGridViewTextBoxColumn
    Friend WithEvents col_NombreCta As DataGridViewTextBoxColumn
    Friend WithEvents col_TC As DataGridViewTextBoxColumn
    Friend WithEvents colArea As DataGridViewTextBoxColumn
    Friend WithEvents colidreserva As DataGridViewTextBoxColumn
    Friend WithEvents colCancelado As DataGridViewTextBoxColumn
End Class
