﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEstimacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.gbFase2 = New System.Windows.Forms.GroupBox()
        Me.dgEstimacionF2 = New System.Windows.Forms.DataGridView()
        Me.gbFase1 = New System.Windows.Forms.GroupBox()
        Me.dgEstimacionF1 = New System.Windows.Forms.DataGridView()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.etiquetaEstado = New System.Windows.Forms.Label()
        Me.celdaEstado = New System.Windows.Forms.TextBox()
        Me.celdaFecha = New System.Windows.Forms.TextBox()
        Me.celdaObservacion = New System.Windows.Forms.TextBox()
        Me.etiquetaObservaciones = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaCapacidad = New System.Windows.Forms.TextBox()
        Me.etiquetaCapacidad = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Usuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoF1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaF1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacionF1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstimacionF1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigoF2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaF2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClasificacionF2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstimacionF2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.gbFase2.SuspendLayout()
        CType(Me.dgEstimacionF2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbFase1.SuspendLayout()
        CType(Me.dgEstimacionF1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFechas)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 110)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(1108, 90)
        Me.panelListaPrincipal.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFecha, Me.colObservation, Me.col_Usuario, Me.colAnio})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 42)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1108, 48)
        Me.dgLista.TabIndex = 1
        '
        'panelFechas
        '
        Me.panelFechas.Controls.Add(Me.botonActualizar)
        Me.panelFechas.Controls.Add(Me.dtpFin)
        Me.panelFechas.Controls.Add(Me.etiquetaFin)
        Me.panelFechas.Controls.Add(Me.dtpInicio)
        Me.panelFechas.Controls.Add(Me.checkFecha)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(1108, 42)
        Me.panelFechas.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(577, 7)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(4)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(100, 28)
        Me.botonActualizar.TabIndex = 10
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(430, 9)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(113, 22)
        Me.dtpFin.TabIndex = 9
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(356, 13)
        Me.etiquetaFin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(66, 17)
        Me.etiquetaFin.TabIndex = 8
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(238, 8)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(112, 22)
        Me.dtpInicio.TabIndex = 7
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(4, 13)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(4)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(224, 21)
        Me.checkFecha.TabIndex = 6
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.gbFase2)
        Me.panelDetalle.Controls.Add(Me.gbFase1)
        Me.panelDetalle.Controls.Add(Me.panelEncabezado)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle.Location = New System.Drawing.Point(0, 200)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1108, 603)
        Me.panelDetalle.TabIndex = 3
        '
        'gbFase2
        '
        Me.gbFase2.Controls.Add(Me.dgEstimacionF2)
        Me.gbFase2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbFase2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!)
        Me.gbFase2.Location = New System.Drawing.Point(866, 159)
        Me.gbFase2.Name = "gbFase2"
        Me.gbFase2.Size = New System.Drawing.Size(242, 444)
        Me.gbFase2.TabIndex = 4
        Me.gbFase2.TabStop = False
        Me.gbFase2.Text = "Estimates Phase 2"
        '
        'dgEstimacionF2
        '
        Me.dgEstimacionF2.AllowUserToAddRows = False
        Me.dgEstimacionF2.AllowUserToDeleteRows = False
        Me.dgEstimacionF2.AllowUserToOrderColumns = True
        Me.dgEstimacionF2.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgEstimacionF2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgEstimacionF2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigoF2, Me.colLineaF2, Me.colClasificacionF2, Me.colEstimacionF2})
        Me.dgEstimacionF2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgEstimacionF2.Location = New System.Drawing.Point(3, 18)
        Me.dgEstimacionF2.MultiSelect = False
        Me.dgEstimacionF2.Name = "dgEstimacionF2"
        Me.dgEstimacionF2.RowTemplate.Height = 24
        Me.dgEstimacionF2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgEstimacionF2.Size = New System.Drawing.Size(236, 423)
        Me.dgEstimacionF2.TabIndex = 4
        '
        'gbFase1
        '
        Me.gbFase1.Controls.Add(Me.dgEstimacionF1)
        Me.gbFase1.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbFase1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbFase1.Location = New System.Drawing.Point(0, 159)
        Me.gbFase1.Name = "gbFase1"
        Me.gbFase1.Size = New System.Drawing.Size(866, 444)
        Me.gbFase1.TabIndex = 3
        Me.gbFase1.TabStop = False
        Me.gbFase1.Text = "Estimates Phase 1"
        '
        'dgEstimacionF1
        '
        Me.dgEstimacionF1.AllowUserToAddRows = False
        Me.dgEstimacionF1.AllowUserToDeleteRows = False
        Me.dgEstimacionF1.AllowUserToOrderColumns = True
        Me.dgEstimacionF1.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgEstimacionF1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgEstimacionF1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigoF1, Me.colLineaF1, Me.colClasificacionF1, Me.colEstimacionF1})
        Me.dgEstimacionF1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgEstimacionF1.Location = New System.Drawing.Point(3, 18)
        Me.dgEstimacionF1.MultiSelect = False
        Me.dgEstimacionF1.Name = "dgEstimacionF1"
        Me.dgEstimacionF1.RowTemplate.Height = 24
        Me.dgEstimacionF1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgEstimacionF1.Size = New System.Drawing.Size(860, 423)
        Me.dgEstimacionF1.TabIndex = 4
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.etiquetaEstado)
        Me.panelEncabezado.Controls.Add(Me.celdaEstado)
        Me.panelEncabezado.Controls.Add(Me.celdaFecha)
        Me.panelEncabezado.Controls.Add(Me.celdaObservacion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaObservaciones)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.panelEncabezado.Controls.Add(Me.celdaAnio)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.panelEncabezado.Controls.Add(Me.celdaCapacidad)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCapacidad)
        Me.panelEncabezado.Controls.Add(Me.celdaTasa)
        Me.panelEncabezado.Controls.Add(Me.botonMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaIdMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaMoneda)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.panelEncabezado.Controls.Add(Me.celdaNumero)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.panelEncabezado.Controls.Add(Me.dtpFecha)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.ForeColor = System.Drawing.SystemColors.ControlText
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1108, 159)
        Me.panelEncabezado.TabIndex = 2
        '
        'etiquetaEstado
        '
        Me.etiquetaEstado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaEstado.AutoSize = True
        Me.etiquetaEstado.BackColor = System.Drawing.Color.YellowGreen
        Me.etiquetaEstado.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaEstado.ForeColor = System.Drawing.Color.White
        Me.etiquetaEstado.Location = New System.Drawing.Point(851, 10)
        Me.etiquetaEstado.Name = "etiquetaEstado"
        Me.etiquetaEstado.Size = New System.Drawing.Size(152, 20)
        Me.etiquetaEstado.TabIndex = 45
        Me.etiquetaEstado.Text = "active estimation"
        '
        'celdaEstado
        '
        Me.celdaEstado.Location = New System.Drawing.Point(4, 134)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.Size = New System.Drawing.Size(63, 22)
        Me.celdaEstado.TabIndex = 44
        Me.celdaEstado.Visible = False
        '
        'celdaFecha
        '
        Me.celdaFecha.Location = New System.Drawing.Point(207, 10)
        Me.celdaFecha.Name = "celdaFecha"
        Me.celdaFecha.Size = New System.Drawing.Size(63, 22)
        Me.celdaFecha.TabIndex = 43
        Me.celdaFecha.Visible = False
        '
        'celdaObservacion
        '
        Me.celdaObservacion.Location = New System.Drawing.Point(398, 92)
        Me.celdaObservacion.Multiline = True
        Me.celdaObservacion.Name = "celdaObservacion"
        Me.celdaObservacion.Size = New System.Drawing.Size(279, 51)
        Me.celdaObservacion.TabIndex = 42
        '
        'etiquetaObservaciones
        '
        Me.etiquetaObservaciones.AutoSize = True
        Me.etiquetaObservaciones.Location = New System.Drawing.Point(276, 92)
        Me.etiquetaObservaciones.Name = "etiquetaObservaciones"
        Me.etiquetaObservaciones.Size = New System.Drawing.Size(92, 17)
        Me.etiquetaObservaciones.TabIndex = 41
        Me.etiquetaObservaciones.Text = "Observations"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(276, 13)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 39
        Me.etiquetaAnio.Text = "Year"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(398, 10)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.Size = New System.Drawing.Size(100, 22)
        Me.celdaAnio.TabIndex = 40
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(276, 51)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(98, 17)
        Me.etiquetaTasa.TabIndex = 38
        Me.etiquetaTasa.Text = "exchange rate"
        '
        'celdaCapacidad
        '
        Me.celdaCapacidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCapacidad.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.celdaCapacidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCapacidad.ForeColor = System.Drawing.Color.DarkBlue
        Me.celdaCapacidad.Location = New System.Drawing.Point(855, 112)
        Me.celdaCapacidad.Multiline = True
        Me.celdaCapacidad.Name = "celdaCapacidad"
        Me.celdaCapacidad.Size = New System.Drawing.Size(153, 33)
        Me.celdaCapacidad.TabIndex = 1
        '
        'etiquetaCapacidad
        '
        Me.etiquetaCapacidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaCapacidad.AutoSize = True
        Me.etiquetaCapacidad.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCapacidad.ForeColor = System.Drawing.Color.DarkBlue
        Me.etiquetaCapacidad.Location = New System.Drawing.Point(851, 85)
        Me.etiquetaCapacidad.Name = "etiquetaCapacidad"
        Me.etiquetaCapacidad.Size = New System.Drawing.Size(212, 24)
        Me.etiquetaCapacidad.TabIndex = 0
        Me.etiquetaCapacidad.Text = "installed capacity (Lb)"
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(398, 48)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(100, 22)
        Me.celdaTasa.TabIndex = 37
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(164, 88)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(38, 25)
        Me.botonMoneda.TabIndex = 33
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(73, 134)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(63, 22)
        Me.celdaIdMoneda.TabIndex = 36
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(93, 89)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(61, 22)
        Me.celdaMoneda.TabIndex = 35
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(12, 92)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 34
        Me.etiquetaMoneda.Text = "Coin"
        '
        'celdaNumero
        '
        Me.celdaNumero.Enabled = False
        Me.celdaNumero.Location = New System.Drawing.Point(93, 48)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(109, 22)
        Me.celdaNumero.TabIndex = 3
        Me.celdaNumero.Text = "-1"
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(12, 51)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 2
        Me.etiquetaNumero.Text = "Number"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(93, 8)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(110, 22)
        Me.dtpFecha.TabIndex = 1
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(12, 13)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 0
        Me.etiquetaFecha.Text = "Date"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 73)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1108, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1108, 73)
        Me.Encabezado1.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colObservation
        '
        Me.colObservation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colObservation.HeaderText = "Description"
        Me.colObservation.Name = "colObservation"
        Me.colObservation.ReadOnly = True
        Me.colObservation.Width = 108
        '
        'col_Usuario
        '
        Me.col_Usuario.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.col_Usuario.HeaderText = "Created By"
        Me.col_Usuario.Name = "col_Usuario"
        Me.col_Usuario.ReadOnly = True
        Me.col_Usuario.Width = 107
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colCodigoF1
        '
        Me.colCodigoF1.HeaderText = "Code"
        Me.colCodigoF1.Name = "colCodigoF1"
        Me.colCodigoF1.Visible = False
        '
        'colLineaF1
        '
        Me.colLineaF1.HeaderText = "Line"
        Me.colLineaF1.Name = "colLineaF1"
        '
        'colClasificacionF1
        '
        Me.colClasificacionF1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClasificacionF1.HeaderText = "Classification"
        Me.colClasificacionF1.Name = "colClasificacionF1"
        Me.colClasificacionF1.Width = 119
        '
        'colEstimacionF1
        '
        Me.colEstimacionF1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEstimacionF1.HeaderText = "Estimate"
        Me.colEstimacionF1.Name = "colEstimacionF1"
        Me.colEstimacionF1.Width = 91
        '
        'colCodigoF2
        '
        Me.colCodigoF2.HeaderText = "Code"
        Me.colCodigoF2.Name = "colCodigoF2"
        Me.colCodigoF2.Visible = False
        '
        'colLineaF2
        '
        Me.colLineaF2.HeaderText = "Line"
        Me.colLineaF2.Name = "colLineaF2"
        '
        'colClasificacionF2
        '
        Me.colClasificacionF2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClasificacionF2.HeaderText = "Classification"
        Me.colClasificacionF2.Name = "colClasificacionF2"
        Me.colClasificacionF2.Width = 119
        '
        'colEstimacionF2
        '
        Me.colEstimacionF2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEstimacionF2.HeaderText = "Estimate"
        Me.colEstimacionF2.Name = "colEstimacionF2"
        Me.colEstimacionF2.Width = 91
        '
        'frmEstimacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1108, 803)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmEstimacion"
        Me.Text = "frmEstimacion"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.gbFase2.ResumeLayout(False)
        CType(Me.dgEstimacionF2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbFase1.ResumeLayout(False)
        CType(Me.dgEstimacionF1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents panelFechas As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents celdaCapacidad As TextBox
    Friend WithEvents etiquetaCapacidad As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents celdaEstado As TextBox
    Friend WithEvents celdaFecha As TextBox
    Friend WithEvents celdaObservacion As TextBox
    Friend WithEvents etiquetaObservaciones As Label
    Friend WithEvents gbFase2 As GroupBox
    Friend WithEvents dgEstimacionF2 As DataGridView
    Friend WithEvents gbFase1 As GroupBox
    Friend WithEvents dgEstimacionF1 As DataGridView
    Friend WithEvents etiquetaEstado As Label
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colObservation As DataGridViewTextBoxColumn
    Friend WithEvents col_Usuario As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoF2 As DataGridViewTextBoxColumn
    Friend WithEvents colLineaF2 As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacionF2 As DataGridViewTextBoxColumn
    Friend WithEvents colEstimacionF2 As DataGridViewTextBoxColumn
    Friend WithEvents colCodigoF1 As DataGridViewTextBoxColumn
    Friend WithEvents colLineaF1 As DataGridViewTextBoxColumn
    Friend WithEvents colClasificacionF1 As DataGridViewTextBoxColumn
    Friend WithEvents colEstimacionF1 As DataGridViewTextBoxColumn
End Class
