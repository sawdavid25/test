﻿Imports System.IO
Imports System.Xml
Public Class frmFacturacion

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim intCurDoc As Integer
    Dim cfun As New clsFunciones
    Dim Poliza As String = STR_VACIO
    Dim intPais As Integer

    Private strOrigen As String

    Private dblDocCantidad As Double
    Private dblDocTotal As Double

    Public Const INT_UNO As Integer = 1

    Private logImpuesto As Boolean
    Private logLibre As Boolean
    Private logAdded As Boolean
    Private logPrinted As Boolean
    Private logPrinting As Boolean


    Private intRefID As Integer
    Private intRefDias As Integer

    'Id medida y factor de conversión
    Private intLbs As Integer
    Private intKgs As Integer
    Private dblFactorLbs As Double
    Private dblFactorKgs As Double

    'Constantes
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Private Const CXC_NAME As String = "Factura"
    Private Const STR_TABLA As String = "Clientes"
    Private Const COL_ID As Byte = 21


    'variables de clientes
    Private strPaisCliente As String = STR_VACIO
    Private strNitCliente As String = STR_VACIO
    Private documentosAsociados As Integer = INT_CERO
    Private asociaciones As Integer = INT_CERO

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub FacturaSVFibra(ByVal strRespuesta As String)
        Dim strSQL As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim repCR As New FacturaSVFibra
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO
        Dim clsConta As New clsContabilidad
        Dim COM2 As New MySqlCommand

        strSQL = "SELECT d.DDoc_Prd_NET precio,d.DDoc_Prd_DSQ Descuento, d.DDoc_Prd_QTY cantidad, Round((d.DDoc_Prd_NET * d.DDoc_Prd_QTY),2) subtotal, c.cat_clave Medida, m.cat_clave Mon2, m.cat_ext Moneda, '{OPCION}' CIF, IFNULL(("
        strSQL &= "     SELECT hh.HDoc_DR1_Num"
        strSQL &= "         FROM Dcmtos_DTL_Pro p"
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pp.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pp.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pp.PDoc_Chi_Num = p.PDoc_Par_Num AND pp.PDoc_Chi_Lin = p.PDoc_Par_Lin AND pp.PDoc_Par_Cat = 47"
        strSQL &= "                 LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = pp.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat = pp.PDoc_Par_Cat AND hh.HDoc_Doc_Ano = pp.PDoc_Par_Ano AND hh.HDoc_Doc_Num = pp.PDoc_Par_Num"
        strSQL &= "                     WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strSQL &= "                          LIMIT 1),'-') referencia, i.inv_prodlote lote, a.art_codigo codProducto, d.DDoc_Prd_Des descripcion, a.art_DLarga, a.art_DCorta DCorta, o.cat_desc origen, Round(d.DDoc_RF2_Dbl,2) pbruto, d.DDoc_Prd_DSQ descuento, h.HDoc_Doc_Fec fecha,"
        strSQL &= "                             h.HDoc_Emp_Nom empresa, h.HDoc_Emp_Dir direccion, h.HDoc_Emp_NIT NIT, h.HDoc_Doc_Num numero, h.HDoc_DR1_Num pedido, IFNULL(cli.cli_plazoCR,0) dias, box.BDoc_Box_QTY bultos, ("
        strSQL &= "                                     SELECT GROUP_CONCAT(DISTINCT Concat(c.HDoc_Doc_Num, ':'), c.HDoc_DR1_Num SEPARATOR ',')"
        strSQL &= "                                          FROM Dcmtos_DTL_Pro aa"
        strSQL &= "                                             INNER JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = aa.PDoc_Sis_Emp AND b.PDoc_Chi_Ano = aa.PDoc_Par_Ano AND b.PDoc_Chi_Cat = aa.PDoc_Par_Cat AND b.PDoc_Chi_Num = aa.PDoc_Par_Num AND b.PDoc_Chi_Lin = aa.PDoc_Par_Lin AND b.PDoc_Par_Cat = 75"
        strSQL &= "                                                 INNER JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.HDoc_Doc_Ano = b.PDoc_Par_Ano AND c.HDoc_Doc_Cat = b.PDoc_Par_Cat AND c.HDoc_Doc_Num = b.PDoc_Par_Num"
        strSQL &= "                                                     WHERE aa.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND aa.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND aa.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND aa.PDoc_Chi_Num =h.HDoc_Doc_Num )pfS, d.DDoc_Prd_Fob brutos,d.DDoc_RF2_Txt TipoBulto "
        strSQL &= "                                                 FROM Dcmtos_HDR h"
        strSQL &= "                                             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQL &= "                                         LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod"
        strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM"
        strSQL &= "                                  LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon"
        strSQL &= "                             LEFT JOIN Dcmtos_DTL_Box box ON box.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND box.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND box.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND box.BDoc_Doc_Num = d.DDoc_Doc_Num AND box.BDoc_Doc_Lin = d.DDoc_Doc_Lin"
        strSQL &= "                          LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSQL &= "                     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strSQL &= "                   LEFT JOIN Catalogos o ON o.cat_num = i.inv_lugarfab"
        strSQL &= "                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {num}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ano}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{OPCION}", strRespuesta)

        If BuscarRegistrosDcmtos_HDR_SVFibra(strSQL) = True Then

        End If
        Try
            repCR.Load("C:\XML\DcmtosHDRsvFibra.xml")

            Dim frm3 As New frmReporteFactSV
            frm3.Reporte_A_VerSV = repCR
            frm3.ShowDialog(Me)

            My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRsvFibra.xml")

            impreso = dgLista.SelectedCells(6).Value
            'If impreso = 0 Then
            '    If frm3.DialogResult  = System.Windows.Forms.DialogResult.Cancel Then
            '        If MsgBox("The Document is printed correctly", MsgBoxStyle.YesNo, "Question") = vbYes Then
            '            imprimir = 1

            '            strSQL4 = "UPDATE Dcmtos_HDR h"
            '            strSQL4 &= "     SET h.HDoc_DR2_Cat = {impresion}"
            '            strSQL4 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

            '            strSQL4 = Replace(strSQL4, "{impresion}", imprimir)
            '            strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
            '            strSQL4 = Replace(strSQL4, "{anio}", celdaAﮔo.Text)
            '            strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

            '            'Ejecuta la instruccin
            '            MyCnn.CONECTAR = strConexion
            '            COM2 = New MySqlCommand(strSQL4, CON)
            '            COM2.ExecuteNonQuery()

            '            clsConta.GenerarPoliza(celdaTipo.Text, celdaAﮔo.Text, celdaNumero.Text)

            '        End If
            '    End If
            'End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Function BuscarRegistrosDcmtos_HDR_SVFibra(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRsvFibra.xml", XmlWriteMode.WriteSchema)
        End If

    End Function

    Private Sub BusquedaHDR(ByVal Consulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(Consulta, CON)
        adaptador.TableMappings.Add("Dcmtos_HDR1", "Dcmtos_HDR")
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")

        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then

            MsgBox("error")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDR.xml", XmlWriteMode.WriteSchema)
        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
            If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                botonPrevio.Visible = True
                etiquetaSerie.Visible = False
                etiquetaAutorizacion.Visible = False
            Else
                botonPrevio.Visible = False
            End If
            botonPrevio.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            botonPrevio.Enabled = True
            If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                botonPrevio.Visible = True
                etiquetaSerie.Visible = False
                etiquetaAutorizacion.Visible = False
            Else
                botonPrevio.Visible = False
            End If
        End If
    End Sub

    'Query que carga Lista Principal
    Private Function SQLlista() As String

        Dim strsql As String = STR_VACIO

        strsql = "  SELECT HDoc_Doc_Ano Year, HDoc_Doc_Num Num, IF(HDoc_DR1_Dbl >0, HDoc_DR1_Dbl, HDoc_Doc_Num) Numero, HDoc_Doc_Fec Fecha, HDoc_Emp_Nom Cliente, HDoc_DR1_Num Referencia, IFNULL(HDoc_DR2_Cat,0) Impreso, HDoc_Doc_Status, HDoc_Doc_Ano, CASE  WHEN  HDoc_DR1_Fec IS NULL  THEN  0  WHEN HDoc_DR1_Fec='0001-01-01' THEN 0  ELSE 1 END  Salida , "
        strsql &= "     IFNULL(HDoc_DR2_Emp,0) Impuesto, IF(ISNULL(HDoc_DR2_Fec),1,0) bloqueado, IFNULL(HDoc_RF2_Cod,0) Cargado, IFNULL(HDoc_RF1_Cod,0) Poliza, HDoc_Emp_Cod Code, HDoc_Emp_Dir Direction, HDoc_Emp_NIT NIT, HDoc_Emp_Tel Phone,HDoc_Doc_Mon, HDoc_Doc_TC, cat_clave, HDoc_RF1_Dbl, HDoc_RF2_Dbl , IFNULL(f.Serie,'') Serie , IFNULL(f.NumeroAutorizacion,'') Autorizacion    "
        strsql &= "         FROM Dcmtos_HDR"
        strsql &= "             LEFT JOIN Catalogos c ON cat_num = HDoc_Doc_Mon"
        strsql &= "                 LEFT JOIN Fel f ON f.Empresa = HDoc_Sis_Emp AND f.Catalogo = HDoc_Doc_Cat AND f.Anio = HDoc_Doc_Ano AND f.Numero = HDoc_Doc_Num  "
        strsql &= "  WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36"
        If checkFecha.Checked = True Then

            strsql &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strsql = Replace(strsql, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strsql = Replace(strsql, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strsql &= "  ORDER BY HDoc_Doc_Fec desc, HDoc_Doc_Num desc"
        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql

    End Function

    'Query que carga Subdocumentos
    Private Function SqlListaSudDocumentos(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT cat_clave, cat_desc, IF(("
        strsql &= "  SELECT COUNT(*) "
        strsql &= "    FROM Dcmtos_ACC"
        strsql &= "       WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 36 AND ADoc_Doc_Ano = {año} AND ADoc_Doc_Num ={numero} AND ADoc_Doc_Sub = cat_clave) >0,'SI','NO') Cantidad"
        strsql &= "     FROM Catalogos"
        strsql &= "   WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_CFactura' AND (cat_sisemp IN (0,{empresa}))"
        strsql &= " ORDER BY cat_clave"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    'Query que Carga las Instrucciones De Despacho
    Private Function SqlInstDespacho(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT DISTINCT HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec,HDoc_Usuario, HDoc_DR1_Num"
        strsql &= " FROM Dcmtos_DTL_Pro a"
        strsql &= "    INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num"
        strsql &= " WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Ano = {año} AND a.PDoc_Chi_Num = {numero} AND a.PDoc_Par_Cat = 48"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    Private Function sqlDetalle(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = "SELECT IFNULL(d.DDoc_Prd_PNr,'') loteNuevo, IFNULL(d.DDoc_Prd_Ref,'') cta, IFNULL(c.nombre,'') Nombre_Cta, IFNULL(p.PDoc_Par_Ano,0) Ano, IFNULL(p.PDoc_Par_Num,0) Numero,d.DDoc_Doc_Lin Linea2,IFNULL(p.PDoc_Par_Lin,0) Linea, IFNULL(p.PDoc_Chi_Lin,0) Lin2, 0 Id, d.DDoc_Prd_Cod Codigo, d.DDoc_Prd_Des Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte, d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, IFNULL(m.cat_num,0) NuMedida, IFNULL(m.cat_clave,'') Medida, IFNULL(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) Despacho, (IF(d.DDoc_RF3_Dbl=0,d.DDoc_Prd_QTY,d.DDoc_RF3_Dbl) * d.DDoc_Prd_NET) Total, IFNULL(d.DDoc_RF2_Cod,0) Distribucion, COALESCE(IFNULL(l.cli_cliente,'')) Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, IFNULL(d.DDoc_RF2_Txt,0) Bulto, IFNULL(d.DDoc_RF2_Num,0) Bobinas, d.DDoc_RF1_Dbl Libras, d.DDoc_RF2_Dbl Kilos, d.DDoc_Prd_UM Unidad, d.DDoc_Prd_QTY Cantidad, IFNULL(b.BDoc_Box_QTY,0) cantidadBulto,d.DDoc_Prd_DSP Porcentaje, d.DDoc_Prd_DSQ Descuento, IFNULL(d.DDoc_RF3_Txt,0) KGBrutos, IFNULL(d.DDoc_Prd_Fob, 0) KGNetos, d.DDoc_Prd_Cif PPF"
        strsql &= "  FROM Dcmtos_DTL d"
        strsql &= "    LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin"
        strsql &= "      LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strsql &= "        LEFT JOIN Clientes l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        strsql &= "              LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin
                                 LEFT JOIN {conta}.cuentas c ON c.empresa = d.DDoc_Sis_Emp AND c.id_cuenta = d.DDoc_Prd_Ref"
        strsql &= "      WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"
        strsql &= "    GROUP BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strsql &= "  ORDER BY d.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)
        strsql = Replace(strsql, "{conta}", Sesion.BaseConta)

        Return strsql
    End Function

    Private Function sqlCC(ByVal intaño As Integer, ByVal intnumero As Integer) As String

        Dim strsql As String = STR_VACIO

        strsql = " SELECT h.HDoc_Doc_Cat,0 status_, cat_num, cat_clave, ECta_Concepto, ECta_Sini_Loc, ECta_Crgo_Loc, ECta_Abno_Loc, ECta_Sini_Ext, ECta_Crgo_Ext, ECta_Abno_Ext, ECta_Doc_Lin, ECta_FecDcmt, ECta_FecVenc, ECta_moneda, ECta_TC, IFNULL(c.cli_cliente,'') Nombre, IFNULL(c.cli_codigo,0) Codigo, 'Clientes' Tipo, IFNULL(h.HDoc_RF2_Num,0) HDoc_RF2_Num, ifnull(c.cli_clasificacion,0) clasTipoFactura, IFNULL(c.cli_nit,'C/F') nitcliente
                        FROM ECtaCte e
                        LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = e.ECta_Sis_Emp AND h.HDoc_Doc_Cat = e.ECta_Ref_Cat AND h.HDoc_Doc_Ano = e.ECta_Ref_Ano AND h.HDoc_Doc_Num = e.ECta_Doc_Num
                        LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod
                        LEFT JOIN Catalogos t ON t.cat_num = e.ECta_moneda AND cat_clase = 'Monedas'
                            WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Ref_Cat = 36 AND e.ECta_Ref_Ano = {año} AND e.ECta_Ref_Num = {numero} AND e.ECta_Doc_Cat =36
                   UNION
                        SELECT d.HDoc_Doc_Cat, d.HDoc_Doc_Status status_, t.cat_num, t.cat_clave, ECta_Concepto, ECta_Sini_Loc, ECta_Crgo_Loc, ECta_Abno_Loc, ECta_Sini_Ext, ECta_Crgo_Ext, ECta_Abno_Ext, ECta_Doc_Lin, ECta_FecDcmt, ECta_FecVenc, ECta_moneda, ECta_TC, IF(e.ECta_Doc_Cat =36, IFNULL(c.cli_cliente,''), CONCAT(ifnull(l.cat_desc,''),' #',IF(not l.cat_num = 54 , d.HDoc_Doc_Num, d.HDoc_DR1_Num ))) Nombre, IFNULL(c.cli_codigo,0) Codigo, 'Clientes' Tipo, IFNULL(h.HDoc_RF2_Num,0) HDoc_RF2_Num, ifnull(c.cli_clasificacion,0) clasTipoFactura, IFNULL(c.cli_nit,'C/F') nitcliente
                            FROM ECtaCte e
                            LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = e.ECta_Sis_Emp AND h.HDoc_Doc_Cat = e.ECta_Ref_Cat AND h.HDoc_Doc_Ano = e.ECta_Ref_Ano AND h.HDoc_Doc_Num = e.ECta_Doc_Num
                            LEFT JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = e.ECta_Sis_Emp AND d.HDoc_Doc_Cat = e.ECta_Doc_Cat AND d.HDoc_Doc_Ano = e.ECta_Doc_Ano AND d.HDoc_Doc_Num = e.ECta_Doc_Num
                            LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod
                            LEFT JOIN Catalogos t ON t.cat_num = e.ECta_moneda AND t.cat_clase = 'Monedas'
                            LEFT JOIN Catalogos l ON l.cat_num = e.ECta_Doc_Cat AND l.cat_clase ='Documentos'
                                WHERE e.ECta_Sis_Emp = {empresa} And e.ECta_Ref_Cat = 36 And e.ECta_Ref_Ano = {año} And e.ECta_Ref_Num = {numero} AND NOT e.ECta_Doc_Cat =36 "

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)

        Return strsql
    End Function

    Private Function SQLMostrarInfoLPrincipal(ByVal intaño As Integer, ByVal intnumero As Integer)

        Dim strsql As String = STR_VACIO

        strsql = " SELECT d.DDoc_Doc_Lin Linea, a.art_DCorta Descripcion, d.DDoc_RF3_Dbl Cantidad, IFNULL(c.cat_clave,'N/A') Medida"
        strsql &= "     FROM Dcmtos_DTL d"
        strsql &= "      LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero= d.DDoc_Prd_Cod"
        strsql &= "     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strsql &= "    LEFT JOIN Catalogos c ON c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_RF3_Num"
        strsql &= "   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"
        strsql &= "  ORDER BY d.DDoc_Doc_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intaño)
        strsql = Replace(strsql, "{numero}", intnumero)
        Return strsql

    End Function

    'Carga el listado de referencias afectadas por las líneas del detalle
    Private Sub sqlCargarRelacion()

        Dim strsql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strTemp As String = STR_VACIO

        strsql = "SELECT b.HDoc_Doc_Cat Tipo, b.HDoc_Doc_Ano Ano, b.HDoc_Doc_Num Numero, b.HDoc_Doc_Fec Fecha, b.HDoc_DR1_Num Referencia, COALESCE(m.cat_clave,'') Medida, COALESCE(m.cat_num,0) Unidad, a.PDoc_Par_Lin Linea, a.PDoc_Prd_Cod Codigo, IFNULL(a.PDoc_QTY_Ord,0) Disponible, a.PDoc_QTY_Pro Descargo, d.DDoc_Prd_QTY Cantidad, a.PDoc_Chi_Lin ID, a.PDoc_Chi_Num Instruccion,  a.PDoc_Chi_Lin linea_Instruccion"
        strsql &= "     FROM Dcmtos_DTL_Pro a"
        strsql &= "      INNER JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = a.PDoc_Sis_Emp AND b.HDoc_Doc_Cat = a.PDoc_Par_Cat AND b.HDoc_Doc_Ano = a.PDoc_Par_Ano AND b.HDoc_Doc_Num = a.PDoc_Par_Num"
        strsql &= "     INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = a.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = a.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = a.PDoc_Chi_Ano AND d.DDoc_Doc_Num = a.PDoc_Chi_Num AND d.DDoc_Doc_Lin = a.PDoc_Chi_Lin"
        strsql &= "    LEFT JOIN Catalogos m ON m.cat_clase='Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strsql &= "   WHERE PDoc_Sis_Emp = {empresa} AND PDoc_Par_Cat = 47 AND PDoc_Chi_Cat = 48 AND PDoc_Chi_Ano = {año} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea}"
        strsql &= "  ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"
        'NOTAS: '48/Instrucciones' es child, y '47/Ingreso' es parent

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Try
            'dgReferencia.Rows.Clear()
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Dim strsql2 As String = strsql

                strsql2 = Replace(strsql2, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
                strsql2 = Replace(strsql2, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
                strsql2 = Replace(strsql2, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strsql2, CON)
                REA = COM.ExecuteReader

                If REA.HasRows Then

                    Do While REA.Read
                        Dim strFila As String = STR_VACIO
                        Dim ID As Integer
                        For j As Integer = 0 To dgDetalle.Rows.Count - 1
                            ID = i + 1
                        Next

                        strFila = ID & "|"
                        strFila &= REA.GetInt32("Tipo") & "|"
                        strFila &= REA.GetInt32("Ano") & "|"
                        strFila &= REA.GetInt32("Numero") & "|"
                        strFila &= REA.GetDateTime("Fecha") & "|"
                        strFila &= PolizaIngreso(REA.GetInt32("Ano"), REA.GetInt32("Numero")) & "|"
                        strFila &= REA.GetString("Referencia") & "|"
                        strFila &= REA.GetInt32("Linea") & "|"
                        strFila &= REA.GetInt32("linea_Instruccion") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        strFila &= REA.GetDouble("Disponible") & "|"
                        strFila &= REA.GetDouble("Descargo") & "|"
                        strFila &= vbEmpty & "|"
                        strFila &= vbNullString & "|"
                        strFila &= REA.GetDouble("Descargo") & "|"
                        strFila &= vbEmpty & "|"
                        strFila &= REA.GetInt32("Unidad") & "|"
                        strFila &= REA.GetString("Medida") & "|"
                        strFila &= REA.GetDouble("Cantidad") & "|"
                        strFila &= 2 & "|"
                        strFila &= REA.GetInt32("Instruccion")

                        cFunciones.AgregarFila(dgReferencia, strFila)

                    Loop
                    REA.Close()
                    REA = Nothing
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Devuelve la póliza para un documento de ingreso
    Private Function PolizaIngreso(ByVal Ano As String, ByVal Numero As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Try
            strSQL = "SELECT a.ADoc_Dta_Chr Poliza"
            strSQL &= " FROM Dcmtos_DTL_Pro p"
            strSQL &= "     INNER JOIN Catalogos c ON c.cat_num = p.PDoc_Par_Cat AND c.cat_clase = 'Documentos'"
            strSQL &= "          INNER JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp = p.PDoc_Sis_Emp AND a.ADoc_Doc_Cat = p.PDoc_Par_Cat AND a.ADoc_Doc_Ano = p.PDoc_Par_Ano AND a.ADoc_Doc_Num = p.PDoc_Par_Num"
            strSQL &= "      WHERE p.PDoc_Sis_Emp ={Empresa} AND p.PDoc_Chi_Cat =47 AND p.PDoc_Chi_Ano ={año} AND p.PDoc_Chi_Num ={Numero} AND c.cat_sist = 'Doc_ODesImp' AND a.ADoc_Doc_Lin = '01'"

            strSQL = Replace(strSQL, "{Empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", Ano)
            strSQL = Replace(strSQL, "{Numero}", Numero)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Poliza = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return Poliza
    End Function

    'Procedimiento para Cargar dgLista Panel Principal
    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Dim e As Integer
        Dim m As Integer
        Dim im As Integer
        Dim b As Integer
        Dim s As Integer
        Dim c As Integer
        Dim p As Integer
        'Dim Lista As DataGridView

        strSQL = SQLlista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then


                If (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 14 And Pais() = 327) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                    dgLista.Columns(15).Visible = False
                    dgLista.Columns(16).Visible = False
                Else
                    dgLista.Columns(15).Visible = True
                    dgLista.Columns(16).Visible = True
                End If

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Year") & "|"
                    strFila &= REA.GetInt32("Num") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("Cliente") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("impreso") & "|"
                    strFila &= REA.GetInt32("HDoc_Doc_Status") & "|"
                    strFila &= REA.GetInt32("Salida") & "|"
                    strFila &= REA.GetInt32("Impuesto") & "|"
                    strFila &= REA.GetInt32("bloqueado") & "|"
                    strFila &= REA.GetInt32("Cargado") & "|"
                    strFila &= REA.GetInt32("Poliza") & "|"
                    strFila &= REA.GetString("Direction") & "|"
                    strFila &= REA.GetString("NIT") & "|"
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    strFila &= arrayCadena(INT_CERO) & "|"
                    strFila &= REA.GetString("Autorizacion")
                    'strFila &= REA.GetString("Phone")


                    e = REA.GetInt32("HDoc_Doc_Status")
                    m = REA.GetInt32("impreso")
                    im = REA.GetInt32("Impuesto")
                    b = REA.GetInt32("bloqueado")
                    s = REA.GetInt32("Salida")
                    c = REA.GetInt32("Cargado")
                    p = REA.GetInt32("Poliza")
                    If REA.GetInt32("HDoc_Doc_Status") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        AgregarFila(dgLista, strFila, e, m, im, b, s, c, p)
                    End If


                Loop

            End If
            REA.Close()
            REA = Nothing
            COM = Nothing
            CON.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Pocedimiento propio de facturacion para agregar listado principal y colores de acuerdo al esta de cada fila
    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Estado As Integer, ByVal impreso As Integer, ByVal Impuesto As Integer, ByVal bloqueado As Integer, ByVal Salida As Integer, ByVal Cargado As Integer, ByVal Poliza As Integer)

        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Estado = vbEmpty Then
                    If i = 2 Then
                        Celda.Style.BackColor = Color.Red
                    End If
                    If i = 1 Then
                        Celda.Style.BackColor = Color.Red
                    End If
                Else
                    If impreso = vbEmpty Then
                        If Sesion.IdEmpresa = 12 And Pais() = 310 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Then
                            If i = 2 Then
                                Celda.Style.BackColor = Color.Yellow
                            End If
                        Else
                            If i = 1 Then
                                Celda.Style.BackColor = Color.Yellow
                            End If
                        End If

                    End If
                End If
                'Pendiente de Certificado de Origen
                If Impuesto = INT_UNO And bloqueado = INT_UNO Then
                    If i = 3 Then
                        Celda.Style.BackColor = Color.Magenta
                    End If
                ElseIf Salida = vbEmpty Then
                    'Pendiente de Salida
                    If i = 3 Then
                        Celda.Style.BackColor = Color.Orange
                    End If
                    If Cargado = vbEmpty Then
                        If i = 4 Then
                            Celda.Style.BackColor = Color.Cyan

                        End If
                    End If
                    If Poliza = INT_CERO Then
                        If i = 5 Then
                            Celda.Style.BackColor = Color.GreenYellow

                        End If
                    End If
                End If


                Fila.Cells.Add(Celda)

            Next

            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Query que carga las Instrucciones de Despacho
    Public Sub queryInstDespacho(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlInstDespacho(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgInstrucDespacho.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO


                    strFila = REA.GetInt32("HDoc_Doc_Cat") & "|" & REA.GetString("HDoc_Doc_Ano") & "|" & REA.GetInt32("HDoc_Doc_Num") & "|" & REA.GetDateTime("HDoc_Doc_Fec") & "|" & REA.GetString("HDoc_Usuario") & "|" & REA.GetString("HDoc_DR1_Num") & "|" & "0"


                    cFunciones.AgregarFila(dgInstrucDespacho, strFila)

                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'procedimiento que cargar SubDocumentos
    Public Sub SeleccionarSubdocumentos(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlListaSudDocumentos(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgSubdocumentos.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO


                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    strFila &= REA.GetString("Cantidad")

                    cFunciones.AgregarFila(dgSubdocumentos, strFila)

                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar dgDetalle 
    Public Sub queryDetalle(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim kgs

        strSQL = sqlDetalle(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO
                    strFila = REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    If celdaTipoFactura.Text >= 1 Then
                        strFila &= REA.GetInt32("Linea2") & "|"
                    Else
                        strFila &= REA.GetInt32("Lin2") & "|"
                    End If
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetInt32("NuMedida") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("Despacho") & "|"
                    strFila &= REA.GetDouble("Precio") & "|"
                    strFila &= REA.GetDouble("Porcentaje") & "|"
                    strFila &= REA.GetDouble("Descuento") & "|"
                    strFila &= REA.GetDouble("Despacho").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Total").ToString("###0.00") & "|"
                    strFila &= REA.GetInt32("cantidadBulto") & "|"
                    strFila &= REA.GetString("Bulto") & "|"
                    strFila &= REA.GetInt32("Bobinas") & "|"
                    strFila &= REA.GetString("Distribucion") & "|"
                    strFila &= REA.GetInt32("Destino") & "|"
                    strFila &= REA.GetString("Lugar") & "|"
                    strFila &= REA.GetDouble("Libras") & "|"
                    strFila &= REA.GetDouble("Kilos").ToString(FORMATO_MONEDA) & "|"
                    If REA.GetDouble("KGNetos") = 0 Then
                        Dim factor As Double
                        factor = (REA.GetDouble("Cantidad"))
                        strFila &= (factor / 2.2046).ToString(FORMATO_MONEDA) & "|"
                        strFila &= (factor / 2.2046).ToString(FORMATO_MONEDA_EXT) & "|"
                    ElseIf REA.GetDouble("KGNetos") = vbNullString Then
                        Dim factor As Double
                        factor = (REA.GetDouble("Cantidad"))
                        strFila &= (factor / 2.2046).ToString(FORMATO_MONEDA) & "|"
                        strFila &= (factor / 2.2046).ToString(FORMATO_MONEDA_EXT) & "|"
                    Else
                        strFila &= REA.GetDouble("KGnetos").ToString(FORMATO_MONEDA) & "|"
                        strFila &= REA.GetDouble("KGnetos").ToString(FORMATO_MONEDA_EXT) & "|"
                    End If
                    strFila &= REA.GetDouble("Original") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Base") & "|"
                    strFila &= REA.GetDouble("PPF") & "|"
                    If (Sesion.IdEmpresa = 18 And celdaTipoFactura.Text = INT_UNO) Or (Sesion.IdEmpresa = 21 And celdaTipoFactura.Text = INT_UNO) Or (Sesion.IdEmpresa = 19 And celdaTipoFactura.Text = INT_UNO) Then
                        strFila &= "0" & "|"
                        strFila &= REA.GetString("cta") & "|"
                        strFila &= REA.GetString("Nombre_Cta")
                    ElseIf Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                        strFila &= "0" & "|"
                        strFila &= REA.GetString("cta") & "|"
                        strFila &= REA.GetString("Nombre_Cta") & "|"
                        strFila &= REA.GetString("loteNuevo")

                    Else
                        strFila &= "0"
                    End If

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
                REA.Close()
                REA = Nothing

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar Cuentas por Cobrar
    Public Sub queryCC(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = sqlCC(intaño, intnumero)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDatos.Rows.Clear()
                asociaciones = 0

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetString("Nombre") & "|" & REA.GetDateTime("ECta_FecDcmt").ToString(FORMATO_MYSQL) & "|" & REA.GetString("ECta_Concepto") & "|" & REA.GetString("cat_clave") & "|" & REA.GetDouble("ECta_TC") & "|" & REA.GetDouble("ECta_Crgo_Ext") & "|" & "{abono}" & "|" & REA.GetInt32("HDoc_RF2_Num")


                    If Sesion.IdEmpresa = 9 Then
                        strFila = strFila.Replace("{abono}", REA.GetDouble("ECta_Abno_Loc"))
                    Else
                        strFila = strFila.Replace("{abono}", REA.GetDouble("ECta_Abno_Ext"))
                    End If

                    cFunciones.AgregarFila(dgDatos, strFila)

                    If REA.GetInt32("HDoc_Doc_Cat") = 36 Then
                        strPaisCliente = REA.GetString("clasTipoFactura")
                        strNitCliente = REA.GetString("nitCliente")
                    End If
                    If REA.GetInt32("status_") <> 0 Then
                        documentosAsociados += REA.GetInt32("status_")
                    End If

                    'se captura si la factura tiene documentos asociados
                    If REA.GetInt32("HDoc_Doc_Cat") <> 36 Then
                        asociaciones += 1
                    End If
                    'dgDatos..BackColor = Color.AntiqueWhite

                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    'Procedimiento para Cargar Informacion de CheckMuestra Detalle en Lista Principal (Parte Inferior)
    Public Sub queryCheckMuestraDetalle(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cone As New MySqlConnection
        cone.ConnectionString = strConexion
        cone.Open()

        Try
            strSQL = SQLMostrarInfoLPrincipal(intaño, intnumero)

            'MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, cone)
            REA = COM.ExecuteReader


            Do While REA.Read


                strFila &= vbNewLine & REA.GetInt32("Linea") & " )     " & REA.GetDouble("Cantidad") & "   " & REA.GetString("Medida") & " " & REA.GetString("Descripcion")

                'celdaInfoDetalle.Text = strFila
            Loop
            celdaInfoDetalle.Text = strFila
        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            cone.Close()
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Facturación")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            queryListaPrincipal()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = ""
            For i As Integer = 0 To Me.dgLista.Rows.Count - 1
                If Me.dgLista.Rows(i).Cells(6).Value = 0 Then
                    Me.dgLista.Rows(i).Cells(2).Style.BackColor = Color.Yellow
                End If
            Next

        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = "Mod"
                BloquearBotones(False)
                botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = False

                LimpiarPanelOrden()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Private Sub Seleccionar(ByVal intaño As Integer, ByVal intnumero As Integer)
        SeleccionarCliente(intaño, intnumero)

    End Sub

    'Limpia todos los campos y datagrid's del panel de Fcaturacion
    Public Sub LimpiarPanelOrden()
        celdaAño.Text = -1
        celdaNumero.Text = -1
        celdaTasa.Text = NO_FILA
        dtpFecha.Value = cfun.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaSerie.Text = STR_VACIO
        celdaIDSerie.Clear()
        celdaEmpresa.Text = NO_FILA
        celdaTipo.Text = NO_FILA
        celdaUsuario.Text = NO_FILA
        celdaDireccion.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaIdCliente.Text = NO_FILA

        celdaTelefono.Text = STR_VACIO
        celdaNIT.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIdMoneda.Text = NO_FILA
        celdaFlete.Text = INT_CERO
        celdaValidacionFlete.Text = INT_CERO
        celdaSeguro.Text = INT_CERO

        celdaTotal1.Text = 0
        celdaTotal2.Text = 0
        celdaSubDocumento.Text = 0
        celdaNum2.Text = 0
        celdaCargado.Text = 0
        celdaSalida.Text = " "
        celdaPoliza.Text = 0
        celdaImpreso.Text = 0
        dgDetalle.Rows.Clear()
        dgDatos.Rows.Clear()
        dgInstrucDespacho.Rows.Clear()
        dgSubdocumentos.Rows.Clear()
        dgReferencia.Rows.Clear()
        logImpuesto = False
        logLibre = True
        etiquetaAnulada.Visible = False
        checkActivar.Checked = False
        'celdaTasa.Text = STR_VACIO
        'celdaKGBrutos.Text = STR_VACIO
        'Fel 
        celdaUUID.Text = STR_VACIO
        celdaFechaEmisionDocumento.Text = STR_VACIO
        celdaFechaHoraCertificacion.Text = STR_VACIO
        celdaSerieFel.Text = STR_VACIO
        etiquetaSerie.Text = STR_VACIO
        etiquetaAutorizacion.Text = STR_VACIO
        celdaSerieFelServi.Clear()
        celdaNumeroFel.Clear()
        celdaGranTotal.Clear()
        rbExportacion.Checked = False
        rbNacionalizacion.Checked = False
        If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 2) Then
            celdaTipoFactura.Text = NO_FILA
        Else
            celdaTipoFactura.Text = INT_CERO
        End If
        checkDestino.Checked = False
    End Sub
    Public Sub ocultarDetalle()
        dgDetalle.ReadOnly = False

    End Sub
    Public Sub OcultarCampos()
        celdaAño.Enabled = False

        celdaNumero.Enabled = False
        dtpFecha.Enabled = False
        celdaSerie.Enabled = False
        'celdaEmpresa.TexEnabledt = NO_FILA
        celdaTipo.Enabled = False
        celdaUsuario.Enabled = False
        celdaDireccion.Enabled = False
        celdaCliente.Enabled = False
        celdaIdCliente.Enabled = False

        celdaTelefono.Enabled = False
        celdaNIT.Enabled = False
        celdaMoneda.Enabled = False
        celdaIdMoneda.Enabled = False
        celdaFlete.Enabled = False
        celdaSeguro.Enabled = False
        celdaTasa.Enabled = False
        celdaTotal1.Enabled = False
        celdaTotal2.Enabled = False
        celdaSubDocumento.Enabled = False
        celdaNum2.Enabled = False

        celdaCargado.Enabled = False
        celdaSalida.Enabled = False
        celdaPoliza.Enabled = False
        celdaImpreso.Enabled = False
        dgInstrucDespacho.Enabled = False
        dgSubdocumentos.Enabled = True
        dgReferencia.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = False
        botonMoneda.Enabled = False

        ocultarDetalle()
        'celdaKGBrutos.Text = STR_VACIO

    End Sub
    Public Sub ActivarCampos()
        celdaAño.Enabled = True
        checkActivar.Enabled = True
        celdaNumero.Enabled = True
        dtpFecha.Enabled = True
        celdaSerie.Enabled = True
        'celdaEmpresa.TexEnabledt = NO_FILA
        celdaTipo.Enabled = True
        celdaUsuario.Enabled = True
        celdaDireccion.Enabled = True
        celdaCliente.Enabled = True
        celdaIdCliente.Enabled = True

        celdaTelefono.Enabled = True
        celdaNIT.Enabled = True
        celdaMoneda.Enabled = True
        celdaIdMoneda.Enabled = True
        celdaFlete.Enabled = True
        celdaSeguro.Enabled = True
        celdaTasa.Enabled = True
        celdaTotal1.Enabled = True
        celdaTotal2.Enabled = True
        celdaSubDocumento.Enabled = True
        celdaNum2.Enabled = True

        celdaCargado.Enabled = True
        celdaSalida.Enabled = True
        celdaPoliza.Enabled = True
        celdaImpreso.Enabled = True
        dgDetalle.Enabled = True
        dgDatos.Enabled = True
        dgInstrucDespacho.Enabled = True
        dgSubdocumentos.Enabled = True
        dgReferencia.Enabled = True
        Encabezado1.botonGuardar.Enabled = True
        Encabezado1.botonBorrar.Enabled = True
        botonMoneda.Enabled = True
        'celdaKGBrutos.Text = STR_VACIO

    End Sub

    Private Sub SeleccionarCliente(ByVal intaño As Integer, ByVal intnumero As Integer)
        Dim HDR As New clsDcmtos_HDR
        Dim CA As New clsCatalogos
        Dim strSQL As String
        Dim strSQL2 As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim intRevisado As Integer
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader

        strCampos = " HDoc_RF1_txt,HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, HDoc_Emp_Cod, HDoc_Emp_Nom, HDoc_Emp_Dir, HDoc_Emp_Tel, HDoc_Emp_NIT, HDoc_Doc_Tc, HDoc_Doc_Status, HDoc_Doc_Mon, HDoc_Doc_TC,HDoc_RF1_Dbl, HDoc_RF2_Dbl, HDoc_Usuario, HDoc_RF2_Cod, HDoc_DR1_Cat, HDoc_RF1_Cod,HDoc_DR2_Cat, HDoc_DR1_Fec, HDoc_DR2_Num, HDoc_DR2_Emp, HDoc_DR2_Fec, HDoc_DR1_Dbl, HDoc_Ant_Com, HDoc_RF2_Txt,HDoc_RF3_Dbl, HDoc_Pro_Fec"
        strCondicion = " HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", intaño)
        strCondicion = Replace(strCondicion, "{numero}", intnumero)

        Try
            HDR.CONEXION = strConexion
            If HDR.Seleccionar(strCondicion, strCampos) Then

                'strPaisCliente = REA.GetString("clasTipoFactura")
                'strNitCliente = REA.GetString("nitCliente")

                celdaAño.Text = HDR.HDOC_DOC_ANO
                celdaNumero.Text = HDR.HDOC_DOC_NUM
                dtpFecha.Text = HDR.HDOC_DOC_FEC
                celdaIdCliente.Text = HDR.HDOC_EMP_COD
                celdaCliente.Text = HDR.HDOC_EMP_NOM
                celdaDireccion.Text = HDR.HDOC_EMP_DIR
                celdaTelefono.Text = HDR.HDOC_EMP_TEL
                celdaNIT.Text = HDR.HDOC_EMP_NIT
                'celdaMoneda.Text = HDR.HDOC_DOC_MON
                celdaTasa.Text = HDR.HDOC_DOC_TC
                celdaFlete.Text = HDR.HDOC_RF1_DBL.ToString(FORMATO_MONEDA)
                celdaValidacionFlete.Text = HDR.HDOC_RF1_DBL.ToString(FORMATO_MONEDA)
                celdaSeguro.Text = HDR.HDOC_RF2_DBL
                celdaUsuario.Text = HDR.HDOC_USUARIO
                celdaEmpresa.Text = Sesion.IdEmpresa
                celdaTipo.Text = 36
                celdaCargado.Text = HDR.HDOC_RF2_COD
                celdaIdMoneda.Text = HDR.HDOC_DOC_MON
                celdaTipoFactura.Text = HDR.HDOC_RF3_DBL 'Tipo de Factura utilizado en Servi, NSM e Hilos
                intPais = Pais()
                If intPais = 310 And HDR.HDOC_DR2_NUM = "B" Then
                    celdaNum2.Text = HDR.HDOC_DR1_DBL
                Else
                    celdaNum2.Text = HDR.HDOC_DR1_DBL
                End If

                If HDR.HDOC_DR2_FEC.ToString = "00/00/0000 00:00:00" Then
                    celdaBloqueado.Text = ""
                Else
                    celdaBloqueado.Text = HDR.HDOC_DR2_FEC
                End If
                'celdaBloqueado.Text = HDR.HDOC_DR2_FEC
                celdaImpreso.Text = HDR.HDOC_DR2_CAT
                celdaSerie.Text = HDR.HDOC_DR2_NUM

                If HDR.HDOC_DR1_FEC.ToString = "00/00/0000 00:00:00" Or HDR.HDOC_DR1_FEC = "01/01/0001" Or HDR.HDOC_DR1_FEC = "12:00:00 a. m." Or HDR.HDOC_DR1_FEC = "1/01/0001" Then
                    celdaSalida.Text = ""
                Else
                    celdaSalida.Text = HDR.HDOC_DR1_FEC
                End If


                celdaPoliza.Text = HDR.HDOC_RF1_COD
                celdaFechavencimiento.Text = HDR.HDOC_PRO_FEC

                botonSerie.Enabled = False
                'If HDR.HDOC_RF1_COD = 1 Then
                '    celdaPoliza.Text = 1
                'Else
                '    celdaPoliza.Text = 0
                'End If

                If CA.Seleccionar(" cat_num = " & HDR.HDOC_DOC_MON, "cat_clave") Then
                    celdaMoneda.Text = CA.CAT_CLAVE
                Else
                    MsgBox(CA.MERROR.ToString)
                End If

                If HDR.HDOC_DOC_STATUS = 1 Then
                    checkActivar.Checked = True
                Else
                    checkActivar.Checked = False
                End If
                checkActivar.Enabled = True
                IIf(HDR.HDOC_RF1_TXT = "HONDURAS", checkDestino.Checked = True, checkDestino.Checked = False)
                'No Permite modificaciones si ya fue impreso
                logPrinted = Val(vbNullString & HDR.HDOC_DR2_CAT) > vbEmpty
                logImpuesto = Not Val(vbNullString & HDR.HDOC_DR2_EMP) = vbEmpty

                If logPrinted Then
                    dgDetalle.ReadOnly = False
                    botonSeguro.Enabled = True
                Else
                    dgDetalle.ReadOnly = False
                    botonSeguro.Enabled = True
                End If

                If HDR.HDOC_DR1_CAT = 0 Then
                    rbNacionalizacion.Checked = True
                Else
                    rbExportacion.Checked = True
                End If

                If logImpuesto Then
                    logLibre = Not IsDBNull(HDR.HDOC_DR2_FEC)
                Else
                    logLibre = True
                End If


                strSQL = "SELECT revisado"
                strSQL &= " FROM {conta}.polizas"
                strSQL &= "      WHERE empresa = {empresa} AND ref_tipo = 36 AND ref_ciclo = {año} AND ref_numero = {numero} "

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{año}", HDR.HDOC_DOC_ANO)
                strSQL = Replace(strSQL, "{numero}", HDR.HDOC_DOC_NUM)
                strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    intRevisado = COM.ExecuteScalar()
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using

                checkRevisado.Checked = IIf(intRevisado = vbEmpty, False, True)

                strSQL2 = "SELECT IFNULL(c.cli_codigo,0) IDEmpresa, IFNULL(c.cli_cliente,'') cliente"
                strSQL2 &= "      FROM Dcmtos_HDR h"
                strSQL2 &= "         LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp  and c.cli_codigo = h.HDoc_Ant_Com"
                strSQL2 &= "       WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {año} and h.HDoc_Doc_Num ={numero}"

                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                strSQL2 = Replace(strSQL2, "{año}", celdaAño.Text)
                strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL2, CON)
                REA = COM2.ExecuteReader

                If REA.HasRows Then
                    REA.Read()
                    celdaIDEmpPagadora.Text = REA.GetInt32("IDEmpresa")
                    celdaEmpPagadora.Text = REA.GetString("cliente")
                End If


                'Carga el CAI
                celdaCAI.Text = HDR.HDOC_RF2_TXT

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Suma la columna para la línea
    Private Function SumarLista(ByVal Columna As String, ByVal Ciclo As String, ByVal Numero As String, ByVal Linea As String) As Double
        Dim i As Integer
        Dim dblSuma As Double

        Try
            dblSuma = vbEmpty
            For i = 0 To dgReferencia.Rows.Count - 1
                If (dgReferencia.Rows(i).Cells("colAno").Value = Ciclo) And
                    (dgReferencia.Rows(i).Cells("colNumber").Value = Numero) And
                    (dgReferencia.Rows(i).Cells("colLine").Value = Linea) Then
                    dblSuma = dblSuma + Val(dgReferencia.Rows(i).Cells(Columna).Value)
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        SumarLista = dblSuma
    End Function

    'Comprueba el descargo desde varias líneas a una misma línea de referencia
    Private Function ComprobarDescargos() As Boolean
        Dim i As Integer
        Dim strTemp As String
        Dim dblDisponible As Double
        Dim dblActual As Double
        Dim dblSuma As Double
        Dim strLineas As String = STR_VACIO
        Dim intDif As Boolean

        Try
            If Me.Tag = "Mod" And checkActivar.Checked = False Then
                ComprobarDescargos = True
            Else
                If (dgReferencia.Rows.Count >= 0) Then
                    For i = 0 To dgReferencia.Rows.Count - 1
                        'Identifica la línea a descargar
                        strTemp = dgReferencia.Rows(i).Cells("colAno").Value & "|"
                        strTemp &= dgReferencia.Rows(i).Cells("colNumber").Value & "|"
                        strTemp &= dgReferencia.Rows(i).Cells("colInstruccion").Value & "|"
                        If dgReferencia.Rows(i).Cells("colAmount").Value = vbNullString Then
                            dgReferencia.Rows(i).Cells("colAmount").Value = 0
                        Else
                            dgReferencia.Rows(i).Cells("colAmount").Value = 0
                        End If
                        dblDisponible = dgReferencia.Rows(i).Cells("colAmount").Value
                        dblActual = SumarLista("colCantDescargada", dgReferencia.Rows(i).Cells("colAno").Value, dgReferencia.Rows(i).Cells("colNumber").Value, dgReferencia.Rows(i).Cells("colLine").Value)
                        dblSuma = SumarLista("colDescargo", dgReferencia.Rows(i).Cells("colAno").Value, dgReferencia.Rows(i).Cells("colNumber").Value, dgReferencia.Rows(i).Cells("colLine").Value)
                        If (dblSuma) > (dblDisponible + dblActual) Then
                            'Comprueba si ya se verificó
                            If InStr(1, strLineas, strTemp) = vbEmpty Then
                                MsgBox("You are trying to download and amount greater than the available" & vbCr & vbCr & "Inventory code" & vbTab & dgReferencia.Rows(i).Cells("colReference").Value & vbCr & "Linea: " & vbTab & vbTab & vbTab & dgReferencia.Rows(i).Cells("colLine").Value & vbCr & "Inventory Code: " & vbTab & dgReferencia.Rows(i).Cells("colCod").Value & vbCr & vbCr & "Faltante:" & vbTab & vbTab & (dblSuma - (dblDisponible + dblActual)).ToString(FORMATO_MONEDA), vbExclamation, "Notice")
                                intDif = intDif + 1
                            End If
                            'Agrega la línea a comprobadas
                            strLineas = strLineas & vbNullChar & strTemp
                        Else
                            'Asigna la existencia actual
                            dgReferencia.Rows(i).Cells("colDisponible").Value = (dblDisponible + dblActual)
                        End If
                    Next
                Else
                    MsgBox("Exculpatory information we not found", vbExclamation, "Notice")
                    intDif = NO_FILA
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        ComprobarDescargos = (intDif = vbEmpty)
    End Function

    Private Function ComprobarFilaDetalle() As Boolean
        ComprobarFilaDetalle = True
        Dim i As Integer
        Dim Comprobacion As Boolean = True

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colEliminar").Value = 1 Then
                If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                Else
                    If dgDetalle.Rows(i).Cells("colCode").Value = vbNullString Then
                        Comprobacion = False
                        MsgBox("Article code invalid")
                    End If
                End If

                If dgDetalle.Rows(i).Cells("colDescrip").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item description")
                End If

                If dgDetalle.Rows(i).Cells("colDescrip").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Blank item description")
                End If

                If dgDetalle.Rows(i).Cells("colPrecio").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("ZERO price items")
                End If

                If dgDetalle.Rows(i).Cells("colCantidad").Value = vbNullString Then
                    Comprobacion = False
                    MsgBox("Item number ZERO")
                End If
                If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                Else
                    If dgDetalle.Rows(i).Cells("colTipoBulto").Value = vbNullString Then
                        Comprobacion = False
                        If i = 1 Then
                            MsgBox("Do You must enter the type of packages", MsgBoxStyle.Information)
                        End If

                    End If
                End If

            End If
        Next
        Return Comprobacion
    End Function

    'Comprueba que se haya ingresado flete y seguro
    Private Function ComprobarGastos() As Boolean

        If checkActivar.Checked = False Then
            ComprobarGastos = True
        ElseIf Val(celdaFlete.Text) = vbEmpty Or Val(celdaSeguro.Text) = vbEmpty Then
            If MsgBox("You have not  entered a values  for freight or insuracne" & vbCr & vbCr & "Want to leave blank some of these values?", vbQuestion + vbYesNo + vbDefaultButton2, "Confirm") = vbYes Then
                ComprobarGastos = True
            Else
                celdaFlete.Focus()
                ComprobarGastos = False
            End If
        Else
            ComprobarGastos = True
        End If
        Return ComprobarGastos
    End Function

    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        If ComprobarNoFacturaDisponible() Then
            comprobar = False
        End If

        'Revisar que los datos de la cabecera no estén en blanco.
        If celdaEmpresa.Text = vbNullString Or
           celdaTipo.Text = vbNullString Or
           celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete  data sytem.", vbCritical)
            comprobar = False
        End If

        If celdaAño.Text = vbEmpty Or
           celdaNumero.Text = vbEmpty Or
           celdaIdCliente.Text = vbEmpty Or
           celdaCliente.Text = "" Or
           celdaNIT.Text = "" Or
           celdaMoneda.Text = "" Or
           celdaTasa.Text = vbEmpty Then
            MsgBox("You must enter all minimum data", vbCritical)
            comprobar = False
        End If

        If Not IsDate(dtpFecha.Text) Then
            MsgBox("You have not entered a valid date", vbExclamation, "Notice")
            dtpFecha.Focus()
            comprobar = False
        ElseIf Not (Val(celdaAño.Text)) = (celdaAño.Text) Then
            MsgBox("The date entered does not match the year of the document", vbExclamation, "Notice")
            dtpFecha.Focus()
            comprobar = False
        End If

        If Not checkActivar.Checked = False Then
            'Verifica datos en el Detalle
            If ComprobarFilaDetalle() = False Then comprobar = False
        End If

        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 10 Then
            If (celdaGranTotal.Text * celdaTasa.Text) >= 2500 And celdaNIT.Text.Length < 4 Then
                MsgBox("The 'NIT' can't be C/F ", vbExclamation, "Notice")
                comprobar = False
            End If
        End If

        'Verifica que total > 0
        CalcularTotales()

        If Not checkActivar.Checked = False Then
            If Not dblDocCantidad > 0 Then
                MsgBox("It is not supported and order with zero amount", vbCritical)
                comprobar = False
            End If
        End If
        Return comprobar
    End Function

    Private Function ComprobarNoFacturaDisponible() As Boolean
        Dim intNumero As Integer
        Dim strSQL As String
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim cai As String = "0"
        Dim rangoInicial As Integer = 0
        Dim rangoFinal As Integer = 0
        Dim autorizacion As String = Now().ToString(FORMATO_MYSQL)

        'Valida que numero este en el rango de facturas disponibles
        If Me.Tag = "Nuevo" And (celdaNum2.Text <= 0) Then
            strSQL = " SELECT ifnull(MAX(HDoc_DR1_Dbl),0)+1"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "         WHERE HDoc_Sis_Emp ={empresa} and HDoc_Doc_Cat = 36 and HDoc_DR2_Num = '" & celdaSerie.Text & "'"

            If Sesion.IdEmpresa = 8 Then
                strSQL = Replace(strSQL, "{serie}", 3)
            Else
                strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                intNumero = COM.ExecuteScalar
                celdaNum2.Text = intNumero
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
        Else
            intNumero = celdaNum2.Text
        End If

        If Me.Tag = "Nuevo" And (Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22) Then
            strSQL = "Select IFNULL(regimen,'') cai, rango_inicial rangoInicial, rango_final rangoFinal, autorizacion FROM Gface"
            strSQL &= " WHERE empresa = {empresa}"
            strSQL &= " And serie=("
            strSQL &= " Select cat_num FROM Catalogos"
            strSQL &= " where cat_clase ='Serie'"
            strSQL &= " And cat_clave ='Doc_CFactura'"
            If Sesion.IdEmpresa = 11 Then
                strSQL &= " And cat_sist='" & celdaSerie.Text & "' "
            End If
            strSQL &= " And cat_sisemp = {empresa} And cat_pid = 0"
            strSQL &= " )"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                cai = REA.GetString("cai")
                rangoInicial = REA.GetString("rangoInicial")
                rangoFinal = REA.GetString("rangoFinal")
                autorizacion = REA.GetString("autorizacion")
            End If
            REA.Close()
            COM.Dispose()
            REA = Nothing
            COM = Nothing
            If Date.Compare(Now().ToString(FORMATO_MYSQL), CDate(autorizacion).ToString(FORMATO_MYSQL)) <= 0 And (rangoInicial <= intNumero And intNumero <= rangoFinal) Then
                Return False
            Else
                MsgBox("No. Invoice not available." & vbLf & "CAI: " & cai & vbLf & "Initial Range: " & rangoInicial & vbLf & "Final Range: " & rangoFinal & vbLf & "Date Expiration: " & CDate(autorizacion).ToString(FORMATO_MYSQL), vbExclamation, "Notice")
                Return True
            End If
        End If

        Return False

    End Function

    'Comprueba que no se mezclen grupos de paises (p.e.: USA, ASIA)
    Private Function ComprobarOrigenes() As Boolean
        Const STR_GRUPOS As String = "'ASIA','USA'"

        Dim logEx As Boolean
        Dim strCod As String
        Dim strLista As String
        Dim strSQL As String
        Dim strTemp As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Dim i As Integer
        Dim c As Integer

        logEx = False
        c = vbEmpty
        strCod = vbNullString : strLista = vbNullString
        For i = vbEmpty To dgDetalle.Rows.Count - 1
            strCod = "|" & strCod & "|"
            If Not (strCod = vbNullString) Then
                strCod = "|" & strCod & "|"
                If InStr(1, strLista, strCod) = vbEmpty Then
                    strLista = strLista & strCod
                    c = c + 1
                End If
            End If
        Next

        'Sólo si hay más de un código involucrado   
        If c > INT_UNO Then
            strLista = Replace(strLista, "||", ",")
            strLista = Replace(strLista, "|", vbNullString)

            strSQL = vbNullString
            strSQL &= "SELECT GROUP_CONCAT(DISTINCT g.cat_clave ORDER BY g.cat_clave SEPARATOR ',') Grupos "
            strSQL &= "      FROM Inventarios i"
            strSQL &= "         INNER JOIN Catalogos c ON c.cat_clase='Paises' AND c.cat_num=i.inv_lugarfab "
            strSQL &= "              INNER JOIN Catalogos g ON g.cat_clase='Countries' AND g.cat_num=c.cat_pid "
            strSQL &= "          WHERE i.inv_sisemp={empresa} AND i.inv_numero IN ({lista}) AND g.cat_clave IN ({grupos}) "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{lista}", strLista)
            strSQL = Replace(strSQL, "{grupo}", STR_GRUPOS)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                strTemp = COM.ExecuteScalar()
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            If Not (strTemp = vbNullString) Then
                If InStr(1, strTemp, ",") > vbEmpty Then
                    MsgBox("You cant not mix products originating" & Replace(Replace(STR_GRUPOS, "'", ""), ",", " y "), vbExclamation, "Origin")
                    logEx = True
                End If
            End If
        End If

        ComprobarOrigenes = Not logEx
    End Function

    'Comprueba que se haya verificado todas las líneas
    Private Function ComprobarLineas() As Boolean
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim strTemp As String = STR_VACIO
        Dim strMensaje As String = STR_VACIO

        If Me.Tag = "Mod" And checkActivar.Checked = False Then
            ComprobarLineas = True
        Else
            'Verifica si se han revisado las referencias para todas las líneas
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colReferences").Value = vbNullString Then
                    j = j + 1
                    strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " , ") & (i + 1)
                End If
            Next

            If (j > vbEmpty) Then
                strMensaje = "Releases have not checked for " & IIf(j = 1, "the line", "the lines") & ":" & strTemp
            End If

            'Verifica si hay alguna línea sin tipo de bulto
            j = vbEmpty
            strTemp = vbNullString
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colTipoBulto").Value = vbNullString And dgDetalle.Rows(i).Cells("colEliminar").Value = 1 Then
                    j = j + 1
                    strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " , ") & (i + 1)
                End If
            Next

            If (j > vbEmpty) Then
                strMensaje = strMensaje & IIf(strMensaje = vbNullString, vbNullString, vbCr & vbCr) & "You have not entered any package for" & IIf(j = 1, "the line", "the lines") & ": " & strTemp
            End If

            'Verifica el formato de distribución de la mercancía
            Dim varPartes As Object
            Dim varDato As Object
            Dim dblSuma As Double
            Dim logErr As Boolean
            Dim strInfo As String = STR_VACIO
            j = vbEmpty
            strTemp = vbNullString

            For i = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("colDistribucion").Value = vbNullString Then
                    varPartes = Split(dgDetalle.Rows(i).Cells("colDistribucion").Value, " , ")
                    dblSuma = vbEmpty
                    logErr = False
                    For k = vbEmpty To UBound(varPartes)
                        If InStr(1, varPartes(k), "/") > vbEmpty Then
                            varDato = Split(varPartes(k), "/")
                            If (UBound(varDato) = 1) Then
                                If IsNumeric(varDato(vbEmpty)) And IsNumeric(varDato(1)) Then
                                    If (varDato(vbEmpty) = CInt(Val(varDato(vbEmpty)))) And Val(varDato(vbEmpty)) > vbEmpty Then
                                        dblSuma = dblSuma + Val(varDato(1))
                                    Else
                                        strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Line " & (i + 1) & ": the sequence must be an integer greater than zero"
                                        logErr = True
                                    End If
                                Else
                                    strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Line " & (i + 1) & ": sequence and quantity must be numerical data"
                                    logErr = True
                                End If
                            Else
                                strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Line " & (i + 1) & ": It is not satisfied with the format n°/quantity[...,n°/quantity] "
                                logErr = True
                            End If
                        Else
                            strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Line " & (i + 1) & ": It is not satisfied with the format n°/quantity[...,n°/quantity] "
                            logErr = True
                        End If
                        If logErr = True Then
                            Exit For
                        End If
                    Next
                    If Not logErr Then
                        If Not (dblSuma).ToString(FORMATO_MONEDA) = (dgDetalle.Rows(i).Cells("colDespacho").Value) Then
                            strInfo = strInfo & IIf(strInfo = vbNullString, vbNullString, vbCr) & "Line " & (i + 1) & ": the sum of amounts(" & (dblSuma).ToString(FORMATO_MONEDA) & ") differs detail"
                            logErr = True
                        End If
                    End If
                    If logErr Then
                        j = j +
                        strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " , ") & (i + 1)
                    End If
                End If
            Next
            If (j > vbEmpty) Then
                strMensaje = strMensaje & IIf(strMensaje = vbNullString, vbNullString, vbCr & vbCr) & "Check the form of distribution for " & IIf(j = 1, "the line", "the lines") & ": " & strTemp & vbCr & vbCr & strInfo
            End If

            If (strMensaje = vbNullString) Then
                ComprobarLineas = True
            Else
                MsgBox(strMensaje, vbExclamation, "Do Not")
            End If
        End If
        ComprobarLineas = True
    End Function

    'Query para guardar Descargos
    Private Sub GuargarDescargos()
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Dim cfun As New clsFunciones
        Dim logResultado As Boolean = True
        Dim j As Integer = 0


        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                MyCnn.CONECTAR = strConexion

                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 48
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAño").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                clsDTLPro.PDOC_CHI_CAT = 36
                clsDTLPro.PDOC_CHI_ANO = Val(celdaAño.Text)
                clsDTLPro.PDOC_CHI_NUM = Val(celdaNumero.Text)
                If Me.Tag = "Nuevo" Then

                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    clsDTLPro.PDOC_CHI_LIN = j
                Else
                    clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea2").Value
                End If

                clsDTLPro.PDOC_PROV_COD = Val(celdaIdCliente.Text)
                clsDTLPro.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCode").Value
                clsDTLPro.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                clsDTLPro.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidad").Value
                clsDTLPro.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidad").Value

                If dgDetalle.Rows(i).Cells("colEliminar").Value = 0 And Me.Tag = "Mod" Then
                    If clsDTLPro.Actualizar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If

                ElseIf dgDetalle.Rows(i).Cells("colEliminar").Value = 1 And Me.Tag = "Nuevo" Then
                    If clsDTLPro.Guardar() = False Then
                        MsgBox(clsDTLPro.MERROR.ToString)
                    End If
                End If

            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function Pais()
        Dim strSQL2 As String
        Dim COM2 As New MySqlCommand
        Dim conec2 As New MySqlConnection

        strSQL2 = "SELECT e.emp_pais "
        strSQL2 &= "     FROM Empresas e"
        strSQL2 &= "         WHERE e.emp_no = {empresa} "

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        conec2 = New MySqlConnection(strConexion)
        conec2.Open()
        COM2 = New MySqlCommand(strSQL2, conec2)
        Using conec2
            intPais = COM2.ExecuteScalar
            COM2.Dispose()
            COM2 = Nothing
            conec2.Close()
            conec2.Dispose()
            conec2 = Nothing
            System.GC.Collect()
        End Using

        Return intPais
    End Function

    Private Sub CAI()
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection
        Dim REA As MySqlDataReader
        Dim strCAI As String = STR_VACIO

        strSQL = "SELECT IFNULL(g.regimen,'') dato
                    FROM Catalogos c
                    LEFT JOIN Gface g ON g.serie = c.cat_num
                    WHERE c.cat_clase = 'Serie' AND c.cat_clave = 'Doc_CFactura' AND c.cat_sist = '{serie}' and cat_pid=0"

        strSQL = strSQL.Replace("{serie}", celdaSerie.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()

            celdaCAI.Text = REA.GetString("dato")
        End If
        REA.Close()
        COM.Dispose()
        REA = Nothing
        COM = Nothing
    End Sub

    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean = True
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Dim intNumero As Integer = Val(celdaNum2.Text)

        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = celdaTipo.Text
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)

            intPais = Pais()
            If (Sesion.IdEmpresa = 12 And intPais = 310) Or Sesion.IdEmpresa = 14 Or (Sesion.IdEmpresa = 15 And intPais = 1) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Or (Sesion.IdEmpresa = 11) Then
                If celdaNum2.Text = "" Then
                    celdaNum2.Text = 0
                End If
                chdr.HDOC_DR1_DBL = Val(celdaNum2.Text)
            Else
                chdr.HDOC_DR1_DBL = intNumero
            End If

            chdr.HDOC_EMP_COD = celdaIdCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_TEL = celdaTelefono.Text
            chdr.HDOC_EMP_NIT = celdaNIT.Text

            chdr.HDOC_DOC_MON = celdaIdMoneda.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text

            chdr.HDOC_RF1_DBL = celdaFlete.Text
            chdr.HDOC_RF1_NUM = IIf(checkDetGatos.Checked = True, 1, vbEmpty)
            chdr.HDOC_RF2_DBL = celdaSeguro.Text

            chdr.HDOC_DR1_CAT = IIf(rbNacionalizacion.Checked, vbEmpty, 1) 'Tipo: venta/exportación
            chdr.HDOC_DR1_NUM = GetReferencia()
            'chdr.HDOC_RF1_COD = 0
            chdr.HDOC_RF1_TXT = IIf(checkDestino.Checked = True, "HONDURAS", STR_VACIO) ' guarda nuevo Destino HSM
            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) Then
                chdr.HDOC_RF3_DBL = celdaTipoFactura.Text
            End If
            chdr.HDOC_DR2_CAT = celdaImpreso.Text
            If celdaEmpresa.Text = 8 Then
                chdr.HDOC_DR2_NUM = "003"
            Else
                chdr.HDOC_DR2_NUM = celdaSerie.Text
            End If

            chdr.HDOC_DR2_EMP = IIf(logImpuesto, INT_UNO, vbEmpty) 'Pago de impuestos

            'DR1_Emp y RF2_Num se utilizan en el Yarn Movement para Cliente y Días
            chdr.HDOC_DR1_EMP = intRefID
            chdr.HDOC_RF2_NUM = intRefDias
            chdr.HDOC_RF2_COD = celdaCargado.Text

            chdr.HDOC_USUARIO = celdaUsuario.Text
            chdr.HDOC_DOC_STATUS = IIf(checkActivar.Checked = True, 1, vbEmpty)

            chdr.HDOC_RF1_COD = celdaPoliza.Text
            chdr.HDOC_DR2_CAT = celdaImpreso.Text
            chdr.HDOC_ANT_COM = celdaIDEmpPagadora.Text

            If celdaSalida.Text = " " Or celdaSalida.Text = "" Or celdaSalida.Text = "12:00:00:a. m." Then
                'ElseIf celdaSalida.Text = "00:00:00" Then
                chdr.HDOC_DR1_FEC = Nothing
            Else
                chdr.HDoc_DR1_Fec_NET = celdaSalida.Text
            End If

            If Me.Tag = "Mod" Then
                If celdaBloqueado.Text = vbNullString Or celdaBloqueado.Text = "00:00:00" Or celdaBloqueado.Text = "12:00:00:a. m." Then
                Else
                    chdr.HDoc_DR2_Fec_NET = celdaBloqueado.Text
                End If

            End If

            'No permitir modificaciones si ya fue impreso
            logPrinted = (Val(vbNullString & chdr.HDOC_DR2_CAT) > vbEmpty)
            logImpuesto = Not (Val(vbNullString & chdr.HDOC_DR2_EMP) = vbEmpty)
            If logImpuesto Then
                logLibre = Not IsDBNull(chdr.HDOC_DR2_FEC)
            Else
                logLibre = True
            End If

            'Dato que se almacena solo para Republica Dominicana
            If Sesion.IdEmpresa = 14 Then
                If celdaFechavencimiento.Text = vbNullString Then
                Else
                    chdr.HDoc_Pro_Fec_NET = celdaFechavencimiento.Text
                End If
            End If

            'Almacena el CAI
            chdr.HDOC_RF2_TXT = celdaCAI.Text


            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarEncabezadoYarn_Movement(ByVal intAño As Integer, ByVal intNumero As Integer) As Boolean
        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim logResultado As Boolean = True
        Dim REA As MySqlDataReader
        Dim chdr As New clsDcmtos_HDR

        Try
            strSql = "INSERT INTO Dcmtos_HDR"
            strSql &= "  SELECT h.HDoc_Sis_Emp,395,h.HDoc_Doc_Ano, h.HDoc_Doc_Num, h.HDoc_Doc_Fec, h.HDoc_Emp_Cod, h.HDoc_Emp_Nom, h.HDoc_Emp_Dir, h.HDoc_Emp_Per ,"
            strSql &= "      h.HDoc_Emp_Tel, h.HDoc_Emp_NIT, h.HDoc_RF2_Num, CONCAT('YRM-','YRM-',h.HDoc_Doc_Num,'B') HDoc_Doc_Num, h.HDoc_DR1_Dbl, h.HDoc_DR1_Fec, h75.HDoc_DR1_Emp, h.HDoc_DR2_Cat, h.HDoc_DR2_Num, h.HDoc_DR2_Fec,"
            strSql &= "          -1 HDoc_Dr2_Emp , h.HDoc_RF1_Num, h.HDoc_RF1_Cod, h.HDoc_RF1_Txt, h.HDoc_RF2_Num, h.HDoc_RF2_Cod,'', h.HDoc_Usuario, h.HDoc_Pro_Fec, h.HDoc_Pro_DCat,"
            strSql &= "                h.HDoc_Pro_DAno, h.HDoc_Pro_DNum,h.HDoc_Doc_TC, h.HDoc_Doc_Mon, h.HDoc_RF1_Dbl, h.HDoc_RF2_Dbl, h.HDoc_RF3_Dbl, h.HDoc_Doc_Status, h.HDoc_Ant_Com"
            strSql &= "       FROM Dcmtos_HDR h"
            strSql &= "         LEFT JOIN Dcmtos_DTL_Pro p48 ON p48.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p48.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p48.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p48.PDoc_Chi_Num = h.HDoc_Doc_Num  AND p48.PDoc_Par_Cat  = 48 "  ' Instruccion De Despacho 
            strSql &= "             LEFT JOIN Dcmtos_DTL_Pro p75 ON p75.PDoc_Sis_Emp = p48.PDoc_Sis_Emp  AND p75.PDoc_Chi_Cat = p48.PDoc_Par_Cat AND p75.PDoc_Chi_Ano = p48.PDoc_Par_Ano AND p75.PDoc_Chi_Num = p48.PDoc_Par_Num AND p48.PDoc_Par_Lin = p75.PDoc_Chi_Lin  AND p75.PDoc_Par_Cat = 75 " ' Pro Forma
            strSql &= "          LEFT JOIN Dcmtos_HDR h75 ON h75.HDoc_Sis_Emp = p75.PDoc_Sis_Emp AND h75.HDoc_Doc_Cat = p75.PDoc_Par_Cat AND h75.HDoc_Doc_Ano = p75.PDoc_Par_Ano AND h75.HDoc_Doc_Num = p75.PDoc_Par_Num   " ' Pro forma HDR
            strSql &= "   WHERE h.HDoc_Sis_Emp  = {empresa} and h.HDoc_Doc_Cat  = 36 and h.HDoc_Doc_Ano  = {año} and h.HDoc_Doc_Num  = {numero}"
            strSql &= "     GROUP by  h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num "
            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{año}", celdaAño.Text)
            strSql = Replace(strSql, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Query para guardar el Detalle
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim j As Integer = 0

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                Dtl.DDOC_DOC_CAT = celdaTipo.Text
                Dtl.DDOC_DOC_ANO = celdaAño.Text
                Dtl.DDOC_DOC_NUM = celdaNumero.Text

                If Me.Tag = "Nuevo" Then
                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    Dtl.DDOC_DOC_LIN = j
                Else
                    Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea2").Value
                End If

                Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCode").Value
                Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescrip").Value
                If celdaTipoFactura.Text >= 1 Then
                    Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colCodMedida").Value
                Else
                    Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colBase").Value
                End If
                Dtl.DDOC_PRD_PUQ = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_DSP = CDbl(dgDetalle.Rows(i).Cells("colDesc").Value) ' Descuento en Porcentaje (%)
                Dtl.DDOC_PRD_DSQ = CDbl(dgDetalle.Rows(i).Cells("colDescDolar").Value) ' Descuento en Dinero ($)
                Dtl.DDOC_PRD_CIF = CDbl(dgDetalle.Rows(i).Cells("colPrecioPF").Value) 'Precio proforma
                Dtl.DDOC_PRD_NET = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                Dtl.DDOC_PRD_QTY = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)

                Dtl.DDOC_RF1_DBL = CDbl(dgDetalle.Rows(i).Cells("colLBS").Value)
                Dtl.DDOC_RF2_DBL = CDbl(dgDetalle.Rows(i).Cells("colKGS").Value)
                Dtl.DDOC_PRD_FOB = CDbl(dgDetalle.Rows(i).Cells("colKGNetosExt").Value)

                Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colOriginal").Value
                Dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCodLugar").Value
                Dtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReferences").Value

                Dtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colBobina").Value
                Dtl.DDOC_PRD_REF = IIf(dgDetalle.Rows(i).Cells("colCta").Value = STR_VACIO, "", dgDetalle.Rows(i).Cells("colCta").Value) ' Guarda la cuenta de las facturas de servicio
                Dtl.DDOC_PRD_PNR = IIf(dgDetalle.Rows(i).Cells("colLoteNuevo").Value = STR_VACIO, "", dgDetalle.Rows(i).Cells("colLoteNuevo").Value) ' Lote Nuevo para HSM

                If dgDetalle.Rows(i).Cells("colDistribucion").Value = Nothing Then
                    Dtl.DDOC_RF2_COD = ""
                ElseIf dgDetalle.Rows(i).Cells("colDistribucion").Value = " " Then
                    Dtl.DDOC_RF2_COD = ""
                Else
                    Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colDistribucion").Value
                End If
                Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colTipoBulto").Value
                If celdaTipoFactura.Text >= 1 Then
                    Dtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colCodMedida").Value
                Else
                    Dtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colBase").Value
                End If
                Dtl.DDOC_RF3_DBL = CDbl(dgDetalle.Rows(i).Cells("colDespacho").Value)


                If dgDetalle.Rows(i).Cells("colEliminar").Value = 0 And Me.Tag = "Mod" Then
                    If Dtl.Actualizar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colEliminar").Value = 1 And Me.Tag = "Nuevo" Then
                    If Dtl.Guardar() = False Then
                        MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDetalleYarn_Movement(ByVal intAño As Integer, ByVal intNumero As Integer)
        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand

        Try
            'Datos del detalle
            strSql = "INSERT INTO Dcmtos_DTL"
            strSql &= "     SELECT d.DDoc_Sis_Emp,395,d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin, d.DDoc_Prd_Cod, d.DDoc_Prd_PNr, d.DDoc_Prd_Des, d.DDoc_Prd_UM, "


            strSql &= "IFNULL(IF(d.DDoc_Prd_UM = 70, -- si la factura esta en kg 
	                         if(d75.DDoc_Prd_Cif>0 , -- si se ingreso precio en kg
	 	                        d75.DDoc_Prd_Cif, -- usar precio en kg
		                        ROUND(COALESCE(d75.DDoc_Prd_Net,0) *2.2046,2) )   , -- si no se ingreso precio kg calcular 
	                        d75.DDoc_Prd_Net),0)  DDoc_Prd_PUQ,  "

            strSql &= " d.DDoc_Prd_DSP, d.DDoc_Prd_DSQ, "

            strSql &= " IFNULL(IF(d.DDoc_Prd_UM = 70, -- si la factura esta en kg 
	                         if(d75.DDoc_Prd_Cif>0 , -- si se ingreso precio en kg
	 	                        d75.DDoc_Prd_Cif, -- usar precio en kg
		                        ROUND(COALESCE(d75.DDoc_Prd_Net,0) *2.2046,2) )   , /* si no se ingreso precio kg calcular */ "
            'Condicion que salva vidas XD, 
            'Condicion para tomar el dato de la dtl de la factura.
            If (Sesion.idGiro = 2 Or Sesion.IdEmpresa = 14) And celdaTipoFactura.Text = "1" Then
                strSql &= "  IFNULL(d75.DDoc_Prd_Net,d.DDoc_Prd_NET)),0)  Doc_Prd_NET,   "
            Else
                strSql &= "  d75.DDoc_Prd_Net),0)  Doc_Prd_NET,  "
            End If

            strSql &= " d.DDoc_Prd_QTY,0,(Select IFNULL(e.HDoc_DR1_Num,'') Pedido"
            strSql &= "         FROM Dcmtos_DTL di"
            strSql &= "             LEFT JOIN Dcmtos_DTL_Pro r ON r.PDoc_Sis_Emp=di.DDoc_Sis_Emp AND r.PDoc_Chi_Cat=di.DDoc_Doc_Cat AND r.PDoc_Chi_Ano=di.DDoc_Doc_Ano AND r.PDoc_Chi_Num=di.DDoc_Doc_Num AND r.PDoc_Chi_Lin=di.DDoc_Doc_Lin AND r.PDoc_Par_Cat= 48"
            strSql &= "                 LEFT JOIN Dcmtos_DTL_Pro o ON o.PDoc_Sis_Emp=r.PDoc_Sis_Emp AND o.PDoc_Chi_Cat=r.PDoc_Par_Cat AND o.PDoc_Chi_Ano=r.PDoc_Par_Ano AND o.PDoc_Chi_Num=r.PDoc_Par_Num AND o.PDoc_Chi_Lin=r.PDoc_Par_Lin AND o.PDoc_Par_Cat= 75"
            strSql &= "                     LEFT JOIN Dcmtos_DTL p ON p.DDoc_Sis_Emp=o.PDoc_Sis_Emp AND p.DDoc_Doc_Cat=o.PDoc_Par_Cat AND p.DDoc_Doc_Ano=o.PDoc_Par_Ano AND p.DDoc_Doc_Num=o.PDoc_Par_Num AND p.DDoc_Doc_Lin=o.PDoc_Par_Lin"
            strSql &= "                         LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=p.DDoc_Sis_Emp AND e.HDoc_Doc_Cat=p.DDoc_Doc_Cat AND e.HDoc_Doc_Ano=p.DDoc_Doc_Ano AND e.HDoc_Doc_Num=p.DDoc_Doc_Num"
            strSql &= "                              WHERE di.DDoc_Sis_Emp=d.DDoc_Sis_Emp AND di.DDoc_Doc_Cat=d.DDoc_Doc_Cat AND di.DDoc_Doc_Ano=d.DDoc_Doc_Ano AND di.DDoc_Doc_Num=d.DDoc_Doc_Num limit 1) pedido, d.DDoc_RF1_Txt, d.DDoc_RF1_Fec, d.DDoc_RF1_Dbl,0,(SELECT  IFNULL(t.ADoc_Dta_Txt,'') Contenedor"
            strSql &= "                                  FROM Dcmtos_DTL di"
            strSql &= "                                      LEFT JOIN Dcmtos_DTL_Pro r ON r.PDoc_Sis_Emp=di.DDoc_Sis_Emp AND r.PDoc_Chi_Cat=di.DDoc_Doc_Cat AND r.PDoc_Chi_Ano=di.DDoc_Doc_Ano AND r.PDoc_Chi_Num=di.DDoc_Doc_Num AND r.PDoc_Chi_Lin=di.DDoc_Doc_Lin AND r.PDoc_Par_Cat= 48"
            strSql &= "                                   LEFT JOIN Dcmtos_DTL_Pro n ON n.PDoc_Sis_Emp=r.PDoc_Sis_Emp AND n.PDoc_Chi_Cat=r.PDoc_Par_Cat AND n.PDoc_Chi_Ano=r.PDoc_Par_Ano AND n.PDoc_Chi_Num=r.PDoc_Par_Num AND n.PDoc_Chi_Lin=r.PDoc_Par_Lin AND n.PDoc_Par_Cat= 47"
            strSql &= "                               LEFT JOIN Dcmtos_DTL_Pro m ON m.PDoc_Sis_Emp=n.PDoc_Sis_Emp AND m.PDoc_Chi_Cat=n.PDoc_Par_Cat AND m.PDoc_Chi_Ano=n.PDoc_Par_Ano AND m.PDoc_Chi_Num=n.PDoc_Par_Num AND m.PDoc_Chi_Lin=n.PDoc_Par_Lin AND m.PDoc_Par_Cat= 180"
            strSql &= "                          LEFT JOIN Dcmtos_DTL_Pro a ON a.PDoc_Sis_Emp=m.PDoc_Sis_Emp AND a.PDoc_Chi_Cat=m.PDoc_Par_Cat AND a.PDoc_Chi_Ano=m.PDoc_Par_Ano AND a.PDoc_Chi_Num=m.PDoc_Par_Num AND a.PDoc_Chi_Lin=m.PDoc_Par_Lin AND a.PDoc_Par_Cat= 55"
            strSql &= "                      LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp=a.PDoc_Sis_Emp AND c.PDoc_Chi_Cat=a.PDoc_Par_Cat AND c.PDoc_Chi_Ano=a.PDoc_Par_Ano AND c.PDoc_Chi_Num=a.PDoc_Par_Num AND c.PDoc_Chi_Lin=a.PDoc_Par_Lin AND c.PDoc_Par_Cat= 127"
            strSql &= "                  LEFT JOIN Dcmtos_ACC t ON t.ADoc_Sis_Emp=c.PDoc_Sis_Emp AND t.ADoc_Doc_Cat=c.PDoc_Par_Cat AND t.ADoc_Doc_Ano=c.PDoc_Par_Ano AND t.ADoc_Doc_Num=c.PDoc_Par_Num AND t.ADoc_Doc_Sub='Doc_PFactura' AND t.ADoc_Doc_Lin='07'"
            strSql &= "               WHERE di.DDoc_Sis_Emp=d.DDoc_Sis_Emp AND di.DDoc_Doc_Cat=d.DDoc_Doc_Cat AND di.DDoc_Doc_Ano=d.DDoc_Doc_Ano AND di.DDoc_Doc_Num=d.DDoc_Doc_Num  LIMIT 1) contenedor,'',d.DDoc_RF2_Fec,0,0,'N/A',d.DDoc_RF3_Fec,0, 0, 0, '', NULL, 0, d.DDoc_Prd_Fob, d.DDoc_Prd_Cif,0"
            strSql &= "           FROM Dcmtos_DTL d"
            strSql &= "         LEFT JOIN Dcmtos_DTL_Pro d48 ON d48.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND d48.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND d48.PDoc_Chi_Ano=d.DDoc_Doc_Ano AND d48.PDoc_Chi_Num=d.DDoc_Doc_Num AND d48.PDoc_Chi_Lin=d.DDoc_Doc_Lin AND d48.PDoc_Par_Cat= 48   "
            strSql &= "       LEFT JOIN Dcmtos_DTL_Pro dr75 ON dr75.PDoc_Sis_Emp=d48.PDoc_Sis_Emp AND dr75.PDoc_Chi_Cat=d48.PDoc_Par_Cat AND dr75.PDoc_Chi_Ano=d48.PDoc_Par_Ano AND dr75.PDoc_Chi_Num=d48.PDoc_Par_Num AND dr75.PDoc_Chi_Lin=d48.PDoc_Par_Lin AND dr75.PDoc_Par_Cat= 75 "
            strSql &= "     LEFT JOIN Dcmtos_DTL d75 ON d75.DDoc_Sis_Emp=dr75.PDoc_Sis_Emp AND d75.DDoc_Doc_Cat=dr75.PDoc_Par_Cat AND d75.DDoc_Doc_Ano=dr75.PDoc_Par_Ano AND d75.DDoc_Doc_Num=dr75.PDoc_Par_Num AND d75.DDoc_Doc_Lin=dr75.PDoc_Par_Lin "
            strSql &= "     WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {numero}"

            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{año}", celdaAño.Text)
            strSql = Replace(strSql, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            COM.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function GuardarDescargosYarn_Movement(ByVal intAño As Integer, ByVal intNumero As Integer)
        Dim strSql As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim REA As MySqlDataReader
        Dim dblPrecio As Double
        Dim dblTotal As Double
        Dim dblCantidad As Double
        Dim intCodigo As Integer
        Dim intLinea As Integer

        Try
            'Datos del detalle
            'Validacion por factura de servicio / Por que la de servicio no tiene dtl pro con instruccion, se  crea el dtl pro con el detalle y encabezado de la factura 
            If (Sesion.idGiro = 2 Or Sesion.IdEmpresa = 14) And celdaTipoFactura.Text = 1 Then
                strSql = "INSERT INTO Dcmtos_DTL_Pro "
                strSql &= "SELECT DDoc_Sis_Emp, DDoc_Doc_Cat,  DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, 395, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, 0, h.HDOC_EMP_COD, DDoc_Prd_Cod, 0, 0, 0, DDoc_Prd_NET, DDoc_Prd_QTY, DDoc_Prd_QTY
                          FROM Dcmtos_DTL d
                          LEFT JOIN dcmtos_hdr h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp
                          AND h.HDoc_Doc_Cat=d.DDoc_Doc_Cat
                          AND h.HDoc_Doc_Ano=d.DDoc_Doc_Ano
                          AND h.HDoc_Doc_Num=d.DDoc_Doc_Num
                          WHERE d.DDoc_Sis_Emp = {empresa}
                          AND d.DDoc_Doc_Cat = 36
                          AND d.DDoc_Doc_Ano = {año}
                          AND d.DDoc_Doc_Num = {numero} ;"
            Else
                strSql = "INSERT INTO Dcmtos_DTL_Pro"
                strSql &= "  SELECT p.PDoc_Sis_Emp, p.PDoc_Chi_Cat, p.PDoc_Chi_Ano, p.PDoc_Chi_Num, p.PDoc_Chi_Lin, 395,p.PDoc_Chi_Ano, p.PDoc_Chi_Num, p.PDoc_Chi_Lin,"
                strSql &= "      p.PDoc_Clte_Cod, p.PDoc_Prov_Cod, p.PDoc_Prd_Cod, p.PDoc_Prd_PNr, p.PDoc_DR1_Num, p.PDoc_DR2_Num, p.PDoc_Prd_NET, p.PDoc_QTY_Ord, p.PDoc_QTY_Pro"
                strSql &= "          FROM Dcmtos_DTL_Pro p"
                strSql &= "             WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 36 AND p.PDoc_Chi_Ano = {año} AND p.PDoc_Chi_Num = {numero}"
            End If

            strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
            strSql = Replace(strSql, "{año}", celdaAño.Text)
            strSql = Replace(strSql, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSql, CON)
            COM.ExecuteNonQuery()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    'Guarda los bultos/cajas de este documento
    Private Function GuardarBultos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        'Const I_CAJA As Integer = 2
        'Const I_CANTIDAD As Integer = 3
        Dim varDato As String = STR_VACIO
        Dim j As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                DtlBox.BDOC_SIS_EMP = celdaEmpresa.Text
                DtlBox.BDOC_DOC_CAT = celdaTipo.Text
                DtlBox.BDOC_DOC_ANO = celdaAño.Text
                DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                If Me.Tag = "Nuevo" Then
                    If dgDetalle.Rows(i).Visible = True Then
                        j = j + 1
                    End If
                    DtlBox.BDOC_DOC_LIN = j
                Else
                    DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea2").Value
                End If
                'DtlBox.BDOC_DOC_LIN = i + 1
                DtlBox.BDOC_BOX_LIN = 1
                DtlBox.BDOC_BOX_COD = I_CODIGO
                DtlBox.BDOC_BOX_QTY = CDbl(dgDetalle.Rows(i).Cells("colBulto").Value)
                DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value


                If dgDetalle.Rows(i).Cells("colEliminar").Value = 0 And Me.Tag = "Mod" Then
                    If DtlBox.PUPDATE = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colEliminar").Value = 1 And Me.Tag = "Nuevo" Then
                    If DtlBox.PINSERT = False Then
                        MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarOperacion() As Boolean
        'Guarda el débito del documento
        Dim logResultado As Boolean = True

        Dim datFecha As Date
        Dim datVence As Date

        Dim dblDebito As Double
        Dim dblCredito As Double
        Dim dblTasa As Double

        Dim intFila As Integer
        Dim intDias As Integer

        Dim strSQL As String = STR_VACIO
        Dim strDato As String = STR_VACIO

        Dim Ectacte As New Tablas.TECTACTE
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        Try

            'Ejecuta la transacción (borrado)
            strSQL = "DELETE FROM ECtaCte "
            strSQL &= "WHERE ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {catalogo} AND ECta_Doc_Ano = {año} AND ECta_Doc_Num = {numero}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", celdaTipo.Text)
            strSQL = Replace(strSQL, "{año}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            'Escribe la operación (débito/crédito)
            intDias = PlazoDeCredito(Val(celdaIdCliente.Text))
            datFecha = dtpFecha.Value.ToString(FORMATO_MYSQL)
            datVence = DateAdd("d", intDias, datFecha)

            intFila = vbEmpty
            intFila = intFila + 1

            dblTasa = Val(celdaTasa.Text)
            dblCredito = vbEmpty
            dblDebito = vbEmpty

            If checkActivar.Checked = True Then
                'Sólo si no está anulada
                CalcularTotales()
                'dblDebito = CDbl(celdaTotal2.Text)
                dblDebito = CDbl(celdaGranTotal.Text)
            End If

            Ectacte.CONEXION = strConexion
            'Id. del documento
            Ectacte.ECTA_SIS_EMP = Val(celdaEmpresa.Text)
            Ectacte.ECTA_DOC_ANO = Val(celdaAño.Text)
            Ectacte.ECTA_DOC_CAT = Val(celdaTipo.Text)
            Ectacte.ECTA_DOC_NUM = Val(celdaNumero.Text)
            Ectacte.ECTA_DOC_LIN = intFila

            'Empresa
            Ectacte.ECTA_TIPOEMP = STR_TABLA
            Ectacte.ECTA_CODEMP = Val(celdaIdCliente.Text)

            'Cargo/Abono
            Ectacte.ECTA_SINI_LOC = vbEmpty
            Ectacte.ECTA_CRGO_LOC = (dblDebito * dblTasa)
            Ectacte.ECTA_ABNO_LOC = (dblCredito * dblTasa)
            Ectacte.ECTA_SINI_EXT = vbEmpty
            Ectacte.ECTA_CRGO_EXT = dblDebito
            Ectacte.ECTA_ABNO_EXT = dblCredito.ToString(FORMATO_MONEDA)

            For i As Integer = 0 To dgReferencia.Rows.Count - 1
                strDato = CXC_NAME & " N° " & Val(celdaNumero.Text) & "/ Refs. " & dgReferencia.Rows(i).Cells("colReference").Value
            Next

            'Concepto, vencimiento y moneda
            Ectacte.ECTA_CONCEPTO = strDato
            Ectacte.ECta_FecDcmt_NET = datFecha
            Ectacte.ECta_FecVenc_NET = datVence
            Ectacte.ECTA_MONEDA = Val(celdaIdMoneda.Text)
            Ectacte.ECTA_TC = Val(celdaTasa.Text)

            'Referencia
            Ectacte.ECTA_REF_CAT = celdaTipo.Text
            Ectacte.ECTA_REF_ANO = celdaAño.Text
            Ectacte.ECTA_REF_NUM = celdaNumero.Text

            If Me.Tag = "Mod" Then
                'If Ectacte.PUPDATE = False Then
                '    MsgBox(Ectacte.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                'End If
                ''MostrarLista(INT_UNO)
                Dim strSQL2 As String = STR_VACIO

                strSQL2 = "   UPDATE ECtaCte"
                strSQL2 &= "     SET Ecta_Crgo_Loc ={Crgo_Loc}, Ecta_AbNo_Loc ={Abno_Loc}, Ecta_Sini_Ext ={Sini_Ext},Ecta_Crgo_Ext ={Crgo_Ext}, Ecta_Abno_Ext ={Abno_Ext},"
                strSQL2 &= "     Ecta_Concepto = '{Concepto}', ECta_FecDcmt = '{FecDcmt_Net}', ECta_FecVenc = '{FecVenc_Net}', Ecta_Moneda = {Moneda}, Ecta_TC ={TC}, Ecta_Ref_Cat ={Ref_Cat},Ecta_Ref_Ano = {Ref_Ano}, Ecta_Ref_Num ={Ref_Num} "
                strSQL2 &= "          WHERE Ecta_Sis_Emp={empresa} AND Ecta_Doc_Cat=36 AND Ecta_Doc_Ano={año} AND Ecta_Doc_Num={numero} AND Ecta_Doc_Lin = {fila}"
                If Sesion.IdEmpresa = 18 Then
                    strSQL2 &= ";   UPDATE PDM.ECtaCte"
                    strSQL2 &= "     SET Ecta_Crgo_Loc ={Crgo_Loc}, Ecta_AbNo_Loc ={Abno_Loc}, Ecta_Sini_Ext ={Sini_Ext},Ecta_Crgo_Ext ={Crgo_Ext}, Ecta_Abno_Ext ={Abno_Ext},"
                    strSQL2 &= "     Ecta_Concepto = '{Concepto}', ECta_FecDcmt = '{FecDcmt_Net}', ECta_FecVenc = '{FecVenc_Net}', Ecta_Moneda = {Moneda}, Ecta_TC ={TC}, Ecta_Ref_Cat ={Ref_Cat},Ecta_Ref_Ano = {Ref_Ano}, Ecta_Ref_Num ={Ref_Num} "
                    strSQL2 &= "          WHERE Ecta_Sis_Emp={empresa} AND Ecta_Doc_Cat=36 AND Ecta_Doc_Ano={año} AND Ecta_Doc_Num={numero} AND Ecta_Doc_Lin = {fila}"
                End If

                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                strSQL2 = Replace(strSQL2, "{año}", celdaAño.Text)
                strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
                strSQL2 = Replace(strSQL2, "{TipoEmp}", STR_TABLA)
                strSQL2 = Replace(strSQL2, "{CodEmp}", celdaIdCliente.Text)
                strSQL2 = Replace(strSQL2, "{Sini_Loc}", NO_FILA)
                strSQL2 = Replace(strSQL2, "{Crgo_Loc}", (dblDebito * dblTasa))
                strSQL2 = Replace(strSQL2, "{Abno_Loc}", (dblCredito * dblTasa))
                strSQL2 = Replace(strSQL2, "{Sini_Ext}", NO_FILA)
                strSQL2 = Replace(strSQL2, "{Crgo_Ext}", dblDebito)
                strSQL2 = Replace(strSQL2, "{Abno_Ext}", dblCredito)
                strSQL2 = Replace(strSQL2, "{Concepto}", strDato)
                strSQL2 = Replace(strSQL2, "{FecDcmt_Net}", datFecha.ToString(FORMATO_MYSQL))
                strSQL2 = Replace(strSQL2, "{FecVenc_Net}", datVence.ToString(FORMATO_MYSQL))
                strSQL2 = Replace(strSQL2, "{Moneda}", celdaIdMoneda.Text)
                strSQL2 = Replace(strSQL2, "{TC}", celdaTasa.Text)
                strSQL2 = Replace(strSQL2, "{Ref_Cat}", celdaTipo.Text)
                strSQL2 = Replace(strSQL2, "{Ref_Ano}", celdaAño.Text)
                strSQL2 = Replace(strSQL2, "{Ref_Num}", celdaNumero.Text)
                strSQL2 = Replace(strSQL2, "{fila}", intFila)


                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL2, conec)
                Using conec
                    'strTemp = COM.ExecuteScalar
                    COM.ExecuteNonQuery()
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using
            Else
                If Ectacte.PINSERT = False Then
                    MsgBox(Ectacte.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
                'MostrarLista(INT_UNO)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function PlazoDeCredito(ByVal ID As Long) As Integer
        Dim strSQL As String
        Dim strTemp As String
        Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        strSQL = "   SELECT cli_plazoCR"
        strSQL &= "     FROM Clientes"
        strSQL &= "          WHERE cli_codigo = {id} AND cli_sisemp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{id}", ID)


        'COM = New MySqlCommand(strSQL, CON)
        'strTemp = COM.ExecuteScalar

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            strTemp = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        Return strTemp
    End Function

    'Comprueba si alguna de las instrucciones de despacho tiene pago de impuestos
    Private Function PagoDeImpuestos() As Boolean
        Dim i As Integer, j As Integer
        Dim strTemp As String = STR_VACIO
        Dim strSQL As String, strDato As String = STR_VACIO
        Dim logEx As Boolean, logSi As Boolean
        Dim COM As MySqlCommand
        'Dim conec As MySqlConnection

        '0 - número / 4 - año
        j = vbEmpty
        For i = vbEmpty To dgInstrucDespacho.Rows.Count - 1
            j = j + 1
            If Val(dgInstrucDespacho.Rows(i).Cells("colAñ").Value) > vbEmpty And dgInstrucDespacho.Rows(i).Visible = True Then
                strTemp = strTemp & IIf(strTemp = vbNullString, vbNullString, " OR ")
                strTemp &= "(HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero})"

                strTemp = Replace(strTemp, "{año}", Val(dgInstrucDespacho.Rows(i).Cells("colAñ").Value))
                strTemp = Replace(strTemp, "{numero}", Val(dgInstrucDespacho.Rows(i).Cells("colInst").Value))
            End If
        Next
        If Not (strTemp = vbNullString) Then
            strTemp = "HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat= 48 AND" & strTemp

            strTemp = Replace(strTemp, "{empresa}", Sesion.IdEmpresa)

            strSQL = "SELECT IFNULL(CAST(GROUP_CONCAT(CONCAT('#',HDoc_Doc_Num) SEPARATOR ', ') AS CHAR),0)"
            strSQL &= " FROM Dcmtos_HDR "
            strSQL &= "     WHERE HDoc_DR1_Emp = 1 AND " & "(" & strTemp & ")"


            'conec = New MySqlConnection(strConexion)
            'conec.Open()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            strDato = COM.ExecuteScalar
            'conec.Close()
        End If
        logSi = Not (strDato = "0")

        If logSi Then
            If Not rbNacionalizacion.Checked Then
                rbNacionalizacion.Checked = True
                MsgBox("It has changed the type of bill to nationalize", vbInformation, "Tax payment")
            End If
            logEx = True
        End If
        'logEx = True
        PagoDeImpuestos = logEx
    End Function

    Private Sub InstruccionDespachada()
        Dim strSQL As String = STR_VACIO
        Dim strInstrucciones As String = STR_VACIO
        Dim r As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Try
            r = 0
            strSQL = "Select ifnull(max(HDoc_RF2_Cod),0) carga "
            strSQL &= "From Dcmtos_HDR where HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = {cat} and HDoc_Doc_Num in({inst})"

            If dgInstrucDespacho.RowCount = 1 Then
                strInstrucciones = dgInstrucDespacho.Rows(0).Cells("colInst").Value
            Else
                For r = 0 To dgInstrucDespacho.Rows.Count - 1
                    If strInstrucciones = "0" Then
                        strInstrucciones = dgInstrucDespacho.Rows(r).Cells("colInst").Value
                    Else
                        strInstrucciones = strInstrucciones & dgInstrucDespacho.Rows(r).Cells("colInst").Value
                    End If
                Next
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cat}", 48)
            strSQL = Replace(strSQL, "{inst}", strInstrucciones)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                celdaCargado.Text = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub DatosDeCliente()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        intRefID = vbEmpty
        intRefDias = vbEmpty


        If dgInstrucDespacho.Rows.Count > vbEmpty Then
            strSQL = vbNullString
            strSQL &= "SELECT COALESCE(e.HDoc_DR1_Emp,0) id, IFNULL(c.cli_plazoCR,0) dias "
            strSQL &= "     FROM Dcmtos_DTL d "
            strSQL &= "         LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat=d.DDoc_Doc_Cat AND p.PDoc_Par_Cat= 75 AND p.PDoc_Chi_Ano=d.Ddoc_Doc_Ano AND p.PDoc_Chi_Num=d.DDoc_Doc_Num AND p.PDoc_Chi_Lin=d.DDoc_Doc_Lin "
            strSQL &= "             LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=p.PDoc_Sis_Emp AND e.HDoc_Doc_Cat=p.PDoc_Par_Cat AND e.HDoc_Doc_Ano=p.PDoc_Par_Ano AND e.HDoc_Doc_Num=p.PDoc_Par_Num"
            strSQL &= "                  LEFT JOIN Clientes c ON c.cli_sisemp=d.DDoc_Sis_Emp AND c.cli_codigo=e.HDoc_DR1_Emp"
            strSQL &= "             WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat= 48 AND d.DDoc_Doc_Ano={año} AND d.DDoc_Doc_Num={numero} "
            strSQL &= "         LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", dgInstrucDespacho.SelectedCells(1).Value)
            strSQL = Replace(strSQL, "{numero}", dgInstrucDespacho.SelectedCells(2).Value)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.Read Then
                intRefID = REA.GetInt32("id")
                intRefDias = REA.GetInt32("dias")
            End If
        Else
            strSQL = vbNullString
            strSQL &= "SELECT IFNULL(c.cli_codigo,0) id, IFNULL(c.cli_plazoCR,0) dias "
            strSQL &= "  FROM Clientes c "
            strSQL &= "       WHERE c.cli_sisemp = {empresa} AND c.cli_codigo = {idCliente}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{idCliente}", celdaIdCliente.Text)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.Read Then
                intRefID = REA.GetInt32("id")
                intRefDias = REA.GetInt32("dias")
            End If
        End If
        REA.Close()
        REA = Nothing
    End Sub
    'Obtiene la existencia para la línea
    Private Function ObtenerExistencia(ByVal ID As Integer) As Double
        Dim i As Integer
        Dim COL_KGS As String = STR_VACIO
        Dim strLineas As String = STR_VACIO
        Dim dblSaldo As Double

        For i = 0 To dgReferencia.Rows.Count - 1
            'Si la referencia corresponde a la línea
            If Val(dgReferencia.Rows(i).Cells("colInstruccion").Value) = ID Then
                COL_KGS = dgReferencia.Rows(i).Cells("colAno").Value & ","
                COL_KGS &= dgReferencia.Rows(i).Cells("colNumber").Value & ","
                COL_KGS &= dgReferencia.Rows(i).Cells("colLine").Value

                'Si no se ha sumado
                If InStr(1, strLineas, COL_KGS) = vbEmpty Then
                    dblSaldo = dblSaldo + Val(dgReferencia.Rows(i).Cells("colDisponible").Value)
                    strLineas = strLineas & vbNullChar & COL_KGS
                End If
            End If
        Next
        ObtenerExistencia = dblSaldo
    End Function

    'Actualiza la línea del detalle de la instrucción
    Private Sub ActualizarDetalle()
        'Documento: 48/Instrucción de despacho
        'Datos:     DSP/Existencia, QTY/A despachar
        Try


            Dim strSQL As String
            Dim COM As New MySqlCommand
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If Val(dgDetalle.Rows(i).Cells("colAño").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colNum").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colLinea").Value) Then
                    'Plantilla de la consulta
                    strSQL = "   UPDATE Dcmtos_DTL "
                    strSQL &= "     SET DDoc_Prd_DSP={0},DDoc_Prd_QTY={1},DDoc_RF3_Dbl={2}"
                    strSQL &= "          WHERE DDoc_Sis_Emp={3} AND DDoc_Doc_Cat={4} AND DDoc_Doc_Ano={5} AND DDoc_Doc_Num={6} AND DDoc_Doc_Lin={7}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= ";   UPDATE PDM.Dcmtos_DTL "
                        strSQL &= "     SET DDoc_Prd_DSP={0},DDoc_Prd_QTY={1},DDoc_RF3_Dbl={2}"
                        strSQL &= "          WHERE DDoc_Sis_Emp={3} AND DDoc_Doc_Cat={4} AND DDoc_Doc_Ano={5} AND DDoc_Doc_Num={6} AND DDoc_Doc_Lin={7}"
                    End If
                    'Reemplaza los parámetros de la plantilla
                    strSQL = Replace(strSQL, "{0}", ObtenerExistencia(dgDetalle.Rows(i).Cells("colNum").Value))
                    strSQL = Replace(strSQL, "{1}", CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value))
                    strSQL = Replace(strSQL, "{2}", CDbl(dgDetalle.Rows(i).Cells("colDespacho").Value))
                    strSQL = Replace(strSQL, "{3}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{4}", 48)
                    strSQL = Replace(strSQL, "{5}", dgDetalle.Rows(i).Cells("colAño").Value)
                    strSQL = Replace(strSQL, "{6}", dgDetalle.Rows(i).Cells("colNum").Value)
                    strSQL = Replace(strSQL, "{7}", dgDetalle.Rows(i).Cells("colLinea").Value)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Reescribe los registros que descargan del ingreso
    Private Sub ActualizarDescargos(ByVal intNumero As Integer)
        'Parent: 47/Ingreso a bodega
        'Child:  48/Instrucción de despacho
        'Datos:  Ord/Existencia, Pro/Descargo
        Dim i As Integer
        Dim dblCantidad As Double
        Dim intInstruccion As Integer
        Dim intLineaInstruccion As Integer
        Dim intLIneaFactura As Integer
        Dim strSQL As String
        Dim strOrden As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As New MySqlCommand
        'Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try

            'Obtiene el identificador de la fila
            For j As Integer = 0 To dgDetalle.Rows.Count - 1
                intInstruccion = dgDetalle.Rows(j).Cells("colNum").Value
                intLIneaFactura = dgDetalle.Rows(j).Cells("colLinea2").Value
                intLineaInstruccion = dgDetalle.Rows(j).Cells("colLinea").Value
                'Busca las referencias le pertenecen
                For i = 0 To dgReferencia.Rows.Count - 1

                    strSQL = " update  Dcmtos_DTL d  "
                    strSQL &= "  left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp = d.DDoc_Sis_Emp and p.PDoc_Chi_Cat = d.DDoc_Doc_Cat and p.PDoc_Chi_Ano =d.DDoc_Doc_Ano and p.PDoc_Chi_Num = d.DDoc_Doc_Num  and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
                    strSQL &= "  left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin "
                    strSQL &= "  set i.PDoc_QTY_Pro = d.DDoc_Prd_QTY "
                    strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 36 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= "; update  PDM.Dcmtos_DTL d  "
                        strSQL &= "  left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp = d.DDoc_Sis_Emp and p.PDoc_Chi_Cat = d.DDoc_Doc_Cat and p.PDoc_Chi_Ano =d.DDoc_Doc_Ano and p.PDoc_Chi_Num = d.DDoc_Doc_Num  and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
                        strSQL &= "  left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin "
                        strSQL &= "  set i.PDoc_QTY_Pro = d.DDoc_Prd_QTY "
                        strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 36 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {numero} "
                    End If
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ano}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{numero}", intNumero)


                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    COM.ExecuteNonQuery()
                    conec.Close()


                    'If dgReferencia.Rows(i).Cells("colInstruccion").Value = intInstruccion And dgReferencia.Rows(i).Cells("colLineaInstruccion").Value = intLineaInstruccion Then

                    '    'ANTERIOR: Existencia
                    '    dblCantidad = vbEmpty
                    '    If checkActivar.Checked = True Then
                    '        dblCantidad = dgReferencia.Rows(i).Cells("colDescargo").Value
                    '        If dblCantidad = vbEmpty Then
                    '            'Reversar anulación
                    '            dblCantidad = dgReferencia.Rows(i).Cells("coldisponible").Value
                    '        End If
                    '    End If

                    '    'Pantilla de la consulta de act. del descargo a ingreso
                    '    strSQL = "   UPDATE Dcmtos_DTL_Pro "
                    '    strSQL &= "     SET PDoc_QTY_Ord={0},PDoc_QTY_Pro={1}"
                    '    strSQL &= "          WHERE PDoc_Sis_Emp={2} AND PDoc_Par_Cat={3} AND PDoc_Par_Ano={4} AND PDoc_Par_Num={5} AND PDoc_Par_Lin={6} AND PDoc_Chi_Cat={7} AND PDoc_Chi_Ano={8} AND PDoc_Chi_Num={9} AND PDoc_Chi_Lin={10}"

                    '    'Reemplaza los parámetros de la plantilla de act. de ingreso
                    '    strSQL = Replace(strSQL, "{0}", CDbl(dgReferencia.Rows(i).Cells("colDescargo").Value))
                    '    strSQL = Replace(strSQL, "{1}", dblCantidad)
                    '    strSQL = Replace(strSQL, "{2}", Sesion.IdEmpresa)
                    '    strSQL = Replace(strSQL, "{3}", 47)
                    '    strSQL = Replace(strSQL, "{4}", dgReferencia.Rows(i).Cells("colAno").Value)
                    '    strSQL = Replace(strSQL, "{5}", dgReferencia.Rows(i).Cells("colNumber").Value)
                    '    strSQL = Replace(strSQL, "{6}", dgReferencia.Rows(i).Cells("colLine").Value)
                    '    strSQL = Replace(strSQL, "{7}", 48)
                    '    strSQL = Replace(strSQL, "{8}", dgDetalle.Rows(j).Cells("colAño").Value)
                    '    strSQL = Replace(strSQL, "{9}", dgReferencia.Rows(i).Cells("colInstruccion").Value)
                    '    strSQL = Replace(strSQL, "{10}", dgReferencia.Rows(i).Cells("colLineaInstruccion").Value)



                    ''Plantilla de la consulta de act. del descargo a pedido
                    'strOrden = "   UPDATE Dcmtos_DTL_Pro "
                    'strOrden &= "     SET PDoc_QTY_Pro={cantidad}"
                    'strOrden &= "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat={pedido} AND PDoc_Chi_Cat={tipo} AND PDoc_Chi_Ano={año} AND PDoc_Chi_Num={numero} AND PDoc_Chi_Lin={linea}"
                    ''Reemplaza los parámetros de la plantilla de pedido
                    'strOrden = Replace(strOrden, "{cantidad}", IIf(checkActivar.Checked = True, CDbl(dgReferencia.Rows(i).Cells("colCantDescargada").Value), vbEmpty))
                    'strOrden = Replace(strOrden, "{empresa}", Sesion.IdEmpresa)
                    'strOrden = Replace(strOrden, "{pedido}", 75)
                    'strOrden = Replace(strOrden, "{tipo}", 48)
                    'strOrden = Replace(strOrden, "{año}", dgDetalle.Rows(j).Cells("colAño").Value)
                    'strOrden = Replace(strOrden, "{numero}", dgReferencia.Rows(i).Cells("colInstruccion").Value)
                    'strOrden = Replace(strOrden, "{linea}", dgReferencia.Rows(i).Cells("colLineaInstruccion").Value)

                    ''Ejecuta la instrucción
                    'MyCnn.CONECTAR = strConexion
                    'COM = New MySqlCommand(strOrden, CON)
                    'COM.ExecuteNonQuery()
                    'End If
                Next
            Next

            'Se actualiza el DTL_Pro de la Instruccion y del Ingreso si la Factura se anula
            If checkActivar.Checked = False Then
                ActualizarPro_Instruccion()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub ActualizarPro_Instruccion()
        Dim i As Integer
        Dim dblCantidad As Double
        Dim intInstruccion As Integer
        Dim intLineaInstruccion As Integer
        Dim intLIneaFactura As Integer
        Dim strSQL As String
        Dim strOrden As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As New MySqlCommand
        'Dim COM As New MySqlCommand
        Dim conec As New MySqlConnection

        Try
            For i = 0 To dgDetalle.Rows.Count - 1
                For j As Integer = 0 To dgReferencia.Rows.Count - 1
                    'ACTUALIZACION DE PEDIDO A LA INSTRUCCION 
                    strOrden = "   UPDATE Dcmtos_DTL_Pro "
                    strOrden &= "     SET PDoc_QTY_Pro={cantidad}"
                    strOrden &= "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat={pedido} AND PDoc_Chi_Cat={tipo} AND PDoc_Chi_Ano={año} AND PDoc_Chi_Num={numero} AND PDoc_Chi_Lin={linea}"
                    If Sesion.IdEmpresa = 18 Then
                        strOrden &= ";   UPDATE PDM.Dcmtos_DTL_Pro "
                        strOrden &= "     SET PDoc_QTY_Pro={cantidad}"
                        strOrden &= "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat={pedido} AND PDoc_Chi_Cat={tipo} AND PDoc_Chi_Ano={año} AND PDoc_Chi_Num={numero} AND PDoc_Chi_Lin={linea}"
                    End If
                    'Reemplaza los parámetros de la plantilla de pedido
                    strOrden = Replace(strOrden, "{cantidad}", IIf(checkActivar.Checked = True, CDbl(dgReferencia.Rows(i).Cells("colCantDescargada").Value), INT_CERO))
                    strOrden = Replace(strOrden, "{empresa}", Sesion.IdEmpresa)
                    strOrden = Replace(strOrden, "{pedido}", 75)
                    strOrden = Replace(strOrden, "{tipo}", 48)
                    strOrden = Replace(strOrden, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
                    strOrden = Replace(strOrden, "{numero}", dgReferencia.Rows(j).Cells("colInstruccion").Value)
                    strOrden = Replace(strOrden, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strOrden, CON)
                    COM.ExecuteNonQuery()


                    'ACTUALIZACION DEL INGRESO A LA INSTRUCCION
                    dblCantidad = vbEmpty
                    If checkActivar.Checked = True Then
                        dblCantidad = dgReferencia.Rows(i).Cells("colDescargo").Value
                        If dblCantidad = vbEmpty Then
                            'Reversar anulación
                            dblCantidad = dgReferencia.Rows(i).Cells("coldisponible").Value
                        End If
                    End If

                    strSQL = "   UPDATE Dcmtos_DTL_Pro "
                    strSQL &= "     SET PDoc_QTY_Ord={0},PDoc_QTY_Pro={1}"
                    strSQL &= "          WHERE PDoc_Sis_Emp={2} AND PDoc_Par_Cat={3} AND PDoc_Par_Ano={4} AND PDoc_Par_Num={5} AND PDoc_Par_Lin={6} AND PDoc_Chi_Cat={7} AND PDoc_Chi_Ano={8} AND PDoc_Chi_Num={9} AND PDoc_Chi_Lin={10}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= ";   UPDATE PDM.Dcmtos_DTL_Pro "
                        strSQL &= "     SET PDoc_QTY_Ord={0},PDoc_QTY_Pro={1}"
                        strSQL &= "          WHERE PDoc_Sis_Emp={2} AND PDoc_Par_Cat={3} AND PDoc_Par_Ano={4} AND PDoc_Par_Num={5} AND PDoc_Par_Lin={6} AND PDoc_Chi_Cat={7} AND PDoc_Chi_Ano={8} AND PDoc_Chi_Num={9} AND PDoc_Chi_Lin={10}"
                    End If
                    'Reemplaza los parámetros de la plantilla de act. de ingreso
                    strSQL = Replace(strSQL, "{0}", CDbl(dgReferencia.Rows(i).Cells("colDescargo").Value))
                    strSQL = Replace(strSQL, "{1}", dblCantidad)
                    strSQL = Replace(strSQL, "{2}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{3}", 47)
                    strSQL = Replace(strSQL, "{4}", dgReferencia.Rows(i).Cells("colAno").Value)
                    strSQL = Replace(strSQL, "{5}", dgReferencia.Rows(i).Cells("colNumber").Value)
                    strSQL = Replace(strSQL, "{6}", dgReferencia.Rows(i).Cells("colLine").Value)
                    strSQL = Replace(strSQL, "{7}", 48)
                    strSQL = Replace(strSQL, "{8}", dgDetalle.Rows(j).Cells("colAño").Value)
                    strSQL = Replace(strSQL, "{9}", dgReferencia.Rows(i).Cells("colInstruccion").Value)
                    strSQL = Replace(strSQL, "{10}", dgReferencia.Rows(i).Cells("colLineaInstruccion").Value)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                Next
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub ActualizarBultos()
        'Const I_CAJA As Integer
        'Const I_CANTIDAD As Integer

        Dim strSQL As String
        Dim varFila As Object = STR_VACIO
        Dim varDato As Object = STR_VACIO
        Dim COM As New MySqlCommand

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If Val(dgDetalle.Rows(i).Cells("colAño").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colNum").Value) > vbEmpty And Val(dgDetalle.Rows(i).Cells("colLinea").Value) > vbEmpty Then

                'Plantilla de la consulta
                strSQL = "   UPDATE Dcmtos_DTL_Box  "
                strSQL &= "     SET BDoc_Box_QTY={0}, BDoc_Box_LB={1}"
                strSQL &= "          WHERE BDoc_Sis_Emp={2} AND BDoc_Doc_Cat={3} AND BDoc_Doc_Ano={4} AND BDoc_Doc_Num={5} AND BDoc_Doc_Lin={6} AND BDoc_Box_Lin=1"
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= ";   UPDATE PDM.Dcmtos_DTL_Box  "
                    strSQL &= "     SET BDoc_Box_QTY={0}, BDoc_Box_LB={1}"
                    strSQL &= "          WHERE BDoc_Sis_Emp={2} AND BDoc_Doc_Cat={3} AND BDoc_Doc_Ano={4} AND BDoc_Doc_Num={5} AND BDoc_Doc_Lin={6} AND BDoc_Box_Lin=1"
                End If
                'Reemplaza los parámetros de la plantilla
                strSQL = Replace(strSQL, "{0}", dgDetalle.Rows(i).Cells("colBulto").Value)
                strSQL = Replace(strSQL, "{1}", CInt(dgDetalle.Rows(i).Cells("colCantidad").Value))
                strSQL = Replace(strSQL, "{2}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{3}", 48)
                strSQL = Replace(strSQL, "{4}", dgDetalle.Rows(i).Cells("colAño").Value)
                strSQL = Replace(strSQL, "{5}", dgDetalle.Rows(i).Cells("colNum").Value)
                strSQL = Replace(strSQL, "{6}", dgDetalle.Rows(i).Cells("colLinea").Value)

                'Ejecuta la instrucción
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
            End If
        Next

    End Sub

    'Actualiza el valor descargado en el Kardex para la línea de la instrucción
    Private Sub RegistrarExistencia()
        'Documento: 48/Instrucción de despacho

        Dim COM2 As New MySqlCommand
        Dim conec As MySqlConnection
        Dim conec2 As MySqlConnection
        Dim conec3 As MySqlConnection
        Dim dblBultos As Double
        Dim lngId As Long
        Dim Existencia As Integer
        Dim Exis As New Tablas.TEXISTENCIA

        Dim strSQL As String = STR_VACIO
        Dim strSQL1 As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            'Determina la cantidad de bultos (para esta línea)
            dblBultos = vbEmpty

            'Sólo si el documento está activo
            strSQL = "  SELECT Ex_Doc_Num numero, Ex_Doc_Fec fecha, Ex_Doc_Lin linea, Ex_Id ID, Ex_Articulo articulo, Ex_Codigo codigo, Ex_Descripcion descripcion,  Ex_Pais pais, Ex_Referencia referencia, Ex_Lote lote, Ex_Ciclo ciclo, Ex_Semana semana, Ex_UM UM, Ex_Egreso egreso, Ex_Costo costo, Ex_Total total"
            strSQL &= "     FROM Existencia"
            strSQL &= "          WHERE Ex_Doc_Emp={empresa} AND Ex_Doc_Tipo={tipo} AND Ex_Doc_Ciclo={año} AND Ex_Doc_Num={numero} AND Ex_Doc_Lin={linea}"

            'Reemplaza los parámetros de la plantilla
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{tipo}", 48) '/Instruccion de Despacho
            strSQL = Replace(strSQL, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
            strSQL = Replace(strSQL, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
            strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLinea").Value)


            'strSQL = " select cat_desc descripcion from Catalogos where cat_num =1"

            ''Ejecuta la instrucción
            conec = New MySqlConnection
            conec.ConnectionString = strConexion
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader
            conec.Close()

            ''Verifica si la factura ha escrito en existencia
            strSQL2 = "  SELECT COUNT(*)  "
            strSQL2 &= "     FROM Existencia "
            strSQL2 &= "          WHERE Ex_Doc_Emp={empresa} AND Ex_Doc_Tipo={tipo} AND Ex_Doc_Ciclo={año} AND Ex_Doc_Num={numero} AND Ex_Doc_Lin={linea}"

            'Reemplaza los parámetros de la plantilla
            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{tipo}", 36) '/Facturación
            strSQL2 = Replace(strSQL2, "{año}", dgDetalle.Rows(i).Cells("colAño").Value)
            strSQL2 = Replace(strSQL2, "{numero}", dgDetalle.Rows(i).Cells("colNum").Value)
            strSQL2 = Replace(strSQL2, "{linea}", i + 1)

            conec2 = New MySqlConnection(strConexion)
            conec2.Open()
            COM = New MySqlCommand(strSQL2, conec2)
            Using conec2
                Existencia = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec2.Close()
                conec2.Dispose()
                conec2 = Nothing
                System.GC.Collect()
            End Using

            'Si no hay registros en existencia, los escribe con los valores de la instrucción
            Try
                If Existencia = 0 Then

                    strSQL1 = "SELECT (IFNULL(MAX(Ex_Id),0) + 1) ID FROM Existencia"
                    conec3 = New MySqlConnection(strConexion)
                    conec3.Open()
                    COM = New MySqlCommand(strSQL1, conec3)
                    Using conec3
                        lngId = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec3.Close()
                        conec3.Dispose()
                        conec3 = Nothing
                        System.GC.Collect()
                    End Using

                    If REA.HasRows Then
                        Do While REA.Read
                            Exis.EX_DOC_EMP = Sesion.IdEmpresa
                            Exis.EX_DOC_TIPO = 36
                            Exis.EX_DOC_CICLO = Val(celdaAño.Text)
                            Exis.EX_DOC_NUM = Val(celdaNumero.Text)
                            Exis.Ex_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
                            Exis.EX_DOC_LIN = i + 1
                            Exis.Ex_Fec_NET = cFunciones.HoyMySQL
                            Exis.EX_ID = lngId
                            Exis.EX_ARTICULO = REA.GetInt32("articulo")
                            Exis.EX_CODIGO = REA.GetInt32("codigo")
                            Exis.EX_DESCRIPCION = REA.GetString("descripcion")
                            Exis.EX_PAIS = REA.GetString("pais")
                            Exis.EX_REFERENCIA = REA.GetString("referencia")
                            Exis.EX_LOTE = REA.GetString("lote")
                            Exis.EX_CICLO = REA.GetInt32("ciclo")
                            Exis.EX_SEMANA = REA.GetInt32("semana")
                            Exis.EX_UM = REA.GetInt32("UM")
                            Exis.EX_INGRESO = vbEmpty
                            Exis.EX_EGRESO = REA.GetDouble("egreso")
                            Exis.EX_BULTOS = dblBultos
                            Exis.EX_MONEDA = Val(celdaIdMoneda.Text)
                            Exis.EX_TC = Val(celdaTasa.Text)
                            Exis.EX_COSTO = REA.GetDouble("costo")
                            Exis.EX_TOTAL = REA.GetDouble("total")

                            lngId = lngId + 1
                        Loop
                    End If
                End If
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        Next

    End Sub

    'Reescribe los registros de las instrucciones de despacho
    Private Sub ReescribirInstruccion(ByVal intNumero As Integer)
        If Sesion.idGiro = 1 Then
            'Actualiza el detalle
            ActualizarDetalle()
            'Actualiza los registros en DTL Pro
            ActualizarDescargos(intNumero)
            'Actualizar bultos
            ActualizarBultos()
        End If
        'Actualiza el valor descargado en el Kardex
        RegistrarExistencia()

        'Actualiza el estado de las instrucciones afectadas
        ActualizarEstado()
    End Sub

    'Actualiza el estado de las 48/instrucciónes de acuerdo al estado de la factura
    Private Sub ActualizarEstado()
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim COM2 As New MySqlCommand
        Dim Conec As New MySqlConnection

        'Selecciona las instrucciones atendidas por esta factura
        strSQL = "SELECT p.PDoc_Par_Cat, p.PDoc_Par_Ano, p.PDoc_Par_Num"
        strSQL &= " FROM Dcmtos_DTL_Pro p WHERE p.PDoc_Sis_Emp={empresa} AND p.PDoc_Chi_Cat={tipo} AND p.PDoc_Chi_Ano={año} AND p.PDoc_Chi_Num={numero}"
        strSQL &= "     GROUP BY p.PDoc_Par_Cat, p.PDoc_Par_Ano, p.PDoc_Par_Num"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", celdaTipo.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader


        Try
            If REA.HasRows Then
                Do While REA.Read
                    'Acturaliza la instrucción
                    strTemp = " UPDATE Dcmtos_HDR h SET h.HDoc_Doc_Status={estado}"
                    strTemp &= "    WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat={tipo} AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                    If Sesion.IdEmpresa = 18 Then
                        strTemp &= "; UPDATE PDM.Dcmtos_HDR h SET h.HDoc_Doc_Status={estado}"
                        strTemp &= "    WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat={tipo} AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                    End If

                    strTemp = Replace(strTemp, "{estado}", IIf(checkActivar.Checked = True, 1, 0))
                    strTemp = Replace(strTemp, "{empresa}", Sesion.IdEmpresa)
                    strTemp = Replace(strTemp, "{tipo}", REA.GetInt32("PDoc_Par_Cat"))
                    strTemp = Replace(strTemp, "{año}", REA.GetInt32("PDoc_Par_Ano"))
                    strTemp = Replace(strTemp, "{numero}", REA.GetInt32("PDoc_Par_Num"))

                    Conec = New MySqlConnection
                    Conec.ConnectionString = strConexion
                    Conec.Open()
                    COM2 = New MySqlCommand(strTemp, Conec)
                    COM2.ExecuteNonQuery()
                    Conec.Close()
                    Conec.Dispose()
                    Conec = Nothing
                    System.GC.Collect()
                Loop
            End If
            REA.Close()
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Actualiza el listado de referencias
    Private Sub ActualizarLista()
        Dim i As Integer
        Dim dblSaldo As Double
        Dim strLineas As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strTemp As String
        Dim COM As MySqlCommand
        Dim arrayFila() As String
        'Dim frmLista As frmFacturasRef_Aux_
        Dim j As Integer
        Dim lstLineas As String
        Dim lstDatos As String = STR_VACIO
        Dim lstDatos1 As String = STR_VACIO
        Dim lstDatos2 As String = STR_VACIO
        Dim lstDatos3 As String = STR_VACIO
        'Si hay referencias
        Try


            If (dgReferencia.ColumnCount > vbEmpty) Then
                For i = 0 To dgReferencia.Rows.Count - 1
                    'Si no se tiene el saldo actual
                    If dgReferencia.Rows(i).Cells("colAmount").Value = vbNullString Then
                        'Identificador de ingreso a bodega
                        strTemp = dgReferencia.Rows(i).Cells("colAno").Value & ","
                        strTemp &= dgReferencia.Rows(i).Cells("colNumber").Value & ","

                        If dgReferencia.Rows.Count = 1 Then
                            strTemp &= dgReferencia.Rows(i).Cells("colLine").Value & "," & "{saldo}"
                        Else
                            strTemp &= dgReferencia.Rows(i).Cells("colLine").Value & "," & "{saldo}" & "|"
                        End If


                        'Si no está en el listado
                        If InStr(1, strLineas, strTemp) = vbEmpty Then
                            strSQL = " SELECT d.DDoc_Prd_QTY -"
                            strSQL &= "     COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
                            strSQL &= "         FROM Dcmtos_DTL_Pro p"
                            strSQL &= "              WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND"
                            strSQL &= "               p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0) Saldo"
                            strSQL &= "     FROM Dcmtos_DTL d"
                            strSQL &= "          WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND"
                            strSQL &= "              d.DDoc_Doc_Cat = 47 AND"
                            strSQL &= "              d.DDoc_Doc_Ano = " & dgReferencia.Rows(i).Cells("colAno").Value & " AND"
                            strSQL &= "              d.DDoc_Doc_Num = " & dgReferencia.Rows(i).Cells("colNumber").Value & " AND"
                            strSQL &= "               d.DDoc_Doc_Lin = " & dgReferencia.Rows(i).Cells("colLine").Value & ""
                        End If
                        'Obtiene el saldo para la línea del documento de referencia
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        dblSaldo = COM.ExecuteScalar()

                        'Agrega la línea
                        If Not (strLineas = vbNullString) Then
                            strLineas = strLineas
                        End If
                        strLineas = strLineas & Replace(strTemp, "{saldo}", dblSaldo)
                    End If
                Next

                If Not (strLineas = vbNullString) Then
                    Dim arrayFila2() As String
                    arrayFila2 = strLineas.Split("|".ToCharArray)
                    For k As Integer = 0 To arrayFila2.Length - 1
                        'Actualiza las líneas de las referencias
                        For j = vbEmpty To dgReferencia.Rows.Count - 1
                            If arrayFila2(k) = vbNullString Then
                                strLineas = STR_VACIO
                                Exit Sub
                            End If
                            lstLineas = arrayFila2(k)
                            'If lstLineas = strLineas Then
                            arrayFila = lstLineas.Split(",".ToArray)
                            'For m As Integer = 0 To arrayFila.Length - 1
                            lstDatos = arrayFila(0)
                            lstDatos1 = arrayFila(1)
                            lstDatos2 = arrayFila(2)
                            lstDatos3 = arrayFila(3)

                            If dgReferencia.Rows(j).Cells("colAno").Value = lstDatos And
                               dgReferencia.Rows(j).Cells("colNumber").Value = lstDatos1 And
                               dgReferencia.Rows(j).Cells("colLine").Value = lstDatos2 Then
                                'Asigna el saldo actual
                                dgReferencia.Rows(j).Cells("colAmount").Value = lstDatos3
                                'Asigna la existencia actualizada
                                dblSaldo = (lstDatos3 + Val(dgReferencia.Rows(j).Cells("colDescargo").Value))
                                dgReferencia.Rows(j).Cells("colDisponible").Value = dblSaldo
                            End If
                            ' End If
                        Next
                    Next
                End If
                strLineas = STR_VACIO

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Devuelve la consulta de selección con los documentos por procesar
    Public Function SqlGetDocumentsList(Optional Clase As Boolean = False, Optional Codigo As Boolean = False, Optional Estado As Boolean = True, Optional Actual As Boolean = False, Optional Alia As Boolean = False, Optional Saldo As Boolean = True, Optional curDoc As Integer = vbEmpty) As String
        'Parámetros: empresa, tipo, clase, codigo, estado
        Dim strSQL As String

        strSQL = vbNullString
        strSQL = " SELECT DISTINCT"

        If Alia Then
            strSQL &= " a.HDoc_Sis_Emp empresa, a.HDoc_Doc_Cat tipo, a.HDoc_Doc_Ano año, a.HDoc_Doc_Num numero, a.HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, a.HDoc_Usuario usuario, a.HDoc_RF1_Dbl Total, IFNULL(a.HDoc_DR2_Emp,0) EmpPagadora, IFNULL(c.cli_cliente,'') NomPagador"
            'strSQL &= " HDoc_Sis_Emp empresa, HDoc_Doc_Cat tipo, HDoc_Doc_Ano año, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, COALESCE(HDoc_DR1_Num,'') referencia, HDoc_Usuario usuario, HDoc_RF1_Dbl Total "
        Else
            strSQL &= " a.HDoc_Sis_Emp, a.HDoc_Doc_Cat, a.HDoc_Doc_Ano, a.HDoc_Doc_Num, a.HDoc_Doc_Fec, COALESCE(HDoc_DR1_Num,'') HDoc_DR1_Num, a.HDoc_Usuario, a.HDoc_RF1_Dbl Total, IFNULL(a.HDoc_DR2_Emp,0) EmpPagadora, IFNULL(c.cli_cliente,'') NomPagador"
            'strSQL &= " HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Doc_Fec, COALESCE(HDoc_DR1_Num,'') HDoc_DR1_Num, HDoc_Usuario, HDoc_RF1_Dbl Total "
        End If

        strSQL &= "  FROM Dcmtos_HDR a"
        strSQL &= "     LEFT JOIN Dcmtos_DTL b  ON a.HDoc_Sis_Emp  = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat  = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano  = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num  = b.DDoc_Doc_Num"
        strSQL &= "                      LEFT JOIN Clientes c ON c.cli_sisemp = a.HDoc_Sis_Emp AND c.cli_codigo = a.HDoc_DR2_Emp "
        strSQL &= "         WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = {tipo}) AND HDoc_Doc_Fec<='{fechafiltro}'"

        If Clase Then
            'Clase: importación, devolución, transferencia
            strSQL &= " AND COALESCE(HDoc_DR1_Cat,0) = {clase}"
        End If

        If Codigo Then
            'Estado del documento
            strSQL &= "  AND (HDoc_Emp_Cod = {codigo})"
        End If

        If Estado Then
            'Estado del documento
            strSQL &= "  AND HDoc_Doc_Status = 1"
        End If


        If Saldo Then
            'Sólo documentos con saldo
            strSQL &= "  AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
            strSQL &= "      FROM Dcmtos_DTL_Pro c"
            strSQL &= "          WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin"

            If Actual Then
                'Documento que descarga (actual)
                strSQL &= " AND c.PDoc_Chi_Cat = {actual}"
            End If

            If curDoc = 36 Then
                strSQL &= "), 0) < (b.DDoc_RF3_Dbl + b.DDoc_Prd_Cif ))"
            Else
                strSQL &= "), 0) < b.DDoc_Prd_QTY)"
            End If
        End If

        strSQL &= "  ORDER BY HDoc_Doc_Ano ASC, HDoc_Doc_Num ASC"

        'Devuelve el resultado
        SqlGetDocumentsList = strSQL
    End Function

    Private Function SqlDocsPorProcesar() As String
        Dim strSQL As String

        strSQL = SqlGetDocumentsList(False, True, True, True, , , 36)

        'Reemplazar parámetros
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", 48)
        strSQL = Replace(strSQL, "{codigo}", celdaIdCliente.Text)
        strSQL = Replace(strSQL, "{actual}", 36)
        strSQL = Replace(strSQL, "{fechaFiltro}", dtpFecha.Value.ToString(FORMATO_MYSQL))
        SqlDocsPorProcesar = strSQL

    End Function

    Private Function SqlDocumentosProcesados() As String
        Dim wSql As String

        wSql = "  SELECT DISTINCT"
        wSql &= "    HDoc_Doc_Cat,"
        wSql &= "    HDoc_Doc_Ano,"
        wSql &= "    HDoc_Doc_Num,"
        wSql &= "    HDoc_Doc_Fec,"
        wSql &= "    HDoc_DR1_Num,"
        wSql &= "    HDoc_Usuario,"
        wSql &= " WHERE"
        wSql &= "    Dcmtos_DTL_Pro a"
        wSql &= "    INNER JOIN"
        wSql &= "      Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND"
        wSql &= "      a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND"
        wSql &= "      a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND"
        wSql &= "      a.PDoc_Par_Num = b.HDoc_Doc_Num"
        wSql &= " WHERE"
        wSql &= "      a.PDoc_Sis_Emp = {empresa} AND"
        wSql &= "       a.PDoc_Chi_Ano = {Año} AND"
        wSql &= "       a.PDoc_Par_Cat = 36 "

        wSql = Replace(wSql, "{Año}", celdaAño.Text)
        wSql = Replace(wSql, "{empresa}", Sesion.IdEmpresa)

        SqlDocumentosProcesados = wSql

    End Function

    Private Sub ListarDocumentos()
        Dim strSQL As String
        Dim strTemp As String
        Dim intAño As Integer
        Dim intNumero As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        intAño = celdaAño.Text
        intNumero = celdaNumero.Text
        'dgInstrucDespacho.ColumnCount = vbEmpty
        If Me.Tag = "Mod" Then
            strSQL = SqlDocumentosProcesados()
        Else
            strSQL = SqlDocsPorProcesar()
        End If

        'Agrega todos los registros de la selección
        MyCnn.CONECTAR = strConexion
        Try

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read

                strTemp = vbNullString
                strTemp &= REA.GetInt32("HDoc_Doc_Cat") & "|"
                strTemp &= REA.GetInt32("HDoc_Doc_Ano") & "|"
                strTemp &= REA.GetString("HDoc_Doc_Num") & "|"
                strTemp &= REA.GetDateTime("HDoc_Doc_Fec") & "|"
                strTemp &= REA.GetString("HDoc_Usuario") & "|"
                strTemp &= REA.GetString("HDoc_DR1_Num") & "|"
                strTemp &= 1

                cFunciones.AgregarFila(dgInstrucDespacho, strTemp)

                celdaEmpPagadora.Text = REA.GetString("NomPagador")
                celdaIDEmpPagadora.Text = REA.GetInt32("EmpPagadora")
            Loop
            REA.Close()
            REA = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Carga el detalle de los documentos del cliente que estén en el listado
    Private Sub ProcesarDocumentos()
        Me.Tag = "Nuevo"
        Dim i As Integer
        Dim strTemp As String
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim dblDescuentoMoney As Double = 0
        Dim dblDescuentoPorcentaje As Double = 0
        Dim dblDescuentoPrecio As Double = 0


        dgDetalle.Rows.Clear()

        If dgInstrucDespacho.RowCount > 5 Then
            If MsgBox("¿Show details of all documents in the list?", vbQuestion + vbYesNo + vbDefaultButton2, "Documents Detail") = vbNo Then
                Exit Sub
            End If
        End If

        For i = 0 To dgInstrucDespacho.Rows.Count - 1
            If dgInstrucDespacho.ColumnCount > vbEmpty Then
                If Not (dgInstrucDespacho.Rows(0).Cells(0).Value) = vbNullString Then
                    strSQL = SqlDetallePorProcesar()
                End If
            End If
            MyCnn.CONECTAR = strConexion
            Try
                dgDetalle.Rows.Clear()
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                Do While REA.Read

                    strTemp = REA.GetInt32("Numero") & "|"
                    strTemp &= REA.GetInt32("Codigo") & "|"
                    strTemp &= REA.GetInt32("Ano") & "|"
                    strTemp &= REA.GetInt32("Linea") & "|"
                    strTemp &= REA.GetInt32("Linea") & "|"
                    strTemp &= REA.GetString("Descripcion") & "|"
                    strTemp &= REA.GetInt32("Base") & "|"
                    strTemp &= REA.GetString("Medida") & "|"
                    strTemp &= REA.GetDouble("Despacho") & "|"
                    strTemp &= REA.GetDouble("Precio") & "|"
                    If Sesion.IdEmpresa = 11 Or (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 16 And Pais() = 310) Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                        dblDescuentoPrecio = (REA.GetDouble("Precio") - REA.GetDouble("precioPF"))
                        If dblDescuentoPrecio <= 0 Then
                            strTemp &= "0.00" & "|" ' Descuento en Porcentaje
                            strTemp &= "0.00" & "|" ' Descuento en $
                        Else
                            dblDescuentoMoney = ((dblDescuentoPrecio) * REA.GetDouble("Cantidad"))
                            dblDescuentoPorcentaje = ((dblDescuentoMoney / REA.GetDouble("Total")) * 100)
                            strTemp &= dblDescuentoPorcentaje.ToString(FORMATO_MONEDA) & "|" ' Descuento en Porcentaje
                            strTemp &= dblDescuentoMoney.ToString(FORMATO_MONEDA) & "|" ' Descuento en $
                        End If
                    Else
                        strTemp &= "0.00" & "|" ' Descuento en Porcentaje
                        strTemp &= "0.00" & "|" ' Descuento en $
                    End If
                    strTemp &= REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= REA.GetDouble("Total").ToString("###0.00") & "|"
                    strTemp &= "0" & "|"
                    strTemp &= REA.GetString("Bulto") & "|"
                    strTemp &= REA.GetInt32("Bobinas") & "|"
                    strTemp &= REA.GetString("Distribucion") & "|"
                    strTemp &= REA.GetInt32("Destino") & "|"
                    strTemp &= REA.GetString("Lugar") & "|"
                    strTemp &= REA.GetDouble("Libras").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= REA.GetDouble("Kilos").ToString(FORMATO_MONEDA) & "|"
                    If REA.GetString("Medida") = "LBS" Then
                        strTemp &= (REA.GetDouble("Cantidad") / 2.2046).ToString(FORMATO_MONEDA) & "|"
                        strTemp &= (REA.GetDouble("Cantidad") / 2.2046).ToString(FORMATO_MONEDA_EXT) & "|"
                    Else
                        strTemp &= (REA.GetDouble("Cantidad")).ToString(FORMATO_MONEDA) & "|"
                        strTemp &= (REA.GetDouble("Cantidad")).ToString(FORMATO_MONEDA_EXT) & "|"
                    End If
                    strTemp &= REA.GetInt32("Original") & "|"
                    strTemp &= REA.GetString("Referencia") & "|"
                    strTemp &= REA.GetInt32("Base") & "|"
                    strTemp &= REA.GetDouble("precioPF") & "|"
                    strTemp &= "1"

                    cFunciones.AgregarFila(dgDetalle, strTemp)
                Loop
                REA.Close()
                REA = Nothing

                'dgDetalle.Columns("colBulto").ReadOnly = False
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Next

        'Limpia el listado de referencias
        dgReferencia.Rows.Clear()

        If dgDetalle.ColumnCount > vbEmpty Then
            'Cargar Info. del DTL Pro
            sqlCargarRelacion()
        End If
        If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
            For j As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                ActualizarBultosPorLinea(dgInstrucDespacho.Rows(j).Cells("colAñ").Value, dgInstrucDespacho.Rows(j).Cells("colInst").Value)

            Next
        End If

        'Actualiza el saldo del listado de referencias
        ActualizarLista()

        CalcularTotales()
        CalcularSeguro()

    End Sub

    Private Function SqlDetallePorProcesar() As String
        Dim strSQL As String


        strSQL = vbNullString
        'strSQL &= " SELECT d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, 0 Id,"
        'strSQL &= "      d.DDoc_Prd_Cod Codigo, IF(COALESCE(a.art_desc,'')='',d.DDoc_Prd_Des,a.art_desc) Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte,"
        'strSQL &= "      d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, "
        'strSQL &= "     (SELECT IF(d.DDoc_Prd_UM = 69, dt.DDoc_Prd_NET, IF(dt.DDoc_Prd_Cif > 0, dt.DDoc_Prd_Cif,(dt.DDoc_Prd_NET * 2.2046))) "
        'strSQL &= "        From Dcmtos_DTL_Pro t "
        'strSQL &= "        Left JOIN Dcmtos_DTL dt ON dt.DDoc_Sis_Emp = t.PDoc_Sis_Emp AND dt.DDoc_Doc_Cat = t.PDoc_Par_Cat AND dt.DDoc_Doc_Ano = t.PDoc_Par_Ano AND dt.DDoc_Doc_Num = t.PDoc_Par_Num AND dt.DDoc_Doc_Lin = t.PDoc_Par_Lin "
        'strSQL &= "        WHERE t.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND t.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND t.PDoc_Chi_Num = d.DDoc_Doc_Num AND t.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND t.PDoc_Par_Cat = 75) precioPF, "
        'strSQL &= "      m.cat_clave Medida, COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) Despacho, (IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) * d.DDoc_Prd_NET) Total,"
        'strSQL &= "      '' Bulto, 0 Bobinas, '' Distribucion, COALESCE(l.cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, "
        'strSQL &= "      0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad,"
        'strSQL &= "      ((d.DDoc_Prd_QTY + d.DDoc_Prd_Cif) - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
        'strSQL &= "         FROM Dcmtos_DTL_Pro p"
        'strSQL &= "         WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND"
        'strSQL &= "          p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND"
        'strSQL &= "          p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0)) Cantidad"
        'strSQL &= "    FROM Dcmtos_DTL d"
        'strSQL &= "         LEFT JOIN Catalogos   m ON m.cat_clase  = 'Medidas'      AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        'strSQL &= "         LEFT JOIN Clientes    l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        'strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        'strSQL &= "         LEFT JOIN Articulos   a ON a.art_sisemp = i.inv_sisemp   AND a.art_codigo = i.inv_artcodigo"
        'strSQL &= "    WHERE d.DDoc_Sis_Emp = {empresa} AND"
        'strSQL &= "             d.DDoc_Doc_Cat = {documento} {lista}"
        'strSQL &= "    HAVING (Cantidad > 0)"
        'strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = "SELECT d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, 0 Id,
              d.DDoc_Prd_Cod Codigo, IF(COALESCE(a.art_desc,'')='',d.DDoc_Prd_Des,a.art_desc) Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte,
              d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, 
             (SELECT IF(d.DDoc_Prd_UM = 69, dt.DDoc_Prd_NET, IF(dt.DDoc_Prd_Cif > 0, dt.DDoc_Prd_Cif,(dt.DDoc_Prd_NET * 2.2046))) 
                From Dcmtos_DTL_Pro t 
                Left JOIN Dcmtos_DTL dt ON dt.DDoc_Sis_Emp = t.PDoc_Sis_Emp AND dt.DDoc_Doc_Cat = t.PDoc_Par_Cat AND dt.DDoc_Doc_Ano = t.PDoc_Par_Ano AND dt.DDoc_Doc_Num = t.PDoc_Par_Num AND dt.DDoc_Doc_Lin = t.PDoc_Par_Lin 
                WHERE t.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND t.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND t.PDoc_Chi_Num = d.DDoc_Doc_Num AND t.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND t.PDoc_Par_Cat = 75) precioPF, 
              m.cat_clave Medida, COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) Despacho, (IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) * d.DDoc_Prd_NET) Total,
              '' Bulto, 0 Bobinas, '' Distribucion, COALESCE(l.cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, 
              0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad,
              ((d.DDoc_Prd_QTY + d.DDoc_Prd_Cif) - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)
                 FROM Dcmtos_DTL_Pro p
                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND
                  p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND
                  p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0)) Cantidad
            FROM Dcmtos_DTL d
                 LEFT JOIN Catalogos   m ON m.cat_clase  = 'Medidas'      AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)
                 LEFT JOIN Clientes    l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num
                 LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                 LEFT JOIN Articulos   a ON a.art_sisemp = i.inv_sisemp   AND a.art_codigo = i.inv_artcodigo
            WHERE d.DDoc_Sis_Emp = {empresa} AND
                     d.DDoc_Doc_Cat = {documento} {lista}
            HAVING (Cantidad > 0)
             ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 48)
        strSQL = Replace(strSQL, "{lista}", SqlSeleccionados())

        SqlDetallePorProcesar = strSQL

    End Function

    Private Function SqlDetallePorProcesar2() As String
        Dim strSQL As String


        strSQL = vbNullString
        'strSQL &= " SELECT d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, 0 Id,"
        'strSQL &= "      d.DDoc_Prd_Cod Codigo, IF(COALESCE(a.art_desc,'')='',d.DDoc_Prd_Des,a.art_desc) Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte,"
        'strSQL &= "      d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, "
        'strSQL &= "     (SELECT IF(d.DDoc_Prd_UM = 69, dt.DDoc_Prd_NET, IF(dt.DDoc_Prd_Cif > 0, dt.DDoc_Prd_Cif,(dt.DDoc_Prd_NET * 2.2046))) "
        'strSQL &= "        From Dcmtos_DTL_Pro t "
        'strSQL &= "        Left JOIN Dcmtos_DTL dt ON dt.DDoc_Sis_Emp = t.PDoc_Sis_Emp AND dt.DDoc_Doc_Cat = t.PDoc_Par_Cat AND dt.DDoc_Doc_Ano = t.PDoc_Par_Ano AND dt.DDoc_Doc_Num = t.PDoc_Par_Num AND dt.DDoc_Doc_Lin = t.PDoc_Par_Lin "
        'strSQL &= "        WHERE t.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND t.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND t.PDoc_Chi_Num = d.DDoc_Doc_Num AND t.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND t.PDoc_Par_Cat = 75) precioPF, "
        'strSQL &= "      m.cat_clave Medida, COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) Despacho, (IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) * d.DDoc_Prd_NET) Total,"
        'strSQL &= "      '' Bulto, 0 Bobinas, '' Distribucion, COALESCE(l.cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, "
        'strSQL &= "      0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad,"
        'strSQL &= "      ((d.DDoc_Prd_QTY + d.DDoc_Prd_Cif) - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)"
        'strSQL &= "         FROM Dcmtos_DTL_Pro p"
        'strSQL &= "         WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND"
        'strSQL &= "          p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND"
        'strSQL &= "          p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0)) Cantidad, IFNULL(h.HDoc_DR2_Emp,0) IDPagadora, IFNULL(cli.cli_cliente,'') EmpPagadora"
        'strSQL &= "    FROM Dcmtos_DTL d"
        'strSQL &= "         LEFT JOIN Catalogos   m ON m.cat_clase  = 'Medidas'      AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        'strSQL &= "         LEFT JOIN Clientes    l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num"
        'strSQL &= "         LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        'strSQL &= "         LEFT JOIN Articulos   a ON a.art_sisemp = i.inv_sisemp   AND a.art_codigo = i.inv_artcodigo"
        'strSQL &= "         LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num"
        'strSQL &= "         LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_DR2_Emp "
        'strSQL &= "   WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {documento} AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {ints}"
        'strSQL &= "     ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = "SELECT d.DDoc_Doc_Ano Ano, d.DDoc_Doc_Num Numero, d.DDoc_Doc_Lin Linea, 0 Id,
              d.DDoc_Prd_Cod Codigo, IF(COALESCE(a.art_desc,'')='',d.DDoc_Prd_Des,a.art_desc) Descripcion, d.DDoc_RF1_Cod Original, d.DDoc_Prd_PNr Parte,
              d.DDoc_Prd_PUQ Unitario, d.DDoc_Prd_NET Precio, 
             (SELECT IF(d.DDoc_Prd_UM = 69, dt.DDoc_Prd_NET, IF(dt.DDoc_Prd_Cif > 0, dt.DDoc_Prd_Cif,(dt.DDoc_Prd_NET * 2.2046))) 
                From Dcmtos_DTL_Pro t 
                Left JOIN Dcmtos_DTL dt ON dt.DDoc_Sis_Emp = t.PDoc_Sis_Emp AND dt.DDoc_Doc_Cat = t.PDoc_Par_Cat AND dt.DDoc_Doc_Ano = t.PDoc_Par_Ano AND dt.DDoc_Doc_Num = t.PDoc_Par_Num AND dt.DDoc_Doc_Lin = t.PDoc_Par_Lin 
                WHERE t.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND t.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND t.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND t.PDoc_Chi_Num = d.DDoc_Doc_Num AND t.PDoc_Chi_Lin = d.DDoc_Doc_Lin AND t.PDoc_Par_Cat = 75) precioPF, 
              m.cat_clave Medida, COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM) Base, IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) Despacho, (IF(d.DDoc_RF3_Dbl=0,(d.DDoc_Prd_QTY + d.DDoc_Prd_Cif),(d.DDoc_RF3_Dbl + d.DDoc_Prd_Cif)) * d.DDoc_Prd_NET) Total,
              '' Bulto, 0 Bobinas, '' Distribucion, COALESCE(l.cli_cliente,'') Lugar, d.DDoc_RF1_Num Destino, d.DDoc_RF1_Txt Referencia, 
              0 Libras, 0 Kilos, d.DDoc_Prd_QTY Magnitud, d.DDoc_Prd_UM Unidad,
              ((d.DDoc_Prd_QTY + d.DDoc_Prd_Cif) - COALESCE((SELECT SUM(p.PDoc_QTY_Pro)
                 FROM Dcmtos_DTL_Pro p
                 WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND
                  p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND
                  p.PDoc_Par_Lin = d.DDoc_Doc_Lin AND p.PDoc_Prd_Cod = d.DDoc_Prd_Cod),0)) Cantidad, IFNULL(h.HDoc_DR2_Emp,0) IDPagadora, IFNULL(cli.cli_cliente,'') EmpPagadora
            FROM Dcmtos_DTL d
                 LEFT JOIN Catalogos   m ON m.cat_clase  = 'Medidas'      AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)
                 LEFT JOIN Clientes    l ON l.cli_sisemp = d.DDoc_Sis_Emp AND l.cli_codigo = d.DDoc_RF1_Num
                 LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod
                 LEFT JOIN Articulos   a ON a.art_sisemp = i.inv_sisemp   AND a.art_codigo = i.inv_artcodigo
                 LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num
                 LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_DR2_Emp 
           WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {documento} AND d.DDoc_Doc_Ano = {año} AND d.DDoc_Doc_Num = {ints}
             ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{documento}", 48)
        strSQL = Replace(strSQL, "{año}", dgInstrucDespacho.SelectedCells(1).Value)
        strSQL = Replace(strSQL, "{ints}", dgInstrucDespacho.SelectedCells(2).Value)

        SqlDetallePorProcesar2 = strSQL

    End Function

    Private Function SqlSeleccionados() As String
        Dim wSql As String = STR_VACIO

        For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1

            If Not dgInstrucDespacho.Rows(i).Cells(0).Value = vbNullString Then
                wSql &= IIf(i = vbEmpty, "(", " OR(")
                wSql &= "d.DDoc_Doc_Ano = " & dgInstrucDespacho.Rows(i).Cells("colAñ").Value & " AND "
                wSql &= "d.DDoc_Doc_Num = " & dgInstrucDespacho.Rows(i).Cells("colInst").Value & ") "
            End If
        Next
        If wSql = vbNullString Then
            SqlSeleccionados = "AND 1 = 0 "
        Else
            SqlSeleccionados = "AND (" & wSql & ")"
        End If

    End Function
    'Descarga de la reserva de inventario (si existe)
    Private Sub DescargarReserva()
        Dim i As Integer, j As Integer
        Dim intLinea As Integer, intEstado As Integer
        Dim intCod As Integer
        Dim Año As Integer
        Dim Numero As Integer
        Dim Tipo As Integer
        Dim Empresa As Integer
        Dim Linea As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Dim dblTemp As Double
        Dim dblCambio As Double
        Dim logEx As Boolean

        Dim strSQL As String

        For i = vbEmpty To dgDetalle.Rows.Count - 1
            'Determinar si hay cambio
            dblCambio = ((dgDetalle.Rows(i).Cells("colDespacho").Value) - (dgDetalle.Rows(i).Cells("colCantidad").Value))

            Empresa = vbEmpty
            If Not (dblCambio = vbEmpty) Then
                intLinea = dgDetalle.Rows(i).Cells("colNum").Value
                For j = vbEmpty To dgReferencia.Rows.Count - 1
                    If dgReferencia.Rows(j).Cells("colID").Value = intLinea Then
                        Empresa = Sesion.IdEmpresa
                        Tipo = 47
                        Año = dgReferencia.Rows(j).Cells("colAno").Value
                        Numero = dgReferencia.Rows(j).Cells("colNumber").Value
                        Linea = dgReferencia.Rows(j).Cells("colLine").Value

                        intCod = celdaIdCliente.Text

                        logEx = True
                        Exit For
                    End If
                Next

                If logEx Then
                    'Reservas de esa línea de referencia para el cliente actual (activas)
                    strSQL = "   SELECT linea, cantidad"
                    strSQL &= "      FROM Reserva"
                    strSQL &= "          WHERE id_empresa=" & Empresa & " AND doc_tipo=" & Tipo & " AND doc_ciclo=" & Año & " AND doc_num=" & Numero & " AND doc_lin=" & Linea & " AND id_entidad=" & intCod & " AND NOT(estado=2)"

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    REA.Read()

                    dblTemp = (REA.GetDouble("Cantidad") - dblCambio)
                    intEstado = IIf(dblTemp <= vbEmpty, 2, INT_UNO)
                    strSQL = "  UPDATE Reserva"
                    strSQL &= "      SET cantidad=" & dblTemp & ", estado=" & intEstado & ", referencia = CONCAT(referencia,'\r\n***** DESPACHO *****\r\nFecha: ',CAST(NOW() AS CHAR),'\r\nUsuario: " & Sesion.idUsuario & "\r\nFactura: " & celdaNumero.Text & "\r\nCantidad: " & dblCambio & "') WHERE id_empresa=" & Empresa & " AND doc_tipo=" & Tipo & " AND doc_ciclo=" & Año & " AND doc_num=" & Numero & " AND doc_lin=" & Linea & " AND linea=" & REA.GetInt32("Linea")
                    If Sesion.IdEmpresa = 18 Then
                        strSQL &= ";  UPDATE PDM.Reserva"
                        strSQL &= "      SET cantidad=" & dblTemp & ", estado=" & intEstado & ", referencia = CONCAT(referencia,'\r\n***** DESPACHO *****\r\nFecha: ',CAST(NOW() AS CHAR),'\r\nUsuario: " & Sesion.idUsuario & "\r\nFactura: " & celdaNumero.Text & "\r\nCantidad: " & dblCambio & "') WHERE id_empresa=" & Empresa & " AND doc_tipo=" & Tipo & " AND doc_ciclo=" & Año & " AND doc_num=" & Numero & " AND doc_lin=" & Linea & " AND linea=" & REA.GetInt32("Linea")
                    End If
                End If
            End If
            dgDetalle.Rows(i).Cells("colOriginal").Value = dgDetalle.Rows(i).Cells("colDespacho").Value
        Next
    End Sub
    'Calculo de KG

    Private Sub CalcularKGBrutos(ByVal Bultos As Integer, ByVal Cantidad As Double, ByVal Medida As String)

        Dim strSQL As String
        Dim strSQL2 As String
        Dim dblTara As Double
        Dim dblKgBrutas As Double
        Dim dblLBSBrutas As Double
        Dim dblFactor As Double
        Dim dblKgNetos As Double
        Dim dblKgNetosExt As Double
        Dim kg As Double
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim KGBrutos As Double
        Dim TotalKG As Double
        Dim CantidadReal As Double

        'For i As Integer = 0 To dgDetalle.Rows.Count - 1
        strSQL = "   SELECT IFNULL(((pe.EDoc_Lin_Gross-pe.EDoc_Lin_Net)/b.BDoc_Box_QTY),0) tara"
        strSQL &= "      FROM Dcmtos_DTL_Pro p"
        strSQL &= "          LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = p.PDoc_Sis_Emp AND b.BDoc_Doc_Cat = p.PDoc_Par_Cat AND b.BDoc_Doc_Ano = p.PDoc_Par_Ano AND b.BDoc_Doc_Num = p.PDoc_Par_Num AND b.BDoc_Doc_Lin = p.PDoc_Par_Lin"
        strSQL &= "              LEFT JOIN Dcmtos_DTL_Pro po ON po.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND po.PDoc_Chi_Cat = p.PDoc_Par_Cat AND po.PDoc_Chi_Ano = p.PDoc_Par_Ano AND po.PDoc_Chi_Num = p.PDoc_Par_Num AND po.PDoc_Chi_Lin = p.PDoc_Par_Lin"
        strSQL &= "           LEFT JOIN Dcmtos_DEC pe ON pe.EDoc_Sis_Emp = po.PDoc_Sis_Emp AND pe.EDoc_Doc_Cat = po.PDoc_Par_Cat AND pe.EDoc_Doc_Ano = po.PDoc_Par_Ano AND pe.EDoc_Doc_Num = po.PDoc_Par_Num AND pe.EDoc_Doc_Lin = po.PDoc_Par_Lin"
        strSQL &= "          WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = {instruccion} AND p.PDoc_Chi_Ano = {año} AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Chi_Lin = {linea} AND p.PDoc_Par_Cat = {ingreso}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{instruccion}", 48)
        strSQL = Replace(strSQL, "{año}", dgDetalle.CurrentRow.Cells("colAño").Value)
        strSQL = Replace(strSQL, "{numero}", dgDetalle.CurrentRow.Cells("colNum").Value)
        strSQL = Replace(strSQL, "{linea}", dgDetalle.CurrentRow.Cells("colLinea").Value)
        strSQL = Replace(strSQL, "{ingreso}", 47)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            dblTara = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        If dblTara < 0 Then
            dblTara = 0
            MsgBox("The tare could not be calculated please enter the gross weight in the Import Policy to continue the process", MsgBoxStyle.Critical, "Note")
            Exit Sub
        End If

        'Query para obtener el factor de conversión
        strSQL2 = " SELECT cat_sist"
        strSQL2 &= "     FROM Catalogos"
        strSQL2 &= " WHERE cat_clave= 'KGS'"

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL2, conec)
        Using conec
            dblFactor = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using


        'Conversion de la cantidad dependiendo de la unidad de medida y el valor de conversion que venga
        If Medida = "KGS" Then
            dblKgBrutas = ((dblTara * Bultos) + Cantidad).ToString(FORMATO_MONEDA)
            dblKgNetos = Cantidad.ToString(FORMATO_MONEDA)
            dblKgNetosExt = Cantidad.ToString(FORMATO_MONEDA_EXT)
            dblLBSBrutas = (dblKgBrutas * dblFactor).ToString(FORMATO_MONEDA)
        ElseIf Medida = "LBS" Then
            dblKgBrutas = ((Cantidad / dblFactor) + (dblTara * Bultos)).ToString(FORMATO_MONEDA)
            dblKgNetos = (Cantidad / dblFactor).ToString(FORMATO_MONEDA)
            dblKgNetosExt = (Cantidad / dblFactor).ToString(FORMATO_MONEDA_EXT)
            dblLBSBrutas = (dblKgBrutas * dblFactor).ToString(FORMATO_MONEDA)
        End If

        dgDetalle.SelectedCells(20).Value = CDbl(dblLBSBrutas).ToString(FORMATO_MONEDA)
        dgDetalle.SelectedCells(21).Value = CDbl(dblKgBrutas).ToString(FORMATO_MONEDA)
        dgDetalle.SelectedCells(22).Value = CDbl(dblKgNetos).ToString(FORMATO_MONEDA)
        dgDetalle.SelectedCells(23).Value = CDbl(dblKgNetosExt).ToString(FORMATO_MONEDA_EXT)
    End Sub
    Private Sub MarcarImpresion()
        Dim strSQL As String
        Dim COM As MySqlCommand

        strSQL = "UPDATE Dcmtos_HDR SET HDoc_DR2_Cat = (COALESCE(HDoc_DR2_Cat,0)+1)"
        strSQL &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= ";UPDATE PDM.Dcmtos_HDR SET HDoc_DR2_Cat = (COALESCE(HDoc_DR2_Cat,0)+1)"
            strSQL &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año} AND HDoc_Doc_Num = {numero}"
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
    End Sub
    Private Function GenerarYarnMovement() As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Pais As String = STR_VACIO
        Dim clsConta As New clsContabilidad
        Dim dtFechaConta As DateTime

        If logPrinting Then
            logPrinting = False
            If Not (etiquetaAnulada.Visible Or logPrinted) Then
                '  If MsgBox("¿The document is printed correctly?", vbQuestion + vbYesNo + vbDefaultButton2, "Print") = vbYes Then
                'Codigo para generar Yarn Movement
                Dim strSQL As String
                strSQL = "SELECT c.cat_clave "
                strSQL &= "  FROM Empresas e"
                strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = e.emp_pais WHERE e.emp_no = " & Sesion.IdEmpresa

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    Pais = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using
                'GenerarDocumento(Val(celdaAño.Text), Val(celdaNumero.Text))

                Dim validarTipoFactura As Integer

                celdaImpreso.Text = 1

                'FORZAR TIPO DE FACTURA PARA GENERAR YARN MOVEMENT PARA PLANTAS
                If (Sesion.idGiro = 2) Then
                    validarTipoFactura = 0 'NOT SERVICIIO
                Else
                    validarTipoFactura = celdaTipoFactura.Text
                End If

                If celdaImpreso.Text = 1 And Not validarTipoFactura = 1 Then
                    If Pais = "HN" And Sesion.IdEmpresa = 11 Then
                        GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                        'GenerarDocumento(celdaAño.Text, celdaNumero.Text)
                    ElseIf Pais = "GT" And Sesion.IdEmpresa = 12 Then
                        GenerarDocumento(celdaAño.Text, celdaNumero.Text)
                    ElseIf Pais = "SV" And Sesion.IdEmpresa = 12 Then
                        GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                    ElseIf Pais = "SV" And Sesion.IdEmpresa = 16 Then
                        GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                    ElseIf Pais = "RD" And Sesion.IdEmpresa = 14 Then
                        GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                        'ElseIf Pais = "NIC" And (Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 19 Then
                        '    GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                    ElseIf Pais = "HN" And (Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22) Then
                        GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                    ElseIf Pais = "GT" And Sesion.IdEmpresa = 9 Then
                        GenerarDocumento(celdaAño.Text, celdaNumero.Text)
                        dtFechaConta = cfun.SQLValidarFechaContable(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                        MarcarImpresion()
                        clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                    ElseIf Pais = "NIC" And Sesion.IdEmpresa = 18 Then
                        GenerarDocumento(celdaAño.Text, celdaNum2.Text)
                    End If

                End If


                'GENERA LA POLIZA DEL DOCUMENTO
                ' clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)

                ' End If

            End If
        End If
    End Function

    'Procedimiento Propio de Facturacion para generar Yard Movemnet
    Public Function GenerarDocumento(ByVal Ciclo As Integer, ByVal Factura As Long, Optional Sobrescribe As Boolean = True) As Boolean
        Dim strSql As String
        Dim strSql2 As String
        Dim logEx As Boolean
        Dim logOk As Boolean
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim REA2 As MySqlDataReader
        Dim conect As MySqlConnection
        Dim Anio As Integer
        Dim Numero As Integer

        logOk = False
        logEx = False

        'OBTENER HDR DE LA FACTURA.
        strSql = "SELECT e.HDoc_Doc_Fec Fecha, e.HDoc_Doc_Cat Tipo, e.HDoc_Doc_Ano Ciclo, e.HDoc_Doc_Num Numero, e.HDoc_Emp_Cod Codigo, e.HDoc_Emp_Nom Nombre, e.HDoc_Emp_Dir Direccion, e.HDoc_Emp_Per Persona, e.HDoc_Emp_Tel Telefono, e.HDoc_Emp_NIT NIT, e.HDoc_RF2_Num Dias, e.HDoc_Doc_Status Estado, e.HDoc_Doc_Mon Moneda, e.HDoc_Doc_TC Tasa"
        strSql &= "  FROM Dcmtos_HDR e"
        strSql &= "          WHERE e.HDoc_Sis_Emp={empresa} AND e.HDoc_Doc_Cat=36 AND e.HDoc_Doc_Ano={año} AND e.HDoc_Doc_Num={numero}"

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{año}", celdaAño.Text)
        strSql = Replace(strSql, "{numero}", celdaNumero.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSql, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            REA.Read()
            'BUSCA YARN MOVEMENT
            strSql2 = "SELECT PDoc_Chi_Ano Ciclo, PDoc_Chi_Num Numero"
            strSql2 &= "      FROM Dcmtos_DTL_Pro"
            strSql2 &= "          WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat=36 AND PDoc_Par_Ano={año} AND PDoc_Par_Num={numero} AND PDoc_Chi_Cat=395"
            strSql2 &= "              LIMIT 1"

            strSql2 = Replace(strSql2, "{empresa}", Sesion.IdEmpresa)
            strSql2 = Replace(strSql2, "{año}", REA.GetInt32("Ciclo"))
            strSql2 = Replace(strSql2, "{numero}", REA.GetInt32("Numero"))
            'MyCnn.CONECTAR = strConexion
            conect = New MySqlConnection(strConexion)
            conect.Open()
            COM2 = New MySqlCommand(strSql2, conect)
            REA2 = COM2.ExecuteReader
            If REA2.HasRows Then

                Do While REA2.Read

                    'Ya Existe
                    logEx = True

                    Anio = REA2.GetInt32("Ciclo")
                    Numero = REA2.GetInt32("Numero")

                    'Borrar datos existentes

                    Dim hdr As New clsDcmtos_HDR
                    hdr.CONEXION = strConexion
                    hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
                    hdr.HDOC_DOC_CAT = 395
                    hdr.HDOC_DOC_ANO = Anio
                    hdr.HDOC_DOC_NUM = Numero
                    hdr.Borrar()

                    'REA = COM.ExecuteReader
                    '  COM.ExecuteNonQuery()

                    strSql = " DDoc_Sis_Emp={empresa} And DDoc_Doc_Cat = 395 And DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num ={numero}"

                    strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
                    strSql = Replace(strSql, "{anio}", Anio)
                    strSql = Replace(strSql, "{numero}", Numero)

                    Dim dtl As New clsDcmtos_DTL
                    dtl.CONEXION = strConexion
                    dtl.Borrar(strSql)

                    'REA = COM.ExecuteReader
                    '   COM.ExecuteNonQuery()

                    strSql = " PDoc_Sis_Emp={empresa} And PDoc_Chi_Cat = 395 And PDoc_Chi_Ano = {anio} AND PDoc_Par_Num ={numero} And PDoc_Par_Cat = 36"

                    strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
                    strSql = Replace(strSql, "{anio}", Anio)
                    strSql = Replace(strSql, "{numero}", Numero)

                    Dim pro As New clsDcmtos_DTL_Pro
                    pro.CONEXION = strConexion
                    pro.Borrar(strSql)
                    'REA = COM.ExecuteReader
                    '   COM.ExecuteNonQuery()
                Loop
            Else
                Anio = Ciclo
                Numero = Factura
            End If

            If logEx = False Then
                Try
                    'Guardar el encabezado del Yarn Movement
                    GuardarEncabezadoYarn_Movement(Anio, Numero)

                    'Guardar el Detalle del Yarn Movement 
                    GuardarDetalleYarn_Movement(Anio, Numero)

                    'Guardar el Descargo de Yarn Movement
                    GuardarDescargosYarn_Movement(Anio, Numero)

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
                logOk = True
            End If
        Else
            MsgBox("The Bill not found", vbExclamation, "Generate Yard Movement")
        End If
        Return logOk
        'GenerarDocumento = logOk
    End Function
    Public Function GetReferencia() As String
        Dim strReferencia As String = STR_VACIO
        Dim referencia As String = STR_VACIO

        Try
            For j As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                If dgInstrucDespacho.Rows(j).Visible = True Then

                    If j = 0 Then

                        referencia = dgInstrucDespacho.Rows(j).Cells("colRef").Value
                    Else
                        referencia = referencia & " / " & dgInstrucDespacho.Rows(j).Cells("colRef").Value
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return referencia
    End Function
    'Muestra el listado de referencias descargadas para su modificación
    Private Sub MostrarReferencias()
        Dim i As Integer
        Dim j As Integer

        Dim intID As Integer
        Dim intFila As Integer
        Dim intUnidad As Integer
        Dim intMedida As Integer
        Dim dblDescuentoPrecio As Double
        Dim dblDescuentoMoney As Double
        Dim dblDescuentoPorcentaje As Double

        Dim strTemp As String
        Dim frmLista As New frmFacturasRef_Aux_
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        'Recupera la ID de la fila
        For i = 0 To dgDetalle.Rows.Count - 1

            intFila = i
            intID = dgDetalle.SelectedCells(3).Value
        Next

        intUnidad = dgDetalle.Rows(intFila).Cells("colBase").Value
        intMedida = CInt(dgDetalle.Rows(intFila).Cells("colBase").Value)


        'Actualiza el saldo de las facturas de referencia
        ActualizarLista()

        'Crea la ventana para mostrar las referencias
        Dim strsql As String = STR_VACIO


        strsql = "SELECT b.HDoc_Doc_Cat Tipo, b.HDoc_Doc_Ano Ano, b.HDoc_Doc_Num Numero, b.HDoc_Doc_Fec Fecha, b.HDoc_DR1_Num Referencia, COALESCE(m.cat_clave,'') Medida, COALESCE(m.cat_num,0) Unidad, a.PDoc_Par_Lin Linea, a.PDoc_Prd_Cod Codigo, a.PDoc_QTY_Ord Disponible, a.PDoc_QTY_Pro Descargo, d.DDoc_Prd_QTY Cantidad, a.PDoc_Chi_Lin linea_Instruccion, a.PDoc_Chi_Num Instruccion, a.PDoc_Chi_Lin ID,"
        strsql &= "  IFNULL(("
        strsql &= "     SELECT a.ADoc_Dta_Chr Poliza"
        strsql &= "       FROM Dcmtos_DTL_Pro p"
        strsql &= "          INNER JOIN Catalogos c ON c.cat_num = p.PDoc_Par_Cat AND c.cat_clase = 'Documentos'"
        strsql &= "             INNER JOIN Dcmtos_ACC a ON a.ADoc_Sis_Emp = p.PDoc_Sis_Emp AND a.ADoc_Doc_Cat = p.PDoc_Par_Cat AND a.ADoc_Doc_Ano = p.PDoc_Par_Ano AND a.ADoc_Doc_Num = p.PDoc_Par_Num"
        strsql &= "              WHERE p.PDoc_Sis_Emp =b.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = b.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = b.HDoc_Doc_Ano AND p.PDoc_Chi_Lin= d.DDoc_Doc_Lin   AND p.PDoc_Chi_Num =b.HDoc_Doc_Num AND c.cat_sist = 'Doc_ODesImp' AND a.ADoc_Doc_Lin = '01' ),'-') POLIZA"
        strsql &= "                 FROM Dcmtos_DTL_Pro a"
        strsql &= "                  INNER JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = a.PDoc_Sis_Emp AND b.HDoc_Doc_Cat = a.PDoc_Par_Cat AND b.HDoc_Doc_Ano = a.PDoc_Par_Ano AND b.HDoc_Doc_Num = a.PDoc_Par_Num"
        strsql &= "                 INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = a.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = a.PDoc_Chi_Cat AND d.DDoc_Doc_Ano = a.PDoc_Chi_Ano AND d.DDoc_Doc_Num = a.PDoc_Chi_Num AND d.DDoc_Doc_Lin = a.PDoc_Chi_Lin"
        strsql &= "                LEFT JOIN Catalogos m ON m.cat_clase='Medidas' AND m.cat_num = COALESCE(d.DDoc_RF3_Num,d.DDoc_Prd_UM)"
        strsql &= "             WHERE PDoc_Sis_Emp = {empresa} AND PDoc_Par_Cat = 47 AND PDoc_Chi_Cat = 48 AND PDoc_Chi_Ano = {año} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea}"
        strsql &= "          ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"

        'NOTAS: '48/Instrucciones' es child, y '47/Ingreso' es parent

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", dgDetalle.SelectedCells(2).Value)
        strsql = Replace(strsql, "{numero}", dgDetalle.SelectedCells(0).Value)
        strsql = Replace(strsql, "{linea}", dgDetalle.SelectedCells(3).Value)

        Try

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                frmLista.dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO
                    Dim disponible As Double
                    Dim descargo As Double

                    For k As Integer = 0 To dgReferencia.Rows.Count - 1

                        If REA.GetInt32("Instruccion") = dgReferencia.Rows(k).Cells("colInstruccion").Value And
                           REA.GetInt32("linea_Instruccion") = dgReferencia.Rows(k).Cells("colLineaInstruccion").Value Then
                            'disponible = dgReferencia.Rows(i).Cells("colDisponible").Value
                            descargo = dgReferencia.Rows(k).Cells("colDescargo").Value
                            'dgReferencia.Rows(i).Cells("colDisponible").Value = REA.GetDouble("Disponible")
                            If dgReferencia.Rows(k).Cells("colAmount").Value = "0" Then
                                disponible = (Val(dgReferencia.Rows(k).Cells("colDisponible").Value) + Val(dgReferencia.Rows(k).Cells("colAmount").Value))
                            Else
                                disponible = dgReferencia.Rows(k).Cells("colDisponible").Value
                            End If

                            Exit For

                        Else
                            'disponible = REA.GetDouble("Disponible")
                            descargo = REA.GetDouble("Descargo")
                            disponible = REA.GetDouble("Disponible")
                        End If
                    Next

                    strFila = REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha") & "|"
                    strFila &= REA.GetString("POLIZA") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("Codigo") & "|"
                    If disponible > 0 Then
                        strFila &= disponible.ToString(FORMATO_MONEDA) & "|"
                    Else
                        strFila &= 0 & "|"
                    End If
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetInt32("Unidad") & "|"
                    strFila &= descargo & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= 0 & "|"
                    strFila &= vbEmpty
                    cFunciones.AgregarFila(frmLista.dgLista, strFila)

                Loop
                REA.Close()
                REA = Nothing
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Try
            frmLista.Factura = True
            frmLista.Unidad = intUnidad
            frmLista.Codigo = dgDetalle.SelectedCells(1).Value

            If (checkActivar.Checked = False) Or logPrinted Then
                frmLista.dgLista.ReadOnly = True
                frmLista.botonAceptar.Enabled = False
            End If
            frmLista.ShowDialog(Me)

            Dim dblFactor As Double
            Dim dblCantidad As Double
            Dim dblDespacho As Double

            'Si se aceptan los cambios
            If frmLista.Aceptado Then
                With frmLista.dgLista
                    dblDespacho = vbEmpty
                    dblCantidad = vbEmpty

                    If (intMedida = intUnidad) Then
                        dblFactor = 1
                    ElseIf intMedida = intLbs Then
                        dblFactor = dblFactorKgs
                    Else
                        dblFactor = dblFactorLbs
                    End If

                    strTemp = vbNullString
                    For i = vbEmpty To frmLista.dgLista.Rows.Count - 1
                        'Buscar la línea dentro del listado
                        j = LineaDeReferencia(intID, frmLista.dgLista.Rows(i).Cells("colAño").Value, frmLista.dgLista.Rows(i).Cells("colNumero").Value, frmLista.dgLista.Rows(i).Cells("colLinea").Value, dgDetalle.CurrentRow.Cells("colNum").Value)
                        If Not (j = NO_FILA) Then
                            dblDespacho = vbEmpty
                            dblDespacho = Val(frmLista.dgLista.Rows(i).Cells("colDescargo").Value)
                            dblCantidad = (dblDespacho / dblFactor)
                            'Asigna la cantidad a descargar
                            dgReferencia.Rows(j).Cells("colDescargo").Value = dblDespacho
                            dgReferencia.Rows(j).Cells("colCantida").Value = dblCantidad
                            dgReferencia.Rows(j).Cells("colCantDescargada").Value = dblDespacho
                            'Comprueba si se ha modificado el descargo
                            If Not Val(frmLista.dgLista.Rows(i).Cells("colDescargo").Value) = Val(dgReferencia.Rows(j).Cells("colDescargado").Value) Then
                                strTemp = strTemp & "X"
                                dgReferencia.Rows(j).Cells("colModificado").Value = "X"
                            Else
                                dgReferencia.Rows(j).Cells("colModificado").Value = vbNullString
                            End If
                        End If
                    Next

                    dgDetalle.CurrentRow.Cells("colDespacho").Value = dblDespacho.ToString(FORMATO_MONEDA)
                    dgDetalle.CurrentRow.Cells("colCantidad").Value = dblCantidad.ToString(FORMATO_MONEDA)
                    Dim TotalFinal As Double
                    TotalFinal = (dblDespacho * dgDetalle.CurrentRow.Cells("colPrecio").Value)
                    dgDetalle.CurrentRow.Cells("coltotal").Value = TotalFinal.ToString(FORMATO_MONEDA)

                    Dim dblDescargo As Double
                    dblDescargo = (dgDetalle.CurrentRow.Cells("colCantidad").Value / dblFactor)
                    dgDetalle.CurrentRow.Cells("colKGNetos").Value = dblDescargo.ToString(FORMATO_MONEDA)
                    dgDetalle.CurrentRow.Cells("colKGNetosExt").Value = dblDescargo.ToString(FORMATO_MONEDA_EXT)   '' se cambia a 4 decimales

                    If Sesion.IdEmpresa = 11 Or (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 16 And Pais() = 310) Then
                        dblDescuentoPrecio = (dgDetalle.CurrentRow.Cells("colPrecio").Value - dgDetalle.CurrentRow.Cells("colPrecioPF").Value)
                        If dblDescuentoPrecio = 0 Then
                            dgDetalle.CurrentRow.Cells("colDesc").Value = "0.00"  ' Descuento en Porcentaje
                            dgDetalle.CurrentRow.Cells("colDescDolar").Value = "0.00" ' Descuento en $
                        Else
                            dblDescuentoMoney = ((dblDescuentoPrecio) * dgDetalle.CurrentRow.Cells("colCantidad").Value)
                            dblDescuentoPorcentaje = ((dblDescuentoMoney / dgDetalle.CurrentRow.Cells("coltotal").Value) * 100)
                            dgDetalle.CurrentRow.Cells("colDesc").Value = dblDescuentoPorcentaje.ToString(FORMATO_MONEDA)  ' Descuento en Porcentaje
                            dgDetalle.CurrentRow.Cells("colDescDolar").Value = dblDescuentoMoney.ToString(FORMATO_MONEDA) ' Descuento en $
                            CalcularTotales()
                        End If

                    End If


                    Try
                        Dim dblFactor1 As Double
                        Dim m As Integer
                        Dim dblSuma As Double
                        Dim dblSeguro As Double
                        Dim strSQL1 As String = STR_VACIO
                        Dim COM2 As MySqlCommand
                        Dim conec As MySqlConnection

                        strSQL1 = "SELECT COALESCE(cat_sist,0) dato"
                        strSQL1 &= " FROM Catalogos"
                        strSQL1 &= "      WHERE cat_clase='Constantes' AND cat_clave='Seguro'"

                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM2 = New MySqlCommand(strSQL1, conec)
                        Using conec
                            dblFactor = COM2.ExecuteScalar()
                            COM.Dispose()
                            COM = Nothing
                            conec.Close()
                            conec.Dispose()
                            conec = Nothing
                            System.GC.Collect()
                        End Using

                        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                            dblFactor1 = 0.015
                        Else
                            If dblFactor1 = vbEmpty Then
                                dblFactor1 = 0.01375
                            End If
                        End If

                        For m = vbEmpty To dgDetalle.Rows.Count - 1
                            If dgDetalle.Rows(m).Cells("colEliminar").Value = 1 Or dgDetalle.Rows(m).Cells("colEliminar").Value = 0 Then
                                dblSuma = (dblSuma + dgDetalle.Rows(m).Cells("colTotal").Value)
                            End If
                        Next

                        dblSeguro = (dblSuma * dblFactor1)
                        celdaSeguro.Text = dblSeguro.ToString(FORMATO_MONEDA)
                        celdaFlete.Text = Val(celdaFlete.Text).ToString(FORMATO_MONEDA)
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                End With
            End If

            frmLista = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function LineaDeReferencia(ByVal ID As String, ByVal Ciclo As String, ByVal Numero As String, ByVal Linea As String, ByVal Instru As Integer) As Integer
        Dim i As Integer
        Dim intFila As Integer
        intFila = NO_FILA

        For i = vbEmpty To dgReferencia.Rows.Count - 1
            'Si la línea coincide en Id, Año, Número y línea
            If dgReferencia.Rows(i).Cells("colLineaInstruccion").Value = ID And
               dgReferencia.Rows(i).Cells("colInstruccion").Value = Instru And
               dgReferencia.Rows(i).Cells("colAno").Value = Ciclo And
               dgReferencia.Rows(i).Cells("colNumber").Value = Numero And
               dgReferencia.Rows(i).Cells("colLine").Value = Linea Then
                intFila = i
                Exit For
            End If
        Next
        LineaDeReferencia = intFila
    End Function

    Private Function PedirCopias()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim copias As Integer

        strSQL = "SELECT COUNT(DISTINCT(d.DDoc_RF1_Num)) DESTINO"
        strSQL &= "  FROM Dcmtos_DTL d"
        strSQL &= "      WHERE d.DDoc_Sis_Emp ={empresa} AND d.DDoc_Doc_Ano ={año} AND d.DDoc_Doc_Cat  =36 AND d.DDoc_Doc_Num ={numero}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            copias = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
        Return copias
    End Function

    Private Function sqlVerificaYMR()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intActivo As Integer = INT_CERO

        strSQL = "SELECT c.cat_sist estado"
        strSQL &= "      FROM Catalogos c"
        strSQL &= "              WHERE c.cat_clase = 'AutoGYMR' AND c.cat_clave = 'YMR'"

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            intActivo = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        Return intActivo
    End Function
    Private Function SQLBultosLinea(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT di.*, ROUND((di.Despachar/di.peso),0) bultos_aprox, di.linea "
        strSQL &= " FROM( "
        strSQL &= " SELECT IFNULL(( "
        strSQL &= "     SELECT ROUND(SUM((b.BDoc_Box_LB / b.BDoc_Box_QTY)), 0) peso "
        strSQL &= "         FROM Dcmtos_DTL_Pro p "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp =p.PDoc_Sis_Emp AND b.BDoc_Doc_Cat = p.PDoc_Par_Cat AND b.BDoc_Doc_Ano = p.PDoc_Par_Ano AND b.BDoc_Doc_Num = p.PDoc_Par_Num AND b.BDoc_Doc_Lin = p.PDoc_Par_Lin "
        strSQL &= "                 WHERE p.PDoc_Sis_Emp = a.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = a.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = a.DDoc_Doc_Ano AND p.PDoc_Chi_Num = a.DDoc_Doc_Num AND p.PDoc_Chi_Lin = a.DDoc_Doc_Lin AND p.PDoc_Par_Cat = 47),1) peso, IF(a.DDoc_RF3_Dbl=0,a.DDoc_Prd_QTY,a.DDoc_RF3_Dbl) Despachar, ( "
        strSQL &= "                     SELECT d.cat_clave "
        strSQL &= "                         FROM Catalogos d "
        strSQL &= "                             WHERE d.cat_num = c.inv_lugarfab) PaisProd, (a.DDoc_Prd_DSP - IF(a.DDoc_RF3_Dbl= 0,a.DDoc_Prd_QTY,a.DDoc_RF3_Dbl))Saldo, tl.DDoc_Prd_UM UMProforma, a.DDoc_Doc_Lin linea "
        strSQL &= "                                 FROM Dcmtos_DTL a "
        strSQL &= "                             LEFT JOIN Dcmtos_DTL_Pro dp47 ON dp47.PDoc_Sis_Emp = a.DDoc_Sis_Emp AND dp47.PDoc_Chi_Cat = a.DDoc_Doc_Cat AND dp47.PDoc_Chi_Ano = a.DDoc_Doc_Ano AND dp47.PDoc_Chi_Num = a.DDoc_Doc_Num AND dp47.PDoc_Chi_Lin = a.DDoc_Doc_Lin AND dp47.PDoc_Par_Cat = 47 "
        strSQL &= "                         LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = dp47.PDoc_Sis_Emp AND h47.HDoc_Doc_Cat = dp47.PDoc_Par_Cat AND h47.HDoc_Doc_Ano = dp47.PDoc_Par_Ano AND h47.HDoc_Doc_Num = dp47.PDoc_Par_Num "
        strSQL &= "                       LEFT JOIN Dcmtos_DTL d47 ON d47.DDoc_Sis_Emp = dp47.PDoc_Sis_Emp AND d47.DDoc_Doc_Cat = dp47.PDoc_Par_Cat AND d47.DDoc_Doc_Ano = dp47.PDoc_Par_Ano AND d47.DDoc_Doc_Num = dp47.PDoc_Par_Num AND d47.DDoc_Doc_Lin = dp47.PDoc_Par_Lin "
        strSQL &= "                    LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp = a.DDoc_Sis_Emp AND pp.PDoc_Chi_Num = a.DDoc_Doc_Num AND pp.PDoc_Chi_Cat = a.DDoc_Doc_Cat AND pp.PDoc_Chi_Ano = a.DDoc_Doc_Ano AND pp.PDoc_Chi_Lin =a.DDoc_Doc_Lin AND pp.PDoc_Par_Cat = 75 "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL tl ON tl.DDoc_Sis_Emp = pp.PDoc_Sis_Emp AND tl.DDoc_Doc_Cat = pp.PDoc_Par_Cat AND tl.DDoc_Doc_Ano = pp.PDoc_Par_Ano AND tl.DDoc_Doc_Num = pp.PDoc_Par_Num AND tl.DDoc_Doc_Lin = pp.PDoc_Par_Lin "
        strSQL &= "             INNER JOIN Catalogos b ON b.cat_num = COALESCE(a.DDoc_RF3_Num, a.DDoc_Prd_UM) "
        strSQL &= "         INNER JOIN Inventarios c ON c.inv_sisemp = a.DDoc_Sis_Emp AND c.inv_numero = a.DDoc_Prd_Cod "
        strSQL &= "     LEFT JOIN Proveedores p ON p.pro_sisemp=a.DDoc_Sis_Emp AND p.pro_codigo=c.inv_provcod "
        strSQL &= "   LEFT JOIN Clientes l ON l.cli_sisemp = a.DDoc_Sis_Emp AND l.cli_codigo=a.DDoc_RF1_Num "
        strSQL &= " WHERE a.DDoc_Sis_Emp = {empresa} AND a.DDoc_Doc_Cat = 48 AND a.DDoc_Doc_Ano = {anio} AND a.DDoc_Doc_Num = {numero} "
        strSQL &= "ORDER BY a.DDoc_Sis_Emp, a.DDoc_Doc_Cat, a.DDoc_Doc_Ano, a.DDoc_Doc_Num, a.DDoc_Doc_Lin) di"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Return strSQL
    End Function
    Public Sub ActualizarBultosPorLinea(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Bultos As Integer
        Dim intCantidad As Double
        Dim intMedida As String
        Dim sender As Object
        Dim i As Integer = 0
        Try

            strSQL = SQLBultosLinea(Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    For i = 0 To dgDetalle.Rows.Count - 1
                        If dgDetalle.Rows(i).Cells("colNum").Value = Numero And dgDetalle.Rows(i).Cells("colAño").Value = Anio And dgDetalle.Rows(i).Cells("colLinea").Value = REA.GetInt32("linea") Then
                            dgDetalle.Rows(i).Cells("colBulto").Value = REA.GetInt32("bultos_aprox")
                            Me.dgDetalle.CurrentCell = Me.dgDetalle.Item(14, i) 'dgDetalle.Rows(i).Cells(14)
                            dgDetalle.BeginEdit(True)

                            'SendKeys.Send("{TAB}")
                            '   Dim ee As New System.Windows.Forms.DataGridViewCellEventArgs(dgDetalle.Rows(i).Cells("colBulto").Value, 8)
                            '  dgDetalle_CellEndEdit(sender, ee)
                        End If
                    Next
                Loop
                SendKeys.Send("{TAB}")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ValidarBultos(ByVal Anio As Integer, ByVal Numero As Integer) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logValidacion As Boolean
        Dim intDiferencia As Integer
        Dim conec As MySqlConnection

        Dim bolAutorizar As Boolean = False
        Try
            strSQL = SQLBultosLinea(Anio, Numero)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        bolAutorizar = False
                        If dgDetalle.Rows(i).Cells("colNum").Value = Numero And dgDetalle.Rows(i).Cells("colAño").Value = Anio And dgDetalle.Rows(i).Cells("colLinea").Value = REA.GetInt32("linea") Then
                            intDiferencia = (dgDetalle.Rows(i).Cells("colBulto").Value - REA.GetInt32("bultos_aprox"))
                            If intDiferencia = 1 Or intDiferencia = -1 Then
                                If MsgBox("packages from line " & dgDetalle.Rows(i).Cells("colLinea").Value & " are not matching with instruction, Do you want to continue?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                                    logValidacion = True
                                Else
                                    logValidacion = False
                                End If
                            ElseIf intDiferencia >= 2 Or intDiferencia <= -2 Then
                                If MsgBox("packages from line " & dgDetalle.Rows(i).Cells("colLinea").Value & " are not matching with instruction, Do you want to continue?", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                                    bolAutorizar = True
                                Else
                                    logValidacion = False
                                End If
                            Else
                                logValidacion = True
                            End If
                        End If
                        If bolAutorizar = True Then
                            If PedirAutorizacionFactura("Bultos") = True Then
                                logValidacion = True
                            Else
                                logValidacion = False
                            End If
                        End If
                    Next

                Loop

            End If

            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidacion
    End Function
    Private Function PedirAutorizacionFactura(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AutorizarBultos"
        Dim frm As frmAutorización
        PedirAutorizacionFactura = False

        frm = New frmAutorización
        frm.Iniciar(36, STR_MARGEN, 0, "Autorizar Bultos")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionFactura = True
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text, "Autorizó Bultos " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
    Private Function PedirAutorizacionFlete(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AutorizarFlete"
        Dim frm As frmAutorización
        PedirAutorizacionFlete = False

        frm = New frmAutorización
        frm.Iniciar(36, STR_MARGEN, 0, "Autorizar Flete")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionFlete = True
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text, "Autorizó Flete " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
#End Region

#Region "Eventos"

    Private Sub frmFacturacion_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Private Sub frmFacturacion_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmFacturacion_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Pais As String
        Dim clsConta As New clsContabilidad
        Dim dtFechaConta As DateTime


        If logPrinting Then
            logPrinting = False
            If Not (etiquetaAnulada.Visible Or logPrinted) Then
                If MsgBox("¿The document is printed correctly?", vbQuestion + vbYesNo + vbDefaultButton2, "Print") = vbYes Then
                    'Codigo para generar Yarn Movement
                    Dim strSQL As String
                    strSQL = "SELECT c.cat_clave "
                    strSQL &= "  FROM Empresas e"
                    strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = e.emp_pais "

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        Pais = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using
                    'GenerarDocumento(Val(celdaAño.Text), Val(celdaNumero.Text))

                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acGeneraYRM, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                    MarcarImpresion()
                    celdaImpreso.Text = 1

                    If celdaImpreso.Text = 1 Then
                        If Pais = "HN" And Sesion.IdEmpresa = 11 Then
                            GenerarDocumento(celdaAño.Text, celdaNumero.Text)
                        End If
                    End If
                    dtFechaConta = cfun.SQLValidarFechaContable(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                    'GENERA LA POLIZA DEL DOCUMENTO
                    clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))

                End If

                'celdaFlete.Enabled = True
                'celdaSeguro.Enabled = True
            End If
        End If

    End Sub

    Private Sub frmFacturacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "   SELECT pms_codigo permiso"
        strSQL &= "      FROM Permisos"
        strSQL &= "         WHERE pms_empresa = {empresa} AND pms_modulo = 16 AND pms_usuario = '{usuario}' and pms_nivel = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)

        dtpInicio.Value = Today.AddDays(-15)
        dtpFinal.Value = Today
        MyCnn.CONECTAR = strConexion

        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then

            Do While REA.Read
                If REA.GetString("permiso") = "CARGA" Then
                    botonCarga.Enabled = True
                End If
                If REA.GetString("permiso") = "LIBERAR" Then
                    botonLiberar.Enabled = True
                End If
                If REA.GetString("permiso") = "POLIZA" Then
                    botonPoliza.Enabled = True
                End If
                If REA.GetString("permiso") = "SALIDA" Then
                    botonSalida.Enabled = True
                End If


            Loop
            REA.Close()
            REA = Nothing
            'COM.Dispose()
        Else
            botonSalida.Enabled = False
            botonPoliza.Enabled = False
            botonLiberar.Enabled = False
            botonCarga.Enabled = False
        End If
        COM.Dispose()
        COM = Nothing
        CON.Dispose()
        If Sesion.idGiro = 2 Then
            panelPlantas.Visible = True
        Else
            panelPlantas.Visible = False
        End If

        intPais = Pais()
        If intPais = 310 Or intPais = 327 Or (Sesion.IdEmpresa = 15 And intPais = 1) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 22) Or (Sesion.IdEmpresa = 11) Then
            celdaNum2.Visible = True
            celdaNumero.Visible = False
            dgLista.Columns("colNumero").Visible = True
            dgLista.Columns("colNum2").Visible = False

        Else
            celdaNum2.Visible = False
            celdaNumero.Visible = True
            dgLista.Columns("colNumero").Visible = False
            dgLista.Columns("colNum2").Visible = True
        End If

        If Sesion.IdEmpresa = 9 Then
            gbFel.Visible = True
        Else
            gbFel.Visible = False
        End If

        Accessos()
        MostrarLista()

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim selectFecha As New frmDateTimePicker
        Dim SDoc As New frmSubDocumentos
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Dim COM2 As MySqlCommand

        Dim Serie As String

        If logInsertar = True Then
            Me.Tag = "Nuevo"
            botonSerie.Enabled = True
            ActivarCampos()
            dgDetalle.Columns("ColDescrip").ReadOnly = False
            dgDetalle.Columns("colMedida").ReadOnly = False
            dgDetalle.Columns("colDespacho").ReadOnly = False
            dgDetalle.Columns("colDesc").ReadOnly = False
            dgDetalle.Columns("colDescDolar").ReadOnly = False
            dgDetalle.Columns("colBobina").ReadOnly = False
            dgDetalle.Columns("colLBS").ReadOnly = False
            dgDetalle.Columns("colKGS").ReadOnly = False
            dgDetalle.Columns("colKGNetos").ReadOnly = False ' se desbloquea para corrección de pesos
            dgDetalle.Columns("colBulto").ReadOnly = False
            etiquetaSerie.Visible = False
            etiquetaAutorizacion.Visible = False
            LimpiarPanelOrden()


            'Verifica el tipo de documento para ServiImport
            If Sesion.IdEmpresa = 9 Or Sesion.idGiro = 2 Or Sesion.idGiro = 1 Then
                Dim frmOp As New frmOption

                If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                    dgDetalle.Columns("colLoteNuevo").Visible = True
                Else
                    dgDetalle.Columns("colLoteNuevo").Visible = False
                End If
                frmOp.Titulo = " Invoice type "
                frmOp.Mensaje = "Choose the type of Billing to be made."
                If Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Then
                    frmOp.Opciones = "Billing Products|Billing Services"
                Else
                    frmOp.Opciones = "Inventory Invoice|Billing Services|Initial Invoice"
                End If

                frmOp.ShowDialog(Me)
                If frmOp.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    dgDetalle.Columns("colCta").ReadOnly = True
                    dgDetalle.Columns("colCta").Visible = False
                    dgDetalle.Columns("colNombreCta").ReadOnly = True
                    dgDetalle.Columns("colNombreCta").Visible = False

                    If frmOp.Seleccion = 0 Then
                        celdaTipoFactura.Text = INT_CERO
                        botonAgrega.Visible = False
                        botonQuitar.Visible = False
                    ElseIf frmOp.Seleccion = 1 Then
                        If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 21 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 20 Then
                            dgDetalle.Columns("colCta").ReadOnly = True
                            dgDetalle.Columns("colCta").Visible = False
                            dgDetalle.Columns("colNombreCta").ReadOnly = True
                            dgDetalle.Columns("colNombreCta").Visible = True
                        End If
                        celdaTipoFactura.Text = INT_UNO
                        botonAgrega.Visible = True
                        botonQuitar.Visible = True
                    Else
                        celdaTipoFactura.Text = 2
                        botonAgrega.Visible = True
                        botonQuitar.Visible = True
                    End If
                End If
            Else
                botonAgrega.Visible = False
                botonQuitar.Visible = False
            End If
            'COM.Dispose()
            COM = Nothing
            celdaIdMoneda.Text = 178
            celdaMoneda.Text = cfun.SimboloMoneda(celdaIdMoneda.Text)
            celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
            MostrarLista(False)

            strSQL &= "SELECT c.cat_sist "
            strSQL &= "   FROM Catalogos c"
            strSQL &= "      WHERE cat_clase='Serie' AND cat_clave= 'Doc_CFactura' and cat_pid = 0 and cat_sisemp = {empresa}"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Serie = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using

            celdaSerie.Text = Serie
            celdaAño.Text = cFunciones.AñoMySQL
            celdaNumero.Enabled = True
            celdaFlete.Enabled = True
            botonSeguro.Enabled = True

            Dim año As Integer
            Dim numero As Integer
            Seleccionar(año, numero)
            SeleccionarSubdocumentos(año, numero)
            dgSubdocumentos.Enabled = True

            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaTipo.Text = 36
            celdaUsuario.Text = Sesion.Usuario
            checkRevisado.Enabled = False
            celdaBloqueado.Text = vbNullString
            celdaSubDocumento.Text = 0
            celdaFlete.Text = 0.ToString(FORMATO_MONEDA)
            etiquetaAnulada.Visible = False
            checkActivar.Checked = True


            SDoc.Año = celdaAño.Text
            SDoc.Numero = celdaNumero.Text
            SDoc.Catalogo = 36
            dgInstrucDespacho.Enabled = True
            ' dtpFecha.Enabled = True

            selectFecha.ShowDialog(Me)
            If selectFecha.DialogResult = System.Windows.Forms.DialogResult.OK Then
                dtpFecha.Text = selectFecha.LLave
            End If
            dtpFecha.Enabled = False


            botonCliente.Enabled = True
            If Sesion.IdEmpresa = 2 Then
                celdaSerie.ReadOnly = False
                celdaSerie.Enabled = True
            Else
                celdaSerie.ReadOnly = True
                celdaSerie.Enabled = False
            End If

            botonSeguro.Enabled = True
            logPrinted = False

            'cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())

            If celdaEmpresa.Text = 12 And Pais() = 0 Then
                dgDetalle.Columns("colDesc").Visible = False
                dgDetalle.Columns("colDescDolar").Visible = False
            Else
                dgDetalle.Columns("colDesc").Visible = True
                dgDetalle.Columns("colDescDolar").Visible = True

            End If

            intPais = Pais()
            If (Sesion.IdEmpresa = 12 And intPais = 310) Or (Sesion.IdEmpresa = 11) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Then
                celdaSeguro.Enabled = True
            Else
                celdaSeguro.Enabled = False
            End If

            celdaNum2.Enabled = True
            dgDetalle.ReadOnly = False

            ''CARGA EL CAI  ''''se cambia de posicion, se agrega al click del boton serie.
            ''CAI()


            ActivarGuardar()
        Else
            MsgBox("Do you not have access to create a new invoice", vbInformation)
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar

        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
        dgReferencia.Rows.Clear()

    End Sub

    'Proceso Para Generar Póliza Contable
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim clsConta As New clsContabilidad
        Dim dtFechaConta As Date

        If Me.Tag = "Mod" Then
            If checkActivar.Checked = False And documentosAsociados >= 1 Then
                MsgBox("Invoice cannot be cancelled, you have payments applied", vbOK, "Notice")
                Exit Sub
            End If
            dtFechaConta = cfun.SQLValidarFechaContable(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
            'Verifica que no haya cierre
            If cfun.SQLVerificarCierre(celdaTipo.Text, celdaAño.Text, celdaNumero.Text) = 0 Then
                GuardarDatosDesdeBotonGuardar()
                If celdaImpreso.Text > 0 Then
                    clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                ElseIf checkActivar.Checked = False Then
                    clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                End If
            Else ' Entra al else si existe cierre
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cfun.AutorizarCambios = True Then
                    'Registra quien autoriza la modificación
                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text, "Autorizó Modificación")
                    GuardarDatosDesdeBotonGuardar()
                    If celdaImpreso.Text > 0 Then
                        clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                    ElseIf checkActivar.Checked = False Then
                        clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                    End If

                End If

            End If
        Else
            GuardarDatosDesdeBotonGuardar()
        End If

    End Sub

    Private Sub GuardarDatosDesdeBotonGuardar()
        Dim strSQL As String = STR_VACIO
        Dim ComParChil As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim logVacia As Boolean
        Dim strDato As String = STR_VACIO
        Dim cls As New clsFunciones
        Dim clsConta As New clsContabilidad
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        If logEditar = True Then
            ' Este codigo evita anulacion de Factura. Si hay dependencias a factura no se puede anular.
            If etiquetaAnulada.Visible Then
                Try

                    strSQL = vbNullString
                    strSQL &= " select sum(b)from("
                    strSQL &= "      SELECT COUNT(*) b"
                    strSQL &= "          FROM Dcmtos_DTL_Pro p"
                    strSQL &= "              left join Dcmtos_HDR h on h.HDoc_Sis_Emp = p.PDoc_Sis_Emp And h.HDoc_Doc_Cat = p.PDoc_Chi_Cat And h.HDoc_Doc_Ano = p.PDoc_Chi_Ano And h.HDoc_Doc_Num = p.PDoc_Chi_Num"
                    strSQL &= "                  Where p.PDoc_Sis_Emp = {empresa} And p.PDoc_Par_Cat = 36 And p.PDoc_Par_Ano = {año} And p.PDoc_Par_Num = {numero} And h.HDoc_Doc_Status = 1"
                    strSQL &= "               UNION"
                    strSQL &= "                  Select count(*)b"
                    strSQL &= "                from ECtaCte c"
                    strSQL &= "              left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp = c.ECta_Sis_Emp and hh.HDoc_Doc_Cat =c.ECta_Doc_Cat and hh.HDoc_Doc_Ano = c.ECta_Doc_Ano and hh.HDoc_Doc_Num =c.ECta_Doc_Num"
                    strSQL &= "          where c.ECta_Sis_Emp = {empresa} And c.ECta_Ref_Cat = 36 And c.ECta_Ref_Ano = {año} And c.ECta_Ref_Num = {numero} And c.ECta_Ref_Cat != c.ECta_Doc_Cat  And hh.HDoc_Doc_Status = 1 )d"

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{año}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        ComParChil = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
                If ComParChil = 0 Then
                ElseIf ComParChil > 0 Then
                    MsgBox("This bill can not be canceled, is related to other agencies")
                    cls.MostrarDependencias(36, celdaAño.Text, celdaNumero.Text)
                    Exit Sub
                End If

            End If

            ' Si hay dependencias a Factura no se puede anular.

            If Not MyCnn.CONECTAR = strConexion Then Exit Sub
            If rbNacionalizacion.Checked = False And rbExportacion.Checked = False Then
                MsgBox("You have not selected the Type" & vbCr & vbCr &
                        "Nationalization:" & vbCr & "-sales tax payments" & vbCr & vbCr &
                        "Export: " & vbCr & "- Central America or the rest of the world", vbExclamation, "Notice")
                Exit Sub
            End If

            logVacia = (Me.Tag = "Nuevo") And checkActivar.Checked = False

            'Comprueba las cantidades a descargar
            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
            Else
                If ComprobarGastos() Then
                    If ComprobarDescargos() Then
                        If ComprobarLineas() Then
                        Else
                            Exit Sub
                        End If
                    Else
                        Exit Sub
                    End If
                Else
                    Exit Sub
                End If
            End If


            If etiquetaAnulada.Visible Then
                If checkActivar.Enabled Then
                    strDato = "Status Change: CANCELED"
                Else
                    MsgBox("No changes allowed", vbExclamation, "Invoice -CANCELED-")
                End If
            End If

            Try
                If Me.Tag = "Nuevo" Then
                    If ComprobarDatos() = True Then
                        If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or (Sesion.idGiro = 2)) And celdaTipoFactura.Text >= 1 Then
                            logLibre = True
                        Else
                            'logImpuesto = PagoDeImpuestos()
                            If dgInstrucDespacho.Rows.Count > 0 Then
                                logImpuesto = PagoDeImpuestos()
                            Else
                                ' El DataGrid está vacío
                                logImpuesto = True
                            End If
                            If logImpuesto Then
                                logLibre = False
                            End If
                        End If

                        If celdaNumero.Text = NO_FILA Then
                            If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                                celdaNumero.Text = NuevaFactura()
                                'For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                                '    If dgInstrucDespacho.Rows(i).Visible = True Then
                                '        If ValidarBultos(dgInstrucDespacho.Rows(i).Cells("colAñ").Value, dgInstrucDespacho.Rows(i).Cells("colInst").Value) = False Then
                                '            Exit Sub
                                '        End If
                                '    End If
                                'Next

                            Else
                                celdaNumero.Text = cls.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 36, celdaAño.Text, celdaIdCliente.Text, True)
                            End If

                        Else
                            Dim strSQL1 As String = STR_VACIO
                            Dim COM2 As MySqlCommand
                            Dim REA As MySqlDataReader

                            strSQL1 = "SELECT COUNT(h.HDoc_Doc_Num ) conteo, h.HDoc_Doc_Num numero"
                            strSQL1 &= " FROM Dcmtos_HDR h"
                            strSQL1 &= "   WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {año} and h.HDoc_Doc_Num = {numero} "

                            strSQL1 = Replace(strSQL1, "{empresa}", Sesion.IdEmpresa)
                            strSQL1 = Replace(strSQL1, "{año}", celdaAño.Text)
                            strSQL1 = Replace(strSQL1, "{numero}", celdaNumero.Text)

                            MyCnn.CONECTAR = strConexion

                            COM2 = New MySqlCommand(strSQL1, CON)
                            REA = COM2.ExecuteReader

                            If REA.HasRows Then

                                Do While REA.Read

                                    If REA.GetInt32("conteo") = 1 Then
                                        If MsgBox("Invoice Number " & REA.GetInt32("numero") & " already exists, add another invoice number", vbInformation) = vbYes Then
                                            Exit Sub
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                Loop
                            End If

                            Dim strSQL2 As String = STR_VACIO
                            Dim COM3 As MySqlCommand
                            Dim REA3 As MySqlDataReader

                            strSQL2 = "SELECT COUNT(h.HDoc_Doc_Num ) conteo, h.HDoc_Doc_Num numero, h.HDoc_Doc_Ano Anio"
                            strSQL2 &= "     FROM Dcmtos_HDR h"
                            strSQL2 &= "          WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Num = {numero}"

                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                            MyCnn.CONECTAR = strConexion

                            COM3 = New MySqlCommand(strSQL2, CON)
                            REA3 = COM3.ExecuteReader

                            If REA3.HasRows Then
                                Do While REA3.Read

                                    If REA3.GetInt32("conteo") = 1 Then
                                        If MsgBox("Invoice Number " & REA3.GetInt32("numero") & " Already exists with year " & REA3.GetInt32("anio") & ", are you sure you want to continue ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                Loop
                            End If
                        End If

                        If celdaNumero.Text > 0 Then
                            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                            Else
                                DatosDeCliente()
                            End If

                            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                                For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                                    If dgInstrucDespacho.Rows(i).Visible = True Then
                                        If ValidarBultos(dgInstrucDespacho.Rows(i).Cells("colAñ").Value, dgInstrucDespacho.Rows(i).Cells("colInst").Value) = False Then
                                            Exit Sub
                                        End If
                                    End If
                                Next
                            End If
                            'Reescribe los datos de las instrucciones afectadas
                            ' If Not logVacia Then ReescribirInstruccion()
                            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or (Sesion.idGiro = 2)) And celdaTipoFactura.Text >= 1 Then
                            Else
                                InstruccionDespachada()
                            End If

                            GuardarDocumento()

                            If Sesion.IdEmpresa = 9 Then
                                GuardarFelServiImport()
                            End If
                            If Not logVacia Then
                                GuardarDetalle()
                                GuardarBultos()
                                If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or (Sesion.idGiro = 2)) And celdaTipoFactura.Text >= 1 Then
                                Else
                                    GuargarDescargos()
                                    DescargarReserva()
                                    ReescribirInstruccion(celdaNumero.Text)
                                End If
                            End If

                            GuardarOperacion()

                            If Me.Tag = "Nuevo" Then
                                If MsgBox("The document has been saved" & vbCr & vbCr & "¿Do you want close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                                    If logImpuesto Then
                                        MsgBox("This firm has Tax." & vbCr & vbCr & "You can not print until the certificate of origin", vbInformation, "Certificate of origin")
                                    End If
                                    MostrarLista()
                                Else
                                    cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                                    celdaAño.Enabled = False
                                    celdaNumero.Enabled = False
                                    botonCliente.Enabled = False
                                    logAdded = True
                                    'With frmSubDocumentos
                                    botonImprimir.Enabled = logLibre
                                    'End With
                                    Me.Tag = "Mod"
                                End If

                                If logVacia Then Encabezado1.botonGuardar.Enabled = False
                                If logVacia Then botonImprimir.Enabled = False
                            End If
                        End If
                    End If

                ElseIf Me.Tag = "Mod" Then      'Actualizando

                    If celdaNumero.Text > 0 Then
                        If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                        Else
                            DatosDeCliente()
                        End If

                        'If ComprobarDatos() = True Then
                        '    'logImpuesto = PagoDeImpuestos()
                        '    'If logImpuesto Then
                        '    '    logLibre = False
                        '    'End If
                        'End If
                        ComprobarDatos()
                        If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                            For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                                If dgInstrucDespacho.Rows(i).Visible = True Then
                                    If ValidarBultos(dgInstrucDespacho.Rows(i).Cells("colAñ").Value, dgInstrucDespacho.Rows(i).Cells("colInst").Value) = False Then
                                        Exit Sub
                                    End If
                                End If
                            Next
                            If (Sesion.IdEmpresa = 11) Then
                                If celdaFlete.Text <> celdaValidacionFlete.Text Then
                                    If PedirAutorizacionFlete("Flete") = False Then
                                        Exit Sub
                                    End If
                                End If

                            End If
                            If (Sesion.IdEmpresa = 12 And Pais() = 0) Then
                                'Reescribe los datos de las instrucciones afectadas
                                If celdaImpreso.Text > INT_CERO Then
                                    If checkActivar.Checked = False Then
                                        ArrayServer = strConexion.Split(";".ToCharArray)
                                        strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                                        ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                                        strCadena = ArrayServer(INT_CERO)
                                        ArrayValidacion = strCadena.Split(".".ToCharArray)
                                        strCadena = ArrayValidacion(INT_CERO)
                                        arrayIP = strCadena.Split("=".ToCharArray)
                                        If arrayIP(INT_UNO) = "192" Then
                                            If VerificarAccesoLocal(IP, strUsuario, strContrasena, strRuta) = True Then
                                            Else
                                                Exit Sub
                                            End If
                                        Else
                                            If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                                            Else
                                                Exit Sub
                                            End If
                                        End If
                                        If PermisoAnular() = True Then
                                            If (DateDiff("d", dtpFecha.Value, Now) > 5) And (dtpFecha.Value <= cfun.UltimoDiaSiguienteMes(dtpFecha.Value)) Then
                                                If PedirAutorizacionAnularFel("Anulacion Fel") = True Then
                                                    If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                                        MsgBox("You don't have access to cancel this document")
                                                        Exit Sub
                                                    End If
                                                Else
                                                    MsgBox("You don't have access to cancel this document")
                                                    Exit Sub
                                                End If
                                            ElseIf (DateDiff("d", dtpFecha.Value, Now) <= 5) Then
                                                If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                                    MsgBox("You don't have access to cancel this document")
                                                    Exit Sub
                                                End If
                                            Else
                                                MsgBox("You don't have access to cancel this document")
                                                Exit Sub
                                            End If
                                        Else
                                            MsgBox("You don't have access to cancel this document")
                                            Exit Sub
                                        End If
                                    End If
                                Else
                                    If checkActivar.Checked = False Then
                                        MsgBox("You cannot cancel a document that is not transmitted" & vbNewLine & "please contact the Financial department.")
                                        Exit Sub
                                    End If
                                End If
                            End If
                        End If
                        GuardarDocumento()
                        If Sesion.IdEmpresa = 9 Then
                            GuardarFelServiImport()
                        End If

                        GuardarDetalle()
                        GuardarBultos()
                        If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                        Else
                            GuargarDescargos()
                            DescargarReserva()
                            ReescribirInstruccion(celdaNumero.Text)
                        End If
                        GuardarOperacion()
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia() & "serie: " & celdaSerie.Text)
                        If MsgBox("The document has been stored successfully" & vbCr & vbCr & "Do you want close the document?", vbQuestion + vbYesNo + vbDefaultButton2, "Close document") = vbYes Then
                            If Not logPrinted Then
                                If logLibre Then
                                    If Not (Sesion.IdEmpresa = 12 And Pais() = 0) Then
                                        If MsgBox("The document has stored successfully" & vbCr & vbCr & "¿To print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                            Const MAX_LINEAS As Byte = 75
                                            Dim intNumero As Integer
                                            Dim intAño As Integer
                                            Dim anulada As Boolean
                                            Dim Inv As New clsReportes
                                            Dim intForma As Integer
                                            Dim logErr As Boolean


                                            If logLibre Then
                                                MsgBox("This document is locked print" & vbCr & vbCr & "Present the certificate  of origin  to the appropriate to proceed to release", vbExclamation, "Notice")
                                                MostrarLista()
                                                Exit Sub
                                            End If

                                            logPrinting = True

                                            strSQL = "SELECT cat_sist"
                                            strSQL &= " FROM Catalogos "
                                            strSQL &= "      WHERE cat_clase='Factura' AND cat_clave='Formato' AND cat_sisemp= {empresa}"

                                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

                                            conec = New MySqlConnection(strConexion)
                                            conec.Open()
                                            COM = New MySqlCommand(strSQL, conec)
                                            Using conec
                                                intForma = COM.ExecuteScalar
                                                COM.Dispose()
                                                COM = Nothing
                                                conec.Close()
                                                conec.Dispose()
                                                conec = Nothing
                                                System.GC.Collect()
                                            End Using

                                            Select Case intForma

                                                Case 0
                                                Case 1
                                                Case 2
                                                    If dgDetalle.Rows.Count > MAX_LINEAS Then


                                                        If MsgBox("NOTA: Some Lines Can Not Print." & vbCr & vbCr & "*** There are more lines in detail in the format ***", vbInformation, "Print format") Then
                                                            logErr = True
                                                            Exit Sub
                                                        End If
                                                    End If

                                                    If Not logErr Then
                                                        intAño = Val(celdaAño.Text)
                                                        intNumero = Val(celdaNumero.Text)
                                                        If checkActivar.Checked = False Then
                                                            anulada = True
                                                        Else
                                                            anulada = False
                                                        End If

                                                        Inv.ReporteInvoicing(intAño, intNumero, anulada)

                                                    End If

                                                Case 3
                                                Case 4
                                                    intAño = Val(celdaAño.Text)
                                                    intNumero = Val(celdaNumero.Text)
                                                    Inv.ReporteInvoicing_PrideYarn(intAño, intNumero)
                                                Case 5
                                                    intAño = Val(celdaAño.Text)
                                                    intNumero = Val(celdaNumero.Text)
                                                    Inv.ReporteInvoicing_Amtex(intAño, intNumero)
                                            End Select
                                            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia() & "serie: " & celdaSerie.Text)

                                        End If
                                    End If
                                End If
                            End If
                            MostrarLista()
                        End If
                    End If

                Else
                    MsgBox("It was not possible  to classify the operation to save", vbExclamation, "Notice")
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        Else
            MsgBox("You do not have acess to save a new invoice", vbInformation)
        End If

    End Sub

    Private Sub GuardarFelServiImport()
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 36
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = dtpFecha.Value.ToString(FORMATO_MYSQL)
            cFel.FECHAHORACERTIFICACION = dtpFecha.Value.ToString(FORMATO_MYSQL)
            cFel.SERIE = celdaSerieFelServi.Text
            cFel.NUMEROAUTORIZACION = celdaNumeroFel.Text
            cFel.INCOTERM = ""
            cFel.UUID = ""
            If Me.Tag = "Nuevo" Then
                If cFel.PINSERT() = False Then
                    MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            Else
                If cFel.PUPDATE() = False Then
                    MsgBox(cFel.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strSQL As String
        Dim strCondicion As String = STR_VACIO
        Dim año As Integer
        Dim numero As Integer
        strCondicion = "c.cli_sisemp  = {empresa} AND cli_tipo = 0 AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit, c.cli_moneda "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaTelefono.Text = frm.Dato3
                celdaNIT.Text = frm.Dato4

                dgInstrucDespacho.Rows.Clear()
                ListarDocumentos()
                ProcesarDocumentos()
                celdaIdMoneda.Text = frm.ListaClientes.SelectedCells(5).Value
                celdaMoneda.Text = cfun.SimboloMoneda(celdaIdMoneda.Text)
                If celdaIdMoneda.Text = cfun.DivisaLocal Then
                    celdaTasa.Text = 1
                Else
                    celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                End If

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency, cat_sist TC"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDatosFelServiImport(ByVal anio As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = " SELECT Serie, NumeroAutorizacion
                        FROM Fel
                        WHERE Empresa = {emp} AND Catalogo = 36 AND Anio = {anio} AND Numero = {num}"
            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", anio)
            strSQL = strSQL.Replace("{num}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaSerieFelServi.Text = REA.GetString("Serie")
                    celdaNumeroFel.Text = REA.GetString("NumeroAutorizacion")
                Loop

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick

        Dim año As Integer = 0
        Dim numero As Integer = 0
        Dim Linea As Integer = 0
        Dim strSQL As String = STR_VACIO
        Dim Descuento As Double
        Dim desc As Double
        Dim Totals As Double
        Dim Total As Double
        Dim SDoc As New frmSubDocumentos

        LimpiarPanelOrden()
        Try
            Me.Tag = "Mod"
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            'captura el año,numero del panelprincipal dglista
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value
            Seleccionar(año, numero)
            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                botonAgrega.Visible = True
                botonQuitar.Visible = True
            Else
                botonAgrega.Visible = False
                botonQuitar.Visible = False
            End If
            MostrarLista(0)
            If Sesion.IdEmpresa = 9 Then
                CargarDatosFelServiImport(año, numero)
            End If
            SeleccionarSubdocumentos(año, numero)
            queryCC(año, numero)
            queryDetalle(año, numero)
            If (Sesion.IdEmpresa = 18 And celdaTipoFactura.Text = INT_UNO) Or (Sesion.IdEmpresa = 21 And celdaTipoFactura.Text = INT_UNO) Or (Sesion.IdEmpresa = 22 And celdaTipoFactura.Text = INT_UNO) Or (Sesion.IdEmpresa = 19 And celdaTipoFactura.Text = INT_UNO) Then
                dgDetalle.Columns("colCta").Visible = False
                dgDetalle.Columns("colNombreCta").Visible = True
            Else
                dgDetalle.Columns("colCta").Visible = False
                dgDetalle.Columns("colNombreCta").Visible = False
            End If
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                dgDetalle.Columns("colLoteNuevo").Visible = True
            Else
                dgDetalle.Columns("colLoteNuevo").Visible = False
            End If
            CalcularTotales()
            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then

            Else
                queryInstDespacho(año, numero)
                'CalcularSeguro()
                sqlCargarRelacion()
                SqlDocsPorProcesar()
                ActualizarLista()
            End If

            If dgLista.SelectedCells(7).Value = 0 Then
                etiquetaAnulada.Visible = True
                etiquetaAnulada.BackColor = Color.Red
                etiquetaAnulada.ForeColor = Color.White
                'checkActivar.Checked = False
                checkActivar.Enabled = False
            Else
                etiquetaAnulada.Visible = False
                checkActivar.Enabled = True
            End If


            If dgLista.SelectedCells(9).Value = 1 And dgLista.SelectedCells(10).Value = 1 Then
                botonImprimir.Enabled = False
                dgDetalle.ReadOnly = True
                celdaFlete.Enabled = False
            Else
                botonImprimir.Enabled = True
                dgDetalle.ReadOnly = False
                celdaFlete.Enabled = True
            End If

            dgSubdocumentos.Enabled = True
            dgInstrucDespacho.Enabled = False
            dtpFecha.Enabled = False
            botonCliente.Enabled = False
            checkRevisado.Enabled = False
            celdaSerie.Enabled = False
            botonSeguro.Enabled = False
            'celdaFlete.Enabled = False
            'For i As Integer = 0 To dgDetalle.Rows.Count - 1
            '    Descuento = dgDetalle.Rows(i).Cells("colDesc").Value
            '    Total = dgDetalle.Rows(i).Cells("colDescDolar").Value

            '    desc = desc + Descuento
            '    Totals = Totals + Total
            'Next
            'celdaDescuento.Text = desc
            'celdaTotalDescuento.Text = Totals

            intPais = Pais()
            If (intPais = 310) Or (intPais = 327) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 22) Or (Sesion.IdEmpresa = 11) Then
                celdaNum2.Visible = True
                celdaNumero.Visible = False
                celdaSeguro.Enabled = True
            Else
                celdaNum2.Visible = False
                celdaNumero.Visible = True
                celdaSeguro.Enabled = False
            End If
            celdaNum2.Enabled = False
            If celdaImpreso.Text <> INT_CERO Then
                If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                    OcultarCampos()
                    dgDetalle.Columns("ColDescrip").ReadOnly = True
                    dgDetalle.Columns("colMedida").ReadOnly = True
                    dgDetalle.Columns("colDespacho").ReadOnly = True
                    dgDetalle.Columns("colDesc").ReadOnly = True
                    dgDetalle.Columns("colDescDolar").ReadOnly = True
                    dgDetalle.Columns("colBobina").ReadOnly = True
                    dgDetalle.Columns("colLBS").ReadOnly = True
                    dgDetalle.Columns("colKGS").ReadOnly = True
                    dgDetalle.Columns("colKGNetos").ReadOnly = False ' se desbloquea para corrección de pesos
                    dgDetalle.Columns("colOriginal").ReadOnly = True
                    dgDetalle.Columns("colBulto").ReadOnly = True
                    If celdaSerieFel.Text <> STR_VACIO Then
                        Encabezado1.botonBorrar.Enabled = True
                    Else
                        Encabezado1.botonBorrar.Enabled = False
                    End If
                End If
            Else
                If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                    ActivarCampos()
                    dgDetalle.Columns("ColDescrip").ReadOnly = False
                    dgDetalle.Columns("colMedida").ReadOnly = False
                    dgDetalle.Columns("colDespacho").ReadOnly = False
                    dgDetalle.Columns("colDesc").ReadOnly = False
                    dgDetalle.Columns("colDescDolar").ReadOnly = False
                    dgDetalle.Columns("colBobina").ReadOnly = False
                    dgDetalle.Columns("colLBS").ReadOnly = False
                    dgDetalle.Columns("colKGS").ReadOnly = False
                    dgDetalle.Columns("colKGNetos").ReadOnly = False ' se desbloquea para corrección de pesos
                    dgDetalle.Columns("colOriginal").ReadOnly = False
                    dgDetalle.Columns("colBulto").ReadOnly = False
                End If
            End If
            If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                CargarDatosFel()
            End If

            'dgDetalle.ReadOnly = True
            dtpFecha.Enabled = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonConcolidacion_Click(sender As Object, e As EventArgs) Handles botonConcolidacion.Click

        Dim frm As New frmManifiesto()

        frm.ShowDialog(Me)

    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim Bultos As Integer
        Dim intCantidad As Double
        Dim intMedida As String
        Dim Descuento As Double
        Dim TotalDesc As Double
        Dim Total As Double
        Dim Total2 As Double
        Dim Dolar As Double
        Dim KG As Double
        Dim totalKG As Double = INT_CERO
        'Dim contador1 As Double
        Dim strSQL2 As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim dblFactor As Double

        If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 9
                    dgDetalle.CurrentRow.Cells("colTotal").Value = dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colCantidad").Value
                Case 12
                    dgDetalle.CurrentRow.Cells("colTotal").Value = dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colCantidad").Value
            End Select
        Else

            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 10 ' Descuento %
                    ' For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    Descuento = dgDetalle.CurrentRow.Cells("colDesc").Value
                    Total = dgDetalle.CurrentRow.Cells("colTotal").Value
                    Total2 = ((Descuento * Total) / 100)

                    dgDetalle.CurrentRow.Cells("colDescDolar").Value = Total2.ToString(FORMATO_MONEDA)


                    TotalDesc = TotalDesc + Descuento

                    CalcularTotales()
                ' Next
                'celdaDescuento.Text = TotalDesc.ToString(FORMATO_MONEDA)
                'celdaTotalDescuento.Text = (Total - Total2).ToString(FORMATO_MONEDA)

                Case 11 ' Descuento $
                    'For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    Dolar = dgDetalle.CurrentRow.Cells("colDescDolar").Value
                    Total = dgDetalle.CurrentRow.Cells("colTotal").Value

                    Total2 = ((Dolar / Total) * 100)
                    dgDetalle.CurrentRow.Cells("colDesc").Value = Total2.ToString(FORMATO_MONEDA)
                    CalcularTotales()
                'Next
                'celdaTotalDescuento.Text = (Total - Dolar).ToString(FORMATO_MONEDA)
                'celdaDescuento.Text = Total2.ToString(FORMATO_MONEDA)

                Case 14
                    Bultos = dgDetalle.SelectedCells(14).Value
                    intCantidad = dgDetalle.SelectedCells(12).Value
                    intMedida = dgDetalle.SelectedCells(7).Value
                    CalcularKGBrutos(Bultos, intCantidad, intMedida)
                Case 17
                    If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                        If Me.Tag = "Mod" Then
                            ActualizarDestino()
                        End If
                    End If
                Case 19
                    If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                        If Me.Tag = "Mod" Then
                            ActualizarDestino()
                        End If
                    End If
                Case 20
                    strSQL2 = " SELECT cat_sist"
                    strSQL2 &= "     FROM Catalogos"
                    strSQL2 &= " WHERE cat_clave= 'KGS'"

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL2, conec)
                    Using conec
                        dblFactor = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                    dgDetalle.CurrentRow.Cells("colKGS").Value = (CDbl(dgDetalle.CurrentRow.Cells("colLBS").Value) / dblFactor).ToString(FORMATO_MONEDA)

                Case 21
                    strSQL2 = " SELECT cat_sist"
                    strSQL2 &= "     FROM Catalogos"
                    strSQL2 &= " WHERE cat_clave= 'KGS'"

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL2, conec)
                    Using conec
                        dblFactor = COM.ExecuteScalar
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                    dgDetalle.CurrentRow.Cells("colLBS").Value = (CDbl(dgDetalle.CurrentRow.Cells("colKGS").Value) * dblFactor).ToString(FORMATO_MONEDA)
                Case 22
                    dgDetalle.CurrentRow.Cells("colKGNetosExt").Value = CDbl(dgDetalle.CurrentRow.Cells("colKGNetos").Value).ToString(FORMATO_MONEDA_EXT)
            End Select
        End If
    End Sub

    'Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
    Private Sub dgDetalle_CellMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgDetalle.CellMouseDoubleClick
        ' Verificar si se ha hecho doble clic en una celda válida
        If e.RowIndex < 0 OrElse e.ColumnIndex < 0 Then
            ' MessageBox.Show("CLICK fuera", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            ' doble clic ocurrió en el encabezado de columna o fuera de las celdas
            Exit Sub
        End If

        Dim FRef As New frmFacturasRef_Aux_
        Dim NC As New frmNumCajas
        Dim CV As New frmCatVentas

        ' Verificar si el DataGridView tiene filas
        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        End If

        If dgDetalle.CurrentCell.ColumnIndex >= 0 Then
            ' Acciones según la columna
            Select Case dgDetalle.CurrentCell.ColumnIndex

                Case 1
                    MostrarReferencias()

                    Dim dblFactor As Double
                    Dim i As Integer
                    Dim dblSuma As Double
                    Dim dblSeguro As Double
                    Dim strSQL As String = STR_VACIO
                    Dim COM As MySqlCommand

                    strSQL = "SELECT COALESCE(cat_sist,0) dato"
                    strSQL &= " FROM Catalogos"
                    strSQL &= "      WHERE cat_clase='Constantes' AND cat_clave='Seguro'"


                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    dblFactor = COM.ExecuteScalar()


                    If dblFactor = vbEmpty Then
                        dblFactor = 0.01375
                    End If

                    For i = vbEmpty To dgDetalle.Rows.Count - 1
                        If dgDetalle.Rows(i).Cells("colEliminar").Value = 1 Or dgDetalle.Rows(i).Cells("colEliminar").Value = 0 Then
                            dblSuma = (dblSuma + dgDetalle.Rows(i).Cells("colTotal").Value)
                        End If
                    Next

                    dblSeguro = (dblSuma * dblFactor)
                    celdaSeguro.Text = dblSeguro.ToString(FORMATO_MONEDA)
                Case 7
                    Dim frms As New frmSeleccionar

                    frms.Titulo = "Type of Measure"
                    frms.Campos = " c.cat_num ID, c.cat_clave Measure"
                    frms.Tabla = " Catalogos c"
                    frms.FiltroText = " Enter the ID Type to filter"
                    frms.Filtro = " c.cat_num "
                    frms.Condicion = "  c.cat_clase = 'Medidas'"
                    frms.Ordenamiento = " c.cat_num"

                    frms.ShowDialog(Me)
                    If frms.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.SelectedCells(6).Value = frms.LLave
                        dgDetalle.SelectedCells(7).Value = frms.Dato
                    End If
                Case 14
                    If Me.Tag = "Nuevo" Then
                        dgDetalle.Columns("colBulto").ReadOnly = False
                    End If

                Case 15
                    Dim frm As New frmSeleccionar

                    Try
                        If celdaImpreso.Text = INT_CERO Then
                            frm.Titulo = "Package Type"
                            frm.Campos = " cat_num Number, cat_Desc Description"
                            frm.Tabla = " Catalogos"
                            frm.FiltroText = " Enter the Package Type to filter"
                            frm.Filtro = " cat_Desc "
                            frm.Condicion = "  cat_clase = 'TipoBulto'"

                            frm.ShowDialog(Me)
                            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                dgDetalle.SelectedCells(15).Value = frm.Dato
                            End If

                            If Sesion.IdEmpresa = 11 Then
                                dgDetalle.Columns("colTipoBulto").ReadOnly = False
                            End If
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 17
                    If celdaImpreso.Text > INT_CERO Then
                        If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                            If Me.Tag = "Mod" Then
                                ActualizarDistribucion()
                            End If
                        End If
                    End If

                Case 19

                    Dim frm As New frmSeleccionar
                    Dim strCondicion As String = STR_VACIO
                    strCondicion = "cli_sisemp = {empresa}"
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    Try
                        frm.Titulo = "Sales Catalog"
                        frm.Campos = " cli_codigo, cli_cliente, cli_status"
                        frm.Tabla = " Clientes"
                        frm.FiltroText = " Enter the Client Name to filter"
                        frm.Filtro = " cli_cliente "
                        frm.Condicion = strCondicion

                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                            dgDetalle.SelectedCells(18).Value = frm.LLave
                            dgDetalle.SelectedCells(19).Value = frm.Dato
                        End If
                        If celdaImpreso.Text > INT_CERO Then
                            If Sesion.IdEmpresa = 12 And Pais() = 0 Then
                                If Me.Tag = "Mod" Then
                                    ActualizarDestino()
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                Case 30
                    Dim frm As New frmSeleccionar
                    Dim strCondicion As String = STR_VACIO
                    strCondicion = "c.empresa = {empresa} AND c.id_cuenta LIKE '4102%' AND LENGTH(c.id_cuenta)>6"
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    Try
                        frm.Titulo = "Select Account"
                        frm.Campos = " c.id_cuenta Account_,c.nombre Name_"
                        frm.Tabla = cfun.ContaEmpresa & ".cuentas c"
                        frm.FiltroText = " Enter account name"
                        frm.Filtro = " c.nombre "
                        frm.Condicion = strCondicion

                        frm.ShowDialog(Me)
                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.SelectedCells(29).Value = frm.LLave
                            dgDetalle.SelectedCells(30).Value = frm.Dato
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                    'cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acCargar, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
            End Select
        End If

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            'Procedimiento para cargar panel dgLista
            queryListaPrincipal()

            For i As Integer = 0 To Me.dgLista.Rows.Count - 1
                If Me.dgLista.Rows(i).Cells(6).Value = 0 Then
                    Me.dgLista.Rows(i).Cells(2).Style.BackColor = Color.Yellow
                End If
            Next

        End If


    End Sub

    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click

        Dim frm As New frmOption
        Dim NP As New clsPolizaContable
        Dim NPC As New frmNPolizasContables


        Try
            frm.Titulo = "Mostrar Poliza Contable"
            frm.Opciones = "Venta|" & "Costos"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        NP.intModo = 9
                        NP.intTipo = 36
                        NP.intCiclo = celdaAño.Text
                        NP.intNumero = celdaNumero.Text
                        NP.MostrarPolizaContable()

                    Case 1
                        NP.intModo = 10
                        NP.intTipo = 36
                        NP.intCiclo = celdaAño.Text
                        NP.intNumero = celdaNumero.Text
                        NP.MostrarPolizaContable()
                End Select
            End If

        Catch ex As Exception
            MsgBox("It has no Accounting Policy")
        End Try

    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double
        Dim dblDesc As Double = 0

        Try
            dblDocCantidad = 0
            dblDocTotal = 0
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Visible = True Then
                    dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                    dblCant = dgDetalle.Rows(i).Cells("colCantidad").Value
                    dblDesc = (dblDesc) + (dgDetalle.Rows(i).Cells("colDescDolar").Value)
                    dblDocCantidad = dblDocCantidad + dblCant
                    dblDocTotal = dblDocTotal + (dblCant * dblPrecio).ToString("###0.00")
                End If
            Next
            celdaTotalDescuento.Text = dblDesc.ToString(FORMATO_MONEDA)
            celdaDescuento.Text = ((dblDesc / dblDocTotal) * 100).ToString(FORMATO_MONEDA) & "%"
            celdaTotal1.Text = dblDocCantidad.ToString(FORMATO_MONEDA) ' cantidad
            celdaTotal2.Text = dblDocTotal.ToString("###0.00") ' Total $
            celdaGranTotal.Text = (dblDocTotal - dblDesc).ToString("###0.00")

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgSubdocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgSubdocumentos.DoubleClick

        Dim SDoc As New frmSubDocumentos
        Dim strDoc As String
        Dim strSQL As String = STR_VACIO
        Dim ComParChil As String = STR_VACIO
        Dim logVacia As Boolean
        Dim strDato As String = STR_VACIO
        Dim cls As New clsFunciones
        Dim Distri As String
        Dim Dis As String = STR_VACIO

        strDoc = dgSubdocumentos.SelectedCells(0).Value

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            Distri = dgDetalle.Rows(i).Cells("colDistribucion").Value
            Dis = Distri & "|" & Dis
        Next


        Select Case dgSubdocumentos.CurrentCell.ColumnIndex

            Case 2
                If celdaNumero.Text = NO_FILA Then
                    Me.Tag = "Nuevo"
                    If ComprobarDatos() = True Then
                        'logImpuesto = PagoDeImpuestos()
                        'SE VALIDA QUE EL DATAGRID NO ESTA VACIO...
                        'ERROR AL ESTAR VACIO EL DATA GRID CAMBIABA EL CHECKBOX, export, nacionalization
                        If dgInstrucDespacho.Rows.Count > 0 Then
                            logImpuesto = PagoDeImpuestos()
                        Else
                            ' El DataGrid está vacío
                            logImpuesto = True
                        End If


                        If logImpuesto Then
                            logLibre = False
                        End If

                        'Comprueba las cantidades a descargar
                        If ComprobarGastos() Then
                            If ComprobarDescargos() Then
                                If ComprobarLineas() Then
                                Else
                                    Exit Sub
                                End If
                            Else
                                Exit Sub
                            End If
                        Else
                            Exit Sub
                        End If

                        If celdaNumero.Text = NO_FILA Then
                            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                                celdaNumero.Text = NuevaFactura()
                                For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                                    If dgInstrucDespacho.Rows(i).Visible = True Then
                                        If ValidarBultos(dgInstrucDespacho.Rows(i).Cells("colAñ").Value, dgInstrucDespacho.Rows(i).Cells("colInst").Value) = False Then
                                            Exit Sub
                                        End If
                                    End If
                                Next
                            Else
                                celdaNumero.Text = cls.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 36, celdaAño.Text, celdaIdCliente.Text, True)
                            End If
                        Else

                            Dim strSQL1 As String = STR_VACIO
                            Dim COM2 As MySqlCommand
                            Dim REA As MySqlDataReader

                            strSQL1 = "SELECT COUNT(h.HDoc_Doc_Num ) conteo, h.HDoc_Doc_Num numero"
                            strSQL1 &= " FROM Dcmtos_HDR h"
                            strSQL1 &= "   WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {año} and h.HDoc_Doc_Num = {numero} "

                            strSQL1 = Replace(strSQL1, "{empresa}", Sesion.IdEmpresa)
                            strSQL1 = Replace(strSQL1, "{año}", celdaAño.Text)
                            strSQL1 = Replace(strSQL1, "{numero}", celdaNumero.Text)

                            MyCnn.CONECTAR = strConexion

                            COM2 = New MySqlCommand(strSQL1, CON)
                            REA = COM2.ExecuteReader

                            If REA.HasRows Then

                                Do While REA.Read

                                    If REA.GetInt32("conteo") = 1 Then
                                        If MsgBox("Invoice Number " & REA.GetInt32("numero") & " Already exists, add another invoice number", vbInformation) = vbYes Then
                                            Exit Sub
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                Loop
                            End If

                            Dim strSQL2 As String = STR_VACIO
                            Dim COM3 As MySqlCommand
                            Dim REA3 As MySqlDataReader

                            strSQL2 = "SELECT COUNT(h.HDoc_Doc_Num ) conteo, h.HDoc_Doc_Num numero, h.HDoc_Doc_Ano Anio"
                            strSQL2 &= "     FROM Dcmtos_HDR h"
                            strSQL2 &= "          WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Num = {numero}"

                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                            MyCnn.CONECTAR = strConexion

                            COM3 = New MySqlCommand(strSQL2, CON)
                            REA3 = COM3.ExecuteReader

                            If REA3.HasRows Then
                                Do While REA3.Read

                                    If REA3.GetInt32("conteo") = 1 Then
                                        If MsgBox("Invoice Number " & REA3.GetInt32("numero") & " Already exists with year " & REA3.GetInt32("anio") & ", are you sure you want to continue ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                Loop
                            End If

                        End If

                        If celdaNumero.Text > 0 Then
                            If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or (Sesion.idGiro = 2)) And celdaTipoFactura.Text >= 1 Then
                            Else
                                DatosDeCliente()
                            End If
                            If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                                For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                                    If dgInstrucDespacho.Rows(i).Visible = True Then
                                        If ValidarBultos(dgInstrucDespacho.Rows(i).Cells("colAñ").Value, dgInstrucDespacho.Rows(i).Cells("colInst").Value) = False Then
                                            Exit Sub
                                        End If
                                    End If
                                Next
                            End If
                            'Reescribe los datos de las instrucciones afectadas
                            InstruccionDespachada()
                            GuardarDocumento()
                            'If Not logVacia Then ReescribirInstruccion()
                        End If
                        If Not logVacia Then
                            GuardarDetalle()
                            GuargarDescargos()
                            GuardarBultos()
                            DescargarReserva()
                            ReescribirInstruccion(celdaNumero.Text)
                        End If
                        GuardarOperacion()
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                        SDoc.Año = celdaAño.Text
                        intPais = Pais()
                        If intPais = 310 Or (Sesion.IdEmpresa = 16) Or Sesion.idGiro = 2 Then
                            SDoc.Numero = celdaNum2.Text
                        Else
                            SDoc.Numero = celdaNumero.Text
                        End If

                        SDoc.Doc = strDoc
                        SDoc.Anuladas = checkActivar.Checked
                        SDoc.Catalogo = 36
                        SDoc.Division = PedirCopias()
                        SDoc.Distribucion = Dis
                        SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                        If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                            SDoc.btnImprimir.Enabled = False
                        Else
                            SDoc.btnImprimir.Enabled = True
                        End If

                        SDoc.ShowDialog(Me)

                        Me.Tag = "Mod"
                    End If
                    Me.Tag = "Mod"
                ElseIf celdaNumero.Text > 0 Then  'ELSE SUB DOCUMENTOS, VERIFICA LINEA
                    If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                        permiteWord = True
                    End If
                    If dgSubdocumentos.SelectedCells(2).Value = "NO" Then

                        If ComprobarDatos() = True Then
                            'logImpuesto = PagoDeImpuestos()
                            If dgInstrucDespacho.Rows.Count > 0 Then
                                logImpuesto = PagoDeImpuestos()
                            Else
                                ' El DataGrid está vacío
                                logImpuesto = True
                            End If
                            If logImpuesto Then
                                logLibre = False
                            End If
                        End If

                        'Comprueba las cantidades a descargar
                        If ComprobarGastos() Then
                            If ComprobarDescargos() Then
                                If ComprobarLineas() Then
                                Else
                                    Exit Sub
                                End If
                            Else
                                Exit Sub
                            End If
                        Else
                            Exit Sub
                        End If

                        If Me.Tag = "Nuevo" Then
                            Dim strSQL1 As String = STR_VACIO
                            Dim COM2 As MySqlCommand
                            Dim REA As MySqlDataReader

                            strSQL1 = "SELECT COUNT(h.HDoc_Doc_Num ) conteo, h.HDoc_Doc_Num numero"
                            strSQL1 &= " FROM Dcmtos_HDR h"
                            strSQL1 &= "   WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {año} and h.HDoc_Doc_Num = {numero} "

                            strSQL1 = Replace(strSQL1, "{empresa}", Sesion.IdEmpresa)
                            strSQL1 = Replace(strSQL1, "{año}", celdaAño.Text)
                            strSQL1 = Replace(strSQL1, "{numero}", celdaNumero.Text)

                            MyCnn.CONECTAR = strConexion

                            COM2 = New MySqlCommand(strSQL1, CON)
                            REA = COM2.ExecuteReader

                            If REA.HasRows Then

                                Do While REA.Read

                                    If REA.GetInt32("conteo") = 1 Then
                                        If MsgBox("El numero de factura " & REA.GetInt32("numero") & " ya existe, agregue otro numero de factura", vbInformation) = vbYes Then
                                            Exit Sub
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                Loop
                            End If

                            Dim strSQL2 As String = STR_VACIO
                            Dim COM3 As MySqlCommand
                            Dim REA3 As MySqlDataReader

                            strSQL2 = "SELECT COUNT(h.HDoc_Doc_Num ) conteo, h.HDoc_Doc_Num numero, h.HDoc_Doc_Ano Anio"
                            strSQL2 &= "     FROM Dcmtos_HDR h"
                            strSQL2 &= "          WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Num = {numero}"

                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                            MyCnn.CONECTAR = strConexion

                            COM3 = New MySqlCommand(strSQL2, CON)
                            REA3 = COM3.ExecuteReader

                            If REA3.HasRows Then
                                Do While REA3.Read

                                    If REA3.GetInt32("conteo") = 1 Then
                                        If MsgBox("Invoice Number " & REA3.GetInt32("numero") & " Already exists with year " & REA3.GetInt32("anio") & ", are you sure you want to continue ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                        Else
                                            Exit Sub
                                        End If
                                    End If
                                Loop
                            End If

                            If celdaSubDocumento.Text = 0 Then
                                If celdaNumero.Text > 0 Then
                                    If (Sesion.IdEmpresa = 9 Or Sesion.idGiro = 1 Or Sesion.idGiro = 2) And celdaTipoFactura.Text >= 1 Then
                                    Else
                                        DatosDeCliente()
                                    End If
                                    If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                                        For i As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                                            If dgInstrucDespacho.Rows(i).Visible = True Then
                                                If ValidarBultos(dgInstrucDespacho.Rows(i).Cells("colAñ").Value, dgInstrucDespacho.Rows(i).Cells("colInst").Value) = False Then
                                                    Exit Sub
                                                End If
                                            End If
                                        Next
                                    End If
                                    'Reescribe los datos de las instrucciones afectadas
                                    'If Not logVacia Then ReescribirInstruccion()
                                    InstruccionDespachada()
                                    GuardarDocumento()
                                End If
                                If Not logVacia Then
                                    GuardarDetalle()
                                    GuargarDescargos()
                                    GuardarBultos()
                                    DescargarReserva()
                                    ReescribirInstruccion(celdaNumero.Text)
                                End If

                                GuardarOperacion()
                            End If

                            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        End If
                        If dgSubdocumentos.SelectedCells(2).Value = "NO" Then
                            SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                            SDoc.Año = CInt(celdaAño.Text)
                            intPais = Pais()
                            'If intPais = 310 Then
                            '    SDoc.Numero = celdaNum2.Text
                            'Else
                            SDoc.Numero = celdaNumero.Text
                            'End If
                            SDoc.Catalogo = 36
                            SDoc.Doc = strDoc
                            SDoc.Division = PedirCopias()
                            SDoc.Distribucion = Dis
                            SDoc.Anuladas = checkActivar.Checked
                            celdaSubDocumento.Text = 1
                            SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                            If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                                SDoc.btnImprimir.Enabled = False
                            Else
                                SDoc.btnImprimir.Enabled = True
                            End If
                            SDoc.ShowDialog(Me)
                            celdaNum2.Enabled = False
                            Me.Tag = "Mod"
                        Else
                            SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                            SDoc.Año = celdaAño.Text
                            intPais = Pais()
                            'If intPais = 310 Then
                            '    SDoc.Numero = celdaNum2.Text
                            'Else
                            SDoc.Numero = celdaNumero.Text
                            'End If
                            SDoc.Doc = strDoc
                            SDoc.Catalogo = 36
                            SDoc.Anuladas = checkActivar.Checked
                            SDoc.Division = PedirCopias()
                            SDoc.Distribucion = Dis
                            SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                            If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                                SDoc.btnImprimir.Enabled = False
                            Else
                                SDoc.btnImprimir.Enabled = True
                            End If
                            celdaSubDocumento.Text = 1
                            SDoc.ShowDialog(Me)
                            celdaNum2.Enabled = False
                            Me.Tag = "Mod"
                            If dgSubdocumentos.SelectedCells(2).Value = "SI" Then

                                SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                                SDoc.Año = CInt(celdaAño.Text)
                                intPais = Pais()
                                'If intPais = 310 Then
                                '    SDoc.Numero = celdaNum2.Text
                                'Else
                                SDoc.Numero = celdaNumero.Text
                                'End If
                                SDoc.Catalogo = 36
                                SDoc.Doc = strDoc
                                SDoc.Division = PedirCopias()
                                SDoc.Distribucion = Dis
                                SDoc.Anuladas = checkActivar.Checked
                                SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                                If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                                    SDoc.btnImprimir.Enabled = False
                                Else
                                    SDoc.btnImprimir.Enabled = True
                                End If
                                SDoc.ShowDialog(Me)
                                celdaNum2.Enabled = False
                            Else
                                SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                                SDoc.Año = celdaAño.Text
                                intPais = Pais()
                                'If intPais = 310 Then
                                '    SDoc.Numero = celdaNum2.Text
                                'Else
                                SDoc.Numero = celdaNumero.Text
                                'End If
                                SDoc.Doc = strDoc
                                SDoc.Catalogo = 36
                                SDoc.Division = PedirCopias()
                                SDoc.Distribucion = Dis
                                SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                                If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                                    SDoc.btnImprimir.Enabled = False
                                Else
                                    SDoc.btnImprimir.Enabled = True
                                End If
                                SDoc.ShowDialog(Me)
                                celdaNum2.Enabled = False
                            End If
                            Me.Tag = "Mod"
                        End If
                    Else 'ELSE VERIFICA SEGUNDA COLUMNA SEA "SI"
                        Me.Tag = "Mod"
                        If dgSubdocumentos.SelectedCells(2).Value = "SI" Then
                            'If celdaSubDocumento.Text = 0 Then
                            '    If celdaNumero.Text > 0 Then
                            '        DatosDeCliente()

                            '        'Reescribe los datos de las instrucciones afectadas
                            '        If Not logVacia Then ReescribirInstruccion()

                            '        InstruccionDespachada()

                            '        GuardarDocumento()
                            '    End If
                            '    If Not logVacia Then
                            '        GuardarDetalle()
                            '        GuargarDescargos()
                            '        GuardarBultos()
                            '        DescargarReserva()
                            '    End If

                            '    GuardarOperacion()

                            'End If
                            SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                            SDoc.Año = CInt(celdaAño.Text)
                            intPais = Pais()
                            'If intPais = 310 Then
                            '    SDoc.Numero = celdaNum2.Text
                            'Else
                            SDoc.Numero = celdaNumero.Text
                            SDoc.Numero2 = celdaNum2.Text
                            'End If
                            SDoc.Catalogo = 36
                            SDoc.Doc = strDoc
                            SDoc.Anuladas = checkActivar.Checked
                            SDoc.Division = PedirCopias()
                            SDoc.Distribucion = Dis
                            SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                            If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                                SDoc.btnImprimir.Enabled = False
                            Else
                                SDoc.btnImprimir.Enabled = True
                            End If
                            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Then
                                permiteWord = True
                            End If
                            SDoc.ShowDialog(Me)
                            celdaNum2.Enabled = False
                        Else
                            SDoc.SubDocumento = dgSubdocumentos.SelectedCells(0).Value
                            SDoc.Año = celdaAño.Text
                            intPais = Pais()
                            'If intPais = 310 Then
                            '    SDoc.Numero = celdaNum2.Text
                            'Else
                            SDoc.Numero = celdaNumero.Text
                            'End If
                            SDoc.Doc = strDoc
                            SDoc.Catalogo = 36
                            SDoc.Division = PedirCopias()
                            SDoc.Distribucion = Dis
                            SDoc.Line = dgDetalle.CurrentRow.Cells("colLinea2").Value
                            If dgLista.SelectedCells(8).Value = 1 And dgLista.SelectedCells(9).Value = 1 Then
                                SDoc.btnImprimir.Enabled = False
                            Else
                                SDoc.btnImprimir.Enabled = True
                            End If
                            SDoc.ShowDialog(Me)
                            celdaNum2.Enabled = False
                        End If
                        Me.Tag = "Mod"
                    End If
                End If
                Me.Tag = "Mod"
        End Select
    End Sub

    Private Sub dgLista_SelectionChanged(sender As Object, e As EventArgs) Handles dgLista.SelectionChanged
        Dim año As Integer
        Dim numero As Integer

        If CheckMuestraDetalle.Checked = True Then
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value
            queryCheckMuestraDetalle(año, numero)
        Else
            celdaInfoDetalle.Text = " "
        End If
    End Sub

    Private Sub checkActivar_Click(sender As Object, e As EventArgs) Handles checkActivar.Click
        Dim clsConta As New clsContabilidad

        If checkActivar.Checked = False Then
            etiquetaAnulada.Visible = True
            etiquetaAnulada.ForeColor = Color.Red
            etiquetaAnulada.BackColor = Color.Orange
        Else
            etiquetaAnulada.Visible = False
        End If

    End Sub

    Private Sub botonCarga_Click(sender As Object, e As EventArgs) Handles botonCarga.Click

        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer


        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "      SELECT IFNULL(h.HDoc_RF2_Cod,0) cargado,h.HDoc_Doc_Status estado"
            strSQL &= "   FROM Dcmtos_HDR h"
            strSQL &= "  WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)
            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Cargado") = vbEmpty Then
                        If MsgBox("Indicate that the invoice: " & numero & " it was loaded. " & vbNewLine & vbNewLine & "NOTA: These changes are not reversibles. Do you wish to continue?", vbQuestion + vbYesNo + vbDefaultButton2, "Print release") = vbYes Then
                            strSQL = ""
                            strSQL &= "    UPDATE Dcmtos_HDR h set h.HDoc_RF2_Cod = 1 "
                            strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR h set h.HDoc_RF2_Cod = 1 "
                                strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)

                            dgLista.SelectedCells(3).Style.BackColor = Color.White
                        End If
                    Else
                        MsgBox("The document was already loaded")
                    End If
                End If

                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL, CON)
                COM2.ExecuteNonQuery()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acCarga, celdaIdCliente.Text, tipo, año, numero)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click

        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer


        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "       SELECT IFNULL(h.HDoc_RF1_Cod,0) cargado,h.HDoc_Doc_Status estado"
            strSQL &= "     From Dcmtos_HDR h"
            strSQL &= "   WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
            strSQL &= "  LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()
                'No Anulados
                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Cargado") = vbEmpty Then
                        If MsgBox("indicate that the invoice: " & numero & " it was loaded. " & vbNewLine & vbNewLine & "NOTA: These changes will not be reversible. Do you wish to continue?", vbQuestion + vbYesNo + vbDefaultButton2, "Print release") = vbYes Then
                            strSQL = ""
                            strSQL &= "    UPDATE Dcmtos_HDR h set h.HDoc_RF1_Cod = 1 "
                            strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR h set h.HDoc_RF1_Cod = 1 "
                                strSQL &= "WHERE h.HDoc_Sis_Emp={empresa} AND h.HDoc_Doc_Cat=36 AND h.HDoc_Doc_Ano={año} AND h.HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)

                            dgLista.SelectedCells(4).Style.BackColor = Color.White
                        End If
                    Else
                        MsgBox("The document was already loaded")
                    End If
                End If

                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL, CON)
                COM2.ExecuteNonQuery()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acPoliza, celdaIdCliente.Text, tipo, año, numero)

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub botonSalida_Click(sender As Object, e As EventArgs) Handles botonSalida.Click
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer
        Dim logFecha As Boolean
        Dim Hoy As Date
        Hoy = cFunciones.HoyMySQL


        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "       SELECT CASE  WHEN  HDoc_DR1_Fec IS NULL  THEN  0  WHEN HDoc_DR1_Fec='0001-01-01' THEN 0  ELSE 1 END  Salida, IFNULL(HDoc_DR2_Cat,0) Impreso, HDoc_Doc_Status Estado"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "  WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()

                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Impreso") = vbEmpty Then
                        MsgBox("To print the document before confirming his departure", vbExclamation, "Notice")
                    Else
                        logFecha = (REA.GetInt32("Salida") = INT_UNO)
                        If logFecha Then
                            dgLista.SelectedCells(1).Style.BackColor = Color.White
                            dgLista.SelectedCells(2).Style.BackColor = Color.White

                        ElseIf MsgBox("Confirms the outputs of invoice number" & numero & "?", vbQuestion + vbYesNo + vbDefaultButton2, "Exit confirmation") = vbYes Then
                            strSQL = "    UPDATE Dcmtos_HDR SET HDoc_DR1_Fec='{dato}'"
                            strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR SET HDoc_DR1_Fec='{dato}'"
                                strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            End If

                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)
                            strSQL = Replace(strSQL, "{dato}", Hoy.ToString(FORMATO_MYSQL))
                        End If
                    End If

                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(strSQL, CON)
                    COM2.ExecuteNonQuery()

                    'Actualizar fecha de autorización
                    strSQL = " REPLACE INTO Dcmtos_ACC (ADoc_Sis_Emp,ADoc_Doc_Cat,ADoc_Doc_Ano,ADoc_Doc_Num,ADoc_Doc_Sub,ADoc_Doc_Lin,ADoc_Dta_Des,ADoc_Dta_Chr,ADoc_Dta_Txt) VALUES ({empresa},36,{año},{numero},'{grupo}','{linea}','{nombre}',CURDATE(),'')"
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{año}", año)
                    strSQL = Replace(strSQL, "{numero}", numero)
                    strSQL = Replace(strSQL, "{grupo}", ("Doc_CFNotas"))
                    strSQL = Replace(strSQL, "{linea}", ("01"))
                    strSQL = Replace(strSQL, "{nombre}", ("Fecha de Autorizacion"))
                    strSQL = Replace(strSQL, "{dato}", Hoy)


                    dgLista.SelectedCells(2).Style.BackColor = Color.White

                End If

                MyCnn.CONECTAR = strConexion
                COM3 = New MySqlCommand(strSQL, CON)
                COM3.ExecuteScalar()

                'Registrar evento
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acSalida, celdaIdCliente.Text, tipo, año, numero)
                MsgBox("The date of authorization has been update notes", vbInformation, "Exit confirmation")
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

    End Sub

    Private Sub botonLiberar_Click(sender As Object, e As EventArgs) Handles botonLiberar.Click
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim strSQL As String
        Dim año As Integer
        Dim tipo As Integer
        Dim numero As Integer
        Dim logFecha As Boolean

        If dgLista.SelectedRows.Count = 0 Then

        Else

            tipo = 36
            año = dgLista.SelectedCells(0).Value
            numero = dgLista.SelectedCells(1).Value

            strSQL = "       SELECT IFNULL(HDoc_DR2_Emp,0) Pago, IF(ISNULL(HDoc_DR2_Fec),0,1) Liberado, IFNULL(HDoc_DR2_Cat,0) Impreso, HDoc_Doc_Status Estado"
            strSQL &= "     FROM Dcmtos_HDR"
            strSQL &= "  WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
            strSQL &= " LIMIT 1"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", año)
            strSQL = Replace(strSQL, "{numero}", numero)

            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                REA.Read()



                'No Anulados
                If REA.GetInt32("Estado") = INT_UNO Then
                    If REA.GetInt32("Pago") = vbEmpty Then
                        MsgBox("This office has no tax" & vbNewLine & vbNewLine & "It is not necesary to block printing", vbExclamation, "Notice")
                    Else
                        logFecha = (REA.GetInt32("Liberado") = INT_UNO)
                        If logFecha Then
                            MsgBox("This bill has no restrictions printed", vbInformation, "Notice")
                        ElseIf MsgBox("Release the invoice number " & numero & "?" & vbNewLine & vbNewLine & "NOTA: and you must have a certificate of origin", vbQuestion + vbYesNo + vbDefaultButton2, "Liberar Impresión") = vbYes Then

                            strSQL = "    UPDATE Dcmtos_HDR SET HDoc_DR2_Emp=1, HDoc_DR2_Fec={dato}"
                            strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL &= ";    UPDATE PDM.Dcmtos_HDR SET HDoc_DR2_Emp=1, HDoc_DR2_Fec={dato}"
                                strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=36 AND HDoc_Doc_Ano={año} AND HDoc_Doc_Num={numero}"
                            End If
                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                            strSQL = Replace(strSQL, "{año}", año)
                            strSQL = Replace(strSQL, "{numero}", numero)
                            strSQL = Replace(strSQL, "{dato}", "CURDATE()")


                            dgLista.SelectedCells(2).Style.BackColor = Color.Orange
                        End If

                        MyCnn.CONECTAR = strConexion
                        COM2 = New MySqlCommand(strSQL, CON)
                        COM2.ExecuteNonQuery()

                        'Registrar evento
                        cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acLiberar, celdaIdCliente.Text, tipo, año, numero)
                        MsgBox("It is released the printing of this document", vbInformation, "Notice")
                    End If
                End If

            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

            queryListaPrincipal()
        End If
    End Sub
    Private Sub CalcularSeguro()
        Dim dblFactor As Double
        Dim i As Integer
        Dim dblSuma As Double
        Dim dblSeguro As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = "SELECT COALESCE(cat_sist,0) dato"
        strSQL &= " FROM Catalogos"
        strSQL &= "      WHERE cat_clase='Constantes' AND cat_clave='Seguro'"


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dblFactor = COM.ExecuteScalar()

        If Sesion.IdEmpresa = 9 Then
            dblFactor = 0
        Else
            If dblFactor = vbEmpty Then
                dblFactor = 0.01375
            End If
        End If


        For i = vbEmpty To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colEliminar").Value = 1 Or dgDetalle.Rows(i).Cells("colTotal").Value = 0 Then
                dblSuma = (dblSuma + dgDetalle.Rows(i).Cells("colTotal").Value)
            End If
        Next

        dblSeguro = (dblSuma * dblFactor)
        celdaSeguro.Text = dblSeguro.ToString(FORMATO_MONEDA)
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            Dim dblFlt As Double = 0
            dblFlt = (dblSuma * 0.01)
            celdaFlete.Text = dblFlt.ToString(FORMATO_MONEDA)
        Else
            celdaFlete.Text = Val(celdaFlete.Text).ToString(FORMATO_MONEDA)
        End If
    End Sub
    'Calcula el seguro con 1.38% como base (1.375) y la suma como FOB
    Private Sub botonSeguro_Click(sender As Object, e As EventArgs) Handles botonSeguro.Click
        CalcularSeguro()

    End Sub

    Private Function BuscarRegistrosDcmtos_HDR_Polizas(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDR.xml", XmlWriteMode.WriteSchema)
        End If

    End Function

    Private Function BuscarRegistrosDcmtos_HDR_SV(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRsv.xml", XmlWriteMode.WriteSchema)
        End If

    End Function
    Private Function BuscarHDRHSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionHDRHSM.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarHDRNS(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionHDRNS.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarDTLHSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionDTLHSM.xml", XmlWriteMode.WriteSchema)
        End If
    End Function

    Private Function BuscarDTLNS(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionDTLNS.xml", XmlWriteMode.WriteSchema)
        End If
    End Function

    Private Function BuscarEmpresaHSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas2")
        adaptador.Fill(Tablas, "Empresas")
        If Tablas.Tables("Empresas").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionEmpresaHSM.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarEmpresaNS(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas2")
        adaptador.Fill(Tablas, "Empresas")
        If Tablas.Tables("Empresas").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionEmpresaNS.xml", XmlWriteMode.WriteSchema)
        End If
    End Function

    Private Function BuscarSerieHSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas2")
        adaptador.Fill(Tablas, "Catalogos")
        If Tablas.Tables("Catalogos").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionCatalogosHSM.xml", XmlWriteMode.WriteSchema)
        End If
    End Function

    Private Function BuscarSerieNS(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas2")
        adaptador.Fill(Tablas, "Catalogos")
        If Tablas.Tables("Catalogos").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionCatalogosNS.xml", XmlWriteMode.WriteSchema)
        End If
    End Function

    Private Function BuscarSigno(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\Signo.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Sub ImpresionFacturaHSM(ByVal strRespuesta As String, ByVal intTipoFacturaHSM As Integer)
        Dim COM2 As MySqlCommand
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO

        Dim clsConta As New clsContabilidad
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        ''encabezado
        ''CONCAT(CAST(IFNULL(cm.cat_clave,'') AS CHAR) ,' ',FORMAT(SUM(IFNULL(ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,2),0)),2)) AS 'fact_total1',
        ''(SUM(IFNULL(ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,2),0)))*a.HDoc_Doc_TC AS 'fact_total2',
        strSQL = "SELECT if(a.HDoc_Doc_Status=1,'','ANULADA') Anulada,
                    c.cli_RegistroNo,
                    a.HDoc_DR2_Cat,
                    a.HDoc_Doc_Num AS 'fact_id',
                    a.HDoc_DR2_Num AS 'fact_serie',
                    CAST(LPAD(a.HDoc_DR1_Dbl,8,0) AS CHAR) AS 'fact_num',

                    c.cli_cliente AS 'cli_nombre',
                    c.cli_nit AS 'cli_nit',
                    a.HDoc_Emp_Dir AS 'cli_direccion',
                    c.cli_telefono AS 'cli_telefono',
                    cont.cnt_correo AS 'cli_email',
                    c.cli_RegistroNo AS 'cli_registro',
                    a.HDoc_Doc_Fec AS 'fact_fecha',
                    a.HDoc_Doc_TC AS 'fact_tasa',
                    a.HDoc_RF1_Dbl AS 'fact_fleteV1',
                    a.HDoc_RF2_Dbl AS 'fact_seguroV1',
                    c.cli_plazoCR AS 'cli_diasCredito',
                    DATE_ADD(a.HDoc_Doc_Fec, INTERVAL IFNULL(c.cli_plazoCR,0) DAY) AS 'fact_fechaVence',

                    CAST(IFNULL(cm.cat_clave,'') AS CHAR) as 'fact_simbolo_moneda',
                    IF(a.HDoc_Sis_Emp = 15,'{Intercom}',cost.cat_desc) AS 'fact_incoterm',
                    IF(hdr.HDoc_DR2_Cat = 2180 or hdr.HDoc_DR2_Cat = 2487,a.HDoc_RF1_Dbl,0) AS 'fact_flete', 
                    IF(hdr.HDoc_DR2_Cat = 2180 or hdr.HDoc_DR2_Cat = 2487,a.HDoc_RF2_Dbl,0) AS 'fact_seguro', 

                    CONCAT(CAST(IFNULL(cm.cat_clave,'') AS CHAR),' ', IF(hdr.HDoc_DR2_Cat = 2180 or hdr.HDoc_DR2_Cat = 2487, FORMAT(SUM(IFNULL((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),0)) + (a.HDoc_RF2_Dbl + a.HDoc_RF1_Dbl),2), FORMAT(SUM(IFNULL((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),0)),2))) AS 'fact_total1',
                    -- round(a.HDoc_Doc_TC * Round(IF(hdr.HDoc_DR2_Cat = 2180 or hdr.HDoc_DR2_Cat = 2487, (SUM(IFNULL((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),0)) + (a.HDoc_RF2_Dbl + a.HDoc_RF1_Dbl)), (SUM(IFNULL((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),0)))),2),2) AS 'fact_total2', 
                    ROUND(a.HDoc_Doc_TC * ROUND(IF(hdr.HDoc_DR2_Cat = 2180 or hdr.HDoc_DR2_Cat = 2487, (SUM(IFNULL((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),0)) + (a.HDoc_RF2_Dbl + a.HDoc_RF1_Dbl)), (SUM(IFNULL((ROUND(d.DDoc_Prd_QTY,4) * ROUND(d.DDoc_Prd_NET,4)),0)))),4),4) AS 'fact_total2',
                    IFNULL(a.HDoc_RF2_Txt,'') AS 'fact_cai',
                    CAST(LPAD(gf.rango_inicial,8,0) AS CHAR) AS 'gf_rangoi',
                    CAST(LPAD(gf.rango_final,8,0) AS CHAR) AS 'gf_rangof',
                    gf.autorizacion AS 'gf_autorizacion',


                    IFNULL(ac.ADoc_Dta_Chr,'') contenedor,
                    IFNULL(acc.ADoc_Dta_Txt,'') transporte,
                    acd.ADoc_Dta_Chr Subdocumento,
	                    (SELECT SUM(BDoc_Box_QTY) -- AS Cantidad
	                        FROM Dcmtos_DTL_Box
		                    WHERE BDoc_Sis_Emp = a.HDoc_Sis_Emp
			                    AND BDoc_Doc_Cat = a.HDoc_Doc_Cat
			                    AND BDoc_Doc_Ano = a.HDoc_Doc_Ano
			                    AND BDoc_Doc_Num = a.HDoc_Doc_Num) Bultos,
                    '-' Orden,
                    0 PesoKG,
                    IF(c.cli_forma='CREDIT','CREDITO', c.cli_forma ) Credito ,
                    a.HDoc_Doc_Fec Despachado

                    FROM Dcmtos_HDR a
                    LEFT JOIN Dcmtos_DTL d	-- Detalle factura
	                    ON d.DDoc_Sis_Emp = a.HDoc_Sis_Emp
		                    AND d.DDoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND d.DDoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND d.DDoc_Doc_Num = a.HDoc_Doc_Num
                    LEFT JOIN Dcmtos_ACC ac -- Contenedor
	                    ON ac.ADoc_Sis_Emp =a.HDoc_Sis_Emp
		                    AND ac.ADoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND ac.ADoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND ac.ADoc_Doc_Num = a.HDoc_Doc_Num
		                    AND ac.ADoc_Doc_Sub = 'Doc_HFDatos'
		                    AND ac.ADoc_Doc_Lin ='03'
                    LEFT JOIN Dcmtos_ACC acd -- Subdocumento
	                    ON acd.ADoc_Sis_Emp =a.HDoc_Sis_Emp
		                    AND acd.ADoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND acd.ADoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND acd.ADoc_Doc_Num = a.HDoc_Doc_Num
		                    AND acd.ADoc_Doc_Sub = 'Doc_CFNotas'
		                    AND acd.ADoc_Doc_Lin ='01'
                    LEFT JOIN Dcmtos_ACC acc -- Transporte
	                    ON acc.ADoc_Sis_Emp =a.HDoc_Sis_Emp
		                    AND acc.ADoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND acc.ADoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND acc.ADoc_Doc_Num = a.HDoc_Doc_Num
		                    AND acc.ADoc_Doc_Sub = 'Doc_CCPorte2'
		                    AND acc.ADoc_Doc_Lin ='05'
                    {tablas}
                    INNER JOIN Clientes AS c -- Clientes
	                    ON c.cli_sisemp = a.HDoc_Sis_Emp
		                    AND c.cli_codigo = a.HDoc_Emp_Cod
                    LEFT JOIN Catalogos AS cm -- Monedas
	                    ON cm.cat_clase='Monedas'
		                    AND cm.cat_num=a.HDoc_Doc_Mon
		              LEFT JOIN Dcmtos_DTL_Pro pro
		              	  ON a.HDoc_Sis_Emp=pro.PDoc_Sis_Emp
		              	  	  AND a.HDoc_Doc_Cat=pro.PDoc_Chi_Cat
								  AND a.HDoc_Doc_Num=pro.PDoc_Chi_Num
		              	  	  AND a.HDoc_Doc_Ano=pro.PDoc_Chi_Ano
		                      AND d.DDoc_Doc_Lin = pro.PDoc_Chi_Lin
                      LEFT JOIN Dcmtos_HDR hdr
		              	  ON hdr.HDoc_Sis_Emp=pro.PDoc_Sis_Emp
		              	  	  AND hdr.HDoc_Doc_Cat=pro.PDoc_Par_Cat
								  AND hdr.HDoc_Doc_Num=pro.PDoc_Par_Num
		              	  	  AND hdr.HDoc_Doc_Ano=pro.PDoc_Par_Ano
                    LEFT JOIN Catalogos AS cost -- Incoterms
	                    ON cost.cat_clase='Costeo'
		                    AND cost.cat_num=hdr.HDoc_DR2_Cat
                    LEFT JOIN Contactos AS cont -- Contacto (campo email)
	                    ON cont.cnt_sisemp=c.cli_sisemp
		                    AND cont.cnt_codemp=c.cli_codigo
                    LEFT JOIN Gface gf -- Informacion CAI
	                    ON a.HDoc_Sis_Emp=gf.empresa 
		                    AND a.HDoc_RF2_Txt=gf.regimen
                        WHERE a.HDoc_Sis_Emp = {empresa}
	                        AND a.HDoc_Doc_Cat = 36
	                        AND a.HDoc_Doc_Ano = {anio}
	                         AND a.HDoc_Doc_Num = {numero}
                        GROUP BY a.HDoc_Doc_Cat,
	                        a.HDoc_Doc_Ano,
	                        a.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{Intercom}", strRespuesta)
        If intTipoFacturaHSM = 1 Then
            strSQL = Replace(strSQL, "{tablas}", STR_VACIO)
        Else
            strSQL = Replace(strSQL, "{tablas}", " INNER JOIN Inventarios AS i -- Inventarios
	                    ON i.inv_sisemp = d.DDoc_Sis_Emp
		                    AND i.inv_numero = d.DDoc_Prd_Cod
                    INNER JOIN Catalogos AS o -- Paises
	                    ON o.cat_clase = 'Paises'
		                    AND o.cat_num = i.inv_lugarfab")
        End If


        If BuscarHDRHSM(strSQL) = True Then
        End If
        ''detalle
        ''  ) a GROUP BY prod_codigo, prod_descripcion, prod_bultos, prod_precio, Medida, Lote, Fabricante, Referencia, PF
        If intTipoFacturaHSM = 1 Then
            strSQL2 = " SELECT 
		                        d.DDoc_Prd_Cod AS 'prod_codigo', 
		                        d.DDoc_Prd_Des AS 'prod_descripcion', 
		                        IFNULL((
		                        SELECT SUM(b.BDoc_Box_QTY)
		                        FROM Dcmtos_DTL_Box b
		                        WHERE b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num= 		d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin),0) AS 'prod_bultos', 
		                        d.DDoc_Prd_QTY AS 'prod_cantidad', 
		                        d.DDoc_Prd_NET AS 'prod_precio', 
		                        ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,4) Monto,c.cat_clave Medida, 'N/A' Lote, 'HONDURAS' Fabricante,''Referencia,'' PF, IFNULL((
		                        SELECT SUM(b.BDoc_Box_QTY)
		                        FROM Dcmtos_DTL_Box b
		                        WHERE b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num 		= d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin),0) AS 'Cajas',
		                        d.DDoc_PRD_DSQ descuentos 
            FROM Dcmtos_HDR h
            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
            LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase ='Medidas'
            LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon
            LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon
            LEFT JOIN Catalogos v ON v.cat_sist = 'DEF_COUNTRY'
            LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod
            LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais
            LEFT JOIN Empresas emp ON emp.emp_no = h.HDoc_Sis_Emp
            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}"
        Else
            strSQL2 = "SELECT prod_codigo, prod_descripcion, prod_bultos, SUM(prod_cantidad)prod_cantidad, prod_precio,round(SUM(Monto),2) Monto, Medida, Lote, Fabricante, Referencia,
PF, SUM(Cajas) Cajas, ifnull(descuento,0) descuentos 
FROM (
SELECT 
                    d.DDoc_PRD_DSQ descuento,
	                d.DDoc_Prd_Cod AS 'prod_codigo',
	                IF(d.DDoc_Prd_Des LIKE '%RENTA%', d.DDoc_Prd_Des, a.art_DCorta) AS 'prod_descripcion',
	                d.DDoc_RF2_Txt AS 'prod_bultos', 
	                d.DDoc_Prd_QTY AS 'prod_cantidad',
	                d.DDoc_Prd_NET AS 'prod_precio', 
	                ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,4) Monto, 
	                cm.cat_clave Medida, 
	                -- IF(i.inv_prodlote='','', CONCAT('',IFNULL(d.DDoc_Prd_PNR,i.inv_prodlote))) Lote,  
                    IF(i.inv_prodlote='',d.DDoc_Prd_PNR, CONCAT('',i.inv_prodlote)) Lote, 
	                IFNULL(p.pro_nombre,'') Fabricante, 
	                IFNULL(							-- Referencia
		                (SELECT if(e.HDoc_DR1_Cat IN (4,5),'',e.HDoc_DR1_Num) as HDoc_DR1_Num
			                FROM Dcmtos_DTL_Pro b 
			                LEFT JOIN Dcmtos_DTL_Pro c -- Ingreso a bodega
				                ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp 
					                AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat 
					                AND  c.PDoc_Chi_Ano = b.PDoc_Par_Ano 
					                AND c.PDoc_Chi_Num = b.PDoc_Par_Num 
					                AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin 
					                AND c.PDoc_Par_Cat = 47   
			                LEFT JOIN Dcmtos_HDR e 
				                ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp 
					                AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat 
					                AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano 
					                AND e.HDoc_Doc_Num = c.PDoc_Par_Num 
			                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp 
				                AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat 
				                AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano 
				                AND b.PDoc_Chi_Num = d.DDoc_Doc_Num 
				                AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin     
			                LIMIT 1),'N/A') Referencia, 
	                IFNULL(								-- Proforma
		                (SELECT  e.HDoc_DR1_Num   
			                FROM Dcmtos_DTL_Pro b 
			                LEFT JOIN Dcmtos_DTL_Pro c 
				                ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp 
					                AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat 
					                AND c.PDoc_Chi_Ano = b.PDoc_Par_Ano 
					                AND c.PDoc_Chi_Num = b.PDoc_Par_Num 
					                AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin 
					                AND c.PDoc_Par_Cat = 75 
			                LEFT JOIN Dcmtos_HDR e 
				                ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp 
					                AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat 
					                AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano 
					                AND e.HDoc_Doc_Num = c.PDoc_Par_Num 
			                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp 
				                AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat 
				                AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano 
				                AND b.PDoc_Chi_Num = d.DDoc_Doc_Num 
				                AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin   
			                LIMIT 1),0) PF, 
	                IFNULL(								-- Cajas
		                (SELECT bx.BDoc_Box_QTY  
			                FROM Dcmtos_DTL_Box bx 
			                WHERE bx.BDoc_Sis_Emp = d.DDoc_Sis_Emp 
				                AND bx.BDoc_Doc_Cat = d.DDoc_Doc_Cat 
				                AND bx.BDoc_Doc_Ano = d.DDoc_Doc_Ano 
				                AND bx.BDoc_Doc_Num= d.DDoc_Doc_Num 
				                AND bx.BDoc_Doc_Lin = d.DDoc_Doc_Lin    
			                LIMIT 1),0) Cajas
                FROM Dcmtos_DTL d  
                INNER JOIN Inventarios i 
	                ON i.inv_sisemp = d.DDoc_Sis_Emp 
		                AND i.inv_numero = d.DDoc_Prd_Cod  
                INNER JOIN Articulos a 
	                ON a.art_sisemp = i.inv_sisemp 
		                AND a.art_codigo = i.inv_artcodigo 
                LEFT JOIN Catalogos cm 
	                ON cm.cat_clase = 'Medidas' 
		                AND cm.cat_num = d.DDoc_Prd_UM
                LEFT JOIN Proveedores p 
	                ON p.pro_sisemp = i.inv_sisemp 
		                AND p.pro_codigo = i.inv_provcod
                WHERE d.DDoc_Sis_Emp = {empresa}	-- variable
	                AND d.DDoc_Doc_Cat = 36 
	                AND d.DDoc_Doc_Ano = {anio} 	-- variable
	                AND d.DDoc_Doc_Num = {numero} -- variable
            ) a GROUP BY prod_codigo, prod_descripcion, prod_bultos, prod_precio, Medida, Lote, Fabricante, PF"
        End If

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

        If BuscarDTLHSM(strSQL2) = True Then

        End If
        ''DATOS EMPRESA
        strSQL3 = "SELECT 
                        e.emp_nit emp_rtn, 
                        c.cat_sist emp_resolucion, 
                        e.emp_direccion emp_direccion, 
                        e.emp_razon emp_nombre, 
                        e.emp_igss AS emp_telefono, 
                        ce.email emp_email
                    From Empresas e 
                    Left JOIN Catalogos c 
                        ON c.cat_clase = 'Serie' 
                          AND c.cat_clave = 'Doc_CFactura'
                          AND c.cat_pid=0
                          AND c.cat_sisemp=e.emp_no
                    LEFT JOIN {conta}.empresas ce 
                       ON ce.id_empresa=e.emp_no
                    WHERE e.emp_no = {empresa}"
        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
        strSQL3 = Replace(strSQL3, "{conta}", cfun.ContaEmpresa)

        If BuscarEmpresaHSM(strSQL3) = True Then
            ''DATOS GFACE (SE DEJARAN DE UTILIZAR, TODO SE TRAE EN EL ENCABEZADO)
        End If
        strSQL4 = "SELECT c.cat_sist,g.autorizacion,
                        LPAD(g.rango_inicial,8,0) inicial,
                        LPAD(g.rango_final,8,0) final
                    FROM Catalogos c
                    LEFT JOIN Gface g 
                        ON g.empresa = c.cat_sisemp
                            AND g.serie = c.cat_num
                    WHERE c.cat_num = 410 AND c.cat_sisemp = {empresa} "
        strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
        If BuscarSerieHSM(strSQL4) = True Then

        End If

        Dim rep4 As New Facturacion

        rep4.Load("C:\XML\FacturacionHDRHSM.xml")
        rep4.Load("C:\XML\FacturacionDTLHSM.xml")
        rep4.Load("C:\XML\FacturacionEmpresaHSM.xml")
        rep4.Load("C:\XML\FacturacionCatalogosHSM.xml")
        Dim frm3 As New FrmFacturaHSM
        frm3.Reporte_A_VerHSM = rep4
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionHDRHSM.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionDTLHSM.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionEmpresaHSM.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionCatalogosHSM.xml")
        impreso = celdaImpreso.Text
        If impreso = 0 Then
            If frm3.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                If MsgBox("The Document is printed correctly", MsgBoxStyle.YesNo, "Question") = vbYes Then
                    imprimir = 1

                    strSQL5 = "UPDATE Dcmtos_HDR h"
                    strSQL5 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                    strSQL5 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL5 &= ";UPDATE PDM.Dcmtos_HDR h"
                        strSQL5 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                        strSQL5 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                    End If
                    strSQL5 = Replace(strSQL5, "{impresion}", imprimir)
                    strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                    strSQL5 = Replace(strSQL5, "{anio}", celdaAño.Text)
                    strSQL5 = Replace(strSQL5, "{numero}", celdaNumero.Text)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(strSQL5, CON)
                    COM2.ExecuteNonQuery()

                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acGeneraYRM, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                    clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtpFecha.Value)

                    If sqlVerificaYMR() = 1 Then
                        GenerarYarnMovement()
                    End If


                End If
            End If
        End If
    End Sub
    Private Sub ImpresionFacturaNS(ByVal strRespuesta As String, ByVal intTipoFacturaHSM As Integer)
        Dim COM2 As MySqlCommand
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO

        Dim clsConta As New clsContabilidad
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        ''encabezado
        strSQL = "SELECT if(a.HDoc_Doc_Status=1,'','ANULADA') Anulada,
                    c.cli_RegistroNo,
                    a.HDoc_DR2_Cat,
                    a.HDoc_Doc_Num AS 'fact_id',
                    a.HDoc_DR2_Num AS 'fact_serie',
                    CAST(LPAD(a.HDoc_DR1_Dbl,8,0) AS CHAR) AS 'fact_num',

                    c.cli_cliente AS 'cli_nombre',
                    c.cli_nit AS 'cli_nit',
                    a.HDoc_Emp_Dir AS 'cli_direccion',
                    c.cli_telefono AS 'cli_telefono',
                    cont.cnt_correo AS 'cli_email',
                    c.cli_RegistroNo AS 'cli_registro',
                    a.HDoc_Doc_Fec AS 'fact_fecha',
                    a.HDoc_Doc_TC AS 'fact_tasa',
                    c.cli_plazoCR AS 'cli_diasCredito',
                    DATE_ADD(a.HDoc_Doc_Fec, INTERVAL IFNULL(c.cli_plazoCR,0) DAY) AS 'fact_fechaVence',

                    CAST(IFNULL(cm.cat_clave,'') AS CHAR) as 'fact_simbolo_moneda',
                    '{Intercom}' AS 'fact_incoterm',
                    a.HDoc_RF1_Dbl AS 'fact_flete',
                    a.HDoc_RF2_Dbl AS 'fact_seguro',

                    CONCAT(CAST(IFNULL(cm.cat_clave,'') AS CHAR) ,' ',FORMAT(SUM(IFNULL(ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,3),0)),2)) AS 'fact_total1',
                    (SUM(IFNULL(ROUND(ROUND (d.DDoc_Prd_QTY, 4) * ROUND(d.DDoc_Prd_NET, 4),4),0)))*a.HDoc_Doc_TC AS 'fact_total2',

                    IFNULL(a.HDoc_RF2_Txt,'') AS 'fact_cai',
                    CAST(LPAD(gf.rango_inicial,8,0) AS CHAR) AS 'gf_rangoi',
                    CAST(LPAD(gf.rango_final,8,0) AS CHAR) AS 'gf_rangof',
                    gf.autorizacion AS 'gf_autorizacion',


                    IFNULL(ac.ADoc_Dta_Chr,'') contenedor,
                    IFNULL(acc.ADoc_Dta_Txt,'') transporte,
                    acd.ADoc_Dta_Chr Subdocumento,
	                    (SELECT SUM(BDoc_Box_QTY) -- AS Cantidad
	                        FROM Dcmtos_DTL_Box
		                    WHERE BDoc_Sis_Emp = a.HDoc_Sis_Emp
			                    AND BDoc_Doc_Cat = a.HDoc_Doc_Cat
			                    AND BDoc_Doc_Ano = a.HDoc_Doc_Ano
			                    AND BDoc_Doc_Num = a.HDoc_Doc_Num) Bultos,
                    '-' Orden,
                    0 PesoKG,
                    IF(c.cli_forma='CREDIT','CREDITO', c.cli_forma ) Credito ,
                    a.HDoc_Doc_Fec Despachado

                    FROM Dcmtos_HDR a
                    LEFT JOIN Dcmtos_DTL d	-- Detalle factura
	                    ON d.DDoc_Sis_Emp = a.HDoc_Sis_Emp
		                    AND d.DDoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND d.DDoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND d.DDoc_Doc_Num = a.HDoc_Doc_Num
                    LEFT JOIN Dcmtos_ACC ac -- Contenedor
	                    ON ac.ADoc_Sis_Emp =a.HDoc_Sis_Emp
		                    AND ac.ADoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND ac.ADoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND ac.ADoc_Doc_Num = a.HDoc_Doc_Num
		                    AND ac.ADoc_Doc_Sub = 'Doc_HFDatos'
		                    AND ac.ADoc_Doc_Lin ='03'
                    LEFT JOIN Dcmtos_ACC acd -- Subdocumento
	                    ON acd.ADoc_Sis_Emp =a.HDoc_Sis_Emp
		                    AND acd.ADoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND acd.ADoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND acd.ADoc_Doc_Num = a.HDoc_Doc_Num
		                    AND acd.ADoc_Doc_Sub = 'Doc_CFNotas'
		                    AND acd.ADoc_Doc_Lin ='01'
                    LEFT JOIN Dcmtos_ACC acc -- Transporte
	                    ON acc.ADoc_Sis_Emp =a.HDoc_Sis_Emp
		                    AND acc.ADoc_Doc_Cat = a.HDoc_Doc_Cat
		                    AND acc.ADoc_Doc_Ano = a.HDoc_Doc_Ano
		                    AND acc.ADoc_Doc_Num = a.HDoc_Doc_Num
		                    AND acc.ADoc_Doc_Sub = 'Doc_CCPorte2'
		                    AND acc.ADoc_Doc_Lin ='05'
                    INNER JOIN Inventarios AS i -- Inventarios
	                    ON i.inv_sisemp = d.DDoc_Sis_Emp
		                    AND i.inv_numero = d.DDoc_Prd_Cod
                    INNER JOIN Catalogos AS o -- Paises
	                    ON o.cat_clase = 'Paises'
		                    AND o.cat_num = i.inv_lugarfab
                    INNER JOIN Clientes AS c -- Clientes
	                    ON c.cli_sisemp = a.HDoc_Sis_Emp
		                    AND c.cli_codigo = a.HDoc_Emp_Cod
                    LEFT JOIN Catalogos AS cm -- Monedas
	                    ON cm.cat_clase='Monedas'
		                    AND cm.cat_num=a.HDoc_Doc_Mon
		              LEFT JOIN Dcmtos_DTL_Pro pro
		              	  ON a.HDoc_Sis_Emp=pro.PDoc_Sis_Emp
		              	  	  AND a.HDoc_Doc_Cat=pro.PDoc_Chi_Cat
								  AND a.HDoc_Doc_Num=pro.PDoc_Chi_Num
		              	  	  AND a.HDoc_Doc_Ano=pro.PDoc_Chi_Ano
		                      AND d.DDoc_Doc_Lin = pro.PDoc_Chi_Lin
                      LEFT JOIN Dcmtos_HDR hdr
		              	  ON hdr.HDoc_Sis_Emp=pro.PDoc_Sis_Emp
		              	  	  AND hdr.HDoc_Doc_Cat=pro.PDoc_Par_Cat
								  AND hdr.HDoc_Doc_Num=pro.PDoc_Par_Num
		              	  	  AND hdr.HDoc_Doc_Ano=pro.PDoc_Par_Ano
                    LEFT JOIN Catalogos AS cost -- Incoterms
	                    ON cost.cat_clase='Costeo'
		                    AND cost.cat_num=hdr.HDoc_DR2_Cat
                    LEFT JOIN Contactos AS cont -- Contacto (campo email)
	                    ON cont.cnt_sisemp=c.cli_sisemp
		                    AND cont.cnt_codemp=c.cli_codigo
                    LEFT JOIN Gface gf -- Informacion CAI
	                    ON a.HDoc_Sis_Emp=gf.empresa 
		                    AND a.HDoc_RF2_Txt=gf.regimen
                            AND gf.tipo_documento = a.HDoc_Doc_Cat
		                    AND gf.tipo_activo = 1
                        WHERE a.HDoc_Sis_Emp = {empresa}
	                        AND a.HDoc_Doc_Cat = 36
	                        AND a.HDoc_Doc_Ano = {anio}
	                         AND a.HDoc_Doc_Num = {numero}
                        GROUP BY a.HDoc_Doc_Cat,
	                        a.HDoc_Doc_Ano,
	                        a.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{Intercom}", strRespuesta)


        If BuscarHDRNS(strSQL) = True Then
        End If
        ''detalle

        If intTipoFacturaHSM = 1 Then
            strSQL2 = " SELECT 
		                        d.DDoc_Prd_Cod AS 'prod_codigo', 
		                        d.DDoc_Prd_Des AS 'prod_descripcion', 
		                        IFNULL((
		                        SELECT SUM(b.BDoc_Box_QTY)
		                        FROM Dcmtos_DTL_Box b
		                        WHERE b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num= 		d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin),0) AS 'prod_bultos', 
		                        d.DDoc_Prd_QTY AS 'prod_cantidad', 
		                        d.DDoc_Prd_NET AS 'prod_precio', 
		                        ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,4) Monto,c.cat_clave Medida, 'N/A' Lote, 'HONDURAS' Fabricante,''Referencia,'' PF, IFNULL((
		                        SELECT SUM(b.BDoc_Box_QTY)
		                        FROM Dcmtos_DTL_Box b
		                        WHERE b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num 		= d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin),0) AS 'Cajas',
		                        d.DDoc_PRD_DSQ descuentos 
            FROM Dcmtos_HDR h
            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
            LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase ='Medidas'
            LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon
            LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon
            LEFT JOIN Catalogos v ON v.cat_sist = 'DEF_COUNTRY'
            LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod
            LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais
            LEFT JOIN Empresas emp ON emp.emp_no = h.HDoc_Sis_Emp
            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero}"
        Else
            strSQL2 = "SELECT prod_codigo, prod_descripcion, prod_bultos, SUM(prod_cantidad)prod_cantidad, prod_precio,SUM(Monto) Monto, Medida, Lote, Fabricante, Referencia,
                        PF, SUM(Cajas) Cajas, ifnull(descuento,0) descuentos, origen
                        FROM (
                        SELECT 
                    IF(h36.HDoc_RF1_Txt = '', ts.cat_desc, h36.HDoc_RF1_Txt) origen,
                    d.DDoc_PRD_DSQ descuento,
	                d.DDoc_Prd_Cod AS 'prod_codigo',
	                IF(d.DDoc_Prd_Des LIKE '%RENTA%', d.DDoc_Prd_Des, a.art_DCorta) AS 'prod_descripcion',
	                d.DDoc_RF2_Txt AS 'prod_bultos', 
	                d.DDoc_Prd_QTY AS 'prod_cantidad',
	                d.DDoc_Prd_NET AS 'prod_precio', 
	                ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,3) Monto, 
	                cm.cat_clave Medida, 
	                -- IF(i.inv_prodlote='','', CONCAT('',IFNULL(d.DDoc_Prd_PNR,i.inv_prodlote))) Lote,  
                    IF(i.inv_prodlote='',d.DDoc_Prd_PNR, CONCAT('',i.inv_prodlote)) Lote, 
	                IFNULL(p.pro_nombre,'') Fabricante, 
	                IFNULL(							-- Referencia
		                (SELECT e.HDoc_DR1_Num  
			                FROM Dcmtos_DTL_Pro b 
			                LEFT JOIN Dcmtos_DTL_Pro c -- Ingreso a bodega
				                ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp 
					                AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat 
					                AND  c.PDoc_Chi_Ano = b.PDoc_Par_Ano 
					                AND c.PDoc_Chi_Num = b.PDoc_Par_Num 
					                AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin 
					                AND c.PDoc_Par_Cat = 47   
			                LEFT JOIN Dcmtos_HDR e 
				                ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp 
					                AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat 
					                AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano 
					                AND e.HDoc_Doc_Num = c.PDoc_Par_Num 
			                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp 
				                AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat 
				                AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano 
				                AND b.PDoc_Chi_Num = d.DDoc_Doc_Num 
				                AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin     
			                LIMIT 1),'N/A') Referencia, 
	                IFNULL(								-- Proforma
		                (SELECT  e.HDoc_DR1_Num   
			                FROM Dcmtos_DTL_Pro b 
			                LEFT JOIN Dcmtos_DTL_Pro c 
				                ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp 
					                AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat 
					                AND c.PDoc_Chi_Ano = b.PDoc_Par_Ano 
					                AND c.PDoc_Chi_Num = b.PDoc_Par_Num 
					                AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin 
					                AND c.PDoc_Par_Cat = 75 
			                LEFT JOIN Dcmtos_HDR e 
				                ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp 
					                AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat 
					                AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano 
					                AND e.HDoc_Doc_Num = c.PDoc_Par_Num 
			                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp 
				                AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat 
				                AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano 
				                AND b.PDoc_Chi_Num = d.DDoc_Doc_Num 
				                AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin   
			                LIMIT 1),0) PF, 
	                IFNULL(								-- Cajas
		                (SELECT bx.BDoc_Box_QTY  
			                FROM Dcmtos_DTL_Box bx 
			                WHERE bx.BDoc_Sis_Emp = d.DDoc_Sis_Emp 
				                AND bx.BDoc_Doc_Cat = d.DDoc_Doc_Cat 
				                AND bx.BDoc_Doc_Ano = d.DDoc_Doc_Ano 
				                AND bx.BDoc_Doc_Num= d.DDoc_Doc_Num 
				                AND bx.BDoc_Doc_Lin = d.DDoc_Doc_Lin    
			                LIMIT 1),0) Cajas
                FROM Dcmtos_DTL d  
                LEFT JOIN Dcmtos_HDR h36 ON h36.HDoc_Sis_Emp = d.DDoc_Sis_Emp 
                    AND h36.HDoc_Doc_Cat = d.DDoc_Doc_Cat 
                    AND h36.HDoc_Doc_Ano = d.DDoc_Doc_Ano 
                    AND h36.HDoc_Doc_Num = d.DDoc_Doc_Num 
                INNER JOIN Inventarios i 
	                ON i.inv_sisemp = d.DDoc_Sis_Emp 
		                AND i.inv_numero = d.DDoc_Prd_Cod  
                INNER JOIN Articulos a 
	                ON a.art_sisemp = i.inv_sisemp 
		                AND a.art_codigo = i.inv_artcodigo 
                LEFT JOIN Catalogos cm 
	                ON cm.cat_clase = 'Medidas' 
		                AND cm.cat_num = d.DDoc_Prd_UM
                LEFT JOIN Catalogos ts ON ts.cat_num = i.inv_lugarfab 
		                AND ts.cat_clase = 'Paises'
                LEFT JOIN Proveedores p 
	                ON p.pro_sisemp = i.inv_sisemp 
		                AND p.pro_codigo = i.inv_provcod
                WHERE d.DDoc_Sis_Emp = {empresa}	-- variable
	                AND d.DDoc_Doc_Cat = 36 
	                AND d.DDoc_Doc_Ano = {anio} 	-- variable
	                AND d.DDoc_Doc_Num = {numero} -- variable
            ) a GROUP BY prod_codigo, prod_descripcion, prod_bultos, prod_precio, Medida, Lote,  Fabricante,/* Referencia,*/ PF"
        End If

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

        If BuscarDTLNS(strSQL2) = True Then

        End If
        ''DATOS EMPRESA
        strSQL3 = "SELECT 
                        e.emp_nit emp_rtn, 
                        c.cat_sist emp_resolucion, 
                        e.emp_direccion emp_direccion, 
                        e.emp_razon emp_nombre, 
                        e.emp_igss AS emp_telefono, 
                        ce.email emp_email
                    From Empresas e 
                    Left JOIN Catalogos c 
                        ON c.cat_clase = 'Serie' 
                          AND c.cat_clave = 'Doc_CFactura'
                          AND c.cat_pid=0
                          AND c.cat_sisemp=e.emp_no
                    LEFT JOIN {conta}.empresas ce 
                       ON ce.id_empresa=e.emp_no
                    WHERE e.emp_no = {empresa}"
        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
        strSQL3 = Replace(strSQL3, "{conta}", cfun.ContaEmpresa)

        If BuscarEmpresaNS(strSQL3) = True Then
            ''DATOS GFACE (SE DEJARAN DE UTILIZAR, TODO SE TRAE EN EL ENCABEZADO)
        End If
        strSQL4 = "SELECT c.cat_sist,g.autorizacion,
                        LPAD(g.rango_inicial,8,0) inicial,
                        LPAD(g.rango_final,8,0) final
                    FROM Catalogos c
                    LEFT JOIN Gface g 
                        ON g.empresa = c.cat_sisemp
                            AND g.serie = c.cat_num
                    WHERE c.cat_num = 410 AND c.cat_sisemp = {empresa} "
        strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
        If BuscarSerieNS(strSQL4) = True Then

        End If

        Dim rep4 As New Facturacion

        rep4.Load("C:\XML\FacturacionHDRNS.xml")
        rep4.Load("C:\XML\FacturacionDTLNS.xml")
        rep4.Load("C:\XML\FacturacionEmpresaNS.xml")
        rep4.Load("C:\XML\FacturacionCatalogosNS.xml")
        Dim frm3 As New FrmFacturaNS
        frm3.Reporte_A_VerNS = rep4
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionHDRNS.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionDTLNS.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionEmpresaNS.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionCatalogosNS.xml")
        impreso = celdaImpreso.Text
        If impreso = 0 Then
            If frm3.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                If MsgBox("The Document is printed correctly", MsgBoxStyle.YesNo, "Question") = vbYes Then
                    imprimir = 1

                    strSQL5 = "UPDATE Dcmtos_HDR h"
                    strSQL5 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                    strSQL5 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL5 &= ";UPDATE PDM.Dcmtos_HDR h"
                        strSQL5 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                        strSQL5 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                    End If
                    strSQL5 = Replace(strSQL5, "{impresion}", imprimir)
                    strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                    strSQL5 = Replace(strSQL5, "{anio}", celdaAño.Text)
                    strSQL5 = Replace(strSQL5, "{numero}", celdaNumero.Text)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(strSQL5, CON)
                    COM2.ExecuteNonQuery()

                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acGeneraYRM, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                    clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtpFecha.Value)

                    If sqlVerificaYMR() = 1 Then
                        GenerarYarnMovement()
                    End If


                End If
            End If
        End If




    End Sub
    Private Function BuscarRegistrosDcmtos_HDR_NSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FNSM")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionNSM.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_DTL_NSM(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FNSM2")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionNSMDTL.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_HDR_Pride(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FPride")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionPride.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_DTL_Pride(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FPride2")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionPrideDTL.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_ACC_Pride(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FPride3")
        adaptador.Fill(Tablas, "Dcmtos_ACC")
        If Tablas.Tables("Dcmtos_ACC").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionPrideACC.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_ACC_Pride2(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FPride4")
        adaptador.Fill(Tablas, "Dcmtos_ACC")
        If Tablas.Tables("Dcmtos_ACC").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionPrideACC2.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Sub ImpresionFacturaHN(ByVal tipoIncoterm As String, ByVal tipoFacturaPY As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        Dim rep4 As New FacturaHN
        strSQL = " SELECT e.emp_domicilio direccion, '{incoterm}' incoterm, a.HDoc_Doc_Num Numero, CAST(LPAD(a.{numerofactura},8,0) AS CHAR) num, CONCAT(a.HDoc_Emp_Nom,'\n','RTN: ',c.cli_nit,'\n',REPLACE(a.HDoc_Emp_Dir,'\r','')) Cliente,a.HDoc_Doc_Fec Fecha, "
        strSQL &= "     CONCAT(CAST(IFNULL(cm.cat_clave,'') AS CHAR),' ', FORMAT(SUM(IFNULL(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2),0)),2)) Total, SUM(IFNULL(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2),0)) total2, "
        strSQL &= "         IFNULL(a.HDoc_RF2_Txt,'') CAI, IFNULL(ac.ADoc_Dta_Chr,'') contenedor,cm.cat_clave,IFNULL(acd.ADoc_Dta_Txt,'') Cuenta , IFNULL(acc.ADoc_Dta_Txt,'') transporte, ( "
        strSQL &= "             SELECT SUM(BDoc_Box_QTY) AS Cantidad "
        strSQL &= "                 FROM Dcmtos_DTL_Box "
        strSQL &= "                     WHERE BDoc_Sis_Emp = a.HDoc_Sis_Emp AND BDoc_Doc_Cat = a.HDoc_Doc_Cat AND BDoc_Doc_Ano = a.HDoc_Doc_Ano AND BDoc_Doc_Num = a.HDoc_Doc_Num) Bultos, '-' Orden, 0 PesoKG, IF(c.cli_plazoCR<=0,'C0D', CONCAT('Net ', CAST(c.cli_plazoCR AS CHAR))) Credito, CAST(IF(c.cli_plazoCR<=0,a.HDoc_Doc_Fec,DATE_ADD(a.HDoc_Doc_Fec, INTERVAL c.cli_plazoCR DAY)) AS DATE) Vencimiento, a.HDoc_Doc_Fec Despachado,  "
        strSQL &= "                         ROUND(a.HDoc_Doc_TC,4) tasa, ROUND(a.HDoc_Doc_TC * ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2)+.0000000001,2) Lempiras, ROUND(IFNULL(a.HDoc_RF1_Dbl,0),2) Flete, ROUND(a.HDoc_RF2_Dbl,2) Seguro,"
        strSQL &= "                             ROUND(SUM(d.DDoc_RF1_Dbl),2) LBsBrutas, ROUND(SUM(d.DDoc_RF2_Dbl),2) KgBrutos, IF(d.DDoc_Prd_UM=69,ROUND(SUM(d.DDoc_Prd_QTY),2),ROUND(SUM(d.DDoc_Prd_QTY * 2.2046),2)) LbsNetas, "
        strSQL &= "                                 SUM(d.DDoc_Prd_Fob) KgNetos, FORMAT(SUM(IFNULL(ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,2),0)),2) Total ,c.cli_RegistroNo"
        strSQL &= "                                     FROM Dcmtos_HDR a "
        strSQL &= "                                         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND d.DDoc_Doc_Num = a.HDoc_Doc_Num "
        strSQL &= "                                             LEFT JOIN Dcmtos_ACC ac ON ac.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Doc_HFDatos' AND ac.ADoc_Doc_Lin ='03' "
        strSQL &= "                                                 LEFT JOIN Dcmtos_ACC acd ON acd.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND acd.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND acd.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND acd.ADoc_Doc_Num = a.HDoc_Doc_Num AND acd.ADoc_Doc_Sub = 'Doc_HFDatos' AND acd.ADoc_Doc_Lin ='01'"
        strSQL &= "                                                     LEFT JOIN Dcmtos_ACC acc ON acc.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND acc.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND acc.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND acc.ADoc_Doc_Num = a.HDoc_Doc_Num AND acc.ADoc_Doc_Sub = 'Doc_CCPorte2' AND acc.ADoc_Doc_Lin ='05' "
        strSQL &= "                                                         /* INNER JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
        strSQL &= "                                                             INNER JOIN Catalogos o ON o.cat_clase = 'Paises' AND o.cat_num = i.inv_lugarfab */ "
        strSQL &= "                                                                 INNER JOIN Clientes c ON c.cli_sisemp = a.HDoc_Sis_Emp AND c.cli_codigo = a.HDoc_Emp_Cod "
        strSQL &= "                                                                     LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=a.HDoc_Doc_Mon LEFT JOIN Empresas e ON e.emp_no=a.HDoc_Sis_Emp"
        strSQL &= "                                                                         WHERE a.HDoc_Sis_Emp = {empresa} AND a.HDoc_Doc_Cat = 36 AND a.HDoc_Doc_Ano = {anio} AND a.HDoc_Doc_Num = {numero} "
        strSQL &= "                                                                             GROUP BY a.HDoc_Doc_Cat, a.HDoc_Doc_Ano, a.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{incoterm}", tipoIncoterm)
        If Sesion.IdEmpresa = 11 Then
            strSQL = Replace(strSQL, "{numerofactura}", "HDoc_DR1_Dbl")
        Else
            strSQL = Replace(strSQL, "{numerofactura}", "HDoc_Doc_Num")
        End If

        If BuscarRegistrosDcmtos_HDR_Pride(strSQL) = True Then

        End If
        If tipoFacturaPY = 1 Then
            strSQL2 = "SELECT cc.cat_sist, g.autorizacion, LPAD(g.rango_inicial,8,0) rango_inicial, LPAD(g.rango_final,8,0) rango_final, (d.DDoc_Prd_QTY / d.DDoc_Prd_NET) PrecioP, DDoc_Prd_DSQ Descuento, (d.DDoc_Prd_Des) Descripcion,d.DDoc_RF2_Txt Bultos, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET Precio, ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2) Monto, cm.cat_clave Medida, '' Lote, '' Fabricante,         IFNULL(    (SELECT e.HDoc_DR1_Num   FROM Dcmtos_DTL_Pro b       
                Left Join Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp And c.PDoc_Chi_Cat = b.PDoc_Par_Cat And  c.PDoc_Chi_Ano = b.PDoc_Par_Ano And c.PDoc_Chi_Num = b.PDoc_Par_Num And c.PDoc_Chi_Lin = b.PDoc_Par_Lin And c.PDoc_Par_Cat = 47
                Left Join Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp And e.HDoc_Doc_Cat = c.PDoc_Par_Cat And e.HDoc_Doc_Ano = c.PDoc_Par_Ano And e.HDoc_Doc_Num = c.PDoc_Par_Num
                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp And b.PDoc_Chi_Cat = d.DDoc_Doc_Cat And b.PDoc_Chi_Ano = d.DDoc_Doc_Ano And b.PDoc_Chi_Num = d.DDoc_Doc_Num And b.PDoc_Chi_Lin = d.DDoc_Doc_Lin
                LIMIT 1),'N/A') Referencia, IFNULL((
                Select e.HDoc_DR1_Num
                From Dcmtos_DTL_Pro b
                Left Join Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp And c.PDoc_Chi_Cat = b.PDoc_Par_Cat And c.PDoc_Chi_Ano = b.PDoc_Par_Ano And c.PDoc_Chi_Num = b.PDoc_Par_Num And c.PDoc_Chi_Lin = b.PDoc_Par_Lin And c.PDoc_Par_Cat = 75
                Left Join Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp And e.HDoc_Doc_Cat = c.PDoc_Par_Cat And e.HDoc_Doc_Ano = c.PDoc_Par_Ano And e.HDoc_Doc_Num = c.PDoc_Par_Num
                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp And b.PDoc_Chi_Cat = d.DDoc_Doc_Cat And b.PDoc_Chi_Ano = d.DDoc_Doc_Ano And b.PDoc_Chi_Num = d.DDoc_Doc_Num And b.PDoc_Chi_Lin = d.DDoc_Doc_Lin
                LIMIT 1),0) PF, IFNULL((
                Select  bx.BDoc_Box_QTY
                From Dcmtos_DTL_Box bx
                Where bx.BDoc_Sis_Emp = d.DDoc_Sis_Emp And bx.BDoc_Doc_Cat = d.DDoc_Doc_Cat And bx.BDoc_Doc_Ano = d.DDoc_Doc_Ano And bx.BDoc_Doc_Num = d.DDoc_Doc_Num And bx.BDoc_Doc_Lin = d.DDoc_Doc_Lin
                                LIMIT 1),0) Cajas
                From Dcmtos_DTL d
                Left Join Dcmtos_HDR h36 ON h36.HDoc_Sis_Emp = d.DDoc_Sis_Emp And h36.HDoc_Doc_Cat = d.DDoc_Doc_Cat And h36.HDoc_Doc_Ano = d.DDoc_Doc_Ano And h36.HDoc_Doc_Num = d.DDoc_Doc_Num
                -- INNER JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod
                -- INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp And a.art_codigo = i.inv_artcodigo
                Left Join Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM
                                Left Join Catalogos cc ON cc.cat_clave = 'Doc_CFactura' AND cc.cat_clase = 'Serie' AND cc.cat_pid=0 AND cc.cat_sist = h36.HDoc_DR2_Num
                                Left Join Gface g ON cc.cat_num = g.serie And g.empresa = d.DDoc_Sis_Emp And h36.{numerofactura} >= g.rango_inicial And h36.HDoc_DR1_Dbl <= g.rango_final
                -- LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp And p.pro_codigo = i.inv_provcod
                WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        Else
            strSQL2 = " Select cc.cat_sist , g.autorizacion, LPAD(g.rango_inicial,8,0) rango_inicial, LPAD(g.rango_final,8,0) rango_final, (d.DDoc_Prd_QTY / d.DDoc_Prd_DSQ) PrecioP , DDoc_Prd_DSQ Descuento , If(d.DDoc_Prd_Des Like '%RENTA%', d.DDoc_Prd_Des, a.art_DCorta) Descripcion,d.DDoc_RF2_Txt Bultos, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET Precio, ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2) Monto, "
            strSQL2 &= "    cm.cat_clave Medida, IF(i.inv_prodlote='','', CONCAT('Lote #',i.inv_prodlote)) Lote, IFNULL(p.pro_nombre,'') Fabricante, "
            strSQL2 &= "        IFNULL(    (SELECT e.HDoc_DR1_Num   FROM Dcmtos_DTL_Pro b       LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat AND  c.PDoc_Chi_Ano = b.PDoc_Par_Ano AND c.PDoc_Chi_Num = b.PDoc_Par_Num AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin AND c.PDoc_Par_Cat = 47 "
            strSQL2 &= "            LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano AND e.HDoc_Doc_Num = c.PDoc_Par_Num  "
            strSQL2 &= "                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND b.PDoc_Chi_Num = d.DDoc_Doc_Num AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin     LIMIT 1),'N/A') "
            strSQL2 &= "                    Referencia,IFNULL((SELECT  e.HDoc_DR1_Num                     FROM Dcmtos_DTL_Pro b                         LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat AND c.PDoc_Chi_Ano = b.PDoc_Par_Ano AND c.PDoc_Chi_Num = b.PDoc_Par_Num AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin AND c.PDoc_Par_Cat = 75 "
            strSQL2 &= "                        LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano AND e.HDoc_Doc_Num = c.PDoc_Par_Num "
            strSQL2 &= "                            WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND b.PDoc_Chi_Num = d.DDoc_Doc_Num AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin   LIMIT 1),0) PF,IFNULL(( "
            strSQL2 &= "                                SELECT bx.BDoc_Box_QTY "
            strSQL2 &= "                                    FROM Dcmtos_DTL_Box bx "
            strSQL2 &= "                                        WHERE bx.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND bx.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND bx.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND bx.BDoc_Doc_Num= d.DDoc_Doc_Num AND bx.BDoc_Doc_Lin = d.DDoc_Doc_Lin LIMIT 1),0) Cajas  "
            strSQL2 &= "                                            FROM Dcmtos_DTL d "
            strSQL2 &= "                                                    LEFT JOIN Dcmtos_HDR h36 ON h36.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h36.HDoc_Doc_Cat = d.DDoc_Doc_Cat  AND h36.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h36.HDoc_Doc_Num = d.DDoc_Doc_Num"
            strSQL2 &= "                                                INNER JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL2 &= "                                            INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL2 &= "                                         LEFT JOIN Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM "
            strSQL2 &= "                                LEFT JOIN Catalogos cc ON  cc.cat_clave = 'Doc_CFactura' AND cc.cat_clase = 'Serie' and cc.cat_pid=0 AND cc.cat_sist = h36.HDoc_DR2_Num "
            strSQL2 &= "                                   LEFT JOIN Gface g ON cc.cat_num  = g.serie AND g.empresa = d.DDoc_Sis_Emp AND h36.{numerofactura} >= g.rango_inicial AND h36.{numerofactura} <= g.rango_final"
            strSQL2 &= "                            LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod "
            strSQL2 &= "                    WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        End If
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
        If Sesion.IdEmpresa = 11 Then
            strSQL2 = Replace(strSQL2, "{numerofactura}", "HDoc_DR1_Dbl")
        Else
            strSQL2 = Replace(strSQL2, "{numerofactura}", "HDoc_Doc_Num")
        End If

        If BuscarRegistrosDcmtos_DTL_Pride(strSQL2) = True Then

        End If

        'strSQL3 = "     SELECT CAST(COALESCE(b.ADoc_Dta_Des) AS Char) Campo, CAST(COALESCE(b.ADoc_Doc_Lin) AS CHAR) Linea, CAST(COALESCE(b.ADoc_Dta_Chr) AS CHAR) Dato,  CAST(COALESCE(b.ADoc_Dta_Txt ) AS CHAR ) Texto  "
        'strSQL3 &= "    SELECT GROUP_CONCAT(DISTINCT(CASE WHEN b.ADoc_Dta_Chr != '' THEN CAST(COALESCE(b.ADoc_Dta_Des, '{null}') AS CHAR) WHEN b.ADoc_Dta_Txt  != '' THEN CAST(COALESCE(b.ADoc_Dta_Des, '{null}') AS CHAR) ELSE '' END)SEPARATOR '') Campo "
        'strSQL3 &= "        GROUP_CONCAT(CASE WHEN b.ADoc_Dta_Chr != '' THEN CAST(COALESCE(b.ADoc_Dta_Chr, '{null}') AS CHAR) WHEN b.ADoc_Dta_Txt != '' THEN CAST(COALESCE(b.ADoc_Dta_Txt, '{null}') AS CHAR) ELSE 'ERROR' END SEPARATOR '|') "
        '  strSQL3 &= "        Case When b.ADoc_Dta_Chr != ''  THEN CAST(COALESCE(b.ADoc_Dta_Chr, '{null}') AS CHAR) When b.ADoc_Dta_Txt != '' THEN CAST(COALESCE(b.ADoc_Dta_Txt, '{null}') AS CHAR) ELSE 'ERROR' END Dato"
        'strSQL3 &= "        FROM Dcmtos_ACC b "
        'strSQL3 &= "            WHERE ADoc_Sis_Emp={empresa} AND ADoc_Doc_Cat=36 AND ADoc_Doc_Ano={anio} AND ADoc_Doc_Num={numero} AND INSTR(ADoc_Dta_Des,'.') > 0 AND ADoc_Doc_Sub = 'Doc_HFDatos' "
        'strSQL3 &= "                  ORDER BY ADoc_Doc_Lin "
        strSQL3 = " select group_concat(l1.dato1) AS dato1 , group_concat(l1.dato2) AS dato2 , group_concat(l1.dato3) AS dato3 , group_concat(l1.dato4) AS dato4 , group_concat(l1.dato5) AS dato5 , group_concat(l1.dato6) AS dato6 , group_concat(l1.dato7) AS dato7  , group_concat(l1.dato8) AS dato8 , group_concat(l1.dato9) AS dato9  , "
        strSQL3 &= "    group_concat(l1.dato10) AS dato10 , group_concat(l1.dato11) AS dato11 , group_concat(l1.dato12) AS dato12, group_concat(l1.dato13) As dato13 , group_concat(l1.dato14) AS dato14   "
        strSQL3 &= "        from ( "
        strSQL3 &= "            SELECT (CASE WHEN b.cat_clave  = '04' THEN b.cat_desc  ELSE NULL END) AS dato1,"
        strSQL3 &= "                (CASE WHEN b.cat_clave  = '05' THEN b.cat_desc  ELSE NULL END) AS dato2, "
        strSQL3 &= "                    (CASE WHEN b.cat_clave  = '06' THEN b.cat_desc  ELSE NULL END) AS dato3, "
        strSQL3 &= "                        (CASE WHEN b.cat_clave  = '07' THEN b.cat_desc  ELSE NULL END) AS dato4, "
        strSQL3 &= "                            (CASE WHEN b.cat_clave  = '08' THEN b.cat_desc  ELSE NULL END) AS dato5, "
        strSQL3 &= "                                (CASE WHEN b.cat_clave  = '09' THEN b.cat_desc  ELSE NULL END) AS dato6, "
        strSQL3 &= "                                    (CASE WHEN b.cat_clave  = '10' THEN b.cat_desc  ELSE NULL END) AS dato7,"
        strSQL3 &= "                                        (CASE WHEN b.cat_clave  = '11' THEN b.cat_desc  ELSE NULL END) AS dato8, "
        strSQL3 &= "                                            (CASE WHEN b.cat_clave  = '12' THEN b.cat_desc  ELSE NULL END) AS dato9, "
        strSQL3 &= "                                                (CASE WHEN b.cat_clave  = '13' THEN b.cat_desc  ELSE NULL END) AS dato10, "
        strSQL3 &= "                                                    (CASE WHEN b.cat_clave  = '14' THEN b.cat_desc  ELSE NULL END) AS dato11, "
        strSQL3 &= "                                                        (CASE WHEN b.cat_clave  = '15' THEN b.cat_desc  ELSE NULL END) AS dato12, "
        strSQL3 &= "                                                            (CASE WHEN b.cat_clave  = '16' THEN b.cat_desc  ELSE NULL END) AS dato13, "
        strSQL3 &= "                                                                (CASE WHEN b.cat_clave  = '17' THEN b.cat_desc  ELSE NULL END) AS dato14 "
        strSQL3 &= "                                                                     from Catalogos b "
        strSQL3 &= "                                                                        where b.cat_clase = 'Doc_HFDatos') l1"


        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
        strSQL3 = Replace(strSQL3, "{anio}", celdaAño.Text)
        strSQL3 = Replace(strSQL3, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_ACC_Pride(strSQL3) = True Then

        End If

        'strSQL4 = "     SELECT GROUP_CONCAT(DISTINCT(Case When b.ADoc_Dta_Chr != ''  THEN CAST(COALESCE(b.ADoc_Dta_Chr, '{null}') AS CHAR) When b.ADoc_Dta_Txt != '' THEN CAST(COALESCE(b.ADoc_Dta_Txt, '{null}') AS CHAR) ELSE 'ERROR' END)SEPARATOR '|') Dato"
        'strSQL4 &= "        FROM Dcmtos_ACC b "
        'strSQL4 &= "            WHERE ADoc_Sis_Emp={empresa} AND ADoc_Doc_Cat=36 AND ADoc_Doc_Ano={anio} AND ADoc_Doc_Num={numero} AND INSTR(ADoc_Dta_Des,'.') > 0 AND ADoc_Doc_Sub = 'Doc_HFDatos' "
        'strSQL4 &= "                ORDER BY ADoc_Doc_Lin "

        strSQL4 = " SELECT IFNULL(final.numero,'') AS Numero, IFNULL(GROUP_CONCAT(DISTINCT(final.fecha)),'') AS fecha, IFNULL(GROUP_CONCAT(DISTINCT(final.importador)),'') AS Salida, IFNULL(GROUP_CONCAT(DISTINCT(final.descarga)),'') AS LugarCarga, "
        strSQL4 &= "    IFNULL(GROUP_CONCAT(DISTINCT(final.trasporte)),'') AS DestinoFinal, IFNULL(GROUP_CONCAT(DISTINCT(final.furgon)),'') AS Transporte, IFNULL(GROUP_CONCAT(DISTINCT(final.cabezal)),'') AS Lot, "
        strSQL4 &= "        IFNULL(GROUP_CONCAT(DISTINCT(final.piloto)),'') AS Mills, IFNULL(GROUP_CONCAT(DISTINCT(final.licencia)),'') AS Origin, "
        strSQL4 &= "            IFNULL(GROUP_CONCAT(DISTINCT(final.pedido)),'') AS Nota, IFNULL(GROUP_CONCAT(DISTINCT(final.marchamo)),'') AS Wire, IFNULL(GROUP_CONCAT(DISTINCT(final.vendedor)),'') AS PrecioFob, "
        strSQL4 &= "                IFNULL(GROUP_CONCAT(DISTINCT(final.origen)),'') AS Hilados, IFNULL(GROUP_CONCAT(DISTINCT(final.pais)),'') AS Hilados2, IFNULL(GROUP_CONCAT(DISTINCT(final.pais1)),'') AS Conductor, IFNULL(GROUP_CONCAT(DISTINCT(final.pais2)),'') AS Hilados3, "
        strSQL4 &= "                    IFNULL(GROUP_CONCAT(DISTINCT(final.pais3)),'') AS Cabezal, IFNULL(GROUP_CONCAT(DISTINCT(final.pais4)),'') AS pais4, IFNULL(GROUP_CONCAT(DISTINCT(final.transportista)),'') AS transportista, IFNULL(GROUP_CONCAT(DISTINCT(final.cargador)),'') AS cargador "
        strSQL4 &= "                        FROM ( "
        strSQL4 &= "                            SELECT DISTINCT(ccc.cat_clave), (CASE WHEN ccc.cat_clave = '01' THEN ccc.valores ELSE NULL END) AS numero, (CASE WHEN ccc.cat_clave = '02' THEN ccc.valores ELSE NULL END) AS fecha, (CASE WHEN ccc.cat_clave = '03' THEN ccc.valores ELSE NULL END) AS importador, "
        strSQL4 &= "                                (CASE WHEN ccc.cat_clave = '04' THEN ccc.valores ELSE NULL END) AS descarga, (CASE WHEN ccc.cat_clave = '05' THEN ccc.valores ELSE NULL END) AS trasporte, "
        strSQL4 &= "                                    (CASE WHEN ccc.cat_clave = '06' THEN ccc.valores ELSE NULL END) AS furgon, 	 (CASE WHEN ccc.cat_clave = '07' THEN ccc.valores ELSE NULL END) AS cabezal, "
        strSQL4 &= "                                        (CASE WHEN ccc.cat_clave = '08' THEN ccc.valores ELSE NULL END) AS piloto, 	(CASE WHEN ccc.cat_clave = '09' THEN ccc.valores ELSE NULL END) AS licencia, "
        strSQL4 &= "                                            (CASE WHEN ccc.cat_clave = '10' THEN ccc.valores ELSE NULL END) AS pedido, (CASE WHEN ccc.cat_clave = '11' THEN ccc.valores ELSE NULL END) AS marchamo, "
        strSQL4 &= "                                                (CASE WHEN ccc.cat_clave = '12' THEN ccc.valores ELSE NULL END) AS vendedor, 	(CASE WHEN ccc.cat_clave = '13' THEN ccc.valores ELSE NULL END) AS origen, (CASE WHEN ccc.cat_clave = '14' THEN ccc.valores ELSE NULL END) AS pais, "
        strSQL4 &= "                                                    (CASE WHEN ccc.cat_clave = '15' THEN ccc.valores ELSE NULL END) AS pais1, (CASE WHEN ccc.cat_clave = '16' THEN ccc.valores ELSE NULL END) AS pais2, "
        strSQL4 &= "                                                        	(CASE WHEN ccc.cat_clave = '17' THEN ccc.valores ELSE NULL END) AS pais3, (CASE WHEN ccc.cat_clave = '18' THEN ccc.valores ELSE NULL END) AS pais4, "
        strSQL4 &= "                                                                (CASE WHEN ccc.cat_clave = '19' THEN ccc.valores ELSE NULL END) AS transportista, 	(CASE WHEN ccc.cat_clave = '20' THEN ccc.valores ELSE NULL END) AS cargador "
        strSQL4 &= "                                                                    FROM ( "
        strSQL4 &= "                                                                        SELECT xx.*, GROUP_CONCAT(DISTINCT(xx.valor) SEPARATOR '|') AS valores "
        strSQL4 &= "                                                                            FROM ( "
        strSQL4 &= "                                                                               SELECT a.cat_clave, a.cat_pid, a.cat_desc, b.ADoc_Sis_Emp, b.ADoc_Doc_Ano, b.ADoc_Doc_Cat, b.ADoc_Doc_Num, ( "
        strSQL4 &= "                                                                        SELECT CASE WHEN a.cat_sist = 'Char' THEN CAST(COALESCE(c.ADoc_Dta_Chr, '{null}') AS CHAR) WHEN a.cat_sist = 'Text' THEN CAST(COALESCE(c.ADoc_Dta_Txt, '{null}') AS CHAR) WHEN a.cat_sist = 'Date' "
        strSQL4 &= "                                                        THEN CAST(COALESCE(c.ADoc_Dta_Fec, '{null}') AS CHAR) WHEN a.cat_sist = 'Weight' THEN CAST(COALESCE(c.ADoc_Dta_Wht, '{null}') AS CHAR) WHEN a.cat_sist = 'Cant' THEN CAST(COALESCE(c.ADoc_Dta_Num, '{null}') AS CHAR) WHEN a.cat_sist = 'Money' THEN CAST(COALESCE(c.ADoc_Dta_Mny, '{null}') AS CHAR) ELSE 'ERROR' END "
        strSQL4 &= "                                                FROM Dcmtos_ACC c "
        strSQL4 &= "                                         WHERE c.ADoc_Sis_Emp = b.ADoc_Sis_Emp AND c.ADoc_Doc_Cat = b.ADoc_Doc_Cat AND c.ADoc_Doc_Ano = b.ADoc_Doc_Ano AND c.ADoc_Doc_Num = b.ADoc_Doc_Num AND c.ADoc_Doc_Sub = b.ADoc_Doc_Sub AND c.ADoc_Doc_Lin = a.cat_clave) AS Valor "
        strSQL4 &= "                               FROM Catalogos a "
        strSQL4 &= "                       INNER JOIN Dcmtos_ACC b ON b.ADoc_Sis_Emp = {empresa} AND b.ADoc_Doc_Ano = {anio} AND b.ADoc_Doc_Cat = 36 AND b.ADoc_Doc_Num = {numero} AND b.ADoc_Doc_Sub = 'Doc_HFDatos' AND b.ADoc_Doc_Lin = a.cat_clave "
        strSQL4 &= "                 WHERE a.cat_clase = b.ADoc_Doc_Sub) xx "
        strSQL4 &= "           GROUP BY xx.cat_clave "
        strSQL4 &= "     ORDER BY xx.cat_pid) ccc "
        strSQL4 &= "GROUP BY ccc.cat_clave)final "
        strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
        strSQL4 = Replace(strSQL4, "{anio}", celdaAño.Text)
        strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

        If BuscarRegistrosDcmtos_ACC_Pride2(strSQL4) = True Then

        End If


        rep4.Load("C:\XML\FacturacionPride.xml")
        rep4.Load("C:\XML\FacturacionPrideDTL.xml")
        rep4.Load("C:\XML\FacturacionPrideACC.xml")
        rep4.Load("C:\XML\FacturacionPrideACC2.xml")
        Dim frm3 As New FrmFacturaHSM
        frm3.Reporte_A_VerHSM = rep4
        frm3.Name = "Facturacion Pride Yarn"
        frm3.CrystalReportViewer1.ReportSource = rep4
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionPride.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionPrideDTL.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionPrideACC.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionPrideACC2.xml")


    End Sub

#Region "Factura LCP"
    Private Function BuscarRegistrosDcmtos_HDR_LCP(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FLCP")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionLCP.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_DTL_LCP(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FLCP2")
        adaptador.Fill(Tablas, "Dcmtos_DTL")
        If Tablas.Tables("Dcmtos_DTL").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionLCPDTL.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_ACC_LCP(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FLCP3")
        adaptador.Fill(Tablas, "Dcmtos_ACC")
        If Tablas.Tables("Dcmtos_ACC").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionLCPACC.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosDcmtos_ACC_LCP2(ByVal strSQL As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strSQL, CON)
        Tablas = New DataSet("FLCP4")
        adaptador.Fill(Tablas, "Dcmtos_ACC")
        If Tablas.Tables("Dcmtos_ACC").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\FacturacionLCPACC2.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Sub ImpresionFacturaLCP()
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        Dim rep4 As New FacturaLCP

        Dim varmoneda As String = cfun.SimboloMoneda(celdaIdMoneda.Text)

        strSQL = "SELECT 
    	            a.HDoc_Doc_Num Numero, 
	                CAST(LPAD(a.HDoc_Doc_Num,8,0) AS CHAR) num, 
	                CONCAT(a.HDoc_Emp_Nom,'\n','Address: ', REPLACE(a.HDoc_Emp_Dir,'\r','')) Cliente,
	                a.HDoc_Doc_Fec Fecha, 
	                CONCAT(CAST(IFNULL(cm.cat_clave,'') AS CHAR),' ', FORMAT(SUM(IFNULL(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2),0)),2)) Total, 
	                SUM(IFNULL(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2),0)) total2, 
	                IFNULL(a.HDoc_RF2_Txt,'') CAI,
                    '' contenedor,
                    cm.cat_clave, 
                    '' Cuenta, 
                    '' transporte,
                    (
		                SELECT SUM(BDoc_Box_QTY) AS Cantidad
		                FROM Dcmtos_DTL_Box
		                WHERE BDoc_Sis_Emp = a.HDoc_Sis_Emp AND BDoc_Doc_Cat = a.HDoc_Doc_Cat AND BDoc_Doc_Ano = a.HDoc_Doc_Ano AND BDoc_Doc_Num = a.HDoc_Doc_Num
	                ) Bultos, '' Orden, 0 PesoKG, 
	
	                IF(c.cli_plazoCR<=0,'C0D', 
	                CONCAT('Net ', CAST(c.cli_plazoCR AS CHAR))
	                ) Credito, 
	
	                date_format(IF(c.cli_plazoCR<=0,a.HDoc_Doc_Fec, DATE_ADD(a.HDoc_Doc_Fec, INTERVAL c.cli_plazoCR DAY)),'%d/%m/%Y') Vencimiento, 
	                a.HDoc_Doc_Fec Despachado, 
	                ROUND(a.HDoc_Doc_TC,4) tasa, 
	                ROUND(a.HDoc_Doc_TC * ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2)+.0000000001,2) Lempiras, 
	                ROUND(IFNULL(a.HDoc_RF1_Dbl,0),2) Flete, 
	                ROUND(a.HDoc_RF2_Dbl,2) Seguro, 
	                ROUND(SUM(d.DDoc_RF1_Dbl),2) LBsBrutas, 
	                ROUND(SUM(d.DDoc_RF2_Dbl),2) KgBrutos, 
	                IF(d.DDoc_Prd_UM=69, ROUND(SUM(d.DDoc_Prd_QTY),2), ROUND(SUM(d.DDoc_Prd_QTY * 2.2046),2)) LbsNetas, 
	                SUM(d.DDoc_Prd_Fob) KgNetos, 
	                FORMAT(SUM(IFNULL(ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,2),0)),2) Total, '" & varmoneda & "' simboloMoneda "
        strSQL &= "FROM Dcmtos_HDR a "
        strSQL &= "LEFT JOIN Dcmtos_DTL d On d.DDoc_Sis_Emp = a.HDoc_Sis_Emp And d.DDoc_Doc_Cat = a.HDoc_Doc_Cat And d.DDoc_Doc_Ano = a.HDoc_Doc_Ano And d.DDoc_Doc_Num = a.HDoc_Doc_Num "
        strSQL &= "INNER JOIN Clientes c ON c.cli_sisemp = a.HDoc_Sis_Emp AND c.cli_codigo = a.HDoc_Emp_Cod "
        strSQL &= "LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=a.HDoc_Doc_Mon "
        strSQL &= "WHERE a.HDoc_Sis_Emp = {empresa} AND a.HDoc_Doc_Cat = 36 AND a.HDoc_Doc_Ano = {anio} AND a.HDoc_Doc_Num = {numero} "
        strSQL &= "GROUP BY a.HDoc_Doc_Cat, a.HDoc_Doc_Ano, a.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_LCP(strSQL) = True Then

        End If
        strSQL2 = " SELECT 
            cc.cat_sist , 
            g.autorizacion  ,
            g.rango_inicial, 
            g.rango_final,  
            (d.DDoc_Prd_QTY / d.DDoc_Prd_DSQ) PrecioP ,
            DDoc_Prd_DSQ Descuento , 
            d.DDoc_Prd_Des Descripcion,
            d.DDoc_RF2_Txt Bultos, 
            d.DDoc_Prd_QTY Cantidad, 
            d.DDoc_Prd_NET Precio, 
            ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2) Monto, 
            '' Medida, 
            '' Lote, 
            '' Fabricante, 

            IFNULL((SELECT e.HDoc_DR1_Num FROM Dcmtos_DTL_Pro b LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat 
            AND  c.PDoc_Chi_Ano = b.PDoc_Par_Ano AND c.PDoc_Chi_Num = b.PDoc_Par_Num AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin AND c.PDoc_Par_Cat = 47 
            LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano AND e.HDoc_Doc_Num = c.PDoc_Par_Num  
            WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND b.PDoc_Chi_Num = d.DDoc_Doc_Num AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin LIMIT 1),'N/A'
            ) Referencia,

            IFNULL((SELECT  e.HDoc_DR1_Num FROM Dcmtos_DTL_Pro b LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat 
            AND c.PDoc_Chi_Ano = b.PDoc_Par_Ano AND c.PDoc_Chi_Num = b.PDoc_Par_Num AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin AND c.PDoc_Par_Cat = 75 
            LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano AND e.HDoc_Doc_Num = c.PDoc_Par_Num 
            WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND b.PDoc_Chi_Num = d.DDoc_Doc_Num AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin LIMIT 1),0
            ) PF,0 cajas

        FROM Dcmtos_DTL d 
        LEFT JOIN Dcmtos_HDR h36 ON h36.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h36.HDoc_Doc_Cat = d.DDoc_Doc_Cat  AND h36.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h36.HDoc_Doc_Num = d.DDoc_Doc_Num
        LEFT JOIN Gface g ON g.empresa = d.DDoc_Sis_Emp AND h36.HDoc_Doc_Num >= g.rango_inicial AND h36.HDoc_Doc_Num <= g.rango_final
        LEFT JOIN Catalogos cc ON cc.cat_num  = g.serie   AND cc.cat_clave = 'Doc_CFactura' AND cc.cat_clase = 'Serie'
            WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

        If BuscarRegistrosDcmtos_DTL_LCP(strSQL2) = True Then

        End If

        strSQL3 = " select group_concat(l1.dato1) AS dato1 , group_concat(l1.dato2) AS dato2 , group_concat(l1.dato3) AS dato3 , group_concat(l1.dato4) AS dato4 , group_concat(l1.dato5) AS dato5 , group_concat(l1.dato6) AS dato6 , group_concat(l1.dato7) AS dato7  , group_concat(l1.dato8) AS dato8 , group_concat(l1.dato9) AS dato9  , 
            group_concat(l1.dato10) AS dato10 , group_concat(l1.dato11) AS dato11 , group_concat(l1.dato12) AS dato12, group_concat(l1.dato13) As dato13 , group_concat(l1.dato14) AS dato14   
            from ( 
            SELECT (CASE WHEN b.cat_clave  = '04' THEN b.cat_desc  ELSE NULL END) AS dato1,
            (CASE WHEN b.cat_clave  = '05' THEN b.cat_desc  ELSE NULL END) AS dato2, 
            (CASE WHEN b.cat_clave  = '06' THEN b.cat_desc  ELSE NULL END) AS dato3, 
            (CASE WHEN b.cat_clave  = '07' THEN b.cat_desc  ELSE NULL END) AS dato4, 
            (CASE WHEN b.cat_clave  = '08' THEN b.cat_desc  ELSE NULL END) AS dato5, 
            (CASE WHEN b.cat_clave  = '09' THEN b.cat_desc  ELSE NULL END) AS dato6, 
            (CASE WHEN b.cat_clave  = '10' THEN b.cat_desc  ELSE NULL END) AS dato7,
            (CASE WHEN b.cat_clave  = '11' THEN b.cat_desc  ELSE NULL END) AS dato8, 
            (CASE WHEN b.cat_clave  = '12' THEN b.cat_desc  ELSE NULL END) AS dato9, 
            (CASE WHEN b.cat_clave  = '13' THEN b.cat_desc  ELSE NULL END) AS dato10, 
            (CASE WHEN b.cat_clave  = '14' THEN b.cat_desc  ELSE NULL END) AS dato11, 
            (CASE WHEN b.cat_clave  = '15' THEN b.cat_desc  ELSE NULL END) AS dato12, 
            (CASE WHEN b.cat_clave  = '16' THEN b.cat_desc  ELSE NULL END) AS dato13, 
            (CASE WHEN b.cat_clave  = '17' THEN b.cat_desc  ELSE NULL END) AS dato14 
            from Catalogos b 
            where b.cat_clase = 'Doc_HFDatos') l1"


        strSQL3 = Replace(strSQL3, "{empresa}", Sesion.IdEmpresa)
        strSQL3 = Replace(strSQL3, "{anio}", celdaAño.Text)
        strSQL3 = Replace(strSQL3, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_ACC_LCP(strSQL3) = True Then

        End If

        strSQL4 = " SELECT IFNULL(final.numero,'') AS Numero, IFNULL(GROUP_CONCAT(DISTINCT(final.fecha)),'') AS fecha, IFNULL(GROUP_CONCAT(DISTINCT(final.importador)),'') AS Salida, IFNULL(GROUP_CONCAT(DISTINCT(final.descarga)),'') AS LugarCarga, 
            IFNULL(GROUP_CONCAT(DISTINCT(final.trasporte)),'') AS DestinoFinal, IFNULL(GROUP_CONCAT(DISTINCT(final.furgon)),'') AS Transporte, IFNULL(GROUP_CONCAT(DISTINCT(final.cabezal)),'') AS Lot, 
            IFNULL(GROUP_CONCAT(DISTINCT(final.piloto)),'') AS Mills, IFNULL(GROUP_CONCAT(DISTINCT(final.licencia)),'') AS Origin, 
            IFNULL(GROUP_CONCAT(DISTINCT(final.pedido)),'') AS Nota, IFNULL(GROUP_CONCAT(DISTINCT(final.marchamo)),'') AS Wire, IFNULL(GROUP_CONCAT(DISTINCT(final.vendedor)),'') AS PrecioFob, 
            IFNULL(GROUP_CONCAT(DISTINCT(final.origen)),'') AS Hilados, IFNULL(GROUP_CONCAT(DISTINCT(final.pais)),'') AS Hilados2, IFNULL(GROUP_CONCAT(DISTINCT(final.pais1)),'') AS Conductor, IFNULL(GROUP_CONCAT(DISTINCT(final.pais2)),'') AS Hilados3, 
            IFNULL(GROUP_CONCAT(DISTINCT(final.pais3)),'') AS Cabezal, IFNULL(GROUP_CONCAT(DISTINCT(final.pais4)),'') AS pais4, IFNULL(GROUP_CONCAT(DISTINCT(final.transportista)),'') AS transportista, IFNULL(GROUP_CONCAT(DISTINCT(final.cargador)),'') AS cargador 
            FROM ( 
            SELECT DISTINCT(ccc.cat_clave), (CASE WHEN ccc.cat_clave = '01' THEN ccc.valores ELSE NULL END) AS numero, (CASE WHEN ccc.cat_clave = '02' THEN ccc.valores ELSE NULL END) AS fecha, (CASE WHEN ccc.cat_clave = '03' THEN ccc.valores ELSE NULL END) AS importador, 
            (CASE WHEN ccc.cat_clave = '04' THEN ccc.valores ELSE NULL END) AS descarga, (CASE WHEN ccc.cat_clave = '05' THEN ccc.valores ELSE NULL END) AS trasporte, 
            (CASE WHEN ccc.cat_clave = '06' THEN ccc.valores ELSE NULL END) AS furgon, 	 (CASE WHEN ccc.cat_clave = '07' THEN ccc.valores ELSE NULL END) AS cabezal,
            (CASE WHEN ccc.cat_clave = '08' THEN ccc.valores ELSE NULL END) AS piloto, 	(CASE WHEN ccc.cat_clave = '09' THEN ccc.valores ELSE NULL END) AS licencia, 
            (CASE WHEN ccc.cat_clave = '10' THEN ccc.valores ELSE NULL END) AS pedido, (CASE WHEN ccc.cat_clave = '11' THEN ccc.valores ELSE NULL END) AS marchamo, 
            (CASE WHEN ccc.cat_clave = '12' THEN ccc.valores ELSE NULL END) AS vendedor, 	(CASE WHEN ccc.cat_clave = '13' THEN ccc.valores ELSE NULL END) AS origen, (CASE WHEN ccc.cat_clave = '14' THEN ccc.valores ELSE NULL END) AS pais, 
            (CASE WHEN ccc.cat_clave = '15' THEN ccc.valores ELSE NULL END) AS pais1, (CASE WHEN ccc.cat_clave = '16' THEN ccc.valores ELSE NULL END) AS pais2, 
            (CASE WHEN ccc.cat_clave = '17' THEN ccc.valores ELSE NULL END) AS pais3, (CASE WHEN ccc.cat_clave = '18' THEN ccc.valores ELSE NULL END) AS pais4, 
            (CASE WHEN ccc.cat_clave = '19' THEN ccc.valores ELSE NULL END) AS transportista, 	(CASE WHEN ccc.cat_clave = '20' THEN ccc.valores ELSE NULL END) AS cargador 
            FROM ( 
            SELECT xx.*, GROUP_CONCAT(DISTINCT(xx.valor) SEPARATOR '|') AS valores 
            FROM ( 
            SELECT a.cat_clave, a.cat_pid, a.cat_desc, b.ADoc_Sis_Emp, b.ADoc_Doc_Ano, b.ADoc_Doc_Cat, b.ADoc_Doc_Num, ( 
            SELECT CASE WHEN a.cat_sist = 'Char' THEN CAST(COALESCE(c.ADoc_Dta_Chr, '{null}') AS CHAR) WHEN a.cat_sist = 'Text' THEN CAST(COALESCE(c.ADoc_Dta_Txt, '{null}') AS CHAR) WHEN a.cat_sist = 'Date' 
            THEN CAST(COALESCE(c.ADoc_Dta_Fec, '{null}') AS CHAR) WHEN a.cat_sist = 'Weight' THEN CAST(COALESCE(c.ADoc_Dta_Wht, '{null}') AS CHAR) WHEN a.cat_sist = 'Cant' THEN CAST(COALESCE(c.ADoc_Dta_Num, '{null}') AS CHAR) WHEN a.cat_sist = 'Money' THEN CAST(COALESCE(c.ADoc_Dta_Mny, '{null}') AS CHAR) ELSE 'ERROR' END 
            FROM Dcmtos_ACC c 
            WHERE c.ADoc_Sis_Emp = b.ADoc_Sis_Emp AND c.ADoc_Doc_Cat = b.ADoc_Doc_Cat AND c.ADoc_Doc_Ano = b.ADoc_Doc_Ano AND c.ADoc_Doc_Num = b.ADoc_Doc_Num AND c.ADoc_Doc_Sub = b.ADoc_Doc_Sub AND c.ADoc_Doc_Lin = a.cat_clave) AS Valor 
            FROM Catalogos a 
            INNER JOIN Dcmtos_ACC b ON b.ADoc_Sis_Emp = {empresa} AND b.ADoc_Doc_Ano = {anio} AND b.ADoc_Doc_Cat = 36 AND b.ADoc_Doc_Num = {numero} AND b.ADoc_Doc_Sub = 'Doc_HFDatos' AND b.ADoc_Doc_Lin = a.cat_clave 
            WHERE a.cat_clase = b.ADoc_Doc_Sub) xx 
            GROUP BY xx.cat_clave 
            ORDER BY xx.cat_pid) ccc 
            GROUP BY ccc.cat_clave)final "
        strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
        strSQL4 = Replace(strSQL4, "{anio}", celdaAño.Text)
        strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

        If BuscarRegistrosDcmtos_ACC_LCP2(strSQL4) = True Then

        End If


        rep4.Load("C:\XML\FacturacionLCP.xml")
        rep4.Load("C:\XML\FacturacionLCPDTL.xml")
        rep4.Load("C:\XML\FacturacionLCPACC.xml")
        rep4.Load("C:\XML\FacturacionLCPACC2.xml")
        Dim frm3 As New FrmFacturaLCP
        frm3.Reporte_A_VerLCP = rep4
        frm3.Name = "Facturacion Lake City Park"
        frm3.CrystalReportViewer1.ReportSource = rep4
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionLCP.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionLCPDTL.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionLCPACC.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionLCPACC2.xml")


    End Sub
#End Region

    Private Sub ImpresionNSM()
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO
        Dim strSQL5 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim clsConta As New clsContabilidad
        Dim rep4 As New FacturacionNSM

        strSQL = " SELECT a.HDoc_Doc_Num Numero,a.HDoc_DR1_Dbl Num2,a.HDoc_Doc_Ano Anio, CAST(LPAD(a.HDoc_Doc_Num,8,0) AS CHAR) num, CONCAT(a.HDoc_Emp_Nom,'\n ','Tax Registration: ',c.cli_nit,'\n ', "
        strSQL &= "     REPLACE(a.HDoc_Emp_Dir,'\r','')) Cliente,IFNULL(cl.cnt_celular,'') CelularCliente,IFNULL(cl.cnt_nombre,'') NombreContacto ,IFNULL(cl.cnt_correo,'') CorreoCliente,IFNULL(DATE_FORMAT(a.HDoc_Doc_Fec,'%d-%m-%Y'),'') Fecha, CONCAT(CAST(IFNULL(cm.cat_clave,'') AS CHAR),' ', FORMAT(SUM(IFNULL(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2),0)),2)) Total, "
        strSQL &= "         SUM(IFNULL(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2),0)) total2	, IFNULL(ac.ADoc_Dta_Chr,'') Remarks,cm.cat_clave, IFNULL(acd.ADoc_Dta_Txt,a.HDoc_Emp_Nom) Cuenta,IFNULL(ac2.ADoc_Dta_Chr,'') Motorista,IFNULL(ac3.ADoc_Dta_Txt,'') Cabezal,IFNULL(ac4.ADoc_Dta_Txt,'')Sello,IFNULL(ac5.ADoc_Dta_Chr,'')CondicionVenta ,IFNULL(DATE_FORMAT(ac6.ADoc_Dta_Fec,'%d %M %Y'),'') FechaA,a.HDoc_DR2_Num Serie, ( "
        strSQL &= "             SELECT SUM(BDoc_Box_QTY) AS Cantidad "
        strSQL &= "                 FROM Dcmtos_DTL_Box "
        strSQL &= "                     WHERE BDoc_Sis_Emp = a.HDoc_Sis_Emp AND BDoc_Doc_Cat = a.HDoc_Doc_Cat AND BDoc_Doc_Ano = a.HDoc_Doc_Ano AND BDoc_Doc_Num = a.HDoc_Doc_Num) Bultos, IF(c.cli_plazoCR<=0,'C0D', CONCAT('Net ', CAST(c.cli_plazoCR AS CHAR))) Credito, "
        strSQL &= "                         CAST(IF(c.cli_plazoCR<=0,a.HDoc_Doc_Fec, DATE_ADD(a.HDoc_Doc_Fec, INTERVAL c.cli_plazoCR DAY)) AS DATE) Vencimiento, a.HDoc_Doc_Fec Despachado, ROUND(a.HDoc_Doc_TC,4) tasa, ROUND(IFNULL(a.HDoc_RF1_Dbl,0),2) Flete, ROUND(a.HDoc_RF2_Dbl,2) Seguro, "
        strSQL &= "                             ROUND(SUM(d.DDoc_RF1_Dbl),2) LBsBrutas, ROUND(SUM(d.DDoc_RF2_Dbl),2) KgBrutos, IF(d.DDoc_Prd_UM=69, ROUND(SUM(d.DDoc_Prd_QTY),2), ROUND(SUM(d.DDoc_Prd_QTY * 2.2046),2)) LbsNetas, SUM(d.DDoc_Prd_Fob) KgNetos, FORMAT(SUM(IFNULL(ROUND(d.DDoc_Prd_QTY * d.DDoc_Prd_NET,2),0)),2) Total, "
        strSQL &= "                                 IFNULL(( "
        strSQL &= "                                     SELECT DISTINCT  CONCAT(e.pro_proveedor,' / RUC.: ',e.pro_nit) "
        strSQL &= "                                         FROM Dcmtos_DTL_Pro p "
        strSQL &= "                                             LEFT JOIN Dcmtos_DTL_Pro p47 ON p47.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p47.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p47.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p47.PDoc_Chi_Num = p.PDoc_Par_Num AND p47.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p47.PDoc_Par_Cat = 47 "
        strSQL &= "                                         LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = p47.PDoc_Sis_Emp AND h47.HDoc_Doc_Cat = p47.PDoc_Par_Cat AND h47.HDoc_Doc_Ano = p47.PDoc_Par_Ano AND h47.HDoc_Doc_Num = p47.PDoc_Par_Num "
        strSQL &= "                                     LEFT JOIN Proveedores e ON e.pro_sisemp = h47.HDoc_Sis_Emp AND e.pro_codigo = h47.HDoc_Emp_Cod "
        strSQL &= "                                 LEFT JOIN Contactos co ON co.cnt_sisemp = e.pro_sisemp AND co.cnt_codemp = e.pro_codigo AND co.cnt_status = 'Activo' "
        strSQL &= "                             WHERE p.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = a.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = a.HDoc_Doc_Ano AND p.PDoc_Chi_Num = a.HDoc_Doc_Num AND p.PDoc_Par_Cat = 48),0) Exportador, "
        strSQL &= "                         IFNULL(( "
        strSQL &= "                     SELECT DISTINCT  CONCAT('Attn.: ',co.cnt_nombre,' Telf.: ',co.cnt_celular,' email:', co.cnt_correo) "
        strSQL &= "                 FROM Dcmtos_DTL_Pro p "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p47 ON p47.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p47.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p47.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p47.PDoc_Chi_Num = p.PDoc_Par_Num AND p47.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p47.PDoc_Par_Cat = 47 "
        strSQL &= "         LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = p47.PDoc_Sis_Emp AND h47.HDoc_Doc_Cat = p47.PDoc_Par_Cat AND h47.HDoc_Doc_Ano = p47.PDoc_Par_Ano AND h47.HDoc_Doc_Num = p47.PDoc_Par_Num "
        strSQL &= "     LEFT JOIN Proveedores e ON e.pro_sisemp = h47.HDoc_Sis_Emp AND e.pro_codigo = h47.HDoc_Emp_Cod "
        strSQL &= " LEFT JOIN Contactos co ON co.cnt_sisemp = e.pro_sisemp AND co.cnt_codemp = e.pro_codigo AND co.cnt_status = 'Activo' "
        strSQL &= "     WHERE p.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = a.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = a.HDoc_Doc_Ano AND p.PDoc_Chi_Num = a.HDoc_Doc_Num AND p.PDoc_Par_Cat = 48),0) ContactoExportador, "
        strSQL &= "         IFNULL(( "
        strSQL &= "             SELECT DISTINCT  CONCAT(e.pro_direccion) "
        strSQL &= "                 FROM Dcmtos_DTL_Pro p "
        strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro p47 ON p47.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p47.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p47.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p47.PDoc_Chi_Num = p.PDoc_Par_Num AND p47.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p47.PDoc_Par_Cat = 47 "
        strSQL &= "                         LEFT JOIN Dcmtos_HDR h47 ON h47.HDoc_Sis_Emp = p47.PDoc_Sis_Emp AND h47.HDoc_Doc_Cat = p47.PDoc_Par_Cat AND h47.HDoc_Doc_Ano = p47.PDoc_Par_Ano AND h47.HDoc_Doc_Num = p47.PDoc_Par_Num "
        strSQL &= "                             LEFT JOIN Proveedores e ON e.pro_sisemp = h47.HDoc_Sis_Emp AND e.pro_codigo = h47.HDoc_Emp_Cod "
        strSQL &= "                                 LEFT JOIN Contactos co ON co.cnt_sisemp = e.pro_sisemp AND co.cnt_codemp = e.pro_codigo AND co.cnt_status = 'Activo' "
        strSQL &= "                                     WHERE p.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = a.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = a.HDoc_Doc_Ano AND p.PDoc_Chi_Num = a.HDoc_Doc_Num AND p.PDoc_Par_Cat = 48),0) DireccionExportador, "
        strSQL &= "                                         IFNULL(( "
        strSQL &= "                                             SELECT DISTINCT GROUP_CONCAT(DISTINCT h75.HDoc_DR1_Num) "
        strSQL &= "                                                 FROM Dcmtos_DTL_Pro p "
        strSQL &= "                                                     LEFT JOIN Dcmtos_DTL_Pro p48 ON p48.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p48.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p48.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p48.PDoc_Chi_Num = p.PDoc_Par_Num AND p48.PDoc_Chi_Lin = p.PDoc_Par_Lin AND p48.PDoc_Par_Cat = 75 "
        strSQL &= "                                                         LEFT JOIN Dcmtos_HDR h75 ON h75.HDoc_Sis_Emp = p48.PDoc_Sis_Emp AND h75.HDoc_Doc_Cat = p48.PDoc_Par_Cat AND h75.HDoc_Doc_Ano = p48.PDoc_Par_Ano AND h75.HDoc_Doc_Num = p48.PDoc_Par_Num "
        strSQL &= "                                                             WHERE p.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = a.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = a.HDoc_Doc_Ano AND p.PDoc_Chi_Num = a.HDoc_Doc_Num AND p.PDoc_Par_Cat = 48),0) PO, "
        strSQL &= "                                                         IFNULL(( "
        strSQL &= "                                                     SELECT DISTINCT  CONCAT(ic.cat_desc) "
        strSQL &= "                                                 FROM Dcmtos_DTL_Pro p "
        strSQL &= "                                             LEFT JOIN Dcmtos_HDR h75 ON h75.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h75.HDoc_Doc_Cat = p.PDoc_Par_Cat AND h75.HDoc_Doc_Ano = p.PDoc_Par_Ano AND h75.HDoc_Doc_Num = p.PDoc_Par_Num "
        strSQL &= "                                         LEFT JOIN Catalogos ic ON ic.cat_num = h75.HDoc_DR2_Cat AND ic.cat_clase = 'Costeo' "
        strSQL &= "                                     WHERE p.PDoc_Sis_Emp = a.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = a.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = a.HDoc_Doc_Ano AND p.PDoc_Chi_Num = a.HDoc_Doc_Num AND p.PDoc_Par_Cat = 48),0) Icoterm "
        strSQL &= "                                 FROM Dcmtos_HDR a "
        strSQL &= "                             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = a.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = a.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = a.HDoc_Doc_Ano AND d.DDoc_Doc_Num = a.HDoc_Doc_Num "
        strSQL &= "                         LEFT JOIN Dcmtos_ACC ac ON ac.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Doc_HFDatos' AND ac.ADoc_Doc_Lin ='02' "
        strSQL &= "                     LEFT JOIN Dcmtos_ACC acd ON acd.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND acd.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND acd.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND acd.ADoc_Doc_Num = a.HDoc_Doc_Num AND acd.ADoc_Doc_Sub = 'Doc_HFDatos' AND acd.ADoc_Doc_Lin ='01' "
        strSQL &= "                 LEFT JOIN Dcmtos_ACC ac2 ON ac2.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac2.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac2.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac2.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac2.ADoc_Doc_Sub = 'Doc_HFDatos' AND ac2.ADoc_Doc_Lin ='03' "
        strSQL &= "             LEFT JOIN Dcmtos_ACC ac3 ON ac3.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac3.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac3.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac3.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac3.ADoc_Doc_Sub = 'Doc_HFDatos' AND ac3.ADoc_Doc_Lin ='04' "
        strSQL &= "         LEFT JOIN Dcmtos_ACC ac4 ON ac4.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac4.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac4.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac4.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac4.ADoc_Doc_Sub = 'Doc_HFDatos' AND ac4.ADoc_Doc_Lin ='05' "
        strSQL &= "     LEFT JOIN Dcmtos_ACC ac5 ON ac5.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac5.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac5.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac5.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac5.ADoc_Doc_Sub = 'Doc_HFDatos' AND ac5.ADoc_Doc_Lin ='06' "
        strSQL &= "   LEFT JOIN Dcmtos_ACC ac6 ON ac6.ADoc_Sis_Emp =a.HDoc_Sis_Emp AND ac6.ADoc_Doc_Cat = a.HDoc_Doc_Cat AND ac6.ADoc_Doc_Ano = a.HDoc_Doc_Ano AND ac6.ADoc_Doc_Num = a.HDoc_Doc_Num AND ac6.ADoc_Doc_Sub = 'Doc_CFNotas' AND ac6.ADoc_Doc_Lin ='01' "
        If celdaTipoFactura.Text = 0 Then
            strSQL &= " INNER JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= "     INNER JOIN Catalogos o ON o.cat_clase = 'Paises' AND o.cat_num = i.inv_lugarfab "
        End If
        strSQL &= "         INNER JOIN Clientes c ON c.cli_sisemp = a.HDoc_Sis_Emp AND c.cli_codigo = a.HDoc_Emp_Cod "
        strSQL &= "             LEFT JOIN Catalogos cm ON cm.cat_clase='Monedas' AND cm.cat_num=a.HDoc_Doc_Mon "
        strSQL &= "                 LEFT JOIN Contactos cl ON cl.cnt_sisemp = a.HDoc_Sis_Emp AND cl.cnt_codemp = a.HDoc_Emp_Cod AND cl.cnt_status = 'Activo' "
        strSQL &= "                     WHERE a.HDoc_Sis_Emp = {empresa} AND a.HDoc_Doc_Cat = 36 AND a.HDoc_Doc_Ano = {anio} AND a.HDoc_Doc_Num = {numero} "
        strSQL &= "                         GROUP BY a.HDoc_Doc_Cat, a.HDoc_Doc_Ano, a.HDoc_Doc_Num "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_NSM(strSQL) = True Then
        End If
        If celdaTipoFactura.Text = 0 Then
            strSQL2 &= "    SELECT  a.art_desc TipoProducto,a.art_frac TipoPoliza,d.DDoc_Prd_Cod Codigo,i.inv_descripcion CodigoD,IF(d.DDoc_Prd_Des LIKE '%RENTA%', d.DDoc_Prd_Des, a.art_DCorta) Clasificacion,d.DDoc_RF2_Txt Bultos, SUM(d.DDoc_Prd_QTY) Cantidad, d.DDoc_Prd_NET Precio,  a.art_DLarga Descripcion, "
            strSQL2 &= "        SUM(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2)) Monto, cm.cat_clave Medida, IF(i.inv_prodlote='','', CONCAT('',i.inv_prodlote)) Lote, IFNULL(p.pro_nombre,'') Fabricante, "
            strSQL2 &= "            IFNULL(( "
            strSQL2 &= "                SELECT e.HDoc_DR1_Num "
            strSQL2 &= "                    FROM Dcmtos_DTL_Pro b "
            strSQL2 &= "                        LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat AND c.PDoc_Chi_Ano = b.PDoc_Par_Ano AND c.PDoc_Chi_Num = b.PDoc_Par_Num AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin AND c.PDoc_Par_Cat = 47 "
            strSQL2 &= "                            LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano AND e.HDoc_Doc_Num = c.PDoc_Par_Num "
            strSQL2 &= "                                WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND b.PDoc_Chi_Num = d.DDoc_Doc_Num AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin LIMIT 1),'N/A') Referencia, "
            strSQL2 &= "                                    IFNULL(( "
            strSQL2 &= "                                        SELECT DISTINCT e.HDoc_RF2_Txt "
            strSQL2 &= "                                            FROM Dcmtos_DTL_Pro b "
            strSQL2 &= "                                                LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = b.PDoc_Par_Cat AND c.PDoc_Chi_Ano = b.PDoc_Par_Ano AND c.PDoc_Chi_Num = b.PDoc_Par_Num AND c.PDoc_Chi_Lin = b.PDoc_Par_Lin AND c.PDoc_Par_Cat = 47 "
            strSQL2 &= "                                                    LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.PDoc_Sis_Emp AND e.HDoc_Doc_Cat = c.PDoc_Par_Cat AND e.HDoc_Doc_Ano = c.PDoc_Par_Ano AND e.HDoc_Doc_Num = c.PDoc_Par_Num "
            strSQL2 &= "                                                        WHERE b.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND b.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND b.PDoc_Chi_Num = d.DDoc_Doc_Num AND b.PDoc_Chi_Lin = d.DDoc_Doc_Lin LIMIT 1),0) ColorConos, "
            strSQL2 &= "                                                    IFNULL(( "
            strSQL2 &= "                                                SELECT SUM(bx.BDoc_Box_QTY) "
            strSQL2 &= "                                            FROM Dcmtos_DTL_Box bx "
            strSQL2 &= "                                        WHERE bx.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND bx.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND bx.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND bx.BDoc_Doc_Num= d.DDoc_Doc_Num  LIMIT 1),0) Cajas "
            strSQL2 &= "                                    FROM Dcmtos_DTL d "
            strSQL2 &= "                                LEFT JOIN Dcmtos_HDR h36 ON h36.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h36.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h36.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h36.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL2 &= "                             INNER JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod "
            strSQL2 &= "                        INNER JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
            strSQL2 &= "                    LEFT JOIN Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM "
            strSQL2 &= "            LEFT JOIN Proveedores p ON p.pro_sisemp = i.inv_sisemp AND p.pro_codigo = i.inv_provcod "
            strSQL2 &= "        WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} "
            strSQL2 &= "    GROUP BY d.DDoc_Prd_Cod,d.DDoc_Prd_NET"
        Else
            strSQL2 &= " SELECT d.DDoc_Prd_Des TipoProducto,'' TipoPoliza,d.DDoc_Prd_Cod Codigo,d.DDoc_Prd_Des CodigoD,IF(d.DDoc_Prd_Cod =0, d.DDoc_Prd_Des, '') Descripcion,d.DDoc_RF2_Txt Bultos, SUM(d.DDoc_Prd_QTY) Cantidad, d.DDoc_Prd_NET Precio, SUM(ROUND((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+.0000000001,2)) Monto, cm.cat_clave Medida, '' Lote, '' Fabricante,'' Referencia, '' ColorConos, IFNULL((
                            SELECT SUM(bx.BDoc_Box_QTY)
                            FROM Dcmtos_DTL_Box bx
                            WHERE bx.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND bx.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND bx.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND bx.BDoc_Doc_Num= d.DDoc_Doc_Num
                            LIMIT 1),0) Cajas
                            FROM Dcmtos_DTL d
                            LEFT JOIN Dcmtos_HDR h36 ON h36.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h36.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h36.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h36.HDoc_Doc_Num = d.DDoc_Doc_Num
                            LEFT JOIN Catalogos cm ON cm.cat_clase = 'Medidas' AND cm.cat_num = d.DDoc_Prd_UM
                            WHERE d.DDoc_Sis_Emp = 18 AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}
                            GROUP BY d.DDoc_Prd_Cod "
        End If

        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
        strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_DTL_NSM(strSQL2) = True Then
        End If
        rep4.Load("C:\XML\FacturacionNSM.xml")
        rep4.Load("C:\XML\FacturacionNSMDTL.xml")
        Dim frm3 As New FrmFacturaHSM
        frm3.Reporte_A_VerHSM = rep4
        frm3.Name = "Facturacion NSM"
        frm3.CrystalReportViewer1.ReportSource = rep4
        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionNSM.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\FacturacionNSMDTL.xml")
        impreso = celdaImpreso.Text
        If impreso = 0 Then
            If frm3.DialogResult = System.Windows.Forms.DialogResult.Cancel Then
                If MsgBox("The Document is printed correctly", MsgBoxStyle.YesNo, "Question") = vbYes Then
                    imprimir = 1
                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acGeneraYRM, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                    strSQL5 = "UPDATE Dcmtos_HDR h"
                    strSQL5 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                    strSQL5 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                    If Sesion.IdEmpresa = 18 Then
                        strSQL5 &= ";UPDATE PDM.Dcmtos_HDR h"
                        strSQL5 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                        strSQL5 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                    End If
                    strSQL5 = Replace(strSQL5, "{impresion}", imprimir)
                    strSQL5 = Replace(strSQL5, "{empresa}", Sesion.IdEmpresa)
                    strSQL5 = Replace(strSQL5, "{anio}", celdaAño.Text)
                    strSQL5 = Replace(strSQL5, "{numero}", celdaNumero.Text)

                    'Ejecuta la instrucción
                    MyCnn.CONECTAR = strConexion
                    COM2 = New MySqlCommand(strSQL5, CON)
                    COM2.ExecuteNonQuery()
                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acGeneraYRM, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                    clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtpFecha.Value)
                    If sqlVerificaYMR() = 1 Then
                        GenerarYarnMovement()
                    End If
                End If
            End If
        End If
    End Sub
    'Procedimiento Fel
    Private Function PermisoAnular() As Boolean

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_codigo Permiso"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_usuario = '{usuario}' AND p.pms_modulo = 16 AND p.pms_codigo  ='ANULAR'"
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetString("Permiso") = "ANULAR" Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    Private Function PedirAutorizacionAnularFel(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AnularFEL"
        Dim frm As frmAutorización
        PedirAutorizacionAnularFel = False

        frm = New frmAutorización
        frm.Iniciar(36, STR_MARGEN, 0, "Autorizar Anula Fel")
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionAnularFel = True
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text, "Autoriza anulacion FEL " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        Else
            MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
        End If
        LogResult = True
    End Function

    Public Sub CargarDatosFel()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Try
            strSQL = "SELECT f.FechaEmisionDocumento,f.FechaHoraCertificacion,f.Serie, f.NumeroAutorizacion ,f.UUID "
            strSQL &= "  FROM Fel f  "
            strSQL &= "     WHERE f.Empresa = {empresa} AND f.catalogo = {catalogo} AND f.Anio = {anio} AND f.Numero = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", 36)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaFechaEmisionDocumento.Text = REA.GetString("FechaEmisionDocumento")
                    celdaFechaHoraCertificacion.Text = REA.GetString("FechaHoraCertificacion")
                    celdaSerieFel.Text = REA.GetString("Serie")
                    celdaUUID.Text = REA.GetString("UUID")
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    etiquetaSerie.Text = arrayCadena(INT_CERO)
                    etiquetaAutorizacion.Text = REA.GetString("NumeroAutorizacion")
                    etiquetaSerie.Visible = True
                    etiquetaAutorizacion.Visible = True
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function EnvioProyecto(ByVal strError As String) As Boolean
        Dim logEnvio As Boolean = False
        Dim mail As New clsCorreo
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim correo As New Tablas.TCORREO
        Dim j As Integer
        Dim K As Integer
        Dim conec As New MySqlConnection
        Dim COM1 As MySqlCommand
        Dim strInsert As String = STR_VACIO
        Dim strUsuario As String
        Dim strSQL1 As String
        Dim strConexion2 As String
        Dim strTemporal As String = STR_VACIO
        Dim strTexto As String = STR_VACIO
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Try

            ArrayServer = strConexion.Split(";".ToCharArray)
            strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

            If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
                strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
            Else
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
                strConexion2 = Replace(strConexion2, "{puerto}", "3308")
            End If

            strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
            strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
            strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

            strSQL1 = " Select   CONCAT(per_nombre1 ,'  ' ,per_apellido1) Puesto  FRom Personal  WHERE per_codigo={usuario} "
            strSQL1 = Replace(strSQL1, "{usuario}", Sesion.idUsuario)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL1, conec)
            strUsuario = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            strTexto &= " <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color:  #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;text-align: Left'>  USUARIO: </td> <td colspan='3' style='border-right: solid black 1px; border-bottom: solid black 1px;padding: 2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;'>" & strUsuario & "</td> </tr>"
            strTexto &= " <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color:  #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;text-align: Left'>  FECHA INGRESO : </td> <td colspan='3' style='border-right: solid black 1px; border-bottom: solid black 1px;padding: 2px 5px; font-family: Tahoma, Arial;font-size:  7pt;width: 3.5cm;'> " & Now() & "</td> </tr>"
            strTexto &= "   <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  CONTRATO DE : </td> <td colspan='3' style='border-right: solid black 1px; border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;'> " & celdaNumero.Text & " </td> </tr>"
            strTexto = Replace(strTexto, vbCrLf, "<br>")
            strTexto = Replace(strTexto, "'", Chr(34))

            strTemporal &= " <html> <BODY> <table cellspacing=0 > <tr> <td colspan='4'; style=' border:solid White 0px; background-color: #FFFFFF; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 10pt;width: 3.5cm;text-align: center;border-bottom:solid black 1px; border-right: solid black 1px;border-left: solid black 1px;border-top:solid black 1px;font-weight:bold;'> " & strError & "</td> </tr> "
            strTemporal = Replace(strTemporal, "'", Chr(34))
            '  strSQL = SQLCorreo()
            ' MyCnn.CONECTAR = strConexion
            'COM = New MySqlCommand(strSQL, CON)
            ' REA = COM.ExecuteReader()
            'If REA.HasRows Then
            'Do While REA.Read
            strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & "tisoportegt@grupokarims.com" & "',' Alerta de Seguridad ' ,'" & strTemporal & vbCrLf & strTexto & " </table> </body> </html>',0); ")
            '    Loop
            'COM = Nothing
            ' End If
            MyCnn.CONECTAR = strConexion2
            COM = New MySqlCommand(strInsert, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
            logEnvio = True




        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logEnvio
    End Function
    Private Function GenerarUUID() As String
        Dim UUID As String
        UUID = System.Guid.NewGuid.ToString.ToUpper
        ' MsgBox(UUID)
        Return UUID
    End Function
    Private Function VerificarAcceso(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felFact' AND c.cat_clave = 'Facturacion' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Private Function VerificarAccesoLocal(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felFactL' AND c.cat_clave = 'Facturacion' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Private Function VerificarDocumentoXML(ByRef strToken As String, ByRef strUUID As String) As Integer
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strVerifica As String = System.Windows.Forms.Application.StartupPath & "\Verifica.xml"
        Dim strSolicitarToken As String = STR_VACIO
        Dim logResultado As Integer
        Dim strResultado As String = STR_VACIO
        Dim strXMLVerificaDocumento As String = STR_VACIO
        Dim t As New Fel
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim fs As FileStream
        If cFunciones.ExisteArchivo(strpath) Then
            'Solicita Token en el Web Service 
            strSolicitarToken = t.SolicitarToken1(strpath)
            If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                ' Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' cierra el archivo 
                sw.Close()
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
            Else
                'Crea Archivo TokenD.xml
                fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                fs.Close()
                'Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
                sw.Close()
            End If
        End If
        If celdaUUID.Text <> STR_VACIO Then
            strUUID = celdaUUID.Text
        Else
            strUUID = GenerarUUID()
            celdaUUID.Text = strUUID
        End If
        'strUUID = "4DFFD5BC-AC7E-4779-8D4C-8C3903322993"
        strXMLVerificaDocumento &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
        strXMLVerificaDocumento &= "<VerificaDocumentoRequest id='" & strUUID & "'/>" & vbCrLf

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        sw.Write(strXMLVerificaDocumento)
        sw.Close()

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        sw.Write(t.VerificaDocumento(strVerifica, strToken))
        sw.Close()
        xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        nodos_lista = xml_Documento.SelectNodes("/VerificaDocumentoResponse")
        ''Iniciamos el ciclo de lectura
        For Each nodo In nodos_lista
            '    ' Asigna el Codigo 64 Bits
            strResultado = nodo.ChildNodes.Item(0).InnerText
            If strResultado = "0" Then
                logResultado = INT_CERO
                GuardarFel(STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, strUUID)
            Else
                logResultado = INT_UNO
            End If
        Next


        Return logResultado
    End Function
    Public Sub GuardarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 36
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PINSERT() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActualizarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 36
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PUPDATE() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Function AnularFel(ByVal strSerieUUID As String, ByVal strFechaEmsionDocumento As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim logResultado As Boolean = True
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenidoA.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\AnulacionFact.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFA" & celdaNumero.Text & ".xml"
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLAnulacion As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strValidarAnulacion As String = STR_VACIO
        Dim strFechaAnulacion As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim strToken As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Try
            If cFunciones.ExisteArchivo(strpath) Then
                'Solicita Token en el Web Service 
                strSolicitarToken = t.SolicitarToken1(strpath)
                If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                    ' Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' cierra el archivo 
                    sw.Close()
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                Else
                    'Crea Archivo TokenD.xml
                    fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    fs.Close()
                    'Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                    sw.Close()
                End If
            End If
            strFechaAnulacion = Now().ToString("yyyy-MM-ddTHH:mm:ss") & "-06:00"
            ' XML Firma Electronica 
            strXMLAnulacion &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLAnulacion &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
            strXMLAnulacion &= "<xml_dte>" & vbCrLf
            strXMLAnulacion &= "<![CDATA[ " & vbCrLf
            ' XML ANULACION
            strXMLAnulacion &= " <ns:GTAnulacionDocumento Version='0.1' xmlns:ns='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#'>" & vbCrLf
            strXMLAnulacion &= "<ns:SAT>" & vbCrLf
            strXMLAnulacion &= "<ns:AnulacionDTE ID='DatosCertificados'>" & vbCrLf
            strXMLAnulacion &= "<ns:DatosGenerales ID='DatosAnulacion'" & vbCrLf
            strXMLAnulacion &= "NumeroDocumentoAAnular='" & celdaSerieFel.Text & "'" & vbCrLf

            'If strPaisCliente <> 0 Then
            '    strXMLAnulacion &= "NITEmisor='90028481' IDReceptor='CF'" & vbCrLf
            'Else
            strXMLAnulacion &= "NITEmisor='90028481' IDReceptor='" & Replace(strNitCliente, "-", "") & "'" & vbCrLf
            'End If
            strXMLAnulacion &= "FechaEmisionDocumentoAnular='" & celdaFechaEmisionDocumento.Text & "'" & vbCrLf
            strXMLAnulacion &= "FechaHoraAnulacion='" & strFechaAnulacion & "' MotivoAnulacion='Cancelacion'/>" & vbCrLf
            strXMLAnulacion &= "</ns:AnulacionDTE>" & vbCrLf
            strXMLAnulacion &= "</ns:SAT>" & vbCrLf
            strXMLAnulacion &= "</ns:GTAnulacionDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXMLAnulacion &= "]]>" & vbCrLf
            strXMLAnulacion &= "</xml_dte>" & vbCrLf
            strXMLAnulacion &= "</FirmaDocumentoRequest>" & vbCrLf

            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenidoA.xml")
            sw.Write(strXMLAnulacion)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<AnulaDocumentoXMLRequest id='" & celdaSerieFel.Text & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</AnulaDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFact.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFact.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml")
            ' Registra la factura ya firmado
            strXMLFinal = t.AnulaDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el Anula documento de Fel ")
                strError &= "Fallo en el Anula documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()

            System.Threading.Thread.Sleep(5000)
            '    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml")
            '   nodos_lista = xml_Documento.SelectNodes("/")
            'iniciamos el ciclo de lectura
            '  For Each nodo In nodos_lista
            ' asigna el token devuelto por web service 
            ' strValidarAnulacion = nodo.ChildNodes.Item(2).InnerText
            ' Next
            ' If strValidarAnulacion = INT_UNO Then
            'MsgBox("La factura registrada se encuentra anulado")
            'logResultado = False
            'Else
            ' MsgBox("La factura  se ha anulado correctamente ")
            'logResultado = True
            'End If


            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & celdaSerieFel.Text & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFA" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFA" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinalAN" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinalAN" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinalAN" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelAnulacion" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacion" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacion" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacion" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacion" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacion" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelAnulacion" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            botonImprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelAnulacion" & celdaNumero.Text & ".pdf")

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Function ImpresionFel(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal strRespuesta As String, ByVal strToken As String, ByVal strUUID As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim strSQL2 As String = STR_VACIO
        Dim logEncabezado As Boolean = False
        Dim Horario As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim fs As FileStream
        Dim t As New Fel
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml"
        Dim strpathCUI As String = System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDF" & celdaNumero.Text & ".xml"
        '  Dim strToken As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLFel As String = STR_VACIO
        Dim strXMLDTL As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strXMLValida As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim strXML As String = STR_VACIO
        Dim nodo As XmlNode
        Dim strNumero As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim dblGranTotal As Double = INT_CERO
        Dim localZone As TimeZone = TimeZone.CurrentTimeZone
        Dim strNombreC As String = STR_VACIO
        Dim strDireccionC As String = STR_VACIO
        Dim strCodigoC As String = STR_VACIO
        Dim strNombreCliente As String = STR_VACIO
        Dim strpaisOrigen As String = STR_VACIO
        Dim strDireccionCliente As String = STR_VACIO
        Dim strCodigoCliente As String = STR_VACIO
        Dim strNombreExportador As String = STR_VACIO
        Dim strIcoterm As String = STR_VACIO
        Dim strFechaHoraCertificacion As String = STR_VACIO
        Dim strNitCertificador As String = STR_VACIO
        Dim strSerieDocumento As String = STR_VACIO
        Dim strNumeroAutorizacion As String = STR_VACIO
        Dim strCadenaEncontrada As String = STR_VACIO
        Dim strDiasCredito As Integer = INT_CERO
        Dim arrayCadena() As String
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strPrueba As String = STR_VACIO
        Dim vlcResultado As String = STR_VACIO
        Dim logResultado As Boolean = True
        Dim strError As String = STR_VACIO
        ' Especifica el criterio
        Dim vlcCriterio As String = "dte:NumeroAutorizacion"


        ' Encabezado
        Dim strPoliza As String = STR_VACIO
        Dim strKI As String = STR_VACIO
        Dim strPO As String = STR_VACIO
        ' Detalle 
        Dim intBulto As Integer = INT_CERO
        'Pie Pagina 
        Dim strNota As String = STR_VACIO


        Try



            'strXMLValida = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><RetornaDatosClienteRequestCUI><CUI>" & celdaNIT.Text & "</CUI></RetornaDatosClienteRequestCUI>"

            '' strXMLRegistra = cfun.convertirXML(strXMLRegistra)
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")
            'fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")

            'sw.Write(strXMLValida)
            'sw.Close()
            'strXMLFinal = t.ValidaCUI(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml", strToken)
            'If logResultado = False Then
            '    MsgBox("Fallo en verifica CUI ")
            '    strError &= "Fallo en verifica CUI"
            '    '  EnvioProyecto(strError)
            '    Exit Function
            'End If
            'sw.Write(strXMLFinal)
            'sw.Close()





            botonImprimir.Enabled = False
            'If cFunciones.ExisteArchivo(strpath) Then
            '    'Solicita Token en el Web Service 
            '    strSolicitarToken = t.SolicitarToken1(strpath)
            '    If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
            '        ' Abre Archivo TokenD.xml
            '        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
            '        ' Copia el Token devuelvo del Web Service 
            '        sw.Write(strSolicitarToken)
            '        ' cierra el archivo 
            '        sw.Close()
            '        ' Carga el Archivo TokenD.xml
            '        xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
            '        nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
            '        'Iniciamos el ciclo de lectura
            '        For Each nodo In nodos_lista
            '            ' Asigna el Token Devuelto por Web Service 
            '            strToken = nodo.ChildNodes.Item(1).InnerText
            '        Next
            '    Else
            '        'Crea Archivo TokenD.xml
            '        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
            '        fs.Close()
            '        'Abre Archivo TokenD.xml
            '        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
            '        ' Copia el Token devuelvo del Web Service 
            '        sw.Write(strSolicitarToken)
            '        ' Carga el Archivo TokenD.xml
            '        xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
            '        nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
            '        'Iniciamos el ciclo de lectura
            '        For Each nodo In nodos_lista
            '            ' Asigna el Token Devuelto por Web Service 
            '            strToken = nodo.ChildNodes.Item(1).InnerText
            '        Next
            '        sw.Close()
            '    End If
            'End If
            Horario = Now().ToString("yyyy-MM-ddTHH:mm:ss")
            If celdaTipoFactura.Text = 0 Then

                strSQL2 = " SELECT cxp.cli_cliente NombreC ,cxp.cli_direccion DireccionC,cxp.cli_codigo CodigoC,emp.emp_nit NIT,emp.emp_direccion DireccionEmisor ,emp.emp_razon NombreComercial,h.HDoc_Emp_Nom, h.HDoc_Emp_Dir, replace(h.HDoc_Emp_NIT,'-','') HDoc_Emp_NIT, YEAR(h.HDoc_Doc_Fec), LPAD(MONTH(h.HDoc_Doc_Fec),2,'0') mes, LPAD(DAY(h.HDoc_Doc_Fec),2,'0') dia, 'GUATEMALA', h.HDoc_DR1_Num KI2, h.HDoc_Emp_Cod, h.HDoc_Doc_Num, CONCAT(d.DDoc_Prd_Des, '-','(',d.DDoc_RF1_Txt,')') Descripcion, d.DDoc_Prd_Cod, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET PrecioUnitario, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET) AS Precio , c.cat_clave Medida, m.cat_clave Moneda, a.art_DLarga,cli.cli_cliente Cliente , cli.cli_direccion DireccionCliente,cli.cli_codigo CodigoCliente ,d.DDoc_Doc_Lin Linea,d.DDoc_prd_DSQ Descuento , h.HDoc_Doc_Mon CodigoMoneda, cp.cat_desc Pais, cp.cat_dato PaisReceptor  ,d.DDoc_RF1_Txt KI, (SELECT GROUP_CONCAT(DISTINCT cc.cat_desc SEPARATOR ',') pai FROM Dcmtos_DTL dd LEFT JOIN Inventarios ii ON ii.inv_sisemp = dd.DDoc_Sis_Emp AND ii.inv_numero = dd.DDoc_Prd_Cod LEFT JOIN Catalogos cc ON cc.cat_num = ii.inv_lugarfab WHERE dd.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND dd.DDoc_Doc_Cat = d.DDoc_Doc_Cat AND dd.DDoc_Doc_Ano = d.DDoc_Doc_Ano AND dd.DDoc_Doc_Num = d.DDoc_Doc_Num) origen, v.cat_desc vendedor,cc.cat_ext Signo, IFNULL(cli.cli_plazoCR,0) dias,a.art_venta Tipo, ("
                strSQL2 &= " select GROUP_CONCAT(DISTINCT e.ADoc_Dta_Chr  SEPARATOR ',') from Dcmtos_DTL_Pro p  "
                strSQL2 &= "    left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin and i.PDoc_Par_Cat = 47 "
                strSQL2 &= "        left join Dcmtos_DTL_Pro pp on pp.PDoc_Sis_Emp = i.PDoc_Sis_Emp and pp.PDoc_Chi_Cat = i.PDoc_Par_Cat and pp.PDoc_Chi_Ano = i.PDoc_Par_Ano and pp.PDoc_Chi_Num = i.PDoc_Par_Num and pp.PDoc_Chi_Lin = i.PDoc_Par_Lin  "
                strSQL2 &= "            left join Dcmtos_ACC e on e.ADoc_Sis_Emp =  pp.PDoc_Sis_Emp and e.ADoc_Doc_Cat = pp.PDoc_Par_Cat and e.ADoc_Doc_Ano = pp.PDoc_Par_Ano and e.ADoc_Doc_Num = pp.PDoc_Par_Num and e.ADoc_Doc_Sub = 'Doc_PolImp' AND e.ADoc_Doc_Lin = '01'  "
                strSQL2 &= "                where p.PDoc_Sis_Emp = h.HDoc_Sis_Emp  and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat  and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Par_Cat = 48  ) poliza, "
                strSQL2 &= "                    ( select GROUP_CONCAT(DISTINCT (concat(pp.HDoc_Doc_Num ,':',pp.HDoc_DR1_Num )) SEPARATOR ',') from Dcmtos_DTL_Pro p "
                strSQL2 &= "                        left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin and i.PDoc_Par_Cat = 75 "
                strSQL2 &= "                            left join Dcmtos_HDR pp on pp.HDoc_Sis_Emp = i.PDoc_Sis_Emp and pp.HDoc_Doc_Cat = i.PDoc_Par_Cat and pp.HDoc_Doc_Ano = i.PDoc_Par_Ano and pp.HDoc_Doc_Num = i.PDoc_Par_Num  "
                strSQL2 &= "                                where p.PDoc_Sis_Emp = h.HDoc_Sis_Emp  and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat  and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Par_Cat = 48 ) pF, "
                strSQL2 &= "                                    (select sum(b.BDoc_Box_QTY ) from Dcmtos_DTL_Box b "
                strSQL2 &= "                                         where b.BDoc_Sis_Emp = d.DDoc_Sis_Emp  and b.BDoc_Doc_Cat = d.DDoc_Doc_Cat  and b.BDoc_Doc_Ano = d.DDoc_Doc_Ano  and b.BDoc_Doc_Num = d.DDoc_Doc_Num  and b.BDoc_Doc_Lin = d.DDoc_Doc_Lin ) bultos,  '{OPCION}' CIF, cast(ADDDATE(h.HDoc_Doc_Fec, INTERVAL IFNULL(cli.cli_plazoCR,0) DAY) as char) fvencimiento "
                strSQL2 &= "        , ifnull(cxp.cli_clasificacion,0) clasTipoFactura, if(cli.cli_exterior='Local',0,1) cli_exterior, cli.cli_plazoCR diasCredito"
                strSQL2 &= "                                            from Dcmtos_HDR h"
                strSQL2 &= "                                                left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num  "
                strSQL2 &= "                                               LEFT JOIN Dcmtos_DTL_Pro d48 ON d48.PDoc_Sis_Emp = d.DDoc_Sis_Emp  AND d48.PDoc_Chi_Cat = d.DDoc_Doc_Cat  AND d48.PDoc_Chi_Ano = d.DDoc_Doc_Ano  AND d48.PDoc_Chi_Num = d.DDoc_Doc_Num AND d48.PDoc_Chi_Lin = d.DDoc_Doc_Lin  AND d48.PDoc_Par_Cat = 48"
                strSQL2 &= "                                                    LEFT JOIN Dcmtos_DTL_Pro i75 ON i75.PDoc_Sis_Emp = d48.PDoc_Sis_Emp AND i75.PDoc_Chi_Cat = d48.PDoc_Par_Cat AND i75.PDoc_Chi_Ano = d48.PDoc_Par_Ano AND i75.PDoc_Chi_Num  = d48.PDoc_Par_Num AND i75.PDoc_Chi_Lin = d48.PDoc_Par_Lin AND i75.PDoc_Par_Cat = 75  "
                strSQL2 &= "                                                        LEFT JOIN Dcmtos_HDR h75 ON h75.HDoc_Sis_Emp = i75.PDoc_Sis_Emp AND h75.HDoc_Doc_Cat = i75.PDoc_Par_Cat AND h75.HDoc_Doc_Ano = i75.PDoc_Par_Ano AND h75.HDoc_Doc_Num = i75.PDoc_Par_Num "
                strSQL2 &= "                                                            LEFT JOIN Clientes cxp ON cxp.cli_sisemp = h75.HDoc_Sis_Emp AND cxp.cli_codigo = h75.HDoc_DR1_Emp  "
                strSQL2 &= "                                                                    left join Catalogos c on c.cat_num = d.DDoc_Prd_UM  and c.cat_clase ='Medidas' "
                strSQL2 &= "                                                                        left join Catalogos m on m.cat_num = h.HDoc_Doc_Mon  "
                strSQL2 &= "                                                                    Left Join Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon "
                strSQL2 &= "                                                                left join Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod "
                strSQL2 &= "                                                           left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo "
                strSQL2 &= "                                                       LEFT JOIN Catalogos v ON v.cat_sist = 'DEF_COUNTRY' "
                strSQL2 &= "                                               LEFT JOIN Catalogos o ON o.cat_num = i.inv_lugarfab "
                strSQL2 &= "                                  LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod "
                strSQL2 &= "                            LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais  "
                strSQL2 &= "                        LEFT JOIN Empresas emp ON emp.emp_no = h.HDoc_Sis_Emp "
                strSQL2 &= "                   WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {numero}"
            Else
                strSQL2 = " SELECT h.HDoc_Emp_Nom NombreC,h.HDoc_Emp_Dir DireccionC,h.HDoc_Emp_Cod CodigoC,emp.emp_nit NIT,emp.emp_direccion DireccionEmisor,emp.emp_razon NombreComercial,h.HDoc_Emp_Nom, h.HDoc_Emp_Dir, replace(h.HDoc_Emp_NIT,'-','') HDoc_Emp_NIT, YEAR(h.HDoc_Doc_Fec), LPAD(MONTH(h.HDoc_Doc_Fec),2,'0') mes, LPAD(DAY(h.HDoc_Doc_Fec),2,'0') dia, 'GUATEMALA', '' KI2, h.HDoc_Emp_Cod, h.HDoc_Doc_Num, d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_Cod, d.DDoc_Prd_QTY Cantidad, d.DDoc_Prd_NET PrecioUnitario, (d.DDoc_Prd_QTY * d.DDoc_Prd_NET) AS Precio, c.cat_clave Medida, m.cat_clave Moneda, ' ' art_DLarga,cli.cli_cliente Cliente, cli.cli_direccion DireccionCliente,cli.cli_codigo CodigoCliente,d.DDoc_Doc_Lin Linea,d.DDoc_prd_DSQ Descuento, h.HDoc_Doc_Mon CodigoMoneda, cp.cat_desc Pais, cp.cat_clave PaisReceptor,'' KI, 'Zona Franca' origen, v.cat_desc vendedor,cc.cat_ext Signo, IFNULL(cli.cli_plazoCR,0) dias,0 Tipo,'' poliza, (h.HDoc_Doc_Num) pF,  IFNULL((SELECT SUM(b.BDoc_Box_QTY)
                                FROM Dcmtos_DTL_Box b
                                WHERE b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin),0) bultos, 'CIF' CIF, CAST(ADDDATE(h.HDoc_Doc_Fec, INTERVAL IFNULL(cli.cli_plazoCR,0) DAY) AS CHAR) fvencimiento
                            , cli.cli_clasificacion clasTipoFactura, if(cli.cli_exterior='Local',0,1) cli_exterior, cli.cli_plazoCR diasCredito
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase ='Medidas'
                            LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon
                            LEFT JOIN Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon
                            LEFT JOIN Catalogos v ON v.cat_sist = 'DEF_COUNTRY'
                            LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod
                            LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais
                            LEFT JOIN Empresas emp ON emp.emp_no = h.HDoc_Sis_Emp
                                WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {numero}"
            End If

            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{año}", intAño)
            strSQL2 = Replace(strSQL2, "{numero}", intNumero)
            strSQL2 = Replace(strSQL2, "{OPCION}", strRespuesta)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL2, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    '    My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml", "file://192.168.2.189/Volume_2/Archivos_Fel/" & "\FactFel" & celdaNumero.Text & ".xml" & "", "fel", "fel2019", True, 9000, True)

                    If REA.GetInt32("CodigoMoneda") = 177 Then
                        strMoneda = "GTQ"
                    ElseIf REA.GetInt32("CodigoMoneda") = 178 Then
                        strMoneda = "USD"
                    End If
                    If File.Exists(System.Windows.Forms.Application.StartupPath & "\contenido.xml") Then

                        If logEncabezado = False Then
                            strPaisCliente = REA.GetInt32("clasTipoFactura")
                            strNumero = celdaNumero.Text
                            strNombreC = REA.GetString("NombreC")
                            strDireccionC = REA.GetString("Pais")
                            strCodigoC = REA.GetString("CodigoC")
                            strNitCliente = REA.GetString("HDoc_Emp_NIT")
                            strNombreCliente = REA.GetString("Cliente")
                            strDireccionCliente = REA.GetString("DireccionCliente")
                            strCodigoCliente = REA.GetString("CodigoCliente")
                            strNombreExportador = REA.GetString("NombreComercial")
                            strDiasCredito = REA.GetString("diasCredito")
                            strIcoterm = REA.GetString("CIF")
                            strPoliza = REA.GetString("poliza")
                            strKI = REA.GetString("KI2")
                            strPO = REA.GetString("pF")
                            'strNombreCliente = Replace(strNombreCliente, "&", "&#38;")
                            'strNombreC = Replace(strNombreC, "&", "&#38;")
                            strNombreCliente = Replace(cfun.convertirXML(strNombreCliente), "-", "&#45;").ToUpper
                            strNombreC = cfun.convertirXML(strNombreC).ToUpper
                            strNombreC = Replace(strNombreC, "-", "&#45;")
                            strpaisOrigen = "COUNTRY OF ORIGIN/ " & vbCrLf & "PAIS DE ORIGEN " & vbCrLf & REA.GetString("origen") & vbCrLf & "SELLING COUNTRY/ " & vbCrLf & "PAIS DE VENTA" & vbCrLf & REA.GetString("vendedor")
                            If celdaTipoFactura.Text >= 1 Then
                                strNota = STR_VACIO
                            Else
                                strNota = "Nota:" & vbCrLf & " La mercader&#237;a arriba detallada fue vendida al cr&#233;dito. Por lo tanto, esta factura debe ser pagada " & vbCrLf & REA.GetDateTime("fvencimiento") & " y generara cargos por mora 2% mensual"
                            End If

                            intBulto = REA.GetInt32("bultos")
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf

                            ' Enabezado de la factura 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= " <dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            'If strPaisCliente <> 0 Then
                            '    strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' Exp='SI'  FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'Else
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'End If
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@hilosyalgodon.com' NITEmisor='90028481' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionEmisor")).ToUpper & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf




                            ''strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com'  IDReceptor ='" & REA.GetString("NIT") & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf


                            'procedimiento posterior a 14/1/2023
                            'If strPaisCliente <> 0 Then
                            '    strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            'Else
                            'strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            'End If


                            If REA.GetInt32("cli_exterior") = 0 Then   '' 0 es local
                                If REA.GetString("NIT") = "CF" Then
                                    'factura consumidor final
                                    strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                ElseIf strNitCliente.Length = 13 Then
                                    'factura CUI Valido
                                    strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                Else
                                    'factura nit valido
                                    strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                                End If
                                'strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            Else
                                'factura exterior
                                strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@hilosyalgodon.com'>"
                            End If

                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionCliente")).ToUpper & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>  </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='2'/>" & vbCrLf
                            'If strPaisCliente <> 0 Then
                            '    strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='4'/>" & vbCrLf
                            'Else
                            strXML &= "<dte:Frase CodigoEscenario='12' TipoFrase ='4'/>" & vbCrLf
                            'End If
                            strXML &= "</dte:Frases>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            ' Linea Factura 
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & "</dte:UnidadMedida>" & vbCrLf
                            strXML &= " <dte:Descripcion>" & REA.GetString("Descripcion") & " " & REA.GetString("art_DLarga") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = (dblGranTotal + REA.GetDouble("Precio")).ToString("###0.00")
                            strXML &= "<dte:Descuento>" & REA.GetDouble("Descuento") & "</dte:Descuento>" & vbCrLf

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            If REA.GetString("Tipo") = 1 Then
                                strXMLDTL &= "<Valor1>" & "RCS " & REA.GetInt32("DDoc_Prd_Cod") & "</Valor1>" & vbCrLf
                            ElseIf REA.GetString("Tipo") = 2 Then
                                strXMLDTL &= "<Valor1>" & "OCS " & REA.GetInt32("DDoc_Prd_Cod") & "</Valor1>" & vbCrLf
                            Else
                                strXMLDTL &= "<Valor1>" & REA.GetInt32("DDoc_Prd_Cod") & "</Valor1>" & vbCrLf
                            End If
                            strXMLDTL &= "<Valor2>" & REA.GetInt32("bultos") & "</Valor2>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0.00</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf

                            strXML &= "<dte:Total>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf


                            logEncabezado = True
                        Else
                            ' Linea Factura 
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & " </dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & " " & REA.GetString("art_DLarga") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = (dblGranTotal + REA.GetDouble("Precio")).ToString("###0.00")
                            strXML &= "<dte:Descuento>" & REA.GetDouble("Descuento") & "</dte:Descuento>" & vbCrLf

                            'Adenda DTL
                            strXMLDTL &= "<AdendaItem LineaReferencia='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXMLDTL &= "<Valor1>" & REA.GetInt32("DDoc_Prd_Cod") & "</Valor1>" & vbCrLf
                            strXMLDTL &= "<Valor2>" & REA.GetInt32("bultos") & "</Valor2>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0.00</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf

                            strXML &= "<dte:Total>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf



                        End If
                    Else
                        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
                        fs.Close()
                        '  sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
                        If logEncabezado = False Then
                            strPaisCliente = REA.GetInt16("clasTipoFactura")
                            strNumero = celdaNumero.Text
                            strNombreC = REA.GetString("NombreC")
                            strDireccionC = REA.GetString("DireccionC")
                            strCodigoC = REA.GetString("CodigoC")
                            strNitCliente = REA.GetString("HDoc_Emp_NIT")
                            strNombreCliente = REA.GetString("Cliente")
                            strDireccionCliente = REA.GetString("DireccionCliente")
                            strDiasCredito = REA.GetString("diasCredito")
                            strCodigoCliente = REA.GetString("CodigoCliente")
                            strNombreExportador = REA.GetString("NombreComercial")
                            strIcoterm = REA.GetString("CIF")
                            strPoliza = REA.GetString("poliza")
                            strKI = REA.GetString("KI")
                            strPO = REA.GetString("pF")
                            'strNombreCliente = Replace(strNombreCliente, "&", "&#38;")
                            strNombreCliente = Replace(cfun.convertirXML(strNombreCliente), "-", "&#45;").ToUpper ' cfun.convertirXML(Replace(strNombreCliente, "-", "&#45;")).ToUpper
                            strNombreC = Replace(strNombreC, "&", "&#38;")
                            strNombreC = Replace(strNombreC, "-", "&#45;")
                            strpaisOrigen = "COUNTRY OF ORIGIN/ " & vbCrLf & "PAIS DE ORIGEN " & vbCrLf & REA.GetString("origen") & vbCrLf & "SELLING COUNTRY/ " & vbCrLf & "PAIS DE VENTA" & vbCrLf & REA.GetString("vendedor")
                            If celdaTipoFactura.Text >= 1 Then
                                strNota = STR_VACIO
                            Else
                                'strNota = "Nota:" & vbCrLf & " La mercadería arriba detallada fue vendida al crédito. Por lo tanto, esta factura debe ser pagada " & vbCrLf & REA.GetDateTime("fvencimiento") & " y generara cargos por mora 2% mensual"
                                strNota = "Nota:" & vbCrLf & " La mercader&#237;a arriba detallada fue vendida al cr&#233;dito. Por lo tanto, esta factura debe ser pagada " & vbCrLf & REA.GetDateTime("fvencimiento") & " y generara cargos por mora 2% mensual"
                            End If
                            intBulto = REA.GetInt32("bultos")
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf

                            ' Enabezado de la factura 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?><dte:GTDocumento xmlns:dte='http//www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= " <dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            'If strPaisCliente <> 0 Then
                            '    strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' Exp='SI'  FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'Else
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'End If

                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@hilosyalgodon.com' NITEmisor='90028481' NombreComercial='Hilos y Algodon Sociedad Anonima' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionEmisor") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Amatitlan</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            If strPaisCliente <> 0 Then
                                strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            Else
                                strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            End If
                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionCliente") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>  </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='2'/>" & vbCrLf
                            'If strPaisCliente <> 0 Then
                            '    strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='4'/>" & vbCrLf
                            'Else
                            strXML &= "<dte:Frase CodigoEscenario='12' TipoFrase ='4'/>" & vbCrLf
                            'End If
                            strXML &= "</dte:Frases>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            ' Linea Factura 
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & "</dte:UnidadMedida>" & vbCrLf
                            strXML &= " <dte:Descripcion>" & REA.GetString("Descripcion") & " " & REA.GetString("art_DLarga") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = (dblGranTotal + REA.GetDouble("Precio")).ToString("###0.00")
                            strXML &= "<dte:Descuento>" & REA.GetDouble("Descuento") & "</dte:Descuento>" & vbCrLf

                            'Adenda DTL'
                            strXMLDTL &= "<AdendaItem LineaReferencia='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXMLDTL &= "<Valor1>" & REA.GetInt32("DDoc_Prd_Cod") & "</Valor1>" & vbCrLf
                            strXMLDTL &= "<Valor2>" & REA.GetInt32("bultos") & "</Valor2>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto> 0.00 </dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf

                            strXML &= "<dte:Total>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf


                            logEncabezado = True
                        Else
                            '  ' Linea Factura 
                            strXML &= "<dte:Item BienOServicio='B' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXML &= "<dte:Cantidad>" & REA.GetDouble("Cantidad") & "</dte:Cantidad>" & vbCrLf
                            strXML &= "<dte:UnidadMedida>" & REA.GetString("Medida") & " </dte:UnidadMedida>" & vbCrLf
                            strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & " " & REA.GetString("art_DLarga") & "</dte:Descripcion> " & vbCrLf
                            strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("PrecioUnitario") & "</dte:PrecioUnitario>" & vbCrLf
                            strXML &= "<dte:Precio>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                            dblGranTotal = (dblGranTotal + REA.GetDouble("Precio")).ToString("###0.00")
                            strXML &= "<dte:Descuento>" & REA.GetDouble("Descuento") & "</dte:Descuento>" & vbCrLf

                            'Adenda DTL
                            strXMLDTL &= "<AdendaItem LineaReferencia='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                            strXMLDTL &= "<Valor1>" & REA.GetInt32("DDoc_Prd_Cod") & "</Valor1>" & vbCrLf
                            strXMLDTL &= "<Valor2>" & REA.GetInt32("bultos") & "</Valor2>" & vbCrLf
                            strXMLDTL &= "</AdendaItem>" & vbCrLf

                            strXML &= "<dte:Impuestos>" & vbCrLf
                            strXML &= "<dte:Impuesto>" & vbCrLf
                            strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                            strXML &= "<dte:CodigoUnidadGravable>2</dte:CodigoUnidadGravable>" & vbCrLf
                            strXML &= "<dte:MontoGravable>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                            strXML &= "<dte:MontoImpuesto>0.00</dte:MontoImpuesto>" & vbCrLf
                            strXML &= "</dte:Impuesto>" & vbCrLf
                            strXML &= "</dte:Impuestos>" & vbCrLf

                            strXML &= "<dte:Total>" & REA.GetDouble("Precio").ToString("###0.00") & "</dte:Total>" & vbCrLf
                            strXML &= "</dte:Item>" & vbCrLf
                        End If
                    End If
                Loop
            End If
            strXML &= "</dte:Items>" & vbCrLf
            'Totales 
            strXML &= "<dte:Totales>" & vbCrLf
            strXML &= "<dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:TotalImpuesto NombreCorto='IVA' TotalMontoImpuesto='0.00'/>" & vbCrLf
            strXML &= "</dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:GranTotal>" & dblGranTotal & "</dte:GranTotal>" & vbCrLf
            strXML &= "</dte:Totales>" & vbCrLf
            'If strPaisCliente <> 0 Then
            '    strXML &= "<dte:Complementos>" & vbCrLf
            '    strXML &= "<dte:Complemento IDComplemento='EXP' NombreComplemento='EXP' URIComplemento='http://www.sat.gob.gt/face2/ComplementoExportaciones/0.1.0'>" & vbCrLf
            '    strXML &= "<cex:Exportacion Version='1' xmlns:cex='http://www.sat.gob.gt/face2/ComplementoExportaciones/0.1.0'>" & vbCrLf
            '    strXML &= "<cex:NombreConsignatarioODestinatario>" & strNombreC & " </cex:NombreConsignatarioODestinatario>" & vbCrLf
            '    strXML &= "<cex:DireccionConsignatarioODestinatario>" & strDireccionC & "</cex:DireccionConsignatarioODestinatario>" & vbCrLf
            '    strXML &= "<cex:CodigoConsignatarioODestinatario>" & strCodigoC & "</cex:CodigoConsignatarioODestinatario>" & vbCrLf
            '    strXML &= "<cex:NombreComprador>" & strNombreCliente & "</cex:NombreComprador> " & vbCrLf
            '    strXML &= "<cex:DireccionComprador>" & strDireccionCliente & "</cex:DireccionComprador> " & vbCrLf
            '    strXML &= "<cex:CodigoComprador>" & strCodigoCliente & " </cex:CodigoComprador> " & vbCrLf
            '    strXML &= "<cex:INCOTERM>" & strIcoterm & "</cex:INCOTERM> " & vbCrLf
            '    strXML &= "<cex:NombreExportador>" & strNombreExportador & " </cex:NombreExportador> " & vbCrLf
            '    strXML &= "<cex:CodigoExportador>H25746</cex:CodigoExportador> " & vbCrLf
            '    strXML &= "</cex:Exportacion> " & vbCrLf
            '    strXML &= "</dte:Complemento>" & vbCrLf
            '    strXML &= "</dte:Complementos> " & vbCrLf
            'End If
            strXML &= "</dte:DatosEmision> " & vbCrLf
            strXML &= "</dte:DTE> " & vbCrLf
            strXML &= "<dte:Adenda>" & vbCrLf
            strXML &= "<dte:AdendaDetail id='AdendaSummary'> " & vbCrLf
            strXML &= "<dte:AdendaSummary>" & vbCrLf
            strXML &= "<dte:Valor1>" & strPoliza & "</dte:Valor1>" & vbCrLf
            strXML &= "<dte:Valor2>" & strKI & "</dte:Valor2>" & vbCrLf
            strXML &= "<dte:Valor3>" & strPO & "</dte:Valor3>" & vbCrLf
            strXML &= "<dte:Valor4>" & strpaisOrigen & "</dte:Valor4>" & vbCrLf
            strXML &= "<dte:Valor5>" & strNota & "</dte:Valor5>" & vbCrLf
            strXML &= "<dte:Valor6>" & strCodigoCliente & "</dte:Valor6>" & vbCrLf
            strXML &= "<dte:Valor7>" & strIcoterm & "</dte:Valor7>" & vbCrLf
            If strPaisCliente <> 0 Then
                strXML &= "<dte:Valor8>CUI: " & strNitCliente & "</dte:Valor8>" & vbCrLf
            Else
                strXML &= "<dte:Valor8></dte:Valor8>" & vbCrLf
            End If
            strXML &= "<dte:Valor9>" & strNumero & "</dte:Valor9>" & vbCrLf
            strXML &= "<dte:Valor10>" & strDiasCredito & "</dte:Valor10>" & vbCrLf
            strXML &= "</dte:AdendaSummary>" & vbCrLf
            strXML &= "<AdendaItems>" & vbCrLf
            strXML &= strXMLDTL
            strXML &= "</AdendaItems>" & vbCrLf
            strXML &= "</dte:AdendaDetail>" & vbCrLf
            '' '' '' ''PRUEBAS 13069
            ''''strXML &= "<TemplateInfo detailTemplateId='13069' templateId='13069' />" & vbCrLf
            'strXML &= "<TemplateInfo detailTemplateId='12316' templateId='12316' />" & vbCrLf
            strXML &= "<TemplateInfo detailTemplateId='15242' templateId='15242' />" & vbCrLf
            strXML &= "</dte:Adenda>" & vbCrLf
            strXML &= "</dte:SAT> " & vbCrLf
            strXML &= "</dte:GTDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXML &= "]]>" & vbCrLf
            strXML &= "</xml_dte>" & vbCrLf
            strXML &= "</FirmaDocumentoRequest>" & vbCrLf
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
            sw.Write(strXML)
            sw.Close()



            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                strError &= " Fallo en la Firma Electronica "
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Close()


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' Asigna el Token Devuelto por Web Service 
                ' strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerXml & " ]]></xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte>" & nodo.ChildNodes.Item(0).InnerXml & "</xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
            Next
            ' strXMLRegistra = cfun.convertirXML(strXMLRegistra)
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")

            sw.Write(strXMLRegistra)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml")
            'Registra la factura ya firmado
            strXMLFinal = t.RegistrarDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el registra documento de Fel ")
                strError &= "Fallo en el registra documento de Fel"
                EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()




            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' '' '' ''PRUEBAS
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml", "file://C:\Archivos_Fel\FactFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\factfel" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RegistraDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strXMLFel = nodo.ChildNodes.Item(0).InnerText
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml")
            sw.Write(strXMLFel)
            sw.Close()


            ' Metodo para subir el archivo en una compartida
            ' My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\Fel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' '' '' ''PRUEBAS
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml", "file://C:\Archivos_Fel\Fel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\Fel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\Fel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.GetElementsByTagName("dte:Certificacion")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strNitCertificador = nodo.ChildNodes.Item(0).InnerText  ' Nit MegaPrint
                '  strFechaHoraCertificacion = nodo.ChildNodes.Item(1).InnerText ' Nombre MegaPrint
                strSerieDocumento = nodo.ChildNodes.Item(2).InnerText ' Serie 
                strFechaHoraCertificacion = nodo.ChildNodes.Item(3).InnerText ' FechaCertificacion 
            Next
            ' Nombre del archivo a utilizar
            Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".xml"
            ' Si el archivo existe
            Dim vloFile As New StreamReader(vlcFileName)
            ' Ciclo de iteración entre líneas
            While True
                ' Cargar la línea
                Dim vlcLinea = vloFile.ReadLine()
                ' Si la línea es nula, sale del ciclo
                If vlcLinea Is Nothing Then Exit While
                ' Si la línea contiene el criterio
                If vlcLinea.Contains(vlcCriterio) Then
                    ' Obtener la línea como resultado,
                    ' Concatenando un retorno de carro si ya hay ocurrencias
                    vlcResultado += IIf(vlcResultado <> "", vbCrLf, "") & vlcLinea
                    ' Salir del ciclo
                    Exit While
                    ' Lo omites si quieres todas las ocurrencias
                End If
            End While
            'Realiza busqueda de la cadena para obtener el numero de Autorizacion
            strCadenaEncontrada = vlcResultado.Substring(vlcResultado.LastIndexOf("Numero=") + 1)
            'En un array parte la cadena despues que encuentre un igual 
            arrayCadena = strCadenaEncontrada.Split("=".ToCharArray)
            'carga el numero de autorizacion de cada documento
            strNumeroAutorizacion = arrayCadena(INT_UNO)
            'sustituye serie por cadena vacio para limpiar la cadena y solo obtenga el numero
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, "Serie", STR_VACIO)
            'sustituye "" por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, """", STR_VACIO)
            'sustituye espacios por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, " ", STR_VACIO)

            ActualizarFel(Horario & "-06:00", strFechaHoraCertificacion, strSerieDocumento, strNumeroAutorizacion, strIcoterm, strUUID)

            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & strSerieDocumento & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDF" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDF" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinal" & celdaNumero.Text & ".xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinal" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinal" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\Fel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' '' '' ''PRUEBAS
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".pdf", "file://C:\Archivos_Fel\Fel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\Fel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\Fel" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try

            botonImprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\Fel" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Sub ImprimirPDFGenerado(ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String)
        Dim Proceso As New Process
        Dim openSave As New SaveFileDialog
        Dim OpenFile As New OpenFileDialog
        Dim strGuardar As String = STR_VACIO
        Dim strArchivo As String = STR_VACIO
        Try
            strGuardar = ".pdf"
            openSave.InitialDirectory = "c:\"
            openSave.Filter = "All Files|*.*"
            openSave.RestoreDirectory = True
            openSave.AddExtension = False
            openSave.FileName = "Fel" & celdaNumero.Text & strGuardar & strGuardar
            If openSave.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                strArchivo = openSave.FileName
                If checkActivar.Checked = True Then
                    If File.Exists("//" & IP & strRuta & "Fel" & celdaNumero.Text & ".pdf" & "") = True Then
                        My.Computer.Network.DownloadFile("file://" & IP & strRuta & "Fel" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                        '' '' '' ''PRUEBAS
                        'My.Computer.Network.DownloadFile("file://C:\Archivos_Fel\Fel" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                    Else
                        MsgBox("This file is not available, please contact with IT", MsgBoxStyle.Critical, "Notice")
                        Exit Sub
                    End If

                Else
                    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "\FelAnulacion" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                    '' '' '' ''PRUEBAS
                    'My.Computer.Network.DownloadFile("file://C:\Archivos_Fel\FelAnulacion" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                End If
            End If

            ''para pruebas locales

            'Proceso.StartInfo.FileName = "C:\Archivos_Fel\Fel" & celdaNumero.Text & ".pdf"
            'Proceso.StartInfo.Arguments = ""
            'Proceso.Start()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActivarGuardar()
        Encabezado1.botonGuardar.Enabled = True
    End Sub
    Public Sub ActualizarDistribucion()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " UPDATE Dcmtos_DTL d SET d.DDoc_RF2_Cod = '{dist}' WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea}     "
        If Sesion.IdEmpresa = 18 Then
            strSQL = "; UPDATE PDM.Dcmtos_DTL d SET d.DDoc_RF2_Cod = '{dist}' WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea}     "
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{linea}", dgDetalle.CurrentRow.Cells("colLinea2").Value)
        strSQL = Replace(strSQL, "{destino}", dgDetalle.CurrentRow.Cells("colCodLugar").Value)
        strSQL = Replace(strSQL, "{dist}", dgDetalle.CurrentRow.Cells("colDistribucion").Value)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        COM.Dispose()
        System.GC.Collect()
    End Sub
    Public Sub ActualizarDestino()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " UPDATE Dcmtos_DTL d SET d.DDoc_RF1_Num = {destino}, d.DDoc_RF2_Cod = '{dist}' WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea} "
        strSQL &= "; UPDATE Dcmtos_ACC SET ADoc_Dta_Txt = ({destinoNombre}) WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {cat} AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = 'Doc_CCPorte2' AND ADoc_Doc_Lin = '04' AND ADoc_Dta_Des = 'Lugar De Descarga'"
        If Sesion.IdEmpresa = 18 Then
            strSQL &= "; UPDATE PDM.Dcmtos_DTL d SET d.DDoc_RF1_Num = {destino},  d.DDoc_RF2_Cod = '{dist}' WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {cat} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero} AND d.DDoc_Doc_Lin = {linea} "
            strSQL &= "; UPDATE PDM.Dcmtos_ACC SET ADoc_Dta_Txt = ({destinoNombre}) WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = {cat} AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = 'Doc_CCPorte2' AND ADoc_Doc_Lin = '04' AND ADoc_Dta_Des = 'Lugar De Descarga'"
        End If
        strSQL = Replace(strSQL, "{destinoNombre}", "select concat(c.cli_cliente, ' ', c.cli_direccion) from Clientes c where c.cli_sisemp = {empresa} and c.cli_codigo = {destino}")
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", "36")
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{linea}", dgDetalle.CurrentRow.Cells("colLinea2").Value)
        strSQL = Replace(strSQL, "{destino}", dgDetalle.CurrentRow.Cells("colCodLugar").Value)

        strSQL = Replace(strSQL, "{dist}", dgDetalle.CurrentRow.Cells("colDistribucion").Value)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()
        COM.Dispose()
        System.GC.Collect()

    End Sub
    Private Function NuevaFactura() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} " ' AND HDR.HDoc_DR2_Num  = '{serie}'  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 36)
        'strSQL = Replace(strSQL, "{serie}", celdaSerie.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        Const MAX_LINEAS As Byte = 75
        Dim COM As MySqlCommand
        Dim COM2 As New MySqlCommand
        Dim conec As MySqlConnection
        Dim intNumero As Integer
        Dim intAño As Integer
        Dim anulada As Boolean
        Dim Inv As New clsReportes
        Dim strSQL As String
        Dim intForma As Integer
        Dim logErr As Boolean
        Dim i As Integer
        Dim ContadorLine As Integer
        Dim strSQL2 As String = STR_VACIO
        Dim strSQL3 As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO
        Dim j As Integer = 0
        Dim strToken As String = STR_VACIO
        Dim strUUID As String = STR_VACIO
        Dim clsConta As New clsContabilidad
        Dim dtFechaConta As DateTime
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String


        If Not logLibre Then
            MsgBox("This document is locked print" & vbCr & vbCr & "Present the certificate  of origin  to the appropriate to proceed to release", vbExclamation, "Notice")
            Exit Sub
        End If

        logPrinting = True

        strSQL = "SELECT cat_sist"
        strSQL &= " FROM Catalogos "
        strSQL &= "      WHERE cat_clase='Factura' AND cat_clave='Formato' AND cat_sisemp= {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            intForma = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using

        Select Case intForma

            Case 0
            Case 1
            Case 2
                For i = vbEmpty To dgDetalle.RowCount - 1
                    If dgDetalle.Rows(i).Visible = True Then
                        ContadorLine = ContadorLine + 1
                    End If
                Next

                If ContadorLine > MAX_LINEAS Then

                    If MsgBox("NOTA: Some Lines Can Not Print." & vbCr & vbCr & "*** There are more lines in detail in the format ***", vbInformation, "Print format") Then
                        logErr = True
                        Exit Sub
                    End If
                End If

                If Not logErr Then
                    intAño = Val(celdaAño.Text)
                    intNumero = Val(celdaNumero.Text)


                    If checkActivar.Checked = False Then
                        anulada = True
                    Else
                        anulada = False
                    End If

                    'Inv.ReporteInvoicing(intAño, intNumero, anulada)

                    'REPORTE EN CRYSTAL REPORT

                    Dim opt As New frmOption
                    Dim strRespuesta As String = STR_VACIO
                    Dim IP As String = STR_VACIO
                    Dim strUsuario As String = STR_VACIO
                    Dim strContrasena As String = STR_VACIO
                    Dim strRuta As String = STR_VACIO
                    If celdaImpreso.Text = INT_CERO Then
                        opt.Titulo = "INCOTERM"
                        opt.Mensaje = "Select an option"
                        opt.Opciones = "Print FOB" & "|" & "Print CIF"

                        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                            Select Case opt.Seleccion

                                Case 0
                                    strRespuesta = "FOB"
                                Case 1
                                    strRespuesta = "CIF"

                            End Select
                        Else
                            Exit Sub
                        End If
                    End If
                    strSQL2 = " select   h.HDoc_Emp_Nom , h.HDoc_Emp_Dir , h.HDoc_Emp_NIT , year(h.HDoc_Doc_Fec ), lpad(MONTH(h.HDoc_Doc_Fec),2,'0') mes, lpad(DAY(h.HDoc_Doc_Fec),2,'0') dia , 'GUATEMALA', h.HDoc_DR1_Num , h.HDoc_Emp_Cod , h.HDoc_Doc_Num , concat(d.DDoc_Prd_Des, '-','(',d.DDoc_RF1_Txt ,')') , d.DDoc_Prd_Cod , d.DDoc_Prd_QTY , d.DDoc_Prd_NET , round((d.DDoc_Prd_QTY * d.DDoc_Prd_NET)+0.001,2) '(d.DDoc_Prd_QTY * d.DDoc_Prd_NET)', c.cat_clave , m.cat_clave , a.art_DLarga , (select group_concat( distinct cc.cat_desc separator ',') pai from Dcmtos_DTL dd left join Inventarios ii on ii.inv_sisemp = dd.DDoc_Sis_Emp and ii.inv_numero = dd.DDoc_Prd_Cod  left join Catalogos cc on cc.cat_num = ii.inv_lugarfab  where dd.DDoc_Sis_Emp = d.DDoc_Sis_Emp  and dd.DDoc_Doc_Cat = d.DDoc_Doc_Cat  and dd.DDoc_Doc_Ano = d.DDoc_Doc_Ano  and dd.DDoc_Doc_Num = d.DDoc_Doc_Num  ) origen, v.cat_desc vendedor,cc.cat_ext Signo,IFNULL(cli.cli_plazoCR,0) dias, (  "
                    strSQL2 &= " select GROUP_CONCAT(DISTINCT e.ADoc_Dta_Chr  SEPARATOR ',') from Dcmtos_DTL_Pro p  "
                    strSQL2 &= " left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin and i.PDoc_Par_Cat = 47 "
                    strSQL2 &= " left join Dcmtos_DTL_Pro pp on pp.PDoc_Sis_Emp = i.PDoc_Sis_Emp and pp.PDoc_Chi_Cat = i.PDoc_Par_Cat and pp.PDoc_Chi_Ano = i.PDoc_Par_Ano and pp.PDoc_Chi_Num = i.PDoc_Par_Num and pp.PDoc_Chi_Lin = i.PDoc_Par_Lin  "
                    strSQL2 &= "left join Dcmtos_ACC e on e.ADoc_Sis_Emp =  pp.PDoc_Sis_Emp and e.ADoc_Doc_Cat = pp.PDoc_Par_Cat and e.ADoc_Doc_Ano = pp.PDoc_Par_Ano and e.ADoc_Doc_Num = pp.PDoc_Par_Num and e.ADoc_Doc_Sub = 'Doc_PolImp' AND e.ADoc_Doc_Lin = '01'  "
                    strSQL2 &= " where p.PDoc_Sis_Emp = h.HDoc_Sis_Emp  and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat  and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Par_Cat = 48  ) poliza, "
                    strSQL2 &= " ( select GROUP_CONCAT(DISTINCT (concat(pp.HDoc_Doc_Num ,':',pp.HDoc_DR1_Num )) SEPARATOR ',') from Dcmtos_DTL_Pro p "
                    strSQL2 &= " left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin and i.PDoc_Par_Cat = 75 "
                    strSQL2 &= " left join Dcmtos_HDR pp on pp.HDoc_Sis_Emp = i.PDoc_Sis_Emp and pp.HDoc_Doc_Cat = i.PDoc_Par_Cat and pp.HDoc_Doc_Ano = i.PDoc_Par_Ano and pp.HDoc_Doc_Num = i.PDoc_Par_Num  "
                    strSQL2 &= " where p.PDoc_Sis_Emp = h.HDoc_Sis_Emp  and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat  and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Par_Cat = 48 ) pF, "
                    strSQL2 &= " (select sum(b.BDoc_Box_QTY ) from Dcmtos_DTL_Box b "
                    strSQL2 &= "  where b.BDoc_Sis_Emp = d.DDoc_Sis_Emp  and b.BDoc_Doc_Cat = d.DDoc_Doc_Cat  and b.BDoc_Doc_Ano = d.DDoc_Doc_Ano  and b.BDoc_Doc_Num = d.DDoc_Doc_Num  and b.BDoc_Doc_Lin = d.DDoc_Doc_Lin ) bultos,  '{OPCION}' CIF, cast(ADDDATE(h.HDoc_Doc_Fec, INTERVAL IFNULL(cli.cli_plazoCR,0) DAY) as char) fvencimiento"
                    strSQL2 &= " from Dcmtos_HDR h"
                    strSQL2 &= "  left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num  "
                    strSQL2 &= " left join Catalogos c on c.cat_num = d.DDoc_Prd_UM  and c.cat_clase ='Medidas' "
                    strSQL2 &= " left join Catalogos m on m.cat_num = h.HDoc_Doc_Mon  "
                    strSQL2 &= " Left Join Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon "
                    strSQL2 &= " left join Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod "
                    strSQL2 &= "  left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo "
                    strSQL2 &= " LEFT JOIN Catalogos v ON v.cat_sist = 'DEF_COUNTRY' "
                    strSQL2 &= "  LEFT JOIN Catalogos o ON o.cat_num = i.inv_lugarfab "
                    strSQL2 &= " LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod "
                    strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {numero}"
                    strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                    strSQL2 = Replace(strSQL2, "{año}", intAño)
                    strSQL2 = Replace(strSQL2, "{numero}", intNumero)
                    strSQL2 = Replace(strSQL2, "{OPCION}", strRespuesta)

                    'Procedimiento Fel
                    If celdaImpreso.Text = INT_CERO Then
                        If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                            If MsgBox("Esta a punto de transmitir esta factura a SAT " & vbNewLine & "Esta seguro que desea continuar? El proceso sera irreversible ", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                If VerificarDocumentoXML(strToken, strUUID) = INT_CERO Then
                                    If ImpresionFel(intAño, intNumero, strRespuesta, strToken, strUUID, IP, strUsuario, strContrasena, strRuta) = True Then
                                        impreso = celdaImpreso.Text
                                        If impreso = 0 Then
                                            imprimir = 1

                                            strSQL4 = "UPDATE Dcmtos_HDR h"
                                            strSQL4 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                                            strSQL4 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                                            If Sesion.IdEmpresa = 18 Then
                                                strSQL4 &= ";UPDATE PDM.Dcmtos_HDR h"
                                                strSQL4 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                                                strSQL4 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                                            End If
                                            strSQL4 = Replace(strSQL4, "{impresion}", imprimir)
                                            strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
                                            strSQL4 = Replace(strSQL4, "{anio}", celdaAño.Text)
                                            strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

                                            'Ejecuta la instrucción
                                            MyCnn.CONECTAR = strConexion
                                            COM2 = New MySqlCommand(strSQL4, CON)
                                            COM2.ExecuteNonQuery()

                                            strSQL4 = STR_VACIO
                                            strSQL4 = "UPDATE Dcmtos_HDR h"
                                            strSQL4 &= " SET h.HDoc_Doc_Fec = CURDATE(),h.HDoc_Doc_TC=(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= CURDATE() ORDER BY t.Fecha DESC LIMIT 1)"
                                            strSQL4 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                                            If Sesion.IdEmpresa = 18 Then
                                                strSQL4 &= ";UPDATE PDM.Dcmtos_HDR h"
                                                strSQL4 &= " SET h.HDoc_Doc_Fec = CURDATE(),h.HDoc_Doc_TC=(SELECT t.Tasa FROM TCambio t WHERE t.Fecha <= CURDATE() ORDER BY t.Fecha DESC LIMIT 1)"
                                                strSQL4 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

                                            End If
                                            strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
                                            strSQL4 = Replace(strSQL4, "{anio}", celdaAño.Text)
                                            strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

                                            'Ejecuta la instrucción
                                            MyCnn.CONECTAR = strConexion
                                            COM2 = New MySqlCommand(strSQL4, CON)
                                            COM2.ExecuteNonQuery()
                                            dtFechaConta = cfun.SQLValidarFechaContable(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                                            clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta)

                                            ' Verifica el tipo de Factura
                                            Dim tipoFact As Integer = NO_FILA

                                            strSQL = " SELECT h.HDoc_RF3_Dbl 
                                                            FROM Dcmtos_HDR h
                                                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano ={anio} AND h.HDoc_Doc_Num = {num} "
                                            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                                            strSQL = Replace(strSQL, "{cat}", 36)
                                            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                                            strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
                                            MyCnn.CONECTAR = strConexion
                                            COM = New MySqlCommand(strSQL, CON)
                                            tipoFact = COM.ExecuteScalar

                                            If tipoFact = 1 Then
                                            Else
                                                If sqlVerificaYMR() = 1 Then
                                                    GenerarYarnMovement()
                                                End If
                                            End If

                                            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                                            OcultarCampos()
                                            Exit Sub
                                        End If
                                    Else
                                        Exit Sub
                                    End If
                                Else
                                    MsgBox("El documento ya ha sido transmitido")
                                    Exit Sub
                                End If
                            Else
                                Exit Sub
                            End If
                        Else
                            Exit Sub
                        End If

                    Else
                        ArrayServer = strConexion.Split(";".ToCharArray)
                        strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                        ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                        strCadena = ArrayServer(INT_CERO)
                        ArrayValidacion = strCadena.Split(".".ToCharArray)
                        strCadena = ArrayValidacion(INT_CERO)
                        arrayIP = strCadena.Split("=".ToCharArray)
                        If arrayIP(INT_UNO) = "192" Then
                            If VerificarAccesoLocal(IP, strUsuario, strContrasena, strRuta) = True Then
                                ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                            Else
                                Exit Sub
                            End If
                        Else
                            If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                                ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                            Else
                                Exit Sub
                            End If
                        End If

                    End If

                    '   If BuscarRegistrosDcmtos_HDR_Polizas(strSQL2) = True Then

                    '                End If
                    '                   Dim rep4 As New Facturacion

                    ''rep4.Load("C:\XML\DcmtosHDR.xml")
                    ''Dim frm3 As New frmReporteFacturacion
                    ''frm3.Reporte_A_Ver = rep4
                    ''frm3.ShowDialog(Me)

                    ''frmReporteFacturacion.ShowDialog()
                    ''My.Computer.FileSystem.DeleteFile("C:\XML\factura.xml")
                    ''My.Computer.FileSystem.DeleteFile("C:\XML\Signo.xml")
                    ''My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDR.xml")
                End If


            Case 3
                ' Verifica el tipo de Factura
                Dim tipoFact As Integer = NO_FILA

                strSQL = " SELECT h.HDoc_RF3_Dbl 
                                                            FROM Dcmtos_HDR h
                                                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano ={anio} AND h.HDoc_Doc_Num = {num} "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cat}", 36)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                tipoFact = COM.ExecuteScalar

                If tipoFact = 1 Then
                Else
                    If celdaImpreso.Text = 0 Then
                        GenerarYarnMovement()
                        MsgBox("YarnMovement Generado", vbInformation, "Info")
                    End If
                End If

            Case 4
                Dim frm5 As New clsReportes
                Dim opt As New frmOption
                Dim strRespuesta As String = STR_VACIO
                Dim frm4 As New frmReporteFactSV
                opt.Titulo = "INCOTERM"
                opt.Mensaje = "Select an option"

                opt.Opciones = "Print FOB" & "|" & "Print CIF" & "|" & "Print FCA" & "|" & "Print EXWORKS" & "|" & "Print CFR" & "|" & "Print CIP"

                If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case 0
                            strRespuesta = "FOB"
                        Case 1
                            strRespuesta = "CIF"
                        Case 2
                            strRespuesta = "FCA"
                        Case 3
                            strRespuesta = "EXWORKS"
                        Case 4
                            strRespuesta = "CFR"
                        Case 5
                            strRespuesta = "CIP"

                    End Select

                Else
                    Exit Sub
                End If

                intAño = Val(celdaAño.Text)
                intNumero = Val(celdaNumero.Text)
                ImpresionFacturaHN(strRespuesta, celdaTipoFactura.Text)
                '   Inv.ReporteInvoicing_PrideYarn(intAño, intNumero)
                ' cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())

            Case 5
                Dim opt As New frmOption
                Dim strRespuesta As String = STR_VACIO
                Dim frm4 As New frmReporteFactSV
                opt.Titulo = "INCOTERM"
                opt.Mensaje = "Select an option"
                opt.Opciones = "Print FOB" & "|" & "Print CIF" & "|" & "Print DAP" & "|" & "Print FCA"

                If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case 0
                            strRespuesta = "FOB"
                        Case 1
                            strRespuesta = "CIF"
                        Case 2
                            strRespuesta = "DAP"
                        Case 3
                            strRespuesta = "FCA"

                    End Select

                Else
                    Exit Sub
                End If

                opt = New frmOption
                opt.Titulo = "FORMAT"
                opt.Mensaje = "Select an option"
                opt.Opciones = "Yarn Invoice" & "|" & "Fiber Invoice"
                If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                    Select Case opt.Seleccion

                        Case 0
                            FacturaSV(strRespuesta)
                        Case 1
                            FacturaSVFibra(strRespuesta)
                    End Select
                Else
                    Exit Sub
                End If



            Case 6
                intAño = Val(celdaAño.Text)
                intNumero = Val(celdaNumero.Text)
                Inv.ReporteInvoicing_Dominican(intAño, intNumero, celdaTipoFactura.Text)
            Case 15
                Dim frmO As New frmOption
                frmO.Opciones = "Invoice|Packing List"
                frmO.Titulo = " Print "
                frmO.Mensaje = " What do you want to print?"
                frmO.ShowDialog(Me)
                If frmO.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    If frmO.Seleccion = INT_CERO Then
                        Dim opt As New frmOption
                        Dim strRespuesta As String = STR_VACIO
                        Dim frm4 As New frmReporteFactSV
                        opt.Titulo = "INCOTERM"
                        opt.Mensaje = "Select an option"
                        opt.Opciones = "Print FOB" & "|" & "Print CIF" & "|" & "Print FCA" & "|" & "Print LOCAL" & "|" & "Print EX WORKS" & "|" & "Print CIP"

                        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                            Select Case opt.Seleccion

                                Case 0
                                    strRespuesta = "FOB"
                                Case 1
                                    strRespuesta = "CIF"
                                Case 2
                                    strRespuesta = "FCA"
                                Case 3
                                    strRespuesta = "LOCAL"
                                Case 4
                                    strRespuesta = "EX WORKS"
                                Case 5
                                    strRespuesta = "CIP"

                            End Select

                        Else
                            Exit Sub
                        End If
                        ImpresionFacturaHSM(strRespuesta, celdaTipoFactura.Text)
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        Exit Sub

                    End If
                    If frmO.Seleccion = INT_UNO Then
                        Inv.ListaEmpaqueDetalle(CInt(celdaAño.Text), CInt(celdaNumero.Text))
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        Exit Sub
                    End If
                Else
                    Exit Sub
                End If
            Case 20
                Dim frmO As New frmOption
                frmO.Opciones = "Invoice|Packing List"
                frmO.Titulo = " Print "
                frmO.Mensaje = " What do you want to print?"
                frmO.ShowDialog(Me)
                If frmO.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    If frmO.Seleccion = INT_CERO Then
                        Dim opt As New frmOption
                        Dim strRespuesta As String = STR_VACIO
                        Dim frm4 As New frmReporteFactSV
                        opt.Titulo = "INCOTERM"
                        opt.Mensaje = "Select an option"
                        opt.Opciones = "Print FOB" & "|" & "Print CIF" & "|" & "Print FCA" & "|" & "Print LOCAL" & "|" & "Print EX WORKS" & "|" & "Print CIP"

                        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                            Select Case opt.Seleccion

                                Case 0
                                    strRespuesta = "FOB"
                                Case 1
                                    strRespuesta = "CIF"
                                Case 2
                                    strRespuesta = "FCA"
                                Case 3
                                    strRespuesta = "LOCAL"
                                Case 4
                                    strRespuesta = "EX WORKS"
                                Case 5
                                    strRespuesta = "CIP"

                            End Select

                        Else
                            Exit Sub
                        End If
                        ImpresionFacturaNS(strRespuesta, celdaTipoFactura.Text)
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        Exit Sub

                    End If
                    If frmO.Seleccion = INT_UNO Then
                        Inv.ListaEmpaqueDetalle(CInt(celdaAño.Text), CInt(celdaNumero.Text))
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        Exit Sub
                    End If
                Else
                    Exit Sub
                End If
            Case 18

                ImpresionNSM()
                Exit Sub
            Case 21
                'Dim frm5 As New clsReportes
                'intAño = Val(celdaAño.Text)
                'intNumero = Val(celdaNumero.Text)
                'ImpresionFacturaHN()
                ''   Inv.ReporteInvoicing_PrideYarn(intAño, intNumero)

                ImpresionFacturaLCP()
                Exit Sub

        End Select
        impreso = celdaImpreso.Text
        If impreso = 0 Then
            If MsgBox("The Document is printed correctly", MsgBoxStyle.YesNo, "Question") = vbYes Then
                'imprimir = 1

                'strSQL4 = "UPDATE Dcmtos_HDR h"
                'strSQL4 &= "     SET h.HDoc_DR2_Cat = {impresion}"
                'strSQL4 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

                'strSQL4 = Replace(strSQL4, "{impresion}", imprimir)
                'strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
                'strSQL4 = Replace(strSQL4, "{anio}", celdaAño.Text)
                'strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

                ''Ejecuta la instrucción
                'MyCnn.CONECTAR = strConexion
                'COM2 = New MySqlCommand(strSQL4, CON)
                'COM2.ExecuteNonQuery()
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acGeneraYRM, celdaIdCliente.Text, celdaTipo.Text, celdaAño.Text, celdaNumero.Text)
                dtFechaConta = cfun.SQLValidarFechaContable(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)

                ' Verifica el tipo de Factura
                Dim tipoFact As Integer = NO_FILA

                strSQL = " SELECT h.HDoc_RF3_Dbl 
                                                            FROM Dcmtos_HDR h
                                                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano ={anio} AND h.HDoc_Doc_Num = {num} "
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{cat}", 36)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                tipoFact = COM.ExecuteScalar

                If tipoFact = 1 Then
                Else
                    If sqlVerificaYMR() = 1 Then
                        GenerarYarnMovement()
                    End If
                End If

                MarcarImpresion()
                clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text, dtFechaConta.ToString(FORMATO_MYSQL))

            End If
        End If
        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
    End Sub


    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(36, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 36)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLCargarBultos(ByVal AnioHSM As Integer, numHSM As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT p.BPDoc_Par_Num Numero, p.BPDoc_Par_Lin Linea, d.BDoc_Box_Lin Bulto, d.BDoc_Box_Cod Marca, d.BDoc_Box_Ctg Categoria, d.BDoc_Box_LB peso, p.BPDoc_Par_Cat catalogo, p.BPDoc_Par_Ano anio,p.BPDoc_Chi_Lin ChiLin "
        strSQL &= "    From Dcmtos_DTL_Box d "
        strSQL &= "        Left JOIN Dcmtos_DTL_Box_Pro p ON p.BPDoc_Sis_Emp = d.BDoc_Sis_Emp AND p.BPDoc_Chi_Cat = d.BDoc_Doc_Cat  AND p.BPDoc_Chi_Ano = d.BDoc_Doc_Ano AND p.BPDoc_Chi_Num = d.BDoc_Doc_Num AND p.BPDoc_Chi_Lin = d.BDoc_Doc_Lin AND p.BPDoc_Box_Lin = d.BDoc_Box_lin "
        strSQL &= "            WHERE d.BDoc_Sis_Emp = {empresa} AND d.BDoc_Doc_Cat = 48 AND d.BDoc_Doc_Ano = {anio} AND d.BDoc_Doc_Num = {numero} "
        strSQL &= "               ORDER BY d.BDoc_Doc_Num, d.BDoc_Doc_Lin, d.BDoc_Box_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", AnioHSM)
        strSQL = Replace(strSQL, "{numero}", numHSM)

        Return strSQL

    End Function
    Private Sub CargarBultos(ByVal AnioHSM As Integer, numHSM As Integer)
        Dim strsql As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim intSumBultos As Integer = 0
        Dim Linea As Integer = 0


        Try
            strsql = SQLCargarBultos(AnioHSM, numHSM)

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strsql, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                Do While REA.Read

                    If Linea = REA.GetInt32("ChiLin") Then
                        intSumBultos = intSumBultos + 1
                    Else
                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                            If dgDetalle.Rows(i).Cells("colLinea").Value = Linea Then
                                dgDetalle.Rows(i).Cells("colBulto").Value = intSumBultos
                            End If
                        Next
                        intSumBultos = 1
                    End If
                    'For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    '    If dgDetalle.Rows(i).Cells("colLinea").Value = REA.GetInt32("ChiLin") Then
                    '        intSumBultos = intSumBultos + 1
                    '        dgDetalle.Rows(i).Cells("colBulto").Value = intSumBultos
                    '    End If
                    'Next
                    Linea = REA.GetInt32("ChiLin")
                Loop
                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                    If dgDetalle.Rows(i).Cells("colLinea").Value = Linea Then
                        dgDetalle.Rows(i).Cells("colBulto").Value = intSumBultos
                    End If
                Next
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgInstrucDespacho_DoubleClick(sender As Object, e As EventArgs) Handles dgInstrucDespacho.DoubleClick
        Dim i As Integer
        Dim strTemp As String
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim AnioHSM As Integer = 0
        Dim NumHSM As Integer = 0
        Dim dblDescuentoMoney As Double = 0
        Dim dblDescuentoPorcentaje As Double = 0
        Dim dblDescuentoPrecio As Double = 0
        Dim Bultos As Integer
        Dim intCantidad As Double
        Dim intMedida As String

        If dgInstrucDespacho.Rows.Count = 0 Then
            Exit Sub
        Else
            For i = 0 To dgInstrucDespacho.Rows.Count - 1
                If dgInstrucDespacho.ColumnCount > vbEmpty Then
                    If Not (dgInstrucDespacho.Rows(i).Cells(0).Value) = vbNullString Then
                        strSQL = SqlDetallePorProcesar2()
                    End If
                End If
            Next

            Try
                dgInstrucDespacho.CurrentRow.Cells(6).Value = 2
                For j As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                    If dgInstrucDespacho.Rows(j).Cells("colMarca").Value = 1 Then
                        dgInstrucDespacho.Rows(j).Visible = False
                    End If

                Next
                dgInstrucDespacho.CurrentRow.Cells(6).Value = 1
            Catch ex As Exception
                'MsgBox(ex.ToString)
            End Try
            MyCnn.CONECTAR = strConexion
            Try
                dgDetalle.Rows.Clear()
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                Do While REA.Read

                    strTemp = REA.GetInt32("Numero") & "|"
                    strTemp &= REA.GetInt32("Codigo") & "|"
                    strTemp &= REA.GetInt32("Ano") & "|"
                    strTemp &= REA.GetInt32("Linea") & "|"
                    strTemp &= REA.GetInt32("Linea") & "|"
                    strTemp &= REA.GetString("Descripcion") & "|"
                    strTemp &= REA.GetInt32("Base") & "|"
                    strTemp &= REA.GetString("Medida") & "|"
                    strTemp &= REA.GetDouble("Despacho") & "|"
                    strTemp &= REA.GetDouble("Precio") & "|"

                    If Sesion.IdEmpresa = 11 Or (Sesion.IdEmpresa = 12 And Pais() = 310) Or (Sesion.IdEmpresa = 16 And Pais() = 310) Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                        dblDescuentoPrecio = (REA.GetDouble("Precio") - REA.GetDouble("precioPF"))
                        If dblDescuentoPrecio = 0 Then
                            strTemp &= "0.00" & "|" ' Descuento en Porcentaje
                            strTemp &= "0.00" & "|" ' Descuento en $
                        Else
                            dblDescuentoMoney = ((dblDescuentoPrecio) * REA.GetDouble("Cantidad"))
                            dblDescuentoPorcentaje = ((dblDescuentoMoney / REA.GetDouble("Total")) * 100)
                            strTemp &= dblDescuentoPorcentaje.ToString(FORMATO_MONEDA) & "|" ' Descuento en Porcentaje
                            strTemp &= dblDescuentoMoney.ToString(FORMATO_MONEDA) & "|" ' Descuento en $
                        End If
                    Else
                        strTemp &= "0.00" & "|" ' Descuento en Porcentaje
                        strTemp &= "0.00" & "|" ' Descuento en $
                    End If

                    'strTemp &= "0.00" & "|"
                    'strTemp &= "0.00" & "|"
                    strTemp &= REA.GetDouble("Cantidad").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= "0.0" & "|"
                    strTemp &= REA.GetString("Bulto") & "|"
                    strTemp &= REA.GetInt32("Bobinas") & "|"
                    strTemp &= REA.GetString("Distribucion") & "|"
                    strTemp &= REA.GetInt32("Destino") & "|"
                    strTemp &= REA.GetString("Lugar") & "|"
                    strTemp &= REA.GetDouble("Libras").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= REA.GetDouble("Kilos").ToString(FORMATO_MONEDA) & "|"
                    strTemp &= (REA.GetDouble("Cantidad") / 2.2046).ToString(FORMATO_MONEDA) & "|"
                    strTemp &= (REA.GetDouble("Cantidad") / 2.2046).ToString(FORMATO_MONEDA_EXT) & "|"
                    strTemp &= REA.GetInt32("Original") & "|"
                    strTemp &= REA.GetString("Referencia") & "|"
                    strTemp &= REA.GetInt32("Base") & "|"
                    strTemp &= REA.GetDouble("precioPF") & "|"
                    strTemp &= 1

                    cFunciones.AgregarFila(dgDetalle, strTemp)

                    AnioHSM = REA.GetInt32("Ano")
                    NumHSM = REA.GetInt32("Numero")
                    'celdaEmpPagadora.Text = REA.GetString("NomPagador")
                    'celdaIDEmpPagadora.Text = REA.GetInt32("EmpPagadora")
                Loop
                REA.Close()
                REA = Nothing
                If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Then
                    CargarBultos(AnioHSM, NumHSM)
                End If
                sqlCargarRelacion()
                If (Sesion.IdEmpresa = 12 And Pais() = 0) Or (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 11) Then
                    For j As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                        ActualizarBultosPorLinea(dgInstrucDespacho.Rows(j).Cells("colAñ").Value, dgInstrucDespacho.Rows(j).Cells("colInst").Value)
                        Bultos = dgDetalle.SelectedCells(14).Value
                        intCantidad = dgDetalle.SelectedCells(12).Value
                        intMedida = dgDetalle.SelectedCells(7).Value
                        CalcularKGBrutos(Bultos, intCantidad, intMedida)
                    Next
                End If
                CalcularTotales()
                CalcularSeguro()
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try

        End If
    End Sub

    Private Sub dgInstrucDespacho_KeyDown(sender As Object, e As KeyEventArgs) Handles dgInstrucDespacho.KeyDown
        If e.KeyCode = Keys.F9 Then
            If dgInstrucDespacho.SelectedRows.Count = 0 Then Exit Sub
            Try

                If dgInstrucDespacho.CurrentRow.Cells(6).Value = 1 Then
                    dgInstrucDespacho.SelectedCells(6).Value = 2
                    For l As Integer = 0 To dgReferencia.Rows.Count - 1
                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                            If dgInstrucDespacho.CurrentRow.Cells(6).Value = 2 Then
                                If dgInstrucDespacho.CurrentRow.Cells("colInst").Value = dgDetalle.Rows(i).Cells("colNum").Value Then
                                    dgDetalle.Rows(i).Cells("colEliminar").Value = 2
                                End If
                            End If
                        Next

                        For k As Integer = 0 To dgDetalle.Rows.Count - 1
                            If dgInstrucDespacho.CurrentRow.Cells("colInst").Value = dgDetalle.Rows(k).Cells("colNum").Value Then
                                If dgDetalle.Rows(k).Cells("colEliminar").Value = 2 Then
                                    dgDetalle.Rows(k).Visible = False

                                End If
                            End If

                            If dgInstrucDespacho.CurrentRow.Cells("colInst").Value = dgReferencia.Rows(l).Cells("colInstruccion").Value Then
                                dgReferencia.Rows(l).Cells("colQuitar").Value = 2
                            Else
                                dgReferencia.Rows(l).Cells("colQuitar").Value = 1
                            End If
                        Next

                    Next
                    For l As Integer = 0 To dgReferencia.Rows.Count - 1
                        If dgReferencia.Rows(l).Cells("colQuitar").Value = 2 Then
                            dgReferencia.Rows(l).Visible = False
                        End If
                    Next
                    For j As Integer = 0 To dgInstrucDespacho.Rows.Count - 1
                        If dgInstrucDespacho.Rows(j).Cells("colMarca").Value = 2 Then
                            dgInstrucDespacho.Rows(j).Visible = False
                        End If
                    Next



                End If

                CalcularTotales()
                CalcularSeguro()
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub botonSerie_Click(sender As Object, e As EventArgs) Handles botonSerie.Click
        Dim frm As New frmSeleccionar
        Try
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Then
                frm.Condicion = " cat_clase='Serie' AND cat_clave= 'Doc_CFactura' AND cat_pid= 0  and cat_sisemp = " & Sesion.IdEmpresa
            Else
                frm.Condicion = " cat_clase='Serie' AND cat_clave= 'Doc_CFactura' and cat_sisemp = " & Sesion.IdEmpresa
            End If
            frm.Campos = " cat_sist, cat_ext Lugar "
            frm.Tabla = " Catalogos "
            frm.Filtro = " cat_sist"
            frm.FiltroText = " Enter the serial number to filter. "
            frm.Titulo = " Series "
            frm.ShowDialog(Fprincipal)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaSerie.Text = frm.LLave

                If Sesion.IdEmpresa = 14 Then
                    Dim strSQL1 As String = STR_VACIO
                    Dim COM3 As MySqlCommand
                    Dim REA As MySqlDataReader

                    strSQL1 = "SELECT f.fecha_resolucion fecha"
                    strSQL1 &= "      FROM Gface f"
                    strSQL1 &= "           LEFT JOIN Catalogos c ON c.cat_num = f.serie "
                    strSQL1 &= "      WHERE c.cat_clase = 'serie' AND c.cat_sist = '{serie}'"

                    strSQL1 = Replace(strSQL1, "{serie}", celdaSerie.Text)

                    MyCnn.CONECTAR = strConexion

                    COM3 = New MySqlCommand(strSQL1, CON)
                    REA = COM3.ExecuteReader
                    If REA.HasRows Then
                        REA.Read()

                        celdaFechavencimiento.Text = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    End If

                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub celdaSerie_TextChanged(sender As Object, e As EventArgs) Handles celdaSerie.TextChanged
        If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            etiquetaCAI.Visible = True
            celdaCAI.Visible = True
            celdaCAI.Enabled = False
        Else
            etiquetaCAI.Visible = False
            celdaCAI.Visible = False
        End If
        CAI()
    End Sub
    Private Sub FacturaSV(ByVal strRespuesta As String)
        Dim strSQL As String = STR_VACIO
        Dim strSQL4 As String = STR_VACIO
        Dim repCR As New FacturaSV
        Dim impreso As Integer = INT_CERO
        Dim imprimir As Integer = INT_CERO
        Dim clsConta As New clsContabilidad
        Dim COM2 As New MySqlCommand

        strSQL = "SELECT d.DDoc_Prd_NET precio,d.DDoc_Prd_DSQ Descuento, d.DDoc_Prd_QTY cantidad, ROUND((d.DDoc_Prd_NET * d.DDoc_Prd_QTY),4) subtotal, c.cat_clave Medida, m.cat_clave Mon2, m.cat_ext Moneda, '{OPCION}' CIF, IF(d.DDoc_RF2_Txt = 'PALLETS', d.DDoc_RF2_Txt,'') TipoBulto, IFNULL(( "
        strSQL &= "     SELECT hh.HDoc_DR1_Num"
        strSQL &= "         FROM Dcmtos_DTL_Pro p"
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro pp ON pp.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND pp.PDoc_Chi_Cat = p.PDoc_Par_Cat AND pp.PDoc_Chi_Ano = p.PDoc_Par_Ano AND pp.PDoc_Chi_Num = p.PDoc_Par_Num AND pp.PDoc_Chi_Lin = p.PDoc_Par_Lin AND pp.PDoc_Par_Cat = 47 "
        strSQL &= "                  LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = pp.PDoc_Sis_Emp AND hh.HDoc_Doc_Cat = pp.PDoc_Par_Cat AND hh.HDoc_Doc_Ano = pp.PDoc_Par_Ano AND hh.HDoc_Doc_Num = pp.PDoc_Par_Num "
        strSQL &= "                     WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                          LIMIT 1),'-') referencia, i.inv_prodlote lote, a.art_codigo codProducto, d.DDoc_Prd_Des descripcion, a.art_DLarga, a.art_DCorta DCorta, o.cat_desc origen, Round(d.DDoc_RF2_Dbl,2) pbruto, d.DDoc_Prd_DSQ descuento, h.HDoc_Doc_Fec fecha,"
        strSQL &= "                             h.HDoc_Emp_Nom empresa, h.HDoc_Emp_Dir direccion, h.HDoc_Emp_NIT NIT, h.HDoc_Doc_Num numero, h.HDoc_DR1_Num pedido, IFNULL(cli.cli_plazoCR,0) dias, box.BDoc_Box_QTY bultos, ("
        strSQL &= "                                     SELECT GROUP_CONCAT(DISTINCT Concat(c.HDoc_Doc_Num, ':'), c.HDoc_DR1_Num SEPARATOR ',')"
        strSQL &= "                                          FROM Dcmtos_DTL_Pro aa"
        strSQL &= "                                             INNER JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = aa.PDoc_Sis_Emp AND b.PDoc_Chi_Ano = aa.PDoc_Par_Ano AND b.PDoc_Chi_Cat = aa.PDoc_Par_Cat AND b.PDoc_Chi_Num = aa.PDoc_Par_Num AND b.PDoc_Chi_Lin = aa.PDoc_Par_Lin AND b.PDoc_Par_Cat = 75"
        strSQL &= "                                                 INNER JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.HDoc_Doc_Ano = b.PDoc_Par_Ano AND c.HDoc_Doc_Cat = b.PDoc_Par_Cat AND c.HDoc_Doc_Num = b.PDoc_Par_Num"
        strSQL &= "                                                     WHERE aa.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND aa.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND aa.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND aa.PDoc_Chi_Num =h.HDoc_Doc_Num )pfS , "

        strSQL &= " (SELECT IFNULL(e.cli_cliente,'')
                        FROM Dcmtos_DTL_Pro aa
                        INNER JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = aa.PDoc_Sis_Emp AND b.PDoc_Chi_Ano = aa.PDoc_Par_Ano AND b.PDoc_Chi_Cat = aa.PDoc_Par_Cat AND b.PDoc_Chi_Num = aa.PDoc_Par_Num AND b.PDoc_Chi_Lin = aa.PDoc_Par_Lin AND b.PDoc_Par_Cat = 75
                        INNER JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.HDoc_Doc_Ano = b.PDoc_Par_Ano AND c.HDoc_Doc_Cat = b.PDoc_Par_Cat AND c.HDoc_Doc_Num = b.PDoc_Par_Num
                        LEFT JOIN Clientes e ON e.cli_sisemp = c.HDoc_Sis_Emp AND e.cli_codigo = c.HDoc_DR1_Emp
                            WHERE aa.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND aa.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND aa.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND aa.PDoc_Chi_Num =h.HDoc_Doc_Num LIMIT 1)empresa2,

                    (SELECT IFNULL(e.cli_direccion,'')
                        FROM Dcmtos_DTL_Pro aa
                        INNER JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = aa.PDoc_Sis_Emp AND b.PDoc_Chi_Ano = aa.PDoc_Par_Ano AND b.PDoc_Chi_Cat = aa.PDoc_Par_Cat AND b.PDoc_Chi_Num = aa.PDoc_Par_Num AND b.PDoc_Chi_Lin = aa.PDoc_Par_Lin AND b.PDoc_Par_Cat = 75
                        INNER JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.HDoc_Doc_Ano = b.PDoc_Par_Ano AND c.HDoc_Doc_Cat = b.PDoc_Par_Cat AND c.HDoc_Doc_Num = b.PDoc_Par_Num
                        LEFT JOIN Clientes e ON e.cli_sisemp = c.HDoc_Sis_Emp AND e.cli_codigo = c.HDoc_DR1_Emp
                            WHERE aa.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND aa.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND aa.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND aa.PDoc_Chi_Num =h.HDoc_Doc_Num LIMIT 1)direccion2 "

        strSQL &= "                                                 FROM Dcmtos_HDR h"
        strSQL &= "                                             LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num"
        strSQL &= "                                         LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod"
        strSQL &= "                                     LEFT JOIN Catalogos c ON c.cat_num = d.DDoc_Prd_UM"
        strSQL &= "                                  LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon"
        strSQL &= "                             LEFT JOIN Dcmtos_DTL_Box box ON box.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND box.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND box.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND box.BDoc_Doc_Num = d.DDoc_Doc_Num AND box.BDoc_Doc_Lin = d.DDoc_Doc_Lin"
        strSQL &= "                          LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod"
        strSQL &= "                     LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo"
        strSQL &= "                   LEFT JOIN Catalogos o ON o.cat_num = i.inv_lugarfab"
        strSQL &= "                 WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {num}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{ano}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{OPCION}", strRespuesta)

        If BuscarRegistrosDcmtos_HDR_SV(strSQL) = True Then

        End If

        repCR.Load("C:\XML\DcmtosHDRsv.xml")
        Dim frm3 As New frmReporteFactSV
        frm3.Reporte_A_VerSV = repCR
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRsv.xml")

        impreso = dgLista.SelectedCells(6).Value
        'If impreso = 0 Then
        '    If frm3.DialogResult  = System.Windows.Forms.DialogResult.Cancel Then
        '        If MsgBox("The Document is printed correctly", MsgBoxStyle.YesNo, "Question") = vbYes Then
        '            imprimir = 1

        '            strSQL4 = "UPDATE Dcmtos_HDR h"
        '            strSQL4 &= "     SET h.HDoc_DR2_Cat = {impresion}"
        '            strSQL4 &= "             WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

        '            strSQL4 = Replace(strSQL4, "{impresion}", imprimir)
        '            strSQL4 = Replace(strSQL4, "{empresa}", Sesion.IdEmpresa)
        '            strSQL4 = Replace(strSQL4, "{anio}", celdaAño.Text)
        '            strSQL4 = Replace(strSQL4, "{numero}", celdaNumero.Text)

        '            'Ejecuta la instrucción
        '            MyCnn.CONECTAR = strConexion
        '            COM2 = New MySqlCommand(strSQL4, CON)
        '            COM2.ExecuteNonQuery()

        '            clsConta.GenerarPoliza(celdaTipo.Text, celdaAño.Text, celdaNumero.Text)

        '        End If
        '    End If
        'End If

    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Try
            cfun.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub



#End Region

#Region "BorrarDocumento"
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(p.PDoc_Par_Num) FROM Dcmtos_HDR h "
        strSQL &= " Left Join Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp And p.PDoc_Par_Cat = h.HDoc_Doc_Cat And p.PDoc_Par_Ano = h.HDoc_Doc_Ano And p.PDoc_Par_Num = h.HDoc_Doc_Num "
        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = 36 And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} And h.HDoc_Doc_Status = 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        Return strSQL
    End Function

    Private Sub BorrarEncabezadoFactura(ByVal num As Integer, ByVal anio As Integer)

        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 36
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDetalleFactura(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = 36 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarBultosFactura(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "BDoc_Sis_Emp = {empresa}  AND BDoc_Doc_Cat = 36 AND BDoc_Doc_Ano = {anio} AND BDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim box As New Tablas.TDCMTOS_DTL_BOX
            box.CONEXION = strConexion
            box.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDtl_ProFactura(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = 36 AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarEctacteFactura(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa}  AND ECta_Doc_Cat = 36 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarSubDocumentosFactura(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ADoc_Sis_Emp = {empresa}  AND ADoc_Doc_Cat = 36 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim acc As New Tablas.TDCMTOS_ACC
            acc.CONEXION = strConexion
            acc.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim IntNumDocs As Integer
            Dim NumFact As Integer = 0
            Dim AnioFact As Integer = 0

            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()

            'IntNumDocs = 0

            'Si la factura tiene dependencias no deja elimnar la factura
            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                'HACE LA VALIDACION SI LA FACTURA TIENE PAGOS O NOTAS DE CREDITO ASOCIADAS NO DEJA ELIMINAR LA FACTURA
                If asociaciones >= 1 Then
                    MsgBox("This inhvoice cannot be deleted because it has associated documents", vbInformation, "Notice")
                Else
                    'si la factura no tiene ni dependecias, ni pagos o notas de credito permite eliminarla
                    If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                        NumFact = celdaNumero.Text
                        AnioFact = celdaAño.Text
                        BorrarEncabezadoFactura(NumFact, AnioFact)
                        BorrarDetalleFactura(NumFact, AnioFact)
                        BorrarBultosFactura(NumFact, AnioFact)
                        BorrarDtl_ProFactura(NumFact, AnioFact)
                        BorrarEctacteFactura(NumFact, AnioFact)
                        BorrarSubDocumentosFactura(NumFact, AnioFact)
                        cFunciones.BorrarEncabezadoPoliza(NumFact, AnioFact, 36)
                        cFunciones.BorrarDetallePoliza(NumFact, AnioFact, 36)
                        cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acDelete, celdaIdCliente.Text, 36, celdaAño.Text, celdaNumero.Text, GetReferencia())
                        MostrarLista()
                    End If
                End If
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

    Private Sub checkActivar_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivar.CheckedChanged
        If Sesion.IdEmpresa = 12 And Pais() = 0 Then
            If checkActivar.Checked = True Then
                Encabezado1.botonGuardar.Enabled = False
            Else
                Encabezado1.botonGuardar.Enabled = True
            End If
        End If
    End Sub

    Private Sub botonPrevio_Click(sender As Object, e As EventArgs) Handles botonPrevio.Click
        Dim intNumero As Integer
        Dim intAño As Integer

        intAño = Val(celdaAño.Text)
        intNumero = Val(celdaNumero.Text)
        'REPORTE EN CRYSTAL REPORT
        Dim opt As New frmOption
        Dim strRespuesta As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO

        opt.Titulo = "INCOTERM"
        opt.Mensaje = "Select an option"
        opt.Opciones = "Print FOB" & "|" & "Print CIF"

        If opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            Select Case opt.Seleccion

                Case 0
                    strRespuesta = "FOB"
                Case 1
                    strRespuesta = "CIF"

            End Select
        Else
            Exit Sub
        End If

        strSQL2 = " select   h.HDoc_Emp_Nom , h.HDoc_Emp_Dir , h.HDoc_Emp_NIT , year(h.HDoc_Doc_Fec ), lpad(MONTH(h.HDoc_Doc_Fec),2,'0') mes, lpad(DAY(h.HDoc_Doc_Fec),2,'0') dia , 'GUATEMALA', h.HDoc_DR1_Num , h.HDoc_Emp_Cod , h.HDoc_Doc_Num , concat(d.DDoc_Prd_Des, '-','(',d.DDoc_RF1_Txt ,')') , d.DDoc_Prd_Cod , d.DDoc_Prd_QTY , d.DDoc_Prd_NET , round((d.DDoc_Prd_QTY * d.DDoc_Prd_NET),4) '(d.DDoc_Prd_QTY * d.DDoc_Prd_NET)', c.cat_clave , m.cat_clave , a.art_DLarga , (select group_concat( distinct cc.cat_desc separator ',') pai from Dcmtos_DTL dd left join Inventarios ii on ii.inv_sisemp = dd.DDoc_Sis_Emp and ii.inv_numero = dd.DDoc_Prd_Cod  left join Catalogos cc on cc.cat_num = ii.inv_lugarfab  where dd.DDoc_Sis_Emp = d.DDoc_Sis_Emp  and dd.DDoc_Doc_Cat = d.DDoc_Doc_Cat  and dd.DDoc_Doc_Ano = d.DDoc_Doc_Ano  and dd.DDoc_Doc_Num = d.DDoc_Doc_Num  ) origen, v.cat_desc vendedor,cc.cat_ext Signo,IFNULL(cli.cli_plazoCR,0) dias, a.art_venta Tipo,(  "
        strSQL2 &= " select GROUP_CONCAT(DISTINCT e.ADoc_Dta_Chr  SEPARATOR ',') from Dcmtos_DTL_Pro p  "
        strSQL2 &= " left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin and i.PDoc_Par_Cat = 47 "
        strSQL2 &= " left join Dcmtos_DTL_Pro pp on pp.PDoc_Sis_Emp = i.PDoc_Sis_Emp and pp.PDoc_Chi_Cat = i.PDoc_Par_Cat and pp.PDoc_Chi_Ano = i.PDoc_Par_Ano and pp.PDoc_Chi_Num = i.PDoc_Par_Num and pp.PDoc_Chi_Lin = i.PDoc_Par_Lin  "
        strSQL2 &= "left join Dcmtos_ACC e on e.ADoc_Sis_Emp =  pp.PDoc_Sis_Emp and e.ADoc_Doc_Cat = pp.PDoc_Par_Cat and e.ADoc_Doc_Ano = pp.PDoc_Par_Ano and e.ADoc_Doc_Num = pp.PDoc_Par_Num and e.ADoc_Doc_Sub = 'Doc_PolImp' AND e.ADoc_Doc_Lin = '01'  "
        strSQL2 &= " where p.PDoc_Sis_Emp = h.HDoc_Sis_Emp  and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat  and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Par_Cat = 48  ) poliza, "
        strSQL2 &= " ( select GROUP_CONCAT(DISTINCT (concat(pp.HDoc_Doc_Num ,':',pp.HDoc_DR1_Num )) SEPARATOR ',') from Dcmtos_DTL_Pro p "
        strSQL2 &= " left join Dcmtos_DTL_Pro i on i.PDoc_Sis_Emp = p.PDoc_Sis_Emp and i.PDoc_Chi_Cat = p.PDoc_Par_Cat and i.PDoc_Chi_Ano = p.PDoc_Par_Ano and i.PDoc_Chi_Num = p.PDoc_Par_Num and i.PDoc_Chi_Lin = p.PDoc_Par_Lin and i.PDoc_Par_Cat = 75 "
        strSQL2 &= " left join Dcmtos_HDR pp on pp.HDoc_Sis_Emp = i.PDoc_Sis_Emp and pp.HDoc_Doc_Cat = i.PDoc_Par_Cat and pp.HDoc_Doc_Ano = i.PDoc_Par_Ano and pp.HDoc_Doc_Num = i.PDoc_Par_Num  "
        strSQL2 &= " where p.PDoc_Sis_Emp = h.HDoc_Sis_Emp  and p.PDoc_Chi_Cat = h.HDoc_Doc_Cat  and p.PDoc_Chi_Ano = h.HDoc_Doc_Ano  and p.PDoc_Chi_Num = h.HDoc_Doc_Num  and p.PDoc_Par_Cat = 48 ) pF, "
        strSQL2 &= " (select sum(b.BDoc_Box_QTY ) from Dcmtos_DTL_Box b "
        strSQL2 &= "  where b.BDoc_Sis_Emp = d.DDoc_Sis_Emp  and b.BDoc_Doc_Cat = d.DDoc_Doc_Cat  and b.BDoc_Doc_Ano = d.DDoc_Doc_Ano  and b.BDoc_Doc_Num = d.DDoc_Doc_Num  and b.BDoc_Doc_Lin = d.DDoc_Doc_Lin ) bultos,  '{OPCION}' CIF, cast(ADDDATE(h.HDoc_Doc_Fec, INTERVAL IFNULL(cli.cli_plazoCR,0) DAY) as char) fvencimiento"
        strSQL2 &= " from Dcmtos_HDR h"
        strSQL2 &= "  left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num  "
        strSQL2 &= " left join Catalogos c on c.cat_num = d.DDoc_Prd_UM  and c.cat_clase ='Medidas' "
        strSQL2 &= " left join Catalogos m on m.cat_num = h.HDoc_Doc_Mon  "
        strSQL2 &= " Left Join Catalogos cc ON cc.cat_num = h.HDoc_Doc_Mon "
        strSQL2 &= " left join Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod "
        strSQL2 &= "  left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo "
        strSQL2 &= " LEFT JOIN Catalogos v ON v.cat_sist = 'DEF_COUNTRY' "
        strSQL2 &= "  LEFT JOIN Catalogos o ON o.cat_num = i.inv_lugarfab "
        strSQL2 &= " LEFT JOIN Clientes cli ON cli.cli_sisemp = h.HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod "
        strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {año} AND h.HDoc_Doc_Num = {numero}"
        strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
        strSQL2 = Replace(strSQL2, "{año}", intAño)
        strSQL2 = Replace(strSQL2, "{numero}", intNumero)
        strSQL2 = Replace(strSQL2, "{OPCION}", strRespuesta)
        If BuscarRegistrosDcmtos_HDR_Polizas(strSQL2) = True Then

        End If
        Dim rep4 As New Facturacion
        rep4.Load("C:\XML\DcmtosHDR.xml")
        Dim frm3 As New frmReporteFacturacion
        frm3.Reporte_A_Ver = rep4
        frm3.ShowDialog(Me)
        ' frmReporteFacturacion.ShowDialog()
        '   My.Computer.FileSystem.DeleteFile("C:\XML\factura.xml")
        '  My.Computer.FileSystem.DeleteFile("C:\XML\Signo.xml")
        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDR.xml")
    End Sub

    Private Sub botonAgrega_Click(sender As Object, e As EventArgs) Handles botonAgrega.Click
        'dgDetalle.Rows.Add()
        Dim strFilaAdd As String = STR_VACIO

        strFilaAdd = 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= celdaAño.Text & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= vbNullString & "|"

        If Sesion.IdEmpresa = 9 Then
            strFilaAdd &= 69 & "|"
            strFilaAdd &= "UND" & "|"
        Else
            If Sesion.IdEmpresa = 14 Then
                strFilaAdd &= 2522 & "|"
            Else
                strFilaAdd &= 2959 & "|"
            End If

            strFilaAdd &= "UNI" & "|"
        End If

        strFilaAdd &= 0 & "|"
        'dgDetalle.CurrentRow.Cells("colLinea2").Value = 0
        strFilaAdd &= 0.00 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 1 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 1 & "|"
        strFilaAdd &= vbNullString & "|"

        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
            strFilaAdd &= "NIC" & "|"
        ElseIf Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            strFilaAdd &= "HN" & "|"
        ElseIf Sesion.IdEmpresa = 14 Then
            strFilaAdd &= "DR" & "|"
        Else
            strFilaAdd &= "GT" & "|"
        End If

        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"

        strFilaAdd &= 0 & "|"
        strFilaAdd &= 0 & "|"
        strFilaAdd &= 1
        cfun.AgregarFila(dgDetalle, strFilaAdd)

        dgDetalle.CurrentRow.Cells("colDescrip").ReadOnly = False
        dgDetalle.CurrentRow.Cells("colPrecio").ReadOnly = False
        dgDetalle.CurrentRow.Cells("colCantidad").ReadOnly = False

    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        dgDetalle.CurrentRow.Cells("colEliminar").Value = 2
        dgDetalle.CurrentRow.Visible = False
    End Sub


    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dgDetalle_ColumnHeaderMouseDoubleClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgDetalle.ColumnHeaderMouseDoubleClick

        If e.ColumnIndex = 15 Then
            Dim resultado As DialogResult = MessageBox.Show("Replicate the value 'Package Type' Row 1 in all rows?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If resultado = DialogResult.Yes Then
                Dim valorPrimeraFila As Object = dgDetalle.Rows(0).Cells(15).Value

                ' Recorrer todas las filas del DataGridView y asignar el mismo valor a la columna 15
                For Each fila As DataGridViewRow In dgDetalle.Rows
                    fila.Cells(15).Value = valorPrimeraFila
                Next

                ' Mensaje opcional para confirmar que la acción se completó
                MessageBox.Show("Values replicated",
                            "Action performed",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            End If
        End If
    End Sub



#End Region
End Class