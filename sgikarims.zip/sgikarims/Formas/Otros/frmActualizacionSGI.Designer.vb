﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmActualizacionSGI
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colIdVersion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaVersion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEmpresaVersion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVersion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionVersion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelEncabezadoLista = New System.Windows.Forms.Panel()
        Me.rbProducción = New System.Windows.Forms.RadioButton()
        Me.rbComercializacion = New System.Windows.Forms.RadioButton()
        Me.celdaIDPrograma = New System.Windows.Forms.TextBox()
        Me.celdaPrograma = New System.Windows.Forms.TextBox()
        Me.botonProgramas = New System.Windows.Forms.Button()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFinLista = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpInicioLista = New System.Windows.Forms.DateTimePicker()
        Me.checkFiltroLista = New System.Windows.Forms.CheckBox()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgProgramas = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdPrograma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrograma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionTecnica = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcionEjecutiva = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotonesDetalle = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelEncabezadoDetalle = New System.Windows.Forms.Panel()
        Me.gbEmpresas = New System.Windows.Forms.GroupBox()
        Me.checkNS = New System.Windows.Forms.CheckBox()
        Me.checkLCP = New System.Windows.Forms.CheckBox()
        Me.checkPDM = New System.Windows.Forms.CheckBox()
        Me.checkHSM = New System.Windows.Forms.CheckBox()
        Me.checkNSM = New System.Windows.Forms.CheckBox()
        Me.checkHilos = New System.Windows.Forms.CheckBox()
        Me.checkDominican = New System.Windows.Forms.CheckBox()
        Me.checkPride = New System.Windows.Forms.CheckBox()
        Me.checkAmtex = New System.Windows.Forms.CheckBox()
        Me.gbEncabezado = New System.Windows.Forms.GroupBox()
        Me.checkObligatorio = New System.Windows.Forms.CheckBox()
        Me.CheckActivo = New System.Windows.Forms.CheckBox()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.celdaVersion = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.checkNT = New System.Windows.Forms.CheckBox()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezadoLista.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgProgramas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotonesDetalle.SuspendLayout()
        Me.panelEncabezadoDetalle.SuspendLayout()
        Me.gbEmpresas.SuspendLayout()
        Me.gbEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelEncabezadoLista)
        Me.panelLista.Location = New System.Drawing.Point(9, 94)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(739, 84)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToResizeColumns = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdVersion, Me.colFechaVersion, Me.colEmpresaVersion, Me.colVersion, Me.colDescripcionVersion})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 46)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(739, 38)
        Me.dgLista.TabIndex = 1
        '
        'colIdVersion
        '
        Me.colIdVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIdVersion.HeaderText = "Id"
        Me.colIdVersion.Name = "colIdVersion"
        Me.colIdVersion.ReadOnly = True
        Me.colIdVersion.Width = 41
        '
        'colFechaVersion
        '
        Me.colFechaVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFechaVersion.HeaderText = "Fecha"
        Me.colFechaVersion.Name = "colFechaVersion"
        Me.colFechaVersion.ReadOnly = True
        Me.colFechaVersion.Width = 62
        '
        'colEmpresaVersion
        '
        Me.colEmpresaVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEmpresaVersion.HeaderText = "Empresa"
        Me.colEmpresaVersion.Name = "colEmpresaVersion"
        Me.colEmpresaVersion.ReadOnly = True
        Me.colEmpresaVersion.Width = 73
        '
        'colVersion
        '
        Me.colVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colVersion.HeaderText = "Version"
        Me.colVersion.Name = "colVersion"
        Me.colVersion.ReadOnly = True
        Me.colVersion.Width = 67
        '
        'colDescripcionVersion
        '
        Me.colDescripcionVersion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcionVersion.HeaderText = "Programas"
        Me.colDescripcionVersion.Name = "colDescripcionVersion"
        Me.colDescripcionVersion.ReadOnly = True
        '
        'panelEncabezadoLista
        '
        Me.panelEncabezadoLista.Controls.Add(Me.rbProducción)
        Me.panelEncabezadoLista.Controls.Add(Me.rbComercializacion)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaIDPrograma)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaPrograma)
        Me.panelEncabezadoLista.Controls.Add(Me.botonProgramas)
        Me.panelEncabezadoLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpFinLista)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaFechas)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpInicioLista)
        Me.panelEncabezadoLista.Controls.Add(Me.checkFiltroLista)
        Me.panelEncabezadoLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelEncabezadoLista.Name = "panelEncabezadoLista"
        Me.panelEncabezadoLista.Size = New System.Drawing.Size(739, 46)
        Me.panelEncabezadoLista.TabIndex = 0
        '
        'rbProducción
        '
        Me.rbProducción.AutoSize = True
        Me.rbProducción.Location = New System.Drawing.Point(671, 24)
        Me.rbProducción.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbProducción.Name = "rbProducción"
        Me.rbProducción.Size = New System.Drawing.Size(79, 17)
        Me.rbProducción.TabIndex = 9
        Me.rbProducción.Text = "Producción"
        Me.rbProducción.UseVisualStyleBackColor = True
        '
        'rbComercializacion
        '
        Me.rbComercializacion.AutoSize = True
        Me.rbComercializacion.Location = New System.Drawing.Point(671, 3)
        Me.rbComercializacion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.rbComercializacion.Name = "rbComercializacion"
        Me.rbComercializacion.Size = New System.Drawing.Size(104, 17)
        Me.rbComercializacion.TabIndex = 8
        Me.rbComercializacion.Text = "Comercialización"
        Me.rbComercializacion.UseVisualStyleBackColor = True
        '
        'celdaIDPrograma
        '
        Me.celdaIDPrograma.Location = New System.Drawing.Point(616, 2)
        Me.celdaIDPrograma.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIDPrograma.Name = "celdaIDPrograma"
        Me.celdaIDPrograma.Size = New System.Drawing.Size(28, 20)
        Me.celdaIDPrograma.TabIndex = 7
        Me.celdaIDPrograma.Visible = False
        '
        'celdaPrograma
        '
        Me.celdaPrograma.Location = New System.Drawing.Point(452, 18)
        Me.celdaPrograma.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaPrograma.Name = "celdaPrograma"
        Me.celdaPrograma.Size = New System.Drawing.Size(160, 20)
        Me.celdaPrograma.TabIndex = 6
        '
        'botonProgramas
        '
        Me.botonProgramas.Location = New System.Drawing.Point(616, 18)
        Me.botonProgramas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonProgramas.Name = "botonProgramas"
        Me.botonProgramas.Size = New System.Drawing.Size(32, 19)
        Me.botonProgramas.TabIndex = 5
        Me.botonProgramas.Text = "..."
        Me.botonProgramas.UseVisualStyleBackColor = True
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(362, 16)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(68, 19)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Actualizar"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFinLista
        '
        Me.dtpFinLista.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinLista.Location = New System.Drawing.Point(254, 16)
        Me.dtpFinLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFinLista.Name = "dtpFinLista"
        Me.dtpFinLista.Size = New System.Drawing.Size(96, 20)
        Me.dtpFinLista.TabIndex = 3
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(206, 20)
        Me.etiquetaFechas.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaFechas.TabIndex = 2
        Me.etiquetaFechas.Text = "Hasta"
        '
        'dtpInicioLista
        '
        Me.dtpInicioLista.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicioLista.Location = New System.Drawing.Point(98, 16)
        Me.dtpInicioLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpInicioLista.Name = "dtpInicioLista"
        Me.dtpInicioLista.Size = New System.Drawing.Size(96, 20)
        Me.dtpInicioLista.TabIndex = 1
        '
        'checkFiltroLista
        '
        Me.checkFiltroLista.AutoSize = True
        Me.checkFiltroLista.Checked = True
        Me.checkFiltroLista.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroLista.Location = New System.Drawing.Point(11, 16)
        Me.checkFiltroLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkFiltroLista.Name = "checkFiltroLista"
        Me.checkFiltroLista.Size = New System.Drawing.Size(83, 17)
        Me.checkFiltroLista.TabIndex = 0
        Me.checkFiltroLista.Text = "Filtrar desde"
        Me.checkFiltroLista.UseVisualStyleBackColor = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.dgProgramas)
        Me.panelDetalle.Controls.Add(Me.panelBotonesDetalle)
        Me.panelDetalle.Controls.Add(Me.panelEncabezadoDetalle)
        Me.panelDetalle.Location = New System.Drawing.Point(9, 193)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(986, 196)
        Me.panelDetalle.TabIndex = 3
        '
        'dgProgramas
        '
        Me.dgProgramas.AllowUserToAddRows = False
        Me.dgProgramas.AllowUserToDeleteRows = False
        Me.dgProgramas.AllowUserToResizeColumns = False
        Me.dgProgramas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgProgramas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgProgramas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colIdPrograma, Me.colPrograma, Me.colDescripcionTecnica, Me.colDescripcionEjecutiva, Me.colExtra})
        Me.dgProgramas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgProgramas.Location = New System.Drawing.Point(0, 128)
        Me.dgProgramas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgProgramas.Name = "dgProgramas"
        Me.dgProgramas.RowTemplate.Height = 24
        Me.dgProgramas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgProgramas.Size = New System.Drawing.Size(934, 68)
        Me.dgProgramas.TabIndex = 10
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 58
        '
        'colIdPrograma
        '
        Me.colIdPrograma.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colIdPrograma.HeaderText = "Id"
        Me.colIdPrograma.Name = "colIdPrograma"
        Me.colIdPrograma.ReadOnly = True
        Me.colIdPrograma.Width = 41
        '
        'colPrograma
        '
        Me.colPrograma.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrograma.HeaderText = "Programa"
        Me.colPrograma.Name = "colPrograma"
        Me.colPrograma.ReadOnly = True
        Me.colPrograma.Width = 77
        '
        'colDescripcionTecnica
        '
        Me.colDescripcionTecnica.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcionTecnica.HeaderText = "Descripción Técnica"
        Me.colDescripcionTecnica.Name = "colDescripcionTecnica"
        '
        'colDescripcionEjecutiva
        '
        Me.colDescripcionEjecutiva.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDescripcionEjecutiva.HeaderText = "Descripción Ejecutiva"
        Me.colDescripcionEjecutiva.Name = "colDescripcionEjecutiva"
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'panelBotonesDetalle
        '
        Me.panelBotonesDetalle.Controls.Add(Me.botonEliminar)
        Me.panelBotonesDetalle.Controls.Add(Me.botonAgregar)
        Me.panelBotonesDetalle.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotonesDetalle.Location = New System.Drawing.Point(934, 128)
        Me.panelBotonesDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelBotonesDetalle.Name = "panelBotonesDetalle"
        Me.panelBotonesDetalle.Size = New System.Drawing.Size(52, 68)
        Me.panelBotonesDetalle.TabIndex = 11
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(8, 71)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(38, 37)
        Me.botonEliminar.TabIndex = 1
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.file_add
        Me.botonAgregar.Location = New System.Drawing.Point(7, 17)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(38, 37)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelEncabezadoDetalle
        '
        Me.panelEncabezadoDetalle.Controls.Add(Me.gbEmpresas)
        Me.panelEncabezadoDetalle.Controls.Add(Me.gbEncabezado)
        Me.panelEncabezadoDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoDetalle.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoDetalle.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelEncabezadoDetalle.Name = "panelEncabezadoDetalle"
        Me.panelEncabezadoDetalle.Size = New System.Drawing.Size(986, 128)
        Me.panelEncabezadoDetalle.TabIndex = 8
        '
        'gbEmpresas
        '
        Me.gbEmpresas.Controls.Add(Me.checkNT)
        Me.gbEmpresas.Controls.Add(Me.checkNS)
        Me.gbEmpresas.Controls.Add(Me.checkLCP)
        Me.gbEmpresas.Controls.Add(Me.checkPDM)
        Me.gbEmpresas.Controls.Add(Me.checkHSM)
        Me.gbEmpresas.Controls.Add(Me.checkNSM)
        Me.gbEmpresas.Controls.Add(Me.checkHilos)
        Me.gbEmpresas.Controls.Add(Me.checkDominican)
        Me.gbEmpresas.Controls.Add(Me.checkPride)
        Me.gbEmpresas.Controls.Add(Me.checkAmtex)
        Me.gbEmpresas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbEmpresas.Location = New System.Drawing.Point(469, 0)
        Me.gbEmpresas.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbEmpresas.Name = "gbEmpresas"
        Me.gbEmpresas.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbEmpresas.Size = New System.Drawing.Size(517, 128)
        Me.gbEmpresas.TabIndex = 9
        Me.gbEmpresas.TabStop = False
        Me.gbEmpresas.Text = "Empresas a Afectar"
        '
        'checkNS
        '
        Me.checkNS.AutoSize = True
        Me.checkNS.Location = New System.Drawing.Point(469, 25)
        Me.checkNS.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkNS.Name = "checkNS"
        Me.checkNS.Size = New System.Drawing.Size(41, 17)
        Me.checkNS.TabIndex = 16
        Me.checkNS.Text = "NS"
        Me.checkNS.UseVisualStyleBackColor = True
        '
        'checkLCP
        '
        Me.checkLCP.AutoSize = True
        Me.checkLCP.Location = New System.Drawing.Point(370, 67)
        Me.checkLCP.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkLCP.Name = "checkLCP"
        Me.checkLCP.Size = New System.Drawing.Size(46, 17)
        Me.checkLCP.TabIndex = 15
        Me.checkLCP.Text = "LCP"
        Me.checkLCP.UseVisualStyleBackColor = True
        '
        'checkPDM
        '
        Me.checkPDM.AutoSize = True
        Me.checkPDM.Location = New System.Drawing.Point(370, 25)
        Me.checkPDM.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkPDM.Name = "checkPDM"
        Me.checkPDM.Size = New System.Drawing.Size(50, 17)
        Me.checkPDM.TabIndex = 14
        Me.checkPDM.Text = "PDM"
        Me.checkPDM.UseVisualStyleBackColor = True
        '
        'checkHSM
        '
        Me.checkHSM.AutoSize = True
        Me.checkHSM.Location = New System.Drawing.Point(271, 67)
        Me.checkHSM.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkHSM.Name = "checkHSM"
        Me.checkHSM.Size = New System.Drawing.Size(50, 17)
        Me.checkHSM.TabIndex = 13
        Me.checkHSM.Text = "HSM"
        Me.checkHSM.UseVisualStyleBackColor = True
        '
        'checkNSM
        '
        Me.checkNSM.AutoSize = True
        Me.checkNSM.Location = New System.Drawing.Point(271, 25)
        Me.checkNSM.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkNSM.Name = "checkNSM"
        Me.checkNSM.Size = New System.Drawing.Size(50, 17)
        Me.checkNSM.TabIndex = 12
        Me.checkNSM.Text = "NSM"
        Me.checkNSM.UseVisualStyleBackColor = True
        '
        'checkHilos
        '
        Me.checkHilos.AutoSize = True
        Me.checkHilos.Location = New System.Drawing.Point(16, 25)
        Me.checkHilos.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkHilos.Name = "checkHilos"
        Me.checkHilos.Size = New System.Drawing.Size(49, 17)
        Me.checkHilos.TabIndex = 8
        Me.checkHilos.Text = "Hilos"
        Me.checkHilos.UseVisualStyleBackColor = True
        '
        'checkDominican
        '
        Me.checkDominican.AutoSize = True
        Me.checkDominican.Location = New System.Drawing.Point(141, 67)
        Me.checkDominican.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkDominican.Name = "checkDominican"
        Me.checkDominican.Size = New System.Drawing.Size(76, 17)
        Me.checkDominican.TabIndex = 11
        Me.checkDominican.Text = "Dominican"
        Me.checkDominican.UseVisualStyleBackColor = True
        '
        'checkPride
        '
        Me.checkPride.AutoSize = True
        Me.checkPride.Location = New System.Drawing.Point(141, 25)
        Me.checkPride.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkPride.Name = "checkPride"
        Me.checkPride.Size = New System.Drawing.Size(72, 17)
        Me.checkPride.TabIndex = 9
        Me.checkPride.Text = "PrideYarn"
        Me.checkPride.UseVisualStyleBackColor = True
        '
        'checkAmtex
        '
        Me.checkAmtex.AutoSize = True
        Me.checkAmtex.Location = New System.Drawing.Point(16, 67)
        Me.checkAmtex.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkAmtex.Name = "checkAmtex"
        Me.checkAmtex.Size = New System.Drawing.Size(71, 17)
        Me.checkAmtex.TabIndex = 10
        Me.checkAmtex.Text = "AmtexPM"
        Me.checkAmtex.UseVisualStyleBackColor = True
        '
        'gbEncabezado
        '
        Me.gbEncabezado.Controls.Add(Me.checkObligatorio)
        Me.gbEncabezado.Controls.Add(Me.CheckActivo)
        Me.gbEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.gbEncabezado.Controls.Add(Me.celdaAnio)
        Me.gbEncabezado.Controls.Add(Me.Label1)
        Me.gbEncabezado.Controls.Add(Me.celdaNumero)
        Me.gbEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.gbEncabezado.Controls.Add(Me.celdaVersion)
        Me.gbEncabezado.Controls.Add(Me.dtpFecha)
        Me.gbEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.gbEncabezado.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.gbEncabezado.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbEncabezado.Name = "gbEncabezado"
        Me.gbEncabezado.Padding = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.gbEncabezado.Size = New System.Drawing.Size(469, 128)
        Me.gbEncabezado.TabIndex = 12
        Me.gbEncabezado.TabStop = False
        Me.gbEncabezado.Text = "Datos"
        '
        'checkObligatorio
        '
        Me.checkObligatorio.AutoSize = True
        Me.checkObligatorio.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.checkObligatorio.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkObligatorio.Location = New System.Drawing.Point(221, 104)
        Me.checkObligatorio.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.checkObligatorio.Name = "checkObligatorio"
        Me.checkObligatorio.Size = New System.Drawing.Size(167, 17)
        Me.checkObligatorio.TabIndex = 12
        Me.checkObligatorio.Text = "Actualización Obligatoria"
        Me.checkObligatorio.UseVisualStyleBackColor = False
        '
        'CheckActivo
        '
        Me.CheckActivo.AutoSize = True
        Me.CheckActivo.Checked = True
        Me.CheckActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckActivo.Location = New System.Drawing.Point(185, 20)
        Me.CheckActivo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.CheckActivo.Name = "CheckActivo"
        Me.CheckActivo.Size = New System.Drawing.Size(56, 17)
        Me.CheckActivo.TabIndex = 8
        Me.CheckActivo.Text = "Activa"
        Me.CheckActivo.UseVisualStyleBackColor = True
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(28, 23)
        Me.etiquetaAnio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(26, 13)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Año"
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(80, 19)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(76, 20)
        Me.celdaAnio.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(10, 108)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Versión"
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(80, 46)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(76, 20)
        Me.celdaNumero.TabIndex = 5
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(17, 78)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(37, 13)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Fecha"
        '
        'celdaVersion
        '
        Me.celdaVersion.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaVersion.ForeColor = System.Drawing.SystemColors.Highlight
        Me.celdaVersion.Location = New System.Drawing.Point(80, 104)
        Me.celdaVersion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaVersion.Name = "celdaVersion"
        Me.celdaVersion.Size = New System.Drawing.Size(104, 19)
        Me.celdaVersion.TabIndex = 7
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(80, 74)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(104, 20)
        Me.dtpFecha.TabIndex = 6
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(10, 50)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Numero"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 58)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1226, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1226, 58)
        Me.Encabezado1.TabIndex = 0
        '
        'checkNT
        '
        Me.checkNT.AutoSize = True
        Me.checkNT.Location = New System.Drawing.Point(469, 67)
        Me.checkNT.Margin = New System.Windows.Forms.Padding(2)
        Me.checkNT.Name = "checkNT"
        Me.checkNT.Size = New System.Drawing.Size(41, 17)
        Me.checkNT.TabIndex = 17
        Me.checkNT.Text = "NT"
        Me.checkNT.UseVisualStyleBackColor = True
        '
        'frmActualizacionSGI
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1226, 390)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmActualizacionSGI"
        Me.Text = "frmActualizacionSGI"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezadoLista.ResumeLayout(False)
        Me.panelEncabezadoLista.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgProgramas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotonesDetalle.ResumeLayout(False)
        Me.panelEncabezadoDetalle.ResumeLayout(False)
        Me.gbEmpresas.ResumeLayout(False)
        Me.gbEmpresas.PerformLayout()
        Me.gbEncabezado.ResumeLayout(False)
        Me.gbEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelEncabezadoLista As Panel
    Friend WithEvents dtpFinLista As DateTimePicker
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpInicioLista As DateTimePicker
    Friend WithEvents checkFiltroLista As System.Windows.Forms.CheckBox
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents dgProgramas As DataGridView
    Friend WithEvents panelBotonesDetalle As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents panelEncabezadoDetalle As Panel
    Friend WithEvents gbEmpresas As GroupBox
    Friend WithEvents checkHilos As System.Windows.Forms.CheckBox
    Friend WithEvents checkDominican As System.Windows.Forms.CheckBox
    Friend WithEvents checkPride As System.Windows.Forms.CheckBox
    Friend WithEvents checkAmtex As System.Windows.Forms.CheckBox
    Friend WithEvents gbEncabezado As GroupBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaVersion As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents CheckActivo As System.Windows.Forms.CheckBox
    Friend WithEvents colIdVersion As DataGridViewTextBoxColumn
    Friend WithEvents colFechaVersion As DataGridViewTextBoxColumn
    Friend WithEvents colEmpresaVersion As DataGridViewTextBoxColumn
    Friend WithEvents colVersion As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionVersion As DataGridViewTextBoxColumn
    Friend WithEvents checkObligatorio As System.Windows.Forms.CheckBox
    Friend WithEvents botonActualizar As Button
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colIdPrograma As DataGridViewTextBoxColumn
    Friend WithEvents colPrograma As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionTecnica As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcionEjecutiva As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents checkHSM As System.Windows.Forms.CheckBox
    Friend WithEvents checkNSM As System.Windows.Forms.CheckBox
    Friend WithEvents rbProducción As RadioButton
    Friend WithEvents rbComercializacion As RadioButton
    Friend WithEvents celdaIDPrograma As TextBox
    Friend WithEvents celdaPrograma As TextBox
    Friend WithEvents botonProgramas As Button
    Friend WithEvents checkNS As System.Windows.Forms.CheckBox
    Friend WithEvents checkLCP As System.Windows.Forms.CheckBox
    Friend WithEvents checkPDM As System.Windows.Forms.CheckBox
    Friend WithEvents checkNT As System.Windows.Forms.CheckBox
End Class
