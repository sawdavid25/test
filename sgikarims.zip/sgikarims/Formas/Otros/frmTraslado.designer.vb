﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTraslado
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.gbFacturas = New System.Windows.Forms.GroupBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonAgregarFact = New System.Windows.Forms.Button()
        Me.botonQuitarFact = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgFacturaRel = New System.Windows.Forms.DataGridView()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRefIngreso = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPaquetes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaPro = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotonesDetalle = New System.Windows.Forms.Panel()
        Me.botonAgrega = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.PanelTotal = New System.Windows.Forms.Panel()
        Me.celdaidDestino = New System.Windows.Forms.TextBox()
        Me.botonDestino = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaDestino = New System.Windows.Forms.TextBox()
        Me.dgSubdocumentos = New System.Windows.Forms.DataGridView()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDisponible = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblInformacion = New System.Windows.Forms.Label()
        Me.lblLinea = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.CeldaInfo = New System.Windows.Forms.TextBox()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaIdSerie = New System.Windows.Forms.TextBox()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.celdaNumeroAutorizado = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaidCliente = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.BotonMoneda = New System.Windows.Forms.Button()
        Me.celdaNombreCliente = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.checkTranseferencia = New System.Windows.Forms.CheckBox()
        Me.celdaIdRazon = New System.Windows.Forms.TextBox()
        Me.etiquetaRazon = New System.Windows.Forms.Label()
        Me.celdaRazon = New System.Windows.Forms.TextBox()
        Me.botonRazon = New System.Windows.Forms.Button()
        Me.celdaCAI = New System.Windows.Forms.TextBox()
        Me.etiquetaCAI = New System.Windows.Forms.Label()
        Me.celdaIdTransporte = New System.Windows.Forms.TextBox()
        Me.celdaTransporte = New System.Windows.Forms.TextBox()
        Me.botonTransporte = New System.Windows.Forms.Button()
        Me.etiquetaTransporte = New System.Windows.Forms.Label()
        Me.celdaNumIngreso = New System.Windows.Forms.TextBox()
        Me.celdaAnioIngreso = New System.Windows.Forms.TextBox()
        Me.celdaCatIngreso = New System.Windows.Forms.TextBox()
        Me.celdaIdAplicante = New System.Windows.Forms.TextBox()
        Me.celdaDireccion2 = New System.Windows.Forms.TextBox()
        Me.botonAplicante = New System.Windows.Forms.Button()
        Me.celdaAplicante = New System.Windows.Forms.TextBox()
        Me.celdaAduana = New System.Windows.Forms.Label()
        Me.celdaDocumento = New System.Windows.Forms.TextBox()
        Me.gbFactura = New System.Windows.Forms.GroupBox()
        Me.dgFactura = New System.Windows.Forms.DataGridView()
        Me.col_Tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Numero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_referencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonAgregarFactura = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colAnioFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuarioFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colREferenciaFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonedaFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTCFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEspecialFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraFact = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCalISR = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFacturaNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.gbFacturas.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgFacturaRel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotonesDetalle.SuspendLayout()
        Me.PanelTotal.SuspendLayout()
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelEncabezado.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gbFactura.SuspendLayout()
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Location = New System.Drawing.Point(21, 115)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(542, 53)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colNumeroSerie, Me.colFecha, Me.colNombre, Me.colReferencia})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 38)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(542, 15)
        Me.dgLista.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Width = 67
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Visible = False
        Me.colNumero.Width = 87
        '
        'colNumeroSerie
        '
        Me.colNumeroSerie.HeaderText = "Number*"
        Me.colNumeroSerie.Name = "colNumeroSerie"
        Me.colNumeroSerie.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 67
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        Me.colNombre.Width = 60
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.Width = 103
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(542, 38)
        Me.panelFiltro.TabIndex = 3
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(457, 6)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(56, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.gbFacturas)
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.PanelTotal)
        Me.panelDocumento.Controls.Add(Me.PanelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(21, 173)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(895, 464)
        Me.panelDocumento.TabIndex = 3
        '
        'gbFacturas
        '
        Me.gbFacturas.Controls.Add(Me.Panel2)
        Me.gbFacturas.Controls.Add(Me.Panel1)
        Me.gbFacturas.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.gbFacturas.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbFacturas.Location = New System.Drawing.Point(0, 269)
        Me.gbFacturas.Margin = New System.Windows.Forms.Padding(2)
        Me.gbFacturas.Name = "gbFacturas"
        Me.gbFacturas.Padding = New System.Windows.Forms.Padding(2)
        Me.gbFacturas.Size = New System.Drawing.Size(895, 93)
        Me.gbFacturas.TabIndex = 6
        Me.gbFacturas.TabStop = False
        Me.gbFacturas.Text = "RELATED DOCUMENT"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonAgregarFact)
        Me.Panel2.Controls.Add(Me.botonQuitarFact)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(817, 14)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(76, 77)
        Me.Panel2.TabIndex = 10
        '
        'botonAgregarFact
        '
        Me.botonAgregarFact.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarFact.Location = New System.Drawing.Point(27, 12)
        Me.botonAgregarFact.Name = "botonAgregarFact"
        Me.botonAgregarFact.Size = New System.Drawing.Size(26, 24)
        Me.botonAgregarFact.TabIndex = 8
        Me.botonAgregarFact.UseVisualStyleBackColor = True
        '
        'botonQuitarFact
        '
        Me.botonQuitarFact.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitarFact.Location = New System.Drawing.Point(26, 48)
        Me.botonQuitarFact.Name = "botonQuitarFact"
        Me.botonQuitarFact.Size = New System.Drawing.Size(27, 24)
        Me.botonQuitarFact.TabIndex = 9
        Me.botonQuitarFact.Text = "-"
        Me.botonQuitarFact.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.dgFacturaRel)
        Me.Panel1.Location = New System.Drawing.Point(2, 14)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(810, 79)
        Me.Panel1.TabIndex = 1
        '
        'dgFacturaRel
        '
        Me.dgFacturaRel.AllowUserToAddRows = False
        Me.dgFacturaRel.AllowUserToDeleteRows = False
        Me.dgFacturaRel.AllowUserToOrderColumns = True
        Me.dgFacturaRel.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFacturaRel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFacturaRel.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnioFac, Me.colFechaFac, Me.colNumeroFac, Me.colUsuarioFac, Me.colREferenciaFac, Me.colTotalFac, Me.colMonedaFac, Me.colTCFac, Me.colEspecialFac, Me.colExtraFact, Me.colCat, Me.colCalISR, Me.DataGridViewTextBoxColumn1, Me.colFacturaNumero})
        Me.dgFacturaRel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgFacturaRel.Location = New System.Drawing.Point(0, 0)
        Me.dgFacturaRel.Margin = New System.Windows.Forms.Padding(2)
        Me.dgFacturaRel.Name = "dgFacturaRel"
        Me.dgFacturaRel.RowTemplate.Height = 24
        Me.dgFacturaRel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFacturaRel.Size = New System.Drawing.Size(810, 79)
        Me.dgFacturaRel.TabIndex = 0
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Controls.Add(Me.panelBotonesDetalle)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 266)
        Me.PanelDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(895, 96)
        Me.PanelDetalle.TabIndex = 5
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colProducto, Me.colRefIngreso, Me.colIdMedida, Me.colLinea, Me.colMedida, Me.colPrecio, Me.colCantidad, Me.colPaquetes, Me.colTotal, Me.colCatalogoPro, Me.colAnioPro, Me.colNumeroPro, Me.colLineaPro, Me.colExtra})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(856, 96)
        Me.dgDetalle.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Width = 57
        '
        'colProducto
        '
        Me.colProducto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colProducto.HeaderText = "Article"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.Width = 61
        '
        'colRefIngreso
        '
        Me.colRefIngreso.HeaderText = "Reference"
        Me.colRefIngreso.Name = "colRefIngreso"
        Me.colRefIngreso.Width = 82
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "IdMedida"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 76
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Width = 52
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 73
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colPaquetes
        '
        Me.colPaquetes.HeaderText = "Package"
        Me.colPaquetes.Name = "colPaquetes"
        Me.colPaquetes.Width = 75
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colCatalogoPro
        '
        Me.colCatalogoPro.HeaderText = "Catalogo"
        Me.colCatalogoPro.Name = "colCatalogoPro"
        Me.colCatalogoPro.ReadOnly = True
        Me.colCatalogoPro.Visible = False
        Me.colCatalogoPro.Width = 74
        '
        'colAnioPro
        '
        Me.colAnioPro.HeaderText = "Anio"
        Me.colAnioPro.Name = "colAnioPro"
        Me.colAnioPro.ReadOnly = True
        Me.colAnioPro.Visible = False
        Me.colAnioPro.Width = 53
        '
        'colNumeroPro
        '
        Me.colNumeroPro.HeaderText = "Numero"
        Me.colNumeroPro.Name = "colNumeroPro"
        Me.colNumeroPro.ReadOnly = True
        Me.colNumeroPro.Visible = False
        Me.colNumeroPro.Width = 69
        '
        'colLineaPro
        '
        Me.colLineaPro.HeaderText = "Linea"
        Me.colLineaPro.Name = "colLineaPro"
        Me.colLineaPro.ReadOnly = True
        Me.colLineaPro.Visible = False
        Me.colLineaPro.Width = 58
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        Me.colExtra.Width = 56
        '
        'panelBotonesDetalle
        '
        Me.panelBotonesDetalle.Controls.Add(Me.botonAgrega)
        Me.panelBotonesDetalle.Controls.Add(Me.botonQuitar)
        Me.panelBotonesDetalle.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotonesDetalle.Location = New System.Drawing.Point(856, 0)
        Me.panelBotonesDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelBotonesDetalle.Name = "panelBotonesDetalle"
        Me.panelBotonesDetalle.Size = New System.Drawing.Size(39, 96)
        Me.panelBotonesDetalle.TabIndex = 9
        '
        'botonAgrega
        '
        Me.botonAgrega.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgrega.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgrega.Location = New System.Drawing.Point(3, 13)
        Me.botonAgrega.Name = "botonAgrega"
        Me.botonAgrega.Size = New System.Drawing.Size(33, 23)
        Me.botonAgrega.TabIndex = 7
        Me.botonAgrega.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(3, 53)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(34, 24)
        Me.botonQuitar.TabIndex = 8
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'PanelTotal
        '
        Me.PanelTotal.Controls.Add(Me.celdaidDestino)
        Me.PanelTotal.Controls.Add(Me.botonDestino)
        Me.PanelTotal.Controls.Add(Me.Label6)
        Me.PanelTotal.Controls.Add(Me.celdaDestino)
        Me.PanelTotal.Controls.Add(Me.dgSubdocumentos)
        Me.PanelTotal.Controls.Add(Me.lblInformacion)
        Me.PanelTotal.Controls.Add(Me.lblLinea)
        Me.PanelTotal.Controls.Add(Me.celdaTotal)
        Me.PanelTotal.Controls.Add(Me.celdaCantidad)
        Me.PanelTotal.Controls.Add(Me.Label18)
        Me.PanelTotal.Controls.Add(Me.Label17)
        Me.PanelTotal.Controls.Add(Me.celdaObservaciones)
        Me.PanelTotal.Controls.Add(Me.Label16)
        Me.PanelTotal.Controls.Add(Me.CeldaInfo)
        Me.PanelTotal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelTotal.Location = New System.Drawing.Point(0, 362)
        Me.PanelTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelTotal.Name = "PanelTotal"
        Me.PanelTotal.Size = New System.Drawing.Size(895, 102)
        Me.PanelTotal.TabIndex = 4
        '
        'celdaidDestino
        '
        Me.celdaidDestino.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaidDestino.Location = New System.Drawing.Point(572, 4)
        Me.celdaidDestino.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidDestino.Name = "celdaidDestino"
        Me.celdaidDestino.Size = New System.Drawing.Size(26, 20)
        Me.celdaidDestino.TabIndex = 45
        Me.celdaidDestino.Visible = False
        '
        'botonDestino
        '
        Me.botonDestino.Location = New System.Drawing.Point(580, 27)
        Me.botonDestino.Margin = New System.Windows.Forms.Padding(2)
        Me.botonDestino.Name = "botonDestino"
        Me.botonDestino.Size = New System.Drawing.Size(32, 19)
        Me.botonDestino.TabIndex = 42
        Me.botonDestino.Text = "..."
        Me.botonDestino.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(316, 5)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 13)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "final destination"
        '
        'celdaDestino
        '
        Me.celdaDestino.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDestino.Location = New System.Drawing.Point(318, 21)
        Me.celdaDestino.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDestino.Multiline = True
        Me.celdaDestino.Name = "celdaDestino"
        Me.celdaDestino.ReadOnly = True
        Me.celdaDestino.Size = New System.Drawing.Size(258, 32)
        Me.celdaDestino.TabIndex = 44
        '
        'dgSubdocumentos
        '
        Me.dgSubdocumentos.AllowUserToAddRows = False
        Me.dgSubdocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgSubdocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgSubdocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colClave, Me.colDocumento, Me.colDisponible})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgSubdocumentos.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgSubdocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgSubdocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgSubdocumentos.MultiSelect = False
        Me.dgSubdocumentos.Name = "dgSubdocumentos"
        Me.dgSubdocumentos.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgSubdocumentos.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgSubdocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgSubdocumentos.Size = New System.Drawing.Size(303, 102)
        Me.dgSubdocumentos.TabIndex = 29
        '
        'colClave
        '
        Me.colClave.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colClave.HeaderText = "Clave"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        Me.colClave.Visible = False
        '
        'colDocumento
        '
        Me.colDocumento.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocumento.HeaderText = "Document"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.ReadOnly = True
        Me.colDocumento.Width = 81
        '
        'colDisponible
        '
        Me.colDisponible.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDisponible.HeaderText = "Available"
        Me.colDisponible.Name = "colDisponible"
        Me.colDisponible.ReadOnly = True
        '
        'lblInformacion
        '
        Me.lblInformacion.AutoSize = True
        Me.lblInformacion.Location = New System.Drawing.Point(800, 12)
        Me.lblInformacion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblInformacion.Name = "lblInformacion"
        Me.lblInformacion.Size = New System.Drawing.Size(86, 13)
        Me.lblInformacion.TabIndex = 28
        Me.lblInformacion.Text = "(add Information)"
        Me.lblInformacion.Visible = False
        '
        'lblLinea
        '
        Me.lblLinea.AutoSize = True
        Me.lblLinea.Location = New System.Drawing.Point(748, 12)
        Me.lblLinea.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblLinea.Name = "lblLinea"
        Me.lblLinea.Size = New System.Drawing.Size(48, 13)
        Me.lblLinea.TabIndex = 27
        Me.lblLinea.Text = "Linea 00"
        Me.lblLinea.Visible = False
        '
        'celdaTotal
        '
        Me.celdaTotal.AllowDrop = True
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Enabled = False
        Me.celdaTotal.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTotal.Location = New System.Drawing.Point(758, 53)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(121, 20)
        Me.celdaTotal.TabIndex = 26
        '
        'celdaCantidad
        '
        Me.celdaCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCantidad.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCantidad.Enabled = False
        Me.celdaCantidad.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaCantidad.Location = New System.Drawing.Point(634, 53)
        Me.celdaCantidad.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(110, 20)
        Me.celdaCantidad.TabIndex = 25
        '
        'Label18
        '
        Me.Label18.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(632, 37)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(46, 13)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Quantity"
        '
        'Label17
        '
        Me.Label17.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(755, 37)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(31, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Total"
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Location = New System.Drawing.Point(706, 12)
        Me.celdaObservaciones.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(20, 28)
        Me.celdaObservaciones.TabIndex = 2
        Me.celdaObservaciones.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(631, 12)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(64, 13)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Observation"
        Me.Label16.Visible = False
        '
        'CeldaInfo
        '
        Me.CeldaInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaInfo.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaInfo.Location = New System.Drawing.Point(742, 10)
        Me.CeldaInfo.Margin = New System.Windows.Forms.Padding(2)
        Me.CeldaInfo.Multiline = True
        Me.CeldaInfo.Name = "CeldaInfo"
        Me.CeldaInfo.Size = New System.Drawing.Size(146, 17)
        Me.CeldaInfo.TabIndex = 0
        Me.CeldaInfo.Visible = False
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.GroupBox1)
        Me.PanelEncabezado.Controls.Add(Me.GroupBox2)
        Me.PanelEncabezado.Controls.Add(Me.gbFactura)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(895, 266)
        Me.PanelEncabezado.TabIndex = 3
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.celdaIdSerie)
        Me.GroupBox1.Controls.Add(Me.botonSerie)
        Me.GroupBox1.Controls.Add(Me.celdaSerie)
        Me.GroupBox1.Controls.Add(Me.celdaNumeroAutorizado)
        Me.GroupBox1.Controls.Add(Me.celdaTasa)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.botonCliente)
        Me.GroupBox1.Controls.Add(Me.celdaidCliente)
        Me.GroupBox1.Controls.Add(Me.celdaIdMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaMoneda)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.celdaNit)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.celdaDireccion)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.BotonMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaNombreCliente)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.celdaNumero)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.checkActive)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(399, 284)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document Data"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(184, 34)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(31, 13)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Serie"
        '
        'celdaIdSerie
        '
        Me.celdaIdSerie.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdSerie.Location = New System.Drawing.Point(301, 8)
        Me.celdaIdSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdSerie.Name = "celdaIdSerie"
        Me.celdaIdSerie.Size = New System.Drawing.Size(62, 20)
        Me.celdaIdSerie.TabIndex = 28
        Me.celdaIdSerie.Visible = False
        '
        'botonSerie
        '
        Me.botonSerie.Location = New System.Drawing.Point(329, 32)
        Me.botonSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(32, 19)
        Me.botonSerie.TabIndex = 27
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        '
        'celdaSerie
        '
        Me.celdaSerie.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaSerie.Location = New System.Drawing.Point(231, 32)
        Me.celdaSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.Size = New System.Drawing.Size(95, 20)
        Me.celdaSerie.TabIndex = 26
        '
        'celdaNumeroAutorizado
        '
        Me.celdaNumeroAutorizado.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumeroAutorizado.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumeroAutorizado.Location = New System.Drawing.Point(54, 54)
        Me.celdaNumeroAutorizado.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroAutorizado.Name = "celdaNumeroAutorizado"
        Me.celdaNumeroAutorizado.Size = New System.Drawing.Size(80, 19)
        Me.celdaNumeroAutorizado.TabIndex = 25
        Me.celdaNumeroAutorizado.Text = "-1"
        '
        'celdaTasa
        '
        Me.celdaTasa.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTasa.Location = New System.Drawing.Point(243, 222)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(95, 20)
        Me.celdaTasa.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(208, 223)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(30, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Rate"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(352, 91)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(32, 19)
        Me.botonCliente.TabIndex = 22
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaidCliente
        '
        Me.celdaidCliente.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaidCliente.Location = New System.Drawing.Point(370, 63)
        Me.celdaidCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidCliente.Name = "celdaidCliente"
        Me.celdaidCliente.Size = New System.Drawing.Size(14, 20)
        Me.celdaidCliente.TabIndex = 21
        Me.celdaidCliente.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdMoneda.Location = New System.Drawing.Point(196, 224)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(8, 20)
        Me.celdaIdMoneda.TabIndex = 20
        Me.celdaIdMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaMoneda.Location = New System.Drawing.Point(55, 223)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(102, 20)
        Me.celdaMoneda.TabIndex = 19
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 225)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Currency"
        '
        'celdaNit
        '
        Me.celdaNit.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNit.Location = New System.Drawing.Point(52, 180)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(296, 20)
        Me.celdaNit.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 183)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "N.I.T"
        '
        'celdaDireccion
        '
        Me.celdaDireccion.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDireccion.Location = New System.Drawing.Point(52, 123)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(332, 45)
        Me.celdaDireccion.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 123)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Direction"
        '
        'BotonMoneda
        '
        Me.BotonMoneda.Location = New System.Drawing.Point(160, 222)
        Me.BotonMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.BotonMoneda.Name = "BotonMoneda"
        Me.BotonMoneda.Size = New System.Drawing.Size(32, 19)
        Me.BotonMoneda.TabIndex = 9
        Me.BotonMoneda.Text = "..."
        Me.BotonMoneda.UseVisualStyleBackColor = True
        '
        'celdaNombreCliente
        '
        Me.celdaNombreCliente.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNombreCliente.Location = New System.Drawing.Point(52, 92)
        Me.celdaNombreCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNombreCliente.Name = "celdaNombreCliente"
        Me.celdaNombreCliente.ReadOnly = True
        Me.celdaNombreCliente.Size = New System.Drawing.Size(296, 20)
        Me.celdaNombreCliente.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(4, 94)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Name"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(231, 60)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(117, 20)
        Me.dtpFecha.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(194, 63)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(30, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Date"
        '
        'celdaNumero
        '
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaNumero.Location = New System.Drawing.Point(132, 8)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(82, 20)
        Me.celdaNumero.TabIndex = 4
        Me.celdaNumero.Text = "-1"
        Me.celdaNumero.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(4, 58)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Number"
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Checked = True
        Me.checkActive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActive.Location = New System.Drawing.Point(231, 10)
        Me.checkActive.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 2
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaAño.Location = New System.Drawing.Point(55, 28)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(80, 20)
        Me.celdaAño.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 28)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(29, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Year"
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.checkTranseferencia)
        Me.GroupBox2.Controls.Add(Me.celdaIdRazon)
        Me.GroupBox2.Controls.Add(Me.etiquetaRazon)
        Me.GroupBox2.Controls.Add(Me.celdaRazon)
        Me.GroupBox2.Controls.Add(Me.botonRazon)
        Me.GroupBox2.Controls.Add(Me.celdaCAI)
        Me.GroupBox2.Controls.Add(Me.etiquetaCAI)
        Me.GroupBox2.Controls.Add(Me.celdaIdTransporte)
        Me.GroupBox2.Controls.Add(Me.celdaTransporte)
        Me.GroupBox2.Controls.Add(Me.botonTransporte)
        Me.GroupBox2.Controls.Add(Me.etiquetaTransporte)
        Me.GroupBox2.Controls.Add(Me.celdaNumIngreso)
        Me.GroupBox2.Controls.Add(Me.celdaAnioIngreso)
        Me.GroupBox2.Controls.Add(Me.celdaCatIngreso)
        Me.GroupBox2.Controls.Add(Me.celdaIdAplicante)
        Me.GroupBox2.Controls.Add(Me.celdaDireccion2)
        Me.GroupBox2.Controls.Add(Me.botonAplicante)
        Me.GroupBox2.Controls.Add(Me.celdaAplicante)
        Me.GroupBox2.Controls.Add(Me.celdaAduana)
        Me.GroupBox2.Controls.Add(Me.celdaDocumento)
        Me.GroupBox2.Location = New System.Drawing.Point(406, 117)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(482, 169)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        '
        'checkTranseferencia
        '
        Me.checkTranseferencia.AutoSize = True
        Me.checkTranseferencia.Checked = True
        Me.checkTranseferencia.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkTranseferencia.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkTranseferencia.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.checkTranseferencia.Location = New System.Drawing.Point(345, 114)
        Me.checkTranseferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.checkTranseferencia.Name = "checkTranseferencia"
        Me.checkTranseferencia.Size = New System.Drawing.Size(132, 19)
        Me.checkTranseferencia.TabIndex = 42
        Me.checkTranseferencia.Text = "Internal Transfer"
        Me.checkTranseferencia.UseVisualStyleBackColor = True
        '
        'celdaIdRazon
        '
        Me.celdaIdRazon.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdRazon.Location = New System.Drawing.Point(409, 86)
        Me.celdaIdRazon.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdRazon.Name = "celdaIdRazon"
        Me.celdaIdRazon.Size = New System.Drawing.Size(19, 20)
        Me.celdaIdRazon.TabIndex = 40
        Me.celdaIdRazon.Visible = False
        '
        'etiquetaRazon
        '
        Me.etiquetaRazon.AutoSize = True
        Me.etiquetaRazon.Location = New System.Drawing.Point(37, 88)
        Me.etiquetaRazon.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaRazon.Name = "etiquetaRazon"
        Me.etiquetaRazon.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaRazon.TabIndex = 39
        Me.etiquetaRazon.Text = "Reason"
        '
        'celdaRazon
        '
        Me.celdaRazon.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRazon.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaRazon.Location = New System.Drawing.Point(92, 86)
        Me.celdaRazon.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaRazon.Name = "celdaRazon"
        Me.celdaRazon.Size = New System.Drawing.Size(283, 20)
        Me.celdaRazon.TabIndex = 38
        '
        'botonRazon
        '
        Me.botonRazon.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonRazon.Location = New System.Drawing.Point(379, 85)
        Me.botonRazon.Margin = New System.Windows.Forms.Padding(2)
        Me.botonRazon.Name = "botonRazon"
        Me.botonRazon.Size = New System.Drawing.Size(26, 19)
        Me.botonRazon.TabIndex = 37
        Me.botonRazon.Text = "..."
        Me.botonRazon.UseVisualStyleBackColor = True
        '
        'celdaCAI
        '
        Me.celdaCAI.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaCAI.Location = New System.Drawing.Point(92, 112)
        Me.celdaCAI.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCAI.Name = "celdaCAI"
        Me.celdaCAI.ReadOnly = True
        Me.celdaCAI.Size = New System.Drawing.Size(236, 20)
        Me.celdaCAI.TabIndex = 25
        '
        'etiquetaCAI
        '
        Me.etiquetaCAI.AutoSize = True
        Me.etiquetaCAI.Location = New System.Drawing.Point(58, 116)
        Me.etiquetaCAI.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaCAI.Name = "etiquetaCAI"
        Me.etiquetaCAI.Size = New System.Drawing.Size(24, 13)
        Me.etiquetaCAI.TabIndex = 25
        Me.etiquetaCAI.Text = "CAI"
        '
        'celdaIdTransporte
        '
        Me.celdaIdTransporte.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdTransporte.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdTransporte.Location = New System.Drawing.Point(406, 57)
        Me.celdaIdTransporte.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdTransporte.Name = "celdaIdTransporte"
        Me.celdaIdTransporte.Size = New System.Drawing.Size(18, 20)
        Me.celdaIdTransporte.TabIndex = 34
        Me.celdaIdTransporte.Visible = False
        '
        'celdaTransporte
        '
        Me.celdaTransporte.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTransporte.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaTransporte.Location = New System.Drawing.Point(92, 58)
        Me.celdaTransporte.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTransporte.Name = "celdaTransporte"
        Me.celdaTransporte.Size = New System.Drawing.Size(283, 20)
        Me.celdaTransporte.TabIndex = 33
        '
        'botonTransporte
        '
        Me.botonTransporte.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonTransporte.Location = New System.Drawing.Point(379, 58)
        Me.botonTransporte.Margin = New System.Windows.Forms.Padding(2)
        Me.botonTransporte.Name = "botonTransporte"
        Me.botonTransporte.Size = New System.Drawing.Size(26, 19)
        Me.botonTransporte.TabIndex = 32
        Me.botonTransporte.Text = "..."
        Me.botonTransporte.UseVisualStyleBackColor = True
        '
        'etiquetaTransporte
        '
        Me.etiquetaTransporte.AutoSize = True
        Me.etiquetaTransporte.Location = New System.Drawing.Point(27, 55)
        Me.etiquetaTransporte.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTransporte.Name = "etiquetaTransporte"
        Me.etiquetaTransporte.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaTransporte.TabIndex = 31
        Me.etiquetaTransporte.Text = "Transport"
        '
        'celdaNumIngreso
        '
        Me.celdaNumIngreso.Location = New System.Drawing.Point(428, 42)
        Me.celdaNumIngreso.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumIngreso.Name = "celdaNumIngreso"
        Me.celdaNumIngreso.Size = New System.Drawing.Size(76, 20)
        Me.celdaNumIngreso.TabIndex = 30
        Me.celdaNumIngreso.Visible = False
        '
        'celdaAnioIngreso
        '
        Me.celdaAnioIngreso.Location = New System.Drawing.Point(428, 28)
        Me.celdaAnioIngreso.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnioIngreso.Name = "celdaAnioIngreso"
        Me.celdaAnioIngreso.Size = New System.Drawing.Size(76, 20)
        Me.celdaAnioIngreso.TabIndex = 29
        Me.celdaAnioIngreso.Visible = False
        '
        'celdaCatIngreso
        '
        Me.celdaCatIngreso.Location = New System.Drawing.Point(428, 13)
        Me.celdaCatIngreso.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCatIngreso.Name = "celdaCatIngreso"
        Me.celdaCatIngreso.Size = New System.Drawing.Size(76, 20)
        Me.celdaCatIngreso.TabIndex = 28
        Me.celdaCatIngreso.Visible = False
        '
        'celdaIdAplicante
        '
        Me.celdaIdAplicante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdAplicante.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaIdAplicante.Location = New System.Drawing.Point(409, 13)
        Me.celdaIdAplicante.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdAplicante.Name = "celdaIdAplicante"
        Me.celdaIdAplicante.Size = New System.Drawing.Size(16, 20)
        Me.celdaIdAplicante.TabIndex = 27
        Me.celdaIdAplicante.Visible = False
        '
        'celdaDireccion2
        '
        Me.celdaDireccion2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDireccion2.Location = New System.Drawing.Point(92, 17)
        Me.celdaDireccion2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion2.Multiline = True
        Me.celdaDireccion2.Name = "celdaDireccion2"
        Me.celdaDireccion2.Size = New System.Drawing.Size(283, 30)
        Me.celdaDireccion2.TabIndex = 25
        '
        'botonAplicante
        '
        Me.botonAplicante.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAplicante.Location = New System.Drawing.Point(379, 17)
        Me.botonAplicante.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAplicante.Name = "botonAplicante"
        Me.botonAplicante.Size = New System.Drawing.Size(26, 19)
        Me.botonAplicante.TabIndex = 23
        Me.botonAplicante.Text = "..."
        Me.botonAplicante.UseVisualStyleBackColor = True
        '
        'celdaAplicante
        '
        Me.celdaAplicante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAplicante.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaAplicante.Location = New System.Drawing.Point(428, 57)
        Me.celdaAplicante.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAplicante.Name = "celdaAplicante"
        Me.celdaAplicante.Size = New System.Drawing.Size(135, 20)
        Me.celdaAplicante.TabIndex = 9
        Me.celdaAplicante.Visible = False
        '
        'celdaAduana
        '
        Me.celdaAduana.AutoSize = True
        Me.celdaAduana.Location = New System.Drawing.Point(4, 17)
        Me.celdaAduana.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.celdaAduana.Name = "celdaAduana"
        Me.celdaAduana.Size = New System.Drawing.Size(76, 13)
        Me.celdaAduana.TabIndex = 8
        Me.celdaAduana.Text = "Customs office"
        '
        'celdaDocumento
        '
        Me.celdaDocumento.ForeColor = System.Drawing.SystemColors.InfoText
        Me.celdaDocumento.Location = New System.Drawing.Point(428, 71)
        Me.celdaDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDocumento.Name = "celdaDocumento"
        Me.celdaDocumento.Size = New System.Drawing.Size(184, 20)
        Me.celdaDocumento.TabIndex = 5
        Me.celdaDocumento.Visible = False
        '
        'gbFactura
        '
        Me.gbFactura.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFactura.Controls.Add(Me.dgFactura)
        Me.gbFactura.Controls.Add(Me.PanelBotones)
        Me.gbFactura.Location = New System.Drawing.Point(406, 2)
        Me.gbFactura.Margin = New System.Windows.Forms.Padding(2)
        Me.gbFactura.Name = "gbFactura"
        Me.gbFactura.Padding = New System.Windows.Forms.Padding(2)
        Me.gbFactura.Size = New System.Drawing.Size(482, 105)
        Me.gbFactura.TabIndex = 1
        Me.gbFactura.TabStop = False
        Me.gbFactura.Text = "Entry to Warehouse"
        '
        'dgFactura
        '
        Me.dgFactura.AllowUserToAddRows = False
        Me.dgFactura.AllowUserToDeleteRows = False
        Me.dgFactura.AllowUserToOrderColumns = True
        Me.dgFactura.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgFactura.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactura.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_Tipo, Me.col_anio, Me.col_Numero, Me.col_fecha, Me.colProveedor, Me.col_referencia, Me.colSaldo, Me.colStatus})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgFactura.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgFactura.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgFactura.Location = New System.Drawing.Point(2, 15)
        Me.dgFactura.Margin = New System.Windows.Forms.Padding(2)
        Me.dgFactura.MultiSelect = False
        Me.dgFactura.Name = "dgFactura"
        Me.dgFactura.ReadOnly = True
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactura.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgFactura.RowTemplate.Height = 24
        Me.dgFactura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFactura.Size = New System.Drawing.Size(436, 88)
        Me.dgFactura.TabIndex = 2
        '
        'col_Tipo
        '
        Me.col_Tipo.HeaderText = "Type"
        Me.col_Tipo.Name = "col_Tipo"
        Me.col_Tipo.ReadOnly = True
        Me.col_Tipo.Visible = False
        Me.col_Tipo.Width = 56
        '
        'col_anio
        '
        Me.col_anio.HeaderText = "Year"
        Me.col_anio.Name = "col_anio"
        Me.col_anio.ReadOnly = True
        Me.col_anio.Width = 54
        '
        'col_Numero
        '
        Me.col_Numero.HeaderText = "Number"
        Me.col_Numero.Name = "col_Numero"
        Me.col_Numero.ReadOnly = True
        Me.col_Numero.Width = 69
        '
        'col_fecha
        '
        Me.col_fecha.HeaderText = "Date"
        Me.col_fecha.Name = "col_fecha"
        Me.col_fecha.ReadOnly = True
        Me.col_fecha.Width = 55
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Provider"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        Me.colProveedor.Width = 71
        '
        'col_referencia
        '
        Me.col_referencia.HeaderText = "Reference"
        Me.col_referencia.Name = "col_referencia"
        Me.col_referencia.ReadOnly = True
        Me.col_referencia.Width = 82
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance KG"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Visible = False
        Me.colSaldo.Width = 89
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Estado"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Visible = False
        Me.colStatus.Width = 65
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.Button1)
        Me.PanelBotones.Controls.Add(Me.botonAgregarFactura)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(438, 15)
        Me.PanelBotones.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(42, 88)
        Me.PanelBotones.TabIndex = 3
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.Button1.Location = New System.Drawing.Point(5, 44)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(31, 28)
        Me.Button1.TabIndex = 12
        Me.Button1.UseVisualStyleBackColor = False
        '
        'botonAgregarFactura
        '
        Me.botonAgregarFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregarFactura.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregarFactura.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarFactura.Location = New System.Drawing.Point(4, 8)
        Me.botonAgregarFactura.Name = "botonAgregarFactura"
        Me.botonAgregarFactura.Size = New System.Drawing.Size(31, 28)
        Me.botonAgregarFactura.TabIndex = 11
        Me.botonAgregarFactura.UseVisualStyleBackColor = False
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(206, 10)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(2)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(54, 45)
        Me.botonImprimir.TabIndex = 4
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(925, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(925, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'colAnioFac
        '
        Me.colAnioFac.HeaderText = "Year"
        Me.colAnioFac.Name = "colAnioFac"
        Me.colAnioFac.ReadOnly = True
        Me.colAnioFac.Visible = False
        '
        'colFechaFac
        '
        Me.colFechaFac.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFechaFac.HeaderText = "Date"
        Me.colFechaFac.Name = "colFechaFac"
        Me.colFechaFac.ReadOnly = True
        Me.colFechaFac.Width = 55
        '
        'colNumeroFac
        '
        Me.colNumeroFac.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumeroFac.HeaderText = "Number"
        Me.colNumeroFac.Name = "colNumeroFac"
        Me.colNumeroFac.ReadOnly = True
        Me.colNumeroFac.Visible = False
        Me.colNumeroFac.Width = 69
        '
        'colUsuarioFac
        '
        Me.colUsuarioFac.HeaderText = "User"
        Me.colUsuarioFac.Name = "colUsuarioFac"
        Me.colUsuarioFac.ReadOnly = True
        Me.colUsuarioFac.Visible = False
        '
        'colREferenciaFac
        '
        Me.colREferenciaFac.HeaderText = "Reference"
        Me.colREferenciaFac.Name = "colREferenciaFac"
        Me.colREferenciaFac.ReadOnly = True
        '
        'colTotalFac
        '
        Me.colTotalFac.HeaderText = "Amount"
        Me.colTotalFac.Name = "colTotalFac"
        Me.colTotalFac.ReadOnly = True
        '
        'colMonedaFac
        '
        Me.colMonedaFac.HeaderText = "Currency"
        Me.colMonedaFac.Name = "colMonedaFac"
        Me.colMonedaFac.ReadOnly = True
        '
        'colTCFac
        '
        Me.colTCFac.HeaderText = "TC"
        Me.colTCFac.Name = "colTCFac"
        Me.colTCFac.ReadOnly = True
        '
        'colEspecialFac
        '
        Me.colEspecialFac.HeaderText = "FacturaEspecial"
        Me.colEspecialFac.Name = "colEspecialFac"
        Me.colEspecialFac.ReadOnly = True
        Me.colEspecialFac.Visible = False
        '
        'colExtraFact
        '
        Me.colExtraFact.HeaderText = "Extra"
        Me.colExtraFact.Name = "colExtraFact"
        Me.colExtraFact.ReadOnly = True
        Me.colExtraFact.Visible = False
        '
        'colCat
        '
        Me.colCat.HeaderText = "Catalogo"
        Me.colCat.Name = "colCat"
        Me.colCat.ReadOnly = True
        Me.colCat.Visible = False
        '
        'colCalISR
        '
        Me.colCalISR.HeaderText = "Calculation ISR"
        Me.colCalISR.Name = "colCalISR"
        Me.colCalISR.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Linea"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Visible = False
        '
        'colFacturaNumero
        '
        Me.colFacturaNumero.HeaderText = "Factura Numero"
        Me.colFacturaNumero.Name = "colFacturaNumero"
        '
        'frmTraslado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(925, 676)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmTraslado"
        Me.Text = "Transfer"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.gbFacturas.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgFacturaRel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotonesDetalle.ResumeLayout(False)
        Me.PanelTotal.ResumeLayout(False)
        Me.PanelTotal.PerformLayout()
        CType(Me.dgSubdocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelEncabezado.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.gbFactura.ResumeLayout(False)
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents BotonMoneda As Button
    Friend WithEvents celdaNombreCliente As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents gbFactura As GroupBox
    Friend WithEvents dgFactura As DataGridView
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaidCliente As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents celdaDireccion2 As TextBox
    Friend WithEvents botonAplicante As Button
    Friend WithEvents celdaAplicante As TextBox
    Friend WithEvents celdaAduana As Label
    Friend WithEvents celdaDocumento As TextBox
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents PanelTotal As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaCantidad As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents celdaObservaciones As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents CeldaInfo As TextBox
    Friend WithEvents PanelEncabezado As Panel
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents botonAgregarFactura As Button
    Friend WithEvents celdaIdAplicante As TextBox
    Friend WithEvents lblInformacion As Label
    Friend WithEvents lblLinea As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents botonImprimir As Button
    Friend WithEvents dgSubdocumentos As DataGridView
    Friend WithEvents colClave As DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As DataGridViewTextBoxColumn
    Friend WithEvents colDisponible As DataGridViewTextBoxColumn
    Friend WithEvents celdaNumIngreso As TextBox
    Friend WithEvents celdaAnioIngreso As TextBox
    Friend WithEvents celdaCatIngreso As TextBox
    Friend WithEvents col_Tipo As DataGridViewTextBoxColumn
    Friend WithEvents col_anio As DataGridViewTextBoxColumn
    Friend WithEvents col_Numero As DataGridViewTextBoxColumn
    Friend WithEvents col_fecha As DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As DataGridViewTextBoxColumn
    Friend WithEvents col_referencia As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents celdaIdTransporte As TextBox
    Friend WithEvents celdaTransporte As TextBox
    Friend WithEvents botonTransporte As Button
    Friend WithEvents etiquetaTransporte As Label
    Friend WithEvents celdaCAI As TextBox
    Friend WithEvents etiquetaCAI As Label
    Friend WithEvents celdaNumeroAutorizado As TextBox
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents celdaRazon As TextBox
    Friend WithEvents botonRazon As Button
    Friend WithEvents etiquetaRazon As Label
    Friend WithEvents celdaIdRazon As TextBox
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroSerie As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents celdaidDestino As TextBox
    Friend WithEvents botonDestino As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents celdaDestino As TextBox
    Friend WithEvents checkTranseferencia As System.Windows.Forms.CheckBox
    Friend WithEvents botonSerie As Button
    Friend WithEvents celdaIdSerie As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgrega As Button
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents colRefIngreso As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPaquetes As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoPro As DataGridViewTextBoxColumn
    Friend WithEvents colAnioPro As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroPro As DataGridViewTextBoxColumn
    Friend WithEvents colLineaPro As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents panelBotonesDetalle As Panel
    Friend WithEvents gbFacturas As GroupBox
    Friend WithEvents Panel2 As Panel
    Friend WithEvents botonAgregarFact As Button
    Friend WithEvents botonQuitarFact As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dgFacturaRel As DataGridView
    Friend WithEvents colAnioFac As DataGridViewTextBoxColumn
    Friend WithEvents colFechaFac As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroFac As DataGridViewTextBoxColumn
    Friend WithEvents colUsuarioFac As DataGridViewTextBoxColumn
    Friend WithEvents colREferenciaFac As DataGridViewTextBoxColumn
    Friend WithEvents colTotalFac As DataGridViewTextBoxColumn
    Friend WithEvents colMonedaFac As DataGridViewTextBoxColumn
    Friend WithEvents colTCFac As DataGridViewTextBoxColumn
    Friend WithEvents colEspecialFac As DataGridViewTextBoxColumn
    Friend WithEvents colExtraFact As DataGridViewTextBoxColumn
    Friend WithEvents colCat As DataGridViewTextBoxColumn
    Friend WithEvents colCalISR As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents colFacturaNumero As DataGridViewTextBoxColumn
End Class
