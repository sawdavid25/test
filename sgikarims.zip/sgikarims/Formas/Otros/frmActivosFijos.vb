﻿Public Class frmActivosFijos
#Region "About SGI"
    ' Ultimo cambio 03-03-2022
    ' Responsable : WC
    ' SGIVER. V3.3.12.42
    ' se agrego agrupacion de los 4 campos desplegables de la lista principal de activos fijoas
    ' Los activos fijos aceptan varios facturas ancladas
    ' se guarda todo en la misma tabla   encabezado/detalle
    ' OBJETO TACTIVOS (Entidity) tabla Activos
    ' se agregaron las llaves primarias (Ref_Cat,Ref_Ano,Ref_Num,Ref_Lin) en la tabla mysql y el Objeto Entity TACTIVOS Class
#End Region
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim intControlador As Integer = NO_FILA
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"



    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            If LogBorrar = True Then
                Encabezado1.botonBorrar.Enabled = True
            Else
                Encabezado1.botonBorrar.Enabled = False
            End If
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub reset()
        celdaCodigo.Text = NO_FILA
        celdaDescripcion.Text = STR_VACIO
        celdaTipo.Text = STR_VACIO
        celdaidTipo.Text = NO_FILA
        celdaMarca.Text = STR_VACIO
        celdaModelo.Text = STR_VACIO
        celdaSerie.Text = STR_VACIO
        celdaColor.Text = STR_VACIO
        celdaProveedor.Text = STR_VACIO
        celdaIdProveedor.Text = INT_CERO
        celdaFactura.Text = STR_VACIO
        celdaSerieF.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaIdMoneda.Text = NO_FILA
        celdaTasa.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaValorLibros.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaValorCompra.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaDepreciacion.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaDiasPendientes.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaidResponsable.Text = INT_CERO
        celdaResponsable.Text = STR_VACIO
        celdaResiduo.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaRefAnio.Text = NO_FILA
        celdaRefcat.Text = NO_FILA
        celdaRefNum.Text = NO_FILA
        dgDepreciacion.Rows.Clear()
        dtpFecha.Value = cfun.HoyMySQL.ToString(FORMATO_MYSQL)

        celdaPorcentaje.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaCostoConIVA.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaVidaUtilUnidades.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaVidaUtilHoras.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaIdTipoDep.Text = INT_CERO
        celdaTipoDep.Text = ""
        'celdaDepreciacion.Clear()
        celdaVidaUtilAños.Clear()
        celdaVidaUtilMeses.Clear()

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Advances")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")

                Me.Tag = "Nuevo"
                dgDetalle.Rows.Clear()
                dgDetalle.Rows.Add()
                dgDetalle.Rows(0).Cells("colExtra").Value = "0"

                BloquearBotones(False)
                'botonInprimir.Enabled = False
                reset()
            End If
            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try


            strSql = " SELECT COALESCE(t.Descripcion,'(sin tipo)') Tipo, a.Codigo, a.Descripcion, a.SN Serie   
                            FROM Activos a 
                                LEFT JOIN Tipos_Activo t ON t.Empresa = a.Empresa AND t.Codigo = a.Id_Tipo 
                                    WHERE a.Empresa = {empresa}
                                        group by 1,2,3,4
                                        ORDER BY a.Id_Tipo,a.codigo "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strLinea = REA.GetString("Tipo") & "|" 'Año
                    strLinea &= REA.GetInt32("Codigo") & "|" 'Numero 
                    strLinea &= REA.GetString("Descripcion") & "|" 'Fecha
                    strLinea &= REA.GetString("Serie") ' Estado
                    cFunciones.AgregarFila(dgLista, strLinea)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function ObtenerPorcentaje() As Double
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim porcentaje As Double
        strSQL = " SELECT Porcentaje FROM Tipos_Activo WHERE Codigo = {codigo}"
        strSQL = Replace(strSQL, "{codigo}", celdaidTipo.Text)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        porcentaje = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return porcentaje
    End Function
    Public Sub CalcularRetencion()
        Dim strFila As String = STR_VACIO
        Dim dteInicio As Date
        Dim dteCorte As Date
        Dim dblPorcentaje As Double
        Dim dblTotal As Double
        Dim dblAnual As Double
        Dim dblMensual As Double
        Dim dblResiduo As Double
        Dim dblResidual As Double
        Dim dblSuma As Double
        Dim dblMonto As Double
        Dim dblAjuste As Double
        Dim i As Integer
        Dim intDias As Integer
        Dim intDiasMes As Integer
        Dim dblPrecio As Double
        Dim dblTasa As Double
        Dim intDiasPendientes As Integer
        Dim UnidadesXmes As Double
        Dim HorasXmes As Double

        Try
            dgDepreciacion.Rows.Clear()
            dblResidual = celdaResiduo.Text
            dblPrecio = celdaValorCompra.Text
            dblTasa = celdaTasa.Text
            dblPorcentaje = ObtenerPorcentaje()
            'Valor de la compra en moneda local
            dblTotal = celdaValorLibros.Text  'Math.Round((dblPrecio - dblResidual) * dblTasa, 2)
            'Depreciación anual
            If dblPorcentaje > 0 Then
                dblAnual = (dblTotal * (dblPorcentaje / 100))
                dblMensual = Math.Round(dblAnual / 12, 2)
            ElseIf celdaTipoDep.Text = "Years" Then
                dblAnual = dblTotal / celdaVidaUtilAños.Text
                dblMensual = Math.Round(dblAnual / 12, 2)
            ElseIf celdaTipoDep.Text = "Units" Then
                UnidadesXmes = (celdaVidaUtilUnidades.Text / (celdaVidaUtilAños.Text * 12))
                dblAnual = ((dblTotal / celdaVidaUtilUnidades.Text) * (UnidadesXmes * 12))
                dblMensual = Math.Round((dblTotal / celdaVidaUtilUnidades.Text) * (UnidadesXmes), 2)
            ElseIf celdaTipoDep.Text = "Hours" Then
                HorasXmes = (celdaVidaUtilHoras.Text / (celdaVidaUtilAños.Text * 12))
                dblAnual = ((dblTotal / celdaVidaUtilHoras.Text) * (HorasXmes * 12))
                dblMensual = Math.Round((dblTotal / celdaVidaUtilHoras.Text) * (HorasXmes), 2)
            End If

            'Depreciación mensual

            'Primer día del mes siguiente a la compra
            dteInicio = DateSerial(Year(dtpFecha.Value), Month(dtpFecha.Value) + 1, 1)

            'If dblPorcentaje > vbEmpty Then
            dblResiduo = dblTotal
            While dblResiduo > vbEmpty
                i = i + 1
                dteCorte = DateSerial(Year(dteInicio), Month(dteInicio) + 1, vbEmpty)
                intDiasMes = Val(Format(dteCorte, "dd"))

                dblMonto = dblMensual
                dblSuma = (dblSuma + dblMonto)

                If (i Mod 12 = vbEmpty) Then
                    dblAjuste = Math.Round(dblAnual - dblSuma, 2)
                    dblMonto = (dblMonto + dblAjuste)
                    dblSuma = vbEmpty
                End If

                If (dblResiduo < dblMonto) Then
                    intDias = CInt((dblResiduo / dblMonto) * intDiasMes)
                    dblMonto = Math.Round(dblResiduo, 2)
                    dblResiduo = vbEmpty
                Else
                    intDias = intDiasMes
                    dblResiduo = Math.Round((dblResiduo - dblMonto), 2)
                End If
                dteInicio = DateAdd("M", 1, dteInicio)
                strFila = INT_CERO & "|"
                strFila &= dteCorte & "|"
                strFila &= dblMonto & "|"
                strFila &= dblResiduo.ToString(FORMATO_MONEDA) & "|"
                strFila &= intDias & "|"
                strFila &= INT_CERO & "|"
                strFila &= INT_CERO
                cfun.AgregarFila(dgDepreciacion, strFila)
                intDiasPendientes = intDiasPendientes + intDias
            End While
            ' End If
            celdaDiasPendientes.Text = intDiasPendientes
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub RecalcularRetencion()
        Dim strFila As String = STR_VACIO
        Dim intFalta As Integer
        Dim intDias As Integer
        Dim intDepreciacion As Integer = INT_CERO
        Dim dblDiferencia As Double = INT_CERO
        Dim dteInicio As Date
        Dim dteCorte As Date
        Dim dblPorcentaje As Double
        Dim dblTotal As Double
        Dim dblAnual As Double
        Dim dblMensual As Double
        Dim dblResiduo As Double
        Dim dblResidual As Double
        Dim dblSuma As Double
        Dim dblSuma2 As Double
        Dim dblMonto As Double
        Dim dblAjuste As Double
        Dim i As Integer
        Dim intDiasMes As Integer
        Dim dblPrecio As Double
        Dim dblTasa As Double
        Dim dblDato As Double
        'Conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        dblResidual = celdaResiduo.Text
        dblPrecio = celdaValorCompra.Text
        dblTasa = celdaTasa.Text
        dblPorcentaje = ObtenerPorcentaje()
        'Valor de la compra en moneda local
        dblTotal = Math.Round((dblPrecio - dblResidual), 2) '* dblTasa, 2)
        'Depreciación anual
        dblAnual = (dblTotal * (dblPorcentaje / 100))
        'Depreciación mensual
        dblMensual = Math.Round(dblAnual / 12, 2)
        dblResiduo = dblTotal
        For j As Integer = 0 To dgDepreciacion.Rows.Count - 1
            i = i + 1
            If dgDepreciacion.Rows(j).Cells("colEstado").Value = INT_UNO Then
                dblDiferencia = (dblMensual - dgDepreciacion.Rows(j).Cells("colMonto").Value)
                intFalta = intFalta + dgDepreciacion.Rows(j).Cells("colDia").Value
                dblResiduo = (dblResiduo - dgDepreciacion.Rows(j).Cells("colMonto").Value)
                dgDepreciacion.Rows(j).Cells("colSaldo").Value = Math.Round(dblResiduo, 2)
                dblSuma = dblSuma + dblDiferencia
            Else
                If Not (dblDiferencia = vbEmpty) Then
                    If dblSuma <= dblMensual And dblSuma > vbEmpty Then
                        dblDato = dblSuma
                    Else
                        dblDato = (dblMensual * (-1))
                    End If
                    dblMonto = (dblMensual + dblDiferencia)
                    intDepreciacion = intDepreciacion + dgDepreciacion.Rows(j).Cells("colDia").Value
                    dblResiduo = (dblResiduo - dblMonto)
                    dgDepreciacion.Rows(j).Cells("colSaldo").Value = Math.Round(dblResiduo, 2)
                    dgDepreciacion.Rows(j).Cells("colMonto").Value = dblMonto
                    dblDiferencia = INT_CERO
                Else

                    dblMonto = dblMensual
                    dblSuma2 = (dblSuma2 + dblMonto)
                    If (i Mod 12 = vbEmpty) Then
                        dblAjuste = Math.Round(dblAnual - dblSuma2, 2)
                        dblMonto = (dblMonto + dblAjuste)
                        dblSuma2 = vbEmpty
                    End If

                    If (dblResiduo < dblMonto) Then
                        intDias = CInt((dblResiduo / dblMonto) * intDiasMes)
                        dblMonto = Math.Round(dblResiduo, 2)
                        dblResiduo = vbEmpty
                    Else
                        intDias = intDiasMes
                        dblResiduo = (dblResiduo - dblMonto)
                    End If
                    dgDepreciacion.Rows(j).Cells("colMonto").Value = dblMonto
                    dgDepreciacion.Rows(j).Cells("colSaldo").Value = Math.Round(dblResiduo, 2)
                    intDepreciacion = intDepreciacion + dgDepreciacion.Rows(j).Cells("colDia").Value
                End If
            End If
        Next
        celdaDepreciacion.Text = intFalta
        celdaDiasPendientes.Text = intDepreciacion
    End Sub
    Private Function sqlEncabezado(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT a.Ref_Cat , a.Ref_Año Ref_Ano,a.Ref_Num ,a.Ref_Lin ,a.Empresa,  a.Codigo , a.Descripcion ,a.Id_Tipo idTipo, ta.Descripcion Tipo,a.Marca,a.Modelo, a.SN ,a.Color , IFNULL(p.pro_proveedor,'') NombreProveedor , "
        strSQL &= "     a.Id_Proveedor idProveedor, IFNULL(a.Factura,'N/A') Factura ,a.Serie ,a.Fecha , c.cat_desc Moneda , a.Id_Moneda , a.Tasa , a.Precio, a.Valor , "
        strSQL &= "     a.Dias_Depreciados , a.Dias_Pendientes ,a.Id_Usuario Usuario,IFNULL(CONCAT(pe.per_nombre1 ,' ',pe.per_apellido1),'') NombreP , a.Ref_Cat, a.Ref_Año Anio,a.Ref_Num ,a.Ref_Lin ,a.Pro_Fecha , a.Residuo, "
        strSQL &= "     a.Id_Depreciacion, IFNULL(t.cat_clave,'') cat_clave , a.Costo_IVA, a.Porcentaje_IVA, a.Pro_Anios, a.Pro_Meses, a.Pro_Unidades, a.Pro_Horas,a.comments, a.Contrato "
        strSQL &= "             FROM Activos a  "
        strSQL &= "                 LEFT JOIN Tipos_Activo ta ON ta.Empresa = a.Empresa AND ta.Codigo = a.Id_Tipo "
        strSQL &= "                     LEFT JOIN Proveedores p ON p.pro_sisemp = a.Empresa AND p.pro_codigo = a.Id_Proveedor  "
        strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = a.Id_Moneda AND c.cat_clase = 'Monedas' "
        strSQL &= "                         LEFT JOIN Catalogos t ON t.cat_num = a.Id_Depreciacion AND t.cat_clase = 'Depreciacion'"
        strSQL &= "                             LEFT JOIN Personal pe ON pe.per_sisemp = a.Empresa AND pe.per_codigo  = a.Id_Usuario  "
        strSQL &= "                                 WHERE a.Empresa = {empresa} AND a.Codigo = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Public Sub CargarEncabezado(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim sFactura As String = ""
        Dim sSerieFac As String = ""
        Dim strFila As String = STR_VACIO

        Try
            strSQL = sqlEncabezado(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                dgDetalle.Rows.Clear()
                Do While REA.Read
                    celdaCodigo.Text = REA.GetInt32("Codigo")
                    celdaDescripcion.Text = REA.GetString("Descripcion")
                    celdaidTipo.Text = REA.GetInt32("idTipo")
                    celdaTipo.Text = REA.GetString("Tipo")
                    celdaMarca.Text = REA.GetString("Marca")
                    celdaModelo.Text = REA.GetString("Modelo")
                    celdaSerie.Text = REA.GetString("SN")
                    celdaColor.Text = REA.GetString("Color")
                    celdaProveedor.Text = REA.GetString("NombreProveedor")
                    celdaIdProveedor.Text = REA.GetInt32("idProveedor")
                    celdaFactura.Text = REA.GetString("Factura")
                    sFactura = REA.GetString("Factura")
                    sSerieFac = REA.GetString("Serie")
                    celdaSerieF.Text = REA.GetString("Serie")
                    dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaIdMoneda.Text = REA.GetInt32("Id_Moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaValorLibros.Text = REA.GetDouble("Valor").ToString(FORMATO_MONEDA)
                    celdaValorCompra.Text = REA.GetDouble("Precio").ToString(FORMATO_MONEDA)
                    celdaDepreciacion.Text = REA.GetInt32("Dias_Depreciados")
                    celdaDiasPendientes.Text = REA.GetInt32("Dias_Pendientes")
                    celdaidResponsable.Text = REA.GetInt32("Usuario")
                    celdaResponsable.Text = REA.GetString("NombreP")
                    celdaRefcat.Text = REA.GetInt32("Ref_Cat")
                    celdaRefAnio.Text = REA.GetInt32("Anio")
                    celdaRefNum.Text = REA.GetInt32("Ref_Num")
                    celdaResiduo.Text = REA.GetDouble("Residuo").ToString(FORMATO_MONEDA)
                    celdaIdTipoDep.Text = REA.GetInt32("Id_Depreciacion")
                    celdaTipoDep.Text = REA.GetString("cat_clave")
                    celdaCostoConIVA.Text = REA.GetDouble("Costo_IVA").ToString(FORMATO_MONEDA)
                    celdaPorcentaje.Text = REA.GetDouble("Porcentaje_IVA")
                    celdaVidaUtilAños.Text = REA.GetDouble("Pro_Anios")
                    celdaVidaUtilMeses.Text = REA.GetDouble("Pro_Meses")
                    celdaVidaUtilUnidades.Text = REA.GetDouble("Pro_Unidades")
                    celdaVidaUtilHoras.Text = REA.GetDouble("Pro_Horas")
                    CeldaComentario.Text = REA.GetString("comments")
                    celdaContrato.Text = REA.GetString("Contrato")

                    If REA.HasRows Then


                        'moficacion 03 - 03 - 2022 se agregaron los siguientes campos a la llamve primaria para
                        'ejercer como detalle de activos
                        'Ref_Cat,Ref_Ano,Ref_Num,Ref_lin



                        strFila = REA.GetInt32("Empresa") & "|"
                        strFila &= REA.GetInt32("Codigo") & "|"
                        strFila &= REA.GetInt32("Ref_Cat") & "|"
                        strFila &= REA.GetInt32("Ref_Ano") & "|"
                        strFila &= REA.GetInt32("Ref_Num") & "|"
                        strFila &= REA.GetString("Ref_Lin") & "|"
                        strFila &= sFactura & "|"
                        strFila &= sSerieFac & "|"
                        strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                        strFila &= REA.GetDouble("Precio") & "|"
                        strFila &= INT_UNO & " "





                        cFunciones.AgregarFila(dgDetalle, strFila)
                    End If
                Loop

            End If
            '  celdaCostoConIVA.Text = TotalizarFacturas()
            COM = Nothing
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function sqlDepreciacion(ByVal Codigo As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT d.dep_linea Linea , d.dep_fecha Fecha , d.dep_dias Dias , d.dep_monto Monto , d.dep_estado Estado  "
        strSQL &= "     FROM Depreciaciones d "
        strSQL &= "         WHERE d.dep_empresa = {empresa} And d.dep_codigo = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Public Sub CargarDepreciacion(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim dblResiduo As Double = INT_CERO
        Dim dblMonto As Double = INT_CERO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intFalta As Integer = INT_CERO
        dblResiduo = Math.Round((celdaValorCompra.Text - celdaResiduo.Text), 2) '* celdaTasa.Text, 2)

        strSQL = sqlDepreciacion(Codigo)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        dgDepreciacion.Rows.Clear()
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read

                dblMonto = REA.GetDouble("Monto")
                dblResiduo = (dblResiduo - dblMonto)
                strFila = REA.GetInt32("Linea") & "|"
                strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                strFila &= REA.GetDouble("Monto") & "|"
                strFila &= dblResiduo.ToString(FORMATO_MONEDA) & "|"
                strFila &= REA.GetInt32("Dias") & "|"
                strFila &= REA.GetInt32("Estado") & "|"
                strFila &= INT_UNO
                If REA.GetInt32("Estado") = INT_UNO Then
                    intFalta = intFalta + REA.GetInt32("Dias")
                    cfun.AgregarFila(dgDepreciacion, strFila, Color.SkyBlue)
                Else
                    cfun.AgregarFila(dgDepreciacion, strFila)
                End If
            Loop
        End If
        celdaDepreciacion.Text = intFalta
    End Sub
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(d.dep_linea),0) + 1  Codigo  "
        strSQL &= " FROM Depreciaciones d  "
        strSQL &= " WHERE d.dep_empresa = {empresa} And d.dep_codigo = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function NuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(a.Codigo),0) + 1  Codigo   "
        strSQL &= " FROM Activos a  "
        strSQL &= "     WHERE a.Empresa = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = True
        Dim IntId As Integer = NO_FILA
        Dim cActivos As New Tablas.TACTIVOS
        Try

            'Modificacion 03-03-2022
            'WC
            'se agrego un grid para que activos fijos tenga opcion de anclar varias facturas
            'al momento de guardar,actualizr o eliminar ahora se recorre el for next para verificacr en la ultima fila de grid
            'los tipos de accion a ejecutar en sql 
            'colExtra   0=insert,1=update,2=delete
            For iRow = 0 To dgDetalle.Rows.Count - 1
                With dgDetalle.Rows(iRow)


                    cActivos.CONEXION = strConexion
                    cActivos.EMPRESA = Sesion.IdEmpresa
                    cActivos.DESCRIPCION = celdaDescripcion.Text
                    cActivos.ID_TIPO = celdaidTipo.Text
                    cActivos.MARCA = celdaMarca.Text
                    cActivos.MODELO = celdaModelo.Text
                    cActivos.SN = celdaSerie.Text
                    cActivos.COLOR = celdaColor.Text
                    cActivos.ID_PROVEEDOR = celdaIdProveedor.Text

                    cActivos.FACTURA = IIf(.Cells("colFactura").Value = vbNullString, STR_VACIO, .Cells("colFactura").Value)
                    cActivos.SERIE = IIf(.Cells("ColSerieFac").Value = vbNullString, STR_VACIO, .Cells("ColSerieFac").Value)
                    cActivos.Fecha_NET = dtpFecha.Value
                    cActivos.ID_MONEDA = celdaIdMoneda.Text
                    cActivos.TASA = celdaTasa.Text
                    cActivos.PRECIO = CDbl(celdaValorCompra.Text)
                    cActivos.VALOR = CDbl(celdaValorLibros.Text)
                    cActivos.DIAS_DEPRECIADOS = celdaDepreciacion.Text
                    cActivos.DIAS_PENDIENTES = celdaDiasPendientes.Text
                    cActivos.ID_USUARIO = celdaidResponsable.Text

                    cActivos.REF_CAT = If(.Cells("colRef_Cat").Value = NO_FILA, 0, .Cells("colRef_Cat").Value)
                    cActivos.REF_AÑO = If(.Cells("colRef_Ano").Value = NO_FILA, 0, .Cells("colRef_Ano").Value)
                    cActivos.REF_NUM = If(.Cells("colRef_Num").Value = NO_FILA, 0, .Cells("colRef_Num").Value)
                    cActivos.REF_LIN = .Cells("colRef_Line").Value
                    cActivos.Pro_Fecha_NET = dtpInicioDep.Value
                    cActivos.RESIDUO = celdaResiduo.Text
                    cActivos.ID_DEPRECIACION = CDbl(celdaIdTipoDep.Text)
                    cActivos.COSTO_IVA = CDbl(celdaCostoConIVA.Text)
                    cActivos.PORCENTAJE_IVA = celdaPorcentaje.Text
                    cActivos.PRO_ANIOS = celdaVidaUtilAños.Text
                    cActivos.PRO_MESES = celdaVidaUtilMeses.Text
                    cActivos.PRO_UNIDADES = celdaVidaUtilUnidades.Text
                    cActivos.PRO_HORAS = celdaVidaUtilHoras.Text
                    cActivos.COMMENTS = CeldaComentario.Text
                    cActivos.CONTRATO = celdaContrato.Text

                    If .Cells("colExtra").Value.ToString.Trim = "0" Then

                        If logInsertar = True Then
                            If Me.Tag = "Nuevo" And dgDetalle.Rows.Count = 1 Then
                                If celdaCodigo.Text = NO_FILA Then
                                    IntId = NuevoCodigo()
                                    cActivos.CODIGO = IntId
                                Else
                                    IntId = celdaCodigo.Text
                                    cActivos.CODIGO = IntId
                                End If

                            End If
                            If cActivos.PINSERT = False Then
                                MsgBox(cActivos.MERROR.ToString)
                                Return False
                                Exit Function
                            Else
                                celdaCodigo.Text = IntId
                                '  If GuardarDepreciacion(IntId) Then
                                '  logResultado = True
                                '  Else
                                ' logResultado = False
                                '  End If
                                cFunciones.EscribirRegistro("Activos", clsFunciones.AccEnum.acAdd,
                                                        celdaCodigo.Text,
                                                        0, 0, celdaCodigo.Text,
                                                        Notas:=celdaDescripcion.Text)
                            End If
                        Else
                            MsgBox("You don't have permission to save ", vbInformation)
                            Return False
                            Exit Function
                        End If
                    End If
                    If .Cells("colExtra").Value.ToString.Trim = "1" Then
                        If logEditar = True Then
                            ''cambio efectuado 23 03 2022
                            '' autorizacion para realizar cambios
                            ' WC
                            ' version 3.3.12.77
                            If PedirAutorizacionMODPed("fixed assets") = False Then
                                MsgBox("You do not have authorization for this operation", vbInformation)
                                Encabezado1.botonGuardar.Enabled = True
                                Exit Function
                            End If


                            IntId = celdaCodigo.Text
                            cActivos.CODIGO = IntId
                            If cActivos.PUPDATE = False Then
                                MsgBox(cActivos.MERROR.ToString)
                                Return False
                                Exit Function
                            Else
                                '    If GuardarDepreciacion(IntId) Then
                                '   logResultado = True
                                '   Else
                                '  logResultado = False
                                'End If
                                cFunciones.EscribirRegistro("Activos", clsFunciones.AccEnum.acUpdate, celdaCodigo.Text, 0, 0, celdaCodigo.Text, Notas:=celdaDescripcion.Text)
                            End If

                        Else
                            MsgBox("You don't have permission to update ", vbInformation)
                            Return False
                            Exit Function
                        End If
                    End If
                    If .Cells("colExtra").Value.ToString.Trim = "2" Then
                        BorrarItemFactura(celdaCodigo.Text,
                                            .Cells("colRef_Cat").Value,
                                            .Cells("colRef_Ano").Value,
                                             .Cells("colRef_Num").Value,
                                             .Cells("colRef_Line").Value)
                    End If
                End With

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function PedirAutorizacionMODPed(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AutorizarModActivo"
        Dim frm As frmAutorización
        PedirAutorizacionMODPed = False

        frm = New frmAutorización
        frm.Iniciar(10, STR_MARGEN, 0, "Autorization Please")
        frm.etiquetaInfo.Text = "Need autorization by update this Document"
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionMODPed = True
                cfun.EscribirRegistro("Activos", clsFunciones.AccEnum.acConfirm, 0, 10,
                 "2022", celdaCodigo.Text, "Autorizacion a  " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
    Private Function BorrarItemFactura(v_codigo As String, v_Ref_Cat As String, v_Ref_Ano As String, v_Ref_Num As String, v_Ref_Lin As String)
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM  Activos  WHERE Empresa = {empresa} AND Codigo = {codigo} 
                                    and Ref_Cat = {Ref_Cat} and Ref_Año = {Ref_Ano} and Ref_Num = {Ref_Num} and Ref_Lin = {Ref_Lin}"


            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)

            strSQL = Replace(strSQL, "{Ref_Cat}", v_Ref_Cat)
            strSQL = Replace(strSQL, "{Ref_Ano}", v_Ref_Ano)
            strSQL = Replace(strSQL, "{Ref_Num}", v_Ref_Num)
            strSQL = Replace(strSQL, "{Ref_Lin}", v_Ref_Lin)




            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function GuardarDepreciacion(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cDepreciacion As New Tablas.TDEPRECIACIONES
        Try
            For i As Integer = 0 To dgDepreciacion.Rows.Count - 1
                cDepreciacion.DEP_EMPRESA = Sesion.IdEmpresa
                cDepreciacion.DEP_CODIGO = numero
                cDepreciacion.dep_fecha_NET = dgDepreciacion.Rows(i).Cells("colFecha").Value
                cDepreciacion.DEP_DIAS = dgDepreciacion.Rows(i).Cells("colDia").Value
                cDepreciacion.DEP_MONTO = dgDepreciacion.Rows(i).Cells("colMonto").Value
                cDepreciacion.DEP_ESTADO = dgDepreciacion.Rows(i).Cells("colEstado").Value



                Select Case dgDepreciacion.Rows(i).Cells("colMarca").Value
                    Case 0 'Guardar nueva Linea
                        dgDepreciacion.Rows(i).Cells("colLinea").Value = NuevaLinea(numero)
                        cDepreciacion.DEP_LINEA = dgDepreciacion.Rows(i).Cells("colLinea").Value
                        cDepreciacion.CONEXION = strConexion
                        If cDepreciacion.PINSERT = False Then
                            logResultado = False
                            MsgBox(cDepreciacion.MERROR.ToString)
                        End If
                    Case 1 'Actualizar Linea
                        cDepreciacion.DEP_LINEA = dgDepreciacion.Rows(i).Cells("colLinea").Value
                        cDepreciacion.CONEXION = strConexion
                        If cDepreciacion.PUPDATE = False Then
                            logResultado = False
                            MsgBox(cDepreciacion.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        cDepreciacion.DEP_LINEA = dgDepreciacion.Rows(i).Cells("colLinea").Value
                        cDepreciacion.CONEXION = strConexion
                        If cDepreciacion.PDELETE = False Then
                            logResultado = False
                            MsgBox(cDepreciacion.MERROR.ToString)
                        End If
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        'If celdaFactura.Text = vbNullString Then
        '    MsgBox("BLANK Invoice")
        '    celdaFactura.Focus()
        '    Comprobar = False
        '    Exit Function

        'End If
        ' If celdaIdProveedor.Text = NO_FILA Then
        'celdaIdProveedor.Focus()
        ' MsgBox("BLANK Provider")
        ' Comprobar = False
        'Exit Function
        ' End If
        'If celdaIdSolicitado.Text = vbNullString Then
        '    MsgBox("BLANK REQUESTED")
        '    Comprobar = False
        '    Exit Function
        'End If
        If celdaTasa.Text = INT_CERO Then
            MsgBox("BLANK Exchange Rate")
            Comprobar = False
            celdaTasa.Focus()
            Exit Function
        End If
        If celdaValorCompra.Text = INT_CERO.ToString(FORMATO_MONEDA) Then
            MsgBox("BLANK Purcharse Value")
            Comprobar = False
            celdaValorCompra.Focus()
            Exit Function
        End If
        If celdaIdMoneda.Text = INT_CERO Then
            MsgBox("BLANK Currency")
            Comprobar = False
            Exit Function
        End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgDepreciacion.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        Return LogVerdadero
    End Function
    Public Sub ValidarRetencion()
        If cfun.ValidarCampoNumerico(celdaValorCompra) = True Then
            If cfun.ValidarCampoNumerico(celdaTasa) = True Then
                'If Not CDbl(celdaValorCompra.Text) = CDbl(celdaValorLibros.Text) Then
                If (Me.Tag = "Nuevo") Then
                    'celdaValorLibros.Text = (celdaTasa.Text * celdaValorCompra.Text)
                    CalcularRetencion()
                ElseIf celdaDepreciacion.Text = INT_CERO Then
                    'celdaValorLibros.Text = (celdaTasa.Text * celdaValorCompra.Text)
                    'RecalcularRetencion()
                    If MsgBox("Va a modificar el valor de un activo ya depreciado" & vbCr & vbCr & "¿Desea continuar?", vbExclamation + vbYesNo + vbDefaultButton2, "Confirmar") = vbYes Then
                        ''Recalcular Retencion
                        'celdaValorLibros.Text = (celdaTasa.Text * celdaValorCompra.Text)
                        RecalcularRetencion()
                    End If
                End If
                'End If
            Else
                MsgBox("Blank Exchange Rate")
            End If
        Else
            MsgBox("Debe ingresar un dato numerico mayor que cero ", vbExclamation, "Aviso")
        End If
    End Sub
    Public Function ValidarDependencia() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logValidar As Boolean = True
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strTemp As String
        strSQL = "SELECT COUNT(*)"
        strSQL &= "     FROM Depreciaciones d "
        strSQL &= "  WHERE d.dep_empresa = {empresa} AND d.dep_codigo = {codigo} AND d.dep_estado = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Using conec
            strTemp = COM.ExecuteScalar
            COM.Dispose()
            COM = Nothing
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
        End Using
        If strTemp > 0 Then
            logValidar = False
        End If
        Return logValidar
    End Function
    'Bprrar Activo
    Public Function BorrarActivo() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM  Activos  WHERE Empresa = {empresa} AND Codigo = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Depreciacion 
    Public Function BorrarDepreciacion() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM  Depreciaciones  WHERE dep_empresa = {empresa} AND dep_codigo = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Function TotalizarFacturas() As Double
        Dim dTotal As Double
        If dgDetalle.Rows.Count = 0 Then Exit Function
        For ff = 0 To dgDetalle.Rows.Count - 1
            dTotal += dgDetalle.Rows(ff).Cells("colPrecio").Value
        Next
        Return dTotal
    End Function

    Private Function ValidatedItems(item As String) As Boolean
        Dim rValue As String
        For RowGrid = 0 To dgDetalle.Rows.Count - 1
            With dgDetalle.Rows(RowGrid)

                If .Cells("colFactura").Value = Nothing And dgDetalle.Rows.Count = 1 Then
                    Return True
                End If

                rValue = .Cells("colCodigo").Value.ToString.Trim &
                     Val(.Cells("colFactura").Value.ToString.Trim) &
                        .Cells("colSerieFac").Value.ToString.Trim &
                       .Cells("colRef_Cat").Value.ToString.Trim &
                       .Cells("colRef_Ano").Value.ToString.Trim &
                        .Cells("colRef_Num").Value.ToString.Trim
                If item = rValue Then
                    rValue = Nothing
                    item = Nothing
                    Return False
                End If
                '   Return True
            End With



        Next
        rValue = Nothing
        item = Nothing

        Return True
    End Function

    Public Sub BloqueodeTiposDepreciacion()

        If celdaTipoDep.Text = "Years" Then
            celdaVidaUtilAños.ReadOnly = False
            celdaVidaUtilMeses.ReadOnly = True
            celdaVidaUtilUnidades.ReadOnly = True
            celdaVidaUtilHoras.ReadOnly = True
        ElseIf celdaTipoDep.Text = "Units" Then
            celdaVidaUtilAños.ReadOnly = True
            celdaVidaUtilMeses.ReadOnly = True
            celdaVidaUtilUnidades.ReadOnly = False
            celdaVidaUtilHoras.ReadOnly = True
        ElseIf celdaTipoDep.Text = "Hours" Then
            celdaVidaUtilAños.ReadOnly = True
            celdaVidaUtilMeses.ReadOnly = True
            celdaVidaUtilUnidades.ReadOnly = True
            celdaVidaUtilHoras.ReadOnly = False
        End If


    End Sub

#End Region
#Region "Eventos"
    Private Sub frmActivosFijos_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accessos()
        celdaCostoConIVA.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaResiduo.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaPorcentaje.Text = INT_CERO.ToString(FORMATO_MONEDA)
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
        Encabezado1.botonBorrar.Enabled = False
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonTipo_Click(sender As Object, e As EventArgs) Handles botonTipo.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Type"
            frm.Campos = " Codigo Id, Descripcion "
            frm.Tabla = " Tipos_Activo "
            frm.FiltroText = " Enter The Name Of The Type To Filter "
            frm.Filtro = "  Descripcion  "
            frm.Condicion = " Empresa = " & Sesion.IdEmpresa & " ORDER BY Descripcion "

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaTipo.Text = frm.Dato
                celdaidTipo.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " cat_num Id, cat_desc Descripcion"
            frm.Tabla = " Catalogos  "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato

                strSQL = " SELECT cat_sist"
                strSQL &= "      FROM Catalogos"
                strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

                strSQL = Replace(strSQL, "{Numero}", frm.LLave)


                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    Cambio = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using
                If Cambio > 1 Then
                    celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = Cambio
                End If

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonProveeedor_Click(sender As Object, e As EventArgs) Handles botonProveeedor.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Provider"
            frm.Campos = " pro_codigo Id, pro_proveedor Descripcion"
            frm.Tabla = " Proveedores  "
            frm.FiltroText = " Enter The Name Of The Provider To Filter "
            frm.Filtro = "  pro_proveedor  "
            frm.Condicion = " pro_sisemp = " & Sesion.IdEmpresa '" ORDER BY pro_proveedor"
            frm.Ordenamiento = "pro_proveedor"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonResposable_Click(sender As Object, e As EventArgs) Handles botonResposable.Click
        Dim frm As New frmSeleccionar
        Dim strRemplazo As String = STR_VACIO
        strRemplazo = "per_sisemp = {empresa} And per_estado = 1"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Select a Responsible"
            frm.Campos = " per_codigo Id, CONCAT(per_nombre1,' ',per_nombre2,' ',per_apellido1,' ',per_apellido2) Descripcion"
            frm.Tabla = " Personal  "
            frm.FiltroText = " Enter The Name Of The responsible To Filter "
            frm.Filtro = "per_nombre1  "
            frm.Ordenamiento = "per_nombre1, per_nombre2, per_apellido1"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidResponsable.Text = frm.LLave
                celdaResponsable.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            intControlador = INT_CERO
            reset()
            CargarEncabezado(dgLista.SelectedCells(1).Value)
            CargarDepreciacion(dgLista.SelectedCells(1).Value)
            BloqueodeTiposDepreciacion()
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmActivosFijos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                '   If ComprobarFila() Then
                If Guardar() = True Then
                    MsgBox("save successful")
                    MostrarLista(True)
                End If
                ' End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaValorCompra_Validated(sender As Object, e As EventArgs) Handles celdaValorCompra.Validated
        'ValidarRetencion()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(0, 0, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, 0, 0, "Activos", dgLista.SelectedCells(1).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCalcular_Click(sender As Object, e As EventArgs) Handles botonCalcular.Click
        ValidarRetencion()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If ValidarDependencia() = False Then
                MsgBox("This Document can not be canceled, is related to other agencies", MsgBoxStyle.Critical, "Warning")
            Else
                If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                    BorrarActivo()
                    BorrarDepreciacion()
                    cFunciones.EscribirRegistro("Activos", clsFunciones.AccEnum.acDelete, celdaCodigo.Text, 0, 0, celdaCodigo.Text, Notas:=celdaDescripcion.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        End If
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
            dtpInicioDep.Value = DateSerial(Year(dtpFecha.Value), Month(dtpFecha.Value) + 2, vbEmpty)
        End If
    End Sub

    Private Sub panelDocumento_Paint(sender As Object, e As PaintEventArgs) Handles panelDocumento.Paint

    End Sub

    Private Sub celdaCostoConIVA_TextChanged(sender As Object, e As EventArgs) Handles celdaCostoConIVA.TextChanged
        '   If Me.Tag = "Nuevo" Then Exit Sub
        Dim dblPorcentajeIVA As Double = 0
        If Not celdaPorcentaje.Text = vbNullString Then
            dblPorcentajeIVA = CDbl(celdaPorcentaje.Text / 100)
            If celdaIdMoneda.Text = cfun.DivisaLocal Then
                celdaValorCompra.Text = (celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)).ToString(FORMATO_MONEDA)
                celdaValorLibros.Text = (celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)).ToString(FORMATO_MONEDA)
            Else
                celdaValorCompra.Text = ((celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)) * celdaTasa.Text).ToString(FORMATO_MONEDA)
            End If
        End If

    End Sub

    Private Sub celdaPorcentaje_TextChanged(sender As Object, e As EventArgs) Handles celdaPorcentaje.TextChanged
        Try
            If Not celdaPorcentaje.Text = vbNullString Then
                ' celdaCostoConIVA.Text >= 0 Then
                Dim dblPorcentajeIVA As Double = 0
                dblPorcentajeIVA = CDbl(celdaPorcentaje.Text / 100)
                If celdaIdMoneda.Text = cfun.DivisaLocal Then
                    celdaValorCompra.Text = (celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)).ToString(FORMATO_MONEDA)
                Else
                    celdaValorCompra.Text = ((celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)) * celdaTasa.Text).ToString(FORMATO_MONEDA)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub celdaResiduo_TextChanged(sender As Object, e As EventArgs) Handles celdaResiduo.TextChanged
        Try
            If celdaResiduo.Text <> "0.00" Then
                celdaValorLibros.Text = CDbl(celdaValorCompra.Text - celdaResiduo.Text).ToString(FORMATO_MONEDA)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Try
            frm.Titulo = "Select a Method"
            frm.Campos = " c.cat_num id, c.cat_clave Description"
            frm.Tabla = " Catalogos c  "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  cat_clave  "
            frm.Condicion = " c.cat_clase = 'Depreciacion'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaTipoDep.Text = frm.Dato
                celdaIdTipoDep.Text = frm.LLave
            End If
            BloqueodeTiposDepreciacion()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaValorCompra_TextChanged(sender As Object, e As EventArgs) Handles celdaValorCompra.TextChanged
        celdaValorLibros.Text = (celdaValorCompra.Text - celdaResiduo.Text).ToString(FORMATO_MONEDA)
    End Sub

    Private Sub celdaVidaUtilAños_TextChanged(sender As Object, e As EventArgs) Handles celdaVidaUtilAños.TextChanged
        If Not celdaVidaUtilAños.Text = vbNullString Then
            celdaVidaUtilMeses.Text = CDbl(celdaVidaUtilAños.Text * 12)
        End If

    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim intID As Integer
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim dblPorcentajeIVA As Double = 0
        Dim strFila As String = STR_VACIO
        Dim INT_SQL As String = 1 ' bandera para el abc transaccional de sql 
        Dim sIdItem As String = Nothing  ' recorre el grid para validar que no ingrese dos veces la misma factura

        Try

            intID = celdaIdProveedor.Text
            If intID > vbEmpty Then
                frm.Titulo = "Select a Invoice "
                frm.Campos = " HDoc_Doc_Fec date_, COALESCE(HDoc_DR1_Num,'') Reference, HDoc_Usuario User_, HDoc_RF1_Dbl Total, a.HDoc_Doc_Mon idCurrency, a.HDoc_Doc_TC TC ,(SELECT t.Tasa from TCambio t where t.Fecha <= a.HDoc_Doc_Fec LIMIT 1) Tasa,HDoc_Sis_Emp Company, HDoc_Doc_Cat Type_, HDoc_Doc_Ano Year_,DDoc_Doc_Num Number_,HDoc_DR2_Num Serie_ ,b.DDoc_Doc_Lin Line_, c.cat_desc Currency_"
                frm.Tabla = " Dcmtos_HDR a
                                LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num
                                LEFT JOIN TCambio t ON t.Fecha = a.HDoc_Doc_Fec
                                LEFT JOIN Catalogos c ON c.cat_num = a.HDoc_Doc_Mon  "
                frm.FiltroText = " Enter The Name Of The Invoice To Filter "
                frm.Filtro = "  HDoc_Doc_Num  "
                frm.Condicion = " HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND (HDoc_Doc_Cat = 44) AND (HDoc_Emp_Cod = " & intID & " ) AND HDoc_Doc_Status = 1 group by 1,2,3,4,5,6,7,8,9,10,11  ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "

                frm.ShowDialog(Me)
                If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                    sIdItem = celdaCodigo.Text.Trim &
                       Val(frm.ListaClientes.SelectedCells(1).Value.ToString.Trim) &
                        frm.ListaClientes.SelectedCells(11).Value.ToString.Trim &
                          frm.ListaClientes.SelectedCells(8).Value.ToString.Trim &
                            frm.ListaClientes.SelectedCells(9).Value.ToString.Trim &
                                frm.ListaClientes.SelectedCells(10).Value.ToString.Trim


                    If Not ValidatedItems(sIdItem) Then
                        MsgBox("Invoice has already been entered", vbInformation)
                        Exit Sub
                    End If



                    celdaFactura.Text = frm.ListaClientes.SelectedCells(1).Value
                    dtpFecha.Value = frm.ListaClientes.SelectedCells(0).Value
                    dtpInicioDep.Value = DateSerial(Year(dtpFecha.Value), Month(dtpFecha.Value) + 1, vbEmpty)
                    celdaRefcat.Text = frm.ListaClientes.SelectedCells(8).Value
                    celdaRefAnio.Text = frm.ListaClientes.SelectedCells(9).Value
                    celdaRefNum.Text = frm.ListaClientes.SelectedCells(10).Value
                    celdaIdMoneda.Text = frm.ListaClientes.SelectedCells(4).Value
                    celdaMoneda.Text = frm.ListaClientes.SelectedCells(13).Value ' simbolo de moneda
                    celdaTasa.Text = frm.ListaClientes.SelectedCells(5).Value ' TC de la factura
                    '  celdaCostoConIVA.Text = frm.ListaClientes.SelectedCells(3).Value
                    dblPorcentajeIVA = CDbl(celdaPorcentaje.Text / 100)




                    ' agrega la fila de facturas validando que no se ingresen varias veces
                    '    If Not ValidatedItems(celdaCodigo.Text &
                    'rm.ListaClientes.SelectedCells(1).Value & celdaCodigo.Text) Then

                    With dgDetalle.Rows(0)
                        If .Cells("colFactura").Value = vbNullString Then
                            .Cells("colIdEmpresa").Value = Sesion.IdEmpresa
                            .Cells("colCodigo").Value = celdaCodigo.Text
                            .Cells("colRef_Cat").Value = celdaRefcat.Text
                            .Cells("colRef_Ano").Value = celdaRefAnio.Text
                            .Cells("ColRef_Num").Value = celdaRefNum.Text
                            .Cells("colRef_Line").Value = dgDetalle.Rows.Count
                            .Cells("colFactura").Value = frm.ListaClientes.SelectedCells(1).Value
                            .Cells("colSerieFac").Value = frm.ListaClientes.SelectedCells(11).Value
                            .Cells("colFechaFactura").Value = dtpFecha.Value.ToString(FORMATO_MYSQL)
                            .Cells("colPrecio").Value = frm.ListaClientes.SelectedCells(3).Value

                            If Me.Tag = "Nuevo" Then
                                .Cells("colExtra").Value = "0"
                            Else
                                .Cells("colExtra").Value = "1"
                            End If
                        Else

                            strFila = Sesion.IdEmpresa & "|"
                            strFila &= celdaCodigo.Text & "|"
                            strFila &= celdaRefcat.Text & "|"
                            strFila &= celdaRefAnio.Text & "|"
                            strFila &= celdaRefNum.Text & "|"
                            strFila &= dgDetalle.Rows.Count + 1 & "|"
                            strFila &= frm.ListaClientes.SelectedCells(1).Value & "|"
                            strFila &= frm.ListaClientes.SelectedCells(11).Value & "|"
                            strFila &= dtpFecha.Value.ToString(FORMATO_MYSQL) & "|"
                            strFila &= frm.ListaClientes.SelectedCells(3).Value & "|"
                            INT_SQL = 0
                            strFila &= INT_SQL
                            cFunciones.AgregarFila(dgDetalle, strFila)
                        End If
                    End With
                    If Me.Tag = "Nuevo" Then
                        celdaCostoConIVA.Text = TotalizarFacturas()
                    End If

                    '58576512


                    If celdaIdMoneda.Text = cFunciones.DivisaLocal Then
                        celdaValorCompra.Text = (celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)).ToString(FORMATO_MONEDA)
                    Else
                        celdaValorCompra.Text = ((celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)) * celdaTasa.Text).ToString(FORMATO_MONEDA)
                    End If
                    celdaValorLibros.Text = CDbl(celdaValorCompra.Text - celdaResiduo.Text).ToString(FORMATO_MONEDA)

                    strSQL = " SELECT HDoc_DR2_Num Serie "
                    strSQL &= "     FROM Dcmtos_HDR "
                    strSQL &= "         WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat ={catalogo} AND HDoc_Doc_Ano ={anio} AND HDoc_Doc_Num ={numero} "
                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{catalogo}", frm.ListaClientes.SelectedCells(8).Value)
                    strSQL = Replace(strSQL, "{anio}", frm.ListaClientes.SelectedCells(9).Value)
                    strSQL = Replace(strSQL, "{numero}", frm.ListaClientes.SelectedCells(10).Value)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    celdaSerieF.Text = COM.ExecuteScalar
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()



                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Dim iRow As Integer = dgDetalle.CurrentCell.RowIndex

        If iRow = 0 And dgDetalle.Rows.Count > 1 Then
            MsgBox("Impossible to remove the Main Invoice when it still has others anchored", MsgBoxStyle.Information)
            Exit Sub
        End If

        If (MsgBox("are you sure to delete?", vbYesNo + vbQuestion)) = vbYes Then

            If dgDetalle.Rows.Count = 1 Then
                dgDetalle.Rows(0).Cells("colFactura").Value = vbNullString
                dgDetalle.Rows(0).Cells("colSerieFac").Value = vbNullString
                dgDetalle.Rows(dgDetalle.CurrentCell.RowIndex).Cells("colExtra").Value = 1
            Else

                dgDetalle.Rows(dgDetalle.CurrentCell.RowIndex).Cells("colExtra").Value = 2

                celdaCostoConIVA.Text = celdaCostoConIVA.Text - dgDetalle.Rows(dgDetalle.CurrentCell.RowIndex).Cells("colPrecio").Value
                dgDetalle.Rows(dgDetalle.CurrentCell.RowIndex).Visible = False
            End If
        End If
    End Sub

    Private Sub celdaTasa_TextChanged(sender As Object, e As EventArgs) Handles celdaTasa.TextChanged
        Try
            Dim dblPorcentajeIVA As Double = 0
            dblPorcentajeIVA = CDbl(celdaPorcentaje.Text / 100)
            If celdaTasa.Text <> STR_VACIO Or celdaTasa.Text <> vbNullString Then
                If celdaIdMoneda.Text = cFunciones.DivisaLocal Then
                    celdaValorCompra.Text = (celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)).ToString(FORMATO_MONEDA)
                Else
                    celdaValorCompra.Text = ((celdaCostoConIVA.Text / CDbl(1 + dblPorcentajeIVA)) * celdaTasa.Text).ToString(FORMATO_MONEDA)
                End If
                celdaValorLibros.Text = CDbl(celdaValorCompra.Text - celdaResiduo.Text).ToString(FORMATO_MONEDA)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region
End Class