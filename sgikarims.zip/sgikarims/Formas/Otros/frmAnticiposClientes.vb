﻿Public Class frmAnticiposClientes

#Region "Variables"
    Dim strKey As String = STR_VACIO
    Public logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
    Dim bandera As Boolean

    Private Const CATALOGO = 950
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub reset()
        celdaAño.Text = cfun.AñoMySQL
        celdaID.Text = STR_VACIO
        celdaTasa.Text = INT_UNO
        celdaidMoneda.Text = cfun.SimboloMoneda(cfun.DivisaLocal)
        celdaMoneda.Text = cfun.DivisaLocal
        celdaTitulo.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        celdaDescripcion.Text = STR_VACIO
        checkActivo.Checked = True
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFecha.Value = cfun.HoyMySQL
        dtpFechaDeposito.Value = cfun.HoyMySQL
        checkActivo.Checked = True
        checkContabilidad.Checked = False
        celdaNumeroDeposito.Text = INT_CERO
        celdaCatalogoDeposito.Text = INT_CERO
        celdaAnioDeposito.Text = INT_CERO
        celdaNumero.Text = INT_CERO
        botonAgregar.Enabled = True
        botonQuitar.Enabled = True
        bandera = False

    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Advances")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLIsta.Visible = True
            panelLIsta.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLIsta.Visible = False
            panelLIsta.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                reset()
            End If
            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Sub CalcularTotal()
        Dim dblGranTotal As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("colMarca").Value = 2 Then
                    dblTotal = CDbl(dgDetalle.Rows(i).Cells("colSaldo").Value)
                    dblGranTotal = dblGranTotal + dblTotal
                End If
            Next
            celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            strSql = " SELECT l1.Anio,l1.Numero,l1.Fecha,l1.Titulo,l1.Descripcion,l1.Estado, l1.Monto monto, Moneda
                        FROM (
                        SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha , h.HDoc_Emp_Nom Titulo, h.HDoc_Emp_Dir Descripcion, if(h.HDoc_Doc_Status= 0 ,'CANCELED', 'ACTIVE') Estado, ifnull(SUM(d.DDoc_Prd_NET),h.HDoc_RF3_Dbl)  Monto,  c.cat_clave Moneda
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                        LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 950 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}'
                        GROUP BY h.HDoc_Doc_Ano,h.HDoc_Doc_Num
                        ORDER BY h.HDoc_Doc_Num desc)l1"

            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSql = strSql.Replace("{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Private Function BuscarDetalle(ByVal Anio As Integer, ByVal Num As Integer) As Boolean
        Dim validacion As Boolean = True
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim conec As New MySqlConnection
        Try
            strSql = " SELECT *
                       FROM Dcmtos_HDR h
                       INNER JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                       WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 950 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}"

            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{anio}", Anio)
            strSql = strSql.Replace("{num}", Num)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSql, conec)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                validacion = False
            End If
            conec.Close()
            conec.Dispose()
            conec = Nothing

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return validacion
    End Function

    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Dim Anio As Integer
        Dim Numero As Integer
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read

                    strLinea = REA.GetInt32("Anio") & "|" 'Año
                    Anio = REA.GetInt32("Anio")
                    strLinea &= REA.GetInt32("Numero") & "|" 'Numero 
                    Numero = REA.GetInt32("Numero")
                    strLinea &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|" 'Fecha
                    strLinea &= REA.GetString("Titulo") & "|"  ' Titulo 
                    strLinea &= REA.GetString("Descripcion") & "|"  ' descripcion 
                    strLinea &= REA.GetDouble("monto").ToString(FORMATO_MONEDA) & "|"  ' monto
                    strLinea &= INT_CERO.ToString(FORMATO_MONEDA) & "|"  ' saldo
                    strLinea &= REA.GetString("Moneda") & "|"  ' Moneda
                    strLinea &= REA.GetString("Estado") ' Estado
                    If REA.GetString("Estado") = "CANCELED" Then
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    ElseIf BuscarDetalle(Anio, Numero) Then
                        cFunciones.AgregarFila(dgLista, strLinea, Color.LightYellow)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea)
                    End If
                Loop


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 950)
        strSQL = Replace(strSQL, "{anio}", dtpFecha.Value.Year)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva


    End Function
    Public Function Guardar(Optional tipo As Integer = 0) As Boolean
        Dim logResultado As Boolean = True
        Dim IntId As Integer = NO_FILA
        Dim chdr As New clsDcmtos_HDR
        Try

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 950
            chdr.HDOC_DOC_ANO = dtpFecha.Value.Year

            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value
            chdr.HDoc_DR1_Fec_NET = dtpFechaDeposito.Value
            chdr.HDOC_EMP_NOM = celdaTitulo.Text
            chdr.HDOC_EMP_DIR = celdaDescripcion.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text
            chdr.HDOC_DOC_MON = celdaMoneda.Text
            chdr.HDOC_USUARIO = Sesion.Usuario
            chdr.HDOC_PRO_DNUM = celdaNumeroDeposito.Text
            chdr.HDOC_PRO_DCAT = celdaCatalogoDeposito.Text
            chdr.HDOC_PRO_DANO = celdaAnioDeposito.Text
            If tipo = 1 Then
                chdr.HDOC_RF2_DBL = 0
                chdr.HDOC_RF3_DBL = Math.Round((CDbl(celdaMonto.Text) - CDbl(celdaTotal.Text)), 2)
            Else
                chdr.HDOC_RF2_DBL = celdaTotal.Text
                chdr.HDOC_RF3_DBL = celdaMonto.Text
            End If

            If dgDetalle.Rows.Count = 0 Or tipo = 1 Then
                checkContabilidad.Checked = False
            End If
            If checkContabilidad.Checked = True Then
                chdr.HDOC_ANT_COM = INT_UNO
            Else
                chdr.HDOC_ANT_COM = INT_CERO
            End If

            If dgDetalle.Rows.Count = 0 Then
                checkContabilidad.Checked = False
            End If
            If checkActivo.Checked = True Then
                chdr.HDOC_DOC_STATUS = INT_UNO
            Else
                chdr.HDOC_DOC_STATUS = INT_CERO
            End If
            chdr.CONEXION = strConexion
            If Me.Tag = "Nuevo" Or tipo = 1 Then
                If logInsertar = True Then
                    IntId = AnticipoCliente()
                    chdr.HDOC_DOC_NUM = IntId
                    If chdr.Guardar = False Then

                        MsgBox(chdr.MERROR.ToString)
                        Return False
                        Exit Function
                    Else
                        ' Me.Tag = "mod"
                        celdaID.Text = IntId
                        cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acAdd, 0, 950, chdr.HDOC_DOC_ANO, chdr.HDOC_DOC_NUM)
                    End If
                Else
                    MsgBox("You don't have permission to save ")
                    Return False
                    Exit Function
                End If
            Else
                If logEditar = True Then
                    IntId = celdaID.Text
                    chdr.HDOC_DOC_NUM = IntId
                    If chdr.Actualizar = False Then

                        MsgBox(chdr.MERROR.ToString)
                        Return False
                        Exit Function
                    Else
                        cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acUpdate, 0, 950, chdr.HDOC_DOC_ANO, chdr.HDOC_DOC_NUM)
                    End If
                Else
                    MsgBox("You don't have permission to update ")
                    Return False
                    Exit Function
                End If
            End If

            If tipo = 1 Then
                Exit Function
            End If
            If dgDetalle.Rows.Count > 0 Then

                If GuardarDetalle(IntId) Then
                    If GuardarECtaCte(IntId) Then
                        If Me.Tag = "Nuevo" Then
                            Dim conta As New clsContabilidad
                            If cfun.SQLVerificarCierre(950, dtpFecha.Value.Year, celdaID.Text) = 0 Then
                                conta.GenerarPoliza(950, dtpFecha.Value.Year, celdaID.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
                            Else
                                conta.GenerarPoliza(950, dtpFecha.Value.Year, celdaID.Text, cfun.HoyMySQL.ToString(FORMATO_MYSQL))
                            End If

                        End If

                        Return True
                    Else
                        logResultado = False
                    End If
                Else
                    logResultado = False
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function GuardarDetalle(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cdtl As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                cdtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                cdtl.DDOC_DOC_CAT = 950
                cdtl.DDOC_DOC_ANO = dtpFecha.Value.Year
                cdtl.DDOC_DOC_NUM = numero

                If Sesion.IdEmpresa = 10 Then
                    cdtl.DDOC_RF1_NUM = 296
                Else
                    cdtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCat").Value
                End If
                'cdtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colFactura").Value
                cdtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colAno").Value
                cdtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colNumero").Value
                cdtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colSaldo").Value


                Select Case dgDetalle.Rows(i).Cells("colMarca").Value
                    Case 0 'Guardar nueva Linea
                        If i = 0 Then
                            bandera = True
                        End If

                        dgDetalle.Rows(i).Cells("colLinea").Value = NuevaLinea(numero)
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Guardar = False Then
                            logResultado = False
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Case 1 'Actualizar Linea
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Actualizar = False Then
                            logResultado = False
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Borrar = False Then
                            logResultado = False
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function GuardarECtaCte(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim ctate As New Tablas.TECTACTE
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                ctate.ECTA_SIS_EMP = Sesion.IdEmpresa
                ctate.ECTA_DOC_CAT = 950
                ctate.ECTA_DOC_ANO = dtpFecha.Value.Year
                ctate.ECTA_DOC_NUM = numero
                ctate.ECTA_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                If Sesion.IdEmpresa = 10 Then
                    ctate.ECTA_REF_CAT = 296
                Else
                    ctate.ECTA_REF_CAT = dgDetalle.Rows(i).Cells("colCat").Value
                End If

                ctate.ECTA_REF_ANO = dgDetalle.Rows(i).Cells("colAno").Value
                ctate.ECTA_REF_NUM = dgDetalle.Rows(i).Cells("colNumero").Value
                ctate.ECta_FecVenc_NET = dtpFecha.Value
                ctate.ECta_FecDcmt_NET = dtpFecha.Value
                ctate.ECTA_MONEDA = celdaMoneda.Text
                ctate.ECTA_TC = celdaTasa.Text
                ctate.ECTA_TRANSID = INT_CERO
                ctate.ECTA_TIPOEMP = 0
                ctate.ECTA_CONCEPTO = celdaTitulo.Text

                If checkActivo.Checked = True Then
                    If celdaMoneda.Text = 178 Then
                        ctate.ECTA_ABNO_EXT = dgDetalle.Rows(i).Cells("colSaldo").Value
                    Else
                        ctate.ECTA_ABNO_LOC = dgDetalle.Rows(i).Cells("colSaldo").Value
                    End If
                Else
                    ctate.ECTA_ABNO_EXT = INT_CERO
                    ctate.ECTA_ABNO_LOC = INT_CERO
                End If


                ctate.CONEXION = strConexion
                Select Case dgDetalle.Rows(i).Cells("colMarca").Value
                    Case 0 'Guardar nueva Linea
                        If ctate.PINSERT = False Then
                            logResultado = False
                            MsgBox(ctate.MERROR.ToString)
                        Else
                            dgDetalle.Rows(i).Cells("colMarca").Value = 1
                        End If
                    Case 1 'Actualizar Linea
                        ctate.CONEXION = strConexion
                        If ctate.PUPDATE = False Then
                            logResultado = False
                            MsgBox(ctate.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        ctate.CONEXION = strConexion
                        EliminarEctate(dtpFecha.Value.Year, numero, dgDetalle.Rows(i).Cells("colLinea").Value)
                        If ctate.PDELETE = False Then
                            logResultado = False
                            MsgBox(ctate.MERROR.ToString)
                        End If
                End Select
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
            logResultado = False
        End Try
        Return logResultado
    End Function
    Private Sub CargarEncabezado(ByVal ano As Integer, ByVal numero As Integer)
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQl = " SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha , h.HDoc_Emp_Nom Titulo, h.HDoc_Emp_Dir Descripcion, 0 monto , 
                        if(h.HDoc_Doc_Status= 0 ,'CANCELED', 'ACTIVE') Estado,h.HDoc_Doc_TC Tasa , h.HDoc_Doc_Mon idMoneda, c.cat_clave moneda, h.HDoc_Ant_Com Conta,
                        CAST(IFNULL(h.HDoc_DR1_Fec,h.HDoc_Doc_Fec) AS date) FechaDeposito, h.HDoc_RF2_Dbl total, h.HDoc_RF3_Dbl montoAnt,h.HDoc_Pro_DCat CatalogoDeposito, 
                        h.HDoc_Pro_DNum NumeroDeposito, h.HDoc_Pro_DAno AnoDeposito, IFNULL(hh.HDoc_DR1_Num,0) Deposito                       
                        FROM Dcmtos_HDR h
                            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon
                            LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND hh.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND hh.HDoc_Doc_Num = h.HDoc_Pro_DNum
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 950 and  h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "

            strSQl = strSQl.Replace("{empresa}", Sesion.IdEmpresa)
            strSQl = strSQl.Replace("{ano}", ano)
            strSQl = strSQl.Replace("{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaID.Text = REA.GetInt32("Numero")
                    celdaAño.Text = REA.GetInt32("Anio")
                    dtpFecha.Value = REA.GetDateTime("Fecha")
                    celdaTitulo.Text = REA.GetString("Titulo")
                    celdaDescripcion.Text = REA.GetString("Descripcion")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaMoneda.Text = REA.GetInt32("idMoneda")
                    celdaidMoneda.Text = REA.GetString("moneda")
                    celdaTotal.Text = REA.GetDouble("total").ToString(FORMATO_MONEDA)
                    celdaMonto.Text = REA.GetDouble("montoAnt").ToString(FORMATO_MONEDA)
                    celdaCatalogoDeposito.Text = REA.GetInt32("CatalogoDeposito")
                    celdaAnioDeposito.Text = REA.GetInt32("AnoDeposito")
                    celdaNumeroDeposito.Text = REA.GetInt32("NumeroDeposito")
                    dtpFechaDeposito.Value = REA.GetDateTime("FechaDeposito").ToString(FORMATO_MYSQL)
                    celdaNumero.Text = REA.GetInt32("Deposito")

                    If REA.GetInt32("Conta") = INT_UNO Then
                        checkContabilidad.Checked = True
                    Else
                        checkContabilidad.Checked = False
                    End If
                    If REA.GetString("Estado") = "CANCELED" Then
                        checkActivo.Checked = False
                    Else
                        checkActivo.Checked = True
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarDetalle(ByVal ano As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = " SELECT c.HDoc_Doc_Ano Anio , c.HDoc_Doc_Num  Numero, c.HDoc_Doc_Fec  Fecha,
                        if(c.HDoc_Doc_Cat=36, c.HDoc_DR1_Dbl, IF(c.HDoc_DR1_Num=0, d.DDoc_RF3_Num,c.HDoc_DR1_Num)) Numero_,
                        c.HDoc_Emp_Nom Proveedor, m.cat_clave Moneda, d.DDoc_Prd_NET Monto, d.DDoc_Doc_Lin linea {fact},
                        d.DDoc_RF1_Num Cat
                        FROM Dcmtos_HDR h
	                    inner JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
	                    LEFT JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND c.HDoc_Doc_Cat = d.DDoc_RF1_Num AND c.HDoc_Doc_Ano = d.DDoc_RF2_Num AND c.HDoc_Doc_Num = d.DDoc_RF3_Num 
	                    LEFT JOIN Catalogos m ON m.cat_num = c.HDoc_Doc_Mon 
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 950 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero}  "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ano}", ano)
            strSQL = strSQL.Replace("{numero}", numero)
            If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                strSQL = strSQL.Replace("{fact}", ", if(c.HDoc_Doc_Cat=36,c.HDoc_DR1_Num,c.HDoc_Doc_Num) Fact")
            Else
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                    strSQL = strSQL.Replace("{fact}", ", c.HDoc_DR1_Dbl Fact")
                Else
                    strSQL = strSQL.Replace("{fact}", ", c.HDoc_Doc_Num Fact")
                End If
            End If


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Cat") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetMySqlDateTime("Fecha").ToString & "|"
                    strFila &= REA.GetString("fact") & "|"
                    strFila &= REA.GetString("Numero_") & "|"
                    strFila &= REA.GetString("Proveedor") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= "1|"
                    strFila &= REA.GetInt32("Linea")

                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
                CalcularTotal()
                botonAgregar.Enabled = False
                botonQuitar.Enabled = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Borrar()
        Dim strSql As String = STR_VACIO
        Try
            'BORRAR ENCABEZADO

            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = CATALOGO
            hdr.HDOC_DOC_ANO = dtpFecha.Value.Year
            hdr.HDOC_DOC_NUM = celdaID.Text
            hdr.Borrar()
            ' BORRAR DETALLE
            strSql = STR_VACIO
            strSql = "DDoc_Sis_Emp = {empresa} and  DDoc_Doc_Cat ={cata} and  DDoc_Doc_Ano = {ano}  and DDoc_Doc_Num = {numero} "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{cata}", CATALOGO)
            strSql = strSql.Replace("{ano}", dtpFecha.Value.Year)
            strSql = strSql.Replace("{numero}", celdaID.Text)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSql)

            'BORRAR ECTATE

            strSql = STR_VACIO
            strSql = "ECta_Sis_Emp = {empresa} and  ECta_Doc_Cat ={cata} and  ECta_Doc_Ano = {ano}  and ECta_Doc_Num = {numero} "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{cata}", CATALOGO)
            strSql = strSql.Replace("{ano}", dtpFecha.Value.Year)
            strSql = strSql.Replace("{numero}", celdaID.Text)

            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSql)

            '  BORRAR POLIZA
            cfun.BorrarEncabezadoPoliza(celdaID.Text, dtpFecha.Value.Year, 950)
            cfun.BorrarDetallePoliza(celdaID.Text, dtpFecha.Value.Year, 950)

            cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acDelete, 0, 950, dtpFecha.Value.Year, celdaID.Text)

            MostrarLista(True)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarEctate(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {cata}  and ECta_Doc_Ano = {anio} and ECta_Doc_Num = {numero} AND ECta_Doc_Lin = {linea} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{numero}", Numero)
            strSQL = Replace(strSQL, "{linea}", Linea)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function AnticipoCliente() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 950)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
#End Region

#Region "Eventos"
    Private Sub frmAnticiposClientes_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFin.Value = Today
        dtpInicio.Value = dtpFin.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
    End Sub
    Private Sub frmAnticiposClientes_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cfun.TasaSegunFecha(dtpFechaDeposito.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If

                dgDetalle.Rows.Clear()
                celdaTotal.Text = "0.00"
                celdaMonto.Text = "0.00"

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim op As New frmOption
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim catFact As Integer = INT_CERO
        Dim NumDoc As String = STR_VACIO
        Dim strCorrelativo As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strLLave As String = STR_VACIO
        Dim strJoin As String = STR_VACIO
        Dim applyBalance As String = STR_VACIO
        Dim applyMultiCat As String = STR_VACIO

        Try
            op.Titulo = "Document Type"
            op.Mensaje = "Choose the type of document"
            If Sesion.IdEmpresa = 18 Or Sesion.IdEmpresa = 19 Or Sesion.IdEmpresa = 21 Then
                op.Opciones = "Sales Invoice|Debit Note"
            Else
                op.Opciones = "Sales Invoice"
            End If

            op.ShowDialog(Me)

            If op.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If op.Seleccion = 0 Then
                    If Sesion.IdEmpresa = 10 Then
                        catFact = 296
                        strCampos = "A._Date, A.Correlative, A._Number, A.Currency, (A.Balance + IF(A.HDoc_DR1_Cat = 2 AND A.Estado = 1, SUM(IFNULL(dd.DDoc_RF4_Dbl,0)), SUM(IFNULL(d.DDoc_RF4_Dbl,0))) )Balance, A.Vendor, A._Year, A.ID
                                FROM (
                                SELECT "

                        NumDoc = "h.HDoc_Doc_Num _Number"
                        strCorrelativo = " h.HDoc_Doc_Num Correlative, "
                        strLLave = ",h.HDoc_Sis_Emp Empresa, h.HDoc_Doc_Cat Catalogo, h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Num, h.HDoc_DR1_Cat, h.HDoc_Doc_Status Estado"
                        strJoin = ") AS A
                            LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp =A.Empresa AND hh.HDoc_Pro_DCat = A.Catalogo AND hh.HDoc_Pro_DAno = A.Anio -- 303
                            AND hh.HDoc_Pro_DNum = A.Num AND hh.HDoc_Doc_Cat=303 AND hh.HDoc_Doc_Status = 1
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND d.DDoc_Doc_Num = hh.HDoc_Doc_Num AND d.DDoc_Prd_Ref='comp'
                            LEFT JOIN Dcmtos_DTL dd ON dd.DDoc_Sis_Emp = A.Empresa AND dd.DDoc_Doc_Cat = A.Catalogo AND dd.DDoc_Doc_Ano = A.Anio 
									 AND dd.DDoc_Doc_Num = A.Num AND dd.DDoc_Prd_Ref='comp'"
                    ElseIf Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
                        catFact = 36
                        strJoin = ") as A"
                        NumDoc = "h.HDoc_DR1_Num _Number"
                        frm.Condicion = "1=1"
                        strCorrelativo = " h.HDoc_DR1_Dbl Correlative, "
                    Else
                        catFact = 36
                        strJoin = ") as A"
                        NumDoc = "h.HDoc_DR1_Num _Number"
                        frm.Condicion = "1=1"
                        strCorrelativo = " h.HDoc_Doc_Num Correlative, "
                    End If

                    If Sesion.IdEmpresa = 10 Then
                        frm.Campos = "A._Date, A.Correlative, A._Number, A.Currency, (A.Balance +  IF(A.HDoc_DR1_Cat = 2 AND A.Estado = 1, SUM(IFNULL(dd.DDoc_RF4_Dbl,0)), SUM(IFNULL(d.DDoc_RF4_Dbl,0))))Balance, A.Vendor, A._Year, A.ID"
                        frm.Condicion = "1=1"
                        frm.Agrupar = " A.Num, A.Anio "
                    Else
                        frm.Campos = "_Date, Correlative, _Number, Currency, Balance, Vendor, _Year, ID  "
                    End If
                    applyMultiCat = "h.HDoc_Doc_Cat"
                    applyBalance = " HAVING ABS(Balance) >= 0.01 "
                ElseIf op.Seleccion = 1 Then
                    catFact = 32
                    strJoin = ") as A"
                    NumDoc = "IF(h.HDoc_DR1_Num=0,h.HDoc_Doc_Num,h.HDoc_DR1_Num) _Number"
                    frm.Condicion = "1=1"
                    strCorrelativo = " h.HDoc_Doc_Num Correlative, "

                    frm.Campos = "_Date, Correlative, _Number, Currency, Balance, Vendor, _Year, ID  "
                    applyMultiCat = "h.HDoc_Doc_Cat, 36"
                End If
                frm.Titulo = " Select a Debit Note "
                frm.FiltroText = " Type the debit note number to filter  "

                frm.Tabla = "(                    
                    Select h.HDoc_Doc_Fec _Date, " & strCorrelativo & NumDoc & " ,m.cat_clave Currency, 
                    ROUND((CASE WHEN h.HDoc_Doc_Mon = 178 THEN (SUM(c.ECta_Crgo_Ext)- SUM(c.ECta_Abno_Ext)) Else (SUM(c.ECta_Crgo_Loc)- SUM(c.ECta_Abno_Loc)) End),2) Balance, 
                    h.HDoc_Emp_Nom Vendor, h.HDoc_Doc_Ano _Year, h.HDoc_Doc_Num ID
                    " & strLLave & "
                    From Dcmtos_HDR h
                    INNER Join ECtaCte c ON c.ECta_Sis_Emp = h.HDoc_Sis_Emp And c.ECta_Ref_Cat IN (" & applyMultiCat & ") And c.ECta_Ref_Ano = h.HDoc_Doc_Ano And c.ECta_Ref_Num = h.HDoc_Doc_Num
                    Left Join Catalogos m ON m.cat_num = h.HDoc_Doc_Mon
                    WHERE h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " And h.HDoc_Doc_Cat = " & catFact & " And h.HDoc_Doc_Mon = " & celdaMoneda.Text & "
                    GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num " & applyBalance & strJoin

                frm.Ordenamiento = " _Date   "
                frm.Filtro = " Correlative "
                frm.Limite = 25
                frm.ShowDialog(Me)
                If frm.DialogResult = DialogResult.OK Then
                    'If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Or Sesion.idGiro = 2 Then
                    strFila = frm.DataGrid.SelectedCells(6).Value & "|" ' año
                    strFila &= catFact.ToString & "|" ' catalogo
                    strFila &= frm.DataGrid.SelectedCells(7).Value & "|" ' numero
                    strFila &= frm.DataGrid.SelectedCells(0).Value & "|" ' fecha
                    strFila &= frm.DataGrid.SelectedCells(1).Value & "|" ' Factura
                    strFila &= frm.DataGrid.SelectedCells(2).Value & "|" ' numero dr1
                    strFila &= frm.DataGrid.SelectedCells(5).Value & "|" ' proveedor
                    strFila &= frm.DataGrid.SelectedCells(3).Value & "|" ' moneda
                    strFila &= frm.DataGrid.SelectedCells(4).Value & "|" ' saldo
                    strFila &= "0"

                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        If dgDetalle.Rows(i).Cells("colAno").Value = frm.DataGrid.SelectedCells(6).Value And dgDetalle.Rows(i).Cells("colNumero").Value = frm.DataGrid.SelectedCells(7).Value And Not dgDetalle.CurrentRow.Cells("colMarca").Value = 2 Then
                            Exit Sub
                        End If
                    Next

                    cFunciones.AgregarFila(dgDetalle, strFila)

                    CalcularTotal()
                    If dgDetalle.Rows.Count > 0 Then
                        checkContabilidad.Checked = True
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        CargarLista()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLIsta.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Try
            If MsgBox("Are you sure you want to delete this row? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                dgDetalle.CurrentRow.Cells("colMarca").Value = 2
                dgDetalle.CurrentRow.Visible = False
                CalcularTotal()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotal()
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim dtFechaConta As Date
        Dim conta As New clsContabilidad
        Dim dblSaldo As Double = 0

        If CDbl(celdaMonto.Text) > 0 Then
            If CDbl(celdaTotal.Text) > 0 Then
                dblSaldo = CDbl(celdaMonto.Text) - CDbl(celdaTotal.Text)
            Else
                dblSaldo = 0
            End If
        Else
            MsgBox("the advance must have value", vbInformation, "Notice")
            Exit Sub
        End If

        If dblSaldo < 0 Then
            MsgBox("The total cannot exceed the amount of the advance", vbInformation, "Notice")
        Else
            If Me.Tag = "Nuevo" Then
                If Guardar() Then
                    MsgBox("Document saved")
                    MostrarLista()
                End If
            Else

                'Captura la fecha
                dtFechaConta = cfun.SQLValidarFechaContable(950, dtpFecha.Value.Year, celdaID.Text)
                'Verifica si hay cierre
                If cfun.SQLVerificarCierre(950, dtpFecha.Value.Year, celdaID.Text, dtpFecha.Value) = 0 Then
                    If Guardar() Then
                        conta.GenerarPoliza(950, dtpFecha.Value.Year, celdaID.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                        MsgBox("Document saved")
                        If dblSaldo > 0 Then
                            If bandera = True Then
                                MsgBox("The amount of the advance is greater than the documents," & vbCrLf & "a new advance will be created with the available balance", vbInformation, "Notice")
                                Guardar(1)
                            End If

                        End If
                        MostrarLista()
                    End If
                Else
                    'Si hay cierre solicita autorización
                    MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                    If cFunciones.AutorizarCambios = True Then
                        cfun.EscribirRegistro("HDR", clsFunciones.AccEnum.acConfirm, celdaID.Text, 950, dtpFecha.Value.Year, celdaID.Text, "Autorizó Modificación")
                        If Guardar() Then
                            conta.GenerarPoliza(950, dtpFecha.Value.Year, celdaID.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                            MsgBox("Document saved")
                            If dblSaldo > 0 Then
                                If bandera = True Then
                                    MsgBox("The amount of the advance is greater than the documents," & vbCrLf & "a new advance will be created with the available balance", vbInformation, "Notice")
                                    Guardar(1)
                                End If
                            End If
                            MostrarLista(False)
                        End If
                    End If
                End If

            End If
        End If



    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Do you want to delete this document? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Borrar()
            End If
        Else
            MsgBox("You don't have permission to delete")
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"

            BarraTitulo1.CambiarTitulo("Modificar Registro")
            reset()
            CargarEncabezado(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)

            CargarDetalle(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonPolizaContable_Click(sender As Object, e As EventArgs) Handles botonPolizaContable.Click
        Dim cls As New clsPolizaContable

        cls.Tipo = 950
        cls.Ciclo = dtpFecha.Value.Year
        cls.Numero = celdaID.Text
        cls.Modo = 28

        cls.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(950, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 950)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged

    End Sub

    Private Sub dtpFechaDeposito_ValueChanged(sender As Object, e As EventArgs) Handles dtpFechaDeposito.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFechaDeposito.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub


#End Region

End Class