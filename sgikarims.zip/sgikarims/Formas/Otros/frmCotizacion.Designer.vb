﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCotizacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCotizacion))
        Me.panelLIsta = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.ano = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.code = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.fecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.activo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.botonFiltrar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.PanelDatos = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.cod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Yarn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idorigen = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.source = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ultimo_precio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ultimo_pedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idprograma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.program = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.available = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.idpoveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.proveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.celdaPo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaReservado = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaOrden = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaInventario = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgInventario = New System.Windows.Forms.DataGridView()
        Me.dgReservado = New System.Windows.Forms.DataGridView()
        Me.dgPO = New System.Windows.Forms.DataGridView()
        Me.dgOrden = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaEstado = New System.Windows.Forms.Button()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaIdPagare = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaIdCliente = New System.Windows.Forms.Label()
        Me.botonBuscarCliente = New System.Windows.Forms.Button()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.CeldaMonto = New System.Windows.Forms.TextBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLIsta.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.PanelDatos.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.dgInventario, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgReservado, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgPO, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgOrden, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLIsta
        '
        Me.panelLIsta.Controls.Add(Me.dgLista)
        Me.panelLIsta.Controls.Add(Me.panelFiltro)
        Me.panelLIsta.Location = New System.Drawing.Point(917, 284)
        Me.panelLIsta.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelLIsta.Name = "panelLIsta"
        Me.panelLIsta.Size = New System.Drawing.Size(399, 284)
        Me.panelLIsta.TabIndex = 4
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ano, Me.code, Me.fecha, Me.cliente, Me.estado, Me.activo})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 101)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(399, 183)
        Me.dgLista.TabIndex = 1
        '
        'ano
        '
        Me.ano.HeaderText = "ano"
        Me.ano.Name = "ano"
        Me.ano.ReadOnly = True
        Me.ano.Visible = False
        '
        'code
        '
        Me.code.HeaderText = "Code"
        Me.code.Name = "code"
        Me.code.ReadOnly = True
        '
        'fecha
        '
        DataGridViewCellStyle1.Format = "d"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.fecha.DefaultCellStyle = DataGridViewCellStyle1
        Me.fecha.HeaderText = "Date"
        Me.fecha.Name = "fecha"
        Me.fecha.ReadOnly = True
        '
        'cliente
        '
        Me.cliente.HeaderText = "Customer"
        Me.cliente.Name = "cliente"
        Me.cliente.ReadOnly = True
        Me.cliente.Width = 250
        '
        'estado
        '
        Me.estado.HeaderText = "Status"
        Me.estado.Name = "estado"
        Me.estado.ReadOnly = True
        '
        'activo
        '
        Me.activo.HeaderText = "Active"
        Me.activo.Name = "activo"
        Me.activo.ReadOnly = True
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.GroupBox1)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(399, 101)
        Me.panelFiltro.TabIndex = 0
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.botonFiltrar)
        Me.GroupBox1.Controls.Add(Me.dtpFin)
        Me.GroupBox1.Controls.Add(Me.dtpInicio)
        Me.GroupBox1.Controls.Add(Me.checkFechas)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(399, 101)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filtrar por:"
        '
        'botonFiltrar
        '
        Me.botonFiltrar.Location = New System.Drawing.Point(295, 59)
        Me.botonFiltrar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonFiltrar.Name = "botonFiltrar"
        Me.botonFiltrar.Size = New System.Drawing.Size(100, 28)
        Me.botonFiltrar.TabIndex = 3
        Me.botonFiltrar.Text = "Filtrar"
        Me.botonFiltrar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(157, 59)
        Me.dtpFin.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(128, 22)
        Me.dtpFin.TabIndex = 2
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(20, 59)
        Me.dtpInicio.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(128, 22)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(20, 31)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(142, 21)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Rango de Fechas"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'PanelDatos
        '
        Me.PanelDatos.AutoScroll = True
        Me.PanelDatos.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelDatos.Controls.Add(Me.dgDetalle)
        Me.PanelDatos.Controls.Add(Me.Panel3)
        Me.PanelDatos.Controls.Add(Me.Panel2)
        Me.PanelDatos.Controls.Add(Me.Panel1)
        Me.PanelDatos.Location = New System.Drawing.Point(16, 145)
        Me.PanelDatos.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PanelDatos.Name = "PanelDatos"
        Me.PanelDatos.Size = New System.Drawing.Size(869, 837)
        Me.PanelDatos.TabIndex = 5
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cod, Me.Yarn, Me.idorigen, Me.source, Me.Quantity, Me.ultimo_precio, Me.ultimo_pedido, Me.Price, Me.idprograma, Me.program, Me.available, Me.idpoveedor, Me.proveedor})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 166)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.dgDetalle.Size = New System.Drawing.Size(209, 671)
        Me.dgDetalle.TabIndex = 13
        '
        'cod
        '
        Me.cod.HeaderText = "Code"
        Me.cod.Name = "cod"
        Me.cod.ReadOnly = True
        Me.cod.Width = 50
        '
        'Yarn
        '
        Me.Yarn.HeaderText = "Yarn"
        Me.Yarn.Name = "Yarn"
        Me.Yarn.ReadOnly = True
        Me.Yarn.Width = 200
        '
        'idorigen
        '
        Me.idorigen.HeaderText = "idsource"
        Me.idorigen.Name = "idorigen"
        Me.idorigen.ReadOnly = True
        Me.idorigen.Visible = False
        '
        'source
        '
        Me.source.HeaderText = "Source"
        Me.source.Name = "source"
        Me.source.ReadOnly = True
        '
        'Quantity
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle2.Format = "N2"
        DataGridViewCellStyle2.NullValue = "0"
        Me.Quantity.DefaultCellStyle = DataGridViewCellStyle2
        Me.Quantity.HeaderText = "Quantity"
        Me.Quantity.Name = "Quantity"
        '
        'ultimo_precio
        '
        DataGridViewCellStyle3.Format = "N2"
        DataGridViewCellStyle3.NullValue = "0"
        Me.ultimo_precio.DefaultCellStyle = DataGridViewCellStyle3
        Me.ultimo_precio.HeaderText = "Last Price Quote"
        Me.ultimo_precio.Name = "ultimo_precio"
        Me.ultimo_precio.ReadOnly = True
        '
        'ultimo_pedido
        '
        DataGridViewCellStyle4.Format = "N2"
        DataGridViewCellStyle4.NullValue = "0"
        Me.ultimo_pedido.DefaultCellStyle = DataGridViewCellStyle4
        Me.ultimo_pedido.HeaderText = "Last Price PO"
        Me.ultimo_pedido.Name = "ultimo_pedido"
        Me.ultimo_pedido.ReadOnly = True
        '
        'Price
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle5.Format = "N2"
        DataGridViewCellStyle5.NullValue = "0"
        Me.Price.DefaultCellStyle = DataGridViewCellStyle5
        Me.Price.HeaderText = "Price"
        Me.Price.Name = "Price"
        '
        'idprograma
        '
        Me.idprograma.HeaderText = "idprogram"
        Me.idprograma.Name = "idprograma"
        Me.idprograma.ReadOnly = True
        Me.idprograma.Visible = False
        '
        'program
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.program.DefaultCellStyle = DataGridViewCellStyle6
        Me.program.HeaderText = "Program"
        Me.program.Name = "program"
        Me.program.ReadOnly = True
        '
        'available
        '
        Me.available.HeaderText = "Available"
        Me.available.Name = "available"
        Me.available.ReadOnly = True
        '
        'idpoveedor
        '
        Me.idpoveedor.HeaderText = "idproveedor"
        Me.idpoveedor.Name = "idpoveedor"
        Me.idpoveedor.ReadOnly = True
        Me.idpoveedor.Visible = False
        '
        'proveedor
        '
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.proveedor.DefaultCellStyle = DataGridViewCellStyle7
        Me.proveedor.HeaderText = "Proveedor"
        Me.proveedor.Name = "proveedor"
        Me.proveedor.ReadOnly = True
        '
        'Panel3
        '
        Me.Panel3.AutoScroll = True
        Me.Panel3.Controls.Add(Me.celdaPo)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.celdaReservado)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.celdaOrden)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.celdaInventario)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.dgInventario)
        Me.Panel3.Controls.Add(Me.dgReservado)
        Me.Panel3.Controls.Add(Me.dgPO)
        Me.Panel3.Controls.Add(Me.dgOrden)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(209, 166)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(589, 671)
        Me.Panel3.TabIndex = 18
        '
        'celdaPo
        '
        Me.celdaPo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaPo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaPo.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaPo.Location = New System.Drawing.Point(432, 633)
        Me.celdaPo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaPo.Name = "celdaPo"
        Me.celdaPo.Size = New System.Drawing.Size(148, 30)
        Me.celdaPo.TabIndex = 25
        Me.celdaPo.Text = "0.00"
        Me.celdaPo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(299, 640)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 20)
        Me.Label4.TabIndex = 24
        Me.Label4.Text = "Total PO"
        '
        'celdaReservado
        '
        Me.celdaReservado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaReservado.BackColor = System.Drawing.SystemColors.Info
        Me.celdaReservado.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaReservado.Location = New System.Drawing.Point(432, 464)
        Me.celdaReservado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaReservado.Name = "celdaReservado"
        Me.celdaReservado.Size = New System.Drawing.Size(148, 30)
        Me.celdaReservado.TabIndex = 23
        Me.celdaReservado.Text = "0.00"
        Me.celdaReservado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(236, 476)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(136, 20)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Total Reserved"
        '
        'celdaOrden
        '
        Me.celdaOrden.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaOrden.BackColor = System.Drawing.SystemColors.Info
        Me.celdaOrden.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaOrden.Location = New System.Drawing.Point(432, 295)
        Me.celdaOrden.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaOrden.Name = "celdaOrden"
        Me.celdaOrden.Size = New System.Drawing.Size(148, 30)
        Me.celdaOrden.TabIndex = 21
        Me.celdaOrden.Text = "0.00"
        Me.celdaOrden.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(257, 303)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 20)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Total Ordened"
        '
        'celdaInventario
        '
        Me.celdaInventario.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaInventario.BackColor = System.Drawing.SystemColors.Info
        Me.celdaInventario.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaInventario.Location = New System.Drawing.Point(432, 132)
        Me.celdaInventario.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaInventario.Name = "celdaInventario"
        Me.celdaInventario.Size = New System.Drawing.Size(148, 30)
        Me.celdaInventario.TabIndex = 19
        Me.celdaInventario.Text = "0.00"
        Me.celdaInventario.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(288, 139)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 20)
        Me.Label1.TabIndex = 18
        Me.Label1.Text = "Total Stock"
        '
        'dgInventario
        '
        Me.dgInventario.AllowUserToAddRows = False
        Me.dgInventario.AllowUserToDeleteRows = False
        Me.dgInventario.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgInventario.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgInventario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgInventario.Location = New System.Drawing.Point(7, 5)
        Me.dgInventario.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgInventario.Name = "dgInventario"
        Me.dgInventario.ReadOnly = True
        Me.dgInventario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgInventario.Size = New System.Drawing.Size(575, 127)
        Me.dgInventario.TabIndex = 15
        '
        'dgReservado
        '
        Me.dgReservado.AllowUserToAddRows = False
        Me.dgReservado.AllowUserToDeleteRows = False
        Me.dgReservado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgReservado.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgReservado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgReservado.Location = New System.Drawing.Point(7, 337)
        Me.dgReservado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgReservado.Name = "dgReservado"
        Me.dgReservado.ReadOnly = True
        Me.dgReservado.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgReservado.Size = New System.Drawing.Size(575, 127)
        Me.dgReservado.TabIndex = 16
        '
        'dgPO
        '
        Me.dgPO.AllowUserToAddRows = False
        Me.dgPO.AllowUserToDeleteRows = False
        Me.dgPO.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgPO.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPO.Location = New System.Drawing.Point(7, 506)
        Me.dgPO.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgPO.Name = "dgPO"
        Me.dgPO.ReadOnly = True
        Me.dgPO.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPO.Size = New System.Drawing.Size(575, 127)
        Me.dgPO.TabIndex = 14
        '
        'dgOrden
        '
        Me.dgOrden.AllowUserToAddRows = False
        Me.dgOrden.AllowUserToDeleteRows = False
        Me.dgOrden.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgOrden.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgOrden.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgOrden.Location = New System.Drawing.Point(7, 169)
        Me.dgOrden.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgOrden.Name = "dgOrden"
        Me.dgOrden.ReadOnly = True
        Me.dgOrden.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgOrden.Size = New System.Drawing.Size(575, 127)
        Me.dgOrden.TabIndex = 17
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Button1)
        Me.Panel2.Controls.Add(Me.botonQuitar)
        Me.Panel2.Controls.Add(Me.botonAgregar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(798, 166)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(71, 671)
        Me.Panel2.TabIndex = 12
        '
        'Button1
        '
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button1.Enabled = False
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(0, 0)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(71, 671)
        Me.Button1.TabIndex = 1
        Me.Button1.Tag = "Update to real time"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(16, 87)
        Me.botonQuitar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(35, 30)
        Me.botonQuitar.TabIndex = 0
        Me.botonQuitar.Tag = "Delete row"
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Enabled = False
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(16, 50)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(35, 30)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.Tag = "Add row"
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaEstado)
        Me.Panel1.Controls.Add(Me.etiquetaMoneda)
        Me.Panel1.Controls.Add(Me.botonMoneda)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.celdaTasa)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.etiquetaDireccion)
        Me.Panel1.Controls.Add(Me.dtpFecha)
        Me.Panel1.Controls.Add(Me.checkActivo)
        Me.Panel1.Controls.Add(Me.celdaIdPagare)
        Me.Panel1.Controls.Add(Me.celdaAño)
        Me.Panel1.Controls.Add(Me.etiquetaIdCliente)
        Me.Panel1.Controls.Add(Me.botonBuscarCliente)
        Me.Panel1.Controls.Add(Me.etiquetaCliente)
        Me.Panel1.Controls.Add(Me.celdaMoneda)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.CeldaMonto)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(869, 166)
        Me.Panel1.TabIndex = 11
        '
        'celdaEstado
        '
        Me.celdaEstado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaEstado.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaEstado.Location = New System.Drawing.Point(264, 57)
        Me.celdaEstado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaEstado.Name = "celdaEstado"
        Me.celdaEstado.Size = New System.Drawing.Size(177, 33)
        Me.celdaEstado.TabIndex = 6
        Me.celdaEstado.Text = "Estado"
        Me.celdaEstado.UseVisualStyleBackColor = True
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(445, 37)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(32, 17)
        Me.etiquetaMoneda.TabIndex = 26
        Me.etiquetaMoneda.Text = "178"
        Me.etiquetaMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonMoneda.Location = New System.Drawing.Point(449, 59)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(36, 28)
        Me.botonMoneda.TabIndex = 25
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(487, 41)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 17)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Currency"
        '
        'celdaTasa
        '
        Me.celdaTasa.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTasa.Location = New System.Drawing.Point(608, 119)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(97, 22)
        Me.celdaTasa.TabIndex = 22
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(604, 100)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(99, 17)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Exchange rate"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaDireccion.Location = New System.Drawing.Point(21, 113)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(215, 20)
        Me.etiquetaDireccion.TabIndex = 20
        Me.etiquetaDireccion.Text = "NOMBRE DEL CLIENTE"
        '
        'dtpFecha
        '
        Me.dtpFecha.Enabled = False
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(25, 9)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(115, 22)
        Me.dtpFecha.TabIndex = 19
        '
        'checkActivo
        '
        Me.checkActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(799, 64)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 18
        Me.checkActivo.Text = "Activo"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaIdPagare
        '
        Me.celdaIdPagare.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.celdaIdPagare.Location = New System.Drawing.Point(97, 41)
        Me.celdaIdPagare.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaIdPagare.Name = "celdaIdPagare"
        Me.celdaIdPagare.ReadOnly = True
        Me.celdaIdPagare.Size = New System.Drawing.Size(65, 22)
        Me.celdaIdPagare.TabIndex = 3
        Me.celdaIdPagare.Text = "-1"
        Me.celdaIdPagare.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaAño
        '
        Me.celdaAño.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.celdaAño.Location = New System.Drawing.Point(25, 41)
        Me.celdaAño.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(68, 22)
        Me.celdaAño.TabIndex = 3
        Me.celdaAño.Text = "-1"
        Me.celdaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaIdCliente
        '
        Me.etiquetaIdCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaIdCliente.AutoSize = True
        Me.etiquetaIdCliente.Location = New System.Drawing.Point(593, 37)
        Me.etiquetaIdCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaIdCliente.Name = "etiquetaIdCliente"
        Me.etiquetaIdCliente.Size = New System.Drawing.Size(16, 17)
        Me.etiquetaIdCliente.TabIndex = 2
        Me.etiquetaIdCliente.Text = "0"
        Me.etiquetaIdCliente.Visible = False
        '
        'botonBuscarCliente
        '
        Me.botonBuscarCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonBuscarCliente.Location = New System.Drawing.Point(721, 59)
        Me.botonBuscarCliente.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.botonBuscarCliente.Name = "botonBuscarCliente"
        Me.botonBuscarCliente.Size = New System.Drawing.Size(36, 28)
        Me.botonBuscarCliente.TabIndex = 1
        Me.botonBuscarCliente.Text = "..."
        Me.botonBuscarCliente.UseVisualStyleBackColor = True
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaCliente.Location = New System.Drawing.Point(21, 75)
        Me.etiquetaCliente.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(215, 20)
        Me.etiquetaCliente.TabIndex = 0
        Me.etiquetaCliente.Text = "NOMBRE DEL CLIENTE"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMoneda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaMoneda.Location = New System.Drawing.Point(488, 59)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(69, 30)
        Me.celdaMoneda.TabIndex = 11
        Me.celdaMoneda.Text = "US$"
        Me.celdaMoneda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(619, 37)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(47, 17)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "Monto"
        '
        'CeldaMonto
        '
        Me.CeldaMonto.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaMonto.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMonto.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CeldaMonto.Location = New System.Drawing.Point(557, 59)
        Me.CeldaMonto.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CeldaMonto.Name = "CeldaMonto"
        Me.CeldaMonto.Size = New System.Drawing.Size(148, 30)
        Me.CeldaMonto.TabIndex = 12
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1268, 39)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1268, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCotizacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1268, 985)
        Me.Controls.Add(Me.PanelDatos)
        Me.Controls.Add(Me.panelLIsta)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frmCotizacion"
        Me.Text = "frmCotizacion"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLIsta.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.PanelDatos.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.dgInventario, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgReservado, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgPO, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgOrden, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLIsta As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents botonFiltrar As System.Windows.Forms.Button
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents PanelDatos As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaIdPagare As System.Windows.Forms.TextBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaIdCliente As System.Windows.Forms.Label
    Friend WithEvents botonBuscarCliente As System.Windows.Forms.Button
    Friend WithEvents etiquetaCliente As System.Windows.Forms.Label
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents CeldaMonto As System.Windows.Forms.TextBox
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents dgOrden As System.Windows.Forms.DataGridView
    Friend WithEvents dgReservado As System.Windows.Forms.DataGridView
    Friend WithEvents dgInventario As System.Windows.Forms.DataGridView
    Friend WithEvents dgPO As System.Windows.Forms.DataGridView
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents celdaPo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents celdaReservado As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents celdaOrden As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents celdaInventario As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ano As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents fecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents estado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents activo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaEstado As System.Windows.Forms.Button
    Friend WithEvents cod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Yarn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents idorigen As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents source As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ultimo_precio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ultimo_pedido As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Price As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents idprograma As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents program As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents available As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents idpoveedor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents proveedor As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
