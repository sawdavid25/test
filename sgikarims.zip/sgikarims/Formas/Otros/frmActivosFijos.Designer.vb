﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmActivosFijos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.CeldaComentario = New System.Windows.Forms.TextBox()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colIdEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef_Cat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef_Ano = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef_Num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colRef_Line = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSerieFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaVidaUtilHoras = New System.Windows.Forms.TextBox()
        Me.celdaVidaUtilUnidades = New System.Windows.Forms.TextBox()
        Me.celdaVidaUtilMeses = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.celdaVidaUtilAños = New System.Windows.Forms.TextBox()
        Me.celdaIdTipoDep = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.celdaTipoDep = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.celdaCostoConIVA = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.celdaPorcentaje = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.dtpInicioDep = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.celdaRefNum = New System.Windows.Forms.TextBox()
        Me.celdaRefAnio = New System.Windows.Forms.TextBox()
        Me.celdaRefcat = New System.Windows.Forms.TextBox()
        Me.celdaidResponsable = New System.Windows.Forms.TextBox()
        Me.celdaidTipo = New System.Windows.Forms.TextBox()
        Me.botonFactura = New System.Windows.Forms.Button()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdProveedor = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.celdaColor = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.celdaResiduo = New System.Windows.Forms.TextBox()
        Me.botonResposable = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.celdaResponsable = New System.Windows.Forms.TextBox()
        Me.botonCalcular = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.celdaDiasPendientes = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaDepreciacion = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.celdaValorLibros = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.celdaValorCompra = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.celdaSerieF = New System.Windows.Forms.TextBox()
        Me.botonProveeedor = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaFactura = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.celdaModelo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaMarca = New System.Windows.Forms.TextBox()
        Me.botonTipo = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.celdaTipo = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.panelDepreciacion = New System.Windows.Forms.Panel()
        Me.dgDepreciacion = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDia = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaTitulo = New System.Windows.Forms.TextBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.celdaContrato = New System.Windows.Forms.TextBox()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDepreciacion.SuspendLayout()
        CType(Me.dgDepreciacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Location = New System.Drawing.Point(248, 59)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(92, 58)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colTipo, Me.colNumero, Me.colDescripcion, Me.colSerie})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(92, 58)
        Me.dgLista.TabIndex = 0
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Type"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Width = 56
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "# Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 79
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colSerie
        '
        Me.colSerie.HeaderText = "Series"
        Me.colSerie.Name = "colSerie"
        Me.colSerie.ReadOnly = True
        Me.colSerie.Width = 61
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Label29)
        Me.panelDocumento.Controls.Add(Me.celdaContrato)
        Me.panelDocumento.Controls.Add(Me.Label28)
        Me.panelDocumento.Controls.Add(Me.CeldaComentario)
        Me.panelDocumento.Controls.Add(Me.Panel2)
        Me.panelDocumento.Controls.Add(Me.celdaVidaUtilHoras)
        Me.panelDocumento.Controls.Add(Me.celdaVidaUtilUnidades)
        Me.panelDocumento.Controls.Add(Me.celdaVidaUtilMeses)
        Me.panelDocumento.Controls.Add(Me.Label27)
        Me.panelDocumento.Controls.Add(Me.Label26)
        Me.panelDocumento.Controls.Add(Me.Label25)
        Me.panelDocumento.Controls.Add(Me.Label24)
        Me.panelDocumento.Controls.Add(Me.celdaVidaUtilAños)
        Me.panelDocumento.Controls.Add(Me.celdaIdTipoDep)
        Me.panelDocumento.Controls.Add(Me.Button1)
        Me.panelDocumento.Controls.Add(Me.celdaTipoDep)
        Me.panelDocumento.Controls.Add(Me.Label23)
        Me.panelDocumento.Controls.Add(Me.celdaCostoConIVA)
        Me.panelDocumento.Controls.Add(Me.Label22)
        Me.panelDocumento.Controls.Add(Me.celdaPorcentaje)
        Me.panelDocumento.Controls.Add(Me.Label21)
        Me.panelDocumento.Controls.Add(Me.dtpInicioDep)
        Me.panelDocumento.Controls.Add(Me.Label20)
        Me.panelDocumento.Controls.Add(Me.celdaRefNum)
        Me.panelDocumento.Controls.Add(Me.celdaRefAnio)
        Me.panelDocumento.Controls.Add(Me.celdaRefcat)
        Me.panelDocumento.Controls.Add(Me.celdaidResponsable)
        Me.panelDocumento.Controls.Add(Me.celdaidTipo)
        Me.panelDocumento.Controls.Add(Me.botonFactura)
        Me.panelDocumento.Controls.Add(Me.celdaIdMoneda)
        Me.panelDocumento.Controls.Add(Me.celdaIdProveedor)
        Me.panelDocumento.Controls.Add(Me.Label19)
        Me.panelDocumento.Controls.Add(Me.celdaColor)
        Me.panelDocumento.Controls.Add(Me.Label18)
        Me.panelDocumento.Controls.Add(Me.celdaResiduo)
        Me.panelDocumento.Controls.Add(Me.botonResposable)
        Me.panelDocumento.Controls.Add(Me.Label17)
        Me.panelDocumento.Controls.Add(Me.celdaResponsable)
        Me.panelDocumento.Controls.Add(Me.botonCalcular)
        Me.panelDocumento.Controls.Add(Me.Label16)
        Me.panelDocumento.Controls.Add(Me.celdaDiasPendientes)
        Me.panelDocumento.Controls.Add(Me.Label15)
        Me.panelDocumento.Controls.Add(Me.celdaDepreciacion)
        Me.panelDocumento.Controls.Add(Me.Label14)
        Me.panelDocumento.Controls.Add(Me.celdaValorLibros)
        Me.panelDocumento.Controls.Add(Me.Label13)
        Me.panelDocumento.Controls.Add(Me.celdaValorCompra)
        Me.panelDocumento.Controls.Add(Me.Label12)
        Me.panelDocumento.Controls.Add(Me.celdaTasa)
        Me.panelDocumento.Controls.Add(Me.botonMoneda)
        Me.panelDocumento.Controls.Add(Me.Label11)
        Me.panelDocumento.Controls.Add(Me.celdaMoneda)
        Me.panelDocumento.Controls.Add(Me.dtpFecha)
        Me.panelDocumento.Controls.Add(Me.Label10)
        Me.panelDocumento.Controls.Add(Me.Label9)
        Me.panelDocumento.Controls.Add(Me.celdaSerieF)
        Me.panelDocumento.Controls.Add(Me.botonProveeedor)
        Me.panelDocumento.Controls.Add(Me.Label8)
        Me.panelDocumento.Controls.Add(Me.celdaFactura)
        Me.panelDocumento.Controls.Add(Me.Label7)
        Me.panelDocumento.Controls.Add(Me.celdaProveedor)
        Me.panelDocumento.Controls.Add(Me.Label6)
        Me.panelDocumento.Controls.Add(Me.celdaSerie)
        Me.panelDocumento.Controls.Add(Me.Label5)
        Me.panelDocumento.Controls.Add(Me.celdaModelo)
        Me.panelDocumento.Controls.Add(Me.Label4)
        Me.panelDocumento.Controls.Add(Me.celdaMarca)
        Me.panelDocumento.Controls.Add(Me.botonTipo)
        Me.panelDocumento.Controls.Add(Me.Label3)
        Me.panelDocumento.Controls.Add(Me.celdaTipo)
        Me.panelDocumento.Controls.Add(Me.Label2)
        Me.panelDocumento.Controls.Add(Me.celdaDescripcion)
        Me.panelDocumento.Controls.Add(Me.Label1)
        Me.panelDocumento.Controls.Add(Me.celdaCodigo)
        Me.panelDocumento.Controls.Add(Me.panelDepreciacion)
        Me.panelDocumento.Location = New System.Drawing.Point(9, 118)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(965, 463)
        Me.panelDocumento.TabIndex = 3
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(35, 362)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(56, 13)
        Me.Label28.TabIndex = 76
        Me.Label28.Text = "Comments"
        '
        'CeldaComentario
        '
        Me.CeldaComentario.Location = New System.Drawing.Point(100, 360)
        Me.CeldaComentario.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.CeldaComentario.Name = "CeldaComentario"
        Me.CeldaComentario.Size = New System.Drawing.Size(441, 20)
        Me.CeldaComentario.TabIndex = 75
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Controls.Add(Me.dgDetalle)
        Me.Panel2.Location = New System.Drawing.Point(0, 387)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(595, 76)
        Me.Panel2.TabIndex = 74
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.botonQuitar)
        Me.Panel3.Controls.Add(Me.botonAgregar)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(548, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(47, 76)
        Me.Panel3.TabIndex = 74
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(10, 38)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(26, 24)
        Me.botonQuitar.TabIndex = 0
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(10, 8)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(26, 24)
        Me.botonAgregar.TabIndex = 4
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue
        Me.dgDetalle.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.Color.White
        Me.dgDetalle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdEmpresa, Me.colCodigo, Me.colRef_Cat, Me.colRef_Ano, Me.colRef_Num, Me.colRef_Line, Me.colFactura, Me.colSerieFac, Me.colFechaFactura, Me.colPrecio, Me.colExtra})
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle3
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.White
        Me.dgDetalle.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(542, 76)
        Me.dgDetalle.TabIndex = 73
        '
        'colIdEmpresa
        '
        Me.colIdEmpresa.HeaderText = "IdEmpresa"
        Me.colIdEmpresa.Name = "colIdEmpresa"
        Me.colIdEmpresa.Visible = False
        Me.colIdEmpresa.Width = 63
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Codigo"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.Visible = False
        Me.colCodigo.Width = 46
        '
        'colRef_Cat
        '
        Me.colRef_Cat.HeaderText = "Ref_Cat"
        Me.colRef_Cat.Name = "colRef_Cat"
        Me.colRef_Cat.Visible = False
        Me.colRef_Cat.Width = 52
        '
        'colRef_Ano
        '
        Me.colRef_Ano.HeaderText = "Año"
        Me.colRef_Ano.Name = "colRef_Ano"
        Me.colRef_Ano.Visible = False
        Me.colRef_Ano.Width = 32
        '
        'colRef_Num
        '
        Me.colRef_Num.HeaderText = "Ref Num"
        Me.colRef_Num.Name = "colRef_Num"
        Me.colRef_Num.Visible = False
        Me.colRef_Num.Width = 55
        '
        'colRef_Line
        '
        Me.colRef_Line.HeaderText = "Ref_Line"
        Me.colRef_Line.Name = "colRef_Line"
        Me.colRef_Line.Visible = False
        Me.colRef_Line.Width = 56
        '
        'colFactura
        '
        Me.colFactura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None
        Me.colFactura.HeaderText = "No. Factura"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        '
        'colSerieFac
        '
        Me.colSerieFac.HeaderText = "Serie Factura"
        Me.colSerieFac.Name = "colSerieFac"
        Me.colSerieFac.ReadOnly = True
        Me.colSerieFac.Width = 95
        '
        'colFechaFactura
        '
        Me.colFechaFactura.HeaderText = "Fecha"
        Me.colFechaFactura.Name = "colFechaFactura"
        Me.colFechaFactura.ReadOnly = True
        Me.colFechaFactura.Visible = False
        Me.colFechaFactura.Width = 62
        '
        'colPrecio
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle2.Format = "N2"
        DataGridViewCellStyle2.NullValue = Nothing
        Me.colPrecio.DefaultCellStyle = DataGridViewCellStyle2
        Me.colPrecio.HeaderText = "Precio"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.Visible = False
        Me.colPrecio.Width = 62
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.Visible = False
        Me.colExtra.Width = 56
        '
        'celdaVidaUtilHoras
        '
        Me.celdaVidaUtilHoras.Location = New System.Drawing.Point(607, 253)
        Me.celdaVidaUtilHoras.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaVidaUtilHoras.Name = "celdaVidaUtilHoras"
        Me.celdaVidaUtilHoras.Size = New System.Drawing.Size(110, 20)
        Me.celdaVidaUtilHoras.TabIndex = 72
        Me.celdaVidaUtilHoras.Text = "0.00"
        Me.celdaVidaUtilHoras.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaVidaUtilUnidades
        '
        Me.celdaVidaUtilUnidades.Location = New System.Drawing.Point(607, 230)
        Me.celdaVidaUtilUnidades.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaVidaUtilUnidades.Name = "celdaVidaUtilUnidades"
        Me.celdaVidaUtilUnidades.Size = New System.Drawing.Size(110, 20)
        Me.celdaVidaUtilUnidades.TabIndex = 71
        Me.celdaVidaUtilUnidades.Text = "0.00"
        Me.celdaVidaUtilUnidades.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaVidaUtilMeses
        '
        Me.celdaVidaUtilMeses.Location = New System.Drawing.Point(606, 205)
        Me.celdaVidaUtilMeses.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaVidaUtilMeses.Name = "celdaVidaUtilMeses"
        Me.celdaVidaUtilMeses.Size = New System.Drawing.Size(110, 20)
        Me.celdaVidaUtilMeses.TabIndex = 70
        Me.celdaVidaUtilMeses.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(506, 255)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(88, 13)
        Me.Label27.TabIndex = 69
        Me.Label27.Text = "Useful Life Hours"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(510, 232)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(84, 13)
        Me.Label26.TabIndex = 68
        Me.Label26.Text = "Useful Life Units"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(500, 207)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(95, 13)
        Me.Label25.TabIndex = 67
        Me.Label25.Text = "Useful Life Months"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(506, 182)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(87, 13)
        Me.Label24.TabIndex = 66
        Me.Label24.Text = "Useful Life Years"
        '
        'celdaVidaUtilAños
        '
        Me.celdaVidaUtilAños.Location = New System.Drawing.Point(607, 180)
        Me.celdaVidaUtilAños.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaVidaUtilAños.Name = "celdaVidaUtilAños"
        Me.celdaVidaUtilAños.Size = New System.Drawing.Size(110, 20)
        Me.celdaVidaUtilAños.TabIndex = 65
        Me.celdaVidaUtilAños.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaIdTipoDep
        '
        Me.celdaIdTipoDep.Location = New System.Drawing.Point(715, 33)
        Me.celdaIdTipoDep.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdTipoDep.Name = "celdaIdTipoDep"
        Me.celdaIdTipoDep.Size = New System.Drawing.Size(24, 20)
        Me.celdaIdTipoDep.TabIndex = 64
        Me.celdaIdTipoDep.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(721, 10)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(28, 19)
        Me.Button1.TabIndex = 63
        Me.Button1.Text = "..."
        Me.Button1.UseVisualStyleBackColor = True
        '
        'celdaTipoDep
        '
        Me.celdaTipoDep.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTipoDep.Location = New System.Drawing.Point(607, 10)
        Me.celdaTipoDep.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTipoDep.Name = "celdaTipoDep"
        Me.celdaTipoDep.ReadOnly = True
        Me.celdaTipoDep.Size = New System.Drawing.Size(110, 20)
        Me.celdaTipoDep.TabIndex = 62
        Me.celdaTipoDep.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(489, 12)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(105, 13)
        Me.Label23.TabIndex = 61
        Me.Label23.Text = "Depreciation method"
        '
        'celdaCostoConIVA
        '
        Me.celdaCostoConIVA.Location = New System.Drawing.Point(607, 60)
        Me.celdaCostoConIVA.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCostoConIVA.Name = "celdaCostoConIVA"
        Me.celdaCostoConIVA.Size = New System.Drawing.Size(110, 20)
        Me.celdaCostoConIVA.TabIndex = 60
        Me.celdaCostoConIVA.Text = "0.00"
        Me.celdaCostoConIVA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(522, 64)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(74, 13)
        Me.Label22.TabIndex = 59
        Me.Label22.Text = "Cost with VAT"
        '
        'celdaPorcentaje
        '
        Me.celdaPorcentaje.Location = New System.Drawing.Point(607, 92)
        Me.celdaPorcentaje.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaPorcentaje.Name = "celdaPorcentaje"
        Me.celdaPorcentaje.Size = New System.Drawing.Size(110, 20)
        Me.celdaPorcentaje.TabIndex = 58
        Me.celdaPorcentaje.Text = "0.00"
        Me.celdaPorcentaje.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(510, 96)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(85, 13)
        Me.Label21.TabIndex = 57
        Me.Label21.Text = "VAT percentage"
        '
        'dtpInicioDep
        '
        Me.dtpInicioDep.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicioDep.Location = New System.Drawing.Point(325, 197)
        Me.dtpInicioDep.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpInicioDep.Name = "dtpInicioDep"
        Me.dtpInicioDep.Size = New System.Drawing.Size(107, 20)
        Me.dtpInicioDep.TabIndex = 56
        Me.dtpInicioDep.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(214, 201)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(104, 13)
        Me.Label20.TabIndex = 55
        Me.Label20.Text = "Start of Depreciation"
        Me.Label20.Visible = False
        '
        'celdaRefNum
        '
        Me.celdaRefNum.Location = New System.Drawing.Point(293, 6)
        Me.celdaRefNum.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRefNum.Name = "celdaRefNum"
        Me.celdaRefNum.Size = New System.Drawing.Size(24, 20)
        Me.celdaRefNum.TabIndex = 54
        Me.celdaRefNum.Visible = False
        '
        'celdaRefAnio
        '
        Me.celdaRefAnio.Location = New System.Drawing.Point(331, 50)
        Me.celdaRefAnio.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRefAnio.Name = "celdaRefAnio"
        Me.celdaRefAnio.Size = New System.Drawing.Size(24, 20)
        Me.celdaRefAnio.TabIndex = 53
        Me.celdaRefAnio.Visible = False
        '
        'celdaRefcat
        '
        Me.celdaRefcat.Location = New System.Drawing.Point(332, 28)
        Me.celdaRefcat.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaRefcat.Name = "celdaRefcat"
        Me.celdaRefcat.Size = New System.Drawing.Size(24, 20)
        Me.celdaRefcat.TabIndex = 52
        Me.celdaRefcat.Visible = False
        '
        'celdaidResponsable
        '
        Me.celdaidResponsable.Location = New System.Drawing.Point(334, 311)
        Me.celdaidResponsable.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaidResponsable.Name = "celdaidResponsable"
        Me.celdaidResponsable.Size = New System.Drawing.Size(24, 20)
        Me.celdaidResponsable.TabIndex = 51
        Me.celdaidResponsable.Visible = False
        '
        'celdaidTipo
        '
        Me.celdaidTipo.Location = New System.Drawing.Point(331, 6)
        Me.celdaidTipo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaidTipo.Name = "celdaidTipo"
        Me.celdaidTipo.Size = New System.Drawing.Size(24, 20)
        Me.celdaidTipo.TabIndex = 50
        Me.celdaidTipo.Visible = False
        '
        'botonFactura
        '
        Me.botonFactura.Location = New System.Drawing.Point(546, 302)
        Me.botonFactura.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonFactura.Name = "botonFactura"
        Me.botonFactura.Size = New System.Drawing.Size(31, 19)
        Me.botonFactura.TabIndex = 49
        Me.botonFactura.Text = "..."
        Me.botonFactura.UseVisualStyleBackColor = True
        Me.botonFactura.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(250, 226)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(24, 20)
        Me.celdaIdMoneda.TabIndex = 48
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdProveedor
        '
        Me.celdaIdProveedor.Location = New System.Drawing.Point(338, 152)
        Me.celdaIdProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaIdProveedor.Name = "celdaIdProveedor"
        Me.celdaIdProveedor.Size = New System.Drawing.Size(24, 20)
        Me.celdaIdProveedor.TabIndex = 47
        Me.celdaIdProveedor.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(60, 152)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 13)
        Me.Label19.TabIndex = 45
        Me.Label19.Text = "Color"
        '
        'celdaColor
        '
        Me.celdaColor.Location = New System.Drawing.Point(100, 148)
        Me.celdaColor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaColor.Name = "celdaColor"
        Me.celdaColor.Size = New System.Drawing.Size(228, 20)
        Me.celdaColor.TabIndex = 43
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(480, 37)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(113, 13)
        Me.Label18.TabIndex = 40
        Me.Label18.Text = "Residual Value (Local)"
        '
        'celdaResiduo
        '
        Me.celdaResiduo.Location = New System.Drawing.Point(607, 33)
        Me.celdaResiduo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaResiduo.Name = "celdaResiduo"
        Me.celdaResiduo.Size = New System.Drawing.Size(110, 20)
        Me.celdaResiduo.TabIndex = 39
        Me.celdaResiduo.Text = "0.00"
        Me.celdaResiduo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'botonResposable
        '
        Me.botonResposable.Location = New System.Drawing.Point(334, 332)
        Me.botonResposable.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonResposable.Name = "botonResposable"
        Me.botonResposable.Size = New System.Drawing.Size(28, 19)
        Me.botonResposable.TabIndex = 38
        Me.botonResposable.Text = "..."
        Me.botonResposable.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(27, 335)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 13)
        Me.Label17.TabIndex = 37
        Me.Label17.Text = "Responsible"
        '
        'celdaResponsable
        '
        Me.celdaResponsable.Location = New System.Drawing.Point(101, 332)
        Me.celdaResponsable.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaResponsable.Name = "celdaResponsable"
        Me.celdaResponsable.ReadOnly = True
        Me.celdaResponsable.Size = New System.Drawing.Size(228, 20)
        Me.celdaResponsable.TabIndex = 36
        '
        'botonCalcular
        '
        Me.botonCalcular.Location = New System.Drawing.Point(642, 283)
        Me.botonCalcular.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonCalcular.Name = "botonCalcular"
        Me.botonCalcular.Size = New System.Drawing.Size(75, 32)
        Me.botonCalcular.TabIndex = 35
        Me.botonCalcular.Text = "Calculate"
        Me.botonCalcular.UseVisualStyleBackColor = True
        Me.botonCalcular.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(235, 287)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(67, 13)
        Me.Label16.TabIndex = 34
        Me.Label16.Text = "Pendig Days"
        Me.Label16.Visible = False
        '
        'celdaDiasPendientes
        '
        Me.celdaDiasPendientes.Location = New System.Drawing.Point(219, 303)
        Me.celdaDiasPendientes.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDiasPendientes.Name = "celdaDiasPendientes"
        Me.celdaDiasPendientes.Size = New System.Drawing.Size(100, 20)
        Me.celdaDiasPendientes.TabIndex = 33
        Me.celdaDiasPendientes.Visible = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(107, 288)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(94, 13)
        Me.Label15.TabIndex = 32
        Me.Label15.Text = "Depreciation Days"
        Me.Label15.Visible = False
        '
        'celdaDepreciacion
        '
        Me.celdaDepreciacion.Location = New System.Drawing.Point(101, 303)
        Me.celdaDepreciacion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDepreciacion.Name = "celdaDepreciacion"
        Me.celdaDepreciacion.Size = New System.Drawing.Size(110, 20)
        Me.celdaDepreciacion.TabIndex = 31
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(517, 157)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(78, 13)
        Me.Label14.TabIndex = 30
        Me.Label14.Text = "Value in Books"
        '
        'celdaValorLibros
        '
        Me.celdaValorLibros.Location = New System.Drawing.Point(607, 154)
        Me.celdaValorLibros.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaValorLibros.Name = "celdaValorLibros"
        Me.celdaValorLibros.ReadOnly = True
        Me.celdaValorLibros.Size = New System.Drawing.Size(110, 20)
        Me.celdaValorLibros.TabIndex = 29
        Me.celdaValorLibros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(368, 124)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(228, 13)
        Me.Label13.TabIndex = 28
        Me.Label13.Text = "Purchase Value in Local Currency without VAT"
        '
        'celdaValorCompra
        '
        Me.celdaValorCompra.Location = New System.Drawing.Point(607, 121)
        Me.celdaValorCompra.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaValorCompra.Name = "celdaValorCompra"
        Me.celdaValorCompra.Size = New System.Drawing.Size(110, 20)
        Me.celdaValorCompra.TabIndex = 27
        Me.celdaValorCompra.Text = "0.00"
        Me.celdaValorCompra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(117, 249)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(81, 13)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "Exchange Rate"
        '
        'celdaTasa
        '
        Me.celdaTasa.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTasa.Location = New System.Drawing.Point(101, 265)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(110, 20)
        Me.celdaTasa.TabIndex = 25
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(215, 225)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(31, 19)
        Me.botonMoneda.TabIndex = 24
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(43, 231)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(49, 13)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "Currency"
        '
        'celdaMoneda
        '
        Me.celdaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMoneda.Location = New System.Drawing.Point(101, 226)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(110, 20)
        Me.celdaMoneda.TabIndex = 22
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(101, 197)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(107, 20)
        Me.dtpFecha.TabIndex = 21
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(3, 201)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(90, 13)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Date of Purchase"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(389, 326)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(36, 13)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Series"
        Me.Label9.Visible = False
        '
        'celdaSerieF
        '
        Me.celdaSerieF.Location = New System.Drawing.Point(432, 323)
        Me.celdaSerieF.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaSerieF.Name = "celdaSerieF"
        Me.celdaSerieF.ReadOnly = True
        Me.celdaSerieF.Size = New System.Drawing.Size(100, 20)
        Me.celdaSerieF.TabIndex = 18
        Me.celdaSerieF.Visible = False
        '
        'botonProveeedor
        '
        Me.botonProveeedor.Location = New System.Drawing.Point(332, 173)
        Me.botonProveeedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonProveeedor.Name = "botonProveeedor"
        Me.botonProveeedor.Size = New System.Drawing.Size(34, 19)
        Me.botonProveeedor.TabIndex = 17
        Me.botonProveeedor.Text = "..."
        Me.botonProveeedor.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(384, 305)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Invoice"
        Me.Label8.Visible = False
        '
        'celdaFactura
        '
        Me.celdaFactura.Location = New System.Drawing.Point(432, 302)
        Me.celdaFactura.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaFactura.Name = "celdaFactura"
        Me.celdaFactura.ReadOnly = True
        Me.celdaFactura.Size = New System.Drawing.Size(110, 20)
        Me.celdaFactura.TabIndex = 15
        Me.celdaFactura.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(45, 176)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 14
        Me.Label7.Text = "Provider"
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(100, 173)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.ReadOnly = True
        Me.celdaProveedor.Size = New System.Drawing.Size(228, 20)
        Me.celdaProveedor.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(55, 128)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Series"
        '
        'celdaSerie
        '
        Me.celdaSerie.Location = New System.Drawing.Point(100, 125)
        Me.celdaSerie.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.Size = New System.Drawing.Size(228, 20)
        Me.celdaSerie.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(56, 105)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Model"
        '
        'celdaModelo
        '
        Me.celdaModelo.Location = New System.Drawing.Point(100, 102)
        Me.celdaModelo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaModelo.Name = "celdaModelo"
        Me.celdaModelo.Size = New System.Drawing.Size(228, 20)
        Me.celdaModelo.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(62, 77)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Mark"
        '
        'celdaMarca
        '
        Me.celdaMarca.Location = New System.Drawing.Point(100, 77)
        Me.celdaMarca.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaMarca.Name = "celdaMarca"
        Me.celdaMarca.Size = New System.Drawing.Size(228, 20)
        Me.celdaMarca.TabIndex = 7
        '
        'botonTipo
        '
        Me.botonTipo.Location = New System.Drawing.Point(288, 26)
        Me.botonTipo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.botonTipo.Name = "botonTipo"
        Me.botonTipo.Size = New System.Drawing.Size(30, 19)
        Me.botonTipo.TabIndex = 6
        Me.botonTipo.Text = "..."
        Me.botonTipo.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(61, 28)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(31, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Type"
        '
        'celdaTipo
        '
        Me.celdaTipo.Location = New System.Drawing.Point(100, 26)
        Me.celdaTipo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTipo.Name = "celdaTipo"
        Me.celdaTipo.ReadOnly = True
        Me.celdaTipo.Size = New System.Drawing.Size(184, 20)
        Me.celdaTipo.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 54)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Description"
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(100, 52)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(182, 20)
        Me.celdaDescripcion.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(60, 6)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Code"
        '
        'celdaCodigo
        '
        Me.celdaCodigo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCodigo.Location = New System.Drawing.Point(100, 2)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.Size = New System.Drawing.Size(110, 20)
        Me.celdaCodigo.TabIndex = 0
        '
        'panelDepreciacion
        '
        Me.panelDepreciacion.Controls.Add(Me.dgDepreciacion)
        Me.panelDepreciacion.Controls.Add(Me.Panel1)
        Me.panelDepreciacion.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelDepreciacion.Location = New System.Drawing.Point(625, 0)
        Me.panelDepreciacion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.panelDepreciacion.Name = "panelDepreciacion"
        Me.panelDepreciacion.Size = New System.Drawing.Size(340, 463)
        Me.panelDepreciacion.TabIndex = 44
        Me.panelDepreciacion.Visible = False
        '
        'dgDepreciacion
        '
        Me.dgDepreciacion.AllowUserToAddRows = False
        Me.dgDepreciacion.AllowUserToDeleteRows = False
        Me.dgDepreciacion.AllowUserToOrderColumns = True
        Me.dgDepreciacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDepreciacion.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDepreciacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDepreciacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDepreciacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colFecha, Me.colMonto, Me.colSaldo, Me.colDia, Me.colEstado, Me.colMarca})
        Me.dgDepreciacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDepreciacion.Location = New System.Drawing.Point(0, 26)
        Me.dgDepreciacion.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dgDepreciacion.Name = "dgDepreciacion"
        Me.dgDepreciacion.ReadOnly = True
        Me.dgDepreciacion.RowTemplate.Height = 24
        Me.dgDepreciacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDepreciacion.Size = New System.Drawing.Size(340, 437)
        Me.dgDepreciacion.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        Me.colLinea.Width = 58
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        Me.colFecha.Width = 55
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        Me.colMonto.Width = 68
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Width = 71
        '
        'colDia
        '
        Me.colDia.HeaderText = "Days"
        Me.colDia.Name = "colDia"
        Me.colDia.ReadOnly = True
        Me.colDia.Width = 37
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        Me.colEstado.Width = 65
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Marca"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Visible = False
        Me.colMarca.Width = 62
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaTitulo)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(340, 26)
        Me.Panel1.TabIndex = 1
        Me.Panel1.Visible = False
        '
        'celdaTitulo
        '
        Me.celdaTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.celdaTitulo.ForeColor = System.Drawing.SystemColors.InactiveBorder
        Me.celdaTitulo.Location = New System.Drawing.Point(65, 6)
        Me.celdaTitulo.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.celdaTitulo.Name = "celdaTitulo"
        Me.celdaTitulo.Size = New System.Drawing.Size(203, 20)
        Me.celdaTitulo.TabIndex = 46
        Me.celdaTitulo.Text = "Depreciation Data"
        Me.celdaTitulo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(985, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(985, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(506, 282)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(87, 13)
        Me.Label29.TabIndex = 78
        Me.Label29.Text = "Contract Number"
        '
        'celdaContrato
        '
        Me.celdaContrato.Location = New System.Drawing.Point(605, 279)
        Me.celdaContrato.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaContrato.Name = "celdaContrato"
        Me.celdaContrato.Size = New System.Drawing.Size(144, 20)
        Me.celdaContrato.TabIndex = 77
        '
        'frmActivosFijos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(985, 590)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmActivosFijos"
        Me.Text = "frmActivosFijos"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDocumento.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDepreciacion.ResumeLayout(False)
        CType(Me.dgDepreciacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents celdaModelo As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaMarca As TextBox
    Friend WithEvents botonTipo As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaTipo As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents celdaCodigo As TextBox
    Friend WithEvents celdaColor As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents celdaResiduo As TextBox
    Friend WithEvents botonResposable As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents celdaResponsable As TextBox
    Friend WithEvents botonCalcular As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents celdaDiasPendientes As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents celdaDepreciacion As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents celdaValorLibros As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents celdaValorCompra As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents Label11 As Label
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents celdaSerieF As TextBox
    Friend WithEvents botonProveeedor As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaFactura As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents panelDepreciacion As Panel
    Friend WithEvents dgDepreciacion As DataGridView
    Friend WithEvents Label19 As Label
    Friend WithEvents celdaTitulo As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdProveedor As TextBox
    Friend WithEvents botonFactura As Button
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colSerie As DataGridViewTextBoxColumn
    Friend WithEvents celdaidTipo As TextBox
    Friend WithEvents celdaidResponsable As TextBox
    Friend WithEvents celdaRefNum As TextBox
    Friend WithEvents celdaRefAnio As TextBox
    Friend WithEvents celdaRefcat As TextBox
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents colDia As DataGridViewButtonColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As Panel
    Friend WithEvents dtpInicioDep As DateTimePicker
    Friend WithEvents Label20 As Label
    Friend WithEvents celdaCostoConIVA As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents celdaPorcentaje As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents celdaTipoDep As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents celdaIdTipoDep As TextBox
    Friend WithEvents celdaVidaUtilAños As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents celdaVidaUtilHoras As TextBox
    Friend WithEvents celdaVidaUtilUnidades As TextBox
    Friend WithEvents celdaVidaUtilMeses As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents botonQuitar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents colIdEmpresa As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colRef_Cat As DataGridViewTextBoxColumn
    Friend WithEvents colRef_Ano As DataGridViewTextBoxColumn
    Friend WithEvents colRef_Num As DataGridViewTextBoxColumn
    Friend WithEvents colRef_Line As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents colSerieFac As DataGridViewTextBoxColumn
    Friend WithEvents colFechaFactura As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents Label28 As Label
    Friend WithEvents CeldaComentario As TextBox
    Friend WithEvents Label29 As Label
    Friend WithEvents celdaContrato As TextBox
End Class
