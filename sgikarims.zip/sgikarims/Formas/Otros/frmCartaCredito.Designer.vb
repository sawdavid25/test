﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCartaCredito
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelDet = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaDate = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.panelDetalle3 = New System.Windows.Forms.Panel()
        Me.dgDetalle3 = New System.Windows.Forms.DataGridView()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCarta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBalance = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle2 = New System.Windows.Forms.Panel()
        Me.dgDetalle2 = New System.Windows.Forms.DataGridView()
        Me.colSubdocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.coldato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFSD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLSD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaTot = New System.Windows.Forms.TextBox()
        Me.celdaQuantity = New System.Windows.Forms.TextBox()
        Me.celdaCanti = New System.Windows.Forms.TextBox()
        Me.celdaLinea = New System.Windows.Forms.TextBox()
        Me.gbDato3 = New System.Windows.Forms.GroupBox()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.botonDescargar = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.dgPedidos = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrder = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDischarge = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbDato2 = New System.Windows.Forms.GroupBox()
        Me.celdaTolerancia = New System.Windows.Forms.TextBox()
        Me.etiquetaTolerancia = New System.Windows.Forms.Label()
        Me.celdaFirmante = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.etiquetaReferencia = New System.Windows.Forms.Label()
        Me.celdaNCarta = New System.Windows.Forms.TextBox()
        Me.etiquetaNCarta = New System.Windows.Forms.Label()
        Me.gbDato = New System.Windows.Forms.GroupBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIDNombre = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.botonNombre = New System.Windows.Forms.Button()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaFech = New System.Windows.Forms.Label()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaNombre = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.etiquetaDocRelacionado = New System.Windows.Forms.Label()
        Me.celdaIDAgregar = New System.Windows.Forms.TextBox()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.panelLista.SuspendLayout()
        Me.panelDet.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDocumento.SuspendLayout()
        Me.panelDetalle3.SuspendLayout()
        CType(Me.dgDetalle3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle2.SuspendLayout()
        CType(Me.dgDetalle2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.gbDato3.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        CType(Me.dgPedidos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbDato2.SuspendLayout()
        Me.gbDato.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.BackColor = System.Drawing.SystemColors.Info
        Me.panelLista.Controls.Add(Me.panelDet)
        Me.panelLista.Controls.Add(Me.botonActualizar)
        Me.panelLista.Controls.Add(Me.etiquetaDate)
        Me.panelLista.Controls.Add(Me.dtpFinal)
        Me.panelLista.Controls.Add(Me.dtpInicio)
        Me.panelLista.Controls.Add(Me.CheckBox1)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 102)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(863, 160)
        Me.panelLista.TabIndex = 2
        '
        'panelDet
        '
        Me.panelDet.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDet.Controls.Add(Me.dgLista)
        Me.panelDet.Location = New System.Drawing.Point(0, 29)
        Me.panelDet.Name = "panelDet"
        Me.panelDet.Size = New System.Drawing.Size(863, 131)
        Me.panelDet.TabIndex = 10
        '
        'dgLista
        '
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.Name = "dgLista"
        Me.dgLista.Size = New System.Drawing.Size(863, 131)
        Me.dgLista.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(515, 5)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 9
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaDate
        '
        Me.etiquetaDate.AutoSize = True
        Me.etiquetaDate.Location = New System.Drawing.Point(323, 13)
        Me.etiquetaDate.Name = "etiquetaDate"
        Me.etiquetaDate.Size = New System.Drawing.Size(52, 13)
        Me.etiquetaDate.TabIndex = 8
        Me.etiquetaDate.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(399, 7)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(95, 20)
        Me.dtpFinal.TabIndex = 7
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(210, 8)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(95, 20)
        Me.dtpInicio.TabIndex = 6
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(18, 11)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(189, 17)
        Me.CheckBox1.TabIndex = 5
        Me.CheckBox1.Text = "Browse Documents Between Date"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.panelDetalle3)
        Me.panelDocumento.Controls.Add(Me.panelDetalle2)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.gbDato3)
        Me.panelDocumento.Controls.Add(Me.gbDato2)
        Me.panelDocumento.Controls.Add(Me.gbDato)
        Me.panelDocumento.Location = New System.Drawing.Point(0, 268)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(851, 476)
        Me.panelDocumento.TabIndex = 4
        '
        'panelDetalle3
        '
        Me.panelDetalle3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle3.Controls.Add(Me.dgDetalle3)
        Me.panelDetalle3.Location = New System.Drawing.Point(291, 388)
        Me.panelDetalle3.Name = "panelDetalle3"
        Me.panelDetalle3.Size = New System.Drawing.Size(560, 85)
        Me.panelDetalle3.TabIndex = 5
        '
        'dgDetalle3
        '
        Me.dgDetalle3.AllowUserToAddRows = False
        Me.dgDetalle3.AllowUserToDeleteRows = False
        Me.dgDetalle3.AllowUserToOrderColumns = True
        Me.dgDetalle3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle3.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLine, Me.colYear, Me.colCarta, Me.colDescargo, Me.colBalance})
        Me.dgDetalle3.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle3.MultiSelect = False
        Me.dgDetalle3.Name = "dgDetalle3"
        Me.dgDetalle3.ReadOnly = True
        Me.dgDetalle3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle3.Size = New System.Drawing.Size(560, 85)
        Me.dgDetalle3.TabIndex = 0
        '
        'colLine
        '
        Me.colLine.HeaderText = "Line"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        '
        'colCarta
        '
        Me.colCarta.HeaderText = "Letter of Credit"
        Me.colCarta.Name = "colCarta"
        Me.colCarta.ReadOnly = True
        '
        'colDescargo
        '
        Me.colDescargo.HeaderText = "Discharge"
        Me.colDescargo.Name = "colDescargo"
        Me.colDescargo.ReadOnly = True
        '
        'colBalance
        '
        Me.colBalance.HeaderText = "Balance"
        Me.colBalance.Name = "colBalance"
        Me.colBalance.ReadOnly = True
        '
        'panelDetalle2
        '
        Me.panelDetalle2.Controls.Add(Me.dgDetalle2)
        Me.panelDetalle2.Location = New System.Drawing.Point(0, 388)
        Me.panelDetalle2.Name = "panelDetalle2"
        Me.panelDetalle2.Size = New System.Drawing.Size(235, 85)
        Me.panelDetalle2.TabIndex = 4
        '
        'dgDetalle2
        '
        Me.dgDetalle2.AllowUserToAddRows = False
        Me.dgDetalle2.AllowUserToDeleteRows = False
        Me.dgDetalle2.AllowUserToOrderColumns = True
        Me.dgDetalle2.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colSubdocumento, Me.coldato})
        Me.dgDetalle2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle2.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle2.MultiSelect = False
        Me.dgDetalle2.Name = "dgDetalle2"
        Me.dgDetalle2.ReadOnly = True
        Me.dgDetalle2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle2.Size = New System.Drawing.Size(235, 85)
        Me.dgDetalle2.TabIndex = 0
        '
        'colSubdocumento
        '
        Me.colSubdocumento.HeaderText = "SubDocument"
        Me.colSubdocumento.Name = "colSubdocumento"
        Me.colSubdocumento.ReadOnly = True
        '
        'coldato
        '
        Me.coldato.HeaderText = "Fact"
        Me.coldato.Name = "coldato"
        Me.coldato.ReadOnly = True
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.dgDetalle)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Location = New System.Drawing.Point(3, 242)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(848, 140)
        Me.panelDetalle.TabIndex = 3
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AllowUserToOrderColumns = True
        Me.dgDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcion, Me.colMedida, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colFSD, Me.colLSD, Me.colFabricante})
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.MultiSelect = False
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.ReadOnly = True
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(848, 92)
        Me.dgDetalle.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code*"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price $."
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity*"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total $."
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        '
        'colFSD
        '
        Me.colFSD.HeaderText = "FSD"
        Me.colFSD.Name = "colFSD"
        Me.colFSD.ReadOnly = True
        '
        'colLSD
        '
        Me.colLSD.HeaderText = "LSD"
        Me.colLSD.Name = "colLSD"
        Me.colLSD.ReadOnly = True
        '
        'colFabricante
        '
        Me.colFabricante.HeaderText = "Manufacturer"
        Me.colFabricante.Name = "colFabricante"
        Me.colFabricante.ReadOnly = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.celdaTotal)
        Me.Panel1.Controls.Add(Me.celdaTot)
        Me.Panel1.Controls.Add(Me.celdaQuantity)
        Me.Panel1.Controls.Add(Me.celdaCanti)
        Me.Panel1.Controls.Add(Me.celdaLinea)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 92)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(848, 48)
        Me.Panel1.TabIndex = 0
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.Color.RoyalBlue
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.Location = New System.Drawing.Point(645, 6)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(203, 20)
        Me.celdaTotal.TabIndex = 27
        Me.celdaTotal.Text = "Total"
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaTot
        '
        Me.celdaTot.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTot.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTot.Location = New System.Drawing.Point(645, 25)
        Me.celdaTot.Name = "celdaTot"
        Me.celdaTot.ReadOnly = True
        Me.celdaTot.Size = New System.Drawing.Size(203, 20)
        Me.celdaTot.TabIndex = 26
        Me.celdaTot.Text = "0.00"
        Me.celdaTot.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaQuantity
        '
        Me.celdaQuantity.BackColor = System.Drawing.Color.RoyalBlue
        Me.celdaQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaQuantity.Location = New System.Drawing.Point(580, 6)
        Me.celdaQuantity.Name = "celdaQuantity"
        Me.celdaQuantity.Size = New System.Drawing.Size(63, 20)
        Me.celdaQuantity.TabIndex = 25
        Me.celdaQuantity.Text = "Quantity"
        Me.celdaQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCanti
        '
        Me.celdaCanti.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCanti.Location = New System.Drawing.Point(580, 25)
        Me.celdaCanti.Name = "celdaCanti"
        Me.celdaCanti.ReadOnly = True
        Me.celdaCanti.Size = New System.Drawing.Size(63, 20)
        Me.celdaCanti.TabIndex = 24
        Me.celdaCanti.Text = "0.00"
        Me.celdaCanti.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaLinea
        '
        Me.celdaLinea.BackColor = System.Drawing.SystemColors.Info
        Me.celdaLinea.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaLinea.Location = New System.Drawing.Point(9, 6)
        Me.celdaLinea.Multiline = True
        Me.celdaLinea.Name = "celdaLinea"
        Me.celdaLinea.ReadOnly = True
        Me.celdaLinea.Size = New System.Drawing.Size(553, 39)
        Me.celdaLinea.TabIndex = 21
        Me.celdaLinea.Text = "Line 01: "
        '
        'gbDato3
        '
        Me.gbDato3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbDato3.Controls.Add(Me.panelBotones)
        Me.gbDato3.Controls.Add(Me.dgPedidos)
        Me.gbDato3.Location = New System.Drawing.Point(356, 116)
        Me.gbDato3.Name = "gbDato3"
        Me.gbDato3.Size = New System.Drawing.Size(489, 120)
        Me.gbDato3.TabIndex = 2
        Me.gbDato3.TabStop = False
        Me.gbDato3.Text = "Customers Orders"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.celdaIDAgregar)
        Me.panelBotones.Controls.Add(Me.botonAgregar)
        Me.panelBotones.Controls.Add(Me.botonDescargar)
        Me.panelBotones.Controls.Add(Me.botonQuitar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(427, 16)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(59, 101)
        Me.panelBotones.TabIndex = 4
        '
        'botonAgregar
        '
        'Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.document_add
        Me.botonAgregar.Location = New System.Drawing.Point(15, 10)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(32, 23)
        Me.botonAgregar.TabIndex = 1
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'botonDescargar
        '
        ' Me.botonDescargar.Image = Global.KARIMs_SGI.My.Resources.Resources.document_exchange
        Me.botonDescargar.Location = New System.Drawing.Point(15, 75)
        Me.botonDescargar.Name = "botonDescargar"
        Me.botonDescargar.Size = New System.Drawing.Size(32, 23)
        Me.botonDescargar.TabIndex = 2
        Me.botonDescargar.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        'Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.document_delete
        Me.botonQuitar.Location = New System.Drawing.Point(15, 43)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(32, 23)
        Me.botonQuitar.TabIndex = 3
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'dgPedidos
        '
        Me.dgPedidos.AllowUserToAddRows = False
        Me.dgPedidos.AllowUserToDeleteRows = False
        Me.dgPedidos.AllowUserToOrderColumns = True
        Me.dgPedidos.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgPedidos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPedidos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colAño, Me.colOrder, Me.colDischarge, Me.colSaldo})
        Me.dgPedidos.Location = New System.Drawing.Point(3, 16)
        Me.dgPedidos.MultiSelect = False
        Me.dgPedidos.Name = "dgPedidos"
        Me.dgPedidos.ReadOnly = True
        Me.dgPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPedidos.Size = New System.Drawing.Size(411, 101)
        Me.dgPedidos.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colOrder
        '
        Me.colOrder.HeaderText = "Order"
        Me.colOrder.Name = "colOrder"
        Me.colOrder.ReadOnly = True
        '
        'colDischarge
        '
        Me.colDischarge.HeaderText = "Discharge"
        Me.colDischarge.Name = "colDischarge"
        Me.colDischarge.ReadOnly = True
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        '
        'gbDato2
        '
        Me.gbDato2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbDato2.Controls.Add(Me.celdaTolerancia)
        Me.gbDato2.Controls.Add(Me.etiquetaTolerancia)
        Me.gbDato2.Controls.Add(Me.celdaFirmante)
        Me.gbDato2.Controls.Add(Me.Label1)
        Me.gbDato2.Controls.Add(Me.celdaReferencia)
        Me.gbDato2.Controls.Add(Me.etiquetaReferencia)
        Me.gbDato2.Controls.Add(Me.celdaNCarta)
        Me.gbDato2.Controls.Add(Me.etiquetaNCarta)
        Me.gbDato2.Location = New System.Drawing.Point(356, 11)
        Me.gbDato2.Name = "gbDato2"
        Me.gbDato2.Size = New System.Drawing.Size(489, 99)
        Me.gbDato2.TabIndex = 1
        Me.gbDato2.TabStop = False
        Me.gbDato2.Text = "Additional Information"
        '
        'celdaTolerancia
        '
        Me.celdaTolerancia.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTolerancia.Location = New System.Drawing.Point(365, 38)
        Me.celdaTolerancia.Name = "celdaTolerancia"
        Me.celdaTolerancia.Size = New System.Drawing.Size(118, 20)
        Me.celdaTolerancia.TabIndex = 27
        '
        'etiquetaTolerancia
        '
        Me.etiquetaTolerancia.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTolerancia.AutoSize = True
        Me.etiquetaTolerancia.Location = New System.Drawing.Point(287, 41)
        Me.etiquetaTolerancia.Name = "etiquetaTolerancia"
        Me.etiquetaTolerancia.Size = New System.Drawing.Size(72, 13)
        Me.etiquetaTolerancia.TabIndex = 26
        Me.etiquetaTolerancia.Text = "Tolerance (%)"
        '
        'celdaFirmante
        '
        Me.celdaFirmante.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFirmante.Location = New System.Drawing.Point(100, 61)
        Me.celdaFirmante.Multiline = True
        Me.celdaFirmante.Name = "celdaFirmante"
        Me.celdaFirmante.Size = New System.Drawing.Size(383, 32)
        Me.celdaFirmante.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 13)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Signatory"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(100, 38)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(118, 20)
        Me.celdaReferencia.TabIndex = 23
        '
        'etiquetaReferencia
        '
        Me.etiquetaReferencia.AutoSize = True
        Me.etiquetaReferencia.Location = New System.Drawing.Point(6, 41)
        Me.etiquetaReferencia.Name = "etiquetaReferencia"
        Me.etiquetaReferencia.Size = New System.Drawing.Size(57, 13)
        Me.etiquetaReferencia.TabIndex = 22
        Me.etiquetaReferencia.Text = "Reference"
        '
        'celdaNCarta
        '
        Me.celdaNCarta.Location = New System.Drawing.Point(100, 16)
        Me.celdaNCarta.Name = "celdaNCarta"
        Me.celdaNCarta.Size = New System.Drawing.Size(118, 20)
        Me.celdaNCarta.TabIndex = 21
        '
        'etiquetaNCarta
        '
        Me.etiquetaNCarta.AutoSize = True
        Me.etiquetaNCarta.Location = New System.Drawing.Point(6, 19)
        Me.etiquetaNCarta.Name = "etiquetaNCarta"
        Me.etiquetaNCarta.Size = New System.Drawing.Size(88, 13)
        Me.etiquetaNCarta.TabIndex = 0
        Me.etiquetaNCarta.Text = "Number Of Letter"
        '
        'gbDato
        '
        Me.gbDato.Controls.Add(Me.celdaIDMoneda)
        Me.gbDato.Controls.Add(Me.celdaIDNombre)
        Me.gbDato.Controls.Add(Me.botonMoneda)
        Me.gbDato.Controls.Add(Me.botonNombre)
        Me.gbDato.Controls.Add(Me.celdaTasa)
        Me.gbDato.Controls.Add(Me.etiquetaTasa)
        Me.gbDato.Controls.Add(Me.etiquetaFech)
        Me.gbDato.Controls.Add(Me.dtpDate)
        Me.gbDato.Controls.Add(Me.celdaMoneda)
        Me.gbDato.Controls.Add(Me.celdaNIT)
        Me.gbDato.Controls.Add(Me.celdaNumero)
        Me.gbDato.Controls.Add(Me.celdaNombre)
        Me.gbDato.Controls.Add(Me.celdaDescripcion)
        Me.gbDato.Controls.Add(Me.checkActivo)
        Me.gbDato.Controls.Add(Me.celdaAño)
        Me.gbDato.Controls.Add(Me.etiquetaMoneda)
        Me.gbDato.Controls.Add(Me.etiquetaNIT)
        Me.gbDato.Controls.Add(Me.etiquetaDireccion)
        Me.gbDato.Controls.Add(Me.etiquetaNombre)
        Me.gbDato.Controls.Add(Me.etiquetaNumero)
        Me.gbDato.Controls.Add(Me.etiquetaAño)
        Me.gbDato.Location = New System.Drawing.Point(0, 3)
        Me.gbDato.Name = "gbDato"
        Me.gbDato.Size = New System.Drawing.Size(333, 233)
        Me.gbDato.TabIndex = 0
        Me.gbDato.TabStop = False
        Me.gbDato.Text = "Document Data"
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(142, 199)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(21, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'celdaIDNombre
        '
        Me.celdaIDNombre.Location = New System.Drawing.Point(284, 69)
        Me.celdaIDNombre.Name = "celdaIDNombre"
        Me.celdaIDNombre.Size = New System.Drawing.Size(21, 20)
        Me.celdaIDNombre.TabIndex = 24
        Me.celdaIDNombre.Text = "-1"
        Me.celdaIDNombre.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(126, 170)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(37, 23)
        Me.botonMoneda.TabIndex = 23
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'botonNombre
        '
        Me.botonNombre.Location = New System.Drawing.Point(241, 67)
        Me.botonNombre.Name = "botonNombre"
        Me.botonNombre.Size = New System.Drawing.Size(37, 23)
        Me.botonNombre.TabIndex = 21
        Me.botonNombre.Text = "..."
        Me.botonNombre.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(201, 174)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(77, 20)
        Me.celdaTasa.TabIndex = 20
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(169, 177)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 19
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaFech
        '
        Me.etiquetaFech.AutoSize = True
        Me.etiquetaFech.Location = New System.Drawing.Point(198, 49)
        Me.etiquetaFech.Name = "etiquetaFech"
        Me.etiquetaFech.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFech.TabIndex = 18
        Me.etiquetaFech.Text = "Date"
        '
        'dtpDate
        '
        Me.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDate.Location = New System.Drawing.Point(241, 46)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(86, 20)
        Me.dtpDate.TabIndex = 17
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(63, 170)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(57, 20)
        Me.celdaMoneda.TabIndex = 16
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(63, 141)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(100, 20)
        Me.celdaNIT.TabIndex = 15
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(63, 46)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(57, 20)
        Me.celdaNumero.TabIndex = 12
        '
        'celdaNombre
        '
        Me.celdaNombre.Location = New System.Drawing.Point(63, 69)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(172, 20)
        Me.celdaNombre.TabIndex = 11
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(63, 91)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(264, 40)
        Me.celdaDescripcion.TabIndex = 10
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(201, 27)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 9
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(63, 24)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(57, 20)
        Me.celdaAño.TabIndex = 8
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 177)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 7
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(9, 148)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(34, 13)
        Me.etiquetaNIT.TabIndex = 5
        Me.etiquetaNIT.Text = "N.I.T."
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(9, 94)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaDireccion.TabIndex = 3
        Me.etiquetaDireccion.Text = "Direction"
        '
        'etiquetaNombre
        '
        Me.etiquetaNombre.AutoSize = True
        Me.etiquetaNombre.Location = New System.Drawing.Point(9, 72)
        Me.etiquetaNombre.Name = "etiquetaNombre"
        Me.etiquetaNombre.Size = New System.Drawing.Size(35, 13)
        Me.etiquetaNombre.TabIndex = 2
        Me.etiquetaNombre.Text = "Name"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(9, 49)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(9, 27)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'etiquetaDocRelacionado
        '
        Me.etiquetaDocRelacionado.AutoSize = True
        Me.etiquetaDocRelacionado.Location = New System.Drawing.Point(288, 761)
        Me.etiquetaDocRelacionado.Name = "etiquetaDocRelacionado"
        Me.etiquetaDocRelacionado.Size = New System.Drawing.Size(173, 13)
        Me.etiquetaDocRelacionado.TabIndex = 5
        Me.etiquetaDocRelacionado.Text = "Related Document (Cargo Receipt)"
        '
        'celdaIDAgregar
        '
        Me.celdaIDAgregar.Location = New System.Drawing.Point(0, 0)
        Me.celdaIDAgregar.Name = "celdaIDAgregar"
        Me.celdaIDAgregar.Size = New System.Drawing.Size(21, 20)
        Me.celdaIDAgregar.TabIndex = 26
        Me.celdaIDAgregar.Text = "-1"
        Me.celdaIDAgregar.Visible = False
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(863, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(863, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonInprimir.Location = New System.Drawing.Point(201, 12)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 41)
        Me.botonInprimir.TabIndex = 21
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'frmCartaCredito
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(863, 783)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.etiquetaDocRelacionado)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCartaCredito"
        Me.Text = "frmCartaCredito"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        Me.panelLista.PerformLayout()
        Me.panelDet.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDocumento.ResumeLayout(False)
        Me.panelDetalle3.ResumeLayout(False)
        CType(Me.dgDetalle3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle2.ResumeLayout(False)
        CType(Me.dgDetalle2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.gbDato3.ResumeLayout(False)
        Me.panelBotones.ResumeLayout(False)
        Me.panelBotones.PerformLayout()
        CType(Me.dgPedidos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbDato2.ResumeLayout(False)
        Me.gbDato2.PerformLayout()
        Me.gbDato.ResumeLayout(False)
        Me.gbDato.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents botonActualizar As System.Windows.Forms.Button
    Friend WithEvents etiquetaDate As System.Windows.Forms.Label
    Friend WithEvents dtpFinal As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents panelDet As System.Windows.Forms.Panel
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents panelDetalle3 As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle3 As System.Windows.Forms.DataGridView
    Friend WithEvents colLine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colYear As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCarta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescargo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colBalance As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelDetalle2 As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle2 As System.Windows.Forms.DataGridView
    Friend WithEvents colSubdocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents coldato As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMedida As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFSD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLSD As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFabricante As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents celdaTot As System.Windows.Forms.TextBox
    Friend WithEvents celdaQuantity As System.Windows.Forms.TextBox
    Friend WithEvents celdaCanti As System.Windows.Forms.TextBox
    Friend WithEvents celdaLinea As System.Windows.Forms.TextBox
    Friend WithEvents gbDato3 As System.Windows.Forms.GroupBox
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonDescargar As System.Windows.Forms.Button
    Friend WithEvents botonAgregar As System.Windows.Forms.Button
    Friend WithEvents dgPedidos As System.Windows.Forms.DataGridView
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAño As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOrder As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDischarge As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gbDato2 As System.Windows.Forms.GroupBox
    Friend WithEvents celdaTolerancia As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTolerancia As System.Windows.Forms.Label
    Friend WithEvents celdaFirmante As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaReferencia As System.Windows.Forms.Label
    Friend WithEvents celdaNCarta As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNCarta As System.Windows.Forms.Label
    Friend WithEvents gbDato As System.Windows.Forms.GroupBox
    Friend WithEvents celdaIDMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDNombre As System.Windows.Forms.TextBox
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents botonNombre As System.Windows.Forms.Button
    Friend WithEvents celdaTasa As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTasa As System.Windows.Forms.Label
    Friend WithEvents etiquetaFech As System.Windows.Forms.Label
    Friend WithEvents dtpDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents celdaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents celdaNIT As System.Windows.Forms.TextBox
    Friend WithEvents celdaNumero As System.Windows.Forms.TextBox
    Friend WithEvents celdaNombre As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaMoneda As System.Windows.Forms.Label
    Friend WithEvents etiquetaNIT As System.Windows.Forms.Label
    Friend WithEvents etiquetaDireccion As System.Windows.Forms.Label
    Friend WithEvents etiquetaNombre As System.Windows.Forms.Label
    Friend WithEvents etiquetaNumero As System.Windows.Forms.Label
    Friend WithEvents etiquetaAño As System.Windows.Forms.Label
    Friend WithEvents panelBotones As System.Windows.Forms.Panel
    Friend WithEvents etiquetaDocRelacionado As System.Windows.Forms.Label
    Friend WithEvents celdaIDAgregar As System.Windows.Forms.TextBox
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
End Class
