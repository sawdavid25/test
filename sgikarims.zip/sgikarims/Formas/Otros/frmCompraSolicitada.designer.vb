﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCompraSolicitada
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCompraSolicitada))
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReason = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colJob = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgCotizacion = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.botonAbajo = New System.Windows.Forms.Button()
        Me.botonUp = New System.Windows.Forms.Button()
        Me.PanelPiePagina = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckActivo = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaIdSolicitado = New System.Windows.Forms.TextBox()
        Me.botonSolicitado = New System.Windows.Forms.Button()
        Me.celdaRason = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaSolicitado = New System.Windows.Forms.TextBox()
        Me.celdaNombre = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgCotizacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Location = New System.Drawing.Point(12, 149)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(743, 64)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo1, Me.colAño, Me.colName, Me.colReason, Me.colJob, Me.colEstado2})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(743, 64)
        Me.dgLista.TabIndex = 0
        '
        'colCodigo1
        '
        Me.colCodigo1.HeaderText = "Code"
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.ReadOnly = True
        '
        'colAño
        '
        Me.colAño.HeaderText = "YEAR"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colName
        '
        Me.colName.HeaderText = "Name"
        Me.colName.Name = "colName"
        Me.colName.ReadOnly = True
        '
        'colReason
        '
        Me.colReason.HeaderText = "Reason"
        Me.colReason.Name = "colReason"
        Me.colReason.ReadOnly = True
        '
        'colJob
        '
        Me.colJob.HeaderText = "Job"
        Me.colJob.Name = "colJob"
        Me.colJob.ReadOnly = True
        '
        'colEstado2
        '
        Me.colEstado2.HeaderText = "Status"
        Me.colEstado2.Name = "colEstado2"
        Me.colEstado2.ReadOnly = True
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.PanelDetalle)
        Me.PanelDocumento.Controls.Add(Me.PanelPiePagina)
        Me.PanelDocumento.Controls.Add(Me.GroupBox1)
        Me.PanelDocumento.Location = New System.Drawing.Point(12, 236)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(715, 461)
        Me.PanelDocumento.TabIndex = 3
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgCotizacion)
        Me.PanelDetalle.Controls.Add(Me.Panel1)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 204)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(715, 165)
        Me.PanelDetalle.TabIndex = 3
        '
        'dgCotizacion
        '
        Me.dgCotizacion.AllowUserToAddRows = False
        Me.dgCotizacion.AllowUserToDeleteRows = False
        Me.dgCotizacion.AllowUserToOrderColumns = True
        Me.dgCotizacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgCotizacion.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgCotizacion.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgCotizacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCotizacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colArticulo, Me.colCantidad, Me.colMedida, Me.colIdMedida, Me.colComentario, Me.colLinea, Me.colAnio, Me.colEstado})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgCotizacion.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgCotizacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCotizacion.Location = New System.Drawing.Point(0, 0)
        Me.dgCotizacion.MultiSelect = False
        Me.dgCotizacion.Name = "dgCotizacion"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgCotizacion.RowTemplate.Height = 24
        Me.dgCotizacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCotizacion.Size = New System.Drawing.Size(660, 165)
        Me.dgCotizacion.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colArticulo
        '
        Me.colArticulo.HeaderText = "Product"
        Me.colArticulo.Name = "colArticulo"
        Me.colArticulo.ReadOnly = True
        Me.colArticulo.Width = 86
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 90
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.Width = 92
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "Id"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 48
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Comment"
        Me.colComentario.Name = "colComentario"
        Me.colComentario.Width = 96
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 64
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.Visible = False
        Me.colAnio.Width = 67
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.Visible = False
        Me.colEstado.Width = 77
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.botonAbajo)
        Me.Panel1.Controls.Add(Me.botonUp)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(660, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(55, 165)
        Me.Panel1.TabIndex = 13
        '
        'botonAbajo
        '
        Me.botonAbajo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAbajo.Location = New System.Drawing.Point(8, 48)
        Me.botonAbajo.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAbajo.Name = "botonAbajo"
        Me.botonAbajo.Size = New System.Drawing.Size(43, 31)
        Me.botonAbajo.TabIndex = 32
        Me.botonAbajo.UseVisualStyleBackColor = True
        '
        'botonUp
        '
        Me.botonUp.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonUp.Location = New System.Drawing.Point(8, 16)
        Me.botonUp.Margin = New System.Windows.Forms.Padding(4)
        Me.botonUp.Name = "botonUp"
        Me.botonUp.Size = New System.Drawing.Size(43, 28)
        Me.botonUp.TabIndex = 31
        Me.botonUp.UseVisualStyleBackColor = True
        '
        'PanelPiePagina
        '
        Me.PanelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelPiePagina.Location = New System.Drawing.Point(0, 369)
        Me.PanelPiePagina.Name = "PanelPiePagina"
        Me.PanelPiePagina.Size = New System.Drawing.Size(715, 92)
        Me.PanelPiePagina.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CheckActivo)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.dtpFecha)
        Me.GroupBox1.Controls.Add(Me.celdaIdSolicitado)
        Me.GroupBox1.Controls.Add(Me.botonSolicitado)
        Me.GroupBox1.Controls.Add(Me.celdaRason)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.celdaSolicitado)
        Me.GroupBox1.Controls.Add(Me.celdaNombre)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.celdaCodigo)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(715, 204)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        '
        'CheckActivo
        '
        Me.CheckActivo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckActivo.AutoSize = True
        Me.CheckActivo.Checked = True
        Me.CheckActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckActivo.Location = New System.Drawing.Point(540, 21)
        Me.CheckActivo.Name = "CheckActivo"
        Me.CheckActivo.Size = New System.Drawing.Size(68, 21)
        Me.CheckActivo.TabIndex = 11
        Me.CheckActivo.Text = "Active"
        Me.CheckActivo.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAño.Location = New System.Drawing.Point(140, 18)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(170, 22)
        Me.celdaAño.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 17)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "YEAR"
        '
        'dtpFecha
        '
        Me.dtpFecha.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(474, 51)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(200, 22)
        Me.dtpFecha.TabIndex = 8
        '
        'celdaIdSolicitado
        '
        Me.celdaIdSolicitado.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdSolicitado.Location = New System.Drawing.Point(140, 163)
        Me.celdaIdSolicitado.Name = "celdaIdSolicitado"
        Me.celdaIdSolicitado.Size = New System.Drawing.Size(170, 22)
        Me.celdaIdSolicitado.TabIndex = 7
        '
        'botonSolicitado
        '
        Me.botonSolicitado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSolicitado.Location = New System.Drawing.Point(349, 162)
        Me.botonSolicitado.Name = "botonSolicitado"
        Me.botonSolicitado.Size = New System.Drawing.Size(51, 23)
        Me.botonSolicitado.TabIndex = 6
        Me.botonSolicitado.Text = "..."
        Me.botonSolicitado.UseVisualStyleBackColor = True
        '
        'celdaRason
        '
        Me.celdaRason.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRason.Location = New System.Drawing.Point(140, 126)
        Me.celdaRason.Name = "celdaRason"
        Me.celdaRason.Size = New System.Drawing.Size(170, 22)
        Me.celdaRason.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 168)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 17)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "REQUESTED BY"
        '
        'celdaSolicitado
        '
        Me.celdaSolicitado.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSolicitado.Location = New System.Drawing.Point(437, 126)
        Me.celdaSolicitado.Name = "celdaSolicitado"
        Me.celdaSolicitado.Size = New System.Drawing.Size(170, 22)
        Me.celdaSolicitado.TabIndex = 3
        Me.celdaSolicitado.Visible = False
        '
        'celdaNombre
        '
        Me.celdaNombre.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNombre.Location = New System.Drawing.Point(140, 89)
        Me.celdaNombre.Name = "celdaNombre"
        Me.celdaNombre.Size = New System.Drawing.Size(170, 22)
        Me.celdaNombre.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "REASON"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(7, 89)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "NAME"
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCodigo.Location = New System.Drawing.Point(140, 51)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(170, 22)
        Me.celdaCodigo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "CODE"
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = CType(resources.GetObject("botonInprimir.Image"), System.Drawing.Image)
        Me.botonInprimir.Location = New System.Drawing.Point(274, 13)
        Me.botonInprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(79, 55)
        Me.botonInprimir.TabIndex = 21
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(875, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(875, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCompraSolicitada
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(875, 720)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCompraSolicitada"
        Me.Text = "frmCompraSolicitada"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgCotizacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaSolicitado As TextBox
    Friend WithEvents celdaNombre As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaCodigo As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PanelPiePagina As Panel
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgCotizacion As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents botonAbajo As Button
    Friend WithEvents botonUp As Button
    Friend WithEvents celdaRason As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents botonSolicitado As Button
    Friend WithEvents celdaIdSolicitado As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents CheckActivo As System.Windows.Forms.CheckBox
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colName As DataGridViewTextBoxColumn
    Friend WithEvents colReason As DataGridViewTextBoxColumn
    Friend WithEvents colJob As DataGridViewTextBoxColumn
    Friend WithEvents colEstado2 As DataGridViewTextBoxColumn
    Friend WithEvents botonInprimir As Button
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colArticulo As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colComentario As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
End Class
