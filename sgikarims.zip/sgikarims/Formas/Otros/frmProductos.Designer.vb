﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmProductos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmProductos))
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDCorta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDLarga = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescrpcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClase = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTitulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelFiltro = New System.Windows.Forms.Panel()
        Me.celdaType = New System.Windows.Forms.TextBox()
        Me.butonType = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.panelDetalle2 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colItem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colClave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDesComponente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPorcentaje = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMerma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonAdd = New System.Windows.Forms.Button()
        Me.botonDelete = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.checkExcento = New System.Windows.Forms.CheckBox()
        Me.checkOrganico = New System.Windows.Forms.CheckBox()
        Me.celdaIdMicronaire = New System.Windows.Forms.TextBox()
        Me.botonMicronaire = New System.Windows.Forms.Button()
        Me.celdaMicronaire = New System.Windows.Forms.TextBox()
        Me.etiquetaMicronaire = New System.Windows.Forms.Label()
        Me.checkProduccion = New System.Windows.Forms.CheckBox()
        Me.checkReciclado = New System.Windows.Forms.CheckBox()
        Me.celdaNombreProducto = New System.Windows.Forms.TextBox()
        Me.etiquetaNombreProducto = New System.Windows.Forms.Label()
        Me.celdaIDClasificacion = New System.Windows.Forms.TextBox()
        Me.botonClasificacion = New System.Windows.Forms.Button()
        Me.celdaClasificacion = New System.Windows.Forms.TextBox()
        Me.etiquetaClasificacion = New System.Windows.Forms.Label()
        Me.checkActivar = New System.Windows.Forms.CheckBox()
        Me.botonTexturizado = New System.Windows.Forms.Button()
        Me.celdaTexturizado = New System.Windows.Forms.TextBox()
        Me.etiquetaTexturizado = New System.Windows.Forms.Label()
        Me.celdaIDFilamento = New System.Windows.Forms.TextBox()
        Me.botonFilamento = New System.Windows.Forms.Button()
        Me.celdaFilamento = New System.Windows.Forms.TextBox()
        Me.etiquetaFilamento = New System.Windows.Forms.Label()
        Me.celdaIDDenier = New System.Windows.Forms.TextBox()
        Me.botonDenier = New System.Windows.Forms.Button()
        Me.celdaDenier = New System.Windows.Forms.TextBox()
        Me.etiquetaDenier = New System.Windows.Forms.Label()
        Me.celdaIDTexturizado = New System.Windows.Forms.TextBox()
        Me.celdaIDSpinning = New System.Windows.Forms.TextBox()
        Me.celdaIDAcabado = New System.Windows.Forms.TextBox()
        Me.celdaIDClase = New System.Windows.Forms.TextBox()
        Me.gbHeather = New System.Windows.Forms.GroupBox()
        Me.rbNo = New System.Windows.Forms.RadioButton()
        Me.rbSi = New System.Windows.Forms.RadioButton()
        Me.botonSpinning = New System.Windows.Forms.Button()
        Me.botonAcabado = New System.Windows.Forms.Button()
        Me.botonClase = New System.Windows.Forms.Button()
        Me.celdaSpinning = New System.Windows.Forms.TextBox()
        Me.celdaTitulo = New System.Windows.Forms.TextBox()
        Me.etiquetaSpinning = New System.Windows.Forms.Label()
        Me.etiquetaTitulo = New System.Windows.Forms.Label()
        Me.celdaAcabado = New System.Windows.Forms.TextBox()
        Me.celdaClase = New System.Windows.Forms.TextBox()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.etiquetaClase = New System.Windows.Forms.Label()
        Me.etiquetaAcabado = New System.Windows.Forms.Label()
        Me.etiquetaCodigo = New System.Windows.Forms.Label()
        Me.panelPiePagina = New System.Windows.Forms.Panel()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.celdaArancel = New System.Windows.Forms.TextBox()
        Me.etiquetaCaracteristicas = New System.Windows.Forms.Label()
        Me.etiquetaTarifa = New System.Windows.Forms.Label()
        Me.CeldaDecripcionCorta = New System.Windows.Forms.TextBox()
        Me.botonVistaPrevia = New System.Windows.Forms.Button()
        Me.celdaPartidaArancelaria = New System.Windows.Forms.TextBox()
        Me.celdaDescripcionLarga = New System.Windows.Forms.TextBox()
        Me.etiquetaPartidaArancelaria = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaDescripcionHilo3 = New System.Windows.Forms.TextBox()
        Me.celdaDescripcionHilo = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelFiltro.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.panelDetalle2.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.gbHeather.SuspendLayout()
        Me.panelPiePagina.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.PanelFiltro)
        Me.panelListaPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelListaPrincipal.Location = New System.Drawing.Point(0, 126)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(4)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(1408, 143)
        Me.panelListaPrincipal.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDCorta, Me.colDLarga, Me.colDescrpcion, Me.colClase, Me.colTitulo})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 36)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(4)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1408, 107)
        Me.dgLista.TabIndex = 0
        '
        'colCodigo
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Info
        Me.colCodigo.DefaultCellStyle = DataGridViewCellStyle1
        Me.colCodigo.HeaderText = "Codigo"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        '
        'colDCorta
        '
        Me.colDCorta.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info
        Me.colDCorta.DefaultCellStyle = DataGridViewCellStyle2
        Me.colDCorta.HeaderText = "DCorta"
        Me.colDCorta.Name = "colDCorta"
        Me.colDCorta.ReadOnly = True
        Me.colDCorta.Width = 81
        '
        'colDLarga
        '
        Me.colDLarga.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Info
        Me.colDLarga.DefaultCellStyle = DataGridViewCellStyle3
        Me.colDLarga.HeaderText = "DLarga"
        Me.colDLarga.Name = "colDLarga"
        Me.colDLarga.ReadOnly = True
        Me.colDLarga.Visible = False
        '
        'colDescrpcion
        '
        Me.colDescrpcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Info
        Me.colDescrpcion.DefaultCellStyle = DataGridViewCellStyle4
        Me.colDescrpcion.HeaderText = "Descripcion"
        Me.colDescrpcion.Name = "colDescrpcion"
        Me.colDescrpcion.ReadOnly = True
        Me.colDescrpcion.Width = 111
        '
        'colClase
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Info
        Me.colClase.DefaultCellStyle = DataGridViewCellStyle5
        Me.colClase.HeaderText = "Clase"
        Me.colClase.Name = "colClase"
        Me.colClase.ReadOnly = True
        Me.colClase.Visible = False
        '
        'colTitulo
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Info
        Me.colTitulo.DefaultCellStyle = DataGridViewCellStyle6
        Me.colTitulo.HeaderText = "Titulo"
        Me.colTitulo.Name = "colTitulo"
        Me.colTitulo.ReadOnly = True
        '
        'PanelFiltro
        '
        Me.PanelFiltro.Controls.Add(Me.celdaType)
        Me.PanelFiltro.Controls.Add(Me.butonType)
        Me.PanelFiltro.Controls.Add(Me.Label1)
        Me.PanelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.PanelFiltro.Margin = New System.Windows.Forms.Padding(4)
        Me.PanelFiltro.Name = "PanelFiltro"
        Me.PanelFiltro.Size = New System.Drawing.Size(1408, 36)
        Me.PanelFiltro.TabIndex = 15
        '
        'celdaType
        '
        Me.celdaType.Location = New System.Drawing.Point(155, 4)
        Me.celdaType.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaType.Name = "celdaType"
        Me.celdaType.ReadOnly = True
        Me.celdaType.Size = New System.Drawing.Size(159, 22)
        Me.celdaType.TabIndex = 12
        '
        'butonType
        '
        Me.butonType.Location = New System.Drawing.Point(323, 1)
        Me.butonType.Margin = New System.Windows.Forms.Padding(4)
        Me.butonType.Name = "butonType"
        Me.butonType.Size = New System.Drawing.Size(53, 28)
        Me.butonType.TabIndex = 13
        Me.butonType.Text = "..."
        Me.butonType.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(5, 7)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(144, 17)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Select Product Type :"
        '
        'panelDetalle
        '
        Me.panelDetalle.Controls.Add(Me.panelDetalle2)
        Me.panelDetalle.Controls.Add(Me.panelEncabezado)
        Me.panelDetalle.Controls.Add(Me.panelPiePagina)
        Me.panelDetalle.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDetalle.Location = New System.Drawing.Point(0, 269)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1408, 682)
        Me.panelDetalle.TabIndex = 3
        '
        'panelDetalle2
        '
        Me.panelDetalle2.Controls.Add(Me.dgDetalle)
        Me.panelDetalle2.Controls.Add(Me.Panel2)
        Me.panelDetalle2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDetalle2.Location = New System.Drawing.Point(0, 233)
        Me.panelDetalle2.Margin = New System.Windows.Forms.Padding(4)
        Me.panelDetalle2.Name = "panelDetalle2"
        Me.panelDetalle2.Size = New System.Drawing.Size(1408, 157)
        Me.panelDetalle2.TabIndex = 1
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEmpresa, Me.colArt, Me.colItem, Me.colNumero, Me.colClave, Me.colDesComponente, Me.colPorcentaje, Me.colXtra, Me.colMerma})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(4)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.Size = New System.Drawing.Size(1313, 157)
        Me.dgDetalle.TabIndex = 0
        '
        'colEmpresa
        '
        Me.colEmpresa.HeaderText = "Empresa"
        Me.colEmpresa.Name = "colEmpresa"
        Me.colEmpresa.ReadOnly = True
        Me.colEmpresa.Visible = False
        '
        'colArt
        '
        Me.colArt.HeaderText = "Articulo"
        Me.colArt.Name = "colArt"
        Me.colArt.ReadOnly = True
        Me.colArt.Visible = False
        '
        'colItem
        '
        Me.colItem.HeaderText = "Item"
        Me.colItem.Name = "colItem"
        Me.colItem.ReadOnly = True
        Me.colItem.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colClave
        '
        Me.colClave.HeaderText = "Key"
        Me.colClave.Name = "colClave"
        Me.colClave.ReadOnly = True
        '
        'colDesComponente
        '
        Me.colDesComponente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDesComponente.HeaderText = "Component Description"
        Me.colDesComponente.Name = "colDesComponente"
        Me.colDesComponente.ReadOnly = True
        '
        'colPorcentaje
        '
        Me.colPorcentaje.HeaderText = "Porcentage"
        Me.colPorcentaje.Name = "colPorcentaje"
        '
        'colXtra
        '
        Me.colXtra.HeaderText = "Xtra"
        Me.colXtra.Name = "colXtra"
        Me.colXtra.Visible = False
        '
        'colMerma
        '
        Me.colMerma.HeaderText = "Merma"
        Me.colMerma.Name = "colMerma"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonAdd)
        Me.Panel2.Controls.Add(Me.botonDelete)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(1313, 0)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(95, 157)
        Me.Panel2.TabIndex = 3
        '
        'botonAdd
        '
        Me.botonAdd.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAdd.Image = CType(resources.GetObject("botonAdd.Image"), System.Drawing.Image)
        Me.botonAdd.Location = New System.Drawing.Point(7, 12)
        Me.botonAdd.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAdd.Name = "botonAdd"
        Me.botonAdd.Size = New System.Drawing.Size(52, 46)
        Me.botonAdd.TabIndex = 1
        Me.botonAdd.UseVisualStyleBackColor = True
        '
        'botonDelete
        '
        Me.botonDelete.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonDelete.Image = CType(resources.GetObject("botonDelete.Image"), System.Drawing.Image)
        Me.botonDelete.Location = New System.Drawing.Point(7, 73)
        Me.botonDelete.Margin = New System.Windows.Forms.Padding(4)
        Me.botonDelete.Name = "botonDelete"
        Me.botonDelete.Size = New System.Drawing.Size(52, 46)
        Me.botonDelete.TabIndex = 2
        Me.botonDelete.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.checkExcento)
        Me.panelEncabezado.Controls.Add(Me.checkOrganico)
        Me.panelEncabezado.Controls.Add(Me.celdaIdMicronaire)
        Me.panelEncabezado.Controls.Add(Me.botonMicronaire)
        Me.panelEncabezado.Controls.Add(Me.celdaMicronaire)
        Me.panelEncabezado.Controls.Add(Me.etiquetaMicronaire)
        Me.panelEncabezado.Controls.Add(Me.checkProduccion)
        Me.panelEncabezado.Controls.Add(Me.checkReciclado)
        Me.panelEncabezado.Controls.Add(Me.celdaNombreProducto)
        Me.panelEncabezado.Controls.Add(Me.etiquetaNombreProducto)
        Me.panelEncabezado.Controls.Add(Me.celdaIDClasificacion)
        Me.panelEncabezado.Controls.Add(Me.botonClasificacion)
        Me.panelEncabezado.Controls.Add(Me.celdaClasificacion)
        Me.panelEncabezado.Controls.Add(Me.etiquetaClasificacion)
        Me.panelEncabezado.Controls.Add(Me.checkActivar)
        Me.panelEncabezado.Controls.Add(Me.botonTexturizado)
        Me.panelEncabezado.Controls.Add(Me.celdaTexturizado)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTexturizado)
        Me.panelEncabezado.Controls.Add(Me.celdaIDFilamento)
        Me.panelEncabezado.Controls.Add(Me.botonFilamento)
        Me.panelEncabezado.Controls.Add(Me.celdaFilamento)
        Me.panelEncabezado.Controls.Add(Me.etiquetaFilamento)
        Me.panelEncabezado.Controls.Add(Me.celdaIDDenier)
        Me.panelEncabezado.Controls.Add(Me.botonDenier)
        Me.panelEncabezado.Controls.Add(Me.celdaDenier)
        Me.panelEncabezado.Controls.Add(Me.etiquetaDenier)
        Me.panelEncabezado.Controls.Add(Me.celdaIDTexturizado)
        Me.panelEncabezado.Controls.Add(Me.celdaIDSpinning)
        Me.panelEncabezado.Controls.Add(Me.celdaIDAcabado)
        Me.panelEncabezado.Controls.Add(Me.celdaIDClase)
        Me.panelEncabezado.Controls.Add(Me.gbHeather)
        Me.panelEncabezado.Controls.Add(Me.botonSpinning)
        Me.panelEncabezado.Controls.Add(Me.botonAcabado)
        Me.panelEncabezado.Controls.Add(Me.botonClase)
        Me.panelEncabezado.Controls.Add(Me.celdaSpinning)
        Me.panelEncabezado.Controls.Add(Me.celdaTitulo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaSpinning)
        Me.panelEncabezado.Controls.Add(Me.etiquetaTitulo)
        Me.panelEncabezado.Controls.Add(Me.celdaAcabado)
        Me.panelEncabezado.Controls.Add(Me.celdaClase)
        Me.panelEncabezado.Controls.Add(Me.celdaCodigo)
        Me.panelEncabezado.Controls.Add(Me.etiquetaClase)
        Me.panelEncabezado.Controls.Add(Me.etiquetaAcabado)
        Me.panelEncabezado.Controls.Add(Me.etiquetaCodigo)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(4)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1408, 233)
        Me.panelEncabezado.TabIndex = 0
        '
        'checkExcento
        '
        Me.checkExcento.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkExcento.AutoSize = True
        Me.checkExcento.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkExcento.ForeColor = System.Drawing.Color.Blue
        Me.checkExcento.Location = New System.Drawing.Point(399, 30)
        Me.checkExcento.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkExcento.Name = "checkExcento"
        Me.checkExcento.Size = New System.Drawing.Size(93, 24)
        Me.checkExcento.TabIndex = 44
        Me.checkExcento.Text = "Exempt"
        Me.checkExcento.UseVisualStyleBackColor = True
        Me.checkExcento.Visible = False
        '
        'checkOrganico
        '
        Me.checkOrganico.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkOrganico.AutoSize = True
        Me.checkOrganico.Checked = True
        Me.checkOrganico.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkOrganico.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkOrganico.ForeColor = System.Drawing.Color.Blue
        Me.checkOrganico.Location = New System.Drawing.Point(1045, 34)
        Me.checkOrganico.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkOrganico.Name = "checkOrganico"
        Me.checkOrganico.Size = New System.Drawing.Size(97, 24)
        Me.checkOrganico.TabIndex = 43
        Me.checkOrganico.Text = "Organic"
        Me.checkOrganico.UseVisualStyleBackColor = True
        '
        'celdaIdMicronaire
        '
        Me.celdaIdMicronaire.Location = New System.Drawing.Point(1004, 128)
        Me.celdaIdMicronaire.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIdMicronaire.Name = "celdaIdMicronaire"
        Me.celdaIdMicronaire.Size = New System.Drawing.Size(37, 22)
        Me.celdaIdMicronaire.TabIndex = 42
        Me.celdaIdMicronaire.Text = "0"
        Me.celdaIdMicronaire.Visible = False
        '
        'botonMicronaire
        '
        Me.botonMicronaire.Location = New System.Drawing.Point(943, 124)
        Me.botonMicronaire.Margin = New System.Windows.Forms.Padding(4)
        Me.botonMicronaire.Name = "botonMicronaire"
        Me.botonMicronaire.Size = New System.Drawing.Size(53, 28)
        Me.botonMicronaire.TabIndex = 41
        Me.botonMicronaire.Text = "..."
        Me.botonMicronaire.UseVisualStyleBackColor = True
        Me.botonMicronaire.Visible = False
        '
        'celdaMicronaire
        '
        Me.celdaMicronaire.Location = New System.Drawing.Point(780, 124)
        Me.celdaMicronaire.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaMicronaire.Name = "celdaMicronaire"
        Me.celdaMicronaire.ReadOnly = True
        Me.celdaMicronaire.Size = New System.Drawing.Size(159, 22)
        Me.celdaMicronaire.TabIndex = 40
        Me.celdaMicronaire.Visible = False
        '
        'etiquetaMicronaire
        '
        Me.etiquetaMicronaire.AutoSize = True
        Me.etiquetaMicronaire.Location = New System.Drawing.Point(697, 128)
        Me.etiquetaMicronaire.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaMicronaire.Name = "etiquetaMicronaire"
        Me.etiquetaMicronaire.Size = New System.Drawing.Size(74, 17)
        Me.etiquetaMicronaire.TabIndex = 39
        Me.etiquetaMicronaire.Text = "Micronaire"
        Me.etiquetaMicronaire.Visible = False
        '
        'checkProduccion
        '
        Me.checkProduccion.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkProduccion.AutoSize = True
        Me.checkProduccion.Checked = True
        Me.checkProduccion.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkProduccion.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkProduccion.ForeColor = System.Drawing.Color.Blue
        Me.checkProduccion.Location = New System.Drawing.Point(236, 30)
        Me.checkProduccion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkProduccion.Name = "checkProduccion"
        Me.checkProduccion.Size = New System.Drawing.Size(121, 24)
        Me.checkProduccion.TabIndex = 38
        Me.checkProduccion.Text = "Production"
        Me.checkProduccion.UseVisualStyleBackColor = True
        '
        'checkReciclado
        '
        Me.checkReciclado.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkReciclado.AutoSize = True
        Me.checkReciclado.Checked = True
        Me.checkReciclado.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkReciclado.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkReciclado.ForeColor = System.Drawing.Color.Blue
        Me.checkReciclado.Location = New System.Drawing.Point(1183, 34)
        Me.checkReciclado.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkReciclado.Name = "checkReciclado"
        Me.checkReciclado.Size = New System.Drawing.Size(113, 24)
        Me.checkReciclado.TabIndex = 37
        Me.checkReciclado.Text = "Recycling"
        Me.checkReciclado.UseVisualStyleBackColor = True
        '
        'celdaNombreProducto
        '
        Me.celdaNombreProducto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNombreProducto.Location = New System.Drawing.Point(773, 80)
        Me.celdaNombreProducto.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaNombreProducto.Multiline = True
        Me.celdaNombreProducto.Name = "celdaNombreProducto"
        Me.celdaNombreProducto.Size = New System.Drawing.Size(369, 31)
        Me.celdaNombreProducto.TabIndex = 36
        '
        'etiquetaNombreProducto
        '
        Me.etiquetaNombreProducto.AutoSize = True
        Me.etiquetaNombreProducto.Location = New System.Drawing.Point(668, 87)
        Me.etiquetaNombreProducto.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaNombreProducto.Name = "etiquetaNombreProducto"
        Me.etiquetaNombreProducto.Size = New System.Drawing.Size(98, 17)
        Me.etiquetaNombreProducto.TabIndex = 35
        Me.etiquetaNombreProducto.Text = "Product Name"
        '
        'celdaIDClasificacion
        '
        Me.celdaIDClasificacion.Location = New System.Drawing.Point(279, 203)
        Me.celdaIDClasificacion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDClasificacion.Name = "celdaIDClasificacion"
        Me.celdaIDClasificacion.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDClasificacion.TabIndex = 33
        Me.celdaIDClasificacion.Text = "0"
        Me.celdaIDClasificacion.Visible = False
        '
        'botonClasificacion
        '
        Me.botonClasificacion.Location = New System.Drawing.Point(285, 167)
        Me.botonClasificacion.Margin = New System.Windows.Forms.Padding(4)
        Me.botonClasificacion.Name = "botonClasificacion"
        Me.botonClasificacion.Size = New System.Drawing.Size(47, 28)
        Me.botonClasificacion.TabIndex = 32
        Me.botonClasificacion.Text = "..."
        Me.botonClasificacion.UseVisualStyleBackColor = True
        '
        'celdaClasificacion
        '
        Me.celdaClasificacion.Location = New System.Drawing.Point(104, 170)
        Me.celdaClasificacion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaClasificacion.Name = "celdaClasificacion"
        Me.celdaClasificacion.ReadOnly = True
        Me.celdaClasificacion.Size = New System.Drawing.Size(172, 22)
        Me.celdaClasificacion.TabIndex = 31
        '
        'etiquetaClasificacion
        '
        Me.etiquetaClasificacion.AutoSize = True
        Me.etiquetaClasificacion.Location = New System.Drawing.Point(17, 177)
        Me.etiquetaClasificacion.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaClasificacion.Name = "etiquetaClasificacion"
        Me.etiquetaClasificacion.Size = New System.Drawing.Size(90, 17)
        Me.etiquetaClasificacion.TabIndex = 30
        Me.etiquetaClasificacion.Text = "Classification"
        '
        'checkActivar
        '
        Me.checkActivar.AutoSize = True
        Me.checkActivar.Checked = True
        Me.checkActivar.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkActivar.ForeColor = System.Drawing.Color.ForestGreen
        Me.checkActivar.Location = New System.Drawing.Point(27, 34)
        Me.checkActivar.Margin = New System.Windows.Forms.Padding(4)
        Me.checkActivar.Name = "checkActivar"
        Me.checkActivar.Size = New System.Drawing.Size(89, 28)
        Me.checkActivar.TabIndex = 29
        Me.checkActivar.Text = "Active"
        Me.checkActivar.UseVisualStyleBackColor = True
        '
        'botonTexturizado
        '
        Me.botonTexturizado.Location = New System.Drawing.Point(1076, 78)
        Me.botonTexturizado.Margin = New System.Windows.Forms.Padding(4)
        Me.botonTexturizado.Name = "botonTexturizado"
        Me.botonTexturizado.Size = New System.Drawing.Size(53, 28)
        Me.botonTexturizado.TabIndex = 28
        Me.botonTexturizado.Text = "..."
        Me.botonTexturizado.UseVisualStyleBackColor = True
        Me.botonTexturizado.Visible = False
        '
        'celdaTexturizado
        '
        Me.celdaTexturizado.Location = New System.Drawing.Point(773, 82)
        Me.celdaTexturizado.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTexturizado.Name = "celdaTexturizado"
        Me.celdaTexturizado.ReadOnly = True
        Me.celdaTexturizado.Size = New System.Drawing.Size(293, 22)
        Me.celdaTexturizado.TabIndex = 27
        Me.celdaTexturizado.Visible = False
        '
        'etiquetaTexturizado
        '
        Me.etiquetaTexturizado.AutoSize = True
        Me.etiquetaTexturizado.Location = New System.Drawing.Point(697, 87)
        Me.etiquetaTexturizado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTexturizado.Name = "etiquetaTexturizado"
        Me.etiquetaTexturizado.Size = New System.Drawing.Size(64, 17)
        Me.etiquetaTexturizado.TabIndex = 26
        Me.etiquetaTexturizado.Text = "Textured"
        Me.etiquetaTexturizado.Visible = False
        '
        'celdaIDFilamento
        '
        Me.celdaIDFilamento.Location = New System.Drawing.Point(1137, 193)
        Me.celdaIDFilamento.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDFilamento.Name = "celdaIDFilamento"
        Me.celdaIDFilamento.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDFilamento.TabIndex = 25
        Me.celdaIDFilamento.Text = "0"
        Me.celdaIDFilamento.Visible = False
        '
        'botonFilamento
        '
        Me.botonFilamento.Location = New System.Drawing.Point(1076, 166)
        Me.botonFilamento.Margin = New System.Windows.Forms.Padding(4)
        Me.botonFilamento.Name = "botonFilamento"
        Me.botonFilamento.Size = New System.Drawing.Size(53, 28)
        Me.botonFilamento.TabIndex = 24
        Me.botonFilamento.Text = "..."
        Me.botonFilamento.UseVisualStyleBackColor = True
        Me.botonFilamento.Visible = False
        '
        'celdaFilamento
        '
        Me.celdaFilamento.Location = New System.Drawing.Point(780, 169)
        Me.celdaFilamento.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaFilamento.Name = "celdaFilamento"
        Me.celdaFilamento.Size = New System.Drawing.Size(288, 22)
        Me.celdaFilamento.TabIndex = 23
        Me.celdaFilamento.Visible = False
        '
        'etiquetaFilamento
        '
        Me.etiquetaFilamento.AutoSize = True
        Me.etiquetaFilamento.Location = New System.Drawing.Point(697, 172)
        Me.etiquetaFilamento.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaFilamento.Name = "etiquetaFilamento"
        Me.etiquetaFilamento.Size = New System.Drawing.Size(69, 17)
        Me.etiquetaFilamento.TabIndex = 22
        Me.etiquetaFilamento.Text = "Filamento"
        Me.etiquetaFilamento.Visible = False
        '
        'celdaIDDenier
        '
        Me.celdaIDDenier.Location = New System.Drawing.Point(643, 198)
        Me.celdaIDDenier.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDDenier.Name = "celdaIDDenier"
        Me.celdaIDDenier.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDDenier.TabIndex = 21
        Me.celdaIDDenier.Text = "0"
        Me.celdaIDDenier.Visible = False
        '
        'botonDenier
        '
        Me.botonDenier.Location = New System.Drawing.Point(576, 124)
        Me.botonDenier.Margin = New System.Windows.Forms.Padding(4)
        Me.botonDenier.Name = "botonDenier"
        Me.botonDenier.Size = New System.Drawing.Size(53, 28)
        Me.botonDenier.TabIndex = 20
        Me.botonDenier.Text = "..."
        Me.botonDenier.UseVisualStyleBackColor = True
        Me.botonDenier.Visible = False
        '
        'celdaDenier
        '
        Me.celdaDenier.Location = New System.Drawing.Point(413, 124)
        Me.celdaDenier.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDenier.Name = "celdaDenier"
        Me.celdaDenier.ReadOnly = True
        Me.celdaDenier.Size = New System.Drawing.Size(159, 22)
        Me.celdaDenier.TabIndex = 19
        Me.celdaDenier.Visible = False
        '
        'etiquetaDenier
        '
        Me.etiquetaDenier.AutoSize = True
        Me.etiquetaDenier.Location = New System.Drawing.Point(360, 124)
        Me.etiquetaDenier.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaDenier.Name = "etiquetaDenier"
        Me.etiquetaDenier.Size = New System.Drawing.Size(50, 17)
        Me.etiquetaDenier.TabIndex = 18
        Me.etiquetaDenier.Text = "Denier"
        Me.etiquetaDenier.Visible = False
        '
        'celdaIDTexturizado
        '
        Me.celdaIDTexturizado.Location = New System.Drawing.Point(1076, 31)
        Me.celdaIDTexturizado.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDTexturizado.Name = "celdaIDTexturizado"
        Me.celdaIDTexturizado.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDTexturizado.TabIndex = 17
        Me.celdaIDTexturizado.Text = "0"
        Me.celdaIDTexturizado.Visible = False
        '
        'celdaIDSpinning
        '
        Me.celdaIDSpinning.Location = New System.Drawing.Point(1137, 162)
        Me.celdaIDSpinning.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDSpinning.Name = "celdaIDSpinning"
        Me.celdaIDSpinning.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDSpinning.TabIndex = 16
        Me.celdaIDSpinning.Text = "0"
        Me.celdaIDSpinning.Visible = False
        '
        'celdaIDAcabado
        '
        Me.celdaIDAcabado.Location = New System.Drawing.Point(649, 172)
        Me.celdaIDAcabado.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDAcabado.Name = "celdaIDAcabado"
        Me.celdaIDAcabado.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDAcabado.TabIndex = 15
        Me.celdaIDAcabado.Text = "0"
        Me.celdaIDAcabado.Visible = False
        '
        'celdaIDClase
        '
        Me.celdaIDClase.Location = New System.Drawing.Point(637, 84)
        Me.celdaIDClase.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaIDClase.Name = "celdaIDClase"
        Me.celdaIDClase.Size = New System.Drawing.Size(37, 22)
        Me.celdaIDClase.TabIndex = 14
        Me.celdaIDClase.Text = "0"
        Me.celdaIDClase.Visible = False
        '
        'gbHeather
        '
        Me.gbHeather.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbHeather.Controls.Add(Me.rbNo)
        Me.gbHeather.Controls.Add(Me.rbSi)
        Me.gbHeather.Location = New System.Drawing.Point(1181, 75)
        Me.gbHeather.Margin = New System.Windows.Forms.Padding(4)
        Me.gbHeather.Name = "gbHeather"
        Me.gbHeather.Padding = New System.Windows.Forms.Padding(4)
        Me.gbHeather.Size = New System.Drawing.Size(191, 78)
        Me.gbHeather.TabIndex = 13
        Me.gbHeather.TabStop = False
        Me.gbHeather.Text = "Heather"
        '
        'rbNo
        '
        Me.rbNo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.rbNo.AutoSize = True
        Me.rbNo.Location = New System.Drawing.Point(111, 37)
        Me.rbNo.Margin = New System.Windows.Forms.Padding(4)
        Me.rbNo.Name = "rbNo"
        Me.rbNo.Size = New System.Drawing.Size(47, 21)
        Me.rbNo.TabIndex = 1
        Me.rbNo.TabStop = True
        Me.rbNo.Text = "No"
        Me.rbNo.UseVisualStyleBackColor = True
        '
        'rbSi
        '
        Me.rbSi.AutoSize = True
        Me.rbSi.Location = New System.Drawing.Point(39, 37)
        Me.rbSi.Margin = New System.Windows.Forms.Padding(4)
        Me.rbSi.Name = "rbSi"
        Me.rbSi.Size = New System.Drawing.Size(41, 21)
        Me.rbSi.TabIndex = 0
        Me.rbSi.TabStop = True
        Me.rbSi.Text = "Si"
        Me.rbSi.UseVisualStyleBackColor = True
        '
        'botonSpinning
        '
        Me.botonSpinning.Location = New System.Drawing.Point(1076, 167)
        Me.botonSpinning.Margin = New System.Windows.Forms.Padding(4)
        Me.botonSpinning.Name = "botonSpinning"
        Me.botonSpinning.Size = New System.Drawing.Size(53, 28)
        Me.botonSpinning.TabIndex = 12
        Me.botonSpinning.Text = "..."
        Me.botonSpinning.UseVisualStyleBackColor = True
        Me.botonSpinning.Visible = False
        '
        'botonAcabado
        '
        Me.botonAcabado.Location = New System.Drawing.Point(581, 166)
        Me.botonAcabado.Margin = New System.Windows.Forms.Padding(4)
        Me.botonAcabado.Name = "botonAcabado"
        Me.botonAcabado.Size = New System.Drawing.Size(53, 28)
        Me.botonAcabado.TabIndex = 11
        Me.botonAcabado.Text = "..."
        Me.botonAcabado.UseVisualStyleBackColor = True
        Me.botonAcabado.Visible = False
        '
        'botonClase
        '
        Me.botonClase.Location = New System.Drawing.Point(576, 78)
        Me.botonClase.Margin = New System.Windows.Forms.Padding(4)
        Me.botonClase.Name = "botonClase"
        Me.botonClase.Size = New System.Drawing.Size(53, 28)
        Me.botonClase.TabIndex = 10
        Me.botonClase.Text = "..."
        Me.botonClase.UseVisualStyleBackColor = True
        '
        'celdaSpinning
        '
        Me.celdaSpinning.Location = New System.Drawing.Point(780, 166)
        Me.celdaSpinning.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaSpinning.Name = "celdaSpinning"
        Me.celdaSpinning.ReadOnly = True
        Me.celdaSpinning.Size = New System.Drawing.Size(288, 22)
        Me.celdaSpinning.TabIndex = 9
        Me.celdaSpinning.Visible = False
        '
        'celdaTitulo
        '
        Me.celdaTitulo.Location = New System.Drawing.Point(773, 80)
        Me.celdaTitulo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTitulo.Name = "celdaTitulo"
        Me.celdaTitulo.Size = New System.Drawing.Size(293, 22)
        Me.celdaTitulo.TabIndex = 8
        Me.celdaTitulo.Visible = False
        '
        'etiquetaSpinning
        '
        Me.etiquetaSpinning.AutoSize = True
        Me.etiquetaSpinning.Location = New System.Drawing.Point(697, 165)
        Me.etiquetaSpinning.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaSpinning.Name = "etiquetaSpinning"
        Me.etiquetaSpinning.Size = New System.Drawing.Size(63, 17)
        Me.etiquetaSpinning.TabIndex = 7
        Me.etiquetaSpinning.Text = "Spinning"
        Me.etiquetaSpinning.Visible = False
        '
        'etiquetaTitulo
        '
        Me.etiquetaTitulo.AutoSize = True
        Me.etiquetaTitulo.Location = New System.Drawing.Point(720, 80)
        Me.etiquetaTitulo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTitulo.Name = "etiquetaTitulo"
        Me.etiquetaTitulo.Size = New System.Drawing.Size(39, 17)
        Me.etiquetaTitulo.TabIndex = 6
        Me.etiquetaTitulo.Text = "Tittle"
        Me.etiquetaTitulo.Visible = False
        '
        'celdaAcabado
        '
        Me.celdaAcabado.Location = New System.Drawing.Point(413, 170)
        Me.celdaAcabado.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaAcabado.Name = "celdaAcabado"
        Me.celdaAcabado.ReadOnly = True
        Me.celdaAcabado.Size = New System.Drawing.Size(159, 22)
        Me.celdaAcabado.TabIndex = 5
        Me.celdaAcabado.Visible = False
        '
        'celdaClase
        '
        Me.celdaClase.Location = New System.Drawing.Point(408, 80)
        Me.celdaClase.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaClase.Name = "celdaClase"
        Me.celdaClase.ReadOnly = True
        Me.celdaClase.Size = New System.Drawing.Size(159, 22)
        Me.celdaClase.TabIndex = 4
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaCodigo.Location = New System.Drawing.Point(104, 76)
        Me.celdaCodigo.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.Size = New System.Drawing.Size(172, 22)
        Me.celdaCodigo.TabIndex = 3
        Me.celdaCodigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaClase
        '
        Me.etiquetaClase.AutoSize = True
        Me.etiquetaClase.Location = New System.Drawing.Point(357, 84)
        Me.etiquetaClase.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaClase.Name = "etiquetaClase"
        Me.etiquetaClase.Size = New System.Drawing.Size(42, 17)
        Me.etiquetaClase.TabIndex = 2
        Me.etiquetaClase.Text = "Class"
        '
        'etiquetaAcabado
        '
        Me.etiquetaAcabado.AutoSize = True
        Me.etiquetaAcabado.Location = New System.Drawing.Point(365, 172)
        Me.etiquetaAcabado.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaAcabado.Name = "etiquetaAcabado"
        Me.etiquetaAcabado.Size = New System.Drawing.Size(45, 17)
        Me.etiquetaAcabado.TabIndex = 1
        Me.etiquetaAcabado.Text = "Finish"
        Me.etiquetaAcabado.Visible = False
        '
        'etiquetaCodigo
        '
        Me.etiquetaCodigo.AutoSize = True
        Me.etiquetaCodigo.Location = New System.Drawing.Point(23, 80)
        Me.etiquetaCodigo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCodigo.Name = "etiquetaCodigo"
        Me.etiquetaCodigo.Size = New System.Drawing.Size(41, 17)
        Me.etiquetaCodigo.TabIndex = 0
        Me.etiquetaCodigo.Text = "Code"
        '
        'panelPiePagina
        '
        Me.panelPiePagina.Controls.Add(Me.celdaDescripcion)
        Me.panelPiePagina.Controls.Add(Me.celdaArancel)
        Me.panelPiePagina.Controls.Add(Me.etiquetaCaracteristicas)
        Me.panelPiePagina.Controls.Add(Me.etiquetaTarifa)
        Me.panelPiePagina.Controls.Add(Me.CeldaDecripcionCorta)
        Me.panelPiePagina.Controls.Add(Me.botonVistaPrevia)
        Me.panelPiePagina.Controls.Add(Me.celdaPartidaArancelaria)
        Me.panelPiePagina.Controls.Add(Me.celdaDescripcionLarga)
        Me.panelPiePagina.Controls.Add(Me.etiquetaPartidaArancelaria)
        Me.panelPiePagina.Controls.Add(Me.celdaTotal)
        Me.panelPiePagina.Controls.Add(Me.celdaDescripcionHilo3)
        Me.panelPiePagina.Controls.Add(Me.celdaDescripcionHilo)
        Me.panelPiePagina.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPiePagina.Location = New System.Drawing.Point(0, 390)
        Me.panelPiePagina.Margin = New System.Windows.Forms.Padding(4)
        Me.panelPiePagina.Name = "panelPiePagina"
        Me.panelPiePagina.Size = New System.Drawing.Size(1408, 292)
        Me.panelPiePagina.TabIndex = 2
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(3, 46)
        Me.celdaDescripcion.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDescripcion.Multiline = True
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.Size = New System.Drawing.Size(585, 122)
        Me.celdaDescripcion.TabIndex = 10
        '
        'celdaArancel
        '
        Me.celdaArancel.Location = New System.Drawing.Point(515, 258)
        Me.celdaArancel.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaArancel.Name = "celdaArancel"
        Me.celdaArancel.Size = New System.Drawing.Size(73, 22)
        Me.celdaArancel.TabIndex = 21
        '
        'etiquetaCaracteristicas
        '
        Me.etiquetaCaracteristicas.AutoSize = True
        Me.etiquetaCaracteristicas.Location = New System.Drawing.Point(3, 25)
        Me.etiquetaCaracteristicas.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaCaracteristicas.Name = "etiquetaCaracteristicas"
        Me.etiquetaCaracteristicas.Size = New System.Drawing.Size(218, 17)
        Me.etiquetaCaracteristicas.TabIndex = 3
        Me.etiquetaCaracteristicas.Text = "Features(Additional Descriptions)"
        '
        'etiquetaTarifa
        '
        Me.etiquetaTarifa.AutoSize = True
        Me.etiquetaTarifa.Location = New System.Drawing.Point(451, 263)
        Me.etiquetaTarifa.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaTarifa.Name = "etiquetaTarifa"
        Me.etiquetaTarifa.Size = New System.Drawing.Size(57, 17)
        Me.etiquetaTarifa.TabIndex = 20
        Me.etiquetaTarifa.Text = "Tariff %"
        '
        'CeldaDecripcionCorta
        '
        Me.CeldaDecripcionCorta.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaDecripcionCorta.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaDecripcionCorta.Location = New System.Drawing.Point(723, 54)
        Me.CeldaDecripcionCorta.Margin = New System.Windows.Forms.Padding(4)
        Me.CeldaDecripcionCorta.Multiline = True
        Me.CeldaDecripcionCorta.Name = "CeldaDecripcionCorta"
        Me.CeldaDecripcionCorta.Size = New System.Drawing.Size(668, 47)
        Me.CeldaDecripcionCorta.TabIndex = 11
        '
        'botonVistaPrevia
        '
        Me.botonVistaPrevia.Image = Global.KARIMs_SGI.My.Resources.Resources.view_next
        Me.botonVistaPrevia.Location = New System.Drawing.Point(723, 110)
        Me.botonVistaPrevia.Margin = New System.Windows.Forms.Padding(4)
        Me.botonVistaPrevia.Name = "botonVistaPrevia"
        Me.botonVistaPrevia.Size = New System.Drawing.Size(125, 58)
        Me.botonVistaPrevia.TabIndex = 14
        Me.botonVistaPrevia.Text = "Preview"
        Me.botonVistaPrevia.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonVistaPrevia.UseVisualStyleBackColor = True
        '
        'celdaPartidaArancelaria
        '
        Me.celdaPartidaArancelaria.Location = New System.Drawing.Point(93, 254)
        Me.celdaPartidaArancelaria.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaPartidaArancelaria.Name = "celdaPartidaArancelaria"
        Me.celdaPartidaArancelaria.Size = New System.Drawing.Size(291, 22)
        Me.celdaPartidaArancelaria.TabIndex = 19
        '
        'celdaDescripcionLarga
        '
        Me.celdaDescripcionLarga.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDescripcionLarga.BackColor = System.Drawing.SystemColors.Info
        Me.celdaDescripcionLarga.Location = New System.Drawing.Point(900, 110)
        Me.celdaDescripcionLarga.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDescripcionLarga.Multiline = True
        Me.celdaDescripcionLarga.Name = "celdaDescripcionLarga"
        Me.celdaDescripcionLarga.Size = New System.Drawing.Size(489, 58)
        Me.celdaDescripcionLarga.TabIndex = 15
        '
        'etiquetaPartidaArancelaria
        '
        Me.etiquetaPartidaArancelaria.AutoSize = True
        Me.etiquetaPartidaArancelaria.Location = New System.Drawing.Point(5, 263)
        Me.etiquetaPartidaArancelaria.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.etiquetaPartidaArancelaria.Name = "etiquetaPartidaArancelaria"
        Me.etiquetaPartidaArancelaria.Size = New System.Drawing.Size(71, 17)
        Me.etiquetaPartidaArancelaria.TabIndex = 18
        Me.etiquetaPartidaArancelaria.Text = "Tariff Item"
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.Enabled = False
        Me.celdaTotal.Location = New System.Drawing.Point(1268, 11)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaTotal.Multiline = True
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(123, 35)
        Me.celdaTotal.TabIndex = 9
        '
        'celdaDescripcionHilo3
        '
        Me.celdaDescripcionHilo3.Location = New System.Drawing.Point(93, 198)
        Me.celdaDescripcionHilo3.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaDescripcionHilo3.Multiline = True
        Me.celdaDescripcionHilo3.Name = "celdaDescripcionHilo3"
        Me.celdaDescripcionHilo3.Size = New System.Drawing.Size(495, 42)
        Me.celdaDescripcionHilo3.TabIndex = 17
        '
        'celdaDescripcionHilo
        '
        Me.celdaDescripcionHilo.AutoSize = True
        Me.celdaDescripcionHilo.Location = New System.Drawing.Point(5, 201)
        Me.celdaDescripcionHilo.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.celdaDescripcionHilo.Name = "celdaDescripcionHilo"
        Me.celdaDescripcionHilo.Size = New System.Drawing.Size(79, 17)
        Me.celdaDescripcionHilo.TabIndex = 16
        Me.celdaDescripcionHilo.Text = "Description"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1408, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1408, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmProductos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1429, 706)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmProductos"
        Me.Text = "frmProductos"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelFiltro.ResumeLayout(False)
        Me.PanelFiltro.PerformLayout()
        Me.panelDetalle.ResumeLayout(False)
        Me.panelDetalle2.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelEncabezado.PerformLayout()
        Me.gbHeather.ResumeLayout(False)
        Me.gbHeather.PerformLayout()
        Me.panelPiePagina.ResumeLayout(False)
        Me.panelPiePagina.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelListaPrincipal As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelDetalle As System.Windows.Forms.Panel
    Friend WithEvents celdaDescripcionLarga As System.Windows.Forms.TextBox
    Friend WithEvents botonVistaPrevia As System.Windows.Forms.Button
    Friend WithEvents CeldaDecripcionCorta As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescripcion As System.Windows.Forms.TextBox
    Friend WithEvents celdaTotal As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaCaracteristicas As System.Windows.Forms.Label
    Friend WithEvents panelDetalle2 As System.Windows.Forms.Panel
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents botonTexturizado As System.Windows.Forms.Button
    Friend WithEvents celdaTexturizado As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTexturizado As System.Windows.Forms.Label
    Friend WithEvents celdaIDFilamento As System.Windows.Forms.TextBox
    Friend WithEvents botonFilamento As System.Windows.Forms.Button
    Friend WithEvents celdaFilamento As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaFilamento As System.Windows.Forms.Label
    Friend WithEvents celdaIDDenier As System.Windows.Forms.TextBox
    Friend WithEvents botonDenier As System.Windows.Forms.Button
    Friend WithEvents celdaDenier As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaDenier As System.Windows.Forms.Label
    Friend WithEvents celdaIDTexturizado As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDSpinning As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDAcabado As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDClase As System.Windows.Forms.TextBox
    Friend WithEvents gbHeather As System.Windows.Forms.GroupBox
    Friend WithEvents rbNo As System.Windows.Forms.RadioButton
    Friend WithEvents rbSi As System.Windows.Forms.RadioButton
    Friend WithEvents botonSpinning As System.Windows.Forms.Button
    Friend WithEvents botonAcabado As System.Windows.Forms.Button
    Friend WithEvents botonClase As System.Windows.Forms.Button
    Friend WithEvents celdaSpinning As System.Windows.Forms.TextBox
    Friend WithEvents celdaTitulo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSpinning As System.Windows.Forms.Label
    Friend WithEvents etiquetaTitulo As System.Windows.Forms.Label
    Friend WithEvents celdaAcabado As System.Windows.Forms.TextBox
    Friend WithEvents celdaClase As System.Windows.Forms.TextBox
    Friend WithEvents celdaCodigo As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaClase As System.Windows.Forms.Label
    Friend WithEvents etiquetaAcabado As System.Windows.Forms.Label
    Friend WithEvents etiquetaCodigo As System.Windows.Forms.Label
    Friend WithEvents colCodigo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDCorta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDLarga As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDescrpcion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colClase As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTitulo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents checkActivar As System.Windows.Forms.CheckBox
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents botonAdd As System.Windows.Forms.Button
    Friend WithEvents botonDelete As System.Windows.Forms.Button
    Friend WithEvents celdaIDClasificacion As System.Windows.Forms.TextBox
    Friend WithEvents botonClasificacion As System.Windows.Forms.Button
    Friend WithEvents celdaClasificacion As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaClasificacion As System.Windows.Forms.Label
    Friend WithEvents celdaNombreProducto As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaNombreProducto As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents colEmpresa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colArt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colItem As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colClave As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDesComponente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPorcentaje As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colXtra As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colMerma As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelPiePagina As System.Windows.Forms.Panel
    Friend WithEvents celdaArancel As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaTarifa As System.Windows.Forms.Label
    Friend WithEvents celdaPartidaArancelaria As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaPartidaArancelaria As System.Windows.Forms.Label
    Friend WithEvents celdaDescripcionHilo3 As System.Windows.Forms.TextBox
    Friend WithEvents celdaDescripcionHilo As System.Windows.Forms.Label
    Friend WithEvents checkReciclado As System.Windows.Forms.CheckBox
    Friend WithEvents checkProduccion As System.Windows.Forms.CheckBox
    Friend WithEvents botonMicronaire As Button
    Friend WithEvents celdaMicronaire As TextBox
    Friend WithEvents etiquetaMicronaire As Label
    Friend WithEvents celdaIdMicronaire As TextBox
    Friend WithEvents checkOrganico As System.Windows.Forms.CheckBox
    Friend WithEvents PanelFiltro As Panel
    Friend WithEvents celdaType As TextBox
    Friend WithEvents butonType As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents checkExcento As System.Windows.Forms.CheckBox
End Class
