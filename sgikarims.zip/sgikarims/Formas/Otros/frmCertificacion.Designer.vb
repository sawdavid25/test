﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCertificacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colfecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.checkFiltroFecha = New System.Windows.Forms.CheckBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colFact = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLin = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoBruto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPesoNeto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNum = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelControles = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.panelButton = New System.Windows.Forms.Panel()
        Me.dgNotificacion = New System.Windows.Forms.DataGridView()
        Me.colIdNotifiaciones = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorreo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelNotificacion = New System.Windows.Forms.Panel()
        Me.botonDelete = New System.Windows.Forms.Button()
        Me.botonAñadir = New System.Windows.Forms.Button()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BotonEnviar = New System.Windows.Forms.Button()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaCertificacion = New System.Windows.Forms.Label()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaCertificacion = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.PanelCliente = New System.Windows.Forms.Panel()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaidUsuario = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.checkActive = New System.Windows.Forms.CheckBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.celdaidCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControles.SuspendLayout()
        Me.panelButton.SuspendLayout()
        CType(Me.dgNotificacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelNotificacion.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        Me.PanelCliente.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.panelFiltro)
        Me.PanelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelLista.Location = New System.Drawing.Point(0, 102)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(800, 69)
        Me.PanelLista.TabIndex = 5
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgLista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo1, Me.colAño, Me.colfecha, Me.colCliente, Me.colEstado2})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 38)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(800, 31)
        Me.dgLista.TabIndex = 0
        '
        'colCodigo1
        '
        Me.colCodigo1.HeaderText = "Code"
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.ReadOnly = True
        Me.colCodigo1.Width = 57
        '
        'colAño
        '
        Me.colAño.HeaderText = "YEAR"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        Me.colAño.Width = 61
        '
        'colfecha
        '
        Me.colfecha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colfecha.HeaderText = "Date"
        Me.colfecha.Name = "colfecha"
        Me.colfecha.ReadOnly = True
        Me.colfecha.Width = 55
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 58
        '
        'colEstado2
        '
        Me.colEstado2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colEstado2.HeaderText = "Status"
        Me.colEstado2.Name = "colEstado2"
        Me.colEstado2.ReadOnly = True
        Me.colEstado2.Width = 62
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.botonActualizar)
        Me.panelFiltro.Controls.Add(Me.checkFiltroFecha)
        Me.panelFiltro.Controls.Add(Me.dtpFechaFinal)
        Me.panelFiltro.Controls.Add(Me.dtpFechaInicial)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(800, 38)
        Me.panelFiltro.TabIndex = 4
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(474, 9)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(110, 24)
        Me.botonActualizar.TabIndex = 3
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'checkFiltroFecha
        '
        Me.checkFiltroFecha.AutoSize = True
        Me.checkFiltroFecha.Checked = True
        Me.checkFiltroFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFiltroFecha.Location = New System.Drawing.Point(10, 10)
        Me.checkFiltroFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFiltroFecha.Name = "checkFiltroFecha"
        Me.checkFiltroFecha.Size = New System.Drawing.Size(183, 17)
        Me.checkFiltroFecha.TabIndex = 0
        Me.checkFiltroFecha.Text = "Show Documents between dates"
        Me.checkFiltroFecha.UseVisualStyleBackColor = True
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(333, 10)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(215, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(114, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelButton)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDocumento.Location = New System.Drawing.Point(0, 171)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(800, 324)
        Me.panelDocumento.TabIndex = 6
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.dgDetalle)
        Me.PanelDetalle.Controls.Add(Me.PanelControles)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 155)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(800, 25)
        Me.PanelDetalle.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colFact, Me.colLin, Me.colLote, Me.colPedido, Me.colProducto, Me.colReferencia, Me.colDescripcion, Me.colIdMedida, Me.colMedida, Me.colCantidad, Me.colPesoBruto, Me.colPesoNeto, Me.colBulto, Me.colTotalC, Me.colCatalogo, Me.colAnio, Me.colNum, Me.colLinea, Me.colEstado})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(751, 25)
        Me.dgDetalle.TabIndex = 1
        '
        'colFact
        '
        Me.colFact.HeaderText = "Invoice"
        Me.colFact.Name = "colFact"
        Me.colFact.ReadOnly = True
        Me.colFact.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFact.Width = 48
        '
        'colLin
        '
        Me.colLin.HeaderText = "Line"
        Me.colLin.Name = "colLin"
        Me.colLin.ReadOnly = True
        Me.colLin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colLin.Width = 33
        '
        'colLote
        '
        Me.colLote.HeaderText = "Lot"
        Me.colLote.Name = "colLote"
        Me.colLote.ReadOnly = True
        Me.colLote.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colLote.Width = 28
        '
        'colPedido
        '
        Me.colPedido.HeaderText = "PO"
        Me.colPedido.Name = "colPedido"
        Me.colPedido.ReadOnly = True
        Me.colPedido.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPedido.Width = 28
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Product"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        Me.colProducto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colProducto.Width = 50
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        Me.colReferencia.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colReferencia.Width = 63
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colDescripcion.Width = 66
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "idMedida"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 75
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMedida.Width = 54
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.ReadOnly = True
        Me.colCantidad.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCantidad.Width = 52
        '
        'colPesoBruto
        '
        Me.colPesoBruto.HeaderText = "Gross weight (KGS)"
        Me.colPesoBruto.Name = "colPesoBruto"
        Me.colPesoBruto.ReadOnly = True
        Me.colPesoBruto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPesoBruto.Width = 95
        '
        'colPesoNeto
        '
        Me.colPesoNeto.HeaderText = "Net weight (KGS)"
        Me.colPesoNeto.Name = "colPesoNeto"
        Me.colPesoNeto.ReadOnly = True
        Me.colPesoNeto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPesoNeto.Width = 86
        '
        'colBulto
        '
        Me.colBulto.HeaderText = "Package"
        Me.colBulto.Name = "colBulto"
        Me.colBulto.Width = 75
        '
        'colTotalC
        '
        Me.colTotalC.HeaderText = "Total Certificated"
        Me.colTotalC.Name = "colTotalC"
        Me.colTotalC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTotalC.Width = 84
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        Me.colCatalogo.Width = 74
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.Visible = False
        Me.colAnio.Width = 53
        '
        'colNum
        '
        Me.colNum.HeaderText = "numero"
        Me.colNum.Name = "colNum"
        Me.colNum.Visible = False
        Me.colNum.Width = 67
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.Visible = False
        Me.colLinea.Width = 58
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.Visible = False
        Me.colEstado.Width = 65
        '
        'PanelControles
        '
        Me.PanelControles.Controls.Add(Me.botonEliminar)
        Me.PanelControles.Controls.Add(Me.botonAgregar)
        Me.PanelControles.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelControles.Location = New System.Drawing.Point(751, 0)
        Me.PanelControles.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelControles.Name = "PanelControles"
        Me.PanelControles.Size = New System.Drawing.Size(49, 25)
        Me.PanelControles.TabIndex = 2
        '
        'botonEliminar
        '
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(5, 50)
        Me.botonEliminar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(38, 19)
        Me.botonEliminar.TabIndex = 1
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(4, 14)
        Me.botonAgregar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(38, 19)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'panelButton
        '
        Me.panelButton.Controls.Add(Me.dgNotificacion)
        Me.panelButton.Controls.Add(Me.PanelNotificacion)
        Me.panelButton.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelButton.Location = New System.Drawing.Point(0, 180)
        Me.panelButton.Name = "panelButton"
        Me.panelButton.Size = New System.Drawing.Size(800, 144)
        Me.panelButton.TabIndex = 1
        '
        'dgNotificacion
        '
        Me.dgNotificacion.AllowUserToAddRows = False
        Me.dgNotificacion.AllowUserToDeleteRows = False
        Me.dgNotificacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgNotificacion.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgNotificacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgNotificacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colIdNotifiaciones, Me.colPuesto, Me.colUsuario, Me.colCodigo, Me.colObservacion, Me.colCorreo, Me.colEstatus})
        Me.dgNotificacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgNotificacion.Location = New System.Drawing.Point(0, 0)
        Me.dgNotificacion.Margin = New System.Windows.Forms.Padding(2)
        Me.dgNotificacion.MultiSelect = False
        Me.dgNotificacion.Name = "dgNotificacion"
        Me.dgNotificacion.RowTemplate.Height = 24
        Me.dgNotificacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgNotificacion.Size = New System.Drawing.Size(751, 144)
        Me.dgNotificacion.TabIndex = 4
        '
        'colIdNotifiaciones
        '
        Me.colIdNotifiaciones.HeaderText = "Notification"
        Me.colIdNotifiaciones.Name = "colIdNotifiaciones"
        Me.colIdNotifiaciones.ReadOnly = True
        Me.colIdNotifiaciones.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colIdNotifiaciones.Width = 66
        '
        'colPuesto
        '
        Me.colPuesto.HeaderText = "JOB"
        Me.colPuesto.Name = "colPuesto"
        Me.colPuesto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPuesto.Width = 33
        '
        'colUsuario
        '
        Me.colUsuario.HeaderText = "User"
        Me.colUsuario.Name = "colUsuario"
        Me.colUsuario.ReadOnly = True
        Me.colUsuario.Visible = False
        Me.colUsuario.Width = 54
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Visible = False
        Me.colCodigo.Width = 57
        '
        'colObservacion
        '
        Me.colObservacion.HeaderText = "Observation"
        Me.colObservacion.Name = "colObservacion"
        Me.colObservacion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colObservacion.Width = 70
        '
        'colCorreo
        '
        Me.colCorreo.HeaderText = "Email"
        Me.colCorreo.Name = "colCorreo"
        Me.colCorreo.Visible = False
        Me.colCorreo.Width = 57
        '
        'colEstatus
        '
        Me.colEstatus.HeaderText = "Acciones"
        Me.colEstatus.Name = "colEstatus"
        Me.colEstatus.ReadOnly = True
        Me.colEstatus.Visible = False
        Me.colEstatus.Width = 76
        '
        'PanelNotificacion
        '
        Me.PanelNotificacion.Controls.Add(Me.botonDelete)
        Me.PanelNotificacion.Controls.Add(Me.botonAñadir)
        Me.PanelNotificacion.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelNotificacion.Location = New System.Drawing.Point(751, 0)
        Me.PanelNotificacion.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelNotificacion.Name = "PanelNotificacion"
        Me.PanelNotificacion.Size = New System.Drawing.Size(49, 144)
        Me.PanelNotificacion.TabIndex = 3
        '
        'botonDelete
        '
        Me.botonDelete.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonDelete.Location = New System.Drawing.Point(5, 47)
        Me.botonDelete.Margin = New System.Windows.Forms.Padding(2)
        Me.botonDelete.Name = "botonDelete"
        Me.botonDelete.Size = New System.Drawing.Size(38, 19)
        Me.botonDelete.TabIndex = 1
        Me.botonDelete.UseVisualStyleBackColor = True
        '
        'botonAñadir
        '
        Me.botonAñadir.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAñadir.Location = New System.Drawing.Point(4, 14)
        Me.botonAñadir.Margin = New System.Windows.Forms.Padding(2)
        Me.botonAñadir.Name = "botonAñadir"
        Me.botonAñadir.Size = New System.Drawing.Size(38, 19)
        Me.botonAñadir.TabIndex = 0
        Me.botonAñadir.UseVisualStyleBackColor = True
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.panelDatos)
        Me.panelEncabezado.Controls.Add(Me.PanelCliente)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(800, 155)
        Me.panelEncabezado.TabIndex = 0
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.Label1)
        Me.panelDatos.Controls.Add(Me.BotonEnviar)
        Me.panelDatos.Controls.Add(Me.celdaTasa)
        Me.panelDatos.Controls.Add(Me.celdaidMoneda)
        Me.panelDatos.Controls.Add(Me.etiquetaCertificacion)
        Me.panelDatos.Controls.Add(Me.etiquetaTasa)
        Me.panelDatos.Controls.Add(Me.botonMoneda)
        Me.panelDatos.Controls.Add(Me.celdaMoneda)
        Me.panelDatos.Controls.Add(Me.celdaCertificacion)
        Me.panelDatos.Controls.Add(Me.etiquetaMoneda)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDatos.Location = New System.Drawing.Point(490, 0)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(310, 155)
        Me.panelDatos.TabIndex = 48
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(124, 131)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(66, 13)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "mail tracking"
        '
        'BotonEnviar
        '
        Me.BotonEnviar.Image = Global.KARIMs_SGI.My.Resources.Resources.folder_document
        Me.BotonEnviar.Location = New System.Drawing.Point(191, 126)
        Me.BotonEnviar.Name = "BotonEnviar"
        Me.BotonEnviar.Size = New System.Drawing.Size(45, 23)
        Me.BotonEnviar.TabIndex = 48
        Me.BotonEnviar.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(72, 58)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(134, 20)
        Me.celdaTasa.TabIndex = 44
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(247, 29)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.Size = New System.Drawing.Size(23, 20)
        Me.celdaidMoneda.TabIndex = 45
        Me.celdaidMoneda.Visible = False
        '
        'etiquetaCertificacion
        '
        Me.etiquetaCertificacion.AutoSize = True
        Me.etiquetaCertificacion.Location = New System.Drawing.Point(7, 89)
        Me.etiquetaCertificacion.Name = "etiquetaCertificacion"
        Me.etiquetaCertificacion.Size = New System.Drawing.Size(62, 13)
        Me.etiquetaCertificacion.TabIndex = 47
        Me.etiquetaCertificacion.Text = "Certification"
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(7, 61)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 43
        Me.etiquetaTasa.Text = "Rate"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(176, 26)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 42
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(72, 28)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(98, 20)
        Me.celdaMoneda.TabIndex = 41
        '
        'celdaCertificacion
        '
        Me.celdaCertificacion.Location = New System.Drawing.Point(72, 86)
        Me.celdaCertificacion.Name = "celdaCertificacion"
        Me.celdaCertificacion.ReadOnly = True
        Me.celdaCertificacion.Size = New System.Drawing.Size(225, 20)
        Me.celdaCertificacion.TabIndex = 46
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(7, 32)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 40
        Me.etiquetaMoneda.Text = "Currency"
        '
        'PanelCliente
        '
        Me.PanelCliente.Controls.Add(Me.celdaUsuario)
        Me.PanelCliente.Controls.Add(Me.celdaidUsuario)
        Me.PanelCliente.Controls.Add(Me.botonCliente)
        Me.PanelCliente.Controls.Add(Me.celdaDireccion)
        Me.PanelCliente.Controls.Add(Me.etiquetaAño)
        Me.PanelCliente.Controls.Add(Me.etiquetaDireccion)
        Me.PanelCliente.Controls.Add(Me.checkActive)
        Me.PanelCliente.Controls.Add(Me.celdaAño)
        Me.PanelCliente.Controls.Add(Me.celdaidCliente)
        Me.PanelCliente.Controls.Add(Me.celdaNumero)
        Me.PanelCliente.Controls.Add(Me.celdaCliente)
        Me.PanelCliente.Controls.Add(Me.etiquetaNumero)
        Me.PanelCliente.Controls.Add(Me.etiquetaCliente)
        Me.PanelCliente.Controls.Add(Me.etiquetaFecha)
        Me.PanelCliente.Controls.Add(Me.dtpFecha)
        Me.PanelCliente.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelCliente.Location = New System.Drawing.Point(0, 0)
        Me.PanelCliente.Name = "PanelCliente"
        Me.PanelCliente.Size = New System.Drawing.Size(490, 155)
        Me.PanelCliente.TabIndex = 39
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(314, 15)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(29, 20)
        Me.celdaUsuario.TabIndex = 50
        Me.celdaUsuario.Visible = False
        '
        'celdaidUsuario
        '
        Me.celdaidUsuario.Location = New System.Drawing.Point(314, 39)
        Me.celdaidUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidUsuario.Name = "celdaidUsuario"
        Me.celdaidUsuario.Size = New System.Drawing.Size(20, 20)
        Me.celdaidUsuario.TabIndex = 49
        Me.celdaidUsuario.Text = "-1"
        Me.celdaidUsuario.Visible = False
        '
        'botonCliente
        '
        Me.botonCliente.Location = New System.Drawing.Point(343, 90)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(33, 23)
        Me.botonCliente.TabIndex = 48
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion.Location = New System.Drawing.Point(63, 115)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(422, 34)
        Me.celdaDireccion.TabIndex = 43
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(3, 10)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 30
        Me.etiquetaAño.Text = "Year"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(4, 120)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 42
        Me.etiquetaDireccion.Text = "Address"
        '
        'checkActive
        '
        Me.checkActive.AutoSize = True
        Me.checkActive.Location = New System.Drawing.Point(224, 22)
        Me.checkActive.Name = "checkActive"
        Me.checkActive.Size = New System.Drawing.Size(56, 17)
        Me.checkActive.TabIndex = 38
        Me.checkActive.Text = "Active"
        Me.checkActive.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(63, 7)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.ReadOnly = True
        Me.celdaAño.Size = New System.Drawing.Size(126, 20)
        Me.celdaAño.TabIndex = 29
        '
        'celdaidCliente
        '
        Me.celdaidCliente.Location = New System.Drawing.Point(234, 62)
        Me.celdaidCliente.Name = "celdaidCliente"
        Me.celdaidCliente.Size = New System.Drawing.Size(23, 20)
        Me.celdaidCliente.TabIndex = 37
        Me.celdaidCliente.Visible = False
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(63, 35)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(126, 20)
        Me.celdaNumero.TabIndex = 31
        '
        'celdaCliente
        '
        Me.celdaCliente.Location = New System.Drawing.Point(63, 92)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(270, 20)
        Me.celdaCliente.TabIndex = 36
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(3, 38)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 32
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(4, 92)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(33, 13)
        Me.etiquetaCliente.TabIndex = 35
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(4, 65)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 33
        Me.etiquetaFecha.Text = "Date"
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(63, 65)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(126, 20)
        Me.dtpFecha.TabIndex = 34
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(800, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(800, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCertificacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 503)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCertificacion"
        Me.Text = "frmCertificacion"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControles.ResumeLayout(False)
        Me.panelButton.ResumeLayout(False)
        CType(Me.dgNotificacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelNotificacion.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.panelDatos.ResumeLayout(False)
        Me.panelDatos.PerformLayout()
        Me.PanelCliente.ResumeLayout(False)
        Me.PanelCliente.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFiltro As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents checkFiltroFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents checkActive As System.Windows.Forms.CheckBox
    Friend WithEvents celdaidCliente As TextBox
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents etiquetaAño As Label
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents PanelCliente As Panel
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents panelButton As Panel
    Friend WithEvents etiquetaCertificacion As Label
    Friend WithEvents celdaCertificacion As TextBox
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents PanelControles As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents botonCliente As Button
    Friend WithEvents PanelNotificacion As Panel
    Friend WithEvents botonDelete As Button
    Friend WithEvents botonAñadir As Button
    Friend WithEvents dgNotificacion As DataGridView
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaidUsuario As TextBox
    Friend WithEvents panelDatos As Panel
    Friend WithEvents BotonEnviar As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colfecha As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colEstado2 As DataGridViewTextBoxColumn
    Friend WithEvents colIdNotifiaciones As DataGridViewTextBoxColumn
    Friend WithEvents colPuesto As DataGridViewTextBoxColumn
    Friend WithEvents colUsuario As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colObservacion As DataGridViewTextBoxColumn
    Friend WithEvents colCorreo As DataGridViewTextBoxColumn
    Friend WithEvents colEstatus As DataGridViewTextBoxColumn
    Friend WithEvents colFact As DataGridViewTextBoxColumn
    Friend WithEvents colLin As DataGridViewTextBoxColumn
    Friend WithEvents colLote As DataGridViewTextBoxColumn
    Friend WithEvents colPedido As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPesoBruto As DataGridViewTextBoxColumn
    Friend WithEvents colPesoNeto As DataGridViewTextBoxColumn
    Friend WithEvents colBulto As DataGridViewTextBoxColumn
    Friend WithEvents colTotalC As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNum As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
End Class
