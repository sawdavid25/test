﻿Public Class frmPolizaExportacion
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim SDoc As New frmSubDocumentos
    Dim Tbl_Documentos As String = "Dcmtos_HDR"
    Dim dblTCambio As String

#End Region


#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property

    Public Property TasaCambio As String
        Get
            Return dblTCambio
        End Get
        Set(value As String)
            dblTCambio = value
        End Set
    End Property

#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else

            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
        End If
    End Sub


    Private Sub Accesos()
        Dim cAcesos As New clsAccesos
        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        If logMostrar = True Then
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            panelDocumento.Visible = False
            panelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Export Policy")

            BloquearBotones()
            ListaPrincipal()

        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Visible = True
            panelDocumento.Dock = DockStyle.Fill
            If Sesion.idGiro = 2 And Me.Tag = "Nuevo" Then
                celdaAnio.ReadOnly = False
            Else
                celdaAnio.ReadOnly = True
            End If
            BloquearBotones(False)
            End If

    End Sub

    Private Function sqlListaPrincipal()
        Dim strSql As String = STR_VACIO

        strSql = " SELECT HDoc_DR1_Dbl num2, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, HDoc_Emp_Nom nombre, ELT(COALESCE(HDoc_DR1_Cat,0)+1,'Nacionalización','Resto del Mundo','Centro América','Transferencia') Clase, IF(ADoc_Dta_Chr!='',ADoc_Dta_Chr,IF(HDoc_RF2_Txt != '',HDoc_RF2_Txt,HDoc_RF2_Txt)) Ref2, HDoc_Doc_Ano anio, HDoc_Doc_Status Estado, HDoc_DR1_Cat tipoDoc "
        strSql &= " From Dcmtos_HDR "
        strSql &= " Left JOIN Dcmtos_ACC ON ADoc_Sis_Emp = HDoc_Sis_Emp AND ADoc_Doc_Cat = HDoc_Doc_Cat AND ADoc_Doc_Ano = HDoc_Doc_Ano AND ADoc_Doc_Num = HDoc_Doc_Num AND ADoc_Doc_Sub = 'Doc_PolExp' AND ADoc_Doc_Lin = '01' "
        strSql &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=56 "
        If checkFechas.Checked = True Then
            strSql &= " AND (HDoc_Doc_Fec BETWEEN '{inicial}' AND '{final}') "
        End If
        If Not celdaClienteE.Text = vbNullString Then
            strSql &= " And (HDoc_Emp_Nom  = '{buscar}')"
            strSql = Replace(strSql, "{buscar}", celdaClienteE.Text)
        End If
        strSql &= " GROUP BY HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num "
        strSql &= " ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{inicial}", dtpInicial.Value.ToString(FORMATO_MYSQL))
        strSql = Replace(strSql, "{final}", dtpFinal.Value.ToString(FORMATO_MYSQL))

        Return strSql

    End Function


    Private Function sqlCargarDatos(ByVal numero As Integer, ByVal fecha As Date)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT HDoc_DR1_Dbl Num2, HDoc_Doc_Cat Catalogo, HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, cli_cliente Cliente, cli_codigo IdCliente, cli_direccion Direccion, cli_nit NIT, HDoc_Doc_Mon IdMoneda, HDoc_Doc_TC Tasa, cat_clave Moneda, HDoc_RF1_Dbl Flete, HDoc_RF2_Dbl Seguro, HDoc_DR1_Num Referencia, HDoc_Usuario Usuario "
        strSql &= " From Dcmtos_HDR "
        strSql &= " Left JOIN Clientes ON cli_codigo = HDoc_Emp_Cod AND cli_sisemp = {empresa} "
        strSql &= " INNER JOIN Catalogos ON cli_moneda = cat_num "
        strSql &= " WHERE HDoc_Doc_Cat = 56 AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Num = {numero} AND HDoc_Doc_Fec = '{fecha}' "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{fecha}", fecha.ToString(FORMATO_MYSQL))

        Return strSql

    End Function

    Private Function sqlDatosPoliza(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT DISTINCT HDoc_Doc_Cat Catalogo, HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_DR1_Dbl Numero2, HDoc_Doc_Fec Fecha, HDoc_Usuario Usuario, HDoc_DR1_Num Referencia,IFNULL(f.Serie,'') Serie , IFNULL(f.NumeroAutorizacion,'') Autorizacion "
        strSql &= " From Dcmtos_DTL_Pro a "
        strSql &= " INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num "
        strSql &= "     Left JOIN Fel f ON f.Empresa = a.PDoc_Sis_Emp AND f.Catalogo = a.PDoc_Par_Cat AND f.Anio = a.PDoc_Par_Ano AND f.Numero = a.PDoc_Par_Num  "
        strSql &= " WHERE a.PDoc_Sis_Emp = {empresa} AND a.PDoc_Chi_Cat = 56 AND a.PDoc_Chi_Ano = {anio} AND a.PDoc_Chi_Num = {numero} "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{anio}", anio)

        Return strSql

    End Function

    Private Function sqlCargarDetalle(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT DDoc_Sis_Emp Empresa, DDoc_Doc_Cat catalogo, DDoc_Doc_Ano Anio, DDoc_Doc_Num Numero, DDoc_Doc_Lin Linea, DDoc_Prd_Cod Codigo, DDoc_Prd_Des Descripcion, IFNULL(cat_clave,'') Medida,  DDoc_Prd_PUQ PrecioU, DDoc_Prd_DSP DescuentoPor, DDoc_Prd_DSQ DescuentoMon, DDoc_Prd_QTY Cantidad, DDoc_Prd_PNr PNR, DDoc_Prd_UM UnidadMed, EDoc_Lin_Frac Inciso, EDoc_Lin_Desc DescLinea,EDoc_Lin_Gross Brutos, EDoc_Lin_Net Netos, EDoc_Lin_Fob Fob, EDoc_Lin_Freight Flete, EDoc_Lin_Insurance Seguro, EDoc_Lin_Cargos Cargos, IFNULL(EDoc_Lin_Cif,0) CIF, IFNULL(EDoc_Lin_DAI,0) DAI, IFNULL(EDoc_Lin_IVA,0) IVA, DDoc_RF1_Num Numero, (ROUND(DDoc_Prd_NET * DDoc_Prd_Qty,2)-(DDoc_Prd_DSQ)) Lin_Subtotal, IFNULL(inv_costo,0) Costo, IFNULL(ROUND(inv_costo * DDoc_Prd_Qty,2),0) Total, IFNULL(EDoc_Lin_Cif,0) CIF, IFNULL(BDoc_Box_QTY,0) Bultos, DDoc_RF4_Dbl egress_line "
        strSql &= " From Dcmtos_DTL "
        strSql &= " Left JOIN Dcmtos_DEC ON EDoc_Sis_Emp = DDoc_Sis_Emp AND EDoc_Doc_Cat = DDoc_Doc_Cat AND EDoc_Doc_Ano = DDoc_Doc_Ano AND EDoc_Doc_Num = DDoc_Doc_Num AND EDoc_Doc_Lin = DDoc_Doc_Lin "
        strSql &= " Left JOIN Catalogos ON cat_num = DDoc_Prd_UM AND cat_clase = 'Medidas' "
        strSql &= " Left JOIN Inventarios ON inv_numero = DDoc_Prd_Cod AND inv_sisemp = {empresa} "
        strSql &= " Left JOIN Dcmtos_DTL_Box ON BDoc_Sis_Emp = DDoc_Sis_Emp AND BDoc_Doc_Cat = DDoc_Doc_Cat AND BDoc_Doc_Ano = DDoc_Doc_Ano AND BDoc_Doc_Num = DDoc_Doc_Num AND BDoc_Doc_Lin = DDoc_Doc_Lin "
        strSql &= " WHERE DDoc_Doc_Cat = 56 AND DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
        strSql &= " ORDER BY DDoc_Doc_Lin "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{numero}", numero)
        strSql = Replace(strSql, "{anio}", anio)

        Return strSql

    End Function

    Private Function sqlDatos(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT cat_clave, cat_desc, ( "
        strSql &= " Select COUNT(*) "
        strSql &= " From Dcmtos_ACC "
        strSql &= " WHERE ADoc_Sis_Emp = {empresa} AND ADoc_Doc_Cat = 56 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {numero} AND ADoc_Doc_Sub = cat_clave) AS cantidad "
        strSql &= " From Catalogos "
        strSql &= " WHERE cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_PolExp' "
        strSql &= " ORDER BY cat_clave "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function

    Private Function sqlNuevosDatosPoliza(ByVal id As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT DISTINCT HDoc_Sis_Emp, HDoc_Doc_Cat Catalogo, HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_DR1_Dbl Numero2, HDoc_Doc_Fec Fecha, IFNULL(COALESCE(HDoc_DR1_Num,''),'') Referencia, HDoc_Usuario Usuario, HDoc_RF1_Dbl Total,IFNULL(f.Serie,'') Serie  , IFNULL(f.NumeroAutorizacion,'') Autorizacion  "
        strSql &= " From Dcmtos_HDR a "
        strSql &= " Left JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num "
        strSql &= "  LEFT JOIN Fel f ON f.Empresa = a.HDoc_Sis_Emp AND f.Catalogo = a.HDoc_Doc_Cat AND f.Anio = a.HDoc_Doc_Ano AND f.Numero = a.HDoc_Doc_Num "
        strSql &= " WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 36) {anio} AND COALESCE(HDoc_DR1_Cat,0) = {tipo} AND (HDoc_Emp_Cod = {id}) AND HDoc_Doc_Status = 1 AND (COALESCE(( "
        strSql &= " Select SUM(c.PDoc_QTY_Pro) "
        strSql &= " From Dcmtos_DTL_Pro c "
        strSql &= " WHERE c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = 56), 0) < b.DDoc_Prd_QTY) "
        strSql &= " ORDER BY HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{id}", id)
        strSql = Replace(strSql, "{tipo}", IIf(intTipoDoc = 0, 0, 1))
        If Sesion.idGiro = 2 Then
            strSql = Replace(strSql, "{anio}", "AND a.HDoc_Doc_Ano = YEAR(" & "'" & celdaDate.Text & "') AND a.HDoc_Doc_Fec <= " & "'" & celdaDate.Text & "'")
        Else
            strSql = Replace(strSql, "{anio}", "")
        End If

        Return strSql

    End Function
    Public Sub DetalleSeleccionado(ByVal codigo As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim total As Double
        Dim strTemp As String = STR_VACIO
        Dim i As Integer
        strSQL = SQLDetalleSeleccionado(codigo, dgPolizaExportacion.CurrentRow.Cells("colNumeroP").Value, dgPolizaExportacion.CurrentRow.Cells("colAnioP").Value)
        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("art_DCorta") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("PrecioU") & "|"
                    strFila &= vbEmpty & "|"
                    strFila &= REA.GetDouble("descuento") & "|"
                    strFila &= REA.GetDouble("Paquetes") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"

                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetString("inv_partnum") & "|"
                    strFila &= REA.GetDouble("Unidad") & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= REA.GetDouble("KGBrutos") & "|"
                    strFila &= REA.GetDouble("KGNetos") & "|"
                    strFila &= REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    'strFila &= REA.GetDouble("DAI") & "|"
                    'strFila &= REA.GetDouble("IVA") & "|"
                    'strFila &= REA.GetDouble("Costo") & "|"
                    'strFila &= REA.GetDouble("Total")
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA

                    cFunciones.AgregarFila(dgDetalle, strFila)


                Loop
                CalcularTotales()
            End If

            For i = INT_CERO To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLDetalleSeleccionado(ByVal Codigo As Integer, ByVal Numero As Integer, ByVal Anio As Integer) As String
        Dim strSQL As String = STR_VACIO
        'strSQL = " SELECT HDoc_Sis_Emp, HDoc_Doc_Cat Catalogo, b.DDoc_Prd_Cod Codigo,a.HDoc_Doc_TC Tasa , e.art_DCorta Titulo, b.DDoc_Prd_PUQ PrecioU, art_DCorta, cat_clave Medida, inv_costo, d.inv_partnum, b.DDoc_Prd_UM Base, IFNULL(b.DDoc_RF3_Num,b.DDoc_Prd_UM) Unidad, b.DDoc_Prd_QTY Cantidad, d.inv_UMfac, b.DDoc_Prd_Des Descripcion,db.BDoc_Box_QTY Paquetes,b.DDoc_RF2_Dbl KGBrutos,IF(b.DDoc_Prd_UM = 70,Round(b.DDoc_Prd_QTY,2), (ROUND((b.DDoc_Prd_QTY / 2.2046),2))) KGNetos, (ROUND((b.DDoc_Prd_QTY * b.DDoc_Prd_NET),2)- (b.DDoc_Prd_DSQ) ) Total, b.DDoc_Prd_DSQ descuento, SUM(b.DDoc_Prd_QTY) - COALESCE(( "
        'strSQL &= "SELECT SUM(c.PDoc_QTY_Pro)"
        'strSQL &= " From Dcmtos_DTL_Pro c "
        'strSQL &= " WHERE b.DDoc_Sis_Emp = c.PDoc_Sis_Emp AND b.DDoc_Doc_Cat = c.PDoc_Par_Cat AND b.DDoc_Doc_Ano = c.PDoc_Par_Ano AND b.DDoc_Doc_Num = c.PDoc_Par_Num AND b.DDoc_Doc_Lin = c.PDoc_Par_Lin AND c.PDoc_Chi_Cat = 56),0) Sum_QTY, '' poliza "

        strSQL = "SELECT 
	            HDoc_Sis_Emp, HDoc_Doc_Cat Catalogo, 
	            IFNULL(b.DDoc_Prd_Cod,'') Codigo,a.HDoc_Doc_TC Tasa, IFNULL(e.art_DCorta, b.DDoc_Prd_Des) Titulo, 
	            b.DDoc_Prd_PUQ PrecioU, 
	            IFNULL(e.art_DCorta, b.DDoc_Prd_Des) art_DCorta, ifnull(f.cat_clave,'N/A') Medida, IFNULL(inv_costo,0) inv_costo, ifnull(d.inv_partnum,'N/A')inv_partnum, b.DDoc_Prd_UM Base, 
	            IFNULL(b.DDoc_RF3_Num,b.DDoc_Prd_UM) Unidad, b.DDoc_Prd_QTY Cantidad, ifnull(d.inv_UMfac,'N/A')inv_UMfac, b.DDoc_Prd_Des Descripcion,
	            db.BDoc_Box_QTY Paquetes, b.DDoc_RF2_Dbl KGBrutos,IF(b.DDoc_Prd_UM = 70, ROUND(b.DDoc_Prd_QTY,2), 
	            (ROUND((b.DDoc_Prd_QTY / 2.2046),2))) KGNetos, 
	            (ROUND((b.DDoc_Prd_QTY * b.DDoc_Prd_NET),2)- (b.DDoc_Prd_DSQ)) Total, 
	            b.DDoc_Prd_DSQ descuento, 
	            SUM(b.DDoc_Prd_QTY) - COALESCE(IFNULL((
		            SELECT SUM(c.PDoc_QTY_Pro)
		            FROM Dcmtos_DTL_Pro c
		            WHERE b.DDoc_Sis_Emp = c.PDoc_Sis_Emp AND b.DDoc_Doc_Cat = c.PDoc_Par_Cat AND b.DDoc_Doc_Ano = c.PDoc_Par_Ano 
			            AND b.DDoc_Doc_Num = c.PDoc_Par_Num AND b.DDoc_Doc_Lin = c.PDoc_Par_Lin AND c.PDoc_Chi_Cat = 56),0),0) Sum_QTY, 
	            '' poliza"

        strSQL &= " From Dcmtos_HDR a "
        strSQL &= " LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num "
        strSQL &= " LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = b.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = b.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = b.DDoc_Doc_Ano AND db.BDoc_Doc_Num = b.DDoc_Doc_Num AND db.BDoc_Doc_Lin = b.DDoc_Doc_Lin  "
        strSQL &= " LEFT JOIN Inventarios d ON b.DDoc_Prd_Cod = d.inv_numero AND b.DDoc_Sis_Emp = d.inv_sisemp "
        strSQL &= " LEFT JOIN Articulos e ON d.inv_artcodigo = e.art_codigo AND d.inv_sisemp = e.art_sisemp "
        strSQL &= " LEFT JOIN Catalogos f ON f.cat_num = IFNULL(b.DDoc_RF3_Num, b.DDoc_Prd_UM) "
        strSQL &= " WHERE HDoc_Doc_Cat = 36 AND HDoc_Sis_Emp = {empresa} AND HDoc_Emp_Cod = {codigo} AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero}  "
        strSQL &= " GROUP BY HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, DDoc_Doc_Lin "
        strSQL &= " HAVING Cantidad > 0 "
        strSQL &= " ORDER BY HDoc_Doc_Ano, HDoc_Doc_Num, b.DDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        strSQL = Replace(strSQL, "{numero}", Numero)
        strSQL = Replace(strSQL, "{anio}", Anio)
        Return strSQL
    End Function
    Private Function SqlNuevoDetalle(ByVal codigo As Integer, ByVal strTemp As String)
        Dim strSql As String = STR_VACIO

        '    strSql = " SELECT HDoc_Sis_Emp, HDoc_Doc_Cat Catalogo, b.DDoc_Prd_Cod Codigo, e.art_DCorta Titulo, b.DDoc_Prd_PUQ PrecioU, art_DCorta, cat_clave Medida, inv_costo, d.inv_partnum, b.DDoc_Prd_UM Base, IFNULL(b.DDoc_RF3_Num,b.DDoc_Prd_UM) Unidad, IF(b.DDoc_RF3_Dbl=0,b.DDoc_Prd_QTY,b.DDoc_RF3_Dbl) Cantidad, d.inv_UMfac, b.DDoc_Prd_Des Descripcion,db.BDoc_Box_QTY Paquetes, b.DDoc_RF2_Dbl KGBrutos, b.DDoc_Prd_Fob KGNetos, b.DDoc_Prd_DSQ descuento, "
        strSql = "SELECT 
	            HDoc_Sis_Emp, HDoc_Doc_Cat Catalogo, HDoc_Doc_Num, b.DDoc_Prd_Cod Codigo, IFNULL(e.art_DCorta, b.DDoc_Prd_Des) Titulo, b.DDoc_Prd_PUQ PrecioU, IFNULL(art_DCorta,b.DDoc_Prd_Des) art_DCorta, b.DDoc_Prd_UM,
	            IFNULL(cat_clave, 'N/A') Medida, 
	            IFNULL(inv_costo, 0) inv_costo, 
	            IFNULL(d.inv_partnum, 'N/A') inv_partnum, 
	            b.DDoc_Prd_UM Base, IFNULL(b.DDoc_RF3_Num,b.DDoc_Prd_UM) Unidad, 
	            IF(b.DDoc_RF3_Dbl=0,b.DDoc_Prd_QTY,b.DDoc_RF3_Dbl) Cantidad, 
	            IFNULL(d.inv_UMfac, 0) inv_UMfac, b.DDoc_Prd_Des Descripcion,db.BDoc_Box_QTY Paquetes, 
	            b.DDoc_RF2_Dbl KGBrutos, b.DDoc_Prd_Fob KGNetos, b.DDoc_Prd_DSQ descuento, "
        strSql &= "SUM(b.DDoc_Prd_QTY) - COALESCE(( "
        strSql &= "SELECT SUM(c.PDoc_QTY_Pro)"
        strSql &= " From Dcmtos_DTL_Pro c "
        strSql &= " WHERE b.DDoc_Sis_Emp = c.PDoc_Sis_Emp AND b.DDoc_Doc_Cat = c.PDoc_Par_Cat AND b.DDoc_Doc_Ano = c.PDoc_Par_Ano AND b.DDoc_Doc_Num = c.PDoc_Par_Num AND b.DDoc_Doc_Lin = c.PDoc_Par_Lin AND c.PDoc_Chi_Cat = 56),0) Sum_QTY, '' poliza, b.DDoc_RF4_Dbl egress_line "
        strSql &= " From Dcmtos_HDR a "
        strSql &= " LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num "
        strSql &= " LEFT JOIN Dcmtos_DTL_Box db ON db.BDoc_Sis_Emp = b.DDoc_Sis_Emp AND db.BDoc_Doc_Cat = b.DDoc_Doc_Cat AND db.BDoc_Doc_Ano = b.DDoc_Doc_Ano AND db.BDoc_Doc_Num = b.DDoc_Doc_Num AND db.BDoc_Doc_Lin = b.DDoc_Doc_Lin "
        strSql &= " LEFT JOIN Inventarios d ON b.DDoc_Prd_Cod = d.inv_numero AND b.DDoc_Sis_Emp = d.inv_sisemp "
        strSql &= " LEFT JOIN Articulos e ON d.inv_artcodigo = e.art_codigo AND d.inv_sisemp = e.art_sisemp "
        strSql &= " LEFT JOIN Catalogos f ON f.cat_num = IFNULL(b.DDoc_RF3_Num, b.DDoc_Prd_UM) "
        strSql &= " WHERE HDoc_Doc_Cat = 36 AND HDoc_Sis_Emp = {empresa} AND HDoc_Emp_Cod = {codigo} AND ({Condicion}) "
        strSql &= " GROUP BY HDoc_Sis_Emp, HDoc_Doc_Cat, HDoc_Doc_Ano, HDoc_Doc_Num, DDoc_Doc_Lin "
        strSql &= " HAVING Cantidad > 0 "
        strSql &= " ORDER BY HDoc_Doc_Ano, HDoc_Doc_Num, b.DDoc_Doc_Lin "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{codigo}", codigo)
        strSql = Replace(strSql, "{Condicion}", strTemp)

        Return strSql

    End Function


    Private Function SqlAgregaAlDetalle(ByVal numero As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT a.art_frac Inciso, a.art_desc Descripcion "
        strSql &= " From Inventarios i "
        strSql &= " INNER JOIN Articulos a ON a.art_codigo = i.inv_artcodigo "
        strSql &= " WHERE i.inv_activo = 0 AND i.inv_numero={numero} "

        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function


    Private Function SqlCargarReferencia(ByVal numero As Integer, ByVal anio As Integer)
        Dim strSql As String = STR_VACIO

        strSql = " SELECT HDoc_DR1_Num Factura, HDoc_DR2_Num Ref_1, HDoc_RF2_Txt Ref_2, HDoc_RF1_Txt Costeo, HDoc_RF1_Dbl Flete, HDoc_RF2_Dbl Seguro "
        strSql &= " From Dcmtos_HDR "
        strSql &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} "

        strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
        strSql = Replace(strSql, "{anio}", anio)
        strSql = Replace(strSql, "{numero}", numero)

        Return strSql

    End Function




    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String

        strSQL = sqlListaPrincipal()

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgLista.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("numero") & "|"
                    strFila &= REA.GetInt32("num2") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("nombre") & "|"
                    strFila &= REA.GetString("Clase") & "|"
                    strFila &= REA.GetString("Ref2") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("tipoDoc") & "|"
                    strFila &= REA.GetInt32("Estado")

                    cFunciones.AgregarFila(dgLista, strFila)

                Loop
                If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.idGiro = 2 Then
                    dgLista.Columns("colNumero2").Visible = True
                    dgLista.Columns("colNumero").Visible = False
                Else
                    dgLista.Columns("colNumero").Visible = True
                    dgLista.Columns("colNumero2").Visible = False
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarDatos(ByVal numero As Integer, ByVal fecha As Date)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        'Dim strFila As String

        strSQL = sqlCargarDatos(numero, fecha)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    'Celdas Ocultas
                    celdaCatalogo.Text = REA.GetInt32("Catalogo")
                    celdaDate.Text = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaIdCliente.Text = REA.GetInt32("IdCliente")
                    celdaNIT.Text = REA.GetString("NIT")
                    celdaIdMoneda.Text = REA.GetInt32("IdMoneda")
                    celdaUsuario.Text = REA.GetString("Usuario")
                    celdaNumero2.Text = REA.GetInt32("Num2")
                    'celdas visibles
                    celdaAnio.Text = REA.GetInt32("Anio")
                    celdaNumero.Text = REA.GetInt32("Numero")
                    dtpFecha.Text = REA.GetDateTime("Fecha")
                    celdaCliente.Text = REA.GetString("Cliente")
                    celdaDireccion.Text = REA.GetString("Direccion")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaFactura.Text = REA.GetString("Referencia")
                    celdaFlete.Text = REA.GetDouble("Flete")
                    celdaSeguro.Text = REA.GetDouble("Seguro")

                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub DatosPoliza(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String
        Dim verPais As Integer = 0
        Dim strCadena As String = STR_VACIO
        Dim ArrayCadena() As String

        verPais = verificarPais()
        If (verPais = 310 And Sesion.IdEmpresa = 12) Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 11 Or Sesion.idGiro = 2 Then
            dgPolizaExportacion.Columns("colNumeroDR1_Dbl").Visible = True
            dgPolizaExportacion.Columns("colNumeroP").Visible = False
            dgPolizaExportacion.Columns("colnumFel").Visible = False
        Else
            If (verPais = 0 And Sesion.IdEmpresa = 12) Then
                dgPolizaExportacion.Columns("colNumeroDR1_Dbl").Visible = False
                dgPolizaExportacion.Columns("colNumeroP").Visible = True
                dgPolizaExportacion.Columns("colnumFel").Visible = True
            Else
                dgPolizaExportacion.Columns("colNumeroDR1_Dbl").Visible = False
                dgPolizaExportacion.Columns("colNumeroP").Visible = True
                dgPolizaExportacion.Columns("colnumFel").Visible = False
            End If

        End If

        strSQL = sqlDatosPoliza(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgPolizaExportacion.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strCadena = REA.GetString("Serie")
                    ArrayCadena = strCadena.Split("-".ToCharArray)
                    strFila = REA.GetInt32("Numero2") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= ArrayCadena(INT_CERO) & " / " & REA.GetString("Autorizacion")
                    cFunciones.AgregarFila(dgPolizaExportacion, strFila)

                Loop

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub CargarDetalle(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String

        strSQL = sqlCargarDetalle(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgDetalle.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("PrecioU") & "|"
                    strFila &= REA.GetDouble("DescuentoPor") & "|"
                    strFila &= REA.GetDouble("DescuentoMon") & "|"
                    strFila &= REA.GetInt32("Bultos") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"
                    strFila &= REA.GetDouble("Lin_Subtotal").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("PNR") & "|"
                    strFila &= REA.GetDouble("UnidadMed") & "|"
                    strFila &= REA.GetString("Inciso") & "|"
                    strFila &= REA.GetString("DescLinea") & "|"
                    strFila &= REA.GetDouble("Brutos") & "|"
                    strFila &= REA.GetDouble("Netos") & "|"
                    strFila &= REA.GetDouble("Fob").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Flete").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Seguro").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("Cargos").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("CIf").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetDouble("DAI") & "|"
                    strFila &= REA.GetDouble("IVA") & "|"
                    strFila &= REA.GetDouble("Costo") & "|"
                    strFila &= REA.GetDouble("Total").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("egress_line")

                    cFunciones.AgregarFila(dgDetalle, strFila)

                Loop

                CalcularTotales()

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarDatosDoc(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim cantidad As Integer

        strSQL = sqlDatos(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgDocumentos.Rows.Clear()

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"
                    cantidad = REA.GetInt32("Cantidad")
                    If cantidad > 0 Then
                        strFila &= "SI"
                    Else
                        strFila &= "NO"
                    End If

                    cFunciones.AgregarFila(dgDocumentos, strFila)

                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function verificarPais()
        Dim strsql As String = STR_VACIO
        Dim com As MySqlCommand

        strsql = " Select e.emp_pais From Empresas e Where e.emp_no =  " & Sesion.IdEmpresa
        MyCnn.CONECTAR = strConexion
        com = New MySqlCommand(strsql, CON)

        Return com.ExecuteScalar()

    End Function
    Public Sub NuevosDatosPoliza(ByVal codigo As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim VerPais As Integer = 0
        Dim strCadena As String = STR_VACIO
        Dim ArrayCadena() As String

        VerPais = verificarPais()
        If (VerPais = 310 And Sesion.IdEmpresa = 12) Or Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Or Sesion.idGiro = 2 Then
            dgPolizaExportacion.Columns("colNumeroDR1_Dbl").Visible = True
            dgPolizaExportacion.Columns("colNumeroP").Visible = False
            dgPolizaExportacion.Columns("colnumFel").Visible = False
        Else
            If (VerPais = 0 And Sesion.IdEmpresa = 12) Then
                dgPolizaExportacion.Columns("colNumeroDR1_Dbl").Visible = False
                dgPolizaExportacion.Columns("colNumeroP").Visible = True
                dgPolizaExportacion.Columns("colnumFel").Visible = True
            Else
                dgPolizaExportacion.Columns("colNumeroDR1_Dbl").Visible = False
                dgPolizaExportacion.Columns("colNumeroP").Visible = True
                dgPolizaExportacion.Columns("colnumFel").Visible = False
            End If
        End If
        strSQL = sqlNuevosDatosPoliza(codigo)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.CommandTimeout = 300
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strCadena = REA.GetString("Serie")
                    ArrayCadena = strCadena.Split("-".ToCharArray)
                    strFila = REA.GetInt32("Numero2") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Referencia") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Catalogo") & "|"
                    strFila &= ArrayCadena(INT_CERO) & " / " & REA.GetString("Autorizacion")


                    cFunciones.AgregarFila(dgPolizaExportacion, strFila)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Public Sub NuevoDetalle(ByVal codigo As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim total As Double
        Dim strTemp As String = STR_VACIO
        Dim i As Integer

        For i = 0 To dgPolizaExportacion.Rows.Count - 1
            If i > 0 Then
                strTemp = strTemp & " OR "
            End If
            If dgPolizaExportacion.Rows.Count - 1 >= 0 Then
                strTemp = strTemp & " ( HDoc_Doc_Ano = " & dgPolizaExportacion.Rows(i).Cells("colAnioP").Value & " AND HDoc_Doc_Num = " & dgPolizaExportacion.Rows(i).Cells("colNumeroP").Value & ")"
            Else
            End If

        Next

        strSQL = SqlNuevoDetalle(codigo, strTemp)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Codigo") & "|"
                    strFila &= REA.GetString("art_DCorta") & "|"
                    strFila &= REA.GetString("Medida") & "|"
                    strFila &= REA.GetDouble("PrecioU") & "|"
                    strFila &= vbEmpty & "|"
                    strFila &= REA.GetDouble("descuento") & "|"
                    strFila &= REA.GetInt32("Paquetes") & "|"
                    strFila &= REA.GetDouble("Cantidad") & "|"

                    total = ((REA.GetDouble("PrecioU") * REA.GetDouble("Cantidad")) - REA.GetDouble("descuento"))
                    strFila &= total.ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("inv_partnum") & "|"
                    strFila &= REA.GetDouble("Unidad") & "|"
                    strFila &= "|"      ' flete
                    strFila &= "|"      ' seguro
                    strFila &= REA.GetDouble("KGBrutos") & "|"
                    strFila &= REA.GetDouble("KGNetos") & "|"
                    strFila &= total.ToString(FORMATO_MONEDA) & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA & "|"
                    strFila &= STR_CERO_MONEDA & "|" & STR_CERO_MONEDA & "|" & STR_CERO_MONEDA & "|"
                    'strFila &= REA.GetDouble("DAI") & "|"  
                    'strFila &= REA.GetDouble("IVA") & "|"
                    'strFila &= REA.GetDouble("Costo") & "|"
                    'strFila &= REA.GetDouble("Total")

                    cFunciones.AgregarFila(dgDetalle, strFila)


                Loop
                CalcularTotales()
            End If

            For i = INT_CERO To dgDetalle.Rows.Count - 1
                dgDetalle.Rows(i).Cells("colLinea").Value = i + 1
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Public Sub AgregarAlDetalle()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim i As Integer
        Dim numero As Integer
        Try
            For i = 0 To dgDetalle.Rows.Count - 1

                If dgDetalle.Rows.Count - 1 >= 0 Then
                    numero = dgDetalle.Rows(i).Cells("colCodigoDet").Value

                    strSQL = SqlAgregaAlDetalle(numero)


                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader

                    If REA.HasRows Then
                        REA.Read()
                        dgDetalle.Rows(i).Cells("colInciso").Value = REA.GetString("Inciso")
                        dgDetalle.Rows(i).Cells("colDescripDet").Value = REA.GetString("Descripcion")
                        dgDetalle.Rows(i).Cells("colKgBrutos").Value = dgDetalle.Rows(i).Cells("colKgBrutos").Value
                        dgDetalle.Rows(i).Cells("colKgNetos").Value = dgDetalle.Rows(i).Cells("colKgNetos").Value
                        dgDetalle.Rows(i).Cells("colFOB").Value = dgDetalle.Rows(i).Cells("colFOB").Value

                        If (Sesion.idGiro = 2) Then
                            dgDetalle.Rows(i).Cells("colFlete").Value = celdaFlete.Text
                            dgDetalle.Rows(i).Cells("colSeguro").Value = celdaSeguro.Text
                        Else
                            dgDetalle.Rows(i).Cells("colFlete").Value = STR_CERO_MONEDA
                            dgDetalle.Rows(i).Cells("colSeguro").Value = STR_CERO_MONEDA
                        End If

                        dgDetalle.Rows(i).Cells("colOtros").Value = STR_CERO_MONEDA
                        dgDetalle.Rows(i).Cells("colCif").Value = dgDetalle.Rows(i).Cells("colCif").Value
                        dgDetalle.Rows(i).Cells("colDAI").Value = STR_CERO_MONEDA
                        dgDetalle.Rows(i).Cells("ColIVA").Value = STR_CERO_MONEDA
                        dgDetalle.Rows(i).Cells("colCosto").Value = STR_CERO_MONEDA
                        dgDetalle.Rows(i).Cells("colGranTotal").Value = Math.Round((dgDetalle.Rows(i).Cells("colCantidadDet").Value * dgDetalle.Rows(i).Cells("colCosto").Value), 2)
                        dgDetalle.Rows(i).Cells("egress_line").Value = STR_CERO_MONEDA
                    End If

                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Public Sub CargarReferencia(ByVal numero As Integer, ByVal anio As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SqlCargarReferencia(numero, anio)

        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                REA.Read()
                celdaFactura.Text = REA.GetString("Factura")
                'celdaRef1.Text = REA.GetString("Ref_1")
                'celdaRef2.Text = REA.GetString("Ref_2")
                'celdaCosteo.Text = REA.GetString("Costeo")
                celdaFlete.Text = REA.GetDouble("Flete")
                celdaSeguro.Text = REA.GetDouble("seguro")

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub


    Private Function EsReferenciaValida() As Boolean
        Dim i As Integer
        Dim logCancelar As Boolean
        Dim Temp As String
        Dim Ref As String = vbNullString

        If intTipoDoc = 0 Then 'intTipoDoc = 0 --> Importación
            For i = 0 To dgPolizaExportacion.Rows.Count - 1
                Temp = dgPolizaExportacion.Rows(i).Cells("colReferenciaP").Value
                If Ref = vbNullString Then
                    Ref = Temp
                End If

                If Not (Temp = Ref) And Not (Ref = vbNullString) Then
                    MsgBox("Only multiple documents are allowed if they have the same reference", vbExclamation, "Notice")
                    logCancelar = True
                End If
            Next
        Else 'intTipoDoc = 1 -->Devolución
            If dgPolizaExportacion.Rows.Count - 1 > 0 Then
                MsgBox("Only one data document for policy is allowed", vbExclamation, "Notice")
                logCancelar = True
            End If
        End If
        EsReferenciaValida = Not (logCancelar)
    End Function

    Private Sub ComprobarIngreso()
        Dim i As Integer

        If celdaAnio.Text = vbEmpty Or celdaNumero.Text = vbEmpty Or
        celdaIdCliente.Text = vbEmpty Or celdaCliente.Text = vbNullString Or
        celdaMoneda.Text = vbNullString Or celdaTasa.Text = vbEmpty Then

            MsgBox("You must enter all the minimum data", vbCritical)
            Exit Sub
        End If

        For i = 0 To dgDetalle.Rows.Count - 1
            If Not ComprobarFila(i) Then
                Exit Sub
            End If
        Next

        CalcularTotales()
        If (celdaTotalCantidad.Text = 0) Or (celdaTotal.Text = 0) Then
            MsgBox("No se admite un pedido con monto Cero", vbCritical)
            Exit Sub
        End If

    End Sub


    Private Function ComprobarFila(ByVal i As Integer) As Boolean
        If dgDetalle.Rows(i).Cells("colCodigoDet").Value = vbNullString Then
            MsgBox("Row " & i + 1 & ": Invalid Item Code")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colDescripcionDet").Value = vbNullString Then
            MsgBox("Row " & i + 1 & ": Description of Item in white")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colPrecioDet").Value = vbEmpty Then
            MsgBox("Row " & i + 1 & ": Precio de articulo en CERO")
            ComprobarFila = False
            Exit Function
        End If

        If dgDetalle.Rows(i).Cells("colCantidadDet").Value = vbEmpty Then
            MsgBox("Row " & i + 1 & ": Cantidad de articulo en CERO")
            ComprobarFila = False
            Exit Function
        End If
        ComprobarFila = True
    End Function


    Private Sub GuardarDocumento()
        Dim HDR As New clsDcmtos_HDR
        Dim verCheck As Integer

        If checkActivo.Checked = True Then
            verCheck = 1
        Else
            verCheck = 0
        End If

        'If celdaNumero.Text = NO_FILA Then
        '    celdaNumero.Text = cfun.NuevoId(180)
        'End If

        HDR.CONEXION = strConexion

        Try
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = celdaCatalogo.Text
            HDR.HDOC_DOC_ANO = celdaAnio.Text
            HDR.HDOC_DOC_NUM = celdaNumero.Text
            HDR.HDoc_Doc_Fec_NET = celdaDate.Text
            HDR.HDOC_EMP_COD = celdaIdCliente.Text
            HDR.HDOC_EMP_NOM = celdaCliente.Text
            HDR.HDOC_EMP_DIR = celdaDireccion.Text
            HDR.HDOC_EMP_NIT = celdaNIT.Text
            HDR.HDOC_DR1_CAT = intTipoDoc
            HDR.HDOC_DR1_NUM = celdaFactura.Text
            HDR.HDOC_DR1_EMP = vbEmpty
            HDR.HDOC_DR1_DBL = celdaNumero2.Text
            'HDR.HDOC_DR2_NUM = celdaRef1.Text
            HDR.HDOC_RF1_TXT = "CIF"
            HDR.HDOC_RF2_TXT = celdaRef2.Text
            HDR.HDOC_USUARIO = celdaUsuario.Text
            HDR.HDOC_PRO_DCAT = vbEmpty
            HDR.HDOC_PRO_DANO = vbEmpty
            HDR.HDOC_PRO_DNUM = vbEmpty
            HDR.HDOC_DOC_TC = celdaTasa.Text
            HDR.HDOC_DOC_MON = celdaIdMoneda.Text
            HDR.HDOC_RF1_DBL = celdaFlete.Text
            HDR.HDOC_RF2_DBL = celdaSeguro.Text
            HDR.HDOC_DOC_STATUS = verCheck
            HDR.HDOC_RF3_DBL = 0

            If Me.Tag = "Mod" Then
                If HDR.Actualizar() = False Then
                    MsgBox(HDR.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If HDR.Guardar() = False Then
                    MsgBox(HDR.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub


    Public Sub GuardarDetalle()
        Dim i As Integer
        For i = 0 To dgDetalle.Rows.Count - 1
            SqlGuardarDetalle(i)
            SqlGuardarDeclaracion(i)
        Next
    End Sub


    Private Sub SqlGuardarDetalle(ByVal i As Integer)
        Dim DTL As New clsDcmtos_DTL

        DTL.CONEXION = strConexion

        Try

            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = celdaCatalogo.Text
            DTL.DDOC_DOC_ANO = celdaAnio.Text
            DTL.DDOC_DOC_NUM = celdaNumero.Text
            DTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
            DTL.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("colMontoDet").Value
            DTL.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigoDet").Value
            DTL.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colParteDet").Value
            DTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcionDet").Value
            DTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colCodigoUMDet").Value
            DTL.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecioDet").Value
            DTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecioDet").Value
            DTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidadDet").Value
            DTL.DDOC_RF1_NUM = vbEmpty
            DTL.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotalDet").Value
            DTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colFOB").Value
            DTL.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colCIF").Value
            DTL.DDOC_RF3_DBL = 0
            DTL.DDOC_RF4_DBL = dgDetalle.Rows(i).Cells("egress_line").Value

            If Me.Tag = "Mod" Then
                If DTL.Actualizar() = False Then
                    MsgBox(DTL.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If DTL.Guardar() = False Then
                    MsgBox(DTL.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If


        Catch ex As Exception

        End Try

    End Sub

    Private Sub SqlGuardarDeclaracion(ByVal i As Integer)
        Dim DEC As New Tablas.TDCMTOS_DEC

        DEC.CONEXION = strConexion

        DEC.EDOC_SIS_EMP = Sesion.IdEmpresa
        DEC.EDOC_DOC_CAT = celdaCatalogo.Text
        DEC.EDOC_DOC_ANO = celdaAnio.Text
        DEC.EDOC_DOC_NUM = celdaNumero.Text
        DEC.EDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
        DEC.EDOC_LIN_FRAC = dgDetalle.Rows(i).Cells("colInciso").Value
        DEC.EDOC_LIN_DESC = dgDetalle.Rows(i).Cells("colDescripDet").Value
        DEC.EDOC_LIN_GROSS = dgDetalle.Rows(i).Cells("colKgBrutos").Value
        DEC.EDOC_LIN_NET = dgDetalle.Rows(i).Cells("colKgNetos").Value
        DEC.EDOC_LIN_FOB = dgDetalle.Rows(i).Cells("colFOB").Value
        DEC.EDOC_LIN_FREIGHT = dgDetalle.Rows(i).Cells("colFlete").Value
        DEC.EDOC_LIN_INSURANCE = dgDetalle.Rows(i).Cells("colSeguro").Value
        DEC.EDOC_LIN_CARGOS = dgDetalle.Rows(i).Cells("colOtros").Value
        DEC.EDOC_LIN_CIF = dgDetalle.Rows(i).Cells("colCIF").Value
        DEC.EDOC_LIN_DAI = dgDetalle.Rows(i).Cells("colDAI").Value
        DEC.EDOC_LIN_IVA = dgDetalle.Rows(i).Cells("colIVA").Value
        Try
            If Me.Tag = "Mod" Then
                If DEC.PUPDATE() = False Then
                    MsgBox(DEC.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If DEC.PINSERT() = False Then
                    MsgBox(DEC.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message & " - sqlGuardarDeclaracion ")
        End Try


    End Sub



    Public Sub GuardarDescargos()
        Dim i As Integer

        For i = 0 To dgDetalle.Rows.Count - 1
            SqlGuardarDescargos(i)
        Next

    End Sub


    Private Sub SqlGuardarDescargos(ByVal i As Integer)
        Dim DTL_P As New clsDcmtos_DTL_Pro
        Dim j As Integer = INT_CERO
        Dim numero As Integer = INT_CERO
        Dim anio As Integer = INT_CERO

        For j = 0 To dgPolizaExportacion.Rows.Count - 1
            numero = dgPolizaExportacion.Rows(j).Cells("colAnioP").Value
            anio = dgPolizaExportacion.Rows(j).Cells("colNumeroP").Value
        Next

        DTL_P.CONEXION = strConexion

        DTL_P.PDOC_SIS_EMP = Sesion.IdEmpresa
        DTL_P.PDOC_PAR_CAT = 36
        DTL_P.PDOC_PAR_ANO = numero
        DTL_P.PDOC_PAR_NUM = anio
        DTL_P.PDOC_PAR_LIN = i + 1
        DTL_P.PDOC_CHI_CAT = celdaCatalogo.Text
        DTL_P.PDOC_CHI_ANO = celdaAnio.Text
        DTL_P.PDOC_CHI_NUM = celdaNumero.Text
        DTL_P.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
        DTL_P.PDOC_PROV_COD = celdaIdCliente.Text
        DTL_P.PDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigoDet").Value
        DTL_P.PDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colParteDet").Value
        DTL_P.PDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecioDet").Value
        DTL_P.PDOC_QTY_ORD = dgDetalle.Rows(i).Cells("colCantidadDet").Value
        DTL_P.PDOC_QTY_PRO = dgDetalle.Rows(i).Cells("colCantidadDet").Value

        If Me.Tag = "Mod" Then
            If DTL_P.Actualizar() = False Then
                MsgBox(DTL_P.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        Else
            If DTL_P.Guardar() = False Then
                MsgBox(DTL_P.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub


    Public Sub GuardarBultos()
        Dim i As Integer

        For i = 0 To dgDetalle.Rows.Count - 1
            SqlGuardarBultos(i)
        Next

    End Sub


    Private Sub SqlGuardarBultos(ByVal i As Integer)
        Dim DTL_B As New Tablas.TDCMTOS_DTL_BOX

        DTL_B.CONEXION = strConexion

        DTL_B.BDOC_SIS_EMP = Sesion.IdEmpresa
        DTL_B.BDOC_DOC_CAT = celdaCatalogo.Text
        DTL_B.BDOC_DOC_ANO = celdaAnio.Text
        DTL_B.BDOC_DOC_NUM = celdaNumero.Text
        DTL_B.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
        DTL_B.BDOC_BOX_LIN = INT_UNO
        DTL_B.BDOC_BOX_COD = dgDetalle.Rows(i).Cells("colCodigoDet").Value
        DTL_B.BDOC_BOX_QTY = dgDetalle.Rows(i).Cells("colBultos").Value
        DTL_B.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidadDet").Value

        If Me.Tag = "Mod" Then
            If DTL_B.PUPDATE() = False Then
                MsgBox(DTL_B.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        Else
            If DTL_B.PINSERT() = False Then
                MsgBox(DTL_B.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If
    End Sub


    Public Sub LimpiarCampos()
        celdaAnio.Text = NO_FILA
        celdaNumero.Text = NO_FILA
        celdaNumero2.Text = NO_FILA
        celdaTasa.Text = INT_UNO
        dtpFecha.Text = cfun.HoyMySQL
        celdaDate.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        celdaCliente.Clear()
        celdaIdCliente.Clear()
        celdaNIT.Clear()
        celdaDireccion.Clear()
        celdaMoneda.Clear()
        celdaIdMoneda.Text = INT_LOC

        celdaFactura.Clear()
        celdaFlete.Clear()
        celdaSeguro.Clear()
        celdaUsuario.Clear()
        celdaTotal.Clear()
        celdaTotalCantidad.Clear()
        celdaCatalogo.Text = 56
        If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.idGiro = 2 Then
            celdaNumero.Visible = False
            celdaNumero2.Visible = True
        Else
            celdaNumero.Visible = True
            celdaNumero2.Visible = False
        End If
        If Sesion.IdEmpresa = 12 Then
            dgDetalle.Columns("egress_line").Visible = True
        Else
            dgDetalle.Columns("egress_line").Visible = False
        End If
    End Sub

    Private Sub CalcularTotales()
        Dim dblCif As Double = 0
        Dim dblFob As Double = 0
        Dim dblOtros As Double = 0
        Dim dblFlete As Double = 0
        Dim dblSeguro As Double = 0
        Dim Cantidad As Double = 0
        Dim Total As Double = 0
        Dim i As Integer
        For i = 0 To dgDetalle.Rows.Count - 1

            dblFob = dblFob + dgDetalle.Rows(i).Cells("colFOB").Value
            dblOtros = dblOtros + dgDetalle.Rows(i).Cells("colOtros").Value
            dblFlete = dblFlete + dgDetalle.Rows(i).Cells("colFlete").Value
            dblSeguro = dblSeguro + dgDetalle.Rows(i).Cells("colSeguro").Value

            dblCif = (dblFob + dblOtros + dblFlete + dblSeguro)

            dgDetalle.Rows(i).Cells("colCif").Value = dblCif
            Cantidad = Cantidad + dgDetalle.Rows(i).Cells("colCantidadDet").Value
            Total = Total + dgDetalle.Rows(i).Cells("colTotalDet").Value
            dblFob = 0
            dblOtros = 0
            dblFlete = 0
            dblSeguro = 0
            dblCif = 0
        Next
        celdaTotalCantidad.Text = Cantidad
        celdaTotal.Text = Total.ToString(FORMATO_MONEDA)
    End Sub
    'Metodos de Borrar 
    Private Function VerificarSiTieneDependencias()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(p.PDoc_Par_Num) FROM Dcmtos_HDR h "
        strSQL &= " Left Join Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp And p.PDoc_Par_Cat = h.HDoc_Doc_Cat And p.PDoc_Par_Ano = h.HDoc_Doc_Ano And p.PDoc_Par_Num = h.HDoc_Doc_Num "
        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} And h.HDoc_Doc_Cat = {catalogo} And h.HDoc_Doc_Ano = {anio} And h.HDoc_Doc_Num = {num} And h.HDoc_Doc_Status = 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
        Return strSQL
    End Function
    Public Function BorrarEncabezado() As Boolean
        Dim logGuardar As Boolean

        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = celdaCatalogo.Text
            hdr.HDOC_DOC_ANO = celdaAnio.Text
            hdr.HDOC_DOC_NUM = celdaNumero.Text
            hdr.Borrar()
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Detalle Poliza
    Private Function BorrarDetalle() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Try
            If LogBorrar = True Then

                strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero}   ;"
                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
                Dim dtl As New clsDcmtos_DTL
                dtl.CONEXION = strConexion
                dtl.Borrar(strSQL)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
                logGuardar = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    'Borrar Descargo 
    Private Function BorrarDescargos() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Try
            If LogBorrar = True Then
                '    For i = 0 To dgDetalle.Rows.Count - 1
                strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {catalogo} AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero} ; "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                strSQl = Replace(strSQl, "{catalogo}", celdaCatalogo.Text)
                'Next
                Dim pro As New clsDcmtos_DTL_Pro
                pro.CONEXION = strConexion
                pro.Borrar(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Sub BorrarBultos(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "BDoc_Sis_Emp = {empresa}  AND BDoc_Doc_Cat = {catalogo} AND BDoc_Doc_Ano = {anio} AND BDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
            Dim box As New Tablas.TDCMTOS_DTL_BOX
            box.CONEXION = strConexion
            box.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function BorrarDec() As Boolean
        Dim logGuardar As Boolean
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            If LogBorrar = True Then
                '    For i = 0 To dgDetalle.Rows.Count - 1

                strSQl = "EDoc_Sis_Emp = {empresa} AND EDoc_Doc_Cat = {catalogo} AND EDoc_Doc_Ano = {anio} AND EDoc_Doc_Num = {numero} ; "
                strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                strSQl = Replace(strSQl, "{anio}", celdaAnio.Text)
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
                strSQl = Replace(strSQl, "{catalogo}", celdaCatalogo.Text)
                'Next
                Dim dec As New Tablas.TDCMTOS_DEC
                dec.CONEXION = strConexion
                dec.PDELETE(strSQl)
                logGuardar = True
            Else
                MsgBox("You don't have permission to this access")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Private Function ValidarRegistro() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logResultado As Boolean
        Dim COM As MySqlCommand
        Dim conec As New MySqlConnection
        Dim intCodigo As Integer

        strSQL = " SELECT COUNT(*) "
        strSQL &= "     FROM Dcmtos_HDR h  "
        strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 56 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intCodigo = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        If intCodigo = INT_UNO Then
            MsgBox("this number already exist please enter another number", MsgBoxStyle.Information)
            logResultado = False
        Else
            logResultado = True
        End If

        Return logResultado
    End Function
#End Region

#Region "Eventos"
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs)
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Coin"
            frm.Campos = "c.cat_clave Moneda, c.cat_num ID, c.cat_sist"
            frm.Tabla = "Catalogos c"
            frm.FiltroText = " Enter the Coin To filter"
            frm.Filtro = " c.cat_clave "
            frm.Limite = 5
            frm.Ordenamiento = " c.cat_clave "
            frm.TipoOrdenamiento = ""
            frm.Condicion = "cat_clase='Monedas'"

            frm.ShowDialog(Me)

            If frm.DialogResult = DialogResult.OK Then
                celdaMoneda.Text = frm.LLave
                celdaIdMoneda.Text = frm.Dato
                celdaTasa.Text = frm.Dato2

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmPolizaExportacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accesos()
        dtpInicial.Value = Today.AddMonths(NO_FILA)
        dtpFinal.Value = Today
        MostrarLista()

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Me.Tag = "Mod"
        Dim numero As Integer
        Dim fecha As Date
        Dim fecha1 As String
        Dim anio As Integer
        Encabezado1.botonGuardar.Enabled = True

        If dgLista.SelectedCells(8).Value = 1 Then
            checkActivo.Checked = True
        Else
            checkActivo.Checked = False
        End If

        If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
        LimpiarCampos()

        intTipoDoc = dgLista.SelectedCells(7).Value
        numero = dgLista.SelectedCells(0).Value
        fecha = dgLista.SelectedCells(2).Value
        fecha1 = fecha.ToString(FORMATO_MYSQL)
        anio = dgLista.SelectedCells(6).Value
        BarraTitulo1.CambiarTitulo("Change Entry")

        CargarDatos(numero, fecha1)
        DatosPoliza(numero, anio)
        CargarDetalle(numero, anio)
        CargarDatosDoc(numero, anio)

        If Me.Tag = "Mod" Then
            botonMenos.Enabled = False
            'botonTipo.Enabled = True
        End If

        MostrarLista(False)

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then

            Me.Tag = "Nuevo"
            Dim frm As New frmOption

            LimpiarCampos()
            dgDetalle.Rows.Clear()
            dgDocumentos.Rows.Clear()
            dgPolizaExportacion.Rows.Clear()

            frm.Opciones = "Nationalization |" & "Rest of the world |" & "Central America |" & "Transfer"
            frm.Titulo = "Type of statement"
            frm.ShowDialog(Me)
            If frm.DialogResult = DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        BarraTitulo1.CambiarTitulo("Export Policy")
                        intTipoDoc = 0
                        CargarDatosDoc(celdaNumero.Text, celdaAnio.Text)
                        MostrarLista(False)
                    Case 1
                        intTipoDoc = 1
                        BarraTitulo1.CambiarTitulo("Export Policy")
                        CargarDatosDoc(celdaNumero.Text, celdaAnio.Text)
                        MostrarLista(False)
                    Case 2
                        intTipoDoc = 2
                        BarraTitulo1.CambiarTitulo("Export Policy")
                        CargarDatosDoc(celdaNumero.Text, celdaAnio.Text)
                        MostrarLista(False)
                    Case 3
                        intTipoDoc = 3
                        BarraTitulo1.CambiarTitulo("Transfer")
                        CargarDatosDoc(celdaNumero.Text, celdaAnio.Text)
                        MostrarLista(False)
                End Select
            End If
            botonMenos.Enabled = False
            Encabezado1.botonBorrar.Enabled = False
            celdaAnio.Text = cFunciones.AñoMySQL
        Else
            MsgBox("You do not have access for this action", vbInformation)
        End If

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
        ElseIf panelDocumento.Visible = True Then
            MostrarLista()
        End If
    End Sub
    Private Sub dgDocumentos_DoubleClick(sender As Object, e As EventArgs) Handles dgDocumentos.DoubleClick
        Try

            Dim strDoc As String

            strDoc = dgDocumentos.SelectedCells(0).Value

            Select Case dgDocumentos.CurrentCell.ColumnIndex
                Case 2
                    If dgDocumentos.SelectedCells(2).Value = "SI" Then
                        SDoc.SubDocumento = dgDocumentos.SelectedCells(0).Value
                        SDoc.Año = CInt(celdaAnio.Text)
                        SDoc.Numero = celdaNumero.Text
                        SDoc.Catalogo = 56
                        SDoc.Doc = strDoc
                        SDoc.TasaC = celdaTasa.Text

                        SDoc.ShowDialog(Me)
                    Else
                        SDoc.SubDocumento = dgDocumentos.SelectedCells(0).Value
                        SDoc.Año = celdaAnio.Text
                        SDoc.Numero = celdaNumero.Text
                        SDoc.Doc = strDoc
                        SDoc.TasaC = celdaTasa.Text
                        SDoc.Catalogo = 56
                        'SubDocumentos desde facturacion, parametros
                        SDoc.anioFact = dgPolizaExportacion.CurrentRow.Cells("colAnioP").Value
                        SDoc.numFactura = dgPolizaExportacion.CurrentRow.Cells("colNumeroP").Value
                        SDoc.fechaPolizaExport = celdaDate.Text
                        SDoc.ShowDialog(Me)
                    End If

                    celdaTasa.Text = SDoc.TasaC
                    For i As Integer = 0 To SDoc.dgvSubDocumentosfrm.Rows.Count - 1
                        celdaRef2.Text = SDoc.dgvSubDocumentosfrm.Rows(i).Cells("Contenido").Value
                    Next
                    GuardarDocumento()
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonTipo_Click(sender As Object, e As EventArgs) Handles botonTipo.Click

        Dim frm As New frmOption

        celdaAnio.Text = cFunciones.AñoMySQL

        frm.Opciones = "Nationalization |" & "Rest of the world |" & "Central America"
        frm.Titulo = "Type of statement"
        frm.ShowDialog(Me)
        If frm.DialogResult = DialogResult.OK Then
            Select Case frm.Seleccion
                Case 0
                    'BarraTitulo1.CambiarTitulo("Export Policy")
                    intTipoDoc = 0
                    'CargarDatos(celdaNumero.Text, celdaAnio.Text)
                    'MostrarLista(False)
                Case 1
                    intTipoDoc = 1
                    'BarraTitulo1.CambiarTitulo("Refund (re-export)")
                    'MostrarLista(False)
                Case 2
                    intTipoDoc = 2
                    'BarraTitulo1.CambiarTitulo("Transfer")
                    'MostrarLista(False)
            End Select

        End If
    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar
        Dim condicion As String = STR_VACIO
        Dim numero As Integer
        Dim anio As Integer
        condicion = " cli_sisemp = {empresa}"
        condicion = Replace(condicion, "{empresa}", Sesion.IdEmpresa)
        Try

            frm.Titulo = "Customers"
            frm.Campos = " cli_codigo IdCliente, cli_cliente Cliente, cli_direccion Direccion, cli_nit NIT, cli_moneda IdMoneda, cat_clave Simbolo, cat_sist TC "
            frm.Tabla = " Clientes LEFT JOIN Catalogos ON cat_num = cli_moneda "
            frm.FiltroText = "Enter the Name Of the Client To Filter"
            frm.Filtro = "cli_cliente"
            frm.Condicion = condicion
            frm.Ordenamiento = "cli_cliente"
            frm.ShowDialog(Me)

            If frm.DialogResult = DialogResult.OK Then
                celdaIdCliente.Text = frm.ListaClientes.SelectedCells(0).Value
                celdaCliente.Text = frm.ListaClientes.SelectedCells(1).Value
                celdaDireccion.Text = frm.ListaClientes.SelectedCells(2).Value
                celdaNIT.Text = frm.ListaClientes.SelectedCells(3).Value
                celdaIdMoneda.Text = frm.ListaClientes.SelectedCells(4).Value
                celdaMoneda.Text = frm.ListaClientes.SelectedCells(5).Value
                celdaTasa.Text = frm.ListaClientes.SelectedCells(6).Value


                NuevosDatosPoliza(celdaIdCliente.Text)
                If dgPolizaExportacion.Rows.Count >= 1 Then
                    NuevoDetalle(celdaIdCliente.Text)

                    celdaUsuario.Text = Sesion.Usuario
                    numero = dgPolizaExportacion.Rows(0).Cells("colNumeroP").Value
                    anio = dgPolizaExportacion.Rows(0).Cells("colAnioP").Value
                    CargarReferencia(numero, anio)
                    If Sesion.idGiro = 2 Then
                        celdaNumero.Text = cfun.NuevoId(56)
                    Else
                        celdaNumero.Text = dgPolizaExportacion.Rows(0).Cells("colNumeroP").Value
                    End If
                    celdaNumero2.Text = dgPolizaExportacion.Rows(0).Cells("colNumeroDR1_Dbl").Value
                    AgregarAlDetalle()
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgPolizaExportacion_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgPolizaExportacion.CellContentClick
        Dim Numero As Integer
        Dim anio As Integer

        Numero = dgPolizaExportacion.Rows(e.RowIndex).Cells("colNumeroP").Value
        anio = dgPolizaExportacion.Rows(e.RowIndex).Cells("colAnioP").Value
        If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.idGiro = 2 Then
            celdaNumero.Text = dgPolizaExportacion.Rows(e.RowIndex).Cells("colNumeroP").Value
            celdaNumero2.Text = dgPolizaExportacion.Rows(e.RowIndex).Cells("colNumeroDR1_Dbl").Value
        End If
        CargarReferencia(Numero, anio)
    End Sub

    Private Sub botonMenos_Click(sender As Object, e As EventArgs) Handles botonMenos.Click
        If Me.Tag = "Mod" Then
            botonMenos.Enabled = False
        Else
            Me.dgPolizaExportacion.Rows.Remove(dgPolizaExportacion.CurrentRow)
            dgDetalle.Rows.Clear()
            NuevoDetalle(celdaIdCliente.Text)
            AgregarAlDetalle()
        End If

    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        dgDetalle.SelectedCells(19).Value = (CDbl(dgDetalle.SelectedCells(15).Value) + CDbl(dgDetalle.SelectedCells(16).Value) + CDbl(dgDetalle.SelectedCells(17).Value) + CDbl(dgDetalle.SelectedCells(18).Value))

        dgDetalle.SelectedCells(8).Value = (CDbl(dgDetalle.SelectedCells(3).Value) * CDbl(dgDetalle.SelectedCells(7).Value))
        CalcularTotales()
    End Sub

    Private Sub botonClienteE_Click(sender As Object, e As EventArgs) Handles botonClienteE.Click
        Dim strRemplazo As String = STR_VACIO
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO

        strRemplazo = "c.cli_sisemp = {empresa}"
        strRemplazo = Replace(strRemplazo, "{empresa}", Sesion.IdEmpresa)


        Try

            frm.Titulo = "Customers"
            frm.Campos = "c.cli_codigo id, c.cli_cliente Client"
            frm.Tabla = "Clientes c"
            frm.FiltroText = "Enter the Client to filter"
            frm.Filtro = "c.cli_cliente"
            frm.Ordenamiento = "c.cli_cliente"
            frm.TipoOrdenamiento = ""
            frm.Condicion = strRemplazo

            frm.ShowDialog(Me)

            If frm.DialogResult = DialogResult.OK Then
                celdaClienteE.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicial.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            ListaPrincipal()

        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim NumDoc As Integer
        Try
            If EsReferenciaValida() Then
                'If Not EsPolizaValida() Then
                '    logConsultar = True
                'End If
            Else
                logConsultar = True
            End If

            If Me.Tag = "Nuevo" Or logEditar = True Then
                ComprobarIngreso()

                If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.idGiro = 2 Then
                    If celdaNumero.Text = NO_FILA Then
                        celdaNumero.Focus()
                        Exit Try
                    Else
                        If Me.Tag = "Nuevo" Then
                            If ValidarRegistro() = False Then
                                Exit Sub
                            End If
                        End If
                    End If
                Else
                    If celdaNumero.Text = NO_FILA Then
                        NumDoc = cfun.NuevoId(56)
                        celdaNumero.Text = NumDoc
                        If Not (celdaNumero.Text = NO_FILA) Then
                            If MsgBox("Year: " & vbTab & celdaAnio.Text & vbCrLf & "Number: " & vbTab & celdaNumero.Text & vbCrLf & vbCrLf & "Do you confirm the use of this document number?", vbExclamation + vbYesNo, "Confirm") = vbYes Then
                                celdaNumero.Text = NumDoc
                            Else
                                celdaNumero.Focus()
                                Exit Try
                            End If
                        End If
                    Else
                        If Me.Tag = "Nuevo" Then
                            If ValidarRegistro() = False Then
                                Exit Sub
                            End If
                        End If
                    End If
                End If

                If celdaNumero.Text > 0 Then
                    GuardarDocumento()
                    GuardarDetalle()
                    GuardarDescargos()
                    GuardarBultos()

                    cFunciones.EscribirRegistro(Tbl_Documentos, IIf(Me.Tag = "Nuevo", clsFunciones.AccEnum.acAdd, clsFunciones.AccEnum.acUpdate), , celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)
                End If
                MostrarLista()
            Else
                MsgBox("You do not have access for this action", vbInformation)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(56, dgLista.SelectedCells(6).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(6).Value, 56)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgPolizaExportacion_DoubleClick(sender As Object, e As EventArgs) Handles dgPolizaExportacion.DoubleClick
        If Me.Tag = "Mod" Then
            botonMenos.Enabled = False
        Else
            Dim strFila As String = STR_VACIO
            dgPolizaExportacion.CurrentRow.Cells(8).Value = 2
            For i As Integer = 0 To dgPolizaExportacion.Rows.Count - 1
                If dgPolizaExportacion.Rows.Count = 1 Then
                    strFila = dgPolizaExportacion.Rows(0).Cells("colNumeroDR1_Dbl").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colNumeroP").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colFechaP").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colOperadorP").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colReferenciaP").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colAnioP").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colCatalogoP").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colnumFel").Value & "|" & dgPolizaExportacion.Rows(0).Cells("colExtra").Value
                ElseIf dgPolizaExportacion.Rows(i).Cells("colExtra").Value = 2 Then
                    dgPolizaExportacion.CurrentRow.Cells(8).Value = 1
                    strFila = dgPolizaExportacion.Rows(i).Cells("colNumeroDR1_Dbl").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colNumeroP").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colFechaP").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colOperadorP").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colReferenciaP").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colAnioP").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colCatalogoP").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colnumFel").Value & "|" & dgPolizaExportacion.Rows(i).Cells("colExtra").Value
                End If

            Next
            dgPolizaExportacion.Rows.Clear()
            cFunciones.AgregarFila(dgPolizaExportacion, strFila)



            dgDetalle.Rows.Clear()
            DetalleSeleccionado(celdaIdCliente.Text)
            AgregarAlDetalle()
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 16 Or Sesion.idGiro = 2 Then
                celdaNumero.Clear()
                celdaNumero2.Clear()
                If Sesion.idGiro = 2 Then
                    celdaNumero.Text = cfun.NuevoId(56) 'dgPolizaExportacion.CurrentRow.Cells("colNumeroP").Value
                Else
                    celdaNumero.Text = dgPolizaExportacion.CurrentRow.Cells("colNumeroP").Value
                End If

                celdaNumero2.Text = dgPolizaExportacion.CurrentRow.Cells("colNumeroDR1_Dbl").Value
            End If
            CargarReferencia(dgPolizaExportacion.CurrentRow.Cells("colNumeroP").Value, dgPolizaExportacion.CurrentRow.Cells("colAnioP").Value)
        End If
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        celdaDate.Text = dtpFecha.Value.ToString(FORMATO_MYSQL)
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim frm As New frmGastosLogistica
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "SELECT b.PDoc_Par_Cat refcat , b.PDoc_Par_Ano refano , b.PDoc_Par_Num refnum, b.PDoc_Par_Lin reflin
                         FROM Dcmtos_DTL_Pro p
	                        LEFT JOIN Dcmtos_DTL_Pro f ON f.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND f.PDoc_Chi_Cat = p.PDoc_Par_Cat AND f.PDoc_Chi_Ano =p.PDoc_Par_Ano AND f.PDoc_Chi_Num = p.PDoc_Par_Num AND f.PDoc_Chi_Lin =p.PDoc_Par_Lin
	                        LEFT JOIN Dcmtos_DTL_Pro t ON t.PDoc_Sis_Emp = f.PDoc_Sis_Emp AND t.PDoc_Chi_Cat = f.PDoc_Par_Cat AND t.PDoc_Chi_Ano =f.PDoc_Par_Ano AND t.PDoc_Chi_Num = f.PDoc_Par_Num AND t.PDoc_Chi_Lin =f.PDoc_Par_Lin AND t.PDoc_Par_Cat = 47
	                        LEFT JOIN Dcmtos_DTL_Pro i ON i.PDoc_Sis_Emp = t.PDoc_Sis_Emp AND i.PDoc_Chi_Cat = t.PDoc_Par_Cat AND i.PDoc_Chi_Ano =t.PDoc_Par_Ano AND i.PDoc_Chi_Num = t.PDoc_Par_Num AND i.PDoc_Chi_Lin =t.PDoc_Par_Lin
	                        LEFT JOIN Dcmtos_DTL_Pro c ON c.PDoc_Sis_Emp = i.PDoc_Sis_Emp AND c.PDoc_Chi_Cat = i.PDoc_Par_Cat AND c.PDoc_Chi_Ano =i.PDoc_Par_Ano AND c.PDoc_Chi_Num = i.PDoc_Par_Num AND c.PDoc_Chi_Lin =i.PDoc_Par_Lin
	                        LEFT JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = c.PDoc_Sis_Emp AND b.PDoc_Chi_Cat = c.PDoc_Par_Cat AND b.PDoc_Chi_Ano =c.PDoc_Par_Ano AND b.PDoc_Chi_Num = c.PDoc_Par_Num AND b.PDoc_Chi_Lin =c.PDoc_Par_Lin
                        WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 56 AND p.PDoc_Chi_Ano = {ano} AND p.PDoc_Chi_Num = {num} AND p.PDoc_Chi_Lin = {lin} "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ano}", celdaAnio.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)
            strSQL = strSQL.Replace("{lin}", dgDetalle.CurrentRow.Cells("colLinea").Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    frm.Ref_Ano = REA.GetInt32("refano")
                    frm.Ref_Catalogo = REA.GetInt32("refcat")
                    frm.Ref_Numero = REA.GetInt32("refnum")
                    frm.Ref_linea = REA.GetInt32("reflin")
                Loop
                frm.Catalogo = 56
                frm.Ano = celdaAnio.Text
                frm.Numero = celdaNumero.Text
                frm.linea = dgDetalle.CurrentRow.Cells("colLinea").Value
                frm.celdaReferencia.Text = celdaFactura.Text
                frm.ShowDialog(Me)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim IntNumDocs As Integer
            Dim intNum As Integer = 0
            Dim intAnio As Integer = 0

            strSQL = VerificarSiTieneDependencias()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            IntNumDocs = COM.ExecuteScalar()

            If IntNumDocs > 0 Then
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            Else
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    intNum = celdaNumero.Text
                    intAnio = celdaAnio.Text
                    BorrarEncabezado()
                    BorrarDetalle()
                    BorrarDescargos()
                    BorrarBultos(intNum, intAnio)
                    BorrarDec()
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, celdaIdCliente.Text, celdaCatalogo.Text, celdaAnio.Text, celdaNumero.Text)
                    MsgBox("Delete Complete")
                    MostrarLista()
                End If
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub

#End Region
End Class