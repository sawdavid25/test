﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmInstDespachoFibra
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmInstDespachoFibra))
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.panelFecha = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelInferior = New System.Windows.Forms.Panel()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.gbPedidosCliente = New System.Windows.Forms.GroupBox()
        Me.dgPedidos = New System.Windows.Forms.DataGridView()
        Me.colPF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperador = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPOCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colYear = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.botonEliminar = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonDelete = New System.Windows.Forms.Button()
        Me.botonAdd = New System.Windows.Forms.Button()
        Me.panelAbajo = New System.Windows.Forms.Panel()
        Me.celdaTotales2 = New System.Windows.Forms.TextBox()
        Me.celdaTotales = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.gbDatosPedido = New System.Windows.Forms.GroupBox()
        Me.celdaImpuestos = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.etiquetaUsuario = New System.Windows.Forms.Label()
        Me.etiquetaCatalogo = New System.Windows.Forms.Label()
        Me.etiquetaEmpresa = New System.Windows.Forms.Label()
        Me.celdaCode = New System.Windows.Forms.TextBox()
        Me.dtpFecha1 = New System.Windows.Forms.DateTimePicker()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaIDCliente = New System.Windows.Forms.TextBox()
        Me.BotonCliente = New System.Windows.Forms.Button()
        Me.celdaTC = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.etiquetaNIT = New System.Windows.Forms.Label()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAño = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNPedido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFech = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colArticulo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExistencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDesc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLote = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBulto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colADespachar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPendiente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colGRS = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTC = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colObservation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumber = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContrato = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFecha.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.gbPedidosCliente.SuspendLayout()
        CType(Me.dgPedidos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelAbajo.SuspendLayout()
        Me.gbDatosPedido.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFecha)
        Me.panelLista.Controls.Add(Me.panelInferior)
        Me.panelLista.Location = New System.Drawing.Point(12, 108)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(837, 109)
        Me.panelLista.TabIndex = 3
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumber, Me.colDate, Me.colCliente, Me.colContrato, Me.colEstado, Me.colAño, Me.colTasa})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 49)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(837, 26)
        Me.dgLista.TabIndex = 0
        '
        'panelFecha
        '
        Me.panelFecha.Controls.Add(Me.botonActualizar)
        Me.panelFecha.Controls.Add(Me.dtpFin)
        Me.panelFecha.Controls.Add(Me.etiquetaFin)
        Me.panelFecha.Controls.Add(Me.dtpInicio)
        Me.panelFecha.Controls.Add(Me.checkFecha)
        Me.panelFecha.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFecha.Location = New System.Drawing.Point(0, 0)
        Me.panelFecha.Name = "panelFecha"
        Me.panelFecha.Size = New System.Drawing.Size(837, 49)
        Me.panelFecha.TabIndex = 1
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(432, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 5
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(328, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 4
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(271, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 3
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(182, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(7, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelInferior
        '
        Me.panelInferior.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelInferior.Location = New System.Drawing.Point(0, 75)
        Me.panelInferior.Name = "panelInferior"
        Me.panelInferior.Size = New System.Drawing.Size(837, 34)
        Me.panelInferior.TabIndex = 2
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.gbPedidosCliente)
        Me.panelDocumento.Controls.Add(Me.panelDetalle)
        Me.panelDocumento.Controls.Add(Me.panelAbajo)
        Me.panelDocumento.Controls.Add(Me.gbDatosPedido)
        Me.panelDocumento.Location = New System.Drawing.Point(12, 223)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(892, 456)
        Me.panelDocumento.TabIndex = 13
        '
        'gbPedidosCliente
        '
        Me.gbPedidosCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbPedidosCliente.Controls.Add(Me.dgPedidos)
        Me.gbPedidosCliente.Controls.Add(Me.Panel3)
        Me.gbPedidosCliente.Location = New System.Drawing.Point(452, 12)
        Me.gbPedidosCliente.Name = "gbPedidosCliente"
        Me.gbPedidosCliente.Size = New System.Drawing.Size(428, 110)
        Me.gbPedidosCliente.TabIndex = 9
        Me.gbPedidosCliente.TabStop = False
        Me.gbPedidosCliente.Text = "Customers Order"
        '
        'dgPedidos
        '
        Me.dgPedidos.AllowUserToAddRows = False
        Me.dgPedidos.AllowUserToDeleteRows = False
        Me.dgPedidos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgPedidos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgPedidos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgPedidos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colPF, Me.colFecha, Me.colOperador, Me.colPOCliente, Me.colYear, Me.colExtra})
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgPedidos.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgPedidos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgPedidos.Location = New System.Drawing.Point(3, 16)
        Me.dgPedidos.Name = "dgPedidos"
        Me.dgPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgPedidos.Size = New System.Drawing.Size(385, 91)
        Me.dgPedidos.TabIndex = 2
        '
        'colPF
        '
        Me.colPF.HeaderText = "PF N°"
        Me.colPF.Name = "colPF"
        Me.colPF.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colOperador
        '
        Me.colOperador.HeaderText = "Operator"
        Me.colOperador.Name = "colOperador"
        Me.colOperador.ReadOnly = True
        '
        'colPOCliente
        '
        Me.colPOCliente.HeaderText = "Client P.O"
        Me.colPOCliente.Name = "colPOCliente"
        Me.colPOCliente.ReadOnly = True
        '
        'colYear
        '
        Me.colYear.HeaderText = "Year"
        Me.colYear.Name = "colYear"
        Me.colYear.ReadOnly = True
        Me.colYear.Visible = False
        '
        'colExtra
        '
        Me.colExtra.HeaderText = "Extra"
        Me.colExtra.Name = "colExtra"
        Me.colExtra.ReadOnly = True
        Me.colExtra.Visible = False
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.botonEliminar)
        Me.Panel3.Controls.Add(Me.botonMas)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(388, 16)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(37, 91)
        Me.Panel3.TabIndex = 1
        '
        'botonEliminar
        '
        Me.botonEliminar.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminar.Location = New System.Drawing.Point(3, 35)
        Me.botonEliminar.Name = "botonEliminar"
        Me.botonEliminar.Size = New System.Drawing.Size(31, 19)
        Me.botonEliminar.TabIndex = 2
        Me.botonEliminar.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonMas.BackColor = System.Drawing.SystemColors.Control
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonMas.Location = New System.Drawing.Point(3, 7)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(31, 22)
        Me.botonMas.TabIndex = 1
        Me.botonMas.UseVisualStyleBackColor = False
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.Panel1)
        Me.panelDetalle.Controls.Add(Me.panelBotones)
        Me.panelDetalle.Location = New System.Drawing.Point(12, 287)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(866, 62)
        Me.panelDetalle.TabIndex = 8
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.dgDetalle)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(816, 62)
        Me.Panel1.TabIndex = 4
        '
        'dgDetalle
        '
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgDetalle.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAno, Me.colCatalogo, Me.colNPedido, Me.colLinea, Me.colFech, Me.colCodigo, Me.colArticulo, Me.colMedida, Me.colPrecio, Me.colExistencia, Me.colLineaDesc, Me.colFactura, Me.colLote, Me.colFechaFactura, Me.colBulto, Me.colADespachar, Me.colPendiente, Me.colGRS, Me.colTC, Me.colXtra, Me.colIdMedida, Me.colObservation})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgDetalle.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.RowTemplate.Height = 24
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(816, 62)
        Me.dgDetalle.TabIndex = 2
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonDelete)
        Me.panelBotones.Controls.Add(Me.botonAdd)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(816, 0)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(50, 62)
        Me.panelBotones.TabIndex = 3
        '
        'botonDelete
        '
        Me.botonDelete.Image = CType(resources.GetObject("botonDelete.Image"), System.Drawing.Image)
        Me.botonDelete.Location = New System.Drawing.Point(5, 48)
        Me.botonDelete.Name = "botonDelete"
        Me.botonDelete.Size = New System.Drawing.Size(30, 23)
        Me.botonDelete.TabIndex = 1
        Me.botonDelete.UseVisualStyleBackColor = True
        '
        'botonAdd
        '
        Me.botonAdd.Enabled = False
        Me.botonAdd.Image = CType(resources.GetObject("botonAdd.Image"), System.Drawing.Image)
        Me.botonAdd.Location = New System.Drawing.Point(5, 15)
        Me.botonAdd.Name = "botonAdd"
        Me.botonAdd.Size = New System.Drawing.Size(30, 23)
        Me.botonAdd.TabIndex = 0
        Me.botonAdd.UseVisualStyleBackColor = True
        '
        'panelAbajo
        '
        Me.panelAbajo.Controls.Add(Me.celdaTotales2)
        Me.panelAbajo.Controls.Add(Me.celdaTotales)
        Me.panelAbajo.Controls.Add(Me.etiquetaTotales)
        Me.panelAbajo.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelAbajo.Location = New System.Drawing.Point(0, 335)
        Me.panelAbajo.Name = "panelAbajo"
        Me.panelAbajo.Size = New System.Drawing.Size(892, 121)
        Me.panelAbajo.TabIndex = 5
        '
        'celdaTotales2
        '
        Me.celdaTotales2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotales2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotales2.Location = New System.Drawing.Point(705, 23)
        Me.celdaTotales2.Multiline = True
        Me.celdaTotales2.Name = "celdaTotales2"
        Me.celdaTotales2.ReadOnly = True
        Me.celdaTotales2.Size = New System.Drawing.Size(92, 30)
        Me.celdaTotales2.TabIndex = 14
        Me.celdaTotales2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaTotales
        '
        Me.celdaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotales.Location = New System.Drawing.Point(606, 23)
        Me.celdaTotales.Multiline = True
        Me.celdaTotales.Name = "celdaTotales"
        Me.celdaTotales.ReadOnly = True
        Me.celdaTotales.Size = New System.Drawing.Size(93, 30)
        Me.celdaTotales.TabIndex = 13
        Me.celdaTotales.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTotales.Location = New System.Drawing.Point(553, 21)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(47, 17)
        Me.etiquetaTotales.TabIndex = 12
        Me.etiquetaTotales.Text = "Totals"
        '
        'gbDatosPedido
        '
        Me.gbDatosPedido.Controls.Add(Me.celdaImpuestos)
        Me.gbDatosPedido.Controls.Add(Me.celdaUsuario)
        Me.gbDatosPedido.Controls.Add(Me.celdaCatalogo)
        Me.gbDatosPedido.Controls.Add(Me.celdaEmpresa)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaUsuario)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaCatalogo)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaEmpresa)
        Me.gbDatosPedido.Controls.Add(Me.celdaCode)
        Me.gbDatosPedido.Controls.Add(Me.dtpFecha1)
        Me.gbDatosPedido.Controls.Add(Me.celdaIDMoneda)
        Me.gbDatosPedido.Controls.Add(Me.botonMoneda)
        Me.gbDatosPedido.Controls.Add(Me.celdaIDCliente)
        Me.gbDatosPedido.Controls.Add(Me.BotonCliente)
        Me.gbDatosPedido.Controls.Add(Me.celdaTC)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaTasa)
        Me.gbDatosPedido.Controls.Add(Me.celdaNit)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNIT)
        Me.gbDatosPedido.Controls.Add(Me.checkActivo)
        Me.gbDatosPedido.Controls.Add(Me.celdaCliente)
        Me.gbDatosPedido.Controls.Add(Me.celdaMoneda)
        Me.gbDatosPedido.Controls.Add(Me.celdaDireccion)
        Me.gbDatosPedido.Controls.Add(Me.celdaNumero)
        Me.gbDatosPedido.Controls.Add(Me.celdaAño)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaMoneda)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaDireccion)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaCliente)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaFecha)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaNumero)
        Me.gbDatosPedido.Controls.Add(Me.etiquetaAño)
        Me.gbDatosPedido.Location = New System.Drawing.Point(12, 12)
        Me.gbDatosPedido.Name = "gbDatosPedido"
        Me.gbDatosPedido.Size = New System.Drawing.Size(434, 269)
        Me.gbDatosPedido.TabIndex = 4
        Me.gbDatosPedido.TabStop = False
        Me.gbDatosPedido.Text = "Invoice  Information"
        '
        'celdaImpuestos
        '
        Me.celdaImpuestos.Location = New System.Drawing.Point(60, 244)
        Me.celdaImpuestos.Name = "celdaImpuestos"
        Me.celdaImpuestos.Size = New System.Drawing.Size(27, 20)
        Me.celdaImpuestos.TabIndex = 40
        Me.celdaImpuestos.Text = "-1"
        Me.celdaImpuestos.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(222, 223)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(27, 20)
        Me.celdaUsuario.TabIndex = 36
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(90, 218)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(27, 20)
        Me.celdaCatalogo.TabIndex = 35
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(61, 218)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(27, 20)
        Me.celdaEmpresa.TabIndex = 34
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'etiquetaUsuario
        '
        Me.etiquetaUsuario.AutoSize = True
        Me.etiquetaUsuario.Location = New System.Drawing.Point(178, 225)
        Me.etiquetaUsuario.Name = "etiquetaUsuario"
        Me.etiquetaUsuario.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaUsuario.TabIndex = 33
        Me.etiquetaUsuario.Text = "Usuario"
        Me.etiquetaUsuario.Visible = False
        '
        'etiquetaCatalogo
        '
        Me.etiquetaCatalogo.AutoSize = True
        Me.etiquetaCatalogo.Location = New System.Drawing.Point(5, 245)
        Me.etiquetaCatalogo.Name = "etiquetaCatalogo"
        Me.etiquetaCatalogo.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaCatalogo.TabIndex = 32
        Me.etiquetaCatalogo.Text = "Catalogo"
        Me.etiquetaCatalogo.Visible = False
        '
        'etiquetaEmpresa
        '
        Me.etiquetaEmpresa.AutoSize = True
        Me.etiquetaEmpresa.Location = New System.Drawing.Point(2, 223)
        Me.etiquetaEmpresa.Name = "etiquetaEmpresa"
        Me.etiquetaEmpresa.Size = New System.Drawing.Size(48, 13)
        Me.etiquetaEmpresa.TabIndex = 31
        Me.etiquetaEmpresa.Text = "Empresa"
        Me.etiquetaEmpresa.Visible = False
        '
        'celdaCode
        '
        Me.celdaCode.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCode.Location = New System.Drawing.Point(397, 18)
        Me.celdaCode.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCode.Name = "celdaCode"
        Me.celdaCode.Size = New System.Drawing.Size(27, 20)
        Me.celdaCode.TabIndex = 30
        Me.celdaCode.Visible = False
        '
        'dtpFecha1
        '
        Me.dtpFecha1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha1.Location = New System.Drawing.Point(62, 68)
        Me.dtpFecha1.Name = "dtpFecha1"
        Me.dtpFecha1.Size = New System.Drawing.Size(146, 20)
        Me.dtpFecha1.TabIndex = 29
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(173, 195)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDMoneda.TabIndex = 25
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(138, 193)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(30, 23)
        Me.botonMoneda.TabIndex = 24
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaIDCliente
        '
        Me.celdaIDCliente.Location = New System.Drawing.Point(397, 95)
        Me.celdaIDCliente.Name = "celdaIDCliente"
        Me.celdaIDCliente.Size = New System.Drawing.Size(27, 20)
        Me.celdaIDCliente.TabIndex = 23
        Me.celdaIDCliente.Text = "-1"
        Me.celdaIDCliente.Visible = False
        '
        'BotonCliente
        '
        Me.BotonCliente.Location = New System.Drawing.Point(355, 92)
        Me.BotonCliente.Name = "BotonCliente"
        Me.BotonCliente.Size = New System.Drawing.Size(30, 23)
        Me.BotonCliente.TabIndex = 22
        Me.BotonCliente.Text = "..."
        Me.BotonCliente.UseVisualStyleBackColor = True
        '
        'celdaTC
        '
        Me.celdaTC.Location = New System.Drawing.Point(257, 199)
        Me.celdaTC.Name = "celdaTC"
        Me.celdaTC.Size = New System.Drawing.Size(71, 20)
        Me.celdaTC.TabIndex = 19
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(227, 202)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 18
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaNit
        '
        Me.celdaNit.Enabled = False
        Me.celdaNit.Location = New System.Drawing.Point(61, 169)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(129, 20)
        Me.celdaNit.TabIndex = 17
        '
        'etiquetaNIT
        '
        Me.etiquetaNIT.AutoSize = True
        Me.etiquetaNIT.Location = New System.Drawing.Point(11, 171)
        Me.etiquetaNIT.Name = "etiquetaNIT"
        Me.etiquetaNIT.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNIT.TabIndex = 16
        Me.etiquetaNIT.Text = "NIT"
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(282, 27)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 15
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Enabled = False
        Me.celdaCliente.Location = New System.Drawing.Point(62, 94)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.Size = New System.Drawing.Size(287, 20)
        Me.celdaCliente.TabIndex = 14
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Enabled = False
        Me.celdaMoneda.Location = New System.Drawing.Point(61, 195)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(71, 20)
        Me.celdaMoneda.TabIndex = 12
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Enabled = False
        Me.celdaDireccion.Location = New System.Drawing.Point(62, 116)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(323, 44)
        Me.celdaDireccion.TabIndex = 10
        '
        'celdaNumero
        '
        Me.celdaNumero.Enabled = False
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.Color.SteelBlue
        Me.celdaNumero.Location = New System.Drawing.Point(62, 46)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(71, 20)
        Me.celdaNumero.TabIndex = 9
        '
        'celdaAño
        '
        Me.celdaAño.Enabled = False
        Me.celdaAño.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAño.ForeColor = System.Drawing.Color.SteelBlue
        Me.celdaAño.Location = New System.Drawing.Point(62, 24)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(71, 20)
        Me.celdaAño.TabIndex = 8
        Me.celdaAño.Text = "2016"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(6, 195)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 7
        Me.etiquetaMoneda.Text = "Currency"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(6, 119)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Address"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(6, 97)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Customer"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(6, 71)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(6, 49)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAño
        '
        Me.etiquetaAño.AutoSize = True
        Me.etiquetaAño.Location = New System.Drawing.Point(6, 27)
        Me.etiquetaAño.Name = "etiquetaAño"
        Me.etiquetaAño.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAño.TabIndex = 0
        Me.etiquetaAño.Text = "Year"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(934, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(934, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'colAno
        '
        Me.colAno.HeaderText = "Year"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.Visible = False
        '
        'colNPedido
        '
        Me.colNPedido.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNPedido.HeaderText = "No. Order"
        Me.colNPedido.Name = "colNPedido"
        Me.colNPedido.ReadOnly = True
        Me.colNPedido.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colNPedido.Width = 59
        '
        'colLinea
        '
        Me.colLinea.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colLinea.HeaderText = "Order Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colLinea.Width = 62
        '
        'colFech
        '
        Me.colFech.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFech.HeaderText = "Date"
        Me.colFech.Name = "colFech"
        Me.colFech.ReadOnly = True
        Me.colFech.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFech.Width = 36
        '
        'colCodigo
        '
        Me.colCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCodigo.HeaderText = "Code*"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colCodigo.Width = 42
        '
        'colArticulo
        '
        Me.colArticulo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colArticulo.HeaderText = "Article*"
        Me.colArticulo.Name = "colArticulo"
        Me.colArticulo.ReadOnly = True
        Me.colArticulo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colArticulo.Width = 46
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colMedida.Width = 54
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPrecio.HeaderText = "Price $"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.ReadOnly = True
        Me.colPrecio.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPrecio.Width = 46
        '
        'colExistencia
        '
        Me.colExistencia.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colExistencia.HeaderText = "Available"
        Me.colExistencia.Name = "colExistencia"
        Me.colExistencia.ReadOnly = True
        Me.colExistencia.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colExistencia.Width = 56
        '
        'colLineaDesc
        '
        Me.colLineaDesc.HeaderText = "ID"
        Me.colLineaDesc.Name = "colLineaDesc"
        Me.colLineaDesc.ReadOnly = True
        Me.colLineaDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colFactura
        '
        Me.colFactura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFactura.HeaderText = "Invoice"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colFactura.Width = 48
        '
        'colLote
        '
        Me.colLote.HeaderText = "Lot"
        Me.colLote.Name = "colLote"
        Me.colLote.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colFechaFactura
        '
        Me.colFechaFactura.HeaderText = "Date Invoice"
        Me.colFechaFactura.Name = "colFechaFactura"
        Me.colFechaFactura.ReadOnly = True
        Me.colFechaFactura.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colBulto
        '
        Me.colBulto.HeaderText = "Package"
        Me.colBulto.Name = "colBulto"
        Me.colBulto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'colADespachar
        '
        Me.colADespachar.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colADespachar.HeaderText = "QTY KGS*"
        Me.colADespachar.Name = "colADespachar"
        Me.colADespachar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colADespachar.Width = 64
        '
        'colPendiente
        '
        Me.colPendiente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colPendiente.HeaderText = "Total"
        Me.colPendiente.Name = "colPendiente"
        Me.colPendiente.ReadOnly = True
        Me.colPendiente.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colPendiente.Width = 37
        '
        'colGRS
        '
        Me.colGRS.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colGRS.HeaderText = "GRS"
        Me.colGRS.Name = "colGRS"
        Me.colGRS.ReadOnly = True
        Me.colGRS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colGRS.Width = 36
        '
        'colTC
        '
        Me.colTC.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colTC.HeaderText = "TC"
        Me.colTC.Name = "colTC"
        Me.colTC.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colTC.Width = 27
        '
        'colXtra
        '
        Me.colXtra.HeaderText = "Extra"
        Me.colXtra.Name = "colXtra"
        Me.colXtra.ReadOnly = True
        Me.colXtra.Visible = False
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "Base"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.Visible = False
        '
        'colObservation
        '
        Me.colObservation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colObservation.HeaderText = "Observations"
        Me.colObservation.Name = "colObservation"
        Me.colObservation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.colObservation.Width = 75
        '
        'colNumber
        '
        Me.colNumber.HeaderText = "Number"
        Me.colNumber.Name = "colNumber"
        Me.colNumber.ReadOnly = True
        '
        'colDate
        '
        Me.colDate.HeaderText = "Date"
        Me.colDate.Name = "colDate"
        Me.colDate.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        Me.colCliente.Width = 58
        '
        'colContrato
        '
        Me.colContrato.HeaderText = "Contract Number"
        Me.colContrato.Name = "colContrato"
        Me.colContrato.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "State"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        Me.colTasa.Visible = False
        '
        'frmInstDespachoFibra
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(934, 691)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmInstDespachoFibra"
        Me.Text = "frmInstDespachoFibra"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFecha.ResumeLayout(False)
        Me.panelFecha.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.gbPedidosCliente.ResumeLayout(False)
        CType(Me.dgPedidos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelAbajo.ResumeLayout(False)
        Me.panelAbajo.PerformLayout()
        Me.gbDatosPedido.ResumeLayout(False)
        Me.gbDatosPedido.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFecha As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelInferior As Panel
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonDelete As Button
    Friend WithEvents botonAdd As Button
    Friend WithEvents panelAbajo As Panel
    Friend WithEvents celdaTotales2 As TextBox
    Friend WithEvents celdaTotales As TextBox
    Friend WithEvents etiquetaTotales As Label
    Friend WithEvents gbDatosPedido As GroupBox
    Friend WithEvents celdaImpuestos As TextBox
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaEmpresa As TextBox
    Friend WithEvents etiquetaUsuario As Label
    Friend WithEvents etiquetaCatalogo As Label
    Friend WithEvents etiquetaEmpresa As Label
    Friend WithEvents celdaCode As TextBox
    Friend WithEvents dtpFecha1 As DateTimePicker
    Friend WithEvents celdaIDMoneda As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaIDCliente As TextBox
    Friend WithEvents BotonCliente As Button
    Friend WithEvents celdaTC As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents etiquetaNIT As Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAño As Label
    Friend WithEvents gbPedidosCliente As GroupBox
    Friend WithEvents Panel3 As Panel
    Friend WithEvents botonEliminar As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents dgPedidos As DataGridView
    Friend WithEvents dgDetalle As DataGridView
    Friend WithEvents colPF As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colOperador As DataGridViewTextBoxColumn
    Friend WithEvents colPOCliente As DataGridViewTextBoxColumn
    Friend WithEvents colYear As DataGridViewTextBoxColumn
    Friend WithEvents colExtra As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colNPedido As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colFech As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colArticulo As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colExistencia As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDesc As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents colLote As DataGridViewTextBoxColumn
    Friend WithEvents colFechaFactura As DataGridViewTextBoxColumn
    Friend WithEvents colBulto As DataGridViewTextBoxColumn
    Friend WithEvents colADespachar As DataGridViewTextBoxColumn
    Friend WithEvents colPendiente As DataGridViewTextBoxColumn
    Friend WithEvents colGRS As DataGridViewTextBoxColumn
    Friend WithEvents colTC As DataGridViewTextBoxColumn
    Friend WithEvents colXtra As DataGridViewTextBoxColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colObservation As DataGridViewTextBoxColumn
    Friend WithEvents colNumber As DataGridViewTextBoxColumn
    Friend WithEvents colDate As DataGridViewTextBoxColumn
    Friend WithEvents colCliente As DataGridViewTextBoxColumn
    Friend WithEvents colContrato As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
End Class
