﻿Public Class frmCertificacion
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strTexto As String = STR_VACIO

    Private Const CATALOGO = 862
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            '  botonImprimir.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            '  botonImprimir.Enabled = True
        End If
    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos
        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function SQLLista() As String
        Dim strSQL As String

        strSQL = " SELECT HDR.HDoc_Doc_Num Numero,HDR.HDoc_Doc_Ano Anio, HDR.HDoc_Doc_Fec fecha ,IFNULL(c.cli_nombre,c.cli_cliente) Cliente, IF(HDR.HDoc_Doc_Status=0,'CANCELED','ACTIVE') Estado "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " LEFT JOIN Clientes c ON c.cli_sisemp = HDR.HDoc_Sis_Emp AND c.cli_codigo = HDR.HDoc_Emp_Cod "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} "
        If checkFiltroFecha.Checked = True Then
            strSQL &= "     AND (HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}')"
        End If
        strSQL &= " ORDER by HDR.HDoc_Doc_Fec desc , HDR.HDoc_Doc_Num DESC "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 862)
        strSQL = Replace(strSQL, "{fechainicial}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strLinea As String = STR_VACIO
        strSQL = SQLLista()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        dgLista.Rows.Clear()
        If REA.HasRows Then
            dgLista.Rows.Clear()
            Do While REA.Read
                strLinea = REA.GetInt32("Numero") & "|" ' CODIGO
                strLinea &= REA.GetInt32("Anio") & "|" ' Año
                strLinea &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|" 'fecha
                strLinea &= REA.GetString("Cliente") & "|" ' Cliente
                strLinea &= REA.GetString("Estado") ' ESTADO 
                If REA.GetString("Estado") = "CANCELED" Then
                    cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                Else
                    cFunciones.AgregarFila(dgLista, strLinea)
                End If
            Loop
        End If
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Certifications")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLlista, False)
            CargarListaPrincipal()
            'Mostrar Panel Filtro
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Record")
                Me.Tag = "Mod"
                BloquearBotones(False)
                'botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Record")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                Limpiar()
                'botonImprimir.Enabled = False
                'LimpiarPanelOrden()
            End If
            dgLista.DataSource = Nothing
        End If
    End Sub
    Public Function ValidarCampos()
        Dim logValidacion As Boolean = True
        Try
            If celdaidCliente.Text = NO_FILA Then
                MsgBox("Select Cliente ", vbExclamation, "NOTICE")
                celdaCliente.Focus()
                logValidacion = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidacion
    End Function
    Public Sub Limpiar()
        celdaNumero.Text = NO_FILA
        celdaAño.Text = NO_FILA
        celdaCliente.Text = STR_VACIO
        celdaidCliente.Text = NO_FILA
        celdaDireccion.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaidMoneda.Text = STR_VACIO
        celdaTasa.Text = INT_UNO
        dtpFecha.Value = Now()
        celdaAño.Text = cFunciones.AñoMySQL
        celdaCertificacion.Text = STR_VACIO
        checkActive.Checked = True
        dgDetalle.Rows.Clear()
        dgNotificacion.Rows.Clear()
    End Sub
    Public Function sqlFactura(ByVal Anio As Integer, ByVal Numero As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT {campo} , d.DDoc_Prd_Cod  Codigo  ,h.HDoc_DR1_Num Referencia, a.art_DCorta Descripcion , d.DDoc_Prd_QTY  Cantidad ,a.art_venta Tipo ,d.DDoc_Doc_Ano Anio , d.DDoc_Doc_Num Num ,d.DDoc_Doc_Lin Linea,i.inv_prodlote Lote,d.DDoc_RF2_Dbl Brutos , d.DDoc_Prd_Fob Netos,b.cat_num idMedida,b.cat_clave Medida,e.BDoc_Box_QTY Bulto, IFNULL(( "
        strSQL &= "     SELECT c.ADoc_Dta_Chr  "
        strSQL &= "         FROM Dcmtos_ACC c "
        strSQL &= "             WHERE c.ADoc_Sis_Emp = d.DDoc_Sis_Emp AND c.ADoc_Doc_Cat = d.DDoc_Doc_Cat AND c.ADoc_Doc_Ano = d.DDoc_Doc_Ano AND c.ADoc_Doc_Num = d.DDoc_Doc_Num AND c.ADoc_Doc_Sub = 'Doc_CCPorte2' AND c.ADoc_Doc_Lin = '10' ),'') PO "
        strSQL &= "                 FROM Dcmtos_DTL d  "
        strSQL &= "               LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod  "
        strSQL &= "            LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo  "
        strSQL &= "      LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num  "
        strSQL &= "   LEFT JOIN Catalogos b ON b.cat_num = d.DDoc_Prd_UM AND b.cat_clase='Medidas'"
        strSQL &= " LEFT JOIN Dcmtos_DTL_Box e ON e.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.BDoc_Doc_Num = d.DDoc_Doc_Num AND e.BDoc_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL &= "WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 36 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num  = {numero} AND a.art_venta IN(1,2) "
        If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 14) Then
            strSQL = Replace(strSQL, "{campo}", "h.HDoc_DR1_Dbl Num")
        Else
            strSQL = Replace(strSQL, "{campo}", "h.HDoc_Doc_Num Num")
        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Numero)
        Return strSQL
    End Function
    Public Function AgregarDetalle(ByVal Anio As Integer, ByVal Numero As Integer) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Dim cfun As New clsFunciones
        Dim logVerificar As Boolean = True
        Dim intContador As Integer = INT_CERO
        Try
            strSQL = sqlFactura(Anio, Numero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If dgDetalle.Rows.Count = 0 Then
                        strFila = REA.GetInt32("Num") & "|" ' Factura 
                        strFila &= intContador + 1 & "|" ' Linea 
                        strFila &= REA.GetString("Lote") & "|" ' Lote
                        strFila &= REA.GetString("PO") & "|" ' #PO
                        If REA.GetString("Tipo") = 1 Then
                            strFila &= "RCS " & REA.GetInt32("Codigo") & "|" ' Producto
                        Else
                            strFila &= "OCS " & REA.GetInt32("Codigo") & "|" ' Producto 
                        End If
                        strFila &= REA.GetString("Referencia") & "|" ' Referencia 
                        strFila &= REA.GetString("Descripcion") & "|" ' Descripcion
                        strFila &= REA.GetInt32("idMedida") & "|" 'idMedida
                        strFila &= REA.GetString("Medida") & "|" 'Medida
                        strFila &= REA.GetDouble("Cantidad") & "|" ' Cantidad 
                        strFila &= REA.GetDouble("Brutos") & "|" ' Peso Bruto
                        strFila &= REA.GetDouble("Netos") & "|" 'Peso Neto
                        strFila &= REA.GetDouble("Bulto") & "|" 'Bultos
                        strFila &= INT_CERO & "|" ' Total 
                        strFila &= 36 & "|" ' Catalogo 
                        strFila &= REA.GetInt32("Anio") & "|" ' Anio 
                        strFila &= REA.GetInt32("Num") & "|" ' Numero 
                        strFila &= REA.GetInt32("Linea") & "|" ' Linea 
                        strFila &= INT_CERO ' EStado
                        cfun.AgregarFila(dgDetalle, strFila)
                    Else
                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                            If dgDetalle.Rows(i).Visible = True Then
                                intContador = dgDetalle.Rows(i).Cells("colLin").Value
                                If dgDetalle.Rows(i).Cells("colFact").Value = REA.GetInt32("Num") And dgDetalle.Rows(i).Cells("colLinea").Value = REA.GetInt32("Linea") Then
                                    MsgBox("The line that select is already repeated")
                                    logVerificar = False
                                    Exit Function
                                End If
                            End If
                        Next
                        If logVerificar = True Then
                            strFila = REA.GetInt32("Num") & "|"
                            strFila &= intContador + 1 & "|"
                            strFila &= REA.GetString("Lote") & "|" ' Lote
                            strFila &= REA.GetString("PO") & "|" ' #PO
                            If REA.GetString("Tipo") = 1 Then
                                strFila &= "RCS " & REA.GetInt32("Codigo") & "|" ' Producto
                            Else
                                strFila &= "OCS " & REA.GetInt32("Codigo") & "|" ' Producto
                            End If
                            strFila &= REA.GetString("Referencia") & "|" ' Referencia 
                            strFila &= REA.GetString("Descripcion") & "|" ' Descripcion
                            strFila &= REA.GetInt32("idMedida") & "|" 'idMedida
                            strFila &= REA.GetString("Medida") & "|" 'Medida
                            strFila &= REA.GetDouble("Cantidad") & "|" ' Cantidad 
                            strFila &= REA.GetDouble("Brutos") & "|" ' Peso Bruto
                            strFila &= REA.GetDouble("Netos") & "|" 'Peso Neto
                            strFila &= REA.GetDouble("Bulto") & "|" 'Bultos
                            strFila &= INT_CERO & "|" ' Total 
                            strFila &= 36 & "|" ' Catalogo 
                            strFila &= REA.GetInt32("Anio") & "|" ' Anio 
                            strFila &= REA.GetInt32("Num") & "|" ' Numero 
                            strFila &= REA.GetInt32("Linea") & "|" ' Linea 
                            strFila &= INT_CERO
                            cfun.AgregarFila(dgDetalle, strFila)
                        End If

                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerificar
    End Function
    Public Sub CalcularTotales()
        Dim dblTotal As Double = INT_CERO
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                dblTotal = dblTotal + dgDetalle.Rows(i).Cells("colTotalC").Value
            Next
            celdaCertificacion.Text = dblTotal.ToString("###0.00")
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function FilaNotificacion() As String
        Dim strLinea As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQl As String

        strSQl = " Select pe.per_codigo Codigo, IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Puesto,pe.per_correo Correo"
        strSQl &= "  FROM Personal pe "
        strSQl &= "  LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto"
        strSQl &= " where pe.per_sisemp= {empresa} and pe.per_codigo = {codigo}"

        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
        strSQl = Replace(strSQl, "{codigo}", Sesion.idUsuario)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQl, CON)
        REA = COM.ExecuteReader
        Do While REA.Read
            strLinea = STR_VACIO


            strLinea = "0|" 'ID ccc
            strLinea &= REA.GetString("Puesto") & "|" 'PUESTO USUARIO   
            strLinea &= Sesion.Usuario & "|" ' USUARIO
            strLinea &= REA.GetInt32("Codigo") & "|" 'CODIGO USUARIO
            strLinea &= "|" 'OBSERVACION
            strLinea &= REA.GetString("Correo") & "|" 'CORREO
            strLinea &= "0" ' Acciones
            cFunciones.AgregarFila(dgNotificacion, strLinea)
        Loop
        Return strSQl
    End Function
    Private Function NuevaCertificacion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} And HDR.HDoc_Doc_Ano = {anio} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 862)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 862)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function NuevoDescargo(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " SELECT IFNULL(MAX(p.PDoc_Chi_Lin),0) + 1  linea "
        strSQL &= " FROM Dcmtos_DTL_Pro p "
        strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = {catalogo} AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 862)
        strSQL = Replace(strSQL, "{anio}", cFunciones.AñoMySQL)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function

    Private Function Guardar() As Boolean
        Dim LogVerdadero As Boolean = False
        Dim HDR As New clsDcmtos_HDR
        Try
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = 862
            HDR.HDOC_DOC_ANO = celdaAño.Text
            HDR.HDOC_EMP_COD = celdaidCliente.Text
            HDR.HDOC_EMP_NOM = celdaCliente.Text
            HDR.HDOC_EMP_DIR = celdaDireccion.Text
            '   HDR.HDOC_EMP_NIT = celdaNit.Text
            HDR.HDOC_DOC_MON = celdaidMoneda.Text
            HDR.HDOC_DOC_TC = celdaTasa.Text
            '  HDR.HDOC_DR1_NUM = celdaPO.Text 'PO
            ' HDR.HDoc_DR1_Fec_NET = dtpFechaExpiracion.Value ' Fecha Expiracion
            'HDR.HDOC_DR2_NUM = celdaDrawee.Text ' Drawee
            ' HDR.HDOC_RF1_TXT = celdaComentario.Text ' Comentario 
            'HDR.HDOC_RF1_COD = celdaLC.Text
            'HDR.HDOC_DR1_CAT = celdaTotal.Text ' Amount
            If checkActive.Checked = True Then
                HDR.HDOC_DOC_STATUS = 1 ' Check Activo
            Else
                HDR.HDOC_DOC_STATUS = 0 ' ANULADO
            End If
            If dtpFecha.Format = DateTimePickerFormat.Custom Then
            Else
                HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            End If

            HDR.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    HDR.HDOC_USUARIO = Sesion.Usuario
                    HDR.HDOC_DOC_NUM = NuevaCertificacion()
                    celdaNumero.Text = HDR.HDOC_DOC_NUM
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, celdaidCliente.Text, 862, celdaAño.Text, HDR.HDOC_DOC_NUM, strTexto)
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not save this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True

                        If GuardarDetalle(HDR.HDOC_DOC_NUM) = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                        If GuardarDcmtosPro(HDR.HDOC_DOC_NUM, celdaAño.Text) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                        If GuardarNotificacion(HDR.HDOC_DOC_NUM) = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                        If EnvioProyecto() = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                    End If
                Else
                    MsgBox("Does Not have Permissions")
                End If
            Else
                'codigo para actualizar CompraSolicitada
                If logEditar = True Then
                    HDR.HDOC_DOC_NUM = celdaNumero.Text
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, celdaidCliente.Text, 862, celdaAño.Text, celdaNumero.Text, strTexto)
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString & " Could not Modify this document ", MsgBoxStyle.Critical)
                    Else
                        LogVerdadero = True
                        If GuardarDetalle(HDR.HDOC_DOC_NUM) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                        If GuardarDcmtosPro(HDR.HDOC_DOC_NUM, celdaAño.Text) Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                        If GuardarNotificacion(celdaNumero.Text) = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                        If EnvioProyecto() = True Then
                            LogVerdadero = True
                        Else
                            LogVerdadero = False
                        End If
                    End If
                Else
                    MsgBox("Does Not Have Permissions")
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogVerdadero
    End Function
    Private Function GuardarNotificacion(ByVal CodigoProyecto As Integer) As Boolean
        Dim NO As New Tablas.TNOTIFICACIONES
        Dim logNotificacion As Boolean = True
        NO.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgNotificacion.RowCount - 1
                NO.EMPRESA = Sesion.IdEmpresa
                NO.IDPROYECTO = CodigoProyecto
                NO.IDTAREA = NO_FILA
                NO.IDUSUARIO = dgNotificacion.Rows(i).Cells("colUsuario").Value
                NO.OBSERVACIONES = dgNotificacion.Rows(i).Cells("colObservacion").Value
                If dgNotificacion.Rows(i).Cells("colEstatus").Value = 0 Then
                    NO.IDNOTIFICACION = dgNotificacion.Rows(i).Cells("colIdNotifiaciones").Value = 0
                    If NO.PINSERT = False Then
                        MsgBox(NO.MERROR.ToString & "Could Not Save this Document ")
                        Return False
                        Exit Function
                    Else
                        logNotificacion = True
                    End If
                    'GuardarNotificacionPorTarea(CodigoProyecto)
                End If
                If dgNotificacion.Rows(i).Cells("colEstatus").Value = 1 Then
                    NO.IDNOTIFICACION = dgNotificacion.Rows(i).Cells("colIdNotifiaciones").Value
                    If NO.PUPDATE = False Then
                        MsgBox(NO.MERROR.ToString & "Could Not Save this Document ")
                        Return False
                        Exit Function
                    Else
                        logNotificacion = True
                    End If
                    '  GuardarNotificacionPorTarea(CodigoProyecto)
                End If
                If dgNotificacion.Rows(i).Cells("colEstatus").Value = 2 Then
                    NO.IDNOTIFICACION = dgNotificacion.Rows(i).Cells("colIdNotifiaciones").Value
                    NO.EMPRESA = Sesion.IdEmpresa
                    If NO.PDELETE = False Then
                        MsgBox(NO.MERROR.ToString & "Could Not Delete this Document")
                        Return False
                        Exit Function
                    Else
                        logNotificacion = True
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logNotificacion
    End Function
    Private Function EnvioProyecto() As Boolean
        Dim logEnvio As Boolean = False
        Dim mail As New clsCorreo
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim REA As MySqlDataReader
        Dim correo As New Tablas.TCORREO
        Dim j As Integer
        Dim K As Integer
        Dim conec As New MySqlConnection
        Dim COM1 As MySqlCommand
        Dim strInsert As String = STR_VACIO
        Dim strUsuario As String
        Dim strSQL1 As String
        Dim strConexion2 As String
        Dim strTemporal As String = STR_VACIO
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strEncabezadoHTML As String = STR_VACIO
        Dim strDatosHTML As String = STR_VACIO
        Dim Actual As DateTime = Convert.ToDateTime(Now)
        Try
            ArrayServer = strConexion.Split(";".ToCharArray)
            strConexion2 = "server={server};port={puerto};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

            If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
                strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
            Else
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
                strConexion2 = Replace(strConexion2, "{puerto}", "3308")
            End If

            strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
            strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
            strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)


            strSQL1 = " Select   CONCAT(per_nombre1 ,'  ' ,per_apellido1) Puesto  FRom Personal  WHERE per_codigo={usuario} "
            strSQL1 = Replace(strSQL1, "{usuario}", Sesion.idUsuario)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL1, conec)
            strUsuario = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    strDatosHTML = "<tr> <td colspan='4'  style='border-right: solid black 1px;border-left:solid black 1px;background-color: #1976D2; color: white;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  FOLLOWERS " & vbTab & "</td> </tr>"
                    For j = 0 To dgNotificacion.RowCount - 1
                        strDatosHTML &= "<tr> <td  colspan='4' style='border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;   width: 3.5cm;text-align: left'>"
                        strDatosHTML &= dgNotificacion.Rows(j).Cells("colPuesto").Value & vbCrLf
                        strDatosHTML &= dgNotificacion.Rows(j).Cells("colObservacion").Value & vbCrLf & "</td> </tr>"
                    Next
                    strDatosHTML &= "<tr> <td colspan='4'  style='border-right: solid black 1px;border-left:solid black 1px;background-color: #1976D2; color: white;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  COMMENTS " & vbTab & "</td> </tr>"
                    strDatosHTML &= "<tr> <td  colspan='4' style='border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;   width: 3.5cm;text-align: left'> "
                    strDatosHTML &= strTexto & vbCrLf & "</td> </tr>"
                    strDatosHTML = Replace(strDatosHTML, vbCrLf, "<br>")
                    strDatosHTML = Replace(strDatosHTML, "'", Chr(34))
                    'For i As Integer = 0 To dgNotificacion.RowCount - 1
                    strEncabezadoHTML = " <html> <BODY> <table cellspacing=0 > <tr> <td colspan='4'; style=' border:solid White 0px; background-color: #FFFFFF; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 10pt;width: 3.5cm;text-align: left;border-bottom:solid black 1px; border-right: solid black 1px;border-left: solid black 1px;border-top:solid black 1px;font-weight:bold;'> CERTIFICATIONS " & " " & " <br><br> </td> </tr> <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color: #DF7401; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 7cm;text-align: left'>  GENERADO EL: '" & Actual & "' </td> </tr>  "
                    strEncabezadoHTML = Replace(strEncabezadoHTML, "'", Chr(34))
                    ' correo.IDCORREO = 0
                    ' correo.DESTINATARIO = dgNotificacion.Rows(i).Cells("colCorreo").Value
                    ' correo.ASUNTO = "Project #  " & celdaCodigo.Text & " " & celdaName.Text
                    ' correo.CONTENIDO = strTemporal & vbCrLf & strTexto & " </table> </body> </html>"
                    ' correo.CONEXION = strConexion2
                    ' If correo.PINSERT = False Then
                    ' MsgBox("Could not Save" & correo.MERROR.ToString, MsgBoxStyle.Information, "Aviso")
                    '   End If
                    'Next
                    'logEnvio = True
                    strSQL = sqlNotificacion(celdaNumero.Text)
                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader()
                    If REA.HasRows Then
                        Do While REA.Read
                            strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & REA.GetString("Correo") & "','Certifications # " & celdaNumero.Text & "','" & strEncabezadoHTML & vbCrLf & strDatosHTML & " </table> </body> </html>',0); ")
                        Loop
                        COM = Nothing
                    End If
                    'MyCnn.CONECTAR = strConexion2
                    conec = New MySqlConnection(strConexion2)
                    conec.Open()
                    COM2 = New MySqlCommand(strInsert, conec)
                    COM2.ExecuteNonQuery()
                    COM2.Dispose()
                    System.GC.Collect()
                    logEnvio = True
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                Else
                    MsgBox("NO HAVE PERMISSIONS")
                End If
            Else
                strDatosHTML = "<tr> <td colspan='4'  style='border-right: solid black 1px;border-left:solid black 1px;background-color: #1976D2; color: white;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  FOLLOWERS " & vbTab & "</td> </tr>"
                For j = 0 To dgNotificacion.RowCount - 1
                    strDatosHTML &= "<tr> <td  colspan='4' style='border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;   width: 3.5cm;text-align: left'>"
                    strDatosHTML &= dgNotificacion.Rows(j).Cells("colPuesto").Value & vbCrLf
                    strDatosHTML &= dgNotificacion.Rows(j).Cells("colObservacion").Value & vbCrLf & "</td> </tr>"
                Next
                strDatosHTML &= "<tr> <td colspan='4'  style='border-right: solid black 1px;border-left:solid black 1px;background-color: #1976D2; color: white;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  COMMENTS " & vbTab & "</td> </tr>"
                strDatosHTML &= "<tr> <td  colspan='4' style='border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;   width: 3.5cm;text-align: left'> "
                strDatosHTML &= strTexto & vbCrLf & "</td> </tr>"
                strDatosHTML = Replace(strDatosHTML, vbCrLf, "<br>")
                strDatosHTML = Replace(strDatosHTML, "'", Chr(34))
                'For i As Integer = 0 To dgNotificacion.RowCount - 1
                strEncabezadoHTML = " <html> <BODY> <table cellspacing=0 > <tr> <td colspan='4'; style=' border:solid White 0px; background-color: #FFFFFF; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 10pt;width: 3.5cm;text-align: left;border-bottom:solid black 1px; border-right: solid black 1px;border-left: solid black 1px;border-top:solid black 1px;font-weight:bold;'> CERTIFICATIONS " & " " & " <br><br> </td> </tr> <tr> <td style='border-left:solid black 1px;border-right: solid black 1px;background-color: #DF7401; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 7cm;text-align: left'>  GENERADO EL: '" & Actual & "' </td> </tr>  "
                strEncabezadoHTML = Replace(strEncabezadoHTML, "'", Chr(34))
                'For i As Integer = 0 To dgNotificacion.RowCount - 1
                '    correo.IDCORREO = 0
                '    correo.DESTINATARIO = dgNotificacion.Rows(i).Cells("colCorreo").Value
                '    correo.ASUNTO = "Project # " & celdaCodigo.Text & "  " & celdaName.Text
                '    correo.CONTENIDO = strTemporal & vbCrLf & strTexto & "</table> </body> </html> "

                '    correo.CONEXION = strConexion2

                '    If correo.PINSERT = False Then
                '        MsgBox("Could not Save" & correo.MERROR.ToString, MsgBoxStyle.Information, "Aviso")
                '    End If
                'Next
                'logEnvio = True
                strSQL = sqlNotificacion(celdaNumero.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader()
                If REA.HasRows Then
                    Do While REA.Read
                        strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & REA.GetString("Correo") & "','Certifications # " & celdaNumero.Text & "','" & strEncabezadoHTML & vbCrLf & strDatosHTML & " </table> </body> </html>',0); ")
                    Loop
                    COM = Nothing
                End If
                MyCnn.CONECTAR = strConexion2
                'conec = New MySqlConnection(strConexion2)
                COM3 = New MySqlCommand(strInsert, CON)
                COM3.ExecuteNonQuery()
                COM3.Dispose()
                System.GC.Collect()
                logEnvio = True
                System.GC.Collect()
            End If
        Catch ex As Exception
            If MsgBox("Error sending email. Please check your internet connection.Press yes to try again or no for cancel the process.", vbQuestion + +vbYesNo + vbDefaultButton2) = vbYes Then
                'SI
                EnvioProyecto()

            Else
                'NO
                logEnvio = True
            End If
        End Try
        strTexto = STR_VACIO
        Return logEnvio
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer) As Boolean
        Dim logVerdadero As Boolean = False
        Dim DTL As New clsDcmtos_DTL
        DTL.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.RowCount - 1
                DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = 862
                DTL.DDOC_DOC_ANO = celdaAño.Text
                DTL.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colidMedida").Value
                DTL.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colProducto").Value
                DTL.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                DTL.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colLote").Value
                DTL.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colPedido").Value
                DTL.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                DTL.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colBulto").Value
                DTL.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colPesoBruto").Value
                DTL.DDOC_PRD_FOB = dgDetalle.Rows(i).Cells("colPesoNeto").Value
                DTL.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReferencia").Value
                DTL.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colTotalC").Value
                If dgDetalle.Rows(i).Cells("colEstado").Value = 0 Then
                    DTL.DDOC_DOC_LIN = NuevaLinea(Codigo)
                    DTL.DDOC_DOC_NUM = Codigo
                    If DTL.Guardar = False Then
                        MsgBox(DTL.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstado").Value = 1 Then
                    DTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                    DTL.DDOC_DOC_NUM = celdaNumero.Text
                    If DTL.Actualizar = False Then
                        MsgBox(DTL.MERROR.ToString & " Could Not Modify this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerdadero = True
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstado").Value = 2 Then
                    If Not Me.Tag = "Nuevo" Then
                        BorrarDetalle(Codigo)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Function GuardarDcmtosPro(ByVal Codigo As Integer, ByVal Anio As Integer) As Boolean
        Dim logGuardar As Boolean
        Dim clsDTLPro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                'Catalogo 395
                clsDTLPro.PDOC_SIS_EMP = Sesion.IdEmpresa
                clsDTLPro.PDOC_PAR_CAT = 36
                clsDTLPro.PDOC_PAR_ANO = dgDetalle.Rows(i).Cells("colAnio").Value
                clsDTLPro.PDOC_PAR_NUM = dgDetalle.Rows(i).Cells("colNum").Value
                clsDTLPro.PDOC_PAR_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                'Catalogo 894
                clsDTLPro.PDOC_CHI_CAT = 862
                clsDTLPro.PDOC_CHI_ANO = Anio
                clsDTLPro.PDOC_CHI_NUM = Codigo
                If logInsertar = True Then
                    If dgDetalle.Rows(i).Cells("colEstado").Value = 0 Then
                        clsDTLPro.PDOC_CHI_LIN = NuevoDescargo(Codigo)
                        If clsDTLPro.Guardar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not Save this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If

                If logEditar = True Then
                    If dgDetalle.Rows(i).Cells("colEstado").Value = 1 Then
                        clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                        If clsDTLPro.Actualizar = False Then
                            MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                            Return False
                            logGuardar = False
                            Exit Function
                        Else
                            logGuardar = True
                        End If
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstado").Value = 2 Then
                    clsDTLPro.PDOC_CHI_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                    If clsDTLPro.Borrar = False Then
                        MsgBox(clsDTLPro.MERROR.ToString() & " Could Not update this document", MsgBoxStyle.Critical)
                        Return False
                        logGuardar = False
                        Exit Function
                    Else
                        logGuardar = True
                    End If
                End If
                ' If checkActive.Checked = False Then
                'checkActive.Enabled = False
                'If clsDTLPro.Borrar = False Then
                'MsgBox(clsDTLPro.MERROR.ToString() & " Could Not delete this document", MsgBoxStyle.Critical)
                '     Return False
                '      logGuardar = False
                '       Exit Function
                '    End If
                ' End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    Public Function BorrarDetalle(ByVal Codigo As Integer) As Boolean
        Dim LogAceptado As Boolean = False
        Dim DTL As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.RowCount - 1
                If Me.Tag = "Nuevo" Then
                Else

                    DTL.CONEXION = strConexion
                    DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                    DTL.DDOC_DOC_CAT = 862
                    DTL.DDOC_DOC_ANO = celdaAño.Text
                    If dgDetalle.Rows(i).Cells("colEstado").Value = 2 Then
                        DTL.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLin").Value
                        DTL.DDOC_DOC_NUM = Codigo
                        If DTL.Borrar = False Then
                            MsgBox(DTL.MERROR.ToString & " Could Not Delete this document", MsgBoxStyle.Critical)
                            Return False
                            Exit Function
                        Else
                            LogAceptado = True
                        End If
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogAceptado
    End Function
    Private Function sqlNotificacion(ByVal intProyecto As Integer) As String
        Dim strSQL As String
        strSQL = " SELECT nof.idNotificacion Notificacion, pe.per_codigo Codigo, IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pue.pue_descripcion),'')Puesto, nof.idUsuario,nof.Observaciones,pe.per_correo Correo"
        strSQL &= "  FROM Notificaciones nof  "
        strSQL &= "  LEFT JOIN Personal pe ON  pe.per_sisemp = nof.Empresa  AND pe.per_usuario = nof.idUsuario "
        strSQL &= " LEFT JOIN Puestos pue ON pue.pue_sisemp = pe.per_sisemp AND pue.pue_codigo = pe.per_puesto"
        strSQL &= " where nof.Empresa= {empresa}  and nof.idProyecto = {proyecto} AND nof.idTarea is null "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        strSQL = Replace(strSQL, "{proyecto}", intProyecto)
        '        strSQL = Replace(strSQL, "{codigo}", Sesion.idUsuario)
        Return strSQL
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaidCliente.Text = NO_FILA Then
            MsgBox("BLANK CLIENT ")
            Comprobar = False
            Exit Function

        End If
        'If celdaIdSolicitado.Text = vbNullString Then
        '    MsgBox("BLANK REQUESTED")
        '    Comprobar = False
        '    Exit Function
        'End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim LogVerdadero As Boolean = True
        If dgDetalle.Rows.Count = 0 Then
            MsgBox("Fill all fields", MsgBoxStyle.Critical)
            LogVerdadero = False
        Else
            LogVerdadero = True
        End If
        Return LogVerdadero
    End Function
    Private Function SQLEncabezado(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String
        strSQL = " SELECT HDR.HDoc_Doc_Num Numero,HDR.HDoc_Doc_Ano Anio ,HDR.HDoc_Doc_Fec Fecha,HDR.HDoc_Emp_Cod idCliente,HDR.HDoc_Emp_Nom Cliente, HDR.HDoc_Emp_Dir Direccion,HDR.HDoc_Doc_Mon idMoneda,c.cat_clave Moneda,HDR.HDoc_Doc_TC Tasa , HDR.HDoc_Doc_Status Estado "
        strSQL &= " FROM Dcmtos_HDR HDR "
        strSQL &= " LEFT JOIN Catalogos c ON c.cat_num = HDR.HDoc_Doc_Mon AND c.cat_clase='Monedas' "
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} AND HDR.HDoc_Doc_Cat = {catalogo} AND HDR.HDoc_Doc_Ano = {anio} AND HDR.HDoc_Doc_Num = {codigo} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 862)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Public Sub Seleccionar(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLEncabezado(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                celdaAño.Text = REA.GetInt32("Anio")
                celdaNumero.Text = REA.GetInt32("Numero")
                dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                celdaCliente.Text = REA.GetString("Cliente")
                celdaidCliente.Text = REA.GetString("idCliente")
                celdaDireccion.Text = REA.GetString("Direccion")
                celdaidMoneda.Text = REA.GetInt32("idMoneda")
                celdaMoneda.Text = REA.GetString("Moneda")
                celdaTasa.Text = REA.GetDouble("Tasa")
                If REA.GetInt32("Estado") = 0 Then
                    checkActive.Checked = False
                    DeshabilitarFormas()
                Else
                    checkActive.Checked = True
                    HabilitarFormas()
                End If
                botonCliente.Enabled = False
            Loop
        End If
        CargarDetalle(Codigo, Año)
        CargarNotificacion(Codigo)
    End Sub
    Private Function SQLDetalle(ByVal Codigo As Integer, ByVal Año As Integer) As String
        Dim strSQL As String = STR_VACIO

        strSQL = "  SELECT h6.HDoc_Doc_Num Numero,h6.HDoc_DR1_Dbl num,d.DDoc_Doc_Lin Linea,IFNULL(d.DDoc_RF1_Cod,'') Lote,IFNULL(d.DDoc_RF2_Cod,'') PO,d.DDoc_Prd_PNr Producto, d.DDoc_Prd_Des Descripcion, d.DDoc_Prd_QTY Cantidad,IFNULL(d.DDoc_RF2_Dbl,0) Brutos,IFNULL(d.DDoc_Prd_Fob,0) Netos,"
        strSQL &= "     d.DDoc_RF1_Txt Referencia,d.DDoc_Prd_NET Total,p.PDoc_Par_Cat Catalogo,p.PDoc_Par_Ano Anio, p.PDoc_Par_Lin lin,p.PDoc_Par_Num numero,IFNULL(b.cat_num,-1) idMedida,IFNULL(b.cat_clave,'') Medida,IFNULL(d.DDoc_RF1_Num,0) Bulto"
        strSQL &= "         FROM Dcmtos_DTL d"
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND p.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND p.PDoc_Chi_Num = d.DDoc_Doc_Num AND p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
        strSQL &= "                 LEFT JOIN Dcmtos_HDR h6 ON h6.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND h6.HDoc_Doc_Cat = p.PDoc_Par_Cat AND h6.HDoc_Doc_Ano = p.PDoc_Par_Ano AND h6.HDoc_Doc_Num = p.PDoc_Par_Num "
        strSQL &= "               LEFT JOIN Catalogos b ON b.cat_num = d.DDoc_Prd_UM AND b.cat_clase='Medidas'"
        strSQL &= "           WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {codigo}"
        strSQL &= "    ORDER BY d.DDoc_Doc_Cat , d.DDoc_Doc_Ano,d.DDoc_Doc_Num ,d.DDoc_Doc_Lin "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 862)
        strSQL = Replace(strSQL, "{anio}", Año)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        Return strSQL
    End Function
    Private Sub CargarDetalle(ByVal Codigo As Integer, ByVal Año As Integer)
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim dblTotal As Double = INT_CERO
        Dim strLinea As String = STR_VACIO
        strSQL = SQLDetalle(Codigo, Año)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgDetalle.Rows.Clear()
            Do While REA.Read
                If Sesion.IdEmpresa = 16 Or Sesion.IdEmpresa = 14 Then
                    strLinea = REA.GetInt32("num") & "|" 'Numero
                Else
                    strLinea = REA.GetInt32("Numero") & "|" 'Numero
                End If
                strLinea &= REA.GetInt32("Linea") & "|" 'Linea
                strLinea &= REA.GetString("Lote") & "|" 'Lote
                strLinea &= REA.GetString("PO") & "|" 'PO
                strLinea &= REA.GetString("Producto") & "|" ' Producto
                strLinea &= REA.GetString("Referencia") & "|" ' Referencia
                strLinea &= REA.GetString("Descripcion") & "|" ' Descripcion
                strLinea &= REA.GetInt32("idMedida") & "|" 'id Medida
                strLinea &= REA.GetString("Medida") & "|" 'Medida
                strLinea &= REA.GetDouble("Cantidad") & "|" ' Cantidad
                strLinea &= REA.GetDouble("Brutos") & "|" 'Peso Bruto
                strLinea &= REA.GetDouble("Netos") & "|" 'Peso Neto
                strLinea &= REA.GetInt32("Bulto") & "|" 'Bulto
                strLinea &= REA.GetDouble("Total").ToString("###0.00") & "|" ' id
                strLinea &= REA.GetInt32("Catalogo") & "|" '  LINE
                strLinea &= REA.GetInt32("Anio") & "|" ' Año
                strLinea &= REA.GetInt32("numero") & "|" ' Año
                strLinea &= REA.GetInt32("lin") & "|" ' Año
                strLinea &= "1" ' Status
                dblTotal = dblTotal + REA.GetDouble("Total")
                cFunciones.AgregarFila(dgDetalle, strLinea)
            Loop
        End If
        celdaCertificacion.Text = dblTotal.ToString("###0.00")
        '   CalcularTotales()
    End Sub
    Private Sub CargarNotificacion(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlNotificacion(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If dgNotificacion.Rows.Count > 0 Then
                        Dim Validar As Boolean
                        For i As Integer = 0 To dgNotificacion.RowCount - 1
                            If dgNotificacion.Rows(i).Cells("colCodigo").Value = REA.GetInt32("Codigo") Then
                                Validar = True
                            End If
                        Next
                        If Not Validar Then
                            strFila = STR_VACIO
                            strFila = REA.GetInt32("Notificacion") & "|" 'ID Notificacion
                            strFila &= REA.GetString("Puesto") & "|" 'PUESTO USUARIO   
                            strFila &= REA.GetString("idUsuario") & "|" ' USUARIO
                            strFila &= REA.GetInt32("Codigo") & "|" 'CODIGO USUARIO
                            strFila &= REA.GetString("Observaciones") & "|" 'OBSERVACION
                            strFila &= REA.GetString("Correo") & "|" 'CORREO
                            strFila &= "1" ' Acciones
                            cFunciones.AgregarFila(dgNotificacion, strFila)
                        Else
                            '    MsgBox("Repeat user")
                        End If
                    Else
                        strFila = STR_VACIO
                        strFila = REA.GetInt32("Notificacion") & "|" 'ID Notificacion
                        strFila &= REA.GetString("Puesto") & "|" 'PUESTO USUARIO   
                        strFila &= REA.GetString("idUsuario") & "|" ' USUARIO
                        strFila &= REA.GetInt32("Codigo") & "|" 'CODIGO USUARIO
                        strFila &= REA.GetString("Observaciones") & "|" 'OBSERVACION
                        strFila &= REA.GetString("Correo") & "|" 'CORREO
                        strFila &= "1" ' Acciones
                        cFunciones.AgregarFila(dgNotificacion, strFila)
                    End If
                Loop
            End If
            'CON2.Close()
            'CON2.Dispose()
            'CON2 = Nothing
            REA.Close()
            REA = Nothing
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub DeshabilitarFormas()
        celdaCliente.Enabled = False
        celdaDireccion.Enabled = False
        dgDetalle.ReadOnly = True
        dgNotificacion.ReadOnly = True
        ' Encabezado1.botonGuardar.Enabled = False
        '   Encabezado1.botonNuevo.Enabled = False
        botonAgregar.Enabled = False
        botonEliminar.Enabled = False
        dtpFecha.Enabled = False
        checkActive.Enabled = False
        botonMoneda.Enabled = False
        PanelControles.Enabled = False
        PanelNotificacion.Enabled = False
        BotonEnviar.Enabled = False
    End Sub
    Public Sub HabilitarFormas()
        celdaCliente.Enabled = True
        celdaDireccion.Enabled = True
        dgDetalle.ReadOnly = False
        dgNotificacion.ReadOnly = False
        ' Encabezado1.botonGuardar.Enabled = False
        '       Encabezado1.botonNuevo.Enabled = True
        botonAgregar.Enabled = True
        botonEliminar.Enabled = True
        dtpFecha.Enabled = True
        checkActive.Enabled = True
        botonMoneda.Enabled = True
        botonCliente.Enabled = True
        PanelControles.Enabled = True
        PanelNotificacion.Enabled = True
    End Sub
    Private Sub BorrarCertificacion(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO

        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = CATALOGO
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarDetalleCertificacion(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa}  AND DDoc_Doc_Cat = {cata} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarProCertificacion(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = {cata} AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub BorrarNotificadores(ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "Empresa = {empresa} AND idProyecto = {numero}  AND idTarea IS NULL "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim noti As New Tablas.TNOTIFICACIONES
            noti.CONEXION = strConexion
            noti.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
#Region "Eventos"
    Private Sub frmCertificacion_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFechaInicial.Value = Today.AddMonths(NO_FILA)
        dtpFechaFinal.Value = Today
        Accesos()
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            HabilitarFormas()
            BotonEnviar.Enabled = False
            MostrarLista(False, logInsertar)
            FilaNotificacion()
        Else
            MsgBox("You do not have permission to create a new document", vbCritical, "Notice")
        End If
    End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
    End Sub
    Private Sub frmCertificacion_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO

        strCondicion = "c.cli_sisemp  = {empresa} AND c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Client"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the client to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2

                celdaMoneda.Text = "US$"
                celdaidMoneda.Text = 178
                celdaTasa.Text = cFunciones.QueryTasa
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double
        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            If Cambio > 1 Then
                celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
            Else
                celdaTasa.Text = Cambio
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frmS As New frmSeleccionar
        Dim strfila As String = STR_VACIO
        Dim intNumero As Integer = NO_FILA
        Dim strCondicion As String = STR_VACIO
        Dim intContador = INT_CERO
        Dim dblTotal As Double
        Try
            If ValidarCampos() = True Then
                frmS.Titulo = "Invoice "
                strCondicion = "  {campo} , h.HDoc_Doc_Fec  Date , h.HDoc_DR1_Num  Reference , h.HDoc_Doc_Ano Year,h.HDoc_Doc_Num Number  "
                If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 14) Then
                    strCondicion = Replace(strCondicion, "{campo}", "h.HDoc_DR1_Dbl Num")
                Else
                    strCondicion = Replace(strCondicion, "{campo}", "h.HDoc_Doc_Num Num")
                End If
                frmS.Campos = strCondicion
                frmS.Tabla = " Dcmtos_HDR h  LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano  AND d.DDoc_Doc_Num = h.HDoc_Doc_Num  LEFT JOIN Inventarios i ON i.inv_sisemp = d.DDoc_Sis_Emp AND i.inv_numero = d.DDoc_Prd_Cod  LEFT JOIN Articulos a ON a.art_sisemp = i.inv_sisemp AND a.art_codigo = i.inv_artcodigo "
                frmS.FiltroText = "Enter the Invoice Number"
                frmS.Filtro = "h.HDoc_Doc_Num"
                frmS.Limite = 50
                frmS.Condicion = "  h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 36  AND a.art_venta IN(1,2) AND h.HDoc_Doc_Status = 1  AND h.HDoc_Emp_Cod = " & celdaidCliente.Text & "  GROUP BY h.HDoc_Sis_Emp,h.HDoc_Doc_Cat,h.HDoc_Doc_Ano, h.HDoc_Doc_Num "
                frmS.ShowDialog(Me)
                If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    AgregarDetalle(frmS.ListaClientes.SelectedCells(3).Value, frmS.ListaClientes.SelectedCells(4).Value)
                End If
            End If
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonAñadir_Click(sender As Object, e As EventArgs) Handles botonAñadir.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = "User"
            frm.Campos = " pe.per_codigo Code,IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Job"
            frm.Tabla = " Personal pe LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto "
            frm.FiltroText = " Enter the User Filtered"
            frm.Filtro = " pe.per_nombre1 "
            frm.Condicion = " pe.per_sisemp = " & Sesion.IdEmpresa & " AND per_estado = 1 "
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidUsuario.Text = frm.LLave
                celdaUsuario.Text = frm.Dato
                ' strTexto = "ADD " & celdaUsuario.Text
                strSql = " SELECT pe.per_codigo Codigo,IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Puesto,pe.per_usuario Usuario , pe.per_correo Correo"
                strSql &= "  FROM Personal pe "
                strSql &= "  LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto"
                strSql &= " where pe.per_sisemp= {empresa} and pe.per_codigo = {codigo}"
                strSql = Replace(strSql, "{empresa}", Sesion.IdEmpresa)
                strSql = Replace(strSql, "{codigo}", celdaidUsuario.Text)
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSql, CON)
                REA = COM.ExecuteReader
                Do While REA.Read
                    strLinea = STR_VACIO
                    strUsuario = celdaidUsuario.Text
                    If dgNotificacion.Rows.Count > 0 Then
                        Dim Validar As Boolean
                        For i As Integer = 0 To dgNotificacion.RowCount - 1
                            If dgNotificacion.Rows(i).Cells("colCodigo").Value = strUsuario Then
                                Validar = True
                            End If
                        Next
                        If Not Validar Then
                            strUsuario = REA.GetString("Codigo")
                            strLinea = "0|" 'ID Notificacion
                            strLinea &= REA.GetString("Puesto") & "|" 'PUESTO USUARIO   
                            strLinea &= REA.GetString("Usuario") & "|" ' USUARIO
                            strLinea &= REA.GetInt32("Codigo") & "|" ' CODIGO USUARIO
                            strLinea &= "|" 'OBSERVACION
                            strLinea &= REA.GetString("Correo") & "|" 'CORREO
                            strLinea &= "0" ' Acciones
                            cFunciones.AgregarFila(dgNotificacion, strLinea)
                        Else
                            MsgBox("Repeat user")
                        End If
                    Else
                        strUsuario = REA.GetString("Codigo")
                        strLinea = "0|" 'ID Notificacion
                        strLinea &= REA.GetString("Puesto") & "|" 'PUESTO USUARIO   
                        strLinea &= REA.GetString("Usuario") & "|" ' USUARIO
                        strLinea &= REA.GetInt32("Codigo") & "|" ' CODIGO USUARIO
                        strLinea &= "|" 'OBSERVACION
                        strLinea &= REA.GetString("Correo") & "|" 'CORREO
                        strLinea &= "0" ' Acciones
                        cFunciones.AgregarFila(dgNotificacion, strLinea)
                    End If
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonDelete_Click(sender As Object, e As EventArgs) Handles botonDelete.Click
        Try
            Dim Count As Integer
            If dgNotificacion.SelectedRows Is Nothing Then Exit Sub
            If dgNotificacion.Rows.Count > 0 Then
                Count = dgNotificacion.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    ' strTexto = "Remove " & CStr(dgNotificacion.SelectedCells(1).Value) & vbCrLf
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgNotificacion.SelectedCells(0).Value) & ", " &
               CStr(dgNotificacion.SelectedCells(3).Value) & " " &
                   CStr(dgNotificacion.SelectedCells(4).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgNotificacion.SelectedCells(6).Value = 0 Or dgNotificacion.SelectedCells(6).Value = 1 Then
                            dgNotificacion.SelectedCells(6).Value = 2
                            If dgNotificacion.SelectedCells(6).Value = 2 Then
                                dgNotificacion.CurrentRow.Visible = False
                            End If
                        ElseIf dgNotificacion.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgNotificacion.Rows.RemoveAt(dgNotificacion.RowCount - 1)
                        End If
                    End If
                Next
            Else
                Exit Sub
            End If
            dgNotificacion.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        Try
            Dim Count As Integer
            If dgDetalle.SelectedRows Is Nothing Then Exit Sub
            If dgDetalle.Rows.Count > 1 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CInt(dgDetalle.SelectedCells(0).Value) & ", " &
               CStr(dgDetalle.SelectedCells(1).Value) & " " &
                CStr(dgDetalle.SelectedCells(2).Value) & " " &
                   CStr(dgDetalle.SelectedCells(3).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgDetalle.SelectedCells(18).Value = 0 Or dgDetalle.SelectedCells(18).Value = 1 Then
                            dgDetalle.SelectedCells(18).Value = 2
                            If dgDetalle.SelectedCells(18).Value = 2 Then
                                dgDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                MsgBox("you can not delete the last row")
                Exit Sub
            End If
            dgDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        If dgDetalle.Rows.Count = 0 Then Exit Sub
        Try
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 6
                    CalcularTotales()
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim PD As New frmPedirComentarios
        Try
            If ComprobarDatos() Then
                If ComprobarFila() Then
                    PD.ShowDialog(Me)
                    strTexto = PD.celdaInfo.Text
                    PD.Iniciar(strTexto)
                    If Guardar() = True Then
                        MsgBox("the document has been saved")
                        MostrarLista(True)
                    End If
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim Codigo As Integer = NO_FILA
        Dim Año As Integer = NO_FILA
        If dgLista.Rows.Count = 0 Then Exit Sub
        Try
            Codigo = dgLista.SelectedCells(0).Value
            Año = dgLista.SelectedCells(1).Value
            Limpiar()
            MostrarLista(False)
            BloquearBotones(False)
            Me.Tag = "mod"
            BotonEnviar.Enabled = True
            Seleccionar(Codigo, Año)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(862, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value, 862, codigo:=celdaidCliente.Text)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim NumFact As Integer = 0
            Dim AnioFact As Integer = 0
            If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                NumFact = celdaNumero.Text
                AnioFact = celdaAño.Text
                BorrarCertificacion(NumFact, AnioFact)
                BorrarDetalleCertificacion(NumFact, AnioFact)
                BorrarProCertificacion(NumFact, AnioFact)
                BorrarNotificadores(NumFact)
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, celdaidCliente.Text, 862, celdaAño.Text, celdaNumero.Text)
                MostrarLista()
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub
    Private Sub BotonEnviar_Click(sender As Object, e As EventArgs) Handles BotonEnviar.Click
        Dim PD As New frmPedirComentarios
        PD.ShowDialog(Me)
        If PD.DialogResult = System.Windows.Forms.DialogResult.OK Then
            strTexto = PD.celdaInfo.Text
            PD.Iniciar(strTexto)
            If GuardarNotificacion(celdaNumero.Text) = True Then
                If EnvioProyecto() Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, celdaidCliente.Text, 862, celdaAño.Text, celdaNumero.Text, PD.celdaInfo.Text)
                    MsgBox("The certification was sent successfully", vbInformation, "SEND")
                    MostrarLista(True)
                End If
            End If
        End If
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarListaPrincipal()
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub
#End Region
End Class