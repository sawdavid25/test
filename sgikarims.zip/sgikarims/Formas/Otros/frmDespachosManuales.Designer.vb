﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDespachosManuales
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Accept = New System.Windows.Forms.Button()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.panelLista.Location = New System.Drawing.Point(25, 22)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(518, 156)
        Me.panelLista.TabIndex = 0
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.Info
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(25, 184)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(518, 85)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = "Additional Information"
        '
        'Accept
        '
        Me.Accept.Location = New System.Drawing.Point(387, 283)
        Me.Accept.Name = "Accept"
        Me.Accept.Size = New System.Drawing.Size(75, 23)
        Me.Accept.TabIndex = 2
        Me.Accept.Text = "Accept"
        Me.Accept.UseVisualStyleBackColor = True
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(468, 283)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.botonCancelar.TabIndex = 3
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'frmDespachosManuales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(575, 315)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.Accept)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.panelLista)
        Me.Name = "frmDespachosManuales"
        Me.Text = "frmDespachosManuales"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Accept As System.Windows.Forms.Button
    Friend WithEvents botonCancelar As System.Windows.Forms.Button
End Class
