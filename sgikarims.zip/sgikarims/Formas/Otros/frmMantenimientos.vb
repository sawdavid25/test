﻿Public Class frmMantenimientos

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub limpiarCampos()
        celdaNumero.Text = NO_FILA
        dtpFecha.Value = Today
        celdaIdTipo.Clear()
        celdaTipo.Clear()
        celdaIdEquipo.Clear()
        celdaEquipo.Clear()
        dgDetalle.Rows.Clear()
        botonEquipo.Enabled = True
        botonTipo.Enabled = True
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDetalle.Dock = DockStyle.None
            panelDetalle.Visible = False
            BarraTitulo1.CambiarTitulo("Mantenimientos")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDetalle.Dock = DockStyle.Fill
            panelDetalle.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Mantenimientos")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.Fecha,h.Numero,h.Descripcion,i.Codigo_Equipo
                        FROM Mantenimiento_HDR h
                        LEFT JOIN InventarioIT i ON i.id_Empresa = h.idEmpresa AND i.id_Inventario = h.idEquipo
                        WHERE h.idEmpresa = {emp} {fechas} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        If checkFechas.Checked = True Then
            strSQL = strSQL.Replace("{fechas}", "AND  h.Fecha BETWEEN '{inicio}' AND '{fin}'")
            strSQL = strSQL.Replace("{inicio}", dtpInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{fin}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        Else
            strSQL = strSQL.Replace("{fechas}", "")
        End If


        Return strSQL
    End Function

    Private Function SqlCargarEncabezado(ByVal Num As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.Numero,h.Fecha,h.idTipo idFlujo,h.Descripcion,h.idEquipo,i.Codigo_Equipo
                        FROM Mantenimiento_HDR h
                        LEFT JOIN InventarioIT i ON i.id_Empresa = h.idEmpresa AND i.id_Inventario = h.idEquipo
                        WHERE h.idEmpresa = {emp} AND h.Numero = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{num}", Num)

        Return strSQL
    End Function

    Private Function SqlCargarDetalle(ByVal num As Integer)
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT d.idTarea,d.Descripcion,d.Comentario, IFNULL(d.DescripcionTarea,'') DescripcionTarea, IFNULL(d.Correccion,'') Correccion
                        FROM Mantenimiento_HDR h
                        LEFT JOIN Mantenimiento_DTL d ON d.idEmpresa = h.idEmpresa AND d.Numero = h.Numero
                        WHERE h.idEmpresa = {emp} AND h.Numero = {num} "

        strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
        strSQL = strSQL.Replace("{num}", num)

        Return strSQL
    End Function

    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read

                    strFila = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("Codigo_Equipo")

                    cFunciones.AgregarFila(dgLista, strFila)

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function NuevoCodigo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " SELECT IFNULL(MAX(m.Numero),0)  + 1 Codigo "
        strSQL &= " FROM Mantenimiento_HDR m"
        strSQL &= "     WHERE m.idEmpresa = {empresa}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function NuevaLinea(ByVal Codigo As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " SELECT IFNULL(MAX(c.id_Linea),0) + 1  Codigo  "
        strSQL &= " FROM Mantenimiento_DTL m   "
        strSQL &= " WHERE m.idEmpresa  = {empresa} AND m.Numero = {codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", Codigo)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva
    End Function
    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean = True
        If celdaIdTipo.Text = NO_FILA Then
            MsgBox("BLANK Type")
            celdaIdEquipo.Focus()
            Comprobar = False
        End If
        If celdaIdEquipo.Text = NO_FILA Then
            MsgBox("BLANK Inventory")
        End If
        'If strMsg = vbNullString Then
        '    Comprobar = True
        'End If
        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim Comprobar As Boolean = True
        Try
            'If dgDetalleTarea.Rows.Count = 0 Then
            '    Comprobar = False
            '    MsgBox("Blank Rows Project ")
            'End If
            For i As Integer = 0 To dgDetalle.RowCount - 1
                If CStr(dgDetalle.Rows(i).Cells("colComentario").Value) = vbNullString Then
                    MsgBox("Blank Comment")
                    Comprobar = False
                    Exit Function
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Comprobar
    End Function
    Private Function GuardarMantenimiento() As Boolean
        Dim logValidar As Boolean = True
        Dim cMantenimiento As New Tablas.TMANTENIMIENTO_HDR
        Dim intCodigo As Integer = NO_FILA
        Try
            cMantenimiento.CONEXION = strConexion
            cMantenimiento.IDEMPRESA = Sesion.IdEmpresa
            cMantenimiento.IDEQUIPO = celdaIdEquipo.Text
            cMantenimiento.IDTIPO = celdaIdTipo.Text
            cMantenimiento.DESCRIPCION = celdaTipo.Text
            cMantenimiento.Fecha_NET = dtpFecha.Value
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    intCodigo = NuevoCodigo()
                    cMantenimiento.NUMERO = intCodigo
                    If cMantenimiento.PINSERT = False Then
                        MsgBox(cMantenimiento.MERROR.ToString)
                        Return False
                        Exit Function
                    End If
                    If GuardarDetalle(intCodigo) = True Then
                        logValidar = True
                    Else
                        logValidar = False
                    End If
                    cFunciones.EscribirRegistro("Mantenimiento_HDR", clsFunciones.AccEnum.acAdd, intCodigo, 0, 0, intCodigo, Notas:=celdaEquipo.Text)
                Else
                    MsgBox("You don't have permission to save ")
                    Return False
                    Exit Function
                End If
            Else
                If logEditar = True Then
                    intCodigo = celdaNumero.Text
                    cMantenimiento.NUMERO = intCodigo
                    If cMantenimiento.PUPDATE = False Then
                        MsgBox(cMantenimiento.MERROR.ToString)
                        Return False
                        Exit Function
                    End If
                    If GuardarDetalle(intCodigo) = True Then
                        logValidar = True
                    Else
                        logValidar = False
                    End If
                    cFunciones.EscribirRegistro("Mantenimiento_HDR", clsFunciones.AccEnum.acUpdate, intCodigo, 0, 0, intCodigo, Notas:=celdaEquipo.Text)
                Else
                    MsgBox("You don't have permission to update ")
                    Return False
                    Exit Function
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
    Private Function GuardarDetalle(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cMantenimientosDTL As New Tablas.TMANTENIMIENTO_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                cMantenimientosDTL.IDEMPRESA = Sesion.IdEmpresa
                cMantenimientosDTL.NUMERO = numero
                cMantenimientosDTL.DESCRIPCION = dgDetalle.Rows(i).Cells("colTarea").Value
                cMantenimientosDTL.COMENTARIO = dgDetalle.Rows(i).Cells("colComentario").Value
                cMantenimientosDTL.DESCRIPCIONTAREA = dgDetalle.Rows(i).Cells("colDescripcion").Value
                cMantenimientosDTL.IDTAREA = dgDetalle.Rows(i).Cells("colIdProceso").Value
                cMantenimientosDTL.CORRECCION = dgDetalle.Rows(i).Cells("colCorreccion").Value
                If Me.Tag = "Nuevo" Then
                    cMantenimientosDTL.CONEXION = strConexion
                    If cMantenimientosDTL.PINSERT = False Then
                        logResultado = False
                        MsgBox(cMantenimientosDTL.MERROR.ToString)
                    End If
                Else
                    cMantenimientosDTL.CONEXION = strConexion
                    If cMantenimientosDTL.PUPDATE = False Then
                        logResultado = False
                        MsgBox(cMantenimientosDTL.MERROR.ToString)
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Sub CargarEncabezado(ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SqlCargarEncabezado(intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaNumero.Text = REA.GetInt32("Numero")
                    dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    celdaIdTipo.Text = REA.GetInt32("idFlujo")
                    celdaTipo.Text = REA.GetString("Descripcion")
                    celdaIdEquipo.Text = REA.GetInt32("idEquipo")
                    celdaEquipo.Text = REA.GetString("Codigo_Equipo")
                    botonTipo.Enabled = False
                    botonEquipo.Enabled = False
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub CargarDetalle(ByVal intNum)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SqlCargarDetalle(intNum)
            If celdaIdTipo.Text = 77 Then
                dgDetalle.Columns("colCorreccion").Visible = True
            Else
                dgDetalle.Columns("colCorreccion").Visible = False
            End If
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("idTarea") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= REA.GetString("DescripcionTarea") & "|"
                    strFila &= REA.GetString("Comentario") & "|"
                    strFila &= REA.GetString("Correccion")
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Bprrar InventarioIT
    Public Function BorrarMantenimiento() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Mantenimiento_HDR  WHERE idEmpresa = {empresa}  AND Numero = {codigo}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaNumero.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
    ' Borrar Cobian 
    Public Function BorrarMantenimientoDetalle() As Boolean
        Dim logGuardar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim clsHDR As New clsDcmtos_HDR
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Mantenimiento_DTL  WHERE idEmpresa  = {empresa} AND Numero = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", celdaNumero.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logGuardar = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

#End Region
#Region "Eventos"
    Private Sub frmMantenimientos_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFinal.Value = Today  'DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        MostrarLista()
        Accessos()
    End Sub

    Private Sub botonTipo_Click(sender As Object, e As EventArgs) Handles botonTipo.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try
            frm.Titulo = "Flujos"
            frm.Campos = " idFlujo Flujo ,Nombre Nombre"
            frm.Tabla = " Flujos"
            frm.FiltroText = " Ingrese el nombre del Flujo a filtrar"
            frm.Filtro = " Nombre "
            frm.Condicion = " Empresa = " & Sesion.IdEmpresa & " and Estado = 1 AND idFlujo >76 "
            frm.Ordenamiento = " Nombre "
            frm.TipoOrdenamiento = " ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdTipo.Text = frm.LLave
                celdaTipo.Text = frm.Dato

                strSql = " SELECT d.idFlujoDet id,d.Comentario, p.Nombre 
                                FROM Flujos f
                                LEFT JOIN Flujo_Detalle d ON d.Empresa = f.Empresa AND d.idFlujo = f.idFlujo
                                left join Proceso p on p.Empresa = d.Empresa and p.idProceso = d.idProceso 
                                WHERE f.Empresa = {emp} AND f.idFlujo = {id} "

                strSql = strSql.Replace("{emp}", Sesion.IdEmpresa)
                strSql = strSql.Replace("{id}", celdaIdTipo.Text)

                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSql, CON)
                REA = COM.ExecuteReader

                dgDetalle.Rows.Clear()

                If Not celdaIdTipo.Text = 77 Then
                    dgDetalle.Columns("colCorreccion").Visible = False
                Else
                    dgDetalle.Columns("colCorreccion").Visible = True
                End If

                Do While REA.Read

                    strLinea = REA.GetInt32("id") & "|"
                    strLinea &= REA.GetString("Nombre") & "|"
                    strLinea &= REA.GetString("Comentario")

                    cFunciones.AgregarFila(dgDetalle, strLinea)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonEquipo_Click(sender As Object, e As EventArgs) Handles botonEquipo.Click
        Dim frm As New frmSeleccionar
        Dim strSql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO
        Try

        Catch ex As Exception

        End Try
        frm.Titulo = ""
        frm.Campos = " i.id_Inventario id, i.Codigo_Equipo"
        frm.Tabla = " InventarioIT i"
        frm.FiltroText = " Ingrese el código del equipo"
        frm.Filtro = " i.Codigo_Equipo "
        frm.Condicion = " i.id_Empresa = " & Sesion.IdEmpresa
        frm.Ordenamiento = " i.id_Inventario"
        frm.TipoOrdenamiento = " ASC"

            frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            celdaIdEquipo.Text = frm.LLave
            celdaEquipo.Text = frm.Dato
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intNum As Integer = 0

        limpiarCampos()
        BloquearBotones()
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            intNum = dgLista.SelectedCells(1).Value
            CargarEncabezado(intNum)
            CargarDetalle(intNum)
            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDetalle.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            limpiarCampos()
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Try
            If ComprobarDatos() Then
                If ComprobarFila() Then
                    If GuardarMantenimiento() = True Then
                        MsgBox("save successful")
                        MostrarLista(True)
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(0, 0, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, 0, 0, "Mantenimiento_HDR", dgLista.SelectedCells(1).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                BorrarMantenimiento()
                BorrarMantenimientoDetalle()
                cFunciones.EscribirRegistro("Mantenimiento_HDR", clsFunciones.AccEnum.acDelete, celdaNumero.Text, 0, 0, celdaNumero.Text, Notas:=celdaEquipo.Text)
                MsgBox("Delete Complete")
                MostrarLista()
            End If
        Else
            MsgBox("You don't have permission to delete ")
        End If
    End Sub

    Private Sub dgDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellContentClick

    End Sub
#End Region
End Class