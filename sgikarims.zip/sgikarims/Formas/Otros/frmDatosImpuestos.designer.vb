﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDatosImpuestos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDatosImpuestos))
        Me.etiquetaTitulo = New System.Windows.Forms.Label()
        Me.panelPrincipal = New System.Windows.Forms.Panel()
        Me.botonDescripcion = New System.Windows.Forms.Button()
        Me.celdaTotalOpcional = New System.Windows.Forms.TextBox()
        Me.checkMonto = New System.Windows.Forms.CheckBox()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.celdaCantidad = New System.Windows.Forms.TextBox()
        Me.celdaFactor = New System.Windows.Forms.TextBox()
        Me.celdaDescripcion = New System.Windows.Forms.TextBox()
        Me.etiquetaTotal = New System.Windows.Forms.Label()
        Me.etiquetaCantidad = New System.Windows.Forms.Label()
        Me.etiquetaFactor = New System.Windows.Forms.Label()
        Me.etiquetaDescripcion = New System.Windows.Forms.Label()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.panelPrincipal.SuspendLayout()
        Me.panelBotones.SuspendLayout()
        Me.SuspendLayout()
        '
        'etiquetaTitulo
        '
        Me.etiquetaTitulo.AutoSize = True
        Me.etiquetaTitulo.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.etiquetaTitulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.etiquetaTitulo.Font = New System.Drawing.Font("Consolas", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaTitulo.Location = New System.Drawing.Point(0, 0)
        Me.etiquetaTitulo.Name = "etiquetaTitulo"
        Me.etiquetaTitulo.Size = New System.Drawing.Size(225, 20)
        Me.etiquetaTitulo.TabIndex = 0
        Me.etiquetaTitulo.Text = "Tax on fuel distribution"
        Me.etiquetaTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panelPrincipal
        '
        Me.panelPrincipal.Controls.Add(Me.botonDescripcion)
        Me.panelPrincipal.Controls.Add(Me.celdaTotalOpcional)
        Me.panelPrincipal.Controls.Add(Me.checkMonto)
        Me.panelPrincipal.Controls.Add(Me.celdaTotal)
        Me.panelPrincipal.Controls.Add(Me.celdaCantidad)
        Me.panelPrincipal.Controls.Add(Me.celdaFactor)
        Me.panelPrincipal.Controls.Add(Me.celdaDescripcion)
        Me.panelPrincipal.Controls.Add(Me.etiquetaTotal)
        Me.panelPrincipal.Controls.Add(Me.etiquetaCantidad)
        Me.panelPrincipal.Controls.Add(Me.etiquetaFactor)
        Me.panelPrincipal.Controls.Add(Me.etiquetaDescripcion)
        Me.panelPrincipal.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelPrincipal.Location = New System.Drawing.Point(0, 20)
        Me.panelPrincipal.Name = "panelPrincipal"
        Me.panelPrincipal.Size = New System.Drawing.Size(444, 216)
        Me.panelPrincipal.TabIndex = 1
        '
        'botonDescripcion
        '
        Me.botonDescripcion.Location = New System.Drawing.Point(401, 17)
        Me.botonDescripcion.Name = "botonDescripcion"
        Me.botonDescripcion.Size = New System.Drawing.Size(32, 23)
        Me.botonDescripcion.TabIndex = 10
        Me.botonDescripcion.Text = "..."
        Me.botonDescripcion.UseVisualStyleBackColor = True
        '
        'celdaTotalOpcional
        '
        Me.celdaTotalOpcional.Location = New System.Drawing.Point(274, 148)
        Me.celdaTotalOpcional.Name = "celdaTotalOpcional"
        Me.celdaTotalOpcional.Size = New System.Drawing.Size(99, 22)
        Me.celdaTotalOpcional.TabIndex = 9
        '
        'checkMonto
        '
        Me.checkMonto.AutoSize = True
        Me.checkMonto.Checked = True
        Me.checkMonto.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkMonto.Location = New System.Drawing.Point(274, 121)
        Me.checkMonto.Name = "checkMonto"
        Me.checkMonto.Size = New System.Drawing.Size(154, 21)
        Me.checkMonto.TabIndex = 8
        Me.checkMonto.Text = "Enter Exact Amount"
        Me.checkMonto.UseVisualStyleBackColor = True
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(107, 148)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.Size = New System.Drawing.Size(99, 22)
        Me.celdaTotal.TabIndex = 7
        '
        'celdaCantidad
        '
        Me.celdaCantidad.Location = New System.Drawing.Point(107, 94)
        Me.celdaCantidad.Name = "celdaCantidad"
        Me.celdaCantidad.Size = New System.Drawing.Size(99, 22)
        Me.celdaCantidad.TabIndex = 6
        '
        'celdaFactor
        '
        Me.celdaFactor.Location = New System.Drawing.Point(107, 58)
        Me.celdaFactor.Name = "celdaFactor"
        Me.celdaFactor.ReadOnly = True
        Me.celdaFactor.Size = New System.Drawing.Size(99, 22)
        Me.celdaFactor.TabIndex = 5
        '
        'celdaDescripcion
        '
        Me.celdaDescripcion.Location = New System.Drawing.Point(107, 17)
        Me.celdaDescripcion.Name = "celdaDescripcion"
        Me.celdaDescripcion.ReadOnly = True
        Me.celdaDescripcion.Size = New System.Drawing.Size(288, 22)
        Me.celdaDescripcion.TabIndex = 4
        '
        'etiquetaTotal
        '
        Me.etiquetaTotal.AutoSize = True
        Me.etiquetaTotal.Location = New System.Drawing.Point(12, 151)
        Me.etiquetaTotal.Name = "etiquetaTotal"
        Me.etiquetaTotal.Size = New System.Drawing.Size(40, 17)
        Me.etiquetaTotal.TabIndex = 3
        Me.etiquetaTotal.Text = "Total"
        '
        'etiquetaCantidad
        '
        Me.etiquetaCantidad.AutoSize = True
        Me.etiquetaCantidad.Location = New System.Drawing.Point(12, 97)
        Me.etiquetaCantidad.Name = "etiquetaCantidad"
        Me.etiquetaCantidad.Size = New System.Drawing.Size(61, 17)
        Me.etiquetaCantidad.TabIndex = 2
        Me.etiquetaCantidad.Text = "Quantity"
        '
        'etiquetaFactor
        '
        Me.etiquetaFactor.AutoSize = True
        Me.etiquetaFactor.Location = New System.Drawing.Point(12, 61)
        Me.etiquetaFactor.Name = "etiquetaFactor"
        Me.etiquetaFactor.Size = New System.Drawing.Size(48, 17)
        Me.etiquetaFactor.TabIndex = 1
        Me.etiquetaFactor.Text = "Factor"
        '
        'etiquetaDescripcion
        '
        Me.etiquetaDescripcion.AutoSize = True
        Me.etiquetaDescripcion.Location = New System.Drawing.Point(12, 20)
        Me.etiquetaDescripcion.Name = "etiquetaDescripcion"
        Me.etiquetaDescripcion.Size = New System.Drawing.Size(79, 17)
        Me.etiquetaDescripcion.TabIndex = 0
        Me.etiquetaDescripcion.Text = "Description"
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonCancelar)
        Me.panelBotones.Controls.Add(Me.botonAceptar)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelBotones.Location = New System.Drawing.Point(0, 236)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(444, 110)
        Me.panelBotones.TabIndex = 2
        '
        'botonCancelar
        '
        Me.botonCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.botonCancelar.Image = Global.KARIMs_SGI.My.Resources.Resources.forbidden
        Me.botonCancelar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCancelar.Location = New System.Drawing.Point(275, 22)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(99, 57)
        Me.botonCancelar.TabIndex = 1
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Image = CType(resources.GetObject("botonAceptar.Image"), System.Drawing.Image)
        Me.botonAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonAceptar.Location = New System.Drawing.Point(144, 22)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(99, 57)
        Me.botonAceptar.TabIndex = 0
        Me.botonAceptar.Text = "To Accept"
        Me.botonAceptar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'frmDatosImpuestos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 346)
        Me.Controls.Add(Me.panelBotones)
        Me.Controls.Add(Me.panelPrincipal)
        Me.Controls.Add(Me.etiquetaTitulo)
        Me.Name = "frmDatosImpuestos"
        Me.Text = "Tax Information"
        Me.panelPrincipal.ResumeLayout(False)
        Me.panelPrincipal.PerformLayout()
        Me.panelBotones.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents etiquetaTitulo As Label
    Friend WithEvents panelPrincipal As Panel
    Friend WithEvents botonDescripcion As Button
    Friend WithEvents celdaTotalOpcional As TextBox
    Friend WithEvents checkMonto As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents celdaCantidad As TextBox
    Friend WithEvents celdaFactor As TextBox
    Friend WithEvents celdaDescripcion As TextBox
    Friend WithEvents etiquetaTotal As Label
    Friend WithEvents etiquetaCantidad As Label
    Friend WithEvents etiquetaFactor As Label
    Friend WithEvents etiquetaDescripcion As Label
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonAceptar As Button
    Friend WithEvents botonCancelar As Button
End Class
