﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCuentasIncobrables
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.panelEncabezadoLista = New System.Windows.Forms.Panel()
        Me.botonClienteE = New System.Windows.Forms.Button()
        Me.celdaClienteE = New System.Windows.Forms.TextBox()
        Me.etiquetaClienteE = New System.Windows.Forms.Label()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFechas = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFechas = New System.Windows.Forms.CheckBox()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCliente = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.panelDetalle = New System.Windows.Forms.Panel()
        Me.dgFactura = New System.Windows.Forms.DataGridView()
        Me.colEmpresa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnioF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogoF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuentaIncobrable = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrden = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colXtra = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelBotones = New System.Windows.Forms.Panel()
        Me.botonMenos = New System.Windows.Forms.Button()
        Me.botonMas = New System.Windows.Forms.Button()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.celdaTotalCantidad = New System.Windows.Forms.TextBox()
        Me.etiquetaTotales = New System.Windows.Forms.Label()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.gbCliente = New System.Windows.Forms.GroupBox()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.celdaNIT = New System.Windows.Forms.TextBox()
        Me.celdaIdMoneda = New System.Windows.Forms.TextBox()
        Me.celdaIdCliente = New System.Windows.Forms.TextBox()
        Me.celdaDate = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.celdaCliente = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaCliente = New System.Windows.Forms.Label()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelEncabezadoLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelLista.SuspendLayout()
        Me.panelDetalle.SuspendLayout()
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelBotones.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.gbCliente.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelEncabezadoLista
        '
        Me.panelEncabezadoLista.Controls.Add(Me.botonClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.celdaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaClienteE)
        Me.panelEncabezadoLista.Controls.Add(Me.botonActualizar)
        Me.panelEncabezadoLista.Controls.Add(Me.etiquetaFechas)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpFinal)
        Me.panelEncabezadoLista.Controls.Add(Me.dtpInicial)
        Me.panelEncabezadoLista.Controls.Add(Me.checkFechas)
        Me.panelEncabezadoLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezadoLista.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezadoLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelEncabezadoLista.Name = "panelEncabezadoLista"
        Me.panelEncabezadoLista.Size = New System.Drawing.Size(1273, 85)
        Me.panelEncabezadoLista.TabIndex = 0
        '
        'botonClienteE
        '
        Me.botonClienteE.Location = New System.Drawing.Point(568, 54)
        Me.botonClienteE.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonClienteE.Name = "botonClienteE"
        Me.botonClienteE.Size = New System.Drawing.Size(43, 28)
        Me.botonClienteE.TabIndex = 7
        Me.botonClienteE.Text = "..."
        Me.botonClienteE.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonClienteE.UseVisualStyleBackColor = True
        '
        'celdaClienteE
        '
        Me.celdaClienteE.Location = New System.Drawing.Point(131, 57)
        Me.celdaClienteE.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaClienteE.Name = "celdaClienteE"
        Me.celdaClienteE.Size = New System.Drawing.Size(432, 22)
        Me.celdaClienteE.TabIndex = 6
        '
        'etiquetaClienteE
        '
        Me.etiquetaClienteE.AutoSize = True
        Me.etiquetaClienteE.Location = New System.Drawing.Point(45, 59)
        Me.etiquetaClienteE.Name = "etiquetaClienteE"
        Me.etiquetaClienteE.Size = New System.Drawing.Size(51, 17)
        Me.etiquetaClienteE.TabIndex = 5
        Me.etiquetaClienteE.Text = "Cliente"
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(741, 10)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 26)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Refresh"
        Me.botonActualizar.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFechas
        '
        Me.etiquetaFechas.AutoSize = True
        Me.etiquetaFechas.Location = New System.Drawing.Point(485, 14)
        Me.etiquetaFechas.Name = "etiquetaFechas"
        Me.etiquetaFechas.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaFechas.TabIndex = 3
        Me.etiquetaFechas.Text = "And Date"
        '
        'dtpFinal
        '
        Me.dtpFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFinal.Location = New System.Drawing.Point(568, 11)
        Me.dtpFinal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(121, 22)
        Me.dtpFinal.TabIndex = 2
        '
        'dtpInicial
        '
        Me.dtpInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicial.Location = New System.Drawing.Point(349, 11)
        Me.dtpInicial.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpInicial.Name = "dtpInicial"
        Me.dtpInicial.Size = New System.Drawing.Size(121, 22)
        Me.dtpInicial.TabIndex = 1
        '
        'checkFechas
        '
        Me.checkFechas.AutoSize = True
        Me.checkFechas.Checked = True
        Me.checkFechas.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFechas.Location = New System.Drawing.Point(49, 15)
        Me.checkFechas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkFechas.Name = "checkFechas"
        Me.checkFechas.Size = New System.Drawing.Size(231, 21)
        Me.checkFechas.TabIndex = 0
        Me.checkFechas.Text = "Show Documents Between Date"
        Me.checkFechas.UseVisualStyleBackColor = True
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colNumero, Me.colFecha, Me.colCliente, Me.colNumeroFac, Me.colAnio})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 85)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(1273, 57)
        Me.dgLista.TabIndex = 0
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colCliente
        '
        Me.colCliente.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colCliente.HeaderText = "Client"
        Me.colCliente.Name = "colCliente"
        Me.colCliente.ReadOnly = True
        '
        'colNumeroFac
        '
        Me.colNumeroFac.HeaderText = "Number Invoice"
        Me.colNumeroFac.Name = "colNumeroFac"
        Me.colNumeroFac.ReadOnly = True
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Anio"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelEncabezadoLista)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 110)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(1273, 142)
        Me.panelLista.TabIndex = 12
        '
        'panelDetalle
        '
        Me.panelDetalle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDetalle.Controls.Add(Me.dgFactura)
        Me.panelDetalle.Controls.Add(Me.panelBotones)
        Me.panelDetalle.Controls.Add(Me.panelTotales)
        Me.panelDetalle.Controls.Add(Me.panelDatos)
        Me.panelDetalle.Location = New System.Drawing.Point(5, 258)
        Me.panelDetalle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDetalle.Name = "panelDetalle"
        Me.panelDetalle.Size = New System.Drawing.Size(1255, 586)
        Me.panelDetalle.TabIndex = 13
        '
        'dgFactura
        '
        Me.dgFactura.AllowUserToAddRows = False
        Me.dgFactura.AllowUserToDeleteRows = False
        Me.dgFactura.AllowUserToOrderColumns = True
        Me.dgFactura.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colEmpresa, Me.colNumeroF, Me.colFechaF, Me.colReferenciaF, Me.colAnioF, Me.colCatalogoF, Me.colLineaF, Me.colTotal, Me.colSaldo, Me.colCuentaIncobrable, Me.colOrden, Me.colLineaCuenta, Me.colXtra})
        Me.dgFactura.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgFactura.Location = New System.Drawing.Point(0, 318)
        Me.dgFactura.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dgFactura.MultiSelect = False
        Me.dgFactura.Name = "dgFactura"
        Me.dgFactura.RowTemplate.Height = 24
        Me.dgFactura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFactura.Size = New System.Drawing.Size(1194, 163)
        Me.dgFactura.TabIndex = 0
        '
        'colEmpresa
        '
        Me.colEmpresa.HeaderText = "Business"
        Me.colEmpresa.Name = "colEmpresa"
        Me.colEmpresa.ReadOnly = True
        Me.colEmpresa.Visible = False
        '
        'colNumeroF
        '
        Me.colNumeroF.HeaderText = "Bill No."
        Me.colNumeroF.Name = "colNumeroF"
        Me.colNumeroF.ReadOnly = True
        '
        'colFechaF
        '
        Me.colFechaF.HeaderText = "Date"
        Me.colFechaF.Name = "colFechaF"
        Me.colFechaF.ReadOnly = True
        '
        'colReferenciaF
        '
        Me.colReferenciaF.HeaderText = "Reference"
        Me.colReferenciaF.Name = "colReferenciaF"
        Me.colReferenciaF.ReadOnly = True
        '
        'colAnioF
        '
        Me.colAnioF.HeaderText = "Anio"
        Me.colAnioF.Name = "colAnioF"
        Me.colAnioF.ReadOnly = True
        '
        'colCatalogoF
        '
        Me.colCatalogoF.HeaderText = "Catalogo"
        Me.colCatalogoF.Name = "colCatalogoF"
        Me.colCatalogoF.ReadOnly = True
        Me.colCatalogoF.Visible = False
        '
        'colLineaF
        '
        Me.colLineaF.HeaderText = "LineaF"
        Me.colLineaF.Name = "colLineaF"
        Me.colLineaF.Visible = False
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Balance"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        '
        'colCuentaIncobrable
        '
        Me.colCuentaIncobrable.HeaderText = "Bad Debit"
        Me.colCuentaIncobrable.Name = "colCuentaIncobrable"
        '
        'colOrden
        '
        Me.colOrden.HeaderText = "Order No."
        Me.colOrden.Name = "colOrden"
        Me.colOrden.ReadOnly = True
        '
        'colLineaCuenta
        '
        Me.colLineaCuenta.HeaderText = "LineaCuenta"
        Me.colLineaCuenta.Name = "colLineaCuenta"
        Me.colLineaCuenta.Visible = False
        '
        'colXtra
        '
        Me.colXtra.HeaderText = "Xtra"
        Me.colXtra.Name = "colXtra"
        Me.colXtra.Visible = False
        '
        'panelBotones
        '
        Me.panelBotones.Controls.Add(Me.botonMenos)
        Me.panelBotones.Controls.Add(Me.botonMas)
        Me.panelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.panelBotones.Location = New System.Drawing.Point(1194, 318)
        Me.panelBotones.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelBotones.Name = "panelBotones"
        Me.panelBotones.Size = New System.Drawing.Size(61, 163)
        Me.panelBotones.TabIndex = 1
        '
        'botonMenos
        '
        Me.botonMenos.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonMenos.Location = New System.Drawing.Point(15, 78)
        Me.botonMenos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMenos.Name = "botonMenos"
        Me.botonMenos.Size = New System.Drawing.Size(35, 31)
        Me.botonMenos.TabIndex = 45
        Me.botonMenos.UseVisualStyleBackColor = True
        '
        'botonMas
        '
        Me.botonMas.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonMas.Location = New System.Drawing.Point(15, 22)
        Me.botonMas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMas.Name = "botonMas"
        Me.botonMas.Size = New System.Drawing.Size(35, 31)
        Me.botonMas.TabIndex = 4
        Me.botonMas.UseVisualStyleBackColor = True
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.celdaTotalCantidad)
        Me.panelTotales.Controls.Add(Me.etiquetaTotales)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 481)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(1255, 105)
        Me.panelTotales.TabIndex = 3
        '
        'celdaTotalCantidad
        '
        Me.celdaTotalCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotalCantidad.Location = New System.Drawing.Point(1079, 31)
        Me.celdaTotalCantidad.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTotalCantidad.Name = "celdaTotalCantidad"
        Me.celdaTotalCantidad.ReadOnly = True
        Me.celdaTotalCantidad.Size = New System.Drawing.Size(113, 22)
        Me.celdaTotalCantidad.TabIndex = 19
        '
        'etiquetaTotales
        '
        Me.etiquetaTotales.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTotales.AutoSize = True
        Me.etiquetaTotales.Location = New System.Drawing.Point(977, 36)
        Me.etiquetaTotales.Name = "etiquetaTotales"
        Me.etiquetaTotales.Size = New System.Drawing.Size(55, 17)
        Me.etiquetaTotales.TabIndex = 1
        Me.etiquetaTotales.Text = "Totales"
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.panelEncabezado)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(1255, 318)
        Me.panelDatos.TabIndex = 0
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.gbCliente)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(1255, 311)
        Me.panelEncabezado.TabIndex = 24
        '
        'gbCliente
        '
        Me.gbCliente.Controls.Add(Me.celdaEmpresa)
        Me.gbCliente.Controls.Add(Me.celdaUsuario)
        Me.gbCliente.Controls.Add(Me.botonMoneda)
        Me.gbCliente.Controls.Add(Me.dtpFecha)
        Me.gbCliente.Controls.Add(Me.celdaNIT)
        Me.gbCliente.Controls.Add(Me.celdaIdMoneda)
        Me.gbCliente.Controls.Add(Me.celdaIdCliente)
        Me.gbCliente.Controls.Add(Me.celdaDate)
        Me.gbCliente.Controls.Add(Me.checkActivo)
        Me.gbCliente.Controls.Add(Me.celdaTasa)
        Me.gbCliente.Controls.Add(Me.celdaMoneda)
        Me.gbCliente.Controls.Add(Me.celdaDireccion)
        Me.gbCliente.Controls.Add(Me.botonCliente)
        Me.gbCliente.Controls.Add(Me.celdaCliente)
        Me.gbCliente.Controls.Add(Me.celdaNumero)
        Me.gbCliente.Controls.Add(Me.celdaCatalogo)
        Me.gbCliente.Controls.Add(Me.celdaAnio)
        Me.gbCliente.Controls.Add(Me.etiquetaTasa)
        Me.gbCliente.Controls.Add(Me.etiquetaMoneda)
        Me.gbCliente.Controls.Add(Me.etiquetaDireccion)
        Me.gbCliente.Controls.Add(Me.etiquetaCliente)
        Me.gbCliente.Controls.Add(Me.etiquetaFecha)
        Me.gbCliente.Controls.Add(Me.etiquetaNumero)
        Me.gbCliente.Controls.Add(Me.etiquetaAnio)
        Me.gbCliente.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbCliente.Location = New System.Drawing.Point(0, 0)
        Me.gbCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbCliente.Name = "gbCliente"
        Me.gbCliente.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbCliente.Size = New System.Drawing.Size(1255, 311)
        Me.gbCliente.TabIndex = 1
        Me.gbCliente.TabStop = False
        Me.gbCliente.Text = "Return"
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(385, 101)
        Me.celdaEmpresa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(47, 22)
        Me.celdaEmpresa.TabIndex = 23
        Me.celdaEmpresa.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(415, 283)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(100, 22)
        Me.celdaUsuario.TabIndex = 21
        Me.celdaUsuario.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(227, 235)
        Me.botonMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(37, 25)
        Me.botonMoneda.TabIndex = 22
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(107, 108)
        Me.dtpFecha.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(113, 22)
        Me.dtpFecha.TabIndex = 20
        '
        'celdaNIT
        '
        Me.celdaNIT.Location = New System.Drawing.Point(433, 60)
        Me.celdaNIT.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNIT.Name = "celdaNIT"
        Me.celdaNIT.Size = New System.Drawing.Size(100, 22)
        Me.celdaNIT.TabIndex = 19
        Me.celdaNIT.Visible = False
        '
        'celdaIdMoneda
        '
        Me.celdaIdMoneda.Location = New System.Drawing.Point(269, 238)
        Me.celdaIdMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdMoneda.Name = "celdaIdMoneda"
        Me.celdaIdMoneda.Size = New System.Drawing.Size(81, 22)
        Me.celdaIdMoneda.TabIndex = 18
        Me.celdaIdMoneda.Visible = False
        '
        'celdaIdCliente
        '
        Me.celdaIdCliente.Location = New System.Drawing.Point(591, 121)
        Me.celdaIdCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaIdCliente.Name = "celdaIdCliente"
        Me.celdaIdCliente.Size = New System.Drawing.Size(41, 22)
        Me.celdaIdCliente.TabIndex = 18
        Me.celdaIdCliente.Text = "-1"
        Me.celdaIdCliente.Visible = False
        '
        'celdaDate
        '
        Me.celdaDate.Location = New System.Drawing.Point(224, 110)
        Me.celdaDate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaDate.Name = "celdaDate"
        Me.celdaDate.Size = New System.Drawing.Size(81, 22)
        Me.celdaDate.TabIndex = 17
        Me.celdaDate.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(591, 21)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(68, 21)
        Me.checkActivo.TabIndex = 16
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'celdaTasa
        '
        Me.celdaTasa.Location = New System.Drawing.Point(107, 276)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(113, 22)
        Me.celdaTasa.TabIndex = 15
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Location = New System.Drawing.Point(107, 238)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.Size = New System.Drawing.Size(113, 22)
        Me.celdaMoneda.TabIndex = 14
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion.Location = New System.Drawing.Point(107, 178)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.ReadOnly = True
        Me.celdaDireccion.Size = New System.Drawing.Size(437, 48)
        Me.celdaDireccion.TabIndex = 13
        '
        'botonCliente
        '
        Me.botonCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCliente.Location = New System.Drawing.Point(508, 144)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(37, 30)
        Me.botonCliente.TabIndex = 8
        Me.botonCliente.Text = "..."
        Me.botonCliente.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'celdaCliente
        '
        Me.celdaCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCliente.Location = New System.Drawing.Point(107, 146)
        Me.celdaCliente.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCliente.Name = "celdaCliente"
        Me.celdaCliente.ReadOnly = True
        Me.celdaCliente.Size = New System.Drawing.Size(395, 22)
        Me.celdaCliente.TabIndex = 12
        '
        'celdaNumero
        '
        Me.celdaNumero.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaNumero.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.celdaNumero.Location = New System.Drawing.Point(107, 74)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(113, 23)
        Me.celdaNumero.TabIndex = 10
        Me.celdaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(193, 16)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(81, 22)
        Me.celdaCatalogo.TabIndex = 8
        Me.celdaCatalogo.Visible = False
        '
        'celdaAnio
        '
        Me.celdaAnio.AcceptsReturn = True
        Me.celdaAnio.Location = New System.Drawing.Point(107, 39)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(113, 22)
        Me.celdaAnio.TabIndex = 7
        Me.celdaAnio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(19, 276)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaTasa.TabIndex = 6
        Me.etiquetaTasa.Text = "Rate"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(19, 238)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(36, 17)
        Me.etiquetaMoneda.TabIndex = 5
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(16, 178)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(53, 17)
        Me.etiquetaDireccion.TabIndex = 4
        Me.etiquetaDireccion.Text = "Addres"
        '
        'etiquetaCliente
        '
        Me.etiquetaCliente.AutoSize = True
        Me.etiquetaCliente.Location = New System.Drawing.Point(16, 146)
        Me.etiquetaCliente.Name = "etiquetaCliente"
        Me.etiquetaCliente.Size = New System.Drawing.Size(43, 17)
        Me.etiquetaCliente.TabIndex = 3
        Me.etiquetaCliente.Text = "Client"
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(16, 110)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaFecha.TabIndex = 2
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(16, 74)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(58, 17)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "Number"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(16, 39)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(38, 17)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 73)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1273, 37)
        Me.BarraTitulo1.TabIndex = 11
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(5, 5, 5, 5)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1273, 73)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCuentasIncobrables
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1273, 894)
        Me.Controls.Add(Me.panelDetalle)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmCuentasIncobrables"
        Me.Text = "frmCuentasIncobrables"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelEncabezadoLista.ResumeLayout(False)
        Me.panelEncabezadoLista.PerformLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelLista.ResumeLayout(False)
        Me.panelDetalle.ResumeLayout(False)
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelBotones.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelDatos.ResumeLayout(False)
        Me.panelEncabezado.ResumeLayout(False)
        Me.gbCliente.ResumeLayout(False)
        Me.gbCliente.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelEncabezadoLista As Panel
    Friend WithEvents botonClienteE As Button
    Friend WithEvents celdaClienteE As TextBox
    Friend WithEvents etiquetaClienteE As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents etiquetaFechas As Label
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents dtpInicial As DateTimePicker
    Friend WithEvents checkFechas As System.Windows.Forms.CheckBox
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelLista As Panel
    Friend WithEvents panelDetalle As Panel
    Friend WithEvents panelTotales As Panel
    Friend WithEvents celdaTotalCantidad As TextBox
    Friend WithEvents etiquetaTotales As Label
    Friend WithEvents panelDatos As Panel
    Friend WithEvents panelBotones As Panel
    Friend WithEvents botonMenos As Button
    Friend WithEvents botonMas As Button
    Friend WithEvents dgFactura As DataGridView
    Friend WithEvents gbCliente As GroupBox
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents celdaNIT As TextBox
    Friend WithEvents celdaIdMoneda As TextBox
    Friend WithEvents celdaIdCliente As TextBox
    Friend WithEvents celdaDate As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents celdaCliente As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaCliente As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCliente As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroFac As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents panelEncabezado As System.Windows.Forms.Panel
    Friend WithEvents colEmpresa As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFechaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnioF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCatalogoF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colTotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCuentaIncobrable As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colOrden As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colLineaCuenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colXtra As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
