﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient

Public Class frmClientes

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Public Const TBL_DOCUMENTOS As String = "Clientes"
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private strMascara As String
    Private strTipo As String
    Private intNiveles As Integer
    Private iFila As Integer
    Private strDireccion As String
    Private strLugar As String


    Private Function SQLLista() As String
        Dim strsql As String = STR_VACIO
        strsql &= "select"
        strsql &= " cli_codigo Code, cli_cliente Name, cli_nombre Abreviation, cli_direccion Direction,cli_plazoCR Credit_Days, cli_usuario User"
        strsql &= "   from Clientes "
        strsql &= "where cli_sisemp = {empresa} "
        strsql &= " ORDER BY cli_codigo  DESC"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)

        Return strsql
    End Function

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub reset()
        celdaCategoria.Text = STR_VACIO
        celdaIdCategoria.Text = INT_CERO
        celdaCodigo.Text = STR_VACIO
        celdaDescripcionCorta.Text = STR_VACIO
        celdaRazonSocial.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        celdaTelefono.Text = NO_FILA
        celdaNIT.Text = NO_FILA
        celdaDescuento.Text = NO_FILA
        celdaPlazoCreditos.Text = INT_CERO
        celdaLimiteCredito.Text = NO_FILA
        celdaCuentasxCobrar.Text = STR_VACIO
        celdaNumeroCta.Text = STR_VACIO
        CeldaNombreCta.Text = STR_VACIO
        celdaPaymentInfo.Text = STR_VACIO
        celdaCxC.Text = STR_VACIO
        celdaSaldo.Text = NO_FILA
        celdaDisponible.Text = NO_FILA
        celdaRegimen.Text = STR_VACIO
        celdaUsuario.Text = STR_VACIO
        celdaPais.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaEstado.Text = STR_VACIO
        celdaIdClasificacion.Text = INT_CERO
        celdaClasificacion.Text = STR_VACIO
        celdaPaymentInfo.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        dgDireccionCliente.Rows.Clear()
        celdaRegistro.Clear()
        celdaGiro.Clear()
        'celdaIdCategoria.Clear()
        'celdaIdClasificacion.Clear()
        rdHilo.Checked = True

    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonImprimir.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
        End If

    End Sub

    Private Sub Seleccionar(ByVal intCodigo As Integer)
        Dim strSQL As String
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim Contador As Integer
        SeleccionarCliente(intCodigo)
        SeleccionarCuenta(intCodigo)
        SeleccionarContacto(intCodigo)
        strTipo = "Clientes"
        strSQL = "SELECT Dir_Nombre Nombre, Dir_Direccion Direccion "
        strSQL &= " FROM Direcciones"
        strSQL &= " WHERE Dir_Sis_Emp = {empresa} AND Dir_Emp_Tipo = {tipo} AND Dir_Emp_Cod = {numero} "
        strSQL = Replace(strSQL, "{numero}", intCodigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", "'" & strTipo & "'")


        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        strDireccion = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()

        If Not strDireccion = vbNullString Then
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read
                Contador = Contador + 1
                cFunciones.AgregarFila(dgDireccionCliente, Contador & "|" & REA.GetString("Nombre") & "|" & REA.GetString("Direccion"))
            Loop
        Else
            SeleccionarDireccion(intCodigo)
        End If
    End Sub
    Private Sub SeleccionarCuenta(ByVal intCodigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = "SELECT IFNULL(cc.id_cuenta,'N/A') Cuenta, IFNULL(cc.nombre,'N/A') NombreCuenta, IFNULL(n.idCuenta,'N/A')cta, IFNULL(n.NombreEspanol,'N/A') Nombre "
            strSQL &= "     FROM Clientes c  "
            strSQL &= "         LEFT JOIN {conta}.cuentas cc ON cc.empresa = c.cli_sisemp AND cc.id_cuenta = c.cli_cuenta"
            strSQL &= "         LEFT JOIN {conta}.nomenclatura n ON n.idEmpresa = cc.empresa AND n.idCuenta = cc.id_nomenclatura"
            strSQL &= "             WHERE c.cli_sisemp = {empresa} AND c.cli_codigo = {codigo} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{codigo}", intCodigo)
            strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaCuentasxCobrar.Text = REA.GetString("Cuenta")
                    celdaCxC.Text = REA.GetString("NombreCuenta")
                    celdaNumeroCta.Text = REA.GetString("cta")
                    CeldaNombreCta.Text = REA.GetString("Nombre")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub SeleccionarCliente(ByVal intCodigo As Integer)
        Dim CLS As New Tablas.TCLIENTES
        Dim CA As New clsCatalogos
        Dim strSQL As String
        Dim strSQL1 As String
        Dim REA As MySqlDataReader
        Dim REA1 As MySqlDataReader
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand
        Dim dblAbonos As Double
        Dim dblCargos As Double
        Dim dblSist As Double
        Dim dblMonto As Double
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        strCampos = " cli_categoria, cli_codigo, cli_nombre,cli_cliente,cli_direccion,cli_telefono,cli_nit,cli_exterior,cli_status"
        strCondicion = "cli_codigo = {codigo} AND cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{codigo}", intCodigo)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        strSQL = SQLBALANCE(intCodigo)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        Do While REA.Read
            dblCargos = REA.GetDouble("Cargos")
            dblAbonos = REA.GetDouble("Abonos")
        Loop
        strSQL1 = SQLClientesLista(intCodigo)
        MyCnn.CONECTAR = strConexion
        COM1 = New MySqlCommand(strSQL1, CON)
        REA1 = COM1.ExecuteReader
        Do While REA1.Read
            dblSist = REA1.GetDouble("cat_sist")
            dblMonto = REA1.GetDouble("cli_montoCR")
        Loop

        celdaSaldo.Text = Math.Round((dblCargos - dblAbonos) / dblSist, 2).ToString(FORMATO_MONEDA)
        celdaDisponible.Text = Math.Round((dblMonto) - (dblCargos - dblAbonos) / dblSist, 2).ToString(FORMATO_MONEDA)
        gbPosicionCuenta.Enabled = False

        Try
            CLS.CONEXION = strConexion
            If CLS.PSELECT(Sesion.IdEmpresa, intCodigo) = True Then
                celdaCodigo.Text = CLS.CLI_CODIGO.ToString
                If CLS.CLI_NOMBRE = "NULL" Then
                    celdaDescripcionCorta.Text = vbNullString
                Else
                    celdaDescripcionCorta.Text = CLS.CLI_NOMBRE.ToString

                End If
                celdaRazonSocial.Text = CLS.CLI_CLIENTE
                celdaDireccion.Text = CLS.CLI_DIRECCION
                celdaTelefono.Text = CLS.CLI_TELEFONO.ToString
                celdaNIT.Text = CLS.CLI_NIT.ToString
                celdaUsuario.Text = CLS.CLI_USUARIO
                celdaRegimen.Text = CLS.CLI_EXTERIOR
                celdaEstado.Text = CLS.CLI_STATUS
                celdaFormaPago.Text = CLS.CLI_FORMA
                celdaMetodoCosteo.Text = CLS.CLI_CMETHOD
                celdaPaymentInfo.Text = CLS.CLI_OBSERVACIONES
                celdaDescuento.Text = CLS.CLI_DSCTO
                celdaPlazoCreditos.Text = CLS.CLI_PLAZOCR.ToString
                celdaLimiteCredito.Text = CLS.CLI_MONTOCR.ToString(FORMATO_MONEDA)
                celdaCuentasxCobrar.Text = CLS.CLI_CUENTA.ToString
                celdaCxC.Text = CLS.CLI_CLIENTE.ToString
                celdaIdCategoria.Text = CLS.CLI_CATEGORIA
                celdaIdClasificacion.Text = IIf(CLS.CLI_CLASIFICACION = 0, -1, CLS.CLI_CLASIFICACION)
                celdaRegistro.Text = IIf(CLS.CLI_REGISTRONO = "NULL", STR_VACIO, CLS.CLI_REGISTRONO.ToString)
                celdaGiro.Text = IIf(CLS.CLI_GIRO = "NULL", STR_VACIO, CLS.CLI_GIRO.ToString)

                Select Case CLS.CLI_TIPO
                    Case 0
                        rdHilo.Checked = True
                    Case 1
                        rdDestino.Checked = True
                    Case 2
                        rdCobro.Checked = True
                End Select

                CA.CONEXION = strConexion
                If CA.Seleccionar(" cat_num = " & CLS.CLI_PAIS, "cat_desc") Then
                    celdaPais.Text = CA.CAT_DESC
                Else
                    MsgBox(CA.MERROR.ToString)
                End If


                If CA.Seleccionar(" cat_num = " & CLS.CLI_MONEDA, "cat_clave") Then
                    celdaMoneda.Text = CA.CAT_CLAVE
                Else
                    MsgBox(CA.MERROR.ToString)
                End If

                If CA.Seleccionar("cat_num = " & CLS.CLI_CLASIFICACION, "cat_desc") Then
                    celdaClasificacion.Text = CA.CAT_DESC

                End If

                If CA.Seleccionar(" cat_clase = 'CategoriaClt' and cat_num = " & CLS.CLI_CATEGORIA, "cat_desc") Then
                    celdaCategoria.Text = CA.CAT_DESC

                End If

                CLS.CONEXION = strConexion
                celdaManufactura.Text = CLS.CLI_MAQUILA
            Else
                MsgBox(CLS.MERROR.ToString)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SeleccionarContacto(ByVal intCodigo As Integer)
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim CNT As New Tablas.TCONTACTOS
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFIla As String = STR_VACIO
        strCampos = "cnt_codigo, cnt_nombre, cnt_celular, cnt_correo, cnt_status"
        strCondicion = "DDoc_Doc_Num = {numero} AND DDoc_Sis_Emp = {empresa}"
        strCondicion = Replace(strCondicion, "{numero}", intCodigo)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        strSQL = " SELECT cnt_codigo, cnt_nombre,cnt_puesto, cnt_celular, cnt_correo, cnt_status "
        strSQL &= " FROM Contactos"
        strSQL &= " WHERE cnt_codemp ={numero} AND cnt_sisemp ={empresa}"
        strSQL = Replace(strSQL, "{numero}", intCodigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Try

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Do While REA.Read
                cFunciones.AgregarFila(dgDetalle, REA.GetString("cnt_nombre") & "|" & REA.GetString("cnt_puesto") & "|" & REA.GetString("cnt_celular") & "|" & REA.GetString("cnt_correo") & "|" & REA.GetString("cnt_Status") & "|" & REA.GetInt32("cnt_codigo"))
                ' cfun.AgregarFila(dgDetalle, strFIla)
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub SeleccionarDireccion(ByVal intCodigo As Integer)
        Dim CLS As New Tablas.TCLIENTES
        Dim CA As New clsCatalogos
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFIla As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO

        Dim contador As Integer = 0
        strCampos = " cli_codigo, cli_nombre,cli_cliente,cli_direccion,cli_telefono,cli_nit,cli_exterior,cli_status"
        strCondicion = "cli_codigo = {codigo} AND cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{codigo}", intCodigo)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        strSQL = " SELECT DISTINCT(cl.cli_direccion) Direccion, cl.cli_cliente Nombre "
        strSQL &= " FROM Clientes cl"
        strSQL &= " LEFT JOIN Contactos ct ON ct.cnt_sisemp = cl.cli_sisemp AND ct.cnt_tipoemp = 'Clientes' AND ct.cnt_codemp = cl.cli_codigo"
        strSQL &= " LEFT JOIN Direcciones dr ON dr.Dir_Sis_Emp = cl.cli_sisemp AND dr.Dir_Emp_Cod = cl.cli_codigo  "
        strSQL &= "  WHERE cl.cli_sisemp = {empresa} AND cl.cli_codigo = {numero} "
        strSQL = Replace(strSQL, "{numero}", intCodigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        Try
            Do While REA.Read
                contador = contador + 1
                cFunciones.AgregarFila(dgDireccionCliente, contador & "|" & REA.GetString("Nombre") & "|" & REA.GetString("Direccion"))
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function GuardarEncabezado(Optional logUpdate As Boolean = False) As Boolean
        Dim cHDR As New Tablas.TCLIENTES
        Dim intNuevoID As Integer = NO_FILA

        Dim logGuardar As Boolean = False
        Try
            cHDR.CONEXION = strConexion
            cHDR.CLI_SISEMP = Sesion.IdEmpresa
            cHDR.CLI_CODIGO = celdaCodigo.Text
            cHDR.CLI_NOMBRE = celdaDescripcionCorta.Text
            cHDR.CLI_CLIENTE = celdaRazonSocial.Text
            cHDR.CLI_DIRECCION = celdaDireccion.Text
            cHDR.CLI_TELEFONO = celdaTelefono.Text
            cHDR.CLI_NIT = celdaNIT.Text
            cHDR.CLI_USUARIO = celdaUsuario.Text
            cHDR.CLI_EXTERIOR = celdaRegimen.Text
            cHDR.CLI_STATUS = celdaEstado.Text
            cHDR.CLI_FORMA = celdaFormaPago.Text
            cHDR.CLI_CMETHOD = celdaMetodoCosteo.Text
            If rdCobro.Checked = True Then
                cHDR.CLI_TIPO = 2
            ElseIf rdDestino.Checked = True Then
                cHDR.CLI_TIPO = INT_UNO
            Else
                cHDR.CLI_TIPO = INT_CERO
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function

    Private Function GuardarDetalle() As Boolean
        Dim CNT As New Tablas.TCONTACTOS
        Dim logDetalle As Boolean = True

        CNT.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                CNT.CNT_SISEMP = Sesion.IdEmpresa
                CNT.CNT_CODEMP = celdaCodigo.Text
                CNT.CNT_TIPOEMP = "Clientes"
                CNT.CNT_NOMBRE = CStr(dgDetalle.Rows(i).Cells("colNombre").Value)
                CNT.CNT_PUESTO = CStr(dgDetalle.Rows(i).Cells("colPuesto").Value)
                CNT.CNT_CELULAR = (dgDetalle.Rows(i).Cells("colCelular").Value)
                CNT.CNT_CORREO = CStr(dgDetalle.Rows(i).Cells("colCorreoElectronico").Value)
                CNT.CNT_STATUS = CStr(dgDetalle.Rows(i).Cells("colEstado").Value)

                If dgDetalle.Rows(i).Cells("colEstatus").Value = 1 Then
                    CNT.CNT_CODIGO = dgDetalle.Rows(i).Cells("colCode").Value
                    If CNT.PINSERT = False Then
                        MsgBox(CNT.MERROR.ToString & "Could not save the document ", MsgBoxStyle.Critical)
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstatus").Value = 2 Then
                    CNT.CNT_CODIGO = CInt(dgDetalle.Rows(i).Cells("colCode").Value)
                    If CNT.PUPDATE = False Then
                        MsgBox(CNT.MERROR.ToString & "could not Modify the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dgDetalle.Rows(i).Cells("colEstatus").Value = 3 Then
                    CNT.CNT_CODIGO = CInt(dgDetalle.Rows(i).Cells("colCode").Value)
                    If CNT.PDELETE = False Then
                        MsgBox(CNT.MERROR.ToString & "Could not delete the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function
    Private Function GuardarDireccion() As Boolean
        Dim DIR As New Tablas.TDIRECCIONES
        Dim logDetalle As Boolean = True

        DIR.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDireccionCliente.Rows.Count - 1
                DIR.DIR_NOMBRE = dgDireccionCliente.Rows(i).Cells("colNom").Value
                DIR.DIR_DIRECCION = dgDireccionCliente.Rows(i).Cells("colDireccion").Value


                DIR.DIR_SIS_EMP = Sesion.IdEmpresa
                DIR.DIR_EMP_COD = celdaCodigo.Text
                DIR.DIR_LIN = i
                DIR.DIR_EMP_TIPO = "Clientes"



                If dgDireccionCliente.Rows(i).Cells("colEstadoD").Value = 0 Then
                    If DIR.PINSERT = False Then
                        MsgBox(DIR.MERROR.ToString & "could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
                If dgDireccionCliente.Rows(i).Cells("colEstadoD").Value = 1 Then
                    If DIR.PUPDATE() = False Then
                        MsgBox(DIR.MERROR.ToString & "could not Modify the document", MsgBoxStyle.Critical)
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logDetalle
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Customers")
            'Cargar Datos
            cfun.CargarLista(dgLista, SQLLista, False)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            'Me.Tag = "Nuevo"
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Register")
                Me.Tag = "Mod"
                BloquearBotones(False)
                botonImprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                botonImprimir.Enabled = False

                reset()
            End If

            dgLista.DataSource = Nothing
        End If

    End Sub

    Private Function BorrarDetalle() As Boolean
        Dim logResulta As Boolean = False
        Dim cCLS As New Tablas.TDIRECCIONES
        Dim strCondicion As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            MyCnn.CONECTAR = strConexion
            strCondicion = "  DELETE FROM Direcciones  WHERE Dir_Sis_Emp = {empresa} AND Dir_Emp_Cod = {numero}"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{numero}", celdaCodigo.Text)
            COM = New MySqlCommand(strCondicion, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logResulta = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResulta
    End Function

    Private Function BorrarEncabezado() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim logResult As Boolean
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Clientes  WHERE cli_sisemp = {empresa} AND cli_codigo = {numero}  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", celdaCodigo.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logResult = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Function BorrarContacto() As Boolean
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim logResult As Boolean
        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Contactos  WHERE cnt_sisemp = {empresa} AND cnt_codemp = {numero}  AND cnt_tipoemp = 'Clientes'  "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", celdaCodigo.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            logResult = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Function Borrar2() As Boolean
        Dim logResult As Boolean = False
        If BorrarDetalle() = True Then 'DIRECCIONES
            If BorrarEncabezado() = True Then 'CLIENTES
                If BorrarContacto() = True Then 'CONTACTOS
                    logResult = True
                End If
            End If
        End If
        Return logResult
    End Function
    Private Function Borrar3(ByVal num As Integer) As Boolean
        Borrar3 = False
        Dim DIREC As New Tablas.TDIRECCIONES
        Dim CONTAC As New Tablas.TCONTACTOS
        Dim CLI As New Tablas.TCLIENTES

        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = " Dir_Sis_Emp = {empresa} AND Dir_Emp_Tipo = 'Clientes' AND Dir_Emp_Cod = {numero}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{numero}", celdaCodigo.Text) 'cliente
        Try
            DIREC.CONEXION = strConexion
            If DIREC.PDELETE(strCondicion) = True Then 'DIRECCION
                strCondicion = STR_VACIO
                strCondicion = " cnt_sisemp = {empresa} AND cnt_codemp = {numero}  AND cnt_tipoemp = 'Clientes' "
                strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                strCondicion = Replace(strCondicion, "{numero}", celdaCodigo.Text) 'cliente
                If CONTAC.PDELETE(strCondicion) = True Then 'CONTACTOS
                    strCondicion = STR_VACIO
                    strCondicion = " cli_sisemp = {empresa} AND cli_codigo = {numero} "
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{numero}", celdaCodigo.Text) 'cliente
                    If CLI.PDELETE(strCondicion) = True Then 'CLIENTES
                        Borrar3 = True
                        MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Function Borrar() As Boolean
        Dim resultado As Boolean = False
        Dim clienteId As Integer = celdaCodigo.Text
        Dim empresaId As Integer = Sesion.IdEmpresa

        Using conexion As New MySqlConnection(strConexion)
            conexion.Open()
            Dim transaccion As MySqlTransaction = conexion.BeginTransaction()

            Try
                ' Inicializa las tablas con la misma conexión y transacción
                Dim DIREC As New Tablas.TDIRECCIONES With {.CONEXIONEXTERNA = conexion, .TRANSACCION = transaccion}
                Dim CONTAC As New Tablas.TCONTACTOS With {.CONEXIONEXTERNA = conexion, .TRANSACCION = transaccion}
                Dim CLI As New Tablas.TCLIENTES With {.CONEXIONEXTERNA = conexion, .TRANSACCION = transaccion}

                ' Condiciones
                Dim condDireccion As String = $" Dir_Sis_Emp = {empresaId} AND Dir_Emp_Cod = {clienteId} AND Dir_Emp_Tipo = 'Clientes'"
                Dim condContacto As String = $" cnt_sisemp = {empresaId} AND cnt_codemp = {clienteId} AND cnt_tipoemp = 'Clientes'"
                Dim condCliente As String = $" cli_sisemp = {empresaId} AND cli_codigo = {clienteId}"

                ' Eliminar en orden y verificar
                If Not DIREC.PDELETE(condDireccion) Then Throw New Exception("Error al eliminar direcciones.")
                If Not CONTAC.PDELETE(condContacto) Then Throw New Exception("Error al eliminar contactos.")
                If Not CLI.PDELETE(condCliente) Then Throw New Exception("Error al eliminar cliente.")

                transaccion.Commit()
                resultado = True
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")

            Catch ex As Exception
                transaccion.Rollback()
                MsgBox("Error during deletion: " & vbCrLf & ex.Message, MsgBoxStyle.Critical, "Error")
            End Try
        End Using

        Return resultado
    End Function


    Private Function ComprobarDatos() As Boolean
        Dim Comprobar As Boolean
        Dim strMsg As String

        strMsg = vbNullString
        'If celdaCodigo.Text = vbNullString Then
        '    strMsg = strMsg & vbCr
        '    MsgBox("Blank Customer Name", MsgBoxStyle.Critical, "AVISO")
        'End If
        If celdaRazonSocial.Text = vbNullString Then
            strMsg = strMsg & vbCr
            MsgBox("Blank Customer Name")
        End If
        If celdaDireccion.Text = vbNullString Then
            strMsg = strMsg & vbCr
            MsgBox("Blank Customer Address")
        End If
        If celdaTelefono.Text = vbNullString Then
            strMsg = strMsg & vbCr
            MsgBox("Blank Customer Phone")
        End If
        If celdaNIT.Text = vbNullString And celdaRegimen.Text = "Local" Then
            strMsg = strMsg & vbCr
            MsgBox("Every local client must indicate NIT")
        End If
        If celdaRegimen.Text = "" Then
            strMsg = strMsg & vbCr
            MsgBox("Blank Customer Regime")
        End If
        If celdaPais.Text = "" Then
            strMsg = strMsg & vbCr
            MsgBox("Customer Country Blank")
        End If
        If celdaManufactura.Text = "" Then
            strMsg = strMsg & vbCr
            MsgBox("Blanck manufacturing SI / NOT")
        End If

        If celdaMoneda.Text = "" Then
            strMsg = strMsg & vbCr
            MsgBox("Blank Customer Currency")
        End If

        If celdaMetodoCosteo.Text = "" Then
            strMsg = strMsg & vbCr
            MsgBox("Blank costing method")
        End If
        If Not IsNumeric(celdaLimiteCredito.Text) Then
            strMsg = strMsg & vbCr
            MsgBox("Amount of invalid credit")
        End If
        If Not IsNumeric(celdaPlazoCreditos.Text) Then
            strMsg = strMsg & vbCr
            MsgBox("Invalid credit card")
        End If
        If Trim(celdaCuentasxCobrar.Text) = vbNullString Then
            strMsg = strMsg & vbCr
            MsgBox("Blank Account Account")
        End If
        If Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 22 Then
        Else
            If rdHilo.Checked = True Then
                If celdaNumeroCta.Text = vbNullString Then
                    strMsg = strMsg & vbCr
                    MsgBox("Choose the account to affect")
                End If
            End If

        End If

        If InStr(1, "%", celdaDescuento.Text) > 0 Then
            strMsg = strMsg & vbCr
            MsgBox("Not allowed % sign in Authorized Discount")
            If Not IsNumeric(celdaDescuento.Text) Then
                strMsg = strMsg & vbCr
                MsgBox("Term of credit invalid")
            End If
        End If

        If strMsg = vbNullString Then
            Comprobar = True
        End If



        Return Comprobar
    End Function
    Private Function ComprobarFila() As Boolean
        Dim Comprobar As Boolean = True
        Try
            If dgDetalle.Rows.Count = 0 Then

                ' MsgBox("no hay filas de contactos")
                For i As Integer = 0 To dgDetalle.RowCount - 1


                    If dgDetalle.Rows(i).Cells("colNombre").Value = vbNullString Then
                        MsgBox("Row " & i + 1 & " Blank Contact Name")
                        Comprobar = False
                    End If
                    If dgDetalle.Rows(i).Cells("colCelular").Value = vbEmpty Then
                        MsgBox("Row " & i + 1 & " Blank Contact post")
                        Comprobar = False
                    End If
                    If dgDetalle.Rows(i).Cells("colCorreoElectronico").Value = vbNullString Then
                        If MsgBox("¿Correct email address?", vbQuestion + vbYesNo, "Email") = vbYes Then
                            Comprobar = False
                        End If
                    End If

                    If dgDetalle.Rows(i).Cells("colEstado").Value = vbNullString Then
                        MsgBox("Row" & i + 1 & "Blank Contact status")
                        Comprobar = False
                    End If
                    If dgDetalle.Rows(i).Cells("colEstado").Value <> "Activo" And
                        dgDetalle.Rows(i).Cells("colEstado").Value <> "Baja" Then
                        MsgBox("Row" & i + 1 & "Invalid Contact status")
                        Comprobar = False
                    End If
                Next
            Else
                Comprobar = True

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return Comprobar
    End Function
    Public Function CuentaHijaSuperior(ByVal Dato As String) As String
        Dim strDato As String
        Dim i As Integer


        i = NivelesDeCuenta(AplicarFormatoDeCuenta(Dato, strMascara))

        strDato = MascaraDeNivel(strMascara, i + 1, "9")
        CuentaHijaSuperior = Dato & strDato
    End Function
    Public Function MascaraDeNivel(ByVal Formato As String, Nivel As Integer, Optional ByVal Letra As String = "X") As String
        Dim varDato As Object
        Dim strDato As String

        If InStr(1, Formato, "-") > vbEmpty Then
            varDato = Split(Formato, "-")
            If UBound(varDato) >= (Nivel - 1) Then
                strDato = varDato(Nivel - 1)
                If Not (Letra = "X") Then
                    strDato = Replace(strDato, "X", Letra)
                End If
            End If
        End If
        MascaraDeNivel = strDato
    End Function
    'Prepara un texto para tener el formato de cuenta (XX.XX.XXX[...])
    Public Function FormatoDeCuenta(ByVal Dato As String, Optional Mascara As Boolean = True) As String
        Dim i As Integer
        Dim j As Integer
        Dim logLetra As Boolean
        Dim strLetra As String
        Dim strTexto As String

        'Quita espacios
        Dato = UCase(Replace(Dato, Space(1), vbNullString))
        logLetra = False
        For i = 1 To Len(Dato)
            strLetra = Mid(Dato, i, 1)
            Select Case strLetra
                Case "A" To "Z", 0 To 9
                    'Es una letra o un número
                    strLetra = IIf(Mascara, "X", strLetra)
                    logLetra = True
                    j = j + 1
                Case Else
                    'No permite más de un carácter como separador,
                    'tampoco que el separador esté al inicio
                    If logLetra Then
                        strLetra = "-"
                    Else
                        strLetra = vbNullString
                    End If
                    logLetra = False
            End Select
            strTexto = strTexto & strLetra
        Next
        'Si la cuenta no termina con una letra quita el último carácter
        If Not logLetra And (j > vbEmpty) Then
            strTexto = Microsoft.VisualBasic.Left(strTexto, Len(strTexto) - 1)
        End If
        FormatoDeCuenta = strTexto
    End Function
    Public Function AplicarFormatoDeCuenta(ByVal Dato As String, ByVal Formato As String) As String
        Dim i As Integer
        Dim intNivel As Integer
        Dim strDato As String
        Dim strFormato As String
        Dim strTexto As String
        Dim strParte As String
        Dim varParte As Object

        strDato = ExtraerNumeroDeCuenta(Dato)
        strFormato = FormatoDeCuenta(Formato)
        If Not ((strDato = vbNullString) Or (strFormato = vbNullString)) Then
            If InStr(1, strFormato, "-") = vbEmpty Then
                'No se encontró ningún separador
                strTexto = strDato
            Else
                varParte = Split(strFormato, "-")
                For i = vbEmpty To UBound(varParte)
                    If Not (strDato = vbNullString) Then
                        'Aun se tienen datos
                        If Not (strTexto = vbNullString) Then
                            'Agrega un separador al resultado
                            strTexto = strTexto & "-"
                        End If
                        If (Len(varParte(i)) > Len(strDato)) Then
                            'Es la última parte
                            strParte = strDato
                            strDato = vbNullString
                        Else
                            'Quita la parte correspondiente al nivel
                            strParte = Microsoft.VisualBasic.Left(strDato, Len(varParte(i)))
                            strDato = Microsoft.VisualBasic.Right(strDato, Len(strDato) - Len(strParte))
                        End If
                        'Agrega la parte correspondiente al resultado
                        strTexto = strTexto & strParte
                    End If
                Next
                If Not (strDato = vbNullString) Then
                    'La longitud del dato es mayor que la máscara
                    strTexto = vbNullString
                End If
            End If
            If Not (strTexto = vbNullString) Then
                intNivel = NivelesDeCuenta(strTexto)
                strParte = ExtraerDeCuenta(strFormato, intNivel)

                If Not (FormatoDeCuenta(strTexto) = strParte) Then
                    'No coincide con el formato de la cuenta para el nivel indicado
                    strTexto = vbNullString
                End If
            End If
        End If
        'Devuelve el resultado
        AplicarFormatoDeCuenta = strTexto
    End Function
    'Extrae la parte alfanumérica de una cuenta (no separadores)
    Public Function ExtraerNumeroDeCuenta(ByVal Dato As String) As String
        Dim i As Integer
        Dim strDato As String
        Dim strLetra As String
        Dim strTexto As String = STR_VACIO

        'Cambia a mayúsculas (para efectos de comparación) y quita los espacios
        strDato = Replace(UCase(Dato), Space(1), vbNullString)
        If Not (strDato = vbNullString) Then
            For i = 1 To Len(strDato)
                strLetra = Mid(strDato, i, 1)
                Select Case strLetra
                    Case "A" To "Z", 0 To 9
                        'Es una letra o número
                        strTexto = strTexto & strLetra
                End Select
            Next
        End If

        'Devuelve el resultado
        ExtraerNumeroDeCuenta = strTexto
    End Function
    Public Function ExtraerDeCuenta(ByVal Formato As String, Optional Niveles As Integer = (-1)) As String
        Dim strFormato As String
        Dim strTexto As String
        Dim strLetra As String
        Dim n As Integer
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer

        'Inicializar
        strTexto = vbNullString
        strFormato = FormatoDeCuenta(Formato, False)

        If Not (strFormato = vbNullString) Then
            n = NivelesDeCuenta(strFormato)
            If (Niveles <= vbEmpty) Then
                j = (n - (Niveles * (-1)))
            Else
                j = Niveles
            End If
            If (j > vbEmpty) And (j <= n) Then
                'Niveles es mayor que cero y menor o igual al máximo
                If j = n Then
                    strTexto = strFormato
                ElseIf Not (strFormato = vbNullString) Then
                    'Si es un formato válido, continuar con la extracción
                    k = 1
                    For i = 1 To Len(strFormato)
                        strLetra = Mid(strFormato, i, 1)
                        If (strLetra = "-") Then
                            k = k + 1
                        End If
                        If Not (k > j) Then
                            strTexto = strTexto & strLetra
                        Else
                            'Se ha llegado a los niveles solicitados
                            Exit For
                        End If
                    Next
                End If
            End If
        End If
        ExtraerDeCuenta = strTexto
    End Function
    Public Function NivelesDeCuenta(ByVal Dato As String) As Integer
        Dim strTexto As String
        Dim strLetra As String
        Dim i As Integer
        Dim n As Integer
        'Da formato al texto recibido
        strTexto = FormatoDeCuenta(Dato)
        n = vbEmpty
        If Not (strTexto = vbNullString) Then
            'Si el texto no está vacío tiene al menos un nivel
            n = n + 1
            For i = 1 To Len(strTexto)
                strLetra = Mid(strTexto, i, 1)
                If (strLetra = "-") Then
                    'Si es un separador incementa el contador
                    n = n + 1
                End If
            Next
        End If
        'Devuelve el resultado

        NivelesDeCuenta = n
    End Function
    Private Function ClienteDuplicado(ByVal intCodigo As Integer) As Boolean
        Dim LogResultado As Boolean
        Dim strNombre As String = STR_VACIO
        Dim strNit As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim DOC As MySqlDataReader
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand

        strNombre = Replace(Replace(Replace(UCase(Trim(celdaRazonSocial.Text)), " ", ""), ",", ""), ".", "")
        strNit = UCase(Trim(celdaNIT.Text))

        'Comprobar Nombre
        strSQL = "SELECT cli_codigo Codigo, cli_cliente Nombre FROM Clientes WHERE cli_sisemp = {empresa} AND NOT(cli_codigo={id}) AND UPPER(REPLACE(REPLACE(REPLACE(TRIM(cli_cliente),' ',''),',',''),'.',''))  = {nombre}"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{nombre}", "'" & strNombre & "'")
        strSQL = Replace(strSQL, "{id}", intCodigo)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If MsgBox("At least one customer with this description already exists" & vbCr & vbCr &
                "CODE: " & vbTab & REA.GetInt32("Codigo") & vbCr & "NAME: " & vbTab & REA.GetString("Nombre") & vbCr & vbCr &
                "Do you want to continue anyway?", vbExclamation + vbYesNo + vbDefaultButton2, "Aviso") = vbNo Then
                    LogResultado = True
                    Exit Function
                End If
            Loop
        End If

        'Comprobar NIT 
        If Not ((Trim(celdaNIT.Text) = vbNullString) Or (UCase(celdaNIT.Text) = "N/A")) Then
            strSQL2 = "SELECT cli_codigo Codigo, cli_nit Nit, cli_cliente Nombre FROM Clientes WHERE cli_sisemp = {empresa} AND NOT(cli_codigo={id}) AND TRIM(cli_nit) = {nit}"
            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{nit}", "'" & strNit & "'")
            strSQL2 = Replace(strSQL2, "{id}", intCodigo)
            MyCnn.CONECTAR = strConexion
            COM1 = New MySqlCommand(strSQL2, CON)
            DOC = COM1.ExecuteReader
            If DOC.HasRows Then
                Do While DOC.Read
                    If MsgBox("There is already at least one customer with this " & "NIT" & vbCr & vbCr &
                   "CODE: " & vbTab & DOC.GetInt32("Codigo") & vbCr & "NIT" & ": " & vbTab & DOC.GetString("NIT") & vbCr & vbCr & "NAME: " & vbTab & DOC.GetString("Nombre") & vbCr & vbCr &
                   "Do you want to continue anyway?", vbExclamation + vbYesNo + vbDefaultButton2, "Aviso") = vbNo Then
                        LogResultado = True
                        Exit Function
                    End If
                Loop
            End If
        End If
        Return LogResultado
    End Function
    Private Sub BloquearFunciones()
        celdaCodigo.ReadOnly = True
        celdaUsuario.ReadOnly = True
        celdaRegimen.ReadOnly = True
        celdaMoneda.ReadOnly = True
        celdaPais.ReadOnly = True
        celdaMetodoCosteo.ReadOnly = True
        celdaFormaPago.ReadOnly = True
        celdaCuentasxCobrar.ReadOnly = True
        celdaNumeroCta.ReadOnly = True
        celdaManufactura.ReadOnly = True
        celdaEstado.ReadOnly = True
        gbPosicionCuenta.Enabled = True
    End Sub


#End Region

#Region "Eventos"

    Private Sub frmClientes_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmClientes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If Borrar() = True Then
                MsgBox("Document deleted")
                cfun.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, CAT_ORD, celdaCodigo.Text)
                MostrarLista()
            Else
                MsgBox("ERROR: The Document could not be deleted")
            End If
        Else

            MsgBox("You do not have enough permissions to execute this action")
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
            Encabezado1.botonNuevo.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonBuscar.Enabled = True
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Dim cls As New clsFunciones
        Dim strSQL As String
        Dim strSQL1 As String
        Dim SubMascara As String = STR_VACIO
        Dim Valor As String = STR_VACIO
        Dim x3 As String = STR_VACIO
        Dim strMax As String = STR_VACIO
        Dim conec As MySqlConnection
        Dim COM As MySqlCommand
        Dim COM1 As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim strFila As String = STR_VACIO

        If logInsertar = True Then
            MostrarLista(False, True)
            reset()
            BloquearFunciones()
            gbPosicionCuenta.Enabled = False

            dgDetalle.ReadOnly = False

            strFila = "1" & "|"
            strFila &= "" & "|"
            strFila &= ""

            cfun.AgregarFila(dgDireccionCliente, strFila)

            dgDetalle.ReadOnly = False


            celdaSaldo.Text = STR_VACIO
            celdaDisponible.Text = STR_VACIO
            celdaTelefono.Text = vbNullString
            celdaNIT.Text = vbNullString
            celdaRegimen.Text = "Local"
            celdaManufactura.Text = "No"
            celdaMoneda.Text = "US$"
            celdaEstado.Text = "Activo"
            celdaFormaPago.Text = "CREDIT"
            celdaDescuento.Text = "0.00"
            celdaLimiteCredito.Text = "0.00"



            strSQL = "SELECT valor FROM {conta}.parametros_empresa WHERE empresa={empresa} AND parametro={parametro}"
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{parametro}", 2)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM2 = New MySqlCommand(strSQL, conec)
            SubMascara = COM2.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()


            strMascara = FormatoDeCuenta(SubMascara)
            intNiveles = NivelesDeCuenta(strMascara)

            strSQL = "SELECT valor FROM {conta}.parametros_empresa WHERE empresa = " & Sesion.IdEmpresa & " AND parametro = 23"
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Valor = COM.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            If Not (Valor = vbNullString) Then
                strMax = CuentaHijaSuperior(Valor)
            End If
            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 14 Then
                strSQL = "SELECT IFNULL(MAX(a.id_cuenta),0) FROM {conta}.cuentas a LEFT JOIN {conta}.cuentas b ON b.empresa=a.empresa AND b.id_cuenta=LPAD((a.id_cuenta+1), " & 13 & ",'0') WHERE a.empresa = " & Sesion.IdEmpresa & " AND a.pid = " & "'" & (Valor) & "'" & " AND LENGTH(a.id_cuenta)= " & 13 & " AND ISNULL(b.id_cuenta)"
            Else
                strSQL = "SELECT IFNULL(MAX(a.id_cuenta),0) FROM {conta}.cuentas a LEFT JOIN {conta}.cuentas b ON b.empresa=a.empresa AND b.id_cuenta=LPAD((a.id_cuenta+1)," & Len(strMax) & ",'0') WHERE a.empresa = " & Sesion.IdEmpresa & " AND a.pid = " & "'" & (Valor) & "'" & " AND LENGTH(a.id_cuenta)=" & Len(strMax) & " AND ISNULL(b.id_cuenta)"
            End If
            strSQL = Replace(strSQL, "{conta}", cfun.ContaEmpresa)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQL, conec)
            x3 = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()
            If Not Sesion.idGiro = 2 Then
                If x3 = 0 Then
                    celdaCuentasxCobrar.Text = Valor & "001"
                Else
                    celdaCuentasxCobrar.Text = "0" & (x3 + 1)
                End If
                celdaCxC.Text = "Cuenta Nueva"
            End If
            strSQL1 = " SELECT cat_desc "
                strSQL1 &= " From Empresas"
                strSQL1 &= " LEFT JOIN Catalogos ON emp_pais = cat_num"
                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM3 = New MySqlCommand(strSQL1, conec)
                celdaPais.Text = COM3.ExecuteScalar
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()

                Encabezado1.botonBorrar.Enabled = False
                Encabezado1.botonNuevo.Enabled = False
                botonImprimir.Enabled = False
                botonBuscar.Enabled = False
            Else
                MsgBox("you do not have permission to perform this action", vbCritical, "Notice")
        End If

    End Sub
    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click
        Try
            cfun.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        'MostrarLista(True, False)

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim Codigo As Integer = NO_FILA
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            Codigo = dgLista.SelectedCells(0).Value
            dgDireccionCliente.ReadOnly = False
            reset()
            Seleccionar(Codigo)
            BloquearFunciones()
            gbPosicionCuenta.Enabled = False
            botonUp.Enabled = True
            'botonDown.Enabled = False
            celdaCodigo.ReadOnly = True
            For i As Integer = 0 To dgDetalle.RowCount - 1
                dgDetalle.Rows(i).Cells("colEstatus").Value = "2"
                dgDetalle.Rows(i).Cells("colEliminar").Value = "3"
                dgDetalle.Rows(i).Cells("colEstado").ReadOnly = True
            Next
            For j As Integer = 0 To dgDireccionCliente.RowCount - 1
                dgDireccionCliente.Rows(j).Cells("colEstadoD").Value = "1"
            Next

            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub dgDetalle_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)
        cfun.ValidarFilaGrid(dgDetalle, "colNombre")
        cfun.ValidarFilaGrid(dgDetalle, "colPuesto")
        cfun.ValidarFilaGrid(dgDetalle, "colCelular")
        cfun.ValidarFilaGrid(dgDetalle, "colCorreoElectronico")
        cfun.ValidarFilaGrid(dgDetalle, "colEstado")
    End Sub

    Private Sub botonFormaPago_Click_1(sender As Object, e As EventArgs) Handles botonFormaPago.Click
        '  Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = "Way to Pay"
            'frm.Campos = " DISTINCT(cli_forma) Pago"
            'frm.Tabla = " Clientes"
            'frm.FiltroText = " Enter a Payment method to filter"
            'frm.Filtro = " cli_forma "
            'frm.Condicion = "cli_forma >= 0"

            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaFormaPago.Text = frm.LLave
            'End If
            frm.Mensaje = " Way to Pay"
            frm.Opciones = "L/C |" & "CASH |" & "CREDIT |" & " PENDING"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaFormaPago.Text = "L/C"
                    Case 1
                        celdaFormaPago.Text = "CASH"
                    Case 2
                        celdaFormaPago.Text = "CREDIT"
                    Case 3
                        celdaFormaPago.Text = "PENDING"
                End Select
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonUsuario_Click_1(sender As Object, e As EventArgs) Handles botonUsuario.Click

        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "per_sisemp = {empresa} and per_estado  = 1"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = " User"
            frm.Campos = " per_usuario Usuario "
            frm.Tabla = " Personal "
            frm.FiltroText = " Enter the user to filter"
            frm.Filtro = " per_usuario "
            frm.Condicion = " per_sisemp=" & Sesion.IdEmpresa & " AND per_estado = 1 "
            frm.Ordenamiento = " per_usuario"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                ''celda.Text = frm.LLave
                celdaUsuario.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonRegimen_Click(sender As Object, e As EventArgs) Handles botonRegimen.Click
        '  Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = "Regime"
            'frm.Campos = " DISTINCT (cli_exterior) Regimen"
            'frm.Tabla = " Clientes "
            'frm.FiltroText = " Enter the name of the Regime to filter"
            'frm.Filtro = " cli_exterior "
            'frm.Condicion = "cli_exterior >=0"

            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaRegimen.Text = frm.LLave
            'End If
            frm.Mensaje = " Regime"
            frm.Opciones = "Local |" & "Exterior"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaRegimen.Text = "Local"
                    Case 1
                        celdaRegimen.Text = "Exterior"
                End Select
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonPais_Click(sender As Object, e As EventArgs) Handles botonPais.Click

        Dim frm As New frmSeleccionar

        Try
            ' Propiedades de consulta 
            frm.Campos = " cat_num ID , cat_desc Description "
            frm.Tabla = " Catalogos "
            frm.Condicion = " cat_clase = 'paises' "
            frm.Filtro = " cat_desc "
            frm.Limite = " 20"
            ' Propiedades de formulario 
            frm.Titulo = " Catalogs "
            frm.FiltroText = " Enter the name of the country to filter"

            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then
                celdaIdPais.Text = frm.LLave
                celdaPais.Text = frm.Dato

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonMoneda_Click_1(sender As Object, e As EventArgs) Handles botonMoneda.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num ID , cat_clave Moneda"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the name of the currency to filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonEstado_Click_1(sender As Object, e As EventArgs) Handles botonEstado.Click
        ' Dim frm As New frmSeleccionar
        Dim frm As New frmOption
        Try
            'frm.Titulo = "State"
            'frm.Campos = " DISTINCT(cli_status) Estado "
            'frm.Tabla = " Clientes"
            'frm.FiltroText = " Enter status to filter"
            'frm.Filtro = " cli_status "
            'frm.Condicion = "cli_status >= 0"

            'frm.ShowDialog(Me)
            'If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '    celdaEstado.Text = frm.LLave
            'End If
            frm.Mensaje = "State"
            frm.Opciones = "Activo |" & "Baja"
            frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        celdaEstado.Text = "Activo"
                    Case 1
                        celdaEstado.Text = "Baja"
                End Select
            Else
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonCuentasxCobrar_Click(sender As Object, e As EventArgs) Handles botonCuentasxCobrar.Click

        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        If Sesion.IdEmpresa = 22 Then
            strCondicion = "empresa = {empresa} and id_cuenta IN('110301001','110302001','110303001','110303002','110404001','110405001') "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        End If
        ' strCondicion = "cli_sisemp = {empresa} "

        Try
            frm.Titulo = "Nomenclature"
            frm.Campos = " id_cuenta Cuenta, nombre Nombre "
            frm.Tabla = cfun.ContaEmpresa & ".cuentas "
            frm.FiltroText = " Enter the name of the account to be filtered"
            frm.Filtro = " nombre "
            If (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa = 18) Or (Sesion.IdEmpresa = 19) Then
                frm.Condicion = "CHARACTER_LENGTH(id_cuenta) > 6"
            ElseIf Sesion.IdEmpresa = 22 Then
                frm.Condicion = strCondicion
            Else
                frm.Condicion = "id_cuenta >= 0"
            End If
            frm.Ordenamiento = "id_cuenta"
            frm.TipoOrdenamiento = " ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaCuentasxCobrar.Text = frm.LLave
                celdaCxC.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function SQLBALANCE(Codigo As Integer) As String
        Dim strSQL As String


        strSQL = " SELECT COALESCE(SUM(ECta_Crgo_Ext),0) Cargos, COALESCE(SUM(ECta_Abno_Ext),0) Abonos "
        strSQL &= " FROM ECtaCte"
        strSQL &= " WHERE ECta_tipoemp = 'Clientes' AND ECta_codemp = {numero} AND ECta_Sis_Emp ={empresa}; "

        strSQL = Replace(strSQL, "{numero}", Codigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


        Return strSQL
    End Function
    Private Function SQLClientesLista(Codigo As Integer) As String
        Dim strSQL As String

        strSQL = " SELECT a.*, b.cat_desc AS cat_pais, c.cat_clave AS cat_moneda, c.cat_sist"
        strSQL &= " FROM Catalogos b, Catalogos c, Clientes a"
        strSQL &= " WHERE b.cat_num = cli_pais AND c.cat_num = cli_moneda AND cli_sisemp = {empresa} AND cli_codigo ={numero};"
        strSQL = Replace(strSQL, "{numero}", Codigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function
    Private Function SQLDireccion(Codigo As Integer) As String
        Dim strSQL As String
        strSQL = " SELECT DISTINCT(cl.cli_direccion) Direccion, cl.cli_cliente Nombre "
        strSQL &= " FROM Clientes cl"
        strSQL &= " LEFT JOIN Contactos ct ON ct.cnt_sisemp = cl.cli_sisemp AND ct.cnt_tipoemp = 'Clientes' AND ct.cnt_codemp = cl.cli_codigo"
        strSQL &= " LEFT JOIN Direcciones dr ON dr.Dir_Sis_Emp = cl.cli_sisemp AND dr.Dir_Emp_Cod = cl.cli_codigo  "
        strSQL &= "  WHERE cl.cli_sisemp = {empresa} AND cl.cli_codigo = {numero} "


        strSQL = Replace(strSQL, "{numero}", Codigo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)


        Return strSQL
    End Function
    Private Function VerificarDireccion() As String
        Dim strSQL As String
        strSQL = vbNullString
        strSQL = strSQL & " SELECT Dir_Nombre Nombre, Dir_Direccion Direccion "
        strSQL = strSQL & "     From Direcciones "
        strSQL = strSQL & "     WHERE Dir_Sis_Emp = {empresa} AND Dir_Emp_Tipo = {tipo} AND Dir_Emp_Cod ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{tipo}", "'" & strTipo & "'")
        strSQL = Replace(strSQL, "{codigo}", celdaCodigo.Text)

        VerificarDireccion = strSQL
    End Function
    Private Sub botonMetodoCosteo_Click(sender As Object, e As EventArgs) Handles botonMetodoCosteo.Click
        Dim frm As New frmOption

        frm.Opciones = "CIF |" & "FOB |" & "Local"
        frm.ShowDialog(Me)
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Select Case frm.Seleccion
                Case 0
                    celdaMetodoCosteo.Text = "CIF"
                Case 1
                    celdaMetodoCosteo.Text = "FOB"
                Case 2
                    celdaMetodoCosteo.Text = "Local"
            End Select
        Else
            Exit Sub

        End If
    End Sub
    Private Function sqlInsertarDireccion() As String
        Dim strSQL As String
        strSQL = vbNullString
        strTipo = "Clientes"
        strSQL = strSQL & " INSERT INTO Direcciones (Dir_Sis_Emp, Dir_Emp_Tipo, Dir_Emp_Cod, Dir_Lin, Dir_Nombre, Dir_Direccion) VALUES(" & Sesion.IdEmpresa & ", " & "'" & strTipo & "'" & ", " & celdaCodigo.Text & ", " & iFila & ", " & "'" & strLugar & "'" & ", " & "'" & strDireccion & "'" & ")"
        Return strSQL
    End Function

    Private Function GuardarCliente() As Boolean
        Dim logResultado As Boolean = True
        Dim cHDR As New Tablas.TCLIENTES
        cHDR.CONEXION = strConexion
        Try
            cHDR.CLI_SISEMP = Sesion.IdEmpresa
            cHDR.CLI_CODIGO = celdaCodigo.Text
            cHDR.CLI_CLIENTE = celdaRazonSocial.Text
            cHDR.CLI_NOMBRE = IIf(celdaDescripcionCorta.Text = vbNullString, "NULL", celdaDescripcionCorta.Text)
            cHDR.CLI_DIRECCION = celdaDireccion.Text
            cHDR.CLI_TELEFONO = celdaTelefono.Text
            cHDR.CLI_NIT = celdaNIT.Text
            cHDR.CLI_FORMA = celdaFormaPago.Text
            cHDR.CLI_MONTOCR = celdaLimiteCredito.Text
            cHDR.CLI_PLAZOCR = celdaPlazoCreditos.Text

            cHDR.CLI_DSCTO = celdaDescuento.Text
            cHDR.CLI_STATUS = celdaEstado.Text
            cHDR.CLI_EXTERIOR = celdaRegimen.Text
            cHDR.CLI_MAQUILA = celdaManufactura.Text
            cHDR.CLI_PAIS = CInt(celdaIdPais.Text)
            cHDR.CLI_MONEDA = celdaIdMoneda.Text
            cHDR.CLI_CMETHOD = celdaMetodoCosteo.Text
            cHDR.CLI_OBSERVACIONES = celdaPaymentInfo.Text
            cHDR.CLI_USUARIO = celdaUsuario.Text
            cHDR.CLI_CLASIFICACION = IIf(celdaIdClasificacion.Text = vbNullString, 0, celdaIdClasificacion.Text)
            cHDR.CLI_CATEGORIA = IIf(celdaIdCategoria.Text = vbNullString, 0, celdaIdCategoria.Text)
            cHDR.CLI_REGISTRONO = IIf(celdaRegistro.Text = vbNullString, "NULL", celdaRegistro.Text)
            cHDR.CLI_GIRO = IIf(celdaGiro.Text = vbNullString, "NULL", celdaGiro.Text)
            If rdCobro.Checked = True Then
                cHDR.CLI_TIPO = 2
                cHDR.CLI_CUENTA = STR_VACIO
            ElseIf rdDestino.Checked = True Then
                cHDR.CLI_TIPO = INT_UNO
                cHDR.CLI_CUENTA = STR_VACIO
            Else
                cHDR.CLI_TIPO = INT_CERO
                cHDR.CLI_CUENTA = celdaCuentasxCobrar.Text
            End If


            If Me.Tag = "Nuevo" Then

                If cHDR.PINSERT = False Then
                    MsgBox(cHDR.MERROR.ToString & "Could not save the document ", MsgBoxStyle.Critical)
                    logResultado = False
                End If
            ElseIf Me.Tag = "Mod" Then

                If cHDR.PUPDATE = False Then
                    MsgBox(cHDR.MERROR.ToString & "Could not modify the document", MsgBoxStyle.Critical)
                    logResultado = False
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try



        Return logResultado
    End Function


    Private Sub botonManucfactura_Click(sender As Object, e As EventArgs) Handles botonManucfactura.Click
        Dim frm As New frmOption

        frm.Opciones = "SI |" & "NO"
        frm.ShowDialog(Me)
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Select Case frm.Seleccion
                Case 0
                    celdaManufactura.Text = "SI"
                Case 1
                    celdaManufactura.Text = "NO"
            End Select
        Else
            Exit Sub

        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim strSQL2 As String
        Dim strSQL3 As String
        Dim conec As MySqlConnection
        Dim COM4 As MySqlCommand
        Dim COM3 As MySqlCommand
        Dim frmMsg As New frmPedirComentarios
        Dim cls As New clsContabilidad

        If Me.Tag = "Nuevo" Then
            If logInsertar = True Then

                If ComprobarDatos() Then
                    If ComprobarFila() = True Then

                        strSQL2 = " SELECT IFNULL(MAX(cli_codigo) + 1,1) FROM Clientes
                                        WHERE cli_sisemp = " & Sesion.IdEmpresa

                        conec = New MySqlConnection(strConexion)
                        conec.Open()
                        COM4 = New MySqlCommand(strSQL2, conec)
                        celdaCodigo.Text = COM4.ExecuteScalar
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                        If ClienteDuplicado(celdaCodigo.Text) Then
                            Exit Sub
                        End If
                        Encabezado1.botonGuardar.Enabled = False
                        If GuardarCliente() = True Then
                            GuardarDetalle()
                            If rdHilo.Checked = True Then
                                If (Sesion.IdEmpresa = 16) Or (Sesion.IdEmpresa = 15) Or (Sesion.IdEmpresa >= 18 And Sesion.IdEmpresa <= 21) Then
                                    If Not celdaCuentasxCobrar.Text = vbNullString Then
                                        If rdHilo.Checked = True Then
                                            strSQL2 = STR_VACIO
                                            strSQL2 = " update {conta}.cuentas c 
                                            SET c.id_nomenclatura = '{id}'
                                            WHERE c.empresa = {emp} AND c.id_cuenta = '{cta}'"

                                            strSQL2 = strSQL2.Replace("{emp}", Sesion.IdEmpresa)
                                            strSQL2 = strSQL2.Replace("{cta}", celdaCuentasxCobrar.Text)
                                            strSQL2 = strSQL2.Replace("{id}", celdaNumeroCta.Text)
                                            strSQL2 = strSQL2.Replace("{conta}", Sesion.BaseConta)

                                            MyCnn.CONECTAR = strConexion
                                            COM3 = New MySqlCommand(strSQL2, CON)
                                            COM3.ExecuteNonQuery()
                                        End If
                                    End If
                                ElseIf Sesion.IdEmpresa = 22 Then

                                Else
                                    cls.CodigoConta("Clientes", "Guardar", Codigo:=celdaCuentasxCobrar.Text, Nombre:=celdaRazonSocial.Text, NIT:=celdaNIT.Text, ID:=celdaCodigo.Text, Tipo:=0, padre:=NO_FILA, ctaNomenclatura:=celdaNumeroCta.Text)
                                End If

                            End If

                            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaCodigo.Text, -1, -1, -1, frmMsg.celdaInfo.Text)

                            For iFila As Integer = 0 To dgDireccionCliente.RowCount - 1
                                If Me.Tag = "Nuevo" Then
                                    strLugar = celdaRazonSocial.Text
                                    strDireccion = celdaDireccion.Text
                                ElseIf Me.Tag = "Mod" Then
                                    strLugar = dgDireccionCliente.Rows(iFila).Cells("colNom").Value
                                    strDireccion = dgDireccionCliente.Rows(iFila).Cells("colDireccion").Value
                                End If

                                MyCnn.CONECTAR = strConexion
                                strSQL3 = sqlInsertarDireccion()
                                COM3 = New MySqlCommand(strSQL3, CON)
                                COM3.ExecuteNonQuery()

                            Next

                        End If

                    Else
                        MsgBox("Rows Not FOUND")
                        Exit Sub
                    End If
                    If panelLista.Visible = True Then

                    Else
                        MostrarLista(True)
                        Encabezado1.botonNuevo.Enabled = True
                        Encabezado1.botonGuardar.Enabled = True
                    End If
                Else
                    Exit Sub
                End If
            End If

        ElseIf Me.Tag = "Mod" Then
            If logEditar = True Then
                If ComprobarDatos() Then
                    If ComprobarFila() Then
                        'Agregar procedimiento que actualice el campo de nomenclatura en la tabla cuentas
                        '********************************************************************************
                        If Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 22 Then
                        Else
                            If rdHilo.Checked = True Then
                                If celdaNumeroCta.Text = "N/A" Or celdaNumeroCta.Text = vbNullString Then
                                    MsgBox("Choose the account to affect", vbInformation, "Notice")
                                    Exit Sub

                                End If
                            End If
                        End If

                        frmMsg.ShowDialog(Me)

                        If frmMsg.DialogResult = System.Windows.Forms.DialogResult.OK Then

                            cFunciones.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaCodigo.Text, -1, -1, -1, frmMsg.celdaInfo.Text)

                            GuardarCliente()
                            GuardarDetalle()
                            GuardarDireccion()
                            If Sesion.IdEmpresa = 9 Then
                            Else
                                If rdHilo.Checked = True Then
                                    strSQL2 = STR_VACIO
                                    strSQL2 = " update {conta}.cuentas c 
                                            SET c.id_nomenclatura = '{id}'
                                            WHERE c.empresa = {emp} AND c.id_cuenta = '{cta}'"

                                    strSQL2 = strSQL2.Replace("{emp}", Sesion.IdEmpresa)
                                    strSQL2 = strSQL2.Replace("{cta}", celdaCuentasxCobrar.Text)
                                    strSQL2 = strSQL2.Replace("{id}", celdaNumeroCta.Text)
                                    strSQL2 = strSQL2.Replace("{conta}", Sesion.BaseConta)

                                    MyCnn.CONECTAR = strConexion
                                    COM3 = New MySqlCommand(strSQL2, CON)
                                    COM3.ExecuteNonQuery()
                                End If
                            End If

                        End If


                    Else
                        MsgBox("Rows Not Found")
                        Exit Sub
                    End If
                    If panelLista.Visible = True Then
                    Else
                        MostrarLista(True)
                        Encabezado1.botonNuevo.Enabled = True
                        Encabezado1.botonGuardar.Enabled = True
                    End If
                End If
            Else
                MsgBox("You do not have permission to modify clients")
                Encabezado1.botonGuardar.Enabled = True
                Exit Sub
            End If
        Else
            MsgBox("you dont have Permission")
            Encabezado1.botonGuardar.Enabled = True
            Exit Sub
        End If
        'MsgBox("Save Succesful")
        Exit Sub
    End Sub

    Private Sub botonDown_Click(sender As Object, e As EventArgs)
        Dim strFila As String = STR_VACIO
        strFila = "" & "|"
        strFila &= "" & "|"
        strFila &= ""

        cfun.AgregarFila(dgDireccionCliente, strFila)

        dgDetalle.ReadOnly = False
    End Sub

    Private Sub botonUp_Click(sender As Object, e As EventArgs) Handles botonUp.Click
        Dim strFila As String = STR_VACIO
        Dim intUltimoDato As Integer = NO_FILA

        For i As Integer = 0 To dgDireccionCliente.RowCount - 1
            intUltimoDato = CInt(dgDireccionCliente.Rows(i).Cells("colCodigo").Value)
        Next
        strFila = intUltimoDato + 1 & "|"
        strFila &= "" & "|"
        strFila &= "" & "|"
        strFila &= "" & "|"
        strFila &= "0"

        cfun.AgregarFila(dgDireccionCliente, strFila)

        dgDetalle.ReadOnly = False
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Dim frm As New frmOption
        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        Else
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 4
                    frm.Opciones = "Activo |" & "Baja"
                    frm.ShowDialog(Me)
                    If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        Select Case frm.Seleccion
                            Case 0
                                dgDetalle.CurrentRow.Cells("colEstado").Value = "Activo"
                            Case 1
                                dgDetalle.CurrentRow.Cells("colEstado").Value = "Baja"
                        End Select
                    Else
                        Exit Sub
                    End If
            End Select
        End If
    End Sub
    Private Sub botonArriba_Click(sender As Object, e As EventArgs) Handles botonArriba.Click
        Dim strFila As String = STR_VACIO

        strFila = "" & "|"
        strFila &= "" & "|"
        strFila &= "" & "|"
        strFila &= "" & "|"
        strFila &= "" & "|"
        strFila &= "0" & "|"
        strFila &= "1"

        cfun.AgregarFila(dgDetalle, strFila)

        dgDetalle.ReadOnly = False
        For i As Integer = 0 To dgDetalle.RowCount - 1
            dgDetalle.Rows(i).Cells("colEstado").ReadOnly = True
        Next
    End Sub

    Private Sub botonAbajo_Click(sender As Object, e As EventArgs) Handles botonAbajo.Click
        Try
            Dim Count As Integer
            If dgDetalle.SelectedRows Is Nothing Then Exit Sub
            If dgDetalle.Rows.Count > 0 Then
                Count = dgDetalle.Rows.GetRowCount(DataGridViewElementStates.Selected)
                For i As Integer = 0 To Count - 1
                    If MsgBox("You sure you want to delete the row " & "OF THE ORDER " &
                    CStr(dgDetalle.SelectedCells(0).Value) & ", " &
                    CStr(dgDetalle.SelectedCells(1).Value) & ", " &
                    Val(dgDetalle.SelectedCells(2).Value) & " , " &
                    CStr(dgDetalle.SelectedCells(3).Value) & " ," &
                    CStr(dgDetalle.SelectedCells(4).Value) & "?", vbQuestion + vbYesNo + vbDefaultButton2) =
                    vbYes Then
                        If dgDetalle.SelectedCells(6).Value = 1 Or dgDetalle.SelectedCells(6).Value = 2 Then
                            dgDetalle.SelectedCells(6).Value = 3
                            If dgDetalle.SelectedCells(6).Value = 3 Then
                                dgDetalle.CurrentRow.Visible = False
                            End If
                        ElseIf dgDetalle.Rows(i).Selected = Nothing Then
                            '  dgDetalle.SelectedCells(6).Value = 3
                            ' dgDetalle.CurrentRow.Visible = False
                            dgDetalle.Rows.RemoveAt(dgDetalle.RowCount - 1)
                        End If
                    End If
                Next
            Else
                Exit Sub
            End If
            dgDetalle.ReadOnly = False
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(0, 0, 0, "Clientes", dgLista.CurrentRow.Cells(0).Value)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub btnClasificacion_Click(sender As Object, e As EventArgs) Handles btnClasificacion.Click

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Catalogs Country Invoice"
            frm.Campos = " cat_num ID , cat_desc Description "
            frm.Tabla = "Catalogos"
            frm.FiltroText = "Enter the client country invoice"
            frm.Filtro = "cat_desc"
            frm.Condicion = "cat_clase = 'Paises'"
            frm.Limite = " 20"
            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdClasificacion.Text = frm.LLave
                celdaClasificacion.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCategoria_Click(sender As Object, e As EventArgs) Handles botonCategoria.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Category"
            frm.Campos = "cat_num ID ,cat_desc Category"
            frm.Tabla = "Catalogos"
            frm.FiltroText = "Enter the classification of client"
            frm.Filtro = "cat_desc"
            frm.Condicion = "cat_clase = 'CategoriaClt'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCategoria.Text = frm.LLave
                celdaCategoria.Text = frm.Dato
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
    End Sub

    Private Sub frmClientes_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        Fprincipal.BarraDeTareas1.QuitarFormulario(Key)
    End Sub

    Private Sub botonCuentaNomenclatura_Click(sender As Object, e As EventArgs) Handles botonCuentaNomenclatura.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "n.idEmpresa = {empresa} AND n.Pertenencia = 1102 "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Nomenclature"
            frm.Campos = " n.idCuenta Cuenta, n.NombreEspanol Nombre "
            frm.Tabla = cfun.ContaEmpresa & ".nomenclatura n "
            frm.FiltroText = " Enter the account to be filtered"
            frm.Filtro = " n.idCuenta "
            frm.Condicion = strCondicion
            frm.Ordenamiento = "n.idCuenta"
            frm.TipoOrdenamiento = " ASC"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaNumeroCta.Text = frm.LLave
                CeldaNombreCta.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub panelDocumento_Paint(sender As Object, e As PaintEventArgs) Handles panelDocumento.Paint

    End Sub


#End Region

End Class



