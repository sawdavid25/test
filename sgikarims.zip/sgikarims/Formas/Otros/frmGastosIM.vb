﻿Public Class frmGastosIM

#Region "variables"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim dicRequisitos As New Dictionary(Of Integer, Integer)
    Dim dicAccesos As New Dictionary(Of Integer, Integer)
#End Region
#Region "propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "funciones"
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            paneldocumento.Dock = DockStyle.None
            paneldocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Gastos Importaciones")
            'Cargar Datos
            ' cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = "Nuevo"
        Else
            BloquearBotones(True)
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            paneldocumento.Dock = DockStyle.Fill
            paneldocumento.Visible = True
            If logInsert = False Then
                Me.Tag = "Mod"
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                BloquearBotones(False, True)
            Else
                Me.Tag = "Nuevo"

                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                BloquearBotones(False)
            End If
            dglista.DataSource = Nothing
        End If
    End Sub
    Private Function sqlcargarGastosIM(ByVal intcodigo As Integer) As String
        Dim str_sql As String
        str_sql = " SELECT cat_num, cat_desc  "
        str_sql &= "     FROM Catalogos c "
        str_sql &= "        WHERE c.cat_clase ='GastosI'  "
        Return str_sql
    End Function

    Private Sub CargarLista()
        Dim str_sql As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            str_sql = sqlGastosIM()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(str_sql, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dglista.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("cat_num") & "|"
                    strFila &= REA.GetString("cat_desc")
                    cFunciones.AgregarFila(dglista, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logResultado As Boolean = False
        Try
            If celdadescripcion.Text.Length > 0 Then
                logResultado = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function sqlGastosIM() As String
        Dim str_sql As String
        str_sql = " SELECT cat_num, cat_desc "
        str_sql &= "   FROM Catalogos c    "
        str_sql &= "        WHERE c.cat_clase ='GastosI' "
        Return str_sql
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True, Optional logBorrar As Boolean = False)
        If logBloquear = True Then
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonBorrar.Enabled = False
        Else
            Encabezado1.botonGuardar.Enabled = True
            Encabezado1.botonBorrar.Enabled = True

        End If
    End Sub
    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function Nuevo() As Integer
        Dim intResultado As Integer = NO_FILA
        Dim str_sql As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            str_sql = " select max(cat_num)+1 from Catalogos  "

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(str_sql, CON)
            intResultado = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intResultado
    End Function
    Private Function SQLENCABEZADO(ByVal codigo As Integer) As String
        Dim str_sql As String = STR_VACIO

        str_sql = "  select cat_num,  cat_desc "
        str_sql &= "     from Catalogos c "
        str_sql &= "   Where  cat_num = {codigo} "
        str_sql = Replace(str_sql, "{codigo}", codigo)
        Return str_sql
    End Function

    Public Sub CargarEncabezado(ByVal Codigo As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQL = SQLENCABEZADO(Codigo)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdacodigo.Text = REA.GetInt32("cat_num")
                    celdadescripcion.Text = REA.GetString("cat_desc")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function guardarGastosI() As Boolean
        Dim logresultado As Boolean
        Dim gastos As New clsCatalogos

         Try
            gastos.CONEXION = strConexion

            gastos.CAT_DESC = celdadescripcion.Text
            gastos.CAT_CLASE = "GastosI"
            gastos.CAT_CLAVE = "GastosI"

            If Me.Tag = "Nuevo" Then
                celdacodigo.Text = Nuevo()
                gastos.CAT_NUM = celdacodigo.Text

                If logInsertar = True Then
                    Encabezado1.botonBorrar.Enabled = False
                    If gastos.Guardar = False Then
                        MsgBox(gastos.MERROR.ToString & "Could not save this document")

                        logresultado = False
                    Else
                        logresultado = True
                    End If
                Else
                    MsgBox("Does Not have Permissions ")
                End If
                cFunciones.EscribirRegistro("Gastos", clsFunciones.AccEnum.acAdd, 0, 0, 0, celdacodigo.Text, celdadescripcion.Text)

            ElseIf Me.Tag = "mod" Then
                gastos.CAT_NUM = celdacodigo.Text
                cFunciones.EscribirRegistro("Gastos", clsFunciones.AccEnum.acUpdate, 0, 0, 0, celdacodigo.Text, celdadescripcion.Text)
                If logEditar Then

                    If gastos.Actualizar = False Then
                        MsgBox(gastos.MERROR.ToString)
                        logresultado = False
                    Else
                        logresultado = True
                    End If
                Else
                    MsgBox("Does Not have Permissions ")
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logresultado
    End Function

    Private Function borrarGastosIM() As Boolean
        Dim logresultado As Boolean
        Dim catalogo As New clsCatalogos
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            MyCnn.CONECTAR = strConexion
            strSQL = "  DELETE FROM Catalogos WHERE cat_num = {codigo}  "
            strSQL = Replace(strSQL, "{codigo}", celdacodigo.Text)
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM = Nothing
            cFunciones.EscribirRegistro("Gastos", clsFunciones.AccEnum.acDelete, 0, 0, 0, celdacodigo.Text, celdadescripcion.Text)
            logresultado = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logresultado

    End Function
    Public Sub reset()
        celdacodigo.Text = INT_CERO
        celdadescripcion.Text = ""
    End Sub
#End Region

#Region "Eventos"
    Private Sub frmGastosIM_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        MostrarLista()
        Me.Tag = "Nuevo"
    End Sub

    Private Sub dglista_DoubleClick(sender As Object, e As EventArgs) Handles dglista.DoubleClick
        Dim int_codigo As Integer
        If dglista.SelectedRows.Count = INT_CERO Then Exit Sub
        If logConsultar Then
            int_codigo = dglista.SelectedCells(0).Value
            reset()
            Me.Tag = "Mod"
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonBorrar.Enabled = True
            MostrarLista(False)
            CargarEncabezado(int_codigo)
        Else
            MsgBox("Does Not have Permissions ")
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarDatos() = True Then

            If guardarGastosI() = True Then

                MostrarLista(False)
            End If
        Else
            MsgBox("Ingrese los datos")
        End If
        If ComprobarDatos() = True Then

            MostrarLista(True)
        End If
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If paneldocumento.Visible = True Then
            MostrarLista()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar Then
            reset()
            MostrarLista(False, True)
            Encabezado1.botonBorrar.Enabled = False
        Else
            MsgBox("Does Not have Permissions ")
        End If


    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar Then
            If MsgBox("Esta seguro que desea eliminar", vbQuestion + vbYesNo, "Verificacion") = vbYes Then
                If borrarGastosIM() = True Then
                    MostrarLista(True)
                End If
            Else
            End If
        Else

            MsgBox("Does Not have Permissions ")
        End If
    End Sub

    Private Sub dglista_KeyDown(sender As Object, e As KeyEventArgs) Handles dglista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dglista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dglista.SelectedCells(0).Value, 0, 0)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmGastosIM_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub
#End Region

End Class