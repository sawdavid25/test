﻿Public Class frmGastoProduccion
#Region "Variables"
    Dim strKey As String = STR_VACIO
    Dim CodigosMat As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intTipoDoc As Integer
    Dim Tbl_Documentos As String = "Gastos_Produccion"
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region
#Region "Procedimientos"
    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT g.Anio , g.idGastoProduccion Numero , g.Fecha "
        strSQL &= "     FROM Gastos_Produccion g"
        strSQL &= "         WHERE g.idEmpresa = {empresa}"

        If checkFecha.Checked = True Then

            strSQL &= " AND (g.Fecha BETWEEN '{fechainicio}' AND '{fechafin}') "

            strSQL = Replace(strSQL, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafin}", dtpFin.Value.ToString(FORMATO_MYSQL))
        End If
        strSQL &= "  GROUP BY g.idGastoProduccion"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        ' strSQL = Replace(strSQL, "{NumProceso}", NumProceso)

        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        strSQL = SQLListaPrincipal()

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                    cFunciones.AgregarFila(dgLista, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function NuevaLinea() As Integer
        Dim intLInea As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT IFNULL(MAX(d.Linea),0)+1 "
            strSQL &= "     FROM Gastos_Produccion d"
            strSQL &= "         WHERE d.idEmpresa = {empresa} AND d.Anio = {anio} AND d.idGastoProduccion = {numero}  "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAnio.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intLInea = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return intLInea
    End Function
    Private Function NuevoDocumento() As Integer
        Dim intNumero As Integer = NO_FILA
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " SELECT IFNULL(MAX(g.idGastoProduccion),0) + 1  Numero "
            strSQL &= "     FROM Gastos_Produccion g "
            strSQL &= "         WHERE g.idEmpresa = {empresa}  "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intNumero = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intNumero
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = True)
        'Muestra Lista Principal
        If logMostrar = True Then
            panelListaPrincipal.Visible = True
            panelListaPrincipal.Dock = DockStyle.Fill
            PanelDocumento.Visible = False
            PanelDocumento.Dock = DockStyle.None
            BarraTitulo1.CambiarTitulo("Production Expenses")
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

            dtpInicio.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 30)
            dtpFin.Value = DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

            ListaPrincipal()

        Else
            'Muestra Detalle
            panelListaPrincipal.Visible = False
            panelListaPrincipal.Dock = DockStyle.None
            PanelDocumento.Visible = True
            PanelDocumento.Dock = DockStyle.Fill

            'Verifica si se va a crear un nuevo documento o se va modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                '      LimpiarCampos()
                'CargarCostos()
                '        ColocaMoneda()
            End If
        End If
    End Sub
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If

    End Sub
    Private Sub Accesos()
        Dim cAcesos As New clsAccesos

        Try
            If cAcesos.Accesos(strKey) = True Then
                logInsertar = cAcesos.Insertar
                logEditar = cAcesos.Editar
                LogBorrar = cAcesos.Borrar
                logConsultar = cAcesos.Consultar

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Reset()
        celdaTasa.Text = cFunciones.QueryTasa()
        dtpFecha.Value = Today
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = NO_FILA
        dgDetalle.Rows.Clear()
        celdaIdMoneda.Text = 178 'dolares
        celdaMoneda.Text = "USD $"
        celdaEstado.Text = NO_FILA

    End Sub
    Private Function sqlGasto() As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT c.cat_num Num , c.cat_sist Descripcion "
        strSQL &= "     FROM Catalogos c "
        strSQL &= "         WHERE c.cat_clase = 'GastoP' AND c.cat_pid >= 1 Order By c.cat_num Asc "
        Return strSQL
    End Function
    Public Sub CargarGastoDG()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlGasto()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    ' Aqui va Detalle 
                    strFila = INT_CERO & "|" ' Lineea
                    strFila &= REA.GetInt32("Num") & "|" 'id Gasto
                    strFila &= REA.GetString("Descripcion") & "|" 'Nombre Gasto
                    strFila &= INT_CERO & "|" ' Promedio
                    strFila &= INT_CERO & "|" ' Total 1
                    strFila &= INT_CERO & "|" ' Total 2
                    strFila &= ""
                    cfun.AgregarFila(dgDetalle, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CalcularTotales()
        Dim dblTotal As Double = INT_CERO
        Dim dblPeso As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim i As Integer = 0
        For i = 0 To dgDetalle.Rows.Count - 1
            dgDetalle.Rows(i).Cells("colTotal").Value = CDbl(dgDetalle.Rows(i).Cells("colPromedio").Value) + CDbl(dgDetalle.Rows(i).Cells("colTotal1").Value).ToString(FORMATO_MONEDA) + CDbl(dgDetalle.Rows(i).Cells("colTotal2").Value).ToString(FORMATO_MONEDA)
        Next
    End Sub
    Private Function ComprobarDetalles() As Boolean
        Dim Comprobar As Boolean = True
        If dgDetalle.RowCount > 0 Then 'comprueba que el datagrid de Productos tengo al menos 1 Linea
        Else
            Comprobar = False
            Exit Function
        End If
        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colPromedio").Value = vbNullString Then
                Comprobar = False
                MsgBox("Blank item Average")
            End If
            If dgDetalle.Rows(i).Cells("colTotal1").Value = vbNullString Then
                Comprobar = False
                MsgBox("Blank item Total 1")
            End If
            If dgDetalle.Rows(i).Cells("colTotal2").Value = vbNullString Then
                Comprobar = False
                MsgBox("Blank item Total 2")
            End If
        Next
        Return Comprobar
    End Function
    Private Function GuardarGasto() As Boolean
        Dim CHDR As New Tablas.TGASTOS_PRODUCCION
        Dim logResultado As Boolean = True
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                CHDR.IDEMPRESA = Sesion.IdEmpresa
                CHDR.ANIO = celdaAnio.Text
                CHDR.Fecha_NET = dtpFecha.Value
                CHDR.IDMONEDA = celdaIdMoneda.Text
                CHDR.TASA = celdaTasa.Text
                CHDR.GASTO = dgDetalle.Rows(i).Cells("colidGasto").Value
                CHDR.PROMEDIO = dgDetalle.Rows(i).Cells("colPromedio").Value
                CHDR.TOTAL1 = dgDetalle.Rows(i).Cells("colTotal1").Value
                CHDR.TOTAL2 = dgDetalle.Rows(i).Cells("colTotal2").Value

                CHDR.CONEXION = strConexion
                If Me.Tag = "Nuevo" Then
                    CHDR.LINEA = NuevaLinea()
                    CHDR.IDGASTOPRODUCCION = celdaNumero.Text
                    CHDR.ESTADO = INT_UNO
                    If CHDR.PINSERT = False Then
                        logResultado = False
                        MsgBox(CHDR.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                Else
                    CHDR.LINEA = dgDetalle.Rows(i).Cells("colLinea").Value
                    CHDR.IDGASTOPRODUCCION = celdaNumero.Text
                    CHDR.ESTADO = celdaEstado.Text
                    If CHDR.PUPDATE = False Then
                        logResultado = False
                        MsgBox(CHDR.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                End If
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function SQLCargarGasto(ByVal Anio As Integer, ByVal Num As Integer) As String
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT g.Estado, g.Anio ,g.idGastoProduccion Numero , g.Linea , g.Fecha ,g.idMoneda ,c.cat_clave Moneda ,g.Tasa , g.Gasto ,gp.cat_sist NombreGasto, g.Promedio , g.Total1 , g.Total2 "
        strSQL &= "     FROM Gastos_Produccion g "
        strSQL &= "         LEFT JOIN Catalogos c ON c.cat_num = g.idMoneda AND c.cat_clase = 'Monedas' "
        strSQL &= "             LEFT JOIN Catalogos gp ON gp.cat_num = g.Gasto AND gp.cat_clase = 'GastoP' "
        strSQL &= "                 WHERE g.idEmpresa = {empresa} AND g.Anio = {anio} AND g.idGastoProduccion = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", Anio)
        strSQL = Replace(strSQL, "{numero}", Num)
        Return strSQL
    End Function
    Public Sub CargarGasto(ByVal Anio As Integer, ByVal Num As Integer)
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLCargarGasto(Anio, Num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    dtpFecha.Value = REA.GetDateTime("Fecha")
                    celdaAnio.Text = REA.GetInt32("Anio")
                    celdaNumero.Text = REA.GetInt32("Numero")
                    celdaEstado.Text = REA.GetInt32("Estado")
                    strFila = REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetInt32("Gasto") & "|"
                    strFila &= REA.GetString("NombreGasto") & "|"
                    strFila &= REA.GetDouble("Promedio") & "|"
                    strFila &= REA.GetDouble("Total1") & "|"
                    strFila &= REA.GetDouble("Total2") & "|"
                    strFila &= INT_CERO
                    cfun.AgregarFila(dgDetalle, strFila)
                Loop
            End If
            CalcularTotales()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    'Metodo Borrar
    Public Function BorrarGasto() As Boolean
        Dim logGuardar As Boolean = False
        Dim gast As New Tablas.TGASTOS_PRODUCCION
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = " idEmpresa = {empresa} AND Anio = {anio} AND idGastoProduccion = {numero}  "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{anio}", celdaAnio.Text)
        strCondicion = Replace(strCondicion, "{numero}", celdaNumero.Text)
        Try
            gast.CONEXION = strConexion
            If gast.PDELETE(strCondicion) = True Then
                logGuardar = True
                MsgBox("The record has been successfully deleted.", MsgBoxStyle.Information, "Deletion Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logGuardar
    End Function
#End Region
#Region "Eventos"
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelListaPrincipal.Visible = True Then
            Me.Close()
        ElseIf PanelDocumento.Visible = True Then
            MostrarLista()
        End If
    End Sub
    Private Sub frmGastoProduccion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Accesos()
        MostrarLista()
    End Sub
    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Me.Tag = "Nuevo"
        MostrarLista(False)
        celdaAnio.Text = cfun.AñoMySQL
        Reset()
        celdaEstado.Text = INT_UNO
        CargarGastoDG()
    End Sub
    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency, cat_sist Rate"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 3
                CalcularTotales()
            Case 4
                CalcularTotales()
            Case 5
                CalcularTotales()
        End Select
    End Sub
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim NumLong As Long
        Dim i As Integer
        Dim clsConta As New clsContabilidad
        Try
            If Me.Tag = "Nuevo" Then
                NumLong = celdaNumero.Text
                ' celdaNumero.Text = cfun.Verificacion_Nuevo_Registro(NumLong, "Dcmtos", 952, celdaAnio.Text)
                celdaNumero.Text = NuevoDocumento()

                If celdaNumero.Text > 0 Then
                    If ComprobarDetalles() = True Then
                        ActualizarEstadoGst()
                        GuardarGasto()
                        cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acAdd, Sesion.idUsuario, 0, celdaAnio.Text, celdaNumero.Text)
                        If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                            MostrarLista(True)
                        End If
                    Else
                        MsgBox("Please enter the minimum data to continue", vbExclamation, "Notice")
                        Exit Sub
                    End If
                End If
            ElseIf Me.Tag = "Mod" Then
                GuardarGasto()
                cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acUpdate, Sesion.idUsuario, 0, celdaAnio.Text, celdaNumero.Text)
                If MsgBox("Information Saved Successfully", vbInformation, "Notice") = vbOK Then
                    MostrarLista(True)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ActualizarEstadoGst()
        Dim logGuardar As Boolean = False
        Dim gast As New Tablas.TGASTOS_PRODUCCION
        'Puede o no mandar Condicion. SI NO MANDA... mandar llaves de tabla.
        Dim strCondicion As String = STR_VACIO
        strCondicion = " Estado = 1 " 'DESACTIVAR TODOS LOS ACTIVOS PARA INGRESAR NUEVO GASTO
        Try
            gast.CONEXION = strConexion
            gast.ESTADO = 0
            If gast.PUPDATE(strCondicion) = True Then
                logGuardar = True
                'MsgBox("The record has been successfully update.", MsgBoxStyle.Information, "Update Successful")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Reset()
        Dim intAnio As Integer
        Dim intNumero As Integer

        Try
            If dgLista.Rows.Count = 0 Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(0).Value
            intNumero = dgLista.SelectedCells(1).Value
            CargarGasto(intAnio, intNumero)
            MostrarLista(False, False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cFunciones.MostrarDependencias(0, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 0)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Are You sure " & vbCr & vbCr & "¿do you want to delete this document? ", vbQuestion + vbYesNo, "Aviso") = vbYes Then
                If BorrarGasto() Then
                    '   cFunciones.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAño.Text, 47)
                    '   cFunciones.BorrarDetallePoliza(celdaNumero.Text, celdaAño.Text, 47)
                    cFunciones.EscribirRegistro(Tbl_Documentos, clsFunciones.AccEnum.acDelete, Sesion.idUsuario, 0, celdaAnio.Text, celdaNumero.Text)
                    MsgBox("Delete Complete")
                End If
                MostrarLista()
            End If
            Else
            MsgBox("You don't have permission to this access")
        End If
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub
#End Region
End Class