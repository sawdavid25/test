﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmConfirmacion
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.celdaLineas = New System.Windows.Forms.TextBox()
        Me.panelFiltro = New System.Windows.Forms.Panel()
        Me.checkMostrarDetalle = New System.Windows.Forms.CheckBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.rbtTransito = New System.Windows.Forms.RadioButton()
        Me.btnFiltro = New System.Windows.Forms.Button()
        Me.chkFecha = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.pnlContenedores = New System.Windows.Forms.Panel()
        Me.panelTotales = New System.Windows.Forms.Panel()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CeldaTotal = New System.Windows.Forms.TextBox()
        Me.CeldaCantidad = New System.Windows.Forms.TextBox()
        Me.panelSubdocumentos = New System.Windows.Forms.Panel()
        Me.dgInfoDescargo = New System.Windows.Forms.DataGridView()
        Me.colID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLine = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExistencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargar = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescargado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colSaldo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelContenedor2 = New System.Windows.Forms.Panel()
        Me.dgDocumentos = New System.Windows.Forms.DataGridView()
        Me.colDes = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumentos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDatos = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelContenedor1 = New System.Windows.Forms.Panel()
        Me.dgDetalle = New System.Windows.Forms.DataGridView()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodigo = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCodProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.colIdMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrden = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNInventario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDD = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNaviera = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidNaviera = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOperacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIdVendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pnlSeparador3 = New System.Windows.Forms.Panel()
        Me.celdaEmpresa = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.botonAgrega = New System.Windows.Forms.Button()
        Me.botonInfo = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.pnlGroupBox = New System.Windows.Forms.Panel()
        Me.panelReferencia = New System.Windows.Forms.Panel()
        Me.gpAdicional = New System.Windows.Forms.GroupBox()
        Me.celdaTipoIng = New System.Windows.Forms.TextBox()
        Me.botonGenerarIngreso = New System.Windows.Forms.Button()
        Me.celdaIdCosto = New System.Windows.Forms.TextBox()
        Me.celdaSeguro = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.celdaFlete = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.botonCosteo = New System.Windows.Forms.Button()
        Me.CeldaCosteo = New System.Windows.Forms.TextBox()
        Me.CeldaReferencia2 = New System.Windows.Forms.TextBox()
        Me.CeldaReferencia1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.panelDatos = New System.Windows.Forms.Panel()
        Me.gpDocumentos = New System.Windows.Forms.GroupBox()
        Me.botonGastos = New System.Windows.Forms.Button()
        Me.celdaTipoIngreso = New System.Windows.Forms.TextBox()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.etiquetaNit = New System.Windows.Forms.Label()
        Me.checkPolizImportacion = New System.Windows.Forms.CheckBox()
        Me.celdaProveedor = New System.Windows.Forms.Button()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.dtpEncabezado = New System.Windows.Forms.DateTimePicker()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.celdaIDProveedores = New System.Windows.Forms.TextBox()
        Me.lblIDMoneda = New System.Windows.Forms.Label()
        Me.CeldaTasa = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.CeldaMoneda = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CeldaDireccion = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CeldaCliente = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CeldaNumero = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CeldaAño = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFiltro.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.pnlContenedores.SuspendLayout()
        Me.panelTotales.SuspendLayout()
        Me.panelSubdocumentos.SuspendLayout()
        CType(Me.dgInfoDescargo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelContenedor2.SuspendLayout()
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelContenedor1.SuspendLayout()
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSeparador3.SuspendLayout()
        Me.pnlTop.SuspendLayout()
        Me.pnlGroupBox.SuspendLayout()
        Me.panelReferencia.SuspendLayout()
        Me.gpAdicional.SuspendLayout()
        Me.panelDatos.SuspendLayout()
        Me.gpDocumentos.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.Splitter1)
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.celdaLineas)
        Me.panelLista.Controls.Add(Me.panelFiltro)
        Me.panelLista.Location = New System.Drawing.Point(12, 98)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(444, 254)
        Me.panelLista.TabIndex = 2
        '
        'Splitter1
        '
        Me.Splitter1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Splitter1.Location = New System.Drawing.Point(235, 100)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(10, 154)
        Me.Splitter1.TabIndex = 3
        Me.Splitter1.TabStop = False
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 100)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(245, 154)
        Me.dgLista.TabIndex = 1
        '
        'celdaLineas
        '
        Me.celdaLineas.Dock = System.Windows.Forms.DockStyle.Right
        Me.celdaLineas.Enabled = False
        Me.celdaLineas.ForeColor = System.Drawing.Color.DarkRed
        Me.celdaLineas.Location = New System.Drawing.Point(245, 100)
        Me.celdaLineas.Multiline = True
        Me.celdaLineas.Name = "celdaLineas"
        Me.celdaLineas.Size = New System.Drawing.Size(199, 154)
        Me.celdaLineas.TabIndex = 2
        '
        'panelFiltro
        '
        Me.panelFiltro.Controls.Add(Me.checkMostrarDetalle)
        Me.panelFiltro.Controls.Add(Me.RadioButton1)
        Me.panelFiltro.Controls.Add(Me.rbtTransito)
        Me.panelFiltro.Controls.Add(Me.btnFiltro)
        Me.panelFiltro.Controls.Add(Me.chkFecha)
        Me.panelFiltro.Controls.Add(Me.Label1)
        Me.panelFiltro.Controls.Add(Me.dtpFin)
        Me.panelFiltro.Controls.Add(Me.Label3)
        Me.panelFiltro.Controls.Add(Me.dtpInicio)
        Me.panelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.panelFiltro.Name = "panelFiltro"
        Me.panelFiltro.Size = New System.Drawing.Size(444, 100)
        Me.panelFiltro.TabIndex = 0
        '
        'checkMostrarDetalle
        '
        Me.checkMostrarDetalle.AutoSize = True
        Me.checkMostrarDetalle.Location = New System.Drawing.Point(140, 80)
        Me.checkMostrarDetalle.Name = "checkMostrarDetalle"
        Me.checkMostrarDetalle.Size = New System.Drawing.Size(83, 17)
        Me.checkMostrarDetalle.TabIndex = 16
        Me.checkMostrarDetalle.Text = "Show Detail"
        Me.checkMostrarDetalle.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(18, 80)
        Me.RadioButton1.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(36, 17)
        Me.RadioButton1.TabIndex = 15
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "All"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'rbtTransito
        '
        Me.rbtTransito.AutoSize = True
        Me.rbtTransito.Location = New System.Drawing.Point(72, 80)
        Me.rbtTransito.Margin = New System.Windows.Forms.Padding(2)
        Me.rbtTransito.Name = "rbtTransito"
        Me.rbtTransito.Size = New System.Drawing.Size(57, 17)
        Me.rbtTransito.TabIndex = 14
        Me.rbtTransito.Text = "Transit"
        Me.rbtTransito.UseVisualStyleBackColor = True
        '
        'btnFiltro
        '
        Me.btnFiltro.Location = New System.Drawing.Point(372, 27)
        Me.btnFiltro.Name = "btnFiltro"
        Me.btnFiltro.Size = New System.Drawing.Size(75, 23)
        Me.btnFiltro.TabIndex = 13
        Me.btnFiltro.Text = "Filter"
        Me.btnFiltro.UseVisualStyleBackColor = True
        '
        'chkFecha
        '
        Me.chkFecha.AutoSize = True
        Me.chkFecha.Checked = True
        Me.chkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFecha.Location = New System.Drawing.Point(26, 32)
        Me.chkFecha.Name = "chkFecha"
        Me.chkFecha.Size = New System.Drawing.Size(49, 17)
        Me.chkFecha.TabIndex = 12
        Me.chkFecha.Text = "Date"
        Me.chkFecha.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(88, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Of The"
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(134, 53)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(89, 20)
        Me.dtpFin.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(86, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "To The"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(134, 27)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(89, 20)
        Me.dtpInicio.TabIndex = 8
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.pnlContenedores)
        Me.panelDocumento.Controls.Add(Me.pnlTop)
        Me.panelDocumento.Location = New System.Drawing.Point(386, 124)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(990, 488)
        Me.panelDocumento.TabIndex = 4
        '
        'pnlContenedores
        '
        Me.pnlContenedores.Controls.Add(Me.panelTotales)
        Me.pnlContenedores.Controls.Add(Me.panelSubdocumentos)
        Me.pnlContenedores.Controls.Add(Me.panelContenedor1)
        Me.pnlContenedores.Controls.Add(Me.pnlSeparador3)
        Me.pnlContenedores.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlContenedores.Location = New System.Drawing.Point(0, 214)
        Me.pnlContenedores.Name = "pnlContenedores"
        Me.pnlContenedores.Size = New System.Drawing.Size(990, 274)
        Me.pnlContenedores.TabIndex = 1
        '
        'panelTotales
        '
        Me.panelTotales.Controls.Add(Me.Label13)
        Me.panelTotales.Controls.Add(Me.Label12)
        Me.panelTotales.Controls.Add(Me.CeldaTotal)
        Me.panelTotales.Controls.Add(Me.CeldaCantidad)
        Me.panelTotales.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotales.Location = New System.Drawing.Point(0, 107)
        Me.panelTotales.Margin = New System.Windows.Forms.Padding(2)
        Me.panelTotales.Name = "panelTotales"
        Me.panelTotales.Size = New System.Drawing.Size(936, 47)
        Me.panelTotales.TabIndex = 6
        '
        'Label13
        '
        Me.Label13.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(850, 6)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Amount"
        '
        'Label12
        '
        Me.Label12.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(768, 6)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Quantity"
        '
        'CeldaTotal
        '
        Me.CeldaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaTotal.Location = New System.Drawing.Point(853, 23)
        Me.CeldaTotal.Name = "CeldaTotal"
        Me.CeldaTotal.ReadOnly = True
        Me.CeldaTotal.Size = New System.Drawing.Size(77, 20)
        Me.CeldaTotal.TabIndex = 18
        Me.CeldaTotal.Text = "0.00"
        '
        'CeldaCantidad
        '
        Me.CeldaCantidad.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaCantidad.Location = New System.Drawing.Point(759, 23)
        Me.CeldaCantidad.Name = "CeldaCantidad"
        Me.CeldaCantidad.ReadOnly = True
        Me.CeldaCantidad.Size = New System.Drawing.Size(97, 20)
        Me.CeldaCantidad.TabIndex = 17
        Me.CeldaCantidad.Text = "0.00"
        Me.CeldaCantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'panelSubdocumentos
        '
        Me.panelSubdocumentos.Controls.Add(Me.dgInfoDescargo)
        Me.panelSubdocumentos.Controls.Add(Me.panelContenedor2)
        Me.panelSubdocumentos.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelSubdocumentos.Location = New System.Drawing.Point(0, 154)
        Me.panelSubdocumentos.Name = "panelSubdocumentos"
        Me.panelSubdocumentos.Size = New System.Drawing.Size(936, 120)
        Me.panelSubdocumentos.TabIndex = 5
        '
        'dgInfoDescargo
        '
        Me.dgInfoDescargo.AllowUserToAddRows = False
        Me.dgInfoDescargo.AllowUserToDeleteRows = False
        Me.dgInfoDescargo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgInfoDescargo.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgInfoDescargo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgInfoDescargo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colID, Me.colTipo, Me.colAno, Me.colNumero, Me.colLine, Me.colCode, Me.colUnidad, Me.colExistencia, Me.colDescargar, Me.colDescargado, Me.colSaldo})
        Me.dgInfoDescargo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgInfoDescargo.Location = New System.Drawing.Point(337, 0)
        Me.dgInfoDescargo.Margin = New System.Windows.Forms.Padding(2)
        Me.dgInfoDescargo.Name = "dgInfoDescargo"
        Me.dgInfoDescargo.ReadOnly = True
        Me.dgInfoDescargo.RowTemplate.Height = 24
        Me.dgInfoDescargo.Size = New System.Drawing.Size(599, 120)
        Me.dgInfoDescargo.TabIndex = 4
        '
        'colID
        '
        Me.colID.HeaderText = "Line"
        Me.colID.Name = "colID"
        Me.colID.ReadOnly = True
        Me.colID.Width = 52
        '
        'colTipo
        '
        Me.colTipo.HeaderText = "Tipo"
        Me.colTipo.Name = "colTipo"
        Me.colTipo.ReadOnly = True
        Me.colTipo.Visible = False
        Me.colTipo.Width = 53
        '
        'colAno
        '
        Me.colAno.HeaderText = "Ano"
        Me.colAno.Name = "colAno"
        Me.colAno.ReadOnly = True
        Me.colAno.Visible = False
        Me.colAno.Width = 51
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "PO"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        Me.colNumero.Width = 47
        '
        'colLine
        '
        Me.colLine.HeaderText = "PO Line"
        Me.colLine.Name = "colLine"
        Me.colLine.ReadOnly = True
        Me.colLine.Width = 70
        '
        'colCode
        '
        Me.colCode.HeaderText = "Codigo"
        Me.colCode.Name = "colCode"
        Me.colCode.ReadOnly = True
        Me.colCode.Visible = False
        Me.colCode.Width = 65
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unidad"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.ReadOnly = True
        Me.colUnidad.Visible = False
        Me.colUnidad.Width = 66
        '
        'colExistencia
        '
        Me.colExistencia.HeaderText = "Existencia"
        Me.colExistencia.Name = "colExistencia"
        Me.colExistencia.ReadOnly = True
        Me.colExistencia.Visible = False
        Me.colExistencia.Width = 80
        '
        'colDescargar
        '
        Me.colDescargar.HeaderText = "Descargar"
        Me.colDescargar.Name = "colDescargar"
        Me.colDescargar.ReadOnly = True
        Me.colDescargar.Visible = False
        Me.colDescargar.Width = 81
        '
        'colDescargado
        '
        Me.colDescargado.HeaderText = "Discharge"
        Me.colDescargado.Name = "colDescargado"
        Me.colDescargado.ReadOnly = True
        Me.colDescargado.Width = 80
        '
        'colSaldo
        '
        Me.colSaldo.HeaderText = "Saldo"
        Me.colSaldo.Name = "colSaldo"
        Me.colSaldo.ReadOnly = True
        Me.colSaldo.Visible = False
        Me.colSaldo.Width = 59
        '
        'panelContenedor2
        '
        Me.panelContenedor2.Controls.Add(Me.dgDocumentos)
        Me.panelContenedor2.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelContenedor2.Location = New System.Drawing.Point(0, 0)
        Me.panelContenedor2.Name = "panelContenedor2"
        Me.panelContenedor2.Size = New System.Drawing.Size(337, 120)
        Me.panelContenedor2.TabIndex = 3
        '
        'dgDocumentos
        '
        Me.dgDocumentos.AllowUserToAddRows = False
        Me.dgDocumentos.AllowUserToDeleteRows = False
        Me.dgDocumentos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDocumentos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDocumentos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDocumentos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colDes, Me.colDocumentos, Me.colDatos})
        Me.dgDocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.dgDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.dgDocumentos.Name = "dgDocumentos"
        Me.dgDocumentos.ReadOnly = True
        Me.dgDocumentos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDocumentos.Size = New System.Drawing.Size(337, 120)
        Me.dgDocumentos.TabIndex = 5
        '
        'colDes
        '
        Me.colDes.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDes.HeaderText = "Descrpcion"
        Me.colDes.Name = "colDes"
        Me.colDes.ReadOnly = True
        Me.colDes.Visible = False
        '
        'colDocumentos
        '
        Me.colDocumentos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colDocumentos.HeaderText = "Documents"
        Me.colDocumentos.Name = "colDocumentos"
        Me.colDocumentos.ReadOnly = True
        Me.colDocumentos.Width = 86
        '
        'colDatos
        '
        Me.colDatos.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colDatos.HeaderText = "Data"
        Me.colDatos.Name = "colDatos"
        Me.colDatos.ReadOnly = True
        '
        'panelContenedor1
        '
        Me.panelContenedor1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelContenedor1.BackColor = System.Drawing.SystemColors.Control
        Me.panelContenedor1.Controls.Add(Me.dgDetalle)
        Me.panelContenedor1.Location = New System.Drawing.Point(0, 0)
        Me.panelContenedor1.Name = "panelContenedor1"
        Me.panelContenedor1.Size = New System.Drawing.Size(936, 101)
        Me.panelContenedor1.TabIndex = 2
        '
        'dgDetalle
        '
        Me.dgDetalle.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.dgDetalle.AllowUserToAddRows = False
        Me.dgDetalle.AllowUserToDeleteRows = False
        Me.dgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colCodigo, Me.colLinea, Me.colCodProducto, Me.colDescripcion, Me.colIdMedida, Me.colMedida, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colOrden, Me.colNInventario, Me.colReferencia, Me.colIDD, Me.colEstado, Me.colVendido, Me.colNaviera, Me.colidNaviera, Me.colFechaDetalle, Me.colOperacion, Me.colIdVendido})
        Me.dgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgDetalle.Name = "dgDetalle"
        Me.dgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDetalle.Size = New System.Drawing.Size(936, 101)
        Me.dgDetalle.TabIndex = 1
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        Me.colAño.Visible = False
        Me.colAño.Width = 54
        '
        'colCodigo
        '
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        Me.colCodigo.DefaultCellStyle = DataGridViewCellStyle1
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colCodigo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.colCodigo.Width = 57
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        Me.colLinea.Width = 52
        '
        'colCodProducto
        '
        Me.colCodProducto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.colCodProducto.HeaderText = "ProductCode"
        Me.colCodProducto.Name = "colCodProducto"
        Me.colCodProducto.ReadOnly = True
        Me.colCodProducto.Visible = False
        '
        'colDescripcion
        '
        Me.colDescripcion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Info
        Me.colDescripcion.DefaultCellStyle = DataGridViewCellStyle2
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.colDescripcion.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'colIdMedida
        '
        Me.colIdMedida.HeaderText = "IDMedida"
        Me.colIdMedida.Name = "colIdMedida"
        Me.colIdMedida.ReadOnly = True
        Me.colIdMedida.Visible = False
        Me.colIdMedida.Width = 78
        '
        'colMedida
        '
        Me.colMedida.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Info
        Me.colMedida.DefaultCellStyle = DataGridViewCellStyle3
        Me.colMedida.HeaderText = "Mesure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 67
        '
        'colPrecio
        '
        Me.colPrecio.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight
        Me.colPrecio.DefaultCellStyle = DataGridViewCellStyle4
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 56
        '
        'colCantidad
        '
        Me.colCantidad.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight
        Me.colCantidad.DefaultCellStyle = DataGridViewCellStyle5
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colTotal
        '
        Me.colTotal.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomRight
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Info
        Me.colTotal.DefaultCellStyle = DataGridViewCellStyle6
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 56
        '
        'colOrden
        '
        Me.colOrden.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.colOrden.DefaultCellStyle = DataGridViewCellStyle7
        Me.colOrden.HeaderText = "Order"
        Me.colOrden.Name = "colOrden"
        Me.colOrden.Width = 58
        '
        'colNInventario
        '
        Me.colNInventario.HeaderText = "NumInventario"
        Me.colNInventario.Name = "colNInventario"
        Me.colNInventario.ReadOnly = True
        Me.colNInventario.Visible = False
        Me.colNInventario.Width = 101
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Referencia"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.Visible = False
        Me.colReferencia.Width = 84
        '
        'colIDD
        '
        Me.colIDD.HeaderText = "ID"
        Me.colIDD.Name = "colIDD"
        Me.colIDD.Visible = False
        Me.colIDD.Width = 43
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Width = 62
        '
        'colVendido
        '
        Me.colVendido.HeaderText = "Sold To"
        Me.colVendido.Name = "colVendido"
        Me.colVendido.ReadOnly = True
        Me.colVendido.Width = 69
        '
        'colNaviera
        '
        Me.colNaviera.HeaderText = "Naviera"
        Me.colNaviera.Name = "colNaviera"
        Me.colNaviera.Width = 69
        '
        'colidNaviera
        '
        Me.colidNaviera.HeaderText = "idNaviera"
        Me.colidNaviera.Name = "colidNaviera"
        Me.colidNaviera.Visible = False
        Me.colidNaviera.Width = 77
        '
        'colFechaDetalle
        '
        Me.colFechaDetalle.HeaderText = "ETD"
        Me.colFechaDetalle.Name = "colFechaDetalle"
        Me.colFechaDetalle.Width = 54
        '
        'colOperacion
        '
        Me.colOperacion.HeaderText = "Operacion"
        Me.colOperacion.Name = "colOperacion"
        Me.colOperacion.ReadOnly = True
        Me.colOperacion.Visible = False
        Me.colOperacion.Width = 81
        '
        'colIdVendido
        '
        Me.colIdVendido.HeaderText = "idCliente"
        Me.colIdVendido.Name = "colIdVendido"
        Me.colIdVendido.Visible = False
        Me.colIdVendido.Width = 72
        '
        'pnlSeparador3
        '
        Me.pnlSeparador3.Controls.Add(Me.celdaEmpresa)
        Me.pnlSeparador3.Controls.Add(Me.celdaUsuario)
        Me.pnlSeparador3.Controls.Add(Me.celdaCatalogo)
        Me.pnlSeparador3.Controls.Add(Me.botonAgrega)
        Me.pnlSeparador3.Controls.Add(Me.botonInfo)
        Me.pnlSeparador3.Controls.Add(Me.botonQuitar)
        Me.pnlSeparador3.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlSeparador3.Location = New System.Drawing.Point(936, 0)
        Me.pnlSeparador3.Name = "pnlSeparador3"
        Me.pnlSeparador3.Size = New System.Drawing.Size(54, 274)
        Me.pnlSeparador3.TabIndex = 0
        '
        'celdaEmpresa
        '
        Me.celdaEmpresa.Location = New System.Drawing.Point(14, 173)
        Me.celdaEmpresa.Name = "celdaEmpresa"
        Me.celdaEmpresa.Size = New System.Drawing.Size(22, 20)
        Me.celdaEmpresa.TabIndex = 14
        Me.celdaEmpresa.Text = "-1"
        Me.celdaEmpresa.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.AllowDrop = True
        Me.celdaUsuario.Location = New System.Drawing.Point(10, 226)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(22, 20)
        Me.celdaUsuario.TabIndex = 22
        Me.celdaUsuario.Text = "-1"
        Me.celdaUsuario.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(10, 199)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(22, 20)
        Me.celdaCatalogo.TabIndex = 21
        Me.celdaCatalogo.Text = "-1"
        Me.celdaCatalogo.Visible = False
        '
        'botonAgrega
        '
        Me.botonAgrega.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgrega.Location = New System.Drawing.Point(7, 16)
        Me.botonAgrega.Name = "botonAgrega"
        Me.botonAgrega.Size = New System.Drawing.Size(34, 23)
        Me.botonAgrega.TabIndex = 4
        Me.botonAgrega.UseVisualStyleBackColor = True
        '
        'botonInfo
        '
        Me.botonInfo.Image = Global.KARIMs_SGI.My.Resources.Resources.zoom
        Me.botonInfo.Location = New System.Drawing.Point(10, 75)
        Me.botonInfo.Name = "botonInfo"
        Me.botonInfo.Size = New System.Drawing.Size(26, 26)
        Me.botonInfo.TabIndex = 3
        Me.botonInfo.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(10, 45)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(26, 24)
        Me.botonQuitar.TabIndex = 1
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'pnlTop
        '
        Me.pnlTop.Controls.Add(Me.pnlGroupBox)
        Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTop.Location = New System.Drawing.Point(0, 0)
        Me.pnlTop.Name = "pnlTop"
        Me.pnlTop.Size = New System.Drawing.Size(990, 214)
        Me.pnlTop.TabIndex = 0
        '
        'pnlGroupBox
        '
        Me.pnlGroupBox.Controls.Add(Me.panelReferencia)
        Me.pnlGroupBox.Controls.Add(Me.panelDatos)
        Me.pnlGroupBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlGroupBox.Location = New System.Drawing.Point(0, 0)
        Me.pnlGroupBox.Name = "pnlGroupBox"
        Me.pnlGroupBox.Size = New System.Drawing.Size(990, 214)
        Me.pnlGroupBox.TabIndex = 0
        '
        'panelReferencia
        '
        Me.panelReferencia.Controls.Add(Me.gpAdicional)
        Me.panelReferencia.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelReferencia.Location = New System.Drawing.Point(539, 0)
        Me.panelReferencia.Name = "panelReferencia"
        Me.panelReferencia.Size = New System.Drawing.Size(451, 214)
        Me.panelReferencia.TabIndex = 1
        '
        'gpAdicional
        '
        Me.gpAdicional.Controls.Add(Me.celdaTipoIng)
        Me.gpAdicional.Controls.Add(Me.botonGenerarIngreso)
        Me.gpAdicional.Controls.Add(Me.celdaIdCosto)
        Me.gpAdicional.Controls.Add(Me.celdaSeguro)
        Me.gpAdicional.Controls.Add(Me.Label16)
        Me.gpAdicional.Controls.Add(Me.celdaFlete)
        Me.gpAdicional.Controls.Add(Me.Label15)
        Me.gpAdicional.Controls.Add(Me.celdaReferencia)
        Me.gpAdicional.Controls.Add(Me.Label14)
        Me.gpAdicional.Controls.Add(Me.botonCosteo)
        Me.gpAdicional.Controls.Add(Me.CeldaCosteo)
        Me.gpAdicional.Controls.Add(Me.CeldaReferencia2)
        Me.gpAdicional.Controls.Add(Me.CeldaReferencia1)
        Me.gpAdicional.Controls.Add(Me.Label11)
        Me.gpAdicional.Controls.Add(Me.Label10)
        Me.gpAdicional.Controls.Add(Me.Label9)
        Me.gpAdicional.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gpAdicional.Location = New System.Drawing.Point(0, 0)
        Me.gpAdicional.Name = "gpAdicional"
        Me.gpAdicional.Size = New System.Drawing.Size(451, 214)
        Me.gpAdicional.TabIndex = 1
        Me.gpAdicional.TabStop = False
        Me.gpAdicional.Text = "Data reference documents"
        '
        'celdaTipoIng
        '
        Me.celdaTipoIng.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTipoIng.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTipoIng.Location = New System.Drawing.Point(186, 21)
        Me.celdaTipoIng.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTipoIng.Name = "celdaTipoIng"
        Me.celdaTipoIng.ReadOnly = True
        Me.celdaTipoIng.Size = New System.Drawing.Size(188, 19)
        Me.celdaTipoIng.TabIndex = 31
        Me.celdaTipoIng.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'botonGenerarIngreso
        '
        Me.botonGenerarIngreso.Image = Global.KARIMs_SGI.My.Resources.Resources.edit_2
        Me.botonGenerarIngreso.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.botonGenerarIngreso.Location = New System.Drawing.Point(402, 141)
        Me.botonGenerarIngreso.Margin = New System.Windows.Forms.Padding(2)
        Me.botonGenerarIngreso.Name = "botonGenerarIngreso"
        Me.botonGenerarIngreso.Size = New System.Drawing.Size(114, 53)
        Me.botonGenerarIngreso.TabIndex = 55
        Me.botonGenerarIngreso.Text = "Generate  Income to Inventory"
        Me.botonGenerarIngreso.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonGenerarIngreso.UseVisualStyleBackColor = True
        Me.botonGenerarIngreso.Visible = False
        '
        'celdaIdCosto
        '
        Me.celdaIdCosto.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.celdaIdCosto.Location = New System.Drawing.Point(314, 42)
        Me.celdaIdCosto.Name = "celdaIdCosto"
        Me.celdaIdCosto.Size = New System.Drawing.Size(22, 20)
        Me.celdaIdCosto.TabIndex = 23
        Me.celdaIdCosto.Text = "1"
        Me.celdaIdCosto.Visible = False
        '
        'celdaSeguro
        '
        Me.celdaSeguro.Location = New System.Drawing.Point(186, 157)
        Me.celdaSeguro.Name = "celdaSeguro"
        Me.celdaSeguro.Size = New System.Drawing.Size(189, 20)
        Me.celdaSeguro.TabIndex = 13
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(183, 141)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(54, 13)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Insurance"
        '
        'celdaFlete
        '
        Me.celdaFlete.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaFlete.Location = New System.Drawing.Point(184, 107)
        Me.celdaFlete.Name = "celdaFlete"
        Me.celdaFlete.Size = New System.Drawing.Size(191, 20)
        Me.celdaFlete.TabIndex = 11
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(181, 91)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(39, 13)
        Me.Label15.TabIndex = 10
        Me.Label15.Text = "Freight"
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Location = New System.Drawing.Point(17, 63)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.ReadOnly = True
        Me.celdaReferencia.Size = New System.Drawing.Size(161, 20)
        Me.celdaReferencia.TabIndex = 9
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(14, 43)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(57, 13)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "Reference"
        '
        'botonCosteo
        '
        Me.botonCosteo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCosteo.Location = New System.Drawing.Point(389, 61)
        Me.botonCosteo.Name = "botonCosteo"
        Me.botonCosteo.Size = New System.Drawing.Size(31, 23)
        Me.botonCosteo.TabIndex = 7
        Me.botonCosteo.Text = "..."
        Me.botonCosteo.UseVisualStyleBackColor = True
        '
        'CeldaCosteo
        '
        Me.CeldaCosteo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaCosteo.Location = New System.Drawing.Point(186, 63)
        Me.CeldaCosteo.Name = "CeldaCosteo"
        Me.CeldaCosteo.ReadOnly = True
        Me.CeldaCosteo.Size = New System.Drawing.Size(189, 20)
        Me.CeldaCosteo.TabIndex = 5
        '
        'CeldaReferencia2
        '
        Me.CeldaReferencia2.Location = New System.Drawing.Point(17, 157)
        Me.CeldaReferencia2.Name = "CeldaReferencia2"
        Me.CeldaReferencia2.Size = New System.Drawing.Size(158, 20)
        Me.CeldaReferencia2.TabIndex = 4
        '
        'CeldaReferencia1
        '
        Me.CeldaReferencia1.Location = New System.Drawing.Point(17, 107)
        Me.CeldaReferencia1.Name = "CeldaReferencia1"
        Me.CeldaReferencia1.Size = New System.Drawing.Size(161, 20)
        Me.CeldaReferencia1.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(181, 45)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(42, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Costing"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 141)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Invoice"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(14, 87)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(57, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Reference"
        '
        'panelDatos
        '
        Me.panelDatos.Controls.Add(Me.gpDocumentos)
        Me.panelDatos.Dock = System.Windows.Forms.DockStyle.Left
        Me.panelDatos.Location = New System.Drawing.Point(0, 0)
        Me.panelDatos.Name = "panelDatos"
        Me.panelDatos.Size = New System.Drawing.Size(539, 214)
        Me.panelDatos.TabIndex = 0
        '
        'gpDocumentos
        '
        Me.gpDocumentos.Controls.Add(Me.botonGastos)
        Me.gpDocumentos.Controls.Add(Me.celdaTipoIngreso)
        Me.gpDocumentos.Controls.Add(Me.celdaNit)
        Me.gpDocumentos.Controls.Add(Me.etiquetaNit)
        Me.gpDocumentos.Controls.Add(Me.checkPolizImportacion)
        Me.gpDocumentos.Controls.Add(Me.celdaProveedor)
        Me.gpDocumentos.Controls.Add(Me.checkActivo)
        Me.gpDocumentos.Controls.Add(Me.dtpEncabezado)
        Me.gpDocumentos.Controls.Add(Me.Label17)
        Me.gpDocumentos.Controls.Add(Me.celdaIDProveedores)
        Me.gpDocumentos.Controls.Add(Me.lblIDMoneda)
        Me.gpDocumentos.Controls.Add(Me.CeldaTasa)
        Me.gpDocumentos.Controls.Add(Me.Label8)
        Me.gpDocumentos.Controls.Add(Me.botonMoneda)
        Me.gpDocumentos.Controls.Add(Me.CeldaMoneda)
        Me.gpDocumentos.Controls.Add(Me.Label7)
        Me.gpDocumentos.Controls.Add(Me.CeldaDireccion)
        Me.gpDocumentos.Controls.Add(Me.Label6)
        Me.gpDocumentos.Controls.Add(Me.CeldaCliente)
        Me.gpDocumentos.Controls.Add(Me.Label5)
        Me.gpDocumentos.Controls.Add(Me.CeldaNumero)
        Me.gpDocumentos.Controls.Add(Me.Label4)
        Me.gpDocumentos.Controls.Add(Me.CeldaAño)
        Me.gpDocumentos.Controls.Add(Me.Label2)
        Me.gpDocumentos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gpDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.gpDocumentos.Name = "gpDocumentos"
        Me.gpDocumentos.Size = New System.Drawing.Size(539, 214)
        Me.gpDocumentos.TabIndex = 0
        Me.gpDocumentos.TabStop = False
        Me.gpDocumentos.Text = "Data document"
        '
        'botonGastos
        '
        Me.botonGastos.Location = New System.Drawing.Point(448, 178)
        Me.botonGastos.Name = "botonGastos"
        Me.botonGastos.Size = New System.Drawing.Size(75, 23)
        Me.botonGastos.TabIndex = 31
        Me.botonGastos.Text = "Expenses"
        Me.botonGastos.UseVisualStyleBackColor = True
        '
        'celdaTipoIngreso
        '
        Me.celdaTipoIngreso.Location = New System.Drawing.Point(514, 41)
        Me.celdaTipoIngreso.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTipoIngreso.Name = "celdaTipoIngreso"
        Me.celdaTipoIngreso.Size = New System.Drawing.Size(20, 20)
        Me.celdaTipoIngreso.TabIndex = 30
        Me.celdaTipoIngreso.Text = "-1"
        Me.celdaTipoIngreso.Visible = False
        '
        'celdaNit
        '
        Me.celdaNit.Location = New System.Drawing.Point(302, 181)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(114, 20)
        Me.celdaNit.TabIndex = 29
        '
        'etiquetaNit
        '
        Me.etiquetaNit.AutoSize = True
        Me.etiquetaNit.Location = New System.Drawing.Point(271, 182)
        Me.etiquetaNit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNit.Name = "etiquetaNit"
        Me.etiquetaNit.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNit.TabIndex = 28
        Me.etiquetaNit.Text = "NIT"
        '
        'checkPolizImportacion
        '
        Me.checkPolizImportacion.AutoSize = True
        Me.checkPolizImportacion.Checked = True
        Me.checkPolizImportacion.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkPolizImportacion.Location = New System.Drawing.Point(416, 31)
        Me.checkPolizImportacion.Margin = New System.Windows.Forms.Padding(2)
        Me.checkPolizImportacion.Name = "checkPolizImportacion"
        Me.checkPolizImportacion.Size = New System.Drawing.Size(86, 17)
        Me.checkPolizImportacion.TabIndex = 27
        Me.checkPolizImportacion.Text = "Import Policy"
        Me.checkPolizImportacion.UseVisualStyleBackColor = True
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(471, 75)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(31, 23)
        Me.celdaProveedor.TabIndex = 26
        Me.celdaProveedor.Text = "..."
        Me.celdaProveedor.UseVisualStyleBackColor = True
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(323, 31)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 25
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'dtpEncabezado
        '
        Me.dtpEncabezado.CalendarMonthBackground = System.Drawing.Color.White
        Me.dtpEncabezado.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpEncabezado.Location = New System.Drawing.Point(200, 48)
        Me.dtpEncabezado.Name = "dtpEncabezado"
        Me.dtpEncabezado.Size = New System.Drawing.Size(101, 20)
        Me.dtpEncabezado.TabIndex = 24
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(197, 35)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(30, 13)
        Me.Label17.TabIndex = 23
        Me.Label17.Text = "Date"
        '
        'celdaIDProveedores
        '
        Me.celdaIDProveedores.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.celdaIDProveedores.Location = New System.Drawing.Point(138, 58)
        Me.celdaIDProveedores.Name = "celdaIDProveedores"
        Me.celdaIDProveedores.Size = New System.Drawing.Size(22, 20)
        Me.celdaIDProveedores.TabIndex = 22
        Me.celdaIDProveedores.Text = "-1"
        Me.celdaIDProveedores.Visible = False
        '
        'lblIDMoneda
        '
        Me.lblIDMoneda.AutoSize = True
        Me.lblIDMoneda.Location = New System.Drawing.Point(105, 165)
        Me.lblIDMoneda.Name = "lblIDMoneda"
        Me.lblIDMoneda.Size = New System.Drawing.Size(25, 13)
        Me.lblIDMoneda.TabIndex = 21
        Me.lblIDMoneda.Text = "178"
        Me.lblIDMoneda.Visible = False
        '
        'CeldaTasa
        '
        Me.CeldaTasa.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaTasa.Location = New System.Drawing.Point(139, 180)
        Me.CeldaTasa.Name = "CeldaTasa"
        Me.CeldaTasa.Size = New System.Drawing.Size(62, 20)
        Me.CeldaTasa.TabIndex = 13
        Me.CeldaTasa.Text = "1.00"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(136, 164)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Exchange"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(98, 181)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(32, 20)
        Me.botonMoneda.TabIndex = 11
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'CeldaMoneda
        '
        Me.CeldaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMoneda.Location = New System.Drawing.Point(24, 181)
        Me.CeldaMoneda.Name = "CeldaMoneda"
        Me.CeldaMoneda.ReadOnly = True
        Me.CeldaMoneda.Size = New System.Drawing.Size(67, 20)
        Me.CeldaMoneda.TabIndex = 10
        Me.CeldaMoneda.Text = "US$"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(21, 164)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Currency"
        '
        'CeldaDireccion
        '
        Me.CeldaDireccion.Location = New System.Drawing.Point(24, 116)
        Me.CeldaDireccion.Multiline = True
        Me.CeldaDireccion.Name = "CeldaDireccion"
        Me.CeldaDireccion.Size = New System.Drawing.Size(429, 45)
        Me.CeldaDireccion.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(21, 100)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Address"
        '
        'CeldaCliente
        '
        Me.CeldaCliente.Location = New System.Drawing.Point(24, 77)
        Me.CeldaCliente.Name = "CeldaCliente"
        Me.CeldaCliente.ReadOnly = True
        Me.CeldaCliente.Size = New System.Drawing.Size(429, 20)
        Me.CeldaCliente.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(21, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Provider"
        '
        'CeldaNumero
        '
        Me.CeldaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaNumero.Location = New System.Drawing.Point(89, 37)
        Me.CeldaNumero.Name = "CeldaNumero"
        Me.CeldaNumero.Size = New System.Drawing.Size(72, 20)
        Me.CeldaNumero.TabIndex = 3
        Me.CeldaNumero.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(86, 21)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(18, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "ID"
        '
        'CeldaAño
        '
        Me.CeldaAño.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaAño.Location = New System.Drawing.Point(24, 37)
        Me.CeldaAño.Name = "CeldaAño"
        Me.CeldaAño.ReadOnly = True
        Me.CeldaAño.Size = New System.Drawing.Size(67, 20)
        Me.CeldaAño.TabIndex = 1
        Me.CeldaAño.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Year"
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonInprimir.Location = New System.Drawing.Point(410, 10)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(59, 45)
        Me.botonInprimir.TabIndex = 20
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 61)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1376, 30)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1376, 61)
        Me.Encabezado1.TabIndex = 0
        '
        'frmConfirmacion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(985, 660)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmConfirmacion"
        Me.Text = "frmConfirmacion"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.panelLista.ResumeLayout(False)
        Me.panelLista.PerformLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFiltro.ResumeLayout(False)
        Me.panelFiltro.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.pnlContenedores.ResumeLayout(False)
        Me.panelTotales.ResumeLayout(False)
        Me.panelTotales.PerformLayout()
        Me.panelSubdocumentos.ResumeLayout(False)
        CType(Me.dgInfoDescargo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelContenedor2.ResumeLayout(False)
        CType(Me.dgDocumentos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelContenedor1.ResumeLayout(False)
        CType(Me.dgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSeparador3.ResumeLayout(False)
        Me.pnlSeparador3.PerformLayout()
        Me.pnlTop.ResumeLayout(False)
        Me.pnlGroupBox.ResumeLayout(False)
        Me.panelReferencia.ResumeLayout(False)
        Me.gpAdicional.ResumeLayout(False)
        Me.gpAdicional.PerformLayout()
        Me.panelDatos.ResumeLayout(False)
        Me.gpDocumentos.ResumeLayout(False)
        Me.gpDocumentos.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Encabezado1 As KARIMs_SGI.encabezado
    Friend WithEvents BarraTitulo1 As KARIMs_SGI.BarraTitulo
    Friend WithEvents panelLista As System.Windows.Forms.Panel
    Friend WithEvents dgLista As System.Windows.Forms.DataGridView
    Friend WithEvents panelFiltro As System.Windows.Forms.Panel
    Friend WithEvents btnFiltro As System.Windows.Forms.Button
    Friend WithEvents chkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpFin As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents dtpInicio As System.Windows.Forms.DateTimePicker
    Friend WithEvents panelDocumento As System.Windows.Forms.Panel
    Friend WithEvents pnlTop As System.Windows.Forms.Panel
    Friend WithEvents pnlGroupBox As System.Windows.Forms.Panel
    Friend WithEvents CeldaCosteo As System.Windows.Forms.TextBox
    Friend WithEvents CeldaReferencia2 As System.Windows.Forms.TextBox
    Friend WithEvents CeldaReferencia1 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents gpDocumentos As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents CeldaTotal As System.Windows.Forms.TextBox
    Friend WithEvents CeldaCantidad As System.Windows.Forms.TextBox
    Friend WithEvents CeldaTasa As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents botonMoneda As System.Windows.Forms.Button
    Friend WithEvents CeldaMoneda As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents CeldaDireccion As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents CeldaCliente As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents CeldaNumero As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CeldaAño As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents pnlContenedores As System.Windows.Forms.Panel
    Friend WithEvents dgDocumentos As System.Windows.Forms.DataGridView
    Friend WithEvents dgDetalle As System.Windows.Forms.DataGridView
    Friend WithEvents pnlSeparador3 As System.Windows.Forms.Panel
    Friend WithEvents botonQuitar As System.Windows.Forms.Button
    Friend WithEvents botonCosteo As System.Windows.Forms.Button
    Friend WithEvents celdaSeguro As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents celdaFlete As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents celdaReferencia As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents botonInfo As System.Windows.Forms.Button
    Friend WithEvents botonInprimir As System.Windows.Forms.Button
    Friend WithEvents panelContenedor2 As System.Windows.Forms.Panel
    Friend WithEvents panelContenedor1 As System.Windows.Forms.Panel
    Friend WithEvents lblIDMoneda As System.Windows.Forms.Label
    Friend WithEvents botonAgrega As System.Windows.Forms.Button
    Friend WithEvents dgInfoDescargo As System.Windows.Forms.DataGridView
    Friend WithEvents celdaUsuario As System.Windows.Forms.TextBox
    Friend WithEvents celdaCatalogo As System.Windows.Forms.TextBox
    Friend WithEvents celdaEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents celdaIDProveedores As System.Windows.Forms.TextBox
    Friend WithEvents colDes As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumentos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDatos As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dtpEncabezado As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents celdaProveedor As System.Windows.Forms.Button
    Friend WithEvents panelSubdocumentos As System.Windows.Forms.Panel
    Friend WithEvents gpAdicional As System.Windows.Forms.GroupBox
    Friend WithEvents panelReferencia As System.Windows.Forms.Panel
    Friend WithEvents panelDatos As System.Windows.Forms.Panel
    Friend WithEvents checkPolizImportacion As System.Windows.Forms.CheckBox
    Friend WithEvents celdaIdCosto As System.Windows.Forms.TextBox
    Friend WithEvents panelTotales As System.Windows.Forms.Panel
    Friend WithEvents botonGenerarIngreso As Button
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents etiquetaNit As Label
    Friend WithEvents celdaTipoIngreso As System.Windows.Forms.TextBox
    Friend WithEvents celdaTipoIng As System.Windows.Forms.TextBox
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents rbtTransito As RadioButton
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewButtonColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colCodProducto As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewButtonColumn
    Friend WithEvents colIdMedida As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colOrden As DataGridViewTextBoxColumn
    Friend WithEvents colNInventario As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents colIDD As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents colVendido As DataGridViewTextBoxColumn
    Friend WithEvents colNaviera As DataGridViewTextBoxColumn
    Friend WithEvents colidNaviera As DataGridViewTextBoxColumn
    Friend WithEvents colFechaDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colOperacion As DataGridViewTextBoxColumn
    Friend WithEvents colIdVendido As DataGridViewTextBoxColumn
    Friend WithEvents botonGastos As Button
    Friend WithEvents colID As DataGridViewTextBoxColumn
    Friend WithEvents colTipo As DataGridViewTextBoxColumn
    Friend WithEvents colAno As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colLine As DataGridViewTextBoxColumn
    Friend WithEvents colCode As DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As DataGridViewTextBoxColumn
    Friend WithEvents colExistencia As DataGridViewTextBoxColumn
    Friend WithEvents colDescargar As DataGridViewTextBoxColumn
    Friend WithEvents colDescargado As DataGridViewTextBoxColumn
    Friend WithEvents colSaldo As DataGridViewTextBoxColumn
    Friend WithEvents celdaLineas As TextBox
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents checkMostrarDetalle As System.Windows.Forms.CheckBox
End Class
