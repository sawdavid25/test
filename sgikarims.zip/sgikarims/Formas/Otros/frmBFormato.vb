﻿Imports System.Text.RegularExpressions

Public Class frmBFormato
    Private Const STR_CODIGO As String = "Fmt_Cheque"

    Private intTipo As Integer
    Private intCiclo As Integer
    Private intCuenta As Integer

    Private Base As New clsBancos

    'Cargar los elementos elementos del formato
    Public Sub Cargar(ByVal ID As Integer)
        Dim strSQL As String

        Dim cmd As MySqlCommand
        Dim row As DataGridViewRow

        Dim c As Integer = INT_CERO
        Dim obj As Object

        intCuenta = ID

        'Recuperar tipo de documento (formato de cheque)
        intTipo = Base.ObtenerIdDeDocumento(STR_CODIGO,, False)
        If Not intTipo.Equals(INT_CERO) Then
            'Recuperar ciclo
            strSQL = "SELECT e.HDoc_Doc_Ano FROM Dcmtos_HDR e WHERE e.HDoc_Sis_Emp={empresa} And e.HDoc_Doc_Cat={tipo} And e.HDoc_Doc_Num={numero}"
            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{tipo}", intTipo)
            strSQL = strSQL.Replace("{numero}", intCuenta)
            MyCnn.CONECTAR = strConexion
            cmd = New MySqlCommand(strSQL, CON)
            obj = cmd.ExecuteScalar
            If obj IsNot Nothing Then
                c = CInt(obj)
                intCiclo = c

                'Preparar la cuadricula
                Lista.SuspendLayout()
                Lista.AllowUserToAddRows = True

                'Recorrer el detalle del documento para cargar posiciones
                strSQL = "SELECT d.DDoc_Doc_Lin Linea, d.DDoc_RF1_Cod Campo, IFNULL(d.DDoc_RF1_Txt,'0.0.0') Posicion FROM Dcmtos_DTL d WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat={tipo} AND d.DDoc_Doc_Ano={ciclo} AND d.DDoc_Doc_Num={numero} ORDER BY d.DDoc_Doc_Lin"
                strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
                strSQL = strSQL.Replace("{tipo}", intTipo)
                strSQL = strSQL.Replace("{ciclo}", c)
                strSQL = strSQL.Replace("{numero}", intCuenta)
                MyCnn.CONECTAR = strConexion
                cmd = New MySqlCommand(strSQL, CON)
                Using dr As MySqlDataReader = cmd.ExecuteReader
                    While dr.Read()
                        row = Lista.Rows(Lista.NewRowIndex).Clone
                        row.Cells(Lista.Columns.Item("lista_item").Index).Value = CInt(dr("linea")).ToString
                        row.Cells(Lista.Columns.Item("lista_campo").Index).Value = dr("campo").ToString.ToUpper
                        row.Cells(Lista.Columns.Item("lista_texto").Index).Value = dr("posicion").ToString

                        Lista.Rows.Add(row)
                    End While
                End Using

                Lista.AllowUserToAddRows = False
                Lista.ResumeLayout()
            End If
        End If

    End Sub

    'Cerrar esta ventana
    Private Sub BotonCerrar_Click(sender As Object, e As EventArgs) Handles BotonCerrar.Click
        DialogResult = DialogResult.Cancel
    End Sub

    'Cerrar la ventana y guardar los cambios
    Private Sub BotonGuardar_Click(sender As Object, e As EventArgs) Handles BotonGuardar.Click
        Dim logErr As Boolean = False
        Dim i As Integer

        Dim strTemp As String
        Dim strSQL As String

        'INFO si se desea permitir el valor cero en cada dato, quitar [1-9] y cambiar {0,2} por {1,3}
        Dim rx As New Regex("^[1-9][0-9]{0,2}\.[1-9][0-9]{0,2}\.[1-9][0-9]{0,2}$")
        Dim m As Match

        'Instruccion SQL para actualizar el detalle del documento (formato de cheque)
        Dim strUpdate As String = "UPDATE Dcmtos_DTL SET DDoc_RF1_Txt={valor} WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat={tipo} AND DDoc_Doc_Ano={ciclo} AND DDoc_Doc_Num={numero} AND DDoc_Doc_Lin={linea}"
        If Sesion.IdEmpresa = 18 Then
            strUpdate &= ";UPDATE PDM.Dcmtos_DTL SET DDoc_RF1_Txt={valor} WHERE DDoc_Sis_Emp={empresa} AND DDoc_Doc_Cat={tipo} AND DDoc_Doc_Ano={ciclo} AND DDoc_Doc_Num={numero} AND DDoc_Doc_Lin={linea}"
        End If
        strUpdate = strUpdate.Replace("{empresa}", Sesion.IdEmpresa)
        strUpdate = strUpdate.Replace("{tipo}", intTipo)
        strUpdate = strUpdate.Replace("{ciclo}", intCiclo)
        strUpdate = strUpdate.Replace("{numero}", intCuenta)

        'Recorrer la cuadricula y evaluar cada valor debe contener tres datos separados por un punto
        For Each row As DataGridViewRow In Lista.Rows
            logErr = True
            strTemp = String.Concat(row.Cells(lista_texto.Index).Value).Trim

            If Not strTemp.Equals(String.Empty) Then
                m = rx.Match(strTemp)
                If m.Success Then
                    logErr = False
                End If
            End If
            If logErr Then
                Lista.CurrentCell = row.Cells(lista_texto.Index)
                Exit For
            End If
        Next

        If logErr Then
            MessageBox.Show("Item value must be a valid position (x.y.w)", Me.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Lista.Focus()
            Lista.BeginEdit(True)
        Else
            If intTipo > INT_CERO And intCiclo > INT_CERO And intCuenta > INT_CERO Then
                'Actualizar cada linea del detalle
                For Each row As DataGridViewRow In Lista.Rows
                    i = CInt(row.Cells(lista_item.Index).Value)
                    strTemp = row.Cells(lista_texto.Index).Value.ToString
                    strSQL = strUpdate.Replace("{linea}", i)
                    strSQL = strSQL.Replace("{valor}", Base.Text(strTemp))
                    MyCnn.CONECTAR = strConexion
                    Using cmd As New MySqlCommand(strSQL, CON)
                        cmd.ExecuteNonQuery()
                    End Using
                Next
            End If

            DialogResult = DialogResult.OK
        End If
    End Sub

    'Permite cargar la posicion y ancho de cada elemento desde un archivo INI
    Private Sub BotonINI_Click(sender As Object, e As EventArgs) Handles BotonINI.Click
        Dim strArchivo As String, strLinea As String
        Dim strCampo As String, strGrupo As String = String.Empty
        Dim strDato As String
        Dim s As String

        Dim i As Integer

        Try
            'Mostrar el cuadro de dialogo para abrir el archivo
            If LoadFile.ShowDialog() = DialogResult.OK Then
                Cursor.Current = Cursors.WaitCursor
                Threading.Thread.Sleep(100)

                'Continuar solo si es un archivo INI
                strArchivo = LoadFile.FileName.ToLower.Trim
                If strArchivo.Substring(strArchivo.Length - 4).Equals(".ini") Then
                    Using rd As New IO.StreamReader(strArchivo, System.Text.Encoding.Default)
                        'Recorrer el archivo linea x linea
                        strLinea = rd.ReadLine
                        While strLinea IsNot Nothing
                            strLinea = strLinea.Trim.ToUpper
                            If Not strLinea.Equals(String.Empty) Then
                                If strLinea.Substring(INT_CERO, 1) = "[" Then
                                    'Identificar la seccion actual
                                    strGrupo = strLinea.Replace("[", String.Empty).Replace("]", String.Empty).ToUpper
                                ElseIf strLinea.Substring(INT_CERO, 1) = ";" Then
                                    'Lineas comentadas
                                Else
                                    i = strLinea.IndexOf("=")
                                    If i > INT_CERO Then
                                        'Separar el nombre del valor
                                        strCampo = strLinea.Substring(INT_CERO, i).Trim
                                        strDato = strLinea.Substring(i + 1, strLinea.Length - (i + 1)).Trim

                                        For Each row As DataGridViewRow In Lista.Rows
                                            'Remplazar nombres que han cambiados (en esta version)
                                            Select Case strCampo
                                                Case "AÑO" : strCampo = "CICLO"
                                                Case "FECHA_IMP" : strCampo = "IMPRESION_FECHA"
                                                Case "HORA_IMP" : strCampo = "IMPRESION_HORA"
                                                Case "NOMBRE2" : strCampo = "PIE_NOMBRE"
                                                Case "MONTO2" : strCampo = "PIE_MONTO"
                                                Case "DESCRIPCION2" : strCampo = "PIE_DESCRIPCION"
                                                Case "HECHO_POR" : strCampo = "USUARIO"
                                                Case "CUENTA"
                                                    If strGrupo.Equals("REGISTRO") Then
                                                        strCampo = "DETALLE_CUENTA"
                                                    End If
                                                Case "CONCEPTO" : strCampo = "DETALLE_DESCRIPCION"
                                                Case "DEBE" : strCampo = "DETALLE_DEBE"
                                                Case "HABER" : strCampo = "DETALLE_HABER"
                                                Case "CHECK_NUM" : strCampo = "NUMERO"
                                            End Select

                                            'Asignar valor y colorear
                                            s = row.Cells(lista_campo.Index).Value.ToString
                                            If s.Equals(strCampo) Then
                                                row.Cells(lista_texto.Index).Value = strDato
                                                row.Cells(lista_texto.Index).Style.BackColor = Color.LightYellow
                                                row.Cells(lista_texto.Index).Style.ForeColor = Color.Blue
                                                Exit For
                                            End If
                                        Next
                                    End If
                                End If
                            End If
                            strLinea = rd.ReadLine
                        End While
                    End Using
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, ex.Source, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Lista.Focus()

    End Sub
End Class