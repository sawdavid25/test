﻿Public Class frmActualizacionSGI

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim strBase As String = "YarnDivision"
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub Accesos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub LimpiarCampos(Optional blMod As Boolean = False)
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaNumero.Text = NO_FILA
        celdaVersion.Clear()
        dtpFecha.Value = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        CheckActivo.Checked = True
        checkHilos.Checked = False
        checkPride.Checked = False
        checkAmtex.Checked = False
        checkNSM.Checked = False
        checkHSM.Checked = False
        checkNS.Checked = False
        checkLCP.Checked = False
        checkPDM.Checked = False
        checkDominican.Checked = False
        checkObligatorio.Checked = False
        checkNT.Checked = False
        dgProgramas.Rows.Clear()
        If blMod = True Then
            gbEmpresas.Enabled = False
        Else
            gbEmpresas.Enabled = True
        End If
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.Id, h.IdEmpresa, IF(h.IdEmpresa = 12,'Hilos', IF(h.IdEmpresa =11,'PrideYarn', IF(h.IdEmpresa = 16,'AmtexPM',IF(h.IdEmpresa = 14,'Dominican',IF(h.idEmpresa = 15,'HSM',IF(h.idEmpresa = 19,'PDM',IF(h.idEmpresa= 20,'NS',IF(h.idEmpresa = 21,'LCP',IF(h.idEmpresa = 22,'NT','NSM'))))))))) Nombre_empresa,h.Fecha,h.VersionString, GROUP_CONCAT(p.pro_descripcion) programa, h.Estado
                        FROM YarnDivision.Update_HDR h
                        LEFT JOIN " & strBase & ".Update_DTL d ON d.IdUpdate = h.Id
                        LEFT JOIN Hilos.Programas p ON p.pro_codigo = d.IdPrograma
                            WHERE h.Id > 0 {fecha} {emp} {programa}
                            GROUP BY h.Id 
                        ORDER BY h.Fecha desc , h.Id desc"
        If rbComercializacion.Checked = True Then
            strSQL = strSQL.Replace("{emp}", " AND NOT h.IdEmpresa IN(15,18,19,20,21,22)")
        Else
            strSQL = strSQL.Replace("{emp}", " AND h.IdEmpresa IN(15,18,19,20,21,22)")
        End If
        If celdaPrograma.TextLength > 0 Then
            strSQL = strSQL.Replace("{programa}", " AND p.pro_codigo = " & celdaIDPrograma.Text)
        Else
            strSQL = strSQL.Replace("{programa}", STR_VACIO)
        End If
        If checkFiltroLista.Checked = True Then
            strSQL = strSQL.Replace("{fecha}", "  AND  h.Fecha BETWEEN '{inicial}' AND '{final}' ")
            strSQL = strSQL.Replace("{inicial}", dtpInicioLista.Value.ToString(FORMATO_MYSQL))
            strSQL = strSQL.Replace("{final}", dtpFinLista.Value.ToString(FORMATO_MYSQL))
        Else
            strSQL = strSQL.Replace("{fecha}", STR_VACIO)
        End If

        Return strSQL
    End Function

    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try

            strSQL = SQLListaPrincipal()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                Do While REA.Read
                    strFila = REA.GetInt32("Id") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Nombre_Empresa") & "|"
                    strFila &= REA.GetString("VersionString") & "|"
                    strFila &= REA.GetString("programa")

                    If REA.GetInt32("Estado") = 0 Then
                        cFunciones.AgregarFila(dgLista, strFila, Color.Coral)
                    Else
                        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 18 Then
                            cFunciones.AgregarFila(dgLista, strFila, Color.AliceBlue)
                        Else
                            cFunciones.AgregarFila(dgLista, strFila)
                        End If

                    End If

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub frmActualizacionSGI_Load(sender As Object, e As EventArgs) Handles Me.Load
        Accesos()
        dtpFinLista.Value = Today
        dtpInicioLista.Value = DateSerial(dtpInicioLista.Value.Year, Month(dtpInicioLista.Value) - 1, dtpInicioLista.Value.Day)
        rbComercializacion.Checked = True
        rbProducción.Checked = False
        celdaIDPrograma.Text = NO_FILA
        celdaPrograma.Clear()
        MostrarLista()
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDetalle.Dock = DockStyle.None
            panelDetalle.Visible = False
            BarraTitulo1.CambiarTitulo("Listado de Versiones")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDetalle.Dock = DockStyle.Fill
            panelDetalle.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("Nuevo registro")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Sub EnviarCorreo(ByVal emp As Integer, ByVal BDD As String, ByVal NombreEmp As String)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strInsert As String = STR_VACIO
        Dim Conec As MySqlConnection
        Dim COM2 As MySqlCommand

        Dim strVersion As String
        Dim intVersion As Integer
        Dim strHtml As String
        Dim logPrimeraLinea As Boolean = True
        Dim strUsuario As String = STR_VACIO
        Dim logLineaUno As Boolean = True
        Dim strCorreo As String = STR_VACIO

        strVersion = celdaVersion.Text
        strVersion = strVersion.Replace(".", "")
        intVersion = CInt(strVersion)

        Dim strConexion2 As String = "server={server};uid={user};password={pass};database={db} ;Allow User Variables=True"

        strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
        strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
        strConexion2 = Replace(strConexion2, "{pass}", MAIL_PASS)
        strConexion2 = Replace(strConexion2, "{db}", MAIL_BASE)

        strSQL = " SELECT e.per_usuario usuario, h.Fecha , h.VersionString , h.Obligatorio , p.pro_descripcion Programa, d.Descripcion, e.per_correo correo1  
                        FROM YarnDivision.Update_HDR h
                            LEFT JOIN YarnDivision.Update_DTL d ON d.IdUpdate = h.Id
                            LEFT JOIN Programas p ON p.pro_codigo = d.IdPrograma
                            LEFT JOIN {BDD}.Personal e ON e.per_sisemp = h.IdEmpresa AND e.per_estado = 1
                        WHERE h.VersionInteger = {version} AND h.IdEmpresa = {empresa} AND d.IdPrograma in(SELECT a.seg_programa  FROM {BDD}.Accesos a
																	           WHERE a.seg_sisemp ={empresa} AND a.seg_usuario = e.per_usuario AND a.seg_programa = d.IdPrograma)
                        ORDER BY e.per_codigo ASC, h.VersionInteger DESC "
        strSQL = strSQL.Replace("{version}", intVersion)
        strSQL = strSQL.Replace("{empresa}", emp)
        strSQL = strSQL.Replace("{BDD}", BDD)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.HasRows Then
            Do While REA.Read

                If logLineaUno = True Then
                    strHtml = " <!DOCTYPE html>
                <html>
                  <head>
                    <meta charset='utf-8'>
                    <title>SGIUpdate</title>
                    <style type='text/css'>
                
                      </style>
                  </head>
                  <body>"

                    logLineaUno = False
                Else

                    If Not strUsuario = REA.GetString("usuario") Then

                        strHtml &= " </ul>
                                        </p> </body>
                </html> "

                        strHtml = Replace(strHtml, vbCrLf, "")
                        strHtml = Replace(strHtml, "'", Chr(34))
                        strInsert = ("INSERT INTO mailserver.correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & strCorreo & "','ACTUALIZACION DE SISTEMA','" & strHtml & "</table> </body> </html>',0); ")

                        Conec = New MySqlConnection(strConexion2)
                        Conec.Open()
                        COM2 = New MySqlCommand(strInsert, Conec)
                        COM2.ExecuteNonQuery()
                        COM2.Dispose()
                        System.GC.Collect()
                        Conec.Close()
                        Conec.Dispose()
                        Conec = Nothing
                        System.GC.Collect()

                        strHtml = " <!DOCTYPE html>
                <html>
                  <head>
                    <meta charset='utf-8'>
                    <title>SGIUpdate</title>
                    <style type='text/css'>
                     
                      </style>
                  </head>
                  <body>"

                    End If

                End If

                If Not strUsuario = REA.GetString("usuario") Then
                    strVersion = REA.GetString("VersionString")
                    If logPrimeraLinea = True Then
                        logPrimeraLinea = False
                        strHtml &= "    <p>
                                      <h1 style= 'font-family: Tahoma, Arial;font-size: 11pt;font-weight: bold; color:black'> " & NombreEmp & " - Version - " & REA.GetString("VersionString") & "</h1>
                                      <h3 style= 'font-family: Tahoma, Arial;font-size: 7pt;text-align: left;font-style: italic; border: none; width: 5.1cm'>" & REA.GetMySqlDateTime("Fecha").ToString & "</h3>
                                      <ul class='navbar'> "
                    Else
                        strHtml &= "   </ul>
                                        </p> <p>
                                      <h1 style= 'font-family: Tahoma, Arial;font-size: 11pt;font-weight: bold; color:black'> " & NombreEmp & " - Version - " & REA.GetString("VersionString") & "</h1>
                                      <h3 style= 'font-family: Tahoma, Arial;font-size: 7pt;text-align: left;font-style: italic; border: none; width: 5.1cm'>" & REA.GetMySqlDateTime("Fecha").ToString & "</h3>
                                      <ul class='navbar'> "
                    End If
                End If
                strHtml &= "  <li style= 'font-family: Tahoma, Arial;font-size: 11pt;font-weight: bold; color:black'>" & REA.GetString("Programa") & "
                          <p style='color:#6F6F6E;font-family: Tahoma Arial;font-size: 8pt;text-align: left; border: none; width: 5.1cm'>" & REA.GetString("Descripcion") & " </p> </li> "


                strUsuario = REA.GetString("usuario")
                strCorreo = REA.GetString("correo1")
            Loop
            strHtml &= " </ul>
                                        </p> </body>
                </html> "

            strHtml = Replace(strHtml, vbCrLf, "")
            strHtml = Replace(strHtml, "'", Chr(34))
            strInsert = ("INSERT INTO mailserver.correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & strCorreo & "','ACTUALIZACION DE SISTEMA','" & strHtml & "</table> </body> </html>',0); ")

            Conec = New MySqlConnection(strConexion2)
            Conec.Open()
            COM2 = New MySqlCommand(strInsert, Conec)
            COM2.ExecuteNonQuery()
            COM2.Dispose()
            System.GC.Collect()
            Conec.Close()
            Conec.Dispose()
            Conec = Nothing
            System.GC.Collect()
        End If
    End Sub

    Private Sub GuardarEncabezado(ByVal emp As Integer)
        Dim hdr As New Tablas.TUPDATE_HDR
        Dim strVersion As String
        Dim intVersion As Integer

        strVersion = celdaVersion.Text
        strVersion = strVersion.Replace(".", "")
        intVersion = CInt(strVersion)
        hdr.IDEMPRESA = emp
        hdr.Fecha_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
        hdr.VERSIONSTRING = celdaVersion.Text
        hdr.VERSIONINTEGER = intVersion
        hdr.OBLIGATORIO = IIf(checkObligatorio.Checked = True, 1, 0)
        hdr.ESTADO = If(CheckActivo.Checked = True, 1, 0)

        hdr.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then
            celdaNumero.Text = NuevoID()
            hdr.ID = celdaNumero.Text
            If hdr.PINSERT() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
        End If
        Else
            hdr.ID = celdaNumero.Text
            If hdr.PUPDATE() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub

    Private Sub GuardarDetalle(ByVal emp As Integer)
        Dim dtl As New Tablas.TUPDATE_DTL

        For i As Integer = 0 To dgProgramas.Rows.Count - 1
            dtl.IDUPDATE = celdaNumero.Text
            If dgProgramas.Rows(i).Cells("colLinea").Value = 0 Then
                dgProgramas.Rows(i).Cells("colLinea").Value = i + 1
                dtl.LINEA = dgProgramas.Rows(i).Cells("colLinea").Value
            Else
                dtl.LINEA = dgProgramas.Rows(i).Cells("colLinea").Value
            End If
            dtl.IDPROGRAMA = dgProgramas.Rows(i).Cells("colIdPrograma").Value
            dtl.DESCRIPCION_TECNICA = dgProgramas.Rows(i).Cells("colDescripcionTecnica").Value
            dtl.DESCRIPCION = dgProgramas.Rows(i).Cells("colDescripcionEjecutiva").Value

            dtl.CONEXION = strConexion
            If dgProgramas.Rows(i).Cells("colExtra").Value = 0 Then
                If dtl.PINSERT = False Then
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgProgramas.Rows(i).Cells("colExtra").Value = 1 Then
                If dtl.PUPDATE = False Then
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgProgramas.Rows(i).Cells("colExtra").Value = 2 Then
                If dtl.PDELETE = False Then
                    MsgBox(dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Next

    End Sub

    Private Function ComprobarCampos()
        Dim bolComprobar As Boolean = True
        Try
            If Len(celdaVersion.Text) < 3 Then
                bolComprobar = False
                Exit Function
            End If
            If dgProgramas.Rows.Count < 1 Then
                bolComprobar = False
                Exit Function
            End If
            If checkHilos.Checked = False And checkPride.Checked = False And checkAmtex.Checked = False And checkDominican.Checked = False And checkNSM.Checked = False And checkHSM.Checked = False And checkNS.Checked = False And checkPDM.Checked = False And checkLCP.Checked = False And checkNT.Checked = False Then
                bolComprobar = False
                Exit Function
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return bolComprobar
    End Function

    Private Sub Guardar(ByVal emp As Integer, ByVal BDD As String, ByVal NombreEmp As String)
        GuardarEncabezado(emp)
        GuardarDetalle(emp)
        EnviarCorreo(emp, BDD, NombreEmp)
    End Sub

    Private Sub BorrarEncabezado()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = " DELETE FROM " & strBase & ".Update_HDR WHERE Id = " & celdaNumero.Text
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorraDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        Try
            strSQL = " DELETE FROM " & strBase & ".Update_DTL WHERE IdUpdate = " & celdaNumero.Text
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function NuevoID() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim id As Integer = 0

        Try
            strSQL = " SELECT IFNULL(MAX(h.Id +1),1) id
                        FROM " & strBase & ".Update_HDR h"

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            id = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return id
    End Function

#End Region

#Region "Eventos"
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDetalle.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intCont As Integer = 0
        Try
            LimpiarCampos(True)

            strSQL = " SELECT h.Id, h.IdEmpresa, h.VersionString,h.Fecha,h.Obligatorio,d.Linea, p.pro_codigo,p.pro_descripcion,d.Descripcion_Tecnica,d.Descripcion, h.Estado
                            FROM YarnDivision.Update_HDR h
                            LEFT JOIN YarnDivision.Update_DTL d ON d.IdUpdate = h.Id
                            LEFT JOIN Programas p ON p.pro_codigo = d.IdPrograma
                            WHERE h.Id = {id} "

            strSQL = strSQL.Replace("{id}", dgLista.SelectedCells(0).Value)
            Me.Tag = "Mod"
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                Do While REA.Read
                    'El if está para que solo entre una vez, ya que lo que va a llenar es el encabezado
                    If intCont = 0 Then
                        celdaAnio.Text = REA.GetDateTime("Fecha").Year
                        celdaNumero.Text = REA.GetInt32("Id")
                        celdaVersion.Text = REA.GetString("VersionString")
                        dtpFecha.Value = REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL)
                        If REA.GetInt32("Estado") = 1 Then
                            CheckActivo.Checked = True
                        Else
                            CheckActivo.Checked = False
                        End If
                        If REA.GetInt32("IdEmpresa") = 12 Then
                            checkHilos.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 11 Then
                            checkPride.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 16 Then
                            checkAmtex.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 14 Then
                            checkDominican.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 15 Then ' HSM
                            checkHSM.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 18 Then 'NSM
                            checkNSM.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 19 Then 'PDM
                            checkPDM.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 20 Then 'NS
                            checkNS.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 21 Then 'LCP
                            checkLCP.Checked = True
                        ElseIf REA.GetInt32("IdEmpresa") = 22 Then 'NT
                            checkNT.Checked = True
                        End If

                        If REA.GetInt32("Obligatorio") = 1 Then
                            checkObligatorio.Checked = True
                        Else
                            checkObligatorio.Checked = False
                        End If
                    End If
                    intCont = 1

                    'LLenar Datagrid
                    strFila = REA.GetInt32("Linea") & "|" 'Linea
                    strFila &= REA.GetInt32("pro_codigo") & "|" 'Codigo del Programa
                    strFila &= REA.GetString("pro_descripcion") & "|" ' Nombre del programa
                    strFila &= REA.GetString("Descripcion_Tecnica") & "|"
                    strFila &= REA.GetString("Descripcion") & "|"
                    strFila &= INT_UNO

                    cFunciones.AgregarFila(dgProgramas, strFila)
                Loop
            End If

            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim strfila As String = STR_VACIO
        Try
            frm.Titulo = "Listado de Programas"
            frm.Campos = " p.pro_codigo,p.pro_descripcion programa "
            frm.Tabla = " Programas p "
            frm.FiltroText = "Ingrese el nombre del programa a buscar"
            frm.Filtro = " p.pro_descripcion "
            frm.Condicion = " p.pro_codigo >0 "
            frm.Limite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                strfila = INT_CERO & "|"
                strfila &= frm.LLave & "|"
                strfila &= frm.Dato & "|"
                strfila &= vbNullString & "|"
                strfila &= vbNullString & "|"
                strfila &= INT_CERO

                cFunciones.AgregarFila(dgProgramas, strfila)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            Me.Tag = "Nuevo"
            LimpiarCampos()
            MostrarLista(False)
        Else
            MsgBox("No tiene permisos para realizar esta acción", vbInformation)
        End If

    End Sub

    Private Sub botonEliminar_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        dgProgramas.CurrentRow.Cells("colExtra").Value = 2
        dgProgramas.CurrentRow.Visible = False
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "Nuevo" Or logEditar = True Then
            If ComprobarCampos() = True Then
                If checkHilos.Checked = True Then 'Hilos
                    Guardar(12, "Hilos", "Hilos y Algodon")
                End If
                If checkPride.Checked = True Then 'PrideYarn
                    Guardar(11, "PrideYarn", "PrideYarn")
                End If
                If checkAmtex.Checked = True Then 'Amtex
                    Guardar(16, "AmtexPM", "Amtex Pymes")
                End If
                If checkDominican.Checked = True Then 'Dominican
                    Guardar(14, "Dominican", "Dominican")
                End If
                If checkNSM.Checked = True Then
                    Guardar(18, "NSM", "Nicaragua Spinning Mills")
                End If
                If checkHSM.Checked = True Then
                    Guardar(15, "HSM", "Honduras Spinning Mills")
                End If
                If checkPDM.Checked = True Then
                    Guardar(19, "PDM", "Pride Denim Mills")
                End If
                If checkNS.Checked = True Then
                    Guardar(20, "NS", "Northern Spinning")
                End If
                If checkLCP.Checked = True Then
                    Guardar(21, "LCP", "Lake City Park")
                End If
                If checkNT.Checked = True Then
                    Guardar(22, "NT", "Northern Textiles")
                End If
                MsgBox("Datos Guardados exitosamente", vbInformation)
                MostrarLista()
            Else
                MsgBox("Ingrese los datos minimos para continuar")
            End If
        Else
            MsgBox("No tiene permisos para esta acción", vbInformation)
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        ListaPrincipal()
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            BorrarEncabezado()
            BorraDetalle()
            MsgBox("Datos eliminados exitosamente")
            MostrarLista()
        Else
            MsgBox("No tiene permisos para realizar esta acción", vbInformation)
        End If
    End Sub

    Private Sub botonProgramas_Click(sender As Object, e As EventArgs) Handles botonProgramas.Click
        Dim frm As New frmSeleccionar
        Dim strfila As String = STR_VACIO
        Try
            frm.Titulo = "Listado de Programas"
            frm.Campos = " p.pro_codigo,p.pro_descripcion programa "
            frm.Tabla = " Programas p "
            frm.FiltroText = "Ingrese el nombre del programa a buscar"
            frm.Filtro = " p.pro_descripcion "
            frm.Condicion = " p.pro_codigo >0 "
            frm.Limite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                celdaIDPrograma.Text = frm.LLave
                celdaPrograma.Text = frm.Dato

                cFunciones.AgregarFila(dgProgramas, strfila)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


#End Region
End Class