﻿Public Class frmAnticipos
#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim cfun As New clsFunciones

    Private Const CATALOGO = 689
#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Funciones y Procedimientos"


    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonInprimir.Enabled = False
            Encabezado1.botonNuevo.Enabled = True
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            'botonInprimir.Enabled = True
            Encabezado1.botonNuevo.Enabled = False
        End If

    End Sub

    Private Sub CalcularTotal()
        Dim dblGranTotal As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If Not dgDetalle.Rows(i).Cells("colMarca").Value = 2 Then
                    dblTotal = CDbl(dgDetalle.Rows(i).Cells("colSaldo").Value)
                    dblGranTotal = dblGranTotal + dblTotal
                End If
            Next
            celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logCoprobar As Boolean = True
        If cfun.ValidarCampoTexto(celdaTitulo) = False Then
            logCoprobar = False
        End If
        If cfun.ValidarCampoTexto(celdaDescripcion) = False Then
            logCoprobar = False
        End If
        'If cfun.ValidarCampoTexto(celdaCostos) = False Then
        '    logCoprobar = False
        'End If
        If dgDetalle.Rows.Count <= 0 Then
            logCoprobar = False
        End If
        Return logCoprobar
    End Function

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub reset()
        celdaAño.Text = cfun.AñoMySQL
        celdaID.Text = STR_VACIO
        celdaTasa.Text = cFunciones.QueryTasa("CURDATE()")
        celdaidMoneda.Text = cfun.SimboloMoneda(cfun.DivisaLocal)
        celdaMoneda.Text = cfun.DivisaLocal
        celdaTitulo.Text = STR_VACIO
        dgDetalle.Rows.Clear()
        dgLiquidacion.Rows.Clear()
        celdaDescripcion.Text = STR_VACIO
        checkActivo.Checked = True
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFecha.Value = cfun.HoyMySQL
        checkActivo.Checked = True
        checkContabilidad.Checked = True
        celdaTipoAnticipo.Text = NO_FILA
        If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
            dgDetalle.Columns(12).Visible = True
        Else
            dgDetalle.Columns(12).Visible = False
        End If

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'ocultar panel de documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'actualizar Titulo
            BarraTitulo1.CambiarTitulo("Advances")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            CargarLista()
            'Mostrar Panel Filtro
            panelLIsta.Visible = True
            panelLIsta.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLIsta.Visible = False
            panelLIsta.Dock = DockStyle.None
            'Mostrar panel de documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a crear un nuevo documento o se va modifica
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Update")
                Me.Tag = "mod"
                BloquearBotones(False)
                ' botonInprimir.Enabled = True
            Else
                BarraTitulo1.CambiarTitulo("New")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
                'botonInprimir.Enabled = False
                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
    Private Function SQLLista() As String
        Dim strSql As String = STR_VACIO
        Try
            ' SUM((l1.Saldo - l1.Monto)) monto
            strSql = "      SELECT l1.Anio,l1.Numero,l1.Fecha,l1.Titulo,l1.Descripcion,l1.Estado, sum(IFNULL(l1.Monto,0)) monto   
                                FROM( 
                        SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha , h.HDoc_Emp_Nom Titulo, h.HDoc_Emp_Dir Descripcion, d.DDoc_Prd_NET Monto, IF(h.HDoc_Doc_Status= 0,'CANCELED', 'ACTIVE') Estado
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 689 AND h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{fin}'
                        ORDER BY h.HDoc_Doc_Num ,h.HDoc_Doc_Fec DESC)l1
                        GROUP BY l1.Anio,l1.Numero DESC "


            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strSql = strSql.Replace("{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSql
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        ' Conexiones
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            dgLista.Rows.Clear()
            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read

                    strLinea = REA.GetInt32("Anio") & "|" 'Año
                    strLinea &= REA.GetInt32("Numero") & "|" 'Numero 
                    strLinea &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|" 'Fecha
                    strLinea &= REA.GetString("Titulo") & "|"  ' Titulo  
                    strLinea &= REA.GetDouble("monto").ToString(FORMATO_MONEDA) & "|"  ' monto
                    strLinea &= REA.GetString("Estado") ' Estado
                    If REA.GetString("Estado") = "CANCELED" Then
                        cFunciones.AgregarFila(dgLista, strLinea, Color.Coral)
                    Else
                        cFunciones.AgregarFila(dgLista, strLinea)
                    End If
                Loop


            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function NuevaLinea(ByVal Codigo As Integer, ByVal anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim LineaNueva As Integer

        strSQL = " Select IFNULL(MAX(DTL.DDoc_Doc_Lin),0) + 1  DTL "
        strSQL &= " FROM Dcmtos_DTL DTL "
        strSQL &= " WHERE DTL.DDoc_Sis_emp = {empresa} And DTL.DDoc_Doc_Cat = {catalogo} And DTL.DDoc_Doc_Ano = {anio} And DTL.DDoc_Doc_Num ={codigo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 689)
        strSQL = Replace(strSQL, "{anio}", anio)
        strSQL = Replace(strSQL, "{codigo}", Codigo)



        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        LineaNueva = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return LineaNueva


    End Function

    Private Function Guardar() As Boolean
        Dim logResultado As Boolean = True
        Dim IntId As Integer = NO_FILA
        Dim chdr As New clsDcmtos_HDR
        Dim conta As New clsContabilidad
        Try

            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_DOC_CAT = 689
            chdr.HDOC_DOC_ANO = dtpFecha.Value.Year

            chdr.HDoc_Doc_Fec_NET = dtpFecha.Value
            chdr.HDOC_EMP_COD = celdaTipoAnticipo.Text
            chdr.HDOC_EMP_NOM = celdaTitulo.Text
            chdr.HDOC_EMP_DIR = celdaDescripcion.Text
            chdr.HDOC_DOC_TC = celdaTasa.Text
            chdr.HDOC_DOC_MON = celdaMoneda.Text


            If checkContabilidad.Checked = True Then
                chdr.HDOC_ANT_COM = INT_UNO
            Else
                chdr.HDOC_ANT_COM = INT_CERO
            End If

            If checkActivo.Checked = True Then
                chdr.HDOC_DOC_STATUS = INT_UNO
            Else
                chdr.HDOC_DOC_STATUS = INT_CERO
            End If
            chdr.CONEXION = strConexion
            If Me.Tag = "Nuevo" Then
                If logInsertar = True Then
                    IntId = Anticipo()
                    chdr.HDOC_DOC_NUM = IntId
                    chdr.HDOC_DR1_NUM = "Anticipo No. " & IntId
                    If chdr.Guardar = False Then

                        MsgBox(chdr.MERROR.ToString)
                        Return False
                        Exit Function
                    Else
                        'Me.Tag = "mod"
                        celdaID.Text = IntId
                        cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acAdd, 0, 689, chdr.HDOC_DOC_ANO, chdr.HDOC_DOC_NUM)
                    End If
                Else
                    MsgBox("You don't have permission to save ")
                    Return False
                    Exit Function
                End If
            Else
                If logEditar = True Then
                    IntId = celdaID.Text
                    chdr.HDOC_DOC_NUM = IntId
                    chdr.HDOC_DR1_NUM = "Anticipo No. " & IntId
                    If chdr.Actualizar = False Then

                        MsgBox(chdr.MERROR.ToString)
                        Return False
                        Exit Function
                    Else
                        cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acUpdate, 0, 689, chdr.HDOC_DOC_ANO, chdr.HDOC_DOC_NUM)
                    End If
                Else
                    MsgBox("You don't have permission to update ")
                    Return False
                    Exit Function
                End If
            End If

            If GuardarDetalle(IntId) Then


                If celdaTipoAnticipo.Text = 1 Then '1 Anticipo de liquidación
                    GuardarPro(IntId)
                    ActualizarLiquidacion(IntId)
                    If Me.Tag = "Nuevo" Then
                        If cfun.SQLVerificarCierre(689, dtpFecha.Value.Year, celdaID.Text) = 0 Then
                            conta.GenerarPoliza(689, dtpFecha.Value.Year, celdaID.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
                        Else
                            conta.GenerarPoliza(689, dtpFecha.Value.Year, celdaID.Text, cfun.HoyMySQL.ToString(FORMATO_MYSQL))
                        End If

                    End If
                Else
                    If GuardarECtaCte(IntId) Then
                        If Me.Tag = "Nuevo" Then
                            If cfun.SQLVerificarCierre(689, dtpFecha.Value.Year, celdaID.Text) = 0 Then
                                conta.GenerarPoliza(689, dtpFecha.Value.Year, celdaID.Text, dtpFecha.Value.ToString(FORMATO_MYSQL))
                            Else
                                conta.GenerarPoliza(689, dtpFecha.Value.Year, celdaID.Text, cfun.HoyMySQL.ToString(FORMATO_MYSQL))
                            End If

                        End If
                    Else
                        logResultado = False
                    End If
                End If
            Else
                logResultado = False
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub GuardarPro(ByVal id As Integer)
        Dim pro As New clsDcmtos_DTL_Pro
        Try
            For i As Integer = 0 To dgLiquidacion.Rows.Count - 1
                pro.PDOC_SIS_EMP = Sesion.IdEmpresa
                pro.PDOC_PAR_CAT = 246
                pro.PDOC_PAR_ANO = dgLiquidacion.Rows(i).Cells("colAnioLiquidacion").Value
                pro.PDOC_PAR_NUM = dgLiquidacion.Rows(i).Cells("colNumeroLiquidacion").Value

                pro.PDOC_CHI_CAT = CATALOGO
                pro.PDOC_CHI_ANO = dtpFecha.Value.Year
                pro.PDOC_CHI_NUM = id
                pro.PDOC_CHI_LIN = INT_UNO

                pro.CONEXION = strConexion
                Select Case dgLiquidacion.Rows(i).Cells("colExtraLiquidacion").Value
                    Case 0
                        pro.PDOC_PAR_LIN = i + 1
                        If pro.Guardar = False Then
                            MsgBox(pro.MERROR.ToString)
                        End If
                    Case 1
                        pro.PDOC_PAR_LIN = dgLiquidacion.Rows(i).Cells("colLineaLiquidacion").Value
                        If pro.Actualizar = False Then
                            MsgBox(pro.MERROR.ToString)
                        End If
                End Select
                If checkActivo.Checked = False Then
                    pro.PDOC_PAR_LIN = dgLiquidacion.Rows(i).Cells("colLineaLiquidacion").Value
                    If pro.Borrar = False Then
                        MsgBox(pro.MERROR.ToString)
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub ActualizarLiquidacion(ByVal id As Integer, Optional borrar As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        For i As Integer = 0 To dgLiquidacion.Rows.Count - 1
            strSQL = " UPDATE Dcmtos_HDR h SET HDoc_Pro_DCat = {catAnt}, HDoc_Pro_DAno = {anioAnt}, HDoc_Pro_DNum = {numAnt}
                       WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = 246 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Dcmtos_HDR h SET HDoc_Pro_DCat = {catAnt}, HDoc_Pro_DAno = {anioAnt}, HDoc_Pro_DNum = {numAnt}
                       WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = 246 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "
            End If

            If checkActivo.Checked = True And borrar = 0 Then
                strSQL = Replace(strSQL, "{catAnt}", 689)
                strSQL = Replace(strSQL, "{anioAnt}", dtpFecha.Value.Year)
                strSQL = Replace(strSQL, "{numAnt}", id)
            Else
                strSQL = Replace(strSQL, "{catAnt}", 0)
                strSQL = Replace(strSQL, "{anioAnt}", 0)
                strSQL = Replace(strSQL, "{numAnt}", 0)
            End If

            strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", dgLiquidacion.Rows(i).Cells("colAnioLiquidacion").Value)
            strSQL = Replace(strSQL, "{num}", dgLiquidacion.Rows(i).Cells("colNumeroLiquidacion").Value)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Next
    End Sub

    Private Function GuardarDetalle(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim cdtl As New clsDcmtos_DTL
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                cdtl.DDOC_SIS_EMP = Sesion.IdEmpresa
                cdtl.DDOC_DOC_CAT = 689
                cdtl.DDOC_DOC_ANO = dtpFecha.Value.Year
                cdtl.DDOC_DOC_NUM = numero

                cdtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCatalogo").Value
                cdtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("colAno").Value
                cdtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("colNumero").Value
                cdtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colSaldo").Value
                cdtl.DDOC_PRD_UM = If(dgDetalle.Rows(i).Cells("colCaja").Value = vbNullString, 0, dgDetalle.Rows(i).Cells("colCaja").Value)
                cdtl.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colCta").Value ' cuenta
                Select Case dgDetalle.Rows(i).Cells("colMarca").Value
                    Case 0 'Guardar nueva Linea
                        dgDetalle.Rows(i).Cells("colLinea").Value = NuevaLinea(numero, cdtl.DDOC_DOC_ANO)
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Guardar = False Then
                            logResultado = False
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Case 1 'Actualizar Linea
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Actualizar = False Then
                            logResultado = False
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        cdtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value
                        cdtl.CONEXION = strConexion
                        If cdtl.Borrar = False Then
                            logResultado = False
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                End Select

            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarECtaCte(ByVal numero As Integer) As Boolean
        Dim logResultado As Boolean = True
        Dim ctate As New Tablas.TECTACTE
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                ctate.ECTA_SIS_EMP = Sesion.IdEmpresa
                ctate.ECTA_DOC_CAT = 689
                ctate.ECTA_DOC_ANO = dtpFecha.Value.Year
                ctate.ECTA_DOC_NUM = numero
                ctate.ECTA_DOC_LIN = dgDetalle.Rows(i).Cells("colLinea").Value

                ctate.ECTA_REF_CAT = dgDetalle.Rows(i).Cells("colCatalogo").Value
                ctate.ECTA_REF_ANO = dgDetalle.Rows(i).Cells("colAno").Value
                ctate.ECTA_REF_NUM = dgDetalle.Rows(i).Cells("colNumero").Value
                ctate.ECta_FecVenc_NET = dtpFecha.Value
                ctate.ECta_FecDcmt_NET = dtpFecha.Value
                ctate.ECTA_MONEDA = celdaMoneda.Text
                ctate.ECTA_TC = celdaTasa.Text
                ctate.ECTA_TRANSID = INT_CERO

                If checkActivo.Checked = True Then
                    If celdaMoneda.Text = cfun.DivisaExtranjera Then
                        ctate.ECTA_ABNO_EXT = dgDetalle.Rows(i).Cells("colSaldo").Value
                        ctate.ECTA_ABNO_LOC = (dgDetalle.Rows(i).Cells("colSaldo").Value * celdaTasa.Text)
                    Else
                        ctate.ECTA_ABNO_LOC = dgDetalle.Rows(i).Cells("colSaldo").Value
                        ctate.ECTA_ABNO_EXT = (dgDetalle.Rows(i).Cells("colSaldo").Value / celdaTasa.Text)
                    End If
                Else
                    ctate.ECTA_ABNO_EXT = INT_CERO
                    ctate.ECTA_ABNO_LOC = INT_CERO
                End If


                ctate.CONEXION = strConexion
                Select Case dgDetalle.Rows(i).Cells("colMarca").Value
                    Case 0 'Guardar nueva Linea
                        If ctate.PINSERT = False Then
                            logResultado = False
                            MsgBox(ctate.MERROR.ToString)
                        Else
                            dgDetalle.Rows(i).Cells("colMarca").Value = 1
                        End If
                    Case 1 'Actualizar Linea
                        ctate.CONEXION = strConexion
                        If ctate.PUPDATE = False Then
                            logResultado = False
                            MsgBox(ctate.MERROR.ToString)
                        End If
                    Case 2 ' Borrar Linea
                        ctate.CONEXION = strConexion
                        EliminarEctate(dtpFecha.Value.Year, numero, dgDetalle.Rows(i).Cells("colLinea").Value)
                        If ctate.PDELETE = False Then
                            logResultado = False
                            MsgBox(ctate.MERROR.ToString)
                        End If
                End Select
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
            logResultado = False
        End Try
        Return logResultado
    End Function

    Private Sub CargarEncabezado(ByVal ano As Integer, ByVal numero As Integer)
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQl = " SELECT h.HDoc_Doc_Ano Anio, h.HDoc_Doc_Num Numero, h.HDoc_Doc_Fec Fecha , h.HDoc_Emp_Nom Titulo, h.HDoc_Emp_Dir Descripcion, 0 monto , if(h.HDoc_Doc_Status= 0 ,'CANCELED', 'ACTIVE') Estado,h.HDoc_Doc_TC Tasa , h.HDoc_Doc_Mon idMoneda, c.cat_clave moneda, h.HDoc_Ant_Com Conta, h.HDoc_Emp_Cod tipo
                        FROM Dcmtos_HDR h
                            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 689 and  h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "

            strSQl = strSQl.Replace("{empresa}", Sesion.IdEmpresa)
            strSQl = strSQl.Replace("{ano}", ano)
            strSQl = strSQl.Replace("{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaID.Text = REA.GetInt32("Numero")
                    celdaAño.Text = REA.GetInt32("Anio")
                    dtpFecha.Value = REA.GetDateTime("Fecha")
                    celdaTitulo.Text = REA.GetString("Titulo")
                    celdaDescripcion.Text = REA.GetString("Descripcion")
                    celdaTasa.Text = REA.GetDouble("Tasa")
                    celdaMoneda.Text = REA.GetInt32("idMoneda")
                    celdaidMoneda.Text = REA.GetString("moneda")
                    celdaTipoAnticipo.Text = REA.GetInt32("tipo")
                    If REA.GetInt32("Conta") = INT_UNO Then
                        checkContabilidad.Checked = True
                    Else
                        checkContabilidad.Checked = False
                    End If
                    If REA.GetString("Estado") = "CANCELED" Then
                        checkActivo.Checked = False
                    Else
                        checkActivo.Checked = True
                    End If
                Loop
            End If

            If celdaTipoAnticipo.Text = 1 Then
                CargarRelacionPro(celdaAño.Text, celdaID.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarRelacionPro(ByVal ano As Integer, ByVal numero As Integer)
        Dim strSQl As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO
        Try
            strSQl = " SELECT p.PDoc_Par_Ano anio, p.PDoc_Par_Num num, p.PDoc_Par_Lin lin
                            FROM Dcmtos_DTL_Pro p
                            WHERE p.PDoc_Sis_Emp = {emp} AND p.PDoc_Chi_Cat = 689 AND p.PDoc_Chi_Ano = {anio} AND p.PDoc_Chi_Num = {num} AND p.PDoc_Chi_Lin = 1 "

            strSQl = Replace(strSQl, "{emp}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{anio}", ano)
            strSQl = Replace(strSQl, "{num}", numero)


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQl, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgLiquidacion.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("num") & "|"
                    strFila &= REA.GetInt32("lin") & "|"
                    strFila &= INT_UNO

                    cfun.AgregarFila(dgLiquidacion, strFila)
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDetalle(ByVal ano As Integer, ByVal numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = " SELECT IFNULL(d.DDoc_RF1_Txt,'') cta, d.DDoc_RF1_Num cat, c.HDoc_Doc_Ano Anio , c.HDoc_Doc_Num  Numero, c.HDoc_Doc_Fec  Fecha, c.HDoc_DR1_Num  Numero_, c.HDoc_Emp_Nom Proveedor ,  m.cat_clave Moneda , d.DDoc_Prd_NET Monto , d.DDoc_Doc_Lin linea, d.DDoc_Prd_UM caja, p.cat_desc Document  
                      FROM Dcmtos_HDR h
	                    LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
	                    LEFT JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND c.HDoc_Doc_Cat = d.DDoc_RF1_Num AND c.HDoc_Doc_Ano = d.DDoc_RF2_Num AND c.HDoc_Doc_Num = d.DDoc_RF3_Num 
	                    LEFT JOIN Catalogos m ON m.cat_num = c.HDoc_Doc_Mon
                        LEFT JOIN Catalogos p ON p.cat_num = d.DDoc_RF1_Num
                    WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 689 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero}  "

            strSQL = strSQL.Replace("{empresa}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{ano}", ano)
            strSQL = strSQL.Replace("{numero}", numero)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("cat") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetMySqlDateTime("Fecha").ToString & "|"
                    strFila &= REA.GetString("Numero_") & "|"
                    strFila &= REA.GetString("Proveedor") & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= "1|"
                    strFila &= REA.GetString("caja") & "|"
                    strFila &= REA.GetString("Document") & "|"
                    strFila &= REA.GetInt32("Linea") & "|"
                    strFila &= REA.GetString("cta") 'Linea de cuenta
                    cFunciones.AgregarFila(dgDetalle, strFila)
                Loop
                If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then
                    dgDetalle.Columns(12).Visible = True
                Else
                    dgDetalle.Columns(12).Visible = False
                End If
                CalcularTotal()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Borrar()
        Dim strSql As String = STR_VACIO
        Try
            checkActivo.Checked = False
            'BORRAR ENCABEZADO
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = CATALOGO
            hdr.HDOC_DOC_ANO = dtpFecha.Value.Year
            hdr.HDOC_DOC_NUM = celdaID.Text
            hdr.Borrar()

            ' BORRAR DETALLE
            strSql = STR_VACIO
            strSql = "DDoc_Sis_Emp = {empresa} and  DDoc_Doc_Cat ={cata} and  DDoc_Doc_Ano = {ano}  and DDoc_Doc_Num = {numero} "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{ano}", dtpFecha.Value.Year)
            strSql = strSql.Replace("{cata}", CATALOGO)
            strSql = strSql.Replace("{numero}", celdaID.Text)

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSql)

            'BORRAR ECTATE

            strSql = STR_VACIO
            strSql = "ECta_Sis_Emp = {empresa} and  ECta_Doc_Cat ={cata} and  ECta_Doc_Ano = {ano}  and ECta_Doc_Num = {numero} "
            strSql = strSql.Replace("{empresa}", Sesion.IdEmpresa)
            strSql = strSql.Replace("{cata}", CATALOGO)
            strSql = strSql.Replace("{ano}", dtpFecha.Value.Year)
            strSql = strSql.Replace("{numero}", celdaID.Text)

            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSql)

            '  BORRAR POLIZA
            cfun.BorrarEncabezadoPoliza(celdaID.Text, dtpFecha.Value.Year, 689)
            cfun.BorrarDetallePoliza(celdaID.Text, dtpFecha.Value.Year, 689)
            ActualizarLiquidacion(celdaID.Text, 1)
            GuardarPro(celdaID.Text)
            cFunciones.EscribirRegistro("HDR", clsFunciones.AccEnum.acDelete, 0, 689, dtpFecha.Value.Year, celdaID.Text)

            MostrarLista(True)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarEctate(ByVal Anio As Integer, ByVal Numero As Integer, ByVal Linea As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = {cata}  and ECta_Doc_Ano = {anio} and ECta_Doc_Num = {numero} AND ECta_Doc_Lin = {linea} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{cata}", CATALOGO)
            strSQL = Replace(strSQL, "{anio}", Anio)
            strSQL = Replace(strSQL, "{numero}", Numero)
            strSQL = Replace(strSQL, "{linea}", Linea)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)
            System.GC.Collect()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function Anticipo() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 689)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
#End Region

    Private Sub frmAnticipos_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmAnticipos_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFin.Value = Today
        dtpInicio.Value = dtpFin.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False, True)
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Titulo = "Select a Currency"
            frm.Campos = " c.cat_clave Moneda, c.cat_num ID, c.cat_sist "
            frm.Tabla = " Catalogos c "
            frm.FiltroText = " Enter The Name Of The Currency To Filter "
            frm.Filtro = "  c.cat_clave  "
            frm.Condicion = " cat_clase='Monedas' ORDER BY c.cat_clave LIMIT 5"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaidMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cfun.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
                dgDetalle.Rows.Clear()
                celdaTotal.Text = "0.00"

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        CargarLista()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLIsta.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click  ''se agregan recibos (209)
        Dim op As New frmOption
        Dim frm As New frmSeleccionar
        Dim strFila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFilaLlave As String = STR_VACIO

        Try
            op.Titulo = "Document Type"
            op.Mensaje = "Choose the type of document"
            op.Opciones = "Invoice|Liquidation"
            op.ShowDialog(Me)

            If op.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaTipoAnticipo.Text = op.Seleccion
                If op.Seleccion = 0 Then
                    frm.Titulo = " Select an Invoice "
                    frm.FiltroText = " Type the invoice number to filter  "
                    'If Sesion.idGiro = 1 Then
                    frm.Campos = " h.HDoc_Doc_Fec _Date , h.HDoc_DR1_Num _Number ,m.cat_clave Currency ,
                                ((case 
                                when h.HDoc_Doc_Mon = " & cfun.DivisaExtranjera & " then (SUM(c.ECta_Crgo_Ext )-SUM(c.ECta_Abno_Ext )) 
                                ELSE (SUM(c.ECta_Crgo_Loc  )-SUM(c.ECta_Abno_Loc  )) END )) Balance,  h.HDoc_Emp_Nom Vendor , h.HDoc_Doc_Ano _Year , h.HDoc_Doc_Num ID, h.HDoc_Doc_Cat Doc,p.cat_desc Document "
                    'Else
                    '    frm.Campos = " h.HDoc_Doc_Fec _Date , h.HDoc_DR1_Num _Number ,m.cat_clave Currency, (SUM(c.ECta_Crgo_Loc)- SUM(c.ECta_Abno_Loc)) Balance, h.HDoc_Emp_Nom Vendor , h.HDoc_Doc_Ano _Year , h.HDoc_Doc_Num ID, h.HDoc_Doc_Cat Doc,p.cat_desc Document"
                    'End If

                    frm.Tabla = "  Dcmtos_HDR h
                            inner JOIN ECtaCte c ON c.ECta_Sis_Emp = h.HDoc_Sis_Emp AND c.ECta_Ref_Cat = h.HDoc_Doc_Cat AND c.ECta_Ref_Ano = h.HDoc_Doc_Ano AND c.ECta_Ref_Num = h.HDoc_Doc_Num 
                            LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon 
                            LEFT JOIN Catalogos p ON p.cat_num = h.HDoc_Doc_Cat"

                    frm.Condicion = "  h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat in (44,209)  AND h.HDoc_Doc_Mon =  " & celdaMoneda.Text & " 
                                GROUP BY h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num 
                                HAVING ABS(Balance) >= 0.01 "
                    frm.Ordenamiento = " _Date   "
                    frm.Filtro = " _Number "
                    frm.Limite = 25

                    frm.ShowDialog(Me)
                    If frm.DialogResult = DialogResult.OK Then

                        strFila = frm.DataGrid.SelectedCells(7).Value & "|" 'catalogo
                        strFila &= frm.DataGrid.SelectedCells(5).Value & "|" ' año
                        strFila &= frm.DataGrid.SelectedCells(6).Value & "|" ' numeroa
                        strFila &= frm.DataGrid.SelectedCells(0).Value & "|" ' fecha
                        strFila &= frm.DataGrid.SelectedCells(1).Value & "|" ' numero dr1
                        strFila &= frm.DataGrid.SelectedCells(4).Value & "|" ' proveedor
                        strFila &= frm.DataGrid.SelectedCells(2).Value & "|" ' moneda
                        strFila &= frm.DataGrid.SelectedCells(3).Value & "|" ' saldo
                        strFila &= "0" & "|" 'Marca
                        strFila &= "" & "|" 'Caja
                        strFila &= frm.DataGrid.SelectedCells(8).Value  ' Documento

                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                            If dgDetalle.Rows(i).Cells("colAno").Value = frm.DataGrid.SelectedCells(5).Value And dgDetalle.Rows(i).Cells("colNumero").Value = frm.DataGrid.SelectedCells(6).Value And Not dgDetalle.CurrentRow.Cells("colMarca").Value = 2 Then
                                Exit Sub
                            End If
                        Next
                        cFunciones.AgregarFila(dgDetalle, strFila)

                        CalcularTotal()

                    End If
                ElseIf op.Seleccion = 1 Then
                    'Proceso de Liquidaciones
                    frm.Titulo = "Liquidation"
                    frm.FiltroText = " Type the Liquidation number to filter "
                    frm.Campos = " h.HDoc_Doc_Fec _Date, h.HDoc_DR1_Num _Number, m.cat_clave Currency, h.HDoc_RF1_Dbl Balance,b.BCta_Des_Cue Petty_Cash, h.HDoc_Doc_Ano _Year, h.HDoc_Doc_Num ID "
                    frm.Tabla = " Dcmtos_HDR h
                                  LEFT JOIN CtasBcos b ON b.BCta_Sis_Emp = h.HDoc_Sis_Emp AND b.BCta_Num = h.HDoc_DR1_Cat
                                  LEFT JOIN Catalogos m ON m.cat_num = h.HDoc_Doc_Mon "
                    frm.Condicion = " h.HDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND h.HDoc_Doc_Cat = 246 AND h.HDoc_Doc_Mon = " & celdaMoneda.Text & " AND h.HDoc_Pro_DCat = 0 AND h.HDoc_Pro_DAno = 0 AND h.HDoc_Pro_DNum = 0 HAVING Balance >0.1 "
                    frm.Ordenamiento = " h.HDoc_Doc_Ano DESC,h.HDoc_Doc_Fec "
                    frm.Filtro = " h.HDoc_DR1_Num "

                    frm.ShowDialog(Me)
                    If frm.DialogResult = DialogResult.OK Then

                        strFila = frm.DataGrid.SelectedCells(5).Value & "|" ' año
                        strFila &= frm.DataGrid.SelectedCells(6).Value & "|" ' numero
                        strFila &= INT_CERO & "|" ' linea
                        strFila &= INT_CERO

                        For i As Integer = 0 To dgLiquidacion.Rows.Count - 1
                            If dgLiquidacion.Rows(i).Cells("colAnioLiquidacion").Value = frm.DataGrid.SelectedCells(5).Value And dgLiquidacion.Rows(i).Cells("colNumeroLiquidacion").Value = frm.DataGrid.SelectedCells(6).Value And Not dgDetalle.CurrentRow.Cells("colMarca").Value = 2 Then
                                Exit Sub
                            End If
                        Next
                        cFunciones.AgregarFila(dgLiquidacion, strFila)
                        strFila = STR_VACIO
                        strSQL = " SELECT d.DDoc_Prd_Cod cat, h44.HDoc_Doc_Fec _Date, CONCAT(h44.HDoc_DR1_Num,' ', h44.HDoc_DR2_Num) _Number, m.cat_clave Currency, ROUND((CASE WHEN h44.HDoc_Doc_Mon = 178 THEN ((h44.HDoc_RF1_Dbl)- IFNULL(SUM(c.ECta_Abno_Ext),0)) ELSE ((h44.HDoc_RF1_Dbl)- IFNULL(SUM(c.ECta_Abno_Loc),0)) END),2) Balance, h44.HDoc_Emp_Nom Vendor, h44.HDoc_Doc_Ano _Year, h44.HDoc_Doc_Num ID, h.HDoc_DR1_Cat Caja,p.cat_desc Document,h44.HDoc_Emp_Per Proveedor	
                                        FROM Dcmtos_HDR h 
                                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                                        LEFT JOIN Dcmtos_HDR h44 ON h44.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h44.HDoc_Doc_Cat = d.DDoc_Prd_Cod AND h44.HDoc_Doc_Ano = d.DDoc_RF1_Num AND h44.HDoc_Doc_Num = d.DDoc_Prd_UM
                                        LEFT JOIN Dcmtos_DTL d44 ON d44.DDoc_Sis_Emp = h44.HDoc_Sis_Emp AND d44.DDoc_Doc_Cat = h44.HDoc_Doc_Cat AND d44.DDoc_Doc_Ano = h44.HDoc_Doc_Ano AND d44.DDoc_Doc_Num = h44.HDoc_Doc_Num
                                        LEFT JOIN ECtaCte c ON c.ECta_Sis_Emp = h44.HDoc_Sis_Emp AND c.ECta_Ref_Cat = h44.HDoc_Doc_Cat AND c.ECta_Ref_Ano = h44.HDoc_Doc_Ano AND c.ECta_Ref_Num = h44.HDoc_Doc_Num
                                        LEFT JOIN Catalogos m ON m.cat_num = h44.HDoc_Doc_Mon
                                        LEFT JOIN Catalogos p ON p.cat_num = d.DDoc_Prd_Cod
                                            WHERE  h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 246 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}
                                            GROUP BY h44.HDoc_Doc_Cat, h44.HDoc_Doc_Num
                                            ORDER BY h44.HDoc_Doc_Fec DESC "

                        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{anio}", frm.DataGrid.SelectedCells(5).Value)
                        strSQL = Replace(strSQL, "{num}", frm.DataGrid.SelectedCells(6).Value)
                        strSQL = Replace(strSQL, "{mon}", cfun.DivisaExtranjera)
                        MyCnn.CONECTAR = strConexion
                        COM = New MySqlCommand(strSQL, CON)
                        REA = COM.ExecuteReader
                        If REA.HasRows Then
                            Do While REA.Read
                                strFila = REA.GetInt32("cat") & "|"
                                strFila &= REA.GetInt32("_Year") & "|"
                                strFila &= REA.GetInt32("ID") & "|"
                                strFila &= REA.GetDateTime("_Date").ToString(FORMATO_MYSQL) & "|"
                                strFila &= REA.GetString("_Number") & "|"
                                If REA.GetString("Vendor") = STR_VACIO Then
                                    strFila &= REA.GetString("Proveedor") & "|"
                                Else
                                    strFila &= REA.GetString("Vendor") & "|"
                                End If
                                strFila &= REA.GetString("Currency") & "|"
                                strFila &= REA.GetDouble("Balance") & "|"
                                strFila &= INT_CERO & "|"
                                strFila &= REA.GetInt32("Caja") & "|"
                                strFila &= REA.GetString("Document")
                                For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                    If dgDetalle.Rows(i).Cells("colCatalogo").Value = REA.GetInt32("cat") And dgDetalle.Rows(i).Cells("colAno").Value = REA.GetInt32("_Year") And dgDetalle.Rows(i).Cells("colNumero").Value = REA.GetInt32("ID") And Not dgDetalle.CurrentRow.Cells("colMarca").Value = 2 Then
                                        Exit Sub
                                    End If
                                Next
                                cFunciones.AgregarFila(dgDetalle, strFila)
                            Loop
                            CalcularTotal()
                        Else
                            dgLiquidacion.Rows.Clear()
                        End If
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        Try
            If MsgBox("Are you sure you want to delete this row? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                dgDetalle.CurrentRow.Cells("colMarca").Value = 2
                dgDetalle.CurrentRow.Visible = False
                CalcularTotal()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotal()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"

            BarraTitulo1.CambiarTitulo("Modificar Registro")
            reset()
            CargarEncabezado(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            CargarDetalle(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            MostrarLista(False)
            Encabezado1.botonNuevo.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim dtFechaConta As Date
        Dim conta As New clsContabilidad
        If Me.Tag = "Nuevo" Then
            If Guardar() Then
                MsgBox("Document saved")
                MostrarLista()
            End If
        Else
            'Captura la fecha
            dtFechaConta = cfun.SQLValidarFechaContable(689, dtpFecha.Value.Year, celdaID.Text)
            'Verifica si hay cierre
            If cfun.SQLVerificarCierre(689, dtpFecha.Value.Year, celdaID.Text) = 0 Then
                If Guardar() Then
                    conta.GenerarPoliza(689, dtpFecha.Value.Year, celdaID.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                    MsgBox("Document saved")
                    MostrarLista()
                End If
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cfun.EscribirRegistro("HDR", clsFunciones.AccEnum.acConfirm, celdaID.Text, 689, dtpFecha.Value.Year, celdaID.Text, "Autorizó Modificación")
                    If Guardar() Then
                        conta.GenerarPoliza(689, dtpFecha.Value.Year, celdaID.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                        MsgBox("Document saved")
                        MostrarLista()
                    End If
                End If
            End If
            End If



    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("Do you want to delete this document? ", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                Borrar()
            End If
        Else
            MsgBox("You don't have permission to delete")
        End If

    End Sub

    Private Sub botonPolizaContable_Click(sender As Object, e As EventArgs) Handles botonPolizaContable.Click
        Dim cls As New clsPolizaContable

        cls.Tipo = 689
        cls.Ciclo = dtpFecha.Value.Year
        cls.Numero = celdaID.Text
        cls.Modo = 27

        cls.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(950, dgLista.SelectedCells(0).Value, dgLista.SelectedCells(1).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 950)

            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        celdaAño.Text = dtpFecha.Value.Year
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick
        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim dbltotalLin As Double = 0
            If Sesion.IdEmpresa = 15 Or Sesion.IdEmpresa = 20 Or Sesion.IdEmpresa = 22 Then

                Select Case dgDetalle.CurrentCell.ColumnIndex
                    Case 12
                        strCondicion = "c.empresa = {emp} AND c.pid = '110603'"
                        strCondicion = strCondicion.Replace("{emp}", Sesion.IdEmpresa)

                        Frm.Titulo = "VAT"
                        Frm.Campos = "c.id_cuenta Account_,c.nombre Name_"
                        Frm.Tabla = cFunciones.ContaEmpresa & ".cuentas c"
                        Frm.Condicion = strCondicion
                        Frm.Filtro = "c.id_cuenta"

                        Frm.ShowDialog(Me)

                        If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.CurrentRow.Cells("colCta").Value = Frm.LLave
                        End If
                End Select
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class