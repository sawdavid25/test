﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_programas1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.paneldocumento = New System.Windows.Forms.Panel()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.celdanombre = New System.Windows.Forms.TextBox()
        Me.celdaid = New System.Windows.Forms.TextBox()
        Me.lblname = New System.Windows.Forms.Label()
        Me.lblid = New System.Windows.Forms.Label()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgListaProgramas = New System.Windows.Forms.DataGridView()
        Me.cat_num = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cat_clave = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BarraTitulo2 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.paneldocumento.SuspendLayout()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgListaProgramas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'paneldocumento
        '
        Me.paneldocumento.Controls.Add(Me.BarraTitulo1)
        Me.paneldocumento.Controls.Add(Me.celdanombre)
        Me.paneldocumento.Controls.Add(Me.celdaid)
        Me.paneldocumento.Controls.Add(Me.lblname)
        Me.paneldocumento.Controls.Add(Me.lblid)
        Me.paneldocumento.Location = New System.Drawing.Point(47, 121)
        Me.paneldocumento.Name = "paneldocumento"
        Me.paneldocumento.Size = New System.Drawing.Size(324, 215)
        Me.paneldocumento.TabIndex = 2
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Location = New System.Drawing.Point(3, 4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(317, 30)
        Me.BarraTitulo1.TabIndex = 4
        '
        'celdanombre
        '
        Me.celdanombre.Location = New System.Drawing.Point(96, 123)
        Me.celdanombre.Name = "celdanombre"
        Me.celdanombre.Size = New System.Drawing.Size(162, 20)
        Me.celdanombre.TabIndex = 3
        '
        'celdaid
        '
        Me.celdaid.Location = New System.Drawing.Point(96, 84)
        Me.celdaid.Name = "celdaid"
        Me.celdaid.ReadOnly = True
        Me.celdaid.Size = New System.Drawing.Size(100, 20)
        Me.celdaid.TabIndex = 2
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.Location = New System.Drawing.Point(21, 126)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(35, 13)
        Me.lblname.TabIndex = 1
        Me.lblname.Text = "Name"
        '
        'lblid
        '
        Me.lblid.AutoSize = True
        Me.lblid.Location = New System.Drawing.Point(21, 87)
        Me.lblid.Name = "lblid"
        Me.lblid.Size = New System.Drawing.Size(18, 13)
        Me.lblid.TabIndex = 0
        Me.lblid.Text = "ID"
        '
        'PanelLista
        '
        Me.PanelLista.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelLista.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelLista.Controls.Add(Me.dgListaProgramas)
        Me.PanelLista.Location = New System.Drawing.Point(444, 121)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(325, 239)
        Me.PanelLista.TabIndex = 3
        '
        'dgListaProgramas
        '
        Me.dgListaProgramas.AllowUserToAddRows = False
        Me.dgListaProgramas.AllowUserToDeleteRows = False
        Me.dgListaProgramas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgListaProgramas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgListaProgramas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgListaProgramas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgListaProgramas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.cat_num, Me.cat_clave})
        Me.dgListaProgramas.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgListaProgramas.GridColor = System.Drawing.SystemColors.Control
        Me.dgListaProgramas.Location = New System.Drawing.Point(0, 0)
        Me.dgListaProgramas.Name = "dgListaProgramas"
        Me.dgListaProgramas.ReadOnly = True
        Me.dgListaProgramas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgListaProgramas.Size = New System.Drawing.Size(325, 239)
        Me.dgListaProgramas.TabIndex = 0
        '
        'cat_num
        '
        Me.cat_num.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.cat_num.HeaderText = "ID"
        Me.cat_num.Name = "cat_num"
        Me.cat_num.ReadOnly = True
        Me.cat_num.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.cat_num.Width = 43
        '
        'cat_clave
        '
        Me.cat_clave.HeaderText = "Name"
        Me.cat_clave.Name = "cat_clave"
        Me.cat_clave.ReadOnly = True
        Me.cat_clave.Width = 60
        '
        'BarraTitulo2
        '
        Me.BarraTitulo2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BarraTitulo2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo2.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo2.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo2.Name = "BarraTitulo2"
        Me.BarraTitulo2.Size = New System.Drawing.Size(800, 30)
        Me.BarraTitulo2.TabIndex = 4
        '
        'Encabezado1
        '
        Me.Encabezado1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(800, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frm_programas1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.paneldocumento)
        Me.Controls.Add(Me.BarraTitulo2)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frm_programas1"
        Me.Text = "Programas"
        Me.paneldocumento.ResumeLayout(False)
        Me.paneldocumento.PerformLayout()
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgListaProgramas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents paneldocumento As Panel
    Friend WithEvents celdanombre As TextBox
    Friend WithEvents celdaid As TextBox
    Friend WithEvents lblname As Label
    Friend WithEvents lblid As Label
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgListaProgramas As DataGridView
    Friend WithEvents BarraTitulo2 As BarraTitulo
    Friend WithEvents cat_num As DataGridViewTextBoxColumn
    Friend WithEvents cat_clave As DataGridViewTextBoxColumn
End Class
