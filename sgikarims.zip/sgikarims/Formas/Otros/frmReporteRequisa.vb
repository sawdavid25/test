﻿Public Class frmReporteRequisa
#Region "Variables"
    Dim dtFechaInicial As Date
    Dim dtFechaFinal As Date
#End Region
#Region "Propiedades"
    Public ReadOnly Property Seleccion_Fecha_Inicial As Date
        Get
            Return dtFechaInicial
        End Get
    End Property
    Public ReadOnly Property Seleccion_Fecha_Final As Date
        Get
            Return dtFechaFinal
        End Get
    End Property
#End Region
    Private Sub botonRequisa_Click(sender As Object, e As EventArgs) Handles botonRequisa.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strAgrupar As String = STR_VACIO



        strTabla = "Dcmtos_HDR h
                    INNER JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Par_Cat = h.HDoc_Doc_Cat AND p.PDoc_Par_Ano = h.HDoc_Doc_Ano AND p.PDoc_Par_Num = h.HDoc_Doc_Num"

        strCondicion = " h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 734 AND h.HDoc_Doc_Status = 1 "

        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        strCampos = "h.HDoc_Doc_Num Numero, h.HDoc_Emp_Nom Requester, h.HDoc_Doc_Ano Anio,  h.HDoc_Doc_Fec Fecha "
        strAgrupar = "h.HDoc_Doc_Ano, h.HDoc_Doc_Num"

        frm.Titulo = "Requisitions"
        frm.Campos = strCampos
        frm.Tabla = strTabla
        frm.Condicion = strCondicion
        frm.FiltroText = " Select a Requisitions"
        frm.Filtro = " h.HDoc_Emp_Nom "
        frm.Agrupar = strAgrupar

        Try

            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDRequisa.Text = frm.LLave
                celdaRequisa.Text = frm.Dato
                celdaAnioRequisa.Text = frm.Dato2
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonArticulo_Click(sender As Object, e As EventArgs) Handles botonArticulo.Click
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strAgrupar As String = STR_VACIO



        strTabla = "Dcmtos_DTL d
                    INNER JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num
										AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin"

        strCondicion = " d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat = 734 {num} {anio} "

        If celdaIDRequisa.Text > 0 Then
            strCondicion = Replace(strCondicion, "{num}", "AND d.DDoc_Doc_Num = " & celdaIDRequisa.Text)
            strCondicion = Replace(strCondicion, "{anio}", "AND d.DDoc_Doc_Ano = " & celdaAnioRequisa.Text)
        Else
            strCondicion = Replace(strCondicion, "{num}", vbNullString)
            strCondicion = Replace(strCondicion, "{anio}", vbNullString)

        End If


        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)


        strCampos = "d.DDoc_Doc_Num Numero, d.DDoc_Prd_Des Descripcion, d.DDoc_RF2_Cod  Marca, d.DDoc_Doc_Ano Año, d.DDoc_Doc_Lin Linea"
        strAgrupar = "d.DDoc_Doc_Ano, d.DDoc_Doc_Num"

        frm.Titulo = "Articles"
        frm.Campos = strCampos
        frm.Tabla = strTabla
        frm.Condicion = strCondicion
        frm.FiltroText = " Select a Article"
        frm.Filtro = " d.DDoc_Prd_Des "
        frm.Agrupar = strAgrupar

        Try

            frm.ShowDialog(frmSPrincipal)
            If frm.DialogResult = DialogResult.OK Then
                celdaIDArticulo.Text = frm.LLave
                celdaArticulo.Text = frm.Dato
                celdaAnioArticulo.Text = frm.Dato3
                celdaLineaArticulo.Text = frm.Dato4
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAceptar_Click(sender As Object, e As EventArgs) Handles botonAceptar.Click
        Try
            dtFechaInicial = dtpFechaInicial.Value
            dtFechaFinal = dtpFechaFinal.Value
            Me.DialogResult = DialogResult.OK

        Catch ex As Exception
            MsgBox(e.ToString)
        End Try


    End Sub
End Class