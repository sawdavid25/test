﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmReporteRequisa
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.celdaLineaArticulo = New System.Windows.Forms.TextBox()
        Me.celdaAnioArticulo = New System.Windows.Forms.TextBox()
        Me.celdaAnioRequisa = New System.Windows.Forms.TextBox()
        Me.celdaIDArticulo = New System.Windows.Forms.TextBox()
        Me.celdaIDRequisa = New System.Windows.Forms.TextBox()
        Me.etiquetaProducto = New System.Windows.Forms.Label()
        Me.botonArticulo = New System.Windows.Forms.Button()
        Me.celdaArticulo = New System.Windows.Forms.TextBox()
        Me.celdaRequisa = New System.Windows.Forms.TextBox()
        Me.botonRequisa = New System.Windows.Forms.Button()
        Me.etiquetaFabricante = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFechaInicial = New System.Windows.Forms.Label()
        Me.etiquetaFechaFinal = New System.Windows.Forms.Label()
        Me.botonCancelar = New System.Windows.Forms.Button()
        Me.botonAceptar = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.celdaLineaArticulo)
        Me.GroupBox1.Controls.Add(Me.celdaAnioArticulo)
        Me.GroupBox1.Controls.Add(Me.celdaAnioRequisa)
        Me.GroupBox1.Controls.Add(Me.celdaIDArticulo)
        Me.GroupBox1.Controls.Add(Me.celdaIDRequisa)
        Me.GroupBox1.Controls.Add(Me.etiquetaProducto)
        Me.GroupBox1.Controls.Add(Me.botonArticulo)
        Me.GroupBox1.Controls.Add(Me.celdaArticulo)
        Me.GroupBox1.Controls.Add(Me.celdaRequisa)
        Me.GroupBox1.Controls.Add(Me.botonRequisa)
        Me.GroupBox1.Controls.Add(Me.etiquetaFabricante)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(491, 69)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Request  By"
        '
        'celdaLineaArticulo
        '
        Me.celdaLineaArticulo.Location = New System.Drawing.Point(188, 62)
        Me.celdaLineaArticulo.Name = "celdaLineaArticulo"
        Me.celdaLineaArticulo.Size = New System.Drawing.Size(29, 20)
        Me.celdaLineaArticulo.TabIndex = 32
        Me.celdaLineaArticulo.Text = "-1"
        Me.celdaLineaArticulo.Visible = False
        '
        'celdaAnioArticulo
        '
        Me.celdaAnioArticulo.Location = New System.Drawing.Point(153, 62)
        Me.celdaAnioArticulo.Name = "celdaAnioArticulo"
        Me.celdaAnioArticulo.Size = New System.Drawing.Size(29, 20)
        Me.celdaAnioArticulo.TabIndex = 31
        Me.celdaAnioArticulo.Text = "-1"
        Me.celdaAnioArticulo.Visible = False
        '
        'celdaAnioRequisa
        '
        Me.celdaAnioRequisa.Location = New System.Drawing.Point(153, 17)
        Me.celdaAnioRequisa.Name = "celdaAnioRequisa"
        Me.celdaAnioRequisa.Size = New System.Drawing.Size(29, 20)
        Me.celdaAnioRequisa.TabIndex = 30
        Me.celdaAnioRequisa.Text = "-1"
        Me.celdaAnioRequisa.Visible = False
        '
        'celdaIDArticulo
        '
        Me.celdaIDArticulo.Location = New System.Drawing.Point(118, 62)
        Me.celdaIDArticulo.Name = "celdaIDArticulo"
        Me.celdaIDArticulo.Size = New System.Drawing.Size(29, 20)
        Me.celdaIDArticulo.TabIndex = 13
        Me.celdaIDArticulo.Text = "-1"
        Me.celdaIDArticulo.Visible = False
        '
        'celdaIDRequisa
        '
        Me.celdaIDRequisa.Location = New System.Drawing.Point(118, 17)
        Me.celdaIDRequisa.Name = "celdaIDRequisa"
        Me.celdaIDRequisa.Size = New System.Drawing.Size(29, 20)
        Me.celdaIDRequisa.TabIndex = 29
        Me.celdaIDRequisa.Text = "-1"
        Me.celdaIDRequisa.Visible = False
        '
        'etiquetaProducto
        '
        Me.etiquetaProducto.AutoSize = True
        Me.etiquetaProducto.Location = New System.Drawing.Point(9, 69)
        Me.etiquetaProducto.Name = "etiquetaProducto"
        Me.etiquetaProducto.Size = New System.Drawing.Size(36, 13)
        Me.etiquetaProducto.TabIndex = 28
        Me.etiquetaProducto.Text = "Article"
        Me.etiquetaProducto.Visible = False
        '
        'botonArticulo
        '
        Me.botonArticulo.Location = New System.Drawing.Point(447, 85)
        Me.botonArticulo.Name = "botonArticulo"
        Me.botonArticulo.Size = New System.Drawing.Size(33, 23)
        Me.botonArticulo.TabIndex = 26
        Me.botonArticulo.Text = "..."
        Me.botonArticulo.UseVisualStyleBackColor = True
        Me.botonArticulo.Visible = False
        '
        'celdaArticulo
        '
        Me.celdaArticulo.Location = New System.Drawing.Point(6, 85)
        Me.celdaArticulo.Name = "celdaArticulo"
        Me.celdaArticulo.Size = New System.Drawing.Size(415, 20)
        Me.celdaArticulo.TabIndex = 25
        Me.celdaArticulo.Visible = False
        '
        'celdaRequisa
        '
        Me.celdaRequisa.Location = New System.Drawing.Point(6, 40)
        Me.celdaRequisa.Name = "celdaRequisa"
        Me.celdaRequisa.Size = New System.Drawing.Size(415, 20)
        Me.celdaRequisa.TabIndex = 0
        '
        'botonRequisa
        '
        Me.botonRequisa.Location = New System.Drawing.Point(447, 40)
        Me.botonRequisa.Name = "botonRequisa"
        Me.botonRequisa.Size = New System.Drawing.Size(33, 20)
        Me.botonRequisa.TabIndex = 1
        Me.botonRequisa.Text = "..."
        Me.botonRequisa.UseVisualStyleBackColor = True
        '
        'etiquetaFabricante
        '
        Me.etiquetaFabricante.AutoSize = True
        Me.etiquetaFabricante.Location = New System.Drawing.Point(9, 24)
        Me.etiquetaFabricante.Name = "etiquetaFabricante"
        Me.etiquetaFabricante.Size = New System.Drawing.Size(59, 13)
        Me.etiquetaFabricante.TabIndex = 23
        Me.etiquetaFabricante.Text = "Requisition"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.dtpFechaFinal)
        Me.GroupBox3.Controls.Add(Me.dtpFechaInicial)
        Me.GroupBox3.Controls.Add(Me.etiquetaFechaInicial)
        Me.GroupBox3.Controls.Add(Me.etiquetaFechaFinal)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 148)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(491, 14)
        Me.GroupBox3.TabIndex = 32
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Date Range"
        Me.GroupBox3.Visible = False
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(280, 29)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(91, 20)
        Me.dtpFechaFinal.TabIndex = 15
        Me.dtpFechaFinal.Value = New Date(2017, 3, 3, 8, 31, 0, 0)
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(106, 28)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(83, 20)
        Me.dtpFechaInicial.TabIndex = 14
        Me.dtpFechaInicial.Value = New Date(2017, 1, 1, 8, 31, 0, 0)
        '
        'etiquetaFechaInicial
        '
        Me.etiquetaFechaInicial.AutoSize = True
        Me.etiquetaFechaInicial.Location = New System.Drawing.Point(52, 34)
        Me.etiquetaFechaInicial.Name = "etiquetaFechaInicial"
        Me.etiquetaFechaInicial.Size = New System.Drawing.Size(31, 13)
        Me.etiquetaFechaInicial.TabIndex = 16
        Me.etiquetaFechaInicial.Text = "Initial"
        '
        'etiquetaFechaFinal
        '
        Me.etiquetaFechaFinal.AutoSize = True
        Me.etiquetaFechaFinal.Location = New System.Drawing.Point(239, 34)
        Me.etiquetaFechaFinal.Name = "etiquetaFechaFinal"
        Me.etiquetaFechaFinal.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaFechaFinal.TabIndex = 17
        Me.etiquetaFechaFinal.Text = "Final"
        '
        'botonCancelar
        '
        Me.botonCancelar.Location = New System.Drawing.Point(254, 100)
        Me.botonCancelar.Name = "botonCancelar"
        Me.botonCancelar.Size = New System.Drawing.Size(75, 23)
        Me.botonCancelar.TabIndex = 34
        Me.botonCancelar.Text = "Cancel"
        Me.botonCancelar.UseVisualStyleBackColor = True
        '
        'botonAceptar
        '
        Me.botonAceptar.Location = New System.Drawing.Point(139, 100)
        Me.botonAceptar.Name = "botonAceptar"
        Me.botonAceptar.Size = New System.Drawing.Size(75, 23)
        Me.botonAceptar.TabIndex = 33
        Me.botonAceptar.Text = "Accept"
        Me.botonAceptar.UseVisualStyleBackColor = True
        '
        'frmReporteRequisa
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(514, 137)
        Me.Controls.Add(Me.botonCancelar)
        Me.Controls.Add(Me.botonAceptar)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmReporteRequisa"
        Me.Text = "frmReporteRequisa"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents celdaIDArticulo As TextBox
    Friend WithEvents celdaIDRequisa As TextBox
    Friend WithEvents etiquetaProducto As Label
    Friend WithEvents botonArticulo As Button
    Friend WithEvents celdaArticulo As TextBox
    Friend WithEvents celdaRequisa As TextBox
    Friend WithEvents botonRequisa As Button
    Friend WithEvents etiquetaFabricante As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents etiquetaFechaInicial As Label
    Friend WithEvents etiquetaFechaFinal As Label
    Friend WithEvents botonCancelar As Button
    Friend WithEvents botonAceptar As Button
    Friend WithEvents celdaAnioRequisa As TextBox
    Friend WithEvents celdaAnioArticulo As TextBox
    Friend WithEvents celdaLineaArticulo As TextBox
End Class
