﻿Public Class frmCotizacion
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Dim INTarticulo As Integer = NO_FILA
    Dim INTOrigen As Integer = NO_FILA
    Dim intLinea As Integer = NO_FILA
    Dim superUsuario As Boolean = False

    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#Region "Funciones y Procedimientos Locales"

    Private Sub CargarInventario()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select   p.pro_proveedor Provider ,  round(sum((ki.ingresos-ki.egresos)),2) Stock from ( "
            strSQL = strSQL & " select i.inv_sisemp empresa, i.inv_numero numero, i.inv_artcodigo articulo, i.inv_provcod proveedor, i.inv_lugarfab origen , "
            strSQL = strSQL & " ifnull(( "
            strSQL = strSQL & " select sum(if(d.DDoc_Prd_UM = 69, d.DDoc_Prd_QTY, (d.DDoc_Prd_QTY * 2.2046))) from Dcmtos_DTL d where d.DDoc_Sis_Emp = i.inv_sisemp and d.DDoc_Doc_Cat = 47 and d.DDoc_Prd_Cod = i.inv_numero  "
            strSQL = strSQL & " ),0) ingresos, "
            strSQL = strSQL & " ifnull(( "
            strSQL = strSQL & "  select sum(if(d.DDoc_Prd_UM = 69, d.DDoc_Prd_QTY, (d.DDoc_Prd_QTY * 2.2046))) from Dcmtos_DTL d "
            strSQL = strSQL & "  left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL = strSQL & " where d.DDoc_Sis_Emp = i.inv_sisemp and d.DDoc_Doc_Cat = 48 and d.DDoc_Prd_Cod = i.inv_numero and h.HDoc_Doc_Status = 1 "
            strSQL = strSQL & " ),0) egresos "
            strSQL = strSQL & " from Inventarios i "
            strSQL = strSQL & " where i.inv_sisemp = {empresa} and i.inv_artcodigo = {articulo} and i.inv_lugarfab = {origen}) ki "
            strSQL = strSQL & " left join Articulos a on a.art_sisemp = ki.empresa and a.art_codigo = ki.articulo "
            strSQL = strSQL & " left join Proveedores p on p.pro_sisemp = ki.empresa and p.pro_codigo = ki.proveedor "
            strSQL = strSQL & " left join Catalogos c on c.cat_num = ki.origen "
            strSQL = strSQL & " group by ki.proveedor "
            strSQL = strSQL & " having Stock>0.9 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{articulo}", intArticulo)
            strSQL = Replace(strSQL, "{origen}", intOrigen)

            cFunciones.CargarLista(dgInventario, strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarOrdenes()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL &= "select a.Proveedor Mill , round(sum(a.saldo),2) Balance from ( "
            strSQL &= " select p.pro_proveedor Proveedor ,(o.cantidad-o.despachos1-o.despachos2) saldo from ( "
            strSQL = strSQL & " select   d.DDoc_Doc_Num numerop ,i.inv_sisemp empresa, i.inv_numero numero, i.inv_artcodigo articulo, d.DDoc_RF1_Num cliente, i.inv_lugarfab origen , d.DDoc_Prd_QTY cantidad, "
            strSQL = strSQL & " ifnull(( "
            strSQL = strSQL & " select sum(p.PDoc_QTY_Pro ) from Dcmtos_DTL_Pro p   "
            strSQL = strSQL & " where p.PDoc_Sis_Emp = d.DDoc_Sis_Emp and p.PDoc_Par_Cat = d.DDoc_Doc_Cat and p.PDoc_Par_Ano = d.DDoc_Doc_Ano and p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin = d.DDoc_Doc_Lin and p.PDoc_Chi_Cat = 127 "
            strSQL = strSQL & " ),0) despachos1, "
            strSQL = strSQL & " ifnull((  "
            strSQL = strSQL & " select sum(di.IDoc_Itm_QTY) from Dcmtos_DTL_Itm di  "
            strSQL = strSQL & " where di.IDoc_Sis_Emp = d.DDoc_Sis_Emp and di.IDoc_Doc_Cat = d.DDoc_Doc_Cat and di.IDoc_Doc_Ano = d.DDoc_Doc_Ano and di.IDoc_Doc_Num = d.DDoc_Doc_Num and di.IDoc_Doc_Lin = d.DDoc_Doc_Lin  "
            strSQL = strSQL & " ),0) despachos2 "
            strSQL = strSQL & " from Inventarios i "
            strSQL = strSQL & " inner join Dcmtos_DTL d on d.DDoc_Sis_Emp = i.inv_sisemp and d.DDoc_Doc_Cat = 38 and d.DDoc_Prd_Cod = i.inv_numero  "
            strSQL = strSQL & " left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num "
            strSQL = strSQL & " where i.inv_sisemp = {empresa} and i.inv_artcodigo = {articulo} and i.inv_lugarfab = {origen} and d.DDoc_RF2_Num = 0 and h.HDoc_Doc_Status =1) o "
            strSQL = strSQL & " left join Proveedores p on p.pro_sisemp = o.empresa and p.pro_codigo = o.cliente "
            strSQL = strSQL & " having saldo > 0.9) a "
            strSQL &= " group by Mill"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{articulo}", INTarticulo)
            strSQL = Replace(strSQL, "{origen}", INTOrigen)

            cFunciones.CargarLista(dgOrden, strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub CargarPO()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select  p.cli_cliente  Customer ,sum((pe.cantidad-pe.despachos)) Balance from ( "
            strSQL = strSQL & " select  i.inv_sisemp empresa, i.inv_numero numero, i.inv_artcodigo articulo, h.HDoc_Emp_Cod   cliente, i.inv_lugarfab origen , d.DDoc_Prd_QTY cantidad, "
            strSQL = strSQL & " ifnull(( "
            strSQL = strSQL & "  select sum(p.PDoc_QTY_Pro ) from Dcmtos_DTL_Pro p  "
            strSQL = strSQL & " where p.PDoc_Sis_Emp = d.DDoc_Sis_Emp and p.PDoc_Par_Cat = d.DDoc_Doc_Cat and p.PDoc_Par_Ano = d.DDoc_Doc_Ano and p.PDoc_Par_Num = d.DDoc_Doc_Num and p.PDoc_Par_Lin = d.DDoc_Doc_Lin and p.PDoc_Chi_Cat = 48) "
            strSQL = strSQL & " ,0) despachos  "
            strSQL = strSQL & " from Inventarios i  "
            strSQL = strSQL & "  inner join Dcmtos_DTL d on d.DDoc_Sis_Emp = i.inv_sisemp and d.DDoc_Doc_Cat = 75 and d.DDoc_Prd_Cod = i.inv_numero  "
            strSQL = strSQL & " left join Dcmtos_HDR h on h.HDoc_Sis_Emp = d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num   "
            strSQL = strSQL & " where i.inv_sisemp = {empresa} and i.inv_artcodigo = {articulo} and i.inv_lugarfab = {origen} and d.DDoc_RF2_Num = 0 and h.HDoc_Doc_Status =1) pe "
            strSQL = strSQL & " left join Articulos a on a.art_sisemp = pe.empresa and a.art_codigo = pe.articulo "
            strSQL = strSQL & " left join Clientes p on p.cli_sisemp  = pe.empresa and p.cli_codigo  = pe.cliente "
            strSQL = strSQL & " left join Catalogos c on c.cat_num = pe.origen "
            strSQL = strSQL & " group by pe.cliente "
            strSQL = strSQL & "  having Balance >0 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{articulo}", intArticulo)
            strSQL = Replace(strSQL, "{origen}", intOrigen)

            cFunciones.CargarLista(dgPO, strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarReserva()
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = " select g2.Fabricante Mill, sum(g2.Reservado) Reserved  from ( "
            strSQL = strSQL & " SELECT  d.DDoc_Sis_Emp Empresa, i.inv_artcodigo  , i.inv_lugarfab , d.DDoc_Doc_Cat Tipo, d.DDoc_Doc_Ano Año, d.DDoc_Doc_Num Documento,  "
            strSQL = strSQL & " d.DDoc_Doc_Lin Linea, a.art_DCorta Producto, i.inv_prodlote Lote,  "
            strSQL = strSQL & " IF(IFNULL(p.pro_nombre,'')='',p.pro_proveedor,p.pro_nombre) Fabricante, e.HDoc_DR1_Num Referencia, d.DDoc_Prd_QTY Cantidad,  "
            strSQL = strSQL & " m.cat_clave Unidad, IF(ROUND(m.cat_sist,5)=0,1, ROUND(m.cat_sist,5)) Factor, i.inv_costo Precio,  "
            strSQL = strSQL & " IFNULL(( "
            strSQL = strSQL & "     SELECT SUM(r.PDoc_QTY_Pro) Suma "
            strSQL = strSQL & "     FROM Dcmtos_DTL_Pro r "
            strSQL = strSQL & "     WHERE r.PDoc_Sis_Emp=d.DDoc_Sis_Emp AND r.PDoc_Par_Cat=d.DDoc_Doc_Cat AND r.PDoc_Par_Ano=d.DDoc_Doc_Ano AND r.PDoc_Par_Num=d.DDoc_Doc_Num AND r.PDoc_Par_Lin=d.DDoc_Doc_Lin AND r.PDoc_Chi_Cat=48),0) Despacho,  "
            strSQL = strSQL & " IFNULL(( "
            strSQL = strSQL & " 	SELECT SUM(v.Cantidad) Suma "
            strSQL = strSQL & " 	FROM Reserva v "
            strSQL = strSQL & " 	WHERE v.id_empresa=d.DDoc_Sis_Emp AND v.doc_tipo=d.DDoc_Doc_Cat AND v.doc_ciclo=d.DDoc_Doc_Ano AND v.doc_num=d.DDoc_Doc_Num AND v.doc_lin=d.DDoc_Doc_Lin AND NOT(v.estado=2)),0) Reservado "
            strSQL = strSQL & " FROM Dcmtos_DTL d "
            strSQL = strSQL & " LEFT JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp=d.DDoc_Sis_Emp AND e.HDoc_Doc_Cat=d.DDoc_Doc_Cat AND e.HDoc_Doc_Ano=d.DDoc_Doc_Ano AND e.HDoc_Doc_Num=d.DDoc_Doc_Num "
            strSQL = strSQL & " LEFT JOIN Inventarios i ON i.inv_sisemp=d.DDoc_Sis_Emp AND i.inv_numero=d.DDoc_Prd_Cod "
            strSQL = strSQL & " LEFT JOIN Articulos a ON a.art_sisemp=i.inv_sisemp AND a.art_codigo=i.inv_artcodigo "
            strSQL = strSQL & " LEFT JOIN Catalogos m ON m.cat_clase='Medidas' AND m.cat_num=d.DDoc_Prd_UM "
            strSQL = strSQL & " LEFT JOIN Proveedores p ON p.pro_sisemp=i.inv_sisemp AND p.pro_codigo=i.inv_provcod "
            strSQL = strSQL & " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=47 and i.inv_artcodigo = {articulo} and i.inv_lugarfab ={origen}	 "
            strSQL = strSQL & " HAVING (Cantidad - Despacho) > 0.09 AND (Reservado > 0.09) "
            strSQL = strSQL & " ORDER BY i.inv_lugarfab, a.art_clase, e.HDoc_Doc_Fec, e.HDoc_Doc_Num, d.DDoc_Doc_Lin) g2 "
            strSQL = strSQL & " group by Mill "


            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{articulo}", INTarticulo)
            strSQL = Replace(strSQL, "{origen}", INTOrigen)

            cFunciones.CargarLista(dgReservado, strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(ByVal logMostrar As Boolean)
        If logMostrar = True Then
            PanelDatos.Visible = False
            PanelDatos.Dock = DockStyle.None
            panelLIsta.Visible = True
            panelLIsta.Dock = DockStyle.Fill
            CargarDocumentos(True)
        Else
            PanelDatos.Visible = True
            PanelDatos.Dock = DockStyle.Fill
            panelLIsta.Visible = False
            panelLIsta.Dock = DockStyle.None

        End If
    End Sub

    Private Sub ObterInvenario(ByVal intInventario As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim Rea As MySqlDataReader
        Try
            INTarticulo = NO_FILA
            INTOrigen = NO_FILA
            strSQL = " select i.inv_artcodigo articulo , i.inv_lugarfab origen from Inventarios i "
            strSQL &= " where i.inv_sisemp = {empresa} and i.inv_numero = {inventario} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{inventario}", intInventario)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            Rea = COM.ExecuteReader()
            If Rea.HasRows Then
                Rea.Read()
                INTarticulo = Rea.GetInt32("articulo")
                INTOrigen = Rea.GetInt32("origen")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularTotales()

        Dim dblInventario As Double = INT_CERO
        Dim dblOreden As Double = INT_CERO
        Dim dblPo As Double = INT_CERO
        Dim dblRes As Double = INT_CERO

        Try
            'Suma el datagrid  de Inventarios
            For i As Integer = 0 To dgInventario.Rows.Count - 1
                dblInventario = dblInventario + CDbl(dgInventario.Rows(i).Cells("Stock").Value)
            Next
            ' suma el datagrid de Ordenes de compra
            For i As Integer = 0 To dgOrden.Rows.Count - 1
                dblOreden = dblOreden + CDbl(dgOrden.Rows(i).Cells("Balance").Value)
            Next
            ' suma el datagrid de Po
            For i As Integer = 0 To dgPO.Rows.Count - 1
                dblPo = dblPo + CDbl(dgPO.Rows(i).Cells("Balance").Value)
            Next
            'inventario reserva
            For i As Integer = 0 To dgReservado.Rows.Count - 1
                dblRes = dblRes + CDbl(dgReservado.Rows(i).Cells("Reserved").Value)
            Next

            celdaPo.Text = dblPo.ToString(FORMATO_MONEDA)
            celdaOrden.Text = dblOreden.ToString(FORMATO_MONEDA)
            celdaInventario.Text = dblInventario.ToString(FORMATO_MONEDA)
            celdaReservado.Text = dblRes.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function UltimoPrecio(ByVal strTipo As String, ByVal intHilo As Integer, ByVal intCliente As Integer) As Double
        Dim strSQL As String = STR_VACIO
        Dim dblResultado As Double = 0
        Dim COM As MySqlCommand
        MyCnn.CONECTAR = strConexion

        strSQL &= "select ifnull(d.DDoc_Prd_NET  , 0) precio from Dcmtos_DTL d "
        strSQL &= " left join Dcmtos_HDR h on h.HDoc_Sis_Emp= d.DDoc_Sis_Emp and h.HDoc_Doc_Cat = d.DDoc_Doc_Cat and h.HDoc_Doc_Ano = d.DDoc_Doc_Ano and h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat ={catalogo}  and d.DDoc_Prd_Cod = {hilo} and h.HDoc_Emp_Cod = {cliente} and h.HDoc_Doc_Status = 1"
        If strTipo = "Cotizacion" Then
            strSQL &= " and d.DDoc_RF1_Num  = 1"
            strSQL = Replace(strSQL, "{catalogo}", 29)

        ElseIf strTipo = "PO" Then
            strSQL = Replace(strSQL, "{catalogo}", 75)

        End If
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{hilo}", intHilo)
        strSQL = Replace(strSQL, "{cliente}", intCliente)

        strSQL &= "  order by  h.HDoc_Doc_Fec desc"
        strSQL &= " limit 1"
        COM = New MySqlCommand(strSQL, CON)
        dblResultado = COM.ExecuteScalar

        Return dblResultado
    End Function

    Private Sub Reset()
        intLinea = NO_FILA
        INTarticulo = NO_FILA
        INTOrigen = NO_FILA
        celdaAño.Text = NO_FILA
        celdaIdPagare.Text = NO_FILA
        botonAgregar.Enabled = False
        etiquetaCliente.Text = STR_VACIO
        etiquetaDireccion.Text = STR_VACIO
        etiquetaIdCliente.Text = NO_FILA
        CeldaMonto.Text = 0
        celdaMoneda.Text = "US$"
        etiquetaMoneda.Text = 178
        checkActivo.Checked = True
        dgDetalle.Rows.Clear()
        dgInventario.DataSource = Nothing
        dgReservado.DataSource = Nothing
        dgPO.DataSource = Nothing
        dgOrden.DataSource = Nothing
        dtpFecha.Value = Today
        celdaInventario.Text = "0.00"
        celdaOrden.Text = "0.00"
        celdaReservado.Text = "0.00"
        celdaPo.Text = "0.00"
        celdaTasa.Text = cFunciones.QueryTasa
        If superUsuario Then
            celdaEstado.Visible = True
            celdaEstado.BackColor = Color.LightYellow
            celdaEstado.Text = "REQUESTED"
        Else
            celdaEstado.Visible = False
        End If

    End Sub

    Private Sub Guardar(Optional ByVal logGuardar As Boolean = True)
        Dim chdr As New clsDcmtos_HDR
        Dim cdtl As New clsDcmtos_DTL
        Dim intNuevo As Integer = NO_FILA
        Dim loghdr As Boolean = False
        Dim strCondicion As String = STR_VACIO
        Try
            chdr.CONEXION = strConexion
            chdr.HDOC_DOC_CAT = 29
            chdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            chdr.HDOC_EMP_COD = etiquetaIdCliente.Text
            chdr.HDOC_EMP_NOM = etiquetaCliente.Text
            chdr.HDOC_EMP_DIR = etiquetaDireccion.Text
            chdr.HDOC_DOC_MON = etiquetaMoneda.Text
            chdr.HDOC_DOC_TC = CDbl(celdaTasa.Text)
            If logGuardar = True Then
                intNuevo = cFunciones.NuevoId(29)

                chdr.HDOC_DOC_CAT = 29
                chdr.HDOC_DOC_ANO = cFunciones.AñoMySQL
                chdr.HDOC_DOC_NUM = intNuevo
                chdr.HDoc_Doc_Fec_NET = cFunciones.HoyMySQL
                chdr.HDOC_RF1_NUM = INT_CERO 'solicitado
                chdr.HDOC_DOC_STATUS = INT_UNO 'activ
                If chdr.Guardar = True Then

                    loghdr = True

                Else
                    MsgBox(chdr.MERROR.ToString)
                End If
            Else
                intNuevo = celdaIdPagare.Text
                chdr.HDOC_DOC_ANO = celdaAño.Text
                chdr.HDOC_DOC_NUM = intNuevo
                chdr.HDoc_Doc_Fec_NET = dtpFecha.Value
                If celdaEstado.BackColor = Color.LightYellow Then
                   chdr.HDOC_RF1_NUM = INT_CERO 'solicitado
                Else
                    chdr.HDOC_RF1_NUM = INT_UNO  'aprobado
                End If

                If checkActivo.Checked = True Then
                    chdr.HDOC_DOC_STATUS = INT_UNO 'activo
                Else
                    chdr.HDOC_DOC_STATUS = INT_CERO  'inactivo
                End If
                If chdr.Actualizar = True Then

                    loghdr = True

                Else
                    MsgBox(chdr.MERROR.ToString)
                End If
            End If
            
            If loghdr = True Then
                If logGuardar = False Then
                    strCondicion = "DDoc_Sis_Emp = {empresa} and DDoc_Doc_Cat = 29 and DDoc_Doc_Ano = {ano} and DDoc_Doc_Num = {numero}"
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{ano}", chdr.HDOC_DOC_ANO)
                    strCondicion = Replace(strCondicion, "{numero}", chdr.HDOC_DOC_NUM)
                    cdtl.CONEXION = strConexion
                    If cdtl.Borrar(strCondicion) Then
                        loghdr = True
                    Else
                        MsgBox(cdtl.MERROR.ToString)
                    End If
                End If
                If loghdr Then
                    For i = 0 To dgDetalle.Rows.Count - 1
                        cdtl.CONEXION = strConexion
                        cdtl.DDOC_SIS_EMP = chdr.HDOC_SIS_EMP
                        cdtl.DDOC_DOC_CAT = chdr.HDOC_DOC_CAT
                        cdtl.DDOC_DOC_NUM = chdr.HDOC_DOC_NUM
                        cdtl.DDOC_DOC_LIN = i + 1
                        cdtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("cod").Value
                        cdtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("Yarn").Value
                        cdtl.DDOC_RF3_NUM = dgDetalle.Rows(i).Cells("idorigen").Value
                        cdtl.DDOC_RF3_TXT = dgDetalle.Rows(i).Cells("source").Value
                        cdtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("ultimo_precio").Value
                        cdtl.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("ultimo_pedido").Value
                        cdtl.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("available").Value
                        cdtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("Price").Value
                        cdtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("Quantity").Value
                        cdtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("idpoveedor").Value
                        cdtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("proveedor").Value
                        cdtl.DDOC_RF2_NUM = dgDetalle.Rows(i).Cells("idprograma").Value
                        cdtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("program").Value
                        If cdtl.Guardar = True Then
                            'Dim citm As New Tablas.TDCMTOS_DTL_ITM
                            'Dim j As Integer = INT_CERO
                            'For h = 0 To dgInventario.Rows.Count - 1
                            '    j = j + 1
                            '    citm.CONEXION = strConexion
                            '    citm.IDOC_SIS_EMP = cdtl.DDOC_SIS_EMP
                            '    citm.IDOC_DOC_CAT = cdtl.DDOC_DOC_CAT
                            '    citm.IDOC_DOC_ANO = cdtl.DDOC_DOC_ANO
                            '    citm.IDOC_DOC_NUM = cdtl.DDOC_DOC_NUM
                            '    citm.IDOC_DOC_LIN = cdtl.DDOC_DOC_LIN
                            '    citm.IDOC_DOC_ITM = j
                            '    citm.IDOC_ITM_DES = dgInventario.Rows(h).Cells("").Value
                            'Next
                        Else
                            MsgBox(cdtl.MERROR.ToString)
                        End If
                    Next
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarDocumentos(Optional ByVal logFechas As Boolean = False)
        Try
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim REA As MySqlDataReader
           
            strSQL &= " select h.HDoc_Doc_Ano ano , h.HDoc_Doc_Num  num ,h.HDoc_Doc_Fec fec , h.HDoc_Emp_Nom cli ,if(h.HDoc_RF1_Num =1,'APPROVED', 'REQUESTED') estado, if(h.HDoc_Doc_Status = 1,'ON', 'OFF') activo  "
            strSQL &= " from Dcmtos_HDR h "
            strSQL &= " where h.HDoc_Sis_Emp = 3 and h.HDoc_Doc_Cat = 29 "
            If logFechas = True Then
                strSQL &= " and h.HDoc_Doc_Fec between '{inicio}' and '{fin}' "
                strSQL = Replace(strSQL, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
                strSQL = Replace(strSQL, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))
            End If
            strSQL &= " order by h.HDoc_Doc_Fec desc "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgLista.Rows.Clear()
                Do While REA.Read
                    Dim Cell As DataGridViewCell
                    Dim Row = New DataGridViewRow
                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetInt32("ano").ToString
                    Row.Cells.Add(Cell)

                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetInt32("num").ToString
                    Row.Cells.Add(Cell)

                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetMySqlDateTime("fec").ToString
                    Row.Cells.Add(Cell)

                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetString("cli").ToString
                    Row.Cells.Add(Cell)

                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetString("estado").ToString
                    If REA.GetString("estado") = "REQUESTED" Then
                        Cell.Style.BackColor = Color.LightYellow
                    Else
                        Cell.Style.BackColor = Color.Aqua
                    End If
                    Row.Cells.Add(Cell)

                    Cell = New DataGridViewTextBoxCell
                    Cell.Value = REA.GetString("activo").ToString
                    If REA.GetString("activo") = "ON" Then
                        Cell.Style.BackColor = Color.LimeGreen
                    Else
                        Cell.Style.BackColor = Color.Coral
                    End If
                    Row.Cells.Add(Cell)
                    dgLista.Rows.Add(Row)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SeleccionarDocumento(ByVal id As Integer, ByVal ano As Integer)
        Try
            Dim strCondicion As String = STR_VACIO
            Dim strCampos As String = STR_VACIO
            Dim chdr As New clsDcmtos_HDR
            Dim cdtl As New clsDcmtos_DTL
            chdr.CONEXION = strConexion
            strCampos = " HDoc_Doc_Ano, HDoc_Doc_Num, HDoc_Emp_Nom, HDoc_Emp_Cod, HDoc_Doc_Fec, HDoc_Emp_Dir, HDoc_Doc_Mon, HDoc_Doc_TC, HDoc_RF1_Num, HDoc_Doc_Status "
            strCondicion = "HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 29 and HDoc_Doc_Num = {numero} and HDoc_Doc_Ano = {ano} "
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{numero}", id)
            strCondicion = Replace(strCondicion, "{ano}", ano)


            If chdr.Seleccionar(strCondicion, strCampos) Then
                celdaAño.Text = chdr.HDOC_DOC_ANO.ToString
                celdaIdPagare.Text = chdr.HDOC_DOC_NUM.ToString
                etiquetaCliente.Text = chdr.HDOC_EMP_NOM
                etiquetaIdCliente.Text = chdr.HDOC_EMP_COD.ToString
                dtpFecha.Value = chdr.HDOC_DOC_FEC
                etiquetaDireccion.Text = chdr.HDOC_EMP_DIR
                etiquetaMoneda.Text = chdr.HDOC_DOC_MON.ToString
                celdaTasa.Text = chdr.HDOC_DOC_TC.ToString
                If chdr.HDOC_DOC_STATUS = INT_CERO Then
                    checkActivo.Checked = False
                Else
                    checkActivo.Checked = True
                End If
                If chdr.HDOC_RF1_NUM = INT_CERO Then
                    celdaEstado.Text = "REQUESTED"
                    celdaEstado.BackColor = Color.LightYellow
                Else
                    celdaEstado.Text = "APPROVED"
                    celdaEstado.BackColor = Color.LimeGreen
                End If

                strCampos = " DDoc_Prd_Cod, DDoc_Prd_Des,DDoc_Prd_PUQ,DDoc_Prd_DSP,DDoc_Prd_DSQ, DDoc_Prd_NET, DDoc_Prd_QTY, DDoc_RF1_Num, DDoc_RF1_Cod, DDoc_RF3_Num, DDoc_RF3_Txt,   DDoc_RF2_Num,DDoc_RF2_Cod "
                strCondicion = Replace(strCondicion, "HDoc_", "DDoc_")
                Dim connnn As MySqlConnection
                Dim COM As MySqlCommand
                Dim reeaaa As MySqlDataReader
                MyCnn.CONECTAR = strConexion
                connnn = New MySqlConnection
                connnn.ConnectionString = strConexion
                connnn.Open()
                COM = New MySqlCommand(" SELECT " & strCampos & "  from Dcmtos_DTL WHERE " & strCondicion, connnn)
                reeaaa = COM.ExecuteReader
                If reeaaa.HasRows Then
                    Do While reeaaa.Read And reeaaa.HasRows
                        cFunciones.AgregarFila(dgDetalle, reeaaa.GetInt32("DDoc_Prd_Cod") & "|" & reeaaa.GetString("DDoc_Prd_Des") & "|" & reeaaa.GetInt32("DDoc_RF3_Num") & "|" & reeaaa.GetString("DDoc_RF3_Txt") & "|" & reeaaa.GetDouble("DDoc_Prd_QTY") & "|" & reeaaa.GetDouble("DDoc_Prd_PUQ") & "|" & reeaaa.GetDouble("DDoc_Prd_DSP") & "|" & reeaaa.GetDouble("DDoc_Prd_NET") & "|" & reeaaa.GetInt32("DDoc_RF2_Num") & "|" & reeaaa.GetString("DDoc_RF2_Cod") & "|" & reeaaa.GetDouble("DDoc_Prd_DSQ") & "|" & reeaaa.GetInt32("DDoc_RF1_Num") & "|" & reeaaa.GetString("DDoc_RF1_Cod"))
                    Loop
                    connnn.Close()
                End If

                   
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Function ComprobarPrivilecios(ByVal strusuario As String) As Boolean
        Dim logresult As Boolean = False
        Dim intsuper As Integer = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        strSQL &= " select COUNT(*) from Permisos p "
        strSQL &= " where p.pms_empresa ={empresa} AND p.pms_modulo= 110 and p.pms_usuario= '{usuario}' and p.pms_codigo = 'ALL' "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            intsuper = COM.ExecuteScalar
            If intsuper > INT_CERO Then
                logresult = True
            Else
                logresult = False
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logresult
    End Function

#End Region

    Private Sub frmCotizacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        superUsuario = ComprobarPrivilecios(Sesion.Usuario)
        MostrarLista(True)

    End Sub

    Private Sub frmCotizacion_FormClosed(sender As Object, e As FormClosedEventArgs)

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strkey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonBuscarCliente_Click(sender As Object, e As EventArgs) Handles botonBuscarCliente.Click
        Dim strCondicion As String = STR_VACIO
        Dim frm As New frmSeleccionar

        strCondicion = "cli_sisemp= " & Sesion.IdEmpresa
        frm.Tabla = "Clientes"
        frm.Campos = "cli_codigo Code, cli_cliente Customer, cli_direccion Address"
        frm.Condicion = strCondicion
        frm.Limite = 50
        frm.Filtro = "cli_cliente"
        frm.Titulo = "Customer"
        frm.FiltroText = "Enter the customer's name to filter out"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            etiquetaIdCliente.Text = frm.LLave
            etiquetaCliente.Text = frm.Dato
            etiquetaDireccion.Text = frm.Dato2

            botonAgregar.Enabled = True
            botonAgregar.Focus()
        End If
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frm As New frmSeleccionar
        Dim frmmjs As New frmMensaje
        Dim dblUltimoPrecioQ As Double = 0
        Dim dblUltimoPrecioPO As Double = 0

        frm.Tabla = " Inventarios i left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo left join Catalogos c on c.cat_num = i.inv_lugarfab "
        frm.Campos = " i.inv_numero Code, a.art_DCorta Yarn,  c.cat_num id_source, c.cat_desc Source "
        frm.Condicion = " i.inv_sisemp = " & Sesion.IdEmpresa & " and i.inv_generico = 1 "
        frm.Limite = 20
        frm.Filtro = " a.art_DCorta "
        frm.Titulo = " Generics Codes "
        frm.FiltroText = " Enter the description of the yarn to filter out "
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

            frmmjs.Mensaje = "Consulting Data"
            frmmjs.Show()
            system.Windows.Forms.Application.DoEvents()
            ObterInvenario(CInt(frm.LLave))

            CargarInventario()
            CargarOrdenes()
            CargarPO()
            CargarReserva()
            CalcularTotales()

            cFunciones.AgregarFila(dgDetalle, frm.LLave & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & "0" & "|" & UltimoPrecio("Cotizacion", frm.LLave, etiquetaIdCliente.Text) & "|" & UltimoPrecio("PO", frm.LLave, etiquetaIdCliente.Text) & "|" & "0" & "|" & "0" & "|" & "" & "|" & celdaInventario.Text & "|" & "0" & "|" & "")
            If superUsuario Then
                dgDetalle.Columns("Price").ReadOnly = False
            Else
                dgDetalle.Columns("Price").ReadOnly = True
            End If

            frmmjs.Close()
        End If

    End Sub

    Private Sub dgDetalle_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellDoubleClick
        Dim frm As New frmSeleccionar
        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 12
                If superUsuario Then

                    frm.Tabla = "Proveedores"
                    frm.Condicion = "  pro_status= 'Activo' and pro_fabricante = 'Si' and pro_sisemp = " & Sesion.IdEmpresa
                    frm.Campos = "pro_codigo Code, pro_proveedor Program "
                    frm.Filtro = " pro_proveedor "
                    frm.Titulo = " Mill "
                    frm.FiltroText = " Enter the Mill's name to filter out "
                    If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                        dgDetalle.CurrentCell.Value = frm.Dato
                        dgDetalle.CurrentRow.Cells("idpoveedor").Value = frm.LLave
                    End If
                End If
            Case 9
                frm.Tabla = "Catalogos"
                frm.Condicion = "cat_clase ='Programa'"
                frm.Campos = "cat_num Code, cat_clave Program "
                frm.Filtro = " cat_clave"
                frm.Titulo = " Programs "
                frm.FiltroText = " Enter the description of program to filter out "
                If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then

                    dgDetalle.CurrentCell.Value = frm.Dato
                    dgDetalle.CurrentRow.Cells("idprograma").Value = frm.LLave

                End If
        End Select
        If dgDetalle.CurrentCell.ColumnIndex = 8 Then


        End If
    End Sub

    Private Sub botonQuitar_Click(sender As Object, e As EventArgs) Handles botonQuitar.Click
        If dgDetalle.SelectedRows.Count = NO_FILA Then Exit Sub
        dgDetalle.Rows.Remove(dgDetalle.CurrentRow)
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Try
            frm.Tabla = " Catalogos "
            frm.Campos = " cat_num Code, cat_clave Currency , cat_desc description "
            frm.Condicion = " cat_clase =  'Monedas' "
            frm.Limite = 20
            frm.Filtro = " cat_clave "
            frm.Titulo = " Currency "
            frm.FiltroText = " Enter the symbol  to filter out "
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                celdaMoneda.Text = frm.Dato
                etiquetaMoneda.Text = frm.LLave
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If PanelDatos.Visible = True Then
            MostrarLista(True)
        Else
            Me.Close()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If Me.Tag = "mod" Then
            Guardar(False)
        Else
            Guardar()
        End If

        MostrarLista(True)
    End Sub

    Private Sub dgDetalle_SelectionChanged(sender As Object, e As EventArgs) Handles dgDetalle.SelectionChanged
        If dgDetalle.RowCount = INT_CERO Then
            Exit Sub
        End If
        If Not intLinea = dgDetalle.CurrentRow.Index Then
            Dim frmmjs As New frmMensaje
            frmmjs.Mensaje = "Consulting Data"
            frmmjs.Show()
            system.Windows.Forms.Application.DoEvents()
            ObterInvenario(CInt(dgDetalle.CurrentRow.Cells("cod").Value))

            CargarInventario()
            CargarOrdenes()
            CargarPO()
            CargarReserva()
            CalcularTotales()
            frmmjs.Close()
            intLinea = dgDetalle.CurrentRow.Index
        End If

    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        MostrarLista(False)
        Reset()
        Me.Tag = "Nuevo"
    End Sub

    Private Sub botonFiltrar_Click(sender As Object, e As EventArgs) Handles botonFiltrar.Click
        CargarDocumentos(True)
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            intID = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(1).Value
            Reset()
            SeleccionarDocumento(intAño, intID)
            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub celdaEstado_Click(sender As Object, e As EventArgs) Handles celdaEstado.Click
        If celdaEstado.BackColor = Color.LightYellow Then
            celdaEstado.Text = "APPROVED"
            celdaEstado.BackColor = Color.LimeGreen
        Else
            celdaEstado.Text = "REQUESTED"
            celdaEstado.BackColor = Color.LightYellow
        End If
    End Sub

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub
End Class