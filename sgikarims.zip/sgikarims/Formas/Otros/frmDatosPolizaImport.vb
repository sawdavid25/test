﻿Public Class frmDatosPolizaImport

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Ordenes de Compra")
            'Cargar Datos
            'cfun.CargarLista(dgLista, SQLLista, False)
            'Mostrar Panel Filtro
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
            Me.Tag = ""
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modificar Registro")
                Me.Tag = ""
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("Nuevo Registro")
                Me.Tag = "Nuevo"
                BloquearBotones(False)

                reset()
            End If

            dgLista.DataSource = Nothing
        End If
    End Sub
#End Region

#Region "Eventos VB.NET"

    Private Sub frmDatosPolizaImport_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Try
            frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub frmDatosPolizaImport_load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFinal.Value = Today
        dtpInicio.Value = dtpFinal.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
    End Sub


#End Region


    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub
End Class