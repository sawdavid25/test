﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBCuentas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBCuentas))
        Me.Documento = New KARIMs_SGI.usrBancoDocumento()
        Me.Lista = New KARIMs_SGI.usrBancoLista()
        Me.Cuenta = New KARIMs_SGI.usrBancoCuenta()
        Me.Titulo = New KARIMs_SGI.BarraTitulo()
        Me.Botones = New KARIMs_SGI.encabezado()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Documento
        '
        Me.Documento.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Documento.Ciclo = 0
        Me.Documento.Cuenta = 0
        Me.Documento.Documento = 0
        Me.Documento.Grupo = 0
        Me.Documento.Location = New System.Drawing.Point(12, 135)
        Me.Documento.Moneda = 0
        Me.Documento.Name = "Documento"
        Me.Documento.Nota_ = ""
        Me.Documento.Numero = 0
        Me.Documento.Size = New System.Drawing.Size(673, 465)
        Me.Documento.TabIndex = 4
        Me.Documento.Tipo = 0
        Me.Documento.Titulo = "Document"
        Me.Documento.Visible = False
        '
        'Lista
        '
        Me.Lista.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Lista.Location = New System.Drawing.Point(726, 104)
        Me.Lista.Name = "Lista"
        Me.Lista.Size = New System.Drawing.Size(158, 166)
        Me.Lista.TabIndex = 2
        '
        'Cuenta
        '
        Me.Cuenta.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Cuenta.EsNuevo = False
        Me.Cuenta.ID = 0
        Me.Cuenta.Location = New System.Drawing.Point(0, 104)
        Me.Cuenta.Name = "Cuenta"
        Me.Cuenta.Size = New System.Drawing.Size(884, 499)
        Me.Cuenta.TabIndex = 3
        Me.Cuenta.Visible = False
        '
        'Titulo
        '
        Me.Titulo.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Titulo.Dock = System.Windows.Forms.DockStyle.Top
        Me.Titulo.Location = New System.Drawing.Point(0, 65)
        Me.Titulo.Name = "Titulo"
        Me.Titulo.Size = New System.Drawing.Size(884, 28)
        Me.Titulo.TabIndex = 1
        Me.Titulo.TabStop = False
        '
        'Botones
        '
        Me.Botones.Dock = System.Windows.Forms.DockStyle.Top
        Me.Botones.Location = New System.Drawing.Point(0, 0)
        Me.Botones.Name = "Botones"
        Me.Botones.Size = New System.Drawing.Size(884, 65)
        Me.Botones.TabIndex = 0
        '
        'botonImprimir
        '
        Me.botonImprimir.Enabled = False
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print
        Me.botonImprimir.Location = New System.Drawing.Point(203, 9)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(56, 45)
        Me.botonImprimir.TabIndex = 1
        Me.botonImprimir.Text = "&Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        Me.botonImprimir.Visible = False
        '
        'frmBCuentas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(884, 601)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.Documento)
        Me.Controls.Add(Me.Lista)
        Me.Controls.Add(Me.Titulo)
        Me.Controls.Add(Me.Botones)
        Me.Controls.Add(Me.Cuenta)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmBCuentas"
        Me.Text = "Cuentas Bancarias"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Botones As encabezado
    Friend WithEvents Titulo As BarraTitulo
    Friend WithEvents Lista As usrBancoLista
    Friend WithEvents Cuenta As usrBancoCuenta
    Friend WithEvents Documento As usrBancoDocumento
    Friend WithEvents botonImprimir As Button
End Class
