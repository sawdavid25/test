﻿Public Class FrmCompras
#Region "Variables"
    Dim strKey As String = STR_VACIO
#End Region
#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region
#Region "Funciones"
    Private Function SQLCompras() As String
        Dim strSQL As String = STR_VACIO
        Dim Fecha As DateTime
        Dim FechaFinal As DateTime


        strSQL = " SELECT HDoc_Doc_Ano Anio, HDoc_Doc_Num Numero, HDoc_Doc_Fec Fecha, MONTH(HDoc_Doc_Fec) Mes, HDoc_Doc_Status Estado "
        strSQL &= " FROM Dcmtos_HDR "
        strSQL &= " WHERE HDoc_Sis_Emp={empresa} AND HDoc_Doc_Cat=286 AND HDoc_Doc_Fec BETWEEN '{fechainicial}' AND '{fechafinal}' "
        If checkFiltro.Checked = True Then
            strSQL &= " And HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafinal}' "
            strSQL = Replace(strSQL, "{fechainicio}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        End If
        strSQL &= " ORDER BY HDoc_Doc_Fec "

        If checkFiltro.Checked = True Then
            Fecha = dtpFechaInicio.Value
            FechaFinal = dtpFechaFinal.Value
        Else
            Fecha = DateSerial(Year(DateTime.Now) - 1, Month(DateTime.Now), 1)
            FechaFinal = DateSerial(Year(DateTime.Now) + 1, Month(DateTime.Now), 1)
        End If


        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{fechainicial}", Fecha.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fechafinal}", FechaFinal.ToString(FORMATO_MYSQL))
        Return strSQL
    End Function
    Public Sub CargarLibroCompras()
        Dim strSQL As String
        Dim strLinea As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = SQLCompras()
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            dgSeleccionCompras.Rows.Clear()
            Do While REA.Read
                strLinea = REA.GetInt32("Anio") & "|"
                strLinea &= REA.GetInt32("Numero") & "|"
                strLinea &= REA.GetDateTime("Fecha") & "|"
                strLinea &= UCase(MonthName(REA.GetInt32("Mes"))) & "|"
                If REA.GetInt32("Estado") = INT_UNO Then
                    strLinea &= "CERRADO"
                Else
                    strLinea &= ""
                End If
                cFunciones.AgregarFila(dgSeleccionCompras, strLinea)
            Loop
        End If


    End Sub
    Private Function sqlLibroCompras(ByVal intAnio As Integer, ByVal intNumero As Integer) As String
        Dim strSQL As String = STR_VACIO
        'strSQL = " SELECT DDoc_Doc_Cat catalogo,DDoc_Doc_Ano Anio,d.DDoc_Doc_Num id,d.DDoc_Doc_Lin Linea,SUBSTRING_INDEX(CONCAT(d.DDoc_RF2_Txt,'|'),'|',1) relacion, '' regimen, SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT(d.DDoc_RF2_Txt,'|'),'|',2),'|',-1) correlativo, d.DDoc_RF1_Fec fecha, SUBSTRING_INDEX(CONCAT(d.DDoc_RF1_Txt,'|'),'|',1) numero, "
        'strSQL &= " SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT(d.DDoc_RF1_Txt,'|'),'|',2),'|',-1) tipo, SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT(d.DDoc_RF1_Txt,'|'),'|',3),'|',-1) nit, d.DDoc_Prd_Des proveedor, d.DDoc_Prd_PNr clase, d.DDoc_Prd_Fob exento, IF(d.DDoc_Prd_PNr IN ('C','NC'),d.DDoc_RF1_Dbl,0) base_bienes, IF(d.DDoc_Prd_PNr='S',d.DDoc_RF1_Dbl,0) base_servicios, 0 base_importaciones, IF(d.DDoc_Prd_PNr='I',d.DDoc_RF1_Dbl,0) base_2989, IF(d.DDoc_Prd_PNr IN ('C','NC'),d.DDoc_RF2_Dbl,0) iva_bienes, "
        'strSQL &= " IF(d.DDoc_Prd_PNr='S',d.DDoc_RF1_Dbl,0) base_servicios, 0 base_importaciones, IF(d.DDoc_Prd_PNr='I',d.DDoc_RF1_Dbl,0) base_2989, IF(d.DDoc_Prd_PNr IN ('C','NC'),d.DDoc_RF2_Dbl,0) iva_bienes, IF(d.DDoc_Prd_PNr='S',d.DDoc_RF2_Dbl,0) iva_servicios, 0 base_importaciones1, IF(d.DDoc_Prd_PNr='I',d.DDoc_RF2_Dbl,0) iva_2989, d.DDoc_RF3_Dbl directo, SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT(d.DDoc_RF2_Txt,'|'),'|',3),'|',-1) cuenta, d.DDoc_Prd_Cif total, d.DDoc_RF1_Num ref_tipo, d.DDoc_RF2_Num ref_anio, d.DDoc_RF3_Num ref_numero, '' tag, '' notas, IFNULL(d.DDoc_Prd_PUQ,-1) fiscal, IFNULL(("
        'strSQL &= " SELECT CAST(t.poliza AS CHAR)  "
        'strSQL &= " FROM contahilos.detalle_polizas t "
        'strSQL &= " WHERE t.empresa=d.DDoc_Sis_Emp AND t.ref_tipo=d.DDoc_RF1_Num AND t.ref_ciclo=d.DDoc_RF2_Num AND t.ref_numero=d.DDoc_RF3_Num LIMIT 1),'') poliza, IFNULL(("
        'strSQL &= " SELECT IFNULL(SUM(t.importe),0) "
        'strSQL &= " FROM contahilos.detalle_polizas t "
        'strSQL &= " WHERE t.empresa=d.DDoc_Sis_Emp AND t.ref_tipo=d.DDoc_RF1_Num AND t.ref_ciclo=d.DDoc_RF2_Num AND t.ref_numero=d.DDoc_RF3_Num AND t.operacion='C'),'') importe "
        'strSQL &= " FROM Dcmtos_DTL d "
        'strSQL &= " WHERE d.DDoc_Sis_Emp={empresa} AND d.DDoc_Doc_Cat=286 AND d.DDoc_Doc_Ano={anio} AND d.DDoc_Doc_Num={numero} "
        strSQL = " SELECT e1.*, ROUND((e1.total - e1.importe),2) dif "
        strSQL &= "     FROM ( "
        strSQL &= "         SELECT d.DDoc_RF1_Cod id,d.DDoc_Doc_Cat catalogo,d.DDoc_Doc_Ano Anio,d.DDoc_Doc_Num num,d.DDoc_Doc_Lin fila, DDoc_Prd_UM grupo, "
        strSQL &= "             1 linea, SUBSTRING_INDEX(CONCAT(d.DDoc_RF2_Txt,'|'),'|',1) relacion, '' regimen, SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT(d.DDoc_RF2_Txt,'|'),'|',2),'|',-1) correlativo, "
        strSQL &= "                 d.DDoc_RF1_Fec fecha, IFNULL(SUBSTRING_INDEX(CONCAT(d.DDoc_RF1_Txt,'|'),'|',1),'N/A') numero, "
        strSQL &= "                     d.DDoc_Prd_PNr tipo, IFNULL(SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT(d.DDoc_RF1_Txt,'|'),'|',3),'|',-1),'N/A') nit, "
        strSQL &= "                         d.DDoc_Prd_Des proveedor, IFNULL(d.DDoc_RF2_Cod,d.DDoc_Prd_PNr) clase, d.DDoc_Prd_Fob exento, IF(d.DDoc_RF2_Cod IN ('C','B','NC','ND'),d.DDoc_RF1_Dbl,0) base_bienes, "
        strSQL &= "                             IF(d.DDoc_RF2_Cod='S',d.DDoc_RF1_Dbl,0) base_servicios, 0 base_importaciones, IF(d.DDoc_RF2_Cod='I',d.DDoc_RF1_Dbl,0) base_2989, "
        strSQL &= "                                 IF(d.DDoc_RF2_Cod IN ('C','B','NC','ND'),d.DDoc_RF2_Dbl,0) iva_bienes, IF(d.DDoc_RF2_Cod='S',d.DDoc_RF2_Dbl,0) iva_servicios, "
        strSQL &= "                                     0 iva_importaciones, IF(d.DDoc_RF2_Cod='I',d.DDoc_RF2_Dbl,0) iva_2989, d.DDoc_RF3_Dbl directo, SUBSTRING_INDEX(SUBSTRING_INDEX(CONCAT (d.DDoc_RF2_Txt,'|'),'|',3),'|',-1) cuenta, "
        strSQL &= "                                         d.DDoc_Prd_Cif total, d.DDoc_RF1_Num ref_tipo, d.DDoc_RF2_Num ref_anio, d.DDoc_RF3_Num ref_numero, '' tag, '' notas, IFNULL(d.DDoc_Prd_PUQ,-1) fiscal, "
        strSQL &= "                                             IFNULL(( "
        strSQL &= "                                                 SELECT CAST(t.poliza AS CHAR) "
        strSQL &= "                                                     FROM {conta}.detalle_polizas t "
        strSQL &= "                                                         WHERE t.empresa=d.DDoc_Sis_Emp AND t.ref_tipo=d.DDoc_RF1_Num AND t.ref_ciclo=d.DDoc_RF2_Num AND t.ref_numero=d.DDoc_RF3_Num LIMIT 1),'') poliza, IFNULL(( "
        strSQL &= "                                                             SELECT IFNULL(SUM(t.importe),0) "
        strSQL &= "                                                                 FROM {conta}.detalle_polizas t "
        strSQL &= "                                                                     WHERE t.empresa=d.DDoc_Sis_Emp AND t.ref_tipo=d.DDoc_RF1_Num AND t.ref_ciclo=d.DDoc_RF2_Num AND t.ref_numero=d.DDoc_RF3_Num AND t.operacion='C'),'') importe "
        strSQL &= "                                                                         FROM Dcmtos_DTL d "
        strSQL &= "                                                                             WHERE d.DDoc_Sis_Emp= {empresa} AND d.DDoc_Doc_Cat=286 AND d.DDoc_Doc_Ano= {anio} AND d.DDoc_Doc_Num= {numero} "
        If checkFiltro.Checked = True Then
            strSQL &= " And d.DDoc_RF1_Fec between '{fechainicio}' AND '{fechafinal}' "
            strSQL = Replace(strSQL, "{fechainicio}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fechafinal}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))
        End If
        If celdaProveedor.Text <> STR_VACIO Then
            strSQL &= " AND d.DDoc_Prd_Des= '{proveedor}'"
            strSQL = Replace(strSQL, "{proveedor}", celdaProveedor.Text)
        End If
        If celdaNumero.Text <> STR_VACIO Then
            strSQL &= " AND d.DDoc_RF1_Txt  LIKE '%{id}%'  "
            strSQL = Replace(strSQL, "{id}", celdaNumero.Text)
        End If
        If celdaTipo.Text <> STR_VACIO Then
            strSQL &= " AND d.DDoc_Prd_PNr  LIKE '%{tipo}%'  "
            strSQL = Replace(strSQL, "{tipo}", celdaTipo.Text)
        End If
        strSQL &= "  )e1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{numero}", intNumero)
        strSQL = Replace(strSQL, "{conta}", cFunciones.ContaEmpresa)

        Return strSQL
    End Function
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = False
            'botonInprimir.Enabled = False
            etiquetaNumero.Visible = False
            celdaNumero.Visible = False
            etiquetaProveedor.Visible = False
            celdaProveedor.Visible = False
            botonProveedor.Visible = False
            botonTipo.Visible = False
            etiquetaTipo.Visible = False
            celdaTipo.Visible = False
            botonTipo.Visible = False
            botonBuscar.Visible = False
            botonRefresh.Visible = False

        Else
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            Encabezado1.botonNuevo.Enabled = False
            etiquetaNumero.Visible = True
            celdaNumero.Visible = True
            etiquetaProveedor.Visible = True
            celdaProveedor.Visible = True
            botonProveedor.Visible = True
            botonTipo.Visible = True
            etiquetaTipo.Visible = True
            celdaTipo.Visible = True
            botonTipo.Visible = True
            botonBuscar.Visible = True
            botonRefresh.Visible = True
            ' botonInprimir.Enabled = True
        End If
    End Sub
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True)
        If logMostrar = True Then
            PanelLista.Dock = DockStyle.Fill
            PanelLista.Visible = True
            BarraTitulo1.CambiarTitulo("Libro de Compras")
            PanelDocumento.Visible = False
            PanelDocumento.Dock = DockStyle.None
            panelTotales.Dock = DockStyle.None
            panelTotales.Visible = False
            BloquearBotones()
        Else
            BarraTitulo1.CambiarTitulo("Libro de Compras  " & dgSeleccionCompras.CurrentRow.Cells("colAnio").Value & "  " & dgSeleccionCompras.CurrentRow.Cells("colMes").Value & "")
            PanelLista.Dock = DockStyle.None
            PanelLista.Visible = False
            panelTotales.Visible = True
            panelTotales.Dock = DockStyle.Bottom
            PanelDocumento.Visible = True
            PanelDocumento.Dock = DockStyle.Fill
            BloquearBotones(False)
        End If
        ' panelLista.Visible = False
        ' panelLista.Dock = DockStyle.None
        ' panelDocumento.Dock = DockStyle.Fill
        ' panelDocumento.Visible = True
    End Sub
    Public Sub LibroCompras(ByVal intAnio As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim strFila As String
        Dim dblBienes As Double
        Dim dblServicios As Double
        Dim dbl65_69 As Double
        Dim dblBienes2 As Double
        Dim dblServicios2 As Double
        Dim dbl65_2 As Double
        Dim dblIMP As Double
        Dim dblTotal As Double
        Dim dblGrandTotal As Double
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = sqlLibroCompras(intAnio, intNumero)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                ' dgLibroCompras.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetString("regimen") & "|"
                    strFila &= REA.GetString("correlativo") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("numero") & "|"
                    strFila &= REA.GetString("tipo") & "|"
                    strFila &= REA.GetString("nit") & "|"
                    strFila &= REA.GetString("proveedor") & "|"
                    strFila &= REA.GetString("clase") & "|"
                    strFila &= REA.GetInt32("exento") & "|"
                    strFila &= REA.GetDouble("base_bienes") & "|"
                    strFila &= REA.GetDouble("base_servicios") & "|"
                    strFila &= REA.GetDouble("base_importaciones") & "|"
                    strFila &= REA.GetDouble("base_2989") & "|"
                    strFila &= REA.GetDouble("iva_bienes") & "|"
                    strFila &= REA.GetDouble("iva_servicios") & "|"
                    strFila &= REA.GetDouble("iva_importaciones") & "|"
                    strFila &= REA.GetDouble("iva_2989") & "|"
                    strFila &= REA.GetDouble("directo") & "|"

                    dblGrandTotal = REA.GetInt32("exento") + REA.GetDouble("base_bienes") + REA.GetDouble("base_servicios") + REA.GetDouble("base_importaciones") + REA.GetDouble("base_2989") + REA.GetDouble("iva_bienes") + REA.GetDouble("iva_servicios") + REA.GetDouble("iva_importaciones") + REA.GetDouble("iva_2989") + REA.GetDouble("directo")

                    strFila &= dblGrandTotal.ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("cuenta") & "|"
                    strFila &= REA.GetString("ref_tipo") & "|"
                    strFila &= REA.GetString("ref_anio") & "|"
                    strFila &= REA.GetString("ref_numero") & "|"
                    strFila &= REA.GetString("importe") & "|"
                    strFila &= REA.GetInt32("catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("num") & "|"
                    strFila &= REA.GetInt32("fila")
                    dblBienes = dblBienes + REA.GetDouble("base_bienes")
                    dblServicios = dblServicios + REA.GetDouble("base_servicios")
                    dbl65_69 = dbl65_69 + REA.GetDouble("base_2989")
                    dblBienes2 = dblBienes2 + REA.GetDouble("iva_bienes")
                    dblServicios2 = dblServicios2 + REA.GetDouble("iva_servicios")
                    dbl65_2 = dbl65_2 + REA.GetDouble("iva_2989")
                    dblIMP = dblIMP + REA.GetDouble("directo")
                    dblTotal = dblTotal + REA.GetDouble("total")
                    cFunciones.AgregarFila(dgLibroCompras, strFila)
                Loop
                celdaBienes.Text = dblBienes.ToString(FORMATO_MONEDA)
                celdaServicio.Text = dblServicios.ToString(FORMATO_MONEDA)
                celdaIMP6589.Text = dbl65_69.ToString(FORMATO_MONEDA)
                celdaBienes2.Text = dblBienes2.ToString(FORMATO_MONEDA)
                celdaServicios2.Text = dblServicios2.ToString(FORMATO_MONEDA)
                celdaIMP65892.Text = dbl65_2.ToString(FORMATO_MONEDA)
                celdaOtros.Text = dblIMP.ToString(FORMATO_MONEDA)
                celdaTotal.Text = dblTotal.ToString(FORMATO_MONEDA)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarLibroCompras() As Boolean
        Dim DTL As New clsDcmtos_DTL
        Dim logVerdadero As Boolean
        DTL.CONEXION = strConexion
        Try

            DTL.DDoc_Doc_Fec_NET = dgLibroCompras.CurrentRow.Cells("colFecha").Value
            DTL.DDOC_PRD_DES = dgLibroCompras.CurrentRow.Cells("colNombreProveedor").Value
            DTL.DDOC_PRD_PNR = dgLibroCompras.CurrentRow.Cells("colISC").Value
            DTL.DDOC_PRD_FOB = dgLibroCompras.CurrentRow.Cells("colExentas").Value
            DTL.DDOC_RF1_DBL = dgLibroCompras.CurrentRow.Cells("colBienes").Value
            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "S" Then
                DTL.DDOC_RF1_DBL = dgLibroCompras.CurrentRow.Cells("colServicios").Value
            End If
            'IMP'
            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "I" Then
                DTL.DDOC_RF1_DBL = dgLibroCompras.CurrentRow.Cells("colImp65").Value
            End If
            DTL.DDOC_RF2_DBL = dgLibroCompras.CurrentRow.Cells("colBienes1").Value
            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "S" Then
                DTL.DDOC_RF2_DBL = dgLibroCompras.CurrentRow.Cells("colServicio1").Value
            End If
            'IMP'
            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "I" Then
                DTL.DDOC_RF2_DBL = dgLibroCompras.CurrentRow.Cells("colimp6589").Value
            End If
            DTL.DDOC_RF3_DBL = dgLibroCompras.CurrentRow.Cells("colDirecto").Value
            '  DTL.DDOC_PRD_CIF = dgLibroCompras.CurrenRow.Cells("colMonto").Value

            ' DTL.DDOC_RF1_NUM = dgLibroCompras.CurrenRow.Cells("colReftipo").Value
            ' DTL.DDOC_RF2_NUM = dgLibroCompras.CurrenRow.Cells("colrefAnio").Value
            'DTL.DDOC_RF3_NUM = dgLibroCompras.CurrenRow.Cells("colrefAnio").Value
            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = dgLibroCompras.CurrentRow.Cells("colCatalogo").Value
            DTL.DDOC_DOC_ANO = dgLibroCompras.CurrentRow.Cells("col_anio").Value
            DTL.DDOC_DOC_NUM = dgLibroCompras.CurrentRow.Cells("colDocumento").Value
            DTL.DDOC_DOC_LIN = dgLibroCompras.CurrentRow.Cells("colLinea").Value

            If DTL.Actualizar = False Then
                MsgBox(DTL.MERROR.ToString & "Could Not Modify this document", MsgBoxStyle.Critical)
                Return False
                Exit Function
            Else
                logVerdadero = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerdadero
    End Function
    Private Function GuardarLibro(ByVal ISC As String, ByVal intRF1 As Double, intRF2 As Double, ByVal intTotal As Double) As Boolean
        Dim logverdadero As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Try
            strSQL = " UPDATE Dcmtos_DTL d  Set d.DDoc_Prd_PNr = '" & ISC & "' , d.DDoc_RF1_Dbl = " & intRF1 & ", d.DDoc_RF2_Dbl = " & intRF2 & "   , d.DDoc_RF3_Dbl = " & dgLibroCompras.CurrentRow.Cells("colDirecto").Value & ", d.DDoc_Prd_Cif =" & intTotal & "    WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND d.DDoc_Doc_Cat = " & dgLibroCompras.CurrentRow.Cells("colCatalogo").Value & " AND d.DDoc_Doc_Ano = " & dgLibroCompras.CurrentRow.Cells("col_anio").Value & " AND d.DDoc_Doc_Num = " & dgLibroCompras.CurrentRow.Cells("colDocumento").Value & " AND d.DDoc_Doc_Lin = " & dgLibroCompras.CurrentRow.Cells("colLinea").Value & " "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE PDM.Dcmtos_DTL d  Set d.DDoc_Prd_PNr = '" & ISC & "' , d.DDoc_RF1_Dbl = " & intRF1 & ", d.DDoc_RF2_Dbl = " & intRF2 & "   , d.DDoc_RF3_Dbl = " & dgLibroCompras.CurrentRow.Cells("colDirecto").Value & ", d.DDoc_Prd_Cif =" & intTotal & "    WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND d.DDoc_Doc_Cat = " & dgLibroCompras.CurrentRow.Cells("colCatalogo").Value & " AND d.DDoc_Doc_Ano = " & dgLibroCompras.CurrentRow.Cells("col_anio").Value & " AND d.DDoc_Doc_Num = " & dgLibroCompras.CurrentRow.Cells("colDocumento").Value & " AND d.DDoc_Doc_Lin = " & dgLibroCompras.CurrentRow.Cells("colLinea").Value & " "
            End If
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logverdadero
    End Function
    Private Sub CancelarPoliza()
        Dim logVerdero As Boolean = False
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Try

            If MsgBox(" Do you want to delete this row ?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                strSQL = " UPDATE Dcmtos_DTL d  Set d.DDoc_Sis_Emp = 120  WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND d.DDoc_Doc_Cat = " & dgLibroCompras.CurrentRow.Cells("colCatalogo").Value & " AND d.DDoc_Doc_Ano = " & dgLibroCompras.CurrentRow.Cells("col_anio").Value & " AND d.DDoc_Doc_Num = " & dgLibroCompras.CurrentRow.Cells("colDocumento").Value & " AND d.DDoc_Doc_Lin = " & dgLibroCompras.CurrentRow.Cells("colLinea").Value & " "
                If Sesion.IdEmpresa = 18 Then
                    strSQL &= "; UPDATE PDM.Dcmtos_DTL d  Set d.DDoc_Sis_Emp = 120  WHERE d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND d.DDoc_Doc_Cat = " & dgLibroCompras.CurrentRow.Cells("colCatalogo").Value & " AND d.DDoc_Doc_Ano = " & dgLibroCompras.CurrentRow.Cells("col_anio").Value & " AND d.DDoc_Doc_Num = " & dgLibroCompras.CurrentRow.Cells("colDocumento").Value & " AND d.DDoc_Doc_Lin = " & dgLibroCompras.CurrentRow.Cells("colLinea").Value & " "
                End If
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()

                ResetDatagrid()
                LibroCompras(celdaAnio.Text, celdaidNumero.Text)
                Colorear()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub Colorear()

        For i As Integer = 0 To dgLibroCompras.RowCount - 1
            dgLibroCompras.Rows(i).Cells("colISC").Style.BackColor = Color.SkyBlue
        Next

    End Sub
    Private Sub Reset()
        dtpFechaInicio.Enabled = False
        dtpFechaFinal.Enabled = False
        celdaNumero.Text = STR_VACIO
        celdaProveedor.Text = STR_VACIO
        celdaTipo.Text = STR_VACIO
        checkFiltro.Checked = False
        celdaidProveedor.Text = NO_FILA
        botonAgregar.Enabled = False
    End Sub
    Public Sub ResetDatagrid()
        dgLibroCompras.Rows.Clear()
    End Sub
    Private Sub CalcularTotal()
        Dim dblTotal As Double = NO_FILA
        Dim dblCantidad As Double = NO_FILA
        Dim dblGranTotal As Double = NO_FILA
        For i As Integer = 0 To dgLibroCompras.Rows.Count - 1
            dblTotal = CDbl(dgLibroCompras.Rows(i).Cells("colExentas").Value) + CDbl(dgLibroCompras.Rows(i).Cells("colBienes").Value) + CDbl(dgLibroCompras.Rows(i).Cells("colImp65").Value) + dgLibroCompras.Rows(i).Cells("colServicios").Value
            dblCantidad = CDbl(dgLibroCompras.Rows(i).Cells("colBienes1").Value) + CDbl(dgLibroCompras.Rows(i).Cells("colServicio1").Value) + CDbl(dgLibroCompras.Rows(i).Cells("colimp6589").Value) + CDbl(dgLibroCompras.Rows(i).Cells("colDirecto").Value)
            dblGranTotal = dblTotal + dblCantidad
            dgLibroCompras.Rows(i).Cells("colMonto").Value = dblGranTotal.ToString(FORMATO_MONEDA)
        Next



    End Sub
#End Region
#Region "Eventos"
    Private Sub FrmCompras_Load(sender As Object, e As EventArgs) Handles Me.Load
        Reset()
        CargarLibroCompras()
        MostrarLista(True)
    End Sub
    Private Sub dgSeleccionCompras_DoubleClick(sender As Object, e As EventArgs) Handles dgSeleccionCompras.DoubleClick
        celdaAnio.Text = dgSeleccionCompras.CurrentRow.Cells("colAnio").Value
        celdaidNumero.Text = dgSeleccionCompras.CurrentRow.Cells("colNumero").Value
        ResetDatagrid()
        MostrarLista(False)
        LibroCompras(celdaAnio.Text, celdaidNumero.Text)

        Colorear()
    End Sub
    'Private Sub dgLibroCompras_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs)
    'End Sub
    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If PanelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub
    Private Sub dgLibroCompras_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgLibroCompras.CellEndEdit
        Dim Dato_RF1 As Double
        Dim Dato2_RF2 As Double
        Try
            CalcularTotal()
            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "C" Or dgLibroCompras.CurrentRow.Cells("colISC").Value = "NC" Or dgLibroCompras.CurrentRow.Cells("colISC").Value = "ND" Or dgLibroCompras.CurrentRow.Cells("colISC").Value = "B" Then
                Dato_RF1 = dgLibroCompras.CurrentRow.Cells("colBienes").Value
            End If
            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "S" Then
                Dato_RF1 = dgLibroCompras.CurrentRow.Cells("colServicios").Value
            End If

            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "I" Then
                Dato_RF1 = dgLibroCompras.CurrentRow.Cells("colImp65").Value
            End If


            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "C" Or dgLibroCompras.CurrentRow.Cells("colISC").Value = "NC" Or dgLibroCompras.CurrentRow.Cells("colISC").Value = "ND" Or dgLibroCompras.CurrentRow.Cells("colISC").Value = "B" Then
                Dato2_RF2 = dgLibroCompras.CurrentRow.Cells("colBienes1").Value
            End If

            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "S" Then
                Dato2_RF2 = dgLibroCompras.CurrentRow.Cells("colServicio1").Value
            End If

            If dgLibroCompras.CurrentRow.Cells("colISC").Value = "I" Then
                Dato2_RF2 = dgLibroCompras.CurrentRow.Cells("colimp6589").Value
            End If

            GuardarLibro(dgLibroCompras.CurrentRow.Cells("colISC").Value, Dato_RF1, Dato2_RF2, dgLibroCompras.CurrentRow.Cells("colMonto").Value)
            '        ' ResetDatagrid()
            '        '  GuardarLibroCompras()
            '        ' LibroCompras(celdaAnio.Text, celdaidNumero.Text)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub botonRefresh_Click_1(sender As Object, e As EventArgs) Handles botonRefresh.Click
        Reset()
        ResetDatagrid()
        LibroCompras(celdaAnio.Text, celdaidNumero.Text)
        Colorear()
    End Sub
    Private Sub botonBuscar_Click_1(sender As Object, e As EventArgs) Handles botonBuscar.Click
        CargarLibroCompras()
        ResetDatagrid()
        LibroCompras(celdaAnio.Text, celdaidNumero.Text)
        Colorear()
    End Sub
    Private Sub botonTipo_Click_1(sender As Object, e As EventArgs) Handles botonTipo.Click
        Dim frm As New frmSeleccionar

        frm.Campos = " Distinct d.DDoc_Prd_PNr Tipo "
        frm.Tabla = " Dcmtos_DTL d "
        frm.Condicion = " d.DDoc_Sis_Emp = " & Sesion.IdEmpresa & " and d.DDoc_Doc_Cat = 286 and d.DDoc_Doc_Ano = " & celdaAnio.Text & " and d.DDoc_Doc_Num  = " & celdaidNumero.Text & " "
        frm.Titulo = " Type "
        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaTipo.Text = frm.LLave
        End If
    End Sub
    Private Sub botonProveedor_Click_1(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar

        ' propiedades de consulta
        frm.Campos = " p.pro_codigo Code , p.pro_proveedor Provider "
        frm.Tabla = " Proveedores p  "
        frm.Condicion = " p.pro_sisemp = " & Sesion.IdEmpresa & ""
        frm.Ordenamiento = " Provider"
        frm.Filtro = " p.pro_proveedor"
        frm.Limite = " 20 "
        ' propiedades de formulario
        frm.Titulo = " Suppliers "
        frm.FiltroText = " Enter provider name to filter"

        frm.ShowDialog(frmSPrincipal)
        If frm.DialogResult = DialogResult.OK Then
            celdaidProveedor.Text = frm.LLave
            celdaProveedor.Text = frm.Dato
        End If
    End Sub
    Private Sub BotonDeshabilitar_Click_1(sender As Object, e As EventArgs) Handles BotonDeshabilitar.Click
        CancelarPoliza()
    End Sub
    Private Sub checkFiltro_CheckedChanged(sender As Object, e As EventArgs) Handles checkFiltro.CheckedChanged
        If checkFiltro.Checked = False Then
            dtpFechaInicio.Enabled = False
            dtpFechaFinal.Enabled = False
            botonAgregar.Enabled = False
        Else
            dtpFechaInicio.Enabled = True
            dtpFechaFinal.Enabled = True
            botonAgregar.Enabled = True
        End If

    End Sub
    Private Sub dgLibroCompras_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLibroCompras.KeyDown
        Dim cfun As New clsFunciones
        Try
            'LIMPIA EL DATAGRID PARA RECARGAR INFO.
            ' dgLibroCompras.Rows.Clear()
            ' ResetDatagrid()

            ' LibroCompras(celdaAnio.Text, celdaidNumero.Text)
            ' Colorear()


            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLibroCompras)
                e.Handled = True
                e.SuppressKeyPress = True
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub FrmCompras_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub





#End Region

#Region "Boton Agregar"

    '/Proceso de Facturas Compra
    Private Function VerificarLinea(ByVal Anio As Integer, ByVal intLibro As Integer)
        Dim strCmd As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim intLinea As Integer

        Try
            strCmd = " SELECT MAX(d.DDoc_Doc_Lin +1) linea "
            strCmd &= "   From Dcmtos_DTL d "
            strCmd &= "    WHERE d.DDoc_Sis_Emp = {emp} AND d.DDoc_Doc_Cat = 286 AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {num} "

            strCmd = Replace(strCmd, "{emp}", Sesion.IdEmpresa)
            strCmd = Replace(strCmd, "{anio}", Anio)
            strCmd = Replace(strCmd, "{num}", intLibro)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strCmd, CON)
            intLinea = COM.ExecuteScalar()


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intLinea
    End Function
    Private Sub InsertarFacturas(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intLibro As Integer, ByVal intLinea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_UM, DDoc_RF1_Num, DDoc_RF2_Num, DDoc_RF3_Num, DDoc_RF1_Fec, DDoc_RF1_Cod, DDoc_Prd_Des, DDoc_Prd_PNr, DDoc_Prd_Fob, DDoc_RF1_Txt, DDoc_RF2_Txt, DDoc_Prd_PUQ, DDoc_RF1_Dbl, DDoc_RF2_Dbl,DDoc_Prd_Cif, DDoc_RF3_Dbl, DDoc_RF2_Cod) "
        strSQL &= "    Select {emp} emp,286 cat,{anio} anio,{idlibro} num,{linea} linea,0, d.DDoc_Doc_Cat ref_tipo, d.DDoc_Doc_Ano ref_ano, d.DDoc_Doc_Num ref_numero, h.HDoc_Doc_Fec fecha, CAST(CONCAT(d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num) AS CHAR) id, COALESCE(lp.pro_proveedor,h.HDoc_Emp_Nom) proveedor, IF(h.HDoc_DR1_Emp =2,'FPC', IF(h.HDoc_Ant_Com = 1, 'FE', IF(h.HDoc_DR1_Emp =1, 'FEL', 'FA'))) tipo, IFNULL(( "
        strSQL &= "    Select COUNT(*) "
        strSQL &= "    From Dcmtos_DTL e "
        strSQL &= "    Left JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND c.HDoc_Doc_Cat=e.DDoc_RF1_Num AND c.HDoc_Doc_Ano=e.DDoc_RF2_Num AND c.HDoc_Doc_Num=e.DDoc_RF3_Num "
        strSQL &= "    WHERE e.DDoc_Sis_Emp=d.DDoc_Sis_Emp AND e.DDoc_Doc_Cat=286 AND e.DDoc_RF1_Num=d.DDoc_Doc_Cat AND e.DDoc_RF2_Num=d.DDoc_Doc_Ano AND e.DDoc_RF3_Num=d.DDoc_Doc_Num AND c.HDoc_Doc_Status=1),0) existe, CONCAT(CONCAT(h.HDoc_DR2_Num,' ',h.HDoc_DR1_Num), '|FA|', COALESCE(lp.pro_nit,'N/A')) documento, CONCAT(( "
        strSQL &= "    Select IFNULL(GROUP_CONCAT(DISTINCT b.HDoc_DR1_Num SEPARATOR ', '),'-') "
        strSQL &= "    From Dcmtos_DTL a "
        strSQL &= "    Left JOIN Dcmtos_HDR b ON b.HDoc_Sis_Emp = a.DDoc_Sis_Emp AND b.HDoc_Doc_Cat = a.DDoc_Doc_Cat AND b.HDoc_Doc_Ano = a.DDoc_Doc_Ano AND b.HDoc_Doc_Num = a.DDoc_Doc_Num "
        strSQL &= "    WHERE a.DDoc_Sis_Emp = d.DDoc_Sis_Emp AND a.DDoc_Doc_Cat = 51 AND a.DDoc_RF1_Num = d.DDoc_Doc_Cat AND a.DDoc_RF2_Num = d.DDoc_Doc_Ano AND a.DDoc_RF3_Num = d.DDoc_Doc_Num),'|-|', GROUP_CONCAT(DISTINCT IFNULL(d.DDoc_RF1_Cod,'N/A') SEPARATOR ',')) cuenta, -1 uno, IFNULL(ii.MDoc_Lin_Base,0) base, IFNULL(ii.MDoc_Lin_Monto,0) iva, ROUND((SUM(IFNULL(d.DDoc_RF1_Dbl * h.HDoc_Doc_TC,0))),2) total, IFNULL(ic.MDoc_Lin_Monto,0) directo, IF(IFNULL(ic.MDoc_Lin_Monto,0)>0,'C', ELT((d.DDoc_RF1_Num + 1),'B','S')) TTipo "
        strSQL &= "        FROM "
        strSQL &= "        Dcmtos_DTL d "
        strSQL &= "        INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "        Left JOIN Proveedores lp ON lp.pro_sisemp = d.DDoc_Sis_Emp AND lp.pro_codigo = h.HDoc_Emp_Cod "
        strSQL &= "        Left JOIN Dcmtos_IMP ii ON ii.MDoc_Sis_Emp=d.DDoc_Sis_Emp AND ii.MDoc_Doc_Cat=d.DDoc_Doc_Cat AND ii.MDoc_Doc_Ano=d.DDoc_Doc_Ano AND ii.MDoc_Doc_Num=d.DDoc_Doc_Num AND ii.MDoc_Lin_Codigo='IVA' "
        strSQL &= "        Left JOIN Dcmtos_IMP ic ON ic.MDoc_Sis_Emp=d.DDoc_Sis_Emp AND ic.MDoc_Doc_Cat=d.DDoc_Doc_Cat AND ic.MDoc_Doc_Ano=d.DDoc_Doc_Ano AND ic.MDoc_Doc_Num=d.DDoc_Doc_Num AND ic.MDoc_Lin_Codigo='IMP_DC' "
        strSQL &= "            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num}  AND h.HDoc_RF1_Num = 0 AND HDoc_DR1_Emp>=0 AND IFNULL(h.HDoc_DR2_Cat,0)=0  AND (d.DDoc_RF1_Dbl > 0) AND h.HDoc_Doc_Num >=1 "
        strSQL &= "            GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, d.DDoc_RF1_Num "
        strSQL &= "            HAVING existe=0  "
        strSQL &= "            ORDER BY h.HDoc_Doc_Fec, h.HDoc_Emp_Cod, h.HDoc_Doc_Num, d.DDoc_Doc_Lin "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNumero)
        strSQL = Replace(strSQL, "{idlibro}", intLibro)
        strSQL = Replace(strSQL, "{linea}", intLinea)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

    End Sub
    Private Sub CargarFacturas()
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strTabla As String = STR_VACIO

        Dim intLinea As Integer = 0

        strCampos = " SELECT h.HDoc_Doc_Fec fecha, COALESCE(lp.pro_proveedor,h.HDoc_Emp_Nom) proveedor, IF(h.HDoc_DR1_Emp =2,'FPC', IF(h.HDoc_Ant_Com = 1, 'FE', IF(h.HDoc_DR1_Emp =1, 'FEL', 'FA'))) tipo, CONCAT(CONCAT(h.HDoc_DR2_Num,' ',h.HDoc_DR1_Num), '|FA|', COALESCE(lp.pro_nit,'N/A')) documento, ROUND((SUM(IFNULL(d.DDoc_RF1_Dbl * h.HDoc_Doc_TC,0))),2) total, d.DDoc_Doc_Cat ref_tipo, d.DDoc_Doc_Ano ref_ano, d.DDoc_Doc_Num ref_numero, IFNULL(( "
        strCampos &= " SELECT COUNT(*) "
        strCampos &= " From Dcmtos_DTL e "
        strCampos &= " Left JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp=e.DDoc_Sis_Emp And c.HDoc_Doc_Cat=e.DDoc_RF1_Num And c.HDoc_Doc_Ano=e.DDoc_RF2_Num And c.HDoc_Doc_Num=e.DDoc_RF3_Num "
        strCampos &= " WHERE e.DDoc_Sis_Emp = d.DDoc_Sis_Emp And e.DDoc_Doc_Cat = 286 And e.DDoc_RF1_Num = d.DDoc_Doc_Cat And e.DDoc_RF2_Num = d.DDoc_Doc_Ano And e.DDoc_RF3_Num = d.DDoc_Doc_Num And c.HDoc_Doc_Status = 1),0) existe "

        strTabla = " FROM Dcmtos_DTL d "
        strTabla &= " INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strTabla &= " Left JOIN Proveedores lp ON lp.pro_sisemp = d.DDoc_Sis_Emp AND lp.pro_codigo = h.HDoc_Emp_Cod "
        strTabla &= " Left JOIN Dcmtos_IMP ii ON ii.MDoc_Sis_Emp=d.DDoc_Sis_Emp AND ii.MDoc_Doc_Cat=d.DDoc_Doc_Cat AND ii.MDoc_Doc_Ano=d.DDoc_Doc_Ano AND ii.MDoc_Doc_Num=d.DDoc_Doc_Num AND ii.MDoc_Lin_Codigo='IVA' "
        strTabla &= " Left JOIN Dcmtos_IMP ic ON ic.MDoc_Sis_Emp=d.DDoc_Sis_Emp AND ic.MDoc_Doc_Cat=d.DDoc_Doc_Cat AND ic.MDoc_Doc_Ano=d.DDoc_Doc_Ano AND ic.MDoc_Doc_Num=d.DDoc_Doc_Num AND ic.MDoc_Lin_Codigo='IMP_DC' "

        strCondicion = " WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 44 AND h.HDoc_Doc_Fec BETWEEN '{fechaI}' AND '{fechaF}' AND h.HDoc_RF1_Num = 0 AND HDoc_DR1_Emp>=0 AND IFNULL(h.HDoc_DR2_Cat,0)=0 AND (d.DDoc_RF1_Dbl > 0) AND h.HDoc_Doc_Num >=1 "
        strCondicion &= " GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, d.DDoc_RF1_Num "
        strCondicion &= " HAVING existe = 0 "
        strCondicion &= " ORDER BY h.HDoc_Doc_Fec, h.HDoc_Emp_Cod, h.HDoc_Doc_Num, d.DDoc_Doc_Lin "
        strCondicion = Replace(strCondicion, "{emp}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{fechaI}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
        strCondicion = Replace(strCondicion, "{fechaF}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))

        Try
            frm.Titulo = "Invoicing"
            frm.Multiple = True
            frm.Campos = " a1.fecha fecha, a1.proveedor proveedor, a1.tipo tipo, a1.documento documento, a1.total total,a1.ref_tipo ref_tipo, a1.ref_ano ref_ano, a1.ref_numero ref_numero, a1.existe existe "
            frm.Tabla = " (" & strCampos & strTabla & strCondicion & ") a1"
            frm.Condicion = " ref_tipo = 44 "
            frm.FiltroText = " Enter the name of provider "
            frm.Filtro = " proveedor "
            frm.Agrupar = " ref_tipo,ref_ano,ref_numero HAVING existe=0 "
            frm.Ordenamiento = " fecha "
            frm.TipoOrdenamiento = " ASC "
            'frm.Limite = 30

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If MsgBox("You want to add these documents to the shopping book?", vbYesNo + vbQuestion, "Question") = vbNo Then
                    Exit Sub
                End If

                For i As Integer = 0 To frm.ListaClientes.Rows.Count - 1
                    If frm.ListaClientes.Rows(i).Cells(0).Value = True Then
                        intLinea = VerificarLinea(frm.ListaClientes.Rows(i).Cells(7).Value, celdaidNumero.Text)
                        InsertarFacturas(frm.ListaClientes.Rows(i).Cells(7).Value, frm.ListaClientes.Rows(i).Cells(8).Value, celdaidNumero.Text, intLinea)
                    End If
                Next
                MsgBox("Documents Added", vbInformation)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    '/Proceso de Importaciones
    Private Sub InsertarImportaciones(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intLibro As Integer, ByVal intLinea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_UM, DDoc_RF1_Num, DDoc_RF2_Num, DDoc_RF3_Num, DDoc_RF1_Fec, DDoc_RF1_Cod, DDoc_Prd_Des, DDoc_Prd_PNr, DDoc_Prd_Fob, DDoc_RF1_Txt, DDoc_RF2_Txt, DDoc_Prd_PUQ, DDoc_RF1_Dbl, DDoc_RF2_Dbl,DDoc_Prd_Cif, DDoc_RF3_Dbl, DDoc_RF2_Cod) "
        strSQL &= "    Select {emp}, 286,{anio},{idlibro}, {linea} linea, 0, ref_tipo, ref_ano, ref_numero, fecha, documento, proveedor, IF(regimen='ZI','DA','DA') Tipo,existe, CONCAT(documento,'|Poliza|SAT'), CONCAT('|',correlativo,'|'),-1, ROUND(SUM(monto),2) monto, ((ROUND(SUM(monto),2))*0.12), ROUND(SUM(monto),2) + ((ROUND(SUM(monto),2))*0.12), 0, 'I' TTipo "
        strSQL &= "        FROM "
        strSQL &= "         ( "
        strSQL &= "        Select d.DDoc_Doc_Cat ref_tipo, d.DDoc_Doc_Ano ref_ano, d.DDoc_Doc_Num ref_numero, CAST(CONCAT(d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num) AS CHAR) id, d.DDoc_Doc_Lin linea, COALESCE(ac.ADoc_Dta_Chr,'-') correlativo, i.HDoc_Doc_Fec fecha, COALESCE(an.ADoc_Dta_Chr,'-') documento, IFNULL(ar.ADoc_Dta_Chr,'-') regimen, h.HDoc_Emp_Nom proveedor, ROUND(IFNULL(e.EDoc_Lin_Cif * h.HDoc_Doc_TC,0),7) monto, IFNULL(( "
        strSQL &= "        Select COUNT(*) "
        strSQL &= "        From Dcmtos_DTL e "
        strSQL &= "        Left JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND c.HDoc_Doc_Cat=e.DDoc_RF1_Num AND c.HDoc_Doc_Ano=e.DDoc_RF2_Num AND c.HDoc_Doc_Num=e.DDoc_RF3_Num "
        strSQL &= "        WHERE e.DDoc_Sis_Emp=d.DDoc_Sis_Emp AND e.DDoc_Doc_Cat=286 AND e.DDoc_RF1_Num=d.DDoc_Doc_Cat AND e.DDoc_RF2_Num=d.DDoc_Doc_Ano AND e.DDoc_RF3_Num=d.DDoc_Doc_Num AND c.HDoc_Doc_Status=1),0) existe "
        strSQL &= "            From Dcmtos_DTL d "
        strSQL &= "            INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strSQL &= "            Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = 47 AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin "
        strSQL &= "            Left JOIN Dcmtos_HDR i ON i.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND i.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND i.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND i.HDoc_Doc_Num = p.PDoc_Chi_Num "
        strSQL &= "            Left JOIN Dcmtos_DEC e ON e.EDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.EDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.EDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.EDoc_Doc_Num = d.DDoc_Doc_Num AND e.EDoc_Doc_Lin = d.DDoc_Doc_Lin "
        strSQL &= "            Left JOIN Dcmtos_ACC an ON an.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND an.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND an.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND an.ADoc_Doc_Num = h.HDoc_Doc_Num AND an.ADoc_Doc_Sub = 'Doc_PolImp' AND an.ADoc_Doc_Lin = '01' "
        strSQL &= "            Left JOIN Dcmtos_ACC ar ON ar.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ar.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ar.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ar.ADoc_Doc_Num = h.HDoc_Doc_Num AND ar.ADoc_Doc_Sub = 'Doc_PolImp' AND ar.ADoc_Doc_Lin = '22' "
        strSQL &= "            Left JOIN Dcmtos_ACC ac ON ac.ADoc_Sis_Emp = i.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = i.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = i.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = i.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Doc_DIngreso' AND ac.ADoc_Doc_Lin = '01' "
        strSQL &= "            WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 180 AND  h.HDoc_Doc_Ano= {anio} AND  h.HDoc_Doc_Num = {num} "
        strSQL &= "            GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, d.DDoc_Doc_Lin "
        strSQL &= "            HAVING existe= 0 "
        strSQL &= "            ORDER BY i.HDoc_Doc_Fec, CAST(ac.ADoc_Dta_Chr AS SIGNED), d.DDoc_Doc_Num, d.DDoc_Doc_Lin) g1 "
        strSQL &= "            GROUP BY id "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNumero)
        strSQL = Replace(strSQL, "{idlibro}", intLibro)
        strSQL = Replace(strSQL, "{linea}", intLinea)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

    End Sub
    Private Sub CargarImportaciones()
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        Dim strCampos As String = STR_VACIO
        Dim strTabla As String = STR_VACIO

        Dim intLinea As Integer = 0

        strCampos = " fecha, documento, proveedor, If(regimen='ZI','DA','DA') Tipo, CONCAT('|',correlativo,'|') correlativo, ref_tipo, ref_ano, ref_numero,existe "

        strTabla = " (SELECT d.DDoc_Doc_Cat ref_tipo, d.DDoc_Doc_Ano ref_ano, d.DDoc_Doc_Num ref_numero, CAST(CONCAT(d.DDoc_Doc_Cat,d.DDoc_Doc_Ano,d.DDoc_Doc_Num) AS CHAR) id, d.DDoc_Doc_Lin linea, COALESCE(ac.ADoc_Dta_Chr,'-') correlativo, i.HDoc_Doc_Fec fecha, COALESCE(an.ADoc_Dta_Chr,'-') documento, IFNULL(ar.ADoc_Dta_Chr,'-') regimen, h.HDoc_Emp_Nom proveedor, ROUND(IFNULL(e.EDoc_Lin_Cif * h.HDoc_Doc_TC,0),7) monto, IFNULL(( "
        strTabla &= "     Select COUNT(*) "
        strTabla &= "      From Dcmtos_DTL e "
        strTabla &= "      Left JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp=e.DDoc_Sis_Emp AND c.HDoc_Doc_Cat=e.DDoc_RF1_Num AND c.HDoc_Doc_Ano=e.DDoc_RF2_Num AND c.HDoc_Doc_Num=e.DDoc_RF3_Num "
        strTabla &= "      WHERE e.DDoc_Sis_Emp=d.DDoc_Sis_Emp AND e.DDoc_Doc_Cat=286 AND e.DDoc_RF1_Num=d.DDoc_Doc_Cat AND e.DDoc_RF2_Num=d.DDoc_Doc_Ano AND e.DDoc_RF3_Num=d.DDoc_Doc_Num AND c.HDoc_Doc_Status=1),0) existe "
        strTabla &= "      From Dcmtos_DTL d "
        strTabla &= "      INNER JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num = d.DDoc_Doc_Num "
        strTabla &= "      Left JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND p.PDoc_Chi_Cat = 47 AND p.PDoc_Par_Cat = d.DDoc_Doc_Cat AND p.PDoc_Par_Ano = d.DDoc_Doc_Ano AND p.PDoc_Par_Num = d.DDoc_Doc_Num AND p.PDoc_Par_Lin = d.DDoc_Doc_Lin "
        strTabla &= "      Left JOIN Dcmtos_HDR i ON i.HDoc_Sis_Emp = p.PDoc_Sis_Emp AND i.HDoc_Doc_Cat = p.PDoc_Chi_Cat AND i.HDoc_Doc_Ano = p.PDoc_Chi_Ano AND i.HDoc_Doc_Num = p.PDoc_Chi_Num "
        strTabla &= "      Left JOIN Dcmtos_DEC e ON e.EDoc_Sis_Emp = d.DDoc_Sis_Emp AND e.EDoc_Doc_Cat = d.DDoc_Doc_Cat AND e.EDoc_Doc_Ano = d.DDoc_Doc_Ano AND e.EDoc_Doc_Num = d.DDoc_Doc_Num AND e.EDoc_Doc_Lin = d.DDoc_Doc_Lin "
        strTabla &= "      Left JOIN Dcmtos_ACC an ON an.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND an.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND an.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND an.ADoc_Doc_Num = h.HDoc_Doc_Num AND an.ADoc_Doc_Sub = 'Doc_PolImp' AND an.ADoc_Doc_Lin = '01' "
        strTabla &= "      Left JOIN Dcmtos_ACC ar ON ar.ADoc_Sis_Emp = h.HDoc_Sis_Emp AND ar.ADoc_Doc_Cat = h.HDoc_Doc_Cat AND ar.ADoc_Doc_Ano = h.HDoc_Doc_Ano AND ar.ADoc_Doc_Num = h.HDoc_Doc_Num AND ar.ADoc_Doc_Sub = 'Doc_PolImp' AND ar.ADoc_Doc_Lin = '22' "
        strTabla &= "      Left JOIN Dcmtos_ACC ac ON ac.ADoc_Sis_Emp = i.HDoc_Sis_Emp AND ac.ADoc_Doc_Cat = i.HDoc_Doc_Cat AND ac.ADoc_Doc_Ano = i.HDoc_Doc_Ano AND ac.ADoc_Doc_Num = i.HDoc_Doc_Num AND ac.ADoc_Doc_Sub = 'Doc_DIngreso' AND ac.ADoc_Doc_Lin = '01' "
        strTabla &= "      WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 180 AND h.HDoc_Doc_Fec Between '{fechaI}' and '{fechaF}' "
        strTabla &= "      GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num, d.DDoc_Doc_Lin "
        strTabla &= "      HAVING existe= 0 "
        strTabla &= "      ORDER BY i.HDoc_Doc_Fec, CAST(ac.ADoc_Dta_Chr AS SIGNED), d.DDoc_Doc_Num, d.DDoc_Doc_Lin) g1 "

        strTabla = Replace(strTabla, "{emp}", Sesion.IdEmpresa)
        strTabla = Replace(strTabla, "{fechaI}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
        strTabla = Replace(strTabla, "{fechaF}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))

        Try
            frm.Titulo = "Import"
            frm.Multiple = True
            frm.Campos = " a1.fecha fecha, a1.documento documento, a1.proveedor proveedor, a1.Tipo Tipo, a1.correlativo correlativo, a1.ref_tipo ref_tipo, a1.ref_ano ref_ano, a1.ref_numero ref_numero,a1.existe existe "
            frm.Tabla = " (Select " & strCampos & " FROM " & strTabla & " GROUP BY fecha) a1"
            frm.Condicion = " ref_tipo = 180 "
            frm.FiltroText = " Enter the name of provider "
            frm.Filtro = " proveedor "
            'frm.Limite = 30

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If MsgBox("You want to add these documents to the shopping book?", vbYesNo + vbQuestion, "Question") = vbNo Then
                    Exit Sub
                End If

                For i As Integer = 0 To frm.ListaClientes.Rows.Count - 1
                    If frm.ListaClientes.Rows(i).Cells(0).Value = True Then
                        intLinea = VerificarLinea(frm.ListaClientes.Rows(i).Cells(7).Value, celdaidNumero.Text)
                        InsertarImportaciones(frm.ListaClientes.Rows(i).Cells(7).Value, frm.ListaClientes.Rows(i).Cells(8).Value, celdaidNumero.Text, intLinea)
                    End If
                Next
                MsgBox("Documents Added", vbInformation)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    '/Proceso de Notas de Crédito y Débito

    Private Sub InsertarNotas(ByVal intAnio As Integer, ByVal intNumero As Integer, ByVal intLibro As Integer, ByVal intLinea As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand

        strSQL = " INSERT INTO Dcmtos_DTL (DDoc_Sis_Emp, DDoc_Doc_Cat, DDoc_Doc_Ano, DDoc_Doc_Num, DDoc_Doc_Lin, DDoc_Prd_UM, DDoc_RF1_Num, DDoc_RF2_Num, DDoc_RF3_Num, DDoc_RF1_Fec, DDoc_RF1_Cod, DDoc_Prd_Des, DDoc_Prd_PNr, DDoc_Prd_Fob, DDoc_RF1_Txt, DDoc_RF2_Txt, DDoc_Prd_PUQ, DDoc_RF1_Dbl, DDoc_RF2_Dbl,DDoc_Prd_Cif, DDoc_RF3_Dbl, DDoc_RF2_Cod) "
        strSQL &= "    Select {emp}, 286,{anio},{idlibro}, {linea} linea,0, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ano, h.HDoc_Doc_Num ref_numero, e.ECta_FecDcmt Fecha, CAST(CONCAT(e.ECta_Doc_Cat, e.ECta_Doc_Ano, e.ECta_Doc_Num) AS CHAR) Id, lp.pro_proveedor Proveedor, (CASE e.ECta_Doc_Cat WHEN 40 THEN 'ND' ELSE 'NC' END) Tipo,0, CONCAT(h.HDoc_DR1_Num,'|', (CASE e.ECta_Doc_Cat WHEN 40 THEN 'ND' ELSE 'NC' END),'|',lp.pro_nit) Documento, '||', -1, ((SUM(CASE e.ECta_Doc_Cat WHEN 40 THEN e.ECta_Crgo_Loc ELSE (e.ECta_Abno_Loc * (-1)) END))/1.12) rf1, ((((SUM(CASE e.ECta_Doc_Cat WHEN 40 THEN e.ECta_Crgo_Loc ELSE (e.ECta_Abno_Loc * (-1)) END))/1.12))*0.12)rf2, SUM(CASE e.ECta_Doc_Cat WHEN 40 THEN e.ECta_Crgo_Loc ELSE (e.ECta_Abno_Loc * (-1)) END) Monto, ( "
        strSQL &= "    Select COUNT(*) "
        strSQL &= "    From Dcmtos_DTL dl "
        strSQL &= "    WHERE dl.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND dl.DDoc_RF1_Num = h.HDoc_Doc_Cat AND dl.DDoc_RF2_Num =h.HDoc_Doc_Ano AND dl.DDoc_RF3_Num = h.HDoc_Doc_Num) libro, (CASE e.ECta_Doc_Cat WHEN 40 THEN 'ND' ELSE 'NC' END) TTipo "
        strSQL &= "        FROM "
        strSQL &= "        ECtaCte e "
        strSQL &= "        Left JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = e.ECta_Sis_Emp AND h.HDoc_Doc_Cat = e.ECta_Doc_Cat AND h.HDoc_Doc_Ano = e.ECta_Doc_Ano AND h.HDoc_Doc_Num = e.ECta_Doc_Num "
        strSQL &= "        Left JOIN Proveedores lp ON lp.pro_sisemp = e.ECta_Sis_Emp AND lp.pro_codigo = e.ECta_codemp "
        strSQL &= "        WHERE e.ECta_Sis_Emp = {emp} AND (e.ECta_Doc_Cat = 39 OR e.ECta_Doc_Cat = 40) AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strSQL &= "        GROUP BY e.ECta_Sis_Emp, e.ECta_Doc_Cat, e.ECta_Doc_Ano, e.ECta_Doc_Num "
        strSQL &= "        HAVING libro=0 "

        strSQL = Replace(strSQL, "{emp}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNumero)
        strSQL = Replace(strSQL, "{idlibro}", intLibro)
        strSQL = Replace(strSQL, "{linea}", intLinea)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        COM.ExecuteNonQuery()

    End Sub
    Private Sub CargarNotas()
        Dim frm As New frmSeleccionar
        Dim strTabla As String = STR_VACIO
        Dim intLinea As Integer = 0

        strTabla = " (SELECT e.ECta_FecDcmt Fecha, lp.pro_proveedor Proveedor, (CASE e.ECta_Doc_Cat WHEN 40 THEN 'ND' ELSE 'NC' END) Tipo, CONCAT(h.HDoc_DR1_Num,'|', (CASE e.ECta_Doc_Cat WHEN 40 THEN 'ND' ELSE 'NC' END),'|',lp.pro_nit) Documento, h.HDoc_Doc_Cat ref_tipo, h.HDoc_Doc_Ano ref_ano, h.HDoc_Doc_Num ref_numero, ( "
        strTabla &= "  SELECT COUNT(*) "
        strTabla &= "  From Dcmtos_DTL dl "
        strTabla &= "  WHERE dl.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND dl.DDoc_RF1_Num = h.HDoc_Doc_Cat AND dl.DDoc_RF2_Num =h.HDoc_Doc_Ano AND dl.DDoc_RF3_Num = h.HDoc_Doc_Num) existe "
        strTabla &= "  FROM "
        strTabla &= "  ECtaCte e "
        strTabla &= "  Left JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = e.ECta_Sis_Emp AND h.HDoc_Doc_Cat = e.ECta_Doc_Cat AND h.HDoc_Doc_Ano = e.ECta_Doc_Ano AND h.HDoc_Doc_Num = e.ECta_Doc_Num "
        strTabla &= "  Left JOIN Proveedores lp ON lp.pro_sisemp = e.ECta_Sis_Emp AND lp.pro_codigo = e.ECta_codemp "
        strTabla &= "  WHERE e.ECta_Sis_Emp = {emp} AND (e.ECta_Doc_Cat = 39 OR e.ECta_Doc_Cat = 40) AND (e.ECta_FecDcmt BETWEEN '{fechaI}' AND '{fechaF}') "
        strTabla &= "  GROUP BY e.ECta_Sis_Emp, e.ECta_Doc_Cat, e.ECta_Doc_Ano, e.ECta_Doc_Num "
        strTabla &= "  HAVING existe = 0) a1 "

        strTabla = Replace(strTabla, "{emp}", Sesion.IdEmpresa)
        strTabla = Replace(strTabla, "{fechaI}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
        strTabla = Replace(strTabla, "{fechaF}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))

        Try
            frm.Titulo = "Import"
            frm.Multiple = True
            frm.Campos = " a1.Fecha fecha, a1.Proveedor proveedor, a1.Tipo tipo, a1.Documento documento, a1.ref_tipo ref_tipo, a1.ref_ano ref_ano, a1.ref_numero ref_numero, a1.existe existe "
            frm.Tabla = strTabla
            frm.Condicion = " ref_tipo >0 "
            frm.FiltroText = " Enter the name of provider "
            frm.Filtro = " proveedor "
            'frm.Limite = 30

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                If MsgBox("You want to add these documents to the shopping book?", vbYesNo + vbQuestion, "Question") = vbNo Then
                    Exit Sub
                End If

                For i As Integer = 0 To frm.ListaClientes.Rows.Count - 1
                    If frm.ListaClientes.Rows(i).Cells(0).Value = True Then
                        intLinea = VerificarLinea(frm.ListaClientes.Rows(i).Cells(6).Value, celdaidNumero.Text)
                        InsertarNotas(frm.ListaClientes.Rows(i).Cells(6).Value, frm.ListaClientes.Rows(i).Cells(7).Value, celdaidNumero.Text, intLinea)
                    End If
                Next
                MsgBox("Documents Added", vbInformation)
                Reset()
                ResetDatagrid()
                LibroCompras(celdaAnio.Text, celdaidNumero.Text) 'Recarga los datos
                Colorear()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim frmO As New frmOption
        Try

            frmO.Titulo = "Document type"
            frmO.Mensaje = "Select the type of Document"
            frmO.Opciones = "Invoice | Import | Credit and Debit Note"
            frmO.ShowDialog(Me)
            If frmO.DialogResult = System.Windows.Forms.DialogResult.OK Then
                Select Case frmO.Seleccion
                    Case 0
                        CargarFacturas()
                    Case 1
                        CargarImportaciones()
                    Case 2
                        CargarNotas()
                End Select
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region
End Class