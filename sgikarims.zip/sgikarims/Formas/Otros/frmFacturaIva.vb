﻿Imports System.IO
Imports System.Xml
Imports MySql.Data.MySqlClient
Public Class frmFacturaIva

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False

    Private Const CXC_NAME As String = "Factura de Cobro"
    Dim strBaseRel As String = STR_VACIO
    Dim intEmpRel As Integer = NO_FILA
    Dim intTipo As Integer = NO_FILA '0.-- factura de Cobro| 1.--factura de credito Fiscal| 2.-- factura simple
    Dim strTipo As String = STR_VACIO
    Dim strSerie As String = STR_VACIO
    Dim dblImpuestos As Double = INT_CERO
    Dim intOrden As Integer = NO_FILA
    Dim IntCalcularImpuesto As Integer = NO_FILA

    Dim vDatosCuentaAjena As Boolean = False
    Dim vConceptoCuentaAjena As String = STR_VACIO
    Dim vValorCuentaAjena As Double = INT_CERO

    Dim cfun As New clsFunciones
#End Region

#Region "Propiedades"

    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property


#End Region

#Region "Procedimientos"
    Private Function BuscarRegistrosDcmtos_HDR_FISCAL(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("tablas1")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRcf.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosFacturaCMC(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("CMC")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRCMC.xml", XmlWriteMode.WriteSchema)
        End If
    End Function
    Private Function BuscarRegistrosSimpleCMC(ByVal strConsulta As String)
        Dim Tablas As New DataSet
        Dim adaptador As New MySqlDataAdapter

        MyCnn.CONECTAR = strConexion
        adaptador = New MySqlDataAdapter(strConsulta, CON)
        Tablas = New DataSet("FACSIMPLECMC")
        adaptador.Fill(Tablas, "Dcmtos_HDR")
        If Tablas.Tables("Dcmtos_HDR").Rows.Count = 0 Then
            MsgBox("")
        Else
            My.Computer.FileSystem.CreateDirectory("C:\XML")
            Tablas.WriteXml("C:\XML\DcmtosHDRSIMPLECMC.xml", XmlWriteMode.WriteSchema)
        End If
    End Function


    Public Function NuevoCorrelativo(ByVal idCatalogo As Integer, ByVal Serie As String) As Long
        Dim intId As Long = NO_FILA
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand

        strSQL = "SELECT (IFNULL(MAX(HDoc_DR2_Cat),0)+1) ID FROM Dcmtos_HDR WHERE HDoc_Sis_Emp= {empresa}" &
            " AND HDoc_Doc_Cat = {cat}  and HDoc_DR2_Num = '" & Serie & "'"
        strSQL = Replace(strSQL, "{cat}", idCatalogo)
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)



        Try
            MyCnn.CONECTAR = strConexion
            If MyCnn.ProbarConexiones = True Then
                COM = New MySqlCommand(strSQL, CON)
                intId = CInt(COM.ExecuteScalar)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intId
    End Function

    Private Sub CargarVariables()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim intContador As Integer = INT_CERO

        If Sesion.IdEmpresa = 10 Then
            strSQL = " select  c.cat_desc descripcion , c.cat_sist empresa, c.cat_dato base "
            strSQL &= "  from Catalogos c "
            strSQL &= " where c.cat_clase = 'Factura' and c.cat_clave ='Empresa' and c.cat_sisemp = {empresa} limit 1 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            Try
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
                If REA.HasRows Then
                    Do While REA.Read
                        strBaseRel = REA.GetString("base")
                        intEmpRel = CInt(REA.GetString("empresa"))
                    Loop
                Else
                    MsgBox("No hay ninguna empresa asignada ", MsgBoxStyle.Critical)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If


        '---------------------- cargar factor de IVA ---------------------
        strSQL = STR_VACIO
        strSQL = " select c.cat_sist  from Catalogos c "
        strSQL &= " where c.cat_clase = 'Impuestos' and c.cat_clave = 'IVA' and c.cat_sisemp =  " & Sesion.IdEmpresa
        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            dblImpuestos = CDbl(COM.ExecuteScalar)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            ' botonImprimir.Enabled = False
            If (Sesion.IdEmpresa = 10) Then
                botonPrevio.Visible = True
                etiquetaSerie.Visible = True
                etiquetaAutorizacion.Visible = True
            Else
                botonPrevio.Visible = False
            End If
            botonPrevio.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonInprimir.Enabled = True
            If (Sesion.IdEmpresa = 10) Then
                botonPrevio.Visible = True
                botonPrevio.Enabled = True
                etiquetaSerie.Visible = True
                etiquetaAutorizacion.Visible = True
            Else
                botonPrevio.Visible = False
            End If
        End If

    End Sub
    Private Sub CalcularTotalComplemento()
        Dim dblTotalComplemento As Double = INT_CERO
        Try
            For i As Integer = 0 To dgComplemento.Rows.Count - 1
                If dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 2 Then
                Else
                    Select Case intTipo
                        Case INT_CERO
                            dblTotalComplemento += CDbl(dgComplemento.Rows(i).Cells("colComplementoValor").Value)
                        Case 2
                            dblTotalComplemento += CDbl(dgComplemento.Rows(i).Cells("colComplementoValor").Value)
                    End Select

                    If (dgComplemento.Rows(i).Cells("colExtraComplemento").Value) = vbNullString Then
                        dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 0
                    End If
                End If
            Next
            celdaTotalComplemento.Text = dblTotalComplemento.ToString(FORMATO_MONEDA)
            celdaTotalDocumento.Text = (CDbl(celdaTotalDetalle.Text) + CDbl(celdaTotalComplemento.Text)).ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CalcularTotal()
        Dim dblGranTotal As Double = INT_CERO
        Dim dblTotalImpuesto As Double = INT_CERO
        Dim dblTotalExepcion As Double = INT_CERO
        Dim dblTotalSubTotal As Double = INT_CERO

        Dim dblSubTotal As Double = INT_CERO
        Dim dblDescuento As Double = INT_CERO
        Dim dblTotal As Double = INT_CERO
        Dim dblTotalComplemento As Double = INT_CERO
        Dim dblPrecio As Double = INT_CERO
        Dim dblCantidad As Double = INT_CERO
        Dim dblImpuesto As Double = INT_CERO
        Dim dblExepcion As Double = INT_CERO

        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                Else
                    Select Case intTipo
                        Case INT_CERO
                            dblTotal = CDbl(dgDetalle.Rows(i).Cells("ColFlete").Value) + CDbl(dgDetalle.Rows(i).Cells("colAgente").Value) + CDbl(dgDetalle.Rows(i).Cells("ColGestiones").Value)
                        Case INT_UNO
                            dblCantidad = CDbl(dgDetalle.Rows(i).Cells("colCantidad").Value)
                            dblPrecio = CDbl(dgDetalle.Rows(i).Cells("colPrecio").Value)
                            dblDescuento = CDbl(dgDetalle.Rows(i).Cells("ColDesD").Value)

                            dblSubTotal = dblCantidad * dblPrecio - dblDescuento
                            dblImpuesto = dblSubTotal * dblImpuestos / 100
                            If IntCalcularImpuesto = 1 Then
                                dblExepcion = dblSubTotal / 100
                            ElseIf IntCalcularImpuesto = 0 Then
                                dblExepcion = 0
                            End If

                            dblTotal = dblSubTotal + dblImpuesto - dblExepcion

                        Case 2
                            dblTotal = CDbl(dgDetalle.Rows(i).Cells("ColFlete").Value)
                    End Select

                    dgDetalle.Rows(i).Cells("colTotal_").Value = dblTotal.ToString(FORMATO_MONEDA)
                    dgDetalle.Rows(i).Cells("colSubTotal").Value = dblSubTotal.ToString(FORMATO_MONEDA)
                    dgDetalle.Rows(i).Cells("colImpuesto").Value = dblImpuesto.ToString(FORMATO_MONEDA)
                    dgDetalle.Rows(i).Cells("colExepcion").Value = dblExepcion.ToString(FORMATO_MONEDA)
                    If (vValorCuentaAjena > 0) Then
                        vDatosCuentaAjena = True
                    Else
                        vDatosCuentaAjena = False
                    End If


                    If (dgDetalle.Rows(i).Cells("colExtra").Value) = vbNullString Then
                        dgDetalle.Rows(i).Cells("colExtra").Value = 0
                    End If

                    dblTotalSubTotal = dblTotalSubTotal + dblSubTotal
                    dblGranTotal = dblGranTotal + dblTotal
                    dblTotalImpuesto = dblTotalImpuesto + dblImpuesto
                    dblTotalExepcion = dblTotalExepcion + dblExepcion
                End If

            Next
            celdaTotalComplemento.Text = dblTotalComplemento
            celdaTotal.Text = dblGranTotal.ToString(FORMATO_MONEDA)
            celdaIva.Text = dblTotalImpuesto.ToString(FORMATO_MONEDA)
            celdaSubTotal.Text = dblTotalSubTotal.ToString(FORMATO_MONEDA)
            If IntCalcularImpuesto = 1 Then
                celdaExepcion.Text = dblTotalExepcion.ToString(FORMATO_MONEDA)
            ElseIf IntCalcularImpuesto = 0 Then
                celdaExepcion.Text = INT_CERO.ToString(FORMATO_MONEDA)
            End If

            celdaTotalDetalle.Text = CDbl(celdaTotal.Text).ToString(FORMATO_MONEDA)
            celdaTotalDocumento.Text = (CDbl(celdaTotalDetalle.Text) + CDbl(celdaTotalComplemento.Text)).ToString(FORMATO_MONEDA)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function ComprobarDatos() As Boolean
        Dim logCoprobar As Boolean = True

        If panelExtras.Visible = True Then
            If cfun.ValidarCampoTexto(celdaRegistro) = False Then
                MsgBox("Please fill in the registration field", vbInformation, "Notice")
                Return False
                Exit Function
            End If
            If cfun.ValidarCampoTexto(celdaGiro) = False Then
                MsgBox("PPlease fill in the line of business", vbInformation, "Notice")
                Return False
                Exit Function
            End If
        End If

        If cfun.ValidarCampoNumerico(celdaIdCliente) = False Then
            Return False
            Exit Function
        End If
        If cfun.ValidarCampoTexto(celdaCliente) = False Then
            Return False
            Exit Function
        End If
        If cfun.ValidarCampoTexto(celdaDireccion) = False Then
            Return False
            Exit Function
        End If
        If cfun.ValidarCampoNumerico(celdaTasa) = False Then
            Return False
            Exit Function
        End If
        If cfun.ValidarCampoNumerico(celdaIdMoneda) = False Then
            Return False
            Exit Function
        End If
        If cfun.ValidarCampoTexto(celdaMoneda) = False Then
            Return False
            Exit Function
        End If
        If dgDetalle.Rows.Count = 0 Then
            Return False
            Exit Function
        End If
        Select Case intTipo
            Case INT_CERO, INT_UNO
                If dgFactrura.Rows.Count = INT_CERO Then
                    Return False
                    Exit Function
                End If
        End Select
        If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 12 Then
            If celdaNIT.Text.Length < 4 And (celdaTotal.Text * celdaTasa.Text) >= 2500 Then
                MsgBox("The 'NIT' can't be C/F ", vbExclamation, "Notice")
                Return False
                Exit Function
            End If
        End If


        Return logCoprobar
    End Function

    Private Function ComprobarFilaComplemento() As Boolean
        If intTipo = 0 And dgComplemento.Rows.Count > 0 Then
            For i = 0 To dgComplemento.Rows.Count - 1
                If dgComplemento.Rows(i).Cells("colExtraComplemento").Value <> 2 Then 'valida que no se esté eliminando la fila
                    If dgComplemento.Rows(i).Cells("colRelatedDocument").Value = vbNullString Then
                        MsgBox("Row " & i + 1 & ": Complement description is Blank ")
                        ComprobarFilaComplemento = False
                        Exit Function
                    End If
                    If dgComplemento.Rows(i).Cells("colDate").Value = vbNullString Then
                        MsgBox("Row " & i + 1 & ": Complement date at Blank")
                        ComprobarFilaComplemento = False
                        Exit Function
                    End If
                    If dgComplemento.Rows(i).Cells("colComplemento").Value = vbNullString Then
                        MsgBox("Row " & i + 1 & ": Complement another accounts at Blank")
                        ComprobarFilaComplemento = False
                        Exit Function
                    End If

                    If dgComplemento.Rows(i).Cells("colComplementoValor").Value = vbEmpty Then
                        MsgBox("Row " & i + 1 & ": Complement another accounts value at Blank")
                        ComprobarFilaComplemento = False
                        Exit Function
                    End If
                End If

            Next
        End If
        ComprobarFilaComplemento = True
    End Function
    Private Function ComprobarFila() As Boolean
        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Cells("colExtra").Value <> 2 Then 'valida que no se esté eliminando la fila
                Select Case intTipo
                    Case INT_CERO, 2
                        If dgDetalle.Rows(i).Cells("ColDestino").Value = vbNullString Then
                            MsgBox("Row " & i + 1 & ": Description is Blank")
                            ComprobarFila = False
                            Exit Function
                        End If

                        If dgDetalle.Rows(i).Cells("ColFlete").Value = vbNullString Then
                            MsgBox("Row " & i + 1 & ": Item price at Blank")
                            ComprobarFila = False
                            Exit Function
                        End If


                        If dgDetalle.Rows(i).Cells("colAgente").Value = vbNullString Then
                            MsgBox("Row " & i + 1 & ": Item price at Blank")
                            ComprobarFila = False
                            Exit Function
                        End If

                        If dgDetalle.Rows(i).Cells("ColGestiones").Value = vbNullString Then
                            MsgBox("Row " & i + 1 & ": Item Price at Blank")
                            ComprobarFila = False
                            Exit Function
                        End If
                End Select
            End If
        Next
        If Sesion.IdEmpresa = 10 Then
            ComprobarFilaComplemento()
        End If
        ComprobarFila = True
    End Function

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String
        Dim strNumFactura As String = STR_VACIO
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String

        strSQL = "{campos}"

        strSQL &= " select h.HDoc_Doc_Cat cat , h.HDoc_Doc_Ano ano , h.HDoc_Doc_Num  num , h.HDoc_Doc_Fec fecha, h.HDoc_Sis_Emp Empresa ,  h.HDoc_Emp_Nom  cliente , 
                    IF((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY)= 0 ),SUM(d.DDoc_RF1_Dbl),h.HDoc_RF1_Dbl) total, 
                    IF((SUM(d.DDoc_Prd_NET * d.DDoc_Prd_QTY)= 0 ),(d.DDoc_RF1_Dbl),h.HDoc_RF1_Dbl) totalFact, 
                    SUM(ifnull(d.DDoc_RF4_Dbl,0)) bb,
                    IFNULL(h.HDoc_DR2_Cat,-1) CCF, if(ifnull(h.HDoc_DR2_Fec ,0)=0,0,1) entregado, h.HDoc_Doc_Status estado,IFNULL(f.Serie,'') Serie, IFNULL(f.NumeroAutorizacion,'') Autorizacion, "
        strSQL &= "     IFNULL((    SELECT GROUP_CONCAT(p36.PDoc_Par_Num) Factura "
        strSQL &= "         FROM Dcmtos_DTL_Pro p "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p36 ON p36.PDoc_Sis_Emp = p.PDoc_Sis_Emp AND p36.PDoc_Chi_Cat = p.PDoc_Par_Cat AND p36.PDoc_Chi_Ano = p.PDoc_Par_Ano AND p36.PDoc_Chi_Num = p.PDoc_Par_Num AND p36.PDoc_Par_Lin = p.PDoc_Chi_Lin AND p36.PDoc_Par_Cat = 36  "
        strSQL &= "                 WHERE p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p.PDoc_Chi_Num = h.HDoc_Doc_Num   ),'-') factura  "
        strSQL &= "                     from Dcmtos_HDR h "
        strSQL &= "                         LEFT JOIN Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Catalogo = h.HDoc_Doc_Cat AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_Doc_Num "
        strSQL &= "                             left join Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num = h.HDoc_Doc_Num   "
        strSQL &= "                                 where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 "
        If checkFecha.Checked = True Then
            strSQL &= "    AND  h.HDoc_Doc_Fec between '{inicio}' and '{fin}' "
        End If
        strSQL &= "                                 group by h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num  "
        strSQL &= "                                     order by  h.HDoc_Doc_Fec desc, h.HDoc_Doc_Num desc  "
        strSQL &= "{join}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        If Sesion.IdEmpresa = 10 Then

            strSQL = Replace(strSQL, "{campos}", "SELECT A.cat, A.ano, A.num, A.fecha, A.cliente, (A.totalFact + SUM(IFNULL(d.DDoc_RF4_Dbl,A.bb))) total, A.CCF, A.entregado, A.estado, A.Serie,                                                 A.Autorizacion, A.factura 
                                                    FROM (")
            strSQL = Replace(strSQL, "{join}", ") AS A

                                                LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp =A.Empresa AND hh.HDoc_Pro_DCat = A.cat AND hh.HDoc_Pro_DAno = A.ano -- 303
                                                AND hh.HDoc_Pro_DNum = A.num AND hh.HDoc_Doc_Cat=303 AND hh.HDoc_Doc_Status = 1
                                                LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano AND d.DDoc_Doc_Num = hh.HDoc_Doc_Num AND d.DDoc_Prd_Ref='comp'

                                                GROUP BY A.Num, A.ano
                                                ORDER BY A.Fecha DESC, A.Num DESC")
        Else
            strSQL = Replace(strSQL, "{campos}", STR_VACIO)
            strSQL = Replace(strSQL, "{join}", STR_VACIO)
        End If
        strSQL = Replace(strSQL, "{inicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
        strSQL = Replace(strSQL, "{fin}", dtpFin.Value.ToString(FORMATO_MYSQL))

        If Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16 Then
            dgLista.Columns(5).Visible = True
        ElseIf Sesion.IdEmpresa = 10 Then
            dgLista.Columns(5).Visible = True
            dgLista.Columns(7).Visible = True
            dgLista.Columns(8).Visible = True
        Else
            dgLista.Columns(5).Visible = False
        End If

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        dgLista.Rows.Clear()
        If REA.HasRows Then
            Do While REA.Read
                If Sesion.IdEmpresa = 10 Then
                    strNumFactura = REA.GetString("Factura")
                Else
                    strNumFactura = REA.GetString("CCF")
                End If
                strCadena = REA.GetString("Serie")
                arrayCadena = strCadena.Split("-".ToCharArray)

                strLinea = STR_VACIO
                strLinea = REA.GetInt32("cat").ToString & "|" & REA.GetInt32("ano").ToString & "|" & REA.GetInt32("num").ToString & "|" & REA.GetMySqlDateTime("fecha").ToString & "|" & REA.GetString("cliente").ToString & "|" & strNumFactura & "|" & REA.GetDouble("total").ToString(FORMATO_MONEDA) & "|" & arrayCadena(INT_CERO) & "|" & REA.GetString("Autorizacion")
                If REA.GetInt32("estado") = 0 Then
                    cfun.AgregarFila(dgLista, strLinea, Color.Red)
                Else
                    If REA.GetInt32("entregado") = 0 Then
                        cfun.AgregarFila(dgLista, strLinea, Color.LightYellow)
                    Else
                        cfun.AgregarFila(dgLista, strLinea)
                    End If
                End If

            Loop
            REA.Close()
            REA = Nothing
        End If
    End Sub
    Private Function Serie() As String
        Dim strSQL As String = STR_VACIO
        Dim strSeriee As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " select c.cat_sist from Catalogos c "
            strSQL &= "  where c.cat_clase = 'Serie' and c.cat_clave = 'frmDFacturaCobro' and c.cat_sisemp = " & Sesion.IdEmpresa & " and c.cat_pid =  " & intTipo

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            strSeriee = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return strSeriee
    End Function
    Private Sub reset()
        celdaOrden.Text = INT_CERO
        celdaCorrelativo.Text = NO_FILA
        intOrden = NO_FILA
        celdaSerie.Text = strSerie
        celdaTasa.Text = Divisa.Local.factor
        celdaAño.Text = cfun.AñoMySQL.ToString
        celdaNumero.Text = NO_FILA
        celdaIdCliente.Text = NO_FILA
        celdaCliente.Text = STR_VACIO
        celdaIdMoneda.Text = Divisa.Local.id
        celdaMoneda.Text = Divisa.Local.simbolo
        celdaDireccion.Text = STR_VACIO
        celdaTelefono.Text = STR_VACIO
        celdaNIT.Text = STR_VACIO
        celdaObservaciones.Text = STR_VACIO
        celdaTotal.Text = "0.00"
        dgFactrura.Rows.Clear()
        dgDetalle.Rows.Clear()
        dgComplemento.Rows.Clear()
        dgDatos.Rows.Clear()
        checkActivar.Checked = True
        checkActivar.Enabled = True
        botonRefacturar.BackColor = Color.LightGray
        celdaNotas.Text = "Info..." & vbCrLf
        celdaObservaciones.Text = vbNullString
        If (Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16) And intTipo = 1 Then
            panelExtras.Visible = True
        Else
            panelExtras.Visible = False
        End If
        If Sesion.IdEmpresa = 10 Then
            PanelComplemento.Visible = True
            panelComplementoTotales.Visible = True
        Else
            PanelComplemento.Visible = False
            panelComplementoTotales.Visible = False
        End If
        celdaGiro.Clear()
        celdaRegistro.Clear()
        celdaIva.Clear()
        celdaSubTotal.Clear()
        celdaExepcion.Clear()
        dtpFecha.Value = cfun.HoyMySQL
        celdaTotalComplemento.Clear()
        celdaTotalDetalle.Clear()
        celdaTotalDocumento.Clear()

        celdaUUID.Text = STR_VACIO
        celdaFechaEmisionDocumento.Text = STR_VACIO
        celdaFechaHoraCertificacion.Text = STR_VACIO
        celdaSerieFel.Text = STR_VACIO
        etiquetaSerie.Text = STR_VACIO
        etiquetaAutorizacion.Text = STR_VACIO

    End Sub
    Private Sub seleccionar(ByVal ano As Integer, ByVal num As Integer)
        Me.Tag = "mod"
        CargarEncabezad(ano, num)
        CargarDetalle(ano, num)
        CargarRelacion(ano, num)
        CargarDatosFel()
    End Sub
    Private Sub CargarEncabezad(ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try


            strSQL = " SELECT IFNULL(h.HDoc_DR2_Cat,h.HDoc_Doc_Num) correlativo, IFNULL(h.HDoc_DR2_Num, 'A') Serie, h.HDoc_Doc_Cat cat, h.HDoc_Doc_Ano ano, h.HDoc_Doc_Num num, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod codigo, h.HDoc_Emp_Nom cliente, h.HDoc_Emp_Dir direccion, h.HDoc_Emp_Tel telefono, h.HDoc_Emp_NIT nit, h.HDoc_Doc_Mon idmoneda, h.HDoc_Doc_TC tasa, h.HDoc_Doc_Status estado, c.cat_clave moneda, IFNULL(h.HDoc_DR1_Cat,0) tipo ,ifnull(hh.HDOc_Doc_Num,0) orden, IFNULL(h.HDoc_RF2_Txt,'') Info , IFNULL(h.HDoc_RF1_Txt,'') Observaciones, IFNULL(h.HDoc_RF1_Cod,'') registroo, h.HDoc_Ant_Com Impuesto, IFNULL(h.HDoc_RF1_Cod,'') relatedDoc "
            strSQL &= "   from Dcmtos_HDR h "
            strSQL &= "   left join Dcmtos_HDR hh on hh.HDOc_Sis_Emp = h.HDOc_Sis_Emp and  h.HDoc_Doc_Cat = hh.HDoc_Pro_DCat and h.HDoc_Doc_Ano = hh.HDoc_Pro_DAno and h.HDoc_Doc_Num = hh.HDoc_Pro_DNum "
            strSQL &= "   left join Catalogos c on c.cat_num = h.HDoc_Doc_Mon and c.cat_clase ='Monedas'"
            strSQL &= " where h.HDoc_Sis_Emp =  {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num = {numero} "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{ano}", ano)
            strSQL = Replace(strSQL, "{numero}", num)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read

                    celdaAño.Text = REA.GetInt32("ano").ToString
                    celdaNumero.Text = REA.GetString("num")
                    dtpFecha.Value = REA.GetMySqlDateTime("fecha")
                    celdaIdCliente.Text = REA.GetInt32("codigo").ToString
                    celdaCliente.Text = REA.GetString("cliente")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaTelefono.Text = REA.GetString("telefono")
                    celdaNIT.Text = REA.GetString("nit")
                    celdaIdMoneda.Text = REA.GetUInt32("idmoneda").ToString
                    celdaTasa.Text = REA.GetDouble("tasa").ToString
                    celdaMoneda.Text = REA.GetString("moneda")
                    celdaSerie.Text = REA.GetString("serie")
                    intTipo = REA.GetInt32("tipo").ToString
                    If (Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16) And intTipo = 1 Then
                        celdaGiro.Text = REA.GetString("Info")
                        celdaRegistro.Text = REA.GetString("registroo")
                        IntCalcularImpuesto = REA.GetInt32("Impuesto")
                    Else
                        celdaNotas.Text = REA.GetString("Info")
                    End If
                    celdaCorrelativo.Text = REA.GetString("correlativo").ToString
                    celdaOrden.Text = REA.GetInt32("orden")
                    celdaObservaciones.Text = REA.GetString("Observaciones")
                    If REA.GetInt32("estado") = INT_UNO Then
                        etiquetaAnulada.Visible = False
                        checkActivar.Checked = True
                        checkActivar.Enabled = True
                    Else
                        etiquetaAnulada.Visible = True
                        checkActivar.Checked = False
                        checkActivar.Enabled = False
                    End If
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub CargarDetalle(ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        ConfigurarForma(intTipo)
        dgDetalle.Rows.Clear()

        Try
            Select Case intTipo
                Case INT_CERO
                    strSQL = "  select ifnull(d.DDoc_Doc_Lin,1) linea , ifnull(d.DDoc_Prd_Des,'N/A') destino, ifnull(d.DDoc_RF1_Dbl,0) flete ,ifnull(d.DDoc_RF2_Dbl,0) agente, ifnull(d.DDoc_RF3_Dbl,0) gestiones

                                , IFNULL(d.DDoc_RF4_Dbl,0) cuentaAjenaValor, IFNULL(d.DDoc_RF4_Txt,'') cuentaAjena, ifnull(DDoc_RF4_Cod,'') relatedDocument, ifnull(DDoc_RF4_Fec,CURDATE()) documentDate, ifnull(DDoc_PRD_Ref,'') complemento "

                    strSQL &= " from Dcmtos_HDR h "
                    strSQL &= "   left join Dcmtos_HDR hh on hh.HDoc_Sis_Emp =h.HDoc_Sis_Emp and hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat and hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano  and hh.HDoc_Pro_DNum = h.HDoc_Doc_Num "
                    strSQL &= "   left join Dcmtos_DTL d on d.DDoc_Sis_Emp = hh.HDoc_Sis_Emp  and d.DDoc_Doc_Cat = hh.HDoc_Doc_Cat and d.DDoc_Doc_Ano = hh.HDoc_Doc_Ano and d.DDoc_Doc_Num = hh.HDoc_Doc_Num "
                    strSQL &= " where h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {ano} and h.HDoc_Doc_Num ={numero} "

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ano}", ano)
                    strSQL = Replace(strSQL, "{numero}", num)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Do While REA.Read
                            If REA.GetString("complemento").ToString <> "comp" Then
                                strLinea = REA.GetInt32("linea") & "|" 'linea
                                strLinea &= "  " & "|" ' codigo
                                strLinea &= "  " & "|" ' descripcion
                                strLinea &= "  " & "|" ' id unidad de medida
                                strLinea &= "  " & "|" ' unidad de medida
                                strLinea &= "  " & "|" 'Bulto 
                                strLinea &= "  " & "|" ''Tipo Bulto 
                                strLinea &= "  " & "|" ' precio
                                strLinea &= "  " & "|" ' descuento %
                                strLinea &= "  " & "|" ' descuento cantidad
                                strLinea &= "  " & "|" ' cantidad
                                strLinea &= "  " & "|" 'referencia
                                strLinea &= "  " & "|" '  catalogo pro
                                strLinea &= "  " & "|" ' año pro
                                strLinea &= "  " & "|" ' numero pro
                                strLinea &= "  " & "|" ' linea pro
                                strLinea &= REA.GetString("destino").ToUpper & "|" 'destino
                                strLinea &= REA.GetDouble("flete").ToString(FORMATO_MONEDA) & "|" 'flete
                                strLinea &= REA.GetDouble("agente").ToString(FORMATO_MONEDA) & "|" ' agente de aduanas
                                strLinea &= REA.GetDouble("gestiones").ToString(FORMATO_MONEDA) & "|" ' gestiones aduanales
                                strLinea &= "  " & "|" ' descripcion de factura simple
                                strLinea &= "  " & "|" ' iva
                                strLinea &= "  " & "|" ' ventas exentas
                                strLinea &= "  " & "|" ' subtotal
                                strLinea &= "|" ' cobro cuenta Ajena
                                strLinea &= "|" ' cobro cuenta Ajena valor
                                strLinea &= (REA.GetDouble("flete") + REA.GetDouble("agente") + REA.GetDouble("gestiones")).ToString(FORMATO_MONEDA) & "|" ' total
                                strLinea &= INT_UNO
                                cfun.AgregarFila(dgDetalle, strLinea)
                            Else
                                strLinea = REA.GetInt32("linea") & "|" 'linea complemento
                                strLinea &= REA.GetString("relatedDocument") & "|" ' Documento Relacionado complemento
                                strLinea &= REA.GetDateTime("documentDate").ToString(FORMATO_MYSQL) & "|" ' fecha complemento
                                strLinea &= REA.GetString("cuentaAjena") & "|" ' descripcion complemento
                                strLinea &= REA.GetString("cuentaAjenaValor") & "|" ' valor complemento
                                strLinea &= INT_UNO 'editar complemento
                                cfun.AgregarFila(dgComplemento, strLinea)
                            End If

                        Loop
                    End If
                Case INT_UNO
                    strSQL = "  SELECT d.DDoc_Doc_Lin  linea , d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des des, d.DDoc_Prd_UM idmedida, c.cat_clave medida, d.DDoc_Prd_NET precio, d.DDoc_Prd_QTY cantidad,  d.DDoc_Prd_DSP descuentop , d.DDoc_Prd_DSQ descuentoq, d.DDoc_RF1_Txt referencia, d.DDoc_RF2_Txt Bulto,IFNULL(b.BDoc_Box_QTY,0) Cantidad, p.PDoc_Par_Cat ID, p.PDoc_Par_Ano anorel , p.PDoc_Par_Num numrel, p.PDoc_Par_Lin linrel, ifnull(i.MDoc_Lin_Base,0) exento, ifnull(i.MDoc_Lin_Monto,0) iva   "
                    strSQL &= " FROM Dcmtos_DTL d  "
                    strSQL &= "   left join Catalogos c on c.cat_num = d.DDoc_Prd_UM  "
                    strSQL &= "   left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp = d.DDoc_Sis_Emp and p.PDoc_Chi_Cat = d.DDoc_Doc_Cat and p.PDoc_Chi_Ano = d.DDoc_Doc_Ano and p.PDoc_Chi_Num = d.DDoc_Doc_Num and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin  "
                    strSQL &= "   left join Dcmtos_IMP i on i.MDoc_Sis_Emp = d.DDoc_Sis_Emp and i.MDoc_Doc_Cat = d.DDoc_Doc_Cat and i.MDoc_Doc_Ano = d.DDoc_Doc_Ano and i.MDoc_Doc_Num = d.DDoc_Doc_Num and i.MDoc_Doc_Lin = d.DDoc_Doc_Lin   "
                    strSQL &= "     LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin  "
                    strSQL &= " where d.DDoc_Sis_Emp = {empresa} and d.DDoc_Doc_Cat = 296 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num ={numero} "

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ano}", ano)
                    strSQL = Replace(strSQL, "{numero}", num)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Do While REA.Read
                            strLinea = REA.GetInt32("linea") & "|" 'linea
                            strLinea &= REA.GetInt32("codigo") & "|" ' codigo
                            strLinea &= REA.GetString("des") & "|" ' descripcion
                            strLinea &= REA.GetInt32("idmedida") & "|" ' id unidad de medida
                            strLinea &= REA.GetString("medida") & "|" ' unidad de medida
                            strLinea &= REA.GetInt32("Cantidad") & "|" 'Bulto 
                            strLinea &= REA.GetString("Bulto") & "|" 'Tipo Bulto 
                            strLinea &= REA.GetDouble("precio").ToString & "|" ' precio
                            strLinea &= REA.GetDouble("descuentop").ToString(FORMATO_MONEDA) & "|" ' descuento %
                            strLinea &= REA.GetDouble("descuentoq").ToString(FORMATO_MONEDA) & "|" ' descuento cantidad
                            strLinea &= REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & "|" ' cantidad
                            strLinea &= REA.GetString("referencia") & "|" 'referencia
                            strLinea &= REA.GetInt32("ID") & "|" '  catalogo pro
                            strLinea &= REA.GetInt32("anorel") & "|" ' año pro
                            strLinea &= REA.GetInt32("numrel") & "|" ' numero pro
                            strLinea &= REA.GetInt32("linrel") & "|" ' linea pro
                            strLinea &= "  " & "|" 'destino
                            strLinea &= "  " & "|" 'flete
                            strLinea &= "  " & "|" ' agente de aduanas
                            strLinea &= "  " & "|" ' gestiones aduanales
                            strLinea &= "  " & "|" ' descripcion de factura simple

                            strLinea &= REA.GetDouble("iva").ToString(FORMATO_MONEDA) & "|" ' iva
                            strLinea &= REA.GetDouble("exento").ToString(FORMATO_MONEDA) & "|" ' ventas excentas
                            strLinea &= (REA.GetDouble("cantidad") * REA.GetDouble("precio") - REA.GetDouble("descuentoq")).ToString(FORMATO_MONEDA) & "|" ' subtotal
                            strLinea &= "|" ' cobro cuenta Ajena
                            strLinea &= "0|" ' cobro cuenta Ajena valor
                            strLinea &= ((REA.GetDouble("cantidad") * REA.GetDouble("precio") - REA.GetDouble("descuentoq")) + REA.GetDouble("iva") - REA.GetDouble("exento")).ToString(FORMATO_MONEDA) & "|" ' total
                            strLinea &= INT_UNO

                            cfun.AgregarFila(dgDetalle, strLinea)

                        Loop
                    End If
                Case 2
                    strSQL = " SELECT IFNULL(d.DDoc_Doc_Lin,1) linea, IFNULL(d.DDoc_Prd_Des, 'N/A') descripcion, IFNULL(d.DDoc_RF1_Dbl,0) subTotal
                            , IFNULL(d.DDoc_RF4_Dbl,0) cuentaAjenaValor, IFNULL(d.DDoc_RF4_Txt,'') cuentaAjena, ifnull(DDoc_RF4_Cod,'') relatedDocument, ifnull(DDoc_RF4_Fec,CURDATE()) documentDate, ifnull(DDoc_PRD_Ref,'') complemento "
                    strSQL &= "    From Dcmtos_HDR h "
                    strSQL &= "        Left JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                    strSQL &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num ={numero} "

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ano}", ano)
                    strSQL = Replace(strSQL, "{numero}", num)

                    MyCnn.CONECTAR = strConexion
                    COM = New MySqlCommand(strSQL, CON)
                    REA = COM.ExecuteReader
                    If REA.HasRows Then
                        Do While REA.Read
                            If REA.GetString("complemento").ToString() <> "comp" Then
                                strLinea = REA.GetInt32("linea") & "|" 'linea
                                strLinea &= "  " & "|" ' codigo
                                strLinea &= REA.GetString("descripcion") & "|" ' descripcion
                                strLinea &= "  " & "|" ' id unidad de medida
                                strLinea &= "  " & "|" ' unidad de medida
                                strLinea &= "  " & "|" 'Bulto 
                                strLinea &= "  " & "|" ''Tipo Bulto 
                                strLinea &= "  " & "|" ' precio
                                strLinea &= "  " & "|" ' descuento %
                                strLinea &= "  " & "|" ' descuento cantidad
                                strLinea &= "  " & "|" ' cantidad
                                strLinea &= "  " & "|" 'referencia
                                strLinea &= "  " & "|" '  catalogo pro
                                strLinea &= "  " & "|" ' año pro
                                strLinea &= "  " & "|" ' numero pro
                                strLinea &= "  " & "|" ' linea pro
                                strLinea &= "  " & "|" 'destino
                                strLinea &= REA.GetDouble("subTotal").ToString(FORMATO_MONEDA) & "|" 'flete
                                strLinea &= "  " & "|" ' agente de aduanas
                                strLinea &= "  " & "|" ' gestiones aduanales
                                strLinea &= "  " & "|" ' descripcion de factura simple
                                strLinea &= "  " & "|" ' iva
                                strLinea &= "  " & "|" ' ventas exentas
                                strLinea &= "  " & "|" ' subtotal
                                strLinea &= "|"  ' cobro cuenta Ajena
                                strLinea &= "|"  ' cobro cuenta Ajena valor
                                strLinea &= (REA.GetDouble("subTotal")).ToString(FORMATO_MONEDA) & "|" ' total
                                strLinea &= INT_UNO
                                cfun.AgregarFila(dgDetalle, strLinea)
                            Else
                                strLinea = REA.GetInt32("linea") & "|" 'linea complemento
                                strLinea &= REA.GetString("relatedDocument") & "|" ' Documento Relacionado complemento
                                strLinea &= REA.GetDateTime("documentDate").ToString(FORMATO_MYSQL) & "|" ' fecha complemento
                                strLinea &= REA.GetString("cuentaAjena") & "|" ' descripcion complemento
                                strLinea &= REA.GetString("cuentaAjenaValor") & "|" ' valor complemento
                                strLinea &= INT_UNO 'editar complemento 
                                cfun.AgregarFila(dgComplemento, strLinea)
                            End If
                        Loop
                    End If
            End Select
            CalcularTotal()
            CalcularTotalComplemento()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Sub CargarRelacion(ByVal ano As Integer, ByVal num As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim strLinea As String = STR_VACIO

        dgFactrura.Rows.Clear()

        If (Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16) And intTipo = 1 Then
            panelExtras.Visible = True
        Else
            panelExtras.Visible = False
        End If

        Try
            Select Case intTipo
                Case INT_CERO
                    If Sesion.IdEmpresa = 10 Then
                        RelacionatedData(ano, num)
                        Exit Sub
                    Else
                        strSQL = " SELECT h.HDoc_Doc_Status estado, IFNULL(hr.HDoc_Doc_Ano,0) ano, IFNULL(hr.HDoc_Doc_Num,0) numero, IFNULL(hr.HDoc_Doc_Fec,'') fecha, IFNULL(hr.HDoc_DR1_Num,'') referencia, IFNULL(SUM(IF(dr.DDoc_Prd_UM =cc.cat_num,dr.DDoc_Prd_QTY, (dr.DDoc_Prd_QTY / cc.cat_sist))),0) peso  "
                        strSQL &= " FROM Dcmtos_HDR h "
                        strSQL &= "   LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num "
                        strSQL &= "   LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = hh.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = hh.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = hh.HDoc_Doc_Ano AND p.PDoc_Chi_Num = hh.HDoc_Doc_Num AND p.PDoc_Par_Cat = 36 "
                        strSQL &= "   LEFT JOIN {base}.Dcmtos_HDR hr ON hr.HDoc_Sis_Emp = {empresarel} AND hr.HDoc_Doc_Cat = p.PDoc_Par_Cat AND hr.HDoc_Doc_Ano = p.PDoc_Par_Ano AND hr.HDoc_Doc_Num = p.PDoc_Par_Num  "
                        strSQL &= "   LEFT JOIN {base}.Dcmtos_DTL dr ON dr.DDoc_Sis_Emp = hr.HDoc_Sis_Emp AND dr.DDoc_Doc_Cat = hr.HDoc_Doc_Cat AND dr.DDoc_Doc_Ano = hr.HDoc_Doc_Ano AND dr.DDoc_Doc_Num = hr.HDoc_Doc_Num "
                        strSQL &= "   LEFT JOIN {base}.Catalogos c ON c.cat_num = dr.DDoc_Prd_UM AND c.cat_clase ='Medidas' "
                        strSQL &= "   LEFT JOIN {base}.Catalogos cc ON cc.cat_clase ='Medidas' AND cc.cat_clave ='KGS' "
                        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {ano} AND h.HDoc_Doc_Num = {numero} "
                        strSQL &= " group by hr.HDoc_Sis_Emp , hr.HDoc_Doc_Cat , hr.HDoc_Doc_Ano , hr.HDoc_Doc_Num  "

                        strSQL = Replace(strSQL, "{base}", strBaseRel)
                        strSQL = Replace(strSQL, "{empresarel}", intEmpRel)
                        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                        strSQL = Replace(strSQL, "{ano}", ano)
                        strSQL = Replace(strSQL, "{numero}", num)
                    End If


                Case INT_UNO
                    strSQL = " SELECT h.HDoc_Doc_Status estado, IFNULL(h.HDoc_Doc_Ano,0)  ano, IFNULL(h.HDoc_Doc_Num,0) numero, h.HDoc_Doc_Fec fecha, IFNULL(h.HDoc_DR1_Num,0) referencia,  SUM(IF(d.DDoc_Prd_UM =cc.cat_num,d.DDoc_Prd_QTY, (d.DDoc_Prd_QTY / cc.cat_sist))) peso "
                    strSQL &= " FROM Dcmtos_DTL_Pro p "
                    strSQL &= "   LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num AND d.DDoc_Doc_Lin = p.PDoc_Par_Lin "
                    strSQL &= "   LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = d.DDoc_Sis_Emp AND h.HDoc_Doc_Cat = d.DDoc_Doc_Cat AND h.HDoc_Doc_Ano = d.DDoc_Doc_Ano AND h.HDoc_Doc_Num =d.DDoc_Doc_Num "
                    strSQL &= "   left join  Catalogos c ON c.cat_num = d.DDoc_Prd_UM AND c.cat_clase ='Medidas' "
                    strSQL &= "   left join Catalogos cc ON cc.cat_clase ='Medidas' AND cc.cat_clave ='KGS' "
                    strSQL &= " WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Chi_Cat = 296 AND p.PDoc_Chi_Ano = {ano} AND p.PDoc_Chi_Num = {numero} "
                    strSQL &= " group by h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num  "


                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{ano}", ano)
                    strSQL = Replace(strSQL, "{numero}", num)
                Case 2
                    Exit Sub
            End Select

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgFactrura.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetInt32("estado") = 1 Then
                        strLinea = REA.GetInt32("ano") & "|"
                        If REA.GetInt32("numero") = INT_CERO Then
                            strLinea &= "|"
                        Else
                            strLinea &= REA.GetInt32("numero") & "|"
                        End If
                        strLinea &= REA.GetString("fecha").ToString & "|"
                        strLinea &= REA.GetString("referencia") & "|"
                        strLinea &= REA.GetDouble("peso").ToString(FORMATO_MONEDA)

                        cfun.AgregarFila(dgFactrura, strLinea)
                    End If
                Loop
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function OcultarColumnas(ByVal opicion As Integer) As Boolean
        Dim logResult As Boolean = False
        Try

            Select Case opicion
                Case INT_CERO 'factura de cobro
                    botonAgregar.Enabled = True
                    botonQuitar.Enabled = True
                    dgDetalle.Columns("ColCodigo").Visible = False
                    dgDetalle.Columns("colDes").Visible = False
                    dgDetalle.Columns("colIdMedida").Visible = False
                    dgDetalle.Columns("colMedida").Visible = False
                    dgDetalle.Columns("colBulto").Visible = False
                    dgDetalle.Columns("colTipoBulto").Visible = False
                    dgDetalle.Columns("colPrecio").Visible = False
                    dgDetalle.Columns("colDescP").Visible = False
                    dgDetalle.Columns("ColDesD").Visible = False
                    dgDetalle.Columns("colCantidad").Visible = False
                    dgDetalle.Columns("colReferencia").Visible = False
                    dgDetalle.Columns("colID").Visible = False
                    dgDetalle.Columns("ColAnio").Visible = False
                    dgDetalle.Columns("ColNumero").Visible = False
                    dgDetalle.Columns("colLineF").Visible = False

                    dgDetalle.Columns("ColDestino").Visible = True
                    dgDetalle.Columns("ColFlete").Visible = True
                    dgDetalle.Columns("colAgente").Visible = True
                    dgDetalle.Columns("ColGestiones").Visible = True

                    dgDetalle.Columns("ColDestino").ReadOnly = False
                    dgDetalle.Columns("ColFlete").ReadOnly = False
                    dgDetalle.Columns("colAgente").ReadOnly = False
                    dgDetalle.Columns("ColGestiones").ReadOnly = False

                    dgDetalle.Columns("colOtros").Visible = False

                    dgDetalle.Columns("colExepcion").Visible = False
                    dgDetalle.Columns("colImpuesto").Visible = False
                    dgDetalle.Columns("colSubTotal").Visible = False

                    'dgDetalle.Columns("colCtaAjena").Visible = False
                    'dgDetalle.Columns("colCtaAjenaValor").Visible = False

                    EtiquetaImpuesto.Visible = False
                    etiquetaSubTotal.Visible = False
                    etiquetaExepto.Visible = False
                    celdaIva.Visible = False
                    celdaExepcion.Visible = False
                    celdaSubTotal.Visible = False


                    dgDetalle.Columns("colTotal_").Visible = True

                    strTipo = " Bill of payment "
                    logResult = True
                Case INT_UNO ' factura de credito fiscal
                    dgDetalle.Columns("ColCodigo").Visible = True
                    dgDetalle.Columns("colDes").Visible = True
                    dgDetalle.Columns("colIdMedida").Visible = False
                    dgDetalle.Columns("colMedida").Visible = True
                    dgDetalle.Columns("colPrecio").Visible = True
                    dgDetalle.Columns("colDescP").Visible = True
                    dgDetalle.Columns("ColDesD").Visible = True
                    dgDetalle.Columns("colCantidad").Visible = True
                    dgDetalle.Columns("colReferencia").Visible = True
                    dgDetalle.Columns("colID").Visible = False
                    dgDetalle.Columns("ColAnio").Visible = False
                    dgDetalle.Columns("ColNumero").Visible = False
                    dgDetalle.Columns("colLineF").Visible = False

                    dgDetalle.Columns("ColDestino").Visible = False
                    dgDetalle.Columns("ColFlete").Visible = False
                    dgDetalle.Columns("colAgente").Visible = False
                    dgDetalle.Columns("ColGestiones").Visible = False

                    dgDetalle.Columns("colOtros").Visible = False

                    dgDetalle.Columns("colExepcion").Visible = True
                    dgDetalle.Columns("colImpuesto").Visible = True
                    dgDetalle.Columns("colSubTotal").Visible = True
                    dgDetalle.Columns("colTotal_").Visible = True

                    'dgDetalle.Columns("colCtaAjena").Visible = False
                    'dgDetalle.Columns("colCtaAjenaValor").Visible = False

                    EtiquetaImpuesto.Visible = True
                    etiquetaSubTotal.Visible = True
                    etiquetaExepto.Visible = True
                    celdaIva.Visible = True
                    celdaExepcion.Visible = True
                    celdaSubTotal.Visible = True

                    strTipo = " Tax credit invoice "
                    logResult = True
                Case 2 ' factura simple
                    dgDetalle.Columns("ColCodigo").Visible = False
                    dgDetalle.Columns("colDes").Visible = True
                    dgDetalle.Columns("colDes").ReadOnly = False
                    dgDetalle.Columns("colIdMedida").Visible = False
                    dgDetalle.Columns("colMedida").Visible = False
                    dgDetalle.Columns("colBulto").Visible = False
                    dgDetalle.Columns("colTipoBulto").Visible = False
                    dgDetalle.Columns("colPrecio").Visible = False
                    dgDetalle.Columns("colDescP").Visible = False
                    dgDetalle.Columns("ColDesD").Visible = False
                    dgDetalle.Columns("colCantidad").Visible = False
                    dgDetalle.Columns("colReferencia").Visible = False
                    dgDetalle.Columns("colID").Visible = False
                    dgDetalle.Columns("ColAnio").Visible = False
                    dgDetalle.Columns("ColNumero").Visible = False
                    dgDetalle.Columns("colLineF").Visible = False

                    dgDetalle.Columns("ColDestino").Visible = False
                    dgDetalle.Columns("ColFlete").HeaderText = "Subtotal"
                    dgDetalle.Columns("ColFlete").Visible = True
                    dgDetalle.Columns("ColFlete").ReadOnly = False
                    dgDetalle.Columns("colAgente").Visible = False
                    dgDetalle.Columns("ColGestiones").Visible = False

                    dgDetalle.Columns("colExepcion").Visible = False
                    dgDetalle.Columns("colImpuesto").Visible = False
                    dgDetalle.Columns("colSubTotal").Visible = False
                    dgDetalle.Columns("colOtros").Visible = False
                    dgDetalle.Columns("colTotal_").Visible = True

                    'dgDetalle.Columns("colCtaAjena").Visible = False
                    'dgDetalle.Columns("colCtaAjenaValor").Visible = False

                    EtiquetaImpuesto.Visible = False
                    etiquetaSubTotal.Visible = False
                    etiquetaExepto.Visible = False
                    celdaIva.Visible = False
                    celdaExepcion.Visible = False
                    celdaSubTotal.Visible = False

                    strTipo = " Simple invoice "
                    logResult = True
            End Select
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Function ConfigurarForma(Optional ByVal tipo As Integer = NO_FILA) As Boolean
        Dim logResult As Boolean = False
        Dim frmOp As New frmOption
        Try
            If tipo = NO_FILA Then
                frmOp.Titulo = " Invoice type "
                frmOp.Mensaje = "Choose the type of invoice you are going to generate."
                frmOp.Opciones = "Bill of payment|Tax credit invoice|Simple invoice"
                frmOp.ShowDialog(Me)
                If frmOp.DialogResult = System.Windows.Forms.DialogResult.OK Then
                    If OcultarColumnas(frmOp.Seleccion) Then
                        If frmOp.Seleccion = 1 Then
                            If MsgBox("Withhold 1% of Total?", vbYesNo, "Withhold taxes") = vbYes Then
                                IntCalcularImpuesto = 1
                            Else
                                IntCalcularImpuesto = 0
                            End If
                        End If
                        intTipo = frmOp.Seleccion
                        strSerie = Serie()
                        logResult = True
                    End If

                End If
            Else
                If OcultarColumnas(tipo) Then
                    intTipo = tipo
                    logResult = True
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResult
    End Function
    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        Try
            If logMostrar = True Then

                'ocultar panel de documento
                panelDocumento.Dock = DockStyle.None
                panelDocumento.Visible = False
                reset()
                'actualizar Titulo
                BarraTitulo1.CambiarTitulo(" Invoice List")
                'Cargar Datos
                CargarLista()
                'Mostrar Panel Filtro
                panelLista.Visible = True
                panelLista.Dock = DockStyle.Fill
                BloquearBotones()
                Me.Tag = ""
            Else
                'Verifica si se va a crear un nuevo documento o se va modifica
                If logInsert = False Then
                    BarraTitulo1.CambiarTitulo("Update" & strTipo)
                    Me.Tag = "mod"
                    BloquearBotones(False)
                    botonInprimir.Enabled = True
                    'Ocultar Panel Filtro
                    panelLista.Visible = False
                    panelLista.Dock = DockStyle.None
                    'Mostrar panel de documento
                    panelDocumento.Dock = DockStyle.Fill
                    panelDocumento.Visible = True
                Else
                    If ConfigurarForma() = True Then
                        BarraTitulo1.CambiarTitulo("New " & strTipo)
                        Me.Tag = "Nuevo"
                        BloquearBotones(False)
                        botonInprimir.Enabled = False
                        reset()
                        'Ocultar Panel Filtro
                        panelLista.Visible = False
                        panelLista.Dock = DockStyle.None
                        'Mostrar panel de documento
                        panelDocumento.Dock = DockStyle.Fill
                        panelDocumento.Visible = True
                    End If

                    dgLista.DataSource = Nothing
                End If


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarImpuestos(ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim logResultado As Boolean = False
        Dim DT As New Tablas.TDCMTOS_IMP



        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                DT.MDOC_SIS_EMP = Sesion.IdEmpresa
                DT.MDOC_DOC_CAT = 296
                DT.MDOC_DOC_ANO = ano
                DT.MDOC_DOC_NUM = num
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Or dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    DT.MDOC_DOC_LIN = dgDetalle.Rows(i).Cells("ColLinea").Value
                Else
                    DT.MDOC_DOC_LIN = i + 1
                End If

                Select Case intTipo
                    Case INT_CERO

                        DT.MDOC_LIN_ID = 1581
                        DT.MDOC_LIN_CODIGO = "IVA"
                        DT.MDOC_LIN_TIPO = INT_CERO
                        DT.MDOC_LIN_DESC = "IVA"
                        DT.MDOC_LIN_BASE = (dgDetalle.Rows(i).Cells("colTotal_").Value / (1 + (dblImpuestos / 100)))
                        DT.MDOC_LIN_CANTIDAD = 0
                        DT.MDOC_LIN_FACTOR = dblImpuestos
                        DT.MDOC_LIN_MONTO = (dgDetalle.Rows(i).Cells("colTotal_").Value / (1 + (dblImpuestos / 100))) * (dblImpuestos / 100)
                    Case INT_UNO

                        DT.MDOC_LIN_ID = 1581
                        DT.MDOC_LIN_CODIGO = "IVA"
                        DT.MDOC_LIN_TIPO = INT_CERO
                        DT.MDOC_LIN_DESC = "IVA"
                        DT.MDOC_LIN_BASE = dgDetalle.Rows(i).Cells("colSubTotal").Value
                        DT.MDOC_LIN_CANTIDAD = dgDetalle.Rows(i).Cells("colExepcion").Value
                        DT.MDOC_LIN_FACTOR = dblImpuestos
                        DT.MDOC_LIN_MONTO = dgDetalle.Rows(i).Cells("colImpuesto").Value
                    Case 2
                        DT.MDOC_LIN_ID = 1581
                        DT.MDOC_LIN_CODIGO = "IVA"
                        DT.MDOC_LIN_TIPO = INT_CERO
                        DT.MDOC_LIN_DESC = "IVA"
                        DT.MDOC_LIN_BASE = (dgDetalle.Rows(i).Cells("colTotal_").Value / (1 + (dblImpuestos / 100)))
                        DT.MDOC_LIN_CANTIDAD = 0
                        DT.MDOC_LIN_FACTOR = dblImpuestos
                        DT.MDOC_LIN_MONTO = (dgDetalle.Rows(i).Cells("colTotal_").Value / (1 + (dblImpuestos / 100))) * (dblImpuestos / 100)
                End Select
                DT.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If DT.PUPDATE = False Then
                        MsgBox(DT.MERROR.ToUpper)
                    Else
                        logResultado = True
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then

                    If DT.PINSERT = False Then
                        MsgBox(DT.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then

                    If DT.PDELETE = False Then
                        MsgBox(DT.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                End If

            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Return logResultado
    End Function
    Private Function GuardarOrden(ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim logResultados As Boolean = False

        Dim HDR As New clsDcmtos_HDR
        Dim IDFactura As Integer = NO_FILA
        Try


            If Me.Tag = "mod" Then
                HDR.HDOC_DOC_NUM = celdaOrden.Text
                HDR.HDOC_DOC_ANO = celdaAño.Text
                HDR.HDOC_DR2_CAT = celdaCorrelativo.Text
                If checkActivar.Checked = True Then
                    HDR.HDOC_DOC_STATUS = INT_UNO
                Else
                    HDR.HDOC_DOC_STATUS = INT_CERO
                End If
            Else
                HDR.HDOC_DOC_ANO = cfun.AñoMySQL
                IDFactura = cfun.NuevoId(303)
                HDR.HDOC_DOC_NUM = IDFactura
                HDR.HDOC_DOC_STATUS = INT_UNO
                HDR.HDOC_DR2_CAT = NuevoCorrelativo(303, strSerie)
                celdaOrden.Text = IDFactura
            End If
            HDR.HDOC_DR2_NUM = strSerie
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = 303
            HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            HDR.HDOC_EMP_COD = CInt(celdaIdCliente.Text)
            HDR.HDOC_EMP_NOM = celdaCliente.Text
            HDR.HDOC_EMP_DIR = celdaDireccion.Text
            HDR.HDOC_EMP_NIT = celdaNIT.Text
            HDR.HDOC_DR1_CAT = intTipo
            HDR.HDOC_DOC_MON = CInt(celdaIdMoneda.Text)
            HDR.HDOC_DOC_TC = CDbl(celdaTasa.Text)
            HDR.HDOC_EMP_TEL = celdaTelefono.Text
            HDR.HDOC_USUARIO = Sesion.Usuario
            HDR.HDOC_DR2_NUM = "NULL"
            HDR.HDOC_PRO_DANO = ano
            HDR.HDOC_PRO_DCAT = 296
            HDR.HDOC_PRO_DNUM = num
            HDR.HDOC_RF2_NUM = intEmpRel
            HDR.HDOC_RF2_COD = strBaseRel
            HDR.HDOC_RF1_COD = "NULL"
            HDR.CONEXION = strConexion
            If Me.Tag = "mod" Then
                If logEditar = True Then
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString)
                    Else
                        intOrden = HDR.HDOC_DOC_NUM
                        logResultados = True
                    End If
                Else
                    MsgBox("You do not have permissions to perform this action", MsgBoxStyle.Information)
                    Return False
                    Exit Function
                End If
            Else
                If logInsertar = True Then
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString)
                    Else
                        intOrden = HDR.HDOC_DOC_NUM
                        logResultados = True
                    End If
                Else
                    MsgBox("You do not have permissions to perform this action", MsgBoxStyle.Information)
                    Return False
                    Exit Function
                End If
            End If
            If GuardarDetalle(303, HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM) = False Then
                Return False
                Exit Function
            End If
            If GuardarPro(HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM, HDR.HDOC_PRO_DANO, HDR.HDOC_PRO_DNUM) = False Then
                Return False
                Exit Function
            End If
            If GuardarImpuestos(HDR.HDOC_PRO_DANO, HDR.HDOC_PRO_DNUM) = False Then
                Return False
                Exit Function
            End If
            Return logResultados
        Catch ex As Exception
            MsgBox(ex.ToString)
            Return False
        End Try
    End Function
    Private Function GuardarDetalle(ByVal cat As Integer, ByVal ano As Integer, ByVal num As Integer) As Boolean
        Dim DT As New clsDcmtos_DTL
        Dim logResultado As Boolean = False
        Dim linea As Integer = 0
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                DT.DDOC_SIS_EMP = Sesion.IdEmpresa
                DT.DDOC_DOC_CAT = cat
                DT.DDOC_DOC_ANO = ano
                DT.DDOC_DOC_NUM = num
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Or dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    DT.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("ColLinea").Value
                Else
                    DT.DDOC_DOC_LIN = linea + 1
                End If

                Select Case intTipo
                    Case INT_CERO
                        DT.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("ColDestino").Value
                        DT.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("ColFlete").Value
                        DT.DDOC_RF2_DBL = dgDetalle.Rows(i).Cells("colAgente").Value
                        DT.DDOC_RF3_DBL = dgDetalle.Rows(i).Cells("ColGestiones").Value
                    Case INT_UNO

                        DT.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("ColCodigo").Value
                        DT.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDes").Value
                        DT.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colIdMedida").Value
                        DT.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                        DT.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value
                        DT.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colDescP").Value
                        DT.DDOC_PRD_DSQ = dgDetalle.Rows(i).Cells("ColDesD").Value
                        DT.DDOC_RF1_TXT = dgDetalle.Rows(i).Cells("colReferencia").Value
                        DT.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colTipoBulto").Value
                    Case 2
                        DT.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDes").Value
                        DT.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("ColFlete").Value
                End Select

                DT.CONEXION = strConexion
                If dgDetalle.Rows(i).Cells("colExtra").Value = 1 Then
                    If DT.Actualizar = False Then
                        MsgBox(DT.MERROR.ToUpper)
                    Else
                        logResultado = True
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 Then
                    If DT.Guardar = False Then
                        MsgBox(DT.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                    If DT.Borrar = False Then
                        MsgBox(DT.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                End If
                linea += 1
            Next

            For i As Integer = 0 To dgComplemento.Rows.Count - 1

                DT.DDOC_SIS_EMP = Sesion.IdEmpresa
                DT.DDOC_DOC_CAT = cat
                DT.DDOC_DOC_ANO = ano
                DT.DDOC_DOC_NUM = num
                If dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 1 Or dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 2 Then
                    DT.DDOC_DOC_LIN = dgComplemento.Rows(i).Cells("colLinComplemento").Value
                Else
                    DT.DDOC_DOC_LIN = linea + 1
                End If

                DT.DDoc_RF4_Fec_NET = dgComplemento.Rows(i).Cells("colDate").Value
                DT.DDOC_RF4_COD = dgComplemento.Rows(i).Cells("colRelatedDocument").Value
                DT.DDOC_RF4_TXT = dgComplemento.Rows(i).Cells("colComplemento").Value
                DT.DDOC_RF4_DBL = dgComplemento.Rows(i).Cells("colComplementoValor").Value
                DT.DDOC_PRD_REF = "comp"

                DT.CONEXION = strConexion
                If dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 1 Then
                    If DT.Actualizar = False Then
                        MsgBox(DT.MERROR.ToUpper)
                    Else
                        logResultado = True
                    End If
                ElseIf dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 0 Then
                    If DT.Guardar = False Then
                        MsgBox(DT.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                ElseIf dgComplemento.Rows(i).Cells("colExtraComplemento").Value = 2 Then
                    If DT.Borrar = False Then
                        MsgBox(DT.MERROR.ToString)
                    Else
                        logResultado = True
                    End If
                End If
                linea += 1
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado

    End Function
    Private Function GuardarBultos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlBox As New Tablas.TDCMTOS_DTL_BOX
        Const I_CODIGO As Integer = 1
        'Const I_CAJA As Integer = 2
        'Const I_CANTIDAD As Integer = 3
        Dim varDato As String = STR_VACIO
        Dim j As Integer = 0

        DtlBox.CONEXION = strConexion
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                Select Case intTipo
                    Case INT_UNO

                        DtlBox.BDOC_SIS_EMP = Sesion.IdEmpresa
                        DtlBox.BDOC_DOC_CAT = 296
                        DtlBox.BDOC_DOC_ANO = celdaAño.Text
                        DtlBox.BDOC_DOC_NUM = celdaNumero.Text
                        If Me.Tag = "Nuevo" Then
                            If dgDetalle.Rows(i).Visible = True Then
                                j = j + 1
                            End If
                            DtlBox.BDOC_DOC_LIN = j
                        Else
                            DtlBox.BDOC_DOC_LIN = dgDetalle.Rows(i).Cells("ColLinea").Value
                        End If
                        'DtlBox.BDOC_DOC_LIN = i + 1
                        DtlBox.BDOC_BOX_LIN = 1
                        DtlBox.BDOC_BOX_COD = I_CODIGO
                        DtlBox.BDOC_BOX_QTY = CDbl(dgDetalle.Rows(i).Cells("colBulto").Value)
                        DtlBox.BDOC_BOX_LB = dgDetalle.Rows(i).Cells("colCantidad").Value


                        If dgDetalle.Rows(i).Cells("colExtra").Value = 1 And Me.Tag = "mod" Then
                            If DtlBox.PUPDATE = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                                logResultado = False
                            End If
                        ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 0 And Me.Tag = "Nuevo" Then
                            If DtlBox.PINSERT = False Then
                                MsgBox(DtlBox.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                                logResultado = False
                            Else
                                logResultado = True
                            End If
                        ElseIf dgDetalle.Rows(i).Cells("colExtra").Value = 2 Then
                            If DtlBox.PDELETE = False Then
                                MsgBox(DtlBox.MERROR.ToString)
                                logResultado = False
                            Else
                                logResultado = True
                            End If
                        End If

                End Select
            Next
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Private Function GuardarPro(ByVal ano As Integer, ByVal num As Integer, Optional ByVal ano2 As Integer = NO_FILA, Optional ByVal num2 As Integer = NO_FILA) As Boolean
        Dim DPRO As New clsDcmtos_DTL_Pro
        Dim logResultado As Boolean = False
        Try
            For j As Integer = INT_CERO To INT_UNO

                DPRO.PDOC_SIS_EMP = Sesion.IdEmpresa

                Select Case intTipo
                    Case INT_CERO
                        For i As Integer = 0 To dgFactrura.Rows.Count - 1

                            If j = INT_CERO Then
                                DPRO.PDOC_PAR_ANO = ano
                                DPRO.PDOC_PAR_CAT = 303
                                DPRO.PDOC_PAR_NUM = num
                                DPRO.PDOC_PAR_LIN = i + 1
                                DPRO.PDOC_CHI_ANO = ano2
                                DPRO.PDOC_CHI_CAT = 296
                                DPRO.PDOC_CHI_NUM = num2
                            Else
                                DPRO.PDOC_PAR_ANO = dgFactrura.Rows(i).Cells("ColYearF").Value
                                DPRO.PDOC_PAR_CAT = 36
                                DPRO.PDOC_PAR_NUM = dgFactrura.Rows(i).Cells("ColInvoiceF").Value
                                DPRO.PDOC_PAR_LIN = i + 1
                                DPRO.PDOC_CHI_ANO = ano
                                DPRO.PDOC_CHI_CAT = 303
                                DPRO.PDOC_CHI_NUM = num
                            End If
                            If Me.Tag = "mod" Then
                                DPRO.PDOC_CHI_LIN = 1
                            Else
                                DPRO.PDOC_CHI_LIN = i + 1
                            End If
                            DPRO.CONEXION = strConexion
                            If Me.Tag = "mod" Then
                                If checkActivar.Checked = True Then
                                    If DPRO.Actualizar = False Then
                                        MsgBox(DPRO.MERROR.ToString)
                                    Else
                                        logResultado = True
                                    End If
                                Else
                                    BorrarDtl_ProFactura(num, ano)
                                End If

                            Else
                                If DPRO.Guardar = False Then
                                    MsgBox(DPRO.MERROR.ToString)
                                Else
                                    logResultado = True
                                End If
                            End If
                        Next
                    Case INT_UNO
                        For I As Integer = 0 To dgDetalle.Rows.Count - 1

                            DPRO.PDOC_PAR_ANO = dgDetalle.Rows(I).Cells("ColAnio").Value
                            DPRO.PDOC_PAR_CAT = 36
                            DPRO.PDOC_PAR_NUM = dgDetalle.Rows(I).Cells("ColNumero").Value
                            DPRO.PDOC_PAR_LIN = dgDetalle.Rows(I).Cells("colLineF").Value
                            DPRO.PDOC_CHI_ANO = ano
                            DPRO.PDOC_CHI_CAT = 296
                            DPRO.PDOC_CHI_NUM = num

                            If dgDetalle.Rows(I).Cells("colExtra").Value = 1 Or dgDetalle.Rows(I).Cells("colExtra").Value = 2 Then
                                DPRO.PDOC_CHI_LIN = dgDetalle.Rows(I).Cells("ColLinea").Value
                            Else
                                DPRO.PDOC_CHI_LIN = I + 1
                            End If
                            DPRO.CONEXION = strConexion
                            If dgDetalle.Rows(I).Cells("colExtra").Value = 1 Then
                                If DPRO.Actualizar = False Then
                                    MsgBox(DPRO.MERROR.ToString)
                                Else
                                    logResultado = True
                                End If
                            ElseIf dgDetalle.Rows(I).Cells("colExtra").Value = 0 Then

                                If DPRO.Guardar = False Then
                                    MsgBox(DPRO.MERROR.ToString)
                                Else
                                    logResultado = True
                                End If
                            ElseIf dgDetalle.Rows(I).Cells("colExtra").Value = 2 Then

                                If DPRO.Borrar = False Then
                                    MsgBox(DPRO.MERROR.ToString)
                                Else
                                    logResultado = True
                                End If
                            End If
                            'If Me.Tag = "mod" Then
                            '    If DPRO.Actualizar = False Then
                            '        MsgBox(DPRO.MERROR.ToString)
                            '    Else
                            '        logResultado = True
                            '    End If
                            'Else
                            '    If DPRO.Guardar = False Then
                            '        MsgBox(DPRO.MERROR.ToString)
                            '    Else
                            '        logResultado = True
                            '    End If
                            'End If
                        Next
                    Case 2
                        logResultado = True 'TODO
                End Select

                If intTipo > INT_CERO Then
                    Exit For
                End If
            Next
            Return logResultado

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Function

    Private Sub BorrarDtl_ProFactura(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "PDoc_Sis_Emp = {empresa}  AND PDoc_Chi_Cat = 303 AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function PlazoDeCredito(ByVal ID As Long) As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim intPlazo As Integer = NO_FILA

        strSQL = "SELECT cli_plazoCR " &
                 "FROM Clientes " &
                 "WHERE cli_codigo = " & ID & " AND cli_sisemp = " & Sesion.IdEmpresa
        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            intPlazo = COM.ExecuteScalar

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return intPlazo

    End Function
    Private Function GuardarOperacion(ByVal ano As Integer, ByVal num As Integer)
        Dim logResultado As Boolean = False
        Dim CC As New Tablas.TECTACTE
        Dim intdias As Integer = INT_CERO
        Try
            intdias = PlazoDeCredito(CInt(celdaIdCliente.Text))
            CC.ECTA_SIS_EMP = Sesion.IdEmpresa
            CC.ECTA_DOC_CAT = 296
            CC.ECTA_DOC_ANO = ano
            CC.ECTA_DOC_NUM = num
            CC.ECTA_DOC_LIN = INT_UNO
            CC.ECTA_TIPOEMP = "Clientes"
            CC.ECTA_CODEMP = CInt(celdaIdCliente.Text)
            CC.ECTA_SINI_LOC = INT_CERO
            If checkActivar.Checked = True Then
                'Sólo si no está anulada
                CC.ECTA_CRGO_LOC = CDbl(celdaTotal.Text) * CDbl(celdaTasa.Text)
                CC.ECTA_CRGO_EXT = CDbl(celdaTotal.Text)
            End If
            CC.ECTA_ABNO_EXT = INT_CERO
            CC.ECTA_ABNO_LOC = INT_CERO
            CC.ECTA_CONCEPTO = " Factura de Cobro No. " & num
            CC.ECta_FecDcmt_NET = dtpFecha.Value
            CC.ECta_FecVenc_NET = dtpFecha.Value.AddDays(intdias)
            CC.ECTA_MONEDA = CInt(celdaIdMoneda.Text)
            CC.ECTA_TC = celdaTasa.Text
            CC.ECTA_REF_CAT = 296
            CC.ECTA_REF_ANO = ano
            CC.ECTA_REF_NUM = num
            'Me.Tag = "nuevo"
            CC.CONEXION = strConexion
            If Me.Tag = "mod" Then
                ActualizarReferencia()
                If CC.PUPDATE = False Then
                    MsgBox(CC.MERROR.ToString)
                Else
                    logResultado = True
                End If
            Else
                If CC.PINSERT = False Then
                    MsgBox(CC.MERROR.ToString)
                Else
                    logResultado = True
                End If
            End If


        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            CC.Dispose()
            CC = Nothing
            System.GC.Collect()
        End Try
        Return logResultado

    End Function
    Public Sub ActualizarReferencia()
        Dim COM As MySqlCommand
        Dim strSQL As String
        Dim dblAbonoExt As Double = 0
        Dim dblAbonoLoc As Double = 0
        Dim dblTotal As Double
        Dim dblCredito As Double
        Dim dblCobro As Double
        Dim dblTasa As Double
        Dim strDato As String = STR_VACIO
        Dim cat As Integer = NO_FILA
        Dim anioRef As Integer = NO_FILA
        Dim numref As Integer = NO_FILA
        Dim intdias As Integer = NO_FILA
        Dim dtpFechaV As Date
        Try




            dblCredito = vbEmpty
            intdias = PlazoDeCredito(CInt(celdaIdCliente.Text))
            If (checkActivar.Checked) = True Then
                dblTotal = CDbl(celdaTotal.Text) * CDbl(celdaTasa.Text)
            End If
            strDato = CXC_NAME & " No. " & CDbl(celdaNumero.Text)

            'Documento de referencia (factura)
            If Sesion.IdEmpresa = 10 Or Sesion.IdEmpresa = 9 Or Sesion.IdEmpresa = 13 Then
                cat = 296
            Else
                cat = 36
            End If

            'Transacción: cargo/abono local y en moneda del doc.
            dblCobro = CDbl(celdaTotal.Text)

            dtpFechaV = dtpFecha.Value.AddDays(intdias)

            strSQL = " UPDATE  ECtaCte  e  SET e.ECta_codemp = {cliente},e.ECta_Crgo_Loc = {total}, e.ECta_Crgo_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fechaV}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
            strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 296  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            If Sesion.IdEmpresa = 18 Then
                strSQL &= "; UPDATE  PDM.ECtaCte  e  SET e.ECta_codemp = {cliente},e.ECta_Crgo_Loc = {total}, e.ECta_Crgo_Ext = {totalext} , e.ECta_Concepto = '{dato}', e.ECta_FecVenc = '{fechaV}', e.ECta_FecDcmt = '{fecha}' , e.ECta_moneda = {moneda} , e.ECta_TC = {tasa} ,e.ECta_Ref_Cat = {catref} , e.ECta_Ref_Ano = {anioref} , e.ECta_Ref_Num = {numref}  "
                strSQL &= "     WHERE e.ECta_Sis_Emp = {empresa} AND e.ECta_Doc_Cat = 296  and e.ECta_Doc_Ano = {anio} and e.ECta_Doc_Num = {numero} "
            End If
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{total}", dblTotal)
            strSQL = Replace(strSQL, "{totalext}", dblCobro)
            strSQL = Replace(strSQL, "{dato}", strDato)
            strSQL = Replace(strSQL, "{cliente}", celdaIdCliente.Text)
            strSQL = Replace(strSQL, "{fechaV}", dtpFechaV.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fecha}", dtpFecha.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{moneda}", celdaIdMoneda.Text)
            strSQL = Replace(strSQL, "{tasa}", celdaTasa.Text)
            strSQL = Replace(strSQL, "{catref}", cat)
            strSQL = Replace(strSQL, "{anioref}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numref}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Public Sub ActualizarHilos()
        'actualizar usando..catalogo 303
        'num.. numero de orden
        'año

        Try

            Dim anio As Integer
            Dim numOrd As Integer
            Dim FacturasH As String
            Dim Fact As Integer
            Dim AnioF As Integer
            Dim i As Integer
            Dim COM As New MySqlCommand
            Dim strSQL As String = STR_VACIO

            anio = celdaAño.Text
            numOrd = celdaOrden.Text

            For i = 0 To dgFactrura.Rows.Count - 1
                Fact = dgFactrura.Rows(i).Cells("colInvoiceF").Value
                AnioF = dgFactrura.Rows(i).Cells("colYearF").Value

                'HDoc_Doc_Ano = 2017 AND HDoc_Doc_Num =111
                If i = 0 Then
                    FacturasH = " HDoc_Doc_Ano = " & AnioF & " AND HDoc_Doc_Num = " & Fact
                Else
                    FacturasH = FacturasH & " OR " & " HDoc_Doc_Ano = " & AnioF & " AND HDoc_Doc_Num = " & Fact
                End If

            Next

            strSQL = " UPDATE Hilos.Dcmtos_HDR Set HDoc_Pro_DCat = {cat} , HDoc_Pro_DAno= {anio} , HDoc_Pro_DNum = {num} WHERE HDoc_Sis_Emp = 12 And HDoc_Doc_Cat = 36 And ({fact})"
            If checkActivar.Checked = True Then
                strSQL = Replace(strSQL, "{anio}", anio)
                strSQL = Replace(strSQL, "{num}", numOrd)
                strSQL = Replace(strSQL, "{fact}", FacturasH)
                strSQL = Replace(strSQL, "{cat}", 303)
            Else
                strSQL = Replace(strSQL, "{anio}", 0)
                strSQL = Replace(strSQL, "{num}", 0)
                strSQL = Replace(strSQL, "{fact}", FacturasH)
                strSQL = Replace(strSQL, "{cat}", 0)
            End If


            If Sesion.IdEmpresa = 10 Then
                cfun.sesionHilos()
                ' Configura la cadena de conexión para baseOF
                Dim connectionStringBaseOF As String = "server=" & CMC_Hilos_Host & ";Port=" & CMC_Hilos_PORT & ";database=" & CMC_Hilos_BASE & ";uid=" & CMC_Hilos_USER & ";password=" & CMC_Hilos_PASS & ";"
                Try
                    MyCnn.CONECTAR = connectionStringBaseOF
                    COM = New MySqlCommand(strSQL, CON)
                    COM.ExecuteNonQuery()
                    COM = Nothing
                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Else
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                COM.ExecuteNonQuery()
            End If



        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
    Private Function NuevaFacturaCobro() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 296)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Function Guardar() As Boolean
        Dim logResultados As Boolean = False
        Dim HDR As New clsDcmtos_HDR
        Dim IDFactura As Integer = NO_FILA
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        Try


            If Me.Tag = "mod" Then
                HDR.HDOC_DOC_NUM = celdaNumero.Text
                HDR.HDOC_DOC_ANO = celdaAño.Text
                HDR.HDOC_DR2_CAT = celdaCorrelativo.Text
                If checkActivar.Checked = True Then
                    HDR.HDOC_DOC_STATUS = INT_UNO
                Else
                    HDR.HDOC_DOC_STATUS = INT_CERO
                End If
            Else
                HDR.HDOC_DOC_ANO = cfun.AñoMySQL
                IDFactura = NuevaFacturaCobro()
                celdaNumero.Text = IDFactura
                HDR.HDOC_DOC_NUM = celdaNumero.Text
                HDR.HDOC_DOC_STATUS = INT_UNO
                If celdaCorrelativo.Text = NO_FILA Then
                    celdaCorrelativo.Text = NuevoCorrelativo(296, strSerie)
                End If

                HDR.HDOC_DR2_CAT = celdaCorrelativo.Text

            End If


            ' HDR.HDOC_DR2_NUM = vbNullString
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = 296
            HDR.HDoc_Doc_Fec_NET = dtpFecha.Value
            HDR.HDOC_EMP_COD = CInt(celdaIdCliente.Text)
            HDR.HDOC_EMP_NOM = celdaCliente.Text
            HDR.HDOC_EMP_DIR = celdaDireccion.Text
            HDR.HDOC_EMP_NIT = celdaNIT.Text
            HDR.HDOC_DR1_CAT = intTipo
            HDR.HDOC_DOC_MON = CInt(celdaIdMoneda.Text)
            HDR.HDOC_DOC_TC = CDbl(celdaTasa.Text)
            HDR.HDOC_EMP_TEL = celdaTelefono.Text
            HDR.HDOC_USUARIO = Sesion.Usuario
            'HDR.HDOC_DR2_NUM = vbNullString
            HDR.HDOC_RF1_DBL = CDbl(celdaTotal.Text)

            HDR.HDOC_RF1_TXT = celdaObservaciones.Text
            If (Sesion.IdEmpresa = 12 Or Sesion.IdEmpresa = 16) And intTipo = 1 Then
                HDR.HDOC_RF1_COD = celdaRegistro.Text
                HDR.HDOC_RF2_TXT = celdaGiro.Text
                HDR.HDOC_DR2_NUM = celdaSerie.Text
                HDR.HDOC_ANT_COM = IntCalcularImpuesto
            ElseIf Sesion.IdEmpresa = 10 Then
                HDR.HDOC_RF2_TXT = celdaNotas.Text
                HDR.HDOC_RF1_COD = "NULL"
                HDR.HDOC_DR2_NUM = "NULL"
            End If


            If Me.Tag = "mod" Then
                If Sesion.IdEmpresa = 10 Then
                    If celdaUUID.Text <> STR_VACIO Then
                        If checkActivar.Checked = False Then
                            ArrayServer = strConexion.Split(";".ToCharArray)
                            strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
                            ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
                            strCadena = ArrayServer(INT_CERO)
                            ArrayValidacion = strCadena.Split(".".ToCharArray)
                            strCadena = ArrayValidacion(INT_CERO)
                            arrayIP = strCadena.Split("=".ToCharArray)
                            If arrayIP(INT_UNO) = "192" Then
                                If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                                Else
                                    MsgBox("Check your local connection")
                                    Exit Function
                                End If
                            Else
                                Exit Function
                            End If
                            If PermisoAnular() = True Then
                                If AnularFel(celdaSerieFel.Text, celdaFechaEmisionDocumento.Text, IP, strUsuario, strContrasena, strRuta) = False Then
                                    Exit Function
                                End If
                            Else
                                MsgBox("You don't have access to cancel this document")
                                Exit Function
                            End If
                        End If
                    Else
                        If checkActivar.Checked = False Then
                            MsgBox("You cannot cancel a document that is not transmitted" & vbNewLine & "please contact the Financial department.")
                            Exit Function
                        End If
                    End If
                End If

                HDR.CONEXION = strConexion
                If logEditar = True Then
                    If HDR.Actualizar = False Then
                        MsgBox(HDR.MERROR.ToString)
                    Else

                        logResultados = True
                    End If
                Else
                    MsgBox("You Do Not have permissions To perform this action", MsgBoxStyle.Information)
                    Return False
                    Exit Function
                End If
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 296, celdaAño.Text, celdaNumero.Text)
            Else
                If logInsertar = True Then
                    If HDR.Guardar = False Then
                        MsgBox(HDR.MERROR.ToString)
                    Else

                        logResultados = True
                    End If
                Else
                    MsgBox("You Do Not have permissions To perform this action", MsgBoxStyle.Information)
                    Return False
                    Exit Function
                End If
                cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 296, celdaAño.Text, celdaNumero.Text)
            End If

            If intTipo = INT_CERO Then
                GuardarOrden(HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM)
                'If dgComplemento.Rows.Count > 0 Then
                '    If GuardarDetalle(296, HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM) = False Then
                '        Return False
                '        Exit Function
                '    End If
                'End If
            Else

                If GuardarDetalle(296, HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM) = False Then
                    Return False
                    Exit Function
                End If
                If GuardarBultos() = False Then
                    Return False
                    Exit Function
                End If
                If GuardarPro(HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM) = False Then
                    Return False
                    Exit Function
                End If
                If GuardarImpuestos(HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM) = False Then
                    Return False
                    Exit Function
                End If
            End If
            If GuardarOperacion(HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM) = False Then
                Return False
            End If

            ' Actualiza HDR de Hilos
            If celdaOrden.Text > 0 Then
                ActualizarHilos()
            End If


            '-------------------------------Generar poliza contable---------------------------------
            Dim conta As New clsContabilidad
            conta.GenerarPoliza(296, HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM)
            If checkActivar.Checked = False Then
                cfun.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAño.Text, 296)
                cfun.BorrarDetallePoliza(celdaNumero.Text, celdaAño.Text, 296)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Me.Tag = "mod"
        Return logResultados

    End Function
    Private Sub FacturaFiscal()
        Dim strSQL As String
        Dim repCR As New FacturaCreditoFiscal
        If Sesion.IdEmpresa = 16 Then
            strSQL = " Select c.cli_plazoCR plazoCR, h.HDoc_Emp_Nom cliente, h.HDoc_Emp_Dir direccion, 
                h.HDoc_Doc_Fec fecha, h.HDoc_Emp_NIT nit, h.HDoc_RF1_Cod nregistro, h.HDoc_RF2_Txt giro, 
                CAST(If(d.DDoc_Prd_UM = 70, CONCAT(d.DDoc_Prd_QTY, ' KGS'), CONCAT(d.DDoc_Prd_QTY, ' LBS')) AS CHAR) cantidad, 
                d.DDoc_RF1_Dbl precioU, i.MDoc_Lin_Base base, i.MDoc_Lin_Cantidad exento, 
                i.MDoc_Lin_Monto impuesto, inv.inv_prodlote lote, 0 Bulto, 
                IFNULL(b.BDoc_Box_QTY, 0) Bultos, 0 KBruto, 
                CAST(If(d.DDoc_Prd_UM = 70, CONCAT(' KGS'), CONCAT(' LBS')) AS CHAR) medida, '' orden,
                d.DDoc_Prd_Des descripcion, '' Destino, '' PO_No
                                From Dcmtos_HDR h
                Left Join Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num
                Left Join Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp And b.BDoc_Doc_Cat = d.DDoc_Doc_Cat And b.BDoc_Doc_Ano = d.DDoc_Doc_Ano And b.BDoc_Doc_Num = d.DDoc_Doc_Num And b.BDoc_Doc_Lin = d.DDoc_Doc_Lin
                Left Join Dcmtos_IMP i ON i.MDoc_Sis_Emp = d.DDoc_Sis_Emp And i.MDoc_Doc_Cat = d.DDoc_Doc_Cat And i.MDoc_Doc_Ano = d.DDoc_Doc_Ano And i.MDoc_Doc_Num = d.DDoc_Doc_Num And i.MDoc_Doc_Lin = d.DDoc_Doc_Lin
                Left Join Inventarios inv ON inv.inv_sisemp = d.DDoc_Sis_Emp And inv.inv_numero = d.DDoc_Prd_Cod
                Left Join Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp And c.cli_codigo = h.HDoc_Emp_Cod"
        Else

            strSQL = " SELECT c.cli_plazoCR plazoCR, h.HDoc_Emp_Nom cliente, h.HDoc_Emp_Dir direccion, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_NIT nit, h.HDoc_RF1_Cod nregistro, h.HDoc_RF2_Txt giro, CAST(IF(d.DDoc_Prd_UM = 70, CONCAT(d.DDoc_Prd_QTY, ' KGS'), 
                CONCAT(d.DDoc_Prd_QTY, ' LBS')) AS CHAR) cantidad, d.DDoc_Prd_NET precioU, i.MDoc_Lin_Base base, i.MDoc_Lin_Cantidad exento, i.MDoc_Lin_Monto impuesto, inv.inv_prodlote lote,d36.DDoc_RF2_Txt Bulto, 
                IFNULL(b.BDoc_Box_QTY,0) Bultos,d36.DDoc_RF2_Dbl KBruto,CAST(IF(d.DDoc_Prd_UM = 70, CONCAT(' KGS'), CONCAT(' LBS')) AS CHAR) medida, ( "
            strSQL &= " SELECT CAST(GROUP_CONCAT(DISTINCT CONCAT(c.HDoc_Doc_Num, ':'), c.HDoc_DR1_Num SEPARATOR ',') AS CHAR) "
            strSQL &= " FROM Dcmtos_DTL_Pro aa "
            strSQL &= " INNER JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = aa.PDoc_Sis_Emp AND b.PDoc_Chi_Ano = aa.PDoc_Par_Ano AND b.PDoc_Chi_Cat = aa.PDoc_Par_Cat AND b.PDoc_Chi_Num = aa.PDoc_Par_Num AND b.PDoc_Chi_Lin = aa.PDoc_Par_Lin AND b.PDoc_Par_Cat = 75 "
            strSQL &= " INNER JOIN Dcmtos_HDR c ON c.HDoc_Sis_Emp = b.PDoc_Sis_Emp AND c.HDoc_Doc_Ano = b.PDoc_Par_Ano AND c.HDoc_Doc_Cat = b.PDoc_Par_Cat AND c.HDoc_Doc_Num = b.PDoc_Par_Num  "
            strSQL &= " WHERE aa.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND aa.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND aa.PDoc_Chi_Cat = 36 AND aa.PDoc_Chi_Num = dp.PDoc_Par_Num) orden,( "

            strSQL &= "                                 SELECT l.DDoc_Prd_Des "
            strSQL &= "                                     FROM Dcmtos_DTL_Pro aa "
            strSQL &= "                                         INNER JOIN Dcmtos_DTL_Pro b ON b.PDoc_Sis_Emp = aa.PDoc_Sis_Emp AND b.PDoc_Chi_Ano = aa.PDoc_Par_Ano AND b.PDoc_Chi_Cat = aa.PDoc_Par_Cat AND b.PDoc_Chi_Num = aa.PDoc_Par_Num AND b.PDoc_Chi_Lin = aa.PDoc_Par_Lin AND b.PDoc_Par_Cat = 75 "
            strSQL &= "                                             INNER JOIN Dcmtos_DTL l ON l.DDoc_Sis_Emp = b.PDoc_Sis_Emp AND l.DDoc_Doc_Ano = b.PDoc_Par_Ano AND l.DDoc_Doc_Cat = b.PDoc_Par_Cat AND l.DDoc_Doc_Num = b.PDoc_Par_Num AND l.DDoc_Doc_Lin = b.PDoc_Par_Lin "
            strSQL &= "                                         WHERE aa.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND aa.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND aa.PDoc_Chi_Cat = 36 AND aa.PDoc_Chi_Num = dp.PDoc_Par_Num AND aa.PDoc_Chi_Lin = dp.PDoc_Par_Lin) descripcion, cat.cat_desc Destino "

            strSQL &= ",(
                    SELECT GROUP_CONCAT(DISTINCT(hp75.HDoc_DR1_Num) SEPARATOR ', ') FROM Dcmtos_DTL_Pro pc296
                    JOIN Dcmtos_DTL_Pro pp36 ON pp36.PDoc_Sis_Emp=pc296.PDoc_Sis_Emp AND pp36.PDoc_Chi_Cat=pc296.PDoc_Par_Cat AND pp36.PDoc_Chi_Ano=pc296.PDoc_Par_Ano AND pp36.PDoc_Chi_Num=pc296.PDoc_Par_Num
                    JOIN Dcmtos_DTL_Pro pp75
                    ON pp75.PDoc_Sis_Emp=pp36.PDoc_Sis_Emp AND pp75.PDoc_Chi_Cat=pp36.PDoc_Par_Cat AND pp75.PDoc_Chi_Ano=pp36.PDoc_Par_Ano AND pp75.PDoc_Chi_Num=pp36.PDoc_Par_Num AND pp75.PDoc_Par_Cat=75
                    JOIN Dcmtos_HDR hp75
	                    ON hp75.HDoc_Sis_Emp=pp75.PDoc_Sis_Emp AND hp75.HDoc_Doc_Cat=pp75.PDoc_Par_Cat AND hp75.HDoc_Doc_Ano=pp75.PDoc_Par_Ano AND hp75.HDoc_Doc_Num=pp75.PDoc_Par_Num
                    WHERE pc296.PDoc_Sis_Emp=h.HDoc_Sis_Emp AND pc296.PDoc_Chi_Cat=296 AND pc296.PDoc_Chi_Ano=h.HDoc_Doc_Ano AND pc296.PDoc_Chi_Num=h.HDoc_Doc_Num
	                        )PO_No"

            strSQL &= " FROM Dcmtos_HDR h "
            strSQL &= " LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
            strSQL &= " LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin "
            strSQL &= " LEFT JOIN Dcmtos_IMP i ON i.MDoc_Sis_Emp = d.DDoc_Sis_Emp AND i.MDoc_Doc_Cat = d.DDoc_Doc_Cat AND i.MDoc_Doc_Ano = d.DDoc_Doc_Ano AND i.MDoc_Doc_Num = d.DDoc_Doc_Num AND i.MDoc_Doc_Lin = d.DDoc_Doc_Lin "
            strSQL &= " LEFT JOIN Inventarios inv ON inv.inv_sisemp = d.DDoc_Sis_Emp AND inv.inv_numero = d.DDoc_Prd_Cod "
            strSQL &= " LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = d.DDoc_Sis_Emp AND dp.PDoc_Chi_Cat = d.DDoc_Doc_Cat AND dp.PDoc_Chi_Ano = d.DDoc_Doc_Ano AND dp.PDoc_Chi_Num = d.DDoc_Doc_Num AND dp.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
            strSQL &= "LEFT JOIN Dcmtos_DTL d36 ON d36.DDoc_Sis_Emp = dp.PDoc_Sis_Emp AND d36.DDoc_Doc_Cat = dp.PDoc_Par_Cat AND d36.DDoc_Doc_Ano = dp.PDoc_Par_Ano AND d36.DDoc_Doc_Num = dp.PDoc_Par_Num AND d36.DDoc_Doc_Lin = dp.PDoc_Par_Lin  "
            strSQL &= " LEFT JOIN Dcmtos_DTL_Box db36 ON db36.BDoc_Sis_Emp  = d36.DDoc_Sis_Emp AND db36.BDoc_Doc_Cat = d36.DDoc_Doc_Cat AND db36.BDoc_Doc_Ano = d36.DDoc_Doc_Ano AND db36.BDoc_Doc_Num = d36.DDoc_Doc_Num AND db36.BDoc_Doc_Lin = d36.DDoc_Doc_Lin "
            strSQL &= " LEFT JOIN Clientes c ON c.cli_sisemp = h.HDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
            strSQL &= " LEFT JOIN Catalogos cat ON cat.cat_num = inv.inv_lugarfab AND cat.cat_clase = 'Paises' "
        End If
        strSQL &= " WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 296 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        If BuscarRegistrosDcmtos_HDR_FISCAL(strSQL) = True Then

        End If
        repCR.Load("C:\XML\DcmtosHDRcf.xml")
        Dim frm3 As New FrmCreditoFiscal
        frm3.Reporte_A_VerCF = repCR

        frm3.CrystalReportViewer1.RefreshReport()
        frm3.ShowDialog(Me)

        My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRcf.xml")


    End Sub
    Private Sub FacturaCMC()
        Dim strSQL As String
        Dim Eleccion As Integer
        Dim frm As New frmOption
        Dim repCR As New FacturaCMC
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strToken As String = STR_VACIO
        Dim strUUID As String = STR_VACIO
        Dim intNumero As Integer
        Dim intAño As Integer
        Dim strRespuesta As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        Dim strSQL2 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        frm.Opciones = "Recovery Order |" & "Consignment note |" & "Policy"
        frm.Titulo = "Print reference"
        frm.Mensaje = "Select an Option"
        'frm.ShowDialog(Me)
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Select Case frm.Seleccion
                Case 0
                    Eleccion = 0
                Case 1
                    Eleccion = 1
                Case 2
                    Eleccion = 3
            End Select
        Else
            Exit Sub

        End If



        strSQL = " SELECT HDoc_Doc_Num Numero,HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total,DAY(HDoc_Doc_Fec) Dia, "
        strSQL &= "     MONTH(HDoc_Doc_Fec) Mes , YEAR(HDoc_Doc_Fec) Anio  , HDoc_Doc_Status STATUS, IFNULL (HDoc_RF1_Txt,'/') Texto , "
        strSQL &= "         CAST(GROUP_CONCAT(DISTINCT p.PDoc_Par_Num) AS CHAR) Documentos, "
        strSQL &= "             SUM(d.DDoc_RF1_Dbl) Flete, SUM(d.DDoc_RF2_Dbl) AgenteAduana, SUM(d.DDoc_RF3_Dbl) Gestiones, c.cat_clave  Moneda "
        strSQL &= "                 FROM Dcmtos_HDR "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Num = HDoc_Doc_Num  "
        strSQL &= "         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num "
        strSQL &= "     LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
        strSQL &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} AND p.PDoc_Par_Lin = 1  "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        If celdaUUID.Text = STR_VACIO Then
            If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                If MsgBox("Esta a punto de transmitir esta factura a SAT " & vbNewLine & "Esta seguro que desea continuar? El proceso sera irreversible ", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                    If VerificarDocumentoXML(strToken, strUUID) = INT_CERO Then
                        If ImpresionFel(intAño, intNumero, strRespuesta, strToken, strUUID, IP, strUsuario, strContrasena, strRuta) = True Then
                            strSQL2 = STR_VACIO
                            strSQL2 = "UPDATE Dcmtos_HDR h"
                            strSQL2 &= " SET h.HDoc_Doc_Fec = CURDATE()"
                            strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL2 &= ";UPDATE PDM.Dcmtos_HDR h"
                                strSQL2 &= " SET h.HDoc_Doc_Fec = CURDATE()"
                                strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"

                            End If
                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
                            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                            'Ejecuta la instrucción
                            MyCnn.CONECTAR = strConexion
                            COM2 = New MySqlCommand(strSQL2, CON)
                            COM2.ExecuteNonQuery()
                            cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 296, celdaAño.Text, celdaNumero.Text)
                        End If
                    Else
                        MsgBox("El documento ya ha sido transmitido")
                    End If
                Else
                    Exit Sub
                End If
            Else
                Exit Sub
            End If
        Else
            ArrayServer = strConexion.Split(";".ToCharArray)
            strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
            strCadena = ArrayServer(INT_CERO)
            ArrayValidacion = strCadena.Split(".".ToCharArray)
            strCadena = ArrayValidacion(INT_CERO)
            arrayIP = strCadena.Split("=".ToCharArray)
            If arrayIP(INT_UNO) = "192" Then
                If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                    ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                Else
                    Exit Sub
                End If
            Else

            End If
        End If
        '    If BuscarRegistrosFacturaCMC(strSQL) = True Then
        '   End If
        '   repCR.Load("C:\XML\DcmtosHDRCMC.xml")
        '  Dim frm3 As New FrmFacturaCMC
        ' frm3.Reporte_A_Ver_FacturaCMC = repCR
        'frm3.CrystalReportViewer1.RefreshReport()
        'frm3.ShowDialog(Me)
        ' My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRCMC.xml")
    End Sub
    Private Sub FacturaSimpleCMC()
        Dim strSQL As String = STR_VACIO
        Dim repCR As New FacturaSimpleCMC
        Dim IP As String = STR_VACIO
        Dim strUsuario As String = STR_VACIO
        Dim strContrasena As String = STR_VACIO
        Dim strRuta As String = STR_VACIO
        Dim strToken As String = STR_VACIO
        Dim strUUID As String = STR_VACIO
        Dim intNumero As Integer
        Dim intAño As Integer
        Dim strRespuesta As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Dim strCadena As String = STR_VACIO
        Dim ArrayValidacion() As String
        Dim arrayIP() As String
        Dim strSQL2 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        strSQL = " SELECT HDoc_Doc_Num Numero,HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total, "
        strSQL &= "     Day(HDoc_Doc_Fec) Dia , MONTH(HDoc_Doc_Fec) Mes , YEAR(HDoc_Doc_Fec) Anio,  HDoc_Doc_Status STATUS, IFNULL(d.DDoc_Prd_Des, 'N/A') descripcion, "
        strSQL &= "         c.cat_clave  , IFNULL(d.DDoc_RF1_Dbl,0) subTotal , IFNULL(p.PDoc_Par_Num,' . ') Documentos, IFNULL (HDoc_RF1_Txt,'/') Texto ,if(cli.cli_exterior='Local',0,1) cli_exterior
                    , IFNULL(d.DDoc_RF4_Dbl,0) cuentaAjenaValor, IFNULL(d.DDoc_RF4_Txt,'') cuentaAjena, ifnull(d.DDoc_RF4_Cod,'') relatedDocument, ifnull(DDoc_RF4_Fec,'') documentDate, ifnull(DDoc_PRD_Ref,'') complemento"
        strSQL &= "             FROM Dcmtos_HDR "
        strSQL &= "                 LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = HDoc_Sis_Emp AND d.DDoc_Doc_Cat = HDoc_Doc_Cat AND d.DDoc_Doc_Ano = HDoc_Doc_Ano AND d.DDoc_Doc_Num = HDoc_Doc_Num "
        strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Ano = HDoc_Doc_Ano AND p.PDoc_Chi_Num = HDoc_Doc_Num "
        strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp AND cli.cli_codigo = HDoc_Emp_Cod "
        strSQL &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} "
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        If celdaUUID.Text = STR_VACIO Then
            If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                If MsgBox("Esta a punto de transmitir esta factura a SAT " & vbNewLine & "Esta seguro que desea continuar? El proceso sera irreversible ", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                    If VerificarDocumentoXML(strToken, strUUID) = INT_CERO Then
                        If ImpresionSimpleFel(intAño, intNumero, strRespuesta, strToken, strUUID, IP, strUsuario, strContrasena, strRuta) = True Then
                            strSQL2 = STR_VACIO
                            strSQL2 = "UPDATE Dcmtos_HDR h"
                            strSQL2 &= " SET h.HDoc_Doc_Fec = CURDATE()"
                            strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                            If Sesion.IdEmpresa = 18 Then
                                strSQL2 &= ";UPDATE PDM.Dcmtos_HDR h"
                                strSQL2 &= " SET h.HDoc_Doc_Fec = CURDATE()"
                                strSQL2 &= " WHERE h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 296 and h.HDoc_Doc_Ano = {anio} and h.HDoc_Doc_Num = {numero}"
                            End If
                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
                            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                            'Ejecuta la instrucción
                            MyCnn.CONECTAR = strConexion
                            COM2 = New MySqlCommand(strSQL2, CON)
                            COM2.ExecuteNonQuery()
                            cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acPrint, celdaIdCliente.Text, 296, celdaAño.Text, celdaNumero.Text)
                        End If

                    Else
                        MsgBox("El documento ya ha sido transmitido")
                    End If
                Else
                    Exit Sub
                End If
            Else
                Exit Sub
            End If
        Else
            ArrayServer = strConexion.Split(";".ToCharArray)
            strConexion2 = "server={server};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("server=".ToCharArray)
            strCadena = ArrayServer(INT_CERO)
            ArrayValidacion = strCadena.Split(".".ToCharArray)
            strCadena = ArrayValidacion(INT_CERO)
            arrayIP = strCadena.Split("=".ToCharArray)
            If arrayIP(INT_UNO) = "192" Then
                If VerificarAcceso(IP, strUsuario, strContrasena, strRuta) = True Then
                    ImprimirPDFGenerado(IP, strUsuario, strContrasena, strRuta)
                Else
                    Exit Sub
                End If
            Else

            End If
        End If
        'If BuscarRegistrosSimpleCMC(strSQL) = True Then
        'End If
        ' repCR.Load("C:\XML\DcmtosHDRCMC.xml")
        Dim frm3 As New FrmFacturaCMC
        'frm3.CrystalReportViewer1.ReportSource = repCR
        'frm3.Reporte_A_Ver_FacturaCMC = repCR
        'frm3.CrystalReportViewer1.RefreshReport()
        'frm3.ShowDialog(Me)
        'My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRSIMPLECMC.xml")
    End Sub
    'Procedimientos Fel
    Private Function PermisoAnular() As Boolean

        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim logResultado As Boolean = False
        strSQL = "SELECT p.pms_codigo Permiso"
        strSQL &= "     FROM Permisos p "
        strSQL &= "         WHERE p.pms_usuario = '{usuario}' AND p.pms_modulo = 147 AND p.pms_codigo  ='ANULAR'"
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)
        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader
        If REA.HasRows Then
            Do While REA.Read
                If REA.GetString("Permiso") = "ANULAR" Then
                    logResultado = True
                End If
            Loop
        End If
        Return logResultado
    End Function
    Public Sub CargarDatosFel()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strCadena As String = STR_VACIO
        Dim arrayCadena() As String
        Try
            strSQL = "SELECT f.FechaEmisionDocumento,f.FechaHoraCertificacion,f.Serie, f.NumeroAutorizacion ,f.UUID "
            strSQL &= "  FROM Fel f  "
            strSQL &= "     WHERE f.Empresa = {empresa} AND f.catalogo = {catalogo} AND f.Anio = {anio} AND f.Numero = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{catalogo}", 296)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    celdaFechaEmisionDocumento.Text = REA.GetString("FechaEmisionDocumento")
                    celdaFechaHoraCertificacion.Text = REA.GetString("FechaHoraCertificacion")
                    celdaSerieFel.Text = REA.GetString("Serie")
                    celdaUUID.Text = REA.GetString("UUID")
                    strCadena = REA.GetString("Serie")
                    arrayCadena = strCadena.Split("-".ToCharArray)
                    etiquetaSerie.Text = arrayCadena(INT_CERO)
                    etiquetaAutorizacion.Text = REA.GetString("NumeroAutorizacion")
                    etiquetaSerie.Visible = True
                    etiquetaAutorizacion.Visible = True
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActivarFel()
        celdaObservaciones.Enabled = True
        celdaAño.Enabled = True
        celdaNumero.Enabled = True
        celdaDireccion.Enabled = True
        celdaTelefono.Enabled = True
        celdaNIT.Enabled = True
        celdaMoneda.Enabled = True
        botonMoneda.Enabled = True
        celdaTasa.Enabled = True
        celdaCliente.Enabled = True
        celdaRegistro.Enabled = True
        celdaGiro.Enabled = True
        dgFactrura.Enabled = True
        dgDetalle.Enabled = True
        celdaSubTotal.Enabled = True
        celdaTotal.Enabled = True
        Button1.Enabled = True
        Button2.Enabled = True
        botonAgregar.Enabled = True
        botonQuitar.Enabled = True
        botonRefacturar.Enabled = True
        botonCliente.Enabled = True
        Encabezado1.botonGuardar.Enabled = True
        Encabezado1.botonBorrar.Enabled = True
        botonPrevio.Enabled = True
        botonISR.Enabled = True
        botonInprimir.Enabled = True
        celdaTotalComplemento.Enabled = False
        If intTipo = 0 Then
            panelComplementoTotales.Enabled = True
            dgComplemento.Enabled = True
        Else
            panelComplementoTotales.Enabled = False
            dgComplemento.Enabled = False
        End If
    End Sub
    Public Sub BloquearFel()
        celdaObservaciones.Enabled = False
        celdaAño.Enabled = False
        celdaNumero.Enabled = False
        celdaDireccion.Enabled = False
        celdaTelefono.Enabled = False
        celdaNIT.Enabled = False
        celdaMoneda.Enabled = False
        botonMoneda.Enabled = False
        celdaTasa.Enabled = False
        celdaCliente.Enabled = False
        celdaRegistro.Enabled = False
        celdaGiro.Enabled = False
        dgFactrura.Enabled = False
        dgDetalle.Enabled = False
        dgComplemento.Enabled = False
        celdaSubTotal.Enabled = False
        celdaTotal.Enabled = False
        Button1.Enabled = False
        Button2.Enabled = False
        botonAgregar.Enabled = False
        botonQuitar.Enabled = False
        botonRefacturar.Enabled = False
        botonCliente.Enabled = False
        Encabezado1.botonGuardar.Enabled = False
        Encabezado1.botonBorrar.Enabled = False
        botonPrevio.Enabled = False
        botonISR.Enabled = False
        celdaTotalComplemento.Visible = True
        etiquetaComplemento.Visible = True
        celdaTotalComplemento.Enabled = False
        panelComplementoTotales.Enabled = False
    End Sub
    Private Function VerificarDocumentoXML(ByRef strToken As String, ByRef strUUID As String) As Integer
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strVerifica As String = System.Windows.Forms.Application.StartupPath & "\Verifica.xml"
        Dim strSolicitarToken As String = STR_VACIO
        Dim logResultado As Integer
        Dim strResultado As String = STR_VACIO
        Dim strXMLVerificaDocumento As String = STR_VACIO
        Dim t As New Fel
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim fs As FileStream
        If cFunciones.ExisteArchivo(strpath) Then
            'Solicita Token en el Web Service 
            strSolicitarToken = t.SolicitarToken1(strpath)
            If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                ' Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' cierra el archivo 
                sw.Close()
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
            Else
                'Crea Archivo TokenD.xml
                fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                fs.Close()
                'Abre Archivo TokenD.xml
                sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                ' Copia el Token devuelvo del Web Service 
                sw.Write(strSolicitarToken)
                ' Carga el Archivo TokenD.xml
                xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                'Iniciamos el ciclo de lectura
                For Each nodo In nodos_lista
                    ' Asigna el Token Devuelto por Web Service 
                    strToken = nodo.ChildNodes.Item(1).InnerText
                Next
                sw.Close()
            End If
        End If
        If celdaUUID.Text <> STR_VACIO Then
            strUUID = celdaUUID.Text
        Else
            strUUID = GenerarUUID()
            celdaUUID.Text = strUUID
        End If
        'strUUID = "4DFFD5BC-AC7E-4779-8D4C-8C3903322993"
        strXMLVerificaDocumento &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
        strXMLVerificaDocumento &= "<VerificaDocumentoRequest id='" & strUUID & "'/>" & vbCrLf

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Verifica.xml")
        sw.Write(strXMLVerificaDocumento)
        sw.Close()

        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        fs.Close()
        sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        sw.Write(t.VerificaDocumento(strVerifica, strToken))
        sw.Close()
        xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\Validacion.xml")
        nodos_lista = xml_Documento.SelectNodes("/VerificaDocumentoResponse")
        ''Iniciamos el ciclo de lectura
        For Each nodo In nodos_lista
            '    ' Asigna el Codigo 64 Bits
            strResultado = nodo.ChildNodes.Item(0).InnerText
            If strResultado = "0" Then
                logResultado = INT_CERO
                GuardarFel(STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, STR_VACIO, strUUID)
            Else
                logResultado = INT_UNO
            End If
        Next


        Return logResultado
    End Function
    Public Sub GuardarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 296
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PINSERT() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ActualizarFel(ByVal strFechaEmisionDocumento As String, ByVal strFechaHoraCertificacion As String, ByVal strSerie As String, ByVal strNumeroAutorizacion As String, ByVal strIncoterm As String, ByVal strUUID As String)
        Dim cFel As New Tablas.TFEL
        Try
            cFel.CONEXION = strConexion
            cFel.EMPRESA = Sesion.IdEmpresa
            cFel.CATALOGO = 296
            cFel.ANIO = celdaAño.Text
            cFel.NUMERO = celdaNumero.Text
            cFel.FECHAEMISIONDOCUMENTO = strFechaEmisionDocumento
            cFel.FECHAHORACERTIFICACION = strFechaHoraCertificacion
            cFel.SERIE = strSerie
            cFel.NUMEROAUTORIZACION = strNumeroAutorizacion
            cFel.INCOTERM = strIncoterm
            cFel.UUID = strUUID
            If cFel.PUPDATE() = False Then
                MsgBox(cFel.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GenerarUUID() As String
        Dim UUID As String
        UUID = System.Guid.NewGuid.ToString.ToUpper
        ' MsgBox(UUID)
        Return UUID
    End Function
    Private Function VerificarAcceso(ByRef IP As String, ByRef strUsuario As String, ByRef strContrasena As String, ByRef strRuta As String) As Boolean
        Dim COM As MySqlCommand
        Dim logVerificar As Boolean
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Try
            strSQL = " SELECT c.cat_desc IP , c.cat_ext usuario, c.cat_sist Ruta , c.cat_dato Contrasena  "
            strSQL &= "     FROM Catalogos c "
            strSQL &= "         WHERE c.cat_clase = 'felFact' AND c.cat_clave = 'Facturacion' "
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    IP = REA.GetString("IP")
                    strUsuario = REA.GetString("usuario")
                    strContrasena = REA.GetString("Contrasena")
                    strRuta = REA.GetString("Ruta")
                Loop
            End If


            If My.Computer.Network.Ping(IP) Then
                MessageBox.Show("Conexion correcta", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                logVerificar = True
            Else
                MessageBox.Show("Conexion erronea", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                logVerificar = False
            End If
        Catch ex As Net.NetworkInformation.PingException
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        Catch ex As Exception
            MessageBox.Show("Ocurrió el siguiente error:" & vbCrLf & ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            logVerificar = False
        End Try
        Return logVerificar
    End Function
    Public Function ImpresionFel(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal strRespuesta As String, ByVal strToken As String, ByVal strUUID As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logEncabezado As Boolean = False
        Dim Horario As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim fs As FileStream
        Dim t As New Fel
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml"
        Dim strpathCUI As String = System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml"
        'Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFCMC" & celdaNumero.Text & ".xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFLS" & celdaNumero.Text & ".xml"
        ' Dim strToken As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLFel As String = STR_VACIO
        Dim strXMLDTL As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim strXML As String = STR_VACIO
        Dim strXMLComplemento As String = STR_VACIO
        Dim nodo As XmlNode
        Dim strNumero As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim dblGranTotal As Double = INT_CERO
        Dim dblIvaImpuesto As Double = INT_CERO
        Dim dblIva As Double = INT_CERO
        Dim dblGranTotalIva As Double = INT_CERO
        Dim localZone As TimeZone = TimeZone.CurrentTimeZone
        Dim strNombreC As String = STR_VACIO
        Dim strDireccionC As String = STR_VACIO
        Dim strCodigoC As String = STR_VACIO
        Dim strNombreCliente As String = STR_VACIO
        Dim strNitCliente As String = STR_VACIO
        Dim strDireccionCliente As String = STR_VACIO
        Dim strCodigoCliente As String = STR_VACIO
        Dim strNombreExportador As String = STR_VACIO
        Dim strObservacion As String = STR_VACIO
        Dim strFechaHoraCertificacion As String = STR_VACIO
        Dim strNitCertificador As String = STR_VACIO
        Dim strSerieDocumento As String = STR_VACIO
        Dim strNumeroAutorizacion As String = STR_VACIO
        Dim strCadenaEncontrada As String = STR_VACIO
        Dim arrayCadena() As String
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strPrueba As String = STR_VACIO
        Dim vlcResultado As String = STR_VACIO
        Dim logResultado As Boolean = True
        Dim strError As String = STR_VACIO
        ' Especifica el criterio
        Dim vlcCriterio As String = "dte:NumeroAutorizacion"




        'xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")
        'nodos_lista = xml_Documento.SelectNodes("/nombre")
        ''Iniciamos el ciclo de lectura
        'For Each nodo In nodos_lista
        '    ' Asigna el Token Devuelto por Web Service 
        '    strXMLRegistra = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><RetornaDatosClienteRequestCUI><CUI>" & celdaNIT.Text & "</CUI></RetornaDatosClienteRequestCUI>"
        'Next
        'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")
        'fs.Close()
        'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")
        'sw.Write(strXMLRegistra)
        'sw.Close()
        'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")
        'fs.Close()
        'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\verificaCUI.xml")
        'sw.Write(t.ValidaCUI(strpathF, strToken))
        'If logResultado = False Then
        '    MsgBox("Fallo en verifica CUI")
        '    strError &= " Fallo en verifica CUI"
        '    '   EnvioProyecto(strError)
        '    Exit Function
        'End If
        'sw.Close()




        Try
            botonInprimir.Enabled = False
            Horario = Now().ToString("yyyy-MM-ddTHH:mm:ss")
            strSQL = " SELECT 1 Linea ,c.cat_num Moneda, cp.cat_desc Pais, cp.cat_clave PaisReceptor,cli.cli_direccion DireccionCliente,emp.emp_direccion DireccionEmisor,emp.emp_razon NombreComercial,HDoc_Doc_Num Numero,HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total,DAY(HDoc_Doc_Fec) Dia, "
            strSQL &= "     MONTH(HDoc_Doc_Fec) Mes , YEAR(HDoc_Doc_Fec) Anio  , HDoc_Doc_Status STATUS, CAST(IFNULL(HDoc_RF1_Txt,'/') AS CHAR) Texto ,CAST(GROUP_CONCAT(DISTINCT p.PDoc_Par_Num) AS CHAR) Documentos, SUM(ROUND((d.DDoc_RF1_Dbl/ 1.12),3)) Monto, c.cat_clave Moneda0, 'SERVICIO DE FLETE' Descripcion,SUM(d.DDoc_RF1_Dbl) Total1 "
            strSQL &= "              ,if(cli.cli_exterior='Local',0,1) cli_exterior, IFNULL(d.DDoc_Prd_Ref,'') refcomp   FROM Dcmtos_HDR "
            strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Num = HDoc_Doc_Num  "
            strSQL &= "         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num "
            strSQL &= "     LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
            strSQL &= "   LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp AND cli.cli_codigo = HDoc_Emp_Cod"
            strSQL &= "  LEFT JOIN Empresas emp ON emp.emp_no = HDoc_Sis_Emp "
            strSQL &= " LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais "
            strSQL &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} AND p.PDoc_Par_Lin = 1 AND d.DDoc_Prd_Ref='' UNION  "
            ' 2 Linea 
            strSQL &= "  SELECT 2 Linea,c.cat_num Moneda,cp.cat_desc Pais, cp.cat_clave PaisReceptor,cli.cli_direccion DireccionCliente,emp.emp_direccion DireccionEmisor,emp.emp_razon NombreComercial,HDoc_Doc_Num Numero, "
            strSQL &= "         HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total, DAY(HDoc_Doc_Fec) Dia, MONTH(HDoc_Doc_Fec) Mes, YEAR(HDoc_Doc_Fec) Anio, HDoc_Doc_Status STATUS, CAST(IFNULL(HDoc_RF1_Txt,'/') AS CHAR) Texto, "
            strSQL &= "             CAST(GROUP_CONCAT(DISTINCT p.PDoc_Par_Num) AS CHAR) Documentos, SUM(ROUND((d.DDoc_RF2_Dbl /1.12),3)) AgenteAduana, c.cat_clave Moneda0, 'AGENTE DE ADUANAS' Descripcion,SUM(d.DDoc_RF2_Dbl) Total1 "
            strSQL &= "              ,if(cli.cli_exterior='Local',0,1) cli_exterior, IFNULL(d.DDoc_Prd_Ref,'') refcomp   FROM Dcmtos_HDR "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Num = HDoc_Doc_Num "
            strSQL &= "                         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num "
            strSQL &= "                             LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
            strSQL &= "                                 LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp AND cli.cli_codigo = HDoc_Emp_Cod "
            strSQL &= "                                     LEFT JOIN Empresas emp ON emp.emp_no = HDoc_Sis_Emp "
            strSQL &= "                                         LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais "
            strSQL &= "                                             WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} AND p.PDoc_Par_Lin = 1 AND d.DDoc_Prd_Ref='' UNION"
            ' 3 Linea 
            strSQL &= "  SELECT 3 Linea ,c.cat_num Moneda,cp.cat_desc Pais, cp.cat_clave PaisReceptor,cli.cli_direccion DireccionCliente,emp.emp_direccion DireccionEmisor,emp.emp_razon NombreComercial,HDoc_Doc_Num Numero, "
            strSQL &= "     HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total, DAY(HDoc_Doc_Fec) Dia, MONTH(HDoc_Doc_Fec) Mes, "
            strSQL &= "         YEAR(HDoc_Doc_Fec) Anio, HDoc_Doc_Status STATUS, CAST(IFNULL(HDoc_RF1_Txt,'/') AS CHAR) Texto, CAST(GROUP_CONCAT(DISTINCT p.PDoc_Par_Num) AS CHAR) Documentos, SUM(ROUND((d.DDoc_RF3_Dbl/1.12),3)) Monto, c.cat_clave Moneda0, 'GESTIONES ADUANALES' Descripcion,SUM(d.DDoc_RF3_Dbl) Total1 "
            strSQL &= "           ,if(cli.cli_exterior='Local',0,1) cli_exterior, IFNULL(d.DDoc_Prd_Ref,'') refcomp  FROM Dcmtos_HDR "
            strSQL &= "                 LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Num = HDoc_Doc_Num "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num "
            strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
            strSQL &= "                             LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp AND cli.cli_codigo = HDoc_Emp_Cod "
            strSQL &= "                                 LEFT JOIN Empresas emp ON emp.emp_no = HDoc_Sis_Emp "
            strSQL &= "                                     LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais "
            strSQL &= "                                         WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} AND p.PDoc_Par_Lin = 1 AND d.DDoc_Prd_Ref='' "

            strSQL &= " UNION 
                        SELECT DDoc_Doc_Lin Linea,c.cat_num Moneda,cp.cat_desc Pais, cp.cat_clave PaisReceptor,cli.cli_direccion DireccionCliente,
                        emp.emp_direccion DireccionEmisor,emp.emp_razon NombreComercial,HDoc_Doc_Num Numero, HDoc_Emp_NIT NIT, 
                        IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total, 
                        DAY(d.DDoc_RF4_Fec) Dia, MONTH(d.DDoc_RF4_Fec) Mes, YEAR(d.DDoc_RF4_Fec) Anio, HDoc_Doc_Status STATUS, 
                        CAST(IFNULL(DDoc_RF4_Cod,'') AS CHAR) Texto, CAST(DDoc_RF4_Txt AS CHAR) Documentos, 
                        d.DDoc_RF4_Dbl Monto, c.cat_clave Moneda0, 'GESTIONES ADUANALES' Descripcion, 
                        0 Total1, if(cli.cli_exterior='Local',0,1) cli_exterior, IFNULL(d.DDoc_Prd_Ref,'') refcomp
                        FROM Dcmtos_HDR h
                        LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                        LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'
                        LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp AND cli.cli_codigo = h.HDoc_Emp_Cod
                        LEFT JOIN Empresas emp ON emp.emp_no = h.HDoc_Sis_Emp
                        LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais
                        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Pro_DCat = 296 AND h.HDoc_Pro_DAno = {anio} AND h.HDoc_Pro_DNum = {numero} AND d.DDoc_Prd_Ref='comp'
 "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetInt32("Moneda") = 177 Then
                        strMoneda = "GTQ"
                    ElseIf REA.GetInt32("Moneda") = 178 Then
                        strMoneda = "USD"
                    End If
                    If File.Exists(System.Windows.Forms.Application.StartupPath & "\contenido.xml") Then
                        If logEncabezado = False Then
                            strNombreCliente = REA.GetString("Nombre")
                            strNombreCliente = Replace(strNombreCliente, "&", "&#38;")
                            strNombreCliente = cfun.convertirXML(Replace(strNombreCliente, "-", "&#45;"))
                            strObservacion = cfun.convertirXML(REA.GetString("Texto"))
                            strNitCliente = REA.GetString("NIT")
                            strNitCliente = Replace(strNitCliente, "-", "")
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A3FD2363-05C2-AB7B-373D-56C08CF892B6'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            ' Enabezado de la factura 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= " <dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "'   FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'cmc
                            'strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@cmcguatemala.com' NITEmisor='76882551' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@logisticservicesgt.com' NITEmisor='120375265' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("DireccionEmisor") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Guatemala</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            'strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com'  IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf

                            If REA.GetInt32("cli_exterior") = 0 Then   '' 0 es local
                                If REA.GetString("NIT") = "CF" Then
                                    'factura consumidor final
                                    'strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                ElseIf strNitCliente.Length = 13 Then
                                    'factura CUI Valido
                                    'strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                Else
                                    'factura nit valido
                                    'strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                End If
                                ' strXML &= "<dte:Receptor CorreoReceptor='contabilidad@hilosyalgodon.com' IDReceptor ='CF' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            Else
                                'factura exterior
                                'strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                            End If



                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & REA.GetString("Dic") & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>  </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "</dte:Frases>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            logEncabezado = True
                            If REA.GetString("refcomp") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total1") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("Total1")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf

                                dblIva = (REA.GetDouble("Total1") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)
                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                        Else
                            If REA.GetString("refcomp") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & REA.GetString("Descripcion") & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total1") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("Total1")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf
                                dblIva = (REA.GetDouble("Total1") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)

                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                        End If
                    Else
                        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
                        fs.Close()
                        If logEncabezado = False Then
                            strNombreCliente = REA.GetString("Nombre")
                            strNombreCliente = Replace(strNombreCliente, "&", "&#38;")
                            strNombreCliente = Replace(strNombreCliente, "-", "&#45;")
                            strObservacion = cfun.convertirXML(REA.GetString("Texto"))
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A3FD2363-05C2-AB7B-373D-56C08CF892B6'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            ' Enabezado de la factura 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= " <dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "'   FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'cmc
                            'strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@cmcguatemala.com' NITEmisor='76882551' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@logisticservicesgt.com' NITEmisor='120375265' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionEmisor")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Guatemala</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf

                            ''strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com'  IDReceptor ='" & REA.GetString("NIT") & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf

                            If REA.GetInt32("cli_exterior") = 0 Then   '' 0 es local
                                If REA.GetString("NIT") = "CF" Then
                                    'factura consumidor final
                                    'strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                ElseIf strNitCliente.Length = 13 Then
                                    'factura CUI Valido
                                    'strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                Else
                                    'factura nit valido
                                    'strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                End If
                            Else
                                'factura exterior
                                'strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                            End If




                            strXML &= " <dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("Dic")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento></dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "</dte:Frases>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            logEncabezado = True
                            If REA.GetString("refcomp") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total1") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("Total1")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf

                                dblIva = (REA.GetDouble("Total1") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)
                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If

                            logEncabezado = True
                        Else
                            If REA.GetString("refcomp") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("Descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("Total1") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("Total1")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf
                                dblIva = (REA.GetDouble("Total1") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)

                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("Total1").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                        End If
                    End If
                    If dgComplemento.Rows.Count > 0 And REA.GetString("refcomp") = "comp" Then
                        strXMLComplemento &= " <cca:ItemCuentaAjena>" & vbCrLf
                        strXMLComplemento &= " <cca:NITtercero>" & strNitCliente & "</cca:NITtercero>" & vbCrLf
                        strXMLComplemento &= " <cca:NumeroDocumento>" & REA.GetString("Texto").ToString & "</cca:NumeroDocumento>" & vbCrLf
                        strXMLComplemento &= " <cca:FechaDocumento>" & CDate(REA.GetInt16("Anio").ToString & "-" & REA.GetInt16("Mes").ToString & "-" & REA.GetInt16("Dia").ToString).ToString(FORMATO_MYSQL) & "</cca:FechaDocumento>" & vbCrLf
                        strXMLComplemento &= " <cca:Descripcion>" & cfun.convertirXML(REA.GetString("Documentos").ToString) & "</cca:Descripcion>" & vbCrLf
                        strXMLComplemento &= " <cca:BaseImponible>0.00</cca:BaseImponible>" & vbCrLf
                        strXMLComplemento &= " <cca:MontoCobroDAI>0.00</cca:MontoCobroDAI>" & vbCrLf
                        strXMLComplemento &= " <cca:MontoCobroIVA>0.00</cca:MontoCobroIVA>" & vbCrLf
                        strXMLComplemento &= " <cca:MontoCobroOtros>" & REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "</cca:MontoCobroOtros>" & vbCrLf
                        strXMLComplemento &= " <cca:MontoCobroTotal>" & REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "</cca:MontoCobroTotal>" & vbCrLf
                        strXMLComplemento &= " </cca:ItemCuentaAjena>" & vbCrLf
                    End If
                Loop
            End If
            strXML &= "</dte:Items>" & vbCrLf
            'Totales 
            strXML &= "<dte:Totales>" & vbCrLf
            strXML &= "<dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:TotalImpuesto NombreCorto='IVA' TotalMontoImpuesto='" & dblGranTotalIva & "'/>" & vbCrLf
            strXML &= "</dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:GranTotal>" & dblGranTotal & "</dte:GranTotal>" & vbCrLf
            strXML &= "</dte:Totales>" & vbCrLf
            If dgComplemento.Rows.Count > 0 Then
                strXML &= "<dte:Complementos>" & vbCrLf
                strXML &= "<dte:Complemento IDComplemento='1' NombreComplemento='CXCA' URIComplemento='http://www.sat.gob.gt/face2/CobroXCuentaAjena/0.1.0'>" & vbCrLf
                strXML &= "<cca:CobroXCuentaAjena xmlns:cca='http://www.sat.gob.gt/face2/CobroXCuentaAjena/0.1.0' Version='1'>" & vbCrLf
                strXML &= strXMLComplemento & vbCrLf
                strXML &= "</cca:CobroXCuentaAjena>" & vbCrLf
                strXML &= "</dte:Complemento>" & vbCrLf
                strXML &= "</dte:Complementos>" & vbCrLf
            End If
            strXML &= "</dte:DatosEmision> " & vbCrLf
            strXML &= "</dte:DTE> " & vbCrLf
            strXML &= "<dte:Adenda>" & vbCrLf
            strXML &= "<dte:AdendaDetail id='AdendaSummary'> " & vbCrLf
            strXML &= "<dte:AdendaSummary>" & vbCrLf
            strXML &= "<dte:Valor1>" & strObservacion & "</dte:Valor1>" & vbCrLf
            strXML &= "<dte:Valor2>" & celdaNumero.Text & "</dte:Valor2>" & vbCrLf
            strXML &= "<dte:Valor4>Q." & (CDbl(celdaTotal.Text) + CDbl(celdaTotalComplemento.Text)).ToString(FORMATO_MONEDA) & "</dte:Valor4>" & vbCrLf
            If dgComplemento.Rows.Count > 0 Then
                strXML &= "<dte:Valor5>Q." & CDbl(celdaTotalComplemento.Text).ToString(FORMATO_MONEDA) & "</dte:Valor5>" & vbCrLf
            End If
            strXML &= "</dte:AdendaSummary>" & vbCrLf
            strXML &= "</dte:AdendaDetail>" & vbCrLf
            strXML &= "</dte:Adenda>" & vbCrLf
            strXML &= "</dte:SAT> " & vbCrLf
            strXML &= "</dte:GTDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXML &= "]]>" & vbCrLf
            strXML &= "</xml_dte>" & vbCrLf
            strXML &= "</FirmaDocumentoRequest>" & vbCrLf
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
            sw.Write(strXML)
            sw.Close()

            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                strError &= " Fallo en la Firma Electronica "
                '   EnvioProyecto(strError)
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            sw.Write(strXMLRegistra)
            sw.Close()

            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FactCMCFel" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FactLSFel" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FactCMCFel" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FactLSFel" & celdaNumero.Text & ".xml")
            'Registra la factura ya firmado
            strXMLFinal = t.RegistrarDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el registra documento de Fel ")
                strError &= "Fallo en el registra documento de Fel"
                '  EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactCMCFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactCMCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactCMCFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactCMCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactLSFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactLSFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)

            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactLSFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactLSFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try




            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FactLSfel" & celdaNumero.Text & ".xml")

            nodos_lista = xml_Documento.SelectNodes("/RegistraDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strXMLFel = nodo.ChildNodes.Item(0).InnerText
            Next
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml")
            sw.Write(strXMLFel)
            sw.Close()

            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FelCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FelCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)

            '' '' '' Actual
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FelLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FelLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)

            '' se modifica el 29/01/2025 para hacer el 
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FelLS" & celdaNumero.Text & ".xml", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FelLS" & celdaNumero.Text & ".xml", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try

            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml")

            nodos_lista = xml_Documento.GetElementsByTagName("dte:Certificacion")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strNitCertificador = nodo.ChildNodes.Item(0).InnerText  ' Nit MegaPrint
                '  strFechaHoraCertificacion = nodo.ChildNodes.Item(1).InnerText ' Nombre MegaPrint
                strSerieDocumento = nodo.ChildNodes.Item(2).InnerText ' Serie 
                strFechaHoraCertificacion = nodo.ChildNodes.Item(3).InnerText ' FechaCertificacion 
            Next
            ' Nombre del archivo a utilizar
            'Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".xml"
            Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".xml"
            ' Si el archivo existe
            Dim vloFile As New StreamReader(vlcFileName)
            ' Ciclo de iteración entre líneas
            While True
                ' Cargar la línea
                Dim vlcLinea = vloFile.ReadLine()
                ' Si la línea es nula, sale del ciclo
                If vlcLinea Is Nothing Then Exit While
                ' Si la línea contiene el criterio
                If vlcLinea.Contains(vlcCriterio) Then
                    ' Obtener la línea como resultado,
                    ' Concatenando un retorno de carro si ya hay ocurrencias
                    vlcResultado += IIf(vlcResultado <> "", vbCrLf, "") & vlcLinea
                    ' Salir del ciclo
                    Exit While
                    ' Lo omites si quieres todas las ocurrencias
                End If
            End While
            'Realiza busqueda de la cadena para obtener el numero de Autorizacion
            strCadenaEncontrada = vlcResultado.Substring(vlcResultado.LastIndexOf("Numero=") + 1)
            'En un array parte la cadena despues que encuentre un igual 
            arrayCadena = strCadenaEncontrada.Split("=".ToCharArray)
            'carga el numero de autorizacion de cada documento
            strNumeroAutorizacion = arrayCadena(INT_UNO)
            'sustituye serie por cadena vacio para limpiar la cadena y solo obtenga el numero
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, "Serie", STR_VACIO)
            'sustituye "" por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, """", STR_VACIO)
            'sustituye espacios por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, " ", STR_VACIO)

            ActualizarFel(Horario & "-06:00", strFechaHoraCertificacion, strSerieDocumento, strNumeroAutorizacion, STR_VACIO, strUUID)

            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & strSerieDocumento & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFCMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFLS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFCMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFLS" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFCMCFinal" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFLSFinal" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFCMCFinal" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFLSFinal" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            'xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFCMCFinal" & celdaNumero.Text & ".xml")
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFLSFinal" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            'Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".pdf")
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelCMC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelCMC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)

            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)

            '' se modifica el 29/01/2025 para hacer el 
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try



            botonInprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                'System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelCMC" & celdaNumero.Text & ".pdf")
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelLS" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Function ImpresionSimpleFel(ByVal intAño As Integer, ByVal intNumero As Integer, ByVal strRespuesta As String, ByVal strToken As String, ByVal strUUID As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim strSQL As String = STR_VACIO
        Dim logEncabezado As Boolean = False
        Dim Horario As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim COM2 As MySqlCommand
        Dim REA2 As MySqlDataReader
        Dim fs As FileStream
        Dim t As New Fel
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenido.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml"
        'Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFSimpleCMC" & celdaNumero.Text & ".xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFSimpleLS" & celdaNumero.Text & ".xml"
        '  Dim strToken As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLFel As String = STR_VACIO
        Dim strXMLDTL As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strXMLComp As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim strXML As String = STR_VACIO
        Dim nodo As XmlNode
        Dim strNumero As String = STR_VACIO
        Dim strMoneda As String = STR_VACIO
        Dim dblGranTotal As Double = INT_CERO
        Dim dblIvaImpuesto As Double = INT_CERO
        Dim dblIva As Double = INT_CERO
        Dim dblGranTotalIva As Double = INT_CERO
        Dim dblTotalComplemento As Double = INT_CERO
        Dim localZone As TimeZone = TimeZone.CurrentTimeZone
        Dim strNombreC As String = STR_VACIO
        Dim strDireccionC As String = STR_VACIO
        Dim strCodigoC As String = STR_VACIO
        Dim strNombreCliente As String = STR_VACIO
        Dim strNitCliente As String = STR_VACIO
        Dim strDireccionCliente As String = STR_VACIO
        Dim strCodigoCliente As String = STR_VACIO
        Dim strNombreExportador As String = STR_VACIO
        Dim strObservacion As String = STR_VACIO
        Dim strFechaHoraCertificacion As String = STR_VACIO
        Dim strNitCertificador As String = STR_VACIO
        Dim strSerieDocumento As String = STR_VACIO
        Dim strNumeroAutorizacion As String = STR_VACIO
        Dim strCadenaEncontrada As String = STR_VACIO
        Dim arrayCadena() As String
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strPrueba As String = STR_VACIO
        Dim vlcResultado As String = STR_VACIO
        Dim logResultado As Boolean = True
        Dim strError As String = STR_VACIO
        ' Especifica el criterio
        Dim vlcCriterio As String = "dte:NumeroAutorizacion"
        Try
            botonInprimir.Enabled = False
            Horario = Now().ToString("yyyy-MM-ddTHH:mm:ss")
            strSQL = " SELECT d.DDoc_Doc_Lin Linea,c.cat_num Moneda, cp.cat_desc Pais, cp.cat_clave PaisReceptor,cli.cli_direccion DireccionCliente,emp.emp_direccion DireccionEmisor,emp.emp_razon NombreComercial,HDoc_Doc_Num Numero, "
            strSQL &= "     HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total, DAY(HDoc_Doc_Fec) Dia, MONTH(HDoc_Doc_Fec) Mes, YEAR(HDoc_Doc_Fec) Anio, "
            strSQL &= "         HDoc_Doc_Status STATUS, IFNULL(d.DDoc_Prd_Des, 'N/A') descripcion, c.cat_clave, IFNULL(d.DDoc_RF1_Dbl,0) subTotal, 
                 IFNULL(p.PDoc_Par_Num,' . ')  Documentos, IFNULL (HDoc_RF1_Txt,'/') Texto,if(cli.cli_exterior='Local',0,1) cli_exterior 
                , IFNULL(d.DDoc_RF4_Dbl,0) cuentaAjenaValor, IFNULL(d.DDoc_RF4_Txt,'') cuentaAjena, ifnull(DDoc_RF4_Cod,'') relatedDocument, ifnull(DDoc_RF4_Fec,'') documentDate, ifnull(DDoc_PRD_Ref,'') complemento"
            strSQL &= "             FROM Dcmtos_HDR "
            strSQL &= "                 LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = HDoc_Sis_Emp AND d.DDoc_Doc_Cat = HDoc_Doc_Cat AND d.DDoc_Doc_Ano = HDoc_Doc_Ano AND d.DDoc_Doc_Num = HDoc_Doc_Num "
            strSQL &= "                     LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Ano = HDoc_Doc_Ano AND p.PDoc_Chi_Num = HDoc_Doc_Num "
            strSQL &= "                         LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
            strSQL &= "                             LEFT JOIN Clientes cli ON cli.cli_sisemp = HDoc_Sis_Emp AND cli.cli_codigo = HDoc_Emp_Cod "
            strSQL &= "                                 LEFT JOIN Empresas emp ON emp.emp_no = HDoc_Sis_Emp "
            strSQL &= "                                     LEFT JOIN Catalogos cp ON cp.cat_num = cli.cli_pais "
            strSQL &= "                                         WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    If REA.GetInt32("Moneda") = 177 Then
                        strMoneda = "GTQ"
                    ElseIf REA.GetInt32("Moneda") = 178 Then
                        strMoneda = "USD"
                    End If
                    If File.Exists(System.Windows.Forms.Application.StartupPath & "\contenido.xml") Then
                        If logEncabezado = False Then
                            strNombreCliente = REA.GetString("Nombre")
                            strNombreCliente = Replace(strNombreCliente, "&", "&#38;")
                            strNombreCliente = cfun.convertirXML(Replace(strNombreCliente, "-", "&#45;"))
                            strObservacion = cfun.convertirXML(REA.GetString("Texto"))
                            strNitCliente = REA.GetString("NIT")
                            strNitCliente = cfun.convertirXML(Replace(strNitCliente, "-", ""))
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A3FD2363-05C2-AB7B-373D-56C08CF892B6'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            ' Enabezado de la factura 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= " <dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'cmc
                            'strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@cmcguatemala.com' NITEmisor='76882551' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@logisticservicesgt.com' NITEmisor='120375265' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionEmisor")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Guatemala</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            '' strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com'  IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            If REA.GetInt32("cli_exterior") = 0 Then   '' 0 es local
                                If REA.GetString("NIT") = "CF" Then
                                    'factura consumidor final
                                    'strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                ElseIf strNitCliente.Length = 13 Then
                                    'factura CUI Valido
                                    'strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                Else
                                    'factura nit valido
                                    'strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                End If
                            Else
                                'factura exterior
                                'strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                            End If

                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("Dic")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento></dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "</dte:Frases>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            logEncabezado = True
                            If REA.GetString("complemento") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("subTotal") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("subTotal")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf

                                dblIva = (REA.GetDouble("subTotal") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)
                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                        Else
                            If REA.GetString("complemento") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("subTotal") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("subTotal")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf
                                dblIva = (REA.GetDouble("subTotal") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)

                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                        End If
                    Else
                        fs = File.Create(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
                        fs.Close()
                        If logEncabezado = False Then
                            strNombreCliente = cfun.convertirXML(REA.GetString("Nombre"))
                            strObservacion = cfun.convertirXML(REA.GetString("Texto"))
                            ' XML Firma Electronica 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
                            strXML &= "<FirmaDocumentoRequest id='A3FD2363-05C2-AB7B-373D-56C08CF892B6'>" & vbCrLf
                            strXML &= "<xml_dte>" & vbCrLf
                            strXML &= "<![CDATA[ " & vbCrLf
                            ' Enabezado de la factura 
                            strXML &= "<?xml version='1.0' encoding='UTF-8'?> <dte:GTDocumento xmlns:dte='http://www.sat.gob.gt/dte/fel/0.2.0' Version='0.1'>" & vbCrLf
                            strXML &= " <dte:SAT ClaseDocumento='dte'>" & vbCrLf
                            strXML &= "<dte:DTE ID='DatosCertificados'>" & vbCrLf
                            strXML &= "<dte:DatosEmision ID='DatosEmision'>" & vbCrLf
                            strXML &= "<dte:DatosGenerales CodigoMoneda='" & strMoneda & "' FechaHoraEmision='" & Horario & "-06:00" & "' Tipo='FACT'/>" & vbCrLf
                            'cmc
                            'strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@cmcguatemala.com' NITEmisor='76882551' NombreComercial='" & REA.GetString("NombreComercial") & "' NombreEmisor='" & REA.GetString("NombreComercial") & "'>" & vbCrLf
                            strXML &= "<dte:Emisor AfiliacionIVA='GEN' CodigoEstablecimiento='1' CorreoEmisor='contabilidad@logisticservicesgt.com' NITEmisor='120375265' NombreComercial='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "' NombreEmisor='" & cfun.convertirXML(REA.GetString("NombreComercial")) & "'>" & vbCrLf
                            strXML &= "<dte:DireccionEmisor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("DireccionEmisor")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio>Guatemala</dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento> Guatemala </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>GT</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionEmisor>" & vbCrLf
                            strXML &= "</dte:Emisor>" & vbCrLf
                            ''strXML &= "<dte:Receptor CorreoReceptor='contabilidad@cmcguatemala.com'  IDReceptor ='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "'>" & vbCrLf
                            If REA.GetInt32("cli_exterior") = 0 Then   '' 0 es local
                                If REA.GetString("NIT") = "CF" Then
                                    'factura consumidor final
                                    'strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor IDReceptor='CF' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                ElseIf strNitCliente.Length = 13 Then
                                    'factura CUI Valido
                                    'strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= "<dte:Receptor TipoEspecial='CUI' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                Else
                                    'factura nit valido
                                    'strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                    strXML &= " <dte:Receptor IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                                End If
                            Else
                                'factura exterior
                                'strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@cmcguatemala.com'>"
                                strXML &= "<dte:Receptor TipoEspecial='EXT' IDReceptor='" & strNitCliente & "' NombreReceptor='" & strNombreCliente & "' CorreoReceptor='contabilidad@logisticservicesgt.com'>"
                            End If


                            strXML &= "<dte:DireccionReceptor>" & vbCrLf
                            strXML &= "<dte:Direccion>" & cfun.convertirXML(REA.GetString("Dic")) & "</dte:Direccion>" & vbCrLf
                            strXML &= "<dte:CodigoPostal>0</dte:CodigoPostal>" & vbCrLf
                            strXML &= "<dte:Municipio></dte:Municipio>" & vbCrLf
                            strXML &= "<dte:Departamento>  </dte:Departamento>" & vbCrLf
                            strXML &= "<dte:Pais>" & REA.GetString("PaisReceptor") & "</dte:Pais>" & vbCrLf
                            strXML &= "</dte:DireccionReceptor>" & vbCrLf
                            strXML &= "</dte:Receptor>" & vbCrLf

                            strXML &= "<dte:Frases>" & vbCrLf
                            strXML &= "<dte:Frase CodigoEscenario='1' TipoFrase ='1'/>" & vbCrLf
                            strXML &= "</dte:Frases>" & vbCrLf
                            strXML &= "<dte:Items>" & vbCrLf
                            logEncabezado = True
                            If REA.GetString("complemento") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("subTotal") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("subTotal")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf

                                dblIva = (REA.GetDouble("subTotal") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)
                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                            logEncabezado = True
                        Else
                            If REA.GetString("complemento") = "" Then
                                ' Linea Factura 
                                strXML &= "<dte:Item BienOServicio='S' NumeroLinea='" & REA.GetInt32("Linea") & "'>" & vbCrLf
                                strXML &= "<dte:Cantidad>1</dte:Cantidad>" & vbCrLf
                                strXML &= "<dte:UnidadMedida>UNI</dte:UnidadMedida>" & vbCrLf
                                strXML &= "<dte:Descripcion>" & cfun.convertirXML(REA.GetString("descripcion")) & "</dte:Descripcion> " & vbCrLf
                                strXML &= "<dte:PrecioUnitario>" & REA.GetDouble("subTotal") & "</dte:PrecioUnitario>" & vbCrLf
                                strXML &= "<dte:Precio>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Precio>" & vbCrLf
                                dblGranTotal = (dblGranTotal + REA.GetDouble("subTotal")).ToString("###0.00")
                                strXML &= "<dte:Descuento>" & INT_CERO.ToString("###0.00") & "</dte:Descuento>" & vbCrLf
                                dblIva = (REA.GetDouble("subTotal") / 1.12)
                                dblIvaImpuesto = (dblIva * 0.12)

                                strXML &= "<dte:Impuestos>" & vbCrLf
                                strXML &= "<dte:Impuesto>" & vbCrLf
                                strXML &= "<dte:NombreCorto>IVA</dte:NombreCorto>" & vbCrLf
                                strXML &= "<dte:CodigoUnidadGravable>1</dte:CodigoUnidadGravable>" & vbCrLf
                                strXML &= "<dte:MontoGravable>" & dblIva.ToString("###0.00") & "</dte:MontoGravable>" & vbCrLf
                                strXML &= "<dte:MontoImpuesto>" & dblIvaImpuesto.ToString("###0.00") & "</dte:MontoImpuesto>" & vbCrLf
                                strXML &= "</dte:Impuesto>" & vbCrLf
                                strXML &= "</dte:Impuestos>" & vbCrLf
                                dblGranTotalIva = (dblGranTotalIva + dblIvaImpuesto).ToString("###0.00")
                                strXML &= "<dte:Total>" & REA.GetDouble("subTotal").ToString("###0.00") & "</dte:Total>" & vbCrLf
                                strXML &= "</dte:Item>" & vbCrLf
                            End If
                        End If
                    End If


                    If dgComplemento.Rows.Count > 0 And REA.GetString("complemento") = "comp" Then
                        strXMLComp &= "<cca:ItemCuentaAjena>" & vbCrLf
                        strXMLComp &= "<cca:NITtercero>" & strNitCliente & "</cca:NITtercero>" & vbCrLf
                        strXMLComp &= "<cca:NumeroDocumento>" & REA.GetString("relatedDocument") & "</cca:NumeroDocumento>" & vbCrLf
                        strXMLComp &= "<cca:FechaDocumento>" & REA.GetDateTime("documentDate").ToString(FORMATO_MYSQL) & "</cca:FechaDocumento>" & vbCrLf
                        strXMLComp &= "<cca:Descripcion>" & cfun.convertirXML(REA.GetString("cuentaAjena")) & "</cca:Descripcion>" & vbCrLf
                        strXMLComp &= "<cca:BaseImponible>0.00</cca:BaseImponible>" & vbCrLf
                        strXMLComp &= "<cca:MontoCobroDAI>0.00</cca:MontoCobroDAI>" & vbCrLf
                        strXMLComp &= "<cca:MontoCobroIVA>0.00</cca:MontoCobroIVA>" & vbCrLf
                        strXMLComp &= "<cca:MontoCobroOtros>" & REA.GetDouble("cuentaAjenaValor").ToString(FORMATO_MONEDA) & "</cca:MontoCobroOtros>" & vbCrLf
                        strXMLComp &= "<cca:MontoCobroTotal>" & REA.GetDouble("cuentaAjenaValor").ToString(FORMATO_MONEDA) & "</cca:MontoCobroTotal>" & vbCrLf
                        strXMLComp &= "</cca:ItemCuentaAjena>" & vbCrLf
                        dblTotalComplemento += REA.GetDouble("cuentaAjenaValor").ToString(FORMATO_MONEDA)
                    End If

                Loop
            End If
            strXML &= "</dte:Items>" & vbCrLf
            'Totales 
            strXML &= "<dte:Totales>" & vbCrLf
            strXML &= "<dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:TotalImpuesto NombreCorto='IVA' TotalMontoImpuesto='" & dblGranTotalIva & "'/>" & vbCrLf
            strXML &= "</dte:TotalImpuestos>" & vbCrLf
            strXML &= "<dte:GranTotal>" & dblGranTotal & "</dte:GranTotal>" & vbCrLf
            strXML &= "</dte:Totales>" & vbCrLf

            If strXMLComp.Length > 0 Then
                strXML &= "<dte:Complementos>" & vbCrLf
                strXML &= "<dte:Complemento IDComplemento='1' NombreComplemento='CXCA' URIComplemento='http://www.sat.gob.gt/face2/CobroXCuentaAjena/0.1.0'>" & vbCrLf
                strXML &= "<cca:CobroXCuentaAjena xmlns:cca='http://www.sat.gob.gt/face2/CobroXCuentaAjena/0.1.0' Version='1'>" & vbCrLf
                strXML &= strXMLComp
                strXML &= "</cca:CobroXCuentaAjena>" & vbCrLf
                strXML &= "</dte:Complemento>" & vbCrLf
                strXML &= "</dte:Complementos>" & vbCrLf
            End If

            strXML &= "</dte:DatosEmision> " & vbCrLf
            strXML &= "</dte:DTE> " & vbCrLf
            strXML &= "<dte:Adenda>" & vbCrLf
            strXML &= "<dte:AdendaDetail id='AdendaSummary'> " & vbCrLf
            strXML &= "<dte:AdendaSummary>" & vbCrLf
            strXML &= "<dte:Valor1>" & strObservacion & "</dte:Valor1>" & vbCrLf
            strXML &= "<dte:Valor2>" & celdaNumero.Text & "</dte:Valor2>" & vbCrLf
            strXML &= "<dte:Valor4>Q." & (CDbl(celdaTotal.Text) + CDbl(celdaTotalComplemento.Text)).ToString(FORMATO_MONEDA) & "</dte:Valor4>" & vbCrLf
            If strXMLComp.Length > 0 Then
                strXML &= "<dte:Valor5>Q." & CDbl(celdaTotalComplemento.Text).ToString(FORMATO_MONEDA) & "</dte:Valor5>" & vbCrLf
            End If
            strXML &= "</dte:AdendaSummary>" & vbCrLf
            strXML &= "</dte:AdendaDetail>" & vbCrLf
            strXML &= "</dte:Adenda>" & vbCrLf
            strXML &= "</dte:SAT> " & vbCrLf
            strXML &= "</dte:GTDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXML &= "]]>" & vbCrLf
            strXML &= "</xml_dte>" & vbCrLf
            strXML &= "</FirmaDocumentoRequest>" & vbCrLf
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenido.xml")
            sw.Write(strXML)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                strError &= " Fallo en la Firma Electronica "
                '   EnvioProyecto(strError)
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<RegistraDocumentoXMLRequest id='" & strUUID & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</RegistraDocumentoXMLRequest>"
            Next
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\RegistraDocumento.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FactSimpleCMCFel" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSFel" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FactSimpleCMCFel" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSFel" & celdaNumero.Text & ".xml")

            'Registra la factura ya firmado
            strXMLFinal = t.RegistrarDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el registra documento de Fel ")
                strError &= "Fallo en el registra documento de Fel"
                '  EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            ' Metodo para subir el archivo en una compartida
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactSimpleCMCFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactSimpleCMCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactSimpleCMCFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactSimpleCMCFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)

            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactSimpleLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactSimpleLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)

            '' se modifica el 29/01/2025 para hacer el 
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSFel" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FactSimpleLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSFel" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FactSimpleLSFel" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FactSimpleLSfel" & celdaNumero.Text & ".xml")

            nodos_lista = xml_Documento.SelectNodes("/RegistraDocumentoXMLResponse")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strXMLFel = nodo.ChildNodes.Item(0).InnerText
            Next
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml")
            sw.Write(strXMLFel)
            sw.Close()

            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FelSimpleCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FelSimpleCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)

            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FelSimpleLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FelSimpleLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025 para hacer el 
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\FelSimpleLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\FelSimpleLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try


            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml")

            nodos_lista = xml_Documento.GetElementsByTagName("dte:Certificacion")
            'iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                ' asigna el token devuelto por web service 
                strNitCertificador = nodo.ChildNodes.Item(0).InnerText  ' Nit MegaPrint
                '  strFechaHoraCertificacion = nodo.ChildNodes.Item(1).InnerText ' Nombre MegaPrint
                strSerieDocumento = nodo.ChildNodes.Item(2).InnerText ' Serie 
                strFechaHoraCertificacion = nodo.ChildNodes.Item(3).InnerText ' FechaCertificacion 
            Next
            ' Nombre del archivo a utilizar
            'Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".xml"
            Dim vlcFileName As String = System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".xml"
            ' Si el archivo existe
            Dim vloFile As New StreamReader(vlcFileName)
            ' Ciclo de iteración entre líneas
            While True
                ' Cargar la línea
                Dim vlcLinea = vloFile.ReadLine()
                ' Si la línea es nula, sale del ciclo
                If vlcLinea Is Nothing Then Exit While
                ' Si la línea contiene el criterio
                If vlcLinea.Contains(vlcCriterio) Then
                    ' Obtener la línea como resultado,
                    ' Concatenando un retorno de carro si ya hay ocurrencias
                    vlcResultado += IIf(vlcResultado <> "", vbCrLf, "") & vlcLinea
                    ' Salir del ciclo
                    Exit While
                    ' Lo omites si quieres todas las ocurrencias
                End If
            End While
            'Realiza busqueda de la cadena para obtener el numero de Autorizacion
            strCadenaEncontrada = vlcResultado.Substring(vlcResultado.LastIndexOf("Numero=") + 1)
            'En un array parte la cadena despues que encuentre un igual 
            arrayCadena = strCadenaEncontrada.Split("=".ToCharArray)
            'carga el numero de autorizacion de cada documento
            strNumeroAutorizacion = arrayCadena(INT_UNO)
            'sustituye serie por cadena vacio para limpiar la cadena y solo obtenga el numero
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, "Serie", STR_VACIO)
            'sustituye "" por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, """", STR_VACIO)
            'sustituye espacios por cadena vacia para limpiar la cadena y solo obtenga el numero 
            strNumeroAutorizacion = Replace(strNumeroAutorizacion, " ", STR_VACIO)
            ActualizarFel(Horario & "-06:00", strFechaHoraCertificacion, strSerieDocumento, strNumeroAutorizacion, STR_VACIO, strUUID)

            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & strSerieDocumento & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFSimpleCMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFSimpleLS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFSimpleCMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFSimpleLS" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFSimpleCMCFinal" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFSimpleLSFinal" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFSimpleCMCFinal" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFSimpleLSFinal" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            'xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFSimpleCMCFinal" & celdaNumero.Text & ".xml")
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFSimpleLSFinal" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next

            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            'Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".pdf")
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()
            '' Metodo para subir el archivo en una compartida
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelSimpleCMC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelSimpleCMC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelSimpleLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelSimplLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)

            '' se modifica el 29/01/2025 para hacer el 
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelSimpleLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelSimplLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try

            botonInprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                'System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelSimpleCMC" & celdaNumero.Text & ".pdf")
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelSimpleLS" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Function AnularFel(ByVal strSerieUUID As String, ByVal strFechaEmsionDocumento As String, ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String) As Boolean
        Dim logResultado As Boolean = True
        Dim strpath As String = System.Windows.Forms.Application.StartupPath & "\SolicitaToken.xml"
        Dim strpathF As String = System.Windows.Forms.Application.StartupPath & "\contenidoA.xml"
        'Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC.xml"
        Dim strpathR As String = System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS.xml"
        'Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFACMC" & celdaNumero.Text & ".xml"
        Dim strpathPDF As String = System.Windows.Forms.Application.StartupPath & "\PDFALS" & celdaNumero.Text & ".xml"
        Dim strCodigo64BitsPDF As String = STR_VACIO
        Dim strSolicitarToken As String = STR_VACIO
        Dim strXMLAnulacion As String = STR_VACIO
        Dim strXMLRegistra As String = STR_VACIO
        Dim strXMLFinal As String = STR_VACIO
        Dim strXMLPDF As String = STR_VACIO
        Dim strValidarAnulacion As String = STR_VACIO
        Dim strFechaAnulacion As String = STR_VACIO
        Dim fs As FileStream
        Dim t As New Fel
        Dim strToken As String = STR_VACIO
        Dim strError As String = STR_VACIO
        Dim sw As StreamWriter
        Dim xml_Documento As New XmlDocument
        Dim nodos_lista As XmlNodeList
        Dim strNitCliente As String = STR_VACIO
        Dim strConexion2 As String
        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String
        Try
            If cFunciones.ExisteArchivo(strpath) Then
                'Solicita Token en el Web Service 
                strSolicitarToken = t.SolicitarToken1(strpath)
                If File.Exists(System.Windows.Forms.Application.StartupPath & "\TokenD.xml") Then
                    ' Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' cierra el archivo 
                    sw.Close()
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                Else
                    'Crea Archivo TokenD.xml
                    fs = File.Create(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    fs.Close()
                    'Abre Archivo TokenD.xml
                    sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    ' Copia el Token devuelvo del Web Service 
                    sw.Write(strSolicitarToken)
                    ' Carga el Archivo TokenD.xml
                    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\TokenD.xml")
                    nodos_lista = xml_Documento.SelectNodes("/SolicitaTokenResponse")
                    'Iniciamos el ciclo de lectura
                    For Each nodo In nodos_lista
                        ' Asigna el Token Devuelto por Web Service 
                        strToken = nodo.ChildNodes.Item(1).InnerText
                    Next
                    sw.Close()
                End If
            End If
            strFechaAnulacion = Now().ToString("yyyy-MM-ddTHH:mm:ss") & "-06:00"
            strNitCliente = celdaNIT.Text
            strNitCliente = Replace(strNitCliente, "-", "")
            ' XML Firma Electronica 
            strXMLAnulacion &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLAnulacion &= "<FirmaDocumentoRequest id='A50E4C76-6084-11E9-8647-D663BD873D93'>" & vbCrLf
            strXMLAnulacion &= "<xml_dte>" & vbCrLf
            strXMLAnulacion &= "<![CDATA[ " & vbCrLf
            ' XML ANULACION
            strXMLAnulacion &= " <ns:GTAnulacionDocumento Version='0.1' xmlns:ns='http://www.sat.gob.gt/dte/fel/0.1.0' xmlns:xd='http://www.w3.org/2000/09/xmldsig#'>" & vbCrLf
            strXMLAnulacion &= "<ns:SAT>" & vbCrLf
            strXMLAnulacion &= "<ns:AnulacionDTE ID='DatosCertificados'>" & vbCrLf
            strXMLAnulacion &= "<ns:DatosGenerales ID='DatosAnulacion'" & vbCrLf
            strXMLAnulacion &= "NumeroDocumentoAAnular='" & celdaSerieFel.Text & "'" & vbCrLf
            'cmc
            'strXMLAnulacion &= "NITEmisor='76882551' IDReceptor='" & strNitCliente & "'" & vbCrLf
            strXMLAnulacion &= "NITEmisor='120375265' IDReceptor='" & strNitCliente & "'" & vbCrLf
            strXMLAnulacion &= "FechaEmisionDocumentoAnular='" & celdaFechaEmisionDocumento.Text & "'" & vbCrLf
            strXMLAnulacion &= "FechaHoraAnulacion='" & strFechaAnulacion & "' MotivoAnulacion='Cancelacion'/>" & vbCrLf
            strXMLAnulacion &= "</ns:AnulacionDTE>" & vbCrLf
            strXMLAnulacion &= "</ns:SAT>" & vbCrLf
            strXMLAnulacion &= "</ns:GTAnulacionDocumento>" & vbCrLf
            'Fin Fima Electronica 
            strXMLAnulacion &= "]]>" & vbCrLf
            strXMLAnulacion &= "</xml_dte>" & vbCrLf
            strXMLAnulacion &= "</FirmaDocumentoRequest>" & vbCrLf

            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\contenidoA.xml")
            sw.Write(strXMLAnulacion)
            sw.Close()
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            fs.Close()
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            sw.Write(t.FirmaElectronica(strpathF, strToken, logResultado))
            If logResultado = False Then
                MsgBox("Fallo en la Firma Electronica")
                Exit Function
            End If
            sw.Close()
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\firma.xml")
            nodos_lista = xml_Documento.SelectNodes("/FirmaDocumentoResponse")
            'Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    Asigna el Token Devuelto por Web Service 
                strXMLRegistra = "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf & "<AnulaDocumentoXMLRequest id='" & celdaSerieFel.Text & "'>" & vbCrLf & "<xml_dte><![CDATA[" & nodo.ChildNodes.Item(0).InnerText & " ]]></xml_dte>" & vbCrLf & "</AnulaDocumentoXMLRequest>"
            Next
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC.xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS.xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC.xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS.xml")
            sw.Write(strXMLRegistra)
            sw.Close()
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS" & celdaNumero.Text & ".xml")
            ' Registra la factura ya firmado
            strXMLFinal = t.AnulaDocumento(strpathR, strToken, logResultado)
            If logResultado = False Then
                MsgBox("Fallo en el Anula documento de Fel ")
                strError &= "Fallo en el Anula documento de Fel"
                '  EnvioProyecto(strError)
                Exit Function
            End If
            sw.Write(strXMLFinal)
            sw.Close()
            System.Threading.Thread.Sleep(5000)
            '    xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\AnulacionFel" & celdaNumero.Text & ".xml")
            '   nodos_lista = xml_Documento.SelectNodes("/")
            'iniciamos el ciclo de lectura
            '  For Each nodo In nodos_lista
            ' asigna el token devuelto por web service 
            ' strValidarAnulacion = nodo.ChildNodes.Item(2).InnerText
            ' Next
            ' If strValidarAnulacion = INT_UNO Then
            'MsgBox("La factura registrada se encuentra anulado")
            'logResultado = False
            'Else
            ' MsgBox("La factura  se ha anulado correctamente ")
            'logResultado = True
            'End If

            ' Metodo para subir el archivo en una compartida
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025 
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS" & celdaNumero.Text & ".xml", "file://" & IP & strRuta & "\AnulacionFelLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red local: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelLS" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelLS" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo: " & ex2.Message)
            End Try


            'Creacion de XML para consumir Webservice retorna pdf
            strXMLPDF &= "<?xml version='1.0' encoding='UTF-8'?>" & vbCrLf
            strXMLPDF &= "<RetornaPDFRequest>" & vbCrLf
            strXMLPDF &= "<uuid>" & celdaSerieFel.Text & "</uuid>" & vbCrLf
            strXMLPDF &= "</RetornaPDFRequest>" & vbCrLf
            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFACMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFALS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFACMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFALS" & celdaNumero.Text & ".xml")
            sw.Write(strXMLPDF)
            sw.Close()

            'fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinalANCMC" & celdaNumero.Text & ".xml")
            fs = File.Create(System.Windows.Forms.Application.StartupPath & "\PDFFinalANLS" & celdaNumero.Text & ".xml")
            fs.Close()
            'sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinalANCMC" & celdaNumero.Text & ".xml")
            sw = New StreamWriter(System.Windows.Forms.Application.StartupPath & "\PDFFinalANLS" & celdaNumero.Text & ".xml")
            sw.Write(t.RetornaPDF(strpathPDF, strToken))
            sw.Close()
            'xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinalANCMC" & celdaNumero.Text & ".xml")
            xml_Documento.Load(System.Windows.Forms.Application.StartupPath & "\PDFFinalANLS" & celdaNumero.Text & ".xml")
            nodos_lista = xml_Documento.SelectNodes("/RetornaPDFResponse")
            ''Iniciamos el ciclo de lectura
            For Each nodo In nodos_lista
                '    ' Asigna el Codigo 64 Bits
                strCodigo64BitsPDF = nodo.ChildNodes.Item(0).InnerText
            Next
            Dim str As String = strCodigo64BitsPDF
            Dim Base64Byte() As Byte = Convert.FromBase64String(str)
            'Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelAnulacionCMC" & celdaNumero.Text & ".pdf")
            Dim obj As FileStream = File.Create(System.Windows.Forms.Application.StartupPath & "\FelAnulacionLS" & celdaNumero.Text & ".pdf")
            obj.Write(Base64Byte, 0, Base64Byte.Length)
            obj.Flush()
            obj.Close()

            ' Metodo para subir el archivo en una compartida
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionCMC" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionCMC" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            ''My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\AnulacionFelCMC" & celdaNumero.Text & ".xml", "C:\Archivos_Fel\AnulacionFelCMC" & celdaNumero.Text & ".xml" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionLS" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            'My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionLS" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\AnulacionFelLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            '' se modifica el 29/01/2025
            Try
                ' Intento la primera subida con la ruta de red
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionLS" & celdaNumero.Text & ".pdf", "file://" & IP & strRuta & "\FelAnulacionLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex1 As Exception
                MessageBox.Show("Error al subir el archivo en red: " & ex1.Message)
            End Try
            Try
                ' Si falla, intento la segunda subida con la ruta local
                My.Computer.Network.UploadFile(System.Windows.Forms.Application.StartupPath & "\FelAnulacionLS" & celdaNumero.Text & ".pdf", "C:\Archivos_Fel\FelAnulacionLS" & celdaNumero.Text & ".pdf" & "", strUsuario, strContrasena, True, 9000, True)
            Catch ex2 As Exception
                MessageBox.Show("Error al guardar archivo local: " & ex2.Message)
            End Try


            botonInprimir.Enabled = True
            If MsgBox("Open file PDF ?", MsgBoxStyle.OkCancel, "Info") = MsgBoxResult.Ok Then
                'System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelAnulacionCMC" & celdaNumero.Text & ".pdf")
                System.Diagnostics.Process.Start(System.Windows.Forms.Application.StartupPath & "\FelAnulacionLS" & celdaNumero.Text & ".pdf")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function
    Public Sub ImprimirPDFGenerado(ByVal IP As String, ByVal strUsuario As String, ByVal strContrasena As String, ByVal strRuta As String)
        Dim Proceso As New Process
        Dim openSave As New SaveFileDialog
        Dim OpenFile As New OpenFileDialog
        Dim strGuardar As String = STR_VACIO
        Dim strArchivo As String = STR_VACIO
        Try
            strGuardar = ".pdf"
            openSave.InitialDirectory = "c:\"
            openSave.Filter = "All Files|*.*"
            openSave.RestoreDirectory = True
            openSave.AddExtension = False
            openSave.FileName = "Fel" & celdaNumero.Text & strGuardar & strGuardar
            If openSave.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                strArchivo = openSave.FileName
                If checkActivar.Checked = True Then
                    If intTipo = 2 Then
                        'If File.Exists("//" & IP & strRuta & "FelSimpleCMC" & celdaNumero.Text & ".pdf" & "") = True Then
                        '    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "FelSimpleCMC" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                        If File.Exists("//" & IP & strRuta & "FelSimpleLS" & celdaNumero.Text & ".pdf" & "") = True Then
                            My.Computer.Network.DownloadFile("file://" & IP & strRuta & "FelSimpleLS" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                        Else
                            MsgBox("This file is not available, please contact with IT", MsgBoxStyle.Critical, "Notice")
                            Exit Sub
                        End If

                    ElseIf intTipo = 0 Then
                        'If File.Exists("//" & IP & strRuta & "FelCMC" & celdaNumero.Text & ".pdf" & "") = True Then
                        '    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "FelCMC" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                        If File.Exists("//" & IP & strRuta & "FelLS" & celdaNumero.Text & ".pdf" & "") = True Then
                            My.Computer.Network.DownloadFile("file://" & IP & strRuta & "FelLS" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                        Else
                            MsgBox("This file is not available, please contact with IT", MsgBoxStyle.Critical, "Notice")
                            Exit Sub
                        End If
                    End If
                Else
                    'My.Computer.Network.DownloadFile("file://" & IP & strRuta & "\FelAnulacionCMC" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                    My.Computer.Network.DownloadFile("file://" & IP & strRuta & "\FelAnulacionLS" & celdaNumero.Text & ".pdf" & "", strArchivo, strUsuario, strContrasena, True, 9000, True)
                End If
            End If
            'Proceso.StartInfo.FileName = "\\192.168.4.142\Archivos_Fel" & "\Fel" & celdaNumero.Text & ".pdf"
            'Proceso.StartInfo.Arguments = ""
            'Proceso.Start()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub AgregarComentario(ByVal Anio As Integer, ByVal Numero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        'Dim datos_Factura As String
        ' cfun.sesionHilos()
        Try
            strSQL = " SELECT CONCAT('FACT-' ,ifnull(f.NumeroAutorizacion,0)) Invoice , CONCAT('REF-',h.HDoc_Doc_Num) Num  "
            strSQL &= "     FROM " & strBaseRel & ".Dcmtos_HDR h"
            strSQL &= "         LEFT JOIN " & strBaseRel & ".Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Catalogo = h.HDoc_Doc_Cat 
                                AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_Doc_Num "
            strSQL &= "             WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Ano = {Anio} AND h.HDoc_Doc_Num ={Num} "
            strSQL = Replace(strSQL, "{empresa}", intEmpRel)
            strSQL = Replace(strSQL, "{Anio}", Anio)
            strSQL = Replace(strSQL, "{Num}", Numero)



            If Sesion.IdEmpresa = 10 Then
                cfun.sesionHilos()
                ' Configura la cadena de conexión para baseOF
                Dim connectionStringBaseOF As String = "server=" & CMC_Hilos_Host & ";Port=" & CMC_Hilos_PORT & ";database=" & CMC_Hilos_BASE & ";uid=" & CMC_Hilos_USER & ";password=" & CMC_Hilos_PASS & ";"
                Try

                    Using VconnectionStringBaseOF As New MySqlConnection(connectionStringBaseOF)
                        VconnectionStringBaseOF.Open()
                        COM = New MySqlCommand(strSQL, VconnectionStringBaseOF)
                        REA = COM.ExecuteReader

                        If REA.HasRows Then
                            Do While REA.Read
                                For i As Integer = 0 To dgFactrura.Rows.Count - 1
                                    If dgFactrura.Rows.Count = 1 Then
                                        celdaObservaciones.Text = REA.GetString("Invoice") & " " & REA.GetString("Num")
                                    Else
                                        celdaObservaciones.Text = celdaObservaciones.Text & " / " & REA.GetString("Invoice") & " " & REA.GetString("Num")
                                        Exit For
                                    End If
                                Next
                            Loop
                        End If
                        VconnectionStringBaseOF.Close()
                        COM = Nothing
                        REA.Close()
                        Exit Sub
                    End Using

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
            Else
                MyCnn.CONECTAR = strConexion
                COM = New MySqlCommand(strSQL, CON)
                REA = COM.ExecuteReader
            End If


            If REA.HasRows Then
                Do While REA.Read
                    For i As Integer = 0 To dgFactrura.Rows.Count - 1
                        If dgFactrura.Rows.Count = 1 Then
                            celdaObservaciones.Text = REA.GetString("Invoice") & " " & REA.GetString("Num")
                        Else
                            celdaObservaciones.Text = celdaObservaciones.Text & " / " & REA.GetString("Invoice") & " " & REA.GetString("Num")
                            Exit For
                        End If
                    Next
                Loop
            End If
            COM = Nothing
            REA.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
#End Region

#Region "Eventos"


    Private Sub frmOrdenCompra_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmOrdenCompra_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dtpFin.Value = Today
        dtpInicio.Value = dtpFin.Value.AddMonths(NO_FILA)
        Accessos()
        MostrarLista()
        CargarVariables()
        cfun.sesionHilos()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelLista.Visible = True Then
            Me.Close()
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        If ComprobarDatos() = True Then
            If ComprobarFila() = True Then
                If Guardar() = True Then
                    MostrarLista()
                End If
            End If
        Else
            MsgBox("You must fill In all the required fields To Continue.", MsgBoxStyle.Exclamation)
        End If
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            If Sesion.IdEmpresa = 10 Then
                ActivarFel()
            End If
            MostrarLista(False, True)

        Else
            MsgBox("You do not have permissions for this action", vbCritical, "Notice")
        End If

    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        CargarLista()
    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intID As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub

            Me.Tag = "mod"
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            intID = dgLista.SelectedCells(1).Value
            intAño = dgLista.SelectedCells(2).Value
            reset()
            seleccionar(intID, intAño)
            MostrarLista(False)
            If Sesion.IdEmpresa = 10 Then
                If celdaSerieFel.Text <> STR_VACIO Then
                    BloquearFel()
                Else
                    ActivarFel()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(296, dgLista.SelectedCells(1).Value, dgLista.SelectedCells(2).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(2).Value, dgLista.SelectedCells(1).Value, 296)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "c.cli_sisemp  = {empresa} And c.cli_status  = 'Activo' "
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            frm.Titulo = "Customer"
            frm.Campos = " c.cli_codigo , c.cli_cliente , c.cli_direccion , c.cli_telefono , c.cli_nit "
            frm.Tabla = " Clientes c"
            frm.FiltroText = " Enter the name of customer to filter"
            frm.Filtro = "  c.cli_cliente"
            frm.Limite = 30
            frm.Ordenamiento = " c.cli_codigo "
            frm.TipoOrdenamiento = ""
            frm.Condicion = strCondicion

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdCliente.Text = frm.LLave
                celdaCliente.Text = frm.Dato
                celdaDireccion.Text = frm.Dato2
                celdaTelefono.Text = frm.Dato3
                celdaNIT.Text = frm.Dato4

                dgDatos.Rows.Clear()
                dgFactrura.Rows.Clear()
                dgDetalle.Rows.Clear()

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Currency"
            frm.Campos = " cat_num Code, cat_clave Currency, cat_sist rate"
            frm.Tabla = " Catalogos"
            frm.FiltroText = " Enter the Name of the Currency to Filter"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
                If frm.Dato2 > 1 Then
                    celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
                Else
                    celdaTasa.Text = frm.Dato2
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click
        Dim strFila As String = STR_VACIO
        Dim logExiste As Boolean = False
        Dim strMsg As String = STR_VACIO
        Dim strComentario As String = STR_VACIO
        Dim strFlete As String = STR_VACIO
        Dim strGasto As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO


        Select Case intTipo
            Case INT_CERO

                If Not celdaIdCliente.Text = NO_FILA Then
                    Dim frmOp As New frmOption
                    Dim frm As New frmSeleccionar
                    Dim frmA As New frmAutorización
                    Dim frmCMC As New frmSeleccionarCMC

                    frmOp.Titulo = "Connection options"
                    frmOp.Mensaje = "Select a connection"
                    frmOp.Opciones = celdaCliente.Text & "|" & "Other"
                    frmOp.ShowDialog(Me)
                    If frmOp.DialogResult = System.Windows.Forms.DialogResult.OK Then
                        If Sesion.IdEmpresa = 10 Then
                            If frmOp.Seleccion = INT_CERO Then
                                'frmCMC.FiltroText = "AND h.HDoc_Emp_Nom LIKE '%" & celdaCliente.Text & "%'"
                                frmCMC.FiltroText = "AND h.HDoc_Emp_Cod = " & celdaIdCliente.Text
                            Else
                                frmA.Iniciar(147, "OTHER", 0, "Billing for different customers.")
                                frmA.ShowDialog(Me)
                                frmCMC.FiltroText = ""
                                If frmA.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                Else
                                    Exit Sub
                                End If

                            End If
                            frmCMC.ShowDialog(Me)


                            For i As Integer = 0 To frmCMC.DataGrid.Rows.Count - 1
                                logExiste = False
                                strFila = STR_VACIO
                                If frmCMC.DataGrid.Rows(i).Cells("Select").Value = True Then ' agregar solo las que este seleccionadas
                                    For j As Integer = 0 To dgFactrura.Rows.Count - 1 ' verificar en el data grid factura si ya se agrego anteriormente
                                        If dgFactrura.Rows.Count = 0 Then
                                            Exit For
                                        Else
                                            If (dgFactrura.Rows(j).Cells("colYearF").Value = frmCMC.DataGrid.Rows(i).Cells("YEAR").Value And dgFactrura.Rows(j).Cells("colInvoiceF").Value = frmCMC.DataGrid.Rows(i).Cells("Invoice").Value) Then
                                                logExiste = True
                                            End If
                                        End If
                                    Next
                                    If Not logExiste Then ' si no se agrego anteriormente agrega la linea
                                        strFila &= frmCMC.DataGrid.Rows(i).Cells("YEAR").Value & "|"
                                        strFila &= frmCMC.DataGrid.Rows(i).Cells("Invoice").Value & "|"
                                        strFila &= frmCMC.DataGrid.Rows(i).Cells("DATE").Value & "|"
                                        strFila &= frmCMC.DataGrid.Rows(i).Cells("Reference").Value & "|"
                                        strFila &= frmCMC.DataGrid.Rows(i).Cells("Weight").Value
                                        If frmCMC.DataGrid.Rows(i).Cells("Flete").Value = 0 Then
                                            strFlete = "HILOS Y ALGODON"
                                        ElseIf frmCMC.DataGrid.Rows(i).Cells("Flete").Value = 1 Then
                                            strFlete = "Does not apply"
                                        Else
                                            strFlete = celdaCliente.Text
                                        End If

                                        If frmCMC.DataGrid.Rows(i).Cells("Gasto").Value = 0 Then
                                            strGasto = "HILOS Y ALGODON"
                                        ElseIf frmCMC.DataGrid.Rows(i).Cells("Gasto").Value = 1 Then
                                            strGasto = "Does not apply"
                                        Else
                                            strGasto = celdaCliente.Text
                                        End If

                                        strComentario = strComentario & frmCMC.DataGrid.Rows(i).Cells("Comentario").Value & vbCrLf
                                        strMsg = strMsg & vbCrLf & "On the invoice: " & frmCMC.DataGrid.Rows(i).Cells("Invoice").Value & vbCrLf & "Freight pay: " & strFlete & vbCrLf & "Pay other expenses: " & strGasto & vbCrLf & "Comments: " & strComentario & vbCrLf
                                        cfun.AgregarFila(dgFactrura, strFila)
                                        If Sesion.IdEmpresa = 10 Then
                                            AgregarComentario(frmCMC.DataGrid.Rows(i).Cells("YEAR").Value, frmCMC.DataGrid.Rows(i).Cells("Invoice").Value)
                                        End If
                                    End If
                                End If
                            Next
                            If Sesion.IdEmpresa = 10 Then
                                If MsgBox(strMsg, vbExclamation, "Notice") = vbOK Then
                                    celdaNotas.Text = celdaNotas.Text & strMsg
                                End If
                            End If


                        Else


                            If frmOp.Seleccion = INT_CERO Then

                                strCondicion = "  h.HDoc_Sis_Emp = " & intEmpRel & " AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Emp_Nom LIKE '%" & celdaCliente.Text.Substring(0, celdaCliente.Text.Length - 4) & "%' AND {relacion} AND h.HDoc_Doc_Status = 1    and p.PDoc_Sis_Emp is null "
                                If botonRefacturar.BackColor = Color.LightSkyBlue Then
                                    strCondicion = Replace(strCondicion, "{relacion}", "h.HDoc_Pro_DCat >0")
                                Else
                                    strCondicion = Replace(strCondicion, "{relacion}", "h.HDoc_Pro_DCat =0 AND dp.PDoc_Chi_Num is null ")
                                End If
                            Else
                                frmA.Iniciar(147, "OTHER", 0, "Billing for different customers.")
                                frmA.ShowDialog(Me)
                                If frmA.DialogResult = System.Windows.Forms.DialogResult.OK Then

                                    strCondicion = "  h.HDoc_Sis_Emp = " & intEmpRel & " AND h.HDoc_Doc_Cat = 36 AND h.HDoc_Doc_Num LIKE '%" & InputBox("Give me an invoice number", "Other customer") & "%' AND {relacion} AND h.HDoc_Doc_Status = 1  "
                                    If botonRefacturar.BackColor = Color.LightSkyBlue Then
                                        strCondicion = Replace(strCondicion, "{relacion}", "h.HDoc_Pro_DCat >0")
                                    Else
                                        strCondicion = Replace(strCondicion, "{relacion}", "h.HDoc_Pro_DCat =0")
                                    End If

                                Else
                                    Exit Sub
                                End If
                            End If

                            frm.Campos = "  S1.Invoice Invoice, S1.DATE Date, S1.Reference Reference, S1.Weight Weight, S1.User User, S1.YEAR YEAR, S1.Flete Flete, S1.Gasto Gasto, S1.Comentario Comentarios "
                            frm.Tabla = "( SELECT h.HDoc_Doc_Num Invoice, h.HDoc_Doc_Fec DATE, h.HDoc_DR1_Num Reference, SUM(d.DDoc_Prd_QTY) Weight,h.HDoc_Usuario USER, h.HDoc_Doc_Ano YEAR, 
                            IFNULL(h48.HDoc_RF1_Num,-1) Flete, IFNULL(h48.HDoc_Rf2_Num,-1) Gasto, IFNULL(h.HDoc_RF2_txt, ' ') Comentario  
                            From " & strBaseRel & ".Dcmtos_HDR h Left 
                            Join " & strBaseRel & ".Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp And d.DDoc_Doc_Cat = h.HDoc_Doc_Cat And d.DDoc_Doc_Ano = h.HDoc_Doc_Ano And d.DDoc_Doc_Num = h.HDoc_Doc_Num 
                            LEFT JOIN " & strBaseRel & ".Dcmtos_DTL_Pro p48 ON p48.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p48.PDoc_Chi_Cat = h.HDoc_Doc_Cat AND p48.PDoc_Chi_Ano = h.HDoc_Doc_Ano AND p48.PDoc_Chi_Num = h.HDoc_Doc_Num AND p48.PDoc_Par_Cat = 48  
                            LEFT JOIN " & strBaseRel & ".Dcmtos_HDR h48 ON h48.HDoc_Sis_Emp = p48.PDoc_Sis_Emp AND h48.HDoc_Doc_Cat = p48.PDoc_Par_Cat AND h48.HDoc_Doc_Ano = p48.PDoc_Par_Ano  AND h48.HDoc_Doc_Num = p48.PDoc_Par_Num 
                            Left Join " & strBaseRel & ".Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = 10 And p.PDoc_Par_Cat = d.DDoc_Doc_Cat And p.PDoc_Par_Ano = d.DDoc_Doc_Ano And p.PDoc_Par_Num = d.DDoc_Doc_Num  
                            LEFT JOIN Dcmtos_DTL_Pro dp ON dp.PDoc_Sis_Emp = 10 AND dp.PDoc_Par_Cat = h.HDoc_Doc_Cat AND dp.PDoc_Par_Ano = h.HDoc_Doc_Ano  AND dp.PDoc_Par_Num = h.HDoc_Doc_Num  AND dp.PDoc_Chi_Cat = 303  
                            WHERE " & strCondicion & " GROUP BY h.HDoc_Sis_Emp, h.HDoc_Doc_Cat, h.HDoc_Doc_Ano, h.HDoc_Doc_Num ORDER BY h.HDoc_Doc_Fec, h.HDoc_Doc_Num DESC) S1"
                            'frm.Tabla = strBaseRel & ".Dcmtos_HDR h left join " & strBaseRel & ".Dcmtos_DTL d on d.DDoc_Sis_Emp = h.HDoc_Sis_Emp and d.DDoc_Doc_Cat = h.HDoc_Doc_Cat and d.DDoc_Doc_Ano = h.HDoc_Doc_Ano and d.DDoc_Doc_Num =  h.HDoc_Doc_Num  left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp = " & Sesion.IdEmpresa & " and p.PDoc_Par_Cat = d.DDoc_Doc_Cat and p.PDoc_Par_Ano = d.DDoc_Doc_Ano and p.PDoc_Par_Num = d.DDoc_Doc_Num "
                            'frm.Agrupar = "  h.HDoc_Sis_Emp , h.HDoc_Doc_Cat , h.HDoc_Doc_Ano , h.HDoc_Doc_Num "
                            'frm.Ordenamiento = "  h.HDoc_Doc_Fec, h.HDoc_Doc_Num "
                            frm.Multiple = True
                            frm.Titulo = "multiples"
                            frm.FiltroText = " Enter the invoice number to Filter out"
                            frm.Filtro = " S1.Invoice "
                            frm.Condicion = " S1.Invoice > 0 "
                            frm.ShowDialog(Me)
                            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                For i As Integer = 0 To frm.DataGrid.Rows.Count - 1
                                    logExiste = False
                                    strFila = STR_VACIO
                                    If frm.DataGrid.Rows(i).Cells("colCheck").Value = True Then ' agregar solo las que este seleccionadas
                                        For j As Integer = 0 To dgFactrura.Rows.Count - 1 ' verificar en el data grid factura si ya se agrego anteriormente
                                            If dgFactrura.Rows.Count = 0 Then Exit For
                                            If (dgFactrura.Rows(j).Cells("colYearF").Value = frm.DataGrid.Rows(i).Cells("col_Year").Value And dgFactrura.Rows(j).Cells("colInvoiceF").Value = frm.DataGrid.Rows(i).Cells("col_Invoice").Value) Then
                                                logExiste = True
                                            End If
                                        Next
                                        If Not logExiste Then ' si no se agrego anteriormente agrega la linea
                                            strFila &= frm.DataGrid.Rows(i).Cells("col_Year").Value & "|"
                                            strFila &= frm.DataGrid.Rows(i).Cells("col_Invoice").Value & "|"
                                            strFila &= frm.DataGrid.Rows(i).Cells("col_Date").Value & "|"
                                            strFila &= frm.DataGrid.Rows(i).Cells("col_Reference").Value & "|"
                                            strFila &= frm.DataGrid.Rows(i).Cells("col_Weight").Value
                                            If frm.DataGrid.Rows(i).Cells("col_Flete").Value = 0 Then
                                                strFlete = "HILOS Y ALGODON"
                                            ElseIf frm.DataGrid.Rows(i).Cells("col_Flete").Value = 1 Then
                                                strFlete = "Does not apply"
                                            Else
                                                strFlete = celdaCliente.Text
                                            End If

                                            If frm.DataGrid.Rows(i).Cells("col_Gasto").Value = 0 Then
                                                strGasto = "HILOS Y ALGODON"
                                            ElseIf frm.DataGrid.Rows(i).Cells("col_Gasto").Value = 1 Then
                                                strGasto = "Does not apply"
                                            Else
                                                strGasto = celdaCliente.Text
                                            End If

                                            strComentario = strComentario & frm.DataGrid.Rows(i).Cells("col_Comentarios").Value & vbCrLf
                                            strMsg = strMsg & vbCrLf & "On the invoice: " & frm.DataGrid.Rows(i).Cells("col_Invoice").Value & vbCrLf & "Freight pay: " & strFlete & vbCrLf & "Pay other expenses: " & strGasto & vbCrLf & "Comments: " & strComentario & vbCrLf
                                            cfun.AgregarFila(dgFactrura, strFila)
                                            If Sesion.IdEmpresa = 10 Then
                                                AgregarComentario(frm.DataGrid.Rows(i).Cells("col_Year").Value, frm.DataGrid.Rows(i).Cells("col_Invoice").Value)
                                            End If
                                        End If
                                    End If
                                Next
                                If Sesion.IdEmpresa = 10 Then
                                    If MsgBox(strMsg, vbExclamation, "Notice") = vbOK Then
                                        celdaNotas.Text = celdaNotas.Text & strMsg
                                    End If
                                End If

                            End If
                        End If
                    End If
                Else
                    MsgBox("Before continuing select a customer", MsgBoxStyle.Information)
                End If

            Case INT_UNO
                Dim frm As New frmSeleccionar
                Dim strSQl As String = STR_VACIO
                Dim COM As MySqlCommand
                Dim REA As MySqlDataReader


                Dim strCondicion2 As String = STR_VACIO
                strCondicion2 = " h.HDoc_Sis_Emp = {empresa} and h.HDoc_Doc_Cat = 36 and h.HDoc_DR1_Cat = 0  and h.HDoc_Doc_Status = 1"
                strCondicion2 = Replace(strCondicion2, "{empresa}", Sesion.IdEmpresa)

                Try
                    frm.Titulo = "Invoice"
                    frm.Campos = "   h.HDoc_Doc_Ano Year , h.HDoc_Doc_Num ID , h.HDoc_Emp_Nom Customer, h.HDoc_DR1_Num Reference, h.HDoc_DR1_Dbl Factura "
                    frm.Tabla = " Dcmtos_HDR h LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Par_Cat = h.HDoc_Doc_Cat   AND p.PDoc_Par_Ano = h.HDoc_Doc_Ano AND p.PDoc_Par_Num = h.HDoc_Doc_Num AND p.PDoc_Chi_Cat = 296  "
                    frm.FiltroText = " Enter the invoice number to filter"
                    frm.Filtro = " h.HDoc_DR1_Dbl "
                    frm.Limite = 10
                    frm.Ordenamiento = " h.HDoc_Doc_Num "
                    frm.Condicion = strCondicion2

                    frm.ShowDialog(Me)
                    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then

                        logExiste = False
                        strFila = STR_VACIO

                        For j As Integer = 0 To dgFactrura.Rows.Count - 1 ' verificar en el data grid factura si ya se agrego anteriormente
                            If dgFactrura.Rows.Count = 0 Then Exit For
                            If (dgFactrura.Rows(j).Cells("colYearF").Value = frm.LLave And dgFactrura.Rows(j).Cells("colInvoiceF").Value = frm.Dato) Then
                                logExiste = True
                            End If
                        Next
                        If Not logExiste Then ' si no se agrego anteriormente agrega la linea
                            strFila &= frm.LLave & "|"
                            strFila &= frm.Dato & "|"
                            strFila &= frm.Dato2 & "|"
                            strFila &= frm.Dato3 & "|"
                            strFila &= "0.00"
                            cfun.AgregarFila(dgFactrura, strFila)
                        End If

                        strSQl = " select d.DDoc_Doc_Ano ano , d.DDoc_DOc_Num num,   d.DDoc_Doc_Lin linea, d.DDoc_Prd_Cod codigo, d.DDoc_Prd_Des des, d.DDoc_Prd_UM  idmedida,c.cat_clave medida, d.DDoc_Prd_Net precio, d.DDoc_Prd_DSP descuentop , d.DDoc_Prd_DSQ descuentoq, d.DDoc_Prd_QTY cantidad, d.DDoc_RF1_Txt referencia,b.BDoc_Box_QTY CantidadBultos,d.DDoc_RF2_Txt Bultos   "
                        strSQl &= "   from Dcmtos_DTL d "
                        strSQl &= "   left join Catalogos c on c.cat_num =d.DDoc_Prd_UM "
                        strSQl &= " LEFT JOIN Dcmtos_DTL_Box b ON b.BDoc_Sis_Emp = d.DDoc_Sis_Emp AND b.BDoc_Doc_Cat = d.DDoc_Doc_Cat AND b.BDoc_Doc_Ano = d.DDoc_Doc_Ano AND b.BDoc_Doc_Num = d.DDoc_Doc_Num AND b.BDoc_Doc_Lin = d.DDoc_Doc_Lin  "
                        strSQl &= " where d.DDoc_Sis_Emp ={empresa} and d.DDoc_DOc_Cat = 36 and d.DDoc_Doc_Ano = {ano} and d.DDoc_Doc_Num = {num} "

                        strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
                        strSQl = Replace(strSQl, "{ano}", frm.LLave)
                        strSQl = Replace(strSQl, "{num}", frm.Dato)

                        strFila = STR_VACIO
                        COM = New MySqlCommand(strSQl, CON)
                        REA = COM.ExecuteReader
                        If REA.HasRows Then
                            Do While REA.Read
                                strFila = "0" & "|" 'linea
                                strFila &= REA.GetInt32("codigo") & "|" ' codigo
                                strFila &= REA.GetString("des") & "|" ' descripcion
                                strFila &= REA.GetInt32("idmedida") & "|" ' id unidad de medida
                                strFila &= REA.GetString("medida") & "|" ' unidad de medida
                                strFila &= REA.GetInt32("CantidadBultos") & "|" ' Cantidad Bultos 
                                strFila &= REA.GetString("Bultos") & "|" ' Tipo Bulto 
                                strFila &= REA.GetDouble("precio") & "|" ' precio
                                strFila &= REA.GetDouble("descuentop") & "|" 'descuento porcentual
                                strFila &= REA.GetDouble("descuentoq") & "|" ' descuento $
                                strFila &= REA.GetDouble("cantidad") & "|" ' cantidad
                                strFila &= REA.GetString("referencia") & "|" 'referencia
                                strFila &= "0" & "|" ' catalogo pro
                                strFila &= REA.GetInt32("ano") & "|" ' año pro
                                strFila &= REA.GetInt32("num") & "|" ' numero pro
                                strFila &= REA.GetInt32("linea") & "|" 'linea pro
                                strFila &= " " & "|" 'destino   
                                strFila &= " " & "|" 'flete
                                strFila &= " " & "|" ' agente de aduanas
                                strFila &= " " & "|" ' servicios aduanales
                                strFila &= " " & "|" 'descripcion
                                strFila &= (REA.GetDouble("cantidad") * REA.GetDouble("precio")) - REA.GetDouble("descuentoq") * dblImpuestos / 100 & "|" ' iva
                                strFila &= (REA.GetDouble("cantidad") * REA.GetDouble("precio")) - REA.GetDouble("descuentoq") / 100 & "|" ' ventas excentas
                                strFila &= (REA.GetDouble("cantidad") * REA.GetDouble("precio")) - REA.GetDouble("descuentoq") & "|" ' subtotal
                                strFila &= " " & "|" ' Complemento cuenta ajena
                                strFila &= "0" & "|" 'complemento cuenta ajena valor
                                strFila &= (REA.GetDouble("cantidad") * REA.GetDouble("precio")) - REA.GetDouble("descuentoq") + ((REA.GetDouble("cantidad") * REA.GetDouble("precio")) - REA.GetDouble("descuentoq") * dblImpuestos / 100) - ((REA.GetDouble("cantidad") * REA.GetDouble("precio")) - REA.GetDouble("descuentoq") / 100)

                                cfun.AgregarFila(dgDetalle, strFila)
                            Loop
                            CalcularTotal()

                        End If
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString)
                End Try
        End Select

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'dgDetalle.Rows.Add()
        cfun.AgregarFila(dgDetalle, "||||||||||||||||0|0|0|0||||||||0")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If dgDetalle.SelectedRows.Count = INT_CERO Then Exit Sub
        dgDetalle.CurrentRow.Cells("colExtra").Value = 2
        dgDetalle.CurrentRow.Visible = False
        CalcularTotal()
    End Sub

    Private Sub buttonAddcomplemento_Click(sender As Object, e As EventArgs) Handles buttonAddcomplemento.Click
        'dgComplemento.Rows.Add()
        cfun.AgregarFila(dgComplemento, "||||0|0")
    End Sub

    Private Sub buttonDelComplemento_Click(sender As Object, e As EventArgs) Handles buttonDelComplemento.Click
        If dgComplemento.SelectedRows.Count = INT_CERO Then Exit Sub
        dgComplemento.CurrentRow.Cells("colExtraComplemento").Value = 2
        dgComplemento.CurrentRow.Visible = False
        CalcularTotalComplemento()
    End Sub
    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        CalcularTotal()
    End Sub
    Private Sub dgComplemento_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgComplemento.CellEndEdit
        CalcularTotalComplemento()
    End Sub
    Private Sub botonPolizaC_Click(sender As Object, e As EventArgs) Handles botonPolizaC.Click

        Dim NP As New clsPolizaContable
        Try
            If intTipo = 1 Then
                Dim op As New frmOption


                op.Titulo = "Option"
                op.Mensaje = "Select an option"
                op.Opciones = "Cost " & "|" & "Sale"
                If op.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    Select Case op.Seleccion

                        Case 0
                            NP.intModo = 10
                        Case 1
                            NP.intModo = 9
                    End Select

                Else
                    Exit Sub
                End If
            Else
                NP.intModo = 9
            End If

            NP.intTipo = 296
            NP.intCiclo = celdaAño.Text
            NP.intNumero = celdaNumero.Text
            NP.MostrarPolizaContable()

        Catch ex As Exception
            MsgBox("It has no Accounting Policy")
        End Try
    End Sub

    Private Sub botonInprimir_Click(sender As Object, e As EventArgs) Handles botonInprimir.Click
        Impresiones()
    End Sub
    Private Sub Impresiones()
        Dim imprimir As New clsReportes
        Dim numero As Integer
        Dim anio As Integer

        numero = celdaNumero.Text
        anio = celdaAño.Text
        If intTipo = 2 Then
            If Sesion.IdEmpresa = 16 Then
                FacturaFiscal()
                ' imprimir.FacturaSimpleCMC(numero, anio)
            Else
                FacturaSimpleCMC()
            End If
        ElseIf intTipo = 1 Then
            FacturaFiscal()
        ElseIf intTipo = 0 Then
            'imprimir.FacturaCMC(numero, anio)
            FacturaCMC()
        End If

    End Sub

    Private Sub botonRefacturar_Click(sender As Object, e As EventArgs) Handles botonRefacturar.Click
        If botonRefacturar.BackColor = Color.LightSkyBlue Then
            botonRefacturar.BackColor = Color.LightGray
        Else
            botonRefacturar.BackColor = Color.LightSkyBlue
        End If
    End Sub

    Private Sub BorrarHDR(ByVal cat As Integer)
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = cat
            hdr.HDOC_DOC_ANO = celdaAño.Text

            If cat = 296 Then
                hdr.HDOC_DOC_NUM = celdaNumero.Text
            Else
                hdr.HDOC_DOC_NUM = celdaOrden.Text
            End If
            hdr.Borrar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDTL(ByVal cat As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Cat = {cat} AND DDoc_Doc_Ano  = {anio}   AND DDoc_Doc_Num  = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{cat}", cat)
            If cat = 296 Then
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            Else
                strSQL = Replace(strSQL, "{numero}", celdaOrden.Text)
            End If

            Dim dtl As New clsDcmtos_DTL
            dtl.CONEXION = strConexion
            dtl.Borrar(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarIMP(ByVal cat As Integer)
        Dim strSQL As String = STR_VACIO

        Try
            strSQL = "MDoc_Sis_Emp = {empresa}  AND MDoc_Doc_Cat = {cat} AND MDoc_Doc_Ano = {anio} AND MDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
            strSQL = Replace(strSQL, "{cat}", cat)
            If cat = 296 Then
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            Else
                strSQL = Replace(strSQL, "{numero}", celdaOrden.Text)
            End If
            Dim imp As New Tablas.TDCMTOS_IMP
            imp.CONEXION = strConexion
            imp.PDELETE(strSQL)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDTL_PRO(ByVal cat As Integer)
        Dim strSQl As String = STR_VACIO
        Try

            strSQl = "PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = {cat} AND PDoc_Chi_Ano  = {anio} AND PDoc_Chi_Num = {numero}  "
            strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
            strSQl = Replace(strSQl, "{cat}", cat)
            If cat = 296 Then
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
            Else
                strSQl = Replace(strSQl, "{numero}", celdaOrden.Text)
            End If

            Dim pro As New clsDcmtos_DTL_Pro
            pro.CONEXION = strConexion
            pro.Borrar(strSQl)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarDTL_BOX(ByVal cat As Integer)
        Dim strSQl As String = STR_VACIO
        Try
            '   For i = 0 To dgDetalle.Rows.Count - 1
            strSQl = "BDoc_Sis_Emp = {empresa} AND BDoc_Doc_Cat = {cat} AND BDoc_Doc_Ano  = {anio} AND BDoc_Doc_Num = {numero}  "
            strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
            strSQl = Replace(strSQl, "{cat}", cat)
            If cat = 296 Then
                strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)
            Else
                strSQl = Replace(strSQl, "{numero}", celdaOrden.Text)
            End If

            Dim box As New Tablas.TDCMTOS_DTL_BOX
            box.CONEXION = strConexion
            box.PDELETE(strSQl)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub BorrarCtaCorriente()
        Dim strSQl As String = STR_VACIO
        Try
            '   For i = 0 To dgDetalle.Rows.Count - 1
            strSQl = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 296 AND ECta_Doc_Ano  = {anio} AND ECta_Doc_Num = {numero}  "
            strSQl = Replace(strSQl, "{empresa}", Sesion.IdEmpresa)
            strSQl = Replace(strSQl, "{anio}", celdaAño.Text)
            strSQl = Replace(strSQl, "{numero}", celdaNumero.Text)

            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQl)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            If MsgBox("You are sure you want to Delete the Registry", vbYesNo, "Question") = vbYes Then
                BorrarHDR(296)
                BorrarDTL(296)
                BorrarIMP(296)
                BorrarDTL_PRO(296)
                BorrarDTL_BOX(296)
                BorrarCtaCorriente()
                cfun.BorrarEncabezadoPoliza(celdaNumero.Text, celdaAño.Text, 296)
                cfun.BorrarDetallePoliza(celdaNumero.Text, celdaAño.Text, 296)
                ' Borrar 303
                BorrarHDR(303)
                BorrarDTL(303)
                BorrarIMP(303)
                BorrarDTL_PRO(303)

                MsgBox("Registry Deleted Correctly", vbInformation, "Notice")
                MostrarLista()
            End If
            ' Borrar 296

        Else
            MsgBox("You don't have permission to this action", vbInformation, "Notice")
        End If

    End Sub

    Private Sub botonPrevio_Click(sender As Object, e As EventArgs) Handles botonPrevio.Click
        If intTipo = 2 Then
            Dim strSQL As String = STR_VACIO
            Dim repCR As New FacturaSimpleCMC
            strSQL = " SELECT HDoc_Doc_Num Numero,HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total, "
            strSQL &= "     Day(HDoc_Doc_Fec) Dia , MONTH(HDoc_Doc_Fec) Mes , YEAR(HDoc_Doc_Fec) Anio,  HDoc_Doc_Status STATUS, IFNULL(d.DDoc_Prd_Des, 'N/A') descripcion, "
            strSQL &= "         c.cat_clave  , IFNULL(d.DDoc_RF1_Dbl,0) subTotal ,IFNULL(CAST(GROUP_CONCAT(DISTINCT p.PDoc_Par_Num) AS CHAR),' . ') Documentos, IFNULL (HDoc_RF1_Txt,'/') Texto "
            strSQL &= "             FROM Dcmtos_HDR "
            strSQL &= "                 LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = HDoc_Sis_Emp AND d.DDoc_Doc_Cat = HDoc_Doc_Cat AND d.DDoc_Doc_Ano = HDoc_Doc_Ano AND d.DDoc_Doc_Num = HDoc_Doc_Num "
            strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Ano = HDoc_Doc_Ano AND p.PDoc_Chi_Num = HDoc_Doc_Num "
            strSQL &= "      LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
            strSQL &= " WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

            If BuscarRegistrosSimpleCMC(strSQL) = True Then
            End If
            repCR.Load("C:\XML\DcmtosHDRCMC.xml")
            Dim frm3 As New FrmFacturaCMC
            frm3.CrystalReportViewer1.ReportSource = repCR
            frm3.Reporte_A_Ver_FacturaCMC = repCR
            frm3.CrystalReportViewer1.RefreshReport()
            frm3.ShowDialog(Me)
            My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRSIMPLECMC.xml")
            My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRSIMPLELS.xml")
        ElseIf intTipo = 1 Then
        ElseIf intTipo = 0 Then
            'imprimir.FacturaCMC(numero, anio)
            Dim strSQL As String
            Dim Eleccion As Integer
            Dim frm As New frmOption
            Dim repCR As New FacturaCMC
            frm.Opciones = "Recovery Order |" & "Consignment note |" & "Policy"
            frm.Titulo = "Print reference"
            frm.Mensaje = "Select an Option"
            'frm.ShowDialog(Me)
            If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case frm.Seleccion
                    Case 0
                        Eleccion = 0
                    Case 1
                        Eleccion = 1
                    Case 2
                        Eleccion = 3
                End Select
            Else
                Exit Sub

            End If
            strSQL = " SELECT HDoc_Doc_Num Numero,HDoc_Emp_NIT NIT, IFNULL(HDoc_DR2_Num, HDoc_Emp_Nom)Nombre, IFNULL(HDoc_RF1_Cod,HDoc_Emp_Dir)Dic, HDoc_RF1_Dbl Total,DAY(HDoc_Doc_Fec) Dia, "
            strSQL &= "     MONTH(HDoc_Doc_Fec) Mes , YEAR(HDoc_Doc_Fec) Anio  , HDoc_Doc_Status STATUS, IFNULL (HDoc_RF1_Txt,'/') Texto , "
            strSQL &= "         CAST(GROUP_CONCAT(DISTINCT p.PDoc_Par_Num) AS CHAR) Documentos, "
            strSQL &= "             SUM(d.DDoc_RF1_Dbl) Flete, SUM(d.DDoc_RF2_Dbl) AgenteAduana, SUM(d.DDoc_RF3_Dbl) Gestiones, c.cat_clave  Moneda "
            strSQL &= "                 FROM Dcmtos_HDR "
            strSQL &= "             LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = HDoc_Sis_Emp AND p.PDoc_Chi_Cat = HDoc_Doc_Cat AND p.PDoc_Chi_Num = HDoc_Doc_Num  "
            strSQL &= "         LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = p.PDoc_Sis_Emp AND d.DDoc_Doc_Cat = p.PDoc_Par_Cat AND d.DDoc_Doc_Ano = p.PDoc_Par_Ano AND d.DDoc_Doc_Num = p.PDoc_Par_Num "
            strSQL &= "     LEFT JOIN Catalogos c ON c.cat_num = HDoc_Doc_Mon AND c.cat_clase = 'Monedas' "
            strSQL &= "  WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 296 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {numero} AND p.PDoc_Par_Lin = 1  "

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
            strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

            If BuscarRegistrosFacturaCMC(strSQL) = True Then
            End If
            repCR.Load("C:\XML\DcmtosHDRCMC.xml")
            Dim frm3 As New FrmFacturaCMC
            frm3.Reporte_A_Ver_FacturaCMC = repCR
            frm3.CrystalReportViewer1.RefreshReport()
            frm3.ShowDialog(Me)
            My.Computer.FileSystem.DeleteFile("C:\XML\DcmtosHDRCMC.xml")
        End If
    End Sub

    Private Sub checkActivar_CheckedChanged(sender As Object, e As EventArgs) Handles checkActivar.CheckedChanged
        If Sesion.IdEmpresa = 10 Then
            If checkActivar.Checked = True Then
                Encabezado1.botonGuardar.Enabled = False
            Else
                Encabezado1.botonGuardar.Enabled = True
            End If
        End If
    End Sub

    Private Sub dtpFecha_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha.ValueChanged
        If celdaTasa.Text > 1 Then
            celdaTasa.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub
#End Region

#Region "conexión hilos"


    Private Sub RelacionatedData(ByVal ano As Integer, ByVal num As Integer)
        Dim strLinea As String = STR_VACIO
        cfun.sesionHilos()


        Dim connectionStringBaseOF As String = "server=" & CMC_Hilos_Host & ";Port=" & CMC_Hilos_PORT & ";database=" & CMC_Hilos_BASE & ";uid=" & CMC_Hilos_USER & ";password=" & CMC_Hilos_PASS & ";"
        Dim connectionStringBase As String = strConexion

        ' Variables para los parámetros
        Dim empresa As Integer = Sesion.IdEmpresa
        Dim numero As Integer = num
        Dim empresaRel As Integer = 12

        ' Consulta en baseOF hilos
        Dim queryBaseOF As String = "SELECT 
	                            IFNULL(hr.HDoc_Doc_Ano,0) AS ano, 
	                            IFNULL(hr.HDoc_Doc_Num,0) AS numero, 
	                            IFNULL(hr.HDoc_Doc_Fec,'') AS fecha, 
	                            IFNULL(hr.HDoc_DR1_Num,'') AS referencia, 
	                            IFNULL(SUM(IF(dr.DDoc_Prd_UM = cc.cat_num, dr.DDoc_Prd_QTY, (dr.DDoc_Prd_QTY / cc.cat_sist))),0) AS peso,
	                            IFNULL(hr.HDoc_Sis_Emp,0) HDoc_Sis_Emp,
	                            IFNULL(hr.HDoc_Doc_Cat,0) HDoc_Doc_Cat,
	                            IFNULL(hr.HDoc_Doc_Ano,0) AS HDoc_Doc_Ano, 
	                            IFNULL(hr.HDoc_Doc_Num,0) AS HDoc_Doc_Num
	
                            FROM {base}.Dcmtos_HDR hr
                            LEFT JOIN {base}.Dcmtos_DTL dr ON dr.DDoc_Sis_Emp = hr.HDoc_Sis_Emp AND dr.DDoc_Doc_Cat = hr.HDoc_Doc_Cat AND dr.DDoc_Doc_Ano = hr.HDoc_Doc_Ano 
	                            AND dr.DDoc_Doc_Num = hr.HDoc_Doc_Num 
                            LEFT JOIN {base}.Catalogos c ON c.cat_num = dr.DDoc_Prd_UM AND c.cat_clase = 'Medidas' 
                            LEFT JOIN {base}.Catalogos cc ON cc.cat_clase = 'Medidas' AND cc.cat_clave = 'KGS' 
                            WHERE hr.HDoc_Sis_Emp = @empresarel AND hr.HDoc_Doc_Cat = 36 -- AND hr.HDoc_Emp_Cod=" & celdaIdCliente.Text & "
                            GROUP BY hr.HDoc_Sis_Emp, hr.HDoc_Doc_Cat, hr.HDoc_Doc_Ano, hr.HDoc_Doc_Num"
        queryBaseOF = Replace(queryBaseOF, "{base}", strBaseRel)
        ' Consulta en base
        Dim queryBase As String = "SELECT 
	                            h.HDoc_Doc_Status AS estado, 
	                            p.PDoc_Par_Cat HDoc_Doc_Cat, 
	                            p.PDoc_Par_Ano HDoc_Doc_Ano, 
	                            p.PDoc_Par_Num HDoc_Doc_Num
                            FROM Dcmtos_HDR h 
                            LEFT JOIN Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano 
	                            AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = hh.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = hh.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = hh.HDoc_Doc_Ano 
	                            AND p.PDoc_Chi_Num = hh.HDoc_Doc_Num AND p.PDoc_Par_Cat = 36 
                            WHERE h.HDoc_Doc_Cat = 296  AND h.HDoc_Emp_Cod=" & celdaIdCliente.Text & " AND h.HDoc_Doc_Num=" & celdaNumero.Text

        Using connectionBaseOF As New MySqlConnection(connectionStringBaseOF)
            Using connectionBase As New MySqlConnection(connectionStringBase)
                Try
                    ' Abre las conexiones
                    connectionBaseOF.Open()
                    connectionBase.Open()

                    ' Ejecuta la consulta en baseOF
                    Dim commandBaseOF As New MySqlCommand(queryBaseOF, connectionBaseOF)
                    commandBaseOF.Parameters.AddWithValue("@empresa", empresa)
                    commandBaseOF.Parameters.AddWithValue("@empresarel", empresaRel)
                    commandBaseOF.Parameters.AddWithValue("@ano", ano)
                    commandBaseOF.Parameters.AddWithValue("@numero", numero)

                    Dim dataTableBaseOF As New System.Data.DataTable()
                    Using readerBaseOF As MySqlDataReader = commandBaseOF.ExecuteReader()
                        dataTableBaseOF.Load(readerBaseOF)
                    End Using

                    ' Ejecuta la consulta en base
                    Dim commandBase As New MySqlCommand(queryBase, connectionBase)
                    commandBase.Parameters.AddWithValue("@empresarel", empresaRel)

                    Dim dataTableBase As New System.Data.DataTable()
                    Using readerBase As MySqlDataReader = commandBase.ExecuteReader()
                        dataTableBase.Load(readerBase)
                    End Using

                    ' Combina los resultados
                    Dim combinedResults As New List(Of Object)() ' Cambia a tu estructura deseada

                    For Each rowBaseOF As DataRow In dataTableBaseOF.Rows
                        For Each rowBase As DataRow In dataTableBase.Rows

                            If (rowBaseOF("HDoc_Doc_Cat") = rowBase("HDoc_Doc_Cat") And
                                rowBaseOF("HDoc_Doc_Ano") = rowBase("HDoc_Doc_Ano") And
                                rowBaseOF("HDoc_Doc_Num") = rowBase("HDoc_Doc_Num")) Then
                                combinedResults.Add(New With {
                                    .Estado = rowBase("estado"),
                                    .Ano = rowBaseOF("ano"),
                                    .Numero = rowBaseOF("numero"),
                                    .Fecha = rowBaseOF("fecha"),
                                    .Referencia = rowBaseOF("referencia"),
                                    .Peso = rowBaseOF("peso")
                                })
                            End If
                        Next
                    Next

                    ' Muestra los resultados combinados (ajusta según tu necesidad)
                    For Each result In combinedResults
                        Console.WriteLine($"Estado: {result.Estado}, Año: {result.Ano}, Número: {result.Numero}, Fecha: {result.Fecha}, Referencia: {result.Referencia}, Peso: {result.Peso}")

                        If result.Estado = 1 Then
                            strLinea = result.Ano & "|"
                            If result.Numero = INT_CERO Then
                                strLinea &= "|"
                            Else
                                strLinea &= result.Numero & "|"
                            End If
                            strLinea &= result.Fecha.ToString & "|"
                            strLinea &= result.Referencia & "|"
                            strLinea &= result.Peso.ToString

                            cfun.AgregarFila(dgFactrura, strLinea)
                        End If

                    Next


                Catch ex As MySqlException
                    ' Manejo de errores
                    MessageBox.Show("Error: " & ex.Message)
                End Try
                Exit Sub
            End Using
        End Using
    End Sub
    Private Sub relationeButton(ByVal ano As Integer, ByVal num As Integer)

        Dim strLinea As String = STR_VACIO
        cfun.sesionHilos()

        Dim connectionStringBaseOF As String = "server=" & CMC_Hilos_Host & ";Port=" & CMC_Hilos_PORT & ";database=" & CMC_Hilos_BASE & ";uid=" & CMC_Hilos_USER & ";password=" & CMC_Hilos_PASS & ";"
        Dim connectionStringBase As String = strConexion

        ' Variables para los parámetros
        Dim empresa As Integer = Sesion.IdEmpresa
        Dim numero As Integer = num
        Dim empresaRel As Integer = 12

        ' Consulta en baseOF hilos
        Dim queryBaseOF As String = " SELECT 
                                h.HDoc_Doc_Status AS estado, 
                                hh.HDoc_Doc_Cat,
                                hh.HDoc_Doc_Ano,
                                hh.HDoc_Doc_Num
                            FROM {base}.Dcmtos_HDR h 
                            LEFT JOIN {base}.Dcmtos_HDR hh ON hh.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND hh.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND hh.HDoc_Pro_DAno = h.HDoc_Doc_Ano 
                             AND hh.HDoc_Pro_DNum = h.HDoc_Doc_Num
                            LEFT JOIN {base}.Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = hh.HDoc_Sis_Emp AND p.PDoc_Chi_Cat = hh.HDoc_Doc_Cat AND p.PDoc_Chi_Ano = hh.HDoc_Doc_Ano 
                             AND p.PDoc_Chi_Num = hh.HDoc_Doc_Num AND p.PDoc_Par_Cat = 36 
                            WHERE h.HDoc_Sis_Emp = 12 AND h.HDoc_Doc_Cat = 296  AND h.HDoc_Emp_Cod=505 AND h.HDoc_Doc_Num=17787;"
        queryBaseOF = Replace(queryBaseOF, "{base}", strBaseRel)
        ' Consulta en base
        Dim queryBase As String = "SELECT 
                             p.PDoc_Chi_Cat,
                             p.PDoc_Chi_Ano, 
                             p.PDoc_Chi_Num,
                             p.PDoc_Par_Cat HDoc_Doc_Cat, 
                             p.PDoc_Par_Ano HDoc_Doc_Ano, 
                             p.PDoc_Par_Num HDoc_Doc_Num
                            FROM  Dcmtos_DTL_Pro p 
                            WHERE p.PDoc_Sis_Emp = " & Sesion.IdEmpresa & " AND  p.PDoc_Par_Cat = 36  ;"

        Using connectionBaseOF As New MySqlConnection(connectionStringBaseOF)
            Using connectionBase As New MySqlConnection(connectionStringBase)
                Try
                    ' Abre las conexiones
                    connectionBaseOF.Open()
                    connectionBase.Open()

                    ' Ejecuta la consulta en baseOF
                    Dim commandBaseOF As New MySqlCommand(queryBaseOF, connectionBaseOF)
                    commandBaseOF.Parameters.AddWithValue("@empresa", empresa)
                    commandBaseOF.Parameters.AddWithValue("@empresarel", empresaRel)
                    commandBaseOF.Parameters.AddWithValue("@ano", ano)
                    commandBaseOF.Parameters.AddWithValue("@numero", numero)

                    Dim dataTableBaseOF As New System.Data.DataTable()
                    Using readerBaseOF As MySqlDataReader = commandBaseOF.ExecuteReader()
                        dataTableBaseOF.Load(readerBaseOF)
                    End Using

                    ' Ejecuta la consulta en base
                    Dim commandBase As New MySqlCommand(queryBase, connectionBase)
                    commandBase.Parameters.AddWithValue("@empresarel", empresaRel)

                    Dim dataTableBase As New System.Data.DataTable()
                    Using readerBase As MySqlDataReader = commandBase.ExecuteReader()
                        dataTableBase.Load(readerBase)
                    End Using

                    ' Combina los resultados
                    Dim combinedResults As New List(Of Object)() ' Cambia a tu estructura deseada

                    For Each rowBaseOF As DataRow In dataTableBaseOF.Rows
                        For Each rowBase As DataRow In dataTableBase.Rows

                            If (rowBaseOF("HDoc_Doc_Cat") = rowBase("PDoc_Chi_Cat") And
                                rowBaseOF("HDoc_Doc_Ano") = rowBase("PDoc_Chi_Ano") And
                                rowBaseOF("HDoc_Doc_Num") = rowBase("PDoc_Chi_Num")) Then
                                combinedResults.Add(New With {
                                    .Estado = rowBase("estado"),
                                    .Ano = rowBaseOF("ano"),
                                    .Numero = rowBaseOF("numero"),
                                    .Fecha = rowBaseOF("fecha"),
                                    .Referencia = rowBaseOF("referencia"),
                                    .Peso = rowBaseOF("peso")
                                })
                            End If
                        Next
                    Next

                    ' Muestra los resultados combinados (ajusta según tu necesidad)
                    For Each result In combinedResults
                        Console.WriteLine($"Estado: {result.Estado}, Año: {result.Ano}, Número: {result.Numero}, Fecha: {result.Fecha}, Referencia: {result.Referencia}, Peso: {result.Peso}")

                        If result.Estado = 1 Then
                            strLinea = result.Ano & "|"
                            If result.Numero = INT_CERO Then
                                strLinea &= "|"
                            Else
                                strLinea &= result.Numero & "|"
                            End If
                            strLinea &= result.Fecha.ToString & "|"
                            strLinea &= result.Referencia & "|"
                            strLinea &= result.Peso.ToString

                            cfun.AgregarFila(dgFactrura, strLinea)
                        End If

                    Next


                Catch ex As MySqlException
                    ' Manejo de errores
                    MessageBox.Show("Error: " & ex.Message)
                End Try
                Exit Sub
            End Using
        End Using
    End Sub

#End Region
End Class