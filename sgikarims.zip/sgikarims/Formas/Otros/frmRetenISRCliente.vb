﻿Public Class frmRetenISRCliente

#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True

        End If
    End Sub
    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Function SQLListaPrincipal()
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT h.HDoc_Doc_Num Numero, h.HDoc_Doc_Ano Anio, IF(h.HDoc_DR1_Num = '',h.HDoc_Doc_Num,h.HDoc_DR1_Num) Documento, h.HDoc_Doc_Fec Fecha, h.HDoc_Emp_Nom Nombre, h.HDoc_RF1_Dbl Monto, h.HDoc_DR2_Num Factura, d.HDoc_RF1_Dbl Total, h.HDoc_Doc_Status Estado "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        Left JOIN Dcmtos_HDR d ON d.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.HDoc_Doc_Cat = h.HDoc_Pro_DCat AND d.HDoc_Doc_Ano = h.HDoc_Pro_DAno AND d.HDoc_Doc_Num = h.HDoc_Pro_DNum "
        strSQL &= "            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 733 AND h.HDoc_Ant_Com =0 "

        If checkFecha.Checked = True Then
            strSQL &= " AND (h.HDoc_Doc_Fec BETWEEN '{inicio}' AND '{final}') "
            strSQL = Replace(strSQL, "{inicio}", dtpFechaInicial.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{final}", dtpFechaFinal.Value.ToString(FORMATO_MYSQL))

        End If
        strSQL &= "                ORDER BY h.HDoc_Doc_Fec DESC, h.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)

        Return strSQL
    End Function

    Private Function SQLCargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        strSQL = " SELECT h.HDoc_Sis_Emp empresa, h.HDoc_Doc_Cat cat, h.HDoc_Doc_Ano anio, h.HDoc_Doc_Num numero, h.HDoc_Doc_Fec fecha, h.HDoc_Emp_Cod cod, h.HDoc_Emp_Nom proveedor, h.HDoc_Doc_Mon moneda, h.HDoc_Doc_TC TC, h.HDoc_RF1_Dbl total, h.HDoc_Pro_DCat catF, h.HDoc_Pro_DAno anioF, h.HDoc_Pro_DNum numF, IF(h.HDoc_DR1_Num = '',h.HDoc_Doc_Num,h.HDoc_DR1_Num) retencion, HDoc_DR1_Cat tipoFac "
        strSQL &= "    From Dcmtos_HDR h "
        strSQL &= "        WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 733 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "
        strSQL &= "            LIMIT 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)
        Return strSQL
    End Function

    Private Function SQLCargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO

        If Sesion.IdEmpresa = 10 Then
            strSQL = " SELECT e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num Numero, e.HDoc_Doc_Fec Fecha, e.HDoc_Usuario Usuario, e.HDoc_DR1_Num Referencia, e.HDoc_RF1_Dbl Monto, e.HDoc_Doc_Mon moneda, e.HDoc_Doc_TC TC "
            strSQL &= "    FROM ECtaCte c "
            strSQL &= "    INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.ECta_Sis_Emp AND e.HDoc_Doc_Cat = c.ECta_Ref_Cat AND e.HDoc_Doc_Ano = c.ECta_Ref_Ano AND e.HDoc_Doc_Num = c.ECta_Ref_Num "
        Else
            strSQL = " SELECT e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num Numero, e.HDoc_Doc_Fec Fecha, e.HDoc_Usuario Usuario, h.HDoc_DR2_Num, (d.DDoc_Prd_NET * d.DDoc_Prd_QTY * e.HDoc_Doc_TC) Monto, e.HDoc_Doc_Mon moneda, e.HDoc_Doc_TC TC
                            FROM ECtaCte c
                            INNER JOIN Dcmtos_HDR e ON e.HDoc_Sis_Emp = c.ECta_Sis_Emp AND e.HDoc_Doc_Cat = c.ECta_Ref_Cat AND e.HDoc_Doc_Ano = c.ECta_Ref_Ano AND e.HDoc_Doc_Num = c.ECta_Ref_Num
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = e.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = e.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = e.HDoc_Doc_Ano AND d.DDoc_Doc_Num = e.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = c.ECta_Sis_Emp AND h.HDoc_Doc_Cat = c.ECta_Doc_Cat AND h.HDoc_Doc_Ano = c.ECta_Doc_Ano AND h.HDoc_Doc_Num = c.ECta_Doc_Num"
        End If
        strSQL &= "        WHERE c.ECta_Sis_Emp = {empresa} AND c.ECta_Doc_Cat = 733 AND c.ECta_Doc_Ano = {anio} AND c.ECta_Doc_Num = {num} "
        strSQL &= "        ORDER BY e.HDoc_Doc_Fec DESC, e.HDoc_Doc_Num DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", intAnio)
        strSQL = Replace(strSQL, "{num}", intNum)

        Return strSQL
    End Function

    Private Function SQLCargarPagos(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSLQ As String = STR_VACIO

        strSLQ = " SELECT HDoc_DR1_Num cheque, HDoc_Doc_Fec fecha,cat_clave moneda ,HDoc_Doc_TC tasa, CONCAT(Bcta_Des_Cue,' ',BCta_Num_Cue) cuenta ,DDoc_RF1_Dbl total "
        strSLQ &= "    From Dcmtos_HDR "
        strSLQ &= "        Left JOIN Dcmtos_DTL ON DDoc_Sis_Emp = HDoc_Sis_Emp AND DDoc_Doc_Cat = HDoc_Doc_Cat AND DDoc_Doc_Ano = HDoc_Doc_Ano AND DDoc_Doc_Num = HDoc_Doc_Num "
        strSLQ &= "            Left JOIN Catalogos ON cat_num = HDoc_Doc_Mon "
        strSLQ &= "                Left JOIN CtasBcos ON BCta_Num = HDoc_RF1_Num "
        strSLQ &= "                    WHERE DDoc_Sis_Emp = {empresa} AND DDoc_RF1_Num = 733 AND DDoc_RF2_Num = {anio} and DDoc_RF3_Num= {num} "

        strSLQ = Replace(strSLQ, "{empresa}", Sesion.IdEmpresa)
        strSLQ = Replace(strSLQ, "{anio}", intAnio)
        strSLQ = Replace(strSLQ, "{num}", intNum)

        Return strSLQ

    End Function

    Private Function SQLMostrarFacturas()
        Dim strSQL As String = STR_VACIO

        If Sesion.IdEmpresa = 10 Then
            strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, h.HDoc_DR1_Num NumFac, IFNULL(h.HDoc_DR2_Num,'') Serie, h.HDoc_RF1_Dbl Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp "
            strSQL &= "    From Dcmtos_HDR h "
            strSQL &= "        LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Doc_Cat = 733 AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num "
            strSQL &= "           LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon and c.cat_clase = 'Monedas' "
        Else
            strSQL = " SELECT h.HDoc_Doc_Ano anio, h.HDoc_Doc_Fec fecha, h.HDoc_Doc_Num numero, h.HDoc_Usuario, f.NumeroAutorizacion NumFac, IFNULL(f.Serie,'') Serie, (d.DDoc_Prd_Net * d.DDoc_Prd_QTY * h.HDoc_Doc_TC) Monto, h.HDoc_Doc_TC TC, c.cat_clave Moneda, h.HDoc_Ant_Com FactEsp
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Dcmtos_HDR r ON r.HDoc_Sis_Emp = h.HDoc_Sis_Emp AND r.HDoc_Doc_Cat = 733 AND r.HDoc_Pro_DCat = h.HDoc_Doc_Cat AND r.HDoc_Pro_DAno = h.HDoc_Doc_Ano AND r.HDoc_Pro_DNum = h.HDoc_Doc_Num 
                            LEFT JOIN Fel f ON f.Empresa = h.HDoc_Sis_Emp AND f.Catalogo = h.HDoc_Doc_Cat AND f.Anio = h.HDoc_Doc_Ano AND f.Numero = h.HDoc_Doc_Num
                            LEFT JOIN Catalogos c ON c.cat_num = h.HDoc_Doc_Mon AND c.cat_clase = 'Monedas'"
        End If

        strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Emp_Cod ={cod} AND h.HDoc_Doc_Fec > '{fecha}' AND r.HDoc_Sis_Emp IS NULL Order By h.HDoc_Doc_Fec DESC "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cod}", celdaIdProveedor.Text)
        strSQL = Replace(strSQL, "{fecha}", DateSerial(Year(Date.Now), Month(Date.Now) - 4, 1).ToString(FORMATO_MYSQL))

        If Sesion.IdEmpresa = 10 Then
            strSQL = Replace(strSQL, "{cat}", 296)
        Else
            strSQL = Replace(strSQL, "{cat}", 36)
        End If

        Return strSQL
    End Function
    Public Sub ListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLListaPrincipal()

            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            dgLista.Rows.Clear()
            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read

                    strFila = REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Documento") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetString("Nombre") & "|"
                    strFila &= REA.GetDouble("Monto") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetDouble("Total") & "|"
                    strFila &= REA.GetInt32("Estado")

                    cFunciones.AgregarFila(dgLista, strFila)

                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            BarraTitulo1.CambiarTitulo("ISR Withholding Customer")
            ListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()
        Else
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True

            If logInsert = False Then
                BarraTitulo1.CambiarTitulo("Modify Registration")
                BloquearBotones(False)
            Else
                BarraTitulo1.CambiarTitulo("New Register")
                BloquearBotones(False)
            End If
        End If
    End Sub

    Private Sub CargarEncabezado(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        Try
            strSQL = SQLCargarEncabezado(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then

                REA.Read()

                celdaAnio.Text = REA.GetInt32("anio")
                dtpFechaDoc.Value = REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                celdaNumero.Text = REA.GetString("retencion")
                celdaProveedor.Text = REA.GetString("proveedor")
                celdaIdProveedor.Text = REA.GetInt32("cod")
                celdaMonto.Text = REA.GetDouble("total").ToString(FORMATO_MONEDA)
                celdaCatalogo.Text = REA.GetInt32("cat")
                celdaAnio.Text = REA.GetInt32("anio")
                celdaNumeroHDR.Text = REA.GetInt32("numero")
                celdaCatF.Text = REA.GetInt32("catF")
                celdaAnioF.Text = REA.GetInt32("anioF")
                'celdaNumF.Text = REA.GetInt32("numF")
                'If REA.GetInt32("tipoFac") = 1 Then
                '    checkFacturaEspecial.Checked = True
                'Else
                '    checkFacturaEspecial.Checked = False
                'End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarFactura(Optional intAnio As Integer = 0, Optional intNum As Integer = 0, Optional codigo As Integer = 0)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarFactura(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("Fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("Numero") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    If Sesion.IdEmpresa = 10 Then
                        strFila &= REA.GetString("Numero") & "|"
                    Else
                        strFila &= REA.GetString("HDoc_DR2_Num") & "|"
                    End If
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    'If checkFacturaEspecial.Checked = True Then
                    '    strFila &= 1 & "|"
                    'Else
                    strFila &= 0 & "|"
                    'End If
                    strFila &= 1 ' 1 actualizar, 0 insertar

                    cFunciones.AgregarFila(dgFactura, strFila)
                    celdaIDMoneda.Text = cFunciones.DivisaLocal
                    celdaTipoCambio.Text = 1
                    If Sesion.IdEmpresa = 10 Then
                        celdaCatF.Text = 296
                    Else
                        celdaCatF.Text = 36
                    End If
                    celdaAnioF.Text = REA.GetInt32("anio")
                    celdaNumF.Text = REA.GetInt32("numero")
                    celdaTCFactura.Text = REA.GetDouble("TC")
                    celdaMontoF.Text = REA.GetDouble("Monto")

                Loop
                celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub CargarPago(ByVal intAnio As Integer, ByVal intNum As Integer)
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLCargarPagos(intAnio, intNum)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetString("cheque") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL)
                    strFila &= REA.GetString("moneda") & "|"
                    strFila &= REA.GetDouble("tasa") & "|"
                    strFila &= REA.GetString("cuenta") & "|"
                    strFila &= REA.GetDouble("total")

                    cFunciones.AgregarFila(dgDatos, strFila)
                Loop
                celdaTotal.Text = CDbl(celdaMonto.Text) - CDbl(dgDatos.CurrentRow.Cells("colTota1").Value)
            Else
                celdaTotal.Text = CDbl(celdaMonto.Text)
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub MostrarFacturas()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strFila As String = STR_VACIO

        Try
            strSQL = SQLMostrarFacturas()

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            If REA.HasRows Then
                dgFactura.Rows.Clear()
                Do While REA.Read
                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetDateTime("fecha").ToString(FORMATO_MYSQL) & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetString("HDoc_Usuario") & "|"
                    If Sesion.IdEmpresa = 10 Then
                        strFila &= REA.GetString("numero") & " " & REA.GetString("Serie") & "|"
                    Else
                        strFila &= REA.GetString("NumFac") & " " & REA.GetString("Serie") & "|"
                    End If
                    strFila &= REA.GetDouble("Monto").ToString(FORMATO_MONEDA) & "|"
                    strFila &= REA.GetString("Moneda") & "|"
                    strFila &= REA.GetDouble("TC") & "|"
                    'strFila &= REA.GetInt32("FactEsp") & "|"
                    strFila &= 0 ' 1 actualizar, 0 insertar

                    cFunciones.AgregarFila(dgFactura, strFila)
                Loop

            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Function FactorISR() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim factor As Double = 0

        strSQL = " SELECT ROUND(a.cat_sist /100,2) factorISR "
        strSQL &= "    From Catalogos a "
        strSQL &= "        WHERE a.cat_clase='Impuestos' AND a.cat_sisemp = 0 AND a.cat_clave = 'ISR_RG' "

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        factor = COM.ExecuteScalar

        Return factor
    End Function

    Public Function VerificarIVA() As Double
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim IVA As Double = 0

        If Sesion.IdEmpresa = 10 Then
            strSQL = " SELECT IFNULL(SUM(MDoc_Lin_Monto),0) "
            strSQL &= "    From Dcmtos_IMP "
            strSQL &= "        WHERE MDoc_Sis_Emp={empresa} AND MDoc_Doc_Cat={cat} AND MDoc_Doc_Ano={anio} AND MDoc_Doc_Num={num} AND MDoc_Lin_Tipo= 0 "

            strSQL = Replace(strSQL, "{cat}", 296)
        Else
            strSQL = " SELECT ROUND((d.DDoc_Prd_NET * d.DDoc_Prd_QTY * h.HDoc_Doc_TC ) - ((d.DDoc_Prd_NET * d.DDoc_Prd_QTY * h.HDoc_Doc_TC) / ((c.cat_sist /100)+1)),2) IVA
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num
                            LEFT JOIN Catalogos c ON c.cat_clase = 'Impuestos' AND c.cat_clave ='IVA' AND c.cat_sisemp = {empresa}
                            WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = {cat} AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL = Replace(strSQL, "{cat}", 36)
        End If

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAnioF.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumF.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        IVA = COM.ExecuteScalar

        Return IVA
    End Function

    Public Sub LimpiarCampos()
        celdaAnio.Text = cFunciones.AñoMySQL
        celdaAnioOc.Clear()
        celdaCatalogo.Text = 733
        celdaMonto.Text = INT_CERO.ToString(FORMATO_MONEDA)
        celdaNumero.Clear()
        celdaNumeroHDR.Text = -1
        celdaProveedor.Clear()
        celdaTotal.Text = INT_CERO.ToString(FORMATO_MONEDA)
        dtpFechaDoc.Text = cFunciones.HoyMySQL.ToString(FORMATO_MYSQL)
        celdaMoneda.Clear()
        celdaIDMoneda.Clear()
        celdaTipoCambio.Clear()
        celdaTCFactura.Clear()
        'checkFacturaEspecial.Checked = False

        dgFactura.Rows.Clear()
        dgDatos.Rows.Clear()

    End Sub

    Private Function ComprobarCampos() As Boolean
        Dim comprobar As Boolean = True
        If celdaNumero.Text = vbNullString Then
            If MsgBox("You must enter the Withholding Number", vbOK, vbInformation) = vbOK Then
                celdaNumero.Focus()
                comprobar = False
            ElseIf celdaProveedor.Text = vbNullString Then
                If MsgBox("You must select a Customer", vbOK, vbInformation) = vbOK Then
                    botonProveedor.Focus()
                    comprobar = False
                End If
            ElseIf dgFactura.Rows.Count > 1 Then
                If MsgBox("Select an invoice please", vbOK, vbInformation) = vbOK Then
                    comprobar = False
                End If
            End If
        End If
        Return comprobar
    End Function
    Private Sub BorrarEncabezadoISRProveedor(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            Dim hdr As New clsDcmtos_HDR
            hdr.CONEXION = strConexion
            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 733
            hdr.HDOC_DOC_ANO = anio
            hdr.HDOC_DOC_NUM = num
            hdr.Borrar()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarRetencionHDR()
        Dim hdr As New clsDcmtos_HDR

        hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
        hdr.HDOC_DOC_CAT = 733
        hdr.HDOC_DOC_ANO = celdaAnio.Text
        hdr.HDOC_DOC_NUM = celdaNumeroHDR.Text
        hdr.HDoc_Doc_Fec_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        hdr.HDOC_EMP_COD = celdaIdProveedor.Text
        hdr.HDOC_EMP_NOM = celdaProveedor.Text
        hdr.HDOC_RF1_DBL = celdaMonto.Text
        hdr.HDOC_PRO_DCAT = celdaCatF.Text
        hdr.HDOC_PRO_DNUM = celdaNumF.Text
        hdr.HDOC_PRO_DANO = celdaAnioF.Text
        hdr.HDOC_DR1_NUM = celdaNumero.Text
        'hdr.HDOC_DR1_CAT = IIf(checkFacturaEspecial.Checked = True, INT_UNO, INT_CERO)
        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 0 Or dgFactura.Rows(i).Cells("colExtraFact").Value = 1 Then
                hdr.HDOC_DR2_NUM = dgFactura.Rows(i).Cells("colREferenciaFac").Value
                hdr.HDOC_RF1_TXT = dgFactura.Rows(i).Cells("colMonedaFac").Value
            Else
            End If
        Next
        hdr.HDOC_DOC_MON = celdaIDMoneda.Text
        hdr.HDOC_DOC_TC = celdaTipoCambio.Text
        hdr.HDOC_USUARIO = Sesion.Usuario
        hdr.HDOC_DOC_STATUS = INT_CERO
        hdr.HDOC_ANT_COM = INT_CERO

        hdr.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then

            If hdr.Guardar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If

        Else
            If hdr.Actualizar() = False Then
                MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        End If
    End Sub
    Private Sub BorrarEctateRetenISR(ByVal num As Integer, ByVal anio As Integer)
        Dim strSQL As String = STR_VACIO
        Try
            strSQL = "ECta_Sis_Emp = {empresa} AND ECta_Doc_Cat = 733 AND ECta_Doc_Ano = {anio} AND ECta_Doc_Num = {numero} "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            Dim ectacte As New Tablas.TECTACTE
            ectacte.CONEXION = strConexion
            ectacte.PDELETE(strSQL)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub GuardarCuentaXPagar()
        Dim ect As New Tablas.TECTACTE

        ect.ECTA_SIS_EMP = Sesion.IdEmpresa
        ect.ECTA_DOC_CAT = 733
        ect.ECTA_DOC_ANO = celdaAnio.Text
        ect.ECTA_DOC_NUM = celdaNumeroHDR.Text
        ect.ECTA_DOC_LIN = INT_UNO
        ect.ECTA_TIPOEMP = "Clientes"
        ect.ECTA_CODEMP = celdaIdProveedor.Text
        ect.ECTA_SINI_LOC = INT_CERO
        ect.ECTA_CRGO_LOC = INT_CERO
        ect.ECTA_ABNO_LOC = celdaMonto.Text
        ect.ECTA_SINI_EXT = INT_CERO
        ect.ECTA_CRGO_EXT = INT_CERO
        For i As Integer = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 0 Then
                ect.ECTA_ABNO_EXT = ((celdaMonto.Text) / CDbl(dgFactura.Rows(i).Cells("colTCFac").Value))
                ect.ECTA_CONCEPTO = "Retencion ISR / Factura " & dgFactura.Rows(i).Cells("colREferenciaFac").Value
            Else
            End If
        Next
        ect.ECta_FecDcmt_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECta_FecVenc_NET = dtpFechaDoc.Value.ToString(FORMATO_MYSQL)
        ect.ECTA_MONEDA = celdaIDMoneda.Text
        ect.ECTA_TC = celdaTipoCambio.Text
        ect.ECTA_REF_CAT = celdaCatF.Text
        ect.ECTA_REF_ANO = celdaAnioF.Text
        ect.ECTA_REF_NUM = celdaNumF.Text

        ect.CONEXION = strConexion

        If Me.Tag = "Nuevo" Then
            If ect.PINSERT = False Then
                MsgBox(ect.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
            End If
        Else
            If ect.PUPDATE = False Then
                MsgBox(ect.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
            End If
        End If

    End Sub
    Private Function ValidarRetencionIvaProveedor(ByVal num As Integer, ByVal anio As Integer) As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim logValidar As Integer = INT_CERO

        Try
            strSQL = " SELECT COUNT(*) "
            strSQL &= "     FROM Dcmtos_HDR h "
            strSQL &= "         WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 733 AND h.HDoc_Doc_Ano = {anio} AND h.HDoc_Doc_Num = {numero} AND h.HDoc_Doc_Status = 1 "
            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{anio}", anio)
            strSQL = Replace(strSQL, "{numero}", num)
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            logValidar = COM.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logValidar
    End Function
#End Region

#Region "Eventos"
    Private Sub frmRetenISRCliente_Load(sender As Object, e As EventArgs) Handles Me.Load
        dtpFechaInicial.Value = DateSerial(Year(Date.Now), Month(Date.Now) - 1, 1)
        dtpFechaFinal.Value = Today  'DateSerial(Year(Date.Now), Month(Date.Now) + 1, vbEmpty)

        MostrarLista()
        Accessos()
    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Else
            MostrarLista()
        End If
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click

        If CDate(dtpFechaInicial.Value) > CDate(dtpFechaFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
        Else
            ListaPrincipal()
        End If

    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Dim intAnio As Integer = 0
        Dim intNum As Integer = 0

        LimpiarCampos()
        BloquearBotones()
        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"
            intAnio = dgLista.SelectedCells(0).Value
            intNum = dgLista.SelectedCells(1).Value
            CargarEncabezado(intAnio, intNum)
            CargarFactura(intAnio, intNum)
            CargarPago(intAnio, intNum)

            MostrarLista(False)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonProveedor_Click(sender As Object, e As EventArgs) Handles botonProveedor.Click
        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Customer"
            frm.Campos = " c.cli_codigo codigo, c.cli_cliente cliente "
            frm.Tabla = " Clientes c "
            frm.FiltroText = " Enter the Customer to filter "
            frm.Filtro = " c.cli_cliente "
            frm.Ordenamiento = " c.cli_cliente "
            frm.TipoOrdenamiento = " ASC "
            frm.Condicion = " c.cli_sisemp = " & Sesion.IdEmpresa & " AND c.cli_status = 'Activo'"
            frm.Limite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIdProveedor.Text = frm.LLave
                celdaProveedor.Text = frm.Dato

                MostrarFacturas()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        If logInsertar = True Then
            LimpiarCampos()
            MostrarLista(False, True)
            Me.Tag = "Nuevo"
        Else
            MsgBox("You do not have access to create a new document.", vbInformation)
        End If

    End Sub

    Private Sub dgFactura_DoubleClick(sender As Object, e As EventArgs) Handles dgFactura.DoubleClick
        Dim i As Integer = 0
        Dim FISR As Double = 0
        Dim VIVA As Double = 0
        dgFactura.CurrentRow.Cells("colExtraFact").Value = 3 ' 3 es solo un pivote para que no se oculte la fila seleccionada
        For i = 0 To dgFactura.Rows.Count - 1
            If dgFactura.Rows(i).Cells("colExtraFact").Value = 3 Then
                celdaAnioF.Text = dgFactura.Rows(i).Cells("colAnioFac").Value
                celdaNumF.Text = dgFactura.Rows(i).Cells("colNumeroFac").Value
                If Sesion.IdEmpresa = 10 Then
                    celdaCatF.Text = 296
                Else
                    celdaCatF.Text = 36
                End If
                celdaMontoF.Text = dgFactura.Rows(i).Cells("colTotalFac").Value
                celdaIDMoneda.Text = cFunciones.DivisaLocal
                celdaMoneda.Text = cFunciones.TraerMoneda(celdaIDMoneda.Text)  'dgFactura.Rows(i).Cells("colMonedaFac").Value
                celdaTipoCambio.Text = INT_UNO.ToString(FORMATO_MONEDA) 'dgFactura.Rows(i).Cells("colTCFac").Value
                celdaTCFactura.Text = dgFactura.Rows(i).Cells("colTCFac").Value
                dgFactura.Rows(i).Cells("colExtraFact").Value = 0
                FISR = FactorISR() ' Consulta cual es el porcentaje de ISR dependiendo del pais
                VIVA = VerificarIVA()
                'Procedimiento para Calcular el ISR
                celdaMonto.Text = Math.Round(((CDbl(celdaMontoF.Text) * CDbl(celdaTCFactura.Text)) - VIVA) * FISR, 2)
                celdaTotal.Text = celdaMonto.Text
                'If dgFactura.Rows(i).Cells("colEspecialFac").Value = 1 Then
                '    checkFacturaEspecial.Checked = True
                'Else
                '    checkFacturaEspecial.Checked = False
                'End If
            Else
                dgFactura.Rows(i).Cells("colExtraFact").Value = 2 ' 2 elimina la fila (no guarda)
                dgFactura.Rows(i).Visible = False
            End If
        Next
    End Sub

    Private Sub celdaMonto_TextChanged(sender As Object, e As EventArgs) Handles celdaMonto.TextChanged
        If celdaMonto.Text.LongCount = 0 Then
            celdaTotal.Text = 0.00
        Else
            celdaTotal.Text = celdaMonto.Text
        End If
    End Sub

    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Dim dtFechaConta As Date
        Dim conta As New clsContabilidad
        If Me.Tag = "Nuevo" Then
            GuardarDatosDeDocumento()
        Else
            'Captura la Fecha de la póliza o del documento, si este no tiene poliza
            dtFechaConta = cFunciones.SQLValidarFechaContable(733, celdaAnio.Text, celdaNumeroHDR.Text)
            'Verifica si hay cierre o no
            If cFunciones.SQLVerificarCierre(733, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                GuardarDatosDeDocumento()
                conta.GenerarPoliza(733, celdaAnio.Text, celdaNumeroHDR.Text, dtFechaConta.ToString(FORMATO_MYSQL))
            Else
                'Si hay cierre solicita autorización
                MsgBox("You need authorization to modify this document", vbInformation, "Notice")
                If cFunciones.AutorizarCambios = True Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acConfirm, celdaProveedor.Text, 733, celdaAnio.Text, celdaNumero.Text, "Autorizó Modificación")
                    GuardarDatosDeDocumento()
                    conta.GenerarPoliza(733, celdaAnio.Text, celdaNumeroHDR.Text, dtFechaConta.ToString(FORMATO_MYSQL))
                End If
            End If
        End If
    End Sub


    Private Sub GuardarDatosDeDocumento()
        If logEditar = True Or Me.Tag = "Nuevo" Then
            Dim clsConta As New clsContabilidad
            If ComprobarCampos() = True Then
                If celdaNumeroHDR.Text = -1 Then
                    celdaNumeroHDR.Text = cFunciones.NuevoId(733)
                End If
                GuardarRetencionHDR()
                GuardarCuentaXPagar()
                If Me.Tag = "Nuevo" Then
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acAdd, 0, 733, celdaAnio.Text, celdaNumeroHDR.Text)

                    If cFunciones.SQLVerificarCierre(733, celdaAnio.Text, celdaNumeroHDR.Text) = 0 Then
                        clsConta.GenerarPoliza(733, celdaAnio.Text, celdaNumeroHDR.Text, dtpFechaDoc.Value.ToString(FORMATO_MYSQL))
                    Else
                        clsConta.GenerarPoliza(733, celdaAnio.Text, celdaNumeroHDR.Text, cFunciones.HoyMySQL.ToString(FORMATO_MYSQL))
                    End If

                    MsgBox("The Document has been successfully saved", vbInformation, "Notice")
                Else
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acUpdate, 0, 733, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("The document has been successfully updated", vbInformation, "Notice")
                End If


                MostrarLista(True)

            End If
        Else
            MsgBox("You do not have access to edit this document", vbInformation)
        End If
    End Sub
    Private Sub botonPoliza_Click(sender As Object, e As EventArgs) Handles botonPoliza.Click
        Dim PC As New clsPolizaContable
        PC.intTipo = 733
        PC.intCiclo = celdaAnio.Text
        PC.intNumero = celdaNumeroHDR.Text
        PC.intModo = 28
        PC.MostrarPolizaContable()
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cFunciones.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(1).Value, dgLista.SelectedCells(0).Value, 733,)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub dgFactura_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgFactura.CellContentClick

    End Sub

    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        If LogBorrar = True Then
            Dim strSQL As String = STR_VACIO
            Dim COM As MySqlCommand
            If ValidarRetencionIvaProveedor(celdaNumeroHDR.Text, celdaAnio.Text) = INT_CERO Then
                If MsgBox("The document will be permanently deleted, do you want to continue?", vbQuestion + vbYesNo, "Question") = vbYes Then
                    BorrarEncabezadoISRProveedor(celdaNumeroHDR.Text, celdaAnio.Text)
                    BorrarEctateRetenISR(celdaNumeroHDR.Text, celdaAnio.Text)
                    cFunciones.BorrarEncabezadoPoliza(celdaNumeroHDR.Text, celdaAnio.Text, 733)
                    cFunciones.BorrarDetallePoliza(celdaNumeroHDR.Text, celdaAnio.Text, 733)
                    cFunciones.EscribirRegistro("Dcmtos_HDR", clsFunciones.AccEnum.acDelete, 0, 733, celdaAnio.Text, celdaNumeroHDR.Text)
                    MsgBox("Eliminated Complete")
                    MostrarLista()
                End If
            Else
                MsgBox("You can not delete a document in the process", vbInformation, "Notice")
            End If
        Else
            MsgBox("You do not have permission for this action", vbInformation, "Notice")
        End If
    End Sub



#End Region
End Class