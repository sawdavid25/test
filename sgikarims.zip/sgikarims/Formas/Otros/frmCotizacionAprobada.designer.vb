﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCotizacionAprobada
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCotizacionAprobada))
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colCodigo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReason = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colJob = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelDocumento = New System.Windows.Forms.Panel()
        Me.PanelCotizacion = New System.Windows.Forms.Panel()
        Me.PanelCotizacion2 = New System.Windows.Forms.Panel()
        Me.dgCotizacion2 = New System.Windows.Forms.DataGridView()
        Me.col_codigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_descripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_cantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_PrecioAnterior = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_medida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_id = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_linea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_anio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_total = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_aprobacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Pago = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Tiempo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_estado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelProveedor3 = New System.Windows.Forms.Panel()
        Me.celdaidProveedor3 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.celdaTotal3 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.botonProveedor3 = New System.Windows.Forms.Button()
        Me.celdaProveedor3 = New System.Windows.Forms.TextBox()
        Me.paneCotizacion3 = New System.Windows.Forms.Panel()
        Me.dgCotizacion3 = New System.Windows.Forms.DataGridView()
        Me.colCode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colprice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_precio_anterior = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAprobacion1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPago1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTiempo1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_Comentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelProveedor = New System.Windows.Forms.Panel()
        Me.celdaidProveedor2 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.celdaTotal2 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaProveedor2 = New System.Windows.Forms.TextBox()
        Me.panelCotizacion1 = New System.Windows.Forms.Panel()
        Me.dgCotizacion = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProducto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecioAnterior = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedida = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAprobacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPago = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTiempo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colComentario = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelProveedor1 = New System.Windows.Forms.Panel()
        Me.celdaidProveedor = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.botonProveedor2 = New System.Windows.Forms.Button()
        Me.celdaProveedor1 = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.celdaObservaciones = New System.Windows.Forms.TextBox()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.celdaAño = New System.Windows.Forms.TextBox()
        Me.CheckAnulado = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpFechaInicio = New System.Windows.Forms.DateTimePicker()
        Me.celdaidSolitado = New System.Windows.Forms.TextBox()
        Me.celdaSolicitado = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.celdaRason = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.celdaNumeroCotizacion = New System.Windows.Forms.TextBox()
        Me.botonCotizacion = New System.Windows.Forms.Button()
        Me.celdaCotizacion = New System.Windows.Forms.TextBox()
        Me.celdaCodigo = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.botonInprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelDocumento.SuspendLayout()
        Me.PanelCotizacion.SuspendLayout()
        Me.PanelCotizacion2.SuspendLayout()
        CType(Me.dgCotizacion2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelProveedor3.SuspendLayout()
        Me.paneCotizacion3.SuspendLayout()
        CType(Me.dgCotizacion3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelProveedor.SuspendLayout()
        Me.panelCotizacion1.SuspendLayout()
        CType(Me.dgCotizacion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelProveedor1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Location = New System.Drawing.Point(12, 147)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(788, 106)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo1, Me.colAño, Me.colName, Me.colReason, Me.colJob, Me.colEstado2})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 0)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(788, 106)
        Me.dgLista.TabIndex = 0
        '
        'colCodigo1
        '
        Me.colCodigo1.HeaderText = "CODE"
        Me.colCodigo1.Name = "colCodigo1"
        Me.colCodigo1.ReadOnly = True
        '
        'colAño
        '
        Me.colAño.HeaderText = "YEAR"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colName
        '
        Me.colName.HeaderText = "NAME"
        Me.colName.Name = "colName"
        Me.colName.ReadOnly = True
        '
        'colReason
        '
        Me.colReason.HeaderText = "REASON"
        Me.colReason.Name = "colReason"
        Me.colReason.ReadOnly = True
        '
        'colJob
        '
        Me.colJob.HeaderText = "JOB"
        Me.colJob.Name = "colJob"
        Me.colJob.ReadOnly = True
        '
        'colEstado2
        '
        Me.colEstado2.HeaderText = "Status"
        Me.colEstado2.Name = "colEstado2"
        Me.colEstado2.ReadOnly = True
        '
        'PanelDocumento
        '
        Me.PanelDocumento.Controls.Add(Me.PanelCotizacion)
        Me.PanelDocumento.Controls.Add(Me.GroupBox1)
        Me.PanelDocumento.Location = New System.Drawing.Point(12, 273)
        Me.PanelDocumento.Name = "PanelDocumento"
        Me.PanelDocumento.Size = New System.Drawing.Size(931, 450)
        Me.PanelDocumento.TabIndex = 3
        '
        'PanelCotizacion
        '
        Me.PanelCotizacion.Controls.Add(Me.PanelCotizacion2)
        Me.PanelCotizacion.Controls.Add(Me.paneCotizacion3)
        Me.PanelCotizacion.Controls.Add(Me.panelCotizacion1)
        Me.PanelCotizacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelCotizacion.Location = New System.Drawing.Point(431, 0)
        Me.PanelCotizacion.Name = "PanelCotizacion"
        Me.PanelCotizacion.Size = New System.Drawing.Size(500, 450)
        Me.PanelCotizacion.TabIndex = 1
        '
        'PanelCotizacion2
        '
        Me.PanelCotizacion2.Controls.Add(Me.dgCotizacion2)
        Me.PanelCotizacion2.Controls.Add(Me.panelProveedor3)
        Me.PanelCotizacion2.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelCotizacion2.Location = New System.Drawing.Point(0, 450)
        Me.PanelCotizacion2.Name = "PanelCotizacion2"
        Me.PanelCotizacion2.Size = New System.Drawing.Size(500, 269)
        Me.PanelCotizacion2.TabIndex = 2
        '
        'dgCotizacion2
        '
        Me.dgCotizacion2.AllowUserToAddRows = False
        Me.dgCotizacion2.AllowUserToDeleteRows = False
        Me.dgCotizacion2.AllowUserToOrderColumns = True
        Me.dgCotizacion2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgCotizacion2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgCotizacion2.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion2.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgCotizacion2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCotizacion2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_codigo, Me.col_descripcion, Me.col_cantidad, Me.col_price, Me.col_PrecioAnterior, Me.col_medida, Me.col_id, Me.col_linea, Me.col_anio, Me.col_total, Me.col_aprobacion, Me.col_Pago, Me.col_Tiempo, Me.colComentario1, Me.col_estado})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgCotizacion2.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgCotizacion2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCotizacion2.Location = New System.Drawing.Point(0, 80)
        Me.dgCotizacion2.MultiSelect = False
        Me.dgCotizacion2.Name = "dgCotizacion2"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion2.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgCotizacion2.RowTemplate.Height = 24
        Me.dgCotizacion2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCotizacion2.Size = New System.Drawing.Size(500, 189)
        Me.dgCotizacion2.TabIndex = 0
        '
        'col_codigo
        '
        Me.col_codigo.HeaderText = "Code"
        Me.col_codigo.Name = "col_codigo"
        Me.col_codigo.ReadOnly = True
        Me.col_codigo.Width = 70
        '
        'col_descripcion
        '
        Me.col_descripcion.HeaderText = "Product"
        Me.col_descripcion.Name = "col_descripcion"
        Me.col_descripcion.ReadOnly = True
        Me.col_descripcion.Width = 86
        '
        'col_cantidad
        '
        Me.col_cantidad.HeaderText = "Quantity"
        Me.col_cantidad.Name = "col_cantidad"
        Me.col_cantidad.Width = 90
        '
        'col_price
        '
        Me.col_price.HeaderText = "Price"
        Me.col_price.Name = "col_price"
        Me.col_price.Width = 69
        '
        'col_PrecioAnterior
        '
        Me.col_PrecioAnterior.HeaderText = "Last Price"
        Me.col_PrecioAnterior.Name = "col_PrecioAnterior"
        Me.col_PrecioAnterior.Width = 92
        '
        'col_medida
        '
        Me.col_medida.HeaderText = "Measure"
        Me.col_medida.Name = "col_medida"
        Me.col_medida.ReadOnly = True
        Me.col_medida.Width = 92
        '
        'col_id
        '
        Me.col_id.HeaderText = "Id"
        Me.col_id.Name = "col_id"
        Me.col_id.ReadOnly = True
        Me.col_id.Visible = False
        Me.col_id.Width = 48
        '
        'col_linea
        '
        Me.col_linea.HeaderText = "Line"
        Me.col_linea.Name = "col_linea"
        Me.col_linea.ReadOnly = True
        Me.col_linea.Visible = False
        Me.col_linea.Width = 64
        '
        'col_anio
        '
        Me.col_anio.HeaderText = "Year"
        Me.col_anio.Name = "col_anio"
        Me.col_anio.ReadOnly = True
        Me.col_anio.Visible = False
        Me.col_anio.Width = 67
        '
        'col_total
        '
        Me.col_total.HeaderText = "Total"
        Me.col_total.Name = "col_total"
        Me.col_total.ReadOnly = True
        Me.col_total.Width = 69
        '
        'col_aprobacion
        '
        Me.col_aprobacion.HeaderText = "approbation"
        Me.col_aprobacion.Name = "col_aprobacion"
        Me.col_aprobacion.ReadOnly = True
        Me.col_aprobacion.Width = 113
        '
        'col_Pago
        '
        Me.col_Pago.HeaderText = "Payment Method"
        Me.col_Pago.Name = "col_Pago"
        Me.col_Pago.Width = 131
        '
        'col_Tiempo
        '
        Me.col_Tiempo.HeaderText = "Delivery Time"
        Me.col_Tiempo.Name = "col_Tiempo"
        Me.col_Tiempo.Width = 113
        '
        'colComentario1
        '
        Me.colComentario1.HeaderText = "Comment"
        Me.colComentario1.Name = "colComentario1"
        Me.colComentario1.Width = 96
        '
        'col_estado
        '
        Me.col_estado.HeaderText = "Status"
        Me.col_estado.Name = "col_estado"
        Me.col_estado.ReadOnly = True
        Me.col_estado.Visible = False
        Me.col_estado.Width = 77
        '
        'panelProveedor3
        '
        Me.panelProveedor3.Controls.Add(Me.celdaidProveedor3)
        Me.panelProveedor3.Controls.Add(Me.Label10)
        Me.panelProveedor3.Controls.Add(Me.celdaTotal3)
        Me.panelProveedor3.Controls.Add(Me.Label11)
        Me.panelProveedor3.Controls.Add(Me.botonProveedor3)
        Me.panelProveedor3.Controls.Add(Me.celdaProveedor3)
        Me.panelProveedor3.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelProveedor3.Location = New System.Drawing.Point(0, 0)
        Me.panelProveedor3.Name = "panelProveedor3"
        Me.panelProveedor3.Size = New System.Drawing.Size(500, 80)
        Me.panelProveedor3.TabIndex = 10
        '
        'celdaidProveedor3
        '
        Me.celdaidProveedor3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaidProveedor3.Location = New System.Drawing.Point(437, 8)
        Me.celdaidProveedor3.Name = "celdaidProveedor3"
        Me.celdaidProveedor3.Size = New System.Drawing.Size(58, 22)
        Me.celdaidProveedor3.TabIndex = 9
        Me.celdaidProveedor3.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 3)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(61, 17)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Provider"
        '
        'celdaTotal3
        '
        Me.celdaTotal3.Location = New System.Drawing.Point(96, 33)
        Me.celdaTotal3.Name = "celdaTotal3"
        Me.celdaTotal3.ReadOnly = True
        Me.celdaTotal3.Size = New System.Drawing.Size(110, 22)
        Me.celdaTotal3.TabIndex = 7
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 38)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(40, 17)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Total"
        '
        'botonProveedor3
        '
        Me.botonProveedor3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor3.Location = New System.Drawing.Point(266, 6)
        Me.botonProveedor3.Name = "botonProveedor3"
        Me.botonProveedor3.Size = New System.Drawing.Size(45, 25)
        Me.botonProveedor3.TabIndex = 5
        Me.botonProveedor3.Text = "..."
        Me.botonProveedor3.UseVisualStyleBackColor = True
        '
        'celdaProveedor3
        '
        Me.celdaProveedor3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor3.Location = New System.Drawing.Point(95, 7)
        Me.celdaProveedor3.Name = "celdaProveedor3"
        Me.celdaProveedor3.ReadOnly = True
        Me.celdaProveedor3.Size = New System.Drawing.Size(141, 22)
        Me.celdaProveedor3.TabIndex = 4
        '
        'paneCotizacion3
        '
        Me.paneCotizacion3.Controls.Add(Me.dgCotizacion3)
        Me.paneCotizacion3.Controls.Add(Me.PanelProveedor)
        Me.paneCotizacion3.Dock = System.Windows.Forms.DockStyle.Top
        Me.paneCotizacion3.Location = New System.Drawing.Point(0, 236)
        Me.paneCotizacion3.Name = "paneCotizacion3"
        Me.paneCotizacion3.Size = New System.Drawing.Size(500, 214)
        Me.paneCotizacion3.TabIndex = 1
        '
        'dgCotizacion3
        '
        Me.dgCotizacion3.AllowUserToAddRows = False
        Me.dgCotizacion3.AllowUserToDeleteRows = False
        Me.dgCotizacion3.AllowUserToOrderColumns = True
        Me.dgCotizacion3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgCotizacion3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgCotizacion3.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion3.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgCotizacion3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCotizacion3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCode, Me.colDescripcion, Me.colCantidad1, Me.colprice, Me.col_precio_anterior, Me.colMedida1, Me.colidMedida, Me.colLinea1, Me.colAnio1, Me.colTotal1, Me.colAprobacion1, Me.colPago1, Me.colTiempo1, Me.col_Comentario, Me.colEstado1})
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgCotizacion3.DefaultCellStyle = DataGridViewCellStyle8
        Me.dgCotizacion3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCotizacion3.Location = New System.Drawing.Point(0, 64)
        Me.dgCotizacion3.MultiSelect = False
        Me.dgCotizacion3.Name = "dgCotizacion3"
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion3.RowHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.dgCotizacion3.RowTemplate.Height = 24
        Me.dgCotizacion3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCotizacion3.Size = New System.Drawing.Size(500, 150)
        Me.dgCotizacion3.TabIndex = 0
        '
        'colCode
        '
        Me.colCode.HeaderText = "Code"
        Me.colCode.Name = "colCode"
        Me.colCode.ReadOnly = True
        Me.colCode.Width = 70
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Product"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 86
        '
        'colCantidad1
        '
        Me.colCantidad1.HeaderText = "Quantity"
        Me.colCantidad1.Name = "colCantidad1"
        Me.colCantidad1.Width = 90
        '
        'colprice
        '
        Me.colprice.HeaderText = "Price"
        Me.colprice.Name = "colprice"
        Me.colprice.Width = 69
        '
        'col_precio_anterior
        '
        Me.col_precio_anterior.HeaderText = "Last Price"
        Me.col_precio_anterior.Name = "col_precio_anterior"
        Me.col_precio_anterior.Width = 92
        '
        'colMedida1
        '
        Me.colMedida1.HeaderText = "Measure"
        Me.colMedida1.Name = "colMedida1"
        Me.colMedida1.ReadOnly = True
        Me.colMedida1.Width = 92
        '
        'colidMedida
        '
        Me.colidMedida.HeaderText = "id"
        Me.colidMedida.Name = "colidMedida"
        Me.colidMedida.ReadOnly = True
        Me.colidMedida.Visible = False
        Me.colidMedida.Width = 48
        '
        'colLinea1
        '
        Me.colLinea1.HeaderText = "Line"
        Me.colLinea1.Name = "colLinea1"
        Me.colLinea1.ReadOnly = True
        Me.colLinea1.Visible = False
        Me.colLinea1.Width = 64
        '
        'colAnio1
        '
        Me.colAnio1.HeaderText = "Year"
        Me.colAnio1.Name = "colAnio1"
        Me.colAnio1.ReadOnly = True
        Me.colAnio1.Visible = False
        Me.colAnio1.Width = 67
        '
        'colTotal1
        '
        Me.colTotal1.HeaderText = "Total"
        Me.colTotal1.Name = "colTotal1"
        Me.colTotal1.ReadOnly = True
        Me.colTotal1.Width = 69
        '
        'colAprobacion1
        '
        Me.colAprobacion1.HeaderText = "approbation"
        Me.colAprobacion1.Name = "colAprobacion1"
        Me.colAprobacion1.ReadOnly = True
        Me.colAprobacion1.Width = 113
        '
        'colPago1
        '
        Me.colPago1.HeaderText = "Payment Method"
        Me.colPago1.Name = "colPago1"
        Me.colPago1.Width = 131
        '
        'colTiempo1
        '
        Me.colTiempo1.HeaderText = "Delivery Time "
        Me.colTiempo1.Name = "colTiempo1"
        Me.colTiempo1.Width = 117
        '
        'col_Comentario
        '
        Me.col_Comentario.HeaderText = "Comment"
        Me.col_Comentario.Name = "col_Comentario"
        Me.col_Comentario.Width = 96
        '
        'colEstado1
        '
        Me.colEstado1.HeaderText = "Status"
        Me.colEstado1.Name = "colEstado1"
        Me.colEstado1.ReadOnly = True
        Me.colEstado1.Visible = False
        Me.colEstado1.Width = 77
        '
        'PanelProveedor
        '
        Me.PanelProveedor.Controls.Add(Me.celdaidProveedor2)
        Me.PanelProveedor.Controls.Add(Me.Label7)
        Me.PanelProveedor.Controls.Add(Me.celdaTotal2)
        Me.PanelProveedor.Controls.Add(Me.Label6)
        Me.PanelProveedor.Controls.Add(Me.botonProveedor)
        Me.PanelProveedor.Controls.Add(Me.celdaProveedor2)
        Me.PanelProveedor.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelProveedor.Location = New System.Drawing.Point(0, 0)
        Me.PanelProveedor.Name = "PanelProveedor"
        Me.PanelProveedor.Size = New System.Drawing.Size(500, 64)
        Me.PanelProveedor.TabIndex = 1
        '
        'celdaidProveedor2
        '
        Me.celdaidProveedor2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaidProveedor2.Location = New System.Drawing.Point(341, 6)
        Me.celdaidProveedor2.Name = "celdaidProveedor2"
        Me.celdaidProveedor2.Size = New System.Drawing.Size(62, 22)
        Me.celdaidProveedor2.TabIndex = 9
        Me.celdaidProveedor2.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(61, 17)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Provider"
        '
        'celdaTotal2
        '
        Me.celdaTotal2.Location = New System.Drawing.Point(95, 35)
        Me.celdaTotal2.Name = "celdaTotal2"
        Me.celdaTotal2.ReadOnly = True
        Me.celdaTotal2.Size = New System.Drawing.Size(111, 22)
        Me.celdaTotal2.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(21, 38)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 17)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Total"
        '
        'botonProveedor
        '
        Me.botonProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor.Location = New System.Drawing.Point(266, 5)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(45, 22)
        Me.botonProveedor.TabIndex = 5
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaProveedor2
        '
        Me.celdaProveedor2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor2.Location = New System.Drawing.Point(95, 3)
        Me.celdaProveedor2.Name = "celdaProveedor2"
        Me.celdaProveedor2.ReadOnly = True
        Me.celdaProveedor2.Size = New System.Drawing.Size(141, 22)
        Me.celdaProveedor2.TabIndex = 4
        '
        'panelCotizacion1
        '
        Me.panelCotizacion1.Controls.Add(Me.dgCotizacion)
        Me.panelCotizacion1.Controls.Add(Me.PanelProveedor1)
        Me.panelCotizacion1.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelCotizacion1.Location = New System.Drawing.Point(0, 0)
        Me.panelCotizacion1.Name = "panelCotizacion1"
        Me.panelCotizacion1.Size = New System.Drawing.Size(500, 236)
        Me.panelCotizacion1.TabIndex = 0
        '
        'dgCotizacion
        '
        Me.dgCotizacion.AllowUserToAddRows = False
        Me.dgCotizacion.AllowUserToDeleteRows = False
        Me.dgCotizacion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgCotizacion.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgCotizacion.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle10
        Me.dgCotizacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgCotizacion.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colProducto, Me.colCantidad, Me.colPrecio, Me.colPrecioAnterior, Me.colMedida, Me.colId, Me.colLinea, Me.colAnio, Me.colTotal, Me.colAprobacion, Me.colPago, Me.colTiempo, Me.colComentario, Me.colEstado})
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgCotizacion.DefaultCellStyle = DataGridViewCellStyle11
        Me.dgCotizacion.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgCotizacion.GridColor = System.Drawing.SystemColors.Control
        Me.dgCotizacion.Location = New System.Drawing.Point(0, 74)
        Me.dgCotizacion.MultiSelect = False
        Me.dgCotizacion.Name = "dgCotizacion"
        DataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgCotizacion.RowHeadersDefaultCellStyle = DataGridViewCellStyle12
        Me.dgCotizacion.RowTemplate.Height = 24
        Me.dgCotizacion.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgCotizacion.Size = New System.Drawing.Size(500, 162)
        Me.dgCotizacion.TabIndex = 0
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 70
        '
        'colProducto
        '
        Me.colProducto.HeaderText = "Product"
        Me.colProducto.Name = "colProducto"
        Me.colProducto.ReadOnly = True
        Me.colProducto.Width = 86
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 90
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Price"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 69
        '
        'colPrecioAnterior
        '
        Me.colPrecioAnterior.HeaderText = "Last Price"
        Me.colPrecioAnterior.Name = "colPrecioAnterior"
        Me.colPrecioAnterior.Width = 92
        '
        'colMedida
        '
        Me.colMedida.HeaderText = "Measure"
        Me.colMedida.Name = "colMedida"
        Me.colMedida.ReadOnly = True
        Me.colMedida.Width = 92
        '
        'colId
        '
        Me.colId.HeaderText = "Id"
        Me.colId.Name = "colId"
        Me.colId.ReadOnly = True
        Me.colId.Visible = False
        Me.colId.Width = 48
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Line"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        Me.colLinea.Width = 64
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        Me.colAnio.Width = 67
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Width = 69
        '
        'colAprobacion
        '
        Me.colAprobacion.HeaderText = "approbation"
        Me.colAprobacion.Name = "colAprobacion"
        Me.colAprobacion.ReadOnly = True
        Me.colAprobacion.Width = 113
        '
        'colPago
        '
        Me.colPago.HeaderText = "Payment Method"
        Me.colPago.Name = "colPago"
        Me.colPago.Width = 131
        '
        'colTiempo
        '
        Me.colTiempo.HeaderText = "Delivery Time"
        Me.colTiempo.Name = "colTiempo"
        Me.colTiempo.Width = 113
        '
        'colComentario
        '
        Me.colComentario.HeaderText = "Comment"
        Me.colComentario.Name = "colComentario"
        Me.colComentario.Width = 96
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        Me.colEstado.Width = 77
        '
        'PanelProveedor1
        '
        Me.PanelProveedor1.Controls.Add(Me.celdaidProveedor)
        Me.PanelProveedor1.Controls.Add(Me.Label8)
        Me.PanelProveedor1.Controls.Add(Me.celdaTotal)
        Me.PanelProveedor1.Controls.Add(Me.Label9)
        Me.PanelProveedor1.Controls.Add(Me.botonProveedor2)
        Me.PanelProveedor1.Controls.Add(Me.celdaProveedor1)
        Me.PanelProveedor1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelProveedor1.Location = New System.Drawing.Point(0, 0)
        Me.PanelProveedor1.Name = "PanelProveedor1"
        Me.PanelProveedor1.Size = New System.Drawing.Size(500, 74)
        Me.PanelProveedor1.TabIndex = 9
        '
        'celdaidProveedor
        '
        Me.celdaidProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaidProveedor.Location = New System.Drawing.Point(322, 10)
        Me.celdaidProveedor.Name = "celdaidProveedor"
        Me.celdaidProveedor.Size = New System.Drawing.Size(49, 22)
        Me.celdaidProveedor.TabIndex = 9
        Me.celdaidProveedor.Visible = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 17)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 17)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Provider"
        '
        'celdaTotal
        '
        Me.celdaTotal.Location = New System.Drawing.Point(96, 46)
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(110, 22)
        Me.celdaTotal.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 51)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 17)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Total"
        '
        'botonProveedor2
        '
        Me.botonProveedor2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor2.Location = New System.Drawing.Point(257, 11)
        Me.botonProveedor2.Name = "botonProveedor2"
        Me.botonProveedor2.Size = New System.Drawing.Size(45, 23)
        Me.botonProveedor2.TabIndex = 5
        Me.botonProveedor2.Text = "..."
        Me.botonProveedor2.UseVisualStyleBackColor = True
        '
        'celdaProveedor1
        '
        Me.celdaProveedor1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor1.Location = New System.Drawing.Point(95, 12)
        Me.celdaProveedor1.Name = "celdaProveedor1"
        Me.celdaProveedor1.ReadOnly = True
        Me.celdaProveedor1.Size = New System.Drawing.Size(141, 22)
        Me.celdaProveedor1.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.celdaObservaciones)
        Me.GroupBox1.Controls.Add(Me.celdaTasa)
        Me.GroupBox1.Controls.Add(Me.Label14)
        Me.GroupBox1.Controls.Add(Me.celdaidMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaMoneda)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.botonMoneda)
        Me.GroupBox1.Controls.Add(Me.celdaAño)
        Me.GroupBox1.Controls.Add(Me.CheckAnulado)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.dtpFechaInicio)
        Me.GroupBox1.Controls.Add(Me.celdaidSolitado)
        Me.GroupBox1.Controls.Add(Me.celdaSolicitado)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.celdaRason)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.celdaAnio)
        Me.GroupBox1.Controls.Add(Me.celdaNumeroCotizacion)
        Me.GroupBox1.Controls.Add(Me.botonCotizacion)
        Me.GroupBox1.Controls.Add(Me.celdaCotizacion)
        Me.GroupBox1.Controls.Add(Me.celdaCodigo)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(431, 450)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(6, 348)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(118, 17)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "Recommendation"
        '
        'celdaObservaciones
        '
        Me.celdaObservaciones.Location = New System.Drawing.Point(4, 379)
        Me.celdaObservaciones.Margin = New System.Windows.Forms.Padding(4)
        Me.celdaObservaciones.Multiline = True
        Me.celdaObservaciones.Name = "celdaObservaciones"
        Me.celdaObservaciones.Size = New System.Drawing.Size(343, 71)
        Me.celdaObservaciones.TabIndex = 26
        Me.celdaObservaciones.Text = "..."
        '
        'celdaTasa
        '
        Me.celdaTasa.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTasa.Location = New System.Drawing.Point(126, 309)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.ReadOnly = True
        Me.celdaTasa.Size = New System.Drawing.Size(161, 22)
        Me.celdaTasa.TabIndex = 23
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(-3, 314)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(108, 17)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = " Exchange Rate"
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(324, 55)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.Size = New System.Drawing.Size(69, 22)
        Me.celdaidMoneda.TabIndex = 21
        Me.celdaidMoneda.Visible = False
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMoneda.Location = New System.Drawing.Point(126, 269)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(161, 22)
        Me.celdaMoneda.TabIndex = 20
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(3, 269)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 17)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "Currency"
        '
        'botonMoneda
        '
        Me.botonMoneda.Location = New System.Drawing.Point(302, 268)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(45, 23)
        Me.botonMoneda.TabIndex = 18
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'celdaAño
        '
        Me.celdaAño.Location = New System.Drawing.Point(324, 88)
        Me.celdaAño.Name = "celdaAño"
        Me.celdaAño.Size = New System.Drawing.Size(73, 22)
        Me.celdaAño.TabIndex = 17
        Me.celdaAño.Visible = False
        '
        'CheckAnulado
        '
        Me.CheckAnulado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckAnulado.AutoSize = True
        Me.CheckAnulado.Checked = True
        Me.CheckAnulado.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckAnulado.Location = New System.Drawing.Point(334, 21)
        Me.CheckAnulado.Name = "CheckAnulado"
        Me.CheckAnulado.Size = New System.Drawing.Size(68, 21)
        Me.CheckAnulado.TabIndex = 15
        Me.CheckAnulado.Text = "Active"
        Me.CheckAnulado.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(0, 74)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 17)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Date"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(3, 148)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 17)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Quotation"
        '
        'dtpFechaInicio
        '
        Me.dtpFechaInicio.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtpFechaInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicio.Location = New System.Drawing.Point(122, 69)
        Me.dtpFechaInicio.Name = "dtpFechaInicio"
        Me.dtpFechaInicio.Size = New System.Drawing.Size(164, 22)
        Me.dtpFechaInicio.TabIndex = 7
        '
        'celdaidSolitado
        '
        Me.celdaidSolitado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaidSolitado.Location = New System.Drawing.Point(355, 183)
        Me.celdaidSolitado.Name = "celdaidSolitado"
        Me.celdaidSolitado.Size = New System.Drawing.Size(59, 22)
        Me.celdaidSolitado.TabIndex = 12
        Me.celdaidSolitado.Visible = False
        '
        'celdaSolicitado
        '
        Me.celdaSolicitado.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSolicitado.Location = New System.Drawing.Point(126, 231)
        Me.celdaSolicitado.Name = "celdaSolicitado"
        Me.celdaSolicitado.ReadOnly = True
        Me.celdaSolicitado.Size = New System.Drawing.Size(160, 22)
        Me.celdaSolicitado.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(-3, 236)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(97, 17)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Requested By"
        '
        'celdaRason
        '
        Me.celdaRason.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaRason.Location = New System.Drawing.Point(126, 188)
        Me.celdaRason.Name = "celdaRason"
        Me.celdaRason.ReadOnly = True
        Me.celdaRason.Size = New System.Drawing.Size(161, 22)
        Me.celdaRason.TabIndex = 9
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(0, 188)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Reason"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(1, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 17)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "year"
        '
        'celdaAnio
        '
        Me.celdaAnio.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAnio.Location = New System.Drawing.Point(123, 32)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(164, 22)
        Me.celdaAnio.TabIndex = 5
        '
        'celdaNumeroCotizacion
        '
        Me.celdaNumeroCotizacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNumeroCotizacion.Location = New System.Drawing.Point(324, 115)
        Me.celdaNumeroCotizacion.Name = "celdaNumeroCotizacion"
        Me.celdaNumeroCotizacion.Size = New System.Drawing.Size(59, 22)
        Me.celdaNumeroCotizacion.TabIndex = 4
        Me.celdaNumeroCotizacion.Visible = False
        '
        'botonCotizacion
        '
        Me.botonCotizacion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCotizacion.Location = New System.Drawing.Point(302, 148)
        Me.botonCotizacion.Name = "botonCotizacion"
        Me.botonCotizacion.Size = New System.Drawing.Size(45, 22)
        Me.botonCotizacion.TabIndex = 3
        Me.botonCotizacion.Text = "..."
        Me.botonCotizacion.UseVisualStyleBackColor = True
        '
        'celdaCotizacion
        '
        Me.celdaCotizacion.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCotizacion.Location = New System.Drawing.Point(126, 148)
        Me.celdaCotizacion.Name = "celdaCotizacion"
        Me.celdaCotizacion.ReadOnly = True
        Me.celdaCotizacion.Size = New System.Drawing.Size(161, 22)
        Me.celdaCotizacion.TabIndex = 2
        '
        'celdaCodigo
        '
        Me.celdaCodigo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCodigo.Location = New System.Drawing.Point(126, 106)
        Me.celdaCodigo.Name = "celdaCodigo"
        Me.celdaCodigo.ReadOnly = True
        Me.celdaCodigo.Size = New System.Drawing.Size(161, 22)
        Me.celdaCodigo.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 106)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Code"
        '
        'botonInprimir
        '
        Me.botonInprimir.Image = CType(resources.GetObject("botonInprimir.Image"), System.Drawing.Image)
        Me.botonInprimir.Location = New System.Drawing.Point(280, 13)
        Me.botonInprimir.Margin = New System.Windows.Forms.Padding(4)
        Me.botonInprimir.Name = "botonInprimir"
        Me.botonInprimir.Size = New System.Drawing.Size(79, 55)
        Me.botonInprimir.TabIndex = 20
        Me.botonInprimir.Text = "Print"
        Me.botonInprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonInprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 89)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(950, 37)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(950, 89)
        Me.Encabezado1.TabIndex = 0
        '
        'frmCotizacionAprobada
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(950, 788)
        Me.Controls.Add(Me.botonInprimir)
        Me.Controls.Add(Me.PanelDocumento)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Name = "frmCotizacionAprobada"
        Me.Text = "frmCotizacionAprobada"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelDocumento.ResumeLayout(False)
        Me.PanelCotizacion.ResumeLayout(False)
        Me.PanelCotizacion2.ResumeLayout(False)
        CType(Me.dgCotizacion2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelProveedor3.ResumeLayout(False)
        Me.panelProveedor3.PerformLayout()
        Me.paneCotizacion3.ResumeLayout(False)
        CType(Me.dgCotizacion3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelProveedor.ResumeLayout(False)
        Me.PanelProveedor.PerformLayout()
        Me.panelCotizacion1.ResumeLayout(False)
        CType(Me.dgCotizacion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelProveedor1.ResumeLayout(False)
        Me.PanelProveedor1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents PanelDocumento As Panel
    Friend WithEvents PanelCotizacion As Panel
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents botonCotizacion As Button
    Friend WithEvents celdaCotizacion As TextBox
    Friend WithEvents celdaCodigo As TextBox
    Friend WithEvents paneCotizacion3 As Panel
    Friend WithEvents dgCotizacion3 As DataGridView
    Friend WithEvents panelCotizacion1 As Panel
    Friend WithEvents dgCotizacion As DataGridView
    Friend WithEvents dgCotizacion2 As DataGridView
    Friend WithEvents celdaNumeroCotizacion As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents dtpFechaInicio As DateTimePicker
    Friend WithEvents celdaRason As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents celdaSolicitado As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents celdaidSolitado As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PanelCotizacion2 As Panel
    Friend WithEvents panelProveedor3 As Panel
    Friend WithEvents Label10 As Label
    Friend WithEvents celdaTotal3 As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents botonProveedor3 As Button
    Friend WithEvents celdaProveedor3 As TextBox
    Friend WithEvents PanelProveedor1 As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents botonProveedor2 As Button
    Friend WithEvents celdaProveedor1 As TextBox
    Friend WithEvents PanelProveedor As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents celdaTotal2 As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaProveedor2 As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents celdaidProveedor As TextBox
    Friend WithEvents celdaidProveedor2 As TextBox
    Friend WithEvents celdaidProveedor3 As TextBox
    Friend WithEvents CheckAnulado As System.Windows.Forms.CheckBox
    Friend WithEvents celdaAño As TextBox
    Friend WithEvents colCodigo1 As DataGridViewTextBoxColumn
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colName As DataGridViewTextBoxColumn
    Friend WithEvents colReason As DataGridViewTextBoxColumn
    Friend WithEvents colJob As DataGridViewTextBoxColumn
    Friend WithEvents colEstado2 As DataGridViewTextBoxColumn
    Friend WithEvents Label13 As Label
    Friend WithEvents botonMoneda As Button
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents botonInprimir As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents celdaObservaciones As TextBox
    Friend WithEvents colCode As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad1 As DataGridViewTextBoxColumn
    Friend WithEvents colprice As DataGridViewTextBoxColumn
    Friend WithEvents col_precio_anterior As DataGridViewTextBoxColumn
    Friend WithEvents colMedida1 As DataGridViewTextBoxColumn
    Friend WithEvents colidMedida As DataGridViewTextBoxColumn
    Friend WithEvents colLinea1 As DataGridViewTextBoxColumn
    Friend WithEvents colAnio1 As DataGridViewTextBoxColumn
    Friend WithEvents colTotal1 As DataGridViewTextBoxColumn
    Friend WithEvents colAprobacion1 As DataGridViewTextBoxColumn
    Friend WithEvents colPago1 As DataGridViewTextBoxColumn
    Friend WithEvents colTiempo1 As DataGridViewTextBoxColumn
    Friend WithEvents col_Comentario As DataGridViewTextBoxColumn
    Friend WithEvents colEstado1 As DataGridViewTextBoxColumn
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colProducto As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colPrecioAnterior As DataGridViewTextBoxColumn
    Friend WithEvents colMedida As DataGridViewTextBoxColumn
    Friend WithEvents colId As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colAprobacion As DataGridViewTextBoxColumn
    Friend WithEvents colPago As DataGridViewTextBoxColumn
    Friend WithEvents colTiempo As DataGridViewTextBoxColumn
    Friend WithEvents colComentario As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents col_codigo As DataGridViewTextBoxColumn
    Friend WithEvents col_descripcion As DataGridViewTextBoxColumn
    Friend WithEvents col_cantidad As DataGridViewTextBoxColumn
    Friend WithEvents col_price As DataGridViewTextBoxColumn
    Friend WithEvents col_PrecioAnterior As DataGridViewTextBoxColumn
    Friend WithEvents col_medida As DataGridViewTextBoxColumn
    Friend WithEvents col_id As DataGridViewTextBoxColumn
    Friend WithEvents col_linea As DataGridViewTextBoxColumn
    Friend WithEvents col_anio As DataGridViewTextBoxColumn
    Friend WithEvents col_total As DataGridViewTextBoxColumn
    Friend WithEvents col_aprobacion As DataGridViewTextBoxColumn
    Friend WithEvents col_Pago As DataGridViewTextBoxColumn
    Friend WithEvents col_Tiempo As DataGridViewTextBoxColumn
    Friend WithEvents colComentario1 As DataGridViewTextBoxColumn
    Friend WithEvents col_estado As DataGridViewTextBoxColumn
End Class
