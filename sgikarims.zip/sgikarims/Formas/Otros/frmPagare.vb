﻿Public Class frmPagare
    Dim strkey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Public Property key As String
        Get
            Return strkey
        End Get
        Set(value As String)
            strkey = value
        End Set
    End Property

#Region "Funciones Locales"

    Private Function SQLLista() As String
        Dim strSQL As String = STR_VACIO
        strSQL = STR_VACIO
        strSQL = "SELECT HDoc_Doc_Num ID,HDoc_Doc_Ano Ano,CAST(GROUP_CONCAT(DISTINCT  PDoc_Par_Num SEPARATOR '-') AS CHAR) Factura," &
            "        HDoc_Emp_Nom Deudor, HDoc_Usuario Usuario, if(HDoc_Doc_Status=1,'Activo','Anulado') Activo, if(HDoc_RF1_Num=1,'Recibido','No Recibido') Recibido" &
            "     FROM Dcmtos_HDR" &
            "     INNER JOIN Dcmtos_DTL_Pro ON " &
            "           PDoc_Chi_Cat = HDoc_Doc_Cat and PDoc_Sis_Emp = HDoc_Sis_Emp  and" &
            "           PDoc_Chi_Ano =  HDoc_Doc_Ano and PDoc_Chi_Num = HDoc_Doc_Num and PDoc_Par_Cat = 36" &
            "     WHERE HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 465 "
        If checkFecha.Checked = True Then
            strSQL &= " and HDoc_Doc_Fec between '{inicio}' and '{fin}' "
            strSQL = Replace(strSQL, "{inicio}", dtpFechaInicio.Value.ToString(FORMATO_MYSQL))
            strSQL = Replace(strSQL, "{fin}", dtpFechaFin.Value.ToString(FORMATO_MYSQL))
        End If
        If checkCliente.Checked = True Then
            strSQL &= " AND HDoc_Emp_Nom like '%{clientef}%'"
            strSQL = Replace(strSQL, "{clientef}", Trim(celdaClienteFiltro.Text))
        End If
        strSQL &= "" &
            "     group by ID" &
            "     ORDER BY HDoc_Doc_Ano DESC , HDoc_Doc_Num desc"
        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        Return strSQL
    End Function
    Public Sub CargarLista()
        Dim strSQL As String = STR_VACIO
        Dim strFila As String = STR_VACIO
        'Conexiones 
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Try
            strSQL = SQLLista()
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            ListaPagare.Rows.Clear()
            If REA.HasRows Then
                Do While REA.Read
                    strFila = REA.GetInt32("ID") & "|"
                    strFila &= REA.GetInt32("Ano") & "|"
                    strFila &= REA.GetString("Factura") & "|"
                    strFila &= REA.GetString("Deudor") & "|"
                    strFila &= REA.GetString("Usuario") & "|"
                    strFila &= REA.GetString("Activo") & "|"
                    strFila &= REA.GetString("Recibido") & ""
                    cFunciones.AgregarFila(ListaPagare, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)





        End Try
    End Sub
    Private Sub Colorear()

        For i As Integer = 0 To ListaPagare.RowCount - 1
            Select Case ListaPagare.Rows(i).Cells("colActivo").Value
                Case "Anulado"
                    ListaPagare.Rows(i).Cells("colActivo").Style.BackColor = Color.LightCoral
                Case "Recibido"
                    ListaPagare.Rows(i).Cells("colRecibido").Style.BackColor = Color.LightGreen
            End Select
        Next


        For i As Integer = 0 To ListaPagare.RowCount - 1
            Select Case ListaPagare.Rows(i).Cells("colRecibido").Value
                Case "Recibido"
                    ListaPagare.Rows(i).Cells("colRecibido").Style.BackColor = Color.LightGreen
            End Select
        Next
    End Sub

    Private Function DatosdeLista(ByVal logOpcion As Boolean) As String
        'logOpcion= True para recuperar los numerosde factura y False para los numeros de pedido'
        DatosdeLista = STR_VACIO
        ' Dim TempArrayCelda() As String
        ' Dim TempArrayResult() As String
        Dim intColumna As Integer = INT_UNO
        Dim celda As DataGridViewCell
        If logOpcion = True Then
            intColumna = INT_UNO
        Else
            intColumna = 6
        End If
       
        For i As Integer = 0 To ListaFacturas.Rows.Count - 1
            celda = ListaFacturas.Rows(i).Cells(intColumna)
            If DatosdeLista.Length = 0 Then
                DatosdeLista = celda.Value
            Else
                'TempArrayCelda = celda.Value.ToString.Split("|".ToCharArray)
                'If TempArrayCelda.Length > 1 Then
                '    'For j As Integer = 0 To TempArrayCelda.Length - 1
                '    '    TempArrayResult = DatosdeLista.Split("\".ToCharArray)
                '    '    For h As Integer = 0 To TempArrayResult.Length - 1
                '    '        If Not TempArrayResult(h) = TempArrayCelda(j) Then
                '    '            DatosdeLista &= "\" & celda.Value
                '    '        End If
                '    '    Next
                '    'Next
                'Else
                DatosdeLista &= "\" & celda.Value
                'End If
            End If
        Next
        Return DatosdeLista
    End Function

    Private Sub MostrarLista(Optional ByVal logInsert As Boolean = True)
        If logInsert = True Then
            CeldaTitulo.Text = "Lista de Pagarés"
            panelPestañas.Dock = DockStyle.None
            panelPestañas.Visible = False
            PanelLista.Visible = True
            PanelLista.Dock = DockStyle.Fill
            ListaPagare.Dock = DockStyle.Fill
            ListaPagare.Visible = True
            ' cFunciones.CargarLista(ListaPagare, SQLLista)
            CargarLista()
            Colorear()
            checkFecha.Focus()
        Else
            CeldaTitulo.Text = "Modificar registro"
            panelPestañas.Dock = DockStyle.Fill
            panelPestañas.Visible = True
            ListaPagare.DataSource = Nothing
            ListaPagare.Refresh()
            ListaPagare.Dock = DockStyle.None
            ListaPagare.Visible = False
            PanelLista.Visible = False
            PanelLista.Dock = DockStyle.None
        End If
    End Sub

    Private Sub Reset()
        ''Deudor
        etiquetaIdCliente.Text = STR_VACIO
        etiquetaCliente.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaDPIRepresentante.Text = STR_VACIO
        celdaRepresentante.Text = STR_VACIO
        celdaNotario.Text = STR_VACIO
        dtpFNombramiento.Value = Today
        celdaRegistro.Text = STR_VACIO
        celdaLibro.Text = STR_VACIO
        celdaFolio.Text = STR_VACIO
        ''Pagare
        celdaIdPagare.Text = NO_FILA
        celdaAño.Text = NO_FILA
        celdaFactura.Text = INT_CERO
        celdaPedido.Text = INT_CERO
        celdaMoneda.Text = STR_VACIO
        CeldaMonto.Text = STR_VACIO
        celdaInteres.Text = 18
        celdaPlazo.Text = INT_CERO
        dtpVigencia.Value = "01/01/2000"
        dtpVencimiento.Value = Today
        celdaNotificaciones.Text = STR_VACIO
        celdaMunicipioNotificaciones.Text = STR_VACIO
        celdaDepartamentoNotificaciones.Text = STR_VACIO
        ''Fiador
        celdaFiador.Text = STR_VACIO
        celdaDPIFiador.Text = STR_VACIO
        CeldaMunicipioFiador.Text = STR_VACIO
        CeldaDepartamentoFiador.Text = STR_VACIO
        ''Acreedor
        celdaAcreedor.Text = STR_VACIO
        celdaDireccionAcreedor.Text = STR_VACIO
        celdaDireccionAcreedor.Text = cFunciones.OficinasCentrales
        celdaAcreedor.Text = cFunciones.OficinasCentrales(True)
        ListaFacturas.Rows.Clear()
        ListaFacturas.Visible = True
    End Sub

    Private Sub Borrar()
        Dim HDR As New clsDcmtos_HDR
        Dim DTL As New clsDcmtos_DTL
        Dim PRO As New clsDcmtos_DTL_Pro
        Dim strCondicion As String = STR_VACIO
        If LogBorrar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        'Borrar Relecion con facturas DTL_Pro
        strCondicion = "PDoc_Chi_Cat = 465 and PDoc_Chi_Num={idpagare} and PDoc_Sis_Emp= {empresa}"
        strCondicion = Replace(strCondicion, "{idpagare}", celdaIdPagare.Text)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        Try
            PRO.logConexion = False
            PRO.CONEXION = strConexion
            If PRO.Borrar(strCondicion) = False Then
                MsgBox("No se pudo borrar" & PRO.MERROR.ToString)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox("DTL_Pro" & ex.ToString)
        End Try

        '' Borrar detalle de Pagare
        strCondicion = STR_VACIO
        strCondicion = "DDoc_Doc_Cat = 465 and DDoc_Doc_Num = {idpagare}  and DDoc_Doc_Ano = {año} and DDoc_Sis_Emp= {empresa}"
        strCondicion = Replace(strCondicion, "{idpagare}", celdaIdPagare.Text)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        Try
            DTL.CONEXION = strConexion
            If DTL.Borrar(strCondicion) = False Then
                MsgBox("No se pudo borrar" & PRO.MERROR.ToString)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox("DTL -->" & ex.ToString)
        End Try

        ''Borrar encabezado
        strCondicion = STR_VACIO
        strCondicion = "HDoc_Doc_Cat= 465 and HDoc_Doc_Ano= {año} and HDoc_Doc_Num= {idpagare} and HDoc_Sis_Emp = {empresa}"
        strCondicion = Replace(strCondicion, "{idpagare}", celdaIdPagare.Text)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        Try
            HDR.CONEXION = strConexion
            If HDR.Borrar(strCondicion) = False Then
                MsgBox("No se pudo borrar" & PRO.MERROR.ToString)
                Exit Sub
            End If
        Catch ex As Exception
            MsgBox("HDR -->" & ex.ToString)
        End Try
        MostrarLista()
    End Sub

    Private Sub Seleccionar(ByVal strTag As String)
        Dim id As Integer
        Dim año As Integer
        Dim cPagare As New clsPagare
        Dim strCondicion As String = STR_VACIO
        Reset()
        If logConsultar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If strTag = "mod" Then

            If ListaPagare.SelectedRows.Count = 0 Then Exit Sub
            id = CInt(ListaPagare.SelectedCells(0).Value)
            año = CInt(ListaPagare.SelectedCells(1).Value)
            strCondicion = "HDoc_Doc_Num ={id} AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 465 " & _
                " AND HDoc_Doc_Ano = {año}"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{id}", id)
            strCondicion = Replace(strCondicion, "{año}", año)

            botonBuscarCliente.Enabled = False
            ListaFacturas.Visible = True
        Else
            Dim frm As New frmSeleccionar
            Try
                strCondicion = "cli_sisemp= " & Sesion.IdEmpresa
                frm.Tabla = "Clientes"
                frm.Campos = "cli_codigo Código, cli_cliente Nombre_Cliente"
                frm.Condicion = strCondicion
                frm.Limite = 20
                frm.Filtro = "cli_cliente"
                If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                    id = CInt(frm.LLave)
                    etiquetaIdCliente.Text = id
                    etiquetaCliente.Text = frm.Dato
                    celdaCliente.Text = frm.Dato
                    strCondicion = STR_VACIO
                    strCondicion = "HDoc_DR2_Cat ={id} AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat = 465 "
                    strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
                    strCondicion = Replace(strCondicion, "{id}", id)
                    botonBuscarCliente.Enabled = True
                    ListaFacturas.Visible = True
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If

        Try
            If cPagare.Selecionar(strCondicion, STR_ASTERISCO, STR_ASTERISCO, STR_ASTERISCO, " order by  HDoc_Doc_Num DESC ") = True Then
                ''Deudor
                Reset()
                If cPagare.FechaNombramientoVencimiento.IsValidDateTime Then
                    dtpFNombramientoF.Value = cPagare.FechaNombramientoVencimiento
                End If

                If cPagare.NombramientoDefinido = INT_UNO Then
                    CheckNombramiento.Checked = True

                Else
                    CheckNombramiento.Checked = False
                    Dim dias As Integer = CInt(DateDiff(DateInterval.Day, cPagare.FechaNombramientoVencimiento.Value, Today))
                    If dias <= 0 Then

                    ElseIf dias < 61 Then
                        MsgBox("Quedan menos de dos meses para que el nombramiento expire", MsgBoxStyle.Information)
                    End If
                End If
                etiquetaIdCliente.Text = cPagare.DeudorId
                If strTag = "mod" Then
                    cPagare.SeleccionarPro(ListaFacturas, cPagare.PagareId)
                End If
                etiquetaCliente.Text = cPagare.DeudorEmpreas
                celdaCliente.Text = cPagare.DeudorEmpreas
                celdaDPIRepresentante.Text = cPagare.DeudorDPI
                celdaRepresentante.Text = cPagare.DeudorRepresentante
                celdaNotario.Text = cPagare.DeudorNotario
                If cPagare.DeudorFechaNombramiento.IsValidDateTime Then
                    If CDate(cPagare.DeudorFechaNombramiento) > Today Then
                        MsgBox("El nombramiento esta a punto de vencer")
                    End If
                    dtpFNombramiento.Value = cPagare.DeudorFechaNombramiento
                    dtpFNombramiento.Checked = False
                Else
                    dtpFNombramiento.Enabled = False
                    dtpFNombramiento.Checked = True
                End If
                celdaRegistro.Text = cPagare.DeudorRegistro
                celdaLibro.Text = cPagare.DeudorLibro
                celdaFolio.Text = cPagare.DeudorFolio
                ''Pagare
                If strTag = "mod" Then
                    celdaIdPagare.Text = cPagare.PagareId
                    celdaAño.Text = cPagare.PagareAño
                    celdaFactura.Text = cPagare.PagareIdFactura
                    celdaPedido.Text = cPagare.PagarePedido
                    celdaMoneda.Text = cPagare.PagareSimboloMoneda
                    CeldaMonto.Text = Format(cPagare.PagareMonto, FORMATO_MONEDA)
                    celdaInteres.Text = cPagare.PagareInteres
                    If cPagare.Estado = 1 Then
                        checkActivo.Checked = True
                    Else
                        checkActivo.Checked = False
                    End If
                End If

                If cPagare.Recibido = 1 Then
                    checkRecibido.Checked = True
                Else
                    checkRecibido.Checked = False
                End If
                celdaPlazo.Text = cPagare.PagareDias
                If cPagare.PagareFechaIncio.IsValidDateTime Then
                    dtpVigencia.Value = cPagare.PagareFechaIncio
                    dtpVigencia.Checked = False
                Else
                    dtpVigencia.Checked = True
                    dtpVigencia.Enabled = False
                End If
                If cPagare.PagareFechaVencimiento.IsValidDateTime Then
                    dtpVencimiento.Value = cPagare.PagareFechaVencimiento
                    dtpVencimiento.Value = dtpVigencia.Value.AddDays(celdaPlazo.Text)
                    dtpVencimiento.Checked = False
                Else
                    dtpVencimiento.Checked = True
                    dtpVencimiento.Enabled = False
                End If
                celdaNotificaciones.Text = cPagare.DeudorNotificaciones
                celdaMunicipioNotificaciones.Text = cPagare.DeudorNotificacionesMunicipio
                celdaDepartamentoNotificaciones.Text = cPagare.DeudorNotificacionesDepartamento
                ''Fiador
                celdaFiador.Text = cPagare.FiadorNombre
                celdaDPIFiador.Text = cPagare.FiadorDpi
                CeldaMunicipioFiador.Text = cPagare.FiadorMunicipio
                CeldaDepartamentoFiador.Text = cPagare.FiadorDepartamento
                ''Acreedor
                celdaAcreedor.Text = cPagare.AcreedorEmpresa
                celdaDireccionAcreedor.Text = cPagare.AcreedroDireccion
                lblIdMoneda.Text = cPagare.PagareMoneda
                MostrarLista(False)
                Me.Tag = strTag
            End If
        Catch ex As Exception

            MsgBox(ex.ToString)
        Finally
            CON.Dispose()
            CON = Nothing
            cPagare = Nothing
        End Try
    End Sub

    Private Function ComprobarCampos() As Boolean
        'Deudor
        ComprobarCampos = True
        If cFunciones.ValidarCampoTexto(celdaCliente, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaRepresentante, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaNotario, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaDPIRepresentante, 20) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaRegistro) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaFolio) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaLibro) = False Then
            ComprobarCampos = False
        End If
        'Pagaré
        If cFunciones.ValidarCampoTexto(celdaFactura, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaPedido, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaMoneda, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoNumerico(CeldaMonto) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoNumerico(celdaInteres) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaNotificaciones, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaDepartamentoNotificaciones, 255) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaMunicipioNotificaciones, 255) = False Then
            ComprobarCampos = False
        End If
        'Fiador
        If cFunciones.ValidarCampoTexto(celdaFiador, 2500) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaDPIFiador, 20) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(CeldaDepartamentoFiador, 2500) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(CeldaMunicipioFiador, 2500) = False Then
            ComprobarCampos = False
        End If
        'Acreedor
        If cFunciones.ValidarCampoTexto(celdaAcreedor, 2500) = False Then
            ComprobarCampos = False
        End If
        If cFunciones.ValidarCampoTexto(celdaDireccionAcreedor, 2500) = False Then
            ComprobarCampos = False
        End If
    End Function

    Private Sub Guardar()
        Dim cPagare As New clsPagare
        Dim LogNombramiento As Integer = NO_FILA
        If logInsertar = False Then
            MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
            Exit Sub
        End If
        If CheckNombramiento.Checked = True Then
            LogNombramiento = 1
        Else
            LogNombramiento = 0
        End If
        Try
            If ComprobarCampos() = True Then
                'Deudor
                cPagare.DeudorId = etiquetaIdCliente.Text
                cPagare.DeudorEmpreas = celdaCliente.Text
                cPagare.DeudorRepresentante = celdaRepresentante.Text
                cPagare.DeudorDPI = celdaDPIRepresentante.Text
                cPagare.DeudorNotario = celdaNotario.Text
                cPagare.DeudorFechaNombramiento_Net = dtpFNombramiento.Value
                cPagare.DeudorRegistro = celdaRegistro.Text
                cPagare.DeudorFolio = celdaFolio.Text
                cPagare.DeudorLibro = celdaLibro.Text
                'Pagare
                cPagare.PagarePedido = celdaPedido.Text
                cPagare.PagareIdFactura = celdaFactura.Text
                cPagare.PagarePedido = celdaPedido.Text
                cPagare.PagareMoneda = lblIdMoneda.Text
                cPagare.PagareSimboloMoneda = celdaMoneda.Text
                cPagare.PagareMonto = CeldaMonto.Text
                cPagare.PagareInteres = celdaInteres.Text
                cPagare.PagareFechaInicio_Net = dtpVigencia.Value
                cPagare.PagareFechaVencimiento_Net = dtpVencimiento.Value
                cPagare.PagareDias = DateDiff(DateInterval.Day, dtpVigencia.Value, dtpVencimiento.Value)
                cPagare.DeudorNotificaciones = celdaNotificaciones.Text
                cPagare.DeudorNotificacionesDepartamento = celdaDepartamentoNotificaciones.Text
                cPagare.DeudorNotificacionesMunicipio = celdaMunicipioNotificaciones.Text

                cPagare.PagareFecha_Net = dtpVigencia.Value
                cPagare.DeudorFechaNombramiento_Net = dtpFNombramientoF.Value
                cPagare.NombramientoDefinido = LogNombramiento
                cPagare.Facturas = ListaFacturas
                ' indica si el pagare esta activo
                If checkActivo.Checked = True Then
                    cPagare.Estado = 1
                Else
                    cPagare.Estado = 0
                End If
                ' indica si el pagare fue recibido
                If checkRecibido.Checked = True Then
                    cPagare.Recibido = 1
                Else
                    cPagare.Recibido = 0
                End If
                ''Fiador
                cPagare.FiadorNombre = celdaFiador.Text
                cPagare.FiadorDpi = celdaDPIFiador.Text
                cPagare.FiadorMunicipio = CeldaMunicipioFiador.Text
                cPagare.FiadorDepartamento = CeldaMunicipioFiador.Text
                ''Acreedor
                cPagare.AcreedorEmpresa = celdaAcreedor.Text
                cPagare.AcreedroDireccion = celdaDireccionAcreedor.Text
                If Me.Tag = "mod" Then
                    If logEditar = False Then
                        MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                        Exit Sub
                    End If
                    cPagare.PagareId = CInt(celdaIdPagare.Text)
                    cPagare.PagareAño = CInt(celdaAño.Text)
                    cPagare.PagareEmpresa = Sesion.IdEmpresa
                    If cPagare.Guardar(True) = True Then
                        MostrarLista(True)
                    Else
                        MsgBox(" Nos se pudo guardar el documento")
                    End If
                Else
                    If logInsertar = False Then
                        MsgBox("No posee suficientes privilegios para ejecutar esta transacción")
                        Exit Sub
                    End If
                    If cPagare.Guardar() = True Then
                        cPagare.PagareAño = cFunciones.AñoMySQL
                        MsgBox("Documento guardado correctamente!")
                        MostrarLista(True)
                    Else
                        MsgBox("No se pudo guardar el documento")
                    End If
                End If
            Else
                MsgBox("Todos los campos son obligatorios")
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function GuardarEncabezado() As Boolean
        Dim LogVerificar As Boolean = False
        Dim HDR As New clsDcmtos_HDR
        Try
            HDR.CONEXION = strConexion
            HDR.HDOC_SIS_EMP = Sesion.IdEmpresa
            HDR.HDOC_DOC_CAT = 465
            HDR.HDoc_Doc_Fec_NET = dtpVigencia.Value
            HDR.HDOC_EMP_COD = celdaFactura.Text
            HDR.HDOC_EMP_NOM = celdaCliente.Text
            HDR.HDOC_EMP_TEL = celdaMoneda.Text
            HDR.HDOC_EMP_NIT = celdaPedido.Text
            HDR.HDOC_EMP_DIR = celdaDireccionAcreedor.Text
            HDR.HDOC_EMP_PER = celdaAcreedor.Text
            HDR.HDOC_DR1_CAT = lblIdMoneda.Text
            HDR.HDOC_DR1_DBL = CeldaMonto.Text
            HDR.HDoc_DR1_Fec_NET = dtpVigencia.Value
            HDR.HDOC_DR1_EMP = DateDiff(DateInterval.Day, dtpVigencia.Value, dtpVencimiento.Value)
            HDR.HDoc_DR2_Fec_NET = dtpFNombramientoF.Value
            HDR.HDOC_RF1_COD = celdaDPIRepresentante.Text
            HDR.HDOC_RF2_COD = celdaRepresentante.Text
            HDR.HDOC_DR1_NUM = celdaNotario.Text
            HDR.HDOC_USUARIO = Sesion.Usuario
            HDR.HDoc_Pro_Fec_NET = dtpFNombramiento.Value
            HDR.HDOC_PRO_DCAT = celdaRegistro.Text
            HDR.HDOC_PRO_DANO = celdaLibro.Text
            HDR.HDOC_PRO_DNUM = celdaFolio.Text
            HDR.HDOC_DOC_TC = celdaInteres.Text
            HDR.HDOC_DR2_CAT = etiquetaIdCliente.Text
            If checkActivo.Checked = True Then
                HDR.HDOC_DOC_STATUS = 1
            Else
                HDR.HDOC_DOC_STATUS = 0
            End If
            ' indica si el pagare fue recibido
            If checkRecibido.Checked = True Then
                HDR.HDOC_RF1_NUM = 1
            Else
                HDR.HDOC_RF1_NUM = 0
            End If
            If Me.Tag = "nuevo" Then
                celdaAño.Text = cFunciones.AñoMySQL
                HDR.HDOC_DOC_ANO = celdaAño.Text
                HDR.HDOC_DOC_NUM = cFunciones.NuevoId(465)
                If HDR.Guardar = True Then
                    LogVerificar = True
                Else
                    LogVerificar = False
                End If
                If GuardarDetalle(HDR.HDOC_DOC_NUM, celdaAño.Text) = True Then
                    LogVerificar = True
                Else
                    LogVerificar = False
                End If
                If GuardarDTLPRO(HDR.HDOC_DOC_NUM, celdaAño.Text) Then
                    LogVerificar = True
                Else
                    LogVerificar = False
                End If
            Else
                HDR.HDOC_DOC_ANO = celdaAño.Text
                HDR.HDOC_DOC_NUM = celdaIdPagare.Text
                If HDR.Actualizar = True Then
                    LogVerificar = True
                Else
                    LogVerificar = False
                End If
                If GuardarDetalle(HDR.HDOC_DOC_NUM, celdaAño.Text) = True Then
                    LogVerificar = True
                Else
                    LogVerificar = False
                End If
                If GuardarDTLPRO(HDR.HDOC_DOC_NUM, celdaAño.Text) Then
                    LogVerificar = True
                Else
                    LogVerificar = False
                End If


            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return LogVerificar
    End Function
    Private Function GuardarDetalle(ByVal Codigo As Integer, ByVal Anio As Integer) As Boolean
        Dim logVerificar As Boolean = False
        Dim DTL As New clsDcmtos_DTL
        Dim logNombramiento As Integer = NO_FILA
        Try
            DTL.CONEXION = strConexion

            If CheckNombramiento.Checked = True Then
                logNombramiento = 1
            Else
                logNombramiento = 0
            End If


            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = 465
            DTL.DDOC_DOC_ANO = Anio
            DTL.DDOC_DOC_NUM = Codigo
            DTL.DDOC_DOC_LIN = INT_UNO
            DTL.DDOC_PRD_PNR = "FIADOR"
            DTL.DDOC_PRD_DES = celdaFiador.Text
            DTL.DDOC_RF1_COD = celdaDPIFiador.Text
            DTL.DDOC_RF2_COD = CeldaMunicipioFiador.Text
            DTL.DDOC_PRD_REF = CeldaDepartamentoFiador.Text
            If Me.Tag = "mod" Then
                If DTL.Actualizar = False Then
                    MsgBox(DTL.MERROR.ToString & "Could Not modify this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logVerificar = True
                End If
            Else

                If DTL.Guardar = False Then
                    MsgBox(DTL.MERROR.ToString & "Could Not save this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logVerificar = True
                End If
            End If

            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
            DTL.DDOC_DOC_CAT = 465
            DTL.DDOC_DOC_ANO = Anio
            DTL.DDOC_DOC_NUM = Codigo
            DTL.DDOC_DOC_LIN = 2
            DTL.DDOC_PRD_PNR = "NOTIFICACIONES"
            DTL.DDOC_RF1_TXT = celdaNotificaciones.Text
            DTL.DDOC_RF2_COD = celdaMunicipioNotificaciones.Text
            DTL.DDOC_PRD_REF = celdaDepartamentoNotificaciones.Text
            If Me.Tag = "mod" Then
                If DTL.Actualizar = False Then
                    MsgBox(DTL.MERROR.ToString & "Could Not modify this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logVerificar = True
                End If
            Else

                If DTL.Guardar = False Then
                    MsgBox(DTL.MERROR.ToString & "Could Not save this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logVerificar = True
                End If

            End If

            DTL.DDOC_SIS_EMP = Sesion.IdEmpresa
                DTL.DDOC_DOC_CAT = 465
                DTL.DDOC_DOC_ANO = Anio
                DTL.DDOC_DOC_NUM = Codigo
                DTL.DDOC_DOC_LIN = 3
                DTL.DDOC_PRD_PNR = "NOMBRAMIENTO"
                DTL.DDOC_PRD_DES = celdaNotario.Text
                DTL.DDOC_PRD_UM = logNombramiento
                DTL.DDoc_RF1_Fec_NET = dtpFNombramiento.Value
                DTL.DDoc_RF2_Fec_NET = dtpVencimiento.Value
            If Me.Tag = "mod" Then
                If DTL.Actualizar = False Then
                    MsgBox(DTL.MERROR.ToString & "Could Not modify this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logVerificar = True
                End If
            Else

                If DTL.Guardar = False Then
                    MsgBox(DTL.MERROR.ToString & "Could Not save this document", MsgBoxStyle.Critical)
                    Return False
                    Exit Function
                Else
                    logVerificar = True
                End If
            End If






        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerificar
    End Function
    Private Function GuardarDTLPRO(ByVal Codigo As Integer, ByVal Anio As Integer) As Boolean
        Dim PRO_Fact As New clsDcmtos_DTL_Pro
        Dim logVerificar As Boolean = False
        Try
            For i As Integer = 0 To ListaFacturas.Rows.Count - 1


                PRO_Fact.CONEXION = strConexion
                PRO_Fact.PDOC_SIS_EMP = Sesion.IdEmpresa
                PRO_Fact.PDOC_PAR_CAT = 36
                PRO_Fact.PDOC_PAR_ANO = CInt(ListaFacturas.Rows(i).Cells(0).Value)
                PRO_Fact.PDOC_PAR_NUM = CInt(ListaFacturas.Rows(i).Cells(1).Value)
                PRO_Fact.PDOC_PAR_LIN = INT_UNO
                PRO_Fact.PDOC_CHI_CAT = 465
                PRO_Fact.PDOC_CHI_ANO = Anio
                PRO_Fact.PDOC_CHI_NUM = Codigo
                PRO_Fact.PDOC_CHI_LIN = INT_UNO
                PRO_Fact.PDOC_CLTE_COD = Sesion.IdEmpresa
                PRO_Fact.PDOC_QTY_PRO = CDbl(ListaFacturas.Rows(i).Cells(5).Value)
                PRO_Fact.PDOC_DR1_NUM = CStr(ListaFacturas.Rows(i).Cells(6).Value)
                If Me.Tag = "mod" Then
                    If checkActivo.Checked = False Then
                        If PRO_Fact.Borrar = False Then
                            MsgBox(PRO_Fact.MERROR.ToString & "Could Not delete this document", MsgBoxStyle.Critical)
                            Return False
                            Exit Function
                        Else
                            logVerificar = True
                        End If
                    End If
                Else

                    If PRO_Fact.Guardar() = False Then
                        MsgBox(PRO_Fact.MERROR.ToString & "Could Not save this document", MsgBoxStyle.Critical)
                        Return False
                        Exit Function
                    Else
                        logVerificar = True
                    End If
                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logVerificar
    End Function

    Private Function ComprobarFactura(ByVal año As Integer, ByVal id As Integer, ByVal intMoneda As String) As Boolean
        ComprobarFactura = True
        Dim celda As DataGridViewCell
        Dim intaño As Integer = INT_CERO
        Dim intId As Integer = NO_FILA
        Dim modena As String = STR_VACIO
        For i As Integer = 0 To ListaFacturas.Rows.Count - 1
            celda = ListaFacturas.Rows(i).Cells(0)
            intaño = CInt(celda.Value)
            celda = ListaFacturas.Rows(i).Cells(1)
            intId = CInt(celda.Value)
            celda = ListaFacturas.Rows(i).Cells(4)
            modena = celda.Value
            If intaño = año And intId = id Then
                ComprobarFactura = True
            End If
            If Not intMoneda = modena Then
                ComprobarFactura = False
            End If
        Next
    End Function

    Private Function MontoActualizado() As Double
        Dim dblMonto As Double = INT_CERO
        Dim celda As DataGridViewCell
        For i As Integer = 0 To ListaFacturas.Rows.Count - 1
            celda = ListaFacturas.Rows(i).Cells(5)
            dblMonto = dblMonto + celda.Value
        Next
        Return dblMonto
    End Function

    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Botones1.botonBorrar.Enabled = False
            Botones1.botonGuardar.Enabled = False
            botonExportar.Enabled = False
        Else
            Botones1.botonBorrar.Enabled = True
            Botones1.botonGuardar.Enabled = True
            botonExportar.Enabled = True
        End If
    End Sub

#End Region

    Private Sub botonExportar_Click(sender As Object, e As EventArgs) Handles botonExportar.Click
        Dim cPagare As New clsPagare
        Dim frm As New frmMensaje
        Dim strCondicion As String = STR_VACIO
        Dim strPath As String = STR_VACIO
        Dim strFMoneda As String = STR_VACIO
        frm.Show()
        strCondicion = "HDoc_Sis_Emp = {idempresa} And HDoc_Doc_Num = {id} AND HDoc_Doc_Ano = {año}"
        strCondicion = Replace(strCondicion, "{año}", celdaAño.Text)
        strCondicion = Replace(strCondicion, "{idempresa}", Sesion.IdEmpresa)
        strCondicion = Replace(strCondicion, "{id}", celdaIdPagare.Text)
        strPath = cFunciones.CopiarArchivo("Pagare.docx", "Pagare1")
        If cPagare.Selecionar(strCondicion, STR_ASTERISCO, STR_ASTERISCO, STR_ASTERISCO) = True Then
            ''Datos del Deudor
            cFunciones.LimpiarParametros()
            cFunciones.AgregarParametro("{deudorempresa}", celdaCliente.Text)
            cFunciones.AgregarParametro("{deudorrepresentante}", celdaRepresentante.Text)
            cFunciones.AgregarParametro("{notario}", celdaNotario.Text)
            cFunciones.AgregarParametro("{fechanombramiento}", dtpFNombramientoF.Value)
            cFunciones.AgregarParametro("{noregistro}", celdaRegistro.Text)
            cFunciones.AgregarParametro("{folio}", celdaFolio.Text)
            cFunciones.AgregarParametro("{libro}", celdaLibro.Text)
            cFunciones.AgregarParametro("{deudordpi}", celdaDPIRepresentante.Text)
            'Datos del Acreedor
            cFunciones.AgregarParametro("{acreedorempresa}", celdaAcreedor.Text)
            cFunciones.AgregarParametro("{acreedordireccion}", celdaDireccionAcreedor.Text)
            'Datos del Fiador
            cFunciones.AgregarParametro("{fiador}", celdaFiador.Text)
            cFunciones.AgregarParametro("{fiadordpi}", celdaDPIFiador.Text)
            cFunciones.AgregarParametro("{fiadormunicipio}", CeldaMunicipioFiador.Text)
            cFunciones.AgregarParametro("{fiadordepartamento}", CeldaDepartamentoFiador.Text)
            'Datos del Pagare
            cFunciones.AgregarParametro("{nofactura}", DatosdeLista(True))
            strFMoneda = Format(cPagare.PagareMonto, FORMATO_MONEDA)
            cFunciones.AgregarParametro("{monto}", strFMoneda)
            cFunciones.AgregarParametro("{montoletras}", cFunciones.ALetras(CeldaMonto.Text, lblIdMoneda.Text))
            cFunciones.AgregarParametro("{moneda}", celdaMoneda.Text)
            cFunciones.AgregarParametro("{diasletras}", cFunciones.ALetras(DateDiff(DateInterval.Day, dtpVigencia.Value, dtpVencimiento.Value)))
            cFunciones.AgregarParametro("{diasplazo}", DateDiff(DateInterval.Day, dtpVigencia.Value, dtpVencimiento.Value))
            cFunciones.AgregarParametro("{inicio}", dtpVigencia.Value)
            cFunciones.AgregarParametro("{vencimiento}", dtpVencimiento.Value)
            cFunciones.AgregarParametro("{porcentaje}", celdaInteres.Text)
            cFunciones.AgregarParametro("{porcentajel}", cFunciones.ALetras(celdaInteres.Text))
            cFunciones.AgregarParametro("{notificacion}", celdaNotificaciones.Text)
            cFunciones.AgregarParametro("{lugar}", "Guatemala")
            cFunciones.AgregarParametro("{departamento}", "Ciudad de Guatemala")
            cFunciones.AgregarParametro("{notificacionmunicipio}", celdaMunicipioNotificaciones.Text)
            cFunciones.AgregarParametro("{notificaciondepartamento}", celdaDepartamentoNotificaciones.Text)
            cFunciones.AgregarParametro("{dia}", dtpVigencia.Value.Day)
            cFunciones.AgregarParametro("{mes}", cFunciones.MesALetras(dtpVigencia.Value.Month))
            cFunciones.AgregarParametro("{año}", dtpVigencia.Value.Year)
            cFunciones.AgregarParametro("{niidea}", DatosdeLista(False))
            cFunciones.WordBuscaryReemplazar(strPath)
            frm.Close()
        End If
    End Sub

    Private Sub Botones1_ClickBorrar(sender As Object, click As Boolean) Handles Botones1.ClickBorrar
        If Me.Tag = "mod" Then
            If LogBorrar = True Then
                If MsgBox("¿Esta seguro que desea borrar este registro?" & vbNewLine & " Si elige 'Si' los datos de este documento " & vbNewLine & "no se podrán recuperar.", MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then
                    Borrar()
                End If
            Else
                MsgBox("No tiene los suficientes privilegios para borrar este documento", vbInformation)
            End If
        End If
    End Sub

    Private Sub Botones1_ClickCerrar(sender As Object, click As Boolean) Handles Botones1.ClickCerrar
        If panelPestañas.Visible = True Then
            MostrarLista()
            BloquearBotones()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub Botones1_ClickGuardar(sender As Object, click As Boolean) Handles Botones1.ClickGuardar
        If ComprobarCampos() = True Then
            If GuardarEncabezado() = True Then
                MostrarLista(True)
            End If
        Else
            MsgBox("Todos los campos son obligatorios")
        End If

    End Sub

    Private Sub Botones1_ClickNuevo(sender As Object, click As Boolean) Handles Botones1.ClickNuevo
        MostrarLista(False)
        Reset()
        checkActivo.Checked = True
        botonBuscarCliente.Enabled = True
        BloquearBotones(False)
        Me.Tag = "nuevo"
    End Sub

    Private Sub ListaPagare_DoubleClick(sender As Object, e As EventArgs) Handles ListaPagare.DoubleClick
        Seleccionar("mod")
        BloquearBotones(False)
    End Sub

    Private Sub ListaPagare_KeyDown(sender As Object, e As KeyEventArgs) Handles ListaPagare.KeyDown
        'Seleccionar("mod")
        'BloquearBotones(False)
    End Sub

    Private Sub frmPagare_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Fprincipal.BarraDeTareas1.QuitarFormulario(strkey)
    End Sub

    Private Sub frmPagare_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cAccesos As New clsAccesos
        'inicializar rango de fecha 1 mes
        dtpFechaInicio.Value = dtpFechaInicio.Value.AddDays(-30)
        dtpFechaFin.Value = Today

        Try
            If cAccesos.Accesos(strkey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
                If logConsultar = True Then
                    MostrarLista()
                    BloquearBotones()
                Else
                    Me.Close()
                End If
            Else
                Me.Close()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
      
    End Sub

    Private Sub botonBuscarCliente_Click(sender As Object, e As EventArgs) Handles botonBuscarCliente.Click
        Seleccionar("nuevo")
    End Sub

    Private Sub botonSelFacturas_Click(sender As Object, e As EventArgs) Handles botonSelFacturas.Click
        Dim FRM As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "Hdoc_Emp_Cod= {cliente} AND HDoc_Sis_Emp = {empresa} AND HDoc_Doc_Cat= 36 and HDoc_Doc_Status = 1 AND PDoc_Chi_Num IS NULL "
        strCondicion = Replace(strCondicion, "{cliente}", etiquetaIdCliente.Text)
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
        FRM.Tabla = "Dcmtos_HDR LEFT JOIN Dcmtos_DTL_Pro  ON PDoc_Sis_Emp = HDoc_Sis_Emp AND PDoc_Par_Cat = HDoc_Doc_Cat AND PDoc_Par_Ano = HDoc_Doc_Ano AND PDoc_Par_Num = HDoc_Doc_Num AND PDoc_Chi_Cat = 465 "
        FRM.Titulo = "Factura"
        FRM.FiltroText = "Ingrese el número de factura para filtrar"
        FRM.Ordenamiento = "HDoc_Doc_Fec"
        FRM.Campos = "HDoc_Doc_Ano Ano, HDoc_Doc_Num Factura, HDoc_RF2_Num Dias_Credito,HDoc_Emp_Nom " & _
            " DTNombre_Cliente,HDoc_Doc_Fec Fecha "
        frm.Condicion = strCondicion
        FRM.Limite = 50
        FRM.Filtro = "HDoc_Doc_Num"
        If FRM.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            Dim HDR As New clsDcmtos_HDR
            strCondicion = STR_VACIO
            strCondicion = "HDoc_Sis_Emp= {empresa} AND HDoc_Doc_Cat = 36 AND HDoc_Doc_Ano = {año}" & _
                " AND HDoc_Doc_Num = {numero}"
            strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)
            strCondicion = Replace(strCondicion, "{año}", FRM.LLave)
            strCondicion = Replace(strCondicion, "{numero}", FRM.Dato)
            Dim strCampos As String = "HDoc_Doc_Ano,HDoc_Doc_Num,HDoc_Emp_Nom, HDoc_Doc_Fec, HDoc_Doc_Mon, HDoc_Sis_Emp"
            Try
                HDR.CONEXION = strConexion
                If HDR.Seleccionar(strCondicion, strCampos) = True Then
                    If ListaFacturas.RowCount = 0 Then

                        Dim Cell As DataGridViewCell
                        Dim Row = New DataGridViewRow
                        Dim cCatalogo As New clsCatalogos
                        Try
                            cCatalogo.CONEXION = strConexion
                            strCondicion = STR_VACIO
                            strCondicion = "cat_num = " & HDR.HDOC_DOC_MON
                            If cCatalogo.Seleccionar(strCondicion, "cat_clave, cat_num") = False Then
                                MsgBox(cCatalogo.MERROR.ToString)
                            End If
                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try
                        If ComprobarFactura(HDR.HDOC_DOC_ANO, HDR.HDOC_DOC_NUM, cCatalogo.CAT_CLAVE) = True Then
                            Dim cPagare As New clsPagare
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = HDR.HDOC_DOC_ANO
                            Row.Cells.Add(Cell)
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = HDR.HDOC_DOC_NUM
                            Row.Cells.Add(Cell)
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = HDR.HDOC_EMP_NOM
                            Row.Cells.Add(Cell)
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = HDR.HDOC_DOC_FEC
                            dtpVigencia.Value = HDR.HDOC_DOC_FEC
                            Row.Cells.Add(Cell)
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = cCatalogo.CAT_CLAVE
                            Row.Cells.Add(Cell)
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = Format(cPagare.CalcularMonto(HDR.HDOC_DOC_ANO, HDR.HDOC_SIS_EMP, HDR.HDOC_DOC_NUM), FORMATO_MONEDA)
                            Row.Cells.Add(Cell)
                            Cell = New DataGridViewTextBoxCell
                            Cell.Value = cPagare.Pedidos
                            Row.Cells.Add(Cell)
                            ListaFacturas.Rows.Add(Row)
                            celdaMoneda.Text = cCatalogo.CAT_CLAVE
                            CeldaMonto.Text = Format(MontoActualizado, FORMATO_MONEDA)
                            lblIdMoneda.Text = cCatalogo.CAT_NUM
                            If dtpVigencia.Value < CDate(HDR.HDOC_DOC_FEC) Then
                                dtpVigencia.Value = HDR.HDOC_DOC_FEC
                            End If
                            ' If CInt(FRM.Dato2) > CInt(celdaPlazo.Text) Then
                            celdaPlazo.Text = FRM.Dato2
                                dtpVencimiento.Value = dtpVigencia.Value.AddDays(FRM.Dato2)
                            ' End If
                        End If
                    Else
                        MsgBox("Error ya tiene asignado una factura", MsgBoxStyle.Information)
                    End if 
                    ' CeldaMonto.Text = Format(MontoActualizado(), FORMATO_MONEDA)
                Else
                    MsgBox(HDR.MERROR.ToString)
                End If
            Catch ex As Exception
                MsgBox(ex.ToString)
            End Try
        End If
    End Sub

    Private Sub ListaFacturas_RowsRemoved(sender As Object, e As DataGridViewRowsRemovedEventArgs) Handles ListaFacturas.RowsRemoved
        CeldaMonto.Text = Format(MontoActualizado, FORMATO_MONEDA)
    End Sub

    Private Sub dtpFNombramiento_LostFocus(sender As Object, e As EventArgs) Handles dtpFNombramiento.LostFocus
        Pestañas.SelectedIndex = 1
    End Sub

    Private Sub CheckNombramiento_CheckedChanged(sender As Object, e As EventArgs) Handles CheckNombramiento.CheckedChanged
        If CheckNombramiento.Checked = True Then
            dtpFNombramientoF.Enabled = False
        Else
            dtpFNombramientoF.Enabled = True
        End If
    End Sub

    Private Sub celdaPlazo_TextChanged(sender As Object, e As EventArgs) Handles celdaPlazo.TextChanged
        cFunciones.ValidarCampoNumerico(celdaPlazo)
    End Sub

    Private Sub botonFiltar_Click(sender As Object, e As EventArgs) Handles botonFiltar.Click
        '  cFunciones.CargarLista(ListaPagare, SQLLista)
        CargarLista()
        Colorear()
    End Sub

    Private Sub celdaClienteFiltro_KeyDown(sender As Object, e As KeyEventArgs) Handles celdaClienteFiltro.KeyDown
        If e.KeyCode = Keys.Enter Then
            CargarLista()
            Colorear()
            e.Handled = True
            e.SuppressKeyPress = True
        End If
    End Sub

 
    Private Sub TabDeudor_Click(sender As Object, e As EventArgs) Handles TabDeudor.Click

    End Sub

    Private Sub botonCliente_Click(sender As Object, e As EventArgs) Handles botonCliente.Click
        Dim frm As New frmSeleccionar
        'Propiedades de la consulta 
        frm.Campos = " cli_codigo Code, cli_cliente Client"
        frm.Tabla = " Clientes"
        frm.Condicion = " cli_sisemp = " & Sesion.IdEmpresa & ""
        frm.Ordenamiento = " cli_cliente"
        frm.Filtro = " cli_cliente"
        frm.Limite = " 20 "
        ' Propiedades del Formulario 
        frm.Titulo = "Provider"
        frm.FiltroText = "Enter the name of the client to filter"
        If frm.ShowDialog = System.Windows.Forms.DialogResult.OK Then
            celdaClienteFiltro.Text = frm.Dato
        End If
    End Sub

    Private Sub checkCliente_CheckedChanged(sender As Object, e As EventArgs) Handles checkCliente.CheckedChanged
        If checkCliente.Checked = True Then
            botonCliente.Enabled = True
        Else
            botonCliente.Enabled = False
        End If
    End Sub

    Private Sub Pestañas_DoubleClick(sender As Object, e As EventArgs) Handles Pestañas.DoubleClick
        Me.Tag = "mod"
        If Pestañas.TabPages.Count = 4 Then
            Seleccionar("mod")
        End If
    End Sub
End Class


