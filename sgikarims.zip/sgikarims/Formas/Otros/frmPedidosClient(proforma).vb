﻿Public Class frmPedidosClient_proforma_


#Region "Miembros"
    Dim strKey As String = STR_VACIO
    Dim logInsertar As Boolean = False
    Dim logConsultar As Boolean = False
    Dim logEditar As Boolean = False
    Dim LogBorrar As Boolean = False
    Const CAT_ORD As Integer = 777
    Dim cfun As New clsFunciones
    Dim intCurDoc As Integer
    Dim contratoNum As Integer
    Dim Descargos As Integer
    Private Const DOC_NAME As String = "Doc_CPedido"
    Dim strTextoComentario As String

    Private dblSaldo As Double
    Private intLinea As Integer
    Private dblDocCantidad As Double
    Private dblDocTotal As Double

    'Constantes
    Public Const PRE_PF As String = "PF "
    Public Const TBL_DOCUMENTOS As String = "Dcmtos_HDR"
    Private Const STR_NOMBRE As String = "cliente"

    'Si el documento tiene descargos indica la línea mayor
    Private intMaxRef As Integer

    Public logRelacion As Boolean

    Dim dtpDetalle As DateTimePicker

#End Region

#Region "Propiedades"
    Public Property Key As String
        Get
            Return strKey
        End Get
        Set(value As String)
            strKey = value
        End Set
    End Property
#End Region

#Region "Procedimientos"
    Private Sub BloquearBotones(Optional ByVal logBloquear As Boolean = True)
        If logBloquear = True Then
            Encabezado1.botonBorrar.Enabled = False
            Encabezado1.botonGuardar.Enabled = False
            botonContrato.Enabled = False
            botonImprimir.Enabled = False
            botonBuscar.Enabled = True
            botonOrdenProduccion.Enabled = False

        Else
            Encabezado1.botonBorrar.Enabled = True
            Encabezado1.botonGuardar.Enabled = True
            botonImprimir.Enabled = True
            botonBuscar.Enabled = False
            botonOrdenProduccion.Enabled = True
        End If
    End Sub

    Private Sub Accessos()
        Dim cAccesos As New clsAccesos
        Try
            If cAccesos.Accesos(strKey) = True Then
                logInsertar = cAccesos.Insertar
                logConsultar = cAccesos.Consultar
                logEditar = cAccesos.Editar
                LogBorrar = cAccesos.Borrar
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub MostrarLista(Optional ByVal logMostrar As Boolean = True, Optional logInsert As Boolean = False)
        Dim cfun As New clsFunciones
        If logMostrar = True Then
            'Ocultar Panel de Documento
            panelDocumento.Dock = DockStyle.None
            panelDocumento.Visible = False
            'Actualizar Titulo
            BarraTitulo1.CambiarTitulo("Customer Order(Proforma)")
            queryListaPrincipal()
            panelLista.Visible = True
            panelLista.Dock = DockStyle.Fill
            BloquearBotones()

            'Me.Tag = "Nuevo"
            If Sesion.idGiro = 2 Then
                botonOrdenProduccion.Visible = True

            Else
                botonOrdenProduccion.Visible = False

            End If
        Else
            'Ocultar Panel Filtro
            panelLista.Visible = False
            panelLista.Dock = DockStyle.None
            'Mostrar Panel de Documento
            panelDocumento.Dock = DockStyle.Fill
            panelDocumento.Visible = True
            If Sesion.idGiro = 2 Then
                botonOrdenProduccion.Visible = True
                botonOrdenProduccion.Enabled = True
            Else
                botonOrdenProduccion.Visible = False
                botonOrdenProduccion.Enabled = False
            End If
            'Verifica si se va a Crear un nuevo Documento o se va a modificar
            If logInsert = False Then
                If celdaidProyecto.Text <> NO_FILA Then
                    BarraTitulo1.CambiarTitulo("Modify Registration Project # " & celdaidProyecto.Text & "  " & celdaProyecto.Text & "")
                Else
                    BarraTitulo1.CambiarTitulo("Modify Registration")
                End If

                '   BarraTitulo1.CambiarTitulo("Modify Registration")
                Me.Tag = "Mod"
                BloquearBotones(False)

            Else
                BarraTitulo1.CambiarTitulo("New Register")
                Me.Tag = "Nuevo"
                BloquearBotones(False)
            End If
            'Reset()


            dgLista.DataSource = Nothing
        End If
    End Sub

    Private Function SQLLista() As String

        Dim strFiltrarLista As String
        Dim ErrorLog As String

        On Error GoTo e_error

        strFiltrarLista = " Select HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, HDoc_Emp_Nom cliente, HDoc_DR1_Num referencia, HDoc_RF1_Txt texto, HDoc_Doc_Status estado, HDoc_Doc_Ano anio, HDoc_emp_Dir Direccion, HDoc_Pro_DCat Revisado"
        strFiltrarLista &= "    From Dcmtos_HDR"
        strFiltrarLista &= "    Where HDoc_Sis_Emp = {empresa} And HDoc_Doc_Cat = 75"

        If Checkfecha.Checked = True Then

            strFiltrarLista &= " AND (HDoc_Doc_Fec BETWEEN '{fechainicio}' AND '{fechafin}') "

            strFiltrarLista = Replace(strFiltrarLista, "{fechainicio}", dtpInicio.Value.ToString(FORMATO_MYSQL))
            strFiltrarLista = Replace(strFiltrarLista, "{fechafin}", dtpFinal.Value.ToString(FORMATO_MYSQL))
        End If

        strFiltrarLista &= "   Order By HDoc_Doc_Ano DESC, HDoc_Doc_Num DESC"


        strFiltrarLista = Replace(strFiltrarLista, "{empresa}", Sesion.IdEmpresa)

        Return strFiltrarLista


e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        ' ErrorLog "Formulario -> Form.SqlLista()"
        On Error GoTo 0


    End Function

    Private Function SQLDetalle(ByVal intNumero As Integer, ByVal intAño As Integer) As String

        Dim strsql As String
        Dim errorLog As String

        On Error GoTo e_error

        strsql = " Select HDoc_Sis_Emp empresa, HDoc_Doc_Cat catalogo, HDoc_Doc_Ano anio, HDoc_Doc_Num numeroDoc, HDoc_Doc_Fec fecha, HDoc_Emp_Cod codEmpresa, HDoc_Emp_Nom nombreEmp, HDoc_Emp_Dir direccion, HDoc_Emp_Per contacto, HDoc_Emp_Tel telefono, HDoc_Emp_Nit NIT, HDoc_DR1_Emp IdSolicitante, HDoc_DR1_Num docNum, HDoc_DR1_Fec fechaDoc, HDoc_RF1_Cod solicitante, HDoc_RF1_Txt empSolicitante, HDoc_RF2_Cod numeroTel, HDoc_Doc_TC tasa, HDoc_Doc_Mon moneda, HDoc_Doc_Status estatus, cli_codigo codCliente, cli_cliente cliente, cli_direccion direccionCli, cli_telefono telCliente, cat_clave Moneda, HDoc_Pro_DCat Revisado, HDoc_DR2_Emp Impuesto, IFNULL(t.IdProyecto,-1) idproyecto , IFNULL(t.idTareas,-1) idTarea,IFNULL(t.idFlujoDet,-1)idFlujoDetalle,IFNULL(pr.Nombre,'')Nombre,IFNULL(p.Nombre,'') NombreP,IFNULL(p.Descripcion,'')Descripcion "
        strsql &= "    From Dcmtos_HDR"
        strsql &= "        Left Join Clientes ON cli_codigo = HDoc_DR1_Emp And cli_sisemp = {empresa}"
        strsql &= "    LEFT JOIN Catalogos ON  cat_num = HDoc_Doc_Mon"
        strsql &= " LEFT JOIN Tareas t ON t.Empresa = HDoc_Sis_Emp AND t.catalogo = HDoc_Doc_Cat AND t.ano = HDoc_Doc_Ano AND t.numero = HDoc_Doc_Num "
        strsql &= " LEFT JOIN Proyecto p ON p.Empresa = t.Empresa AND p.idProyecto = t.IdProyecto "
        strsql &= " LEFT JOIN Flujo_Detalle f ON f.Empresa = p.Empresa AND f.idFlujo = p.idFlujo AND f.idFlujoDet = t.idFlujoDet "
        strsql &= " LEFT JOIN Proceso pr ON pr.Empresa = f.Empresa AND pr.idProceso = f.idProceso "
        strsql &= " WHERE HDoc_Doc_Cat = 75 And HDoc_Sis_Emp = {empresa} And HDoc_Doc_Num = {numero} And HDoc_Doc_Ano = {anio}"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        ' ErrorLog "Formulario -> Form.SqlLista()"
        On Error GoTo 0

    End Function

    Private Function SQLContratos(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strsql As String
        Dim errorLog As String

        On Error GoTo e_error

        strsql = " Select DISTINCT HDoc_Doc_Cat catalogo, HDoc_Doc_Ano anio, HDoc_Doc_Num numero, HDoc_Doc_Fec fecha, HDoc_Usuario usuario, HDoc_DR1_Num referencia"
        strsql &= "    From Dcmtos_DTL_Pro a"
        strsql &= "        INNER Join Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp And a.PDoc_Par_Cat = b.HDoc_Doc_Cat And a.PDoc_Par_Ano = b.HDoc_Doc_Ano And a.PDoc_Par_Num = b.HDoc_Doc_Num"
        strsql &= "    WHERE a.PDoc_Sis_Emp = {empresa} And a.PDoc_Chi_Cat = 75 And a.PDoc_Chi_Ano = {año} And a.PDoc_Chi_Num = {numero}"
        strsql &= " ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"


        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{año}", intAño)
        strsql = Replace(strsql, "{numero}", intNumero)

        Return strsql

e_salir:
        On Error GoTo 0
        Exit Function

e_error:

        On Error GoTo 0


    End Function

    Private Function SQLDetalleDown(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strsql As String
        Dim errorLog As String

        On Error GoTo e_error

        strsql = " SELECT DDoc_Prd_Cif precioKG,DDoc_Sis_Emp, DDoc_Doc_Cat Catalogo, DDoc_Doc_Ano Anio, DDoc_Doc_Num, DDoc_Prd_Cod codigo, IFNULL(DDoc_Prd_Des,'') descripcion, IFNULL(cat_num,0) numMedida, cat_clave medida, IFNULL(DDoc_Prd_PUQ,0) precio, IFNULL(cli_cliente,'') destino, IFNULL(cli_codigo,0) CodDestino, DDoc_RF1_Fec fecha, DDoc_Prd_Pnr CodArt, DDoc_Prd_QTY cantidad, DDoc_RF2_Num cancelado, IFNULL(DDoc_RF2_Cod,'') programa, DDoc_RF1_Cod division, DDoc_Prd_Ref estilo, DDoc_Doc_Lin linea, (DDoc_Prd_NET * DDoc_Prd_Qty) total, IFNULL(DDoc_RF2_Txt,'') Observaciones, IFNULL(("
        strsql &= "    Select SUM(IDoc_Itm_QTY) Cantidad"
        strsql &= "         From Dcmtos_DTL_Itm"
        strsql &= "            WHERE IDoc_Sis_Emp=DDoc_Sis_Emp AND IDoc_Doc_Cat=DDoc_Doc_Cat AND IDoc_Doc_Ano=DDoc_Doc_Ano AND IDoc_Doc_Num=DDoc_Doc_Num AND IDoc_Doc_Lin=DDoc_Doc_Lin),0) Descargo"
        strsql &= "                 From Dcmtos_DTL"
        strsql &= "                 Left JOIN Catalogos ON cat_num = DDoc_Prd_UM AND cat_clase = 'Medidas'"
        strsql &= "            Left JOIN Inventarios ON inv_numero = DDoc_Prd_Cod AND inv_sisemp = {empresa}"
        strsql &= "         Left JOIN Clientes  ON cli_sisemp = DDoc_Sis_Emp AND cli_codigo = DDoc_RF1_Num"
        strsql &= "    WHERE DDoc_Doc_Cat = 75 AND DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {numero}"
        strsql &= " ORDER BY DDoc_Doc_Lin;"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function

e_error:
        On Error GoTo 0

    End Function

    Private Function SQLDetallesDoc(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strsql As String
        Dim errorLog As String

        On Error GoTo e_error

        strsql = " Select cat_clave, cat_desc, ("
        strsql &= "    Select  COUNT(*)"
        strsql &= "        From Dcmtos_ACC"
        strsql &= "          Where ADoc_Sis_Emp = {empresa} And ADoc_Doc_Cat = 75 And ADoc_Doc_Ano = {anio} And ADoc_Doc_Num = {numero} And ADoc_Doc_Sub = cat_clave) As cantidad"
        strsql &= "        From Catalogos"
        strsql &= "    Where cat_clase = 'SubDcmtos' AND cat_sist = 'Doc_CPedido'"
        strsql &= " ORDER BY cat_clave"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        On Error GoTo 0

    End Function

    Private Function SQLDetalle2(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strsql As String
        Dim errorLog

        On Error GoTo e_error

        strsql = " SELECT  d.DDoc_Prd_QTY inicial,  PDoc_Par_Lin linea, PDoc_Chi_Cat catalogo, PDoc_Chi_Ano anio, PDoc_Chi_Num NumDespacho, HDoc_Doc_Fec fecha, PDoc_QTY_Pro cantidad"
        strsql &= "    From Dcmtos_DTL_Pro"
        strsql &= "        Left JOIN Dcmtos_HDR ON HDoc_Sis_Emp=PDoc_Sis_Emp AND HDoc_Doc_Cat=PDoc_Chi_Cat AND HDoc_Doc_Ano=PDoc_Chi_Ano AND HDoc_Doc_Num=PDoc_Chi_Num"
        strsql &= "        Left join Dcmtos_DTL d on d.DDoc_Sis_Emp =  PDoc_Sis_Emp and d.DDoc_Doc_Cat =PDoc_Par_Cat and d.DDoc_Doc_Ano = PDoc_Par_Ano and d.DDoc_Doc_Num =PDoc_Par_Num and d.DDoc_Doc_Lin = PDoc_Par_Lin"
        strsql &= "    WHERE PDoc_Sis_Emp={empresa} AND PDoc_Par_Cat=75 AND PDoc_Par_Ano={anio} AND PDoc_Par_Num={numero} AND PDoc_Chi_Cat IN (22,48)"
        strsql &= " ORDER BY PDoc_Par_Lin, HDoc_Doc_Fec, PDoc_Chi_Num, PDoc_Chi_Lin"

        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{numero}", intNumero)
        strsql = Replace(strsql, "{anio}", intAño)

        Return strsql
e_salir:
        On Error GoTo 0
        Exit Function
e_error:
        On Error GoTo 0

    End Function

    Private Function SQLFacRef()
        Dim strsql As String

        strsql = " SELECT e.HDoc_Doc_Ano anio, e.HDoc_Doc_Num numero, d.DDoc_Doc_Lin linea, e.HDoc_Doc_Fec fecha, e.HDoc_DR1_Num referencia, d.DDoc_Prd_Cod codigo, COALESCE(c.cat_clave,'') medida, COALESCE(c.cat_num,0) unidad, d.DDoc_Prd_PUQ precio, 0 total, a.art_DLarga descripcion, COALESCE(p.cat_clave,'') pais, COALESCE(v.pro_proveedor,'') fabricante, COALESCE(i.inv_prodsem,'N/A') semana, COALESCE(i.inv_prodlote,'N/A') lote, (d.DDoc_Prd_QTY - COALESCE(("
        strsql &= "    Select SUM(p.PDoc_QTY_Pro)"
        strsql &= "        From Dcmtos_DTL_Pro p"
        strsql &= "             WHERE p.PDoc_Sis_Emp = d.DDoc_Sis_Emp And p.PDoc_Par_Cat = d.DDoc_Doc_Cat And "
        strsql &= "                p.PDoc_Par_Ano = d.DDoc_Doc_Ano And p.PDoc_Par_Num = d.DDoc_Doc_Num And p.PDoc_Par_Lin = d.DDoc_Doc_Lin And p.PDoc_Chi_Cat=75 And Not(p.PDoc_Chi_Ano={anio} And p.PDoc_Chi_Num={doc})),0)) cantidad"
        strsql &= "                    From Dcmtos_DTL d"
        strsql &= "                        Left JOIN Dcmtos_HDR e On e.HDoc_Sis_Emp = d.DDoc_Sis_Emp And e.HDoc_Doc_Cat = d.DDoc_Doc_Cat And e.HDoc_Doc_Ano = d.DDoc_Doc_Ano And e.HDoc_Doc_Num = d.DDoc_Doc_Num"
        strsql &= "                            Left JOIN Inventarios i On i.inv_sisemp = d.DDoc_Sis_Emp And i.inv_numero = d.DDoc_Prd_Cod"
        strsql &= "                                Left JOIN Articulos a On a.art_sisemp = d.DDoc_Sis_Emp And a.art_codigo = i.inv_artcodigo"
        strsql &= "                                Left JOIN Catalogos c On "
        strsql &= "                            c.cat_clase = 'Medidas' AND c.cat_num = d.DDoc_Prd_UM"
        strsql &= "                        Left JOIN Catalogos p On p.cat_clase = 'Paises' AND p.cat_num = i.inv_lugarfab"
        strsql &= "                    Left JOIN Proveedores v On v.pro_sisemp = d.DDoc_Sis_emp And v.pro_codigo = i.inv_provcod"
        strsql &= "                WHERE d.DDoc_Sis_Emp = {empresa} And d.DDoc_Doc_Cat = {tipo} {criterio}"
        strsql &= "            GROUP BY d.DDoc_Sis_Emp, d.DDoc_Doc_Cat, d.DDoc_Doc_Ano, d.DDoc_Doc_Num, d.DDoc_Doc_Lin"
        strsql &= "        HAVING (cantidad > 0)"
        strsql &= "    ORDER BY d.DDoc_Doc_Ano, d.DDoc_Doc_Num"


        strsql = Replace(strsql, "{empresa}", Sesion.IdEmpresa)
        strsql = Replace(strsql, "{tipo}", 389)
        strsql = Replace(strsql, "{anio}", celdaAño.Text)
        strsql = Replace(strsql, "{doc}", celdaNumero.Text)
        strsql = Replace(strsql, "{criterio}", Criterio)

        Return strsql
    End Function

    Private Function Criterio() As String
        Dim strSQL As String = STR_VACIO
        Dim i As Integer
        Dim Crit As String = STR_VACIO


        For i = vbEmpty To dgContratosLista.Rows.Count - 1
            strSQL = strSQL & IIf(i = vbEmpty, "(", " OR (")
            strSQL = strSQL & " HDoc_Doc_Ano = " & dgContratosLista.Rows(i).Cells("colAñoContrato").Value & " AND "
            strSQL = strSQL & " HDoc_Doc_Num = " & dgContratosLista.Rows(i).Cells("colNumeroContrato").Value & ")"

        Next

        If Not (strSQL = vbNullString) Then

            Crit = " AND (" & strSQL & ")"

        End If
        Return Crit
    End Function

    Public Sub LimpiarPanelOrden()
        celdaTC.Text = cFunciones.QueryTasa("CURDATE()")
        celdaAño.Text = -1
        celdaNumero.Text = -1
        dtpFecha.Text = STR_VACIO
        celdaDireccion.Text = STR_VACIO
        celdaCliente.Text = STR_VACIO
        celdaIDCliente.Text = STR_VACIO
        celdaTelefono.Text = STR_VACIO
        celdaNit.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaPhone.Text = STR_VACIO
        celdaDirec.Text = STR_VACIO
        celdaSolicitante.Text = STR_VACIO
        celdaNumeroReq.Text = STR_VACIO
        dtpFecha1.Text = STR_VACIO
        celdaMoneda.Text = STR_VACIO
        celdaTotales.Text = 0
        celdaTotales2.Text = 0
        dgDetalle.Rows.Clear()
        dgDetalle2.Rows.Clear()
        dgContratosLista.Rows.Clear()
        checkCarta.Checked = False
        celdaContrato.Text = NO_FILA
        celdaRevisado.Text = NO_FILA
        celdaImpuestos.Text = NO_FILA
        botonDespachos.BackColor = Color.LightGray
        ckeckPagaImp.Checked = False
        BotonCliente.Enabled = True
        botonSolicitante.Enabled = True
        celdaIDSolicitante.Text = STR_VACIO
        checkActivo.Checked = False
        dgDetalleDoc.Rows.Clear()
        dgReferencias.Rows.Clear()
        checkActivo.Enabled = True
        ' logInsertar = False
        LogBorrar = True

    End Sub

    Public Sub queryListaPrincipal()
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO
        Dim Celda As New DataGridViewTextBoxCell
        Dim r As Integer
        strSQL = SQLLista()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("cliente") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetString("Direccion") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("Revisado")

                    r = REA.GetInt32("Revisado")
                    'cFunciones.AgregarFila(dgLista, strFila)
                    AgregarFila(dgLista, strFila, r)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub AgregarFila(ByRef Lista As DataGridView, ByVal strFila As String, ByVal Revisado As Integer)
        Dim Celda As New DataGridViewTextBoxCell
        Dim Fila As New DataGridViewRow
        Dim strSQL As String = STR_VACIO
        Dim arrayFila() As String
        Dim i As Integer
        Try
            Lista.BackgroundColor = Color.White
            arrayFila = strFila.Split("|".ToCharArray)
            For i = 0 To arrayFila.Length - 1
                Celda = New DataGridViewTextBoxCell
                Celda.Value = arrayFila(i)

                If Revisado = vbEmpty Then
                    If i = 0 Then
                        Celda.Style.BackColor = Color.Yellow
                    End If
                Else
                    If i = 0 Then
                        Celda.Style.BackColor = Color.YellowGreen
                    End If
                End If
                Fila.Cells.Add(Celda)

            Next
            Lista.Rows.Add(Fila)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub queryEncabezado(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim strCampos As String = STR_VACIO
        Dim strCondicion As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO


        strSQL = SQLDetalle(intNumero, intAño)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                'dgLista.Rows.Clear()

                Do While REA.Read

                    celdaNumero.Text = REA.GetInt32("numeroDoc")
                    celdaNumero.Enabled = False
                    dtpFecha1.Text = REA.GetDateTime("fecha")
                    celdaCliente.Text = REA.GetString("nombreEmp")
                    celdaIDCliente.Text = REA.GetInt32("codEmpresa")
                    celdaDireccion.Text = REA.GetString("direccion")
                    celdaTelefono.Text = REA.GetString("telefono")
                    celdaNit.Text = REA.GetString("NIT")
                    celdaMoneda.Text = REA.GetString("Moneda")
                    celdaIDMoneda.Text = REA.GetInt32("moneda")
                    celdaAño.Text = REA.GetInt32("anio")
                    celdaAño.Enabled = False
                    celdaTC.Text = REA.GetDouble("tasa")
                    celdaNumeroReq.Text = REA.GetString("docNum")
                    celdaSolicitante.Text = REA.GetString("cliente")
                    celdaIDSolicitante.Text = REA.GetInt32("IdSolicitante")
                    celdaImpuestos.Text = REA.GetInt32("Impuesto")
                    celdaDirec.Text = REA.GetString("direccionCli")
                    celdaPhone.Text = REA.GetString("telCliente")
                    celdaEmpresa.Text = Sesion.IdEmpresa
                    celdaCatalogo.Text = 75
                    celdaUsuario.Text = Sesion.Usuario
                    celdaRevisado.Text = REA.GetInt32("Revisado")
                    dtpFecha.Text = REA.GetString("fechaDoc")
                    celdaDefault.Text = "Please write Check for Import Charges under the name of NESTOR HERNANDEZ. For Order Items write under AmTex Guatemala, S.A. If International Check. If local check, please issue check under the name of the bank where the check is from. NOTICE: Separate payments are needed."

                    If REA.GetInt32("Impuesto") = 1 Then
                        ckeckPagaImp.Checked = True
                        ckeckPagaImp.ForeColor = Color.Red
                    Else
                        ckeckPagaImp.Checked = False
                        ckeckPagaImp.ForeColor = Color.Black
                    End If

                    If REA.GetInt32("Revisado") = 1 Then
                        botonDespachos.BackColor = Color.YellowGreen
                        botonDespachos.Enabled = False
                    Else
                        botonDespachos.Enabled = True
                    End If

                    If REA.GetInt32("estatus") = 1 Then
                        checkActivo.Checked = True
                        etiquetaAnulada.Visible = False
                        checkActivo.Enabled = True
                    Else
                        checkActivo.Checked = False
                        etiquetaAnulada.Visible = True
                        checkActivo.Enabled = False
                    End If
                    celdaidProyecto.Text = REA.GetInt32("idproyecto")
                    celdaidTarea.Text = REA.GetInt32("idTarea")
                    celdaidflujodetalle.Text = REA.GetInt32("idFlujoDetalle")
                    celdaDescripcion.Text = REA.GetString("Nombre")
                    celdaProyecto.Text = REA.GetString("NombreP")
                    celdaDescripcionP.Text = REA.GetString("Descripcion")
                Loop
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub

    Public Sub queryContratos(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO


        strSQL = SQLContratos(intNumero, intAño)


        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgContratosLista.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("numero") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetString("usuario") & "|"
                    strFila &= REA.GetString("referencia") & "|"
                    strFila &= REA.GetInt32("catalogo")

                    cFunciones.AgregarFila(dgContratosLista, strFila)

                Loop
                'Else
                '    dgContratosLista.Rows.Clear()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub querySubDoc(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO

        strSQL = SQLDetallesDoc(intNumero, intAño)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalleDoc.Rows.Clear()

                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetString("cat_clave") & "|"
                    strFila &= REA.GetString("cat_desc") & "|"

                    If REA.GetInt32("cantidad") = 0 Then
                        strFila &= "No"
                    Else
                        strFila &= "Si"
                    End If

                    cFunciones.AgregarFila(dgDetalleDoc, strFila)

                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub queryDetalleDown(ByVal intNumero As Integer, ByVal intAño As Integer)

        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim STR_ESTADO As String = "si"

        strSQL = SQLDetalleDown(intNumero, intAño)

        Try
            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then

                dgDetalle.Rows.Clear()

                Do While REA.Read

                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("Catalogo") & "|"
                    strFila &= REA.GetInt32("Anio") & "|"
                    strFila &= REA.GetInt32("codigo") & "|"
                    strFila &= REA.GetString("descripcion") & "|"
                    strFila &= REA.GetInt32("numMedida") & "|"
                    strFila &= REA.GetString("medida") & "|"
                    strFila &= REA.GetDouble("precio") & "|"
                    strFila &= REA.GetDouble("precioKG") & "|"
                    strFila &= REA.GetString("destino") & "|"
                    strFila &= REA.GetInt32("CodDestino") & "|"
                    strFila &= REA.GetDateTime("fecha") & "|"
                    strFila &= REA.GetDouble("cantidad") & "|"
                    strFila &= REA.GetDecimal("total") & "|"
                    strFila &= REA.GetDouble("Descargo") & "|"
                    If REA.GetInt32("cancelado") = 0 Then
                        strFila &= "" & "|"
                    Else
                        strFila &= "SI" & "|"
                    End If
                    strFila &= REA.GetString("programa") & "|"
                    strFila &= REA.GetString("division") & "|"
                    strFila &= REA.GetString("estilo") & "|"
                    strFila &= REA.GetInt32("linea") & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= "" & "|"
                    strFila &= 0 & "|"
                    strFila &= REA.GetString("CodArt") & "|"
                    strFila &= REA.GetString("Observaciones")

                    cFunciones.AgregarFila(dgDetalle, strFila)

                    For i As Integer = 0 To dgDetalle.Rows.Count - 1
                        If REA.GetString("NumMedida") = 70 Then
                            dgDetalle.Rows(i).Cells("colMedida").Style.BackColor = Color.Red
                        End If

                        'If Descargos > 0 Then
                        '    dgDetalle.Rows(i).Cells("colPrecio").Value = Enabled
                        'End If
                    Next
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Public Sub queryDetalle2(ByVal intNumero As Integer, ByVal intAño As Integer)
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL As String = STR_VACIO

        strSQL = SQLDetalle2(intNumero, intAño)

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            If REA.HasRows Then
                dgDetalle2.Rows.Clear()
                Dim intLinea As Integer = 1
                Dim num As Integer = 0


                Do While REA.Read
                    Dim strFila As String = STR_VACIO

                    strFila = REA.GetInt32("linea") & "|"
                    strFila &= REA.GetInt32("anio") & "|"
                    strFila &= REA.GetInt32("NumDespacho") & "|"
                    strFila &= REA.GetDecimal("cantidad") & "|"
                    If num = 0 Then
                        dblSaldo = REA.GetDouble("inicial")
                    End If

                    If intLinea = REA.GetInt32("linea") Then
                        dblSaldo = dblSaldo - REA.GetDouble("cantidad")
                        num = 1

                    Else

                        dblSaldo = REA.GetDouble("inicial")
                        dblSaldo = dblSaldo - REA.GetDouble("cantidad")
                        intLinea = REA.GetDouble("linea")
                    End If

                    strFila &= dblSaldo
                    cFunciones.AgregarFila(dgDetalle2, strFila)
                Loop
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CalcularTotales()
        Dim i As Integer
        Dim dblPrecio As Double
        Dim dblCant As Double

        Try
            dblDocCantidad = 0
            dblDocTotal = 0
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                dblPrecio = dgDetalle.Rows(i).Cells("colPrecio").Value
                dblCant = dgDetalle.Rows(i).Cells("colCantidad").Value
                dblDocCantidad = dblDocCantidad + dblCant
                dblDocTotal = dblDocTotal + (dblCant * dblPrecio)
            Next
            celdaTotales.Text = dblDocCantidad.ToString(FORMATO_MONEDA)
            celdaTotales2.Text = dblDocTotal.ToString(FORMATO_MONEDA)

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub CargarReferencias(ByVal intAño As Integer, ByVal intNumero As Integer)
        Dim strSQL As String = STR_VACIO
        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand

        For i As Integer = 0 To dgDetalle.Rows.Count - 1
            strSQL = "SELECT b.HDoc_Doc_Ano Anio, b.HDoc_Doc_Num Numero, a.PDoc_Par_Lin Linea, b.HDoc_DR1_Num Referencia, a.PDoc_QTY_Pro Descargo, a.PDoc_Chi_Lin ID"
            strSQL &= "  FROM Dcmtos_DTL_Pro a"
            strSQL &= "      INNER JOIN Dcmtos_HDR b ON a.PDoc_Sis_Emp = b.HDoc_Sis_Emp AND a.PDoc_Par_Cat = b.HDoc_Doc_Cat AND a.PDoc_Par_Ano = b.HDoc_Doc_Ano AND a.PDoc_Par_Num = b.HDoc_Doc_Num"
            strSQL &= "          WHERE PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat = 75 AND PDoc_Par_Cat = 389 AND PDoc_Chi_Ano = {año} AND PDoc_Chi_Num = {numero} AND PDoc_Chi_Lin = {linea}"
            strSQL &= "      ORDER BY b.HDoc_Doc_Ano, b.HDoc_Doc_Num"

            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{año}", intAño)
            strSQL = Replace(strSQL, "{numero}", intNumero)

            'NOTAS: '75/Instrucciones' es child y '/Contrato' es parent
            strSQL = Replace(strSQL, "{linea}", i + 1)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            'dgReferencias.Rows.Clear()

            Do While REA.Read

                Dim strfila As String = STR_VACIO
                'LLena dataGridView
                strfila = i + 1 & "|"
                strfila &= REA.GetInt32("Anio") & "|"
                strfila &= REA.GetInt32("Numero") & "|"
                strfila &= REA.GetInt32("Linea") & "|"
                strfila &= REA.GetString("Referencia") & "|"
                strfila &= REA.GetDouble("Descargo")

                cFunciones.AgregarFila(dgReferencias, strfila)
            Loop
        Next
    End Sub

    Private Function DescargosdeLinea(ByVal Ciclo As Integer, ByVal Numero As Integer, ByVal Linea As Integer, Optional Excluir As Integer = NO_FILA) As Double
        'Devuelve la suma de las cantidades descargadas para una línea de referencia
        Dim i As Integer
        Dim dblTemp As Double

        dblTemp = vbEmpty
        For i = vbEmpty To dgReferencias.Rows.Count - 1
            If Not (Val(dgReferencias.Rows(i).Cells("colID").Value) = Excluir) Then
                'No es el Id a excluir y corresponde a la línea de referencia

                If (Val(dgReferencias.Rows(i).Cells("colAnio").Value)) = Ciclo And
                    (Val(dgReferencias.Rows(i).Cells("colContrato").Value)) = Numero And
                    (Val(dgReferencias.Rows(i).Cells("colLine").Value)) = Linea Then
                    dblTemp = dblTemp + dgReferencias.Rows(i).Cells("colDescargo").Value
                End If
            End If
        Next
        'Devuelve el resultado
        DescargosdeLinea = dblTemp
    End Function

    Private Sub DatosParaDescargar(ByVal frmFacRef As frmFacturasRef_Aux_)
        'Dim frmFacRef As New frmFacturasRef_Aux_

        Dim REA As MySqlDataReader
        Dim COM As MySqlCommand
        Dim strSQL As String = STR_VACIO
        Dim i As Integer
        Dim intID As Integer
        Dim dblSaldo As Double

        strSQL = SQLFacRef()

        Try
            MyCnn.CONECTAR = strConexion

            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            intID = dgDetalle.SelectedCells(18).Value

            If REA.HasRows Then

                frmFacRef.dgLista.Rows.Clear()

                For i = 0 To dgDetalle.Rows.Count - 1
                    REA.Read()

                    Dim strfila As String = STR_VACIO


                    'i = vbEmpty


                    dblSaldo = (REA.GetDouble("cantidad") - DescargosdeLinea(REA.GetInt32("Anio"), REA.GetInt32("Numero"), REA.GetInt32("linea"), intID))
                    If (dblSaldo > vbEmpty) Then


                        'LLena dataGridView
                        strfila = REA.GetInt32("anio") & "|"
                        strfila &= REA.GetInt32("numero") & "|"
                        strfila &= REA.GetDateTime("fecha") & "|"

                        'oculta la columna poliza en el DataGridview
                        frmFacRef.dgLista.Columns("colPoliza").Visible = False

                        strfila &= 0 & "|"
                        strfila &= REA.GetString("referencia") & "|"
                        strfila &= REA.GetInt32("linea") & "|"
                        strfila &= REA.GetInt32("codigo") & "|"
                        strfila &= REA.GetInt32("cantidad") & "|"
                        strfila &= REA.GetString("medida") & "|"
                        strfila &= REA.GetInt32("unidad") & "|"
                        If dgDetalle.Rows(i).Cells("colDescargos").Value = 0 Then
                            strfila &= 0 & "|"
                        Else
                            strfila &= dgDetalle.Rows(i).Cells("colCantidad").Value & "|"
                        End If
                        strfila &= 0 & "|"
                        strfila &= 0 & "|"
                        strfila &= 0 & "|"
                        strfila &= REA.GetDouble("precio")

                        cFunciones.AgregarFila(frmFacRef.dgLista, strfila)

                    End If
                    frmFacRef.dgLista.Columns("colDescargo").ReadOnly = False
                    frmFacRef.Codigo = dgDetalle.SelectedCells(0).Value
                    frmFacRef.PanelTotales.Visible = False
                    frmFacRef.Catalogo = dgContratosLista.SelectedCells(5).Value

                    'Loop
                Next
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Public Function GetReferencia() As String
    '    Dim i As Integer
    '    Dim strReferencia As String = STR_VACIO

    '    If dgLista.RowCount = 1 Then
    '        strReferencia = dgLista.Rows(3).Cells("colReferenciaLista").Value
    '    Else
    '        For i = 0 To dgLista.Rows.Count - 1
    '            If strReferencia = "0" Then
    '                strReferencia = dgLista.Rows(i).Cells("colReferenciaLista").Value
    '            Else
    '                strReferencia = strReferencia & "/" & dgLista.Rows(i).Cells("colReferenciaLista").Value
    '            End If
    '        Next
    '    End If
    '    Return strReferencia
    'End Function

    Private Sub MostrarReferencias()
        'Muestra las líneas disponibles de los documentos del listado
        Dim frmFacRef As New frmFacturasRef_Aux_

        DatosParaDescargar(frmFacRef)


        If Not (frmFacRef.dgLista.Rows.Count > vbEmpty) Then
            MsgBox("No Data to download", vbExclamation, "Notice")
        Else
            ActualizarDescargos()

            'Código de hilo de la línea actual
            frmFacRef.Codigo = dgDetalle.SelectedCells(2).Value
            frmFacRef.PanelTotales.Visible = False
            frmFacRef.Catalogo = dgContratosLista.SelectedCells(0).Value
            frmFacRef.Pedido = dgDetalle.SelectedCells(11).Value
            If dgDetalle.CurrentRow.Cells("colMedida").Value = "LBS" Then
                frmFacRef.Unidad = 69
            Else
                frmFacRef.Unidad = 70
            End If

            frmFacRef.ShowDialog(Me)

            If frmFacRef.Aceptado Then
                ActualizarDetalle(frmFacRef)
            End If

        End If

    End Sub

    Private Sub ActualizarDescargos()
        'Actualiza el detalle de descargos (con las cant. ya descargadas)
        Dim i As Integer
        Dim k As Integer
        Dim intID As Integer

        Dim dblTemp As Double
        Dim frmDatos As New frmFacturasRef_Aux_

        intID = dgDetalle.CurrentRow.Cells("colLineaDet").Value
        For i = vbEmpty To frmDatos.dgLista.Rows.Count - 1
            dblTemp = vbEmpty
            For k = vbEmpty To dgReferencias.Rows.Count - 1
                If dgReferencias.Rows(k).Cells("colID").Value = intID Then
                    'Es el Id del detalle y corresponde a la línea de referencia
                    If dgReferencias.Rows(k).Cells("colAnio").Value = frmDatos.dgLista.Rows(i).Cells("colAño").Value And
                        dgReferencias.Rows(k).Cells("colContrato").Value = frmDatos.dgLista.Rows(i).Cells("colNumero").Value And
                        dgReferencias.Rows(k).Cells("colLine").Value = frmDatos.dgLista.Rows(i).Cells("colLinea").Value Then
                        dblTemp = dblTemp + Val(frmDatos.dgLista.Rows(k).Cells("colDescargo").Value)
                    End If
                End If
            Next
            dgReferencias.Rows(i).Cells("colDescargo").Value = dblTemp
        Next
    End Sub

    Private Sub ActualizarDetalle(ByVal frmDatos As frmFacturasRef_Aux_)
        'Actualiza la relación entre la línea actual del detalle y los descargos
        Dim i As Integer
        Dim k As Integer
        Dim intID As Integer
        Dim dblTemp As Double
        Dim dblSuma As Double
        Dim strFila As String
        Dim dblPrecio As Double


        intID = Val(dgDetalle.CurrentRow.Cells("colLineaDet").Value)

        QuitarReferencias(intID)

        dblPrecio = vbEmpty
        'Agrega las líneas con descargo al listado de referencias
        For i = vbEmpty To frmDatos.dgLista.Rows.Count - 1
            dblTemp = Val(frmDatos.dgLista.Rows(i).Cells("colDescargo").Value)

            If dblTemp > vbEmpty Then
                dblSuma = dblSuma + dblTemp

                dblTemp = Val(frmDatos.dgLista.Rows(i).Cells("colDetalle").Value)
                If (dblTemp > dblPrecio) Then
                    dblPrecio = dblTemp
                End If

                strFila = intID & "|"
                strFila &= frmDatos.dgLista.Rows(i).Cells("colAño").Value & "|"
                strFila &= frmDatos.dgLista.Rows(i).Cells("colNumero").Value & "|"
                strFila &= frmDatos.dgLista.Rows(i).Cells("colLinea").Value & "|"
                strFila &= frmDatos.dgLista.Rows(i).Cells("colReferencia").Value & "|"
                strFila &= frmDatos.dgLista.Rows(i).Cells("colDescargo").Value

                cFunciones.AgregarFila(dgReferencias, strFila)
            End If
        Next
        'Actualiza la cantidad
        For k = 0 To dgDetalle.Rows.Count - 1
            Dim Line As Integer

            Line = dgDetalle.Rows(k).Cells("colLineaDet").Value
            If Line = intID Then
                dgDetalle.Rows(k).Cells("colCantidad").Value = dblSuma
                dblTemp = Val(dgDetalle.Rows(k).Cells("colPrecio").Value)
                If dblTemp = vbEmpty Then
                    dgDetalle.Rows(k).Cells("colPrecio").Value = dblPrecio
                ElseIf (dblPrecio > dblTemp) Then
                    MsgBox("The Contract price is higher than the price of the order" & vbCr & vbCr & "Pedido (actual): " & dblTemp.ToString(FORMATO_MONEDA) & vbCr & vbCr & "The highest price was used.", vbExclamation, "Notice")
                    dgDetalle.Rows(k).Cells("colPrecio").Value = dblPrecio
                End If
                dgDetalle.Rows(k).Cells("colTotal").Value = (dgDetalle.Rows(k).Cells("colCantidad").Value * Val(dgDetalle.Rows(k).Cells("colPrecio").Value))
                dgDetalle.Rows(k).Cells("colDescargos").Value = 1
            End If
        Next
        ActualizarReferencias(dgDetalle.Rows.Count - 1)
    End Sub

    Private Sub QuitarReferencias(ByVal ID As Integer)
        'Quita las referencias del listado para una fila del detalle
        Dim i As Integer
        For i = dgReferencias.Rows.Count - 1 To vbEmpty Step (-1)
            If dgReferencias.Rows(i).Cells("colID").Value = ID Then
                dgReferencias.Rows.RemoveAt(i)
            End If
        Next
    End Sub

    Private Sub ActualizarReferencias(Optional Index As Integer = NO_FILA)
        'Actualiza la col. ref. del detalle de acuerdo a las líneas referenciadas
        Dim i As Integer
        Dim k As Integer
        Dim intInicio As Integer
        Dim intLimite As Integer
        Dim intID As Integer
        Dim strTemp As String

        If Index = NO_FILA Then
            intInicio = vbEmpty
            intLimite = dgDetalle.Rows.Count - 1
        End If

        For i = vbEmpty To dgDetalle.Rows.Count - 1
            'Identificador del detalle
            intID = dgDetalle.Rows(i).Cells("colLineaDet").Value

            'Busca las referencias en el listado
            strTemp = vbNullString
            For k = vbEmpty To dgReferencias.Rows.Count - 1
                If dgReferencias.Rows(k).Cells("colID").Value = intID Then
                    strTemp = dgReferencias.Rows(k).Cells("colContrato").Value & "/" & dgReferencias.Rows(k).Cells("colLine").Value
                End If
            Next

            'Asigna el texto de referencia
            'dgDetalle.Rows(i).Cells()
        Next

    End Sub

    Private Function PrecioMinimodelArticulo(ByVal wNum As String) As Double
        Dim precio As Double
        Dim strSQL As String
        Dim Activo1 As Integer
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        Activo1 = 0

        strSQL = "SELECT IFNULL(inv_PRECIOmin,0)"
        strSQL &= " FROM Inventarios"
        strSQL &= "     WHERE inv_numero = " & wNum & ""
        strSQL &= " AND inv_activo = " & Activo1 & ""

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        precio = COM.ExecuteScalar()
        conec.Close()

        PrecioMinimodelArticulo = precio
    End Function

    'Revisar que los datos de la cabecera no estén en blanco.
    Private Function ComprobarDatos() As Boolean
        Dim comprobar As Boolean = True
        Dim i As Integer
        Dim logErr As Boolean

        If celdaEmpresa.Text = vbNullString Or celdaCatalogo.Text = vbNullString Or celdaUsuario.Text = vbNullString Then
            MsgBox("Incomplete Data System.", vbCritical)
        ElseIf celdaIDCliente.Text = vbNullString Or
            celdaCliente.Text = vbNullString Or
            celdaDireccion.Text = vbNullString Or
            celdaNit.Text = vbNullString Then
            MsgBox("You must enter all minimum data.", vbCritical)
            comprobar = False
            'Verifica Datos en el DETALLE.
            'logErr = False
            'ComprobarDatos = False
        Else
            For i = vbEmpty To dgDetalle.Rows.Count - 1
                If ComprobarFila(i) = True Then
                    logErr = True
                    Exit For
                Else
                    comprobar = False
                    Exit Function
                End If
            Next

            If Not logErr Then
                'Verifica que total > 0
                If Not celdaTotales.Text > vbEmpty Then
                    MsgBox("An order is not supported with ZERO amount.", vbCritical)
                End If
            End If


        End If
        Return comprobar
    End Function

    Private Function ComprobarPagoImpuestos() As Boolean
        Dim comprobar As Boolean = True
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strSQL = "SELECT h.HDoc_Emp_Cod codEmpresa, h.HDoc_Emp_Nom Cliente, h.HDoc_Doc_Fec fecha, h.HDoc_DR1_Num ref"
        strSQL &= "      From Dcmtos_HDR h"
        strSQL &= "              WHERE h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Cat = 75 AND h.HDoc_Doc_Ano = {año} AND h.HDOC_DR2_EMP = 1 AND h.HDoc_Emp_Cod = {codEmp}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{codEmp}", celdaIDCliente.Text)

        MyCnn.CONECTAR = strConexion
        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        If REA.Read() = True Then
            If ckeckPagaImp.Checked = False Then
                If MsgBox("This Customer has been tax payable on" & Space(2) & REA.GetDateTime("fecha") & Space(2) & "Ref." & Space(2) & REA.GetString("ref") & "," & Space(2) & "Are you sure you want to continue?", vbQuestion + vbYesNo + vbDefaultButton2, "Untaxed") = vbNo Then
                    comprobar = False
                    Return comprobar
                    Exit Function
                End If
            End If
        Else
        End If


        Return comprobar
    End Function

    Private Function ComprobarFila(ByVal Index As Integer) As Boolean
        ComprobarFila = True
        Dim Comprobacion As Boolean
        Dim strFecha As Date

        If dgDetalle.Rows(Index).Visible = True Then
            If dgDetalle.Rows(Index).Cells("colCodigo").Value And Index = dgDetalle.Rows.Count - 1 Then
                ComprobarFila = True
            End If

            If dgDetalle.Rows(Index).Cells("colNumMedida").Value = 70 Then
                If MsgBox("You sure you want to enter a measure in Kilograms" & " In line Nº " & Space(2) & Index + 1, vbQuestion + vbYesNo + vbDefaultButton2, "Measure") = vbYes Then
                    dgDetalle.Rows(Index).Cells("colMedida").Style.BackColor = Color.Red
                Else
                    ComprobarFila = False
                    Exit Function
                End If
            End If

            If Val(dgDetalle.Rows(Index).Cells("colCodigo").Value) = vbEmpty Then
                MsgBox("Row " & Index + 1 & ": Invalid Code Article.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colDescripcion").Value = vbNullString Then
                MsgBox("Row " & Index + 1 & ": Blank Description.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colPrecio").Value = vbEmpty Then
                MsgBox("Row " & Index + 1 & ": Zero price items.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf PrecioMinimodelArticulo(dgDetalle.Rows(Index).Cells("colCodigo").Value) > dgDetalle.Rows(Index).Cells("colPrecio").Value Then
                MsgBox("Row " & Index + 1 & ": Price lower than minimum article.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colDestino").Value = "-1" Then
                MsgBox("Row " & Index + 1 & ": Blank destination.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colFecha").Value = vbNullString Then
                MsgBox("Row " & Index + 1 & ": Delivery date blank.", vbExclamation, "Notice")
                ComprobarFila = False
                Exit Function
            ElseIf dgDetalle.Rows(Index).Cells("colPrograma").Value = "-1" Then
                'MsgBox("Row " & Index + 1 & ": You must enter the program and division", vbExclamation, "Notice")
                dgDetalle.Rows(Index).Cells("colPrograma").Value = "N/A"

            ElseIf dgDetalle.Rows(Index).Cells("colDivision").Value = "-1" Then
                dgDetalle.Rows(Index).Cells("colDivision").Value = "N/A"
            Else
                If dgDetalle.Rows(Index).Cells("colReference").Value And logRelacion Then
                    If MsgBox("Row " & Index + 1 & ": It has no reference." & vbCr & vbCr & "Do you wish to continue?", vbExclamation + vbYesNo + vbDefaultButton2, "Notice") = vbNo Then
                        ComprobarFila = True
                    End If
                End If
                ComprobarFila = Not Comprobacion

            End If

            If dgDetalle.Columns("colFechInicio").Visible = True And dgDetalle.Columns("colFechFinal").Visible = True Then
                If dgDetalle.Rows(Index).Cells("colFechFinal").Value = "-1" Or dgDetalle.Rows(Index).Cells("colFechInicio").Value = "-1" Then
                    If MsgBox("Row " & Index + 1 & ": You must enter a start date and an end date", vbExclamation, "Notice") Then
                        ComprobarFila = False
                        Exit Function
                    End If
                Else
                    ComprobarFila = True
                End If
            End If


            If Not Comprobacion Then
                If Val(dgDetalle.Rows(Index).Cells("colCantidad").Value) = vbEmpty Then
                    MsgBox("Fila " & Index + 1 & ": Item number ZERO.", vbExclamation, "Notice")
                    ComprobarFila = True
                End If
            End If
        End If
        'ComprobarFila = Not Comprobacion
        Return ComprobarFila
    End Function

    Private Function ComprobarDespachos() As Boolean
        Dim logResultado As Boolean
        logResultado = False
        Dim intTemp As Integer
        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = vbNullString
        strSQL &= "SELECT COUNT(*) "
        strSQL &= "      FROM Dcmtos_DTL_Pro p"
        strSQL &= "          LEFT JOIN Dcmtos_HDR h on h.HDoc_Sis_Emp = p.PDoc_Sis_Emp  and h.HDoc_Doc_Cat = p.PDoc_Chi_Cat and h.HDoc_Doc_Ano =p.PDoc_Chi_Ano and h.HDoc_Doc_Num = p.PDoc_Chi_Num "
        strSQL &= "      WHERE p.PDoc_Sis_Emp = {empresa} and p.PDoc_Par_Cat  = {cat} and p.PDoc_Par_Ano = {ano} and p.PDoc_Par_Num = {num} and h.HDoc_Doc_Status = 1 "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{cat}", celdaCatalogo.Text)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        intTemp = COM.ExecuteScalar()
        conec.Close()

        If intTemp > 1 Then
            logResultado = True
        End If

        ComprobarDespachos = logResultado
    End Function

    'Comprueba el nombre del ciente (si difiere del solicitante)
    Private Function ComprobarIDs() As Boolean
        Dim strNombre(2) As String
        Dim logEx As Boolean
        Dim logErr As Boolean
        Dim i As Integer

        If celdaIDCliente.Text = vbEmpty Then
            MsgBox("You have not entered the customer", vbExclamation, "Notice")
            logErr = True
        End If
        If Not logErr Then
            If Val(celdaIDCliente.Text) = vbEmpty Then
                MsgBox("You have not enter the customer", vbExclamation, "Notice")
                logErr = True
            End If

            If Not logErr Then
                If Val(celdaIDSolicitante.Text) = vbEmpty Then
                    If MsgBox("You must complete the details of the applicant" & vbCr & vbCr & "¿Back to correct the data?" & vbCr & vbCr & "NOTE: If you answer [No] it is assumed that the applicant is the same client", vbInformation + vbYesNo, "Applicant") = vbNo Then
                        'Asignar mismos datos de cliente
                        celdaSolicitante.Text = celdaCliente.Text
                        celdaIDSolicitante.Text = celdaIDCliente.Text
                    Else : logErr = True
                    End If
                Else : logErr = True
                End If
            End If
        End If

        If Not logErr Then
            strNombre(0) = celdaIDCliente.Text
            strNombre(1) = celdaSolicitante.Text

            If (strNombre(0) = strNombre(1)) Then
                logEx = True
            ElseIf MsgBox("Receivable" & vbCr & " - " & strNombre(1) & vbCr & vbCr & "Invoicing" & vbCr & " - " & strNombre(vbEmpty), vbInformation + vbOKCancel + vbDefaultButton2, "Confirm") = vbOK Then
                logEx = True
            End If
        End If

        ComprobarIDs = logEx
    End Function

    'Query para guardar Datos Encabezado
    Private Function GuardarDocumento() As Boolean
        Dim logResultado As Boolean = True
        Try
            Dim chdr As New clsDcmtos_HDR
            chdr.CONEXION = strConexion

            chdr.HDOC_SIS_EMP = celdaEmpresa.Text
            chdr.HDOC_DOC_CAT = 75
            chdr.HDOC_DOC_ANO = celdaAño.Text
            chdr.HDOC_DOC_NUM = celdaNumero.Text
            chdr.HDoc_Doc_Fec_NET = dtpFecha1.Value
            chdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, vbEmpty)

            chdr.HDOC_EMP_COD = celdaIDCliente.Text
            chdr.HDOC_EMP_NOM = celdaCliente.Text
            chdr.HDOC_EMP_DIR = celdaDireccion.Text
            chdr.HDOC_EMP_TEL = celdaTelefono.Text
            chdr.HDOC_EMP_NIT = celdaNit.Text

            chdr.HDOC_DOC_MON = celdaIDMoneda.Text
            chdr.HDOC_DOC_TC = celdaTC.Text
            chdr.HDOC_DR2_EMP = IIf(ckeckPagaImp.Checked = True, INT_UNO, vbEmpty)

            chdr.HDOC_DR1_CAT = celdaIDSolicitante.Text

            chdr.HDOC_DR1_NUM = celdaNumeroReq.Text



            chdr.HDoc_DR1_Fec_NET = dtpFecha.Value

            chdr.HDOC_DR1_EMP = celdaIDSolicitante.Text


            chdr.HDOC_DR2_CAT = celdaIDMoneda.Text
            chdr.HDOC_DR2_NUM = celdaTC.Text

            chdr.HDOC_RF1_TXT = celdaDirec.Text
            chdr.HDOC_RF2_COD = celdaPhone.Text

            chdr.HDOC_RF2_TXT = celdaDefault.Text

            chdr.HDOC_USUARIO = celdaUsuario.Text
            chdr.HDOC_PRO_DCAT = celdaRevisado.Text

            If Me.Tag = "Mod" Then
                If chdr.Actualizar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If chdr.Guardar() = False Then
                    MsgBox(chdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    'Query para Guardar Descargos
    Private Function GuardarDescargos() As Boolean
        Dim logResultado As Boolean = True
        Dim DtlPro As New clsDcmtos_DTL_Pro
        DtlPro.CONEXION = strConexion

        Try

            DtlPro.PDOC_SIS_EMP = Sesion.IdEmpresa

            'Documento a ser Descargado


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function


    'Query para guardar el Detalle
    Private Function GuardarDetalle() As Boolean
        Dim logResultado As Boolean = True
        Dim Dtl As New clsDcmtos_DTL
        Dtl.CONEXION = strConexion
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim intLinea As Integer = vbEmpty


        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                strSQL = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
                strSQL &= "      FROM Dcmtos_DTL d"
                strSQL &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

                strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
                strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                strSQL = Replace(strSQL, "{catalogo}", 75)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Using conec
                    intLinea = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using


                If dgDetalle.Rows(i).Visible = True Then
                    Dtl.DDOC_SIS_EMP = celdaEmpresa.Text
                    Dtl.DDOC_DOC_CAT = 75
                    Dtl.DDOC_DOC_ANO = celdaAño.Text
                    Dtl.DDOC_DOC_NUM = celdaNumero.Text
                    If Me.Tag = "Nuevo" Or dgDetalle.Rows(i).Cells("colAgrega").Value = 1 Then
                        Dtl.DDOC_DOC_LIN = intLinea
                        dgDetalle.Rows(i).Cells("colLineaDet").Value = intLinea
                        'dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                    Else
                        Dtl.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaDet").Value

                    End If

                    Dtl.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                    Dtl.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value
                    Dtl.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colNumMedida").Value

                    Dtl.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                    Dtl.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value

                    Dtl.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colNumDestino").Value
                    Dtl.DDOC_RF1_COD = dgDetalle.Rows(i).Cells("colDivision").Value
                    Dtl.DDoc_RF1_Fec_NET = dgDetalle.Rows(i).Cells("colFecha").Value
                    Dtl.DDOC_PRD_PNR = dgDetalle.Rows(i).Cells("colCodArt").Value
                    Dtl.DDOC_PRD_CIF = dgDetalle.Rows(i).Cells("colPrecioKG").Value
                    If dgDetalle.Rows(i).Cells("colObservacion").Value = vbNullString Then
                    Else
                        Dtl.DDOC_RF2_TXT = dgDetalle.Rows(i).Cells("colObservacion").Value
                    End If

                    If dgDetalle.Rows(i).Cells("colCancelado").Value = vbNullString Then
                        Dtl.DDOC_RF2_NUM = 0
                    Else
                        Dtl.DDOC_RF2_NUM = 1
                    End If

                    Dtl.DDOC_RF2_COD = dgDetalle.Rows(i).Cells("colPrograma").Value

                    If dgDetalle.Rows(i).Cells("colEstilo").Value = vbNullString Then
                    Else
                        Dtl.DDOC_PRD_REF = dgDetalle.Rows(i).Cells("colEstilo").Value
                    End If


                    If dgDetalle.Rows(i).Cells("colAgrega").Value = 0 And Me.Tag = "Mod" Then
                        If Dtl.Actualizar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                    ElseIf dgDetalle.Rows(i).Cells("colAgrega").Value = 1 Or Me.Tag = "Nuevo" Then
                        If Dtl.Guardar() = False Then
                            MsgBox(Dtl.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If
                End If
            Next


        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub BorrarLineDetalle(ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Visible = False Then
                If SqlDescargos(dgDetalle.Rows(i).Cells("colLineaDet").Value) > 0 Then
                    MsgBox("You can not delete this line because you already have downloads", vbExclamation, "Notice")
                Else
                    strSQL = "   Delete"
                    strSQL &= "      FROM Dcmtos_DTL"
                    strSQL &= "  WHERE DDoc_Sis_Emp = {empresa} AND DDoc_Doc_Num ={numero} AND DDoc_Doc_Cat = {catalogo} AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Lin ={linea}"

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{numero}", intNumero)
                    strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
                    strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaDet").Value)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        'strTemp = COM.ExecuteScalar
                        COM.ExecuteNonQuery()
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                End If
            End If
        Next
    End Sub

    Private Sub BorrarLineDetalleDescargo(ByVal intNumero As Integer, ByVal intCatalogo As Integer)
        Dim i As Integer = vbEmpty
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As New MySqlCommand

        For i = 0 To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Visible = False Then
                If SqlDescargos(dgDetalle.Rows(i).Cells("colLineaDet").Value) > 0 Then
                    MsgBox("You can not delete this line because you already have downloads", vbExclamation, "Notice")
                Else
                    strSQL = "   Delete"
                    strSQL &= "      FROM Dcmtos_DTL_Pro"
                    strSQL &= "  WHERE PDoc_Sis_Emp = {empresa} AND PDoc_Par_Num ={numero} AND PDoc_Par_Cat = {catalogo} AND PDoc_Par_Ano = {anio} AND PDoc_Par_Lin ={linea}"

                    strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
                    strSQL = Replace(strSQL, "{numero}", intNumero)
                    strSQL = Replace(strSQL, "{catalogo}", intCatalogo)
                    strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
                    strSQL = Replace(strSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaDet").Value)

                    conec = New MySqlConnection(strConexion)
                    conec.Open()
                    COM = New MySqlCommand(strSQL, conec)
                    Using conec
                        'strTemp = COM.ExecuteScalar
                        COM.ExecuteNonQuery()
                        COM.Dispose()
                        COM = Nothing
                        conec.Close()
                        conec.Dispose()
                        conec = Nothing
                        System.GC.Collect()
                    End Using

                End If
            End If
        Next
    End Sub

    Private Function SqlBorrarDatosProcesados()
        'Borra los registros procesados de los documentos relacionados
        Dim strSQL As String

        strSQL = " Delete"
        strSQL &= "  FROM Dcmtos_DTL_Pro"
        strSQL &= "    WHERE"
        strSQL &= "      PDoc_Sis_Emp = {empresa} AND PDoc_Chi_Cat ={tipo} AND PDoc_Chi_Ano ={año} AND PDoc_Chi_Num ={numero}"

        strSQL = Replace(strSQL, "{empresa}", celdaEmpresa.Text)
        strSQL = Replace(strSQL, "{tipo}", celdaCatalogo.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)


        Return strSQL
    End Function

    Private Function SqlRegistrarKardex(ByVal i As Integer)
        Dim strSQL As String = STR_VACIO
        Dim logResultado As Boolean = True
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim OnHand As Double
        Dim OnTransit As Double
        Dim Commited As Double
        Dim IntCurrentRow As Integer
        Dim Kdex As New Tablas.TKARDEX

        'For i As Integer = 0 To dgDetalle.Rows.Count - 1
        strSQL = "SELECT COALESCE(a.Kar_OnHand + a.Kar_Phy_Inc - a.Kar_Phy_Out, 0) OnHand, COALESCE(a.Kar_OnTransit + a.Kar_For_Inc, 0) OnTransit, COALESCE(a.Kar_Committed + a.Kar_For_Out, 0) COMMITTED"
        strSQL &= "     FROM Kardex a"
        strSQL &= "          WHERE Kar_Prd_Cod = '{codigo}' AND Kar_Sis_Emp = {empresa} AND Kar_TransId = ("
        strSQL &= "              SELECT MAX(Kar_TransId)"
        strSQL &= "           FROM Kardex"
        strSQL &= "     WHERE Kar_Prd_Cod = '{codigo}')"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{codigo}", dgDetalle.Rows(i).Cells("colCodigo").Value)

        MyCnn.CONECTAR = strConexion

        COM = New MySqlCommand(strSQL, CON)
        REA = COM.ExecuteReader

        REA.Read()
        If REA.HasRows = False Then
            OnHand = 0
            OnTransit = 0
            Commited = 0
        Else
            OnHand = REA.GetDouble("OnHand")
            OnTransit = REA.GetDouble("OnTransit")
            Commited = REA.GetDouble("COMMITTED")
        End If

        Try

            Kdex.CONEXION = strConexion
            IntCurrentRow = dgDetalle.Rows.Count - 1

            Kdex.KAR_SIS_EMP = Sesion.IdEmpresa
            Kdex.KAR_DOC_CAT = 75
            Kdex.KAR_DOC_ANO = celdaAño.Text
            Kdex.KAR_DOC_NUM = celdaNumero.Text
            Kdex.KAR_DOC_LIN = IntCurrentRow + 1

            Kdex.Kar_Doc_Fec_NET = dtpFecha1.Value.ToString(FORMATO_MYSQL)
            Kdex.Kar_Opr_Fec_NET = dgDetalle.Rows(i).Cells("colFecha").Value
            Kdex.KAR_ONHAND = OnHand
            Kdex.KAR_ONTRANSIT = OnTransit
            Kdex.KAR_COMMITTED = Commited

            Kdex.KAR_PHY_INC = 0
            Kdex.KAR_PHY_OUT = 0

            Kdex.KAR_FOR_INC = 0
            Kdex.KAR_FOR_OUT = dgDetalle.Rows(i).Cells("colCantidad").Value

            Kdex.KAR_COST_EXT = dgDetalle.Rows(i).Cells("colPrecio").Value
            Kdex.KAR_COST_LOC = (dgDetalle.Rows(i).Cells("colPrecio").Value * celdaTC.Text)
            Kdex.KAR_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
            Kdex.KAR_DOC_TC = celdaTC.Text
            Kdex.KAR_DOC_MON = celdaIDMoneda.Text

            If dgDetalle.Rows(i).Cells("colAgrega").Value = 0 Or Me.Tag = "Mod" Then
                If Kdex.PUPDATE() = False Then
                    MsgBox(Kdex.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(i).Cells("colAgrega").Value = 1 Or Me.Tag = "Nuevo" Then
                If Kdex.PINSERT() = False Then
                    MsgBox(Kdex.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        'Next
        Return logResultado
    End Function

    Private Sub GuardarKardex()
        Dim intCurrentRow As Integer

        intCurrentRow = 0
        For i As Integer = vbEmpty To dgDetalle.Rows.Count - 1
            If dgDetalle.Rows(i).Visible = True Then
                If Not dgDetalle.Rows(i).Cells("colCodigo").Value = vbNullString Then
                    SqlRegistrarKardex(i)
                End If
            End If
        Next
    End Sub

    Private Function GuardarContrato() As Boolean
        Dim logResultado As Boolean = True
        Dim hdr As New clsDcmtos_HDR
        Dim strSQL As String
        Dim Contrato As Integer
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = " SELECT count(*)"
        strSQL &= "  FROM Dcmtos_HDR h"
        strSQL &= "      WHERE h.HDoc_Doc_Cat = 389 AND h.HDoc_Doc_Num = {contrato} AND h.HDoc_Sis_Emp = {empresa} AND h.HDoc_Doc_Ano = {año}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{contrato}", celdaContrato.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM2 = New MySqlCommand(strSQL, conec)
        Contrato = COM2.ExecuteScalar()
        conec.Close()

        If Contrato = 0 Then
            Me.Tag = "Nuevo"
        Else
            Me.Tag = "Mod"
        End If

        Try
            hdr.CONEXION = strConexion

            hdr.HDOC_SIS_EMP = Sesion.IdEmpresa
            hdr.HDOC_DOC_CAT = 389
            hdr.HDOC_DOC_ANO = celdaAño.Text
            hdr.HDOC_DOC_NUM = celdaContrato.Text

            hdr.HDOC_USUARIO = Sesion.Usuario

            hdr.HDOC_EMP_COD = celdaIDSolicitante.Text
            hdr.HDOC_EMP_NOM = celdaSolicitante.Text
            hdr.HDOC_EMP_DIR = celdaDirec.Text
            hdr.HDOC_EMP_TEL = celdaTelefono.Text
            hdr.HDOC_EMP_NIT = celdaNit.Text

            hdr.HDOC_DR1_NUM = celdaNumeroReq.Text

            hdr.HDOC_DOC_MON = celdaIDMoneda.Text
            hdr.HDOC_DOC_TC = celdaTC.Text

            hdr.HDoc_Doc_Fec_NET = dtpFecha.Value.ToString(FORMATO_MYSQL)
            hdr.HDOC_DOC_STATUS = IIf(checkActivo.Checked = True, 1, vbEmpty)


            If Me.Tag = "Mod" Then
                If hdr.Actualizar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            Else
                If hdr.Guardar() = False Then
                    MsgBox(hdr.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function GuardarDetalleContrato() As Boolean
        Dim logResultado As Boolean = True
        Dim DtCon As New clsDcmtos_DTL
        Dim strFecha As Date
        DtCon.CONEXION = strConexion
        Dim strSQL As String
        Dim strSQL2 As String
        Dim Contrato As Integer
        Dim COM2 As MySqlCommand
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim REA As MySqlDataReader
        Dim intLineaContrato As Integer = vbEmpty

        strSQL = " SELECT count(*)"
        strSQL &= "  FROM Dcmtos_DTL h"
        strSQL &= "      WHERE h.DDoc_Doc_Cat = 389 AND h.DDoc_Doc_Num = {contrato} AND h.DDoc_Doc_Ano = {año} AND h.DDoc_Sis_Emp = {empresa}"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{contrato}", celdaContrato.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM2 = New MySqlCommand(strSQL, conec)
        Contrato = COM2.ExecuteScalar()
        conec.Close()

        If Contrato = 0 Then
            Me.Tag = "Nuevo"
        Else
            Me.Tag = "Mod"
        End If
        Dim var As Integer = 0
        Try
            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                strSQL2 = "SELECT ifnull(Max(d.DDoc_Doc_Lin + 1),1) Linea"
                strSQL2 &= "      FROM Dcmtos_DTL d"
                strSQL2 &= "          WHERE d.DDoc_Sis_Emp = {empresa} AND d.DDoc_Doc_Cat  = {catalogo} AND d.DDoc_Doc_Ano = {anio} AND d.DDoc_Doc_Num = {numero}"

                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                strSQL2 = Replace(strSQL2, "{numero}", celdaContrato.Text)
                strSQL2 = Replace(strSQL2, "{anio}", celdaAño.Text)
                strSQL2 = Replace(strSQL2, "{catalogo}", 389)

                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL2, conec)
                Using conec
                    intLineaContrato = COM.ExecuteScalar
                    COM.Dispose()
                    COM = Nothing
                    conec.Close()
                    conec.Dispose()
                    conec = Nothing
                    System.GC.Collect()
                End Using

                If dgDetalle.Rows(i).Visible = True Then
                    'Relación con el documento
                    DtCon.DDOC_SIS_EMP = Sesion.IdEmpresa
                    DtCon.DDOC_DOC_CAT = 389
                    DtCon.DDOC_DOC_ANO = celdaAño.Text
                    DtCon.DDOC_DOC_NUM = celdaContrato.Text

                    If Me.Tag = "Nuevo" Or dgDetalle.Rows(i).Cells("colAgrega").Value = 1 Then
                        DtCon.DDOC_DOC_LIN = intLineaContrato
                        dgDetalle.Rows(i).Cells("colLineaDet").Value = intLineaContrato
                        'dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                    Else
                        DtCon.DDOC_DOC_LIN = dgDetalle.Rows(i).Cells("colLineaDet").Value
                    End If

                    DtCon.DDOC_PRD_COD = dgDetalle.Rows(i).Cells("colCodigo").Value
                    DtCon.DDOC_PRD_DES = dgDetalle.Rows(i).Cells("colDescripcion").Value

                    DtCon.DDOC_PRD_UM = dgDetalle.Rows(i).Cells("colNumMedida").Value

                    DtCon.DDOC_PRD_PUQ = dgDetalle.Rows(i).Cells("colPrecio").Value
                    ' DtCon.DDOC_PRD_DSP = dgDetalle.Rows(i).Cells("colDescripcion").Value
                    DtCon.DDOC_PRD_NET = dgDetalle.Rows(i).Cells("colPrecio").Value
                    DtCon.DDOC_PRD_QTY = dgDetalle.Rows(i).Cells("colCantidad").Value

                    DtCon.DDOC_RF1_DBL = dgDetalle.Rows(i).Cells("colTotal").Value

                    'Primera fecha de entrega
                    If IsDate(dgDetalle.Rows(i).Cells("colFechInicio").Value) Then
                        strFecha = CDate(dgDetalle.Rows(i).Cells("colFechInicio").Value)
                    Else

                        strFecha = "Null"
                    End If
                    DtCon.DDoc_RF1_Fec_NET = strFecha

                    'Ultima fecha de entrega
                    If IsDate(dgDetalle.Rows(i).Cells("colFechFinal").Value) Then
                        strFecha = CDate(dgDetalle.Rows(i).Cells("colFechFinal").Value)
                    Else
                        strFecha = "Null"
                    End If
                    DtCon.DDoc_RF2_Fec_NET = strFecha

                    DtCon.DDOC_RF1_NUM = dgDetalle.Rows(i).Cells("colCodFabricante").Value

                    'If dgDetalle.Rows(i).Visible = True Then
                    If dgDetalle.Rows(i).Cells("colAgrega").Value = 0 And Me.Tag = "Mod" Then
                        If DtCon.Actualizar() = False Then
                            MsgBox(DtCon.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                        End If
                        '    var = var + 1
                        '    If var > 2 Then
                        '        DtCon.Guardar()
                        '    End If
                    ElseIf dgDetalle.Rows(i).Cells("colAgrega").Value = 1 Or Me.Tag = "Nuevo" Then
                        If DtCon.Guardar() = False Then
                            MsgBox(DtCon.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                        End If
                    End If

                End If
            Next

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Function SqlGuardarDescargoContrato(ByVal Index As Integer) As String
        Dim logResultado As Boolean = True
        Dim Pro As New clsDcmtos_DTL_Pro
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Linea As Integer = vbEmpty

        Try
            Pro.PDOC_SIS_EMP = Sesion.IdEmpresa

            'Documento a ser descargado
            Pro.PDOC_PAR_CAT = 389
            Pro.PDOC_PAR_ANO = celdaAño.Text
            Pro.PDOC_PAR_LIN = dgDetalle.Rows(Index).Cells("colLineaDet").Value
            If celdaContrato.Text = NO_FILA Then
                Pro.PDOC_PAR_NUM = 0
            Else
                Pro.PDOC_PAR_NUM = celdaContrato.Text
            End If


            'Referencia al documento actual
            Pro.PDOC_CHI_CAT = 75
            Pro.PDOC_CHI_ANO = celdaAño.Text
            Pro.PDOC_CHI_NUM = celdaNumero.Text
            ' Pro.PDOC_CHI_LIN = Index + 1
            Pro.PDOC_CHI_LIN = dgDetalle.Rows(Index).Cells("colLineaDet").Value
            'Empresa relacionada al doc. actual
            If STR_NOMBRE = "proveedor" Then
                Pro.PDOC_PROV_COD = celdaIDCliente.Text
            Else
                Pro.PDOC_CLTE_COD = celdaIDCliente.Text
            End If

            'Referencia al producto y despacho
            Pro.PDOC_PRD_COD = dgDetalle.Rows(Index).Cells("colCodigo").Value
            Pro.PDOC_PRD_NET = dgDetalle.Rows(Index).Cells("colPrecio").Value
            Pro.PDOC_QTY_ORD = dgDetalle.Rows(Index).Cells("colCantidad").Value
            'Pro.PDOC_QTY_PRO = dgDetalle.Rows(Index).Cells("colCantidad").Value
            If dgDetalle.Rows.Count = 1 Then
                Pro.PDOC_QTY_PRO = dgDetalle.Rows(Index).Cells("colCantidad").Value
            Else
                Pro.PDOC_QTY_PRO = 0
            End If


            If dgDetalle.Rows(Index).Cells("colAgrega").Value = 0 And Me.Tag = "Mod" Then
                If Pro.Actualizar() = False Then
                    MsgBox(Pro.MERROR.ToString & "Could not update the document", MsgBoxStyle.Critical)
                End If
            ElseIf dgDetalle.Rows(Index).Cells("colAgrega").Value = 1 Or Me.Tag = "Nuevo" Then
                If Pro.Guardar() = False Then
                    MsgBox(Pro.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                End If
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return logResultado
    End Function

    Private Sub GuardarDatosProcesadosContrato()
        'Guarda los datos procesados de los documentos relacionados
        Dim i As Integer
        Dim strSQL As String

        For i = 0 To dgDetalle.Rows.Count - 1
            If celdaAño.Text > vbEmpty And dgDetalle.Rows(i).Cells("colCodigo").Value > vbEmpty Then
                'Si tiene relación con otro documento

                strSQL = SqlGuardarDescargoContrato(i)
            End If
        Next
    End Sub

    Private Sub SqlDatosContrato()
        Dim StrSQL As String = STR_VACIO
        Dim i As Integer
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader
        Dim strSQL2 As String
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection

        Try

            strSQL2 = "SELECT p.PDoc_Par_Num "
            strSQL2 &= "    FROM Dcmtos_DTL_Pro p"
            strSQL2 &= "        WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 389 AND p.PDoc_Par_Ano = {año} AND p.Pdoc_Chi_Cat = 75 AND p.PDoc_Chi_Ano= {año} AND  p.PDoc_Chi_Num = {numero}"

            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
            strSQL2 = Replace(strSQL2, "{año}", celdaAño.Text)

            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM2 = New MySqlCommand(strSQL2, conec)
            contratoNum = COM2.ExecuteScalar()
            conec.Close()

            celdaContrato.Text = contratoNum
            If dgContratosLista.Rows.Count > 0 Then
                For i = 0 To dgDetalle.Rows.Count - 1
                    StrSQL = "SELECT IFNULL(p.DDoc_RF1_Fec,'')FechaInicio, IFNULL(p.DDoc_RF2_Fec,'') FechaFinal, IFNULL(p.DDoc_RF1_Num,'') Fabricante, IFNULL(pro.pro_proveedor,0) Proveedor"
                    StrSQL &= "     FROM Dcmtos_DTL p"
                    StrSQL &= "          LEFT JOIN Proveedores pro on pro.pro_sisemp = p.DDoc_Sis_Emp and pro.pro_codigo = p.DDoc_RF1_Num"
                    StrSQL &= "          WHERE p.DDoc_Sis_Emp = {empresa} AND p.DDoc_Doc_Cat = 389 AND p.DDoc_Doc_Ano = {anio} AND p.DDoc_Doc_Num = {numero} AND p.DDoc_Doc_Lin = {linea}"

                    StrSQL = Replace(StrSQL, "{empresa}", Sesion.IdEmpresa)
                    StrSQL = Replace(StrSQL, "{numero}", contratoNum)
                    StrSQL = Replace(StrSQL, "{anio}", celdaAño.Text)
                    StrSQL = Replace(StrSQL, "{linea}", dgDetalle.Rows(i).Cells("colLineaDet").Value)


                    MyCnn.CONECTAR = strConexion

                    COM = New MySqlCommand(StrSQL, CON)
                    REA = COM.ExecuteReader
                    REA.Read()

                    If REA.GetString("FechaInicio") = vbNullString Then
                        dgDetalle.Rows(i).Cells("colFechInicio").Value = 0
                        dgDetalle.Rows(i).Cells("colFechFinal").Value = REA.GetString("FechaFinal")
                        dgDetalle.Rows(i).Cells("colFabricante").Value = REA.GetString("Proveedor")
                        dgDetalle.Rows(i).Cells("colCodFabricante").Value = REA.GetString("Fabricante")
                    ElseIf REA.GetString("FechaFinal") = vbNullString Then
                        dgDetalle.Rows(i).Cells("colFechInicio").Value = REA.GetString("FechaInicio")
                        dgDetalle.Rows(i).Cells("colFechFinal").Value = 0
                        dgDetalle.Rows(i).Cells("colFabricante").Value = REA.GetString("Proveedor")
                        dgDetalle.Rows(i).Cells("colCodFabricante").Value = REA.GetString("Fabricante")
                    Else
                        dgDetalle.Rows(i).Cells("colFechInicio").Value = REA.GetString("FechaInicio")
                        dgDetalle.Rows(i).Cells("colFechFinal").Value = REA.GetString("FechaFinal")
                        dgDetalle.Rows(i).Cells("colFabricante").Value = REA.GetString("Proveedor")
                        dgDetalle.Rows(i).Cells("colCodFabricante").Value = REA.GetString("Fabricante")
                    End If

                Next
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    'Descargos por linea
    Private Function SqlDescargos(ByVal Linea As Integer)

        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "SELECT COUNT(*) "
        strSQL &= "  FROM Dcmtos_DTL_Pro p"
        strSQL &= "          LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp and h.HDoc_Doc_Cat = p.PDoc_Chi_Cat and h.HDoc_Doc_Ano = p.PDoc_Chi_Ano and h.HDoc_Doc_Num = p.PDoc_Chi_Num"
        strSQL &= "      WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat  = 75 AND p.PDoc_Par_Ano = {año} AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Par_Num = {numero} AND p.PDoc_Par_Lin ={linea} AND h.HDoc_Doc_Status = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)
        strSQL = Replace(strSQL, "{linea}", Linea)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Descargos = COM.ExecuteScalar()
        conec.Close()

        Return Descargos
    End Function

    'Descargos en General
    Private Function SqlDescargos()

        Dim strSQL As String
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection

        strSQL = "SELECT COUNT(*) "
        strSQL &= "  FROM Dcmtos_DTL_Pro p"
        strSQL &= "          LEFT JOIN Dcmtos_HDR h ON h.HDoc_Sis_Emp = p.PDoc_Sis_Emp and h.HDoc_Doc_Cat = p.PDoc_Chi_Cat and h.HDoc_Doc_Ano = p.PDoc_Chi_Ano and h.HDoc_Doc_Num = p.PDoc_Chi_Num"
        strSQL &= "      WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat  = 75 AND p.PDoc_Par_Ano = {año} AND p.PDoc_Chi_Cat = 48 AND p.PDoc_Par_Num = {numero} AND h.HDoc_Doc_Status = 1"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)
        strSQL = Replace(strSQL, "{año}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Descargos = COM.ExecuteScalar()
        conec.Close()

        Return Descargos
    End Function
    Private Sub GuardarSubdocumento()
        Dim logResultado As Boolean = True
        Dim DtACC As New Tablas.TDCMTOS_ACC
        Dim strFecha As String
        Dim Doc As New frmSubDocumentos
        DtACC.CONEXION = strConexion
        Dim strSQL As String = STR_VACIO
        Dim strSQL5 As String = STR_VACIO
        Dim Nota1 As String = STR_VACIO
        Dim Nota2 As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim i As Integer = 0
        Dim REA As MySqlDataReader
        Dim contador As Integer
        Try

            strSQL5 = "   SELECT DISTINCT(ca.cat_desc) nota, cat_clave tipo"
            strSQL5 &= "     FROM Catalogos ca"
            strSQL5 &= "          WHERE ca.cat_clase='Defaults' AND ca.cat_sist = 'Doc_CNotas'"

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL5, CON)
            REA = COM.ExecuteReader


            contador = 1
            Do While REA.Read

                DtACC.ADOC_SIS_EMP = Sesion.IdEmpresa
                DtACC.ADOC_DOC_CAT = 75
                DtACC.ADOC_DOC_ANO = celdaAño.Text
                DtACC.ADOC_DOC_NUM = celdaNumero.Text

                DtACC.ADOC_DOC_SUB = "Doc_CNotas"
                DtACC.ADOC_DOC_LIN = 0 & contador
                contador = contador + 1
                DtACC.ADOC_DTA_DES = REA.GetString("tipo")
                DtACC.ADOC_DTA_TXT = REA.GetString("nota")
                DtACC.ADoc_Dta_Fec_NET = "2000-01-01"

                If Me.Tag = "Nuevo" Then
                    If DtACC.PINSERT = False Then
                        MsgBox(DtACC.MERROR.ToString & "Could not save the document", MsgBoxStyle.Critical)
                    End If
                End If
            Loop

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Public Sub ResetProyecto()
        celdaidProyecto.Text = NO_FILA
        celdaidTarea.Text = NO_FILA
        celdaidflujodetalle.Text = NO_FILA
        celdaDescripcion.Text = STR_VACIO
        celdaDescripcionP.Text = STR_VACIO
        celdaProyecto.Text = STR_VACIO

    End Sub
    Private Function PedirComentario() As String
        Dim strTemp As String = STR_VACIO
        Dim frm As New frmPedirComentarios
        Dim strSQL As String = STR_VACIO

        frm.Show()
        If frm.Aceptado Then
            strTemp = frm.Dato
        End If
        PedirComentario = strTemp
    End Function
    Private Function sqlMensajeCLiente() As String
        Dim strSQL As String = STR_VACIO

        Select Case celdaCatalogo.Text
            Case 75
                strSQL = " SELECT h.HDoc_Doc_Fec, h.HDoc_Doc_Num, h.HDoc_DR1_Num, h.HDoc_Emp_Nom, o.cat_clave, d.DDoc_Prd_Des, d.DDoc_Prd_QTY, u.cat_desc, d.DDoc_Prd_NET "
                strSQL &= " FROM Dcmtos_HDR h"
                strSQL &= " LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= " LEFT JOIN Clientes c ON c.cli_sisemp = d.DDoc_Sis_Emp AND c.cli_codigo = h.HDoc_Emp_Cod "
                strSQL &= " LEFT JOIN Catalogos o ON o.cat_num = c.cli_pais AND o.cat_clase ='Paises' "
                strSQL &= " LEFT JOIN Catalogos u ON u.cat_num = d.DDoc_Prd_UM "

            Case 36
                strSQL = " SELECT h.HDoc_Doc_Num numero , h.HDoc_Doc_Fec fecha , h.HDoc_Emp_Nom  cliente  ,a.art_DCorta  hilo , d.DDoc_Prd_QTY cantidad , concat(c.cli_plazoCR,' DAYS ', c.cli_forma ) terms , hf.HDoc_DR1_Num pf, g.cli_cliente pagador, datediff(now(),DATE_ADD(h.HDoc_Doc_Fec , INTERVAL c.cli_plazoCR  DAY) ) dias, "
                strSQL &= "  ( select dy.DDoc_Prd_NET FROM Dcmtos_HDR yy "
                strSQL &= "     LEFT JOIN Dcmtos_DTL dy ON dy.DDoc_Sis_Emp = yy.HDoc_Sis_Emp AND dy.DDoc_Doc_Cat = yy.HDoc_Doc_Cat AND dy.DDoc_Doc_Ano = yy.HDoc_Doc_Ano AND dy.DDoc_Doc_Num = yy.HDoc_Doc_Num "
                strSQL &= "    where yy.HDoc_Sis_Emp = h.HDoc_Sis_Emp and yy.HDoc_Doc_Cat = h.HDoc_Doc_Cat and yy.HDoc_Doc_Ano  =h.HDoc_Doc_Ano and yy.HDoc_Doc_Num = h.HDoc_Doc_Num and dy.DDoc_Doc_Lin = d.DDoc_Doc_Lin ) precio, "
                strSQL &= "  (SELECT round((sum(s.ECta_Crgo_Ext))-(sum(s.ECta_Abno_Ext ) ) ,2)  "
                strSQL &= "    FROM ECtaCte s"
                strSQL &= "   where s.ECta_Sis_Emp = h.HDoc_Sis_Emp  and s.ECta_Ref_Cat = h.HDoc_Doc_Cat  and s.ECta_Ref_Ano = h.HDoc_Doc_Ano  and s.ECta_Ref_Num = h.HDoc_Doc_Num )saldo "
                strSQL &= " FROM Dcmtos_HDR h "
                strSQL &= "  LEFT JOIN Dcmtos_DTL d ON d.DDoc_Sis_Emp = h.HDoc_Sis_Emp AND d.DDoc_Doc_Cat = h.HDoc_Doc_Cat AND d.DDoc_Doc_Ano = h.HDoc_Doc_Ano AND d.DDoc_Doc_Num = h.HDoc_Doc_Num "
                strSQL &= "  left join Inventarios i on i.inv_sisemp = d.DDoc_Sis_Emp and i.inv_numero = d.DDoc_Prd_Cod "
                strSQL &= "  left join Articulos a on a.art_sisemp = i.inv_sisemp and a.art_codigo = i.inv_artcodigo "
                strSQL &= "  left join Clientes c on c.cli_sisemp = h.HDoc_Sis_Emp and c.cli_codigo = h.HDoc_Emp_Cod "
                strSQL &= "  left join Dcmtos_DTL_Pro p on p.PDoc_Sis_Emp and d.DDoc_Sis_Emp and p.PDoc_Chi_Cat = d.DDoc_Doc_Cat and p.PDoc_Chi_Ano =d.DDoc_Doc_Ano and p.PDoc_Chi_Num = d.DDoc_Doc_Num and p.PDoc_Chi_Lin = d.DDoc_Doc_Lin "
                strSQL &= "  left join Dcmtos_DTL_Pro f on f.PDoc_Sis_Emp =p.PDoc_Sis_Emp and f.PDoc_Chi_Cat =p.PDoc_Par_Cat and f.PDoc_Chi_Ano = p.PDoc_Par_Ano and f.PDoc_Chi_Num = p.PDoc_Par_Num and f.PDoc_Chi_Lin = p.PDoc_Par_Lin  and f.PDoc_Par_Cat = 75 "
                strSQL &= "  left join Dcmtos_HDR hf on hf.HDoc_Sis_Emp  =f.PDoc_Sis_Emp and  hf.HDoc_Doc_Cat = f.PDoc_Par_Cat and hf.HDoc_Doc_Ano = f.PDoc_Par_Ano and hf.HDoc_Doc_Num = f.PDoc_Par_Num "
                strSQL &= "  left join Clientes g on g.cli_sisemp = hf.HDoc_Sis_Emp and g.cli_codigo = hf.HDoc_DR1_Emp  "


        End Select

        strSQL &= " WHERE h.HDoc_Sis_Emp ={empresa} AND h.HDoc_Doc_Cat ={catalogo} AND h.HDoc_Doc_Ano ={ano} AND h.HDoc_Doc_Num ={numero} "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", celdaCatalogo.Text)
        strSQL = Replace(strSQL, "{ano}", celdaAño.Text)
        strSQL = Replace(strSQL, "{numero}", celdaNumero.Text)

        Return strSQL
    End Function
    Private Sub GenerarComentarioDocumentos(Optional strComentario As String = STR_VACIO)
        Dim frmComentario As New frmPedirComentarios
        Dim ts As New Tablas.TENTRADAS
        Dim strSQL As String
        Dim strTemporal As String = STR_VACIO
        Dim COM As New MySqlCommand
        Dim REA As MySqlDataReader
        Dim intValidacion As Integer

        Try
            MyCnn.CONECTAR = strConexion
            strSQL = sqlMensajeCLiente()
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader

            intValidacion = 0
            If REA.HasRows Then
                Do While REA.Read
                    Select Case celdaCatalogo.Text
                        Case 75
                            If intValidacion = 0 Then
                                frmComentario.Dato = "DATE: " & REA.GetDateTime("HDoc_Doc_Fec") & vbCrLf
                                frmComentario.Dato &= "PF: " & REA.GetInt32("HDoc_Doc_Num") & vbCrLf
                                frmComentario.Dato &= "ORDER: " & REA.GetString("HDoc_DR1_Num") & vbCrLf
                                frmComentario.Dato &= "Client: " & REA.GetString("cat_clave") & vbCrLf
                            End If
                            intValidacion = 1
                            frmComentario.Dato &= REA.GetString("DDoc_Prd_Des") & Space(3) & REA.GetDouble("DDoc_Prd_QTY").ToString(FORMATO_MONEDA) & Space(3) & REA.GetDouble("DDoc_Prd_NET").ToString(FORMATO_MONEDA) & vbCrLf
                        Case 36
                            If intValidacion = 0 Then
                                frmComentario.Dato = "DATE: " & REA.GetDateTime("fecha") & vbCrLf
                                frmComentario.Dato &= "INVOICE: " & REA.GetInt32("numero") & vbCrLf
                                frmComentario.Dato &= "CUSTOMER: " & REA.GetString("cliente") & vbCrLf
                                frmComentario.Dato &= "TERMS: " & REA.GetString("terms") & vbCrLf
                                frmComentario.Dato &= "PF : " & REA.GetString("pf") & vbCrLf
                                frmComentario.Dato &= "PAYER : " & REA.GetString("pagador") & vbCrLf
                                frmComentario.Dato &= "DAYS EXPIRED : " & REA.GetString("dias") & vbCrLf
                                frmComentario.Dato &= "BALANCE : " & REA.GetString("saldo") & vbCrLf

                                frmComentario.Dato &= vbCrLf & vbCrLf
                            End If
                            intValidacion = 1
                            frmComentario.Dato &= REA.GetString("hilo") & Space(3) & REA.GetDouble("cantidad").ToString(FORMATO_MONEDA) & Space(3) & REA.GetDouble("precio").ToString(FORMATO_MONEDA) & vbCrLf
                    End Select
                    strTemporal = frmComentario.Dato

                    strTemporal = Replace(strTemporal, vbCrLf, "<br>")

                Loop
                strTextoComentario &= vbCrLf & "<tr> <td colspan='3' style='border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: center'>" & strComentario & " " & celdaDescripcion.Text & "- " & vbCrLf & strTemporal & "</td> </tr> "

                ts.Inicio_NET = cFunciones.HoyMySQL
                ts.Fin_NET = cFunciones.HoyMySQL
                ts.CONEXION = strConexion
                ts.EMPRESA = Sesion.IdEmpresa
                ts.IDENTRADA = 0
                ts.IDTAREA = CInt(celdaidTarea.Text)
                ts.IDPROYECTO = CInt(celdaidProyecto.Text)
                ts.USUARIO = Sesion.Usuario
                ts.COMENTARIO = strComentario & vbCrLf & frmComentario.Dato

                If ts.PINSERT = False Then
                    MsgBox(ts.MERROR.ToString)
                End If

                EnvioProyecto()
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    ' Envio Correo 
    Private Function EnvioProyecto() As Boolean
        Dim logEnvio As Boolean = False
        Dim mail As New clsCorreo
        Dim correo As New Tablas.TCORREO
        Dim strSQL As String
        Dim strInsert As String = STR_VACIO
        Dim strUsuario As String
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim DOC As MySqlDataReader
        Dim REA As MySqlDataReader
        Dim conec As MySqlConnection
        Dim COM1 As MySqlCommand
        Dim strSQl1 As String = STR_VACIO
        Dim strSQL2 As String = STR_VACIO
        Dim strConexion2 As String = STR_VACIO
        Dim strContenido As String = STR_VACIO
        Dim strComentario As String = STR_VACIO
        Dim strTexto As String = STR_VACIO


        Dim ArrayServer() As String
        Dim ArrayAuxiliar() As String

        Try
            strSQL = " SELECT nof.idNotificacion Notificacion,pe.per_codigo Codigo,IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pue.pue_descripcion),'')Puesto, nof.idUsuario,nof.Observaciones,pe.per_correo Correo"
            strSQL &= "  FROM Notificaciones nof  "
            strSQL &= "  LEFT JOIN Personal pe ON  pe.per_sisemp = nof.Empresa  AND pe.per_usuario = nof.idUsuario "
            strSQL &= " LEFT JOIN Puestos pue ON pue.pue_sisemp = pe.per_sisemp AND pue.pue_codigo = pe.per_puesto"
            strSQL &= " where nof.Empresa= {empresa}  and nof.idProyecto = {proyecto} and nof.idTarea in(0,{idtarea})  and length(nof.idUsuario )>1 "
            strSQL &= " group by nof.idUsuario  "


            strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
            strSQL = Replace(strSQL, "{proyecto}", celdaidProyecto.Text)
            strSQL = Replace(strSQL, "{idtarea}", celdaidTarea.Text)





            strSQl1 = " Select   CONCAT(per_nombre1 ,'  ' ,per_apellido1) Puesto  FRom Personal  WHERE per_codigo={usuario} "
            strSQl1 = Replace(strSQl1, "{usuario}", Sesion.idUsuario)
            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM1 = New MySqlCommand(strSQl1, conec)
            strUsuario = COM1.ExecuteScalar
            conec.Close()
            conec.Dispose()
            conec = Nothing
            System.GC.Collect()

            ArrayServer = strConexion.Split(";".ToCharArray)

            strConexion2 = "server={server};port={puerto};uid={user};password={password};database={database} ;Allow User Variables=True"
            ArrayAuxiliar = ArrayServer(INT_CERO).Split("=".ToCharArray)

            If ArrayAuxiliar(INT_UNO) = "192.168.4.9" Then
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST)
                strConexion2 = Replace(strConexion2, "port={puerto};", vbNullString)
            Else
                strConexion2 = Replace(strConexion2, "{server}", MAIL_HOST_REMOTO)
                strConexion2 = Replace(strConexion2, "{puerto}", "3308")
            End If

            strConexion2 = Replace(strConexion2, "{user}", MAIL_USER)
            strConexion2 = Replace(strConexion2, "{password}", MAIL_PASS)
            strConexion2 = Replace(strConexion2, "{database}", MAIL_BASE)

            ' Historial 
            strTexto &= " <tr> <td colspan='3'; style=' border-left:solid black 1px;border-right: solid black 1px;border-bottom:solid black 1px;background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: center' >  History  </td> </tr> "
            strSQL2 = " SELECT  IFNULL(CONCAT(pe.per_nombre1,' ',pe.per_apellido1,' - ',pu.pue_descripcion),'')Puesto,  IFNULL(en.Fin,'')Fin,en.comentario  FROM Entradas en "
            strSQL2 &= " LEFT JOIN Personal pe ON pe.per_sisemp = en.Empresa AND pe.per_usuario = en.usuario LEFT JOIN Puestos pu ON pu.pue_sisemp = pe.per_sisemp AND pu.pue_codigo = pe.per_puesto "
            strSQL2 &= " WHERE en.Empresa = {empresa} AND en.idProyecto ={proyecto}  AND en.idTarea ={tarea} "
            strSQL2 &= " ORDER BY en.Inicio DESC limit 20 "
            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{proyecto}", celdaidProyecto.Text)
            strSQL2 = Replace(strSQL2, "{tarea}", celdaidTarea.Text)

            MyCnn.CONECTAR = strConexion
            COM2 = New MySqlCommand(strSQL2, CON)
            DOC = COM2.ExecuteReader
            Do While DOC.Read
                strComentario = DOC.GetString("comentario")
                strComentario = Replace(strComentario, vbCrLf, "<br>")

                strTexto &= " <tr> <td style='width: 2.0cm;text-align: left;border-left: solid black 1px ;border-right: solid black 1px ;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 1.5cm;'> " & DOC.GetString("Puesto") & " </td> "

                strTexto &= " <td style='width: 2.0cm;text-align: left;border-left: solid black 1px ;border-right: solid black 1px ;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 2.5cm;'> " & DOC.GetString("Fin") & " </td> "

                strTexto &= " <td style='width: 2.0cm;text-align: left;border-left: solid black 1px ;border-right: solid black 1px ;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 13.5cm;'> " & strComentario & " </td> </tr> "
            Loop
            strTexto = Replace(strTexto, "'", Chr(34))


            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            REA = COM.ExecuteReader
            Dim strTemporal As String = STR_VACIO
            Dim strResponsable As String = STR_VACIO
            strTemporal = vbCrLf & " <html> <BODY> <table cellspacing=0> <tr> <td colspan='3'; style=' border:solid White 0px; background-color: #FFFFFF; color: Black; padding:2px 5px; font-family: Tahoma, Arial;font-size: 10pt;width: 3.5cm;text-align: left;border-bottom:solid black 1px; border-right: solid black 1px;border-left: solid black 1px;border-top:solid black 1px;font-weight:bold;'>" & strUsuario & "</td> </tr> <tr><td style='border-left:solid black 1px;border-right: solid black 1px;background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left'>  Project:</td> <td colspan='2' style='border-right: solid black 1px; border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;'> " & celdaProyecto.Text & "</td> </tr> <tr><td style=' border-left:solid black 1px;border-right: solid black 1px; border-top:solid black 1px; background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: left' > Description: </td> <td colspan='2' style='border-right: solid black 1px; border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;'>  " & celdaDescripcionP.Text & " </td></tr> <tr><td colspan='3'; style=' border-top:solid black 1px;border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;background-color: #1976D2; color: white; padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: center'>" & celdaDescripcion.Text & "</td> </tr> " & strTextoComentario
            '  strResponsable = " <tr> <td colspan='3' style='border-right: solid black 1px;border-left:solid black 1px;border-bottom:solid black 1px;padding:2px 5px; font-family: Tahoma, Arial;font-size: 7pt;width: 3.5cm;text-align: center'>  responsability:  " & celdaResponsable.Text & " </td> </tr>"
            strTemporal = Replace(strTemporal, "'", Chr(34))
            strResponsable = Replace(strResponsable, "'", Chr(34))
            Do While REA.Read
                ' correo.IDCORREO = 0
                ' correo.DESTINATARIO = REA.GetString("Correo")
                ' correo.ASUNTO = "Project # " & celdaIdProyecto.Text & "  " & celdaProyecto.Text
                strContenido = strTemporal & vbCrLf & strResponsable & strTexto & " </table> </body> </html>"
                ' correo.CONTENIDO = strUsuario & "  " & strContenido
                ' correo.CONEXION = strConexion2
                '   If correo.PINSERT = False Then
                '  MsgBox("Could not Save" & correo.MERROR.ToString, MsgBoxStyle.Information, "Aviso")
                '  End If
                'logEnvio = True
                strInsert &= ("INSERT INTO MailServer.Correo (idCorreo,Destinatario,Asunto,Contenido,Estado) Values(0,'" & REA.GetString("Correo") & "','Project # " & " " & celdaidProyecto.Text & "','" & strUsuario & "  " & strContenido & "',0); ")
            Loop
            COM = Nothing

            MyCnn.CONECTAR = strConexion2
            COM = New MySqlCommand(strInsert, CON)
            COM.ExecuteNonQuery()
            COM.Dispose()
            System.GC.Collect()
            logEnvio = True
            strTexto = STR_VACIO
            strTextoComentario = STR_VACIO
        Catch ex As Exception
            If MsgBox("Error sending email. Please check your internet connection.Press yes to try again or no for cancel the process.", vbQuestion + +vbYesNo + vbDefaultButton2) = vbYes Then
                'SI
                EnvioProyecto()

            Else
                'NO
                logEnvio = True
            End If
        End Try
        Return logEnvio
        strTexto = STR_VACIO

    End Function

    Private Function VerificarSiTieneDespacho() As Integer
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer
        Dim strSQL As String = STR_VACIO

        strSQL = " SELECT COUNT(*) FROM Dcmtos_HDR d "
        strSQL &= " LEFT JOIN Dcmtos_DTL_Pro s ON s.PDoc_Sis_Emp = d.HDoc_Sis_Emp AND s.PDoc_Par_Cat = d.HDoc_Doc_Cat AND s.PDoc_Par_Ano = d.HDoc_Doc_Ano AND s.PDoc_Par_Num = d.HDoc_Doc_Num and s.PDoc_Chi_Cat = 48 "
        strSQL &= " WHERE d.HDoc_Sis_Emp = {empresa} AND d.HDoc_Doc_Cat = 75 AND d.HDoc_Doc_Ano = {anio} AND d.HDoc_Doc_Num = {num} AND s.PDoc_Sis_Emp IS NULL "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)
        strSQL = Replace(strSQL, "{num}", celdaNumero.Text)
        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto

    End Function

#End Region

#Region "Eventos"

    Private Sub frmPedidosClient_proforma__FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'frmSPrincipal.BarraDeTareas1.QuitarFormulario(strKey)
        Fprincipal.BarraDeTareas1.QuitarFormulario(strKey)
    End Sub

    Private Sub frmPedidosClient_proforma__load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtpInicio.Value = dtpInicio.Value.AddMonths(NO_FILA)
        dtpFinal.Value = Today

        MostrarLista()
        Accessos()

    End Sub

    Private Sub Encabezado1_ClickCerrar(sender As Object, click As Boolean) Handles Encabezado1.ClickCerrar
        If panelDocumento.Visible = False Then
            Me.Close()
            BotonHoras.Visible = False
        Else
            BotonHoras.Visible = True
            MostrarLista()
            LimpiarPanelOrden()
        End If
    End Sub

    Private Sub encabezado1_ClickNuevo(sender As Object, click As Boolean) Handles Encabezado1.ClickNuevo
        Encabezado1.botonGuardar.Enabled = True
        Me.Tag = "Nuevo"
        Dim intNumero As Integer
        Dim intAño As Integer

        If logInsertar = True Then
            LimpiarPanelOrden()
            ResetProyecto()

            MostrarLista(False, True)

            celdaAño.Text = cFunciones.AñoMySQL
            celdaNumero.Text = -1
            celdaNumero.Enabled = True
            intNumero = celdaAño.Text
            intAño = celdaAño.Text
            querySubDoc(intNumero, intAño)
            celdaAño.Text = cFunciones.AñoMySQL
            celdaComentario.Text = 0

            celdaEmpresa.Text = Sesion.IdEmpresa
            celdaMoneda.Text = "US$"
            celdaIDMoneda.Text = 178
            celdaCatalogo.Text = 75
            If dgContratosLista.Rows.Count < vbEmpty Then
                checkCarta.Checked = True
                checkCarta.Enabled = False
            Else
                checkCarta.Checked = False
                checkCarta.Enabled = True
            End If
            celdaUsuario.Text = Sesion.Usuario
            celdaDefault.Text = "Please write Check for Import Charges under the name of NESTOR HERNANDEZ. For Order Items write under AmTex Guatemala, S.A. If International Check. If local check, please issue check under the name of the bank where the check is from. NOTICE: Separate payments are needed."
            celdaAño.Enabled = True
            celdaNumero.Enabled = True
            botonDespachos.Enabled = True
            ckeckPagaImp.Checked = False
            celdaRevisado.Text = 0
            celdaContrato.Text = -1
            botonContrato.Enabled = False
            checkActivo.Checked = True
            etiquetaAnulada.Visible = False
            BotonHoras.Visible = False

        Else
            MsgBox("You do not have access to create a new instruction", vbInformation)
        End If


    End Sub
    Private Function NuevaFactura() As Integer
        Dim strSQL As String = STR_VACIO
        Dim conec As New MySqlConnection
        Dim COM As MySqlCommand
        Dim CodigoProyecto As Integer

        strSQL = " Select IFNULL(MAX(HDR.HDoc_Doc_Num),0)+1 NUMERO  "
        strSQL &= " FROM Dcmtos_HDR HDR"
        strSQL &= " WHERE HDR.HDoc_Sis_Emp = {empresa} And HDR.HDoc_Doc_Cat = {catalogo}   "

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{catalogo}", 75)
        strSQL = Replace(strSQL, "{anio}", celdaAño.Text)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        CodigoProyecto = COM.ExecuteScalar
        conec.Close()
        conec.Dispose()
        conec = Nothing
        System.GC.Collect()
        Return CodigoProyecto
    End Function
    Private Sub Encabezado1_ClickGuardar(sender As Object, click As Boolean) Handles Encabezado1.ClickGuardar
        Encabezado1.botonGuardar.Enabled = False
        Try
            Dim cls As New clsFunciones
            Dim logReporte As Boolean
            ' Me.Tag = vbNullString

            If logInsertar = True Then
                If Me.Tag = "Nuevo" Then
                    If ComprobarDatos() Then
                        If ComprobarPagoImpuestos() Then
                            If checkCarta.Checked = True And dgContratosLista.Rows.Count = vbEmpty Then
                                If MsgBox("Are you sure you want to create a contract?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                    celdaContrato.Text = cls.NuevoId(389) 'cls.Verificacion_Nuevo_Registro(celdaContrato.Text, "Dcmtos", 389, celdaAño.Text)
                                    botonContrato.Enabled = True
                                    If celdaNumeroReq.Text = vbNullString Then
                                        celdaNumeroReq.Text = "PM" & Space(1) & celdaContrato.Text
                                    End If
                                    GuardarContrato()
                                    GuardarDetalleContrato()
                                Else
                                    Exit Sub
                                    botonContrato.Enabled = False
                                End If

                                celdaNumero.Text = NuevaFactura()

                                If celdaNumero.Text > 0 Then
                                    If celdaNumeroReq.Text = vbNullString Then
                                        celdaNumeroReq.Text = PRE_PF & celdaNumero.Text
                                    End If
                                End If

                                GuardarDocumento()
                                GuardarDetalle()
                                GuardarSubdocumento()
                                GuardarKardex()

                                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)

                                If checkCarta.Checked = True Then
                                    GuardarDatosProcesadosContrato()
                                End If


                                If MsgBox("The document has been saved." & vbCr &
                                          vbCr & "Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                    logReporte = True
                                    Dim intAnio As Integer
                                    Dim intNumero As Integer
                                    Dim rpt As New clsReportes
                                    Dim respuesta As String
                                    Dim respuesta1 As String


                                    intNumero = celdaNumero.Text
                                    intAnio = celdaAño.Text
                                    respuesta = MsgBox("¿To print format in English?", vbYesNo)

                                    If respuesta = vbYes Then
                                        respuesta1 = MsgBox("¿To use the special format?", vbYesNo)
                                        If respuesta1 = vbYes Then

                                            ' REPORTE EN FORMATO ESPECIAL
                                            rpt.Rpt_ProformaEsp(intNumero, intAnio)
                                        ElseIf respuesta1 = vbNo Then

                                            'REPORTE EN FORMATO INGLES
                                            rpt.Rpt_ProformaIng(intNumero, intAnio)
                                        End If
                                    ElseIf respuesta = vbNo Then

                                        'REPORTE EN FORMATO ESPAÑOL/INGLES
                                        rpt.Rpt_Proforma(intNumero, intAnio)

                                    End If
                                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)
                                Else
                                    MostrarLista(True)
                                End If
                                MostrarLista(True)
                            Else
                                celdaNumero.Text = cls.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 75, celdaAño.Text)

                                If celdaNumero.Text > 0 Then
                                    If celdaNumeroReq.Text = vbNullString Then
                                        celdaNumeroReq.Text = PRE_PF & celdaNumero.Text
                                    End If
                                End If

                                GuardarDocumento()
                                GuardarDetalle()
                                GuardarSubdocumento()
                                GuardarKardex()
                                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)

                                If MsgBox("The document has been saved." & vbCr &
                                          vbCr & " Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                    logReporte = True
                                    Dim intAnio As Integer
                                    Dim intNumero As Integer
                                    Dim rpt As New clsReportes
                                    Dim respuesta As String
                                    Dim respuesta1 As String


                                    intNumero = celdaNumero.Text
                                    intAnio = celdaAño.Text
                                    respuesta = MsgBox("¿To print format in English?", vbYesNo)

                                    If respuesta = vbYes Then
                                        respuesta1 = MsgBox("¿To use the special format?", vbYesNo)
                                        If respuesta1 = vbYes Then

                                            ' REPORTE EN FORMATO ESPECIAL
                                            rpt.Rpt_ProformaEsp(intNumero, intAnio)
                                        ElseIf respuesta1 = vbNo Then

                                            'REPORTE EN FORMATO INGLES
                                            rpt.Rpt_ProformaIng(intNumero, intAnio)
                                        End If
                                    ElseIf respuesta = vbNo Then

                                        'REPORTE EN FORMATO ESPAÑOL/INGLES
                                        rpt.Rpt_Proforma(intNumero, intAnio)

                                    End If
                                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)
                                Else
                                    MostrarLista(True)
                                End If
                                MostrarLista(True)
                            End If
                        Else
                            Exit Sub
                        End If
                        Exit Sub
                    End If
                Else
                    If logEditar = True Then
                        If Me.Tag = "Mod" Then

                            'Se agrego solicitud de autorizacion para efectuar cambios
                            ' para las empresas 11,12,14,16
                            'WC
                            ' 18-03-2022


                            If Sesion.IdEmpresa = 11 Or Sesion.IdEmpresa = 12 Or
                                Sesion.IdEmpresa = 14 Or Sesion.IdEmpresa = 16 Then


                                If PedirAutorizacionMODPed("Pedido de Clientes (Proforma)") = False Then
                                    MsgBox("You do not have authorization for this operation", vbInformation)
                                    Encabezado1.botonGuardar.Enabled = True
                                    Exit Sub
                                End If
                            End If

                            Dim strSQL2 As String
                            Dim COM2 As MySqlCommand
                            Dim conec2 As MySqlConnection
                            Dim Contrato As Integer
                            Dim strTexto As String = STR_VACIO
                            Dim PD As New frmPedirComentarios

                            If celdaComentario.Text = 1 Then
                                PD.ShowDialog(Me)
                                strTexto = PD.celdaInfo.Text
                                PD.Iniciar(strTexto)
                            End If
                            If checkActivo.Checked = False Then
                                If VerificarSiTieneDespacho() = 0 Then
                                    MsgBox(" Proforma Invoice has deliveries already, therefore, we cannot cancel it ")
                                    Exit Sub
                                End If
                            End If
                            strSQL2 = "SELECT COUNT(*)"
                            strSQL2 &= "     FROM Dcmtos_DTL_Pro p"
                            strSQL2 &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 389 AND p.PDoc_Chi_Cat = 75 AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Chi_Ano = {año}"

                            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
                            strSQL2 = Replace(strSQL2, "{año}", celdaAño.Text)

                            conec2 = New MySqlConnection(strConexion)
                            conec2.Open()
                            COM2 = New MySqlCommand(strSQL2, conec2)
                            Contrato = COM2.ExecuteScalar()
                            If Contrato = 0 Then
                                Contrato = NO_FILA
                            End If
                            conec2.Close()

                            If Contrato = NO_FILA Then
                                If ComprobarDatos() = True Then
                                    'celdaContrato.Text = NO_FILA
                                    If checkCarta.Checked = True And dgContratosLista.Rows.Count = vbEmpty Then
                                        If MsgBox("Are you sure you want to create a contract?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                            celdaContrato.Text = cls.Verificacion_Nuevo_Registro(celdaContrato.Text, "Dcmtos", 389, celdaAño.Text)
                                            If celdaNumeroReq.Text = vbNullString Then
                                                celdaNumeroReq.Text = "PM" & Space(1) & celdaContrato.Text
                                            End If
                                            Me.Tag = "Nuevo"
                                            GuardarContrato()
                                            GuardarDetalleContrato()
                                            BorrarLineDetalle(celdaContrato.Text, 389)
                                            BorrarLineDetalleDescargo(celdaContrato.Text, 389)
                                        Else
                                            Exit Sub
                                        End If

                                    End If
                                    Me.Tag = "Mod"
                                    GuardarDocumento()
                                    GuardarDetalle()
                                    BorrarLineDetalle(celdaNumero.Text, 75)
                                    If celdaidProyecto.Text <> NO_FILA Then
                                        GenerarComentarioDocumentos(strTexto)
                                    End If
                                    GuardarSubdocumento()
                                    GuardarKardex()

                                    'Me.Tag = "Mod"
                                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text, strTexto)

                                    If checkCarta.Checked = True Then
                                        If checkActivo.Checked = True Then
                                            Me.Tag = "Nuevo"
                                            GuardarDatosProcesadosContrato()
                                        Else
                                            Me.Tag = "Mod"
                                            GuardarDatosProcesadosContrato()
                                        End If
                                    End If

                                    'cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaCatalogo.Text, celdaAño.Text, celdaNumero.Text)
                                    If MsgBox("The document has been Save." & vbCr &
                                  vbCr & " Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                        logReporte = True
                                        Dim intAnio As Integer
                                        Dim intNumero As Integer
                                        Dim rpt As New clsReportes
                                        Dim respuesta As String
                                        Dim respuesta1 As String


                                        intNumero = celdaNumero.Text
                                        intAnio = celdaAño.Text
                                        respuesta = MsgBox("¿To print format in English?", vbYesNo)

                                        If respuesta = vbYes Then
                                            respuesta1 = MsgBox("¿To use the special format?", vbYesNo)
                                            If respuesta1 = vbYes Then

                                                ' REPORTE EN FORMATO ESPECIAL
                                                rpt.Rpt_ProformaEsp(intNumero, intAnio)
                                            ElseIf respuesta1 = vbNo Then

                                                'REPORTE EN FORMATO INGLES
                                                rpt.Rpt_ProformaIng(intNumero, intAnio)
                                            End If
                                        ElseIf respuesta = vbNo Then

                                            'REPORTE EN FORMATO ESPAÑOL/INGLES
                                            rpt.Rpt_Proforma(intNumero, intAnio)

                                        End If
                                        cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)
                                    End If
                                    MostrarLista(True)
                                ElseIf MsgBox("You do not have permission Reload this Proforma") Then
                                Else
                                    MsgBox("It was not possible to classify the operation to save", vbExclamation, "Notice")
                                End If

                            Else
                                    Me.Tag = "Mod"
                                    If checkActivo.Checked = False Then
                                        If VerificarSiTieneDespacho() = 0 Then
                                            MsgBox(" Proforma Invoice has deliveries already, therefore, we cannot cancel it ")
                                            Exit Sub
                                        End If
                                    End If
                                    ComprobarDatos()
                                ComprobarPagoImpuestos()
                                GuardarDocumento()
                                GuardarDetalle()
                                BorrarLineDetalle(celdaNumero.Text, 75)
                                If celdaidProyecto.Text <> NO_FILA Then
                                    GenerarComentarioDocumentos(strTexto)
                                End If
                                GuardarSubdocumento()
                                GuardarKardex()
                                If checkCarta.Checked = True Then
                                    If MsgBox("Are you sure to save the contract data?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then

                                        GuardarContrato()
                                        GuardarDetalleContrato()
                                        BorrarLineDetalle(celdaContrato.Text, 389)
                                        BorrarLineDetalleDescargo(celdaContrato.Text, 389)
                                        GuardarDatosProcesadosContrato()
                                    Else
                                    End If
                                End If

                                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acUpdate, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text, strTexto)
                                If MsgBox("The document has been save." & vbCr &
                              vbCr & " Print?", vbQuestion + vbYesNo + vbDefaultButton2, "To Print") = vbYes Then
                                    logReporte = True
                                    Dim intAnio As Integer
                                    Dim intNumero As Integer
                                    Dim rpt As New clsReportes
                                    Dim respuesta As String
                                    Dim respuesta1 As String


                                    intNumero = celdaNumero.Text
                                    intAnio = celdaAño.Text
                                    respuesta = MsgBox("¿To print format in English?", vbYesNo)

                                    If respuesta = vbYes Then
                                        respuesta1 = MsgBox("¿To use the special format?", vbYesNo)
                                        If respuesta1 = vbYes Then

                                            ' REPORTE EN FORMATO ESPECIAL
                                            rpt.Rpt_ProformaEsp(intNumero, intAnio)
                                        ElseIf respuesta1 = vbNo Then

                                            'REPORTE EN FORMATO INGLES
                                            rpt.Rpt_ProformaIng(intNumero, intAnio)
                                        End If
                                    ElseIf respuesta = vbNo Then

                                        'REPORTE EN FORMATO ESPAÑOL/INGLES
                                        rpt.Rpt_Proforma(intNumero, intAnio)

                                    End If
                                    cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)
                                Else
                                    MostrarLista(True)
                                End If
                                'MostrarLista(True)
                            End If
                        End If
                    ElseIf MsgBox("You do not have permission Reload this Proforma") Then
                    Else
                        MsgBox("It was not possible to classify the operation to save", vbExclamation, "Notice")
                    End If

                End If
            Else
                MsgBox("You do not have permission to create a new proforma")
            End If
            Encabezado1.botonGuardar.Enabled = True
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Function PedirAutorizacionMODPed(ByVal Titulo As String, Optional Info As String = vbNullString) As Boolean
        Dim LogResult As Boolean = True
        Const STR_MARGEN As String = "AutorizarMODPed"
        Dim frm As frmAutorización
        PedirAutorizacionMODPed = False

        frm = New frmAutorización
        frm.Iniciar(52, STR_MARGEN, 0, "Autorization Please")
        frm.etiquetaInfo.Text = "Need autorization by update this Document"
        frm.ShowDialog(Me)
        If frm.Aceptado Then
            If frm.Nivel Then
                PedirAutorizacionMODPed = True
                cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acConfirm, 0, 52,
                 celdaAño.Text, celdaNumero.Text, "Autorizacion a  " & "( " & frm.Usuario & " )")
            Else
                MsgBox("It does not have the required authorization level", vbExclamation, "Notice")
            End If
        End If
        LogResult = True
    End Function
    Private Sub BotonIDCliente_Click(sender As Object, e As EventArgs) Handles BotonCliente.Click
        'Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Client"
        frm.FiltroText = "Enter the Name Client To Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "cli_codigo code,cli_cliente Client, cli_direccion Direction, cli_telefono Phone, cli_nit NIT"
        frm.Tabla = "Clientes"
        frm.Condicion = strCondicion
        frm.Limite = 20
        frm.Ordenamiento = "cli_cliente < 0"
        frm.Filtro = "cli_cliente"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDCliente.Text = frm.LLave
            celdaCliente.Text = frm.Dato
            celdaDireccion.Text = frm.Dato2
            celdaNit.Text = frm.Dato4
            celdaTelefono.Text = frm.Dato3

        End If

    End Sub

    Private Sub botonMoneda_Click(sender As Object, e As EventArgs) Handles botonMoneda.Click
        Dim frm As New frmSeleccionar
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim Cambio As Double

        Try
            frm.Titulo = "Currency"
            frm.FiltroText = " Enter The Currency To Filter"
            frm.Campos = " cat_num Code, cat_clave Currency"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase = 'monedas'"

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                celdaIDMoneda.Text = frm.LLave
                celdaMoneda.Text = frm.Dato
            End If

            strSQL = " SELECT cat_sist"
            strSQL &= "      FROM Catalogos"
            strSQL &= "          WHERE cat_clase = 'Monedas' AND cat_num = {Numero}"

            strSQL = Replace(strSQL, "{Numero}", frm.LLave)


            conec = New MySqlConnection(strConexion)
            conec.Open()
            COM = New MySqlCommand(strSQL, conec)
            Using conec
                Cambio = COM.ExecuteScalar
                COM.Dispose()
                COM = Nothing
                conec.Close()
                conec.Dispose()
                conec = Nothing
                System.GC.Collect()
            End Using
            If Cambio > 1 Then
                celdaTC.Text = cFunciones.TasaSegunFecha(dtpFecha.Value.ToString(FORMATO_MYSQL))
            Else
                celdaTC.Text = Cambio
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonDocumento_Click(sender As Object, e As EventArgs)

        Dim frm As New frmSeleccionar

        Try
            frm.Titulo = "Documents"
            frm.FiltroText = " Enter The Document To Filter"
            frm.Campos = " cat_num ID, cat_clave Codigo, IF(cat_desc!='',cat_desc,cat_clave) Descripcion"
            frm.Tabla = " Catalogos"
            frm.Filtro = " cat_clave "
            frm.Condicion = "cat_clase='Documentos'"
            frm.Ordenamiento = "Descripcion"
            frm.TipoOrdenamiento = ""
            frm.Limite = 20

            frm.ShowDialog(Me)
            If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                'celdaIDDocumento.Text = frm.LLave
                'celdaDocument.Text = frm.Dato
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub botonSolicitante_Click(sender As Object, e As EventArgs) Handles botonSolicitante.Click
        '  Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim strCondicion As String = STR_VACIO
        strCondicion = "cli_sisemp = {empresa}"
        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

        'Datospara mostrar en pantalla
        frm.Titulo = "Name Client"
        frm.FiltroText = "Enter the Name Client to Filter "

        'Datos de Base para Llenar Grid
        frm.Campos = "cli_codigo code, cli_cliente Client, cli_direccion Direction, cli_telefono Phone"
        frm.Tabla = "Clientes"
        frm.Condicion = strCondicion
        frm.Limite = 20
        frm.Ordenamiento = "cli_cliente < 0"
        frm.Filtro = "cli_cliente"

        'Mostrar formulario
        frm.ShowDialog(Me)
        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            'Captura de datos seleccionados
            celdaIDSolicitante.Text = frm.LLave
            celdaSolicitante.Text = frm.Dato
            celdaDirec.Text = frm.Dato2
            celdaPhone.Text = frm.Dato3

        End If

    End Sub

    Private Sub botonDespachos_Click(sender As Object, e As EventArgs) Handles botonDespachos.Click

        Dim strSQL As String
        Dim strSQL2 As String
        Dim COM As MySqlCommand
        Dim COM2 As MySqlCommand
        Dim conec As MySqlConnection
        Dim Revisado As Integer



        strSQL = "SELECT COUNT(*)"
        strSQL &= "      FROM Permisos p"
        strSQL &= "              WHERE p.pms_empresa = {empresa} and p.pms_codigo = 'REVISAR' and p.pms_modulo = 52 and p.pms_usuario = '{usuario}'"

        strSQL = Replace(strSQL, "{empresa}", Sesion.IdEmpresa)
        strSQL = Replace(strSQL, "{usuario}", Sesion.Usuario)

        conec = New MySqlConnection(strConexion)
        conec.Open()
        COM = New MySqlCommand(strSQL, conec)
        Revisado = COM.ExecuteScalar()
        conec.Close()


        If Revisado = 1 Then
            If MsgBox("Are you sure you want to dial Revised brand if the changes are irreversible", vbQuestion + vbYesNo + vbDefaultButton2, ) = MsgBoxResult.Yes Then
                strSQL2 = "UPDATE Dcmtos_HDR"
                strSQL2 &= "      SET HDoc_Pro_DCat = 1"
                strSQL2 &= "              WHERE HDoc_Sis_Emp = {empresa} and HDoc_Doc_Cat = 75 and HDoc_Doc_Ano = {año} and HDoc_Doc_Num = {numero}"

                strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
                strSQL2 = Replace(strSQL2, "{año}", celdaAño.Text)
                strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)

                'Ejecuta la instrucción
                MyCnn.CONECTAR = strConexion
                COM2 = New MySqlCommand(strSQL2, CON)
                COM2.ExecuteNonQuery()

                botonDespachos.BackColor = Color.YellowGreen
                celdaRevisado.Text = Revisado
            End If
        Else
            MsgBox("You do not have permission to Mark PERFORMED this Proforma")

        End If
    End Sub

    Private Sub dgDetalleDoc_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalleDoc.DoubleClick

        Dim frm As New frmSubDocumentos
        Dim strDoc As String
        Dim cls As New clsFunciones
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim REA As MySqlDataReader

        strDoc = dgDetalleDoc.SelectedCells(0).Value


        Select Case dgDetalleDoc.CurrentCell.ColumnIndex
            Case 2
                If dgDetalleDoc.SelectedCells(2).Value = "Si" Then

                    frm.SubDocumento = dgDetalleDoc.SelectedCells(0).Value
                    frm.Año = CInt(celdaAño.Text)
                    frm.Numero = CInt(celdaNumero.Text)
                    frm.Pedido = celdaNumeroReq.Text
                    frm.Catalogo = 75
                    frm.Doc = strDoc
                    frm.Contrato = celdaContrato.Text
                    frm.ContratoActivo = checkCarta.Checked
                    frm.ShowDialog(Me)

                ElseIf dgDetalleDoc.SelectedCells(2).Value = "No" Then
                    Try
                        If Me.Tag = "Nuevo" Then

                            Dim Contrato As Integer
                            If ComprobarDatos() Then
                                If ComprobarPagoImpuestos() Then
                                    If checkCarta.Checked = True And dgContratosLista.Rows.Count = 0 Then
                                        If celdaContrato.Text > 0 Then
                                            Me.Tag = "Mod"
                                            GuardarContrato()
                                            GuardarDetalleContrato()
                                        Else
                                            If MsgBox("Are you sure you want to create a contract?", vbQuestion + vbYesNo + vbDefaultButton2) = vbYes Then
                                                Contrato = cls.NuevoId(389) ' cls.Verificacion_Nuevo_Registro(celdaContrato.Text, "Dcmtos", 389, celdaAño.Text)
                                                celdaContrato.Text = Contrato
                                                botonContrato.Enabled = True
                                                If celdaNumeroReq.Text = vbNullString Then
                                                    celdaNumeroReq.Text = "PM" & Space(1) & celdaContrato.Text
                                                End If
                                                GuardarContrato()
                                                GuardarDetalleContrato()
                                            Else
                                                Exit Sub
                                                botonContrato.Enabled = False
                                            End If
                                        End If


                                        If celdaNumero.Text > 0 Then
                                            If celdaNumeroReq.Text = vbNullString Then
                                                celdaNumeroReq.Text = PRE_PF & celdaNumero.Text
                                            End If

                                            Me.Tag = "Mod"
                                        Else
                                            celdaNumero.Text = cls.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 75, celdaAño.Text)
                                            If celdaNumeroReq.Text = vbNullString Then
                                                celdaNumeroReq.Text = PRE_PF & celdaNumero.Text
                                            End If

                                            Me.Tag = "Nuevo"
                                        End If

                                        GuardarDocumento()
                                        GuardarDetalle()
                                        GuardarSubdocumento()
                                        GuardarKardex()

                                        cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)

                                        If checkCarta.Checked = True Then
                                            If checkActivo.Checked = True Then
                                                Me.Tag = "Nuevo"
                                                GuardarDatosProcesadosContrato()
                                            Else
                                                Me.Tag = "Mod"
                                                GuardarDatosProcesadosContrato()
                                            End If
                                        End If

                                        frm.SubDocumento = dgDetalleDoc.SelectedCells(0).Value
                                        frm.Año = CInt(celdaAño.Text)
                                        frm.Numero = CInt(celdaNumero.Text)
                                        'frm.Pedido = CInt(celdaNumeroReq.Text)
                                        frm.Catalogo = 75
                                        frm.Doc = strDoc
                                        frm.Contrato = celdaContrato.Text
                                        frm.ContratoActivo = checkCarta.Checked
                                        frm.ShowDialog(Me)
                                        Me.Tag = "Mod"
                                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                            dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                                        Next


                                    ElseIf checkCarta.Checked = False Then


                                        If celdaNumero.Text > 0 Then
                                            If celdaNumeroReq.Text = vbNullString Then
                                                celdaNumeroReq.Text = PRE_PF & celdaNumero.Text
                                            End If

                                            Me.Tag = "Mod"
                                        Else
                                            celdaNumero.Text = cls.Verificacion_Nuevo_Registro(celdaNumero.Text, "Dcmtos", 75, celdaAño.Text)
                                            If celdaNumeroReq.Text = vbNullString Then
                                                celdaNumeroReq.Text = PRE_PF & celdaNumero.Text
                                            End If

                                            Me.Tag = "Nuevo"

                                            GuardarDocumento()
                                            GuardarDetalle()
                                            GuardarSubdocumento()
                                            GuardarKardex()

                                            cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acAdd, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)
                                        End If

                                        frm.SubDocumento = dgDetalleDoc.SelectedCells(0).Value
                                        frm.Año = CInt(celdaAño.Text)
                                        frm.Numero = CInt(celdaNumero.Text)
                                        frm.Pedido = celdaNumeroReq.Text
                                        frm.Catalogo = 75
                                        frm.Doc = strDoc
                                        frm.Contrato = celdaContrato.Text
                                        frm.ContratoActivo = checkCarta.Checked
                                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                            dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                                        Next
                                        If checkCarta.Checked = False Then
                                            MsgBox("You have not yet signed a Contract, nor have the data been completed. Please mark and complete data and then generate Contract Information")
                                            Exit Sub
                                        End If
                                        frm.ShowDialog(Me)

                                    ElseIf checkCarta.Checked = False And celdaContrato.Text = NO_FILA Then
                                        MsgBox("You have not yet signed a Contract, nor have the data been completed. Please mark and complete data and then generate Contract Information")
                                    ElseIf checkCarta.Checked = True Then
                                        frm.SubDocumento = dgDetalleDoc.SelectedCells(0).Value
                                        frm.Año = CInt(celdaAño.Text)
                                        frm.Numero = CInt(celdaNumero.Text)
                                        'frm.Pedido = CInt(celdaNumeroReq.Text)
                                        frm.Catalogo = 75
                                        frm.Doc = strDoc
                                        frm.Contrato = celdaContrato.Text
                                        frm.ContratoActivo = checkCarta.Checked
                                        frm.ShowDialog(Me)
                                        Me.Tag = "Mod"
                                        For i As Integer = 0 To dgDetalle.Rows.Count - 1
                                            dgDetalle.Rows(i).Cells("ColAgrega").Value = 0
                                        Next

                                    End If
                                End If
                            End If
                        ElseIf Me.Tag = "Mod" Then
                            frm.SubDocumento = dgDetalleDoc.SelectedCells(0).Value
                            frm.Año = CInt(celdaAño.Text)
                            frm.Numero = CInt(celdaNumero.Text)
                            frm.Pedido = celdaNumeroReq.Text
                            frm.Catalogo = 75
                            frm.Doc = strDoc
                            frm.Contrato = celdaContrato.Text
                            frm.ContratoActivo = checkCarta.Checked
                            frm.ShowDialog(Me)
                            Me.Tag = "Mod"
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try
                End If
                'Me.Tag = "Mod"
        End Select


    End Sub

    Private Sub dgLista_DoubleClick(sender As Object, e As EventArgs) Handles dgLista.DoubleClick
        Encabezado1.botonGuardar.Enabled = True
        Dim intNumero As Integer = NO_FILA
        Dim intAño As Integer = NO_FILA
        Dim strSQL2 As String = STR_VACIO
        Dim COM2 As MySqlCommand
        Dim conec2 As MySqlConnection
        Dim Contrato As Integer

        Try
            If dgLista.SelectedRows.Count = INT_CERO Then Exit Sub
            Me.Tag = "Mod"

            intNumero = dgLista.SelectedCells(0).Value
            intAño = dgLista.SelectedCells(5).Value
            LimpiarPanelOrden()
            ResetProyecto()
            queryEncabezado(intNumero, intAño)
            queryContratos(intNumero, intAño)
            dgDetalleDoc.Visible = False
            querySubDoc(intNumero, intAño)
            queryDetalleDown(intNumero, intAño)
            queryDetalle2(intNumero, intAño)
            CargarReferencias(intAño, intNumero)
            SqlDatosContrato()
            celdaComentario.Text = 1
            botonBuscar.Enabled = False
            BotonHoras.Visible = True
            BarraTitulo1.CambiarTitulo("Modificar Registro")
            If celdaidProyecto.Text <> NO_FILA Then
                BotonHoras.Enabled = True
            Else
                BotonHoras.Enabled = False
            End If
            strSQL2 = "SELECT COUNT(*)"
            strSQL2 &= "     FROM Dcmtos_DTL_Pro p"
            strSQL2 &= "         WHERE p.PDoc_Sis_Emp = {empresa} AND p.PDoc_Par_Cat = 389 AND p.PDoc_Chi_Cat = 75 AND p.PDoc_Chi_Num = {numero} AND p.PDoc_Chi_Ano = {año}"

            strSQL2 = Replace(strSQL2, "{empresa}", Sesion.IdEmpresa)
            strSQL2 = Replace(strSQL2, "{numero}", celdaNumero.Text)
            strSQL2 = Replace(strSQL2, "{año}", celdaAño.Text)

            conec2 = New MySqlConnection(strConexion)
            conec2.Open()
            COM2 = New MySqlCommand(strSQL2, conec2)
            Contrato = COM2.ExecuteScalar()

            If Contrato > 0 Then
                celdaContrato.Text = contratoNum
                dgDetalleDoc.Visible = True
            Else
                celdaContrato.Text = NO_FILA
                dgDetalleDoc.Visible = False
            End If
            CalcularTotales()

            If dgContratosLista.Rows.Count > vbEmpty Then
                checkCarta.Checked = True
                checkCarta.Enabled = False
                dgDetalle.Columns("colFechInicio").Visible = True
                dgDetalle.Columns("colFechFinal").Visible = True
                dgDetalle.Columns("colFabricante").Visible = True
            Else
                checkCarta.Checked = False
                checkCarta.Enabled = True
                dgDetalle.Columns("colFechInicio").Visible = False
                dgDetalle.Columns("colFechFinal").Visible = False
                dgDetalle.Columns("colFabricante").Visible = False
            End If


            For i As Integer = 0 To dgDetalle.Rows.Count - 1

                If SqlDescargos(dgDetalle.Rows(i).Cells("colLineaDet").Value) > 0 Then

                    dgDetalle.Rows(i).Cells("colPrecio").ReadOnly = True
                    dgDetalle.Rows(i).Cells("colPrecioKG").ReadOnly = True
                    dgDetalle.Rows(i).Cells("colDescripcion").ReadOnly = True


                    dgDetalle.Rows(i).Cells("colPrecio").Style.BackColor = Color.Cyan
                    dgDetalle.Rows(i).Cells("colDescripcion").Style.BackColor = Color.Cyan
                Else
                    dgDetalle.Rows(i).Cells("colPrecio").ReadOnly = False
                    dgDetalle.Rows(i).Cells("colPrecioKG").ReadOnly = False
                    dgDetalle.Rows(i).Cells("colDescripcion").ReadOnly = False
                End If
            Next

            'Verifica si ya hay descargos para bloquear o desbloquear el boton del cliente
            If SqlDescargos() > 0 Then
                'Bloquea campos pues con una linea que tenga descargo ya no se puede modificar nada
                BotonCliente.Enabled = False
                celdaCliente.Enabled = False
                celdaDireccion.Enabled = False

                botonSolicitante.Enabled = False
                celdaSolicitante.Enabled = False
                celdaDirec.Enabled = False
            Else
                'Habilita campos si las lineas no tienen ningun descargo esto a solicitud de Nancy Gonzalez
                BotonCliente.Enabled = True
                celdaCliente.Enabled = True
                celdaDireccion.Enabled = True

                botonSolicitante.Enabled = True
                celdaSolicitante.Enabled = True
                celdaDirec.Enabled = True
            End If

            For i As Integer = 0 To dgDetalle.Rows.Count - 1
                If dgDetalle.Rows(i).Cells("colNumMedida").Value = 70 Then
                    dgDetalle.Rows(i).Cells("colMedida").Style.BackColor = Color.Red
                Else
                    dgDetalle.Rows(i).Cells("colMedida").Style.BackColor = Color.White
                End If

            Next

            For i As Integer = 0 To dgReferencias.Rows.Count - 1
                For j = 0 To dgDetalle.Rows.Count - 1
                    If dgReferencias.Rows(i).Cells("colDescargo").Value > 0 And
                        dgDetalle.Rows(j).Cells("colYear").Value = dgReferencias.Rows(i).Cells("colAnio").Value And
                        dgDetalle.Rows(j).Cells("colLineaDet").Value = dgReferencias.Rows(i).Cells("colLine").Value Then

                        dgDetalle.Rows(j).Cells("colDescargos").Value = 1
                    End If
                Next
            Next
            MostrarLista(False)

            'If celdaNumero.Text = "" Then
            '    BotonCliente.Enabled = True
            '    botonSolicitante.Enabled = True
            'Else
            '    BotonCliente.Enabled = False
            '    botonSolicitante.Enabled = False
            'End If

            If dgContratosLista.Rows.Count = 0 And celdaContrato.Text = 0 And checkCarta.Checked = False Then
                botonContrato.Enabled = False
            Else
                botonContrato.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonAgregar_Click(sender As Object, e As EventArgs) Handles botonAgregar.Click

        Try
            Dim Opt As New frmOption
            Opt.Titulo = "Contracts"
            Opt.Mensaje = "Select an Option"
            Opt.Opciones = celdaCliente.Text & "|" & celdaSolicitante.Text & "|" & "Other"

            If Opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                Select Case Opt.Seleccion

                    Case 0

                        Dim frmC As New frmSeleccionar
                        Dim strCampos As String = STR_VACIO
                        Dim strFila As String = STR_VACIO

                        frmC.Titulo = "Documents Available"
                        frmC.FiltroText = "Enter the Name Document"
                        strCampos = "DISTINCT HDoc_Doc_Ano Year, HDoc_Doc_Num Number, HDoc_Doc_Fec Date, COALESCE(HDoc_DR1_Num,'') Reference, HDoc_Usuario User FROM Dcmtos_HDR a LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 389) AND (HDoc_Emp_Cod = {numero}) AND HDoc_Doc_Status = 1 AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
                        strCampos = Replace(strCampos, "{empresa}", Sesion.IdEmpresa)
                        strCampos = Replace(strCampos, "{numero}", celdaIDCliente.Text)
                        frmC.Campos = strCampos
                        frmC.Tabla = "Dcmtos_DTL_Pro c"
                        frmC.Condicion = "c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = 75), 0) < b.DDoc_Prd_QTY)"
                        frmC.Ordenamiento = "HDoc_Doc_Ano DESC, HDoc_Doc_Num "
                        frmC.Filtro = "HDoc_Doc_Number"
                        frmC.ShowDialog(Me)

                        Try
                            If frmC.DialogResult = System.Windows.Forms.DialogResult.OK Then

                                Dim Result As Boolean

                                For i = 0 To dgContratosLista.Rows.Count - 1
                                    If dgContratosLista.Rows(i).Cells("colNumeroContrato").Value = frmC.Dato Then
                                        Result = True
                                        MessageBox.Show("This document has already been added", "Notice", MessageBoxButtons.OK)
                                        Exit For
                                    Else
                                        Result = False
                                    End If
                                Next
                                If Result = False Then

                                    strFila = frmC.LLave & "|"
                                    strFila &= frmC.Dato & "|"
                                    strFila &= frmC.Dato2 & "|"
                                    strFila &= frmC.Dato3 & "|"
                                    strFila &= frmC.Dato4

                                    cFunciones.AgregarFila(dgContratosLista, strFila)

                                End If

                            End If
                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try

                    Case 1

                        Dim frmS As New frmSeleccionar
                        Dim strCampos As String = STR_VACIO
                        Dim strFila As String = STR_VACIO

                        frmS.Titulo = "Documents Available"
                        frmS.FiltroText = "Enter the Name Document"
                        strCampos = "DISTINCT HDoc_Doc_Ano Year, HDoc_Doc_Num Number, HDoc_Doc_Fec Date, COALESCE(HDoc_DR1_Num,'') Reference, HDoc_Usuario User FROM Dcmtos_HDR a LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 389) AND (HDoc_Emp_Cod = {numero}) AND HDoc_Doc_Status = 1 AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
                        strCampos = Replace(strCampos, "{empresa}", Sesion.IdEmpresa)
                        strCampos = Replace(strCampos, "{numero}", celdaIDSolicitante.Text)
                        frmS.Campos = strCampos
                        frmS.Tabla = "Dcmtos_DTL_Pro c"
                        frmS.Condicion = "c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = 75), 0) < b.DDoc_Prd_QTY)"
                        frmS.Ordenamiento = "HDoc_Doc_Ano DESC, HDoc_Doc_Num "

                        frmS.ShowDialog(Me)

                        Try

                            If frmS.DialogResult = System.Windows.Forms.DialogResult.OK Then

                                Dim Result As Boolean

                                For i = 0 To dgContratosLista.Rows.Count - 1
                                    If dgContratosLista.Rows(i).Cells("colNumeroContrato").Value = frmS.Dato Then
                                        Result = True
                                        MessageBox.Show("This document has already been added", "Notice", MessageBoxButtons.OK)
                                        Exit For
                                    Else
                                        Result = False

                                    End If
                                Next
                                If Result = False Then

                                    strFila = frmS.LLave & "|"
                                    strFila &= frmS.Dato & "|"
                                    strFila &= frmS.Dato2 & "|"
                                    strFila &= frmS.Dato4 & "|"
                                    strFila &= frmS.Dato3

                                    cFunciones.AgregarFila(dgContratosLista, strFila)

                                End If
                            End If
                        Catch ex As Exception
                            MsgBox(ex.ToString)
                        End Try

                    Case 2
                        Dim frm As New frmSeleccionar
                        Dim strCondicion As String = STR_VACIO

                        strCondicion = "cli_sisemp = {empresa}"

                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)

                        'Datospara mostrar en pantalla
                        frm.Titulo = "Name Client"
                        frm.FiltroText = "Enter the Name Client To Filter "

                        'Datos de Base para Llenar Grid
                        frm.Campos = "cli_codigo Code, cli_cliente Client"
                        frm.Tabla = "Clientes"
                        frm.Condicion = strCondicion
                        frm.Limite =
                        frm.Ordenamiento = "cli_cliente < 0"
                        frm.Filtro = "cli_cliente"

                        'Mostrar formulario
                        frm.ShowDialog(Me)

                        If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            celdaCode.Text = frm.LLave
                            Dim frmDoc As New frmSeleccionar
                            Dim strFila As String = STR_VACIO
                            Dim strCampos As String = STR_VACIO
                            Dim i As Integer
                            Dim Result As Boolean

                            frmDoc.Titulo = "Documents Available"
                            frm.FiltroText = "Enter the Name Document"
                            strCampos = "DISTINCT HDoc_Doc_Ano Year, HDoc_Doc_Num Number, HDoc_Doc_Fec Date, HDoc_Usuario User, COALESCE(HDoc_DR1_Num,'') Reference FROM Dcmtos_HDR a LEFT JOIN Dcmtos_DTL b ON a.HDoc_Sis_Emp = b.DDoc_Sis_Emp AND a.HDoc_Doc_Cat = b.DDoc_Doc_Cat AND a.HDoc_Doc_Ano = b.DDoc_Doc_Ano AND a.HDoc_Doc_Num = b.DDoc_Doc_Num WHERE HDoc_Sis_Emp = {empresa} AND (HDoc_Doc_Cat = 389) AND (HDoc_Emp_Cod = {numero}) AND HDoc_Doc_Status = 1 AND (COALESCE((SELECT SUM(c.PDoc_QTY_Pro)"
                            strCampos = Replace(strCampos, "{empresa}", Sesion.IdEmpresa)
                            strCampos = Replace(strCampos, "{numero}", celdaCode.Text)
                            frmDoc.Campos = strCampos
                            frmDoc.Tabla = "Dcmtos_DTL_Pro c"
                            frmDoc.Condicion = "c.PDoc_Sis_Emp = b.DDoc_Sis_Emp AND c.PDoc_Par_Cat = b.DDoc_Doc_Cat AND c.PDoc_Par_Ano = b.DDoc_Doc_Ano AND c.PDoc_Par_Num = b.DDoc_Doc_Num AND c.PDoc_Par_Lin = b.DDoc_Doc_Lin AND c.PDoc_Chi_Cat = 75), 0) < b.DDoc_Prd_QTY)"
                            frmDoc.Ordenamiento = "HDoc_Doc_Ano DESC, HDoc_Doc_Num "


                            frmDoc.ShowDialog(Me)
                            Try

                                If frmDoc.DialogResult = System.Windows.Forms.DialogResult.OK Then

                                    For i = 0 To dgContratosLista.Rows.Count - 1
                                        If dgContratosLista.Rows(i).Cells("colNumeroContrato").Value = frmDoc.Dato Then
                                            Result = True
                                            MessageBox.Show("This document has already been added", "Notice", MessageBoxButtons.OK)
                                            Exit For
                                        Else
                                            Result = False
                                        End If
                                    Next

                                    If Result = False Then

                                        strFila = frmDoc.LLave & "|"
                                        strFila &= frmDoc.Dato & "|"
                                        strFila &= frmDoc.Dato2 & "|"
                                        strFila &= frmDoc.Dato3 & "|"
                                        strFila &= frmDoc.Dato4

                                        cFunciones.AgregarFila(dgContratosLista, strFila)

                                    End If

                                End If
                            Catch ex As Exception
                                MsgBox(ex.ToString)
                            End Try
                        End If
                End Select
            End If
        Catch ex As Exception
            MessageBox.Show(ToString)
        End Try
    End Sub

    Private Sub botonActualizar_Click(sender As Object, e As EventArgs) Handles botonActualizar.Click
        Dim logCancelar As Boolean

        If CDate(dtpInicio.Value) > CDate(dtpFinal.Value) Then
            MsgBox("The start date may not exceed the final date", vbExclamation, "Notice")
            logCancelar = True
        End If
        If Not (logCancelar) Then

            queryListaPrincipal()

        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles botonEliminar.Click
        Me.dgContratosLista.Rows.Remove(dgContratosLista.CurrentRow)
    End Sub

    Private Sub botonRecargar_Click(sender As Object, e As EventArgs) Handles botonRecargar.Click
        Dim i As Integer
        Dim intID As Integer

        i = dgDetalle.Rows.Count

        If dgContratos.Enabled And (i > NO_FILA) Then
            'Si el doc. es un contrato
            intID = Val(dgDetalle.CurrentRow.Cells("colLineaDet").Value)

            If Not (intID > vbEmpty) Then
                MsgBox("First, you select the document related", vbExclamation, "Notice")
            Else
                MostrarReferencias()
            End If
        End If
    End Sub

    'Private Sub dgDetalle_CellBeginEdit(sender As Object, e As DataGridViewCellCancelEventArgs) Handles dgDetalle.CellBeginEdit
    '    Try

    '        If ((dgDetalle.Focused) & (dgDetalle.CurrentCell.ColumnIndex = 19)) Then
    '            dtpDetalle.Location = dgDetalle.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, False).Location
    '            dtpDetalle.Visible = True
    '            If (dgDetalle.CurrentCell.Value <> DBNull.Value) Then
    '                dtpDetalle.Value = dgDetalle.CurrentCell.Value
    '            Else
    '                dtpDetalle.Value = DateTime.Today
    '            End If
    '        Else
    '            dtpDetalle.Visible = False
    '        End If
    '    Catch ex As Exception
    '        MessageBox.Show(ex.ToString)
    '    End Try
    'End Sub

    Private Sub dgDetalle_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgDetalle.CellEndEdit
        Dim Cantidad As Double
        Dim Precio As Double
        Dim Total As Double

        Select Case dgDetalle.CurrentCell.ColumnIndex
            Case 6
                Precio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value

                Total = (dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colCantidad").Value)

                dgDetalle.CurrentRow.Cells("colPrecioKG").Value = Math.Round(Precio * 2.2046, 2)
                dgDetalle.CurrentRow.Cells("colTotal").Value = Total
                celdaTotales2.Text = Total.ToString(FORMATO_MONEDA)
                celdaTotales.Text = Cantidad.ToString(FORMATO_MONEDA)
            Case 11
                Precio = dgDetalle.CurrentRow.Cells("colPrecio").Value
                Cantidad = dgDetalle.CurrentRow.Cells("colCantidad").Value

                Total = (dgDetalle.CurrentRow.Cells("colPrecio").Value * dgDetalle.CurrentRow.Cells("colCantidad").Value)

                dgDetalle.CurrentRow.Cells("colTotal").Value = Total
                celdaTotales2.Text = Total.ToString(FORMATO_MONEDA)
                celdaTotales.Text = Cantidad.ToString(FORMATO_MONEDA)

                'Try
                '    If ((dgDetalle.Focused & (dgDetalle.CurrentCell.ColumnIndex = 19))) Then
                '        dgDetalle.CurrentCell.Value = dtpDetalle.Value.Date
                '    End If
                'Catch ex As Exception
                '    MsgBox(ex.ToString)
                'End Try

        End Select
    End Sub

    Private Sub dgDetalle_DoubleClick(sender As Object, e As EventArgs) Handles dgDetalle.DoubleClick

        Try
            Dim Frm As New frmSeleccionar
            Dim strCondicion As String = STR_VACIO
            Dim strFila As String = STR_VACIO
            Dim COM As MySqlCommand
            Dim conec As MySqlConnection
            Dim strSQL As String = STR_VACIO
            Dim Codigo As Integer

            'strVal = dgDetalle.SelectedCells(0).Value
            Select Case dgDetalle.CurrentCell.ColumnIndex
                Case 2
                    If dgDetalle.SelectedCells(0).Value > 0 Then

                        strCondicion = "inv_generico = 1 AND inv_sisemp = {empresa} AND inv_status = 'Activo' /* AND art_DCorta LIKE '%20/1 100% COTTON CD RS%' */ "
                        strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)


                        Frm.Titulo = "List of Product"
                        Frm.FiltroText = "Enter the name Product"
                        Frm.Campos = " inv_numero Inventory,  art_DCorta Description, m.cat_num NumMedida, m.cat_clave Measure, p.cat_clave Origin"
                        Frm.Tabla = "Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab"
                        Frm.Condicion = strCondicion
                        Frm.Ordenamiento = "inv_numero"
                        Frm.Filtro = " art_DCorta"

                        Frm.ShowDialog(Me)

                        Try



                            If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                strSQL = "SELECT inv_artcodigo"
                                strSQL &= " FROM Inventarios"
                                strSQL &= "      WHERE inv_numero = {codArt}"

                                strSQL = Replace(strSQL, "{codArt}", Frm.LLave)


                                conec = New MySqlConnection(strConexion)
                                conec.Open()
                                COM = New MySqlCommand(strSQL, conec)
                                Codigo = COM.ExecuteScalar()
                                conec.Close()
                                If "Inventory" <> dgDetalle.SelectedCells(0).Value Then
                                    dgDetalle.SelectedCells(2).Value = Frm.LLave
                                    dgDetalle.SelectedCells(3).Value = Frm.Dato
                                    dgDetalle.SelectedCells(4).Value = Frm.Dato2
                                    dgDetalle.SelectedCells(5).Value = Frm.Dato3
                                    dgDetalle.SelectedCells(6).Value = 0.0
                                    dgDetalle.SelectedCells(25).Value = Codigo
                                End If
                            End If

                        Catch ex As Exception
                            MessageBox.Show(ex.ToString)
                        End Try
                    End If

                Case 8
                    Try

                        If dgDetalle.SelectedCells(0).Value > 0 Then
                            Dim Condicion As String = STR_VACIO
                            Condicion = "cli_sisemp = {empresa}"
                            Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)

                            'Datospara mostrar en pantalla
                            Frm.Titulo = "Name Client"
                            Frm.FiltroText = "Enter the Name Client To Filter "

                            'Datos de Base para Llenar Grid
                            Frm.Campos = "cli_codigo code,cli_cliente Client, if(cli_tipo=0, 'Invoice', if(cli_tipo=1, 'Destination','AR') ) Type "
                            Frm.Tabla = "Clientes"
                            Frm.Condicion = Condicion
                            Frm.Limite =
                            Frm.Ordenamiento = "cli_status = 'Activo' "
                            Frm.Filtro = "cli_cliente"

                            'Mostrar formulario
                            Frm.ShowDialog(Me)

                            If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                'Captura de datos seleccionados
                                dgDetalle.SelectedCells(8).Value = Frm.Dato
                                dgDetalle.SelectedCells(9).Value = Frm.LLave


                            End If
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.ToString)
                    End Try

                Case 14

                    Try
                        If dgDetalle.SelectedCells(0).Value > 0 Then
                            Dim Opt As New frmOption
                            Dim cancel As String
                            Opt.Titulo = "State"
                            Opt.Mensaje = "Select an Option"
                            Opt.Opciones = "Activo" & "|" & "Canceled (Dispatched)"
                            'Opt.ShowDialog(Me)


                            If Opt.ShowDialog = System.Windows.Forms.DialogResult.OK Then
                                Select Case Opt.Seleccion

                                    Case 0
                                        If Opt.Seleccion = 0 Then
                                            cancel = ""
                                            dgDetalle.SelectedCells(14).Value = cancel
                                        End If

                                    Case 1
                                        If Opt.Seleccion = 1 Then
                                            cancel = "Si"
                                            dgDetalle.SelectedCells(14).Value = cancel
                                        End If
                                End Select
                            End If
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.ToString)
                    End Try
                Case 15

                    Try

                        If dgDetalle.SelectedCells(0).Value > 0 Then


                            Frm.Titulo = "Name Program"
                            Frm.FiltroText = "Enter the name Program to filter"

                            Frm.Campos = "cat_clave Program"
                            Frm.Tabla = "Catalogos"
                            Frm.Condicion = "cat_clase = 'Programa' "
                            Frm.Ordenamiento = "cat_num"
                            Frm.Filtro = "cat_clave"
                            Frm.TipoOrdenamiento = "Asc"


                            Frm.ShowDialog(Me)

                            If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                dgDetalle.SelectedCells(15).Value = Frm.LLave
                            End If
                        End If

                    Catch ex As Exception
                        MessageBox.Show(ex.ToString)
                    End Try

                Case 16

                    Try
                        If dgDetalle.SelectedCells(0).Value > 0 Then
                            Frm.Titulo = "Name Program"
                            Frm.FiltroText = "Enter the name Division to filter"

                            Frm.Campos = "cat_clave Division"
                            Frm.Tabla = "Catalogos"
                            Frm.Condicion = "cat_clase = 'Division' "
                            Frm.Ordenamiento = "cat_num"
                            Frm.Filtro = "cat_clave"
                            Frm.TipoOrdenamiento = "Asc"

                            Frm.ShowDialog(Me)

                            If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                dgDetalle.SelectedCells(16).Value = Frm.LLave
                            End If
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.ToString)
                    End Try

                Case 20
                    Try
                        Dim Calendar As New frmDateTimePicker

                        Calendar.ShowDialog(Me)

                        If Calendar.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.SelectedCells(20).Value = Calendar.LLave
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try

                Case 21
                    Try
                        Dim Calendar As New frmDateTimePicker

                        Calendar.ShowDialog(Me)

                        If Calendar.DialogResult = System.Windows.Forms.DialogResult.OK Then
                            dgDetalle.SelectedCells(21).Value = Calendar.LLave
                        End If
                    Catch ex As Exception
                        MsgBox(ex.ToString)
                    End Try

                Case 22
                    Try

                        If dgDetalle.SelectedCells(0).Value > 0 Then
                            Dim Condicion As String = STR_VACIO
                            Condicion = "pro_sisemp = {empresa} AND pro_fabricante='Si' AND pro_proveedor LIKE '%'"
                            Condicion = Replace(Condicion, "{empresa}", Sesion.IdEmpresa)

                            'Datospara mostrar en pantalla
                            Frm.Titulo = "Name Client"
                            Frm.FiltroText = "Enter the Name Client To Filter "

                            'Datos de Base para Llenar Grid
                            Frm.Campos = "pro_codigo Codigo, pro_proveedor Fabricante, pro_status Estado"
                            Frm.Tabla = "Proveedores"
                            Frm.Condicion = Condicion
                            Frm.Limite =
                            Frm.Ordenamiento = "pro_codigo DESC "
                            Frm.Filtro = "pro_proveedor"

                            'Mostrar formulario
                            Frm.ShowDialog(Me)

                            If Frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
                                'Captura de datos seleccionados
                                dgDetalle.SelectedCells(22).Value = Frm.Dato
                                dgDetalle.SelectedCells(23).Value = Frm.LLave

                            End If
                        End If

                    Catch ex As Exception

                    End Try
            End Select
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Sub botonAdd_Click(sender As Object, e As EventArgs) Handles botonAdd.Click
        ' Me.Tag = "Nuevo"
        Dim frm As New frmSeleccionar
        Dim COM As MySqlCommand
        Dim conec As MySqlConnection
        Dim strCondicion As String = STR_VACIO
        Dim fila As String = STR_VACIO
        Dim strSQL As String = STR_VACIO
        Dim Codigo As Integer
        Dim strFila As String
        Dim frmPF As New FrmFiltroPF


        'strCondicion = "inv_generico = 1 AND inv_sisemp = {empresa} AND inv_status = 'Activo' /* AND art_DCorta LIKE '%20/1 100% COTTON CD RS%' */ "
        'strCondicion = Replace(strCondicion, "{empresa}", Sesion.IdEmpresa)


        'frm.Titulo = "List of Product"
        'frm.FiltroText = "Enter the name Product"
        'frm.Campos = " inv_numero Inventory,  art_DCorta Description, m.cat_num NumMedida,  m.cat_clave Measure, p.cat_desc Origen"
        'frm.Tabla = "Inventarios INNER JOIN Articulos ON art_sisemp = inv_sisemp AND art_codigo = inv_artcodigo LEFT JOIN Catalogos m ON m.cat_clase = 'Medidas' AND m.cat_num = inv_UMventa LEFT JOIN Catalogos p ON p.cat_clase = 'Paises' AND p.cat_num = inv_lugarfab"
        'frm.Condicion = strCondicion
        'frm.Ordenamiento = "inv_numero"
        'frm.Filtro = " art_DCorta"

        'frm.ShowDialog(Me)

        Try

            '    If frm.DialogResult = System.Windows.Forms.DialogResult.OK Then
            '        strSQL = "SELECT inv_artcodigo"
            '        strSQL &= " FROM Inventarios"
            '        strSQL &= "      WHERE inv_numero = {codArt}"

            '        strSQL = Replace(strSQL, "{codArt}", frm.LLave)


            '        conec = New MySqlConnection(strConexion)
            '        conec.Open()
            '        COM = New MySqlCommand(strSQL, conec)
            '        Codigo = COM.ExecuteScalar()
            '        conec.Close()

            '        strFila = 75 & "|" & cfun.AñoMySQL & "|" & frm.LLave & "|" & frm.Dato & "|" & frm.Dato2 & "|" & frm.Dato3 & "|" & 0.0 & "|" & NO_FILA & "|" & NO_FILA & "|" & cFunciones.HoyMySQL & "|" & NO_FILA & "|" & NO_FILA & "|" & 0 & "|" & "" & "|" & NO_FILA & "|" & NO_FILA & "|" & "" & "|" & "" & "|" & 0 & "|" & NO_FILA & "|" & NO_FILA & "|" & NO_FILA & "|" & NO_FILA & "|" & 1 & "|" & Codigo & "|" & " "

            '        cFunciones.AgregarFila(dgDetalle, strFila)

            '    End If

            frmPF.ShowDialog(Me)
            If frmPF.DialogResult = System.Windows.Forms.DialogResult.OK Then

                strSQL = "SELECT inv_artcodigo"
                strSQL &= " FROM Inventarios"
                strSQL &= "      WHERE inv_numero = {codArt}"

                strSQL = Replace(strSQL, "{codArt}", frmPF.Inventario)


                conec = New MySqlConnection(strConexion)
                conec.Open()
                COM = New MySqlCommand(strSQL, conec)
                Codigo = COM.ExecuteScalar()
                conec.Close()

                strFila = 75 & "|" & celdaAño.Text & "|" & frmPF.Inventario & "|" & frmPF.Descripcion & "|" & frmPF.idMedida & "|" & frmPF.Medida & "|" & 0.0 & "|" & 0.0 & "|" & NO_FILA & "|" & NO_FILA & "|" & cFunciones.HoyMySQL & "|" & NO_FILA & "|" & NO_FILA & "|" & 0 & "|" & "" & "|" & NO_FILA & "|" & NO_FILA & "|" & "" & "|" & "" & "|" & 0 & "|" & NO_FILA & "|" & NO_FILA & "|" & NO_FILA & "|" & NO_FILA & "|" & 1 & "|" & Codigo & "|" & " "

                cFunciones.AgregarFila(dgDetalle, strFila)

            End If

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub

    Private Sub botonDelete_Click(sender As Object, e As EventArgs) Handles botonDelete.Click
        If dgDetalle.SelectedRows.Count = 0 Then Exit Sub
        Try
            'Dim strFila As String
            If dgDetalle.CurrentRow.Cells(24).Value = 0 Then
                dgDetalle.SelectedCells(24).Value = 2
                dgDetalle.CurrentRow.Visible = False
            Else
                dgDetalle.SelectedCells(24).Value = 2
                dgDetalle.CurrentRow.Visible = False
            End If

        Catch ex As Exception
            '    MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub checkCarta_CheckedChanged(sender As Object, e As EventArgs) Handles checkCarta.CheckedChanged

        If checkCarta.Checked = True Then
            dgDetalle.Columns("colFechInicio").Visible = True
            dgDetalle.Columns("colFechFinal").Visible = True
            dgDetalle.Columns("colFabricante").Visible = True
        Else
            dgDetalle.Columns("colFechInicio").Visible = False
            dgDetalle.Columns("colFechFinal").Visible = False
            dgDetalle.Columns("colFabricante").Visible = False

        End If


        'Muestra subdocumentos
        If checkCarta.Checked Then
            dgDetalleDoc.Visible = True
        ElseIf checkCarta.Checked = False Then
            dgDetalleDoc.Visible = False
        End If
    End Sub

    Private Sub botonImprimir_Click(sender As Object, e As EventArgs) Handles botonImprimir.Click
        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        Else
        End If
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim rpt As New clsReportes
        Dim respuesta As String
        Dim respuesta1 As String


        intNumero = celdaNumero.Text
        intAnio = celdaAño.Text
        respuesta = MsgBox("¿To print format in English?", vbYesNo)

        If respuesta = vbYes Then
            respuesta1 = MsgBox("¿To use the special format?", vbYesNo)
            If respuesta1 = vbYes Then

                ' REPORTE EN FORMATO ESPECIAL
                rpt.Rpt_ProformaEsp(intNumero, intAnio)
            ElseIf respuesta1 = vbNo Then

                'REPORTE EN FORMATO INGLES
                rpt.Rpt_ProformaIng(intNumero, intAnio)
            End If
        ElseIf respuesta = vbNo Then

            'REPORTE EN FORMATO ESPAÑOL/INGLES
            rpt.Rpt_Proforma(intNumero, intAnio)

        End If
        cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)

    End Sub

    Private Sub ckeckPagaImp_CheckedChanged(sender As Object, e As EventArgs) Handles ckeckPagaImp.CheckedChanged

        If ckeckPagaImp.Checked Then
            ckeckPagaImp.ForeColor = Color.Red
            celdaImpuestos.Text = 1
        Else
            ckeckPagaImp.ForeColor = Color.Black
            celdaImpuestos.Text = 0
        End If
    End Sub

    Private Sub dgLista_KeyDown(sender As Object, e As KeyEventArgs) Handles dgLista.KeyDown
        Try
            If e.KeyCode = Keys.F3 Then
                cfun.BuscarenLista(dgLista)
                e.Handled = True
                e.SuppressKeyPress = True
            ElseIf e.KeyCode = Keys.F6 Then
                cfun.MostrarDependencias(75, dgLista.SelectedCells(5).Value, dgLista.SelectedCells(0).Value)
            ElseIf e.KeyCode = Keys.F7 Then
                Dim rpt As New clsReportes
                rpt.Historial(dgLista.SelectedCells(0).Value, dgLista.SelectedCells(5).Value, 75)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub botonContrato_Click(sender As Object, e As EventArgs) Handles botonContrato.Click

        If checkCarta.Checked = True Then
            Dim num As Integer = celdaNumero.Text
            Dim anio As Integer = celdaAño.Text
            Dim pedido As String = celdaNumeroReq.Text
            Dim rpt As New clsReportes

            rpt.Rpt_ProformaContrato(num, anio, pedido)

            cfun.EscribirRegistro(TBL_DOCUMENTOS, clsFunciones.AccEnum.acPrint, celdaIDCliente.Text, 75, celdaAño.Text, celdaNumero.Text)
        Else
        End If
    End Sub

    Private Sub botonBuscar_Click(sender As Object, e As EventArgs) Handles botonBuscar.Click

        Try
            cfun.BuscarenLista(dgLista)
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub
#End Region

    Private Sub Encabezado1_Load(sender As Object, e As EventArgs) Handles Encabezado1.Load

    End Sub

    Private Sub BotonHoras_Click(sender As Object, e As EventArgs) Handles BotonHoras.Click
        Dim hr As New frmHoras
        If Me.Tag = "Nuevo" Then

        Else

            hr.Tarea = celdaidTarea.Text
            hr.Proyecto = celdaidProyecto.Text ' Id Proyecto
            hr.Flujo = celdaidflujodetalle.Text
            hr.LlenarCampos()
            hr.ShowDialog(Me)
            If hr.DialogResult = System.Windows.Forms.DialogResult.OK Then

            End If
        End If

    End Sub

#Region "Borrar"
    Private Sub Encabezado1_ClickBorrar(sender As Object, click As Boolean) Handles Encabezado1.ClickBorrar
        Try
            If LogBorrar = True Then

                If VerificarDependenciaInstruccion() > 0 Then
                    If VerificarDependenciaProyecto() > 0 Then
                        MsgBox("The document is anchored to dispatch instruction and projects", vbInformation, "Noice")
                        Exit Sub
                    Else
                        MsgBox("The document is anchored to dispatch instruction", vbInformation, "Notice")
                        Exit Sub
                    End If
                ElseIf VerificarDependenciaProyecto() > 0 Then
                    MsgBox("The document is anchored to projects", vbInformation, "Notice")
                    Exit Sub
                Else
                    If MsgBox("Are you sure you want to remove this document?", vbYesNo, "Question") = vbYes Then
                        EliminarEncabezado()
                        EliminarDetalle()
                        EliminarSubDocumentos()
                        EliminarAnclajeAContrato()
                        EliminarContrato()
                        MsgBox("Document successfully deleted", vbInformation)
                        MostrarLista(True)
                    Else
                        Exit Sub
                    End If
                End If
            Else
                MsgBox("You do not have permissions to perform this action", vbInformation)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub EliminarEncabezado()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_HDR 
                            WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = 75 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarDetalle()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_DTL 
                            WHERE DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = 75 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarSubDocumentos()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_ACC
                            WHERE ADoc_Sis_Emp = {emp} AND ADoc_Doc_Cat = 75 AND ADoc_Doc_Ano = {anio} AND ADoc_Doc_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
    Private Sub EliminarAnclajeAContrato()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_DTL_Pro 
                            WHERE PDoc_Sis_Emp = {emp} AND PDoc_Chi_Cat = 75 AND PDoc_Chi_Ano = {anio} AND PDoc_Chi_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarContrato()
        EliminarEncabezadoContrato()
        EliminarDetalleContrato()
    End Sub

    Private Sub EliminarEncabezadoContrato()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_HDR 
                            WHERE HDoc_Sis_Emp = {emp} AND HDoc_Doc_Cat = 389 AND HDoc_Doc_Ano = {anio} AND HDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaContrato.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub EliminarDetalleContrato()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Try
            strSQL = " DELETE
                            FROM Dcmtos_DTL 
                            WHERE DDoc_Sis_Emp = {emp} AND DDoc_Doc_Cat = 389 AND DDoc_Doc_Ano = {anio} AND DDoc_Doc_Num = {num}"

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaContrato.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            COM.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub


    Private Function VerificarDependenciaInstruccion() As Integer
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim TieneInstruccion As Integer
        Try

            strSQL = " SELECT COUNT(p.PDoc_Chi_Num)
                            FROM Dcmtos_HDR h
                            LEFT JOIN Dcmtos_DTL_Pro p ON p.PDoc_Sis_Emp = h.HDoc_Sis_Emp AND p.PDoc_Par_Cat = h.HDoc_Doc_Cat AND p.PDoc_Par_Ano = h.HDoc_Doc_Ano AND p.PDoc_Par_Num = h.HDoc_Doc_Num 
                                WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 75 AND h.HDoc_Doc_Ano= {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            TieneInstruccion = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return TieneInstruccion
    End Function

    Private Function VerificarDependenciaProyecto()
        Dim strSQL As String = STR_VACIO
        Dim COM As MySqlCommand
        Dim TieneProyecto As Integer
        Try

            strSQL = " SELECT COUNT(t.numero)
                            FROM Dcmtos_HDR h
                            LEFT JOIN Tareas t ON t.Empresa = h.HDoc_Sis_Emp AND t.catalogo = h.HDoc_Doc_Cat AND t.ano = h.HDoc_Doc_Ano AND t.numero = h.HDoc_Doc_Num  
                                WHERE h.HDoc_Sis_Emp = {emp} AND h.HDoc_Doc_Cat = 75 AND h.HDoc_Doc_Ano= {anio} AND h.HDoc_Doc_Num = {num} "

            strSQL = strSQL.Replace("{emp}", Sesion.IdEmpresa)
            strSQL = strSQL.Replace("{anio}", celdaAño.Text)
            strSQL = strSQL.Replace("{num}", celdaNumero.Text)

            MyCnn.CONECTAR = strConexion
            COM = New MySqlCommand(strSQL, CON)
            TieneProyecto = COM.ExecuteScalar
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return TieneProyecto
    End Function

    Private Sub celdaNumeroReq_Validated(sender As Object, e As EventArgs) Handles celdaNumeroReq.Validated
        celdaNumeroReq.Text = cfun.ValidarCaracteresEspeciales(celdaNumeroReq.Text)
    End Sub

    Private Sub dtpFecha1_ValueChanged(sender As Object, e As EventArgs) Handles dtpFecha1.ValueChanged
        If celdaTC.Text > 1 Then
            celdaTC.Text = cFunciones.TasaSegunFecha(dtpFecha1.Value.ToString(FORMATO_MYSQL))
        End If
    End Sub

    Private Sub botonOrdenProduccion_Click(sender As Object, e As EventArgs) Handles botonOrdenProduccion.Click
        If dgDetalle.Rows.Count = 0 Then
            Exit Sub
        Else
        End If
        Dim intAnio As Integer
        Dim intNumero As Integer
        Dim rpt As New clsReportes
        Dim respuesta As String
        Dim respuesta1 As String


        intNumero = celdaNumero.Text
        intAnio = celdaAño.Text

        'REPORTE EN FORMATO ESPAÑOL/INGLES
        rpt.Rpt_OrdenProduccion(intNumero, intAnio)


    End Sub
#End Region
End Class
