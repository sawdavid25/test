﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmOrdenProduccion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PanelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAño = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colContacto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelFiltro = New System.Windows.Forms.Panel()
        Me.btnFiltro = New System.Windows.Forms.Button()
        Me.chkFecha = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtpFinal = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.pnlOrder = New System.Windows.Forms.Panel()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.pnlContenedores = New System.Windows.Forms.Panel()
        Me.dgvDetalle = New System.Windows.Forms.DataGridView()
        Me.colCodigo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescripcion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMedidas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUnidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFob = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCif = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCantidad = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFila = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colAñoDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLineaDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CodFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFabricante = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colOrden = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.codPrograma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrograma = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstadoDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colApartadoDetalle = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIDP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPais = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDespacho = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colVendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colidVendido = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDescEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.certification = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMKTRef = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Splitter5 = New System.Windows.Forms.Splitter()
        Me.panelPieDetalle = New System.Windows.Forms.Panel()
        Me.CeldaInfo2 = New System.Windows.Forms.Label()
        Me.CeldaInfo1 = New System.Windows.Forms.Label()
        Me.pbLetras = New System.Windows.Forms.PictureBox()
        Me.pnlSeparador3 = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.pnlInternoButton = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.CeldaObservacion = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.pnlTop = New System.Windows.Forms.Panel()
        Me.PanelEncabezado = New System.Windows.Forms.Panel()
        Me.gpAdicional = New System.Windows.Forms.GroupBox()
        Me.celdaContactoCliente = New System.Windows.Forms.TextBox()
        Me.checkIntercompany = New System.Windows.Forms.CheckBox()
        Me.botonContenedores = New System.Windows.Forms.Button()
        Me.celdaContrato = New System.Windows.Forms.TextBox()
        Me.etiquetaContrato = New System.Windows.Forms.Label()
        Me.celdanumero1 = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.celdaIdContactoCliente = New System.Windows.Forms.TextBox()
        Me.celdaIdCliente2 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.botonContactoCliente = New System.Windows.Forms.Button()
        Me.botonCliente = New System.Windows.Forms.Button()
        Me.bntQuitarPedido = New System.Windows.Forms.Button()
        Me.btnPedido = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.CeldaCliente = New System.Windows.Forms.TextBox()
        Me.CeldaReferencia = New System.Windows.Forms.TextBox()
        Me.CeldaPedido = New System.Windows.Forms.TextBox()
        Me.gpDocumentos = New System.Windows.Forms.GroupBox()
        Me.celdaidUsuario = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaidMoneda = New System.Windows.Forms.TextBox()
        Me.celdaidCliente = New System.Windows.Forms.TextBox()
        Me.botonContactoProveedor = New System.Windows.Forms.Button()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.celdaCelular = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.celdaContactoProveedor = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.celdaCliente1 = New System.Windows.Forms.TextBox()
        Me.dtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.CeldaTotal = New System.Windows.Forms.TextBox()
        Me.CeldaCantidad = New System.Windows.Forms.TextBox()
        Me.chkActivo = New System.Windows.Forms.CheckBox()
        Me.CeldaTasa = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnMoneda = New System.Windows.Forms.Button()
        Me.CeldaMoneda = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnNombre = New System.Windows.Forms.Button()
        Me.CeldaDireccion = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.CeldaNumero = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CeldaAño = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.botonImprimirOrden = New System.Windows.Forms.Button()
        Me.botonImprimir = New System.Windows.Forms.Button()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.PanelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelFiltro.SuspendLayout()
        Me.pnlOrder.SuspendLayout()
        Me.pnlContenedores.SuspendLayout()
        CType(Me.dgvDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelPieDetalle.SuspendLayout()
        CType(Me.pbLetras, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlSeparador3.SuspendLayout()
        Me.pnlInternoButton.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.pnlTop.SuspendLayout()
        Me.PanelEncabezado.SuspendLayout()
        Me.gpAdicional.SuspendLayout()
        Me.gpDocumentos.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelLista
        '
        Me.PanelLista.Controls.Add(Me.dgLista)
        Me.PanelLista.Controls.Add(Me.PanelFiltro)
        Me.PanelLista.Location = New System.Drawing.Point(454, 28)
        Me.PanelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelLista.Name = "PanelLista"
        Me.PanelLista.Size = New System.Drawing.Size(256, 127)
        Me.PanelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAño, Me.colNumero, Me.colFecha, Me.colNombre, Me.colContacto, Me.colReferencia})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 96)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(256, 31)
        Me.dgLista.TabIndex = 4
        '
        'colAño
        '
        Me.colAño.HeaderText = "Year"
        Me.colAño.Name = "colAño"
        Me.colAño.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colNombre
        '
        Me.colNombre.HeaderText = "Name"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        '
        'colContacto
        '
        Me.colContacto.HeaderText = "Contact"
        Me.colContacto.Name = "colContacto"
        Me.colContacto.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'PanelFiltro
        '
        Me.PanelFiltro.Controls.Add(Me.btnFiltro)
        Me.PanelFiltro.Controls.Add(Me.chkFecha)
        Me.PanelFiltro.Controls.Add(Me.Label1)
        Me.PanelFiltro.Controls.Add(Me.dtpFinal)
        Me.PanelFiltro.Controls.Add(Me.Label3)
        Me.PanelFiltro.Controls.Add(Me.dtpInicio)
        Me.PanelFiltro.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelFiltro.Location = New System.Drawing.Point(0, 0)
        Me.PanelFiltro.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelFiltro.Name = "PanelFiltro"
        Me.PanelFiltro.Size = New System.Drawing.Size(256, 96)
        Me.PanelFiltro.TabIndex = 3
        '
        'btnFiltro
        '
        Me.btnFiltro.Location = New System.Drawing.Point(349, 28)
        Me.btnFiltro.Name = "btnFiltro"
        Me.btnFiltro.Size = New System.Drawing.Size(75, 23)
        Me.btnFiltro.TabIndex = 13
        Me.btnFiltro.Text = "Filtro"
        Me.btnFiltro.UseVisualStyleBackColor = True
        '
        'chkFecha
        '
        Me.chkFecha.AutoSize = True
        Me.chkFecha.Checked = True
        Me.chkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFecha.Location = New System.Drawing.Point(20, 35)
        Me.chkFecha.Name = "chkFecha"
        Me.chkFecha.Size = New System.Drawing.Size(56, 17)
        Me.chkFecha.TabIndex = 12
        Me.chkFecha.Text = "Fecha"
        Me.chkFecha.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(77, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Del"
        '
        'dtpFinal
        '
        Me.dtpFinal.Location = New System.Drawing.Point(111, 54)
        Me.dtpFinal.Name = "dtpFinal"
        Me.dtpFinal.Size = New System.Drawing.Size(200, 20)
        Me.dtpFinal.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(77, 58)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(16, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Al"
        '
        'dtpInicio
        '
        Me.dtpInicio.Location = New System.Drawing.Point(111, 28)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(200, 20)
        Me.dtpInicio.TabIndex = 8
        '
        'pnlOrder
        '
        Me.pnlOrder.Controls.Add(Me.Splitter1)
        Me.pnlOrder.Controls.Add(Me.pnlContenedores)
        Me.pnlOrder.Controls.Add(Me.pnlInternoButton)
        Me.pnlOrder.Controls.Add(Me.pnlTop)
        Me.pnlOrder.Location = New System.Drawing.Point(12, 142)
        Me.pnlOrder.Name = "pnlOrder"
        Me.pnlOrder.Size = New System.Drawing.Size(956, 475)
        Me.pnlOrder.TabIndex = 4
        '
        'Splitter1
        '
        Me.Splitter1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Splitter1.Cursor = System.Windows.Forms.Cursors.HSplit
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Splitter1.Location = New System.Drawing.Point(0, 244)
        Me.Splitter1.Margin = New System.Windows.Forms.Padding(2)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(956, 8)
        Me.Splitter1.TabIndex = 14
        Me.Splitter1.TabStop = False
        '
        'pnlContenedores
        '
        Me.pnlContenedores.Controls.Add(Me.dgvDetalle)
        Me.pnlContenedores.Controls.Add(Me.Splitter5)
        Me.pnlContenedores.Controls.Add(Me.panelPieDetalle)
        Me.pnlContenedores.Controls.Add(Me.pnlSeparador3)
        Me.pnlContenedores.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlContenedores.Location = New System.Drawing.Point(0, 244)
        Me.pnlContenedores.Name = "pnlContenedores"
        Me.pnlContenedores.Size = New System.Drawing.Size(956, 178)
        Me.pnlContenedores.TabIndex = 1
        '
        'dgvDetalle
        '
        Me.dgvDetalle.AllowUserToAddRows = False
        Me.dgvDetalle.AllowUserToDeleteRows = False
        Me.dgvDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgvDetalle.ColumnHeadersHeight = 29
        Me.dgvDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCodigo, Me.colDescripcion, Me.colMedidas, Me.colUnidad, Me.colFob, Me.colCif, Me.colPrecio, Me.colCantidad, Me.colTotal, Me.colFila, Me.colAñoDetalle, Me.colNumeroDetalle, Me.colLineaDetalle, Me.CodFabricante, Me.colFabricante, Me.colOrden, Me.colFechaDetalle, Me.codPrograma, Me.colPrograma, Me.colEstadoDetalle, Me.colApartadoDetalle, Me.colIDP, Me.colPais, Me.colDespacho, Me.colStatus, Me.colVendido, Me.colidVendido, Me.colDescEstado, Me.certification, Me.colMKTRef})
        Me.dgvDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDetalle.Location = New System.Drawing.Point(0, 0)
        Me.dgvDetalle.Name = "dgvDetalle"
        Me.dgvDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvDetalle.Size = New System.Drawing.Size(902, 58)
        Me.dgvDetalle.TabIndex = 1
        '
        'colCodigo
        '
        Me.colCodigo.HeaderText = "Code"
        Me.colCodigo.Name = "colCodigo"
        Me.colCodigo.ReadOnly = True
        Me.colCodigo.Width = 57
        '
        'colDescripcion
        '
        Me.colDescripcion.HeaderText = "Description"
        Me.colDescripcion.Name = "colDescripcion"
        Me.colDescripcion.ReadOnly = True
        Me.colDescripcion.Width = 85
        '
        'colMedidas
        '
        Me.colMedidas.HeaderText = "Measure"
        Me.colMedidas.Name = "colMedidas"
        Me.colMedidas.ReadOnly = True
        Me.colMedidas.Width = 73
        '
        'colUnidad
        '
        Me.colUnidad.HeaderText = "Unidad"
        Me.colUnidad.Name = "colUnidad"
        Me.colUnidad.Visible = False
        Me.colUnidad.Width = 66
        '
        'colFob
        '
        Me.colFob.HeaderText = "Price Fob $."
        Me.colFob.Name = "colFob"
        Me.colFob.Width = 89
        '
        'colCif
        '
        Me.colCif.HeaderText = "Price Cif $."
        Me.colCif.Name = "colCif"
        Me.colCif.Width = 83
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Precio"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Visible = False
        Me.colPrecio.Width = 62
        '
        'colCantidad
        '
        Me.colCantidad.HeaderText = "Quantity"
        Me.colCantidad.Name = "colCantidad"
        Me.colCantidad.Width = 71
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total $."
        Me.colTotal.Name = "colTotal"
        Me.colTotal.Width = 68
        '
        'colFila
        '
        Me.colFila.HeaderText = "Row"
        Me.colFila.Name = "colFila"
        Me.colFila.ReadOnly = True
        Me.colFila.Width = 54
        '
        'colAñoDetalle
        '
        Me.colAñoDetalle.HeaderText = "Año"
        Me.colAñoDetalle.Name = "colAñoDetalle"
        Me.colAñoDetalle.Visible = False
        Me.colAñoDetalle.Width = 51
        '
        'colNumeroDetalle
        '
        Me.colNumeroDetalle.HeaderText = "Numero"
        Me.colNumeroDetalle.Name = "colNumeroDetalle"
        Me.colNumeroDetalle.Visible = False
        Me.colNumeroDetalle.Width = 69
        '
        'colLineaDetalle
        '
        Me.colLineaDetalle.HeaderText = "Linea"
        Me.colLineaDetalle.Name = "colLineaDetalle"
        Me.colLineaDetalle.Visible = False
        Me.colLineaDetalle.Width = 58
        '
        'CodFabricante
        '
        Me.CodFabricante.HeaderText = "Codigo Fabricante"
        Me.CodFabricante.Name = "CodFabricante"
        Me.CodFabricante.Visible = False
        Me.CodFabricante.Width = 118
        '
        'colFabricante
        '
        Me.colFabricante.HeaderText = "Marker"
        Me.colFabricante.Name = "colFabricante"
        Me.colFabricante.Visible = False
        Me.colFabricante.Width = 65
        '
        'colOrden
        '
        Me.colOrden.HeaderText = "Order"
        Me.colOrden.Name = "colOrden"
        Me.colOrden.Visible = False
        Me.colOrden.Width = 58
        '
        'colFechaDetalle
        '
        DataGridViewCellStyle1.Format = "d"
        DataGridViewCellStyle1.NullValue = Nothing
        Me.colFechaDetalle.DefaultCellStyle = DataGridViewCellStyle1
        Me.colFechaDetalle.HeaderText = "ETD"
        Me.colFechaDetalle.Name = "colFechaDetalle"
        Me.colFechaDetalle.Visible = False
        Me.colFechaDetalle.Width = 54
        '
        'codPrograma
        '
        Me.codPrograma.HeaderText = "CodigoPrograma"
        Me.codPrograma.Name = "codPrograma"
        Me.codPrograma.Visible = False
        Me.codPrograma.Width = 110
        '
        'colPrograma
        '
        Me.colPrograma.HeaderText = "Program"
        Me.colPrograma.Name = "colPrograma"
        Me.colPrograma.Visible = False
        Me.colPrograma.Width = 71
        '
        'colEstadoDetalle
        '
        Me.colEstadoDetalle.HeaderText = "Cancelled"
        Me.colEstadoDetalle.Name = "colEstadoDetalle"
        Me.colEstadoDetalle.Visible = False
        Me.colEstadoDetalle.Width = 79
        '
        'colApartadoDetalle
        '
        Me.colApartadoDetalle.HeaderText = "Separated"
        Me.colApartadoDetalle.Name = "colApartadoDetalle"
        Me.colApartadoDetalle.Visible = False
        Me.colApartadoDetalle.Width = 81
        '
        'colIDP
        '
        Me.colIDP.HeaderText = "IDP"
        Me.colIDP.Name = "colIDP"
        Me.colIDP.Visible = False
        Me.colIDP.Width = 50
        '
        'colPais
        '
        Me.colPais.HeaderText = "Pais"
        Me.colPais.Name = "colPais"
        Me.colPais.Visible = False
        Me.colPais.Width = 52
        '
        'colDespacho
        '
        Me.colDespacho.HeaderText = "dispatches"
        Me.colDespacho.Name = "colDespacho"
        Me.colDespacho.ReadOnly = True
        Me.colDespacho.Visible = False
        Me.colDespacho.Width = 83
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Status"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.ReadOnly = True
        Me.colStatus.Width = 62
        '
        'colVendido
        '
        Me.colVendido.HeaderText = "Sold To"
        Me.colVendido.Name = "colVendido"
        Me.colVendido.ReadOnly = True
        Me.colVendido.Visible = False
        Me.colVendido.Width = 69
        '
        'colidVendido
        '
        Me.colidVendido.HeaderText = "Vendido"
        Me.colidVendido.Name = "colidVendido"
        Me.colidVendido.Visible = False
        Me.colidVendido.Width = 71
        '
        'colDescEstado
        '
        Me.colDescEstado.HeaderText = "Estado"
        Me.colDescEstado.Name = "colDescEstado"
        Me.colDescEstado.Visible = False
        Me.colDescEstado.Width = 65
        '
        'certification
        '
        Me.certification.HeaderText = "Certification"
        Me.certification.Name = "certification"
        Me.certification.Visible = False
        Me.certification.Width = 87
        '
        'colMKTRef
        '
        Me.colMKTRef.HeaderText = "Ref MKT"
        Me.colMKTRef.Name = "colMKTRef"
        Me.colMKTRef.Visible = False
        Me.colMKTRef.Width = 75
        '
        'Splitter5
        '
        Me.Splitter5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Splitter5.Cursor = System.Windows.Forms.Cursors.HSplit
        Me.Splitter5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Splitter5.Location = New System.Drawing.Point(0, 58)
        Me.Splitter5.Margin = New System.Windows.Forms.Padding(2)
        Me.Splitter5.Name = "Splitter5"
        Me.Splitter5.Size = New System.Drawing.Size(902, 8)
        Me.Splitter5.TabIndex = 13
        Me.Splitter5.TabStop = False
        '
        'panelPieDetalle
        '
        Me.panelPieDetalle.Controls.Add(Me.CeldaInfo2)
        Me.panelPieDetalle.Controls.Add(Me.CeldaInfo1)
        Me.panelPieDetalle.Controls.Add(Me.pbLetras)
        Me.panelPieDetalle.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelPieDetalle.Location = New System.Drawing.Point(0, 66)
        Me.panelPieDetalle.Margin = New System.Windows.Forms.Padding(2)
        Me.panelPieDetalle.Name = "panelPieDetalle"
        Me.panelPieDetalle.Size = New System.Drawing.Size(902, 112)
        Me.panelPieDetalle.TabIndex = 6
        '
        'CeldaInfo2
        '
        Me.CeldaInfo2.AutoSize = True
        Me.CeldaInfo2.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaInfo2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CeldaInfo2.Location = New System.Drawing.Point(103, 11)
        Me.CeldaInfo2.Name = "CeldaInfo2"
        Me.CeldaInfo2.Size = New System.Drawing.Size(45, 13)
        Me.CeldaInfo2.TabIndex = 11
        Me.CeldaInfo2.Text = "Label16"
        '
        'CeldaInfo1
        '
        Me.CeldaInfo1.AutoSize = True
        Me.CeldaInfo1.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaInfo1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CeldaInfo1.Location = New System.Drawing.Point(20, 11)
        Me.CeldaInfo1.Name = "CeldaInfo1"
        Me.CeldaInfo1.Size = New System.Drawing.Size(45, 13)
        Me.CeldaInfo1.TabIndex = 10
        Me.CeldaInfo1.Text = "Label16"
        '
        'pbLetras
        '
        Me.pbLetras.BackColor = System.Drawing.SystemColors.Info
        Me.pbLetras.Dock = System.Windows.Forms.DockStyle.Top
        Me.pbLetras.Location = New System.Drawing.Point(0, 0)
        Me.pbLetras.Name = "pbLetras"
        Me.pbLetras.Size = New System.Drawing.Size(902, 44)
        Me.pbLetras.TabIndex = 3
        Me.pbLetras.TabStop = False
        '
        'pnlSeparador3
        '
        Me.pnlSeparador3.Controls.Add(Me.botonAgregar)
        Me.pnlSeparador3.Controls.Add(Me.botonQuitar)
        Me.pnlSeparador3.Dock = System.Windows.Forms.DockStyle.Right
        Me.pnlSeparador3.Location = New System.Drawing.Point(902, 0)
        Me.pnlSeparador3.Name = "pnlSeparador3"
        Me.pnlSeparador3.Size = New System.Drawing.Size(54, 178)
        Me.pnlSeparador3.TabIndex = 0
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.plus
        Me.botonAgregar.Location = New System.Drawing.Point(11, 15)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(26, 24)
        Me.botonAgregar.TabIndex = 2
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(11, 47)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(26, 24)
        Me.botonQuitar.TabIndex = 1
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        '
        'pnlInternoButton
        '
        Me.pnlInternoButton.Controls.Add(Me.Panel2)
        Me.pnlInternoButton.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.pnlInternoButton.Location = New System.Drawing.Point(0, 422)
        Me.pnlInternoButton.Name = "pnlInternoButton"
        Me.pnlInternoButton.Size = New System.Drawing.Size(956, 53)
        Me.pnlInternoButton.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.CeldaObservacion)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel2.Location = New System.Drawing.Point(0, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(956, 50)
        Me.Panel2.TabIndex = 1
        '
        'CeldaObservacion
        '
        Me.CeldaObservacion.Location = New System.Drawing.Point(121, 21)
        Me.CeldaObservacion.Name = "CeldaObservacion"
        Me.CeldaObservacion.Size = New System.Drawing.Size(596, 20)
        Me.CeldaObservacion.TabIndex = 3
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label14.Location = New System.Drawing.Point(7, 3)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(103, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Datos Relacionados"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.Location = New System.Drawing.Point(7, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(78, 13)
        Me.Label15.TabIndex = 2
        Me.Label15.Text = "Observaciones"
        '
        'pnlTop
        '
        Me.pnlTop.Controls.Add(Me.PanelEncabezado)
        Me.pnlTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnlTop.Location = New System.Drawing.Point(0, 0)
        Me.pnlTop.Name = "pnlTop"
        Me.pnlTop.Size = New System.Drawing.Size(956, 244)
        Me.pnlTop.TabIndex = 0
        '
        'PanelEncabezado
        '
        Me.PanelEncabezado.Controls.Add(Me.gpAdicional)
        Me.PanelEncabezado.Controls.Add(Me.gpDocumentos)
        Me.PanelEncabezado.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.PanelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.PanelEncabezado.Name = "PanelEncabezado"
        Me.PanelEncabezado.Size = New System.Drawing.Size(956, 244)
        Me.PanelEncabezado.TabIndex = 0
        '
        'gpAdicional
        '
        Me.gpAdicional.Controls.Add(Me.celdaContactoCliente)
        Me.gpAdicional.Controls.Add(Me.checkIntercompany)
        Me.gpAdicional.Controls.Add(Me.botonContenedores)
        Me.gpAdicional.Controls.Add(Me.celdaContrato)
        Me.gpAdicional.Controls.Add(Me.etiquetaContrato)
        Me.gpAdicional.Controls.Add(Me.celdanumero1)
        Me.gpAdicional.Controls.Add(Me.celdaAnio)
        Me.gpAdicional.Controls.Add(Me.celdaCatalogo)
        Me.gpAdicional.Controls.Add(Me.celdaIdContactoCliente)
        Me.gpAdicional.Controls.Add(Me.celdaIdCliente2)
        Me.gpAdicional.Controls.Add(Me.Label20)
        Me.gpAdicional.Controls.Add(Me.botonContactoCliente)
        Me.gpAdicional.Controls.Add(Me.botonCliente)
        Me.gpAdicional.Controls.Add(Me.bntQuitarPedido)
        Me.gpAdicional.Controls.Add(Me.btnPedido)
        Me.gpAdicional.Controls.Add(Me.Label11)
        Me.gpAdicional.Controls.Add(Me.Label10)
        Me.gpAdicional.Controls.Add(Me.Label9)
        Me.gpAdicional.Controls.Add(Me.CeldaCliente)
        Me.gpAdicional.Controls.Add(Me.CeldaReferencia)
        Me.gpAdicional.Controls.Add(Me.CeldaPedido)
        Me.gpAdicional.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gpAdicional.Location = New System.Drawing.Point(439, 0)
        Me.gpAdicional.Name = "gpAdicional"
        Me.gpAdicional.Size = New System.Drawing.Size(517, 244)
        Me.gpAdicional.TabIndex = 1
        Me.gpAdicional.TabStop = False
        Me.gpAdicional.Text = "Informacion Adicional"
        Me.gpAdicional.Visible = False
        '
        'celdaContactoCliente
        '
        Me.celdaContactoCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaContactoCliente.Location = New System.Drawing.Point(12, 106)
        Me.celdaContactoCliente.Name = "celdaContactoCliente"
        Me.celdaContactoCliente.ReadOnly = True
        Me.celdaContactoCliente.Size = New System.Drawing.Size(425, 20)
        Me.celdaContactoCliente.TabIndex = 11
        '
        'checkIntercompany
        '
        Me.checkIntercompany.AutoSize = True
        Me.checkIntercompany.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkIntercompany.Location = New System.Drawing.Point(17, 215)
        Me.checkIntercompany.Margin = New System.Windows.Forms.Padding(2)
        Me.checkIntercompany.Name = "checkIntercompany"
        Me.checkIntercompany.Size = New System.Drawing.Size(102, 17)
        Me.checkIntercompany.TabIndex = 41
        Me.checkIntercompany.Text = "Intercompany"
        Me.checkIntercompany.UseVisualStyleBackColor = True
        '
        'botonContenedores
        '
        Me.botonContenedores.Location = New System.Drawing.Point(134, 180)
        Me.botonContenedores.Margin = New System.Windows.Forms.Padding(2)
        Me.botonContenedores.Name = "botonContenedores"
        Me.botonContenedores.Size = New System.Drawing.Size(79, 30)
        Me.botonContenedores.TabIndex = 40
        Me.botonContenedores.Text = "Containers"
        Me.botonContenedores.UseVisualStyleBackColor = True
        '
        'celdaContrato
        '
        Me.celdaContrato.Location = New System.Drawing.Point(12, 190)
        Me.celdaContrato.Name = "celdaContrato"
        Me.celdaContrato.Size = New System.Drawing.Size(107, 20)
        Me.celdaContrato.TabIndex = 39
        '
        'etiquetaContrato
        '
        Me.etiquetaContrato.AutoSize = True
        Me.etiquetaContrato.Location = New System.Drawing.Point(10, 173)
        Me.etiquetaContrato.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaContrato.Name = "etiquetaContrato"
        Me.etiquetaContrato.Size = New System.Drawing.Size(85, 13)
        Me.etiquetaContrato.TabIndex = 38
        Me.etiquetaContrato.Text = "Contract number"
        '
        'celdanumero1
        '
        Me.celdanumero1.Location = New System.Drawing.Point(306, 11)
        Me.celdanumero1.Margin = New System.Windows.Forms.Padding(2)
        Me.celdanumero1.Name = "celdanumero1"
        Me.celdanumero1.Size = New System.Drawing.Size(27, 20)
        Me.celdanumero1.TabIndex = 37
        Me.celdanumero1.Visible = False
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(263, 13)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.Size = New System.Drawing.Size(27, 20)
        Me.celdaAnio.TabIndex = 36
        Me.celdaAnio.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(222, 11)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(27, 20)
        Me.celdaCatalogo.TabIndex = 35
        Me.celdaCatalogo.Visible = False
        '
        'celdaIdContactoCliente
        '
        Me.celdaIdContactoCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdContactoCliente.Location = New System.Drawing.Point(394, 7)
        Me.celdaIdContactoCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdContactoCliente.Name = "celdaIdContactoCliente"
        Me.celdaIdContactoCliente.Size = New System.Drawing.Size(26, 20)
        Me.celdaIdContactoCliente.TabIndex = 34
        Me.celdaIdContactoCliente.Visible = False
        '
        'celdaIdCliente2
        '
        Me.celdaIdCliente2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdCliente2.Location = New System.Drawing.Point(355, 8)
        Me.celdaIdCliente2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdCliente2.Name = "celdaIdCliente2"
        Me.celdaIdCliente2.Size = New System.Drawing.Size(26, 20)
        Me.celdaIdCliente2.TabIndex = 33
        Me.celdaIdCliente2.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(10, 89)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(44, 13)
        Me.Label20.TabIndex = 33
        Me.Label20.Text = "Contact"
        '
        'botonContactoCliente
        '
        Me.botonContactoCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonContactoCliente.Location = New System.Drawing.Point(454, 106)
        Me.botonContactoCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.botonContactoCliente.Name = "botonContactoCliente"
        Me.botonContactoCliente.Size = New System.Drawing.Size(31, 20)
        Me.botonContactoCliente.TabIndex = 12
        Me.botonContactoCliente.Text = "..."
        Me.botonContactoCliente.UseVisualStyleBackColor = True
        '
        'botonCliente
        '
        Me.botonCliente.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonCliente.Location = New System.Drawing.Point(454, 67)
        Me.botonCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.botonCliente.Name = "botonCliente"
        Me.botonCliente.Size = New System.Drawing.Size(31, 19)
        Me.botonCliente.TabIndex = 9
        Me.botonCliente.Text = "..."
        Me.botonCliente.UseVisualStyleBackColor = True
        '
        'bntQuitarPedido
        '
        Me.bntQuitarPedido.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.bntQuitarPedido.Location = New System.Drawing.Point(481, 143)
        Me.bntQuitarPedido.Name = "bntQuitarPedido"
        Me.bntQuitarPedido.Size = New System.Drawing.Size(33, 21)
        Me.bntQuitarPedido.TabIndex = 8
        Me.bntQuitarPedido.Text = "..."
        Me.bntQuitarPedido.UseVisualStyleBackColor = True
        '
        'btnPedido
        '
        Me.btnPedido.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPedido.Location = New System.Drawing.Point(442, 143)
        Me.btnPedido.Name = "btnPedido"
        Me.btnPedido.Size = New System.Drawing.Size(33, 21)
        Me.btnPedido.TabIndex = 7
        Me.btnPedido.Text = "..."
        Me.btnPedido.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 127)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Order Number"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 53)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(51, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Customer"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(10, 15)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(59, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Referencia"
        '
        'CeldaCliente
        '
        Me.CeldaCliente.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaCliente.Location = New System.Drawing.Point(12, 67)
        Me.CeldaCliente.Name = "CeldaCliente"
        Me.CeldaCliente.ReadOnly = True
        Me.CeldaCliente.Size = New System.Drawing.Size(425, 20)
        Me.CeldaCliente.TabIndex = 4
        '
        'CeldaReferencia
        '
        Me.CeldaReferencia.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaReferencia.Location = New System.Drawing.Point(12, 32)
        Me.CeldaReferencia.Name = "CeldaReferencia"
        Me.CeldaReferencia.Size = New System.Drawing.Size(425, 20)
        Me.CeldaReferencia.TabIndex = 3
        '
        'CeldaPedido
        '
        Me.CeldaPedido.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CeldaPedido.Location = New System.Drawing.Point(12, 144)
        Me.CeldaPedido.Name = "CeldaPedido"
        Me.CeldaPedido.ReadOnly = True
        Me.CeldaPedido.Size = New System.Drawing.Size(425, 20)
        Me.CeldaPedido.TabIndex = 5
        '
        'gpDocumentos
        '
        Me.gpDocumentos.Controls.Add(Me.celdaidUsuario)
        Me.gpDocumentos.Controls.Add(Me.celdaUsuario)
        Me.gpDocumentos.Controls.Add(Me.celdaidMoneda)
        Me.gpDocumentos.Controls.Add(Me.celdaidCliente)
        Me.gpDocumentos.Controls.Add(Me.botonContactoProveedor)
        Me.gpDocumentos.Controls.Add(Me.celdaNit)
        Me.gpDocumentos.Controls.Add(Me.Label19)
        Me.gpDocumentos.Controls.Add(Me.celdaCelular)
        Me.gpDocumentos.Controls.Add(Me.Label18)
        Me.gpDocumentos.Controls.Add(Me.celdaContactoProveedor)
        Me.gpDocumentos.Controls.Add(Me.Label17)
        Me.gpDocumentos.Controls.Add(Me.celdaCliente1)
        Me.gpDocumentos.Controls.Add(Me.dtpFecha)
        Me.gpDocumentos.Controls.Add(Me.Label16)
        Me.gpDocumentos.Controls.Add(Me.Label13)
        Me.gpDocumentos.Controls.Add(Me.Label12)
        Me.gpDocumentos.Controls.Add(Me.CeldaTotal)
        Me.gpDocumentos.Controls.Add(Me.CeldaCantidad)
        Me.gpDocumentos.Controls.Add(Me.chkActivo)
        Me.gpDocumentos.Controls.Add(Me.CeldaTasa)
        Me.gpDocumentos.Controls.Add(Me.Label8)
        Me.gpDocumentos.Controls.Add(Me.btnMoneda)
        Me.gpDocumentos.Controls.Add(Me.CeldaMoneda)
        Me.gpDocumentos.Controls.Add(Me.Label7)
        Me.gpDocumentos.Controls.Add(Me.btnNombre)
        Me.gpDocumentos.Controls.Add(Me.CeldaDireccion)
        Me.gpDocumentos.Controls.Add(Me.Label6)
        Me.gpDocumentos.Controls.Add(Me.Label5)
        Me.gpDocumentos.Controls.Add(Me.CeldaNumero)
        Me.gpDocumentos.Controls.Add(Me.Label4)
        Me.gpDocumentos.Controls.Add(Me.CeldaAño)
        Me.gpDocumentos.Controls.Add(Me.Label2)
        Me.gpDocumentos.Dock = System.Windows.Forms.DockStyle.Left
        Me.gpDocumentos.Location = New System.Drawing.Point(0, 0)
        Me.gpDocumentos.Name = "gpDocumentos"
        Me.gpDocumentos.Size = New System.Drawing.Size(439, 244)
        Me.gpDocumentos.TabIndex = 0
        Me.gpDocumentos.TabStop = False
        Me.gpDocumentos.Text = "Datos del Documento"
        '
        'celdaidUsuario
        '
        Me.celdaidUsuario.Location = New System.Drawing.Point(408, 195)
        Me.celdaidUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidUsuario.Name = "celdaidUsuario"
        Me.celdaidUsuario.Size = New System.Drawing.Size(20, 20)
        Me.celdaidUsuario.TabIndex = 52
        Me.celdaidUsuario.Text = "-1"
        Me.celdaidUsuario.Visible = False
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Location = New System.Drawing.Point(403, 170)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(29, 20)
        Me.celdaUsuario.TabIndex = 51
        Me.celdaUsuario.Visible = False
        '
        'celdaidMoneda
        '
        Me.celdaidMoneda.Location = New System.Drawing.Point(92, 183)
        Me.celdaidMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidMoneda.Name = "celdaidMoneda"
        Me.celdaidMoneda.Size = New System.Drawing.Size(26, 20)
        Me.celdaidMoneda.TabIndex = 32
        Me.celdaidMoneda.Visible = False
        '
        'celdaidCliente
        '
        Me.celdaidCliente.Location = New System.Drawing.Point(408, 33)
        Me.celdaidCliente.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaidCliente.Name = "celdaidCliente"
        Me.celdaidCliente.Size = New System.Drawing.Size(25, 20)
        Me.celdaidCliente.TabIndex = 31
        Me.celdaidCliente.Visible = False
        '
        'botonContactoProveedor
        '
        Me.botonContactoProveedor.Location = New System.Drawing.Point(407, 136)
        Me.botonContactoProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.botonContactoProveedor.Name = "botonContactoProveedor"
        Me.botonContactoProveedor.Size = New System.Drawing.Size(25, 19)
        Me.botonContactoProveedor.TabIndex = 30
        Me.botonContactoProveedor.Text = "..."
        Me.botonContactoProveedor.UseVisualStyleBackColor = True
        '
        'celdaNit
        '
        Me.celdaNit.Location = New System.Drawing.Point(257, 158)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(143, 20)
        Me.celdaNit.TabIndex = 29
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(229, 158)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(31, 13)
        Me.Label19.TabIndex = 28
        Me.Label19.Text = "N.I.T"
        '
        'celdaCelular
        '
        Me.celdaCelular.Location = New System.Drawing.Point(71, 158)
        Me.celdaCelular.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCelular.Name = "celdaCelular"
        Me.celdaCelular.Size = New System.Drawing.Size(154, 20)
        Me.celdaCelular.TabIndex = 27
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(20, 162)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(38, 13)
        Me.Label18.TabIndex = 26
        Me.Label18.Text = "Phone"
        '
        'celdaContactoProveedor
        '
        Me.celdaContactoProveedor.Location = New System.Drawing.Point(71, 137)
        Me.celdaContactoProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaContactoProveedor.Name = "celdaContactoProveedor"
        Me.celdaContactoProveedor.ReadOnly = True
        Me.celdaContactoProveedor.Size = New System.Drawing.Size(329, 20)
        Me.celdaContactoProveedor.TabIndex = 25
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(20, 141)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(44, 13)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "Contact"
        '
        'celdaCliente1
        '
        Me.celdaCliente1.Location = New System.Drawing.Point(71, 58)
        Me.celdaCliente1.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCliente1.Name = "celdaCliente1"
        Me.celdaCliente1.ReadOnly = True
        Me.celdaCliente1.Size = New System.Drawing.Size(329, 20)
        Me.celdaCliente1.TabIndex = 23
        '
        'dtpFecha
        '
        Me.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFecha.Location = New System.Drawing.Point(224, 31)
        Me.dtpFecha.Name = "dtpFecha"
        Me.dtpFecha.Size = New System.Drawing.Size(161, 20)
        Me.dtpFecha.TabIndex = 22
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(220, 14)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(37, 13)
        Me.Label16.TabIndex = 21
        Me.Label16.Text = "Fecha"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(342, 190)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 20
        Me.Label13.Text = "Amount"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(245, 190)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Quantity"
        '
        'CeldaTotal
        '
        Me.CeldaTotal.Location = New System.Drawing.Point(324, 208)
        Me.CeldaTotal.Name = "CeldaTotal"
        Me.CeldaTotal.ReadOnly = True
        Me.CeldaTotal.Size = New System.Drawing.Size(76, 20)
        Me.CeldaTotal.TabIndex = 18
        '
        'CeldaCantidad
        '
        Me.CeldaCantidad.Location = New System.Drawing.Point(237, 208)
        Me.CeldaCantidad.Name = "CeldaCantidad"
        Me.CeldaCantidad.ReadOnly = True
        Me.CeldaCantidad.Size = New System.Drawing.Size(76, 20)
        Me.CeldaCantidad.TabIndex = 17
        Me.CeldaCantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'chkActivo
        '
        Me.chkActivo.AutoSize = True
        Me.chkActivo.Checked = True
        Me.chkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkActivo.Location = New System.Drawing.Point(153, 34)
        Me.chkActivo.Name = "chkActivo"
        Me.chkActivo.Size = New System.Drawing.Size(56, 17)
        Me.chkActivo.TabIndex = 14
        Me.chkActivo.Text = "Active"
        Me.chkActivo.UseVisualStyleBackColor = True
        '
        'CeldaTasa
        '
        Me.CeldaTasa.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaTasa.Location = New System.Drawing.Point(128, 207)
        Me.CeldaTasa.Name = "CeldaTasa"
        Me.CeldaTasa.ReadOnly = True
        Me.CeldaTasa.Size = New System.Drawing.Size(97, 20)
        Me.CeldaTasa.TabIndex = 13
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(136, 190)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Tasa"
        '
        'btnMoneda
        '
        Me.btnMoneda.Location = New System.Drawing.Point(90, 208)
        Me.btnMoneda.Name = "btnMoneda"
        Me.btnMoneda.Size = New System.Drawing.Size(32, 20)
        Me.btnMoneda.TabIndex = 11
        Me.btnMoneda.Text = "..."
        Me.btnMoneda.UseVisualStyleBackColor = True
        '
        'CeldaMoneda
        '
        Me.CeldaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaMoneda.Location = New System.Drawing.Point(18, 209)
        Me.CeldaMoneda.Name = "CeldaMoneda"
        Me.CeldaMoneda.ReadOnly = True
        Me.CeldaMoneda.Size = New System.Drawing.Size(67, 20)
        Me.CeldaMoneda.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(22, 187)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Moneda"
        '
        'btnNombre
        '
        Me.btnNombre.Location = New System.Drawing.Point(407, 58)
        Me.btnNombre.Name = "btnNombre"
        Me.btnNombre.Size = New System.Drawing.Size(25, 20)
        Me.btnNombre.TabIndex = 8
        Me.btnNombre.Text = "..."
        Me.btnNombre.UseVisualStyleBackColor = True
        '
        'CeldaDireccion
        '
        Me.CeldaDireccion.Location = New System.Drawing.Point(71, 81)
        Me.CeldaDireccion.Multiline = True
        Me.CeldaDireccion.Name = "CeldaDireccion"
        Me.CeldaDireccion.ReadOnly = True
        Me.CeldaDireccion.Size = New System.Drawing.Size(329, 51)
        Me.CeldaDireccion.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(8, 100)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Address"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Supplier"
        '
        'CeldaNumero
        '
        Me.CeldaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaNumero.Location = New System.Drawing.Point(76, 34)
        Me.CeldaNumero.Name = "CeldaNumero"
        Me.CeldaNumero.ReadOnly = True
        Me.CeldaNumero.Size = New System.Drawing.Size(72, 20)
        Me.CeldaNumero.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(73, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "Number"
        '
        'CeldaAño
        '
        Me.CeldaAño.BackColor = System.Drawing.SystemColors.Info
        Me.CeldaAño.Location = New System.Drawing.Point(10, 34)
        Me.CeldaAño.Name = "CeldaAño"
        Me.CeldaAño.ReadOnly = True
        Me.CeldaAño.Size = New System.Drawing.Size(60, 20)
        Me.CeldaAño.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(29, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Year"
        '
        'botonImprimirOrden
        '
        Me.botonImprimirOrden.Enabled = False
        Me.botonImprimirOrden.Image = Global.KARIMs_SGI.My.Resources.Resources.print1
        Me.botonImprimirOrden.Location = New System.Drawing.Point(278, 10)
        Me.botonImprimirOrden.Margin = New System.Windows.Forms.Padding(2)
        Me.botonImprimirOrden.Name = "botonImprimirOrden"
        Me.botonImprimirOrden.Size = New System.Drawing.Size(61, 43)
        Me.botonImprimirOrden.TabIndex = 7
        Me.botonImprimirOrden.Text = "Print Job"
        Me.botonImprimirOrden.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimirOrden.UseVisualStyleBackColor = True
        '
        'botonImprimir
        '
        Me.botonImprimir.Image = Global.KARIMs_SGI.My.Resources.Resources.print1
        Me.botonImprimir.Location = New System.Drawing.Point(204, 10)
        Me.botonImprimir.Margin = New System.Windows.Forms.Padding(2)
        Me.botonImprimir.Name = "botonImprimir"
        Me.botonImprimir.Size = New System.Drawing.Size(61, 43)
        Me.botonImprimir.TabIndex = 5
        Me.botonImprimir.Text = "Print"
        Me.botonImprimir.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.botonImprimir.UseVisualStyleBackColor = True
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 72)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1039, 50)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1039, 72)
        Me.Encabezado1.TabIndex = 0
        '
        'frmOrdenProduccion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1039, 790)
        Me.Controls.Add(Me.botonImprimirOrden)
        Me.Controls.Add(Me.botonImprimir)
        Me.Controls.Add(Me.pnlOrder)
        Me.Controls.Add(Me.PanelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmOrdenProduccion"
        Me.Text = "frmOrdenProduccion"
        Me.PanelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelFiltro.ResumeLayout(False)
        Me.PanelFiltro.PerformLayout()
        Me.pnlOrder.ResumeLayout(False)
        Me.pnlContenedores.ResumeLayout(False)
        CType(Me.dgvDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelPieDetalle.ResumeLayout(False)
        Me.panelPieDetalle.PerformLayout()
        CType(Me.pbLetras, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlSeparador3.ResumeLayout(False)
        Me.pnlInternoButton.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.pnlTop.ResumeLayout(False)
        Me.PanelEncabezado.ResumeLayout(False)
        Me.gpAdicional.ResumeLayout(False)
        Me.gpAdicional.PerformLayout()
        Me.gpDocumentos.ResumeLayout(False)
        Me.gpDocumentos.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents PanelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents colAño As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colContacto As DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As DataGridViewTextBoxColumn
    Friend WithEvents PanelFiltro As Panel
    Friend WithEvents btnFiltro As Button
    Friend WithEvents chkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFinal As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents pnlOrder As Panel
    Friend WithEvents pnlTop As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents botonImprimir As Button
    Friend WithEvents pnlInternoButton As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents CeldaObservacion As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents pnlContenedores As Panel
    Friend WithEvents dgvDetalle As DataGridView
    Friend WithEvents Splitter5 As Splitter
    Friend WithEvents panelPieDetalle As Panel
    Friend WithEvents CeldaInfo2 As Label
    Friend WithEvents CeldaInfo1 As Label
    Friend WithEvents pbLetras As PictureBox
    Friend WithEvents pnlSeparador3 As Panel
    Friend WithEvents botonAgregar As Button
    Friend WithEvents botonQuitar As Button
    Friend WithEvents gpDocumentos As GroupBox
    Friend WithEvents celdaidMoneda As TextBox
    Friend WithEvents celdaidCliente As TextBox
    Friend WithEvents botonContactoProveedor As Button
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents celdaCelular As TextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents celdaContactoProveedor As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents celdaCliente1 As TextBox
    Friend WithEvents dtpFecha As DateTimePicker
    Friend WithEvents Label16 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents CeldaTotal As TextBox
    Friend WithEvents CeldaCantidad As TextBox
    Friend WithEvents chkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents CeldaTasa As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents btnMoneda As Button
    Friend WithEvents CeldaMoneda As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents btnNombre As Button
    Friend WithEvents CeldaDireccion As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents CeldaNumero As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents CeldaAño As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents gpAdicional As GroupBox
    Friend WithEvents botonContenedores As Button
    Friend WithEvents celdaContrato As TextBox
    Friend WithEvents etiquetaContrato As Label
    Friend WithEvents celdanumero1 As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaIdContactoCliente As TextBox
    Friend WithEvents celdaIdCliente2 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents botonContactoCliente As Button
    Friend WithEvents celdaContactoCliente As TextBox
    Friend WithEvents botonCliente As Button
    Friend WithEvents bntQuitarPedido As Button
    Friend WithEvents btnPedido As Button
    Friend WithEvents CeldaPedido As TextBox
    Friend WithEvents CeldaCliente As TextBox
    Friend WithEvents CeldaReferencia As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Splitter1 As Splitter
    Friend WithEvents PanelEncabezado As Panel
    Friend WithEvents checkIntercompany As System.Windows.Forms.CheckBox
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaidUsuario As TextBox
    Friend WithEvents botonImprimirOrden As Button
    Friend WithEvents colCodigo As DataGridViewTextBoxColumn
    Friend WithEvents colDescripcion As DataGridViewTextBoxColumn
    Friend WithEvents colMedidas As DataGridViewTextBoxColumn
    Friend WithEvents colUnidad As DataGridViewTextBoxColumn
    Friend WithEvents colFob As DataGridViewTextBoxColumn
    Friend WithEvents colCif As DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As DataGridViewTextBoxColumn
    Friend WithEvents colCantidad As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents colFila As DataGridViewTextBoxColumn
    Friend WithEvents colAñoDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colLineaDetalle As DataGridViewTextBoxColumn
    Friend WithEvents CodFabricante As DataGridViewTextBoxColumn
    Friend WithEvents colFabricante As DataGridViewTextBoxColumn
    Friend WithEvents colOrden As DataGridViewTextBoxColumn
    Friend WithEvents colFechaDetalle As DataGridViewTextBoxColumn
    Friend WithEvents codPrograma As DataGridViewTextBoxColumn
    Friend WithEvents colPrograma As DataGridViewTextBoxColumn
    Friend WithEvents colEstadoDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colApartadoDetalle As DataGridViewTextBoxColumn
    Friend WithEvents colIDP As DataGridViewTextBoxColumn
    Friend WithEvents colPais As DataGridViewTextBoxColumn
    Friend WithEvents colDespacho As DataGridViewTextBoxColumn
    Friend WithEvents colStatus As DataGridViewTextBoxColumn
    Friend WithEvents colVendido As DataGridViewTextBoxColumn
    Friend WithEvents colidVendido As DataGridViewTextBoxColumn
    Friend WithEvents colDescEstado As DataGridViewTextBoxColumn
    Friend WithEvents certification As DataGridViewTextBoxColumn
    Friend WithEvents colMKTRef As DataGridViewTextBoxColumn
End Class
