﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmNotasCreditoProveedor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.panelListaPrincipal = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colProveedor = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferencia = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCorrelativo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.dtpFin = New System.Windows.Forms.DateTimePicker()
        Me.etiquetaFin = New System.Windows.Forms.Label()
        Me.dtpInicio = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.PanelDetalle = New System.Windows.Forms.Panel()
        Me.DgDetalle = New System.Windows.Forms.DataGridView()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colPrecio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombreCuenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCentroCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colStatus = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelBotones = New System.Windows.Forms.Panel()
        Me.BotonEliminar = New System.Windows.Forms.Button()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.PanelConcepto = New System.Windows.Forms.Panel()
        Me.celdaConcepto = New System.Windows.Forms.TextBox()
        Me.etiquetaAbono = New System.Windows.Forms.Label()
        Me.etiquetaConcepto = New System.Windows.Forms.Label()
        Me.celdaAbono = New System.Windows.Forms.TextBox()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.gbFacturas = New System.Windows.Forms.GroupBox()
        Me.panelImpuesto = New System.Windows.Forms.Panel()
        Me.DgImpuesto = New System.Windows.Forms.DataGridView()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colImpuesto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCosto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMarca = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.celdaReferencia = New System.Windows.Forms.TextBox()
        Me.etiquetaPoliza = New System.Windows.Forms.Label()
        Me.botonPolizaC = New System.Windows.Forms.Button()
        Me.dgFacturas = New System.Windows.Forms.DataGridView()
        Me.colAnioF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuarioF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colReferenciaF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraF = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaVence = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colDocumento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExenta = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.botonEliminaFactura = New System.Windows.Forms.Button()
        Me.botonAgregarFactura = New System.Windows.Forms.Button()
        Me.gbEncabezado = New System.Windows.Forms.GroupBox()
        Me.celdaSerie2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.celdaCorrelativo = New System.Windows.Forms.TextBox()
        Me.celdaTemporal = New System.Windows.Forms.TextBox()
        Me.etiquetaDocumento = New System.Windows.Forms.Label()
        Me.botonSerie = New System.Windows.Forms.Button()
        Me.celdaSerie = New System.Windows.Forms.TextBox()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.botonMoneda = New System.Windows.Forms.Button()
        Me.etiquetaTasa = New System.Windows.Forms.Label()
        Me.celdaTasa = New System.Windows.Forms.TextBox()
        Me.celdaUsuario = New System.Windows.Forms.TextBox()
        Me.celdaIdProveedor = New System.Windows.Forms.TextBox()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.dtFechaDoc = New System.Windows.Forms.DateTimePicker()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.celdaNit = New System.Windows.Forms.TextBox()
        Me.celdaTelefono = New System.Windows.Forms.TextBox()
        Me.celdaDireccion = New System.Windows.Forms.TextBox()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.etiquetaDireccion = New System.Windows.Forms.Label()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.etiquetaNit = New System.Windows.Forms.Label()
        Me.etiquetaTelefono = New System.Windows.Forms.Label()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.etiquetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.etiquetaSerie = New System.Windows.Forms.Label()
        Me.panelListaPrincipal.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.PanelDetalle.SuspendLayout()
        CType(Me.DgDetalle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelBotones.SuspendLayout()
        Me.PanelConcepto.SuspendLayout()
        Me.panelEncabezado.SuspendLayout()
        Me.gbFacturas.SuspendLayout()
        Me.panelImpuesto.SuspendLayout()
        CType(Me.DgImpuesto, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgFacturas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbEncabezado.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelListaPrincipal
        '
        Me.panelListaPrincipal.Controls.Add(Me.dgLista)
        Me.panelListaPrincipal.Controls.Add(Me.panelFechas)
        Me.panelListaPrincipal.Location = New System.Drawing.Point(803, 257)
        Me.panelListaPrincipal.Margin = New System.Windows.Forms.Padding(2)
        Me.panelListaPrincipal.Name = "panelListaPrincipal"
        Me.panelListaPrincipal.Size = New System.Drawing.Size(166, 80)
        Me.panelListaPrincipal.TabIndex = 1
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colNumero2, Me.colFecha, Me.colProveedor, Me.colReferencia, Me.colCorrelativo, Me.colEstado})
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 48)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(166, 32)
        Me.dgLista.TabIndex = 1
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colNumero2
        '
        Me.colNumero2.HeaderText = "Number"
        Me.colNumero2.Name = "colNumero2"
        Me.colNumero2.ReadOnly = True
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colProveedor
        '
        Me.colProveedor.HeaderText = "Supplier"
        Me.colProveedor.Name = "colProveedor"
        Me.colProveedor.ReadOnly = True
        '
        'colReferencia
        '
        Me.colReferencia.HeaderText = "Reference"
        Me.colReferencia.Name = "colReferencia"
        Me.colReferencia.ReadOnly = True
        '
        'colCorrelativo
        '
        Me.colCorrelativo.HeaderText = "Correlative"
        Me.colCorrelativo.Name = "colCorrelativo"
        Me.colCorrelativo.ReadOnly = True
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Status"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'panelFechas
        '
        Me.panelFechas.Controls.Add(Me.botonActualizar)
        Me.panelFechas.Controls.Add(Me.dtpFin)
        Me.panelFechas.Controls.Add(Me.etiquetaFin)
        Me.panelFechas.Controls.Add(Me.dtpInicio)
        Me.panelFechas.Controls.Add(Me.checkFecha)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(166, 48)
        Me.panelFechas.TabIndex = 0
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(435, 12)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(75, 23)
        Me.botonActualizar.TabIndex = 10
        Me.botonActualizar.Text = "To Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'dtpFin
        '
        Me.dtpFin.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFin.Location = New System.Drawing.Point(331, 14)
        Me.dtpFin.Name = "dtpFin"
        Me.dtpFin.Size = New System.Drawing.Size(86, 20)
        Me.dtpFin.TabIndex = 9
        '
        'etiquetaFin
        '
        Me.etiquetaFin.AutoSize = True
        Me.etiquetaFin.Location = New System.Drawing.Point(274, 17)
        Me.etiquetaFin.Name = "etiquetaFin"
        Me.etiquetaFin.Size = New System.Drawing.Size(51, 13)
        Me.etiquetaFin.TabIndex = 8
        Me.etiquetaFin.Text = "and Date"
        '
        'dtpInicio
        '
        Me.dtpInicio.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpInicio.Location = New System.Drawing.Point(185, 13)
        Me.dtpInicio.Name = "dtpInicio"
        Me.dtpInicio.Size = New System.Drawing.Size(85, 20)
        Me.dtpInicio.TabIndex = 7
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(10, 17)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(174, 17)
        Me.checkFecha.TabIndex = 6
        Me.checkFecha.Text = "show documents between date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelDocumento.Controls.Add(Me.PanelDetalle)
        Me.panelDocumento.Controls.Add(Me.PanelConcepto)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Location = New System.Drawing.Point(9, 101)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(790, 575)
        Me.panelDocumento.TabIndex = 3
        '
        'PanelDetalle
        '
        Me.PanelDetalle.Controls.Add(Me.DgDetalle)
        Me.PanelDetalle.Controls.Add(Me.PanelBotones)
        Me.PanelDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelDetalle.Location = New System.Drawing.Point(0, 399)
        Me.PanelDetalle.Name = "PanelDetalle"
        Me.PanelDetalle.Size = New System.Drawing.Size(790, 176)
        Me.PanelDetalle.TabIndex = 25
        '
        'DgDetalle
        '
        Me.DgDetalle.AllowUserToAddRows = False
        Me.DgDetalle.AllowUserToDeleteRows = False
        Me.DgDetalle.AllowUserToOrderColumns = True
        Me.DgDetalle.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DgDetalle.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DgDetalle.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DgDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgDetalle.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colLinea, Me.colPrecio, Me.colCuenta, Me.colNombreCuenta, Me.colNCosto, Me.colCentroCosto, Me.colStatus})
        Me.DgDetalle.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgDetalle.Location = New System.Drawing.Point(0, 0)
        Me.DgDetalle.MultiSelect = False
        Me.DgDetalle.Name = "DgDetalle"
        Me.DgDetalle.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgDetalle.Size = New System.Drawing.Size(732, 176)
        Me.DgDetalle.TabIndex = 0
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        Me.colLinea.Width = 72
        '
        'colPrecio
        '
        Me.colPrecio.HeaderText = "Monto"
        Me.colPrecio.Name = "colPrecio"
        Me.colPrecio.Width = 62
        '
        'colCuenta
        '
        Me.colCuenta.HeaderText = "Account"
        Me.colCuenta.Name = "colCuenta"
        Me.colCuenta.ReadOnly = True
        Me.colCuenta.Visible = False
        Me.colCuenta.Width = 88
        '
        'colNombreCuenta
        '
        Me.colNombreCuenta.HeaderText = "Name Account"
        Me.colNombreCuenta.Name = "colNombreCuenta"
        Me.colNombreCuenta.ReadOnly = True
        Me.colNombreCuenta.Width = 95
        '
        'colNCosto
        '
        Me.colNCosto.HeaderText = "Costo"
        Me.colNCosto.Name = "colNCosto"
        Me.colNCosto.ReadOnly = True
        Me.colNCosto.Visible = False
        Me.colNCosto.Width = 73
        '
        'colCentroCosto
        '
        Me.colCentroCosto.HeaderText = "Cost Center"
        Me.colCentroCosto.Name = "colCentroCosto"
        Me.colCentroCosto.ReadOnly = True
        Me.colCentroCosto.Width = 80
        '
        'colStatus
        '
        Me.colStatus.HeaderText = "Estado"
        Me.colStatus.Name = "colStatus"
        Me.colStatus.Visible = False
        Me.colStatus.Width = 81
        '
        'PanelBotones
        '
        Me.PanelBotones.Controls.Add(Me.BotonEliminar)
        Me.PanelBotones.Controls.Add(Me.botonAgregar)
        Me.PanelBotones.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelBotones.Location = New System.Drawing.Point(732, 0)
        Me.PanelBotones.Name = "PanelBotones"
        Me.PanelBotones.Size = New System.Drawing.Size(58, 176)
        Me.PanelBotones.TabIndex = 1
        '
        'BotonEliminar
        '
        Me.BotonEliminar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.BotonEliminar.Location = New System.Drawing.Point(13, 42)
        Me.BotonEliminar.Name = "BotonEliminar"
        Me.BotonEliminar.Size = New System.Drawing.Size(37, 23)
        Me.BotonEliminar.TabIndex = 1
        Me.BotonEliminar.UseVisualStyleBackColor = True
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregar.Location = New System.Drawing.Point(13, 13)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(37, 23)
        Me.botonAgregar.TabIndex = 0
        Me.botonAgregar.UseVisualStyleBackColor = True
        '
        'PanelConcepto
        '
        Me.PanelConcepto.Controls.Add(Me.celdaConcepto)
        Me.PanelConcepto.Controls.Add(Me.etiquetaAbono)
        Me.PanelConcepto.Controls.Add(Me.etiquetaConcepto)
        Me.PanelConcepto.Controls.Add(Me.celdaAbono)
        Me.PanelConcepto.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelConcepto.Location = New System.Drawing.Point(0, 307)
        Me.PanelConcepto.Name = "PanelConcepto"
        Me.PanelConcepto.Size = New System.Drawing.Size(790, 92)
        Me.PanelConcepto.TabIndex = 24
        '
        'celdaConcepto
        '
        Me.celdaConcepto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaConcepto.Location = New System.Drawing.Point(8, 28)
        Me.celdaConcepto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaConcepto.Multiline = True
        Me.celdaConcepto.Name = "celdaConcepto"
        Me.celdaConcepto.Size = New System.Drawing.Size(354, 54)
        Me.celdaConcepto.TabIndex = 20
        '
        'etiquetaAbono
        '
        Me.etiquetaAbono.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaAbono.AutoSize = True
        Me.etiquetaAbono.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaAbono.Location = New System.Drawing.Point(521, 8)
        Me.etiquetaAbono.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAbono.Name = "etiquetaAbono"
        Me.etiquetaAbono.Size = New System.Drawing.Size(64, 17)
        Me.etiquetaAbono.TabIndex = 22
        Me.etiquetaAbono.Text = "Pay For"
        '
        'etiquetaConcepto
        '
        Me.etiquetaConcepto.AutoSize = True
        Me.etiquetaConcepto.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaConcepto.Location = New System.Drawing.Point(19, 8)
        Me.etiquetaConcepto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaConcepto.Name = "etiquetaConcepto"
        Me.etiquetaConcepto.Size = New System.Drawing.Size(67, 17)
        Me.etiquetaConcepto.TabIndex = 21
        Me.etiquetaConcepto.Text = "Concept"
        '
        'celdaAbono
        '
        Me.celdaAbono.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAbono.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaAbono.Location = New System.Drawing.Point(524, 28)
        Me.celdaAbono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAbono.Name = "celdaAbono"
        Me.celdaAbono.ReadOnly = True
        Me.celdaAbono.Size = New System.Drawing.Size(98, 21)
        Me.celdaAbono.TabIndex = 20
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.gbFacturas)
        Me.panelEncabezado.Controls.Add(Me.gbEncabezado)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(790, 307)
        Me.panelEncabezado.TabIndex = 0
        '
        'gbFacturas
        '
        Me.gbFacturas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFacturas.Controls.Add(Me.panelImpuesto)
        Me.gbFacturas.Controls.Add(Me.celdaReferencia)
        Me.gbFacturas.Controls.Add(Me.etiquetaPoliza)
        Me.gbFacturas.Controls.Add(Me.botonPolizaC)
        Me.gbFacturas.Controls.Add(Me.dgFacturas)
        Me.gbFacturas.Controls.Add(Me.botonEliminaFactura)
        Me.gbFacturas.Controls.Add(Me.botonAgregarFactura)
        Me.gbFacturas.Location = New System.Drawing.Point(518, 2)
        Me.gbFacturas.Margin = New System.Windows.Forms.Padding(2)
        Me.gbFacturas.Name = "gbFacturas"
        Me.gbFacturas.Padding = New System.Windows.Forms.Padding(2)
        Me.gbFacturas.Size = New System.Drawing.Size(268, 302)
        Me.gbFacturas.TabIndex = 1
        Me.gbFacturas.TabStop = False
        Me.gbFacturas.Text = "Invoice"
        '
        'panelImpuesto
        '
        Me.panelImpuesto.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.panelImpuesto.Controls.Add(Me.DgImpuesto)
        Me.panelImpuesto.Location = New System.Drawing.Point(5, 189)
        Me.panelImpuesto.Name = "panelImpuesto"
        Me.panelImpuesto.Size = New System.Drawing.Size(110, 108)
        Me.panelImpuesto.TabIndex = 33
        '
        'DgImpuesto
        '
        Me.DgImpuesto.AllowUserToAddRows = False
        Me.DgImpuesto.AllowUserToDeleteRows = False
        Me.DgImpuesto.AllowUserToOrderColumns = True
        Me.DgImpuesto.BackgroundColor = System.Drawing.SystemColors.Control
        Me.DgImpuesto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgImpuesto.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colMonto, Me.colImpuesto, Me.colCosto, Me.colMarca})
        Me.DgImpuesto.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DgImpuesto.Location = New System.Drawing.Point(0, 0)
        Me.DgImpuesto.MultiSelect = False
        Me.DgImpuesto.Name = "DgImpuesto"
        Me.DgImpuesto.ReadOnly = True
        Me.DgImpuesto.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DgImpuesto.Size = New System.Drawing.Size(110, 108)
        Me.DgImpuesto.TabIndex = 0
        '
        'colMonto
        '
        Me.colMonto.HeaderText = "Base"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        '
        'colImpuesto
        '
        Me.colImpuesto.HeaderText = "IVA"
        Me.colImpuesto.Name = "colImpuesto"
        Me.colImpuesto.ReadOnly = True
        '
        'colCosto
        '
        Me.colCosto.HeaderText = "Total"
        Me.colCosto.Name = "colCosto"
        Me.colCosto.ReadOnly = True
        '
        'colMarca
        '
        Me.colMarca.HeaderText = "Estado"
        Me.colMarca.Name = "colMarca"
        Me.colMarca.ReadOnly = True
        Me.colMarca.Visible = False
        '
        'celdaReferencia
        '
        Me.celdaReferencia.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaReferencia.Location = New System.Drawing.Point(122, 208)
        Me.celdaReferencia.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaReferencia.Name = "celdaReferencia"
        Me.celdaReferencia.Size = New System.Drawing.Size(98, 20)
        Me.celdaReferencia.TabIndex = 23
        Me.celdaReferencia.Visible = False
        '
        'etiquetaPoliza
        '
        Me.etiquetaPoliza.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaPoliza.AutoSize = True
        Me.etiquetaPoliza.Location = New System.Drawing.Point(128, 252)
        Me.etiquetaPoliza.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaPoliza.Name = "etiquetaPoliza"
        Me.etiquetaPoliza.Size = New System.Drawing.Size(69, 13)
        Me.etiquetaPoliza.TabIndex = 20
        Me.etiquetaPoliza.Text = "Check Policy"
        '
        'botonPolizaC
        '
        Me.botonPolizaC.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonPolizaC.Image = Global.KARIMs_SGI.My.Resources.Resources.book_open1
        Me.botonPolizaC.Location = New System.Drawing.Point(206, 245)
        Me.botonPolizaC.Name = "botonPolizaC"
        Me.botonPolizaC.Size = New System.Drawing.Size(33, 28)
        Me.botonPolizaC.TabIndex = 32
        Me.botonPolizaC.UseVisualStyleBackColor = True
        '
        'dgFacturas
        '
        Me.dgFacturas.AllowUserToAddRows = False
        Me.dgFacturas.AllowUserToDeleteRows = False
        Me.dgFacturas.AllowUserToOrderColumns = True
        Me.dgFacturas.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgFacturas.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgFacturas.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgFacturas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgFacturas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFacturas.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnioF, Me.colNumeroF, Me.colFechaF, Me.colUsuarioF, Me.colReferenciaF, Me.colExtraF, Me.colFechaVence, Me.colDocumento, Me.colExenta})
        Me.dgFacturas.Location = New System.Drawing.Point(4, 17)
        Me.dgFacturas.Margin = New System.Windows.Forms.Padding(2)
        Me.dgFacturas.MultiSelect = False
        Me.dgFacturas.Name = "dgFacturas"
        Me.dgFacturas.RowTemplate.Height = 24
        Me.dgFacturas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFacturas.Size = New System.Drawing.Size(214, 167)
        Me.dgFacturas.TabIndex = 14
        '
        'colAnioF
        '
        Me.colAnioF.HeaderText = "Year"
        Me.colAnioF.Name = "colAnioF"
        Me.colAnioF.ReadOnly = True
        Me.colAnioF.Visible = False
        Me.colAnioF.Width = 67
        '
        'colNumeroF
        '
        Me.colNumeroF.HeaderText = "Number"
        Me.colNumeroF.Name = "colNumeroF"
        Me.colNumeroF.ReadOnly = True
        Me.colNumeroF.Width = 69
        '
        'colFechaF
        '
        Me.colFechaF.HeaderText = "Date"
        Me.colFechaF.Name = "colFechaF"
        Me.colFechaF.ReadOnly = True
        Me.colFechaF.Width = 55
        '
        'colUsuarioF
        '
        Me.colUsuarioF.HeaderText = "User"
        Me.colUsuarioF.Name = "colUsuarioF"
        Me.colUsuarioF.ReadOnly = True
        Me.colUsuarioF.Width = 54
        '
        'colReferenciaF
        '
        Me.colReferenciaF.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colReferenciaF.HeaderText = "Reference"
        Me.colReferenciaF.Name = "colReferenciaF"
        Me.colReferenciaF.ReadOnly = True
        Me.colReferenciaF.Width = 82
        '
        'colExtraF
        '
        Me.colExtraF.HeaderText = "Extra"
        Me.colExtraF.Name = "colExtraF"
        Me.colExtraF.ReadOnly = True
        Me.colExtraF.Visible = False
        Me.colExtraF.Width = 69
        '
        'colFechaVence
        '
        Me.colFechaVence.HeaderText = "Vencimiento"
        Me.colFechaVence.Name = "colFechaVence"
        Me.colFechaVence.Visible = False
        Me.colFechaVence.Width = 114
        '
        'colDocumento
        '
        Me.colDocumento.HeaderText = "Documento"
        Me.colDocumento.Name = "colDocumento"
        Me.colDocumento.Visible = False
        Me.colDocumento.Width = 109
        '
        'colExenta
        '
        Me.colExenta.HeaderText = "Documento Ex"
        Me.colExenta.Name = "colExenta"
        Me.colExenta.Visible = False
        Me.colExenta.Width = 128
        '
        'botonEliminaFactura
        '
        Me.botonEliminaFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonEliminaFactura.Enabled = False
        Me.botonEliminaFactura.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonEliminaFactura.Location = New System.Drawing.Point(224, 98)
        Me.botonEliminaFactura.Name = "botonEliminaFactura"
        Me.botonEliminaFactura.Size = New System.Drawing.Size(32, 39)
        Me.botonEliminaFactura.TabIndex = 13
        Me.botonEliminaFactura.UseVisualStyleBackColor = True
        '
        'botonAgregarFactura
        '
        Me.botonAgregarFactura.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonAgregarFactura.BackColor = System.Drawing.SystemColors.Control
        Me.botonAgregarFactura.Enabled = False
        Me.botonAgregarFactura.Image = Global.KARIMs_SGI.My.Resources.Resources.add
        Me.botonAgregarFactura.Location = New System.Drawing.Point(224, 44)
        Me.botonAgregarFactura.Name = "botonAgregarFactura"
        Me.botonAgregarFactura.Size = New System.Drawing.Size(32, 38)
        Me.botonAgregarFactura.TabIndex = 12
        Me.botonAgregarFactura.UseVisualStyleBackColor = False
        '
        'gbEncabezado
        '
        Me.gbEncabezado.Controls.Add(Me.etiquetaSerie)
        Me.gbEncabezado.Controls.Add(Me.celdaSerie2)
        Me.gbEncabezado.Controls.Add(Me.Label1)
        Me.gbEncabezado.Controls.Add(Me.celdaCorrelativo)
        Me.gbEncabezado.Controls.Add(Me.celdaTemporal)
        Me.gbEncabezado.Controls.Add(Me.etiquetaDocumento)
        Me.gbEncabezado.Controls.Add(Me.botonSerie)
        Me.gbEncabezado.Controls.Add(Me.celdaSerie)
        Me.gbEncabezado.Controls.Add(Me.botonProveedor)
        Me.gbEncabezado.Controls.Add(Me.celdaIDMoneda)
        Me.gbEncabezado.Controls.Add(Me.botonMoneda)
        Me.gbEncabezado.Controls.Add(Me.etiquetaTasa)
        Me.gbEncabezado.Controls.Add(Me.celdaTasa)
        Me.gbEncabezado.Controls.Add(Me.celdaUsuario)
        Me.gbEncabezado.Controls.Add(Me.celdaIdProveedor)
        Me.gbEncabezado.Controls.Add(Me.checkActivo)
        Me.gbEncabezado.Controls.Add(Me.dtFechaDoc)
        Me.gbEncabezado.Controls.Add(Me.celdaMoneda)
        Me.gbEncabezado.Controls.Add(Me.celdaNit)
        Me.gbEncabezado.Controls.Add(Me.celdaTelefono)
        Me.gbEncabezado.Controls.Add(Me.celdaDireccion)
        Me.gbEncabezado.Controls.Add(Me.celdaProveedor)
        Me.gbEncabezado.Controls.Add(Me.celdaNumero)
        Me.gbEncabezado.Controls.Add(Me.celdaAnio)
        Me.gbEncabezado.Controls.Add(Me.etiquetaFecha)
        Me.gbEncabezado.Controls.Add(Me.etiquetaDireccion)
        Me.gbEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.gbEncabezado.Controls.Add(Me.etiquetaNit)
        Me.gbEncabezado.Controls.Add(Me.etiquetaTelefono)
        Me.gbEncabezado.Controls.Add(Me.etiquetaProveedor)
        Me.gbEncabezado.Controls.Add(Me.etiquetaNumero)
        Me.gbEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.gbEncabezado.Location = New System.Drawing.Point(2, 2)
        Me.gbEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.gbEncabezado.Name = "gbEncabezado"
        Me.gbEncabezado.Padding = New System.Windows.Forms.Padding(2)
        Me.gbEncabezado.Size = New System.Drawing.Size(511, 302)
        Me.gbEncabezado.TabIndex = 0
        Me.gbEncabezado.TabStop = False
        Me.gbEncabezado.Text = "Document Data"
        '
        'celdaSerie2
        '
        Me.celdaSerie2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSerie2.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSerie2.Location = New System.Drawing.Point(254, 43)
        Me.celdaSerie2.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSerie2.Name = "celdaSerie2"
        Me.celdaSerie2.Size = New System.Drawing.Size(152, 20)
        Me.celdaSerie2.TabIndex = 36
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(14, 44)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Number"
        '
        'celdaCorrelativo
        '
        Me.celdaCorrelativo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaCorrelativo.BackColor = System.Drawing.SystemColors.Info
        Me.celdaCorrelativo.Location = New System.Drawing.Point(76, 43)
        Me.celdaCorrelativo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCorrelativo.Name = "celdaCorrelativo"
        Me.celdaCorrelativo.Size = New System.Drawing.Size(174, 20)
        Me.celdaCorrelativo.TabIndex = 34
        '
        'celdaTemporal
        '
        Me.celdaTemporal.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTemporal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTemporal.Location = New System.Drawing.Point(76, 64)
        Me.celdaTemporal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTemporal.Name = "celdaTemporal"
        Me.celdaTemporal.Size = New System.Drawing.Size(174, 20)
        Me.celdaTemporal.TabIndex = 33
        Me.celdaTemporal.Visible = False
        '
        'etiquetaDocumento
        '
        Me.etiquetaDocumento.AutoSize = True
        Me.etiquetaDocumento.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.etiquetaDocumento.Location = New System.Drawing.Point(292, 67)
        Me.etiquetaDocumento.Name = "etiquetaDocumento"
        Me.etiquetaDocumento.Size = New System.Drawing.Size(39, 13)
        Me.etiquetaDocumento.TabIndex = 32
        Me.etiquetaDocumento.Text = "Label1"
        '
        'botonSerie
        '
        Me.botonSerie.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonSerie.Location = New System.Drawing.Point(411, 42)
        Me.botonSerie.Name = "botonSerie"
        Me.botonSerie.Size = New System.Drawing.Size(26, 20)
        Me.botonSerie.TabIndex = 31
        Me.botonSerie.Text = "..."
        Me.botonSerie.UseVisualStyleBackColor = True
        Me.botonSerie.Visible = False
        '
        'celdaSerie
        '
        Me.celdaSerie.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaSerie.BackColor = System.Drawing.SystemColors.Info
        Me.celdaSerie.Location = New System.Drawing.Point(254, 43)
        Me.celdaSerie.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaSerie.Name = "celdaSerie"
        Me.celdaSerie.ReadOnly = True
        Me.celdaSerie.Size = New System.Drawing.Size(152, 20)
        Me.celdaSerie.TabIndex = 30
        Me.celdaSerie.Visible = False
        '
        'botonProveedor
        '
        Me.botonProveedor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonProveedor.Location = New System.Drawing.Point(464, 116)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(26, 20)
        Me.botonProveedor.TabIndex = 28
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(254, 279)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(20, 20)
        Me.celdaIDMoneda.TabIndex = 27
        Me.celdaIDMoneda.Text = "-1"
        Me.celdaIDMoneda.Visible = False
        '
        'botonMoneda
        '
        Me.botonMoneda.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.botonMoneda.Location = New System.Drawing.Point(208, 277)
        Me.botonMoneda.Name = "botonMoneda"
        Me.botonMoneda.Size = New System.Drawing.Size(26, 20)
        Me.botonMoneda.TabIndex = 26
        Me.botonMoneda.Text = "..."
        Me.botonMoneda.UseVisualStyleBackColor = True
        '
        'etiquetaTasa
        '
        Me.etiquetaTasa.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaTasa.AutoSize = True
        Me.etiquetaTasa.Location = New System.Drawing.Point(343, 279)
        Me.etiquetaTasa.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTasa.Name = "etiquetaTasa"
        Me.etiquetaTasa.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaTasa.TabIndex = 19
        Me.etiquetaTasa.Text = "Rate"
        '
        'celdaTasa
        '
        Me.celdaTasa.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTasa.Location = New System.Drawing.Point(392, 277)
        Me.celdaTasa.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTasa.Name = "celdaTasa"
        Me.celdaTasa.Size = New System.Drawing.Size(67, 20)
        Me.celdaTasa.TabIndex = 18
        '
        'celdaUsuario
        '
        Me.celdaUsuario.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaUsuario.Location = New System.Drawing.Point(466, 24)
        Me.celdaUsuario.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaUsuario.Name = "celdaUsuario"
        Me.celdaUsuario.Size = New System.Drawing.Size(36, 20)
        Me.celdaUsuario.TabIndex = 17
        Me.celdaUsuario.Visible = False
        '
        'celdaIdProveedor
        '
        Me.celdaIdProveedor.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaIdProveedor.Location = New System.Drawing.Point(280, 91)
        Me.celdaIdProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdProveedor.Name = "celdaIdProveedor"
        Me.celdaIdProveedor.Size = New System.Drawing.Size(36, 20)
        Me.celdaIdProveedor.TabIndex = 16
        Me.celdaIdProveedor.Visible = False
        '
        'checkActivo
        '
        Me.checkActivo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(402, 17)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 15
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'dtFechaDoc
        '
        Me.dtFechaDoc.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dtFechaDoc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtFechaDoc.Location = New System.Drawing.Point(76, 91)
        Me.dtFechaDoc.Margin = New System.Windows.Forms.Padding(2)
        Me.dtFechaDoc.Name = "dtFechaDoc"
        Me.dtFechaDoc.Size = New System.Drawing.Size(174, 20)
        Me.dtFechaDoc.TabIndex = 14
        '
        'celdaMoneda
        '
        Me.celdaMoneda.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaMoneda.Location = New System.Drawing.Point(75, 277)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(129, 20)
        Me.celdaMoneda.TabIndex = 13
        '
        'celdaNit
        '
        Me.celdaNit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNit.Location = New System.Drawing.Point(75, 242)
        Me.celdaNit.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNit.Name = "celdaNit"
        Me.celdaNit.Size = New System.Drawing.Size(240, 20)
        Me.celdaNit.TabIndex = 13
        '
        'celdaTelefono
        '
        Me.celdaTelefono.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTelefono.Location = New System.Drawing.Point(73, 208)
        Me.celdaTelefono.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTelefono.Name = "celdaTelefono"
        Me.celdaTelefono.Size = New System.Drawing.Size(240, 20)
        Me.celdaTelefono.TabIndex = 12
        '
        'celdaDireccion
        '
        Me.celdaDireccion.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaDireccion.Location = New System.Drawing.Point(75, 154)
        Me.celdaDireccion.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaDireccion.Multiline = True
        Me.celdaDireccion.Name = "celdaDireccion"
        Me.celdaDireccion.Size = New System.Drawing.Size(384, 44)
        Me.celdaDireccion.TabIndex = 11
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaProveedor.Location = New System.Drawing.Point(75, 119)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(384, 20)
        Me.celdaProveedor.TabIndex = 10
        '
        'celdaNumero
        '
        Me.celdaNumero.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaNumero.BackColor = System.Drawing.SystemColors.Info
        Me.celdaNumero.Location = New System.Drawing.Point(76, 64)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.ReadOnly = True
        Me.celdaNumero.Size = New System.Drawing.Size(174, 20)
        Me.celdaNumero.TabIndex = 9
        '
        'celdaAnio
        '
        Me.celdaAnio.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaAnio.BackColor = System.Drawing.SystemColors.Info
        Me.celdaAnio.Location = New System.Drawing.Point(76, 22)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(174, 20)
        Me.celdaAnio.TabIndex = 8
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(13, 94)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFecha.TabIndex = 7
        Me.etiquetaFecha.Text = "Date"
        '
        'etiquetaDireccion
        '
        Me.etiquetaDireccion.AutoSize = True
        Me.etiquetaDireccion.Location = New System.Drawing.Point(10, 154)
        Me.etiquetaDireccion.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaDireccion.Name = "etiquetaDireccion"
        Me.etiquetaDireccion.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaDireccion.TabIndex = 6
        Me.etiquetaDireccion.Text = "Address"
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(13, 279)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(28, 13)
        Me.etiquetaMoneda.TabIndex = 5
        Me.etiquetaMoneda.Text = "Coin"
        '
        'etiquetaNit
        '
        Me.etiquetaNit.AutoSize = True
        Me.etiquetaNit.Location = New System.Drawing.Point(10, 245)
        Me.etiquetaNit.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNit.Name = "etiquetaNit"
        Me.etiquetaNit.Size = New System.Drawing.Size(25, 13)
        Me.etiquetaNit.TabIndex = 4
        Me.etiquetaNit.Text = "NIT"
        '
        'etiquetaTelefono
        '
        Me.etiquetaTelefono.AutoSize = True
        Me.etiquetaTelefono.Location = New System.Drawing.Point(10, 211)
        Me.etiquetaTelefono.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTelefono.Name = "etiquetaTelefono"
        Me.etiquetaTelefono.Size = New System.Drawing.Size(38, 13)
        Me.etiquetaTelefono.TabIndex = 3
        Me.etiquetaTelefono.Text = "Phone"
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(10, 119)
        Me.etiquetaProveedor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaProveedor.TabIndex = 2
        Me.etiquetaProveedor.Text = "Supplier"
        '
        'etiquetaNumero
        '
        Me.etiquetaNumero.AutoSize = True
        Me.etiquetaNumero.Location = New System.Drawing.Point(13, 68)
        Me.etiquetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaNumero.Name = "etiquetaNumero"
        Me.etiquetaNumero.Size = New System.Drawing.Size(18, 13)
        Me.etiquetaNumero.TabIndex = 1
        Me.etiquetaNumero.Text = "ID"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(14, 22)
        Me.etiquetaAnio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 60)
        Me.BarraTitulo1.Margin = New System.Windows.Forms.Padding(4)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(1033, 27)
        Me.BarraTitulo1.TabIndex = 2
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Margin = New System.Windows.Forms.Padding(4)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(1033, 60)
        Me.Encabezado1.TabIndex = 0
        '
        'etiquetaSerie
        '
        Me.etiquetaSerie.AutoSize = True
        Me.etiquetaSerie.Location = New System.Drawing.Point(292, 22)
        Me.etiquetaSerie.Name = "etiquetaSerie"
        Me.etiquetaSerie.Size = New System.Drawing.Size(36, 13)
        Me.etiquetaSerie.TabIndex = 37
        Me.etiquetaSerie.Text = "Series"
        '
        'frmNotasCreditoProveedor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1033, 731)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelListaPrincipal)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmNotasCreditoProveedor"
        Me.Text = "Notas De Credito Proveedor"
        Me.panelListaPrincipal.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.PanelDetalle.ResumeLayout(False)
        CType(Me.DgDetalle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelBotones.ResumeLayout(False)
        Me.PanelConcepto.ResumeLayout(False)
        Me.PanelConcepto.PerformLayout()
        Me.panelEncabezado.ResumeLayout(False)
        Me.gbFacturas.ResumeLayout(False)
        Me.gbFacturas.PerformLayout()
        Me.panelImpuesto.ResumeLayout(False)
        CType(Me.DgImpuesto, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgFacturas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbEncabezado.ResumeLayout(False)
        Me.gbEncabezado.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents panelListaPrincipal As Panel
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelFechas As Panel
    Friend WithEvents botonActualizar As Button
    Friend WithEvents dtpFin As DateTimePicker
    Friend WithEvents etiquetaFin As Label
    Friend WithEvents dtpInicio As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents gbEncabezado As GroupBox
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents etiquetaNumero As Label
    Friend WithEvents etiquetaTelefono As Label
    Friend WithEvents etiquetaNit As Label
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents etiquetaDireccion As Label
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents celdaTelefono As TextBox
    Friend WithEvents celdaDireccion As TextBox
    Friend WithEvents celdaNit As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents dtFechaDoc As DateTimePicker
    Friend WithEvents celdaIdProveedor As TextBox
    Friend WithEvents celdaUsuario As TextBox
    Friend WithEvents celdaTasa As TextBox
    Friend WithEvents etiquetaTasa As Label
    Friend WithEvents gbFacturas As GroupBox
    Friend WithEvents dgFacturas As DataGridView
    Friend WithEvents botonEliminaFactura As Button
    Friend WithEvents botonAgregarFactura As Button
    Friend WithEvents celdaAbono As TextBox
    Friend WithEvents celdaConcepto As TextBox
    Friend WithEvents etiquetaAbono As Label
    Friend WithEvents etiquetaConcepto As Label
    Friend WithEvents etiquetaPoliza As Label
    Friend WithEvents botonPolizaC As Button
    Friend WithEvents celdaIDMoneda As TextBox
    Friend WithEvents botonMoneda As Button
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaReferencia As TextBox
    Friend WithEvents panelImpuesto As Panel
    Friend WithEvents DgImpuesto As DataGridView
    Friend WithEvents botonSerie As Button
    Friend WithEvents celdaSerie As TextBox
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colImpuesto As DataGridViewTextBoxColumn
    Friend WithEvents colCosto As DataGridViewTextBoxColumn
    Friend WithEvents colMarca As DataGridViewTextBoxColumn
    Friend WithEvents DgDetalle As DataGridView
    Friend WithEvents PanelBotones As Panel
    Friend WithEvents BotonEliminar As Button
    Friend WithEvents botonAgregar As Button
    Friend WithEvents PanelDetalle As Panel
    Friend WithEvents PanelConcepto As Panel
    Friend WithEvents etiquetaDocumento As Label
    Friend WithEvents colLinea As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colPrecio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCuenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNombreCuenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCentroCosto As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colStatus As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colAnioF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumeroF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFechaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colUsuarioF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferenciaF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExtraF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFechaVence As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colDocumento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colExenta As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaTemporal As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents celdaCorrelativo As System.Windows.Forms.TextBox
    Friend WithEvents colAnio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colNumero2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colFecha As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colProveedor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colReferencia As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colCorrelativo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents colEstado As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents celdaSerie2 As System.Windows.Forms.TextBox
    Friend WithEvents etiquetaSerie As Label
End Class
