﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmRetenIVAProveedor
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRetenIVAProveedor))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.panelLista = New System.Windows.Forms.Panel()
        Me.dgLista = New System.Windows.Forms.DataGridView()
        Me.colAnio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumero = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colId = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFecha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFactura = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.catalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEstado = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelFechas = New System.Windows.Forms.Panel()
        Me.botonActualizar = New System.Windows.Forms.Button()
        Me.etiquetaFecha = New System.Windows.Forms.Label()
        Me.dtpFechaFinal = New System.Windows.Forms.DateTimePicker()
        Me.dtpFechaInicial = New System.Windows.Forms.DateTimePicker()
        Me.checkFecha = New System.Windows.Forms.CheckBox()
        Me.panelDocumento = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.botonAgregar = New System.Windows.Forms.Button()
        Me.botonQuitar = New System.Windows.Forms.Button()
        Me.gbFacturas = New System.Windows.Forms.GroupBox()
        Me.dgFactura = New System.Windows.Forms.DataGridView()
        Me.panelEncabezado = New System.Windows.Forms.Panel()
        Me.gbPagos = New System.Windows.Forms.GroupBox()
        Me.dgDatos = New System.Windows.Forms.DataGridView()
        Me.colCheque = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaDoc = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMoneda = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTasa = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colBanco = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTota1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.gbEncabezado = New System.Windows.Forms.GroupBox()
        Me.celdaRecibos = New System.Windows.Forms.TextBox()
        Me.dtpFechaPolizaC = New System.Windows.Forms.DateTimePicker()
        Me.checkActivo = New System.Windows.Forms.CheckBox()
        Me.etiquetaFecha1 = New System.Windows.Forms.Label()
        Me.checkFacturaEspecial = New System.Windows.Forms.CheckBox()
        Me.celdaIDMoneda = New System.Windows.Forms.TextBox()
        Me.celdaTCFactura = New System.Windows.Forms.TextBox()
        Me.etiquetaTipoCambio = New System.Windows.Forms.Label()
        Me.celdaTipoCambio = New System.Windows.Forms.TextBox()
        Me.celdaMoneda = New System.Windows.Forms.TextBox()
        Me.etiquetaMoneda = New System.Windows.Forms.Label()
        Me.celdaMontoF = New System.Windows.Forms.TextBox()
        Me.celdaAnioF = New System.Windows.Forms.TextBox()
        Me.celdaNumF = New System.Windows.Forms.TextBox()
        Me.celdaCatF = New System.Windows.Forms.TextBox()
        Me.celdaIdProveedor = New System.Windows.Forms.TextBox()
        Me.botonPoliza = New System.Windows.Forms.Button()
        Me.botonProveedor = New System.Windows.Forms.Button()
        Me.celdaNumeroHDR = New System.Windows.Forms.TextBox()
        Me.celdaAnioOc = New System.Windows.Forms.TextBox()
        Me.celdaCatalogo = New System.Windows.Forms.TextBox()
        Me.dtpFechaDoc = New System.Windows.Forms.DateTimePicker()
        Me.celdaMonto = New System.Windows.Forms.TextBox()
        Me.celdaProveedor = New System.Windows.Forms.TextBox()
        Me.celdaNumero = New System.Windows.Forms.TextBox()
        Me.celdaAnio = New System.Windows.Forms.TextBox()
        Me.etiquetaMonto = New System.Windows.Forms.Label()
        Me.etiquetaProveedor = New System.Windows.Forms.Label()
        Me.etqiuetaNumero = New System.Windows.Forms.Label()
        Me.etiquetaFechaDoc = New System.Windows.Forms.Label()
        Me.etiquetaAnio = New System.Windows.Forms.Label()
        Me.panelTotal = New System.Windows.Forms.Panel()
        Me.celdaTotal = New System.Windows.Forms.TextBox()
        Me.etiquetaSaldo = New System.Windows.Forms.Label()
        Me.BarraTitulo1 = New KARIMs_SGI.BarraTitulo()
        Me.Encabezado1 = New KARIMs_SGI.encabezado()
        Me.colAnioFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colFechaFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colNumeroFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colUsuarioFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colREferenciaFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTotalFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colMonedaFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colTCFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colEspecialFac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colCatalogo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colExtraFact = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colIva = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.colLinea = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.panelLista.SuspendLayout()
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelFechas.SuspendLayout()
        Me.panelDocumento.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.gbFacturas.SuspendLayout()
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panelEncabezado.SuspendLayout()
        Me.gbPagos.SuspendLayout()
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbEncabezado.SuspendLayout()
        Me.panelTotal.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelLista
        '
        Me.panelLista.Controls.Add(Me.dgLista)
        Me.panelLista.Controls.Add(Me.panelFechas)
        Me.panelLista.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelLista.Location = New System.Drawing.Point(0, 86)
        Me.panelLista.Margin = New System.Windows.Forms.Padding(2)
        Me.panelLista.Name = "panelLista"
        Me.panelLista.Size = New System.Drawing.Size(907, 84)
        Me.panelLista.TabIndex = 2
        '
        'dgLista
        '
        Me.dgLista.AllowUserToAddRows = False
        Me.dgLista.AllowUserToDeleteRows = False
        Me.dgLista.AllowUserToOrderColumns = True
        Me.dgLista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgLista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnio, Me.colNumero, Me.colId, Me.colFecha, Me.colNombre, Me.colMonto, Me.colFactura, Me.colTotal, Me.catalogo, Me.colEstado})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgLista.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgLista.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgLista.Location = New System.Drawing.Point(0, 36)
        Me.dgLista.Margin = New System.Windows.Forms.Padding(2)
        Me.dgLista.MultiSelect = False
        Me.dgLista.Name = "dgLista"
        Me.dgLista.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgLista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgLista.RowTemplate.Height = 24
        Me.dgLista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgLista.Size = New System.Drawing.Size(907, 48)
        Me.dgLista.TabIndex = 0
        '
        'colAnio
        '
        Me.colAnio.HeaderText = "Year"
        Me.colAnio.Name = "colAnio"
        Me.colAnio.ReadOnly = True
        Me.colAnio.Visible = False
        '
        'colNumero
        '
        Me.colNumero.HeaderText = "Number"
        Me.colNumero.Name = "colNumero"
        Me.colNumero.ReadOnly = True
        '
        'colId
        '
        Me.colId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colId.HeaderText = "Document"
        Me.colId.Name = "colId"
        Me.colId.ReadOnly = True
        Me.colId.Width = 81
        '
        'colFecha
        '
        Me.colFecha.HeaderText = "Date"
        Me.colFecha.Name = "colFecha"
        Me.colFecha.ReadOnly = True
        '
        'colNombre
        '
        Me.colNombre.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.colNombre.HeaderText = "Supplier"
        Me.colNombre.Name = "colNombre"
        Me.colNombre.ReadOnly = True
        '
        'colMonto
        '
        Me.colMonto.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colMonto.HeaderText = "Amount"
        Me.colMonto.Name = "colMonto"
        Me.colMonto.ReadOnly = True
        Me.colMonto.Width = 68
        '
        'colFactura
        '
        Me.colFactura.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFactura.HeaderText = "Invoice"
        Me.colFactura.Name = "colFactura"
        Me.colFactura.ReadOnly = True
        Me.colFactura.Width = 67
        '
        'colTotal
        '
        Me.colTotal.HeaderText = "Total"
        Me.colTotal.Name = "colTotal"
        Me.colTotal.ReadOnly = True
        Me.colTotal.Visible = False
        '
        'catalogo
        '
        Me.catalogo.HeaderText = "Catalogo"
        Me.catalogo.Name = "catalogo"
        Me.catalogo.ReadOnly = True
        Me.catalogo.Visible = False
        '
        'colEstado
        '
        Me.colEstado.HeaderText = "Estado"
        Me.colEstado.Name = "colEstado"
        Me.colEstado.ReadOnly = True
        Me.colEstado.Visible = False
        '
        'panelFechas
        '
        Me.panelFechas.BackColor = System.Drawing.SystemColors.Info
        Me.panelFechas.Controls.Add(Me.botonActualizar)
        Me.panelFechas.Controls.Add(Me.etiquetaFecha)
        Me.panelFechas.Controls.Add(Me.dtpFechaFinal)
        Me.panelFechas.Controls.Add(Me.dtpFechaInicial)
        Me.panelFechas.Controls.Add(Me.checkFecha)
        Me.panelFechas.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelFechas.Location = New System.Drawing.Point(0, 0)
        Me.panelFechas.Margin = New System.Windows.Forms.Padding(2)
        Me.panelFechas.Name = "panelFechas"
        Me.panelFechas.Size = New System.Drawing.Size(907, 36)
        Me.panelFechas.TabIndex = 1
        '
        'botonActualizar
        '
        Me.botonActualizar.Location = New System.Drawing.Point(418, 5)
        Me.botonActualizar.Margin = New System.Windows.Forms.Padding(2)
        Me.botonActualizar.Name = "botonActualizar"
        Me.botonActualizar.Size = New System.Drawing.Size(62, 24)
        Me.botonActualizar.TabIndex = 4
        Me.botonActualizar.Text = "Update"
        Me.botonActualizar.UseVisualStyleBackColor = True
        '
        'etiquetaFecha
        '
        Me.etiquetaFecha.AutoSize = True
        Me.etiquetaFecha.Location = New System.Drawing.Point(276, 11)
        Me.etiquetaFecha.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha.Name = "etiquetaFecha"
        Me.etiquetaFecha.Size = New System.Drawing.Size(26, 13)
        Me.etiquetaFecha.TabIndex = 3
        Me.etiquetaFecha.Text = "And"
        '
        'dtpFechaFinal
        '
        Me.dtpFechaFinal.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaFinal.Location = New System.Drawing.Point(305, 9)
        Me.dtpFechaFinal.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaFinal.Name = "dtpFechaFinal"
        Me.dtpFechaFinal.Size = New System.Drawing.Size(88, 20)
        Me.dtpFechaFinal.TabIndex = 2
        '
        'dtpFechaInicial
        '
        Me.dtpFechaInicial.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaInicial.Location = New System.Drawing.Point(186, 9)
        Me.dtpFechaInicial.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaInicial.Name = "dtpFechaInicial"
        Me.dtpFechaInicial.Size = New System.Drawing.Size(86, 20)
        Me.dtpFechaInicial.TabIndex = 1
        '
        'checkFecha
        '
        Me.checkFecha.AutoSize = True
        Me.checkFecha.Checked = True
        Me.checkFecha.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFecha.Location = New System.Drawing.Point(9, 10)
        Me.checkFecha.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFecha.Name = "checkFecha"
        Me.checkFecha.Size = New System.Drawing.Size(180, 17)
        Me.checkFecha.TabIndex = 0
        Me.checkFecha.Text = "Show Documents between Date"
        Me.checkFecha.UseVisualStyleBackColor = True
        '
        'panelDocumento
        '
        Me.panelDocumento.Controls.Add(Me.Panel2)
        Me.panelDocumento.Controls.Add(Me.gbFacturas)
        Me.panelDocumento.Controls.Add(Me.panelEncabezado)
        Me.panelDocumento.Controls.Add(Me.panelTotal)
        Me.panelDocumento.Dock = System.Windows.Forms.DockStyle.Fill
        Me.panelDocumento.Location = New System.Drawing.Point(0, 170)
        Me.panelDocumento.Margin = New System.Windows.Forms.Padding(2)
        Me.panelDocumento.Name = "panelDocumento"
        Me.panelDocumento.Size = New System.Drawing.Size(907, 431)
        Me.panelDocumento.TabIndex = 3
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.botonAgregar)
        Me.Panel2.Controls.Add(Me.botonQuitar)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(838, 241)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(69, 109)
        Me.Panel2.TabIndex = 11
        '
        'botonAgregar
        '
        Me.botonAgregar.Image = CType(resources.GetObject("botonAgregar.Image"), System.Drawing.Image)
        Me.botonAgregar.Location = New System.Drawing.Point(17, 27)
        Me.botonAgregar.Name = "botonAgregar"
        Me.botonAgregar.Size = New System.Drawing.Size(26, 24)
        Me.botonAgregar.TabIndex = 8
        Me.botonAgregar.UseVisualStyleBackColor = True
        Me.botonAgregar.Visible = False
        '
        'botonQuitar
        '
        Me.botonQuitar.Image = Global.KARIMs_SGI.My.Resources.Resources.delete3
        Me.botonQuitar.Location = New System.Drawing.Point(16, 63)
        Me.botonQuitar.Name = "botonQuitar"
        Me.botonQuitar.Size = New System.Drawing.Size(27, 24)
        Me.botonQuitar.TabIndex = 9
        Me.botonQuitar.Text = "-"
        Me.botonQuitar.UseVisualStyleBackColor = True
        Me.botonQuitar.Visible = False
        '
        'gbFacturas
        '
        Me.gbFacturas.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.gbFacturas.Controls.Add(Me.dgFactura)
        Me.gbFacturas.Location = New System.Drawing.Point(9, 239)
        Me.gbFacturas.Margin = New System.Windows.Forms.Padding(2)
        Me.gbFacturas.Name = "gbFacturas"
        Me.gbFacturas.Padding = New System.Windows.Forms.Padding(2)
        Me.gbFacturas.Size = New System.Drawing.Size(824, 107)
        Me.gbFacturas.TabIndex = 1
        Me.gbFacturas.TabStop = False
        Me.gbFacturas.Text = "Related Document"
        '
        'dgFactura
        '
        Me.dgFactura.AllowUserToAddRows = False
        Me.dgFactura.AllowUserToDeleteRows = False
        Me.dgFactura.AllowUserToOrderColumns = True
        Me.dgFactura.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactura.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgFactura.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colAnioFac, Me.colFechaFac, Me.colNumeroFac, Me.colUsuarioFac, Me.colREferenciaFac, Me.colTotalFac, Me.colMonedaFac, Me.colTCFac, Me.colEspecialFac, Me.colCatalogo, Me.colExtraFact, Me.colIva, Me.colLinea})
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgFactura.DefaultCellStyle = DataGridViewCellStyle5
        Me.dgFactura.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgFactura.Location = New System.Drawing.Point(2, 15)
        Me.dgFactura.Margin = New System.Windows.Forms.Padding(2)
        Me.dgFactura.Name = "dgFactura"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgFactura.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgFactura.RowTemplate.Height = 24
        Me.dgFactura.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgFactura.Size = New System.Drawing.Size(820, 90)
        Me.dgFactura.TabIndex = 0
        '
        'panelEncabezado
        '
        Me.panelEncabezado.Controls.Add(Me.gbPagos)
        Me.panelEncabezado.Controls.Add(Me.gbEncabezado)
        Me.panelEncabezado.Dock = System.Windows.Forms.DockStyle.Top
        Me.panelEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.panelEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.panelEncabezado.Name = "panelEncabezado"
        Me.panelEncabezado.Size = New System.Drawing.Size(907, 241)
        Me.panelEncabezado.TabIndex = 0
        '
        'gbPagos
        '
        Me.gbPagos.Controls.Add(Me.dgDatos)
        Me.gbPagos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbPagos.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbPagos.Location = New System.Drawing.Point(500, 0)
        Me.gbPagos.Margin = New System.Windows.Forms.Padding(2)
        Me.gbPagos.Name = "gbPagos"
        Me.gbPagos.Padding = New System.Windows.Forms.Padding(2)
        Me.gbPagos.Size = New System.Drawing.Size(407, 241)
        Me.gbPagos.TabIndex = 1
        Me.gbPagos.TabStop = False
        Me.gbPagos.Text = "PAYMENT MADE"
        '
        'dgDatos
        '
        Me.dgDatos.AllowUserToAddRows = False
        Me.dgDatos.AllowUserToDeleteRows = False
        Me.dgDatos.AllowUserToOrderColumns = True
        Me.dgDatos.BackgroundColor = System.Drawing.SystemColors.Control
        Me.dgDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgDatos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.colCheque, Me.colFechaDoc, Me.colMoneda, Me.colTasa, Me.colBanco, Me.colTota1})
        Me.dgDatos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgDatos.Location = New System.Drawing.Point(2, 14)
        Me.dgDatos.Margin = New System.Windows.Forms.Padding(2)
        Me.dgDatos.Name = "dgDatos"
        Me.dgDatos.ReadOnly = True
        Me.dgDatos.RowTemplate.Height = 24
        Me.dgDatos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgDatos.Size = New System.Drawing.Size(403, 225)
        Me.dgDatos.TabIndex = 1
        '
        'colCheque
        '
        Me.colCheque.HeaderText = "Document"
        Me.colCheque.Name = "colCheque"
        Me.colCheque.ReadOnly = True
        '
        'colFechaDoc
        '
        Me.colFechaDoc.HeaderText = "Date"
        Me.colFechaDoc.Name = "colFechaDoc"
        Me.colFechaDoc.ReadOnly = True
        '
        'colMoneda
        '
        Me.colMoneda.HeaderText = "Currency"
        Me.colMoneda.Name = "colMoneda"
        Me.colMoneda.ReadOnly = True
        '
        'colTasa
        '
        Me.colTasa.HeaderText = "Rate"
        Me.colTasa.Name = "colTasa"
        Me.colTasa.ReadOnly = True
        '
        'colBanco
        '
        Me.colBanco.HeaderText = "Bank"
        Me.colBanco.Name = "colBanco"
        Me.colBanco.ReadOnly = True
        '
        'colTota1
        '
        Me.colTota1.HeaderText = "Total"
        Me.colTota1.Name = "colTota1"
        Me.colTota1.ReadOnly = True
        '
        'gbEncabezado
        '
        Me.gbEncabezado.Controls.Add(Me.celdaRecibos)
        Me.gbEncabezado.Controls.Add(Me.dtpFechaPolizaC)
        Me.gbEncabezado.Controls.Add(Me.checkActivo)
        Me.gbEncabezado.Controls.Add(Me.etiquetaFecha1)
        Me.gbEncabezado.Controls.Add(Me.checkFacturaEspecial)
        Me.gbEncabezado.Controls.Add(Me.celdaIDMoneda)
        Me.gbEncabezado.Controls.Add(Me.celdaTCFactura)
        Me.gbEncabezado.Controls.Add(Me.etiquetaTipoCambio)
        Me.gbEncabezado.Controls.Add(Me.celdaTipoCambio)
        Me.gbEncabezado.Controls.Add(Me.celdaMoneda)
        Me.gbEncabezado.Controls.Add(Me.etiquetaMoneda)
        Me.gbEncabezado.Controls.Add(Me.celdaMontoF)
        Me.gbEncabezado.Controls.Add(Me.celdaAnioF)
        Me.gbEncabezado.Controls.Add(Me.celdaNumF)
        Me.gbEncabezado.Controls.Add(Me.celdaCatF)
        Me.gbEncabezado.Controls.Add(Me.celdaIdProveedor)
        Me.gbEncabezado.Controls.Add(Me.botonPoliza)
        Me.gbEncabezado.Controls.Add(Me.botonProveedor)
        Me.gbEncabezado.Controls.Add(Me.celdaNumeroHDR)
        Me.gbEncabezado.Controls.Add(Me.celdaAnioOc)
        Me.gbEncabezado.Controls.Add(Me.celdaCatalogo)
        Me.gbEncabezado.Controls.Add(Me.dtpFechaDoc)
        Me.gbEncabezado.Controls.Add(Me.celdaMonto)
        Me.gbEncabezado.Controls.Add(Me.celdaProveedor)
        Me.gbEncabezado.Controls.Add(Me.celdaNumero)
        Me.gbEncabezado.Controls.Add(Me.celdaAnio)
        Me.gbEncabezado.Controls.Add(Me.etiquetaMonto)
        Me.gbEncabezado.Controls.Add(Me.etiquetaProveedor)
        Me.gbEncabezado.Controls.Add(Me.etqiuetaNumero)
        Me.gbEncabezado.Controls.Add(Me.etiquetaFechaDoc)
        Me.gbEncabezado.Controls.Add(Me.etiquetaAnio)
        Me.gbEncabezado.Dock = System.Windows.Forms.DockStyle.Left
        Me.gbEncabezado.Location = New System.Drawing.Point(0, 0)
        Me.gbEncabezado.Margin = New System.Windows.Forms.Padding(2)
        Me.gbEncabezado.Name = "gbEncabezado"
        Me.gbEncabezado.Padding = New System.Windows.Forms.Padding(2)
        Me.gbEncabezado.Size = New System.Drawing.Size(500, 241)
        Me.gbEncabezado.TabIndex = 0
        Me.gbEncabezado.TabStop = False
        Me.gbEncabezado.Text = "Document data"
        '
        'celdaRecibos
        '
        Me.celdaRecibos.Location = New System.Drawing.Point(372, 170)
        Me.celdaRecibos.Name = "celdaRecibos"
        Me.celdaRecibos.Size = New System.Drawing.Size(33, 20)
        Me.celdaRecibos.TabIndex = 81
        Me.celdaRecibos.Visible = False
        '
        'dtpFechaPolizaC
        '
        Me.dtpFechaPolizaC.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaPolizaC.Location = New System.Drawing.Point(292, 50)
        Me.dtpFechaPolizaC.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaPolizaC.Name = "dtpFechaPolizaC"
        Me.dtpFechaPolizaC.Size = New System.Drawing.Size(91, 20)
        Me.dtpFechaPolizaC.TabIndex = 80
        '
        'checkActivo
        '
        Me.checkActivo.AutoSize = True
        Me.checkActivo.Checked = True
        Me.checkActivo.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkActivo.Location = New System.Drawing.Point(398, 54)
        Me.checkActivo.Margin = New System.Windows.Forms.Padding(2)
        Me.checkActivo.Name = "checkActivo"
        Me.checkActivo.Size = New System.Drawing.Size(56, 17)
        Me.checkActivo.TabIndex = 28
        Me.checkActivo.Text = "Active"
        Me.checkActivo.UseVisualStyleBackColor = True
        '
        'etiquetaFecha1
        '
        Me.etiquetaFecha1.AutoSize = True
        Me.etiquetaFecha1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.etiquetaFecha1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaFecha1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.etiquetaFecha1.Location = New System.Drawing.Point(184, 54)
        Me.etiquetaFecha1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFecha1.Name = "etiquetaFecha1"
        Me.etiquetaFecha1.Size = New System.Drawing.Size(100, 13)
        Me.etiquetaFecha1.TabIndex = 79
        Me.etiquetaFecha1.Text = "Accounting date"
        '
        'checkFacturaEspecial
        '
        Me.checkFacturaEspecial.AutoSize = True
        Me.checkFacturaEspecial.Checked = True
        Me.checkFacturaEspecial.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkFacturaEspecial.Location = New System.Drawing.Point(398, 17)
        Me.checkFacturaEspecial.Margin = New System.Windows.Forms.Padding(2)
        Me.checkFacturaEspecial.Name = "checkFacturaEspecial"
        Me.checkFacturaEspecial.Size = New System.Drawing.Size(99, 17)
        Me.checkFacturaEspecial.TabIndex = 27
        Me.checkFacturaEspecial.Text = "Special Invoice"
        Me.checkFacturaEspecial.UseVisualStyleBackColor = True
        '
        'celdaIDMoneda
        '
        Me.celdaIDMoneda.Location = New System.Drawing.Point(168, 184)
        Me.celdaIDMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIDMoneda.Name = "celdaIDMoneda"
        Me.celdaIDMoneda.Size = New System.Drawing.Size(50, 20)
        Me.celdaIDMoneda.TabIndex = 26
        Me.celdaIDMoneda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.celdaIDMoneda.Visible = False
        '
        'celdaTCFactura
        '
        Me.celdaTCFactura.Location = New System.Drawing.Point(458, 193)
        Me.celdaTCFactura.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTCFactura.Name = "celdaTCFactura"
        Me.celdaTCFactura.Size = New System.Drawing.Size(43, 20)
        Me.celdaTCFactura.TabIndex = 25
        Me.celdaTCFactura.Visible = False
        '
        'etiquetaTipoCambio
        '
        Me.etiquetaTipoCambio.AutoSize = True
        Me.etiquetaTipoCambio.Location = New System.Drawing.Point(184, 203)
        Me.etiquetaTipoCambio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaTipoCambio.Name = "etiquetaTipoCambio"
        Me.etiquetaTipoCambio.Size = New System.Drawing.Size(81, 13)
        Me.etiquetaTipoCambio.TabIndex = 24
        Me.etiquetaTipoCambio.Text = "Exchange Rate"
        '
        'celdaTipoCambio
        '
        Me.celdaTipoCambio.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTipoCambio.Location = New System.Drawing.Point(278, 201)
        Me.celdaTipoCambio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTipoCambio.Name = "celdaTipoCambio"
        Me.celdaTipoCambio.ReadOnly = True
        Me.celdaTipoCambio.Size = New System.Drawing.Size(92, 20)
        Me.celdaTipoCambio.TabIndex = 23
        Me.celdaTipoCambio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaMoneda
        '
        Me.celdaMoneda.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMoneda.Location = New System.Drawing.Point(73, 201)
        Me.celdaMoneda.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMoneda.Name = "celdaMoneda"
        Me.celdaMoneda.ReadOnly = True
        Me.celdaMoneda.Size = New System.Drawing.Size(92, 20)
        Me.celdaMoneda.TabIndex = 22
        Me.celdaMoneda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaMoneda
        '
        Me.etiquetaMoneda.AutoSize = True
        Me.etiquetaMoneda.Location = New System.Drawing.Point(16, 205)
        Me.etiquetaMoneda.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMoneda.Name = "etiquetaMoneda"
        Me.etiquetaMoneda.Size = New System.Drawing.Size(49, 13)
        Me.etiquetaMoneda.TabIndex = 21
        Me.etiquetaMoneda.Text = "Currency"
        '
        'celdaMontoF
        '
        Me.celdaMontoF.Location = New System.Drawing.Point(416, 215)
        Me.celdaMontoF.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMontoF.Name = "celdaMontoF"
        Me.celdaMontoF.Size = New System.Drawing.Size(76, 20)
        Me.celdaMontoF.TabIndex = 20
        Me.celdaMontoF.Visible = False
        '
        'celdaAnioF
        '
        Me.celdaAnioF.Location = New System.Drawing.Point(416, 170)
        Me.celdaAnioF.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnioF.Name = "celdaAnioF"
        Me.celdaAnioF.Size = New System.Drawing.Size(43, 20)
        Me.celdaAnioF.TabIndex = 19
        Me.celdaAnioF.Visible = False
        '
        'celdaNumF
        '
        Me.celdaNumF.Location = New System.Drawing.Point(416, 193)
        Me.celdaNumF.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumF.Name = "celdaNumF"
        Me.celdaNumF.Size = New System.Drawing.Size(43, 20)
        Me.celdaNumF.TabIndex = 18
        Me.celdaNumF.Visible = False
        '
        'celdaCatF
        '
        Me.celdaCatF.Location = New System.Drawing.Point(416, 150)
        Me.celdaCatF.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCatF.Name = "celdaCatF"
        Me.celdaCatF.Size = New System.Drawing.Size(43, 20)
        Me.celdaCatF.TabIndex = 17
        Me.celdaCatF.Visible = False
        '
        'celdaIdProveedor
        '
        Me.celdaIdProveedor.Location = New System.Drawing.Point(362, 101)
        Me.celdaIdProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaIdProveedor.Name = "celdaIdProveedor"
        Me.celdaIdProveedor.Size = New System.Drawing.Size(43, 20)
        Me.celdaIdProveedor.TabIndex = 16
        Me.celdaIdProveedor.Visible = False
        '
        'botonPoliza
        '
        Me.botonPoliza.Image = CType(resources.GetObject("botonPoliza.Image"), System.Drawing.Image)
        Me.botonPoliza.Location = New System.Drawing.Point(194, 160)
        Me.botonPoliza.Margin = New System.Windows.Forms.Padding(2)
        Me.botonPoliza.Name = "botonPoliza"
        Me.botonPoliza.Size = New System.Drawing.Size(27, 24)
        Me.botonPoliza.TabIndex = 15
        Me.botonPoliza.UseVisualStyleBackColor = True
        '
        'botonProveedor
        '
        Me.botonProveedor.Location = New System.Drawing.Point(376, 124)
        Me.botonProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.botonProveedor.Name = "botonProveedor"
        Me.botonProveedor.Size = New System.Drawing.Size(28, 19)
        Me.botonProveedor.TabIndex = 14
        Me.botonProveedor.Text = "..."
        Me.botonProveedor.UseVisualStyleBackColor = True
        '
        'celdaNumeroHDR
        '
        Me.celdaNumeroHDR.Location = New System.Drawing.Point(179, 43)
        Me.celdaNumeroHDR.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumeroHDR.Name = "celdaNumeroHDR"
        Me.celdaNumeroHDR.Size = New System.Drawing.Size(43, 20)
        Me.celdaNumeroHDR.TabIndex = 13
        Me.celdaNumeroHDR.Visible = False
        '
        'celdaAnioOc
        '
        Me.celdaAnioOc.Location = New System.Drawing.Point(179, 66)
        Me.celdaAnioOc.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnioOc.Name = "celdaAnioOc"
        Me.celdaAnioOc.Size = New System.Drawing.Size(43, 20)
        Me.celdaAnioOc.TabIndex = 12
        Me.celdaAnioOc.Visible = False
        '
        'celdaCatalogo
        '
        Me.celdaCatalogo.Location = New System.Drawing.Point(179, 20)
        Me.celdaCatalogo.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaCatalogo.Name = "celdaCatalogo"
        Me.celdaCatalogo.Size = New System.Drawing.Size(43, 20)
        Me.celdaCatalogo.TabIndex = 11
        Me.celdaCatalogo.Visible = False
        '
        'dtpFechaDoc
        '
        Me.dtpFechaDoc.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpFechaDoc.Location = New System.Drawing.Point(73, 50)
        Me.dtpFechaDoc.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpFechaDoc.Name = "dtpFechaDoc"
        Me.dtpFechaDoc.Size = New System.Drawing.Size(92, 20)
        Me.dtpFechaDoc.TabIndex = 10
        '
        'celdaMonto
        '
        Me.celdaMonto.BackColor = System.Drawing.SystemColors.Info
        Me.celdaMonto.Location = New System.Drawing.Point(73, 167)
        Me.celdaMonto.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaMonto.Name = "celdaMonto"
        Me.celdaMonto.Size = New System.Drawing.Size(92, 20)
        Me.celdaMonto.TabIndex = 9
        Me.celdaMonto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'celdaProveedor
        '
        Me.celdaProveedor.Location = New System.Drawing.Point(73, 124)
        Me.celdaProveedor.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaProveedor.Name = "celdaProveedor"
        Me.celdaProveedor.Size = New System.Drawing.Size(300, 20)
        Me.celdaProveedor.TabIndex = 8
        '
        'celdaNumero
        '
        Me.celdaNumero.Location = New System.Drawing.Point(73, 89)
        Me.celdaNumero.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaNumero.Name = "celdaNumero"
        Me.celdaNumero.Size = New System.Drawing.Size(150, 20)
        Me.celdaNumero.TabIndex = 7
        '
        'celdaAnio
        '
        Me.celdaAnio.Location = New System.Drawing.Point(73, 20)
        Me.celdaAnio.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaAnio.Name = "celdaAnio"
        Me.celdaAnio.ReadOnly = True
        Me.celdaAnio.Size = New System.Drawing.Size(92, 20)
        Me.celdaAnio.TabIndex = 5
        '
        'etiquetaMonto
        '
        Me.etiquetaMonto.AutoSize = True
        Me.etiquetaMonto.Location = New System.Drawing.Point(16, 167)
        Me.etiquetaMonto.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaMonto.Name = "etiquetaMonto"
        Me.etiquetaMonto.Size = New System.Drawing.Size(43, 13)
        Me.etiquetaMonto.TabIndex = 4
        Me.etiquetaMonto.Text = "Amount"
        '
        'etiquetaProveedor
        '
        Me.etiquetaProveedor.AutoSize = True
        Me.etiquetaProveedor.Location = New System.Drawing.Point(16, 128)
        Me.etiquetaProveedor.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaProveedor.Name = "etiquetaProveedor"
        Me.etiquetaProveedor.Size = New System.Drawing.Size(45, 13)
        Me.etiquetaProveedor.TabIndex = 3
        Me.etiquetaProveedor.Text = "Supplier"
        '
        'etqiuetaNumero
        '
        Me.etqiuetaNumero.AutoSize = True
        Me.etqiuetaNumero.Location = New System.Drawing.Point(16, 91)
        Me.etqiuetaNumero.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etqiuetaNumero.Name = "etqiuetaNumero"
        Me.etqiuetaNumero.Size = New System.Drawing.Size(44, 13)
        Me.etqiuetaNumero.TabIndex = 2
        Me.etqiuetaNumero.Text = "Number"
        '
        'etiquetaFechaDoc
        '
        Me.etiquetaFechaDoc.AutoSize = True
        Me.etiquetaFechaDoc.Location = New System.Drawing.Point(16, 54)
        Me.etiquetaFechaDoc.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaFechaDoc.Name = "etiquetaFechaDoc"
        Me.etiquetaFechaDoc.Size = New System.Drawing.Size(30, 13)
        Me.etiquetaFechaDoc.TabIndex = 1
        Me.etiquetaFechaDoc.Text = "Date"
        '
        'etiquetaAnio
        '
        Me.etiquetaAnio.AutoSize = True
        Me.etiquetaAnio.Location = New System.Drawing.Point(16, 23)
        Me.etiquetaAnio.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaAnio.Name = "etiquetaAnio"
        Me.etiquetaAnio.Size = New System.Drawing.Size(29, 13)
        Me.etiquetaAnio.TabIndex = 0
        Me.etiquetaAnio.Text = "Year"
        '
        'panelTotal
        '
        Me.panelTotal.Controls.Add(Me.celdaTotal)
        Me.panelTotal.Controls.Add(Me.etiquetaSaldo)
        Me.panelTotal.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panelTotal.Location = New System.Drawing.Point(0, 350)
        Me.panelTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.panelTotal.Name = "panelTotal"
        Me.panelTotal.Size = New System.Drawing.Size(907, 81)
        Me.panelTotal.TabIndex = 2
        '
        'celdaTotal
        '
        Me.celdaTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.celdaTotal.BackColor = System.Drawing.SystemColors.Info
        Me.celdaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.celdaTotal.Location = New System.Drawing.Point(800, 29)
        Me.celdaTotal.Margin = New System.Windows.Forms.Padding(2)
        Me.celdaTotal.Multiline = True
        Me.celdaTotal.Name = "celdaTotal"
        Me.celdaTotal.ReadOnly = True
        Me.celdaTotal.Size = New System.Drawing.Size(99, 28)
        Me.celdaTotal.TabIndex = 1
        Me.celdaTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'etiquetaSaldo
        '
        Me.etiquetaSaldo.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.etiquetaSaldo.AutoSize = True
        Me.etiquetaSaldo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.etiquetaSaldo.Location = New System.Drawing.Point(608, 35)
        Me.etiquetaSaldo.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.etiquetaSaldo.Name = "etiquetaSaldo"
        Me.etiquetaSaldo.Size = New System.Drawing.Size(158, 17)
        Me.etiquetaSaldo.TabIndex = 0
        Me.etiquetaSaldo.Text = "Outstanding balance"
        '
        'BarraTitulo1
        '
        Me.BarraTitulo1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.BarraTitulo1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BarraTitulo1.Location = New System.Drawing.Point(0, 58)
        Me.BarraTitulo1.Name = "BarraTitulo1"
        Me.BarraTitulo1.Size = New System.Drawing.Size(907, 28)
        Me.BarraTitulo1.TabIndex = 1
        '
        'Encabezado1
        '
        Me.Encabezado1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Encabezado1.Location = New System.Drawing.Point(0, 0)
        Me.Encabezado1.Name = "Encabezado1"
        Me.Encabezado1.Size = New System.Drawing.Size(907, 58)
        Me.Encabezado1.TabIndex = 0
        '
        'colAnioFac
        '
        Me.colAnioFac.HeaderText = "Year"
        Me.colAnioFac.Name = "colAnioFac"
        Me.colAnioFac.ReadOnly = True
        Me.colAnioFac.Visible = False
        '
        'colFechaFac
        '
        Me.colFechaFac.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colFechaFac.HeaderText = "Date"
        Me.colFechaFac.Name = "colFechaFac"
        Me.colFechaFac.ReadOnly = True
        Me.colFechaFac.Width = 55
        '
        'colNumeroFac
        '
        Me.colNumeroFac.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.colNumeroFac.HeaderText = "Number"
        Me.colNumeroFac.Name = "colNumeroFac"
        Me.colNumeroFac.ReadOnly = True
        Me.colNumeroFac.Visible = False
        Me.colNumeroFac.Width = 69
        '
        'colUsuarioFac
        '
        Me.colUsuarioFac.HeaderText = "User"
        Me.colUsuarioFac.Name = "colUsuarioFac"
        Me.colUsuarioFac.ReadOnly = True
        Me.colUsuarioFac.Visible = False
        '
        'colREferenciaFac
        '
        Me.colREferenciaFac.HeaderText = "Reference"
        Me.colREferenciaFac.Name = "colREferenciaFac"
        Me.colREferenciaFac.ReadOnly = True
        '
        'colTotalFac
        '
        Me.colTotalFac.HeaderText = "Amount"
        Me.colTotalFac.Name = "colTotalFac"
        Me.colTotalFac.ReadOnly = True
        '
        'colMonedaFac
        '
        Me.colMonedaFac.HeaderText = "Currency"
        Me.colMonedaFac.Name = "colMonedaFac"
        Me.colMonedaFac.ReadOnly = True
        '
        'colTCFac
        '
        Me.colTCFac.HeaderText = "TC"
        Me.colTCFac.Name = "colTCFac"
        Me.colTCFac.ReadOnly = True
        '
        'colEspecialFac
        '
        Me.colEspecialFac.HeaderText = "FacturaEspecial"
        Me.colEspecialFac.Name = "colEspecialFac"
        Me.colEspecialFac.ReadOnly = True
        Me.colEspecialFac.Visible = False
        '
        'colCatalogo
        '
        Me.colCatalogo.HeaderText = "Catalogo"
        Me.colCatalogo.Name = "colCatalogo"
        Me.colCatalogo.ReadOnly = True
        Me.colCatalogo.Visible = False
        '
        'colExtraFact
        '
        Me.colExtraFact.HeaderText = "Extra"
        Me.colExtraFact.Name = "colExtraFact"
        Me.colExtraFact.ReadOnly = True
        Me.colExtraFact.Visible = False
        '
        'colIva
        '
        Me.colIva.HeaderText = "Calculation IVA"
        Me.colIva.Name = "colIva"
        '
        'colLinea
        '
        Me.colLinea.HeaderText = "Linea"
        Me.colLinea.Name = "colLinea"
        Me.colLinea.ReadOnly = True
        Me.colLinea.Visible = False
        '
        'frmRetenIVAProveedor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(907, 601)
        Me.Controls.Add(Me.panelDocumento)
        Me.Controls.Add(Me.panelLista)
        Me.Controls.Add(Me.BarraTitulo1)
        Me.Controls.Add(Me.Encabezado1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "frmRetenIVAProveedor"
        Me.Text = "Retencion IVA Proveedor"
        Me.panelLista.ResumeLayout(False)
        CType(Me.dgLista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelFechas.ResumeLayout(False)
        Me.panelFechas.PerformLayout()
        Me.panelDocumento.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.gbFacturas.ResumeLayout(False)
        CType(Me.dgFactura, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panelEncabezado.ResumeLayout(False)
        Me.gbPagos.ResumeLayout(False)
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbEncabezado.ResumeLayout(False)
        Me.gbEncabezado.PerformLayout()
        Me.panelTotal.ResumeLayout(False)
        Me.panelTotal.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Encabezado1 As encabezado
    Friend WithEvents BarraTitulo1 As BarraTitulo
    Friend WithEvents panelLista As Panel
    Friend WithEvents dgLista As DataGridView
    Friend WithEvents panelFechas As Panel
    Friend WithEvents etiquetaFecha As Label
    Friend WithEvents dtpFechaFinal As DateTimePicker
    Friend WithEvents dtpFechaInicial As DateTimePicker
    Friend WithEvents checkFecha As System.Windows.Forms.CheckBox
    Friend WithEvents panelDocumento As Panel
    Friend WithEvents panelEncabezado As Panel
    Friend WithEvents gbFacturas As GroupBox
    Friend WithEvents gbEncabezado As GroupBox
    Friend WithEvents botonPoliza As Button
    Friend WithEvents botonProveedor As Button
    Friend WithEvents celdaNumeroHDR As TextBox
    Friend WithEvents celdaAnioOc As TextBox
    Friend WithEvents dtpFechaDoc As DateTimePicker
    Friend WithEvents celdaMonto As TextBox
    Friend WithEvents celdaProveedor As TextBox
    Friend WithEvents celdaNumero As TextBox
    Friend WithEvents celdaAnio As TextBox
    Friend WithEvents etiquetaMonto As Label
    Friend WithEvents etiquetaProveedor As Label
    Friend WithEvents etqiuetaNumero As Label
    Friend WithEvents etiquetaFechaDoc As Label
    Friend WithEvents etiquetaAnio As Label
    Friend WithEvents dgFactura As DataGridView
    Friend WithEvents gbPagos As GroupBox
    Friend WithEvents dgDatos As DataGridView
    Friend WithEvents panelTotal As Panel
    Friend WithEvents celdaTotal As TextBox
    Friend WithEvents etiquetaSaldo As Label
    Friend WithEvents botonActualizar As Button
    Friend WithEvents celdaIdProveedor As TextBox
    Friend WithEvents celdaCatalogo As TextBox
    Friend WithEvents celdaAnioF As TextBox
    Friend WithEvents celdaNumF As TextBox
    Friend WithEvents celdaCatF As TextBox
    Friend WithEvents celdaMontoF As TextBox
    Friend WithEvents etiquetaTipoCambio As Label
    Friend WithEvents celdaTipoCambio As TextBox
    Friend WithEvents celdaMoneda As TextBox
    Friend WithEvents etiquetaMoneda As Label
    Friend WithEvents celdaTCFactura As TextBox
    Friend WithEvents celdaIDMoneda As TextBox
    Friend WithEvents checkFacturaEspecial As System.Windows.Forms.CheckBox
    Friend WithEvents colCheque As DataGridViewTextBoxColumn
    Friend WithEvents colFechaDoc As DataGridViewTextBoxColumn
    Friend WithEvents colMoneda As DataGridViewTextBoxColumn
    Friend WithEvents colTasa As DataGridViewTextBoxColumn
    Friend WithEvents colBanco As DataGridViewTextBoxColumn
    Friend WithEvents colTota1 As DataGridViewTextBoxColumn
    Friend WithEvents checkActivo As System.Windows.Forms.CheckBox
    Friend WithEvents dtpFechaPolizaC As DateTimePicker
    Friend WithEvents etiquetaFecha1 As Label
    Friend WithEvents colAnio As DataGridViewTextBoxColumn
    Friend WithEvents colNumero As DataGridViewTextBoxColumn
    Friend WithEvents colId As DataGridViewTextBoxColumn
    Friend WithEvents colFecha As DataGridViewTextBoxColumn
    Friend WithEvents colNombre As DataGridViewTextBoxColumn
    Friend WithEvents colMonto As DataGridViewTextBoxColumn
    Friend WithEvents colFactura As DataGridViewTextBoxColumn
    Friend WithEvents colTotal As DataGridViewTextBoxColumn
    Friend WithEvents catalogo As DataGridViewTextBoxColumn
    Friend WithEvents colEstado As DataGridViewTextBoxColumn
    Friend WithEvents Panel2 As Panel
    Friend WithEvents botonAgregar As Button
    Friend WithEvents botonQuitar As Button
    Friend WithEvents celdaRecibos As TextBox
    Friend WithEvents colAnioFac As DataGridViewTextBoxColumn
    Friend WithEvents colFechaFac As DataGridViewTextBoxColumn
    Friend WithEvents colNumeroFac As DataGridViewTextBoxColumn
    Friend WithEvents colUsuarioFac As DataGridViewTextBoxColumn
    Friend WithEvents colREferenciaFac As DataGridViewTextBoxColumn
    Friend WithEvents colTotalFac As DataGridViewTextBoxColumn
    Friend WithEvents colMonedaFac As DataGridViewTextBoxColumn
    Friend WithEvents colTCFac As DataGridViewTextBoxColumn
    Friend WithEvents colEspecialFac As DataGridViewTextBoxColumn
    Friend WithEvents colCatalogo As DataGridViewTextBoxColumn
    Friend WithEvents colExtraFact As DataGridViewTextBoxColumn
    Friend WithEvents colIva As DataGridViewTextBoxColumn
    Friend WithEvents colLinea As DataGridViewTextBoxColumn
End Class
