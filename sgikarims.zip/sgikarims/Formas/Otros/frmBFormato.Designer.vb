﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBFormato
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBFormato))
        Me.Lista = New System.Windows.Forms.DataGridView()
        Me.lista_item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_campo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lista_texto = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelTitulo = New System.Windows.Forms.Panel()
        Me.EtiquetaTitulo = New System.Windows.Forms.Label()
        Me.BotonINI = New System.Windows.Forms.Button()
        Me.BotonGuardar = New System.Windows.Forms.Button()
        Me.BotonCerrar = New System.Windows.Forms.Button()
        Me.LoadFile = New System.Windows.Forms.OpenFileDialog()
        CType(Me.Lista, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelTitulo.SuspendLayout()
        Me.SuspendLayout()
        '
        'Lista
        '
        Me.Lista.AllowUserToAddRows = False
        Me.Lista.AllowUserToDeleteRows = False
        Me.Lista.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Lista.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.Lista.BackgroundColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Lista.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Lista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Lista.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.lista_item, Me.lista_campo, Me.lista_texto})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Lista.DefaultCellStyle = DataGridViewCellStyle2
        Me.Lista.Location = New System.Drawing.Point(12, 35)
        Me.Lista.MultiSelect = False
        Me.Lista.Name = "Lista"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Lista.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Lista.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Lista.Size = New System.Drawing.Size(396, 105)
        Me.Lista.TabIndex = 1
        '
        'lista_item
        '
        Me.lista_item.HeaderText = "Item"
        Me.lista_item.Name = "lista_item"
        Me.lista_item.ReadOnly = True
        Me.lista_item.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_item.Width = 40
        '
        'lista_campo
        '
        Me.lista_campo.HeaderText = "Field"
        Me.lista_campo.Name = "lista_campo"
        Me.lista_campo.ReadOnly = True
        Me.lista_campo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_campo.Width = 125
        '
        'lista_texto
        '
        Me.lista_texto.HeaderText = "Position & Width (X.Y.W)"
        Me.lista_texto.Name = "lista_texto"
        Me.lista_texto.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.lista_texto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.lista_texto.Width = 165
        '
        'PanelTitulo
        '
        Me.PanelTitulo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelTitulo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PanelTitulo.Controls.Add(Me.EtiquetaTitulo)
        Me.PanelTitulo.Location = New System.Drawing.Point(12, 12)
        Me.PanelTitulo.Name = "PanelTitulo"
        Me.PanelTitulo.Size = New System.Drawing.Size(396, 24)
        Me.PanelTitulo.TabIndex = 0
        '
        'EtiquetaTitulo
        '
        Me.EtiquetaTitulo.AutoSize = True
        Me.EtiquetaTitulo.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EtiquetaTitulo.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.EtiquetaTitulo.Location = New System.Drawing.Point(6, 3)
        Me.EtiquetaTitulo.Name = "EtiquetaTitulo"
        Me.EtiquetaTitulo.Size = New System.Drawing.Size(287, 16)
        Me.EtiquetaTitulo.TabIndex = 0
        Me.EtiquetaTitulo.Text = "Items Position (expressed in millimeters)"
        '
        'BotonINI
        '
        Me.BotonINI.Image = Global.KARIMs_SGI.My.Resources.Resources.folder_document
        Me.BotonINI.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonINI.Location = New System.Drawing.Point(12, 151)
        Me.BotonINI.Name = "BotonINI"
        Me.BotonINI.Size = New System.Drawing.Size(65, 40)
        Me.BotonINI.TabIndex = 2
        Me.BotonINI.Text = "Load INI"
        Me.BotonINI.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonINI.UseVisualStyleBackColor = True
        '
        'BotonGuardar
        '
        Me.BotonGuardar.Image = Global.KARIMs_SGI.My.Resources.Resources.next_set_2
        Me.BotonGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonGuardar.Location = New System.Drawing.Point(292, 151)
        Me.BotonGuardar.Name = "BotonGuardar"
        Me.BotonGuardar.Size = New System.Drawing.Size(55, 40)
        Me.BotonGuardar.TabIndex = 3
        Me.BotonGuardar.Text = "Save"
        Me.BotonGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonGuardar.UseVisualStyleBackColor = True
        '
        'BotonCerrar
        '
        Me.BotonCerrar.Image = Global.KARIMs_SGI.My.Resources.Resources.db_cancel
        Me.BotonCerrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.BotonCerrar.Location = New System.Drawing.Point(353, 151)
        Me.BotonCerrar.Name = "BotonCerrar"
        Me.BotonCerrar.Size = New System.Drawing.Size(55, 40)
        Me.BotonCerrar.TabIndex = 4
        Me.BotonCerrar.Text = "Close"
        Me.BotonCerrar.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.BotonCerrar.UseVisualStyleBackColor = True
        '
        'LoadFile
        '
        Me.LoadFile.DefaultExt = "ini"
        Me.LoadFile.Filter = "INI File|*.ini"
        Me.LoadFile.Title = "Load positions from INI"
        '
        'frmBFormato
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 203)
        Me.Controls.Add(Me.BotonINI)
        Me.Controls.Add(Me.Lista)
        Me.Controls.Add(Me.PanelTitulo)
        Me.Controls.Add(Me.BotonGuardar)
        Me.Controls.Add(Me.BotonCerrar)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmBFormato"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Check Printing Configuration"
        CType(Me.Lista, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelTitulo.ResumeLayout(False)
        Me.PanelTitulo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BotonGuardar As Button
    Friend WithEvents BotonCerrar As Button
    Friend WithEvents Lista As DataGridView
    Friend WithEvents PanelTitulo As Panel
    Friend WithEvents EtiquetaTitulo As Label
    Friend WithEvents lista_item As DataGridViewTextBoxColumn
    Friend WithEvents lista_campo As DataGridViewTextBoxColumn
    Friend WithEvents lista_texto As DataGridViewTextBoxColumn
    Friend WithEvents BotonINI As Button
    Friend WithEvents LoadFile As OpenFileDialog
End Class
